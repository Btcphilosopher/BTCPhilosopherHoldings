package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.HealthAndSafety
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Radar
import androidx.compose.material.icons.filled.Sensors
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.domain.geo.GeoMath
import com.example.domain.model.AlertResolutionState
import com.example.domain.model.AppSettingsState
import com.example.domain.model.ConnectionState
import com.example.domain.model.ScenarioId
import com.example.ui.RadarScreenState
import com.example.ui.components.InstrumentPanel
import com.example.ui.components.InstrumentSectionHeader
import com.example.ui.components.KeyValueReadout
import com.example.ui.components.StatusPill
import com.example.ui.theme.LocalAureomColors
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

@Composable
fun HomeScreen(
    state: RadarScreenState,
    settings: AppSettingsState,
    onStartSimulation: (ScenarioId) -> Unit,
    onOpenRadar: () -> Unit,
    onOpenReplay: () -> Unit,
    onOpenSources: () -> Unit,
    onOpenAlerts: () -> Unit,
    onOpenHealth: () -> Unit,
    onOpenSettings: () -> Unit,
    modifier: Modifier = Modifier
) {
    val colors = LocalAureomColors.current
    val utcFmt = remember {
        SimpleDateFormat("yyyy-MM-dd HH:mm:ss'Z'", Locale.US).apply {
            timeZone = TimeZone.getTimeZone("UTC")
        }
    }
    val connectedCount = state.sources.count { it.connectionState == ConnectionState.CONNECTED }
    val activeAlerts = state.alerts.count { it.resolutionState == AlertResolutionState.ACTIVE }
    val lastConnText = state.lastConnectionTimestampMs?.let { utcFmt.format(Date(it)) } ?: "NO LINK YET"

    BoxWithConstraints(
        modifier = modifier
            .fillMaxSize()
            .background(colors.scopeBackground)
    ) {
        val isWide = maxWidth >= 700.dp

        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Hero Aerospace Instrument Status Card
            InstrumentPanel(borderColor = colors.cyanMuted) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "AUREOM VECTOR",
                            style = MaterialTheme.typography.displaySmall,
                            color = colors.textPrimary
                        )
                        Text(
                            text = "Radar & Situational Awareness Instrument",
                            style = MaterialTheme.typography.bodyMedium,
                            color = colors.textSecondary
                        )
                    }
                    StatusPill(
                        text = state.operatingMode.label,
                        color = colors.cyan
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                if (isWide) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            KeyValueReadout("Observation Area", state.observationArea.name)
                            KeyValueReadout(
                                "Origin Reference",
                                GeoMath.formatCoordinate(state.observationArea.center, settings.coordinateFormat)
                            )
                            KeyValueReadout("Coordinate Frame", state.observationArea.referenceFrame)
                        }
                        Column(modifier = Modifier.weight(1f)) {
                            KeyValueReadout("Available Sources", "$connectedCount / ${state.sources.size} Online")
                            KeyValueReadout("Last Connection", lastConnText)
                            KeyValueReadout(
                                "Active Picture",
                                "${state.predictions.size} Tracks • $activeAlerts Active Alerts",
                                valueColor = if (activeAlerts > 0) colors.critical else colors.phosphor
                            )
                        }
                    }
                } else {
                    KeyValueReadout("Observation Area", state.observationArea.name)
                    KeyValueReadout(
                        "Origin",
                        GeoMath.formatCoordinate(state.observationArea.center, settings.coordinateFormat)
                    )
                    KeyValueReadout("Available Sources", "$connectedCount / ${state.sources.size} Online")
                    KeyValueReadout("Last Connection", lastConnText)
                    KeyValueReadout(
                        "Active Picture",
                        "${state.predictions.size} Tracks • $activeAlerts Active Alerts",
                        valueColor = if (activeAlerts > 0) colors.critical else colors.phosphor
                    )
                }
            }

            // Synthetic Training Scenario Selector (Featuring North Sea Observation)
            InstrumentPanel {
                InstrumentSectionHeader(
                    title = "Operational & Training Scenarios",
                    trailing = "Seed ${state.simulatorConfig.seed}"
                )
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    ScenarioId.entries.forEach { scenario ->
                        val selected = state.scenarioId == scenario
                        FilterChip(
                            selected = selected,
                            onClick = { onStartSimulation(scenario) },
                            label = {
                                Text(
                                    text = scenario.title,
                                    style = MaterialTheme.typography.labelMedium
                                )
                            },
                            modifier = Modifier
                                .testTag("scenario_chip_${scenario.name}")
                                .heightIn(min = 48.dp)
                        )
                    }
                }
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = state.scenarioId.subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = colors.textSecondary
                )
                Spacer(modifier = Modifier.height(10.dp))
                Button(
                    onClick = { onStartSimulation(ScenarioId.NORTH_SEA_OBSERVATION) },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = colors.phosphor,
                        contentColor = colors.scopeBackground
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(min = 54.dp)
                        .testTag("start_simulation_button")
                ) {
                    Icon(Icons.Default.PlayArrow, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Start Simulation — North Sea Observation",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            // 7 Primary Instrument Actions Grid (Glove & Tablet friendly >= 64.dp targets)
            InstrumentSectionHeader(title = "Instrument Subsystems")

            val actions = listOf(
                HomeActionItem(
                    tag = "action_open_radar",
                    title = "Open Radar",
                    subtitle = "PPI scope, tracks, zones & tabular picture",
                    icon = Icons.Default.Radar,
                    accent = colors.phosphor,
                    onClick = onOpenRadar
                ),
                HomeActionItem(
                    tag = "action_replay_session",
                    title = "Replay Session",
                    subtitle = "Deterministic playback, seek & report export",
                    icon = Icons.Default.History,
                    accent = colors.amber,
                    onClick = onOpenReplay
                ),
                HomeActionItem(
                    tag = "action_configure_sources",
                    title = "Configure Sources",
                    subtitle = "Synthetic sim, Ktor WebSocket & outages",
                    icon = Icons.Default.Sensors,
                    accent = colors.cyan,
                    onClick = onOpenSources
                ),
                HomeActionItem(
                    tag = "action_review_alerts",
                    title = "Review Alerts",
                    subtitle = "$activeAlerts active alerts • Acknowledge & notes",
                    icon = Icons.Default.NotificationsActive,
                    accent = if (activeAlerts > 0) colors.critical else colors.textPrimary,
                    onClick = onOpenAlerts
                ),
                HomeActionItem(
                    tag = "action_system_health",
                    title = "System Health",
                    subtitle = "Frame time, latency, memory & queue metrics",
                    icon = Icons.Default.HealthAndSafety,
                    accent = colors.phosphor,
                    onClick = onOpenHealth
                ),
                HomeActionItem(
                    tag = "action_settings",
                    title = "Settings",
                    subtitle = "Day/Night, units, accessibility & motion",
                    icon = Icons.Default.Settings,
                    accent = colors.textSecondary,
                    onClick = onOpenSettings
                )
            )

            val columns = if (isWide) 3 else 2
            actions.chunked(columns).forEach { rowItems ->
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    rowItems.forEach { item ->
                        HomeActionCard(
                            item = item,
                            modifier = Modifier.weight(1f)
                        )
                    }
                    if (rowItems.size < columns) {
                        repeat(columns - rowItems.size) {
                            Spacer(modifier = Modifier.weight(1f))
                        }
                    }
                }
            }
        }
    }
}

private data class HomeActionItem(
    val tag: String,
    val title: String,
    val subtitle: String,
    val icon: ImageVector,
    val accent: Color,
    val onClick: () -> Unit
)

@Composable
private fun HomeActionCard(
    item: HomeActionItem,
    modifier: Modifier = Modifier
) {
    val colors = LocalAureomColors.current
    Surface(
        modifier = modifier
            .heightIn(min = 96.dp)
            .testTag(item.tag)
            .clickable(onClick = item.onClick),
        color = colors.panelSurface,
        shape = RoundedCornerShape(6.dp),
        border = BorderStroke(1.dp, colors.panelBorder)
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    imageVector = item.icon,
                    contentDescription = item.title,
                    tint = item.accent,
                    modifier = Modifier.size(22.dp)
                )
                Text(
                    text = item.title,
                    style = MaterialTheme.typography.titleMedium,
                    color = colors.textPrimary,
                    fontWeight = FontWeight.SemiBold
                )
            }
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = item.subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = colors.textSecondary
            )
        }
    }
}
