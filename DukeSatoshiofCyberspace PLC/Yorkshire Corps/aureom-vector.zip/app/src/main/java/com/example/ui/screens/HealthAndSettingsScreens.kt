package com.example.ui.screens

import android.os.Build
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.domain.model.AppSettingsState
import com.example.domain.model.CoordinateFormat
import com.example.domain.model.DeviceTelemetryState
import com.example.domain.model.DistanceUnit
import com.example.ui.RadarScreenState
import com.example.ui.components.InstrumentPanel
import com.example.ui.components.InstrumentSectionHeader
import com.example.ui.components.KeyValueReadout
import com.example.ui.components.StatusPill
import com.example.ui.theme.LocalAureomColors
import java.util.Locale

@Composable
fun SystemHealthScreen(
    state: RadarScreenState,
    telemetry: DeviceTelemetryState,
    modifier: Modifier = Modifier
) {
    val colors = LocalAureomColors.current
    val m = state.metrics

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(colors.scopeBackground)
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        InstrumentPanel(borderColor = colors.cyanMuted) {
            InstrumentSectionHeader("Measured Runtime Performance", trailing = Build.MODEL)
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "Live measurements captured from Compose frame callbacks, JVM runtime heap, and ingestion-to-state pipeline on the active device/emulator.",
                style = MaterialTheme.typography.bodySmall,
                color = colors.textSecondary
            )
            Spacer(modifier = Modifier.height(8.dp))
            KeyValueReadout(
                "Measured Frame Time",
                String.format(Locale.US, "%.2f ms (%.1f FPS)", m.frameTimeMs, m.estimatedFps),
                valueColor = if (m.frameTimeMs <= 20.0) colors.phosphor else colors.amber
            )
            KeyValueReadout(
                "JVM Heap Memory",
                String.format(Locale.US, "%.1f MB / %.1f MB max", m.usedMemoryMb, m.maxMemoryMb)
            )
            KeyValueReadout(
                "Track Update Latency",
                "${m.updateLatencyMs} ms (ingestion -> prediction)"
            )
            KeyValueReadout(
                "Bounded Queue Depth",
                "${m.queueDepth} / ${m.maxQueueDepth} (Drops: ${m.droppedBackpressureCount})"
            )
            KeyValueReadout(
                "Total Observations",
                "${m.totalObservationsProcessed} processed • ${m.activeTracksCount} active tracks"
            )
            KeyValueReadout("Power / Duty Profile", m.batteryDrainEstimate)
        }

        InstrumentPanel {
            InstrumentSectionHeader("Device Sensor Subsystems")
            Spacer(modifier = Modifier.height(6.dp))
            KeyValueReadout("GNSS Status", telemetry.gnssAvailability.label)
            KeyValueReadout("GNSS Provider", telemetry.gnssProvider)
            KeyValueReadout("Orientation Sensor", telemetry.orientationAvailability.label)
            KeyValueReadout("Orientation Accuracy", telemetry.orientationAccuracyLabel)
        }

        InstrumentPanel {
            InstrumentSectionHeader("Pipeline Separation & Guardrails")
            Spacer(modifier = Modifier.height(6.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                StatusPill("RENDERING DECOUPLED", colors.phosphor)
                StatusPill("BOUNDED HISTORY (120)", colors.cyan)
            }
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "• UI Canvas drawing executes on Main/Render thread reading immutable StateFlow snapshots.\n" +
                    "• Track association & alert evaluation run on Dispatchers.Default.\n" +
                    "• Room persistence & WebSocket I/O run on Dispatchers.IO with DROP_OLDEST backpressure.",
                style = MaterialTheme.typography.bodySmall,
                color = colors.textSecondary
            )
        }
    }
}

@Composable
fun SettingsScreen(
    settings: AppSettingsState,
    onUpdateSettings: ((AppSettingsState) -> AppSettingsState) -> Unit,
    modifier: Modifier = Modifier
) {
    val colors = LocalAureomColors.current

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(colors.scopeBackground)
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        InstrumentPanel {
            InstrumentSectionHeader("Display & Accessibility")
            Spacer(modifier = Modifier.height(8.dp))

            SettingsSwitchRow(
                title = "Night Tactical Display Mode",
                subtitle = "Matte graphite & phosphor palette (disable for Day cockpit mode)",
                checked = settings.nightMode,
                tag = "setting_night_mode",
                onCheckedChange = { v -> onUpdateSettings { it.copy(nightMode = v) } }
            )

            SettingsSwitchRow(
                title = "Reduced Motion",
                subtitle = "Disables continuous radar sweep animation and motion transitions",
                checked = settings.reducedMotion,
                tag = "setting_reduced_motion",
                onCheckedChange = { v -> onUpdateSettings { it.copy(reducedMotion = v) } }
            )

            SettingsSwitchRow(
                title = "Colour-Blind-Friendly Symbols",
                subtitle = "Adds high-contrast geometric center markers across all track categories",
                checked = settings.colorBlindSymbols,
                tag = "setting_color_blind",
                onCheckedChange = { v -> onUpdateSettings { it.copy(colorBlindSymbols = v) } }
            )

            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "Text Size Scale: ${String.format(Locale.US, "%.2fx", settings.textScale)}",
                style = MaterialTheme.typography.labelMedium,
                color = colors.textPrimary
            )
            Slider(
                value = settings.textScale,
                onValueChange = { scale -> onUpdateSettings { it.copy(textScale = scale) } },
                valueRange = 0.85f..1.30f
            )
        }

        InstrumentPanel {
            InstrumentSectionHeader("Coordinate & Unit Standards")
            Spacer(modifier = Modifier.height(8.dp))
            Text("Coordinate Format", style = MaterialTheme.typography.labelSmall, color = colors.textSecondary)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                CoordinateFormat.entries.forEach { fmt ->
                    FilterChip(
                        selected = settings.coordinateFormat == fmt,
                        onClick = { onUpdateSettings { it.copy(coordinateFormat = fmt) } },
                        label = { Text(fmt.label.substringBefore(" ("), style = MaterialTheme.typography.labelSmall) },
                        modifier = Modifier.heightIn(min = 48.dp)
                    )
                }
            }
            Spacer(modifier = Modifier.height(8.dp))
            Text("Distance & Speed Units", style = MaterialTheme.typography.labelSmall, color = colors.textSecondary)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                DistanceUnit.entries.forEach { unit ->
                    FilterChip(
                        selected = settings.distanceUnit == unit,
                        onClick = { onUpdateSettings { it.copy(distanceUnit = unit) } },
                        label = { Text(unit.label.substringBefore(" ("), style = MaterialTheme.typography.labelSmall) },
                        modifier = Modifier.heightIn(min = 48.dp)
                    )
                }
            }
        }

        InstrumentPanel {
            InstrumentSectionHeader("Track Ageing & Extrapolation Guardrails")
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "Stale Track Threshold: ${settings.staleThresholdSec}s",
                style = MaterialTheme.typography.labelMedium,
                color = colors.textPrimary
            )
            Slider(
                value = settings.staleThresholdSec.toFloat(),
                onValueChange = { v -> onUpdateSettings { it.copy(staleThresholdSec = v.toInt()) } },
                valueRange = 5f..60f
            )
            Text(
                text = "Max Extrapolation Cap: ${settings.maxExtrapolationSec}s",
                style = MaterialTheme.typography.labelMedium,
                color = colors.textPrimary
            )
            Slider(
                value = settings.maxExtrapolationSec.toFloat(),
                onValueChange = { v -> onUpdateSettings { it.copy(maxExtrapolationSec = v.toInt()) } },
                valueRange = 5f..60f
            )
        }
    }
}

@Composable
private fun SettingsSwitchRow(
    title: String,
    subtitle: String,
    checked: Boolean,
    tag: String,
    onCheckedChange: (Boolean) -> Unit
) {
    val colors = LocalAureomColors.current
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f).padding(end = 12.dp)) {
            Text(title, style = MaterialTheme.typography.titleSmall, color = colors.textPrimary)
            Text(subtitle, style = MaterialTheme.typography.bodySmall, color = colors.textSecondary)
        }
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            modifier = Modifier.testTag(tag)
        )
    }
}
