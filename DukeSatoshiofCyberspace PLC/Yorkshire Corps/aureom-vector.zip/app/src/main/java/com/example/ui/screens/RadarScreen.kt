package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddLocationAlt
import androidx.compose.material.icons.filled.CenterFocusStrong
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.filled.FiberManualRecord
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.SignalWifiOff
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.TableChart
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.domain.geo.GeoMath
import com.example.domain.model.AppSettingsState
import com.example.domain.model.DeviceTelemetryState
import com.example.domain.model.DisplayPrediction
import com.example.domain.model.OperatingMode
import com.example.domain.model.PositionQuality
import com.example.domain.model.RadarOrientationMode
import com.example.domain.model.TrackStatus
import com.example.ui.RadarScreenState
import com.example.ui.components.InstrumentPanel
import com.example.ui.components.InstrumentSectionHeader
import com.example.ui.components.StatusPill
import com.example.ui.radar.RadarScopeCanvas
import com.example.ui.radar.RadarViewportState
import com.example.ui.radar.TrackInspectorPanel
import com.example.ui.theme.LocalAureomColors

@Composable
fun RadarScreen(
    state: RadarScreenState,
    settings: AppSettingsState,
    telemetry: DeviceTelemetryState,
    onSelectTrack: (String?) -> Unit,
    onRangeChange: (Double) -> Unit,
    onToggleOrientationMode: () -> Unit,
    onToggleMapOverlay: () -> Unit,
    onCycleTrailLength: () -> Unit,
    onToggleRecording: () -> Unit,
    onToggleOutage: () -> Unit,
    onOpenHud: () -> Unit,
    onCreateZone: (name: String, radiusNm: Double, loiterSec: Int, offsetBrg: Double, offsetDistNm: Double) -> Unit,
    onSaveAnnotation: (String, String) -> Unit,
    onUpdateSettings: ((AppSettingsState) -> AppSettingsState) -> Unit,
    onToggleReplayPause: () -> Unit,
    onFrameDurationMs: (Double) -> Unit,
    modifier: Modifier = Modifier
) {
    val colors = LocalAureomColors.current
    var viewport by remember { mutableStateOf(RadarViewportState()) }
    var showTabularView by remember { mutableStateOf(false) }
    var showAddZoneDialog by remember { mutableStateOf(false) }

    val selectedPrediction = remember(state.predictions, state.selectedTrackId) {
        state.predictions.firstOrNull { it.track.trackId == state.selectedTrackId }
    }
    val ownPos = telemetry.gnssPosition ?: state.observationArea.center

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(colors.scopeBackground)
    ) {
        // Top Radar Control Toolbar (Glove-friendly 48dp+ controls)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(colors.panelSurface)
                .border(1.dp, colors.panelBorder)
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 8.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Range presets
            state.scenarioId.rangePresetsNm.forEach { preset ->
                FilterChip(
                    selected = kotlin.math.abs(state.rangeNm - preset) < 0.05,
                    onClick = { onRangeChange(preset) },
                    label = {
                        Text(
                            text = if (preset < 1.0) "${preset} NM" else "${preset.toInt()} NM",
                            style = MaterialTheme.typography.labelSmall
                        )
                    },
                    modifier = Modifier.heightIn(min = 48.dp)
                )
            }

            OutlinedButton(
                onClick = onToggleOrientationMode,
                modifier = Modifier.heightIn(min = 48.dp).testTag("toggle_orientation_button")
            ) {
                Icon(Icons.Default.Explore, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = if (settings.orientationMode == RadarOrientationMode.NORTH_UP) "N-UP" else "HDG-UP",
                    style = MaterialTheme.typography.labelSmall
                )
            }

            OutlinedButton(
                onClick = onCycleTrailLength,
                modifier = Modifier.heightIn(min = 48.dp)
            ) {
                Text("Trail:${settings.trailLength}", style = MaterialTheme.typography.labelSmall)
            }

            OutlinedButton(
                onClick = onToggleMapOverlay,
                modifier = Modifier.heightIn(min = 48.dp)
            ) {
                Icon(Icons.Default.Layers, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text(if (settings.showMapOverlay) "Map:ON" else "Map:OFF", style = MaterialTheme.typography.labelSmall)
            }

            OutlinedButton(
                onClick = { showTabularView = !showTabularView },
                modifier = Modifier.heightIn(min = 48.dp).testTag("toggle_tabular_button")
            ) {
                Icon(Icons.Default.TableChart, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text(if (showTabularView) "Scope" else "Table", style = MaterialTheme.typography.labelSmall)
            }

            OutlinedButton(
                onClick = { showAddZoneDialog = true },
                modifier = Modifier.heightIn(min = 48.dp).testTag("add_zone_button")
            ) {
                Icon(Icons.Default.AddLocationAlt, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("+Zone", style = MaterialTheme.typography.labelSmall)
            }

            if (state.operatingMode != OperatingMode.REPLAY) {
                Button(
                    onClick = onToggleRecording,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (state.isRecording) colors.critical else colors.elevatedSurface,
                        contentColor = if (state.isRecording) colors.scopeBackground else colors.textPrimary
                    ),
                    border = BorderStroke(1.dp, if (state.isRecording) colors.critical else colors.panelBorder),
                    modifier = Modifier.heightIn(min = 48.dp).testTag("record_session_button")
                ) {
                    Icon(
                        imageVector = if (state.isRecording) Icons.Default.Stop else Icons.Default.FiberManualRecord,
                        contentDescription = "Record session",
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = if (state.isRecording) "Stop (${state.recordingObservationCount})" else "Record",
                        style = MaterialTheme.typography.labelSmall
                    )
                }

                OutlinedButton(
                    onClick = onToggleOutage,
                    border = BorderStroke(
                        1.dp,
                        if (state.simulatorConfig.sensorOutageActive) colors.critical else colors.panelBorder
                    ),
                    modifier = Modifier.heightIn(min = 48.dp).testTag("toggle_outage_button")
                ) {
                    Icon(
                        Icons.Default.SignalWifiOff,
                        contentDescription = null,
                        tint = if (state.simulatorConfig.sensorOutageActive) colors.critical else colors.textSecondary,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = if (state.simulatorConfig.sensorOutageActive) "Restore Src" else "Sim Outage",
                        color = if (state.simulatorConfig.sensorOutageActive) colors.critical else colors.textPrimary,
                        style = MaterialTheme.typography.labelSmall
                    )
                }
            } else {
                Button(
                    onClick = onToggleReplayPause,
                    colors = ButtonDefaults.buttonColors(containerColor = colors.amber, contentColor = colors.scopeBackground),
                    modifier = Modifier.heightIn(min = 48.dp)
                ) {
                    Icon(
                        if (state.replayPlayback.isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(if (state.replayPlayback.isPlaying) "Pause" else "Resume", style = MaterialTheme.typography.labelSmall)
                }
            }

            OutlinedButton(
                onClick = { viewport = RadarViewportState() },
                modifier = Modifier.heightIn(min = 48.dp).testTag("reset_view_button")
            ) {
                Icon(Icons.Default.CenterFocusStrong, contentDescription = "Reset view", modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("Reset", style = MaterialTheme.typography.labelSmall)
            }

            Button(
                onClick = onOpenHud,
                colors = ButtonDefaults.buttonColors(containerColor = colors.cyan, contentColor = colors.scopeBackground),
                modifier = Modifier.heightIn(min = 48.dp).testTag("open_hud_button")
            ) {
                Icon(Icons.Default.Visibility, contentDescription = "Open HUD mode", modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("HUD", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
            }
        }

        // Conspicuous Outage / Disconnect Warning Banner
        if (state.simulatorConfig.sensorOutageActive ||
            (state.operatingMode == OperatingMode.LIVE_OBSERVATION && state.sources.any { it.outageActive })
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(colors.criticalBg)
                    .border(1.dp, colors.critical)
                    .padding(horizontal = 12.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "SOURCE OUTAGE ACTIVE — Retaining last known positions. Extrapolation strictly bounded.",
                    style = MaterialTheme.typography.labelSmall,
                    color = colors.critical,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        // Adaptive Tablet Landscape Two-Pane vs Portrait Layout
        BoxWithConstraints(modifier = Modifier.weight(1f).fillMaxWidth()) {
            val isLandscapeTablet = maxWidth >= 720.dp

            if (isLandscapeTablet) {
                Row(modifier = Modifier.fillMaxSize()) {
                    Box(modifier = Modifier.weight(1.6f).fillMaxHeight().padding(8.dp)) {
                        if (showTabularView) {
                            TabularTrackList(
                                predictions = state.predictions,
                                selectedTrackId = state.selectedTrackId,
                                settings = settings,
                                onSelectTrack = onSelectTrack
                            )
                        } else {
                            RadarScopeCanvas(
                                area = state.observationArea,
                                rangeNm = state.rangeNm,
                                predictions = state.predictions,
                                zones = state.zones,
                                alerts = state.alerts,
                                selectedTrackId = state.selectedTrackId,
                                ownPosition = ownPos,
                                headingUpDegrees = telemetry.deviceHeadingDeg,
                                settings = settings,
                                viewport = viewport,
                                onViewportChange = { viewport = it },
                                onTrackSelected = onSelectTrack,
                                onFrameDurationMs = onFrameDurationMs,
                                modifier = Modifier.fillMaxSize()
                            )
                        }
                    }

                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxHeight()
                            .padding(top = 8.dp, end = 8.dp, bottom = 8.dp)
                    ) {
                        if (selectedPrediction != null) {
                            TrackInspectorPanel(
                                prediction = selectedPrediction,
                                annotation = state.annotations[selectedPrediction.track.trackId],
                                settings = settings,
                                onSaveAnnotation = onSaveAnnotation,
                                onClose = { onSelectTrack(null) },
                                modifier = Modifier.fillMaxSize()
                            )
                        } else {
                            TabularTrackList(
                                predictions = state.predictions,
                                selectedTrackId = state.selectedTrackId,
                                settings = settings,
                                onSelectTrack = onSelectTrack
                            )
                        }
                    }
                }
            } else {
                // Portrait Phone / Compact Layout
                Column(modifier = Modifier.fillMaxSize()) {
                    Box(
                        modifier = Modifier
                            .weight(if (selectedPrediction != null) 1.05f else 1.45f)
                            .fillMaxWidth()
                            .padding(8.dp)
                    ) {
                        if (showTabularView) {
                            TabularTrackList(
                                predictions = state.predictions,
                                selectedTrackId = state.selectedTrackId,
                                settings = settings,
                                onSelectTrack = onSelectTrack
                            )
                        } else {
                            RadarScopeCanvas(
                                area = state.observationArea,
                                rangeNm = state.rangeNm,
                                predictions = state.predictions,
                                zones = state.zones,
                                alerts = state.alerts,
                                selectedTrackId = state.selectedTrackId,
                                ownPosition = ownPos,
                                headingUpDegrees = telemetry.deviceHeadingDeg,
                                settings = settings,
                                viewport = viewport,
                                onViewportChange = { viewport = it },
                                onTrackSelected = onSelectTrack,
                                onFrameDurationMs = onFrameDurationMs,
                                modifier = Modifier.fillMaxSize()
                            )
                        }
                    }

                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth()
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        if (selectedPrediction != null) {
                            TrackInspectorPanel(
                                prediction = selectedPrediction,
                                annotation = state.annotations[selectedPrediction.track.trackId],
                                settings = settings,
                                onSaveAnnotation = onSaveAnnotation,
                                onClose = { onSelectTrack(null) },
                                modifier = Modifier.fillMaxSize()
                            )
                        } else {
                            TabularTrackList(
                                predictions = state.predictions,
                                selectedTrackId = state.selectedTrackId,
                                settings = settings,
                                onSelectTrack = onSelectTrack
                            )
                        }
                    }
                }
            }
        }
    }

    if (showAddZoneDialog) {
        AddMonitoredZoneDialog(
            onDismiss = { showAddZoneDialog = false },
            onConfirm = { name, radiusNm, loiterSec, brg, distNm ->
                onCreateZone(name, radiusNm, loiterSec, brg, distNm)
                showAddZoneDialog = false
            }
        )
    }
}

@Composable
fun TabularTrackList(
    predictions: List<DisplayPrediction>,
    selectedTrackId: String?,
    settings: AppSettingsState,
    onSelectTrack: (String?) -> Unit,
    modifier: Modifier = Modifier
) {
    val colors = LocalAureomColors.current
    InstrumentPanel(modifier = modifier.fillMaxSize().testTag("tabular_track_list")) {
        InstrumentSectionHeader(
            title = "Track Picture (Tabular)",
            trailing = "${predictions.size} active"
        )
        Spacer(modifier = Modifier.height(6.dp))
        if (predictions.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text(
                    text = "Awaiting validated sensor observations...",
                    style = MaterialTheme.typography.bodyMedium,
                    color = colors.textSecondary
                )
            }
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                items(predictions, key = { it.track.trackId }) { pred ->
                    val t = pred.track
                    val selected = t.trackId == selectedTrackId
                    val statusColor = when (t.status) {
                        TrackStatus.CONFIRMED -> colors.phosphor
                        TrackStatus.STALE, TrackStatus.LOST -> colors.critical
                        else -> colors.amber
                    }
                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(min = 56.dp)
                            .testTag("track_row_${t.trackId}")
                            .clickable { onSelectTrack(t.trackId) }
                            .semantics {
                                contentDescription = "Track ${t.trackId}, ${t.reportedIdentity ?: "unlabeled"}, range ${GeoMath.formatDistance(pred.rangeFromOriginMeters, settings.distanceUnit)}, age ${GeoMath.formatAge(pred.observationAgeMs)}"
                            },
                        color = if (selected) colors.elevatedSurface else colors.scopeBackground,
                        shape = RoundedCornerShape(4.dp),
                        border = BorderStroke(1.dp, if (selected) colors.cyan else colors.panelBorder)
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "${t.trackId} • ${t.reportedIdentity ?: "UNLABELED"}",
                                    style = MaterialTheme.typography.labelLarge,
                                    color = if (selected) colors.cyan else colors.textPrimary
                                )
                                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                    StatusPill(pred.positionQuality.badge, if (pred.positionQuality == PositionQuality.MEASURED) colors.phosphor else colors.amber)
                                    StatusPill(t.status.badge, statusColor)
                                }
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = "BRG ${GeoMath.formatBearing(pred.bearingFromOriginDeg)} | RNG ${GeoMath.formatDistance(pred.rangeFromOriginMeters, settings.distanceUnit)}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = colors.textSecondary
                                )
                                Text(
                                    text = "SPD ${GeoMath.formatSpeed(t.estimatedSpeedMps, settings.distanceUnit)} | AGE ${GeoMath.formatAge(pred.observationAgeMs)}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = if (pred.observationAgeMs >= settings.staleThresholdSec * 1000L) colors.amber else colors.textSecondary
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun AddMonitoredZoneDialog(
    onDismiss: () -> Unit,
    onConfirm: (name: String, radiusNm: Double, loiterSec: Int, brg: Double, distNm: Double) -> Unit
) {
    var name by remember { mutableStateOf("North Sector Watch Zone") }
    var radiusNm by remember { mutableStateOf("4.0") }
    var loiterSec by remember { mutableStateOf("30") }
    var bearingDeg by remember { mutableStateOf("45") }
    var distNm by remember { mutableStateOf("6.0") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Configure Monitored Zone") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Zone Name") },
                    singleLine = true
                )
                OutlinedTextField(
                    value = radiusNm,
                    onValueChange = { radiusNm = it },
                    label = { Text("Radius (NM)") },
                    singleLine = true
                )
                OutlinedTextField(
                    value = loiterSec,
                    onValueChange = { loiterSec = it },
                    label = { Text("Dwell / Loiter Threshold (sec)") },
                    singleLine = true
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = bearingDeg,
                        onValueChange = { bearingDeg = it },
                        label = { Text("Offset Brg (°)") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = distNm,
                        onValueChange = { distNm = it },
                        label = { Text("Offset (NM)") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    onConfirm(
                        name,
                        radiusNm.toDoubleOrNull()?.coerceIn(0.2, 50.0) ?: 4.0,
                        loiterSec.toIntOrNull()?.coerceIn(5, 3600) ?: 30,
                        bearingDeg.toDoubleOrNull() ?: 0.0,
                        distNm.toDoubleOrNull()?.coerceIn(0.0, 60.0) ?: 0.0
                    )
                },
                modifier = Modifier.testTag("confirm_add_zone_button")
            ) {
                Text("Create Zone")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}
