package com.example.data.local

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.domain.model.AppSettingsState
import com.example.domain.model.CoordinateFormat
import com.example.domain.model.DistanceUnit
import com.example.domain.model.RadarOrientationMode
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.aureomPrefs by preferencesDataStore(name = "aureom_settings")

class SettingsDataStore(private val context: Context) {
    private object Keys {
        val NIGHT_MODE = booleanPreferencesKey("night_mode")
        val REDUCED_MOTION = booleanPreferencesKey("reduced_motion")
        val COLOR_BLIND = booleanPreferencesKey("color_blind_symbols")
        val TEXT_SCALE = floatPreferencesKey("text_scale")
        val COORD_FORMAT = stringPreferencesKey("coord_format")
        val DISTANCE_UNIT = stringPreferencesKey("distance_unit")
        val STALE_THRESHOLD_SEC = intPreferencesKey("stale_threshold_sec")
        val MAX_EXTRAP_SEC = intPreferencesKey("max_extrap_sec")
        val TRAIL_LENGTH = intPreferencesKey("trail_length")
        val SHOW_MAP_OVERLAY = booleanPreferencesKey("show_map_overlay")
        val SHOW_SWEEP = booleanPreferencesKey("show_sweep")
        val ORIENTATION_MODE = stringPreferencesKey("orientation_mode")
        val BACKEND_WS_URL = stringPreferencesKey("backend_ws_url")
        val BACKEND_TOKEN = stringPreferencesKey("backend_token")
        val USE_REMOTE_BACKEND = booleanPreferencesKey("use_remote_backend")
    }

    val settings: Flow<AppSettingsState> = context.aureomPrefs.data.map { prefs ->
        AppSettingsState(
            nightMode = prefs[Keys.NIGHT_MODE] ?: true,
            reducedMotion = prefs[Keys.REDUCED_MOTION] ?: false,
            colorBlindSymbols = prefs[Keys.COLOR_BLIND] ?: false,
            textScale = prefs[Keys.TEXT_SCALE] ?: 1.0f,
            coordinateFormat = CoordinateFormat.entries.firstOrNull {
                it.name == prefs[Keys.COORD_FORMAT]
            } ?: CoordinateFormat.DECIMAL_DEGREES,
            distanceUnit = DistanceUnit.entries.firstOrNull {
                it.name == prefs[Keys.DISTANCE_UNIT]
            } ?: DistanceUnit.NAUTICAL,
            staleThresholdSec = prefs[Keys.STALE_THRESHOLD_SEC] ?: 15,
            maxExtrapolationSec = prefs[Keys.MAX_EXTRAP_SEC] ?: 20,
            trailLength = prefs[Keys.TRAIL_LENGTH] ?: 30,
            showMapOverlay = prefs[Keys.SHOW_MAP_OVERLAY] ?: true,
            showSweepAnimation = prefs[Keys.SHOW_SWEEP] ?: true,
            orientationMode = RadarOrientationMode.entries.firstOrNull {
                it.name == prefs[Keys.ORIENTATION_MODE]
            } ?: RadarOrientationMode.NORTH_UP,
            backendWsUrl = prefs[Keys.BACKEND_WS_URL] ?: "ws://10.0.2.2:8080/ws/stream",
            backendAuthToken = prefs[Keys.BACKEND_TOKEN] ?: "aureom-dev-token",
            useRemoteBackend = prefs[Keys.USE_REMOTE_BACKEND] ?: false
        )
    }

    suspend fun update(transform: (AppSettingsState) -> AppSettingsState) {
        context.aureomPrefs.edit { prefs ->
            val current = AppSettingsState(
                nightMode = prefs[Keys.NIGHT_MODE] ?: true,
                reducedMotion = prefs[Keys.REDUCED_MOTION] ?: false,
                colorBlindSymbols = prefs[Keys.COLOR_BLIND] ?: false,
                textScale = prefs[Keys.TEXT_SCALE] ?: 1.0f,
                coordinateFormat = CoordinateFormat.entries.firstOrNull {
                    it.name == prefs[Keys.COORD_FORMAT]
                } ?: CoordinateFormat.DECIMAL_DEGREES,
                distanceUnit = DistanceUnit.entries.firstOrNull {
                    it.name == prefs[Keys.DISTANCE_UNIT]
                } ?: DistanceUnit.NAUTICAL,
                staleThresholdSec = prefs[Keys.STALE_THRESHOLD_SEC] ?: 15,
                maxExtrapolationSec = prefs[Keys.MAX_EXTRAP_SEC] ?: 20,
                trailLength = prefs[Keys.TRAIL_LENGTH] ?: 30,
                showMapOverlay = prefs[Keys.SHOW_MAP_OVERLAY] ?: true,
                showSweepAnimation = prefs[Keys.SHOW_SWEEP] ?: true,
                orientationMode = RadarOrientationMode.entries.firstOrNull {
                    it.name == prefs[Keys.ORIENTATION_MODE]
                } ?: RadarOrientationMode.NORTH_UP,
                backendWsUrl = prefs[Keys.BACKEND_WS_URL] ?: "ws://10.0.2.2:8080/ws/stream",
                backendAuthToken = prefs[Keys.BACKEND_TOKEN] ?: "aureom-dev-token",
                useRemoteBackend = prefs[Keys.USE_REMOTE_BACKEND] ?: false
            )
            val updated = transform(current)
            prefs[Keys.NIGHT_MODE] = updated.nightMode
            prefs[Keys.REDUCED_MOTION] = updated.reducedMotion
            prefs[Keys.COLOR_BLIND] = updated.colorBlindSymbols
            prefs[Keys.TEXT_SCALE] = updated.textScale
            prefs[Keys.COORD_FORMAT] = updated.coordinateFormat.name
            prefs[Keys.DISTANCE_UNIT] = updated.distanceUnit.name
            prefs[Keys.STALE_THRESHOLD_SEC] = updated.staleThresholdSec
            prefs[Keys.MAX_EXTRAP_SEC] = updated.maxExtrapolationSec
            prefs[Keys.TRAIL_LENGTH] = updated.trailLength
            prefs[Keys.SHOW_MAP_OVERLAY] = updated.showMapOverlay
            prefs[Keys.SHOW_SWEEP] = updated.showSweepAnimation
            prefs[Keys.ORIENTATION_MODE] = updated.orientationMode.name
            prefs[Keys.BACKEND_WS_URL] = updated.backendWsUrl
            prefs[Keys.BACKEND_TOKEN] = updated.backendAuthToken
            prefs[Keys.USE_REMOTE_BACKEND] = updated.useRemoteBackend
        }
    }
}
