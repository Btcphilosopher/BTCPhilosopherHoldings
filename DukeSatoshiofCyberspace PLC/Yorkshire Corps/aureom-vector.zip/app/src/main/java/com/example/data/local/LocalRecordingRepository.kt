package com.example.data.local

import com.example.domain.model.AltitudeReference
import com.example.domain.model.GeoPoint
import com.example.domain.model.MonitoredZone
import com.example.domain.model.ObjectCategory
import com.example.domain.model.OperatorAnnotation
import com.example.domain.model.RawSourceMessage
import com.example.domain.model.ReplaySessionSummary
import com.example.domain.model.ScenarioId
import com.example.domain.model.SimulatorConfig
import com.example.domain.model.SourceType
import com.example.domain.model.ZoneShape
import com.example.domain.sim.RadarSimulator
import com.example.domain.sim.ScenarioCatalog
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import org.json.JSONArray
import org.json.JSONObject

class LocalRecordingRepository(private val db: AureomDatabase) {
    private val sessionDao = db.replaySessionDao()
    private val zoneDao = db.monitoredZoneDao()
    private val annotationDao = db.annotationDao()

    val sessions: Flow<List<ReplaySessionSummary>> = sessionDao.observeSessions().map { list ->
        list.map {
            ReplaySessionSummary(
                sessionId = it.sessionId,
                title = it.title,
                scenarioId = ScenarioId.entries.firstOrNull { s -> s.name == it.scenarioId }
                    ?: ScenarioId.NORTH_SEA_OBSERVATION,
                seed = it.seed,
                startedAtMs = it.startedAtMs,
                endedAtMs = it.endedAtMs,
                observationCount = it.observationCount,
                alertCount = it.alertCount,
                isBuiltInDemo = it.isBuiltInDemo
            )
        }
    }

    val annotations: Flow<Map<String, OperatorAnnotation>> = annotationDao.observeAnnotations().map { rows ->
        rows.associate { row ->
            row.targetId to OperatorAnnotation(
                targetId = row.targetId,
                note = row.note,
                updatedAtMs = row.updatedAtMs
            )
        }
    }

    fun observeZones(scenarioId: ScenarioId): Flow<List<MonitoredZone>> {
        return zoneDao.observeZonesForScenario(scenarioId.name).map { entities ->
            entities.map { it.toDomain() }
        }
    }

    suspend fun ensureSeededDefaults(scenarioId: ScenarioId) {
        val existingZones = zoneDao.getZonesForScenario(scenarioId.name)
        if (existingZones.isEmpty()) {
            ScenarioCatalog.buildScenario(scenarioId).defaultZones.forEach { zone ->
                zoneDao.upsertZone(zone.toEntity())
            }
        }
    }

    suspend fun ensureBuiltInDemoSession() {
        val count = sessionDao.countAllObservations()
        if (count > 0) return

        val baseTime = 1_760_000_000_000L
        val config = SimulatorConfig(
            scenarioId = ScenarioId.NORTH_SEA_OBSERVATION,
            seed = 20260401L,
            missedDetectionProb = 0.03,
            clutterPerScan = 1,
            delayedMessageProb = 0.05,
            duplicateMessageProb = 0.03
        )
        val sim = RadarSimulator(config)
        val sessionId = "DEMO-NORTH-SEA-01"
        val rows = mutableListOf<RecordedObservationEntity>()

        for (sec in 0..44) {
            val offsetMs = sec * 1000L
            // Inject brief 6-second outage from t=28s..33s in the demo recording
            sim.updateConfig(config.copy(sensorOutageActive = sec in 28..33))
            val msgs = sim.step(1000L, baseTime + offsetMs)
            msgs.forEach { msg ->
                rows.add(msg.toRecordedEntity(sessionId, offsetMs))
            }
        }

        sessionDao.upsertSession(
            ReplaySessionEntity(
                sessionId = sessionId,
                title = "North Sea Baseline Capture (Seed 20260401)",
                scenarioId = ScenarioId.NORTH_SEA_OBSERVATION.name,
                seed = config.seed,
                startedAtMs = baseTime,
                endedAtMs = baseTime + 45_000L,
                observationCount = rows.size,
                alertCount = 2,
                isBuiltInDemo = true
            )
        )
        sessionDao.insertObservations(rows)
    }

    suspend fun saveSessionSummary(summary: ReplaySessionSummary) {
        sessionDao.upsertSession(
            ReplaySessionEntity(
                sessionId = summary.sessionId,
                title = summary.title,
                scenarioId = summary.scenarioId.name,
                seed = summary.seed,
                startedAtMs = summary.startedAtMs,
                endedAtMs = summary.endedAtMs,
                observationCount = summary.observationCount,
                alertCount = summary.alertCount,
                isBuiltInDemo = summary.isBuiltInDemo
            )
        )
    }

    suspend fun appendRecordedMessages(
        sessionId: String,
        sessionStartMs: Long,
        messages: List<RawSourceMessage>
    ) {
        if (messages.isEmpty()) return
        val entities = messages.map { msg ->
            val offset = (msg.receivedAtMs - sessionStartMs).coerceAtLeast(0L)
            msg.toRecordedEntity(sessionId, offset)
        }
        sessionDao.insertObservations(entities)
    }

    suspend fun loadReplayMessages(sessionId: String): List<Pair<Long, RawSourceMessage>> {
        return sessionDao.getObservationsForSession(sessionId).map { row ->
            row.offsetMs to RawSourceMessage(
                messageId = row.messageId,
                sourceId = row.sourceId,
                sourceType = SourceType.RECORDED_FILE,
                sequenceNumber = row.sequenceNumber,
                sensorTimestampMs = row.sensorTimestampMs,
                receivedAtMs = row.sensorTimestampMs,
                latDeg = row.latDeg,
                lonDeg = row.lonDeg,
                groundSpeedMps = row.groundSpeedMps,
                courseOverGroundDeg = row.courseOverGroundDeg,
                headingDeg = row.headingDeg,
                altitudeMeters = row.altitudeMeters,
                altitudeReference = AltitudeReference.entries.firstOrNull { it.name == row.altitudeReference }
                    ?: AltitudeReference.UNAVAILABLE,
                reportedIdentity = row.reportedIdentity,
                reportedIdentitySource = row.reportedIdentitySource,
                objectCategory = ObjectCategory.entries.firstOrNull { it.name == row.objectCategory }
                    ?: ObjectCategory.UNKNOWN_CONTACT,
                uncertaintyMeters = row.uncertaintyMeters,
                isClutter = row.isClutter,
                rawPayloadSummary = "REPLAY offset=${row.offsetMs}ms"
            )
        }
    }

    suspend fun upsertZone(zone: MonitoredZone) {
        zoneDao.upsertZone(zone.toEntity())
    }

    suspend fun deleteZone(zoneId: String) {
        zoneDao.deleteZone(zoneId)
    }

    suspend fun saveAnnotation(targetId: String, note: String, nowMs: Long) {
        annotationDao.upsertAnnotation(
            TrackAnnotationEntity(
                targetId = targetId,
                note = note,
                updatedAtMs = nowMs
            )
        )
    }

    suspend fun deleteSession(sessionId: String) {
        sessionDao.deleteObservationsForSession(sessionId)
        sessionDao.deleteSession(sessionId)
    }

    suspend fun getTotalStoredObservations(): Int = sessionDao.countAllObservations()

    private fun RawSourceMessage.toRecordedEntity(sessionId: String, offsetMs: Long): RecordedObservationEntity {
        return RecordedObservationEntity(
            sessionId = sessionId,
            offsetMs = offsetMs,
            messageId = messageId,
            sourceId = sourceId,
            sourceType = sourceType.name,
            sequenceNumber = sequenceNumber,
            sensorTimestampMs = sensorTimestampMs,
            latDeg = latDeg,
            lonDeg = lonDeg,
            groundSpeedMps = groundSpeedMps,
            courseOverGroundDeg = courseOverGroundDeg,
            headingDeg = headingDeg,
            altitudeMeters = altitudeMeters,
            altitudeReference = altitudeReference.name,
            reportedIdentity = reportedIdentity,
            reportedIdentitySource = reportedIdentitySource,
            objectCategory = objectCategory.name,
            uncertaintyMeters = uncertaintyMeters,
            isClutter = isClutter
        )
    }

    private fun MonitoredZone.toEntity(): MonitoredZoneEntity {
        val arr = JSONArray()
        polygonVertices.forEach { pt ->
            arr.put(JSONObject().apply {
                put("lat", pt.latDeg)
                put("lon", pt.lonDeg)
            })
        }
        return MonitoredZoneEntity(
            zoneId = zoneId,
            name = name,
            scenarioId = scenarioId.name,
            shape = shape.name,
            centerLatDeg = center.latDeg,
            centerLonDeg = center.lonDeg,
            radiusMeters = radiusMeters,
            polygonJson = arr.toString(),
            alertOnEntry = alertOnEntry,
            alertOnExit = alertOnExit,
            loiterThresholdSec = loiterThresholdSec,
            hysteresisMeters = hysteresisMeters,
            enabled = enabled
        )
    }

    private fun MonitoredZoneEntity.toDomain(): MonitoredZone {
        val vertices = mutableListOf<GeoPoint>()
        runCatching {
            val arr = JSONArray(polygonJson)
            for (i in 0 until arr.length()) {
                val obj = arr.getJSONObject(i)
                vertices.add(GeoPoint(obj.getDouble("lat"), obj.getDouble("lon")))
            }
        }
        return MonitoredZone(
            zoneId = zoneId,
            name = name,
            scenarioId = ScenarioId.entries.firstOrNull { it.name == scenarioId }
                ?: ScenarioId.NORTH_SEA_OBSERVATION,
            shape = ZoneShape.entries.firstOrNull { it.name == shape } ?: ZoneShape.CIRCLE,
            center = GeoPoint(centerLatDeg, centerLonDeg),
            radiusMeters = radiusMeters,
            polygonVertices = vertices,
            alertOnEntry = alertOnEntry,
            alertOnExit = alertOnExit,
            loiterThresholdSec = loiterThresholdSec,
            hysteresisMeters = hysteresisMeters,
            enabled = enabled
        )
    }
}
