package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.AureomApplication
import com.example.data.export.ReportExporter
import com.example.domain.alerts.AlertEngine
import com.example.domain.geo.GeoMath
import com.example.domain.model.AlertRecord
import com.example.domain.model.AppSettingsState
import com.example.domain.model.ConnectionState
import com.example.domain.model.DeviceTelemetryState
import com.example.domain.model.DisplayPrediction
import com.example.domain.model.GeoPoint
import com.example.domain.model.MonitoredZone
import com.example.domain.model.ObservationArea
import com.example.domain.model.OperatingMode
import com.example.domain.model.OperatorAnnotation
import com.example.domain.model.RawSourceMessage
import com.example.domain.model.ReplayPlaybackState
import com.example.domain.model.ReplaySessionSummary
import com.example.domain.model.ScenarioId
import com.example.domain.model.SimulatorConfig
import com.example.domain.model.SourceHealthInfo
import com.example.domain.model.SourceType
import com.example.domain.model.SystemMetricsSnapshot
import com.example.domain.model.ZoneShape
import com.example.domain.sim.RadarSimulator
import com.example.domain.sim.ScenarioCatalog
import com.example.domain.tracking.TrackAssociator
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.channels.BufferOverflow
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.UUID

data class RadarScreenState(
    val operatingMode: OperatingMode = OperatingMode.SIMULATION,
    val scenarioId: ScenarioId = ScenarioId.NORTH_SEA_OBSERVATION,
    val observationArea: ObservationArea = ScenarioCatalog.buildScenario(ScenarioId.NORTH_SEA_OBSERVATION).area,
    val rangeNm: Double = ScenarioId.NORTH_SEA_OBSERVATION.defaultRangeNm,
    val predictions: List<DisplayPrediction> = emptyList(),
    val selectedTrackId: String? = null,
    val zones: List<MonitoredZone> = emptyList(),
    val alerts: List<AlertRecord> = emptyList(),
    val sources: List<SourceHealthInfo> = emptyList(),
    val simulatorConfig: SimulatorConfig = SimulatorConfig(),
    val isSimulationRunning: Boolean = false,
    val isRecording: Boolean = false,
    val recordingObservationCount: Int = 0,
    val replayPlayback: ReplayPlaybackState = ReplayPlaybackState(),
    val annotations: Map<String, OperatorAnnotation> = emptyMap(),
    val lastConnectionTimestampMs: Long? = null,
    val currentClockMs: Long = System.currentTimeMillis(),
    val utcClockText: String = "--:--:--Z",
    val metrics: SystemMetricsSnapshot = SystemMetricsSnapshot(),
    val exportReportText: String? = null,
    val statusBannerMessage: String? = null
)

class RadarViewModel(application: Application) : AndroidViewModel(application) {
    private val app = application as AureomApplication
    private val repository = app.repository
    private val settingsStore = app.settingsStore
    private val deviceTelemetry = app.deviceTelemetry
    private val wsAdapter = app.webSocketAdapter

    val settings: StateFlow<AppSettingsState> = settingsStore.settings
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), AppSettingsState())

    val telemetry: StateFlow<DeviceTelemetryState> = deviceTelemetry.state

    val replaySessions: StateFlow<List<ReplaySessionSummary>> = repository.sessions
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _uiState = MutableStateFlow(RadarScreenState())
    val uiState: StateFlow<RadarScreenState> = _uiState.asStateFlow()

    // Bounded queue decoupling ingestion from UI rendering
    private val ingestionQueue = Channel<RawSourceMessage>(
        capacity = 256,
        onBufferOverflow = BufferOverflow.DROP_OLDEST
    )

    private var simulator = RadarSimulator(SimulatorConfig())
    private var associator = TrackAssociator(simulator.getArea().center)
    private val alertEngine = AlertEngine()

    private val sourceMetrics = linkedMapOf<String, MutableSourceMetrics>()
    private var totalObservationsProcessed = 0L
    private var droppedBackpressure = 0L
    private var lastUpdateLatencyMs = 0L

    private var simJob: Job? = null
    private var replayJob: Job? = null
    private var wsCollectJob: Job? = null
    private var activeZonesJob: Job? = null

    private var activeRecordingSessionId: String? = null
    private var activeRecordingStartMs: Long = 0L
    private var activeRecordingTitle: String = ""
    private var activeRecordingObsCount: Int = 0

    private var replayMessages: List<Pair<Long, RawSourceMessage>> = emptyList()
    private var replayCursorIndex: Int = 0

    // Frame timing rolling average
    private var smoothedFrameMs = 16.6

    private data class MutableSourceMetrics(
        val sourceId: String,
        var name: String,
        var type: SourceType,
        var state: ConnectionState,
        var lastTs: Long? = null,
        var accepted: Long = 0L,
        var rejected: Long = 0L,
        var duplicates: Long = 0L,
        var avgLatencyMs: Long = 12L,
        var outage: Boolean = false,
        var endpoint: String = "in-process"
    )

    init {
        initSourceMetrics()
        viewModelScope.launch(Dispatchers.IO) {
            repository.ensureSeededDefaults(ScenarioId.NORTH_SEA_OBSERVATION)
            repository.ensureBuiltInDemoSession()
        }
        observeZonesForScenario(ScenarioId.NORTH_SEA_OBSERVATION)
        observeAnnotations()
        startIngestionConsumer()
        startClockAndRefreshLoop()
        deviceTelemetry.startOrientationSensors()
        if (deviceTelemetry.hasLocationPermission()) {
            deviceTelemetry.refreshLocationStream()
        }
        // Start North Sea Observation immediately so radar is live when explored
        startSimulation(ScenarioId.NORTH_SEA_OBSERVATION)
    }

    private fun initSourceMetrics() {
        sourceMetrics["SIM-MARITIME-1"] = MutableSourceMetrics(
            sourceId = "SIM-MARITIME-1",
            name = "North Sea AIS / Coastal Sim",
            type = SourceType.SYNTHETIC_SIM,
            state = ConnectionState.CONNECTED,
            endpoint = "deterministic://seed-20260401"
        )
        sourceMetrics["SIM-AIR-1"] = MutableSourceMetrics(
            sourceId = "SIM-AIR-1",
            name = "Civilian ADS-B Sim",
            type = SourceType.SYNTHETIC_SIM,
            state = ConnectionState.CONNECTED,
            endpoint = "deterministic://seed-20260401"
        )
        sourceMetrics["SIM-RADAR-PRI"] = MutableSourceMetrics(
            sourceId = "SIM-RADAR-PRI",
            name = "Primary Surveillance Radar Sim",
            type = SourceType.SYNTHETIC_SIM,
            state = ConnectionState.CONNECTED,
            endpoint = "deterministic://seed-20260401"
        )
        sourceMetrics["KTOR-WS-FEED"] = MutableSourceMetrics(
            sourceId = "KTOR-WS-FEED",
            name = "Ktor WebSocket Backend",
            type = SourceType.KTOR_WEBSOCKET,
            state = ConnectionState.STANDBY,
            endpoint = settings.value.backendWsUrl
        )
    }

    private fun observeZonesForScenario(scenarioId: ScenarioId) {
        activeZonesJob?.cancel()
        activeZonesJob = viewModelScope.launch {
            withContext(Dispatchers.IO) {
                repository.ensureSeededDefaults(scenarioId)
            }
            repository.observeZones(scenarioId).collectLatest { zoneList ->
                _uiState.update { it.copy(zones = zoneList) }
            }
        }
    }

    private fun observeAnnotations() {
        viewModelScope.launch {
            repository.annotations.collectLatest { map ->
                _uiState.update { it.copy(annotations = map) }
            }
        }
    }

    private fun startIngestionConsumer() {
        viewModelScope.launch(Dispatchers.Default) {
            val batch = ArrayList<RawSourceMessage>(32)
            while (true) {
                val first = ingestionQueue.receive()
                batch.clear()
                batch.add(first)
                while (batch.size < 64) {
                    val next = ingestionQueue.tryReceive().getOrNull() ?: break
                    batch.add(next)
                }

                val t0 = System.nanoTime()
                val recordedBatch = ArrayList<RawSourceMessage>(batch.size)
                val nowMs = batch.last().receivedAtMs

                for (msg in batch) {
                    val m = sourceMetrics.getOrPut(msg.sourceId) {
                        MutableSourceMetrics(
                            sourceId = msg.sourceId,
                            name = msg.sourceId,
                            type = msg.sourceType,
                            state = ConnectionState.CONNECTED
                        )
                    }
                    m.lastTs = msg.receivedAtMs
                    m.state = ConnectionState.CONNECTED
                    m.avgLatencyMs = (nowMs - msg.sensorTimestampMs).coerceAtLeast(0L)

                    val result = associator.ingest(msg)
                    if (result.isDuplicate) {
                        m.duplicates += 1
                    } else if (result.rejectionReason != null) {
                        m.rejected += 1
                        alertEngine.recordInvalidDataAlert(
                            sourceId = msg.sourceId,
                            reason = result.rejectionReason,
                            rawMessageId = msg.messageId,
                            nowMs = nowMs
                        )
                    } else {
                        m.accepted += 1
                        totalObservationsProcessed += 1
                        if (_uiState.value.isRecording && _uiState.value.operatingMode != OperatingMode.REPLAY) {
                            recordedBatch.add(msg)
                        }
                    }
                }

                lastUpdateLatencyMs = ((System.nanoTime() - t0) / 1_000_000L).coerceAtLeast(1L)

                if (recordedBatch.isNotEmpty() && activeRecordingSessionId != null) {
                    val sid = activeRecordingSessionId!!
                    val startMs = activeRecordingStartMs
                    activeRecordingObsCount += recordedBatch.size
                    launch(Dispatchers.IO) {
                        repository.appendRecordedMessages(sid, startMs, recordedBatch)
                    }
                }

                refreshDisplayState(nowMs)
            }
        }
    }

    private fun startClockAndRefreshLoop() {
        viewModelScope.launch(Dispatchers.Default) {
            val utcFmt = java.text.SimpleDateFormat("HH:mm:ss'Z'", java.util.Locale.US).apply {
                timeZone = java.util.TimeZone.getTimeZone("UTC")
            }
            while (true) {
                delay(1000L)
                val wallNow = System.currentTimeMillis()
                val utcText = utcFmt.format(java.util.Date(wallNow))

                // In REPLAY mode, clock advances only when replay ticks, keeping age accurate to replay time!
                if (_uiState.value.operatingMode != OperatingMode.REPLAY) {
                    refreshDisplayState(wallNow, utcText)
                } else {
                    _uiState.update { it.copy(utcClockText = utcText) }
                }
            }
        }
    }

    private fun refreshDisplayState(evalNowMs: Long, utcTextOverride: String? = null) {
        val currentSettings = settings.value
        val state = _uiState.value
        val ownPos = telemetry.value.gnssPosition ?: state.observationArea.center

        val predictions = associator.buildDisplayPredictions(
            nowMs = evalNowMs,
            ownPosition = ownPos,
            staleThresholdMs = currentSettings.staleThresholdSec * 1000L,
            maxExtrapolationMs = currentSettings.maxExtrapolationSec * 1000L
        )

        // Update WebSocket connection health
        if (state.operatingMode == OperatingMode.LIVE_OBSERVATION) {
            val wsState = wsAdapter.connectionState.value
            sourceMetrics["KTOR-WS-FEED"]?.apply {
                this.state = wsState
                this.outage = (wsState == ConnectionState.DISCONNECTED)
                this.endpoint = currentSettings.backendWsUrl
            }
        }

        val sourceList = sourceMetrics.values.map {
            SourceHealthInfo(
                sourceId = it.sourceId,
                name = it.name,
                sourceType = it.type,
                connectionState = it.state,
                lastMessageTimestampMs = it.lastTs,
                messagesAccepted = it.accepted,
                messagesRejected = it.rejected,
                duplicatesDropped = it.duplicates,
                averageLatencyMs = it.avgLatencyMs,
                outageActive = it.outage,
                endpoint = it.endpoint
            )
        }

        val evaluatedAlerts = alertEngine.evaluate(
            nowMs = evalNowMs,
            predictions = predictions,
            zones = state.zones,
            sources = sourceList,
            staleThresholdMs = currentSettings.staleThresholdSec * 1000L
        )

        val runtime = Runtime.getRuntime()
        val usedMb = (runtime.totalMemory() - runtime.freeMemory()) / (1024.0 * 1024.0)
        val maxMb = runtime.maxMemory() / (1024.0 * 1024.0)

        val latestConn = sourceList.mapNotNull { it.lastMessageTimestampMs }.maxOrNull()

        _uiState.update { prev ->
            prev.copy(
                predictions = predictions,
                alerts = evaluatedAlerts,
                sources = sourceList,
                lastConnectionTimestampMs = latestConn ?: prev.lastConnectionTimestampMs,
                currentClockMs = evalNowMs,
                utcClockText = utcTextOverride ?: prev.utcClockText,
                recordingObservationCount = activeRecordingObsCount,
                metrics = SystemMetricsSnapshot(
                    frameTimeMs = smoothedFrameMs,
                    estimatedFps = (1000.0 / smoothedFrameMs).coerceIn(1.0, 120.0),
                    usedMemoryMb = usedMb,
                    maxMemoryMb = maxMb,
                    updateLatencyMs = lastUpdateLatencyMs,
                    queueDepth = 0,
                    maxQueueDepth = 256,
                    activeTracksCount = predictions.size,
                    totalObservationsProcessed = totalObservationsProcessed,
                    droppedBackpressureCount = droppedBackpressure + wsAdapter.getDroppedCount(),
                    batteryDrainEstimate = if (state.operatingMode == OperatingMode.LIVE_OBSERVATION) {
                        "Moderate (WebSocket + GNSS)"
                    } else {
                        "Nominal (1 Hz Deterministic Sim)"
                    }
                )
            )
        }
    }

    fun startSimulation(scenarioId: ScenarioId = _uiState.value.scenarioId) {
        stopReplayInternal()
        disconnectRemoteInternal()

        val newConfig = _uiState.value.simulatorConfig.copy(
            scenarioId = scenarioId,
            sensorOutageActive = false
        )
        simulator.reset(newConfig)
        val area = simulator.getArea()
        associator = TrackAssociator(area.center)
        alertEngine.reset()
        observeZonesForScenario(scenarioId)

        sourceMetrics.values.forEach {
            if (it.type == SourceType.SYNTHETIC_SIM) {
                it.state = ConnectionState.CONNECTED
                it.outage = false
                it.endpoint = "deterministic://seed-${newConfig.seed}"
            }
        }

        _uiState.update {
            it.copy(
                operatingMode = OperatingMode.SIMULATION,
                scenarioId = scenarioId,
                observationArea = area,
                rangeNm = scenarioId.defaultRangeNm,
                simulatorConfig = newConfig,
                isSimulationRunning = true,
                selectedTrackId = null,
                statusBannerMessage = "Simulation active: ${scenarioId.title} (Seed ${newConfig.seed})"
            )
        }

        simJob?.cancel()
        simJob = viewModelScope.launch(Dispatchers.Default) {
            // Seed initial scan immediately so radar shows contacts right away
            val initialNow = System.currentTimeMillis()
            simulator.step(1000L, initialNow).forEach { enqueueMessage(it) }
            while (true) {
                delay(_uiState.value.simulatorConfig.tickIntervalMs.coerceIn(250L, 5000L))
                if (_uiState.value.isSimulationRunning && _uiState.value.operatingMode == OperatingMode.SIMULATION) {
                    val now = System.currentTimeMillis()
                    val msgs = simulator.step(_uiState.value.simulatorConfig.tickIntervalMs, now)
                    msgs.forEach { enqueueMessage(it) }
                }
            }
        }
    }

    fun pauseOrResumeSimulation() {
        _uiState.update { it.copy(isSimulationRunning = !it.isSimulationRunning) }
    }

    fun updateSimulatorConfig(updated: SimulatorConfig) {
        val scenarioChanged = updated.scenarioId != _uiState.value.simulatorConfig.scenarioId
        val seedChanged = updated.seed != _uiState.value.simulatorConfig.seed
        simulator.updateConfig(updated)
        sourceMetrics.values.forEach {
            if (it.type == SourceType.SYNTHETIC_SIM) {
                it.outage = updated.sensorOutageActive
                it.state = if (updated.sensorOutageActive) ConnectionState.DISCONNECTED else ConnectionState.CONNECTED
                it.endpoint = "deterministic://seed-${updated.seed}"
            }
        }
        _uiState.update { it.copy(simulatorConfig = updated) }
        if (scenarioChanged || seedChanged) {
            startSimulation(updated.scenarioId)
        } else {
            refreshDisplayState(System.currentTimeMillis())
        }
    }

    fun toggleSimulatedOutage() {
        val cur = _uiState.value.simulatorConfig
        updateSimulatorConfig(cur.copy(sensorOutageActive = !cur.sensorOutageActive))
    }

    fun connectRemoteBackend(wsUrl: String? = null, token: String? = null) {
        simJob?.cancel()
        stopReplayInternal()

        val url = wsUrl ?: settings.value.backendWsUrl
        val auth = token ?: settings.value.backendAuthToken

        viewModelScope.launch {
            settingsStore.update { it.copy(backendWsUrl = url, backendAuthToken = auth, useRemoteBackend = true) }
        }

        wsAdapter.updateEndpoint(url, auth)
        val area = ScenarioCatalog.buildScenario(_uiState.value.scenarioId).area
        associator = TrackAssociator(area.center)
        alertEngine.reset()

        sourceMetrics.values.forEach {
            if (it.type == SourceType.SYNTHETIC_SIM) {
                it.state = ConnectionState.STANDBY
                it.outage = false
            }
        }
        sourceMetrics["KTOR-WS-FEED"]?.apply {
            state = ConnectionState.DEGRADED
            outage = false
            endpoint = url
        }

        _uiState.update {
            it.copy(
                operatingMode = OperatingMode.LIVE_OBSERVATION,
                isSimulationRunning = false,
                statusBannerMessage = "Connecting to Ktor WebSocket: $url"
            )
        }

        wsCollectJob?.cancel()
        wsCollectJob = viewModelScope.launch(Dispatchers.IO) {
            wsAdapter.start()
            wsAdapter.incomingMessages.collect { msg ->
                enqueueMessage(msg)
            }
        }
    }

    fun disconnectRemoteBackend() {
        disconnectRemoteInternal()
        startSimulation(_uiState.value.scenarioId)
    }

    private fun disconnectRemoteInternal() {
        wsCollectJob?.cancel()
        wsCollectJob = null
        viewModelScope.launch(Dispatchers.IO) {
            wsAdapter.stop()
        }
        sourceMetrics["KTOR-WS-FEED"]?.apply {
            state = ConnectionState.STANDBY
            outage = false
        }
    }

    private fun enqueueMessage(msg: RawSourceMessage) {
        val res = ingestionQueue.trySend(msg)
        if (res.isFailure) {
            droppedBackpressure += 1
        }
    }

    fun selectTrack(trackId: String?) {
        _uiState.update { it.copy(selectedTrackId = trackId) }
    }

    fun setRangeNm(rangeNm: Double) {
        _uiState.update { it.copy(rangeNm = rangeNm) }
    }

    fun saveTrackAnnotation(trackId: String, note: String) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.saveAnnotation(trackId, note, System.currentTimeMillis())
        }
    }

    fun createMonitoredZone(
        name: String,
        radiusNm: Double,
        loiterThresholdSec: Int,
        offsetBearingDeg: Double = 0.0,
        offsetDistanceNm: Double = 0.0
    ) {
        val area = _uiState.value.observationArea
        val center = if (offsetDistanceNm > 0.01) {
            GeoMath.destinationPoint(area.center, offsetBearingDeg, offsetDistanceNm * GeoMath.METERS_PER_NM)
        } else {
            area.center
        }
        val zone = MonitoredZone(
            zoneId = "ZONE-${UUID.randomUUID().toString().take(6).uppercase()}",
            name = name.ifBlank { "Operator Sector Zone" },
            scenarioId = _uiState.value.scenarioId,
            shape = ZoneShape.CIRCLE,
            center = center,
            radiusMeters = (radiusNm * GeoMath.METERS_PER_NM).coerceAtLeast(150.0),
            alertOnEntry = true,
            alertOnExit = true,
            loiterThresholdSec = loiterThresholdSec.coerceAtLeast(10),
            hysteresisMeters = (radiusNm * GeoMath.METERS_PER_NM * 0.04).coerceIn(40.0, 300.0),
            enabled = true
        )
        viewModelScope.launch(Dispatchers.IO) {
            repository.upsertZone(zone)
        }
    }

    fun toggleZoneEnabled(zone: MonitoredZone) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.upsertZone(zone.copy(enabled = !zone.enabled))
        }
    }

    fun deleteZone(zoneId: String) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.deleteZone(zoneId)
        }
    }

    fun acknowledgeAlert(alertId: String) {
        alertEngine.acknowledgeAlert(alertId, System.currentTimeMillis())
        _uiState.update { it.copy(alerts = alertEngine.getAlerts()) }
    }

    fun resolveAlert(alertId: String) {
        alertEngine.resolveAlert(alertId)
        _uiState.update { it.copy(alerts = alertEngine.getAlerts()) }
    }

    fun updateAlertNotes(alertId: String, notes: String) {
        alertEngine.updateOperatorNotes(alertId, notes)
        _uiState.update { it.copy(alerts = alertEngine.getAlerts()) }
    }

    fun toggleRecording() {
        val currentlyRecording = _uiState.value.isRecording
        if (!currentlyRecording) {
            val now = System.currentTimeMillis()
            val sid = "REC-${now}"
            activeRecordingSessionId = sid
            activeRecordingStartMs = now
            activeRecordingObsCount = 0
            activeRecordingTitle = "${_uiState.value.scenarioId.title} Capture"
            val summary = ReplaySessionSummary(
                sessionId = sid,
                title = activeRecordingTitle,
                scenarioId = _uiState.value.scenarioId,
                seed = _uiState.value.simulatorConfig.seed,
                startedAtMs = now,
                endedAtMs = now,
                observationCount = 0,
                alertCount = _uiState.value.alerts.size,
                isBuiltInDemo = false
            )
            viewModelScope.launch(Dispatchers.IO) {
                repository.saveSessionSummary(summary)
            }
            _uiState.update {
                it.copy(
                    isRecording = true,
                    recordingObservationCount = 0,
                    statusBannerMessage = "Recording session to Room DB..."
                )
            }
        } else {
            val sid = activeRecordingSessionId
            val now = System.currentTimeMillis()
            if (sid != null) {
                val summary = ReplaySessionSummary(
                    sessionId = sid,
                    title = activeRecordingTitle,
                    scenarioId = _uiState.value.scenarioId,
                    seed = _uiState.value.simulatorConfig.seed,
                    startedAtMs = activeRecordingStartMs,
                    endedAtMs = now,
                    observationCount = activeRecordingObsCount,
                    alertCount = _uiState.value.alerts.size,
                    isBuiltInDemo = false
                )
                viewModelScope.launch(Dispatchers.IO) {
                    repository.saveSessionSummary(summary)
                }
            }
            activeRecordingSessionId = null
            _uiState.update {
                it.copy(
                    isRecording = false,
                    statusBannerMessage = "Session saved ($activeRecordingObsCount observations)"
                )
            }
        }
    }

    fun startReplaySession(session: ReplaySessionSummary) {
        simJob?.cancel()
        disconnectRemoteInternal()
        if (_uiState.value.isRecording) toggleRecording()

        viewModelScope.launch {
            val loaded = withContext(Dispatchers.IO) {
                repository.loadReplayMessages(session.sessionId)
            }
            if (loaded.isEmpty()) {
                _uiState.update { it.copy(statusBannerMessage = "Session contains 0 recorded observations") }
                return@launch
            }

            replayMessages = loaded
            replayCursorIndex = 0
            val bundle = ScenarioCatalog.buildScenario(session.scenarioId)
            associator = TrackAssociator(bundle.area.center)
            alertEngine.reset()
            observeZonesForScenario(session.scenarioId)

            val totalDur = (loaded.lastOrNull()?.first ?: 0L).coerceAtLeast(1000L)
            val markers = computeReplayMarkers(loaded)

            _uiState.update {
                it.copy(
                    operatingMode = OperatingMode.REPLAY,
                    scenarioId = session.scenarioId,
                    observationArea = bundle.area,
                    rangeNm = session.scenarioId.defaultRangeNm,
                    isSimulationRunning = false,
                    selectedTrackId = null,
                    replayPlayback = ReplayPlaybackState(
                        activeSession = session,
                        isPlaying = true,
                        speedMultiplier = 1.0f,
                        currentOffsetMs = 0L,
                        totalDurationMs = totalDur,
                        eventMarkersMs = markers
                    ),
                    statusBannerMessage = "Replay started: ${session.title}"
                )
            }
            launchReplayLoop()
        }
    }

    private fun computeReplayMarkers(msgs: List<Pair<Long, RawSourceMessage>>): List<Long> {
        val markers = mutableListOf<Long>()
        var lastOffset = -1L
        for ((offset, _) in msgs) {
            if (lastOffset >= 0 && offset - lastOffset > 4000L) {
                markers.add(lastOffset + 1000L)
            }
            lastOffset = offset
        }
        return markers
    }

    private fun launchReplayLoop() {
        replayJob?.cancel()
        replayJob = viewModelScope.launch(Dispatchers.Default) {
            while (_uiState.value.operatingMode == OperatingMode.REPLAY) {
                delay(200L)
                val pb = _uiState.value.replayPlayback
                if (!pb.isPlaying) continue

                val nextOffset = (pb.currentOffsetMs + (200L * pb.speedMultiplier).toLong())
                    .coerceAtMost(pb.totalDurationMs)

                val sessionStart = pb.activeSession?.startedAtMs ?: 0L
                val evalTimeMs = sessionStart + nextOffset

                while (replayCursorIndex < replayMessages.size &&
                    replayMessages[replayCursorIndex].first <= nextOffset
                ) {
                    val (_, msg) = replayMessages[replayCursorIndex]
                    associator.ingest(msg)
                    replayCursorIndex++
                }

                refreshDisplayState(evalTimeMs)

                val finished = nextOffset >= pb.totalDurationMs
                _uiState.update {
                    it.copy(
                        replayPlayback = it.replayPlayback.copy(
                            currentOffsetMs = nextOffset,
                            isPlaying = if (finished) false else it.replayPlayback.isPlaying
                        )
                    )
                }
            }
        }
    }

    fun toggleReplayPlayPause() {
        val pb = _uiState.value.replayPlayback
        if (pb.activeSession == null) return
        if (!pb.isPlaying && pb.currentOffsetMs >= pb.totalDurationMs) {
            seekReplay(0L)
        }
        _uiState.update {
            it.copy(replayPlayback = it.replayPlayback.copy(isPlaying = !pb.isPlaying))
        }
    }

    fun setReplaySpeed(multiplier: Float) {
        _uiState.update {
            it.copy(replayPlayback = it.replayPlayback.copy(speedMultiplier = multiplier))
        }
    }

    fun seekReplay(targetOffsetMs: Long) {
        val pb = _uiState.value.replayPlayback
        val session = pb.activeSession ?: return
        val clamped = targetOffsetMs.coerceIn(0L, pb.totalDurationMs)

        viewModelScope.launch(Dispatchers.Default) {
            val area = ScenarioCatalog.buildScenario(session.scenarioId).area
            associator = TrackAssociator(area.center)
            alertEngine.reset()
            replayCursorIndex = 0

            while (replayCursorIndex < replayMessages.size &&
                replayMessages[replayCursorIndex].first <= clamped
            ) {
                val (offset, msg) = replayMessages[replayCursorIndex]
                associator.ingest(msg)
                replayCursorIndex++
                // Evaluate alert engine at step boundaries for deterministic zone/stale state
                if (replayCursorIndex == replayMessages.size ||
                    replayMessages[replayCursorIndex].first > offset
                ) {
                    val stepEvalMs = session.startedAtMs + offset
                    val ownPos = area.center
                    val preds = associator.buildDisplayPredictions(
                        nowMs = stepEvalMs,
                        ownPosition = ownPos,
                        staleThresholdMs = settings.value.staleThresholdSec * 1000L,
                        maxExtrapolationMs = settings.value.maxExtrapolationSec * 1000L
                    )
                    alertEngine.evaluate(
                        nowMs = stepEvalMs,
                        predictions = preds,
                        zones = _uiState.value.zones,
                        sources = emptyList(),
                        staleThresholdMs = settings.value.staleThresholdSec * 1000L
                    )
                }
            }

            refreshDisplayState(session.startedAtMs + clamped)
            _uiState.update {
                it.copy(
                    replayPlayback = it.replayPlayback.copy(currentOffsetMs = clamped)
                )
            }
        }
    }

    fun exitReplayToSimulation() {
        stopReplayInternal()
        startSimulation(_uiState.value.scenarioId)
    }

    private fun stopReplayInternal() {
        replayJob?.cancel()
        replayJob = null
        replayMessages = emptyList()
        replayCursorIndex = 0
        _uiState.update {
            it.copy(replayPlayback = ReplayPlaybackState())
        }
    }

    fun deleteReplaySession(sessionId: String) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.deleteSession(sessionId)
        }
    }

    fun updateSettings(transform: (AppSettingsState) -> AppSettingsState) {
        viewModelScope.launch(Dispatchers.IO) {
            settingsStore.update(transform)
        }
    }

    fun generateAndShowReport() {
        val state = _uiState.value
        val s = settings.value
        val report = ReportExporter.buildReport(
            generatedAtMs = System.currentTimeMillis(),
            mode = state.operatingMode,
            area = state.observationArea,
            seed = if (state.operatingMode == OperatingMode.REPLAY) {
                state.replayPlayback.activeSession?.seed
            } else {
                state.simulatorConfig.seed
            },
            predictions = state.predictions,
            alerts = state.alerts,
            zones = state.zones,
            sources = state.sources,
            coordinateFormat = s.coordinateFormat,
            distanceUnit = s.distanceUnit
        )
        _uiState.update { it.copy(exportReportText = report) }
    }

    fun dismissReport() {
        _uiState.update { it.copy(exportReportText = null) }
    }

    fun clearStatusBanner() {
        _uiState.update { it.copy(statusBannerMessage = null) }
    }

    fun onLocationPermissionResult(granted: Boolean) {
        if (granted) {
            deviceTelemetry.refreshLocationStream()
        } else {
            deviceTelemetry.refreshLocationStream()
        }
    }

    fun recordFrameDurationMs(durationMs: Double) {
        if (durationMs in 1.0..250.0) {
            smoothedFrameMs = smoothedFrameMs * 0.9 + durationMs * 0.1
        }
    }

    override fun onCleared() {
        super.onCleared()
        simJob?.cancel()
        replayJob?.cancel()
        wsCollectJob?.cancel()
        deviceTelemetry.stopAll()
    }
}
