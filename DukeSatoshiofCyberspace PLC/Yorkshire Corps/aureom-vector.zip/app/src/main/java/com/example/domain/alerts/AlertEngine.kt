package com.example.domain.alerts

import com.example.domain.geo.GeoMath
import com.example.domain.model.AlertRecord
import com.example.domain.model.AlertResolutionState
import com.example.domain.model.AlertRuleType
import com.example.domain.model.AlertSeverity
import com.example.domain.model.ConnectionState
import com.example.domain.model.DisplayPrediction
import com.example.domain.model.MonitoredZone
import com.example.domain.model.SourceHealthInfo
import com.example.domain.model.TrackStatus

/**
 * Evaluates civilian monitoring alerts with boundary hysteresis and consecutive-observation
 * debouncing to prevent repeated false boundary transitions on noisy positions.
 *
 * Acknowledging an alert marks [AlertRecord.acknowledged] = true without resolving
 * [AlertRecord.resolutionState] until the underlying condition clears or operator resolves it.
 */
class AlertEngine(
    private val confirmObservationsRequired: Int = 2
) {
    private data class ZoneOccupancyState(
        var isInside: Boolean = false,
        var insideStreak: Int = 0,
        var outsideStreak: Int = 0,
        var enteredAtMs: Long = 0L,
        var loiterAlertRaised: Boolean = false
    )

    private val occupancyMap = mutableMapOf<String, ZoneOccupancyState>()
    private val alerts = linkedMapOf<String, AlertRecord>()
    private var nextAlertCounter = 1

    fun reset() {
        occupancyMap.clear()
        alerts.clear()
        nextAlertCounter = 1
    }

    fun getAlerts(): List<AlertRecord> = alerts.values.sortedByDescending { it.lastOccurrenceMs }

    fun evaluate(
        nowMs: Long,
        predictions: List<DisplayPrediction>,
        zones: List<MonitoredZone>,
        sources: List<SourceHealthInfo>,
        staleThresholdMs: Long
    ): List<AlertRecord> {
        val enabledZones = zones.filter { it.enabled }

        for (pred in predictions) {
            val track = pred.track

            // 1. Zone Entry / Exit / Loiter with hysteresis & debouncing
            for (zone in enabledZones) {
                val key = "${track.trackId}::${zone.zoneId}"
                val state = occupancyMap.getOrPut(key) { ZoneOccupancyState() }
                val signedDist = GeoMath.signedDistanceToZoneMeters(track.lastMeasuredPosition, zone)
                val hyst = zone.hysteresisMeters.coerceAtLeast(30.0)

                if (!state.isInside) {
                    if (signedDist <= 0.0) {
                        state.insideStreak += 1
                        state.outsideStreak = 0
                        if (state.insideStreak >= confirmObservationsRequired) {
                            state.isInside = true
                            state.enteredAtMs = nowMs
                            state.loiterAlertRaised = false
                            if (zone.alertOnEntry) {
                                raiseOrUpdateAlert(
                                    dedupKey = "ENTRY:$key",
                                    ruleType = AlertRuleType.ZONE_ENTRY,
                                    severity = AlertSeverity.CRITICAL,
                                    title = "Zone Entry: ${zone.name}",
                                    description = "${track.reportedIdentity ?: track.trackId} entered ${zone.name}",
                                    trackId = track.trackId,
                                    zoneId = zone.zoneId,
                                    sourceId = track.primarySourceId,
                                    observationId = track.lastObservationId,
                                    nowMs = nowMs
                                )
                            }
                        }
                    } else {
                        state.insideStreak = 0
                    }
                } else {
                    // Must cross outside by hysteresis margin to avoid noisy chatter
                    if (signedDist > hyst) {
                        state.outsideStreak += 1
                        state.insideStreak = 0
                        if (state.outsideStreak >= confirmObservationsRequired) {
                            state.isInside = false
                            state.loiterAlertRaised = false
                            markConditionCleared("ENTRY:$key")
                            markConditionCleared("LOITER:$key")
                            if (zone.alertOnExit) {
                                raiseOrUpdateAlert(
                                    dedupKey = "EXIT:$key",
                                    ruleType = AlertRuleType.ZONE_EXIT,
                                    severity = AlertSeverity.INFO,
                                    title = "Zone Exit: ${zone.name}",
                                    description = "${track.reportedIdentity ?: track.trackId} exited ${zone.name}",
                                    trackId = track.trackId,
                                    zoneId = zone.zoneId,
                                    sourceId = track.primarySourceId,
                                    observationId = track.lastObservationId,
                                    nowMs = nowMs
                                )
                            }
                        }
                    } else {
                        state.outsideStreak = 0
                        // Dwell / loiter check
                        val dwellSec = (nowMs - state.enteredAtMs) / 1000L
                        if (!state.loiterAlertRaised && dwellSec >= zone.loiterThresholdSec) {
                            state.loiterAlertRaised = true
                            raiseOrUpdateAlert(
                                dedupKey = "LOITER:$key",
                                ruleType = AlertRuleType.ZONE_LOITER,
                                severity = AlertSeverity.CAUTION,
                                title = "Extended Dwell: ${zone.name}",
                                description = "${track.reportedIdentity ?: track.trackId} remained in ${zone.name} for ${dwellSec}s",
                                trackId = track.trackId,
                                zoneId = zone.zoneId,
                                sourceId = track.primarySourceId,
                                observationId = track.lastObservationId,
                                nowMs = nowMs
                            )
                        }
                    }
                }
            }

            // 2. Stale track evaluation
            val staleKey = "STALE:${track.trackId}"
            if (pred.observationAgeMs >= staleThresholdMs || track.status == TrackStatus.STALE || track.status == TrackStatus.LOST) {
                raiseOrUpdateAlert(
                    dedupKey = staleKey,
                    ruleType = AlertRuleType.TRACK_STALE,
                    severity = AlertSeverity.CAUTION,
                    title = "Stale Track: ${track.trackId}",
                    description = "No fresh observation for ${GeoMath.formatAge(pred.observationAgeMs)} (${track.reportedIdentity ?: "unlabeled"})",
                    trackId = track.trackId,
                    zoneId = null,
                    sourceId = track.primarySourceId,
                    observationId = track.lastObservationId,
                    nowMs = nowMs
                )
            } else {
                markConditionCleared(staleKey)
            }
        }

        // 3. Source connection loss evaluation
        for (src in sources) {
            val srcKey = "OUTAGE:${src.sourceId}"
            if (src.outageActive || src.connectionState == ConnectionState.DISCONNECTED) {
                raiseOrUpdateAlert(
                    dedupKey = srcKey,
                    ruleType = AlertRuleType.SOURCE_CONNECTION_LOSS,
                    severity = AlertSeverity.CRITICAL,
                    title = "Source Loss: ${src.name}",
                    description = "Sensor connection interrupted for ${src.sourceId}. Last known track ages frozen/advancing.",
                    trackId = null,
                    zoneId = null,
                    sourceId = src.sourceId,
                    observationId = null,
                    nowMs = nowMs
                )
            } else {
                markConditionCleared(srcKey)
            }
        }

        return getAlerts()
    }

    fun recordInvalidDataAlert(sourceId: String, reason: String, rawMessageId: String, nowMs: Long) {
        raiseOrUpdateAlert(
            dedupKey = "INVALID:$sourceId:$reason",
            ruleType = AlertRuleType.INVALID_SOURCE_DATA,
            severity = AlertSeverity.CAUTION,
            title = "Invalid Source Data: $sourceId",
            description = reason,
            trackId = null,
            zoneId = null,
            sourceId = sourceId,
            observationId = rawMessageId,
            nowMs = nowMs
        )
    }

    /**
     * Acknowledging an alert records operator awareness, but NEVER resolves the underlying condition.
     */
    fun acknowledgeAlert(alertId: String, nowMs: Long) {
        val entry = alerts.entries.find { it.value.alertId == alertId } ?: return
        val existing = entry.value
        alerts[entry.key] = existing.copy(
            acknowledged = true,
            acknowledgedAtMs = existing.acknowledgedAtMs ?: nowMs
        )
    }

    fun resolveAlert(alertId: String) {
        val entry = alerts.entries.find { it.value.alertId == alertId } ?: return
        alerts[entry.key] = entry.value.copy(
            resolutionState = AlertResolutionState.RESOLVED
        )
    }

    fun updateOperatorNotes(alertId: String, notes: String) {
        val entry = alerts.entries.find { it.value.alertId == alertId } ?: return
        alerts[entry.key] = entry.value.copy(operatorNotes = notes)
    }

    fun loadPersistedAlerts(persisted: List<AlertRecord>) {
        persisted.forEachIndexed { idx, alert ->
            alerts["RESTORED:${alert.alertId}:$idx"] = alert
        }
    }

    private fun raiseOrUpdateAlert(
        dedupKey: String,
        ruleType: AlertRuleType,
        severity: AlertSeverity,
        title: String,
        description: String,
        trackId: String?,
        zoneId: String?,
        sourceId: String?,
        observationId: String?,
        nowMs: Long
    ) {
        val existing = alerts[dedupKey]
        if (existing != null && existing.resolutionState != AlertResolutionState.RESOLVED) {
            val updatedObs = if (observationId != null && !existing.triggeringObservationIds.contains(observationId)) {
                (existing.triggeringObservationIds + observationId).takeLast(12)
            } else {
                existing.triggeringObservationIds
            }
            alerts[dedupKey] = existing.copy(
                description = description,
                lastOccurrenceMs = nowMs,
                occurrenceCount = existing.occurrenceCount + 1,
                triggeringObservationIds = updatedObs,
                resolutionState = AlertResolutionState.ACTIVE
            )
            return
        }

        val id = "ALT-${nextAlertCounter++.toString().padStart(4, '0')}"
        alerts[dedupKey] = AlertRecord(
            alertId = id,
            ruleType = ruleType,
            severity = severity,
            title = title,
            description = description,
            trackId = trackId,
            zoneId = zoneId,
            sourceId = sourceId,
            triggeringObservationIds = listOfNotNull(observationId),
            firstOccurrenceMs = nowMs,
            lastOccurrenceMs = nowMs,
            occurrenceCount = 1,
            acknowledged = false,
            acknowledgedAtMs = null,
            resolutionState = AlertResolutionState.ACTIVE,
            operatorNotes = ""
        )
    }

    private fun markConditionCleared(dedupKey: String) {
        val existing = alerts[dedupKey] ?: return
        if (existing.resolutionState == AlertResolutionState.ACTIVE) {
            alerts[dedupKey] = existing.copy(
                resolutionState = AlertResolutionState.CONDITION_CLEARED
            )
        }
    }
}
