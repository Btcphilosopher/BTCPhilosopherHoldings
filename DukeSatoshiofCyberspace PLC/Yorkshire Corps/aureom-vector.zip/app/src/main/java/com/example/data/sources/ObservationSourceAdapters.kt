package com.example.data.sources

import com.example.domain.model.ConnectionState
import com.example.domain.model.RawSourceMessage
import com.example.domain.model.SourceType
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.StateFlow

/**
 * Documented interface for all observation sources feeding the ingestion pipeline:
 * 1. Synthetic observations ([SyntheticObservationSource])
 * 2. Recorded observation files/sessions ([RecordedObservationSource])
 * 3. Authorised external observation feeds ([ExternalObservationFeedSource])
 * 4. Optional external sensor adapters ([ExternalSensorAdapter])
 */
interface ObservationSourceAdapter {
    val sourceId: String
    val displayName: String
    val sourceType: SourceType
    val connectionState: StateFlow<ConnectionState>
    val incomingMessages: Flow<RawSourceMessage>

    suspend fun start()
    suspend fun stop()
}

interface SyntheticObservationSource : ObservationSourceAdapter

interface RecordedObservationSource : ObservationSourceAdapter {
    suspend fun seekToOffset(offsetMs: Long)
    fun setSpeedMultiplier(multiplier: Float)
    fun setPaused(paused: Boolean)
}

interface ExternalObservationFeedSource : ObservationSourceAdapter {
    fun updateEndpoint(wsUrl: String, bearerToken: String)
}

interface ExternalSensorAdapter {
    val adapterId: String
    val protocolName: String
    fun decodeFrame(rawFrame: ByteArray, receivedAtMs: Long): RawSourceMessage?
}
