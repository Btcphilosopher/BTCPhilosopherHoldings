package com.example.data.sources

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Bundle
import android.os.Looper
import androidx.core.content.ContextCompat
import com.example.domain.geo.GeoMath
import com.example.domain.model.DeviceTelemetryState
import com.example.domain.model.GeoPoint
import com.example.domain.model.SensorAvailability
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

/**
 * Reads device GNSS and orientation sensors as strictly independent inputs with separate
 * availability and accuracy metadata.
 */
class DeviceTelemetryProvider(private val context: Context) {
    private val locationManager = context.getSystemService(Context.LOCATION_SERVICE) as? LocationManager
    private val sensorManager = context.getSystemService(Context.SENSOR_SERVICE) as? SensorManager

    private val _state = MutableStateFlow(DeviceTelemetryState())
    val state: StateFlow<DeviceTelemetryState> = _state.asStateFlow()

    private var locationActive = false
    private var orientationActive = false

    private val rotationMatrix = FloatArray(9)
    private val orientationAngles = FloatArray(3)

    private val locationListener = object : LocationListener {
        override fun onLocationChanged(location: Location) {
            _state.update {
                it.copy(
                    gnssAvailability = SensorAvailability.AVAILABLE,
                    gnssPosition = GeoPoint(location.latitude, location.longitude),
                    gnssAccuracyMeters = if (location.hasAccuracy()) location.accuracy else null,
                    gnssTimestampMs = location.time,
                    gnssProvider = location.provider ?: "GNSS"
                )
            }
        }

        @Deprecated("Deprecated in Android API")
        override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
        override fun onProviderEnabled(provider: String) {}
        override fun onProviderDisabled(provider: String) {}
    }

    private val sensorListener = object : SensorEventListener {
        override fun onSensorChanged(event: SensorEvent) {
            if (event.sensor.type == Sensor.TYPE_ROTATION_VECTOR) {
                SensorManager.getRotationMatrixFromVector(rotationMatrix, event.values)
                SensorManager.getOrientation(rotationMatrix, orientationAngles)
                val azimuthDeg = GeoMath.normalizeBearingDeg(Math.toDegrees(orientationAngles[0].toDouble())).toFloat()
                val pitchDeg = Math.toDegrees(orientationAngles[1].toDouble()).toFloat()
                val rollDeg = Math.toDegrees(orientationAngles[2].toDouble()).toFloat()
                _state.update {
                    it.copy(
                        orientationAvailability = SensorAvailability.AVAILABLE,
                        deviceHeadingDeg = azimuthDeg,
                        devicePitchDeg = pitchDeg,
                        deviceRollDeg = rollDeg,
                        orientationTimestampMs = System.currentTimeMillis()
                    )
                }
            }
        }

        override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {
            val label = when (accuracy) {
                SensorManager.SENSOR_STATUS_ACCURACY_HIGH -> "HIGH"
                SensorManager.SENSOR_STATUS_ACCURACY_MEDIUM -> "MEDIUM"
                SensorManager.SENSOR_STATUS_ACCURACY_LOW -> "LOW"
                else -> "UNRELIABLE"
            }
            _state.update { it.copy(orientationAccuracyLabel = label) }
        }
    }

    fun hasLocationPermission(): Boolean {
        val coarse = ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.ACCESS_COARSE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED
        val fine = ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.ACCESS_FINE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED
        return coarse || fine
    }

    fun hasCameraPermission(): Boolean {
        return ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.CAMERA
        ) == PackageManager.PERMISSION_GRANTED
    }

    @SuppressLint("MissingPermission")
    fun refreshLocationStream() {
        if (!hasLocationPermission()) {
            _state.update {
                it.copy(
                    gnssAvailability = SensorAvailability.PERMISSION_REQUIRED,
                    gnssProvider = "PERMISSION_DENIED"
                )
            }
            return
        }
        val lm = locationManager
        if (lm == null) {
            _state.update { it.copy(gnssAvailability = SensorAvailability.UNAVAILABLE) }
            return
        }
        if (locationActive) return

        val providers = listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER)
            .filter { runCatching { lm.isProviderEnabled(it) }.getOrDefault(false) }

        if (providers.isEmpty()) {
            _state.update {
                it.copy(
                    gnssAvailability = SensorAvailability.UNAVAILABLE,
                    gnssProvider = "NO_ENABLED_PROVIDER"
                )
            }
            return
        }

        providers.forEach { provider ->
            runCatching {
                lm.getLastKnownLocation(provider)?.let { loc ->
                    _state.update {
                        it.copy(
                            gnssAvailability = SensorAvailability.AVAILABLE,
                            gnssPosition = GeoPoint(loc.latitude, loc.longitude),
                            gnssAccuracyMeters = if (loc.hasAccuracy()) loc.accuracy else null,
                            gnssTimestampMs = loc.time,
                            gnssProvider = provider
                        )
                    }
                }
                lm.requestLocationUpdates(provider, 2000L, 5f, locationListener, Looper.getMainLooper())
            }
        }
        locationActive = true
    }

    fun startOrientationSensors() {
        val sm = sensorManager
        val rotSensor = sm?.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR)
        if (sm == null || rotSensor == null) {
            _state.update {
                it.copy(
                    orientationAvailability = SensorAvailability.UNAVAILABLE,
                    orientationAccuracyLabel = "NO_ROT_SENSOR"
                )
            }
            return
        }
        if (orientationActive) return
        sm.registerListener(sensorListener, rotSensor, SensorManager.SENSOR_DELAY_UI)
        orientationActive = true
        _state.update {
            it.copy(
                orientationAvailability = SensorAvailability.AVAILABLE,
                orientationAccuracyLabel = "ACTIVE"
            )
        }
    }

    fun stopAll() {
        if (locationActive) {
            runCatching { locationManager?.removeUpdates(locationListener) }
            locationActive = false
        }
        if (orientationActive) {
            runCatching { sensorManager?.unregisterListener(sensorListener) }
            orientationActive = false
        }
    }
}
