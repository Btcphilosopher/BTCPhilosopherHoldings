package com.example.data.sources

import com.example.domain.model.AltitudeReference
import com.example.domain.model.ConnectionState
import com.example.domain.model.ObjectCategory
import com.example.domain.model.RawSourceMessage
import com.example.domain.model.SourceType
import kotlinx.coroutines.channels.BufferOverflow
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.receiveAsFlow
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import org.json.JSONObject
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicLong

/**
 * Authorised external Ktor WebSocket observation feed adapter.
 * Uses a bounded channel with DROP_OLDEST backpressure so rendering and UI never stall
 * under high-rate telemetry bursts.
 */
class KtorWebSocketSourceAdapter(
    initialWsUrl: String = "ws://10.0.2.2:8080/ws/stream",
    initialToken: String = "aureom-dev-token"
) : ExternalObservationFeedSource {

    override val sourceId: String = "KTOR-WS-FEED"
    override val displayName: String = "Ktor WebSocket Stream"
    override val sourceType: SourceType = SourceType.KTOR_WEBSOCKET

    private val _connectionState = MutableStateFlow(ConnectionState.STANDBY)
    override val connectionState: StateFlow<ConnectionState> = _connectionState.asStateFlow()

    private val queue = Channel<RawSourceMessage>(
        capacity = 256,
        onBufferOverflow = BufferOverflow.DROP_OLDEST
    )
    override val incomingMessages: Flow<RawSourceMessage> = queue.receiveAsFlow()

    private val client = OkHttpClient.Builder()
        .pingInterval(15, TimeUnit.SECONDS)
        .connectTimeout(5, TimeUnit.SECONDS)
        .readTimeout(0, TimeUnit.MILLISECONDS)
        .build()

    private var wsUrl: String = initialWsUrl
    private var bearerToken: String = initialToken
    private var activeSocket: WebSocket? = null
    private val droppedCounter = AtomicLong(0L)
    private val lastError = MutableStateFlow<String?>(null)
    val lastErrorMessage: StateFlow<String?> = lastError.asStateFlow()

    fun getDroppedCount(): Long = droppedCounter.get()

    override fun updateEndpoint(wsUrl: String, bearerToken: String) {
        this.wsUrl = wsUrl.trim()
        this.bearerToken = bearerToken.trim()
    }

    override suspend fun start() {
        stop()
        if (wsUrl.isBlank()) {
            _connectionState.value = ConnectionState.DISCONNECTED
            lastError.value = "Empty WebSocket URL"
            return
        }
        val request = try {
            Request.Builder()
                .url(wsUrl)
                .apply {
                    if (bearerToken.isNotBlank()) {
                        header("Authorization", "Bearer $bearerToken")
                    }
                }
                .build()
        } catch (e: IllegalArgumentException) {
            _connectionState.value = ConnectionState.DISCONNECTED
            lastError.value = "Invalid WebSocket URL: ${e.message}"
            return
        }

        _connectionState.value = ConnectionState.DEGRADED
        lastError.value = null

        activeSocket = client.newWebSocket(request, object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                _connectionState.value = ConnectionState.CONNECTED
                lastError.value = null
            }

            override fun onMessage(webSocket: WebSocket, text: String) {
                val parsed = parseObservationJson(text, System.currentTimeMillis())
                if (parsed != null) {
                    val result = queue.trySend(parsed)
                    if (result.isFailure) {
                        droppedCounter.incrementAndGet()
                    }
                }
            }

            override fun onClosing(webSocket: WebSocket, code: Int, reason: String) {
                _connectionState.value = ConnectionState.DISCONNECTED
                lastError.value = "Closed ($code): $reason"
            }

            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                _connectionState.value = ConnectionState.DISCONNECTED
            }

            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                _connectionState.value = ConnectionState.DISCONNECTED
                lastError.value = t.message ?: "WebSocket connection failed"
            }
        })
    }

    override suspend fun stop() {
        activeSocket?.close(1000, "Operator stop")
        activeSocket = null
        _connectionState.value = ConnectionState.STANDBY
    }

    fun sendControlCommand(commandJson: String) {
        activeSocket?.send(commandJson)
    }

    companion object {
        fun parseObservationJson(text: String, receivedAtMs: Long): RawSourceMessage? {
            return runCatching {
                val obj = JSONObject(text)
                if (obj.optString("type") != "observation") return null
                RawSourceMessage(
                    messageId = obj.getString("messageId"),
                    sourceId = obj.optString("sourceId", "KTOR-WS-FEED"),
                    sourceType = SourceType.KTOR_WEBSOCKET,
                    sequenceNumber = obj.optLong("sequenceNumber", 0L),
                    sensorTimestampMs = obj.optLong("sensorTimestampMs", receivedAtMs),
                    receivedAtMs = receivedAtMs,
                    latDeg = obj.getDouble("latDeg"),
                    lonDeg = obj.getDouble("lonDeg"),
                    groundSpeedMps = if (obj.isNull("groundSpeedMps")) null else obj.optDouble("groundSpeedMps"),
                    courseOverGroundDeg = if (obj.isNull("courseOverGroundDeg")) null else obj.optDouble("courseOverGroundDeg"),
                    headingDeg = if (obj.isNull("headingDeg")) null else obj.optDouble("headingDeg"),
                    altitudeMeters = if (obj.isNull("altitudeMeters")) null else obj.optDouble("altitudeMeters"),
                    altitudeReference = AltitudeReference.entries.firstOrNull {
                        it.name == obj.optString("altitudeReference")
                    } ?: AltitudeReference.UNAVAILABLE,
                    reportedIdentity = obj.optString("reportedIdentity").takeIf { it.isNotBlank() && it != "null" },
                    reportedIdentitySource = obj.optString("reportedIdentitySource").takeIf { it.isNotBlank() && it != "null" },
                    objectCategory = ObjectCategory.entries.firstOrNull {
                        it.name == obj.optString("objectCategory")
                    } ?: ObjectCategory.UNKNOWN_CONTACT,
                    uncertaintyMeters = obj.optDouble("uncertaintyMeters", 50.0),
                    isClutter = obj.optBoolean("isClutter", false),
                    rawPayloadSummary = text.take(160)
                )
            }.getOrNull()
        }
    }
}
