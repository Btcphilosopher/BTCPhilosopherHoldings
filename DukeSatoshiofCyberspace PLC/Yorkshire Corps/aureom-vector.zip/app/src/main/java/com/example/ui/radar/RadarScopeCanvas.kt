package com.example.ui.radar

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.TextMeasurer
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.geo.GeoMath
import com.example.domain.model.AlertRecord
import com.example.domain.model.AlertResolutionState
import com.example.domain.model.AppSettingsState
import com.example.domain.model.DisplayPrediction
import com.example.domain.model.GeoPoint
import com.example.domain.model.MonitoredZone
import com.example.domain.model.ObjectCategory
import com.example.domain.model.ObservationArea
import com.example.domain.model.PositionQuality
import com.example.domain.model.RadarOrientationMode
import com.example.domain.model.TrackStatus
import com.example.domain.model.ZoneShape
import com.example.ui.theme.JetBrainsMonoFamily
import com.example.ui.theme.LocalAureomColors
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.min
import kotlin.math.sin

data class RadarViewportState(
    val zoom: Float = 1.0f,
    val panX: Float = 0f,
    val panY: Float = 0f
)

@Composable
fun RadarScopeCanvas(
    area: ObservationArea,
    rangeNm: Double,
    predictions: List<DisplayPrediction>,
    zones: List<MonitoredZone>,
    alerts: List<AlertRecord>,
    selectedTrackId: String?,
    ownPosition: GeoPoint?,
    headingUpDegrees: Float?,
    settings: AppSettingsState,
    viewport: RadarViewportState,
    onViewportChange: (RadarViewportState) -> Unit,
    onTrackSelected: (String?) -> Unit,
    onFrameDurationMs: (Double) -> Unit,
    modifier: Modifier = Modifier
) {
    val colors = LocalAureomColors.current
    val textMeasurer = rememberTextMeasurer()

    // Measure actual UI frame cadence cleanly without blocking ingestion
    LaunchedEffect(Unit) {
        var lastNs = 0L
        while (true) {
            withFrameNanos { frameNs ->
                if (lastNs != 0L) {
                    val dtMs = (frameNs - lastNs) / 1_000_000.0
                    onFrameDurationMs(dtMs)
                }
                lastNs = frameNs
            }
        }
    }

    val sweepAngle = if (settings.showSweepAnimation && !settings.reducedMotion) {
        val transition = rememberInfiniteTransition(label = "radar_sweep")
        val angle by transition.animateFloat(
            initialValue = 0f,
            targetValue = 360f,
            animationSpec = infiniteRepeatable(
                animation = tween(durationMillis = 6000, easing = LinearEasing),
                repeatMode = RepeatMode.Restart
            ),
            label = "sweep_deg"
        )
        angle
    } else {
        0f
    }

    var scopeSize by remember { mutableStateOf(Size.Zero) }
    val rotationOffsetDeg = if (settings.orientationMode == RadarOrientationMode.HEADING_UP && headingUpDegrees != null) {
        -headingUpDegrees
    } else {
        0f
    }

    val maxRangeMeters = rangeNm * GeoMath.METERS_PER_NM
    val activeZoneAlerts = remember(alerts) {
        alerts.filter { it.resolutionState == AlertResolutionState.ACTIVE && it.zoneId != null }
            .mapNotNull { it.zoneId }
            .toSet()
    }

    Box(
        modifier = modifier
            .testTag("radar_scope_canvas")
            .background(colors.scopeBackground)
            .border(1.dp, colors.panelBorder)
            .semantics {
                contentDescription = "Plan position indicator radar scope with ${predictions.size} tracks and ${zones.size} monitored zones"
            }
    ) {
        Canvas(
            modifier = Modifier
                .fillMaxSize()
                .pointerInput(viewport) {
                    detectTransformGestures { _, pan, zoom, _ ->
                        val newZoom = (viewport.zoom * zoom).coerceIn(0.45f, 5.0f)
                        onViewportChange(
                            viewport.copy(
                                zoom = newZoom,
                                panX = (viewport.panX + pan.x).coerceIn(-1200f, 1200f),
                                panY = (viewport.panY + pan.y).coerceIn(-1200f, 1200f)
                            )
                        )
                    }
                }
                .pointerInput(predictions, viewport, scopeSize, area, rangeNm, rotationOffsetDeg) {
                    detectTapGestures { tapOffset ->
                        if (scopeSize.width <= 0f || scopeSize.height <= 0f) return@detectTapGestures
                        val baseRadiusPx = min(scopeSize.width, scopeSize.height) * 0.43f
                        val center = Offset(
                            scopeSize.width / 2f + viewport.panX,
                            scopeSize.height / 2f + viewport.panY
                        )
                        val pxPerMeter = (baseRadiusPx * viewport.zoom) / maxRangeMeters.toFloat()

                        var nearestId: String? = null
                        var nearestDistPx = 56f // generous touch target

                        for (pred in predictions) {
                            val ptPx = geoToScreenOffset(
                                point = pred.displayPosition,
                                origin = area.center,
                                centerPx = center,
                                pxPerMeter = pxPerMeter,
                                rotationDeg = rotationOffsetDeg
                            )
                            val d = hypot(tapOffset.x - ptPx.x, tapOffset.y - ptPx.y)
                            if (d < nearestDistPx) {
                                nearestDistPx = d
                                nearestId = pred.track.trackId
                            }
                        }
                        onTrackSelected(nearestId)
                    }
                }
        ) {
            scopeSize = size
            val baseRadius = min(size.width, size.height) * 0.43f
            val effectiveRadius = baseRadius * viewport.zoom
            val center = Offset(size.width / 2f + viewport.panX, size.height / 2f + viewport.panY)
            val pxPerMeter = effectiveRadius / maxRangeMeters.toFloat()

            // 1. Subtle radial scope backdrop
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(colors.phosphor.copy(alpha = 0.06f), Color.Transparent),
                    center = center,
                    radius = effectiveRadius.coerceAtLeast(10f)
                ),
                radius = effectiveRadius,
                center = center
            )

            // 2. Fine tactical grid
            drawFineGrid(center, effectiveRadius, colors.phosphorGrid.copy(alpha = 0.25f))

            // 3. Selectable Map Overlay (WGS-84 Coastal / Reference Contours)
            if (settings.showMapOverlay) {
                for (poly in area.coastlinePolygons) {
                    if (poly.size >= 2) {
                        val path = Path()
                        poly.forEachIndexed { idx, pt ->
                            val screen = geoToScreenOffset(pt, area.center, center, pxPerMeter, rotationOffsetDeg)
                            if (idx == 0) path.moveTo(screen.x, screen.y) else path.lineTo(screen.x, screen.y)
                        }
                        path.close()
                        drawPath(
                            path = path,
                            color = colors.cyanMuted.copy(alpha = 0.22f)
                        )
                        drawPath(
                            path = path,
                            color = colors.cyan.copy(alpha = 0.45f),
                            style = Stroke(width = 1.2f)
                        )
                    }
                }
            }

            // 4. Concentric Range Rings & Labels
            val ringCount = 4
            for (i in 1..ringCount) {
                val frac = i / ringCount.toFloat()
                val rPx = effectiveRadius * frac
                drawCircle(
                    color = colors.phosphorGrid.copy(alpha = if (i == ringCount) 0.9f else 0.55f),
                    radius = rPx,
                    center = center,
                    style = Stroke(width = if (i == ringCount) 1.6f else 1.0f)
                )
                val ringDistMeters = maxRangeMeters * frac
                val labelText = GeoMath.formatDistance(ringDistMeters, settings.distanceUnit)
                drawLabelText(
                    textMeasurer = textMeasurer,
                    text = labelText,
                    topLeft = Offset(center.x + 6f, center.y - rPx + 4f),
                    color = colors.textSecondary
                )
            }

            // 5. Bearing ticks & North indicator (rotated in Heading-Up mode)
            drawBearingScale(
                center = center,
                radius = effectiveRadius,
                rotationOffsetDeg = rotationOffsetDeg,
                tickColor = colors.phosphorGrid,
                labelColor = colors.textSecondary,
                northColor = colors.cyan,
                textMeasurer = textMeasurer
            )

            // 6. Monitored Zones
            for (zone in zones) {
                if (!zone.enabled) continue
                val isBreached = activeZoneAlerts.contains(zone.zoneId)
                val zoneColor = if (isBreached) colors.critical else colors.amber
                val dashEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 8f), 0f)

                when (zone.shape) {
                    ZoneShape.CIRCLE -> {
                        val zCenter = geoToScreenOffset(zone.center, area.center, center, pxPerMeter, rotationOffsetDeg)
                        val zRadPx = (zone.radiusMeters * pxPerMeter).toFloat()
                        drawCircle(
                            color = zoneColor.copy(alpha = if (isBreached) 0.16f else 0.08f),
                            radius = zRadPx,
                            center = zCenter
                        )
                        drawCircle(
                            color = zoneColor,
                            radius = zRadPx,
                            center = zCenter,
                            style = Stroke(width = if (isBreached) 2.4f else 1.6f, pathEffect = dashEffect)
                        )
                        drawLabelText(
                            textMeasurer = textMeasurer,
                            text = zone.name,
                            topLeft = Offset(zCenter.x - 40f, zCenter.y - zRadPx - 16f),
                            color = zoneColor
                        )
                    }
                    ZoneShape.POLYGON -> {
                        if (zone.polygonVertices.size >= 3) {
                            val path = Path()
                            zone.polygonVertices.forEachIndexed { idx, pt ->
                                val s = geoToScreenOffset(pt, area.center, center, pxPerMeter, rotationOffsetDeg)
                                if (idx == 0) path.moveTo(s.x, s.y) else path.lineTo(s.x, s.y)
                            }
                            path.close()
                            drawPath(path, color = zoneColor.copy(alpha = if (isBreached) 0.16f else 0.08f))
                            drawPath(
                                path,
                                color = zoneColor,
                                style = Stroke(width = if (isBreached) 2.4f else 1.6f, pathEffect = dashEffect)
                            )
                            val zCenter = geoToScreenOffset(zone.center, area.center, center, pxPerMeter, rotationOffsetDeg)
                            drawLabelText(textMeasurer, zone.name, zCenter, zoneColor)
                        }
                    }
                }
            }

            // 7. Cosmetic Instrument Sweep Sector (NOT tied to observation freshness)
            if (settings.showSweepAnimation && !settings.reducedMotion) {
                rotate(degrees = sweepAngle, pivot = center) {
                    drawArc(
                        brush = Brush.sweepGradient(
                            0.0f to Color.Transparent,
                            0.88f to Color.Transparent,
                            1.0f to colors.phosphor.copy(alpha = 0.22f),
                            center = center
                        ),
                        startAngle = -90f,
                        sweepAngle = 360f,
                        useCenter = true,
                        topLeft = Offset(center.x - effectiveRadius, center.y - effectiveRadius),
                        size = Size(effectiveRadius * 2f, effectiveRadius * 2f)
                    )
                    drawLine(
                        color = colors.phosphor.copy(alpha = 0.65f),
                        start = center,
                        end = Offset(center.x, center.y - effectiveRadius),
                        strokeWidth = 1.5f
                    )
                }
            }

            // 8. Own-position marker (where a valid position source exists)
            if (ownPosition != null) {
                val ownPx = geoToScreenOffset(ownPosition, area.center, center, pxPerMeter, rotationOffsetDeg)
                drawCircle(
                    color = colors.cyan,
                    radius = 7f,
                    center = ownPx,
                    style = Stroke(width = 2f)
                )
                drawLine(colors.cyan, Offset(ownPx.x - 11f, ownPx.y), Offset(ownPx.x + 11f, ownPx.y), 1.5f)
                drawLine(colors.cyan, Offset(ownPx.x, ownPx.y - 11f), Offset(ownPx.x, ownPx.y + 11f), 1.5f)
            }

            // 9. Tracks, Trails & Quality Visual Distinction
            for (pred in predictions) {
                val track = pred.track
                val isSelected = track.trackId == selectedTrackId
                val trackPosPx = geoToScreenOffset(pred.displayPosition, area.center, center, pxPerMeter, rotationOffsetDeg)

                val baseColor = when {
                    track.status == TrackStatus.STALE || track.status == TrackStatus.LOST -> colors.amber
                    track.ambiguousAssociation -> colors.amber
                    track.category == ObjectCategory.CIVILIAN_AIRCRAFT -> colors.cyan
                    track.category == ObjectCategory.MARITIME_VESSEL -> colors.phosphor
                    track.category == ObjectCategory.PERIMETER_VEHICLE -> colors.amber
                    else -> colors.textPrimary
                }

                // Draw optional history trail
                if (settings.trailLength > 0 && track.history.size > 1) {
                    val trailPts = track.history.takeLast(settings.trailLength)
                    for (idx in 0 until trailPts.size - 1) {
                        val a = geoToScreenOffset(trailPts[idx].position, area.center, center, pxPerMeter, rotationOffsetDeg)
                        val b = geoToScreenOffset(trailPts[idx + 1].position, area.center, center, pxPerMeter, rotationOffsetDeg)
                        val alpha = 0.15f + 0.55f * (idx.toFloat() / trailPts.size.toFloat())
                        drawLine(
                            color = baseColor.copy(alpha = alpha),
                            start = a,
                            end = b,
                            strokeWidth = 1.6f
                        )
                    }
                }

                // If extrapolated or estimated, draw connector from last measured position
                if (pred.positionQuality == PositionQuality.EXTRAPOLATED) {
                    val lastMeasPx = geoToScreenOffset(track.lastMeasuredPosition, area.center, center, pxPerMeter, rotationOffsetDeg)
                    drawLine(
                        color = colors.amber.copy(alpha = 0.8f),
                        start = lastMeasPx,
                        end = trackPosPx,
                        strokeWidth = 1.5f,
                        pathEffect = PathEffect.dashPathEffect(floatArrayOf(5f, 5f), 0f)
                    )
                }

                // Velocity leader vector
                val speed = track.estimatedSpeedMps ?: 0.0
                val course = track.estimatedCourseDeg
                if (course != null && speed > 1.0) {
                    val headingRad = Math.toRadians(course + rotationOffsetDeg)
                    val vecLen = (14f + (speed * 0.25f).toFloat()).coerceAtMost(42f)
                    val endPx = Offset(
                        x = trackPosPx.x + (sin(headingRad) * vecLen).toFloat(),
                        y = trackPosPx.y - (cos(headingRad) * vecLen).toFloat()
                    )
                    drawLine(
                        color = baseColor,
                        start = trackPosPx,
                        end = endPx,
                        strokeWidth = 1.8f,
                        pathEffect = if (pred.positionQuality == PositionQuality.EXTRAPOLATED) {
                            PathEffect.dashPathEffect(floatArrayOf(4f, 4f), 0f)
                        } else null
                    )
                }

                // Draw distinct category & quality symbol
                drawTrackSymbol(
                    center = trackPosPx,
                    category = track.category,
                    quality = pred.positionQuality,
                    color = baseColor,
                    courseDeg = (track.estimatedCourseDeg ?: 0.0) + rotationOffsetDeg,
                    colorBlindMode = settings.colorBlindSymbols
                )

                // Ambiguity halo
                if (track.ambiguousAssociation) {
                    drawCircle(
                        color = colors.amber,
                        radius = 16f,
                        center = trackPosPx,
                        style = Stroke(
                            width = 1.4f,
                            pathEffect = PathEffect.dashPathEffect(floatArrayOf(4f, 4f), 0f)
                        )
                    )
                }

                // Selection brackets
                if (isSelected) {
                    val r = 18f
                    drawLine(colors.cyan, Offset(trackPosPx.x - r, trackPosPx.y - r), Offset(trackPosPx.x - r + 7f, trackPosPx.y - r), 2.5f)
                    drawLine(colors.cyan, Offset(trackPosPx.x - r, trackPosPx.y - r), Offset(trackPosPx.x - r, trackPosPx.y - r + 7f), 2.5f)
                    drawLine(colors.cyan, Offset(trackPosPx.x + r, trackPosPx.y - r), Offset(trackPosPx.x + r - 7f, trackPosPx.y - r), 2.5f)
                    drawLine(colors.cyan, Offset(trackPosPx.x + r, trackPosPx.y - r), Offset(trackPosPx.x + r, trackPosPx.y - r + 7f), 2.5f)
                    drawLine(colors.cyan, Offset(trackPosPx.x - r, trackPosPx.y + r), Offset(trackPosPx.x - r + 7f, trackPosPx.y + r), 2.5f)
                    drawLine(colors.cyan, Offset(trackPosPx.x - r, trackPosPx.y + r), Offset(trackPosPx.x - r, trackPosPx.y + r - 7f), 2.5f)
                    drawLine(colors.cyan, Offset(trackPosPx.x + r, trackPosPx.y + r), Offset(trackPosPx.x + r - 7f, trackPosPx.y + r), 2.5f)
                    drawLine(colors.cyan, Offset(trackPosPx.x + r, trackPosPx.y + r), Offset(trackPosPx.x + r, trackPosPx.y + r - 7f), 2.5f)
                }

                // Track tag
                val tag = buildString {
                    append(track.reportedIdentity ?: track.trackId)
                    if (pred.positionQuality == PositionQuality.EXTRAPOLATED) {
                        append(" [EXTRAP ${GeoMath.formatAge(pred.observationAgeMs)}]")
                    } else if (track.ambiguousAssociation) {
                        append(" [AMB]")
                    }
                }
                drawLabelText(
                    textMeasurer = textMeasurer,
                    text = tag,
                    topLeft = Offset(trackPosPx.x + 14f, trackPosPx.y - 8f),
                    color = if (isSelected) colors.cyan else baseColor
                )
            }
        }

        // Top-left Orientation & Scale Legend
        Column(
            modifier = Modifier
                .align(Alignment.TopStart)
                .padding(8.dp)
                .background(colors.panelSurface.copy(alpha = 0.85f), RoundedCornerShape(4.dp))
                .border(1.dp, colors.panelBorder, RoundedCornerShape(4.dp))
                .padding(horizontal = 8.dp, vertical = 5.dp)
        ) {
            Text(
                text = if (settings.orientationMode == RadarOrientationMode.HEADING_UP) {
                    "HDG-UP ${GeoMath.formatBearing(headingUpDegrees?.toDouble())}"
                } else {
                    "NORTH-UP TRUE"
                },
                style = MaterialTheme.typography.labelSmall,
                color = colors.cyan
            )
            Text(
                text = "RNG ${GeoMath.formatDistance(maxRangeMeters, settings.distanceUnit)} | ${String.format("%.1fx", viewport.zoom)}",
                style = MaterialTheme.typography.labelSmall,
                color = colors.textPrimary
            )
        }

        // Bottom-left Quality & Map Attribution Legend
        Column(
            modifier = Modifier
                .align(Alignment.BottomStart)
                .padding(8.dp)
                .background(colors.panelSurface.copy(alpha = 0.85f), RoundedCornerShape(4.dp))
                .border(1.dp, colors.panelBorder, RoundedCornerShape(4.dp))
                .padding(horizontal = 8.dp, vertical = 5.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("● MEASURED  ", style = MaterialTheme.typography.labelSmall, color = colors.phosphor)
                Text("◎ EST  ", style = MaterialTheme.typography.labelSmall, color = colors.cyan)
                Text("◌ EXTRAP", style = MaterialTheme.typography.labelSmall, color = colors.amber)
            }
            if (settings.showMapOverlay) {
                Text(
                    text = "Overlay: WGS-84 Synthetic Coastal Ref (Sweep ≠ Fix Time)",
                    style = MaterialTheme.typography.labelSmall,
                    color = colors.textSecondary
                )
            }
        }
    }
}

private fun geoToScreenOffset(
    point: GeoPoint,
    origin: GeoPoint,
    centerPx: Offset,
    pxPerMeter: Float,
    rotationDeg: Float
): Offset {
    val enu = GeoMath.toEnu(point, origin)
    var x = enu.eastMeters.toFloat() * pxPerMeter
    var y = -enu.northMeters.toFloat() * pxPerMeter
    if (rotationDeg != 0f) {
        val rad = Math.toRadians(rotationDeg.toDouble())
        val cosR = cos(rad).toFloat()
        val sinR = sin(rad).toFloat()
        val rx = x * cosR - y * sinR
        val ry = x * sinR + y * cosR
        x = rx
        y = ry
    }
    return Offset(centerPx.x + x, centerPx.y + y)
}

private fun DrawScope.drawFineGrid(center: Offset, radius: Float, gridColor: Color) {
    val step = (radius / 4f).coerceAtLeast(30f)
    var offset = -radius
    while (offset <= radius) {
        drawLine(gridColor, Offset(center.x + offset, center.y - radius), Offset(center.x + offset, center.y + radius), 0.7f)
        drawLine(gridColor, Offset(center.x - radius, center.y + offset), Offset(center.x + radius, center.y + offset), 0.7f)
        offset += step
    }
}

private fun DrawScope.drawBearingScale(
    center: Offset,
    radius: Float,
    rotationOffsetDeg: Float,
    tickColor: Color,
    labelColor: Color,
    northColor: Color,
    textMeasurer: TextMeasurer
) {
    for (deg in 0 until 360 step 10) {
        val screenDeg = deg + rotationOffsetDeg
        val rad = Math.toRadians(screenDeg.toDouble())
        val isMajor = deg % 30 == 0
        val inner = radius * (if (isMajor) 0.94f else 0.97f)
        val p1 = Offset(center.x + (sin(rad) * inner).toFloat(), center.y - (cos(rad) * inner).toFloat())
        val p2 = Offset(center.x + (sin(rad) * radius).toFloat(), center.y - (cos(rad) * radius).toFloat())
        drawLine(
            color = if (deg == 0) northColor else tickColor,
            start = p1,
            end = p2,
            strokeWidth = if (deg == 0) 2.5f else if (isMajor) 1.5f else 0.9f
        )
        if (isMajor) {
            val label = when (deg) {
                0 -> "N"
                90 -> "E"
                180 -> "S"
                270 -> "W"
                else -> deg.toString().padStart(3, '0')
            }
            val labelR = radius + 12f
            val lp = Offset(
                center.x + (sin(rad) * labelR).toFloat() - 10f,
                center.y - (cos(rad) * labelR).toFloat() - 7f
            )
            drawLabelText(
                textMeasurer = textMeasurer,
                text = label,
                topLeft = lp,
                color = if (deg == 0) northColor else labelColor
            )
        }
    }
}

private fun DrawScope.drawTrackSymbol(
    center: Offset,
    category: ObjectCategory,
    quality: PositionQuality,
    color: Color,
    courseDeg: Double,
    colorBlindMode: Boolean
) {
    val dashed = PathEffect.dashPathEffect(floatArrayOf(4f, 3f), 0f)
    val strokeStyle = when (quality) {
        PositionQuality.MEASURED -> null
        PositionQuality.ESTIMATED -> Stroke(width = 2.0f)
        PositionQuality.EXTRAPOLATED -> Stroke(width = 2.0f, pathEffect = dashed)
    }

    val r = 9f
    when (category) {
        ObjectCategory.CIVILIAN_AIRCRAFT -> {
            val path = Path()
            val rad = Math.toRadians(courseDeg)
            val cosR = cos(rad).toFloat()
            val sinR = sin(rad).toFloat()
            fun rot(dx: Float, dy: Float) = Offset(center.x + dx * cosR - dy * sinR, center.y + dx * sinR + dy * cosR)
            val nose = rot(0f, -r * 1.2f)
            val left = rot(-r, r)
            val tail = rot(0f, r * 0.4f)
            val right = rot(r, r)
            path.moveTo(nose.x, nose.y)
            path.lineTo(left.x, left.y)
            path.lineTo(tail.x, tail.y)
            path.lineTo(right.x, right.y)
            path.close()
            if (strokeStyle == null) drawPath(path, color = color) else drawPath(path, color = color, style = strokeStyle)
        }
        ObjectCategory.MARITIME_VESSEL -> {
            val path = Path().apply {
                moveTo(center.x, center.y - r)
                lineTo(center.x + r * 0.75f, center.y)
                lineTo(center.x, center.y + r)
                lineTo(center.x - r * 0.75f, center.y)
                close()
            }
            if (strokeStyle == null) drawPath(path, color = color) else drawPath(path, color = color, style = strokeStyle)
        }
        ObjectCategory.PERIMETER_VEHICLE -> {
            val topLeft = Offset(center.x - r * 0.8f, center.y - r * 0.8f)
            val rectSize = Size(r * 1.6f, r * 1.6f)
            if (strokeStyle == null) {
                drawRect(color = color, topLeft = topLeft, size = rectSize)
            } else {
                drawRect(color = color, topLeft = topLeft, size = rectSize, style = strokeStyle)
            }
        }
        else -> {
            if (strokeStyle == null) {
                drawCircle(color = color, radius = r * 0.85f, center = center)
            } else {
                drawCircle(color = color, radius = r * 0.85f, center = center, style = strokeStyle)
            }
        }
    }

    if (quality == PositionQuality.ESTIMATED) {
        drawCircle(color = color, radius = r + 3.5f, center = center, style = Stroke(width = 1.0f))
    }
    if (colorBlindMode) {
        // High-contrast center dot/crosshair regardless of hue
        drawCircle(color = Color.White, radius = 2.2f, center = center)
    }
}

private fun DrawScope.drawLabelText(
    textMeasurer: TextMeasurer,
    text: String,
    topLeft: Offset,
    color: Color
) {
    if (topLeft.x < -120f || topLeft.y < -40f || topLeft.x > size.width + 40f || topLeft.y > size.height + 20f) return
    val layout = textMeasurer.measure(
        text = text,
        style = TextStyle(
            fontFamily = JetBrainsMonoFamily,
            fontSize = 10.sp,
            color = color
        )
    )
    drawText(layout, topLeft = topLeft)
}
