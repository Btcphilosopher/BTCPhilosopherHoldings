package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.DoneAll
import androidx.compose.material.icons.filled.Download
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.domain.model.AlertRecord
import com.example.domain.model.AlertResolutionState
import com.example.domain.model.AlertSeverity
import com.example.domain.model.MonitoredZone
import com.example.ui.components.InstrumentPanel
import com.example.ui.components.InstrumentSectionHeader
import com.example.ui.components.KeyValueReadout
import com.example.ui.components.StatusPill
import com.example.ui.theme.LocalAureomColors
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

private enum class AlertFilter(val label: String) {
    ALL("All"),
    ACTIVE("Active"),
    UNACK("Unacknowledged"),
    CRITICAL("Critical")
}

@Composable
fun AlertsScreen(
    alerts: List<AlertRecord>,
    zones: List<MonitoredZone>,
    onAcknowledge: (String) -> Unit,
    onResolve: (String) -> Unit,
    onUpdateNotes: (String, String) -> Unit,
    onToggleZone: (MonitoredZone) -> Unit,
    onExportReport: () -> Unit,
    modifier: Modifier = Modifier
) {
    val colors = LocalAureomColors.current
    var filter by remember { mutableStateOf(AlertFilter.ALL) }
    val utcFmt = remember {
        SimpleDateFormat("HH:mm:ss'Z'", Locale.US).apply {
            timeZone = TimeZone.getTimeZone("UTC")
        }
    }

    val filtered = remember(alerts, filter) {
        when (filter) {
            AlertFilter.ALL -> alerts
            AlertFilter.ACTIVE -> alerts.filter { it.resolutionState == AlertResolutionState.ACTIVE }
            AlertFilter.UNACK -> alerts.filter { !it.acknowledged }
            AlertFilter.CRITICAL -> alerts.filter { it.severity == AlertSeverity.CRITICAL }
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(colors.scopeBackground)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            InstrumentSectionHeader(
                title = "Alerts & Monitored Zones",
                trailing = "${alerts.count { it.resolutionState == AlertResolutionState.ACTIVE }} active",
                modifier = Modifier.weight(1f)
            )
            Spacer(modifier = Modifier.width(8.dp))
            OutlinedButton(
                onClick = onExportReport,
                modifier = Modifier.heightIn(min = 48.dp).testTag("alerts_export_button")
            ) {
                Icon(Icons.Default.Download, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("Report")
            }
        }

        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            AlertFilter.entries.forEach { f ->
                FilterChip(
                    selected = filter == f,
                    onClick = { filter = f },
                    label = { Text(f.label, style = MaterialTheme.typography.labelSmall) },
                    modifier = Modifier.heightIn(min = 48.dp)
                )
            }
        }

        LazyColumn(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(filtered, key = { it.alertId }) { alert ->
                val sevColor = when (alert.severity) {
                    AlertSeverity.CRITICAL -> colors.critical
                    AlertSeverity.CAUTION -> colors.amber
                    AlertSeverity.INFO -> colors.cyan
                }
                val resColor = when (alert.resolutionState) {
                    AlertResolutionState.ACTIVE -> colors.critical
                    AlertResolutionState.CONDITION_CLEARED -> colors.amber
                    AlertResolutionState.RESOLVED -> colors.phosphor
                }
                var noteDraft by remember(alert.alertId, alert.operatorNotes) {
                    mutableStateOf(alert.operatorNotes)
                }

                InstrumentPanel(borderColor = sevColor.copy(alpha = 0.7f)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "${alert.alertId} • ${alert.title}",
                            style = MaterialTheme.typography.titleSmall,
                            color = colors.textPrimary,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.weight(1f)
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            StatusPill(alert.severity.label, sevColor)
                            StatusPill(alert.resolutionState.label, resColor)
                        }
                    }

                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = alert.description,
                        style = MaterialTheme.typography.bodySmall,
                        color = colors.textSecondary
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    KeyValueReadout("Rule", alert.ruleType.label)
                    KeyValueReadout(
                        "First / Recent UTC",
                        "${utcFmt.format(Date(alert.firstOccurrenceMs))} / ${utcFmt.format(Date(alert.lastOccurrenceMs))} (×${alert.occurrenceCount})"
                    )
                    KeyValueReadout(
                        "Triggering Obs",
                        alert.triggeringObservationIds.takeLast(3).joinToString(", ").ifEmpty { "SYS-STATE" }
                    )
                    KeyValueReadout(
                        "Acknowledgement",
                        if (alert.acknowledged) "ACKNOWLEDGED (Condition state independent)" else "UNACKNOWLEDGED",
                        valueColor = if (alert.acknowledged) colors.cyan else colors.amber
                    )

                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = noteDraft,
                        onValueChange = {
                            noteDraft = it
                            onUpdateNotes(alert.alertId, it)
                        },
                        label = { Text("Operator notes") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = { onAcknowledge(alert.alertId) },
                            enabled = !alert.acknowledged,
                            colors = ButtonDefaults.buttonColors(containerColor = colors.cyan, contentColor = colors.scopeBackground),
                            modifier = Modifier.weight(1f).heightIn(min = 48.dp).testTag("ack_alert_${alert.alertId}")
                        ) {
                            Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(if (alert.acknowledged) "Acknowledged" else "Acknowledge")
                        }
                        OutlinedButton(
                            onClick = { onResolve(alert.alertId) },
                            enabled = alert.resolutionState != AlertResolutionState.RESOLVED,
                            modifier = Modifier.weight(1f).heightIn(min = 48.dp).testTag("resolve_alert_${alert.alertId}")
                        ) {
                            Icon(Icons.Default.DoneAll, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(if (alert.resolutionState == AlertResolutionState.RESOLVED) "Resolved" else "Mark Resolved")
                        }
                    }
                }
            }

            if (filtered.isEmpty()) {
                item {
                    InstrumentPanel {
                        Box(
                            modifier = Modifier.fillMaxWidth().padding(24.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "No alerts match the selected filter.",
                                style = MaterialTheme.typography.bodyMedium,
                                color = colors.textSecondary
                            )
                        }
                    }
                }
            }

            item {
                Spacer(modifier = Modifier.height(6.dp))
                InstrumentSectionHeader("Configured Monitored Zones", trailing = "${zones.size} zones")
            }

            items(zones, key = { it.zoneId }) { zone ->
                InstrumentPanel {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(zone.name, style = MaterialTheme.typography.titleSmall, color = colors.textPrimary)
                            Text(
                                text = "${zone.shape.name} • Dwell ${zone.loiterThresholdSec}s • Hysteresis ${zone.hysteresisMeters.toInt()}m",
                                style = MaterialTheme.typography.labelSmall,
                                color = colors.textSecondary
                            )
                        }
                        OutlinedButton(
                            onClick = { onToggleZone(zone) },
                            modifier = Modifier.heightIn(min = 48.dp)
                        ) {
                            Text(if (zone.enabled) "Enabled" else "Disabled")
                        }
                    }
                }
            }
        }
    }
}
