package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.domain.model.AppSettingsState
import com.example.domain.model.ConnectionState
import com.example.domain.model.DeviceTelemetryState
import com.example.domain.model.OperatingMode
import com.example.domain.model.SimulatorConfig
import com.example.ui.RadarScreenState
import com.example.ui.components.InstrumentPanel
import com.example.ui.components.InstrumentSectionHeader
import com.example.ui.components.KeyValueReadout
import com.example.ui.components.StatusPill
import com.example.ui.theme.LocalAureomColors
import java.util.Locale

@Composable
fun SourcesScreen(
    state: RadarScreenState,
    settings: AppSettingsState,
    telemetry: DeviceTelemetryState,
    onUpdateSimConfig: (SimulatorConfig) -> Unit,
    onToggleOutage: () -> Unit,
    onConnectBackend: (wsUrl: String, token: String) -> Unit,
    onDisconnectBackend: () -> Unit,
    modifier: Modifier = Modifier
) {
    val colors = LocalAureomColors.current
    val sim = state.simulatorConfig

    var seedInput by remember(sim.seed) { mutableStateOf(sim.seed.toString()) }
    var wsUrlInput by remember(settings.backendWsUrl) { mutableStateOf(settings.backendWsUrl) }
    var tokenInput by remember(settings.backendAuthToken) { mutableStateOf(settings.backendAuthToken) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(colors.scopeBackground)
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Active Sources Table
        InstrumentPanel {
            InstrumentSectionHeader(
                title = "Configured Observation Sources",
                trailing = state.operatingMode.label
            )
            Spacer(modifier = Modifier.height(8.dp))
            state.sources.forEach { src ->
                val badgeColor = when (src.connectionState) {
                    ConnectionState.CONNECTED -> colors.phosphor
                    ConnectionState.DEGRADED -> colors.amber
                    ConnectionState.DISCONNECTED -> colors.critical
                    ConnectionState.STANDBY -> colors.textSecondary
                }
                Column(modifier = Modifier.padding(vertical = 6.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(src.name, style = MaterialTheme.typography.titleSmall, color = colors.textPrimary)
                            Text(src.endpoint, style = MaterialTheme.typography.labelSmall, color = colors.textSecondary)
                        }
                        StatusPill(src.connectionState.label, badgeColor)
                    }
                    KeyValueReadout(
                        "Accepted / Rejected / Dups",
                        "${src.messagesAccepted} / ${src.messagesRejected} / ${src.duplicatesDropped}"
                    )
                }
            }
            KeyValueReadout(
                "Device GNSS / Orientation",
                "${telemetry.gnssAvailability.label} / ${telemetry.orientationAvailability.label}"
            )
        }

        // Ktor + PostgreSQL WebSocket Feed Adapter
        InstrumentPanel(borderColor = if (state.operatingMode == OperatingMode.LIVE_OBSERVATION) colors.phosphor else colors.panelBorder) {
            InstrumentSectionHeader(
                title = "Ktor + PostgreSQL WebSocket Backend",
                trailing = if (state.operatingMode == OperatingMode.LIVE_OBSERVATION) "ACTIVE" else "STANDBY"
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "Connect to the standalone Kotlin Ktor server (default emulator host ws://10.0.2.2:8080/ws/stream or wss:// for TLS).",
                style = MaterialTheme.typography.bodySmall,
                color = colors.textSecondary
            )
            Spacer(modifier = Modifier.height(8.dp))
            OutlinedTextField(
                value = wsUrlInput,
                onValueChange = { wsUrlInput = it },
                label = { Text("WebSocket Endpoint") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(modifier = Modifier.height(6.dp))
            OutlinedTextField(
                value = tokenInput,
                onValueChange = { tokenInput = it },
                label = { Text("Scoped Bearer Token") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(modifier = Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = { onConnectBackend(wsUrlInput, tokenInput) },
                    colors = ButtonDefaults.buttonColors(containerColor = colors.cyan, contentColor = colors.scopeBackground),
                    modifier = Modifier.weight(1f).heightIn(min = 48.dp).testTag("connect_ktor_button")
                ) {
                    Text("Connect Ktor Stream")
                }
                if (state.operatingMode == OperatingMode.LIVE_OBSERVATION) {
                    OutlinedButton(
                        onClick = onDisconnectBackend,
                        border = BorderStroke(1.dp, colors.amber),
                        modifier = Modifier.weight(1f).heightIn(min = 48.dp)
                    ) {
                        Text("Return to Local Sim", color = colors.amber)
                    }
                }
            }
        }

        // Deterministic Synthetic Sensor & Impairment Controls
        InstrumentPanel {
            InstrumentSectionHeader(
                title = "Deterministic Simulator & Impairments",
                trailing = "Seed ${sim.seed}"
            )
            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = seedInput,
                    onValueChange = { seedInput = it },
                    label = { Text("Random Seed") },
                    singleLine = true,
                    modifier = Modifier.weight(1f)
                )
                Button(
                    onClick = {
                        val parsed = seedInput.toLongOrNull() ?: 20260401L
                        onUpdateSimConfig(sim.copy(seed = parsed))
                    },
                    modifier = Modifier.heightIn(min = 52.dp)
                ) {
                    Text("Apply Seed")
                }
            }

            Spacer(modifier = Modifier.height(10.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Simulate Sensor Outage",
                        style = MaterialTheme.typography.titleSmall,
                        color = if (sim.sensorOutageActive) colors.critical else colors.textPrimary,
                        fontWeight = FontWeight.SemiBold
                    )
                    Text(
                        text = "Drops all incoming plots to test stale-track & connection-loss alerts.",
                        style = MaterialTheme.typography.bodySmall,
                        color = colors.textSecondary
                    )
                }
                Switch(
                    checked = sim.sensorOutageActive,
                    onCheckedChange = { onToggleOutage() },
                    modifier = Modifier.testTag("sources_outage_switch")
                )
            }

            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "Missed Detection Probability: ${String.format(Locale.US, "%.0f%%", sim.missedDetectionProb * 100)}",
                style = MaterialTheme.typography.labelMedium,
                color = colors.textPrimary
            )
            Slider(
                value = sim.missedDetectionProb.toFloat(),
                onValueChange = { onUpdateSimConfig(sim.copy(missedDetectionProb = it.toDouble())) },
                valueRange = 0f..0.4f
            )

            Text(
                text = "Clutter Plots / Scan: ${sim.clutterPerScan}",
                style = MaterialTheme.typography.labelMedium,
                color = colors.textPrimary
            )
            Slider(
                value = sim.clutterPerScan.toFloat(),
                onValueChange = { onUpdateSimConfig(sim.copy(clutterPerScan = it.toInt())) },
                valueRange = 0f..8f,
                steps = 7
            )

            Text(
                text = "Delayed Out-of-Order Probability: ${String.format(Locale.US, "%.0f%%", sim.delayedMessageProb * 100)}",
                style = MaterialTheme.typography.labelMedium,
                color = colors.textPrimary
            )
            Slider(
                value = sim.delayedMessageProb.toFloat(),
                onValueChange = { onUpdateSimConfig(sim.copy(delayedMessageProb = it.toDouble())) },
                valueRange = 0f..0.35f
            )

            Text(
                text = "Duplicate Message Probability: ${String.format(Locale.US, "%.0f%%", sim.duplicateMessageProb * 100)}",
                style = MaterialTheme.typography.labelMedium,
                color = colors.textPrimary
            )
            Slider(
                value = sim.duplicateMessageProb.toFloat(),
                onValueChange = { onUpdateSimConfig(sim.copy(duplicateMessageProb = it.toDouble())) },
                valueRange = 0f..0.35f
            )

            Text(
                text = "Position Noise (1σ): ${sim.positionNoiseSigmaMeters.toInt()} m",
                style = MaterialTheme.typography.labelMedium,
                color = colors.textPrimary
            )
            Slider(
                value = sim.positionNoiseSigmaMeters.toFloat(),
                onValueChange = { onUpdateSimConfig(sim.copy(positionNoiseSigmaMeters = it.toDouble())) },
                valueRange = 5f..250f
            )
        }
    }
}
