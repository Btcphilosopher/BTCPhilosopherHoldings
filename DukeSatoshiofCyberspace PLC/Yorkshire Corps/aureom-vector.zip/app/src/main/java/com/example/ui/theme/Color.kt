package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Night / Tactical British Aerospace Palette
val GraphiteBg = Color(0xFF0B0F14)
val DeepNavySurface = Color(0xFF101720)
val PanelSurface = Color(0xFF151E29)
val ElevatedPanel = Color(0xFF1B2736)
val HairlineBorder = Color(0xFF28384D)

val PhosphorGreen = Color(0xFF2CE67A)
val PhosphorGrid = Color(0xFF194B33)
val PhosphorGlow = Color(0x332CE67A)

val InstrumentCyan = Color(0xFF38D6E8)
val InstrumentCyanMuted = Color(0xFF1C5B66)

val AmberCaution = Color(0xFFF5A623)
val AmberCautionBg = Color(0x29F5A623)

val CriticalRed = Color(0xFFFF4D4F)
val CriticalRedBg = Color(0x29FF4D4F)

val OffWhiteText = Color(0xFFE6ECF2)
val SlateText = Color(0xFF8FA3B8)
val DimSlateText = Color(0xFF5D7085)

// Day / High-Ambient Cockpit Palette
val DayBg = Color(0xFFE5EBF0)
val DaySurface = Color(0xFFF1F5F8)
val DayPanel = Color(0xFFFFFFFF)
val DayElevated = Color(0xFFDCE4EC)
val DayBorder = Color(0xFFB4C2D0)

val DayPhosphor = Color(0xFF0D7A42)
val DayPhosphorGrid = Color(0xFF9AC5AE)
val DayCyan = Color(0xFF006D87)
val DayAmber = Color(0xFFB86B00)
val DayRed = Color(0xFFC9242B)

val DayNavyText = Color(0xFF0D1824)
val DaySlateText = Color(0xFF475A6E)
