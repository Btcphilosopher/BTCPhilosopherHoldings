package com.example.domain.tracking

import com.example.domain.geo.EnuPoint
import com.example.domain.geo.GeoMath
import com.example.domain.model.AssociatedTrack
import com.example.domain.model.AssociationEvent
import com.example.domain.model.DisplayPrediction
import com.example.domain.model.GeoPoint
import com.example.domain.model.ObjectCategory
import com.example.domain.model.PositionQuality
import com.example.domain.model.RawSourceMessage
import com.example.domain.model.TrackHistoryPoint
import com.example.domain.model.TrackStatus
import com.example.domain.model.ValidatedObservation
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.sin

data class IngestionResult(
    val acceptedObservation: ValidatedObservation?,
    val rejectionReason: String?,
    val isDuplicate: Boolean = false,
    val associatedTrackId: String? = null
)

/**
 * Baseline Global Nearest-Neighbor (GNN) + Alpha-Beta kinematic track associator.
 *
 * Guarantees:
 * 1. Explicit units (meters, m/s, degrees, epoch ms).
 * 2. Deduplicates by (sourceId, sequenceNumber) and (sourceId, messageId).
 * 3. Rejects invalid coordinates, NaN, and negative speeds.
 * 4. Handles out-of-order delayed messages without corrupting track state.
 * 5. NEVER merges two tracks solely because their reported labels/identities match.
 * 6. Exposes ambiguous associations in [AssociatedTrack.ambiguousAssociation] and history.
 */
class TrackAssociator(
    private val origin: GeoPoint,
    private val maxHistoryPerTrack: Int = 120,
    private val maxAssociationHistory: Int = 25,
    private val defaultGateMeters: Double = 1200.0
) {
    private val tracks = linkedMapOf<String, MutableTrackState>()
    private val seenKeys = LinkedHashSet<String>()
    private var nextTrackIndex = 101

    private data class MutableTrackState(
        val trackId: String,
        var category: ObjectCategory,
        var primarySourceId: String,
        val contributingSources: MutableSet<String>,
        var reportedIdentity: String?,
        var reportedIdentitySource: String?,
        var lastMeasuredPosition: GeoPoint,
        var lastObservationId: String,
        var lastObservationTimestampMs: Long,
        var estimatedPosition: GeoPoint,
        var estimatedSpeedMps: Double?,
        var estimatedCourseDeg: Double?,
        var headingDeg: Double?,
        var altitudeMeters: Double?,
        var altitudeReference: com.example.domain.model.AltitudeReference,
        var uncertaintyMeters: Double,
        var status: TrackStatus,
        var observationCount: Int,
        var missedScanCount: Int,
        var ambiguousAssociation: Boolean,
        var ambiguousTrackIds: List<String>,
        val history: ArrayDeque<TrackHistoryPoint>,
        val associationHistory: ArrayDeque<AssociationEvent>,
        val sourceObjectHint: String? = null
    )

    fun reset() {
        tracks.clear()
        seenKeys.clear()
        nextTrackIndex = 101
    }

    fun ingest(raw: RawSourceMessage): IngestionResult {
        // 1. Duplicate check
        val dedupKey = "${raw.sourceId}:${raw.sequenceNumber}:${raw.messageId}"
        if (seenKeys.contains(dedupKey)) {
            return IngestionResult(
                acceptedObservation = null,
                rejectionReason = "Duplicate message seq=${raw.sequenceNumber}",
                isDuplicate = true
            )
        }
        seenKeys.add(dedupKey)
        if (seenKeys.size > 4096) {
            val it = seenKeys.iterator()
            if (it.hasNext()) {
                it.next()
                it.remove()
            }
        }

        // 2. Input validation
        val validationError = validateRaw(raw)
        if (validationError != null) {
            return IngestionResult(
                acceptedObservation = null,
                rejectionReason = validationError
            )
        }

        val obs = ValidatedObservation(
            observationId = "OBS-${raw.messageId}",
            rawMessageId = raw.messageId,
            sourceId = raw.sourceId,
            sourceType = raw.sourceType,
            sequenceNumber = raw.sequenceNumber,
            sensorTimestampMs = raw.sensorTimestampMs,
            ingestedAtMs = raw.receivedAtMs,
            position = GeoPoint(raw.latDeg, raw.lonDeg),
            positionUncertaintyMeters = raw.uncertaintyMeters,
            groundSpeedMps = raw.groundSpeedMps,
            courseOverGroundDeg = raw.courseOverGroundDeg?.let { GeoMath.normalizeBearingDeg(it) },
            headingDeg = raw.headingDeg?.let { GeoMath.normalizeBearingDeg(it) },
            altitudeMeters = raw.altitudeMeters,
            altitudeReference = raw.altitudeReference,
            reportedIdentity = raw.reportedIdentity?.takeIf { it.isNotBlank() },
            reportedIdentitySource = raw.reportedIdentitySource,
            objectCategory = raw.objectCategory,
            isClutter = raw.isClutter
        )

        if (obs.isClutter || obs.objectCategory == ObjectCategory.CLUTTER) {
            return IngestionResult(
                acceptedObservation = obs,
                rejectionReason = null,
                associatedTrackId = null
            )
        }

        val associatedId = associateObservation(obs)
        return IngestionResult(
            acceptedObservation = obs,
            rejectionReason = null,
            associatedTrackId = associatedId
        )
    }

    private fun validateRaw(raw: RawSourceMessage): String? {
        if (!GeoMath.isValidCoordinate(raw.latDeg, raw.lonDeg)) {
            return "Invalid coordinates (${raw.latDeg}, ${raw.lonDeg})"
        }
        if (raw.groundSpeedMps != null && (!raw.groundSpeedMps.isFinite() || raw.groundSpeedMps < 0.0 || raw.groundSpeedMps > 1200.0)) {
            return "Invalid ground speed: ${raw.groundSpeedMps} m/s"
        }
        if (raw.courseOverGroundDeg != null && !raw.courseOverGroundDeg.isFinite()) {
            return "Invalid course over ground"
        }
        if (!raw.uncertaintyMeters.isFinite() || raw.uncertaintyMeters < 0.0) {
            return "Invalid uncertainty: ${raw.uncertaintyMeters}"
        }
        if (raw.sensorTimestampMs <= 0L) {
            return "Invalid sensor timestamp"
        }
        return null
    }

    private fun associateObservation(obs: ValidatedObservation): String {
        val gateMeters = computeGateMeters(obs.objectCategory, obs.positionUncertaintyMeters)

        // Score all compatible tracks using kinematic prediction at obs.sensorTimestampMs.
        // Crucially, NEVER gate/merge solely by matching reportedIdentity!
        val candidates = mutableListOf<Pair<MutableTrackState, Double>>()
        for (track in tracks.values) {
            if (!isCategoryCompatible(track.category, obs.objectCategory)) continue

            // Out-of-order protection: if observation is older than track's latest observation by > 1.5s,
            // compare against historical position if available or tight gate without overwriting newer kinematics.
            val dtSec = (obs.sensorTimestampMs - track.lastObservationTimestampMs) / 1000.0
            val predictedPos = if (dtSec >= -1.5 && dtSec <= 60.0) {
                predictPosition(
                    from = track.estimatedPosition,
                    speedMps = track.estimatedSpeedMps ?: 0.0,
                    courseDeg = track.estimatedCourseDeg ?: 0.0,
                    dtSeconds = dtSec.coerceAtLeast(0.0)
                )
            } else if (dtSec < -1.5) {
                // Late/out-of-order packet: check against nearest history point around sensorTimestampMs
                findNearestHistoryPoint(track, obs.sensorTimestampMs) ?: track.lastMeasuredPosition
            } else {
                track.estimatedPosition
            }

            val dist = GeoMath.haversineDistanceMeters(predictedPos, obs.position)
            val dynamicGate = gateMeters + (track.estimatedSpeedMps ?: 0.0) * kotlin.math.abs(dtSec).coerceAtMost(10.0) * 0.5
            if (dist <= dynamicGate) {
                candidates.add(track to dist)
            }
        }

        candidates.sortBy { it.second }

        if (candidates.isEmpty()) {
            return createTrack(obs)
        }

        val best = candidates.first()
        val ambiguousList = candidates.drop(1).filter { it.second <= best.second + 650.0 }.map { it.first.trackId }
        val track = best.first

        // Out-of-order delayed message handling: record in history/provenance, do NOT regress current kinematics
        if (obs.sensorTimestampMs < track.lastObservationTimestampMs) {
            track.contributingSources.add(obs.sourceId)
            track.observationCount += 1
            appendAssociationEvent(
                track,
                AssociationEvent(
                    timestampMs = obs.sensorTimestampMs,
                    observationId = obs.observationId,
                    sourceId = obs.sourceId,
                    gateDistanceMeters = best.second,
                    ambiguousCandidates = ambiguousList.size,
                    summary = "Delayed out-of-order plot recorded (${String.format("%.0f", best.second)} m)"
                )
            )
            return track.trackId
        }

        // Alpha-Beta filter update
        val dtSec = ((obs.sensorTimestampMs - track.lastObservationTimestampMs) / 1000.0).coerceAtLeast(0.1)
        val predicted = predictPosition(
            from = track.estimatedPosition,
            speedMps = track.estimatedSpeedMps ?: (obs.groundSpeedMps ?: 0.0),
            courseDeg = track.estimatedCourseDeg ?: (obs.courseOverGroundDeg ?: 0.0),
            dtSeconds = dtSec
        )

        val alpha = 0.65
        val predEnu = GeoMath.toEnu(predicted, origin)
        val measEnu = GeoMath.toEnu(obs.position, origin)
        val filteredEnu = EnuPoint(
            eastMeters = predEnu.eastMeters + alpha * (measEnu.eastMeters - predEnu.eastMeters),
            northMeters = predEnu.northMeters + alpha * (measEnu.northMeters - predEnu.northMeters)
        )
        val filteredGeo = GeoMath.fromEnu(filteredEnu, origin)

        // Derive/smooth velocity
        val prevMeasEnu = GeoMath.toEnu(track.lastMeasuredPosition, origin)
        val derivEastVel = (measEnu.eastMeters - prevMeasEnu.eastMeters) / dtSec
        val derivNorthVel = (measEnu.northMeters - prevMeasEnu.northMeters) / dtSec
        val derivSpeed = hypot(derivEastVel, derivNorthVel)
        val derivCourse = GeoMath.normalizeBearingDeg(Math.toDegrees(atan2(derivEastVel, derivNorthVel)))

        track.estimatedSpeedMps = obs.groundSpeedMps ?: if (track.estimatedSpeedMps != null) {
            0.6 * track.estimatedSpeedMps!! + 0.4 * derivSpeed
        } else {
            derivSpeed
        }

        track.estimatedCourseDeg = obs.courseOverGroundDeg ?: if (derivSpeed > 0.5) {
            if (track.estimatedCourseDeg != null) {
                val delta = GeoMath.shortestAngularDeltaDeg(track.estimatedCourseDeg!!, derivCourse)
                GeoMath.normalizeBearingDeg(track.estimatedCourseDeg!! + 0.4 * delta)
            } else {
                derivCourse
            }
        } else {
            track.estimatedCourseDeg
        }

        track.lastMeasuredPosition = obs.position
        track.lastObservationId = obs.observationId
        track.lastObservationTimestampMs = obs.sensorTimestampMs
        track.estimatedPosition = filteredGeo
        track.headingDeg = obs.headingDeg ?: track.headingDeg
        track.altitudeMeters = obs.altitudeMeters ?: track.altitudeMeters
        if (obs.altitudeMeters != null) track.altitudeReference = obs.altitudeReference
        track.uncertaintyMeters = obs.positionUncertaintyMeters
        track.primarySourceId = obs.sourceId
        track.contributingSources.add(obs.sourceId)
        if (obs.reportedIdentity != null) {
            track.reportedIdentity = obs.reportedIdentity
            track.reportedIdentitySource = obs.reportedIdentitySource
        }
        track.observationCount += 1
        track.missedScanCount = 0
        track.status = if (track.observationCount >= 2) TrackStatus.CONFIRMED else TrackStatus.TENTATIVE
        track.ambiguousAssociation = ambiguousList.isNotEmpty()
        track.ambiguousTrackIds = ambiguousList

        appendHistory(
            track,
            TrackHistoryPoint(
                position = obs.position,
                timestampMs = obs.sensorTimestampMs,
                quality = PositionQuality.MEASURED
            )
        )
        appendAssociationEvent(
            track,
            AssociationEvent(
                timestampMs = obs.sensorTimestampMs,
                observationId = obs.observationId,
                sourceId = obs.sourceId,
                gateDistanceMeters = best.second,
                ambiguousCandidates = ambiguousList.size,
                summary = if (ambiguousList.isEmpty()) {
                    "GNN associated (${String.format("%.0f", best.second)} m)"
                } else {
                    "Ambiguous gate (${ambiguousList.size + 1} tracks near ${String.format("%.0f", best.second)} m)"
                }
            )
        )
        return track.trackId
    }

    private fun createTrack(obs: ValidatedObservation): String {
        val id = "TRK-${nextTrackIndex++}"
        val history = ArrayDeque<TrackHistoryPoint>(maxHistoryPerTrack)
        history.addLast(
            TrackHistoryPoint(
                position = obs.position,
                timestampMs = obs.sensorTimestampMs,
                quality = PositionQuality.MEASURED
            )
        )
        val assocHistory = ArrayDeque<AssociationEvent>(maxAssociationHistory)
        assocHistory.addLast(
            AssociationEvent(
                timestampMs = obs.sensorTimestampMs,
                observationId = obs.observationId,
                sourceId = obs.sourceId,
                gateDistanceMeters = 0.0,
                ambiguousCandidates = 0,
                summary = "Track initiated from ${obs.sourceId}"
            )
        )
        tracks[id] = MutableTrackState(
            trackId = id,
            category = obs.objectCategory,
            primarySourceId = obs.sourceId,
            contributingSources = linkedSetOf(obs.sourceId),
            reportedIdentity = obs.reportedIdentity,
            reportedIdentitySource = obs.reportedIdentitySource,
            lastMeasuredPosition = obs.position,
            lastObservationId = obs.observationId,
            lastObservationTimestampMs = obs.sensorTimestampMs,
            estimatedPosition = obs.position,
            estimatedSpeedMps = obs.groundSpeedMps,
            estimatedCourseDeg = obs.courseOverGroundDeg,
            headingDeg = obs.headingDeg,
            altitudeMeters = obs.altitudeMeters,
            altitudeReference = obs.altitudeReference,
            uncertaintyMeters = obs.positionUncertaintyMeters,
            status = TrackStatus.TENTATIVE,
            observationCount = 1,
            missedScanCount = 0,
            ambiguousAssociation = false,
            ambiguousTrackIds = emptyList(),
            history = history,
            associationHistory = assocHistory
        )
        return id
    }

    private fun computeGateMeters(category: ObjectCategory, uncertaintyMeters: Double): Double {
        val base = when (category) {
            ObjectCategory.CIVILIAN_AIRCRAFT -> 2200.0
            ObjectCategory.MARITIME_VESSEL -> 900.0
            ObjectCategory.PERIMETER_VEHICLE -> 350.0
            ObjectCategory.UNKNOWN_CONTACT -> defaultGateMeters
            ObjectCategory.CLUTTER -> 100.0
        }
        return base + uncertaintyMeters * 2.0
    }

    private fun isCategoryCompatible(a: ObjectCategory, b: ObjectCategory): Boolean {
        if (a == b) return true
        return a == ObjectCategory.UNKNOWN_CONTACT || b == ObjectCategory.UNKNOWN_CONTACT
    }

    private fun findNearestHistoryPoint(track: MutableTrackState, timestampMs: Long): GeoPoint? {
        return track.history.minByOrNull { kotlin.math.abs(it.timestampMs - timestampMs) }?.position
    }

    private fun appendHistory(track: MutableTrackState, pt: TrackHistoryPoint) {
        if (track.history.size >= maxHistoryPerTrack) {
            track.history.removeFirst()
        }
        track.history.addLast(pt)
    }

    private fun appendAssociationEvent(track: MutableTrackState, ev: AssociationEvent) {
        if (track.associationHistory.size >= maxAssociationHistory) {
            track.associationHistory.removeFirst()
        }
        track.associationHistory.addLast(ev)
    }

    private fun predictPosition(
        from: GeoPoint,
        speedMps: Double,
        courseDeg: Double,
        dtSeconds: Double
    ): GeoPoint {
        if (dtSeconds <= 0.0 || speedMps <= 0.05) return from
        val dist = speedMps * dtSeconds
        return GeoMath.destinationPoint(from, courseDeg, dist)
    }

    /**
     * Builds display predictions at [nowMs] while strictly bounding extrapolation so
     * predicted motion is never presented indefinitely as observed motion.
     */
    fun buildDisplayPredictions(
        nowMs: Long,
        ownPosition: GeoPoint,
        staleThresholdMs: Long = 15_000L,
        maxExtrapolationMs: Long = 20_000L
    ): List<DisplayPrediction> {
        val out = ArrayList<DisplayPrediction>(tracks.size)
        val iterator = tracks.values.iterator()
        while (iterator.hasNext()) {
            val t = iterator.next()
            val ageMs = (nowMs - t.lastObservationTimestampMs).coerceAtLeast(0L)

            // Drop tracks dead for > 5 minutes in long sessions
            if (ageMs > 300_000L) {
                iterator.remove()
                continue
            }

            val effectiveExtrapMs = ageMs.coerceAtMost(maxExtrapolationMs)
            val isCapped = ageMs > maxExtrapolationMs

            val quality: PositionQuality
            val displayPos: GeoPoint
            if (ageMs <= 2200L) {
                quality = PositionQuality.MEASURED
                displayPos = t.lastMeasuredPosition
            } else if (ageMs <= 5000L) {
                quality = PositionQuality.ESTIMATED
                displayPos = predictPosition(
                    from = t.estimatedPosition,
                    speedMps = t.estimatedSpeedMps ?: 0.0,
                    courseDeg = t.estimatedCourseDeg ?: 0.0,
                    dtSeconds = (ageMs / 1000.0).coerceAtMost(5.0)
                )
            } else {
                quality = PositionQuality.EXTRAPOLATED
                displayPos = predictPosition(
                    from = t.estimatedPosition,
                    speedMps = t.estimatedSpeedMps ?: 0.0,
                    courseDeg = t.estimatedCourseDeg ?: 0.0,
                    dtSeconds = effectiveExtrapMs / 1000.0
                )
            }

            t.status = when {
                ageMs > staleThresholdMs * 3 -> TrackStatus.LOST
                ageMs >= staleThresholdMs -> TrackStatus.STALE
                ageMs > 4500L -> TrackStatus.COASTING
                t.observationCount >= 2 -> TrackStatus.CONFIRMED
                else -> TrackStatus.TENTATIVE
            }

            val snapshot = AssociatedTrack(
                trackId = t.trackId,
                category = t.category,
                primarySourceId = t.primarySourceId,
                contributingSources = t.contributingSources.toSet(),
                reportedIdentity = t.reportedIdentity,
                reportedIdentitySource = t.reportedIdentitySource,
                identityVerified = false,
                lastMeasuredPosition = t.lastMeasuredPosition,
                lastObservationId = t.lastObservationId,
                lastObservationTimestampMs = t.lastObservationTimestampMs,
                estimatedPosition = t.estimatedPosition,
                estimatedSpeedMps = t.estimatedSpeedMps,
                estimatedCourseDeg = t.estimatedCourseDeg,
                headingDeg = t.headingDeg,
                altitudeMeters = t.altitudeMeters,
                altitudeReference = t.altitudeReference,
                uncertaintyMeters = t.uncertaintyMeters,
                status = t.status,
                observationCount = t.observationCount,
                missedScanCount = t.missedScanCount,
                ambiguousAssociation = t.ambiguousAssociation,
                ambiguousTrackIds = t.ambiguousTrackIds,
                history = t.history.toList(),
                associationHistory = t.associationHistory.toList()
            )

            out.add(
                DisplayPrediction(
                    track = snapshot,
                    displayPosition = displayPos,
                    positionQuality = quality,
                    observationAgeMs = ageMs,
                    extrapolationDurationMs = if (quality == PositionQuality.EXTRAPOLATED) effectiveExtrapMs else 0L,
                    isExtrapolationCapped = isCapped,
                    rangeFromOriginMeters = GeoMath.haversineDistanceMeters(ownPosition, displayPos),
                    bearingFromOriginDeg = GeoMath.bearingDeg(ownPosition, displayPos)
                )
            )
        }
        return out
    }
}
