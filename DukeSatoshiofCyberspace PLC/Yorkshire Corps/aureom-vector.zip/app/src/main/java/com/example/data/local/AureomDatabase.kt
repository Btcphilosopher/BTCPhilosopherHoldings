package com.example.data.local

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Index
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "replay_sessions")
data class ReplaySessionEntity(
    @PrimaryKey val sessionId: String,
    val title: String,
    val scenarioId: String,
    val seed: Long,
    val startedAtMs: Long,
    val endedAtMs: Long,
    val observationCount: Int,
    val alertCount: Int,
    val isBuiltInDemo: Boolean = false
)

@Entity(
    tableName = "recorded_observations",
    indices = [Index(value = ["sessionId", "offsetMs"])]
)
data class RecordedObservationEntity(
    @PrimaryKey(autoGenerate = true) val rowId: Long = 0,
    val sessionId: String,
    val offsetMs: Long,
    val messageId: String,
    val sourceId: String,
    val sourceType: String,
    val sequenceNumber: Long,
    val sensorTimestampMs: Long,
    val latDeg: Double,
    val lonDeg: Double,
    val groundSpeedMps: Double?,
    val courseOverGroundDeg: Double?,
    val headingDeg: Double?,
    val altitudeMeters: Double?,
    val altitudeReference: String,
    val reportedIdentity: String?,
    val reportedIdentitySource: String?,
    val objectCategory: String,
    val uncertaintyMeters: Double,
    val isClutter: Boolean
)

@Entity(tableName = "monitored_zones")
data class MonitoredZoneEntity(
    @PrimaryKey val zoneId: String,
    val name: String,
    val scenarioId: String,
    val shape: String,
    val centerLatDeg: Double,
    val centerLonDeg: Double,
    val radiusMeters: Double,
    val polygonJson: String,
    val alertOnEntry: Boolean,
    val alertOnExit: Boolean,
    val loiterThresholdSec: Int,
    val hysteresisMeters: Double,
    val enabled: Boolean
)

@Entity(tableName = "track_annotations")
data class TrackAnnotationEntity(
    @PrimaryKey val targetId: String,
    val note: String,
    val updatedAtMs: Long
)

@Entity(tableName = "saved_alerts")
data class SavedAlertEntity(
    @PrimaryKey val alertId: String,
    val sessionId: String,
    val ruleType: String,
    val severity: String,
    val title: String,
    val description: String,
    val trackId: String?,
    val zoneId: String?,
    val sourceId: String?,
    val triggeringObsCsv: String,
    val firstOccurrenceMs: Long,
    val lastOccurrenceMs: Long,
    val occurrenceCount: Int,
    val acknowledged: Boolean,
    val acknowledgedAtMs: Long?,
    val resolutionState: String,
    val operatorNotes: String
)

@Dao
interface ReplaySessionDao {
    @Query("SELECT * FROM replay_sessions ORDER BY startedAtMs DESC")
    fun observeSessions(): Flow<List<ReplaySessionEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertSession(session: ReplaySessionEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertObservations(observations: List<RecordedObservationEntity>)

    @Query("SELECT * FROM recorded_observations WHERE sessionId = :sessionId ORDER BY offsetMs ASC, rowId ASC")
    suspend fun getObservationsForSession(sessionId: String): List<RecordedObservationEntity>

    @Query("SELECT COUNT(*) FROM recorded_observations")
    suspend fun countAllObservations(): Int

    @Query("DELETE FROM replay_sessions WHERE sessionId = :sessionId")
    suspend fun deleteSession(sessionId: String)

    @Query("DELETE FROM recorded_observations WHERE sessionId = :sessionId")
    suspend fun deleteObservationsForSession(sessionId: String)
}

@Dao
interface MonitoredZoneDao {
    @Query("SELECT * FROM monitored_zones WHERE scenarioId = :scenarioId ORDER BY name ASC")
    fun observeZonesForScenario(scenarioId: String): Flow<List<MonitoredZoneEntity>>

    @Query("SELECT * FROM monitored_zones WHERE scenarioId = :scenarioId")
    suspend fun getZonesForScenario(scenarioId: String): List<MonitoredZoneEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertZone(zone: MonitoredZoneEntity)

    @Query("DELETE FROM monitored_zones WHERE zoneId = :zoneId")
    suspend fun deleteZone(zoneId: String)
}

@Dao
interface AnnotationDao {
    @Query("SELECT * FROM track_annotations")
    fun observeAnnotations(): Flow<List<TrackAnnotationEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAnnotation(entity: TrackAnnotationEntity)
}

@Dao
interface AlertDao {
    @Query("SELECT * FROM saved_alerts WHERE sessionId = :sessionId ORDER BY lastOccurrenceMs DESC")
    suspend fun getAlertsForSession(sessionId: String): List<SavedAlertEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAlerts(alerts: List<SavedAlertEntity>)
}

@Database(
    entities = [
        ReplaySessionEntity::class,
        RecordedObservationEntity::class,
        MonitoredZoneEntity::class,
        TrackAnnotationEntity::class,
        SavedAlertEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AureomDatabase : RoomDatabase() {
    abstract fun replaySessionDao(): ReplaySessionDao
    abstract fun monitoredZoneDao(): MonitoredZoneDao
    abstract fun annotationDao(): AnnotationDao
    abstract fun alertDao(): AlertDao

    companion object {
        @Volatile
        private var INSTANCE: AureomDatabase? = null

        fun getInstance(context: Context): AureomDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    AureomDatabase::class.java,
                    "aureom_vector.db"
                ).build().also { INSTANCE = it }
            }
        }
    }
}
