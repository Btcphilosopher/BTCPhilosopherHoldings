package com.example.ui.radar

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.domain.geo.GeoMath
import com.example.domain.model.AltitudeReference
import com.example.domain.model.AppSettingsState
import com.example.domain.model.DisplayPrediction
import com.example.domain.model.OperatorAnnotation
import com.example.domain.model.PositionQuality
import com.example.domain.model.TrackStatus
import com.example.ui.components.InstrumentPanel
import com.example.ui.components.InstrumentSectionHeader
import com.example.ui.components.KeyValueReadout
import com.example.ui.components.StatusPill
import com.example.ui.theme.LocalAureomColors
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

@Composable
fun TrackInspectorPanel(
    prediction: DisplayPrediction,
    annotation: OperatorAnnotation?,
    settings: AppSettingsState,
    onSaveAnnotation: (String, String) -> Unit,
    onClose: () -> Unit,
    modifier: Modifier = Modifier
) {
    val colors = LocalAureomColors.current
    val track = prediction.track
    var noteInput by remember(track.trackId, annotation?.note) {
        mutableStateOf(annotation?.note ?: "")
    }
    val utcFmt = remember {
        SimpleDateFormat("HH:mm:ss.SSS'Z'", Locale.US).apply {
            timeZone = TimeZone.getTimeZone("UTC")
        }
    }

    val qualityColor = when (prediction.positionQuality) {
        PositionQuality.MEASURED -> colors.phosphor
        PositionQuality.ESTIMATED -> colors.cyan
        PositionQuality.EXTRAPOLATED -> colors.amber
    }
    val statusColor = when (track.status) {
        TrackStatus.CONFIRMED -> colors.phosphor
        TrackStatus.TENTATIVE, TrackStatus.COASTING -> colors.cyan
        TrackStatus.STALE, TrackStatus.LOST -> colors.critical
    }

    InstrumentPanel(
        modifier = modifier.testTag("track_inspector_panel")
    ) {
        Column(modifier = Modifier.verticalScroll(rememberScrollState())) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = track.trackId,
                        style = MaterialTheme.typography.titleLarge,
                        color = colors.cyan
                    )
                    Text(
                        text = track.category.displayLabel,
                        style = MaterialTheme.typography.bodySmall,
                        color = colors.textSecondary
                    )
                }
                IconButton(
                    onClick = onClose,
                    modifier = Modifier.testTag("close_inspector_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Close track inspector",
                        tint = colors.textSecondary
                    )
                }
            }

            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                StatusPill(track.status.badge, statusColor)
                StatusPill(prediction.positionQuality.badge, qualityColor)
                if (track.ambiguousAssociation) {
                    StatusPill("AMBIGUOUS", colors.amber)
                }
            }

            if (prediction.isExtrapolationCapped) {
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "Extrapolation capped at ${settings.maxExtrapolationSec}s — displaying last predicted limit, not live motion.",
                    style = MaterialTheme.typography.bodySmall,
                    color = colors.amber
                )
            }

            HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp), color = colors.panelBorder)
            InstrumentSectionHeader("Identity & Provenance")
            Spacer(modifier = Modifier.height(4.dp))
            KeyValueReadout(
                label = "Reported Identity",
                value = track.reportedIdentity ?: "UNAVAILABLE",
                valueColor = if (track.reportedIdentity != null) colors.textPrimary else colors.textDim
            )
            KeyValueReadout(
                label = "Identity Source",
                value = track.reportedIdentitySource ?: "UNAVAILABLE"
            )
            KeyValueReadout(
                label = "Verification",
                value = "UNVERIFIED (Label ≠ Verified ID)",
                valueColor = colors.amber
            )
            KeyValueReadout(
                label = "Sensor / Feed",
                value = track.contributingSources.joinToString(", ")
            )
            KeyValueReadout(
                label = "Uncertainty",
                value = "±${String.format(Locale.US, "%.0f", track.uncertaintyMeters)} m (1σ)"
            )

            HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp), color = colors.panelBorder)
            InstrumentSectionHeader("Kinematics & Position (WGS-84)")
            Spacer(modifier = Modifier.height(4.dp))
            KeyValueReadout(
                label = "Display Pos",
                value = GeoMath.formatCoordinate(prediction.displayPosition, settings.coordinateFormat)
            )
            KeyValueReadout(
                label = "Range / Bearing",
                value = "${GeoMath.formatDistance(prediction.rangeFromOriginMeters, settings.distanceUnit)} / ${GeoMath.formatBearing(prediction.bearingFromOriginDeg)}"
            )
            KeyValueReadout(
                label = "Ground Speed",
                value = GeoMath.formatSpeed(track.estimatedSpeedMps, settings.distanceUnit)
            )
            KeyValueReadout(
                label = "Course (COG)",
                value = GeoMath.formatBearing(track.estimatedCourseDeg)
            )
            KeyValueReadout(
                label = "Heading",
                value = GeoMath.formatBearing(track.headingDeg),
                valueColor = if (track.headingDeg != null) colors.textPrimary else colors.textDim
            )
            val altText = if (track.altitudeMeters != null && track.altitudeReference != AltitudeReference.UNAVAILABLE) {
                "${String.format(Locale.US, "%.0f", track.altitudeMeters)} m (${track.altitudeReference.shortLabel})"
            } else {
                "UNAVAILABLE"
            }
            KeyValueReadout(
                label = "Altitude / Ref",
                value = altText,
                valueColor = if (track.altitudeMeters != null) colors.textPrimary else colors.textDim
            )
            KeyValueReadout(
                label = "Last Obs UTC",
                value = utcFmt.format(Date(track.lastObservationTimestampMs))
            )
            KeyValueReadout(
                label = "Observation Age",
                value = GeoMath.formatAge(prediction.observationAgeMs),
                valueColor = if (prediction.observationAgeMs >= settings.staleThresholdSec * 1000L) colors.amber else colors.phosphor
            )

            HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp), color = colors.panelBorder)
            InstrumentSectionHeader(
                title = "Association History",
                trailing = "${track.observationCount} obs"
            )
            Spacer(modifier = Modifier.height(4.dp))
            if (track.ambiguousTrackIds.isNotEmpty()) {
                Text(
                    text = "Competing gate candidates: ${track.ambiguousTrackIds.joinToString(", ")}",
                    style = MaterialTheme.typography.labelSmall,
                    color = colors.amber
                )
                Spacer(modifier = Modifier.height(4.dp))
            }
            track.associationHistory.takeLast(5).reversed().forEach { ev ->
                Text(
                    text = "${utcFmt.format(Date(ev.timestampMs))} • ${ev.summary}",
                    style = MaterialTheme.typography.labelSmall,
                    color = colors.textSecondary
                )
            }

            HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp), color = colors.panelBorder)
            InstrumentSectionHeader("Operator Annotation")
            Spacer(modifier = Modifier.height(6.dp))
            OutlinedTextField(
                value = noteInput,
                onValueChange = { noteInput = it },
                label = { Text("Track note") },
                singleLine = false,
                maxLines = 3,
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(modifier = Modifier.height(6.dp))
            Button(
                onClick = { onSaveAnnotation(track.trackId, noteInput) },
                colors = ButtonDefaults.buttonColors(containerColor = colors.cyan, contentColor = colors.scopeBackground),
                modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp)
            ) {
                Text("Save Track Annotation")
            }
        }
    }
}
