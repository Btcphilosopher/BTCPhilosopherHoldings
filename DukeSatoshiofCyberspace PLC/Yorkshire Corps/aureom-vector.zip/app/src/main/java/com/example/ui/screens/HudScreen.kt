package com.example.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.GpsFixed
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.example.domain.geo.GeoMath
import com.example.domain.model.AlertResolutionState
import com.example.domain.model.AppSettingsState
import com.example.domain.model.ConnectionState
import com.example.domain.model.DeviceTelemetryState
import com.example.domain.model.SensorAvailability
import com.example.ui.RadarScreenState
import com.example.ui.components.InstrumentPanel
import com.example.ui.components.KeyValueReadout
import com.example.ui.components.StatusPill
import com.example.ui.theme.LocalAureomColors
import java.util.Locale
import kotlin.math.roundToInt

@Composable
fun HudScreen(
    state: RadarScreenState,
    settings: AppSettingsState,
    telemetry: DeviceTelemetryState,
    onRequestLocationPermissionResult: (Boolean) -> Unit,
    onExitHud: () -> Unit,
    modifier: Modifier = Modifier
) {
    val colors = LocalAureomColors.current
    val context = LocalContext.current
    var cameraOverlayEnabled by remember { mutableStateOf(false) }
    var hasCameraPerm by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) ==
                PackageManager.PERMISSION_GRANTED
        )
    }

    val locationPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        val granted = results.values.any { it }
        onRequestLocationPermissionResult(granted)
    }

    val cameraPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        hasCameraPerm = granted
        if (granted) cameraOverlayEnabled = true
    }

    val selectedTrack = remember(state.predictions, state.selectedTrackId) {
        state.predictions.firstOrNull { it.track.trackId == state.selectedTrackId }
            ?: state.predictions.firstOrNull()
    }
    val activeAlerts = state.alerts.filter { it.resolutionState == AlertResolutionState.ACTIVE }
    val connectedSources = state.sources.count { it.connectionState == ConnectionState.CONNECTED }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(colors.scopeBackground)
            .testTag("hud_screen")
    ) {
        // Optional Experimental Camera Overlay (clearly labeled as uncalibrated)
        if (cameraOverlayEnabled && hasCameraPerm) {
            ExperimentalCameraBackdrop(modifier = Modifier.fillMaxSize())
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(colors.scopeBackground.copy(alpha = 0.55f))
            )
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(14.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Top HUD Bar + Heading Strip
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedButton(
                        onClick = onExitHud,
                        modifier = Modifier.heightIn(min = 48.dp).testTag("exit_hud_button")
                    ) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Return from HUD")
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Exit HUD")
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        StatusPill(state.operatingMode.label, colors.cyan)
                        OutlinedButton(
                            onClick = {
                                if (!cameraOverlayEnabled) {
                                    if (hasCameraPerm) {
                                        cameraOverlayEnabled = true
                                    } else {
                                        cameraPermissionLauncher.launch(Manifest.permission.CAMERA)
                                    }
                                } else {
                                    cameraOverlayEnabled = false
                                }
                            },
                            modifier = Modifier.heightIn(min = 48.dp).testTag("hud_camera_toggle")
                        ) {
                            Icon(Icons.Default.CameraAlt, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(if (cameraOverlayEnabled) "Cam:ON" else "Exp. Cam")
                        }
                    }
                }

                if (cameraOverlayEnabled) {
                    Surface(
                        color = colors.amberBg,
                        border = BorderStroke(1.dp, colors.amber),
                        shape = RoundedCornerShape(4.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = "EXPERIMENTAL CAMERA OVERLAY — UNCALIBRATED (±12° ALIGNMENT UNCERTAINTY). DO NOT USE FOR PRECISION TARGETING.",
                            style = MaterialTheme.typography.labelSmall,
                            color = colors.amber,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                        )
                    }
                }

                // Heading Strip
                InstrumentPanel(borderColor = colors.cyanMuted) {
                    val headingDeg = telemetry.deviceHeadingDeg
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "HDG STRIP",
                            style = MaterialTheme.typography.labelSmall,
                            color = colors.textSecondary
                        )
                        Text(
                            text = if (headingDeg != null) {
                                "${GeoMath.formatBearing(headingDeg.toDouble())} (DEV ROTATION)"
                            } else {
                                "---° (ORIENTATION UNAVAILABLE)"
                            },
                            style = MaterialTheme.typography.labelLarge,
                            color = if (headingDeg != null) colors.phosphor else colors.amber
                        )
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    HeadingTapeCanvas(
                        headingDeg = headingDeg ?: 0f,
                        hasValidHeading = headingDeg != null,
                        targetBearingDeg = selectedTrack?.bearingFromOriginDeg?.toFloat(),
                        modifier = Modifier.fillMaxWidth().height(36.dp)
                    )
                }
            }

            // Central HUD Bearing Reticle & Selected Track Readout
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                contentAlignment = Alignment.Center
            ) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val cx = size.width / 2f
                    val cy = size.height / 2f
                    val arm = 36f
                    val gap = 14f
                    val retColor = colors.phosphor
                    // Crosshair reticle
                    drawLine(retColor, Offset(cx - arm, cy), Offset(cx - gap, cy), 2f)
                    drawLine(retColor, Offset(cx + gap, cy), Offset(cx + arm, cy), 2f)
                    drawLine(retColor, Offset(cx, cy - arm), Offset(cx, cy - gap), 2f)
                    drawLine(retColor, Offset(cx, cy + gap), Offset(cx, cy + arm), 2f)
                    drawCircle(retColor.copy(alpha = 0.5f), radius = 64f, center = Offset(cx, cy), style = androidx.compose.ui.graphics.drawscope.Stroke(1.2f))

                    // Pitch ladder ticks if device pitch available
                    val pitchOffset = ((telemetry.devicePitchDeg ?: 0f) * 1.5f).coerceIn(-60f, 60f)
                    drawLine(colors.cyan.copy(alpha = 0.6f), Offset(cx - 50f, cy + pitchOffset), Offset(cx - 22f, cy + pitchOffset), 1.5f)
                    drawLine(colors.cyan.copy(alpha = 0.6f), Offset(cx + 22f, cy + pitchOffset), Offset(cx + 50f, cy + pitchOffset), 1.5f)
                }

                // Selected Track Callout Box
                InstrumentPanel(
                    borderColor = colors.phosphor,
                    modifier = Modifier.align(Alignment.CenterEnd).padding(end = 8.dp)
                ) {
                    if (selectedTrack != null) {
                        val t = selectedTrack.track
                        Text(
                            text = "${t.trackId} • ${t.reportedIdentity ?: "UNLABELED"}",
                            style = MaterialTheme.typography.titleSmall,
                            color = colors.cyan
                        )
                        KeyValueReadout("Bearing", GeoMath.formatBearing(selectedTrack.bearingFromOriginDeg))
                        KeyValueReadout("Range", GeoMath.formatDistance(selectedTrack.rangeFromOriginMeters, settings.distanceUnit))
                        KeyValueReadout(
                            "Obs Age",
                            GeoMath.formatAge(selectedTrack.observationAgeMs),
                            valueColor = if (selectedTrack.observationAgeMs >= settings.staleThresholdSec * 1000L) colors.amber else colors.phosphor
                        )
                        KeyValueReadout("Quality", selectedTrack.positionQuality.badge)
                    } else {
                        Text("NO TRACK SELECTED", style = MaterialTheme.typography.labelMedium, color = colors.textSecondary)
                    }
                }
            }

            // Bottom Independent Sensor Status + Connection Health + Compact Alert Strip
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (activeAlerts.isNotEmpty()) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(colors.criticalBg, RoundedCornerShape(4.dp))
                            .border(1.dp, colors.critical, RoundedCornerShape(4.dp))
                            .padding(horizontal = 10.dp, vertical = 6.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "ALERT [${activeAlerts.size}]: ${activeAlerts.first().title}",
                            style = MaterialTheme.typography.labelMedium,
                            color = colors.critical,
                            fontWeight = FontWeight.Bold
                        )
                        StatusPill(activeAlerts.first().severity.label, colors.critical)
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // Independent GNSS Source Panel
                    InstrumentPanel(modifier = Modifier.weight(1f)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("GNSS POSITION", style = MaterialTheme.typography.labelSmall, color = colors.cyan)
                            StatusPill(
                                telemetry.gnssAvailability.label,
                                if (telemetry.gnssAvailability == SensorAvailability.AVAILABLE) colors.phosphor else colors.amber
                            )
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        val posText = telemetry.gnssPosition?.let {
                            GeoMath.formatCoordinate(it, settings.coordinateFormat)
                        } ?: "USING SCENARIO ORIGIN"
                        KeyValueReadout("Fix", posText)
                        KeyValueReadout(
                            "Accuracy",
                            telemetry.gnssAccuracyMeters?.let { "±${it.roundToInt()} m (${telemetry.gnssProvider})" } ?: "UNAVAILABLE"
                        )
                        if (telemetry.gnssAvailability == SensorAvailability.PERMISSION_REQUIRED) {
                            Spacer(modifier = Modifier.height(4.dp))
                            Button(
                                onClick = {
                                    locationPermissionLauncher.launch(
                                        arrayOf(
                                            Manifest.permission.ACCESS_COARSE_LOCATION,
                                            Manifest.permission.ACCESS_FINE_LOCATION
                                        )
                                    )
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = colors.cyan, contentColor = colors.scopeBackground),
                                modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp)
                            ) {
                                Icon(Icons.Default.GpsFixed, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Enable GNSS")
                            }
                        }
                    }

                    // Independent Orientation & Link Health Panel
                    InstrumentPanel(modifier = Modifier.weight(1f)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("ORIENTATION & LINK", style = MaterialTheme.typography.labelSmall, color = colors.cyan)
                            StatusPill(
                                telemetry.orientationAvailability.label,
                                if (telemetry.orientationAvailability == SensorAvailability.AVAILABLE) colors.phosphor else colors.amber
                            )
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        KeyValueReadout(
                            "Attitude",
                            if (telemetry.devicePitchDeg != null && telemetry.deviceRollDeg != null) {
                                String.format(Locale.US, "P %.0f° / R %.0f° (%s)", telemetry.devicePitchDeg, telemetry.deviceRollDeg, telemetry.orientationAccuracyLabel)
                            } else {
                                "UNAVAILABLE"
                            }
                        )
                        KeyValueReadout(
                            "Source Health",
                            "$connectedSources / ${state.sources.size} Connected",
                            valueColor = if (connectedSources > 0) colors.phosphor else colors.critical
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun HeadingTapeCanvas(
    headingDeg: Float,
    hasValidHeading: Boolean,
    targetBearingDeg: Float?,
    modifier: Modifier = Modifier
) {
    val colors = LocalAureomColors.current
    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height
        val cx = w / 2f
        val pxPerDeg = w / 90f

        drawLine(colors.panelBorder, Offset(0f, h - 2f), Offset(w, h - 2f), 1.5f)
        // Center lubber line
        drawLine(colors.cyan, Offset(cx, 0f), Offset(cx, h), 2.5f)

        val baseHdg = if (hasValidHeading) headingDeg else 0f
        for (offsetDeg in -45..45 step 5) {
            val tickDeg = GeoMath.normalizeBearingDeg((baseHdg + offsetDeg).toDouble())
            val x = cx + offsetDeg * pxPerDeg
            val isMajor = tickDeg.roundToInt() % 15 == 0
            drawLine(
                color = if (isMajor) colors.phosphor else colors.textDim,
                start = Offset(x, h - (if (isMajor) 16f else 9f)),
                end = Offset(x, h - 2f),
                strokeWidth = if (isMajor) 2f else 1f
            )
        }

        if (targetBearingDeg != null) {
            val delta = GeoMath.shortestAngularDeltaDeg(baseHdg.toDouble(), targetBearingDeg.toDouble()).toFloat()
            val tx = (cx + delta * pxPerDeg).coerceIn(8f, w - 8f)
            drawCircle(colors.amber, radius = 5f, center = Offset(tx, 10f))
        }
    }
}

@Composable
private fun ExperimentalCameraBackdrop(modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    AndroidView(
        factory = { ctx ->
            val previewView = PreviewView(ctx)
            val cameraProviderFuture = ProcessCameraProvider.getInstance(ctx)
            cameraProviderFuture.addListener({
                runCatching {
                    val cameraProvider = cameraProviderFuture.get()
                    val preview = Preview.Builder().build().also {
                        it.surfaceProvider = previewView.surfaceProvider
                    }
                    cameraProvider.unbindAll()
                    cameraProvider.bindToLifecycle(
                        lifecycleOwner,
                        CameraSelector.DEFAULT_BACK_CAMERA,
                        preview
                    )
                }
            }, ContextCompat.getMainExecutor(context))
            previewView
        },
        modifier = modifier
    )
}
