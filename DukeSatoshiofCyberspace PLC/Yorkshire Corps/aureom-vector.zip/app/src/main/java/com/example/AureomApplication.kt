package com.example

import android.app.Application
import com.example.data.local.AureomDatabase
import com.example.data.local.LocalRecordingRepository
import com.example.data.local.SettingsDataStore
import com.example.data.sources.DeviceTelemetryProvider
import com.example.data.sources.KtorWebSocketSourceAdapter

class AureomApplication : Application() {
    val database: AureomDatabase by lazy { AureomDatabase.getInstance(this) }
    val repository: LocalRecordingRepository by lazy { LocalRecordingRepository(database) }
    val settingsStore: SettingsDataStore by lazy { SettingsDataStore(this) }
    val deviceTelemetry: DeviceTelemetryProvider by lazy { DeviceTelemetryProvider(this) }
    val webSocketAdapter: KtorWebSocketSourceAdapter by lazy { KtorWebSocketSourceAdapter() }
}
