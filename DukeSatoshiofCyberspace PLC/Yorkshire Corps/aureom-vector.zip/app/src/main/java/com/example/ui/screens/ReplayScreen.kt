package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Radar
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.domain.geo.GeoMath
import com.example.domain.model.OperatingMode
import com.example.domain.model.ReplaySessionSummary
import com.example.ui.RadarScreenState
import com.example.ui.components.InstrumentPanel
import com.example.ui.components.InstrumentSectionHeader
import com.example.ui.components.KeyValueReadout
import com.example.ui.components.StatusPill
import com.example.ui.theme.LocalAureomColors
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

@Composable
fun ReplayScreen(
    state: RadarScreenState,
    sessions: List<ReplaySessionSummary>,
    onStartReplay: (ReplaySessionSummary) -> Unit,
    onTogglePlayPause: () -> Unit,
    onSetSpeed: (Float) -> Unit,
    onSeek: (Long) -> Unit,
    onExitReplay: () -> Unit,
    onDeleteSession: (String) -> Unit,
    onOpenRadar: () -> Unit,
    onExportReport: () -> Unit,
    modifier: Modifier = Modifier
) {
    val colors = LocalAureomColors.current
    val utcFmt = remember {
        SimpleDateFormat("yyyy-MM-dd HH:mm:ss'Z'", Locale.US).apply {
            timeZone = TimeZone.getTimeZone("UTC")
        }
    }
    val pb = state.replayPlayback

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(colors.scopeBackground)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Active Replay Deck
        InstrumentPanel(borderColor = if (state.operatingMode == OperatingMode.REPLAY) colors.amber else colors.panelBorder) {
            InstrumentSectionHeader(
                title = "Deterministic Replay Deck",
                trailing = if (state.operatingMode == OperatingMode.REPLAY) "ISOLATED FROM LIVE" else "STANDBY"
            )
            Spacer(modifier = Modifier.height(8.dp))

            if (pb.activeSession != null && state.operatingMode == OperatingMode.REPLAY) {
                Text(
                    text = pb.activeSession.title,
                    style = MaterialTheme.typography.titleMedium,
                    color = colors.amber
                )
                Spacer(modifier = Modifier.height(4.dp))
                KeyValueReadout(
                    "Replay Time / Total",
                    "${GeoMath.formatAge(pb.currentOffsetMs)} / ${GeoMath.formatAge(pb.totalDurationMs)}"
                )
                KeyValueReadout("Seed", pb.activeSession.seed.toString())

                Slider(
                    value = pb.currentOffsetMs.toFloat(),
                    onValueChange = { onSeek(it.toLong()) },
                    valueRange = 0f..(pb.totalDurationMs.toFloat().coerceAtLeast(1000f)),
                    modifier = Modifier.fillMaxWidth().testTag("replay_seek_slider")
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Button(
                        onClick = onTogglePlayPause,
                        colors = ButtonDefaults.buttonColors(containerColor = colors.amber, contentColor = colors.scopeBackground),
                        modifier = Modifier.heightIn(min = 48.dp).testTag("replay_play_pause_button")
                    ) {
                        Icon(
                            if (pb.isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                            contentDescription = null
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(if (pb.isPlaying) "Pause" else "Resume")
                    }

                    listOf(0.5f, 1f, 2f, 4f).forEach { spd ->
                        FilterChip(
                            selected = pb.speedMultiplier == spd,
                            onClick = { onSetSpeed(spd) },
                            label = { Text("${spd}x", style = MaterialTheme.typography.labelSmall) },
                            modifier = Modifier.heightIn(min = 48.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = onOpenRadar,
                        colors = ButtonDefaults.buttonColors(containerColor = colors.phosphor, contentColor = colors.scopeBackground),
                        modifier = Modifier.weight(1f).heightIn(min = 48.dp).testTag("replay_open_radar_button")
                    ) {
                        Icon(Icons.Default.Radar, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("View on Radar")
                    }
                    OutlinedButton(
                        onClick = onExportReport,
                        modifier = Modifier.weight(1f).heightIn(min = 48.dp).testTag("replay_export_report_button")
                    ) {
                        Icon(Icons.Default.Download, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Export Report")
                    }
                    OutlinedButton(
                        onClick = onExitReplay,
                        border = BorderStroke(1.dp, colors.critical),
                        modifier = Modifier.heightIn(min = 48.dp)
                    ) {
                        Icon(Icons.Default.Stop, contentDescription = "Exit Replay", tint = colors.critical)
                    }
                }
            } else {
                Text(
                    text = "Select a recorded session below to replay exact recorded observations, timestamps, outages, and zone transitions deterministically.",
                    style = MaterialTheme.typography.bodySmall,
                    color = colors.textSecondary
                )
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedButton(
                    onClick = onExportReport,
                    modifier = Modifier.heightIn(min = 48.dp).testTag("export_current_report_button")
                ) {
                    Icon(Icons.Default.Download, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Export Current Picture Report")
                }
            }
        }

        InstrumentSectionHeader(
            title = "Recorded Sessions (Room DB)",
            trailing = "${sessions.size} stored"
        )

        LazyColumn(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(sessions, key = { it.sessionId }) { session ->
                val isActive = pb.activeSession?.sessionId == session.sessionId && state.operatingMode == OperatingMode.REPLAY
                InstrumentPanel(
                    borderColor = if (isActive) colors.amber else colors.panelBorder
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = session.title,
                                style = MaterialTheme.typography.titleMedium,
                                color = colors.textPrimary,
                                fontWeight = FontWeight.SemiBold
                            )
                            Text(
                                text = "${session.scenarioId.title} • ${utcFmt.format(Date(session.startedAtMs))}",
                                style = MaterialTheme.typography.bodySmall,
                                color = colors.textSecondary
                            )
                        }
                        if (session.isBuiltInDemo) {
                            StatusPill("BASELINE DEMO", colors.cyan)
                        }
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    KeyValueReadout(
                        "Recorded Events",
                        "${session.observationCount} obs • Seed ${session.seed}"
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Button(
                            onClick = { onStartReplay(session) },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = colors.amber,
                                contentColor = colors.scopeBackground
                            ),
                            modifier = Modifier.weight(1f).heightIn(min = 48.dp).testTag("play_session_${session.sessionId}")
                        ) {
                            Icon(Icons.Default.PlayArrow, contentDescription = null)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(if (isActive) "Restart Replay" else "Load & Replay")
                        }
                        if (!session.isBuiltInDemo) {
                            IconButton(
                                onClick = { onDeleteSession(session.sessionId) },
                                modifier = Modifier.size(48.dp)
                            ) {
                                Icon(Icons.Default.Delete, contentDescription = "Delete session", tint = colors.critical)
                            }
                        }
                    }
                }
            }
        }
    }
}
