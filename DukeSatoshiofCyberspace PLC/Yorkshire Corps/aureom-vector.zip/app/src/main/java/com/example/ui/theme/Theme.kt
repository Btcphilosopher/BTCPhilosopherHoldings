package com.example.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

@Immutable
data class AureomInstrumentColors(
    val isNightMode: Boolean,
    val scopeBackground: Color,
    val panelSurface: Color,
    val elevatedSurface: Color,
    val panelBorder: Color,
    val phosphor: Color,
    val phosphorGrid: Color,
    val phosphorGlow: Color,
    val cyan: Color,
    val cyanMuted: Color,
    val amber: Color,
    val amberBg: Color,
    val critical: Color,
    val criticalBg: Color,
    val textPrimary: Color,
    val textSecondary: Color,
    val textDim: Color
)

val NightInstrumentColors = AureomInstrumentColors(
    isNightMode = true,
    scopeBackground = GraphiteBg,
    panelSurface = DeepNavySurface,
    elevatedSurface = PanelSurface,
    panelBorder = HairlineBorder,
    phosphor = PhosphorGreen,
    phosphorGrid = PhosphorGrid,
    phosphorGlow = PhosphorGlow,
    cyan = InstrumentCyan,
    cyanMuted = InstrumentCyanMuted,
    amber = AmberCaution,
    amberBg = AmberCautionBg,
    critical = CriticalRed,
    criticalBg = CriticalRedBg,
    textPrimary = OffWhiteText,
    textSecondary = SlateText,
    textDim = DimSlateText
)

val DayInstrumentColors = AureomInstrumentColors(
    isNightMode = false,
    scopeBackground = DayBg,
    panelSurface = DaySurface,
    elevatedSurface = DayPanel,
    panelBorder = DayBorder,
    phosphor = DayPhosphor,
    phosphorGrid = DayPhosphorGrid,
    phosphorGlow = Color(0x220D7A42),
    cyan = DayCyan,
    cyanMuted = Color(0xFFB5D8E2),
    amber = DayAmber,
    amberBg = Color(0x22B86B00),
    critical = DayRed,
    criticalBg = Color(0x22C9242B),
    textPrimary = DayNavyText,
    textSecondary = DaySlateText,
    textDim = Color(0xFF6B7D90)
)

val LocalAureomColors = staticCompositionLocalOf { NightInstrumentColors }

private val NightColorScheme = darkColorScheme(
    primary = PhosphorGreen,
    onPrimary = GraphiteBg,
    primaryContainer = PhosphorGrid,
    onPrimaryContainer = OffWhiteText,
    secondary = InstrumentCyan,
    onSecondary = GraphiteBg,
    secondaryContainer = InstrumentCyanMuted,
    onSecondaryContainer = OffWhiteText,
    tertiary = AmberCaution,
    onTertiary = GraphiteBg,
    background = GraphiteBg,
    onBackground = OffWhiteText,
    surface = DeepNavySurface,
    onSurface = OffWhiteText,
    surfaceVariant = PanelSurface,
    onSurfaceVariant = SlateText,
    outline = HairlineBorder,
    error = CriticalRed,
    onError = GraphiteBg
)

private val DayColorScheme = lightColorScheme(
    primary = DayPhosphor,
    onPrimary = DayPanel,
    primaryContainer = DayPhosphorGrid,
    onPrimaryContainer = DayNavyText,
    secondary = DayCyan,
    onSecondary = DayPanel,
    secondaryContainer = DayElevated,
    onSecondaryContainer = DayNavyText,
    tertiary = DayAmber,
    onTertiary = DayPanel,
    background = DayBg,
    onBackground = DayNavyText,
    surface = DaySurface,
    onSurface = DayNavyText,
    surfaceVariant = DayPanel,
    onSurfaceVariant = DaySlateText,
    outline = DayBorder,
    error = DayRed,
    onError = DayPanel
)

val AureomShapes = Shapes(
    extraSmall = RoundedCornerShape(2.dp),
    small = RoundedCornerShape(4.dp),
    medium = RoundedCornerShape(6.dp),
    large = RoundedCornerShape(8.dp),
    extraLarge = RoundedCornerShape(12.dp)
)

@Composable
fun AureomTheme(
    nightMode: Boolean = true,
    textScale: Float = 1.0f,
    content: @Composable () -> Unit
) {
    val instrumentColors = if (nightMode) NightInstrumentColors else DayInstrumentColors
    val colorScheme = if (nightMode) NightColorScheme else DayColorScheme
    val typography = buildAureomTypography(textScale)

    CompositionLocalProvider(LocalAureomColors provides instrumentColors) {
        MaterialTheme(
            colorScheme = colorScheme,
            typography = typography,
            shapes = AureomShapes,
            content = content
        )
    }
}
