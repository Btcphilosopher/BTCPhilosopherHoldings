package com.example.domain.geo

import com.example.domain.model.CoordinateFormat
import com.example.domain.model.DistanceUnit
import com.example.domain.model.GeoPoint
import com.example.domain.model.MonitoredZone
import com.example.domain.model.ZoneShape
import java.util.Locale
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

data class EnuPoint(val eastMeters: Double, val northMeters: Double)

object GeoMath {
    private const val EARTH_RADIUS_METERS = 6_371_000.0
    const val METERS_PER_NM = 1_852.0
    const val MPS_TO_KNOTS = 1.9438444924406

    fun isValidCoordinate(latDeg: Double, lonDeg: Double): Boolean {
        return latDeg.isFinite() &&
            lonDeg.isFinite() &&
            latDeg in -90.0..90.0 &&
            lonDeg in -180.0..180.0
    }

    fun normalizeBearingDeg(bearingDeg: Double): Double {
        if (!bearingDeg.isFinite()) return 0.0
        val mod = bearingDeg % 360.0
        return if (mod < 0.0) mod + 360.0 else mod
    }

    /**
     * Signed shortest angular difference from [fromDeg] to [toDeg] in [-180, +180).
     */
    fun shortestAngularDeltaDeg(fromDeg: Double, toDeg: Double): Double {
        val diff = (normalizeBearingDeg(toDeg) - normalizeBearingDeg(fromDeg) + 540.0) % 360.0 - 180.0
        return diff
    }

    fun toEnu(point: GeoPoint, origin: GeoPoint): EnuPoint {
        val lat0Rad = Math.toRadians(origin.latDeg)
        val dLat = Math.toRadians(point.latDeg - origin.latDeg)
        val dLon = Math.toRadians(point.lonDeg - origin.lonDeg)
        val north = dLat * EARTH_RADIUS_METERS
        val east = dLon * EARTH_RADIUS_METERS * cos(lat0Rad)
        return EnuPoint(eastMeters = east, northMeters = north)
    }

    fun fromEnu(enu: EnuPoint, origin: GeoPoint): GeoPoint {
        val lat0Rad = Math.toRadians(origin.latDeg)
        val cosLat = max(1e-6, cos(lat0Rad))
        val lat = origin.latDeg + Math.toDegrees(enu.northMeters / EARTH_RADIUS_METERS)
        val lon = origin.lonDeg + Math.toDegrees(enu.eastMeters / (EARTH_RADIUS_METERS * cosLat))
        return GeoPoint(
            latDeg = lat.coerceIn(-90.0, 90.0),
            lonDeg = normalizeLon(lon)
        )
    }

    private fun normalizeLon(lonDeg: Double): Double {
        var lon = lonDeg
        while (lon > 180.0) lon -= 360.0
        while (lon < -180.0) lon += 360.0
        return lon
    }

    fun haversineDistanceMeters(a: GeoPoint, b: GeoPoint): Double {
        val lat1 = Math.toRadians(a.latDeg)
        val lat2 = Math.toRadians(b.latDeg)
        val dLat = lat2 - lat1
        val dLon = Math.toRadians(b.lonDeg - a.lonDeg)
        val sinLat = sin(dLat / 2.0)
        val sinLon = sin(dLon / 2.0)
        val h = sinLat * sinLat + cos(lat1) * cos(lat2) * sinLon * sinLon
        val c = 2.0 * atan2(sqrt(h), sqrt(max(0.0, 1.0 - h)))
        return EARTH_RADIUS_METERS * c
    }

    fun bearingDeg(from: GeoPoint, to: GeoPoint): Double {
        val lat1 = Math.toRadians(from.latDeg)
        val lat2 = Math.toRadians(to.latDeg)
        val dLon = Math.toRadians(to.lonDeg - from.lonDeg)
        val y = sin(dLon) * cos(lat2)
        val x = cos(lat1) * sin(lat2) - sin(lat1) * cos(lat2) * cos(dLon)
        return normalizeBearingDeg(Math.toDegrees(atan2(y, x)))
    }

    fun destinationPoint(start: GeoPoint, bearingDeg: Double, distanceMeters: Double): GeoPoint {
        val angDist = distanceMeters / EARTH_RADIUS_METERS
        val brng = Math.toRadians(normalizeBearingDeg(bearingDeg))
        val lat1 = Math.toRadians(start.latDeg)
        val lon1 = Math.toRadians(start.lonDeg)

        val lat2 = kotlin.math.asin(
            sin(lat1) * cos(angDist) + cos(lat1) * sin(angDist) * cos(brng)
        )
        val lon2 = lon1 + atan2(
            sin(brng) * sin(angDist) * cos(lat1),
            cos(angDist) - sin(lat1) * sin(lat2)
        )
        return GeoPoint(
            latDeg = Math.toDegrees(lat2).coerceIn(-90.0, 90.0),
            lonDeg = normalizeLon(Math.toDegrees(lon2))
        )
    }

    /**
     * Signed distance from [point] to [zone] boundary in meters.
     * Negative means inside the zone; positive means outside the zone.
     */
    fun signedDistanceToZoneMeters(point: GeoPoint, zone: MonitoredZone): Double {
        return when (zone.shape) {
            ZoneShape.CIRCLE -> {
                haversineDistanceMeters(point, zone.center) - zone.radiusMeters
            }
            ZoneShape.POLYGON -> {
                if (zone.polygonVertices.size < 3) {
                    haversineDistanceMeters(point, zone.center) - zone.radiusMeters
                } else {
                    val p = toEnu(point, zone.center)
                    val verts = zone.polygonVertices.map { toEnu(it, zone.center) }
                    val inside = isPointInPolygonEnu(p, verts)
                    val minDist = minDistanceToPolygonEdges(p, verts)
                    if (inside) -minDist else minDist
                }
            }
        }
    }

    private fun isPointInPolygonEnu(p: EnuPoint, verts: List<EnuPoint>): Boolean {
        var inside = false
        var j = verts.lastIndex
        for (i in verts.indices) {
            val xi = verts[i].eastMeters
            val yi = verts[i].northMeters
            val xj = verts[j].eastMeters
            val yj = verts[j].northMeters
            val intersect = ((yi > p.northMeters) != (yj > p.northMeters)) &&
                (p.eastMeters < (xj - xi) * (p.northMeters - yi) / ((yj - yi) + 1e-12) + xi)
            if (intersect) inside = !inside
            j = i
        }
        return inside
    }

    private fun minDistanceToPolygonEdges(p: EnuPoint, verts: List<EnuPoint>): Double {
        var minDist = Double.MAX_VALUE
        for (i in verts.indices) {
            val a = verts[i]
            val b = verts[(i + 1) % verts.size]
            val d = pointToSegmentDistance(p, a, b)
            if (d < minDist) minDist = d
        }
        return minDist
    }

    private fun pointToSegmentDistance(p: EnuPoint, a: EnuPoint, b: EnuPoint): Double {
        val dx = b.eastMeters - a.eastMeters
        val dy = b.northMeters - a.northMeters
        val lenSq = dx * dx + dy * dy
        if (lenSq < 1e-9) return hypot(p.eastMeters - a.eastMeters, p.northMeters - a.northMeters)
        val t = (((p.eastMeters - a.eastMeters) * dx + (p.northMeters - a.northMeters) * dy) / lenSq)
            .coerceIn(0.0, 1.0)
        val projX = a.eastMeters + t * dx
        val projY = a.northMeters + t * dy
        return hypot(p.eastMeters - projX, p.northMeters - projY)
    }

    fun formatCoordinate(point: GeoPoint, format: CoordinateFormat): String {
        return when (format) {
            CoordinateFormat.DECIMAL_DEGREES -> {
                val latHem = if (point.latDeg >= 0) "N" else "S"
                val lonHem = if (point.lonDeg >= 0) "E" else "W"
                String.format(
                    Locale.US,
                    "%.4f° %s  %.4f° %s",
                    abs(point.latDeg),
                    latHem,
                    abs(point.lonDeg),
                    lonHem
                )
            }
            CoordinateFormat.DEGREES_MINUTES -> {
                formatDm(point.latDeg, "N", "S") + "  " + formatDm(point.lonDeg, "E", "W")
            }
            CoordinateFormat.LOCAL_GRID_REF -> {
                val zoneBand = ((point.lonDeg + 180.0) / 6.0).toInt() + 1
                val eKm = ((point.lonDeg + 180.0) * 111.32) % 100.0
                val nKm = ((point.latDeg + 90.0) * 110.57) % 100.0
                String.format(Locale.US, "GR %02dU %04.1f %04.1f", zoneBand, eKm, nKm)
            }
        }
    }

    private fun formatDm(deg: Double, pos: String, neg: String): String {
        val hem = if (deg >= 0) pos else neg
        val absVal = abs(deg)
        val whole = absVal.toInt()
        val mins = (absVal - whole) * 60.0
        return String.format(Locale.US, "%02d° %06.3f' %s", whole, mins, hem)
    }

    fun formatDistance(meters: Double, unit: DistanceUnit): String {
        return when (unit) {
            DistanceUnit.NAUTICAL -> String.format(Locale.US, "%.2f NM", meters / METERS_PER_NM)
            DistanceUnit.METRIC_KM -> String.format(Locale.US, "%.2f km", meters / 1000.0)
            DistanceUnit.METRIC_M -> String.format(Locale.US, "%.0f m", meters)
        }
    }

    fun formatSpeed(mps: Double?, unit: DistanceUnit): String {
        if (mps == null || !mps.isFinite()) return "UNAVAIL"
        return when (unit) {
            DistanceUnit.NAUTICAL -> String.format(Locale.US, "%.1f kt", mps * MPS_TO_KNOTS)
            DistanceUnit.METRIC_KM -> String.format(Locale.US, "%.1f km/h", mps * 3.6)
            DistanceUnit.METRIC_M -> String.format(Locale.US, "%.1f m/s", mps)
        }
    }

    fun formatBearing(deg: Double?): String {
        if (deg == null || !deg.isFinite()) return "---°"
        return String.format(Locale.US, "%05.1f°", normalizeBearingDeg(deg))
    }

    fun formatAge(ageMs: Long): String {
        if (ageMs < 0) return "0.0s"
        val sec = ageMs / 1000.0
        return if (sec < 60.0) {
            String.format(Locale.US, "%.1fs", sec)
        } else {
            val m = (sec / 60).toInt()
            val s = sec % 60
            String.format(Locale.US, "%dm %02.0fs", m, s)
        }
    }
}
