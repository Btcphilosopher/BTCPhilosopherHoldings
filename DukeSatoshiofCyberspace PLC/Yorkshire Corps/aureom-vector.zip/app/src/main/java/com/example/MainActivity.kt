package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.HealthAndSafety
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.Radar
import androidx.compose.material.icons.filled.Sensors
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.NavigationRailItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.domain.model.AlertResolutionState
import com.example.domain.model.RadarOrientationMode
import com.example.ui.RadarViewModel
import com.example.ui.components.AureomTopStatusBar
import com.example.ui.components.ReportExportDialog
import com.example.ui.screens.AlertsScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.HudScreen
import com.example.ui.screens.RadarScreen
import com.example.ui.screens.ReplayScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.screens.SourcesScreen
import com.example.ui.screens.SystemHealthScreen
import com.example.ui.theme.AureomTheme
import com.example.ui.theme.LocalAureomColors

const val ROUTE_HOME = "home"
const val ROUTE_RADAR = "radar"
const val ROUTE_HUD = "hud"
const val ROUTE_REPLAY = "replay"
const val ROUTE_SOURCES = "sources"
const val ROUTE_ALERTS = "alerts"
const val ROUTE_HEALTH = "health"
const val ROUTE_SETTINGS = "settings"

private data class NavDestinationItem(
    val route: String,
    val label: String,
    val icon: ImageVector
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val viewModel: RadarViewModel = viewModel()
            val settings by viewModel.settings.collectAsStateWithLifecycle()

            AureomTheme(
                nightMode = settings.nightMode,
                textScale = settings.textScale
            ) {
                AureomRootApp(viewModel = viewModel)
            }
        }
    }
}

@Composable
fun AureomRootApp(viewModel: RadarViewModel) {
    val colors = LocalAureomColors.current
    val navController = rememberNavController()
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    val settings by viewModel.settings.collectAsStateWithLifecycle()
    val telemetry by viewModel.telemetry.collectAsStateWithLifecycle()
    val replaySessions by viewModel.replaySessions.collectAsStateWithLifecycle()
    val snackbarHostState = remember { SnackbarHostState() }

    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route ?: ROUTE_HOME

    LaunchedEffect(state.statusBannerMessage) {
        val msg = state.statusBannerMessage
        if (msg != null) {
            snackbarHostState.showSnackbar(msg)
            viewModel.clearStatusBanner()
        }
    }

    val activeAlertsCount = state.alerts.count { it.resolutionState == AlertResolutionState.ACTIVE }
    val isOutage = state.simulatorConfig.sensorOutageActive || state.sources.any { it.outageActive }

    val primaryNavItems = remember {
        listOf(
            NavDestinationItem(ROUTE_HOME, "Command", Icons.Default.Home),
            NavDestinationItem(ROUTE_RADAR, "Radar", Icons.Default.Radar),
            NavDestinationItem(ROUTE_REPLAY, "Replay", Icons.Default.History),
            NavDestinationItem(ROUTE_SOURCES, "Sources", Icons.Default.Sensors),
            NavDestinationItem(ROUTE_ALERTS, "Alerts", Icons.Default.NotificationsActive),
            NavDestinationItem(ROUTE_HEALTH, "Health", Icons.Default.HealthAndSafety),
            NavDestinationItem(ROUTE_SETTINGS, "Settings", Icons.Default.Settings)
        )
    }

    fun navigateSingleTop(route: String) {
        navController.navigate(route) {
            popUpTo(ROUTE_HOME) { saveState = true }
            launchSingleTop = true
            restoreState = true
        }
    }

    BoxWithConstraints(
        modifier = Modifier
            .fillMaxSize()
            .background(colors.scopeBackground)
    ) {
        val useNavRail = maxWidth >= 720.dp
        val isHudFullscreen = currentRoute == ROUTE_HUD

        Scaffold(
            modifier = Modifier.fillMaxSize(),
            containerColor = colors.scopeBackground,
            contentWindowInsets = WindowInsets.safeDrawing,
            snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
            topBar = {
                if (!isHudFullscreen) {
                    AureomTopStatusBar(
                        operatingMode = state.operatingMode,
                        areaName = state.observationArea.name,
                        utcClockText = state.utcClockText,
                        activeAlertCount = activeAlertsCount,
                        isRecording = state.isRecording,
                        isOutageActive = isOutage,
                        onAlertsClick = { navigateSingleTop(ROUTE_ALERTS) },
                        modifier = Modifier.statusBarsPadding()
                    )
                }
            },
            bottomBar = {
                if (!isHudFullscreen && !useNavRail) {
                    NavigationBar(
                        containerColor = colors.panelSurface,
                        contentColor = colors.textPrimary,
                        windowInsets = WindowInsets.navigationBars
                    ) {
                        // Compact bottom bar with 5 core operational destinations (Health/Settings reachable from Home)
                        val compactItems = listOf(
                            NavDestinationItem(ROUTE_HOME, "Home", Icons.Default.Home),
                            NavDestinationItem(ROUTE_RADAR, "Radar", Icons.Default.Radar),
                            NavDestinationItem(ROUTE_REPLAY, "Replay", Icons.Default.History),
                            NavDestinationItem(ROUTE_SOURCES, "Sources", Icons.Default.Sensors),
                            NavDestinationItem(ROUTE_ALERTS, "Alerts", Icons.Default.NotificationsActive)
                        )
                        compactItems.forEach { item ->
                            val selected = currentRoute == item.route
                            NavigationBarItem(
                                selected = selected,
                                onClick = { navigateSingleTop(item.route) },
                                icon = { Icon(item.icon, contentDescription = item.label) },
                                label = {
                                    Text(
                                        text = item.label,
                                        style = MaterialTheme.typography.labelSmall,
                                        maxLines = 1
                                    )
                                },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = colors.phosphor,
                                    selectedTextColor = colors.phosphor,
                                    unselectedIconColor = colors.textSecondary,
                                    unselectedTextColor = colors.textSecondary,
                                    indicatorColor = colors.elevatedSurface
                                ),
                                modifier = Modifier.testTag("nav_${item.route}")
                            )
                        }
                    }
                }
            }
        ) { innerPadding ->
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                if (!isHudFullscreen && useNavRail) {
                    NavigationRail(
                        containerColor = colors.panelSurface,
                        contentColor = colors.textPrimary,
                        modifier = Modifier
                            .fillMaxHeight()
                            .windowInsetsPadding(WindowInsets.navigationBars)
                    ) {
                        primaryNavItems.forEach { item ->
                            val selected = currentRoute == item.route
                            NavigationRailItem(
                                selected = selected,
                                onClick = { navigateSingleTop(item.route) },
                                icon = { Icon(item.icon, contentDescription = item.label) },
                                label = {
                                    Text(
                                        text = item.label,
                                        style = MaterialTheme.typography.labelSmall,
                                        maxLines = 1
                                    )
                                },
                                colors = NavigationRailItemDefaults.colors(
                                    selectedIconColor = colors.phosphor,
                                    selectedTextColor = colors.phosphor,
                                    unselectedIconColor = colors.textSecondary,
                                    unselectedTextColor = colors.textSecondary,
                                    indicatorColor = colors.elevatedSurface
                                ),
                                modifier = Modifier.testTag("rail_${item.route}")
                            )
                        }
                    }
                }

                Box(modifier = Modifier.weight(1f).fillMaxSize()) {
                    NavHost(
                        navController = navController,
                        startDestination = ROUTE_HOME
                    ) {
                        composable(ROUTE_HOME) {
                            HomeScreen(
                                state = state,
                                settings = settings,
                                onStartSimulation = { scenario ->
                                    viewModel.startSimulation(scenario)
                                    navigateSingleTop(ROUTE_RADAR)
                                },
                                onOpenRadar = { navigateSingleTop(ROUTE_RADAR) },
                                onOpenReplay = { navigateSingleTop(ROUTE_REPLAY) },
                                onOpenSources = { navigateSingleTop(ROUTE_SOURCES) },
                                onOpenAlerts = { navigateSingleTop(ROUTE_ALERTS) },
                                onOpenHealth = { navigateSingleTop(ROUTE_HEALTH) },
                                onOpenSettings = { navigateSingleTop(ROUTE_SETTINGS) }
                            )
                        }

                        composable(ROUTE_RADAR) {
                            RadarScreen(
                                state = state,
                                settings = settings,
                                telemetry = telemetry,
                                onSelectTrack = viewModel::selectTrack,
                                onRangeChange = viewModel::setRangeNm,
                                onToggleOrientationMode = {
                                    viewModel.updateSettings {
                                        val next = if (it.orientationMode == RadarOrientationMode.NORTH_UP) {
                                            RadarOrientationMode.HEADING_UP
                                        } else {
                                            RadarOrientationMode.NORTH_UP
                                        }
                                        it.copy(orientationMode = next)
                                    }
                                },
                                onToggleMapOverlay = {
                                    viewModel.updateSettings { it.copy(showMapOverlay = !it.showMapOverlay) }
                                },
                                onCycleTrailLength = {
                                    viewModel.updateSettings {
                                        val next = when (it.trailLength) {
                                            0 -> 10
                                            10 -> 30
                                            30 -> 60
                                            else -> 0
                                        }
                                        it.copy(trailLength = next)
                                    }
                                },
                                onToggleRecording = viewModel::toggleRecording,
                                onToggleOutage = viewModel::toggleSimulatedOutage,
                                onOpenHud = { navController.navigate(ROUTE_HUD) },
                                onCreateZone = viewModel::createMonitoredZone,
                                onSaveAnnotation = viewModel::saveTrackAnnotation,
                                onUpdateSettings = viewModel::updateSettings,
                                onToggleReplayPause = viewModel::toggleReplayPlayPause,
                                onFrameDurationMs = viewModel::recordFrameDurationMs
                            )
                        }

                        composable(ROUTE_HUD) {
                            HudScreen(
                                state = state,
                                settings = settings,
                                telemetry = telemetry,
                                onRequestLocationPermissionResult = viewModel::onLocationPermissionResult,
                                onExitHud = { navController.popBackStack() }
                            )
                        }

                        composable(ROUTE_REPLAY) {
                            ReplayScreen(
                                state = state,
                                sessions = replaySessions,
                                onStartReplay = { session ->
                                    viewModel.startReplaySession(session)
                                },
                                onTogglePlayPause = viewModel::toggleReplayPlayPause,
                                onSetSpeed = viewModel::setReplaySpeed,
                                onSeek = viewModel::seekReplay,
                                onExitReplay = viewModel::exitReplayToSimulation,
                                onDeleteSession = viewModel::deleteReplaySession,
                                onOpenRadar = { navigateSingleTop(ROUTE_RADAR) },
                                onExportReport = viewModel::generateAndShowReport
                            )
                        }

                        composable(ROUTE_SOURCES) {
                            SourcesScreen(
                                state = state,
                                settings = settings,
                                telemetry = telemetry,
                                onUpdateSimConfig = viewModel::updateSimulatorConfig,
                                onToggleOutage = viewModel::toggleSimulatedOutage,
                                onConnectBackend = viewModel::connectRemoteBackend,
                                onDisconnectBackend = viewModel::disconnectRemoteBackend
                            )
                        }

                        composable(ROUTE_ALERTS) {
                            AlertsScreen(
                                alerts = state.alerts,
                                zones = state.zones,
                                onAcknowledge = viewModel::acknowledgeAlert,
                                onResolve = viewModel::resolveAlert,
                                onUpdateNotes = viewModel::updateAlertNotes,
                                onToggleZone = viewModel::toggleZoneEnabled,
                                onExportReport = viewModel::generateAndShowReport
                            )
                        }

                        composable(ROUTE_HEALTH) {
                            SystemHealthScreen(
                                state = state,
                                telemetry = telemetry
                            )
                        }

                        composable(ROUTE_SETTINGS) {
                            SettingsScreen(
                                settings = settings,
                                onUpdateSettings = viewModel::updateSettings
                            )
                        }
                    }
                }
            }
        }

        val reportText = state.exportReportText
        if (reportText != null) {
            ReportExportDialog(
                reportText = reportText,
                onDismiss = viewModel::dismissReport
            )
        }
    }
}
