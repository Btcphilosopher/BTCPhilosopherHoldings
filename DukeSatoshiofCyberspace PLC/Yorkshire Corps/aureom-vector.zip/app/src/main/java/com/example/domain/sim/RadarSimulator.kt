package com.example.domain.sim

import com.example.domain.geo.GeoMath
import com.example.domain.model.AltitudeReference
import com.example.domain.model.GeoPoint
import com.example.domain.model.MonitoredZone
import com.example.domain.model.ObjectCategory
import com.example.domain.model.ObservationArea
import com.example.domain.model.RawSourceMessage
import com.example.domain.model.ScenarioId
import com.example.domain.model.SimulatorConfig
import com.example.domain.model.SourceType
import com.example.domain.model.ZoneShape
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

data class SimEntitySpec(
    val entityId: String,
    val initialBearingFromOriginDeg: Double,
    val initialRangeMeters: Double,
    val speedMps: Double,
    val courseDeg: Double,
    val turnRateDegPerSec: Double = 0.0,
    val altitudeMeters: Double?,
    val altitudeReference: AltitudeReference,
    val category: ObjectCategory,
    val reportedIdentity: String?,
    val reportedIdentitySource: String?,
    val sourceId: String
)

data class ScenarioBundle(
    val area: ObservationArea,
    val defaultZones: List<MonitoredZone>,
    val entities: List<SimEntitySpec>
)

object ScenarioCatalog {
    fun buildScenario(scenarioId: ScenarioId): ScenarioBundle {
        return when (scenarioId) {
            ScenarioId.NORTH_SEA_OBSERVATION -> {
                val origin = GeoPoint(55.4200, 1.8500)
                // Simplified North Sea coastline/sandbank reference contours for overlay
                val doggerContour = listOf(
                    GeoPoint(55.65, 1.35),
                    GeoPoint(55.78, 1.92),
                    GeoPoint(55.55, 2.38),
                    GeoPoint(55.28, 2.15),
                    GeoPoint(55.31, 1.48)
                )
                val zones = listOf(
                    MonitoredZone(
                        zoneId = "ZONE-BRAVO",
                        name = "Platform Bravo 5 NM Safety Zone",
                        scenarioId = ScenarioId.NORTH_SEA_OBSERVATION,
                        shape = ZoneShape.CIRCLE,
                        center = GeoMath.destinationPoint(origin, 52.0, 14_500.0),
                        radiusMeters = 9_260.0,
                        alertOnEntry = true,
                        alertOnExit = true,
                        loiterThresholdSec = 35,
                        hysteresisMeters = 250.0
                    ),
                    MonitoredZone(
                        zoneId = "ZONE-ARRAY",
                        name = "Dogger Wind Array Sector",
                        scenarioId = ScenarioId.NORTH_SEA_OBSERVATION,
                        shape = ZoneShape.POLYGON,
                        center = GeoMath.destinationPoint(origin, 235.0, 22_000.0),
                        radiusMeters = 10_000.0,
                        polygonVertices = listOf(
                            GeoMath.destinationPoint(origin, 222.0, 18_000.0),
                            GeoMath.destinationPoint(origin, 238.0, 16_000.0),
                            GeoMath.destinationPoint(origin, 250.0, 28_000.0),
                            GeoMath.destinationPoint(origin, 228.0, 31_000.0)
                        ),
                        alertOnEntry = true,
                        alertOnExit = true,
                        loiterThresholdSec = 45,
                        hysteresisMeters = 250.0
                    )
                )
                val entities = listOf(
                    // Scripted to enter Platform Bravo Safety Zone around ~15-18 seconds
                    SimEntitySpec(
                        entityId = "E-VESSEL-1",
                        initialBearingFromOriginDeg = 60.0,
                        initialRangeMeters = 24_200.0,
                        speedMps = 18.0, // Fast offshore support vessel (~35 kt for prompt demo visibility)
                        courseDeg = 225.0,
                        altitudeMeters = 0.0,
                        altitudeReference = AltitudeReference.SURFACE,
                        category = ObjectCategory.MARITIME_VESSEL,
                        reportedIdentity = "MV SHETLAND STAR",
                        reportedIdentitySource = "AIS MMSI 235009142",
                        sourceId = "SIM-MARITIME-1"
                    ),
                    SimEntitySpec(
                        entityId = "E-VESSEL-2",
                        initialBearingFromOriginDeg = 310.0,
                        initialRangeMeters = 28_000.0,
                        speedMps = 9.5,
                        courseDeg = 128.0,
                        altitudeMeters = 0.0,
                        altitudeReference = AltitudeReference.SURFACE,
                        category = ObjectCategory.MARITIME_VESSEL,
                        reportedIdentity = "SS TYNE CARRIER",
                        reportedIdentitySource = "AIS MMSI 235011480",
                        sourceId = "SIM-MARITIME-1"
                    ),
                    // Close-passing pair to demonstrate track association without false label merging
                    SimEntitySpec(
                        entityId = "E-CLOSE-A",
                        initialBearingFromOriginDeg = 165.0,
                        initialRangeMeters = 18_000.0,
                        speedMps = 14.0,
                        courseDeg = 25.0,
                        altitudeMeters = 0.0,
                        altitudeReference = AltitudeReference.SURFACE,
                        category = ObjectCategory.MARITIME_VESSEL,
                        reportedIdentity = "NORTH WORKBOAT",
                        reportedIdentitySource = "Primary Radar + VHF",
                        sourceId = "SIM-MARITIME-1"
                    ),
                    SimEntitySpec(
                        entityId = "E-CLOSE-B",
                        initialBearingFromOriginDeg = 172.0,
                        initialRangeMeters = 17_800.0,
                        speedMps = 13.5,
                        courseDeg = 345.0,
                        altitudeMeters = 0.0,
                        altitudeReference = AltitudeReference.SURFACE,
                        category = ObjectCategory.MARITIME_VESSEL,
                        reportedIdentity = "NORTH WORKBOAT", // Intentionally identical display label to verify NO label-merge!
                        reportedIdentitySource = "Primary Radar + VHF",
                        sourceId = "SIM-MARITIME-1"
                    ),
                    // High-altitude civilian jet
                    SimEntitySpec(
                        entityId = "E-AIR-1",
                        initialBearingFromOriginDeg = 285.0,
                        initialRangeMeters = 58_000.0,
                        speedMps = 215.0,
                        courseDeg = 102.0,
                        altitudeMeters = 8_534.0,
                        altitudeReference = AltitudeReference.PRESSURE_FL,
                        category = ObjectCategory.CIVILIAN_AIRCRAFT,
                        reportedIdentity = "BAW412",
                        reportedIdentitySource = "ADS-B Mode-S",
                        sourceId = "SIM-AIR-1"
                    ),
                    // Medium-altitude regional turboprop
                    SimEntitySpec(
                        entityId = "E-AIR-2",
                        initialBearingFromOriginDeg = 15.0,
                        initialRangeMeters = 48_000.0,
                        speedMps = 135.0,
                        courseDeg = 195.0,
                        turnRateDegPerSec = 0.25,
                        altitudeMeters = 3_657.0,
                        altitudeReference = AltitudeReference.AMSL,
                        category = ObjectCategory.CIVILIAN_AIRCRAFT,
                        reportedIdentity = "LOG78K",
                        reportedIdentitySource = "ADS-B Mode-S",
                        sourceId = "SIM-AIR-1"
                    ),
                    // Offshore helicopter with missing identity label (tests unavailable fields)
                    SimEntitySpec(
                        entityId = "E-HELI-1",
                        initialBearingFromOriginDeg = 120.0,
                        initialRangeMeters = 22_000.0,
                        speedMps = 62.0,
                        courseDeg = 305.0,
                        altitudeMeters = 548.0,
                        altitudeReference = AltitudeReference.AMSL,
                        category = ObjectCategory.CIVILIAN_AIRCRAFT,
                        reportedIdentity = null,
                        reportedIdentitySource = "Primary Radar Only",
                        sourceId = "SIM-RADAR-PRI"
                    )
                )
                ScenarioBundle(
                    area = ObservationArea(
                        scenarioId = ScenarioId.NORTH_SEA_OBSERVATION,
                        name = "North Sea Observation",
                        center = origin,
                        coastlinePolygons = listOf(doggerContour)
                    ),
                    defaultZones = zones,
                    entities = entities
                )
            }

            ScenarioId.SOLENT_MARITIME_CROSSING -> {
                val origin = GeoPoint(50.7900, -1.1100)
                val isleContour = listOf(
                    GeoPoint(50.76, -1.29),
                    GeoPoint(50.73, -1.07),
                    GeoPoint(50.67, -1.08),
                    GeoPoint(50.65, -1.25)
                )
                val zones = listOf(
                    MonitoredZone(
                        zoneId = "ZONE-SOLENT-TSS",
                        name = "Portsmouth Approach TSS",
                        scenarioId = ScenarioId.SOLENT_MARITIME_CROSSING,
                        shape = ZoneShape.CIRCLE,
                        center = GeoMath.destinationPoint(origin, 140.0, 5_500.0),
                        radiusMeters = 2_800.0,
                        alertOnEntry = true,
                        alertOnExit = true,
                        loiterThresholdSec = 40,
                        hysteresisMeters = 100.0
                    )
                )
                val entities = listOf(
                    SimEntitySpec(
                        entityId = "SOL-FERRY-1",
                        initialBearingFromOriginDeg = 160.0,
                        initialRangeMeters = 8_500.0,
                        speedMps = 11.5,
                        courseDeg = 350.0,
                        altitudeMeters = 0.0,
                        altitudeReference = AltitudeReference.SURFACE,
                        category = ObjectCategory.MARITIME_VESSEL,
                        reportedIdentity = "ST CLARE",
                        reportedIdentitySource = "AIS Class-A",
                        sourceId = "SIM-SOLENT-RADAR"
                    ),
                    SimEntitySpec(
                        entityId = "SOL-CARGO-1",
                        initialBearingFromOriginDeg = 105.0,
                        initialRangeMeters = 14_000.0,
                        speedMps = 8.2,
                        courseDeg = 285.0,
                        altitudeMeters = 0.0,
                        altitudeReference = AltitudeReference.SURFACE,
                        category = ObjectCategory.MARITIME_VESSEL,
                        reportedIdentity = "SOLENT TRADER",
                        reportedIdentitySource = "AIS Class-A",
                        sourceId = "SIM-SOLENT-RADAR"
                    ),
                    SimEntitySpec(
                        entityId = "SOL-VFR-1",
                        initialBearingFromOriginDeg = 250.0,
                        initialRangeMeters = 19_000.0,
                        speedMps = 58.0,
                        courseDeg = 72.0,
                        altitudeMeters = 762.0,
                        altitudeReference = AltitudeReference.AMSL,
                        category = ObjectCategory.CIVILIAN_AIRCRAFT,
                        reportedIdentity = "G-AVFR",
                        reportedIdentitySource = "ADS-B",
                        sourceId = "SIM-AIR-1"
                    )
                )
                ScenarioBundle(
                    area = ObservationArea(
                        scenarioId = ScenarioId.SOLENT_MARITIME_CROSSING,
                        name = "Solent Maritime Crossing",
                        center = origin,
                        coastlinePolygons = listOf(isleContour)
                    ),
                    defaultZones = zones,
                    entities = entities
                )
            }

            ScenarioId.INDUSTRIAL_PERIMETER_SITE -> {
                val origin = GeoPoint(52.4862, -1.8904)
                val zones = listOf(
                    MonitoredZone(
                        zoneId = "ZONE-PERIM-CORE",
                        name = "Substation Perimeter Fence",
                        scenarioId = ScenarioId.INDUSTRIAL_PERIMETER_SITE,
                        shape = ZoneShape.CIRCLE,
                        center = origin,
                        radiusMeters = 900.0,
                        alertOnEntry = true,
                        alertOnExit = true,
                        loiterThresholdSec = 25,
                        hysteresisMeters = 40.0
                    )
                )
                val entities = listOf(
                    SimEntitySpec(
                        entityId = "PERIM-PATROL-1",
                        initialBearingFromOriginDeg = 35.0,
                        initialRangeMeters = 1_450.0,
                        speedMps = 12.0,
                        courseDeg = 215.0,
                        altitudeMeters = 120.0,
                        altitudeReference = AltitudeReference.AGL,
                        category = ObjectCategory.PERIMETER_VEHICLE,
                        reportedIdentity = "PATROL-02",
                        reportedIdentitySource = "Site Telemetry",
                        sourceId = "SIM-PERIM-RADAR"
                    ),
                    SimEntitySpec(
                        entityId = "PERIM-UNK-1",
                        initialBearingFromOriginDeg = 270.0,
                        initialRangeMeters = 1_900.0,
                        speedMps = 8.5,
                        courseDeg = 88.0,
                        altitudeMeters = null,
                        altitudeReference = AltitudeReference.UNAVAILABLE,
                        category = ObjectCategory.UNKNOWN_CONTACT,
                        reportedIdentity = null,
                        reportedIdentitySource = "Ground Radar Only",
                        sourceId = "SIM-PERIM-RADAR"
                    )
                )
                ScenarioBundle(
                    area = ObservationArea(
                        scenarioId = ScenarioId.INDUSTRIAL_PERIMETER_SITE,
                        name = "Industrial Perimeter Site",
                        center = origin,
                        coastlinePolygons = emptyList()
                    ),
                    defaultZones = zones,
                    entities = entities
                )
            }
        }
    }
}

/**
 * Deterministic radar sensor simulator driven by [kotlin.random.Random(seed)].
 */
class RadarSimulator(
    private var config: SimulatorConfig
) {
    private var random = Random(config.seed)
    private var bundle = ScenarioCatalog.buildScenario(config.scenarioId)
    private val entityStates = mutableListOf<EntityKinematics>()
    private val delayedQueue = mutableListOf<Pair<Long, RawSourceMessage>>()
    private var seqCounter = 1L
    private var elapsedSimMs = 0L

    private data class EntityKinematics(
        val spec: SimEntitySpec,
        var pos: GeoPoint,
        var courseDeg: Double
    )

    init {
        reset(config)
    }

    fun getArea(): ObservationArea = bundle.area
    fun getDefaultZones(): List<MonitoredZone> = bundle.defaultZones
    fun getConfig(): SimulatorConfig = config

    fun updateConfig(newConfig: SimulatorConfig) {
        val scenarioOrSeedChanged = newConfig.scenarioId != config.scenarioId || newConfig.seed != config.seed
        config = newConfig
        if (scenarioOrSeedChanged) {
            reset(newConfig)
        }
    }

    fun reset(newConfig: SimulatorConfig = config) {
        config = newConfig
        random = Random(config.seed)
        bundle = ScenarioCatalog.buildScenario(config.scenarioId)
        entityStates.clear()
        delayedQueue.clear()
        seqCounter = 1L
        elapsedSimMs = 0L

        for (spec in bundle.entities) {
            val startPos = GeoMath.destinationPoint(
                bundle.area.center,
                spec.initialBearingFromOriginDeg,
                spec.initialRangeMeters
            )
            entityStates.add(EntityKinematics(spec, startPos, spec.courseDeg))
        }
    }

    /**
     * Advances ground-truth kinematics by [dtMs] and emits raw sensor messages at [wallClockMs].
     */
    fun step(dtMs: Long, wallClockMs: Long): List<RawSourceMessage> {
        elapsedSimMs += dtMs
        val dtSec = dtMs / 1000.0
        val emitted = mutableListOf<RawSourceMessage>()

        // Advance true target kinematics regardless of outage
        for (entity in entityStates) {
            entity.courseDeg = GeoMath.normalizeBearingDeg(entity.courseDeg + entity.spec.turnRateDegPerSec * dtSec)
            entity.pos = GeoMath.destinationPoint(entity.pos, entity.courseDeg, entity.spec.speedMps * dtSec)
        }

        if (config.sensorOutageActive) {
            return emptyList()
        }

        // Release any delayed messages due now
        val readyIterator = delayedQueue.iterator()
        while (readyIterator.hasNext()) {
            val (releaseAt, msg) = readyIterator.next()
            if (wallClockMs >= releaseAt) {
                emitted.add(msg.copy(receivedAtMs = wallClockMs))
                readyIterator.remove()
            }
        }

        // Generate observations for each entity
        for (entity in entityStates) {
            if (random.nextDouble() < config.missedDetectionProb) {
                continue
            }

            val sigma = config.positionNoiseSigmaMeters
            val angle = random.nextDouble(0.0, 2.0 * PI)
            val radius = gaussianApprox() * sigma
            val noisyPos = if (kotlin.math.abs(radius) > 0.1) {
                GeoMath.destinationPoint(
                    entity.pos,
                    Math.toDegrees(angle),
                    kotlin.math.abs(radius)
                )
            } else {
                entity.pos
            }

            val speedNoise = entity.spec.speedMps + (gaussianApprox() * 0.4)
            val courseNoise = GeoMath.normalizeBearingDeg(entity.courseDeg + gaussianApprox() * 1.5)
            val seq = seqCounter++
            val msg = RawSourceMessage(
                messageId = "SIM-${config.seed}-$seq",
                sourceId = entity.spec.sourceId,
                sourceType = SourceType.SYNTHETIC_SIM,
                sequenceNumber = seq,
                sensorTimestampMs = wallClockMs,
                receivedAtMs = wallClockMs,
                latDeg = noisyPos.latDeg,
                lonDeg = noisyPos.lonDeg,
                groundSpeedMps = speedNoise.coerceAtLeast(0.0),
                courseOverGroundDeg = courseNoise,
                headingDeg = if (entity.spec.category == ObjectCategory.MARITIME_VESSEL) {
                    GeoMath.normalizeBearingDeg(courseNoise + gaussianApprox() * 2.0)
                } else null,
                altitudeMeters = entity.spec.altitudeMeters,
                altitudeReference = entity.spec.altitudeReference,
                reportedIdentity = entity.spec.reportedIdentity,
                reportedIdentitySource = entity.spec.reportedIdentitySource,
                objectCategory = entity.spec.category,
                uncertaintyMeters = sigma.coerceAtLeast(15.0),
                isClutter = false,
                rawPayloadSummary = "SIM_PLOT seq=$seq entity=${entity.spec.entityId}"
            )

            if (random.nextDouble() < config.delayedMessageProb) {
                delayedQueue.add((wallClockMs + config.delayMs) to msg)
            } else {
                emitted.add(msg)
                if (random.nextDouble() < config.duplicateMessageProb) {
                    emitted.add(msg.copy(receivedAtMs = wallClockMs + 50L))
                }
            }
        }

        // Inject deterministic clutter plots
        repeat(config.clutterPerScan) {
            val clutterBearing = random.nextDouble(0.0, 360.0)
            val maxRange = bundle.area.scenarioId.defaultRangeNm * GeoMath.METERS_PER_NM * 0.85
            val clutterRange = random.nextDouble(500.0, maxRange)
            val clutterPos = GeoMath.destinationPoint(bundle.area.center, clutterBearing, clutterRange)
            val seq = seqCounter++
            emitted.add(
                RawSourceMessage(
                    messageId = "CLUTTER-${config.seed}-$seq",
                    sourceId = "SIM-RADAR-PRI",
                    sourceType = SourceType.SYNTHETIC_SIM,
                    sequenceNumber = seq,
                    sensorTimestampMs = wallClockMs,
                    receivedAtMs = wallClockMs,
                    latDeg = clutterPos.latDeg,
                    lonDeg = clutterPos.lonDeg,
                    groundSpeedMps = null,
                    courseOverGroundDeg = null,
                    headingDeg = null,
                    altitudeMeters = null,
                    altitudeReference = AltitudeReference.UNAVAILABLE,
                    reportedIdentity = null,
                    reportedIdentitySource = null,
                    objectCategory = ObjectCategory.CLUTTER,
                    uncertaintyMeters = 180.0,
                    isClutter = true,
                    rawPayloadSummary = "CLUTTER_PLOT seq=$seq"
                )
            )
        }

        return emitted
    }

    private fun gaussianApprox(): Double {
        // Central Limit Theorem Irwin-Hall approximation for deterministic fast Gaussian
        var sum = 0.0
        repeat(6) { sum += random.nextDouble() }
        return (sum - 3.0) * 1.41421356
    }
}
