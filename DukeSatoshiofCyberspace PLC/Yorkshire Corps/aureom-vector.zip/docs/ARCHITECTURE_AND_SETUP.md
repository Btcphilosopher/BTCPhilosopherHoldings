# Aureom Vector — Backend, API, Setup & APK Build Guide

## 1. Repository Structure
- `app/` — Native Android Jetpack Compose application (`com.aistudio.aureomvector.r7k4m2`)
  - `domain/geo/` — WGS-84 tangent-plane ENU math, great-circle range/bearing, polygon/circle signed distance
  - `domain/model/` — Separated RawMessage, ValidatedObservation, AssociatedTrack, DisplayPrediction, OperatorAnnotation, Zones & Alerts
  - `domain/tracking/` — Baseline GNN + Alpha-Beta kinematic tracker with deduplication & ambiguity history
  - `domain/alerts/` — Hysteresis + debounced zone & outage alert engine
  - `domain/sim/` — Deterministic PRNG simulator (`North Sea Observation`, `Solent Maritime Crossing`, `Industrial Perimeter Site`)
  - `data/local/` — Room database (`AureomDatabase`, `LocalRecordingRepository`) & DataStore (`SettingsDataStore`)
  - `data/sources/` — `KtorWebSocketSourceAdapter`, `DeviceTelemetryProvider` (GNSS + Orientation), adapter interfaces
  - `data/export/` — `ReportExporter`
  - `ui/` — `RadarScopeCanvas`, `TrackInspectorPanel`, `HudScreen`, `HomeScreen`, `RadarScreen`, `ReplayScreen`, `SourcesScreen`, `AlertsScreen`, `SystemHealthScreen`, `SettingsScreen`
- `backend/` — Standalone Kotlin Ktor 3 + PostgreSQL + WebSockets server
  - `migrations/001_init.sql` — PostgreSQL DDL & seed data
  - `src/main/kotlin/com/aureom/backend/` — Netty server, Bearer auth, rate limiter, HikariCP PostgreSQL store, `/ws/stream`

## 2. PostgreSQL & Ktor Backend Setup
```bash
# 1. Create database & apply migration
createdb aureom_vector
psql -d aureom_vector -f backend/migrations/001_init.sql

# 2. Configure environment variables (never commit credentials)
export AUREOM_DB_URL="jdbc:postgresql://localhost:5432/aureom_vector"
export AUREOM_DB_USER="aureom"
export AUREOM_DB_PASSWORD="your-strong-password"
export AUREOM_API_TOKEN="aureom-dev-token"

# 3. Run Ktor server on port 8080
cd backend && gradle run
```

## 3. HTTP & WebSocket API
- `GET /health` — Server and PostgreSQL readiness check
- `GET /api/v1/observations?limit=100` (Bearer Auth) — Query persisted validated observations
- `POST /api/v1/observations` (Bearer Auth, Rate-limited 120 req/min) — Ingest & validate external observation
- `WS /ws/stream` (`Authorization: Bearer <token>`) — Real-time JSON observation stream (`type = "observation"`)

## 4. Android APK Build & Release Signing
```bash
# Build Debug APK
gradle :app:assembleDebug
# Output: app/build/outputs/apk/debug/app-debug.apk

# Run JVM + Robolectric Unit Tests
gradle :app:testDebugUnitTest

# Build Release APK (supply signing credentials via environment variables outside source control)
export KEYSTORE_PATH="/secure/path/aureom-upload-key.jks"
export STORE_PASSWORD="..."
export KEY_PASSWORD="..."
gradle :app:assembleRelease
```
