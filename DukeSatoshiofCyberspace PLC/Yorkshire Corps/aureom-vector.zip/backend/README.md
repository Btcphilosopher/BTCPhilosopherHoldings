# Aureom Vector — Ktor + PostgreSQL Backend

Standalone Kotlin Ktor 3 server providing:
- PostgreSQL persistence (`HikariCP` + parameterized SQL) for raw messages, validated observations, monitored zones, and alerts
- Authenticated WebSocket observation stream (`/ws/stream`) with bounded outbound queue (`Channel(capacity = 128, DROP_OLDEST)`)
- Rate-limited REST endpoints (`/api/v1/observations`) with input coordinate/uncertainty validation and Bearer token authentication

## Setup
```bash
createdb aureom_vector
psql -d aureom_vector -f migrations/001_init.sql

export AUREOM_DB_URL="jdbc:postgresql://localhost:5432/aureom_vector"
export AUREOM_DB_USER="aureom"
export AUREOM_DB_PASSWORD="change-me"
export AUREOM_API_TOKEN="aureom-dev-token"

gradle run
```

## Connecting from Android Emulator
In the Aureom Vector Android app:
1. Open **Sources**
2. Set WebSocket Endpoint to `ws://10.0.2.2:8080/ws/stream`
3. Set Bearer Token to match `AUREOM_API_TOKEN` (default `aureom-dev-token`)
4. Tap **Connect Ktor Stream**
