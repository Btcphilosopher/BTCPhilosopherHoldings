package com.aureom.backend.db

import com.zaxxer.hikari.HikariConfig
import com.zaxxer.hikari.HikariDataSource
import kotlinx.serialization.Serializable
import java.sql.Connection

@Serializable
data class ObservationPayload(
    val type: String = "observation",
    val messageId: String,
    val sourceId: String,
    val sequenceNumber: Long,
    val sensorTimestampMs: Long,
    val latDeg: Double,
    val lonDeg: Double,
    val groundSpeedMps: Double? = null,
    val courseOverGroundDeg: Double? = null,
    val headingDeg: Double? = null,
    val altitudeMeters: Double? = null,
    val altitudeReference: String = "UNAVAILABLE",
    val reportedIdentity: String? = null,
    val reportedIdentitySource: String? = null,
    val objectCategory: String = "UNKNOWN_CONTACT",
    val uncertaintyMeters: Double = 45.0,
    val isClutter: Boolean = false
)

@Serializable
data class ZoneDto(
    val zoneId: String,
    val areaId: String,
    val name: String,
    val shape: String,
    val centerLatDeg: Double,
    val centerLonDeg: Double,
    val radiusMeters: Double,
    val loiterThresholdSec: Int = 60,
    val hysteresisMeters: Double = 150.0,
    val enabled: Boolean = true
)

class PostgresStore(
    jdbcUrl: String = System.getenv("AUREOM_DB_URL") ?: "jdbc:postgresql://localhost:5432/aureom_vector",
    dbUser: String = System.getenv("AUREOM_DB_USER") ?: "aureom",
    dbPassword: String = System.getenv("AUREOM_DB_PASSWORD") ?: ""
) {
    private val dataSource: HikariDataSource? = runCatching {
        val cfg = HikariConfig().apply {
            this.jdbcUrl = jdbcUrl
            this.username = dbUser
            this.password = dbPassword
            maximumPoolSize = 8
            connectionTimeout = 3000
        }
        HikariDataSource(cfg)
    }.getOrNull()

    fun isDatabaseReady(): Boolean {
        val ds = dataSource ?: return false
        return runCatching {
            ds.connection.use { conn -> conn.isValid(2) }
        }.getOrDefault(false)
    }

    fun persistObservation(obs: ObservationPayload, rawJson: String) {
        val ds = dataSource ?: return
        runCatching {
            ds.connection.use { conn ->
                insertRawMessage(conn, obs, rawJson)
                insertValidatedObservation(conn, obs)
            }
        }
    }

    private fun insertRawMessage(conn: Connection, obs: ObservationPayload, rawJson: String) {
        val sql = """
            INSERT INTO raw_source_messages
                (message_id, source_id, sequence_number, sensor_timestamp_ms, received_at_ms, valid, payload_json)
            VALUES (?, ?, ?, ?, ?, TRUE, ?::jsonb)
            ON CONFLICT (message_id) DO NOTHING
        """.trimIndent()
        conn.prepareStatement(sql).use { st ->
            st.setString(1, obs.messageId)
            st.setString(2, obs.sourceId)
            st.setLong(3, obs.sequenceNumber)
            st.setLong(4, obs.sensorTimestampMs)
            st.setLong(5, System.currentTimeMillis())
            st.setString(6, rawJson)
            st.executeUpdate()
        }
    }

    private fun insertValidatedObservation(conn: Connection, obs: ObservationPayload) {
        val sql = """
            INSERT INTO validated_observations
                (observation_id, raw_message_id, source_id, sensor_timestamp_ms, lat_deg, lon_deg,
                 ground_speed_mps, course_over_ground_deg, heading_deg, altitude_meters,
                 altitude_reference, reported_identity, reported_identity_source, object_category,
                 uncertainty_meters, is_clutter)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT (observation_id) DO NOTHING
        """.trimIndent()
        conn.prepareStatement(sql).use { st ->
            st.setString(1, "OBS-${obs.messageId}")
            st.setString(2, obs.messageId)
            st.setString(3, obs.sourceId)
            st.setLong(4, obs.sensorTimestampMs)
            st.setDouble(5, obs.latDeg)
            st.setDouble(6, obs.lonDeg)
            st.setObject(7, obs.groundSpeedMps)
            st.setObject(8, obs.courseOverGroundDeg)
            st.setObject(9, obs.headingDeg)
            st.setObject(10, obs.altitudeMeters)
            st.setString(11, obs.altitudeReference)
            st.setString(12, obs.reportedIdentity)
            st.setString(13, obs.reportedIdentitySource)
            st.setString(14, obs.objectCategory)
            st.setDouble(15, obs.uncertaintyMeters)
            st.setBoolean(16, obs.isClutter)
            st.executeUpdate()
        }
    }

    fun listRecentObservations(limit: Int = 100): List<ObservationPayload> {
        val ds = dataSource ?: return emptyList()
        return runCatching {
            ds.connection.use { conn ->
                val sql = """
                    SELECT raw_message_id, source_id, sensor_timestamp_ms, lat_deg, lon_deg,
                           ground_speed_mps, course_over_ground_deg, heading_deg, altitude_meters,
                           altitude_reference, reported_identity, reported_identity_source,
                           object_category, uncertainty_meters, is_clutter
                    FROM validated_observations
                    ORDER BY sensor_timestamp_ms DESC
                    LIMIT ?
                """.trimIndent()
                conn.prepareStatement(sql).use { st ->
                    st.setInt(1, limit.coerceIn(1, 500))
                    val rs = st.executeQuery()
                    val out = mutableListOf<ObservationPayload>()
                    while (rs.next()) {
                        out.add(
                            ObservationPayload(
                                messageId = rs.getString("raw_message_id"),
                                sourceId = rs.getString("source_id"),
                                sequenceNumber = 0L,
                                sensorTimestampMs = rs.getLong("sensor_timestamp_ms"),
                                latDeg = rs.getDouble("lat_deg"),
                                lonDeg = rs.getDouble("lon_deg"),
                                groundSpeedMps = rs.getObject("ground_speed_mps") as? Double,
                                courseOverGroundDeg = rs.getObject("course_over_ground_deg") as? Double,
                                headingDeg = rs.getObject("heading_deg") as? Double,
                                altitudeMeters = rs.getObject("altitude_meters") as? Double,
                                altitudeReference = rs.getString("altitude_reference"),
                                reportedIdentity = rs.getString("reported_identity"),
                                reportedIdentitySource = rs.getString("reported_identity_source"),
                                objectCategory = rs.getString("object_category"),
                                uncertaintyMeters = rs.getDouble("uncertainty_meters"),
                                isClutter = rs.getBoolean("is_clutter")
                            )
                        )
                    }
                    out
                }
            }
        }.getOrDefault(emptyList())
    }
}
