package com.aureom.backend

import com.aureom.backend.db.ObservationPayload
import com.aureom.backend.db.PostgresStore
import io.ktor.http.HttpHeaders
import io.ktor.http.HttpStatusCode
import io.ktor.serialization.kotlinx.json.json
import io.ktor.server.application.Application
import io.ktor.server.application.install
import io.ktor.server.auth.Authentication
import io.ktor.server.auth.UserIdPrincipal
import io.ktor.server.auth.authenticate
import io.ktor.server.auth.bearer
import io.ktor.server.engine.embeddedServer
import io.ktor.server.netty.Netty
import io.ktor.server.plugins.calllogging.CallLogging
import io.ktor.server.plugins.contentnegotiation.ContentNegotiation
import io.ktor.server.plugins.ratelimit.RateLimit
import io.ktor.server.plugins.ratelimit.RateLimitName
import io.ktor.server.plugins.ratelimit.rateLimit
import io.ktor.server.plugins.statuspages.StatusPages
import io.ktor.server.request.receive
import io.ktor.server.response.respond
import io.ktor.server.routing.get
import io.ktor.server.routing.post
import io.ktor.server.routing.routing
import io.ktor.server.websocket.WebSockets
import io.ktor.server.websocket.pingPeriod
import io.ktor.server.websocket.timeout
import io.ktor.server.websocket.webSocket
import io.ktor.websocket.CloseReason
import io.ktor.websocket.Frame
import io.ktor.websocket.close
import kotlinx.coroutines.channels.BufferOverflow
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import kotlin.math.asin
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random
import kotlin.time.Duration.Companion.seconds

@Serializable
data class HealthResponse(
    val service: String,
    val status: String,
    val postgresConnected: Boolean,
    val timestampMs: Long
)

fun main() {
    val port = System.getenv("PORT")?.toIntOrNull() ?: 8080
    embeddedServer(Netty, port = port, host = "0.0.0.0", module = Application::aureomModule)
        .start(wait = true)
}

fun Application.aureomModule() {
    val expectedToken = System.getenv("AUREOM_API_TOKEN") ?: "aureom-dev-token"
    val store = PostgresStore()
    val json = Json { encodeDefaults = true; ignoreUnknownKeys = true }

    install(CallLogging)
    install(ContentNegotiation) {
        json(json)
    }
    install(WebSockets) {
        pingPeriod = 15.seconds
        timeout = 30.seconds
        maxFrameSize = 65_536L
    }
    install(RateLimit) {
        register(RateLimitName("api")) {
            rateLimiter(limit = 120, refillPeriod = 60.seconds)
        }
    }
    install(StatusPages) {
        exception<IllegalArgumentException> { call, cause ->
            call.respond(HttpStatusCode.BadRequest, mapOf("error" to (cause.message ?: "Invalid request")))
        }
    }
    install(Authentication) {
        bearer("aureom-bearer") {
            authenticate { tokenCredential ->
                if (tokenCredential.token == expectedToken) {
                    UserIdPrincipal("operator")
                } else null
            }
        }
    }

    routing {
        get("/health") {
            call.respond(
                HealthResponse(
                    service = "aureom-vector-backend",
                    status = "OK",
                    postgresConnected = store.isDatabaseReady(),
                    timestampMs = System.currentTimeMillis()
                )
            )
        }

        rateLimit(RateLimitName("api")) {
            authenticate("aureom-bearer") {
                get("/api/v1/observations") {
                    val limit = call.request.queryParameters["limit"]?.toIntOrNull() ?: 100
                    call.respond(store.listRecentObservations(limit))
                }

                post("/api/v1/observations") {
                    val obs = call.receive<ObservationPayload>()
                    require(obs.latDeg in -90.0..90.0) { "Latitude out of bounds" }
                    require(obs.lonDeg in -180.0..180.0) { "Longitude out of bounds" }
                    require(obs.uncertaintyMeters >= 0.0) { "Negative uncertainty rejected" }
                    store.persistObservation(obs, json.encodeToString(obs))
                    call.respond(HttpStatusCode.Created, mapOf("status" to "accepted", "messageId" to obs.messageId))
                }
            }
        }

        // Authenticated WebSocket stream with bounded outbound queue
        webSocket("/ws/stream") {
            val authHeader = call.request.headers[HttpHeaders.Authorization]
            if (authHeader != "Bearer $expectedToken") {
                close(CloseReason(CloseReason.Codes.VIOLATED_POLICY, "Unauthorized"))
                return@webSocket
            }

            val outbound = Channel<String>(capacity = 128, onBufferOverflow = BufferOverflow.DROP_OLDEST)
            val simJob = launch {
                val rng = Random(20260401L)
                var seq = 1L
                var vesselLat = 55.56
                var vesselLon = 2.15
                var airLat = 55.52
                var airLon = 1.05
                while (isActive) {
                    val now = System.currentTimeMillis()
                    val (vLat, vLon) = stepGeo(vesselLat, vesselLon, 225.0, 18.0)
                    vesselLat = vLat; vesselLon = vLon
                    val (aLat, aLon) = stepGeo(airLat, airLon, 102.0, 215.0)
                    airLat = aLat; airLon = aLon

                    val p1 = ObservationPayload(
                        messageId = "KTOR-${seq++}",
                        sourceId = "KTOR-WS-FEED",
                        sequenceNumber = seq,
                        sensorTimestampMs = now,
                        latDeg = vesselLat + (rng.nextDouble() - 0.5) * 0.0004,
                        lonDeg = vesselLon + (rng.nextDouble() - 0.5) * 0.0004,
                        groundSpeedMps = 18.0,
                        courseOverGroundDeg = 225.0,
                        altitudeMeters = 0.0,
                        altitudeReference = "SURFACE",
                        reportedIdentity = "MV SHETLAND STAR",
                        reportedIdentitySource = "AIS Stream (Ktor)",
                        objectCategory = "MARITIME_VESSEL",
                        uncertaintyMeters = 35.0
                    )
                    val p2 = ObservationPayload(
                        messageId = "KTOR-${seq++}",
                        sourceId = "KTOR-WS-FEED",
                        sequenceNumber = seq,
                        sensorTimestampMs = now,
                        latDeg = airLat,
                        lonDeg = airLon,
                        groundSpeedMps = 215.0,
                        courseOverGroundDeg = 102.0,
                        altitudeMeters = 8534.0,
                        altitudeReference = "PRESSURE_FL",
                        reportedIdentity = "BAW412",
                        reportedIdentitySource = "ADS-B Stream (Ktor)",
                        objectCategory = "CIVILIAN_AIRCRAFT",
                        uncertaintyMeters = 45.0
                    )
                    listOf(p1, p2).forEach { obs ->
                        val payloadStr = json.encodeToString(obs)
                        store.persistObservation(obs, payloadStr)
                        outbound.trySend(payloadStr)
                    }
                    delay(1000L)
                }
            }

            try {
                for (msg in outbound) {
                    send(Frame.Text(msg))
                }
            } finally {
                simJob.cancel()
            }
        }
    }
}

private fun stepGeo(latDeg: Double, lonDeg: Double, bearingDeg: Double, distanceM: Double): Pair<Double, Double> {
    val r = 6_371_000.0
    val ang = distanceM / r
    val brg = Math.toRadians(bearingDeg)
    val lat1 = Math.toRadians(latDeg)
    val lon1 = Math.toRadians(lonDeg)
    val lat2 = asin(sin(lat1) * cos(ang) + cos(lat1) * sin(ang) * cos(brg))
    val lon2 = lon1 + atan2(sin(brg) * sin(ang) * cos(lat1), cos(ang) - sin(lat1) * sin(lat2))
    return Math.toDegrees(lat2) to Math.toDegrees(lon2)
}
