rootProject.name = "aureom-vector-backend"
