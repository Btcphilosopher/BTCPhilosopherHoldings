-- Aureom Vector PostgreSQL Schema Migration 001
-- Run against PostgreSQL 15+ database `aureom_vector`

CREATE TABLE IF NOT EXISTS observation_areas (
    area_id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    center_lat_deg DOUBLE PRECISION NOT NULL CHECK (center_lat_deg BETWEEN -90.0 AND 90.0),
    center_lon_deg DOUBLE PRECISION NOT NULL CHECK (center_lon_deg BETWEEN -180.0 AND 180.0),
    reference_frame TEXT NOT NULL DEFAULT 'WGS-84',
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS sensor_sources (
    source_id TEXT PRIMARY KEY,
    display_name TEXT NOT NULL,
    source_type TEXT NOT NULL,
    auth_scope TEXT NOT NULL DEFAULT 'feed:read',
    enabled BOOLEAN NOT NULL DEFAULT TRUE,
    last_seen_at TIMESTAMPTZ
);

CREATE TABLE IF NOT EXISTS raw_source_messages (
    message_id TEXT PRIMARY KEY,
    source_id TEXT NOT NULL REFERENCES sensor_sources(source_id),
    sequence_number BIGINT NOT NULL,
    sensor_timestamp_ms BIGINT NOT NULL,
    received_at_ms BIGINT NOT NULL,
    valid BOOLEAN NOT NULL,
    validation_error TEXT,
    payload_json JSONB NOT NULL,
    UNIQUE (source_id, sequence_number)
);

CREATE TABLE IF NOT EXISTS validated_observations (
    observation_id TEXT PRIMARY KEY,
    raw_message_id TEXT NOT NULL REFERENCES raw_source_messages(message_id),
    source_id TEXT NOT NULL REFERENCES sensor_sources(source_id),
    sensor_timestamp_ms BIGINT NOT NULL,
    lat_deg DOUBLE PRECISION NOT NULL CHECK (lat_deg BETWEEN -90.0 AND 90.0),
    lon_deg DOUBLE PRECISION NOT NULL CHECK (lon_deg BETWEEN -180.0 AND 180.0),
    ground_speed_mps DOUBLE PRECISION CHECK (ground_speed_mps IS NULL OR ground_speed_mps >= 0.0),
    course_over_ground_deg DOUBLE PRECISION,
    heading_deg DOUBLE PRECISION,
    altitude_meters DOUBLE PRECISION,
    altitude_reference TEXT NOT NULL DEFAULT 'UNAVAILABLE',
    reported_identity TEXT,
    reported_identity_source TEXT,
    object_category TEXT NOT NULL,
    uncertainty_meters DOUBLE PRECISION NOT NULL CHECK (uncertainty_meters >= 0.0),
    is_clutter BOOLEAN NOT NULL DEFAULT FALSE
);

CREATE INDEX IF NOT EXISTS idx_validated_obs_ts ON validated_observations(sensor_timestamp_ms DESC);
CREATE INDEX IF NOT EXISTS idx_validated_obs_src ON validated_observations(source_id, sensor_timestamp_ms DESC);

CREATE TABLE IF NOT EXISTS monitored_zones (
    zone_id TEXT PRIMARY KEY,
    area_id TEXT NOT NULL REFERENCES observation_areas(area_id),
    name TEXT NOT NULL,
    shape TEXT NOT NULL CHECK (shape IN ('CIRCLE', 'POLYGON')),
    center_lat_deg DOUBLE PRECISION NOT NULL,
    center_lon_deg DOUBLE PRECISION NOT NULL,
    radius_meters DOUBLE PRECISION NOT NULL CHECK (radius_meters > 0.0),
    polygon_json JSONB,
    alert_on_entry BOOLEAN NOT NULL DEFAULT TRUE,
    alert_on_exit BOOLEAN NOT NULL DEFAULT TRUE,
    loiter_threshold_sec INTEGER NOT NULL DEFAULT 60,
    hysteresis_meters DOUBLE PRECISION NOT NULL DEFAULT 150.0,
    enabled BOOLEAN NOT NULL DEFAULT TRUE
);

CREATE TABLE IF NOT EXISTS alerts (
    alert_id TEXT PRIMARY KEY,
    rule_type TEXT NOT NULL,
    severity TEXT NOT NULL CHECK (severity IN ('INFO', 'CAUTION', 'CRITICAL')),
    title TEXT NOT NULL,
    description TEXT NOT NULL,
    track_id TEXT,
    zone_id TEXT REFERENCES monitored_zones(zone_id),
    source_id TEXT,
    triggering_observation_ids JSONB NOT NULL DEFAULT '[]'::jsonb,
    first_occurrence_ms BIGINT NOT NULL,
    last_occurrence_ms BIGINT NOT NULL,
    occurrence_count INTEGER NOT NULL DEFAULT 1,
    acknowledged BOOLEAN NOT NULL DEFAULT FALSE,
    acknowledged_at_ms BIGINT,
    resolution_state TEXT NOT NULL CHECK (resolution_state IN ('ACTIVE', 'CONDITION_CLEARED', 'RESOLVED')),
    operator_notes TEXT NOT NULL DEFAULT ''
);

-- Seed North Sea Observation area and baseline sources
INSERT INTO observation_areas (area_id, name, center_lat_deg, center_lon_deg, reference_frame)
VALUES ('NORTH_SEA_OBSERVATION', 'North Sea Observation', 55.4200, 1.8500, 'WGS-84')
ON CONFLICT (area_id) DO NOTHING;

INSERT INTO sensor_sources (source_id, display_name, source_type) VALUES
    ('SIM-MARITIME-1', 'North Sea AIS / Coastal Sim', 'SYNTHETIC_SIM'),
    ('SIM-AIR-1', 'Civilian ADS-B Sim', 'SYNTHETIC_SIM'),
    ('SIM-RADAR-PRI', 'Primary Surveillance Radar Sim', 'SYNTHETIC_SIM')
ON CONFLICT (source_id) DO NOTHING;
