-- deliverables/postgres/rollback_001.sql
-- Safe rollback plan for migration 001_initial_schema.sql

DROP TRIGGER IF EXISTS trg_audit_events_immutable ON audit_events;
DROP TRIGGER IF EXISTS trg_stock_movements_immutable ON stock_movements;
DROP FUNCTION IF EXISTS forbid_ledger_mutation();

DROP TABLE IF EXISTS audit_events CASCADE;
DROP TABLE IF EXISTS approvals CASCADE;
DROP TABLE IF EXISTS documents CASCADE;
DROP TABLE IF EXISTS admin_requests CASCADE;
DROP TABLE IF EXISTS stock_movements CASCADE;
DROP TABLE IF EXISTS stock_items CASCADE;
DROP TABLE IF EXISTS maintenance_orders CASCADE;
DROP TABLE IF EXISTS custody_records CASCADE;
DROP TABLE IF EXISTS equipment_assets CASCADE;
DROP TABLE IF EXISTS leave_requests CASCADE;
DROP TABLE IF EXISTS qualifications CASCADE;
DROP TABLE IF EXISTS enrolments CASCADE;
DROP TABLE IF EXISTS courses CASCADE;
DROP TABLE IF EXISTS assignments CASCADE;
DROP TABLE IF EXISTS positions CASCADE;
DROP TABLE IF EXISTS people_sensitive CASCADE;
DROP TABLE IF EXISTS people CASCADE;
DROP TABLE IF EXISTS units CASCADE;
