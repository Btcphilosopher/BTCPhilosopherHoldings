# BRITISH ARMY — Administrative Information System
## Architecture, Installation, Role Matrix & Verification Guide

### 1. Project Overview
Independent synthetic demonstration administrative system covering personnel records, unit establishment, training & qualifications, leave workflows, equipment custody, maintenance release, immutable stores accounting, reporting, and offline synchronisation.

### 2. Directory Structure
- `src/` — Live Angular 21 + Tailwind CSS v4 + Firebase Auth & Firestore administrative terminal.
- `firestore.rules` & `firebase-blueprint.json` — Hardened Firestore security rules and schema blueprint.
- `deliverables/postgres/` — Normalised PostgreSQL DDL (`001_initial_schema.sql`) and rollback (`rollback_001.sql`).
- `deliverables/backend-fastapi/` — Python FastAPI v1 API source with RBAC and release gates.
- `deliverables/android-compose/` — Offline-first Jetpack Compose + Room + WorkManager sync engine.

### 3. Role-and-Permission Matrix
| Role | Personnel | Sensitive PII | Units/Positions | Training | Approvals | Equipment/Stores | Maint. Release | Audit/Config |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| `individual_member` | Self read | Self only | Read | Self | Submit only | Read | — | — |
| `unit_admin` | Create/Edit | Authorised | Manage | Enrol | Approve unit | Issue/Move | — | Audit read |
| `training_admin` | Read | — | Read | Manage + Correct | Submit | Read | — | Reports |
| `equipment_custodian` | Read | — | Read | — | Submit | Issue/Move | — | Reports |
| `maintenance_staff` | Read | — | Read | — | Submit | Reserve/Move | Work only | — |
| `approver` | Edit posting | Authorised | Assign | — | Approve/Reject | Read | **Release** | Reports |
| `auditor` | Read | — | Read | Read | Read | Read | Read | **Audit + Export** |
| `system_admin` | Create/Edit | **Blocked** | Manage | Manage | Submit | Manage | Release | **Full Config** |

### 4. Local Installation (Web Terminal)
```bash
npm install
npm run dev
```

### 5. Running Tests & Rules Linting
```bash
npx eslint firestore.rules
npx vitest run
```
