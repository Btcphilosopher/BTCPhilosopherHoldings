# deliverables/backend-fastapi/app/main.py
from datetime import datetime, timezone
from typing import Literal
from uuid import UUID
from fastapi import FastAPI, Depends, HTTPException, Header, status
from pydantic import BaseModel, Field

app = FastAPI(
    title="BRITISH ARMY — Administration API",
    version="1.0.0",
    description="Independent synthetic demonstration administrative information system API.",
)

ALLOWED_MIME_TYPES = {"application/pdf", "text/plain", "text/csv", "image/png", "image/jpeg"}
MAX_UPLOAD_BYTES = 10 * 1024 * 1024


class ActorContext(BaseModel):
    uid: str
    role: str
    unit_id: str


class LeaveDecisionPayload(BaseModel):
    decision: Literal["Approved", "Rejected", "Clarification Requested"]
    reason: str = Field(..., min_length=3, max_length=300)
    expected_version: int = Field(..., ge=1)
    policy_version: str = "JSP-760-DEMO-2026.2"
    requester_uid: str


class MaintenanceReleasePayload(BaseModel):
    inspection_passed: bool
    expected_version: int = Field(..., ge=1)
    release_notes: str = Field(..., min_length=3, max_length=300)


class DocumentMetaPayload(BaseModel):
    title: str = Field(..., min_length=2, max_length=160)
    mime_type: str
    size_bytes: int


def get_actor(
    x_actor_uid: str = Header(...),
    x_actor_role: str = Header(...),
    x_unit_id: str = Header(...),
) -> ActorContext:
    return ActorContext(uid=x_actor_uid, role=x_actor_role, unit_id=x_unit_id)


@app.get("/api/v1/health")
def health_check():
    return {
        "status": "ok",
        "service": "british-army-admin-demo",
        "timestamp": datetime.now(timezone.utc).isoformat(),
    }


@app.post("/api/v1/leave-requests/{request_id}/decision")
def decide_leave_request(
    request_id: UUID,
    payload: LeaveDecisionPayload,
    actor: ActorContext = Depends(get_actor),
):
    if actor.role not in {"approver", "unit_admin"}:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Insufficient approval authority.")
    if payload.requester_uid == actor.uid:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Self-approval is prohibited.")
    return {
        "request_id": str(request_id),
        "new_status": payload.decision,
        "new_version": payload.expected_version + 1,
        "approver_uid": actor.uid,
        "policy_version": payload.policy_version,
        "audited": True,
    }


@app.post("/api/v1/maintenance-orders/{order_id}/release")
def release_maintenance_order(
    order_id: UUID,
    payload: MaintenanceReleasePayload,
    actor: ActorContext = Depends(get_actor),
):
    if actor.role not in {"approver", "equipment_custodian"}:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Independent release authority required.")
    if not payload.inspection_passed:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="Equipment cannot be declared serviceable without passing inspection.",
        )
    return {
        "order_id": str(order_id),
        "status": "Released Serviceable",
        "asset_serviceability": "Serviceable",
        "released_by": actor.uid,
        "new_version": payload.expected_version + 1,
    }


@app.post("/api/v1/documents/validate")
def validate_document_upload(payload: DocumentMetaPayload, actor: ActorContext = Depends(get_actor)):
    if payload.mime_type not in ALLOWED_MIME_TYPES:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Unsupported document MIME type.")
    if payload.size_bytes <= 0 or payload.size_bytes > MAX_UPLOAD_BYTES:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="File size exceeds 10 MB limit.")
    return {"accepted": True, "submitted_by": actor.uid}
