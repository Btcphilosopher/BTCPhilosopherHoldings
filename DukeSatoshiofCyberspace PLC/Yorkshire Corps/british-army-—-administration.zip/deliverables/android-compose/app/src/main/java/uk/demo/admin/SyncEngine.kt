// deliverables/android-compose/app/src/main/java/uk/demo/admin/SyncEngine.kt
package uk.demo.admin.sync

import android.content.Context
import androidx.room.*
import androidx.work.*
import kotlinx.coroutines.flow.Flow
import java.util.UUID

@Entity(tableName = "cached_personnel")
data class CachedPersonEntity(
    @PrimaryKey val id: String,
    val serviceId: String,
    val rank: String,
    val surname: String,
    val unitId: String,
    val version: Int
)

@Entity(tableName = "offline_mutation_queue")
data class OfflineMutationEntity(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val idempotencyKey: String = UUID.randomUUID().toString(),
    val entityType: String,
    val entityId: String,
    val expectedVersion: Int,
    val payloadJson: String,
    val status: String = "QUEUED",
    val conflictReason: String? = null
)

@Dao
interface AdminLocalDao {
    @Query("SELECT * FROM cached_personnel ORDER BY surname ASC")
    fun observePersonnel(): Flow<List<CachedPersonEntity>>

    @Query("SELECT * FROM offline_mutation_queue WHERE status = 'QUEUED'")
    suspend fun pendingMutations(): List<OfflineMutationEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun enqueue(mutation: OfflineMutationEntity)

    @Query("UPDATE offline_mutation_queue SET status = :status, conflictReason = :reason WHERE id = :id")
    suspend fun updateMutationStatus(id: String, status: String, reason: String?)

    @Query("DELETE FROM cached_personnel")
    suspend fun purgeRestrictedCache()
}

data class SessionRevalidationResult(val active: Boolean, val permissions: Set<String>)

sealed class SyncOutcome {
    object Applied : SyncOutcome()
    data class VersionConflict(val serverVersion: Int) : SyncOutcome()
    object TransientError : SyncOutcome()
}

interface ReplaceableAdminApi {
    suspend fun revalidateSession(): SessionRevalidationResult
    suspend fun submitMutation(mutation: OfflineMutationEntity): SyncOutcome
}

class OfflineSyncWorker(
    appContext: Context,
    workerParams: WorkerParameters,
    private val dao: AdminLocalDao,
    private val api: ReplaceableAdminApi
) : CoroutineWorker(appContext, workerParams) {

    override suspend fun doWork(): Result {
        val session = api.revalidateSession()
        if (!session.active) {
            dao.purgeRestrictedCache()
            return Result.failure()
        }

        for (item in dao.pendingMutations()) {
            if (!session.permissions.contains(item.entityType)) {
                dao.updateMutationStatus(item.id, "REJECTED_AUTH", "Permission revoked on server.")
                continue
            }
            when (val res = api.submitMutation(item)) {
                is SyncOutcome.Applied -> dao.updateMutationStatus(item.id, "SYNCED", null)
                is SyncOutcome.VersionConflict -> dao.updateMutationStatus(
                    item.id,
                    "CONFLICT",
                    "Expected v${item.expectedVersion}, server at v${res.serverVersion}"
                )
                is SyncOutcome.TransientError -> return Result.retry()
            }
        }
        return Result.success()
    }
}
