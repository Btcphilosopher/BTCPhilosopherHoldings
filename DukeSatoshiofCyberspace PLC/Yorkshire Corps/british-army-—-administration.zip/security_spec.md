# Security Specification & Payload-First TDD (`security_spec.md`)

## 1. Data Invariants

1. **Identity & Privilege Separation**: Users may read their own `users/{uid}` profile, but cannot elevate `role` or `activeDemoRole` on create or update. Only the verified bootstrap administrator (`tom@ahyx.org` with `email_verified == true`) or an authenticated `system_admin` may assign roles.
2. **PII Isolation (`people_sensitive`)**: `people_sensitive/{personId}` forbids `list` queries completely (`allow list: if false;`). `get` is restricted exclusively to `unit_admin`, `approver`, or the record's `ownerUid`. Technical `system_admin` accounts do not gain unrestricted PII access.
3. **Self-Approval Prevention**: In `leave_requests` and `admin_requests`, `approverUid` cannot approve or reject a record where `existing().ownerUid == request.auth.uid` (except explicit bootstrap testing override when not acting as requester, enforced in UI and rule branches).
4. **Immutable Ledgers**: `audit_events` and `stock_movements` are strictly append-only (`allow update, delete: if false;`).
5. **Terminal State Locking**: Requests in terminal states (`Completed`, `Cancelled`, `Withdrawn`, `Rejected`) cannot be modified by non-admin submitters.
6. **Maintenance Release Gate**: `equipment_assets` serviceability cannot transition to `Serviceable` from `Unserviceable` / `In Maintenance` without an authorised release step.
7. **Path & Size Bounds**: Every document ID matches `^[a-zA-Z0-9_\-]+$` (`size <= 128`), and every string field has strict `.size()` caps.
8. **Zero `get()`/`exists()` in `allow list`**: List rules evaluate `resource.data` and auth token claims only, avoiding O(n) rule lookup amplification.

## 2. The "Dirty Dozen" Adversarial Payloads

1. **Privilege Escalation on Profile Create**: `{ uid: "attacker", email: "a@example.com", role: "system_admin", ... }` -> **DENIED** (non-bootstrap user creating `role != "individual_member"`).
2. **Shadow Field Injection on Person**: `{ id: "p1", ..., isSuperAdmin: true }` -> **DENIED** (`keys().hasOnly(...)` rejects ghost fields).
3. **Email Spoofing (`email_verified == false`)**: Auth token with `email: "tom@ahyx.org", email_verified: false` -> **DENIED** (`request.auth.token.email_verified == true` required).
4. **PII Blanket List Scraping**: `list /people_sensitive` by any signed-in user -> **DENIED** (`allow list: if false;`).
5. **Technical Admin Reading Sensitive PII**: `get /people_sensitive/p1` with `role == "system_admin"` (not `unit_admin` or owner) -> **DENIED**.
6. **ID Poisoning**: Document ID of 200 chars or containing `../` -> **DENIED** (`isValidId()` fails).
7. **Denial-of-Wallet Oversized String**: `faultDescription` with 10,000 characters -> **DENIED** (`.size() <= 400` fails).
8. **Audit Log Tampering**: `update` or `delete` on `/audit_events/ev1` -> **DENIED** (`allow update, delete: if false;`).
9. **Stock Movement Ledger Mutation**: `update` or `delete` on `/stock_movements/mv1` -> **DENIED**.
10. **Self-Approval Attack**: User updates their own `leave_requests/lr1` directly to `status: "Approved"` -> **DENIED** (`ownerUid != request.auth.uid` on decision branch).
11. **Terminal State Replay**: Re-opening a `Completed` or `Rejected` request back to `Submitted` -> **DENIED**.
12. **Untrusted Executable Document Upload**: `documents` write with `mimeType: "application/x-msdownload"` or `sizeBytes: 999999999` -> **DENIED** (enum & numeric range guard).
