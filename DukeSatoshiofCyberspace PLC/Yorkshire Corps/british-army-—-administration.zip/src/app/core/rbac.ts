import {AppRole, PermissionAction} from './models';

export interface RoleDefinition {
  id: AppRole;
  label: string;
  scopeSummary: string;
  permissions: PermissionAction[];
}

export const ROLE_DEFINITIONS: Record<AppRole, RoleDefinition> = {
  individual_member: {
    id: 'individual_member',
    label: 'Individual Member',
    scopeSummary: 'Self-service records, personal requests, own sensitive profile only.',
    permissions: ['requests.submit'],
  },
  unit_admin: {
    id: 'unit_admin',
    label: 'Unit Administrator',
    scopeSummary: 'Unit establishment, personnel administration, postings, unit reports, sensitive clearance access.',
    permissions: [
      'personnel.create',
      'personnel.edit',
      'personnel.read_sensitive',
      'units.manage',
      'positions.assign',
      'requests.submit',
      'requests.approve',
      'equipment.custody',
      'stores.move',
      'reports.export',
      'audit.read',
    ],
  },
  training_admin: {
    id: 'training_admin',
    label: 'Training Administrator',
    scopeSummary: 'Course catalogue, enrolments, attendance, qualification awards, authorised result corrections.',
    permissions: [
      'training.manage',
      'training.correct_result',
      'requests.submit',
      'reports.export',
    ],
  },
  equipment_custodian: {
    id: 'equipment_custodian',
    label: 'Equipment Custodian',
    scopeSummary: 'Asset custody issue/return/transfer, stores inventory & movements, fault logging.',
    permissions: [
      'equipment.custody',
      'maintenance.work',
      'stores.move',
      'requests.submit',
      'reports.export',
    ],
  },
  maintenance_staff: {
    id: 'maintenance_staff',
    label: 'Maintenance Staff',
    scopeSummary: 'Work orders, preventive schedules, fault diagnosis, parts reservation, repair completion.',
    permissions: ['maintenance.work', 'stores.move', 'requests.submit'],
  },
  approver: {
    id: 'approver',
    label: 'Approver',
    scopeSummary: 'Request approvals, posting authority, independent maintenance release, sensitive clearance verification.',
    permissions: [
      'personnel.edit',
      'personnel.read_sensitive',
      'positions.assign',
      'requests.submit',
      'requests.approve',
      'maintenance.release',
      'reports.export',
    ],
  },
  auditor: {
    id: 'auditor',
    label: 'Auditor',
    scopeSummary: 'Read-only inspection of audit logs, immutable stock ledger, and data-quality reports.',
    permissions: ['audit.read', 'reports.export'],
  },
  system_admin: {
    id: 'system_admin',
    label: 'System Administrator',
    scopeSummary: 'Technical configuration, role governance, backups, sync inspection. Separated from unrestricted personal sensitive records.',
    permissions: [
      'personnel.create',
      'personnel.edit',
      'units.manage',
      'positions.assign',
      'training.manage',
      'training.correct_result',
      'equipment.custody',
      'maintenance.work',
      'maintenance.release',
      'stores.move',
      'requests.submit',
      'reports.export',
      'audit.read',
      'system.configure',
    ],
  },
};

export const ALL_ROLES: AppRole[] = [
  'unit_admin',
  'approver',
  'training_admin',
  'equipment_custodian',
  'maintenance_staff',
  'individual_member',
  'auditor',
  'system_admin',
];

export const ALL_PERMISSIONS: {action: PermissionAction; label: string}[] = [
  {action: 'personnel.create', label: 'Create Personnel'},
  {action: 'personnel.edit', label: 'Edit Core Posting'},
  {action: 'personnel.read_sensitive', label: 'View Sensitive PII'},
  {action: 'units.manage', label: 'Edit Unit Hierarchy'},
  {action: 'positions.assign', label: 'Assign Positions'},
  {action: 'training.manage', label: 'Manage Courses & Awards'},
  {action: 'training.correct_result', label: 'Correct Results (Reasoned)'},
  {action: 'requests.submit', label: 'Submit Requests'},
  {action: 'requests.approve', label: 'Approve / Reject Requests'},
  {action: 'equipment.custody', label: 'Issue / Transfer Custody'},
  {action: 'maintenance.work', label: 'Execute Work Orders'},
  {action: 'maintenance.release', label: 'Release Serviceable'},
  {action: 'stores.move', label: 'Post Stock Movements'},
  {action: 'reports.export', label: 'Export Authorised Reports'},
  {action: 'audit.read', label: 'Inspect Audit Log'},
  {action: 'system.configure', label: 'Technical Administration'},
];

export function hasPermission(role: AppRole, action: PermissionAction): boolean {
  return ROLE_DEFINITIONS[role]?.permissions.includes(action) ?? false;
}
