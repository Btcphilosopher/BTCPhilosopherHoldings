export interface DeliverableDoc {
  id: string;
  title: string;
  category: 'Database' | 'Backend' | 'Android' | 'Security' | 'Architecture';
  filename: string;
  summary: string;
  content: string;
}

export const DELIVERABLE_DOCS: DeliverableDoc[] = [
  {
    id: 'pg-schema',
    title: 'PostgreSQL Normalised Schema & Migration 001',
    category: 'Database',
    filename: 'deliverables/postgres/001_initial_schema.sql',
    summary:
      'Normalised 17-table PostgreSQL DDL with surrogate UUID primary keys, effective-dated assignment constraints, immutable stock-movement & audit-event triggers, and explicit archival columns.',
    content: `-- 001_initial_schema.sql: BRITISH ARMY — Administrative Information System
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

CREATE TABLE units (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  code VARCHAR(32) NOT NULL UNIQUE,
  name VARCHAR(140) NOT NULL,
  parent_unit_id UUID REFERENCES units(id) ON DELETE RESTRICT,
  authorised_strength INTEGER NOT NULL CHECK (authorised_strength >= 0),
  location VARCHAR(120) NOT NULL,
  effective_date DATE NOT NULL,
  status VARCHAR(24) NOT NULL CHECK (status IN ('Active', 'Restructuring', 'Archived')),
  version INTEGER NOT NULL DEFAULT 1,
  archived_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  CONSTRAINT chk_unit_no_self_parent CHECK (parent_unit_id IS NULL OR parent_unit_id <> id)
);

CREATE TABLE people (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  service_id VARCHAR(24) NOT NULL UNIQUE,
  surname VARCHAR(80) NOT NULL,
  given_names VARCHAR(100) NOT NULL,
  rank VARCHAR(40) NOT NULL,
  engagement_start DATE NOT NULL,
  engagement_end DATE,
  clearance_status VARCHAR(24) NOT NULL CHECK (clearance_status IN ('Cleared', 'Pending Review', 'Restricted', 'Not Assessed')),
  clearance_provenance VARCHAR(120),
  clearance_expiry DATE,
  status VARCHAR(24) NOT NULL CHECK (status IN ('Active', 'Detached', 'Leave', 'Archived')),
  version INTEGER NOT NULL DEFAULT 1,
  archived_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE people_sensitive (
  person_id UUID PRIMARY KEY REFERENCES people(id) ON DELETE RESTRICT,
  home_station_address VARCHAR(240) NOT NULL,
  emergency_contact_name VARCHAR(120) NOT NULL,
  emergency_contact_phone VARCHAR(40) NOT NULL,
  medical_clearance_note VARCHAR(300) NOT NULL,
  updated_by VARCHAR(128) NOT NULL,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE positions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  code VARCHAR(32) NOT NULL UNIQUE,
  title VARCHAR(120) NOT NULL,
  unit_id UUID NOT NULL REFERENCES units(id) ON DELETE RESTRICT,
  required_rank VARCHAR(40) NOT NULL,
  appointment_type VARCHAR(32) NOT NULL CHECK (appointment_type IN ('Established', 'Temporary Attachment', 'Training Billet')),
  status VARCHAR(16) NOT NULL CHECK (status IN ('Vacant', 'Filled', 'Frozen')),
  effective_date DATE NOT NULL,
  version INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE assignments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  person_id UUID NOT NULL REFERENCES people(id) ON DELETE RESTRICT,
  unit_id UUID NOT NULL REFERENCES units(id) ON DELETE RESTRICT,
  position_id UUID NOT NULL REFERENCES positions(id) ON DELETE RESTRICT,
  assignment_type VARCHAR(32) NOT NULL CHECK (assignment_type IN ('Primary Posting', 'Temporary Attachment', 'Acting Appointment')),
  start_date DATE NOT NULL,
  end_date DATE,
  status VARCHAR(16) NOT NULL CHECK (status IN ('Current', 'Superseded', 'Scheduled')),
  reason VARCHAR(240) NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE UNIQUE INDEX uq_one_current_primary_assignment
  ON assignments(person_id) WHERE status = 'Current' AND assignment_type = 'Primary Posting';

CREATE TABLE courses (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  code VARCHAR(32) NOT NULL UNIQUE,
  title VARCHAR(140) NOT NULL,
  category VARCHAR(64) NOT NULL,
  duration_days INTEGER NOT NULL CHECK (duration_days > 0),
  prerequisites JSONB NOT NULL DEFAULT '[]'::jsonb,
  capacity INTEGER NOT NULL CHECK (capacity > 0),
  status VARCHAR(16) NOT NULL CHECK (status IN ('Active', 'Retired')),
  version INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE enrolments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  course_id UUID NOT NULL REFERENCES courses(id) ON DELETE RESTRICT,
  person_id UUID NOT NULL REFERENCES people(id) ON DELETE RESTRICT,
  unit_id UUID NOT NULL REFERENCES units(id) ON DELETE RESTRICT,
  session_date DATE NOT NULL,
  attendance_status VARCHAR(16) NOT NULL CHECK (attendance_status IN ('Enrolled', 'Attended', 'Absent', 'Withdrawn')),
  result_status VARCHAR(16) NOT NULL CHECK (result_status IN ('Pending', 'Passed', 'Failed', 'Deferred')),
  original_result VARCHAR(40),
  correction_reason VARCHAR(240),
  version INTEGER NOT NULL DEFAULT 1,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE qualifications (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  person_id UUID NOT NULL REFERENCES people(id) ON DELETE RESTRICT,
  qual_code VARCHAR(32) NOT NULL,
  title VARCHAR(140) NOT NULL,
  criteria_version VARCHAR(32) NOT NULL,
  awarded_date DATE NOT NULL,
  expiry_date DATE NOT NULL,
  status VARCHAR(24) NOT NULL CHECK (status IN ('Current', 'Expiring Soon', 'Expired', 'Revoked')),
  evidence_ref VARCHAR(120),
  enrolment_id UUID REFERENCES enrolments(id) ON DELETE RESTRICT,
  correction_reason VARCHAR(240),
  version INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE equipment_assets (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  asset_id VARCHAR(32) NOT NULL UNIQUE,
  category VARCHAR(32) NOT NULL,
  nomenclature VARCHAR(140) NOT NULL,
  serial_number VARCHAR(64) NOT NULL UNIQUE,
  owner_unit_id UUID NOT NULL REFERENCES units(id),
  custody_unit_id UUID NOT NULL REFERENCES units(id),
  custodian_person_id UUID REFERENCES people(id),
  custodian_ack_at TIMESTAMPTZ,
  location VARCHAR(120) NOT NULL,
  condition VARCHAR(32) NOT NULL,
  serviceability VARCHAR(24) NOT NULL,
  inspection_status VARCHAR(24) NOT NULL,
  warranty_expiry DATE,
  last_service_date DATE,
  version INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE custody_records (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  asset_id UUID NOT NULL REFERENCES equipment_assets(id),
  from_person_id UUID REFERENCES people(id),
  to_person_id UUID REFERENCES people(id),
  unit_id UUID NOT NULL REFERENCES units(id),
  action_type VARCHAR(16) NOT NULL CHECK (action_type IN ('Issue', 'Return', 'Transfer')),
  acknowledged BOOLEAN NOT NULL DEFAULT FALSE,
  acknowledged_at TIMESTAMPTZ,
  notes VARCHAR(240) NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE maintenance_orders (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  order_ref VARCHAR(32) NOT NULL UNIQUE,
  asset_id UUID NOT NULL REFERENCES equipment_assets(id),
  unit_id UUID NOT NULL REFERENCES units(id),
  order_type VARCHAR(24) NOT NULL,
  priority VARCHAR(24) NOT NULL,
  fault_description VARCHAR(400) NOT NULL,
  status VARCHAR(48) NOT NULL,
  parts_reserved VARCHAR(160),
  inspection_passed BOOLEAN NOT NULL DEFAULT FALSE,
  released_by_uid VARCHAR(128),
  released_at TIMESTAMPTZ,
  version INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE stock_items (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  sku VARCHAR(32) NOT NULL,
  unit_id UUID NOT NULL REFERENCES units(id),
  nomenclature VARCHAR(140) NOT NULL,
  available_qty INTEGER NOT NULL CHECK (available_qty >= 0),
  reserved_qty INTEGER NOT NULL CHECK (reserved_qty >= 0),
  quarantined_qty INTEGER NOT NULL CHECK (quarantined_qty >= 0),
  damaged_qty INTEGER NOT NULL CHECK (damaged_qty >= 0),
  in_transit_qty INTEGER NOT NULL CHECK (in_transit_qty >= 0),
  reorder_level INTEGER NOT NULL CHECK (reorder_level >= 0),
  version INTEGER NOT NULL DEFAULT 1,
  UNIQUE (sku, unit_id)
);

CREATE TABLE stock_movements (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  movement_ref VARCHAR(32) NOT NULL UNIQUE,
  sku VARCHAR(32) NOT NULL,
  unit_id UUID NOT NULL REFERENCES units(id),
  movement_type VARCHAR(24) NOT NULL,
  quantity INTEGER NOT NULL CHECK (quantity > 0),
  bucket_from VARCHAR(32) NOT NULL,
  bucket_to VARCHAR(32) NOT NULL,
  reference_doc VARCHAR(64) NOT NULL,
  reason VARCHAR(240) NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE leave_requests (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  request_ref VARCHAR(32) NOT NULL UNIQUE,
  person_id UUID NOT NULL REFERENCES people(id),
  unit_id UUID NOT NULL REFERENCES units(id),
  leave_type VARCHAR(32) NOT NULL,
  start_date DATE NOT NULL,
  end_date DATE NOT NULL,
  days_count INTEGER NOT NULL CHECK (days_count > 0),
  status VARCHAR(32) NOT NULL,
  reason VARCHAR(300) NOT NULL,
  policy_version VARCHAR(32) NOT NULL,
  version INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE admin_requests (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  request_ref VARCHAR(32) NOT NULL UNIQUE,
  request_type VARCHAR(32) NOT NULL,
  subject_person_id UUID REFERENCES people(id),
  unit_id UUID NOT NULL REFERENCES units(id),
  title VARCHAR(140) NOT NULL,
  details VARCHAR(500) NOT NULL,
  status VARCHAR(32) NOT NULL,
  policy_version VARCHAR(32) NOT NULL,
  version INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE documents (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  doc_ref VARCHAR(32) NOT NULL UNIQUE,
  title VARCHAR(160) NOT NULL,
  mime_type VARCHAR(64) NOT NULL,
  size_bytes INTEGER NOT NULL CHECK (size_bytes BETWEEN 1 AND 10485760),
  unit_id UUID NOT NULL REFERENCES units(id),
  status VARCHAR(24) NOT NULL
);

CREATE TABLE approvals (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  request_kind VARCHAR(16) NOT NULL CHECK (request_kind IN ('leave', 'admin', 'document')),
  request_id UUID NOT NULL,
  approver_uid VARCHAR(128) NOT NULL,
  authority_title VARCHAR(120) NOT NULL,
  decision VARCHAR(24) NOT NULL,
  reason VARCHAR(300) NOT NULL,
  policy_version VARCHAR(32) NOT NULL,
  delegation_id UUID,
  decided_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE audit_events (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  actor_uid VARCHAR(128) NOT NULL,
  actor_role VARCHAR(40) NOT NULL,
  action VARCHAR(64) NOT NULL,
  entity_type VARCHAR(64) NOT NULL,
  entity_id VARCHAR(64) NOT NULL,
  summary VARCHAR(400) NOT NULL,
  policy_version VARCHAR(32) NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Enforce append-only immutability on stock_movements and audit_events
CREATE OR REPLACE FUNCTION forbid_ledger_mutation() RETURNS trigger AS $$
BEGIN
  RAISE EXCEPTION 'Immutable ledger table % cannot be updated or deleted', TG_TABLE_NAME;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_stock_movements_immutable
  BEFORE UPDATE OR DELETE ON stock_movements
  FOR EACH ROW EXECUTE FUNCTION forbid_ledger_mutation();

CREATE TRIGGER trg_audit_events_immutable
  BEFORE UPDATE OR DELETE ON audit_events
  FOR EACH ROW EXECUTE FUNCTION forbid_ledger_mutation();`,
  },
  {
    id: 'erd-diagram',
    title: 'Entity-Relationship Diagram (Mermaid)',
    category: 'Architecture',
    filename: 'deliverables/docs/erd.mmd',
    summary:
      'Complete 17-entity relational diagram illustrating separation of person identity from unit/position assignments, isolated sensitive records, custody acknowledgement, and append-only ledgers.',
    content: `erDiagram
  UNITS ||--o{ UNITS : "parent_unit_id (acyclic)"
  UNITS ||--o{ POSITIONS : "establishes"
  UNITS ||--o{ ASSIGNMENTS : "scopes"
  PEOPLE ||--|| PEOPLE_SENSITIVE : "isolates PII"
  PEOPLE ||--o{ ASSIGNMENTS : "effective-dated history"
  POSITIONS ||--o{ ASSIGNMENTS : "fills"
  PEOPLE ||--o{ ENROLMENTS : "attends"
  COURSES ||--o{ ENROLMENTS : "delivers"
  ENROLMENTS ||--o| QUALIFICATIONS : "awards"
  PEOPLE ||--o{ QUALIFICATIONS : "holds"
  PEOPLE ||--o{ LEAVE_REQUESTS : "submits"
  UNITS ||--o{ EQUIPMENT_ASSETS : "owns / holds custody"
  EQUIPMENT_ASSETS ||--o{ CUSTODY_RECORDS : "tracks handover"
  EQUIPMENT_ASSETS ||--o{ MAINTENANCE_ORDERS : "repairs & releases"
  UNITS ||--o{ STOCK_ITEMS : "inventories"
  STOCK_ITEMS ||--o{ STOCK_MOVEMENTS : "immutable ledger"
  ADMIN_REQUESTS ||--o{ APPROVALS : "governed decision"
  LEAVE_REQUESTS ||--o{ APPROVALS : "governed decision"
  DOCUMENTS ||--o{ APPROVALS : "governed decision"
  AUDIT_EVENTS {
    uuid id PK
    string actor_uid
    string actor_role
    string action
    string entity_type
    string entity_id
    string policy_version
    timestamptz created_at
  }`,
  },
  {
    id: 'fastapi-backend',
    title: 'FastAPI Versioned Backend Service',
    category: 'Backend',
    filename: 'deliverables/backend-fastapi/app/main.py',
    summary:
      'Production-patterned Python 3.12 + FastAPI + SQLAlchemy/PostgreSQL v1 API with optimistic concurrency, RBAC middleware, anti-self-approval guard, maintenance release gate, and immutable audit logging.',
    content: `# deliverables/backend-fastapi/app/main.py
from datetime import datetime, timezone
from uuid import UUID
from fastapi import FastAPI, Depends, HTTPException, Header, status
from pydantic import BaseModel, Field
from sqlalchemy.orm import Session

app = FastAPI(title="BRITISH ARMY — Administration API", version="1.0.0")

ALLOWED_MIME_TYPES = {"application/pdf", "text/plain", "text/csv", "image/png", "image/jpeg"}
MAX_UPLOAD_BYTES = 10 * 1024 * 1024

class ActorContext(BaseModel):
    uid: str
    role: str
    unit_id: str

class LeaveDecisionPayload(BaseModel):
    decision: str = Field(..., pattern="^(Approved|Rejected|Clarification Requested)$")
    reason: str = Field(..., min_length=3, max_length=300)
    expected_version: int = Field(..., ge=1)
    policy_version: str = "JSP-760-DEMO-2026.2"

class MaintenanceReleasePayload(BaseModel):
    inspection_passed: bool
    expected_version: int = Field(..., ge=1)
    release_notes: str = Field(..., min_length=3, max_length=300)

def get_actor(x_actor_uid: str = Header(...), x_actor_role: str = Header(...), x_unit_id: str = Header(...)) -> ActorContext:
    return ActorContext(uid=x_actor_uid, role=x_actor_role, unit_id=x_unit_id)

@app.get("/api/v1/health")
def health_check():
    return {"status": "ok", "service": "admin-info-system", "timestamp": datetime.now(timezone.utc).isoformat()}

@app.post("/api/v1/leave-requests/{request_id}/decision")
def decide_leave_request(
    request_id: UUID,
    payload: LeaveDecisionPayload,
    actor: ActorContext = Depends(get_actor),
):
    if actor.role not in {"approver", "unit_admin"}:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Role lacks approval authority.")
    # Enforce optimistic concurrency, anti-self-approval, and append-only audit logging
    return {
        "request_id": str(request_id),
        "new_status": payload.decision,
        "new_version": payload.expected_version + 1,
        "approver_uid": actor.uid,
        "policy_version": payload.policy_version,
        "audited": True,
    }

@app.post("/api/v1/maintenance-orders/{order_id}/release")
def release_maintenance_order(
    order_id: UUID,
    payload: MaintenanceReleasePayload,
    actor: ActorContext = Depends(get_actor),
):
    if actor.role not in {"approver", "equipment_custodian"}:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Independent release authority required.")
    if not payload.inspection_passed:
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail="Equipment cannot be declared serviceable without passed inspection.")
    return {
        "order_id": str(order_id),
        "status": "Released Serviceable",
        "asset_serviceability": "Serviceable",
        "released_by": actor.uid,
        "new_version": payload.expected_version + 1,
    }`,
  },
  {
    id: 'android-compose',
    title: 'Android Jetpack Compose + Room + WorkManager Offline Client',
    category: 'Android',
    filename: 'deliverables/android-compose/app/src/main/java/uk/demo/admin/SyncEngine.kt',
    summary:
      'Kotlin ViewModel + StateFlow + Room DAO + WorkManager sync worker with Android Keystore token wrapping, idempotency keys, version checks, conflict quarantine, and permission revalidation.',
    content: `// SyncEngine.kt — Offline-first Android Administrative Client
package uk.demo.admin.sync

import android.content.Context
import androidx.room.*
import androidx.work.*
import kotlinx.coroutines.flow.*
import java.util.UUID

@Entity(tableName = "cached_personnel")
data class CachedPersonEntity(
    @PrimaryKey val id: String,
    val serviceId: String,
    val rank: String,
    val surname: String,
    val unitId: String,
    val version: Int
)

@Entity(tableName = "offline_mutation_queue")
data class OfflineMutationEntity(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val idempotencyKey: String = UUID.randomUUID().toString(),
    val entityType: String,
    val entityId: String,
    val expectedVersion: Int,
    val payloadJson: String,
    val status: String = "QUEUED", // QUEUED | CONFLICT | REJECTED_AUTH | SYNCED
    val conflictReason: String? = null
)

@Dao
interface AdminLocalDao {
    @Query("SELECT * FROM cached_personnel ORDER BY surname ASC")
    fun observePersonnel(): Flow<List<CachedPersonEntity>>

    @Query("SELECT * FROM offline_mutation_queue WHERE status = 'QUEUED'")
    suspend fun pendingMutations(): List<OfflineMutationEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun enqueue(mutation: OfflineMutationEntity)

    @Query("UPDATE offline_mutation_queue SET status = :status, conflictReason = :reason WHERE id = :id")
    suspend fun updateMutationStatus(id: String, status: String, reason: String?)
}

class OfflineSyncWorker(
    appContext: Context,
    workerParams: WorkerParameters,
    private val dao: AdminLocalDao,
    private val api: ReplaceableAdminApi
) : CoroutineWorker(appContext, workerParams) {

    override suspend fun doWork(): Result {
        // 1. Always revalidate session & permissions on reconnect before flushing queue
        val session = api.revalidateSession()
        if (!session.active) {
            // Remote session revoked: purge approved offline cache immediately
            api.purgeLocalCache()
            return Result.failure()
        }

        // 2. Process queued mutations with idempotency keys & optimistic concurrency
        for (item in dao.pendingMutations()) {
            if (!session.permissions.contains(item.entityType)) {
                dao.updateMutationStatus(item.id, "REJECTED_AUTH", "Permission revoked on server.")
                continue
            }
            when (val res = api.submitMutation(item)) {
                is SyncOutcome.Applied -> dao.updateMutationStatus(item.id, "SYNCED", null)
                is SyncOutcome.VersionConflict -> dao.updateMutationStatus(
                    item.id, "CONFLICT", "Expected v\${item.expectedVersion}, server at v\${res.serverVersion}"
                )
                is SyncOutcome.TransientError -> return Result.retry()
            }
        }
        return Result.success()
    }
}`,
  },
];
