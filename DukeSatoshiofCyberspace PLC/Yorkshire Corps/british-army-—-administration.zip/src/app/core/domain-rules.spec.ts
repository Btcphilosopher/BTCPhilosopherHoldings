import {describe, expect, it} from 'vitest';
import {hasPermission} from './rbac';
import {buildSeedBundle} from './seed-data';

describe('BRITISH ARMY — Administrative Domain Invariants & RBAC', () => {
  it('separates technical system_admin from unrestricted sensitive PII access', () => {
    expect(hasPermission('system_admin', 'system.configure')).toBe(true);
    expect(hasPermission('system_admin', 'personnel.read_sensitive')).toBe(false);
    expect(hasPermission('unit_admin', 'personnel.read_sensitive')).toBe(true);
    expect(hasPermission('approver', 'personnel.read_sensitive')).toBe(true);
    expect(hasPermission('individual_member', 'requests.approve')).toBe(false);
  });

  it('enforces independent maintenance release authority', () => {
    expect(hasPermission('maintenance_staff', 'maintenance.work')).toBe(true);
    expect(hasPermission('maintenance_staff', 'maintenance.release')).toBe(false);
    expect(hasPermission('approver', 'maintenance.release')).toBe(true);
  });

  it('provides synthetic seed bundle with non-empty unique service IDs and separated sensitive PII', () => {
    const bundle = buildSeedBundle('uid-demo', 'tom@ahyx.org');
    const serviceIds = bundle.people.map((p) => p.serviceId);
    expect(new Set(serviceIds).size).toBe(serviceIds.length);
    expect(bundle.peopleSensitive.length).toBe(bundle.people.length);
  });

  it('enforces one current primary posting per person in seed assignments', () => {
    const bundle = buildSeedBundle('uid-demo', 'tom@ahyx.org');
    const primaryByPerson = new Map<string, number>();
    for (const a of bundle.assignments) {
      if (a.status === 'Current' && a.assignmentType === 'Primary Posting') {
        primaryByPerson.set(a.personId, (primaryByPerson.get(a.personId) ?? 0) + 1);
      }
    }
    for (const count of primaryByPerson.values()) {
      expect(count).toBe(1);
    }
  });

  it('separates attendance from qualification pass/fail and retains originalResult on correction', () => {
    const bundle = buildSeedBundle('uid-demo', 'tom@ahyx.org');
    const corrected = bundle.enrolments.find((e) => e.id === 'enr-003');
    expect(corrected?.attendanceStatus).toBe('Attended');
    expect(corrected?.resultStatus).toBe('Deferred');
    expect(corrected?.originalResult).toBe('Failed');
    expect(corrected?.correctionReason).toBeTruthy();
  });

  it('prevents custody conflicts by ensuring issued assets carry custodian acknowledgement', () => {
    const bundle = buildSeedBundle('uid-demo', 'tom@ahyx.org');
    const issued = bundle.equipmentAssets.filter((e) => Boolean(e.custodianPersonId));
    expect(issued.length).toBeGreaterThan(0);
    for (const asset of issued) {
      expect(asset.custodianAckAt).toBeTruthy();
    }
  });

  it('models 5 distinct stock quantity buckets and non-negative balances', () => {
    const bundle = buildSeedBundle('uid-demo', 'tom@ahyx.org');
    for (const item of bundle.stockItems) {
      expect(item.availableQty).toBeGreaterThanOrEqual(0);
      expect(item.reservedQty).toBeGreaterThanOrEqual(0);
      expect(item.quarantinedQty).toBeGreaterThanOrEqual(0);
      expect(item.damagedQty).toBeGreaterThanOrEqual(0);
      expect(item.inTransitQty).toBeGreaterThanOrEqual(0);
    }
  });
});
