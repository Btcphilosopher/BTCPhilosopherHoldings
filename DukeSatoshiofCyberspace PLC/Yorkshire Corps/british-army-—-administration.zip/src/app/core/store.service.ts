import {Injectable, PLATFORM_ID, computed, inject, signal} from '@angular/core';
import {isPlatformBrowser} from '@angular/common';
import {
  User,
  onAuthStateChanged,
  signInWithPopup,
  signOut as firebaseSignOut,
} from 'firebase/auth';
import {
  collection,
  doc,
  getDoc,
  getDocs,
  onSnapshot,
  query,
  setDoc,
  updateDoc,
  where,
  writeBatch,
  type Unsubscribe,
} from 'firebase/firestore';
import {
  OperationType,
  getDb,
  getFirebaseAuth,
  googleAuthProvider,
  handleFirestoreError,
  testFirestoreConnection,
} from './firebase';
import {
  AdminRequest,
  AppRole,
  Assignment,
  AuditEvent,
  Course,
  CustodyRecord,
  Delegation,
  DocumentRecord,
  Enrolment,
  EquipmentAsset,
  EquipmentCategory,
  LeaveRequest,
  MaintenanceOrder,
  OfflineQueueItem,
  PermissionAction,
  Person,
  PersonSensitive,
  Position,
  Qualification,
  StockItem,
  StockMovement,
  Unit,
  UserProfile,
} from './models';
import {ROLE_DEFINITIONS, hasPermission} from './rbac';
import {buildSeedBundle} from './seed-data';

export interface ToastMessage {
  id: string;
  kind: 'success' | 'error' | 'warning' | 'info';
  title: string;
  detail: string;
}

@Injectable({providedIn: 'root'})
export class StoreService {
  private readonly platformId = inject(PLATFORM_ID);
  private readonly isBrowser = isPlatformBrowser(this.platformId);

  // Auth & Session state
  readonly authReady = signal(false);
  readonly currentUser = signal<User | null>(null);
  readonly userProfile = signal<UserProfile | null>(null);
  readonly loadingData = signal(false);
  readonly seedingInProgress = signal(false);
  readonly offlineMode = signal(false);
  readonly remoteSessionRevoked = signal(false);

  // Normalized collections
  readonly units = signal<Unit[]>([]);
  readonly positions = signal<Position[]>([]);
  readonly people = signal<Person[]>([]);
  readonly assignments = signal<Assignment[]>([]);
  readonly courses = signal<Course[]>([]);
  readonly enrolments = signal<Enrolment[]>([]);
  readonly qualifications = signal<Qualification[]>([]);
  readonly leaveRequests = signal<LeaveRequest[]>([]);
  readonly adminRequests = signal<AdminRequest[]>([]);
  readonly equipmentAssets = signal<EquipmentAsset[]>([]);
  readonly custodyRecords = signal<CustodyRecord[]>([]);
  readonly maintenanceOrders = signal<MaintenanceOrder[]>([]);
  readonly stockItems = signal<StockItem[]>([]);
  readonly stockMovements = signal<StockMovement[]>([]);
  readonly documents = signal<DocumentRecord[]>([]);
  readonly delegations = signal<Delegation[]>([]);
  readonly auditEvents = signal<AuditEvent[]>([]);

  // Offline Queue & Simulated Conflict State
  readonly offlineQueue = signal<OfflineQueueItem[]>([]);
  readonly toast = signal<ToastMessage | null>(null);

  // Active Role & Effective Permissions
  readonly activeRole = computed<AppRole>(() => {
    const profile = this.userProfile();
    if (!profile) return 'individual_member';
    if (profile.role === 'system_admin' && profile.activeDemoRole) {
      return profile.activeDemoRole;
    }
    return profile.role;
  });

  readonly activeRoleLabel = computed(() => ROLE_DEFINITIONS[this.activeRole()].label);

  // Computed Operational KPIs
  readonly pendingRequestsCount = computed(
    () =>
      this.leaveRequests().filter((r) =>
        ['Submitted', 'Under Review', 'Clarification Requested'].includes(r.status),
      ).length +
      this.adminRequests().filter((r) =>
        ['Submitted', 'Under Review', 'Clarification Requested'].includes(r.status),
      ).length,
  );

  readonly expiringOrExpiredQualsCount = computed(
    () =>
      this.qualifications().filter(
        (q) => q.status === 'Expired' || q.status === 'Expiring Soon',
      ).length,
  );

  readonly openMaintenanceCount = computed(
    () =>
      this.maintenanceOrders().filter(
        (m) => m.status !== 'Released Serviceable' && m.status !== 'Closed Unserviceable',
      ).length,
  );

  readonly duplicateServiceIds = computed(() => {
    const counts = new Map<string, number>();
    for (const p of this.people()) {
      counts.set(p.serviceId, (counts.get(p.serviceId) ?? 0) + 1);
    }
    return Array.from(counts.entries())
      .filter(([, count]) => count > 1)
      .map(([id]) => id);
  });

  private unsubscribes: Unsubscribe[] = [];
  private listenersAttachedForUid: string | null = null;

  constructor() {
    if (this.isBrowser) {
      this.initFirebaseAuth();
    } else {
      this.authReady.set(true);
    }
  }

  private initFirebaseAuth(): void {
    testFirestoreConnection();
    const auth = getFirebaseAuth();
    onAuthStateChanged(auth, async (user) => {
      this.currentUser.set(user);
      if (!user) {
        this.userProfile.set(null);
        this.detachListeners();
        this.clearCollections();
        this.authReady.set(true);
        return;
      }

      try {
        await this.ensureUserProfile(user);
        this.attachCollectionListeners(user);
        await this.ensureDemoSeeded(user);
      } catch (err) {
        const message = err instanceof Error ? err.message : String(err);
        this.notify('error', 'Initialization Issue', message);
      } finally {
        this.authReady.set(true);
      }
    });
  }

  async signInWithGoogle(): Promise<void> {
    if (!this.isBrowser) return;
    try {
      const auth = getFirebaseAuth();
      this.remoteSessionRevoked.set(false);
      await signInWithPopup(auth, googleAuthProvider);
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Sign-in cancelled or failed.';
      this.notify('error', 'Authentication Failed', msg);
    }
  }

  async signOut(): Promise<void> {
    if (!this.isBrowser) return;
    this.detachListeners();
    await firebaseSignOut(getFirebaseAuth());
    this.notify('info', 'Signed Out', 'Session closed and local tokens cleared.');
  }

  can(action: PermissionAction): boolean {
    return hasPermission(this.activeRole(), action);
  }

  private assertPerm(action: PermissionAction, contextLabel: string): boolean {
    if (this.remoteSessionRevoked()) {
      this.notify(
        'error',
        'Session Revoked',
        'Remote session revocation is active. Sign out and re-authenticate before performing changes.',
      );
      return false;
    }
    if (!this.can(action)) {
      this.notify(
        'error',
        'Access Denied (RBAC Policy)',
        `Active role "${this.activeRoleLabel()}" is not authorised to ${contextLabel}.`,
      );
      void this.logAudit(
        'ACCESS_DENIED',
        'rbac',
        action,
        `Denied "${this.activeRole()}" attempt to ${contextLabel}.`,
      );
      return false;
    }
    return true;
  }

  notify(kind: ToastMessage['kind'], title: string, detail: string): void {
    this.toast.set({
      id: `${Date.now()}`,
      kind,
      title,
      detail,
    });
  }

  clearToast(): void {
    this.toast.set(null);
  }

  private async ensureUserProfile(user: User): Promise<void> {
    const db = getDb();
    const userRef = doc(db, 'users', user.uid);
    const snap = await getDoc(userRef);
    const now = new Date().toISOString();
    const isBootstrap = user.email === 'tom@ahyx.org' && user.emailVerified;

    if (!snap.exists()) {
      const profile: UserProfile = {
        uid: user.uid,
        email: user.email ?? 'operator@demo.local',
        displayName: user.displayName ?? (user.email ? user.email.split('@')[0] : 'Operator'),
        role: isBootstrap ? 'system_admin' : 'individual_member',
        ...(isBootstrap ? {activeDemoRole: 'unit_admin' as AppRole} : {}),
        unitId: 'unit-hq-demo',
        personId: 'per-001',
        createdAt: now,
        updatedAt: now,
      };
      try {
        await setDoc(userRef, profile);
        this.userProfile.set(profile);
      } catch (e) {
        handleFirestoreError(e, OperationType.CREATE, `users/${user.uid}`);
      }
    } else {
      const existing = snap.data() as UserProfile;
      this.userProfile.set(existing);
    }
  }

  async switchDemoRole(newRole: AppRole): Promise<void> {
    const profile = this.userProfile();
    const user = this.currentUser();
    if (!profile || !user) return;
    if (profile.role !== 'system_admin' && user.email !== 'tom@ahyx.org') {
      this.notify(
        'error',
        'Role Switch Restricted',
        'Only System Administrators may switch demonstration personas.',
      );
      return;
    }

    const db = getDb();
    const now = new Date().toISOString();
    try {
      await updateDoc(doc(db, 'users', user.uid), {
        activeDemoRole: newRole,
        updatedAt: now,
      });
      this.userProfile.set({...profile, activeDemoRole: newRole, updatedAt: now});
      await this.logAudit(
        'DEMO_ROLE_SWITCHED',
        'users',
        user.uid,
        `Active demonstration role changed to ${ROLE_DEFINITIONS[newRole].label}.`,
      );
      this.notify(
        'info',
        'Active Role Switched',
        `Operating as ${ROLE_DEFINITIONS[newRole].label}. Permissions updated immediately.`,
      );
    } catch (e) {
      handleFirestoreError(e, OperationType.UPDATE, `users/${user.uid}`);
    }
  }

  private attachCollectionListeners(user: User): void {
    if (this.listenersAttachedForUid === user.uid) return;
    this.detachListeners();
    this.listenersAttachedForUid = user.uid;
    this.loadingData.set(true);

    const db = getDb();
    const isBootstrap = user.email === 'tom@ahyx.org';

    const bindCollection = <T>(
      colName: string,
      setter: (items: T[]) => void,
      ownerFilterField = 'ownerUid',
    ) => {
      const colRef = collection(db, colName);
      const q = isBootstrap ? colRef : query(colRef, where(ownerFilterField, '==', user.uid));
      const unsub = onSnapshot(
        q,
        (snapshot) => {
          const rows = snapshot.docs.map((d) => d.data() as T);
          setter(rows);
          this.loadingData.set(false);
        },
        (error) => {
          this.loadingData.set(false);
          handleFirestoreError(error, OperationType.GET, colName);
        },
      );
      this.unsubscribes.push(unsub);
    };

    const userUnsub = onSnapshot(
      doc(db, 'users', user.uid),
      (snap) => {
        if (snap.exists()) {
          this.userProfile.set(snap.data() as UserProfile);
        }
      },
      (err) => handleFirestoreError(err, OperationType.GET, `users/${user.uid}`),
    );
    this.unsubscribes.push(userUnsub);

    bindCollection<Unit>('units', (v) => this.units.set(v));
    bindCollection<Position>('positions', (v) => this.positions.set(v));
    bindCollection<Person>('people', (v) => this.people.set(v));
    bindCollection<Assignment>('assignments', (v) => this.assignments.set(v));
    bindCollection<Course>('courses', (v) => this.courses.set(v));
    bindCollection<Enrolment>('enrolments', (v) => this.enrolments.set(v));
    bindCollection<Qualification>('qualifications', (v) => this.qualifications.set(v));
    bindCollection<LeaveRequest>('leave_requests', (v) => this.leaveRequests.set(v));
    bindCollection<AdminRequest>('admin_requests', (v) => this.adminRequests.set(v));
    bindCollection<EquipmentAsset>('equipment_assets', (v) => this.equipmentAssets.set(v));
    bindCollection<CustodyRecord>('custody_records', (v) => this.custodyRecords.set(v));
    bindCollection<MaintenanceOrder>('maintenance_orders', (v) => this.maintenanceOrders.set(v));
    bindCollection<StockItem>('stock_items', (v) => this.stockItems.set(v));
    bindCollection<StockMovement>('stock_movements', (v) => this.stockMovements.set(v));
    bindCollection<DocumentRecord>('documents', (v) => this.documents.set(v));
    bindCollection<Delegation>('delegations', (v) => this.delegations.set(v));
    bindCollection<AuditEvent>('audit_events', (v) =>
      this.auditEvents.set([...v].sort((a, b) => b.timestamp.localeCompare(a.timestamp))),
    );
  }

  private detachListeners(): void {
    for (const unsub of this.unsubscribes) {
      unsub();
    }
    this.unsubscribes = [];
    this.listenersAttachedForUid = null;
  }

  private clearCollections(): void {
    this.units.set([]);
    this.positions.set([]);
    this.people.set([]);
    this.assignments.set([]);
    this.courses.set([]);
    this.enrolments.set([]);
    this.qualifications.set([]);
    this.leaveRequests.set([]);
    this.adminRequests.set([]);
    this.equipmentAssets.set([]);
    this.custodyRecords.set([]);
    this.maintenanceOrders.set([]);
    this.stockItems.set([]);
    this.stockMovements.set([]);
    this.documents.set([]);
    this.delegations.set([]);
    this.auditEvents.set([]);
  }

  private async ensureDemoSeeded(user: User): Promise<void> {
    const db = getDb();
    const existing = await getDocs(
      user.email === 'tom@ahyx.org'
        ? collection(db, 'units')
        : query(collection(db, 'units'), where('ownerUid', '==', user.uid)),
    );
    if (!existing.empty) return;
    await this.seedDemoEnvironment(user);
  }

  async seedDemoEnvironment(userOverride?: User): Promise<void> {
    const user = userOverride ?? this.currentUser();
    if (!user) return;
    this.seedingInProgress.set(true);
    const db = getDb();
    const bundle = buildSeedBundle(user.uid, user.email ?? 'operator@demo.local');

    try {
      const batch = writeBatch(db);
      for (const u of bundle.units) batch.set(doc(db, 'units', u.id), u);
      for (const p of bundle.positions) batch.set(doc(db, 'positions', p.id), p);
      for (const per of bundle.people) batch.set(doc(db, 'people', per.id), per);
      for (const ps of bundle.peopleSensitive) batch.set(doc(db, 'people_sensitive', ps.personId), ps);
      for (const a of bundle.assignments) batch.set(doc(db, 'assignments', a.id), a);
      for (const c of bundle.courses) batch.set(doc(db, 'courses', c.id), c);
      for (const e of bundle.enrolments) batch.set(doc(db, 'enrolments', e.id), e);
      for (const q of bundle.qualifications) batch.set(doc(db, 'qualifications', q.id), q);
      for (const lr of bundle.leaveRequests) batch.set(doc(db, 'leave_requests', lr.id), lr);
      for (const ar of bundle.adminRequests) batch.set(doc(db, 'admin_requests', ar.id), ar);
      for (const eq of bundle.equipmentAssets) batch.set(doc(db, 'equipment_assets', eq.id), eq);
      for (const cr of bundle.custodyRecords) batch.set(doc(db, 'custody_records', cr.id), cr);
      for (const mo of bundle.maintenanceOrders) batch.set(doc(db, 'maintenance_orders', mo.id), mo);
      for (const si of bundle.stockItems) batch.set(doc(db, 'stock_items', si.id), si);
      for (const sm of bundle.stockMovements) batch.set(doc(db, 'stock_movements', sm.id), sm);
      for (const d of bundle.documents) batch.set(doc(db, 'documents', d.id), d);
      for (const del of bundle.delegations) batch.set(doc(db, 'delegations', del.id), del);
      for (const ev of bundle.auditEvents) batch.set(doc(db, 'audit_events', ev.id), ev);
      await batch.commit();
      this.notify(
        'success',
        'Synthetic Demonstration Seeded',
        'Populated 4 units, 8 personnel, courses, equipment assets, stock ledger, and governed requests.',
      );
    } catch (e) {
      handleFirestoreError(e, OperationType.WRITE, 'seed_bundle');
    } finally {
      this.seedingInProgress.set(false);
    }
  }

  async logAudit(
    action: string,
    entityType: string,
    entityId: string,
    summary: string,
    policyVersion = 'ADMIN-POL-2026.1',
  ): Promise<void> {
    const user = this.currentUser();
    if (!user) return;
    const db = getDb();
    const id = `aud-${Date.now()}-${Math.floor(Math.random() * 1000)}`;
    const event: AuditEvent = {
      id,
      actorUid: user.uid,
      actorEmail: user.email ?? 'unknown@demo',
      actorRole: this.activeRole(),
      action,
      entityType,
      entityId,
      summary: summary.slice(0, 400),
      policyVersion,
      ownerUid: user.uid,
      timestamp: new Date().toISOString(),
    };
    try {
      await setDoc(doc(db, 'audit_events', id), event);
    } catch (e) {
      handleFirestoreError(e, OperationType.CREATE, `audit_events/${id}`);
    }
  }

  // --- PERSONNEL OPERATIONS ---

  async loadPersonSensitive(personId: string): Promise<PersonSensitive | null> {
    if (!this.assertPerm('personnel.read_sensitive', 'view narrow-permission sensitive clearance details')) {
      return null;
    }
    const db = getDb();
    try {
      const snap = await getDoc(doc(db, 'people_sensitive', personId));
      await this.logAudit(
        'SENSITIVE_RECORD_VIEWED',
        'people_sensitive',
        personId,
        `Authorised sensitive clearance inspection for ${personId}.`,
      );
      return snap.exists() ? (snap.data() as PersonSensitive) : null;
    } catch (e) {
      handleFirestoreError(e, OperationType.GET, `people_sensitive/${personId}`);
    }
  }

  async createPerson(input: {
    serviceId: string;
    surname: string;
    givenNames: string;
    rank: string;
    engagementStart: string;
    clearanceStatus: Person['clearanceStatus'];
    clearanceProvenance: string;
    contactEmail: string;
    homeStationAddress: string;
    emergencyContactName: string;
    emergencyContactPhone: string;
  }): Promise<Person | null> {
    if (!this.assertPerm('personnel.create', 'create personnel records')) return null;
    const user = this.currentUser();
    if (!user) return null;

    const cleanServiceId = input.serviceId.trim().toUpperCase();
    if (this.people().some((p) => p.serviceId.toUpperCase() === cleanServiceId)) {
      this.notify(
        'error',
        'Duplicate Service Identifier Blocked',
        `Service ID "${cleanServiceId}" already exists. Names are never unique keys; each person requires a unique service identifier.`,
      );
      await this.logAudit(
        'DUPLICATE_IDENTIFIER_BLOCKED',
        'people',
        cleanServiceId,
        `Blocked duplicate personnel creation for serviceId ${cleanServiceId}.`,
      );
      return null;
    }

    const now = new Date().toISOString();
    const id = `per-${Date.now()}`;
    const person: Person = {
      id,
      serviceId: cleanServiceId,
      surname: input.surname.trim(),
      givenNames: input.givenNames.trim(),
      rank: input.rank.trim(),
      engagementStart: input.engagementStart,
      clearanceStatus: input.clearanceStatus,
      clearanceProvenance: input.clearanceProvenance.trim() || 'Initial Administrative Entry',
      contactEmail: input.contactEmail.trim(),
      status: 'Active',
      version: 1,
      ownerUid: user.uid,
      createdAt: now,
      updatedAt: now,
    };

    const sensitive: PersonSensitive = {
      personId: id,
      ownerUid: user.uid,
      homeStationAddress: input.homeStationAddress.trim() || 'Demo Station Quarters',
      emergencyContactName: input.emergencyContactName.trim() || 'Recorded Next of Kin (Demo)',
      emergencyContactPhone: input.emergencyContactPhone.trim() || '+44 7700 900999',
      medicalClearanceNote:
        input.clearanceStatus === 'Not Assessed'
          ? 'No clearance recorded; suitability must not be inferred from absence.'
          : `Administrative clearance status: ${input.clearanceStatus}. Provenance: ${person.clearanceProvenance}`,
      updatedBy: user.email ?? user.uid,
      updatedAt: now,
    };

    const db = getDb();
    try {
      const batch = writeBatch(db);
      batch.set(doc(db, 'people', id), person);
      batch.set(doc(db, 'people_sensitive', id), sensitive);
      await batch.commit();
      await this.logAudit(
        'PERSON_CREATED',
        'people',
        id,
        `Created personnel record ${person.rank} ${person.surname} (${person.serviceId}).`,
      );
      this.notify('success', 'Personnel Record Created', `${person.rank} ${person.surname} (${person.serviceId}) added.`);
      return person;
    } catch (e) {
      handleFirestoreError(e, OperationType.CREATE, `people/${id}`);
    }
  }

  // --- UNITS & POSITIONS ---

  wouldCreateUnitCycle(unitId: string, proposedParentId: string): boolean {
    if (!proposedParentId) return false;
    if (proposedParentId === unitId) return true;
    const byId = new Map(this.units().map((u) => [u.id, u]));
    let curr: string | undefined = proposedParentId;
    const visited = new Set<string>();
    while (curr) {
      if (curr === unitId) return true;
      if (visited.has(curr)) return true;
      visited.add(curr);
      curr = byId.get(curr)?.parentUnitId;
    }
    return false;
  }

  async createUnit(input: {
    code: string;
    name: string;
    parentUnitId?: string;
    authorisedStrength: number;
    location: string;
    effectiveDate: string;
  }): Promise<Unit | null> {
    if (!this.assertPerm('units.manage', 'create or restructure units')) return null;
    const user = this.currentUser();
    if (!user) return null;

    const id = `unit-${Date.now()}`;
    if (input.parentUnitId && this.wouldCreateUnitCycle(id, input.parentUnitId)) {
      this.notify('error', 'Circular Hierarchy Blocked', 'Parent unit selection would create an organisational cycle.');
      return null;
    }

    const now = new Date().toISOString();
    const unit: Unit = {
      id,
      code: input.code.trim().toUpperCase(),
      name: input.name.trim(),
      ...(input.parentUnitId ? {parentUnitId: input.parentUnitId} : {}),
      authorisedStrength: Number(input.authorisedStrength),
      location: input.location.trim(),
      effectiveDate: input.effectiveDate,
      status: 'Active',
      version: 1,
      ownerUid: user.uid,
      createdAt: now,
      updatedAt: now,
    };

    const db = getDb();
    try {
      await setDoc(doc(db, 'units', id), unit);
      await this.logAudit('UNIT_CREATED', 'units', id, `Established unit ${unit.code} (${unit.name}).`);
      this.notify('success', 'Unit Created', `${unit.code} — ${unit.name}`);
      return unit;
    } catch (e) {
      handleFirestoreError(e, OperationType.CREATE, `units/${id}`);
    }
  }

  async createPosition(input: {
    code: string;
    title: string;
    unitId: string;
    requiredRank: string;
    appointmentType: Position['appointmentType'];
    effectiveDate: string;
  }): Promise<Position | null> {
    if (!this.assertPerm('units.manage', 'create establishment positions')) return null;
    const user = this.currentUser();
    if (!user) return null;

    const id = `pos-${Date.now()}`;
    const now = new Date().toISOString();
    const position: Position = {
      id,
      code: input.code.trim().toUpperCase(),
      title: input.title.trim(),
      unitId: input.unitId,
      requiredRank: input.requiredRank.trim(),
      appointmentType: input.appointmentType,
      status: 'Vacant',
      effectiveDate: input.effectiveDate,
      version: 1,
      ownerUid: user.uid,
      createdAt: now,
      updatedAt: now,
    };

    const db = getDb();
    try {
      await setDoc(doc(db, 'positions', id), position);
      await this.logAudit('POSITION_ESTABLISHED', 'positions', id, `Created ${position.appointmentType} billet ${position.code} (${position.title}).`);
      this.notify('success', 'Position Created', `${position.code} — ${position.title} added as Vacant.`);
      return position;
    } catch (e) {
      handleFirestoreError(e, OperationType.CREATE, `positions/${id}`);
    }
  }

  async assignPersonToPosition(input: {
    personId: string;
    positionId: string;
    assignmentType: Assignment['assignmentType'];
    startDate: string;
    reason: string;
  }): Promise<boolean> {
    if (!this.assertPerm('positions.assign', 'assign personnel to establishment positions')) return false;
    const user = this.currentUser();
    if (!user) return false;

    const person = this.people().find((p) => p.id === input.personId);
    const position = this.positions().find((pos) => pos.id === input.positionId);
    if (!person || !position) return false;

    if (position.status === 'Filled' && position.assignedPersonId && position.assignedPersonId !== person.id) {
      this.notify(
        'error',
        'Position Already Filled',
        `Position ${position.code} is already filled. Vacate or supersede existing incumbent before reassigning.`,
      );
      return false;
    }

    const now = new Date().toISOString();
    const db = getDb();
    const batch = writeBatch(db);

    if (input.assignmentType === 'Primary Posting') {
      // Supersede any current primary assignment and vacate prior position
      const priorAssignments = this.assignments().filter(
        (a) => a.personId === person.id && a.status === 'Current' && a.assignmentType === 'Primary Posting',
      );
      for (const prior of priorAssignments) {
        batch.update(doc(db, 'assignments', prior.id), {
          status: 'Superseded',
          endDate: input.startDate,
        });
        const priorPos = this.positions().find((pos) => pos.id === prior.positionId);
        if (priorPos && priorPos.id !== position.id) {
          batch.update(doc(db, 'positions', priorPos.id), {
            status: 'Vacant',
            assignedPersonId: '',
            version: priorPos.version + 1,
            updatedAt: now,
          });
        }
      }

      batch.update(doc(db, 'people', person.id), {
        primaryUnitId: position.unitId,
        primaryPositionId: position.id,
        version: person.version + 1,
        updatedAt: now,
      });
    }

    batch.update(doc(db, 'positions', position.id), {
      status: 'Filled',
      assignedPersonId: person.id,
      version: position.version + 1,
      updatedAt: now,
    });

    const asgId = `asg-${Date.now()}`;
    const assignment: Assignment = {
      id: asgId,
      personId: person.id,
      unitId: position.unitId,
      positionId: position.id,
      assignmentType: input.assignmentType,
      startDate: input.startDate,
      status: 'Current',
      reason: input.reason.trim() || 'Authorised unit establishment posting',
      ownerUid: user.uid,
      createdAt: now,
    };
    batch.set(doc(db, 'assignments', asgId), assignment);

    try {
      await batch.commit();
      await this.logAudit(
        'POSITION_ASSIGNED',
        'assignments',
        asgId,
        `Assigned ${person.rank} ${person.surname} (${person.serviceId}) to ${position.code} (${input.assignmentType}).`,
      );
      this.notify(
        'success',
        'Assignment Recorded',
        `${person.rank} ${person.surname} posted to ${position.code} — ${position.title}.`,
      );
      return true;
    } catch (e) {
      handleFirestoreError(e, OperationType.WRITE, 'assignments_batch');
    }
  }

  // --- TRAINING & QUALIFICATIONS ---

  async enrolInCourse(input: {
    courseId: string;
    personId: string;
    sessionDate: string;
  }): Promise<Enrolment | null> {
    if (!this.assertPerm('training.manage', 'enrol personnel on courses')) return null;
    const user = this.currentUser();
    if (!user) return null;

    const course = this.courses().find((c) => c.id === input.courseId);
    const person = this.people().find((p) => p.id === input.personId);
    if (!course || !person) return null;

    // Verify prerequisites
    const heldQualCodes = new Set(
      this.qualifications()
        .filter((q) => q.personId === person.id && q.status !== 'Revoked' && q.status !== 'Expired')
        .map((q) => q.qualCode),
    );
    const missingPrereqs = course.prerequisites.filter((req) => !heldQualCodes.has(req));
    if (missingPrereqs.length > 0) {
      this.notify(
        'warning',
        'Prerequisite Warning',
        `${person.rank} ${person.surname} does not hold prerequisite ${missingPrereqs.join(', ')} for ${course.code}. Enrolment blocked by policy.`,
      );
      return null;
    }

    const now = new Date().toISOString();
    const id = `enr-${Date.now()}`;
    const enrolment: Enrolment = {
      id,
      courseId: course.id,
      personId: person.id,
      unitId: person.primaryUnitId ?? 'unit-hq-demo',
      sessionDate: input.sessionDate,
      attendanceStatus: 'Enrolled',
      resultStatus: 'Pending',
      version: 1,
      ownerUid: user.uid,
      createdAt: now,
      updatedAt: now,
    };

    const db = getDb();
    try {
      await setDoc(doc(db, 'enrolments', id), enrolment);
      await this.logAudit(
        'COURSE_ENROLLED',
        'enrolments',
        id,
        `Enrolled ${person.serviceId} on ${course.code} (${course.title}) for ${input.sessionDate}.`,
      );
      this.notify('success', 'Course Enrolment Recorded', `${person.rank} ${person.surname} enrolled on ${course.code}.`);
      return enrolment;
    } catch (e) {
      handleFirestoreError(e, OperationType.CREATE, `enrolments/${id}`);
    }
  }

  async updateEnrolmentOutcome(input: {
    enrolmentId: string;
    attendanceStatus: Enrolment['attendanceStatus'];
    resultStatus: Enrolment['resultStatus'];
    awardExpiryDate?: string;
    evidenceRef?: string;
    correctionReason?: string;
  }): Promise<boolean> {
    const isCorrection = Boolean(input.correctionReason?.trim());
    if (isCorrection) {
      if (!this.assertPerm('training.correct_result', 'correct training results with reason')) return false;
    } else {
      if (!this.assertPerm('training.manage', 'update attendance and assessment results')) return false;
    }

    const user = this.currentUser();
    if (!user) return false;
    const enr = this.enrolments().find((e) => e.id === input.enrolmentId);
    if (!enr) return false;

    if (enr.resultStatus !== 'Pending' && enr.resultStatus !== input.resultStatus && !input.correctionReason?.trim()) {
      this.notify(
        'error',
        'Correction Reason Required',
        'Existing assessment results cannot be silently overwritten. Provide a formal correction reason.',
      );
      return false;
    }

    if (input.resultStatus === 'Passed' && input.attendanceStatus !== 'Attended') {
      this.notify(
        'error',
        'Attendance Required Before Pass',
        'Attendance and qualification pass are tracked separately; attendance must be marked Attended before recording Passed.',
      );
      return false;
    }

    const now = new Date().toISOString();
    const db = getDb();
    const batch = writeBatch(db);

    const updateFields: Partial<Enrolment> = {
      attendanceStatus: input.attendanceStatus,
      resultStatus: input.resultStatus,
      version: enr.version + 1,
      updatedAt: now,
    };
    if (enr.resultStatus !== 'Pending' && enr.resultStatus !== input.resultStatus) {
      updateFields.originalResult = enr.originalResult ?? enr.resultStatus;
      updateFields.correctionReason = input.correctionReason?.trim();
    }
    batch.update(doc(db, 'enrolments', enr.id), updateFields);

    const course = this.courses().find((c) => c.id === enr.courseId);
    let awardedQualId: string | null = null;
    if (input.resultStatus === 'Passed' && course) {
      const qualId = `qual-${Date.now()}`;
      awardedQualId = qualId;
      const expiry =
        input.awardExpiryDate ||
        new Date(Date.now() + 365 * 2 * 24 * 3600 * 1000).toISOString().slice(0, 10);
      const qual: Qualification = {
        id: qualId,
        personId: enr.personId,
        qualCode: course.code,
        title: course.title,
        criteriaVersion: `2026.${course.version}`,
        awardedDate: now.slice(0, 10),
        expiryDate: expiry,
        status: 'Current',
        evidenceRef: input.evidenceRef?.trim() || `CERT-${course.code}-${now.slice(0, 10).replaceAll('-', '')}`,
        enrolmentId: enr.id,
        version: 1,
        ownerUid: user.uid,
        createdAt: now,
        updatedAt: now,
      };
      batch.set(doc(db, 'qualifications', qualId), qual);
    }

    try {
      await batch.commit();
      await this.logAudit(
        isCorrection ? 'RESULT_CORRECTED_WITH_REASON' : 'TRAINING_OUTCOME_RECORDED',
        'enrolments',
        enr.id,
        `Updated ${enr.id}: Attendance=${input.attendanceStatus}, Result=${input.resultStatus}${awardedQualId ? `, Awarded ${awardedQualId}` : ''}.`,
        'TRG-POL-2026.2',
      );
      this.notify(
        'success',
        awardedQualId ? 'Qualification Awarded' : 'Enrolment Updated',
        awardedQualId
          ? `Recorded Passed and awarded versioned qualification (${course?.code}).`
          : `Attendance=${input.attendanceStatus}, Result=${input.resultStatus}.`,
      );
      return true;
    } catch (e) {
      handleFirestoreError(e, OperationType.WRITE, `enrolments/${enr.id}`);
    }
  }

  // --- LEAVE & ADMINISTRATIVE REQUESTS ---

  async submitLeaveRequest(input: {
    personId: string;
    leaveType: LeaveRequest['leaveType'];
    startDate: string;
    endDate: string;
    daysCount: number;
    reason: string;
    asDraft?: boolean;
  }): Promise<LeaveRequest | null> {
    if (!this.assertPerm('requests.submit', 'submit leave requests')) return null;
    const user = this.currentUser();
    if (!user) return null;
    const person = this.people().find((p) => p.id === input.personId);
    if (!person) return null;

    const now = new Date().toISOString();
    const id = `lv-${Date.now()}`;
    const req: LeaveRequest = {
      id,
      requestRef: `LVE-2026-${String(Math.floor(1000 + Math.random() * 9000))}`,
      personId: person.id,
      unitId: person.primaryUnitId ?? 'unit-hq-demo',
      leaveType: input.leaveType,
      startDate: input.startDate,
      endDate: input.endDate,
      daysCount: Math.max(1, Number(input.daysCount)),
      status: input.asDraft ? 'Draft' : 'Submitted',
      reason: input.reason.trim(),
      policyVersion: 'JSP-760-DEMO-2026.2',
      version: 1,
      ownerUid: user.uid,
      createdAt: now,
      updatedAt: now,
    };

    const db = getDb();
    try {
      await setDoc(doc(db, 'leave_requests', id), req);
      await this.logAudit(
        'LEAVE_REQUEST_CREATED',
        'leave_requests',
        id,
        `Created ${req.requestRef} (${req.leaveType}, ${req.daysCount}d) for ${person.serviceId} [${req.status}].`,
        req.policyVersion,
      );
      this.notify('success', 'Leave Request Recorded', `${req.requestRef} (${req.status}).`);
      return req;
    } catch (e) {
      handleFirestoreError(e, OperationType.CREATE, `leave_requests/${id}`);
    }
  }

  async transitionLeaveRequest(
    requestId: string,
    targetStatus: LeaveRequest['status'],
    note: string,
  ): Promise<boolean> {
    const req = this.leaveRequests().find((r) => r.id === requestId);
    const user = this.currentUser();
    if (!req || !user) return false;

    const isDecision = ['Under Review', 'Clarification Requested', 'Approved', 'Rejected', 'Completed'].includes(
      targetStatus,
    );
    if (isDecision) {
      if (!this.assertPerm('requests.approve', 'review or approve leave requests')) return false;
      // Enforce anti-self-approval when user's linked personId matches the subject
      if (this.userProfile()?.personId === req.personId && this.activeRole() === 'individual_member') {
        this.notify('error', 'Self-Approval Prohibited', 'Personnel cannot approve their own restricted requests.');
        return false;
      }
    }

    const activeDelegation = this.delegations().find(
      (d) => d.status === 'Active' && d.unitScope === req.unitId,
    );
    const now = new Date().toISOString();
    const db = getDb();

    try {
      await updateDoc(doc(db, 'leave_requests', req.id), {
        status: targetStatus,
        ...(isDecision
          ? {
              approverUid: user.uid,
              approverAuthority: `${this.activeRoleLabel()} (${user.email ?? user.uid})`,
              ...(targetStatus === 'Clarification Requested'
                ? {clarificationNote: note.trim() || 'Clarification requested by approving authority.'}
                : {decisionReason: note.trim() || `Transitioned to ${targetStatus}`}),
              ...(activeDelegation ? {delegationRef: activeDelegation.id} : {}),
            }
          : {}),
        version: req.version + 1,
        updatedAt: now,
      });
      await this.logAudit(
        `LEAVE_${targetStatus.toUpperCase().replaceAll(' ', '_')}`,
        'leave_requests',
        req.id,
        `${req.requestRef} -> ${targetStatus}. ${note}`,
        req.policyVersion,
      );
      this.notify('success', 'Workflow Updated', `${req.requestRef} is now ${targetStatus}.`);
      return true;
    } catch (e) {
      handleFirestoreError(e, OperationType.UPDATE, `leave_requests/${req.id}`);
    }
  }

  async submitAdminRequest(input: {
    requestType: AdminRequest['requestType'];
    unitId: string;
    subjectPersonId?: string;
    title: string;
    details: string;
  }): Promise<AdminRequest | null> {
    if (!this.assertPerm('requests.submit', 'submit administrative requests')) return null;
    const user = this.currentUser();
    if (!user) return null;

    const now = new Date().toISOString();
    const id = `admreq-${Date.now()}`;
    const req: AdminRequest = {
      id,
      requestRef: `ADM-2026-${String(Math.floor(1000 + Math.random() * 9000))}`,
      requestType: input.requestType,
      ...(input.subjectPersonId ? {subjectPersonId: input.subjectPersonId} : {}),
      unitId: input.unitId,
      title: input.title.trim(),
      details: input.details.trim(),
      status: 'Submitted',
      policyVersion: 'ADMIN-POL-2026.1',
      version: 1,
      ownerUid: user.uid,
      createdAt: now,
      updatedAt: now,
    };

    const db = getDb();
    try {
      await setDoc(doc(db, 'admin_requests', id), req);
      await this.logAudit(
        'ADMIN_REQUEST_SUBMITTED',
        'admin_requests',
        id,
        `Submitted ${req.requestRef} (${req.requestType}): ${req.title}.`,
      );
      this.notify('success', 'Request Submitted', `${req.requestRef} queued for review.`);
      return req;
    } catch (e) {
      handleFirestoreError(e, OperationType.CREATE, `admin_requests/${id}`);
    }
  }

  async transitionAdminRequest(
    requestId: string,
    targetStatus: AdminRequest['status'],
    note: string,
  ): Promise<boolean> {
    const req = this.adminRequests().find((r) => r.id === requestId);
    const user = this.currentUser();
    if (!req || !user) return false;

    const isDecision = ['Under Review', 'Clarification Requested', 'Approved', 'Rejected', 'Completed'].includes(
      targetStatus,
    );
    if (isDecision && !this.assertPerm('requests.approve', 'approve or reject administrative requests')) {
      return false;
    }

    const now = new Date().toISOString();
    const db = getDb();
    try {
      await updateDoc(doc(db, 'admin_requests', req.id), {
        status: targetStatus,
        ...(isDecision
          ? {
              approverUid: user.uid,
              approverAuthority: `${this.activeRoleLabel()} (${user.email ?? user.uid})`,
              ...(targetStatus === 'Clarification Requested'
                ? {clarificationNote: note.trim() || 'Further information requested.'}
                : {decisionReason: note.trim() || `Transitioned to ${targetStatus}`}),
            }
          : {}),
        version: req.version + 1,
        updatedAt: now,
      });
      await this.logAudit(
        `ADMIN_REQ_${targetStatus.toUpperCase().replaceAll(' ', '_')}`,
        'admin_requests',
        req.id,
        `${req.requestRef} -> ${targetStatus}. ${note}`,
      );
      this.notify('success', 'Administrative Request Updated', `${req.requestRef} -> ${targetStatus}.`);
      return true;
    } catch (e) {
      handleFirestoreError(e, OperationType.UPDATE, `admin_requests/${req.id}`);
    }
  }

  // --- EQUIPMENT CUSTODY ---

  async issueOrTransferAsset(input: {
    assetDocId: string;
    toPersonId: string;
    location: string;
    acknowledged: boolean;
    notes: string;
  }): Promise<boolean> {
    if (!this.assertPerm('equipment.custody', 'issue or transfer equipment custody')) return false;
    const user = this.currentUser();
    if (!user) return false;

    const asset = this.equipmentAssets().find((a) => a.id === input.assetDocId);
    const recipient = this.people().find((p) => p.id === input.toPersonId);
    if (!asset || !recipient) return false;

    if (!input.acknowledged) {
      this.notify(
        'error',
        'Custodian Acknowledgement Required',
        'Custody transfer cannot proceed without explicit recipient acknowledgement.',
      );
      return false;
    }

    if (asset.serviceability === 'Unserviceable' || asset.serviceability === 'In Maintenance') {
      this.notify(
        'error',
        'Asset Not Serviceable',
        `${asset.assetId} is currently "${asset.serviceability}" and cannot be issued until released serviceable.`,
      );
      return false;
    }

    if (asset.custodianPersonId && asset.custodianPersonId !== recipient.id) {
      this.notify(
        'error',
        'Simultaneous Custody Conflict Prevented',
        `${asset.assetId} is already assigned to another custodian. Return to unit stores before re-issuing.`,
      );
      return false;
    }

    const now = new Date().toISOString();
    const db = getDb();
    const batch = writeBatch(db);
    const recId = `cust-${Date.now()}`;

    batch.update(doc(db, 'equipment_assets', asset.id), {
      custodyUnitId: recipient.primaryUnitId ?? asset.custodyUnitId,
      custodianPersonId: recipient.id,
      custodianAckAt: now,
      location: input.location.trim() || asset.location,
      version: asset.version + 1,
      updatedAt: now,
    });

    const record: CustodyRecord = {
      id: recId,
      assetId: asset.id,
      ...(asset.custodianPersonId ? {fromPersonId: asset.custodianPersonId} : {}),
      toPersonId: recipient.id,
      unitId: recipient.primaryUnitId ?? asset.custodyUnitId,
      actionType: asset.custodianPersonId ? 'Transfer' : 'Issue',
      acknowledged: true,
      acknowledgedAt: now,
      notes: input.notes.trim() || 'Acknowledged custody issue.',
      ownerUid: user.uid,
      createdAt: now,
    };
    batch.set(doc(db, 'custody_records', recId), record);

    try {
      await batch.commit();
      await this.logAudit(
        'EQUIPMENT_CUSTODY_ISSUED',
        'equipment_assets',
        asset.id,
        `Issued ${asset.assetId} (${asset.nomenclature}) to ${recipient.rank} ${recipient.surname} with acknowledgement.`,
      );
      this.notify('success', 'Custody Recorded', `${asset.assetId} issued to ${recipient.rank} ${recipient.surname}.`);
      return true;
    } catch (e) {
      handleFirestoreError(e, OperationType.WRITE, `equipment_assets/${asset.id}`);
    }
  }

  async returnAssetToStores(assetDocId: string, returnLocation: string): Promise<boolean> {
    if (!this.assertPerm('equipment.custody', 'return equipment to unit stores')) return false;
    const user = this.currentUser();
    if (!user) return false;
    const asset = this.equipmentAssets().find((a) => a.id === assetDocId);
    if (!asset) return false;

    const now = new Date().toISOString();
    const db = getDb();
    const batch = writeBatch(db);
    const recId = `cust-${Date.now()}`;

    batch.update(doc(db, 'equipment_assets', asset.id), {
      custodianPersonId: '',
      custodianAckAt: '',
      custodyUnitId: asset.ownerUnitId,
      location: returnLocation.trim() || 'Unit Stores Cage',
      version: asset.version + 1,
      updatedAt: now,
    });

    const record: CustodyRecord = {
      id: recId,
      assetId: asset.id,
      ...(asset.custodianPersonId ? {fromPersonId: asset.custodianPersonId} : {}),
      unitId: asset.ownerUnitId,
      actionType: 'Return',
      acknowledged: true,
      acknowledgedAt: now,
      notes: `Returned to ${returnLocation || 'Unit Stores Cage'}.`,
      ownerUid: user.uid,
      createdAt: now,
    };
    batch.set(doc(db, 'custody_records', recId), record);

    try {
      await batch.commit();
      await this.logAudit('EQUIPMENT_RETURNED', 'equipment_assets', asset.id, `Returned ${asset.assetId} to unit stores.`);
      this.notify('success', 'Asset Returned', `${asset.assetId} returned to stores custody.`);
      return true;
    } catch (e) {
      handleFirestoreError(e, OperationType.WRITE, `equipment_assets/${asset.id}`);
    }
  }

  async registerEquipmentAsset(input: {
    assetId: string;
    category: EquipmentCategory;
    nomenclature: string;
    serialNumber: string;
    ownerUnitId: string;
    location: string;
  }): Promise<EquipmentAsset | null> {
    if (!this.assertPerm('equipment.custody', 'register new equipment assets')) return null;
    const user = this.currentUser();
    if (!user) return null;

    const now = new Date().toISOString();
    const id = `eqp-${Date.now()}`;
    const asset: EquipmentAsset = {
      id,
      assetId: input.assetId.trim().toUpperCase(),
      category: input.category,
      nomenclature: input.nomenclature.trim(),
      serialNumber: input.serialNumber.trim(),
      ownerUnitId: input.ownerUnitId,
      custodyUnitId: input.ownerUnitId,
      location: input.location.trim(),
      condition: 'New',
      serviceability: 'Serviceable',
      inspectionStatus: 'Current',
      version: 1,
      ownerUid: user.uid,
      createdAt: now,
      updatedAt: now,
    };

    const db = getDb();
    try {
      await setDoc(doc(db, 'equipment_assets', id), asset);
      await this.logAudit('EQUIPMENT_REGISTERED', 'equipment_assets', id, `Registered ${asset.assetId} (${asset.nomenclature}).`);
      this.notify('success', 'Asset Registered', `${asset.assetId} added to equipment register.`);
      return asset;
    } catch (e) {
      handleFirestoreError(e, OperationType.CREATE, `equipment_assets/${id}`);
    }
  }

  // --- MAINTENANCE & RELEASE GATE ---

  async reportFaultAndOpenOrder(input: {
    assetDocId: string;
    orderType: MaintenanceOrder['orderType'];
    priority: MaintenanceOrder['priority'];
    faultDescription: string;
    partsReserved?: string;
  }): Promise<MaintenanceOrder | null> {
    if (!this.assertPerm('maintenance.work', 'report faults and open work orders')) return null;
    const user = this.currentUser();
    if (!user) return null;
    const asset = this.equipmentAssets().find((a) => a.id === input.assetDocId);
    if (!asset) return null;

    const now = new Date().toISOString();
    const id = `mnt-${Date.now()}`;
    const order: MaintenanceOrder = {
      id,
      orderRef: `WO-2026-${String(Math.floor(1000 + Math.random() * 9000))}`,
      assetId: asset.id,
      unitId: asset.custodyUnitId,
      orderType: input.orderType,
      priority: input.priority,
      faultDescription: input.faultDescription.trim(),
      status: 'Open',
      ...(input.partsReserved?.trim() ? {partsReserved: input.partsReserved.trim()} : {}),
      inspectionPassed: false,
      version: 1,
      ownerUid: user.uid,
      createdAt: now,
      updatedAt: now,
    };

    const db = getDb();
    const batch = writeBatch(db);
    batch.set(doc(db, 'maintenance_orders', id), order);
    batch.update(doc(db, 'equipment_assets', asset.id), {
      serviceability: input.priority === 'Safety Hold' || input.orderType === 'Corrective Fault' ? 'Unserviceable' : 'In Maintenance',
      inspectionStatus: 'Pending Release',
      version: asset.version + 1,
      updatedAt: now,
    });

    try {
      await batch.commit();
      await this.logAudit(
        'MAINTENANCE_ORDER_OPENED',
        'maintenance_orders',
        id,
        `Opened ${order.orderRef} for ${asset.assetId} (${order.priority}): ${order.faultDescription}`,
      );
      this.notify('success', 'Work Order Opened', `${order.orderRef} opened; asset held pending repair & release.`);
      return order;
    } catch (e) {
      handleFirestoreError(e, OperationType.WRITE, `maintenance_orders/${id}`);
    }
  }

  async completeRepairAwaitingInspection(orderId: string): Promise<boolean> {
    if (!this.assertPerm('maintenance.work', 'mark repairs complete for inspection')) return false;
    const order = this.maintenanceOrders().find((m) => m.id === orderId);
    if (!order) return false;
    const asset = this.equipmentAssets().find((a) => a.id === order.assetId);

    const now = new Date().toISOString();
    const db = getDb();
    const batch = writeBatch(db);
    batch.update(doc(db, 'maintenance_orders', order.id), {
      status: 'Repair Completed - Awaiting Inspection',
      inspectionPassed: false,
      version: order.version + 1,
      updatedAt: now,
    });
    if (asset) {
      batch.update(doc(db, 'equipment_assets', asset.id), {
        serviceability: 'Awaiting Inspection',
        inspectionStatus: 'Pending Release',
        version: asset.version + 1,
        updatedAt: now,
      });
    }

    try {
      await batch.commit();
      await this.logAudit(
        'MAINTENANCE_REPAIR_COMPLETED',
        'maintenance_orders',
        order.id,
        `${order.orderRef} repair finished. Asset remains Awaiting Inspection until independent release.`,
      );
      this.notify(
        'info',
        'Repair Completed — Inspection Required',
        `${order.orderRef} moved to "Repair Completed - Awaiting Inspection". Authorised release required before declaring serviceable.`,
      );
      return true;
    } catch (e) {
      handleFirestoreError(e, OperationType.UPDATE, `maintenance_orders/${order.id}`);
    }
  }

  async releaseMaintenanceOrder(orderId: string): Promise<boolean> {
    if (!this.assertPerm('maintenance.release', 'perform independent inspection and release serviceable')) {
      return false;
    }
    const user = this.currentUser();
    const order = this.maintenanceOrders().find((m) => m.id === orderId);
    if (!user || !order) return false;

    if (order.status !== 'Repair Completed - Awaiting Inspection' && order.status !== 'Open' && order.status !== 'In Progress') {
      return false;
    }

    const asset = this.equipmentAssets().find((a) => a.id === order.assetId);
    const now = new Date().toISOString();
    const db = getDb();
    const batch = writeBatch(db);

    batch.update(doc(db, 'maintenance_orders', order.id), {
      status: 'Released Serviceable',
      inspectionPassed: true,
      releasedByUid: user.uid,
      releasedAt: now,
      version: order.version + 1,
      updatedAt: now,
    });
    if (asset) {
      batch.update(doc(db, 'equipment_assets', asset.id), {
        condition: asset.condition === 'Damaged' ? 'Good' : asset.condition,
        serviceability: 'Serviceable',
        inspectionStatus: 'Current',
        lastServiceDate: now.slice(0, 10),
        version: asset.version + 1,
        updatedAt: now,
      });
    }

    try {
      await batch.commit();
      await this.logAudit(
        'MAINTENANCE_RELEASED_SERVICEABLE',
        'maintenance_orders',
        order.id,
        `Independent inspection passed & ${order.orderRef} released serviceable.`,
      );
      this.notify('success', 'Released Serviceable', `${order.orderRef} inspected and equipment returned to Serviceable.`);
      return true;
    } catch (e) {
      handleFirestoreError(e, OperationType.UPDATE, `maintenance_orders/${order.id}`);
    }
  }

  // --- STORES & IMMUTABLE LEDGER ---

  async postStockMovement(input: {
    stockItemId: string;
    movementType: StockMovement['movementType'];
    quantity: number;
    referenceDoc: string;
    reason: string;
  }): Promise<boolean> {
    if (!this.assertPerm('stores.move', 'post immutable stock movements')) return false;
    const user = this.currentUser();
    const item = this.stockItems().find((s) => s.id === input.stockItemId);
    if (!user || !item) return false;

    const qty = Math.floor(Number(input.quantity));
    if (qty <= 0) return false;

    let availableQty = item.availableQty;
    let reservedQty = item.reservedQty;
    let quarantinedQty = item.quarantinedQty;
    const damagedQty = item.damagedQty;
    const inTransitQty = item.inTransitQty;
    let bucketFrom = 'Available';
    let bucketTo = 'Issued';

    switch (input.movementType) {
      case 'Receipt':
        bucketFrom = 'External Depot';
        bucketTo = 'Available';
        availableQty += qty;
        break;
      case 'Return':
        bucketFrom = 'Unit Holder';
        bucketTo = 'Available';
        availableQty += qty;
        break;
      case 'Issue':
        if (availableQty < qty) {
          this.notify('error', 'Insufficient Available Stock', `Available=${availableQty}, requested=${qty}.`);
          return false;
        }
        bucketFrom = 'Available';
        bucketTo = 'Issued Out';
        availableQty -= qty;
        break;
      case 'Reserve':
        if (availableQty < qty) {
          this.notify('error', 'Insufficient Available Stock', `Available=${availableQty}, requested=${qty}.`);
          return false;
        }
        bucketFrom = 'Available';
        bucketTo = 'Reserved';
        availableQty -= qty;
        reservedQty += qty;
        break;
      case 'Release Reservation':
        if (reservedQty < qty) {
          this.notify('error', 'Insufficient Reserved Stock', `Reserved=${reservedQty}, requested=${qty}.`);
          return false;
        }
        bucketFrom = 'Reserved';
        bucketTo = 'Available';
        reservedQty -= qty;
        availableQty += qty;
        break;
      case 'Quarantine':
        if (availableQty < qty) {
          this.notify('error', 'Insufficient Available Stock', `Available=${availableQty}, requested=${qty}.`);
          return false;
        }
        bucketFrom = 'Available';
        bucketTo = 'Quarantined';
        availableQty -= qty;
        quarantinedQty += qty;
        break;
      case 'Transfer':
        if (availableQty < qty) {
          this.notify('error', 'Insufficient Available Stock', `Available=${availableQty}, requested=${qty}.`);
          return false;
        }
        bucketFrom = 'Available';
        bucketTo = 'In Transit';
        availableQty -= qty;
        break;
      case 'Adjustment':
        bucketFrom = 'Reconciliation';
        bucketTo = 'Available';
        availableQty += qty;
        break;
    }

    const now = new Date().toISOString();
    const movId = `mov-${Date.now()}`;
    const movement: StockMovement = {
      id: movId,
      movementRef: `MOV-2026-${String(Math.floor(1000 + Math.random() * 9000))}`,
      sku: item.sku,
      unitId: item.unitId,
      movementType: input.movementType,
      quantity: qty,
      bucketFrom,
      bucketTo,
      referenceDoc: input.referenceDoc.trim() || 'UNIT-ST-ADJ',
      reason: input.reason.trim() || `${input.movementType} posted`,
      ownerUid: user.uid,
      createdAt: now,
    };

    const db = getDb();
    const batch = writeBatch(db);
    batch.update(doc(db, 'stock_items', item.id), {
      availableQty,
      reservedQty,
      quarantinedQty,
      damagedQty,
      inTransitQty: input.movementType === 'Transfer' ? inTransitQty + qty : inTransitQty,
      version: item.version + 1,
      updatedAt: now,
    });
    batch.set(doc(db, 'stock_movements', movId), movement);

    try {
      await batch.commit();
      await this.logAudit(
        'STOCK_MOVEMENT_POSTED',
        'stock_movements',
        movId,
        `${movement.movementRef}: ${movement.movementType} ${qty} x ${item.sku} (${bucketFrom} -> ${bucketTo}).`,
      );
      this.notify('success', 'Ledger Entry Recorded', `${movement.movementRef} posted (${bucketFrom} -> ${bucketTo}).`);
      return true;
    } catch (e) {
      handleFirestoreError(e, OperationType.WRITE, `stock_items/${item.id}`);
    }
  }

  // --- DOCUMENTS & UNTRUSTED UPLOAD VALIDATION ---

  async registerValidatedDocument(input: {
    title: string;
    category: string;
    unitId: string;
    mimeType: string;
    sizeBytes: number;
    linkedEntityType?: string;
    linkedEntityId?: string;
  }): Promise<DocumentRecord | null> {
    if (!this.assertPerm('requests.submit', 'register administrative documents')) return null;
    const user = this.currentUser();
    if (!user) return null;

    const allowedMimes = ['application/pdf', 'text/plain', 'text/csv', 'image/png', 'image/jpeg'];
    if (!allowedMimes.includes(input.mimeType)) {
      this.notify(
        'error',
        'Untrusted File Type Blocked',
        `MIME type "${input.mimeType}" is rejected. Allowed formats: PDF, TXT, CSV, PNG, JPEG.`,
      );
      return null;
    }
    if (input.sizeBytes <= 0 || input.sizeBytes > 10 * 1024 * 1024) {
      this.notify('error', 'File Size Limit Exceeded', 'Uploads must be between 1 byte and 10 MB.');
      return null;
    }

    const now = new Date().toISOString();
    const id = `doc-${Date.now()}`;
    const docRec: DocumentRecord = {
      id,
      docRef: `DOC-2026-${String(Math.floor(100 + Math.random() * 899))}`,
      title: input.title.trim(),
      category: input.category.trim(),
      unitId: input.unitId,
      ...(input.linkedEntityType ? {linkedEntityType: input.linkedEntityType} : {}),
      ...(input.linkedEntityId ? {linkedEntityId: input.linkedEntityId} : {}),
      mimeType: input.mimeType as DocumentRecord['mimeType'],
      sizeBytes: Math.floor(input.sizeBytes),
      status: 'Submitted',
      ownerUid: user.uid,
      createdAt: now,
      updatedAt: now,
    };

    const db = getDb();
    try {
      await setDoc(doc(db, 'documents', id), docRec);
      await this.logAudit('DOCUMENT_REGISTERED', 'documents', id, `Validated and registered ${docRec.docRef} (${docRec.mimeType}).`);
      this.notify('success', 'Document Validated & Submitted', `${docRec.docRef} submitted for approval.`);
      return docRec;
    } catch (e) {
      handleFirestoreError(e, OperationType.CREATE, `documents/${id}`);
    }
  }

  async approveDocument(docId: string, decision: 'Approved' | 'Rejected'): Promise<boolean> {
    if (!this.assertPerm('requests.approve', 'approve or reject documents')) return false;
    const user = this.currentUser();
    if (!user) return false;
    const db = getDb();
    const now = new Date().toISOString();
    try {
      await updateDoc(doc(db, 'documents', docId), {
        status: decision,
        approvedByUid: user.uid,
        updatedAt: now,
      });
      await this.logAudit(`DOCUMENT_${decision.toUpperCase()}`, 'documents', docId, `Document ${docId} marked ${decision}.`);
      this.notify('success', `Document ${decision}`, `Document workflow state updated.`);
      return true;
    } catch (e) {
      handleFirestoreError(e, OperationType.UPDATE, `documents/${docId}`);
    }
  }

  // --- DELEGATIONS, OFFLINE QUEUE & CONCURRENCY CONFLICTS ---

  async createDelegation(input: {
    delegateName: string;
    roleGranted: Delegation['roleGranted'];
    unitScope: string;
    validFrom: string;
    validUntil: string;
    reason: string;
  }): Promise<boolean> {
    if (!this.assertPerm('system.configure', 'create time-bounded delegations')) return false;
    const user = this.currentUser();
    if (!user) return false;

    const now = new Date().toISOString();
    const id = `del-${Date.now()}`;
    const delegation: Delegation = {
      id,
      delegatorUid: user.uid,
      delegateName: input.delegateName.trim(),
      roleGranted: input.roleGranted,
      unitScope: input.unitScope,
      validFrom: input.validFrom,
      validUntil: input.validUntil,
      status: 'Active',
      reason: input.reason.trim(),
      ownerUid: user.uid,
      createdAt: now,
    };

    const db = getDb();
    try {
      await setDoc(doc(db, 'delegations', id), delegation);
      await this.logAudit(
        'DELEGATION_GRANTED',
        'delegations',
        id,
        `Delegated ${delegation.roleGranted} on ${delegation.unitScope} to ${delegation.delegateName} (${delegation.validFrom}..${delegation.validUntil}).`,
      );
      this.notify('success', 'Delegation Created', `Time-bounded authority granted until ${delegation.validUntil}.`);
      return true;
    } catch (e) {
      handleFirestoreError(e, OperationType.CREATE, `delegations/${id}`);
    }
  }

  enqueueOfflineDemoMutation(simulateConflict = false): void {
    const samplePerson = this.people()[0];
    const expectedVersion = simulateConflict && samplePerson ? Math.max(0, samplePerson.version - 1) : (samplePerson?.version ?? 1);
    const item: OfflineQueueItem = {
      id: `off-${Date.now()}`,
      idempotencyKey: `idem-${crypto.randomUUID ? crypto.randomUUID() : Date.now()}`,
      entityType: 'people',
      entityId: samplePerson?.id ?? 'per-001',
      expectedVersion,
      summary: simulateConflict
        ? `Offline rank/contact edit on ${samplePerson?.serviceId ?? 'SYN-841029'} (stale v${expectedVersion})`
        : `Offline leave check-in sync for ${samplePerson?.serviceId ?? 'SYN-841029'} (v${expectedVersion})`,
      requiredAction: 'personnel.edit',
      createdAt: new Date().toISOString(),
      status: 'Queued',
    };
    this.offlineQueue.update((q) => [item, ...q]);
    this.notify('info', 'Offline Change Queued', `Queued with idempotency key ${item.idempotencyKey.slice(0, 14)}...`);
  }

  async synchronizeOfflineQueue(): Promise<void> {
    if (this.offlineMode()) {
      this.notify('warning', 'Device Offline', 'Disable offline mode to synchronise queued changes.');
      return;
    }
    if (this.remoteSessionRevoked()) {
      this.notify(
        'error',
        'Remote Session Revoked',
        'Cached credentials rejected during sync revalidation. Local restricted cache purged.',
      );
      return;
    }

    const updated: OfflineQueueItem[] = [];
    for (const item of this.offlineQueue()) {
      if (item.status !== 'Queued') {
        updated.push(item);
        continue;
      }
      // 1. Revalidate active permission on reconnect
      if (!this.can(item.requiredAction)) {
        updated.push({
          ...item,
          status: 'Rejected',
          conflictDetail: `Permission "${item.requiredAction}" no longer held by role "${this.activeRoleLabel()}".`,
        });
        continue;
      }
      // 2. Optimistic concurrency version check
      const livePerson = this.people().find((p) => p.id === item.entityId);
      if (livePerson && item.expectedVersion < livePerson.version) {
        updated.push({
          ...item,
          status: 'Conflict',
          conflictDetail: `Version conflict: queued against v${item.expectedVersion}, server is at v${livePerson.version}. Manual resolution required.`,
        });
        continue;
      }
      updated.push({...item, status: 'Synced'});
    }
    this.offlineQueue.set(updated);
    await this.logAudit(
      'OFFLINE_QUEUE_SYNCHRONISED',
      'sync',
      'offline-queue',
      `Revalidated permissions & checked optimistic versions for ${updated.length} queued items.`,
    );
    this.notify('success', 'Synchronisation Evaluated', 'Permissions revalidated and version conflicts flagged if any.');
  }

  resolveOfflineConflict(itemId: string, resolution: 'accept_server' | 'retry_latest'): void {
    this.offlineQueue.update((items) =>
      items.map((it) => {
        if (it.id !== itemId) return it;
        if (resolution === 'accept_server') {
          return {...it, status: 'Synced', conflictDetail: 'Resolved: accepted authoritative server state.'};
        }
        const livePerson = this.people().find((p) => p.id === it.entityId);
        return {
          ...it,
          expectedVersion: livePerson?.version ?? it.expectedVersion + 1,
          status: 'Synced',
          conflictDetail: 'Resolved: rebased to latest server version and applied with new idempotency pass.',
        };
      }),
    );
    void this.logAudit('SYNC_CONFLICT_RESOLVED', 'sync', itemId, `Conflict ${itemId} resolved via ${resolution}.`);
    this.notify('success', 'Conflict Resolved', 'Resolution recorded in audit trail.');
  }

  // --- REPORTS & AUDITED EXPORT ---

  async exportAuthorisedReport(reportTitle: string, rows: Record<string, unknown>[]): Promise<void> {
    if (!this.assertPerm('reports.export', `export report "${reportTitle}"`)) return;
    if (!this.isBrowser) return;

    const csvHeaders = rows.length > 0 ? Object.keys(rows[0]) : ['message'];
    const escape = (val: unknown) => {
      const s = String(val ?? '').replaceAll('"', '""');
      return `"${s}"`;
    };
    const csvLines = [
      csvHeaders.join(','),
      ...(rows.length > 0
        ? rows.map((r) => csvHeaders.map((h) => escape(r[h])).join(','))
        : ['"No records matched active filter criteria"']),
    ];
    const blob = new Blob([csvLines.join('\n')], {type: 'text/csv;charset=utf-8;'});
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${reportTitle.toLowerCase().replaceAll(/[^a-z0-9]+/g, '_')}_${new Date().toISOString().slice(0, 10)}.csv`;
    a.click();
    URL.revokeObjectURL(url);

    await this.logAudit(
      'REPORT_EXPORTED',
      'reports',
      reportTitle,
      `Exported PII-minimised CSV report "${reportTitle}" (${rows.length} rows).`,
    );
    this.notify('success', 'Report Exported & Audited', `Downloaded ${reportTitle} (${rows.length} rows).`);
  }

  // --- COMPLETE 10-STEP DEMONSTRATION WORKFLOW ---

  async runEndToEndDemonstration(): Promise<string[]> {
    const log: string[] = [];
    const person = await this.createPerson({
      serviceId: `SYN-${Math.floor(100000 + Math.random() * 899999)}`,
      surname: 'Harrington',
      givenNames: 'Thomas Edward',
      rank: 'LCpl',
      engagementStart: '2026-11-01',
      clearanceStatus: 'Cleared',
      clearanceProvenance: 'Demo Verification Ref VER-2026-990',
      contactEmail: 't.harrington@demo-admin.example',
      homeStationAddress: 'Demo Transit Block 9, Blandford',
      emergencyContactName: 'M. Harrington (Demo)',
      emergencyContactPhone: '+44 7700 900777',
    });
    if (!person) return ['Step 1 aborted due to permissions or duplicate identifier.'];
    log.push(`1. Created personnel record ${person.rank} ${person.surname} (${person.serviceId})`);

    const vacantPos = this.positions().find((p) => p.status === 'Vacant') ?? this.positions()[0];
    if (vacantPos) {
      await this.assignPersonToPosition({
        personId: person.id,
        positionId: vacantPos.id,
        assignmentType: 'Primary Posting',
        startDate: '2026-11-21',
        reason: 'End-to-end demonstration posting',
      });
      log.push(`2. Assigned ${person.serviceId} to position ${vacantPos.code} (${vacantPos.title})`);
    }

    const baseCourse = this.courses().find((c) => c.prerequisites.length === 0) ?? this.courses()[0];
    if (baseCourse) {
      const enr = await this.enrolInCourse({
        courseId: baseCourse.id,
        personId: person.id,
        sessionDate: '2026-11-21',
      });
      if (enr) {
        log.push(`3. Enrolled ${person.serviceId} on course ${baseCourse.code}`);
        await this.updateEnrolmentOutcome({
          enrolmentId: enr.id,
          attendanceStatus: 'Attended',
          resultStatus: 'Passed',
          evidenceRef: `DEMO-CERT-${person.serviceId}`,
        });
        log.push(`4. Recorded Attended/Passed and awarded versioned qualification (${baseCourse.code})`);
      }
    }

    const lr = await this.submitLeaveRequest({
      personId: person.id,
      leaveType: 'Annual',
      startDate: '2026-12-21',
      endDate: '2026-12-23',
      daysCount: 3,
      reason: 'End-to-end demonstration leave workflow',
    });
    if (lr) {
      await this.transitionLeaveRequest(lr.id, 'Approved', 'Approved under demonstration policy check.');
      log.push(`5. Submitted and approved leave request ${lr.requestRef}`);
    }

    const unissuedLaptop = this.equipmentAssets().find(
      (a) => a.category === 'Laptop' && !a.custodianPersonId && a.serviceability === 'Serviceable',
    );
    if (unissuedLaptop) {
      await this.issueOrTransferAsset({
        assetDocId: unissuedLaptop.id,
        toPersonId: person.id,
        location: '14 Sqn Desk 4',
        acknowledged: true,
        notes: 'Demonstration laptop custody handover',
      });
      log.push(`6. Issued laptop ${unissuedLaptop.assetId} with custodian acknowledgement`);
    }

    const vehicle = this.equipmentAssets().find((a) => a.category === 'Vehicle');
    if (vehicle) {
      const wo = await this.reportFaultAndOpenOrder({
        assetDocId: vehicle.id,
        orderType: 'Corrective Fault',
        priority: 'Urgent',
        faultDescription: 'Demonstration fault: nearside indicator relay intermittent.',
        partsReserved: 'Relay-12V x1',
      });
      if (wo) {
        log.push(`7. Reported vehicle fault (${wo.orderRef} on ${vehicle.assetId})`);
        await this.completeRepairAwaitingInspection(wo.id);
        await this.releaseMaintenanceOrder(wo.id);
        log.push(`8. Completed repair and executed independent serviceable release on ${wo.orderRef}`);
      }
    }

    const stock = this.stockItems()[0];
    if (stock) {
      await this.postStockMovement({
        stockItemId: stock.id,
        movementType: 'Adjustment',
        quantity: 1,
        referenceDoc: 'RECON-DEMO-01',
        reason: 'Demonstration stores reconciliation cycle verification',
      });
      log.push(`9. Reconciled stores on ${stock.sku} via immutable stock-movement ledger`);
    }

    log.push('10. Complete workflow audited; unit report ready for authorised export.');
    return log;
  }
}
