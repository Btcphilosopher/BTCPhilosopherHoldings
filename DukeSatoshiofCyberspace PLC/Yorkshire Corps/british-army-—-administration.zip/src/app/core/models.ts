export type AppRole =
  | 'individual_member'
  | 'unit_admin'
  | 'training_admin'
  | 'equipment_custodian'
  | 'maintenance_staff'
  | 'approver'
  | 'auditor'
  | 'system_admin';

export type NavSection =
  | 'overview'
  | 'personnel'
  | 'units'
  | 'training'
  | 'equipment'
  | 'maintenance'
  | 'stores'
  | 'requests'
  | 'reports'
  | 'administration';

export interface UserProfile {
  uid: string;
  email: string;
  displayName: string;
  role: AppRole;
  activeDemoRole?: AppRole;
  unitId: string;
  personId?: string;
  createdAt: string;
  updatedAt: string;
}

export interface Unit {
  id: string;
  code: string;
  name: string;
  parentUnitId?: string;
  commanderPersonId?: string;
  authorisedStrength: number;
  location: string;
  effectiveDate: string;
  status: 'Active' | 'Restructuring' | 'Archived';
  version: number;
  ownerUid: string;
  createdAt: string;
  updatedAt: string;
}

export interface Position {
  id: string;
  code: string;
  title: string;
  unitId: string;
  requiredRank: string;
  appointmentType: 'Established' | 'Temporary Attachment' | 'Training Billet';
  status: 'Vacant' | 'Filled' | 'Frozen';
  assignedPersonId?: string;
  effectiveDate: string;
  version: number;
  ownerUid: string;
  createdAt: string;
  updatedAt: string;
}

export interface Person {
  id: string;
  serviceId: string;
  surname: string;
  givenNames: string;
  rank: string;
  primaryUnitId?: string;
  primaryPositionId?: string;
  engagementStart: string;
  engagementEnd?: string;
  clearanceStatus: 'Cleared' | 'Pending Review' | 'Restricted' | 'Not Assessed';
  clearanceProvenance?: string;
  clearanceExpiry?: string;
  contactEmail?: string;
  status: 'Active' | 'Detached' | 'Leave' | 'Archived';
  version: number;
  ownerUid: string;
  createdAt: string;
  updatedAt: string;
}

export interface PersonSensitive {
  personId: string;
  ownerUid: string;
  homeStationAddress: string;
  emergencyContactName: string;
  emergencyContactPhone: string;
  medicalClearanceNote: string;
  updatedBy: string;
  updatedAt: string;
}

export interface Assignment {
  id: string;
  personId: string;
  unitId: string;
  positionId: string;
  assignmentType: 'Primary Posting' | 'Temporary Attachment' | 'Acting Appointment';
  startDate: string;
  endDate?: string;
  status: 'Current' | 'Superseded' | 'Scheduled';
  reason: string;
  ownerUid: string;
  createdAt: string;
}

export interface Course {
  id: string;
  code: string;
  title: string;
  category: string;
  durationDays: number;
  prerequisites: string[];
  capacity: number;
  status: 'Active' | 'Retired';
  version: number;
  ownerUid: string;
  createdAt: string;
}

export interface Enrolment {
  id: string;
  courseId: string;
  personId: string;
  unitId: string;
  sessionDate: string;
  attendanceStatus: 'Enrolled' | 'Attended' | 'Absent' | 'Withdrawn';
  resultStatus: 'Pending' | 'Passed' | 'Failed' | 'Deferred';
  originalResult?: string;
  correctionReason?: string;
  version: number;
  ownerUid: string;
  createdAt: string;
  updatedAt: string;
}

export interface Qualification {
  id: string;
  personId: string;
  qualCode: string;
  title: string;
  criteriaVersion: string;
  awardedDate: string;
  expiryDate: string;
  status: 'Current' | 'Expiring Soon' | 'Expired' | 'Revoked';
  evidenceRef?: string;
  enrolmentId?: string;
  correctionReason?: string;
  version: number;
  ownerUid: string;
  createdAt: string;
  updatedAt: string;
}

export type WorkflowStatus =
  | 'Draft'
  | 'Submitted'
  | 'Under Review'
  | 'Clarification Requested'
  | 'Approved'
  | 'Rejected'
  | 'Completed'
  | 'Withdrawn'
  | 'Cancelled';

export interface LeaveRequest {
  id: string;
  requestRef: string;
  personId: string;
  unitId: string;
  leaveType: 'Annual' | 'Privilege' | 'Compassionate' | 'Study' | 'Sick Administrative';
  startDate: string;
  endDate: string;
  daysCount: number;
  status: WorkflowStatus;
  reason: string;
  approverUid?: string;
  approverAuthority?: string;
  policyVersion: string;
  decisionReason?: string;
  clarificationNote?: string;
  delegationRef?: string;
  version: number;
  ownerUid: string;
  createdAt: string;
  updatedAt: string;
}

export interface AdminRequest {
  id: string;
  requestRef: string;
  requestType:
    | 'Assignment Change'
    | 'Qualification Correction'
    | 'Equipment Request'
    | 'Document Approval'
    | 'Administrative Support';
  subjectPersonId?: string;
  unitId: string;
  title: string;
  details: string;
  status: WorkflowStatus;
  approverUid?: string;
  approverAuthority?: string;
  policyVersion: string;
  decisionReason?: string;
  clarificationNote?: string;
  delegationRef?: string;
  version: number;
  ownerUid: string;
  createdAt: string;
  updatedAt: string;
}

export type EquipmentCategory =
  | 'Laptop'
  | 'Radio'
  | 'Vehicle'
  | 'Workshop Equipment'
  | 'Protective Equipment'
  | 'Furniture'
  | 'Training Device';

export interface EquipmentAsset {
  id: string;
  assetId: string;
  category: EquipmentCategory;
  nomenclature: string;
  serialNumber: string;
  ownerUnitId: string;
  custodyUnitId: string;
  custodianPersonId?: string;
  custodianAckAt?: string;
  location: string;
  condition: 'New' | 'Good' | 'Fair' | 'Damaged' | 'Beyond Economical Repair';
  serviceability: 'Serviceable' | 'Unserviceable' | 'Awaiting Inspection' | 'In Maintenance';
  inspectionStatus: 'Current' | 'Due' | 'Overdue' | 'Pending Release';
  warrantyExpiry?: string;
  lastServiceDate?: string;
  version: number;
  ownerUid: string;
  createdAt: string;
  updatedAt: string;
}

export interface CustodyRecord {
  id: string;
  assetId: string;
  fromPersonId?: string;
  toPersonId?: string;
  unitId: string;
  actionType: 'Issue' | 'Return' | 'Transfer';
  acknowledged: boolean;
  acknowledgedAt?: string;
  notes: string;
  ownerUid: string;
  createdAt: string;
}

export interface MaintenanceOrder {
  id: string;
  orderRef: string;
  assetId: string;
  unitId: string;
  orderType: 'Preventive' | 'Corrective Fault' | 'Inspection';
  priority: 'Routine' | 'Urgent' | 'Safety Hold';
  faultDescription: string;
  status:
    | 'Open'
    | 'In Progress'
    | 'Repair Completed - Awaiting Inspection'
    | 'Released Serviceable'
    | 'Closed Unserviceable';
  partsReserved?: string;
  inspectionPassed: boolean;
  releasedByUid?: string;
  releasedAt?: string;
  version: number;
  ownerUid: string;
  createdAt: string;
  updatedAt: string;
}

export interface StockItem {
  id: string;
  sku: string;
  nomenclature: string;
  category: string;
  unitId: string;
  availableQty: number;
  reservedQty: number;
  quarantinedQty: number;
  damagedQty: number;
  inTransitQty: number;
  reorderLevel: number;
  unitOfMeasure: string;
  version: number;
  ownerUid: string;
  updatedAt: string;
}

export interface StockMovement {
  id: string;
  movementRef: string;
  sku: string;
  unitId: string;
  movementType:
    | 'Receipt'
    | 'Issue'
    | 'Reserve'
    | 'Release Reservation'
    | 'Transfer'
    | 'Return'
    | 'Quarantine'
    | 'Adjustment';
  quantity: number;
  bucketFrom: string;
  bucketTo: string;
  referenceDoc: string;
  reason: string;
  ownerUid: string;
  createdAt: string;
}

export interface DocumentRecord {
  id: string;
  docRef: string;
  title: string;
  category: string;
  unitId: string;
  linkedEntityType?: string;
  linkedEntityId?: string;
  mimeType: 'application/pdf' | 'text/plain' | 'text/csv' | 'image/png' | 'image/jpeg';
  sizeBytes: number;
  status: 'Draft' | 'Submitted' | 'Approved' | 'Rejected' | 'Archived';
  approvedByUid?: string;
  ownerUid: string;
  createdAt: string;
  updatedAt: string;
}

export interface Delegation {
  id: string;
  delegatorUid: string;
  delegateName: string;
  roleGranted: 'approver' | 'unit_admin' | 'training_admin' | 'equipment_custodian';
  unitScope: string;
  validFrom: string;
  validUntil: string;
  status: 'Active' | 'Expired' | 'Revoked';
  reason: string;
  ownerUid: string;
  createdAt: string;
}

export interface AuditEvent {
  id: string;
  actorUid: string;
  actorEmail: string;
  actorRole: string;
  action: string;
  entityType: string;
  entityId: string;
  summary: string;
  policyVersion: string;
  ownerUid: string;
  timestamp: string;
}

export interface OfflineQueueItem {
  id: string;
  idempotencyKey: string;
  entityType: string;
  entityId: string;
  expectedVersion: number;
  summary: string;
  requiredAction: PermissionAction;
  createdAt: string;
  status: 'Queued' | 'Conflict' | 'Synced' | 'Rejected';
  conflictDetail?: string;
}

export type PermissionAction =
  | 'personnel.create'
  | 'personnel.edit'
  | 'personnel.read_sensitive'
  | 'units.manage'
  | 'positions.assign'
  | 'training.manage'
  | 'training.correct_result'
  | 'requests.submit'
  | 'requests.approve'
  | 'equipment.custody'
  | 'maintenance.work'
  | 'maintenance.release'
  | 'stores.move'
  | 'reports.export'
  | 'audit.read'
  | 'system.configure';
