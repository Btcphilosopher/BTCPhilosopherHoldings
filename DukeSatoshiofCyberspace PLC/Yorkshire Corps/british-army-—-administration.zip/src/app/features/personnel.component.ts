import {ChangeDetectionStrategy, Component, computed, inject, signal} from '@angular/core';
import {FormsModule} from '@angular/forms';
import {Person, PersonSensitive} from '../core/models';
import {StoreService} from '../core/store.service';

@Component({
  selector: 'app-personnel',
  imports: [FormsModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-6">
      <div class="flex flex-col gap-4 md:flex-row md:items-end md:justify-between border-b border-[#DDD8CB] pb-5">
        <div>
          <p class="text-xs font-medium tracking-wider text-[#5A625B] uppercase">
            Personnel Administration · Synthetic Service Records
          </p>
          <h1 class="mt-1 text-2xl font-semibold text-[#1C221E]">Personnel Register</h1>
          <p class="mt-1 text-sm text-[#4A524C]">
            Identity is separated from unit postings and rank. Sensitive contact and clearance notes require narrow permissions.
          </p>
        </div>
        <button
          type="button"
          (click)="showCreateModal.set(true)"
          class="min-h-[44px] px-4 py-2.5 bg-[#9A7B3E] hover:bg-[#826630] text-[#FCFBF7] text-sm font-medium rounded transition-colors whitespace-nowrap shrink-0 cursor-pointer"
        >
          Create Personnel Record
        </button>
      </div>

      <!-- Filter Bar -->
      <div class="bg-[#FCFBF7] border border-[#DDD8CB] rounded p-4 grid grid-cols-1 md:grid-cols-4 gap-3">
        <input
          type="text"
          [(ngModel)]="searchTerm"
          placeholder="Search service ID, surname, or rank..."
          aria-label="Search personnel"
          class="min-h-[42px] px-3 py-2 bg-white border border-[#CFCAC0] rounded text-sm text-[#1C221E]"
        />
        <select
          [(ngModel)]="unitFilter"
          aria-label="Filter by unit"
          class="min-h-[42px] px-3 py-2 bg-white border border-[#CFCAC0] rounded text-sm text-[#1C221E]"
        >
          <option value="">All Units</option>
          @for (u of store.units(); track u.id) {
            <option [value]="u.id">{{ u.code }} · {{ u.name }}</option>
          }
        </select>
        <select
          [(ngModel)]="statusFilter"
          aria-label="Filter by status"
          class="min-h-[42px] px-3 py-2 bg-white border border-[#CFCAC0] rounded text-sm text-[#1C221E]"
        >
          <option value="">All Statuses</option>
          <option value="Active">Active</option>
          <option value="Detached">Detached</option>
          <option value="Leave">Leave</option>
          <option value="Archived">Archived</option>
        </select>
        <button
          type="button"
          (click)="resetFilters()"
          class="min-h-[42px] px-4 py-2 bg-[#F5F2EA] hover:bg-[#EAE5D8] border border-[#CFCAC0] rounded text-sm font-medium text-[#1C221E] cursor-pointer"
        >
          Reset Filters
        </button>
      </div>

      <!-- Directory & Detail Split -->
      <div class="grid grid-cols-1 xl:grid-cols-12 gap-6 items-start">
        <div class="xl:col-span-7 bg-[#FCFBF7] border border-[#DDD8CB] rounded overflow-hidden">
          <div class="overflow-x-auto">
            <table class="w-full text-left border-collapse text-sm">
              <thead>
                <tr class="border-b border-[#DDD8CB] bg-[#F5F2EA] text-xs text-[#5A625B]">
                  <th class="py-3 px-4 font-medium">Service ID</th>
                  <th class="py-3 px-4 font-medium">Rank & Name</th>
                  <th class="py-3 px-4 font-medium">Current Unit / Billet</th>
                  <th class="py-3 px-4 font-medium">Clearance</th>
                  <th class="py-3 px-4 font-medium">Status</th>
                </tr>
              </thead>
              <tbody class="divide-y divide-[#EFECE2]">
                @for (p of filteredPeople(); track p.id) {
                  <tr
                    (click)="selectPerson(p)"
                    class="cursor-pointer transition-colors"
                    [class.bg-[#EAE5D8]]="selectedPerson()?.id === p.id"
                    [class.hover:bg-[#F5F2EA]]="selectedPerson()?.id !== p.id"
                  >
                    <td class="py-3 px-4 font-mono text-xs font-medium text-[#2A3B30] whitespace-nowrap">
                      {{ p.serviceId }}
                    </td>
                    <td class="py-3 px-4">
                      <div class="font-medium text-[#1C221E]">{{ p.rank }} {{ p.surname }}, {{ p.givenNames }}</div>
                      <div class="text-xs text-[#5A625B] font-mono">Engaged {{ p.engagementStart }}</div>
                    </td>
                    <td class="py-3 px-4 text-xs text-[#3C443E]">
                      <div>{{ unitName(p.primaryUnitId) }}</div>
                      <div class="text-[#5A625B]">{{ positionTitle(p.primaryPositionId) }}</div>
                    </td>
                    <td class="py-3 px-4 text-xs whitespace-nowrap">
                      <span
                        class="font-medium"
                        [class.text-[#1E6B43]]="p.clearanceStatus === 'Cleared'"
                        [class.text-[#A16207]]="p.clearanceStatus === 'Pending Review'"
                        [class.text-[#B91C1C]]="p.clearanceStatus === 'Restricted'"
                        [class.text-[#4B5563]]="p.clearanceStatus === 'Not Assessed'"
                      >
                        {{ p.clearanceStatus }}
                      </span>
                    </td>
                    <td class="py-3 px-4 text-xs font-medium text-[#1C221E] whitespace-nowrap">{{ p.status }}</td>
                  </tr>
                } @empty {
                  <tr>
                    <td colspan="5" class="py-8 text-center text-sm text-[#5A625B]">
                      No personnel records match the current filter.
                    </td>
                  </tr>
                }
              </tbody>
            </table>
          </div>
        </div>

        <!-- Inspector Panel -->
        <div class="xl:col-span-5 bg-[#FCFBF7] border border-[#DDD8CB] rounded p-6 space-y-5">
          @if (selectedPerson(); as person) {
            <div class="border-b border-[#EAE5D8] pb-4 flex items-start justify-between gap-4">
              <div>
                <p class="font-mono text-xs text-[#5A625B]">{{ person.serviceId }} · Record v{{ person.version }}</p>
                <h2 class="mt-1 text-xl font-semibold text-[#1C221E]">
                  {{ person.rank }} {{ person.givenNames }} {{ person.surname }}
                </h2>
                <p class="mt-1 text-xs text-[#4A524C]">
                  {{ unitName(person.primaryUnitId) }} · {{ positionTitle(person.primaryPositionId) }}
                </p>
              </div>
              <button
                type="button"
                (click)="inspectSensitive(person.id)"
                class="min-h-[40px] px-3 py-1.5 bg-[#222924] hover:bg-[#2E3731] text-[#F5F2EA] text-xs font-medium rounded whitespace-nowrap shrink-0 cursor-pointer"
              >
                Inspect Sensitive Notes
              </button>
            </div>

            <!-- Clearance Provenance (never infer from absence) -->
            <div class="text-xs space-y-1 bg-[#F5F2EA] border border-[#E2DDD0] rounded p-3.5">
              <div class="font-semibold text-[#1C221E]">Administrative Clearance Status: {{ person.clearanceStatus }}</div>
              <div class="text-[#4A524C]">
                Provenance: {{ person.clearanceProvenance || 'Not recorded (suitability must not be inferred from absence)' }}
              </div>
              @if (person.clearanceExpiry) {
                <div class="font-mono text-[#5A625B]">Clearance Expiry: {{ person.clearanceExpiry }}</div>
              }
            </div>

            <!-- Isolated Sensitive Record View -->
            @if (sensitiveData(); as sens) {
              <div class="border border-[#9A7B3E]/50 bg-[#FDFCF8] rounded p-4 space-y-1.5 text-xs">
                <div class="font-semibold text-[#7A5E29]">Authorised Narrow-Permission Record</div>
                <div><span class="text-[#5A625B]">Station Address:</span> {{ sens.homeStationAddress }}</div>
                <div><span class="text-[#5A625B]">Emergency Contact:</span> {{ sens.emergencyContactName }} ({{ sens.emergencyContactPhone }})</div>
                <div><span class="text-[#5A625B]">Administrative Note:</span> {{ sens.medicalClearanceNote }}</div>
                <div class="font-mono text-[11px] text-[#5A625B]">Audited access by {{ store.activeRoleLabel() }}</div>
              </div>
            }

            <!-- Effective-Dated Assignment History -->
            <div>
              <h3 class="text-sm font-semibold text-[#1C221E] mb-2">Effective-Dated Assignment History</h3>
              <div class="space-y-2">
                @for (asg of personAssignments(); track asg.id) {
                  <div class="text-xs border-b border-[#EFECE2] pb-2 flex items-baseline justify-between gap-2">
                    <div>
                      <span class="font-medium text-[#1C221E]">{{ positionTitle(asg.positionId) }}</span>
                      <span class="text-[#5A625B]"> · {{ unitName(asg.unitId) }} ({{ asg.assignmentType }})</span>
                      <div class="text-[#5A625B]">{{ asg.reason }}</div>
                    </div>
                    <div class="font-mono text-[11px] text-right whitespace-nowrap text-[#4A524C]">
                      <div>{{ asg.status }}</div>
                      <div>{{ asg.startDate }}{{ asg.endDate ? ' -> ' + asg.endDate : ' -> Present' }}</div>
                    </div>
                  </div>
                } @empty {
                  <p class="text-xs text-[#5A625B]">No historical assignments recorded.</p>
                }
              </div>
            </div>

            <!-- Qualifications & Issued Equipment -->
            <div class="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
              <div>
                <h3 class="text-sm font-semibold text-[#1C221E] mb-2">Qualifications</h3>
                <ul class="space-y-1.5 text-xs">
                  @for (q of personQualifications(); track q.id) {
                    <li class="border-b border-[#EFECE2] pb-1.5">
                      <div class="font-mono text-[#2A3B30]">{{ q.qualCode }} · v{{ q.criteriaVersion }}</div>
                      <div class="text-[#1C221E]">{{ q.title }}</div>
                      <div
                        [class.text-[#B91C1C]]="q.status === 'Expired'"
                        [class.text-[#A16207]]="q.status === 'Expiring Soon'"
                        [class.text-[#1E6B43]]="q.status === 'Current'"
                      >
                        {{ q.status }} · Exp {{ q.expiryDate }}
                      </div>
                    </li>
                  } @empty {
                    <li class="text-[#5A625B]">No qualifications held.</li>
                  }
                </ul>
              </div>

              <div>
                <h3 class="text-sm font-semibold text-[#1C221E] mb-2">Issued Equipment & Leave</h3>
                <ul class="space-y-1.5 text-xs">
                  @for (eq of personEquipment(); track eq.id) {
                    <li class="border-b border-[#EFECE2] pb-1.5">
                      <div class="font-mono text-[#2A3B30]">{{ eq.assetId }} ({{ eq.category }})</div>
                      <div class="text-[#1C221E]">{{ eq.nomenclature }}</div>
                      <div class="text-[#5A625B]">{{ eq.serviceability }} · {{ eq.location }}</div>
                    </li>
                  } @empty {
                    <li class="text-[#5A625B]">No equipment currently held.</li>
                  }
                </ul>
                <div class="mt-3 text-xs text-[#5A625B]">
                  Leave Records: <span class="font-mono text-[#1C221E]">{{ personLeaveCount() }}</span>
                </div>
              </div>
            </div>
          } @else {
            <p class="text-sm text-[#5A625B]">Select a personnel record from the register to inspect current details, assignment history, qualifications, and issued custody items.</p>
          }
        </div>
      </div>

      <!-- Create Personnel Modal -->
      @if (showCreateModal()) {
        <div class="fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4" role="dialog" aria-modal="true">
          <div class="bg-[#FCFBF7] border border-[#CFCAC0] rounded max-w-xl w-full p-6 space-y-4 max-h-[90vh] overflow-y-auto">
            <div class="flex items-center justify-between border-b border-[#EAE5D8] pb-3">
              <h2 class="text-lg font-semibold text-[#1C221E]">Create Synthetic Personnel Record</h2>
              <button type="button" (click)="showCreateModal.set(false)" class="text-sm text-[#5A625B] hover:text-[#1C221E] cursor-pointer">Close</button>
            </div>
            <form (ngSubmit)="submitCreatePerson()" class="grid grid-cols-1 sm:grid-cols-2 gap-3 text-sm">
              <label class="block">
                <span class="block text-xs font-medium text-[#4A524C] mb-1">Synthetic Service ID</span>
                <input [(ngModel)]="newServiceId" name="serviceId" required class="w-full min-h-[40px] px-3 bg-white border border-[#CFCAC0] rounded font-mono text-xs" placeholder="SYN-901244" />
              </label>
              <label class="block">
                <span class="block text-xs font-medium text-[#4A524C] mb-1">Rank</span>
                <select [(ngModel)]="newRank" name="rank" class="w-full min-h-[40px] px-3 bg-white border border-[#CFCAC0] rounded">
                  <option value="Pte">Pte</option>
                  <option value="LCpl">LCpl</option>
                  <option value="Cpl">Cpl</option>
                  <option value="Sgt">Sgt</option>
                  <option value="SSgt">SSgt</option>
                  <option value="Capt">Capt</option>
                  <option value="Maj">Maj</option>
                </select>
              </label>
              <label class="block">
                <span class="block text-xs font-medium text-[#4A524C] mb-1">Surname</span>
                <input [(ngModel)]="newSurname" name="surname" required class="w-full min-h-[40px] px-3 bg-white border border-[#CFCAC0] rounded" />
              </label>
              <label class="block">
                <span class="block text-xs font-medium text-[#4A524C] mb-1">Given Names</span>
                <input [(ngModel)]="newGivenNames" name="givenNames" required class="w-full min-h-[40px] px-3 bg-white border border-[#CFCAC0] rounded" />
              </label>
              <label class="block">
                <span class="block text-xs font-medium text-[#4A524C] mb-1">Engagement Start Date</span>
                <input type="date" [(ngModel)]="newEngagementStart" name="engagementStart" required class="w-full min-h-[40px] px-3 bg-white border border-[#CFCAC0] rounded" />
              </label>
              <label class="block">
                <span class="block text-xs font-medium text-[#4A524C] mb-1">Administrative Clearance</span>
                <select [(ngModel)]="newClearanceStatus" name="clearanceStatus" class="w-full min-h-[40px] px-3 bg-white border border-[#CFCAC0] rounded">
                  <option value="Cleared">Cleared</option>
                  <option value="Pending Review">Pending Review</option>
                  <option value="Not Assessed">Not Assessed</option>
                  <option value="Restricted">Restricted</option>
                </select>
              </label>
              <label class="block sm:col-span-2">
                <span class="block text-xs font-medium text-[#4A524C] mb-1">Clearance Provenance</span>
                <input [(ngModel)]="newProvenance" name="provenance" class="w-full min-h-[40px] px-3 bg-white border border-[#CFCAC0] rounded" placeholder="Unit Registry Ref VER-2026-..." />
              </label>
              <label class="block sm:col-span-2">
                <span class="block text-xs font-medium text-[#4A524C] mb-1">Administrative Contact Email</span>
                <input type="email" [(ngModel)]="newEmail" name="email" class="w-full min-h-[40px] px-3 bg-white border border-[#CFCAC0] rounded" placeholder="name@demo-admin.example" />
              </label>
              <div class="sm:col-span-2 flex justify-end gap-3 pt-2">
                <button type="button" (click)="showCreateModal.set(false)" class="min-h-[42px] px-4 border border-[#CFCAC0] rounded text-sm cursor-pointer">Cancel</button>
                <button type="submit" class="min-h-[42px] px-5 bg-[#9A7B3E] text-[#FCFBF7] rounded text-sm font-medium cursor-pointer">Save Record</button>
              </div>
            </form>
          </div>
        </div>
      }
    </div>
  `,
})
export class PersonnelComponent {
  readonly store = inject(StoreService);

  readonly searchTerm = signal('');
  readonly unitFilter = signal('');
  readonly statusFilter = signal('');
  readonly selectedPerson = signal<Person | null>(null);
  readonly sensitiveData = signal<PersonSensitive | null>(null);
  readonly showCreateModal = signal(false);

  newServiceId = `SYN-${Math.floor(100000 + Math.random() * 899999)}`;
  newRank = 'Cpl';
  newSurname = '';
  newGivenNames = '';
  newEngagementStart = '2026-11-01';
  newClearanceStatus: Person['clearanceStatus'] = 'Cleared';
  newProvenance = 'Brigade Registry Ref VER-2026-501';
  newEmail = '';

  readonly filteredPeople = computed(() => {
    const q = this.searchTerm().trim().toLowerCase();
    const u = this.unitFilter();
    const s = this.statusFilter();
    return this.store.people().filter((p) => {
      if (u && p.primaryUnitId !== u) return false;
      if (s && p.status !== s) return false;
      if (!q) return true;
      return (
        p.serviceId.toLowerCase().includes(q) ||
        p.surname.toLowerCase().includes(q) ||
        p.givenNames.toLowerCase().includes(q) ||
        p.rank.toLowerCase().includes(q)
      );
    });
  });

  readonly personAssignments = computed(() => {
    const pid = this.selectedPerson()?.id;
    if (!pid) return [];
    return this.store.assignments().filter((a) => a.personId === pid);
  });

  readonly personQualifications = computed(() => {
    const pid = this.selectedPerson()?.id;
    if (!pid) return [];
    return this.store.qualifications().filter((q) => q.personId === pid);
  });

  readonly personEquipment = computed(() => {
    const pid = this.selectedPerson()?.id;
    if (!pid) return [];
    return this.store.equipmentAssets().filter((e) => e.custodianPersonId === pid);
  });

  readonly personLeaveCount = computed(() => {
    const pid = this.selectedPerson()?.id;
    if (!pid) return 0;
    return this.store.leaveRequests().filter((l) => l.personId === pid).length;
  });

  selectPerson(p: Person): void {
    this.selectedPerson.set(p);
    this.sensitiveData.set(null);
  }

  async inspectSensitive(personId: string): Promise<void> {
    const data = await this.store.loadPersonSensitive(personId);
    this.sensitiveData.set(data);
  }

  unitName(unitId?: string): string {
    if (!unitId) return 'Unassigned';
    return this.store.units().find((u) => u.id === unitId)?.code ?? unitId;
  }

  positionTitle(posId?: string): string {
    if (!posId) return 'No Primary Billet';
    const pos = this.store.positions().find((p) => p.id === posId);
    return pos ? `${pos.code} · ${pos.title}` : posId;
  }

  resetFilters(): void {
    this.searchTerm.set('');
    this.unitFilter.set('');
    this.statusFilter.set('');
  }

  async submitCreatePerson(): Promise<void> {
    if (!this.newSurname.trim() || !this.newGivenNames.trim() || !this.newServiceId.trim()) return;
    const created = await this.store.createPerson({
      serviceId: this.newServiceId,
      surname: this.newSurname,
      givenNames: this.newGivenNames,
      rank: this.newRank,
      engagementStart: this.newEngagementStart,
      clearanceStatus: this.newClearanceStatus,
      clearanceProvenance: this.newProvenance,
      contactEmail: this.newEmail || `${this.newSurname.toLowerCase()}@demo-admin.example`,
      homeStationAddress: 'Demo Garrison Quarters',
      emergencyContactName: `${this.newSurname} Next of Kin (Demo)`,
      emergencyContactPhone: '+44 7700 900421',
    });
    if (created) {
      this.selectedPerson.set(created);
      this.showCreateModal.set(false);
      this.newServiceId = `SYN-${Math.floor(100000 + Math.random() * 899999)}`;
      this.newSurname = '';
      this.newGivenNames = '';
    }
  }
}
