import {ChangeDetectionStrategy, Component, computed, inject, signal} from '@angular/core';
import {FormsModule} from '@angular/forms';
import {EquipmentAsset, EquipmentCategory} from '../core/models';
import {StoreService} from '../core/store.service';

@Component({
  selector: 'app-equipment',
  imports: [FormsModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-6">
      <div class="flex flex-col gap-4 md:flex-row md:items-end md:justify-between border-b border-[#DDD8CB] pb-5">
        <div>
          <p class="text-xs font-medium tracking-wider text-[#5A625B] uppercase">
            Asset Registry & Custody Accountability
          </p>
          <h1 class="mt-1 text-2xl font-semibold text-[#1C221E]">Equipment & Custody</h1>
          <p class="mt-1 text-sm text-[#4A524C]">
            Tracks non-sensitive demonstration assets separating ownership unit, current custody, location, condition, and serviceability.
          </p>
        </div>
        <button
          type="button"
          (click)="showRegisterModal.set(true)"
          class="min-h-[44px] px-4 py-2.5 bg-[#9A7B3E] hover:bg-[#826630] text-[#FCFBF7] text-sm font-medium rounded cursor-pointer"
        >
          Register Asset
        </button>
      </div>

      <!-- Category Filter -->
      <div class="flex flex-wrap gap-1.5 bg-[#FCFBF7] border border-[#DDD8CB] p-1.5 rounded">
        @for (cat of categories; track cat) {
          <button
            type="button"
            (click)="categoryFilter.set(cat)"
            class="px-3 py-1.5 text-xs font-medium rounded transition-colors cursor-pointer"
            [class.bg-[#222924]]="categoryFilter() === cat"
            [class.text-[#F5F2EA]]="categoryFilter() === cat"
            [class.text-[#4A524C]]="categoryFilter() !== cat"
          >
            {{ cat }}
          </button>
        }
      </div>

      <!-- Asset Table -->
      <section class="bg-[#FCFBF7] border border-[#DDD8CB] rounded overflow-hidden">
        <div class="overflow-x-auto">
          <table class="w-full text-left border-collapse text-sm">
            <thead>
              <tr class="border-b border-[#DDD8CB] bg-[#F5F2EA] text-xs text-[#5A625B]">
                <th class="py-3 px-4 font-medium">Asset ID & Serial</th>
                <th class="py-3 px-4 font-medium">Category & Nomenclature</th>
                <th class="py-3 px-4 font-medium">Owner / Location</th>
                <th class="py-3 px-4 font-medium">Current Custodian</th>
                <th class="py-3 px-4 font-medium">Condition & Serviceability</th>
                <th class="py-3 px-4 font-medium text-right">Custody Action</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-[#EFECE2]">
              @for (a of filteredAssets(); track a.id) {
                <tr class="hover:bg-[#F5F2EA]/70">
                  <td class="py-3 px-4 font-mono text-xs">
                    <div class="font-medium text-[#2A3B30]">{{ a.assetId }}</div>
                    <div class="text-[#5A625B]">{{ a.serialNumber }}</div>
                  </td>
                  <td class="py-3 px-4">
                    <div class="text-xs text-[#5A625B]">{{ a.category }}</div>
                    <div class="font-medium text-[#1C221E]">{{ a.nomenclature }}</div>
                  </td>
                  <td class="py-3 px-4 text-xs text-[#3C443E]">
                    <div>Owner: {{ unitCode(a.ownerUnitId) }}</div>
                    <div class="text-[#5A625B]">{{ a.location }}</div>
                  </td>
                  <td class="py-3 px-4 text-xs">
                    @if (a.custodianPersonId) {
                      <div class="font-medium text-[#1C221E]">{{ personName(a.custodianPersonId) }}</div>
                      <div class="font-mono text-[11px] text-[#5A625B]">Ack {{ a.custodianAckAt?.slice(0, 10) }}</div>
                    } @else {
                      <span class="text-[#5A625B]">Unissued (Unit Stores)</span>
                    }
                  </td>
                  <td class="py-3 px-4 text-xs">
                    <div
                      class="font-semibold"
                      [class.text-[#1E6B43]]="a.serviceability === 'Serviceable'"
                      [class.text-[#A16207]]="a.serviceability === 'Awaiting Inspection' || a.serviceability === 'In Maintenance'"
                      [class.text-[#B91C1C]]="a.serviceability === 'Unserviceable'"
                    >
                      {{ a.serviceability }}
                    </div>
                    <div class="text-[#5A625B]">Cond: {{ a.condition }} · Insp: {{ a.inspectionStatus }}</div>
                  </td>
                  <td class="py-3 px-4 text-right whitespace-nowrap space-x-2">
                    @if (!a.custodianPersonId) {
                      <button
                        type="button"
                        (click)="openIssueModal(a)"
                        class="min-h-[34px] px-3 py-1 bg-[#222924] text-[#F5F2EA] text-xs font-medium rounded cursor-pointer"
                      >
                        Issue Custody
                      </button>
                    } @else {
                      <button
                        type="button"
                        (click)="returnToStores(a)"
                        class="min-h-[34px] px-3 py-1 bg-[#FCFBF7] border border-[#CFCAC0] text-[#1C221E] text-xs font-medium rounded cursor-pointer"
                      >
                        Return to Stores
                      </button>
                    }
                  </td>
                </tr>
              }
            </tbody>
          </table>
        </div>
      </section>

      <!-- Custody Handover Log -->
      <section class="bg-[#FCFBF7] border border-[#DDD8CB] rounded p-5">
        <h2 class="text-base font-semibold text-[#1C221E] mb-3">Custody Issue & Return Acknowledgement History</h2>
        <div class="overflow-x-auto">
          <table class="w-full text-left border-collapse text-xs">
            <thead>
              <tr class="border-b border-[#DDD8CB] text-[#5A625B]">
                <th class="py-2 pr-4 font-medium">Timestamp</th>
                <th class="py-2 pr-4 font-medium">Asset</th>
                <th class="py-2 pr-4 font-medium">Action</th>
                <th class="py-2 pr-4 font-medium">Custodian</th>
                <th class="py-2 pr-4 font-medium">Acknowledgement</th>
                <th class="py-2 font-medium">Notes</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-[#EFECE2]">
              @for (c of store.custodyRecords(); track c.id) {
                <tr>
                  <td class="py-2 pr-4 font-mono text-[#5A625B]">{{ c.createdAt.slice(0, 19).replace('T', ' ') }}</td>
                  <td class="py-2 pr-4 font-mono text-[#2A3B30]">{{ assetCode(c.assetId) }}</td>
                  <td class="py-2 pr-4 font-medium">{{ c.actionType }}</td>
                  <td class="py-2 pr-4">{{ c.toPersonId ? personName(c.toPersonId) : 'Unit Stores' }}</td>
                  <td class="py-2 pr-4 font-medium text-[#1E6B43]">{{ c.acknowledged ? 'Acknowledged' : 'Pending' }}</td>
                  <td class="py-2 text-[#4A524C]">{{ c.notes }}</td>
                </tr>
              }
            </tbody>
          </table>
        </div>
      </section>

      <!-- Issue Modal -->
      @if (issuingAsset(); as asset) {
        <div class="fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4" role="dialog" aria-modal="true">
          <div class="bg-[#FCFBF7] border border-[#CFCAC0] rounded max-w-lg w-full p-6 space-y-4">
            <h2 class="text-lg font-semibold text-[#1C221E]">Issue Custody: {{ asset.assetId }}</h2>
            <form (ngSubmit)="submitIssue()" class="space-y-3 text-sm">
              <label class="block">
                <span class="block text-xs font-medium text-[#4A524C] mb-1">Recipient Custodian</span>
                <select [(ngModel)]="issuePersonId" name="issuePersonId" required class="w-full min-h-[40px] px-3 bg-white border border-[#CFCAC0] rounded">
                  @for (p of store.people(); track p.id) {
                    <option [value]="p.id">{{ p.serviceId }} · {{ p.rank }} {{ p.surname }}</option>
                  }
                </select>
              </label>
              <label class="block">
                <span class="block text-xs font-medium text-[#4A524C] mb-1">Administrative Location</span>
                <input [(ngModel)]="issueLocation" name="issueLocation" required class="w-full min-h-[40px] px-3 bg-white border border-[#CFCAC0] rounded" />
              </label>
              <label class="block">
                <span class="block text-xs font-medium text-[#4A524C] mb-1">Handover Notes</span>
                <input [(ngModel)]="issueNotes" name="issueNotes" required class="w-full min-h-[40px] px-3 bg-white border border-[#CFCAC0] rounded" />
              </label>
              <label class="flex items-center gap-2 text-xs text-[#1C221E] pt-1">
                <input type="checkbox" [(ngModel)]="issueAck" name="issueAck" class="w-4 h-4" />
                <span>Recipient custodian acknowledgement confirmed (required for handover)</span>
              </label>
              <div class="flex justify-end gap-3 pt-2">
                <button type="button" (click)="issuingAsset.set(null)" class="min-h-[40px] px-4 border border-[#CFCAC0] rounded cursor-pointer">Cancel</button>
                <button type="submit" class="min-h-[40px] px-5 bg-[#9A7B3E] text-[#FCFBF7] rounded font-medium cursor-pointer">Confirm Issue</button>
              </div>
            </form>
          </div>
        </div>
      }

      <!-- Register Asset Modal -->
      @if (showRegisterModal()) {
        <div class="fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4" role="dialog" aria-modal="true">
          <div class="bg-[#FCFBF7] border border-[#CFCAC0] rounded max-w-lg w-full p-6 space-y-4">
            <h2 class="text-lg font-semibold text-[#1C221E]">Register Demonstration Equipment Asset</h2>
            <form (ngSubmit)="submitRegister()" class="space-y-3 text-sm">
              <div class="grid grid-cols-2 gap-3">
                <label class="block">
                  <span class="block text-xs font-medium text-[#4A524C] mb-1">Asset ID</span>
                  <input [(ngModel)]="regAssetId" name="regAssetId" required class="w-full min-h-[40px] px-3 bg-white border border-[#CFCAC0] rounded font-mono text-xs" placeholder="AST-LPT-0205" />
                </label>
                <label class="block">
                  <span class="block text-xs font-medium text-[#4A524C] mb-1">Category</span>
                  <select [(ngModel)]="regCategory" name="regCategory" class="w-full min-h-[40px] px-3 bg-white border border-[#CFCAC0] rounded">
                    @for (cat of categories.slice(1); track cat) {
                      <option [value]="cat">{{ cat }}</option>
                    }
                  </select>
                </label>
              </div>
              <label class="block">
                <span class="block text-xs font-medium text-[#4A524C] mb-1">Nomenclature</span>
                <input [(ngModel)]="regNomenclature" name="regNomenclature" required class="w-full min-h-[40px] px-3 bg-white border border-[#CFCAC0] rounded" />
              </label>
              <div class="grid grid-cols-2 gap-3">
                <label class="block">
                  <span class="block text-xs font-medium text-[#4A524C] mb-1">Serial Number</span>
                  <input [(ngModel)]="regSerial" name="regSerial" required class="w-full min-h-[40px] px-3 bg-white border border-[#CFCAC0] rounded font-mono text-xs" />
                </label>
                <label class="block">
                  <span class="block text-xs font-medium text-[#4A524C] mb-1">Owner Unit</span>
                  <select [(ngModel)]="regUnitId" name="regUnitId" class="w-full min-h-[40px] px-3 bg-white border border-[#CFCAC0] rounded">
                    @for (u of store.units(); track u.id) {
                      <option [value]="u.id">{{ u.code }}</option>
                    }
                  </select>
                </label>
              </div>
              <label class="block">
                <span class="block text-xs font-medium text-[#4A524C] mb-1">Storage / Station Location</span>
                <input [(ngModel)]="regLocation" name="regLocation" required class="w-full min-h-[40px] px-3 bg-white border border-[#CFCAC0] rounded" />
              </label>
              <div class="flex justify-end gap-3 pt-2">
                <button type="button" (click)="showRegisterModal.set(false)" class="min-h-[40px] px-4 border border-[#CFCAC0] rounded cursor-pointer">Cancel</button>
                <button type="submit" class="min-h-[40px] px-5 bg-[#9A7B3E] text-[#FCFBF7] rounded font-medium cursor-pointer">Register</button>
              </div>
            </form>
          </div>
        </div>
      }
    </div>
  `,
})
export class EquipmentComponent {
  readonly store = inject(StoreService);

  readonly categories: ('All' | EquipmentCategory)[] = [
    'All',
    'Laptop',
    'Radio',
    'Vehicle',
    'Workshop Equipment',
    'Protective Equipment',
    'Furniture',
    'Training Device',
  ];

  readonly categoryFilter = signal<'All' | EquipmentCategory>('All');
  readonly issuingAsset = signal<EquipmentAsset | null>(null);
  readonly showRegisterModal = signal(false);

  issuePersonId = '';
  issueLocation = '';
  issueNotes = 'Issued under unit custody checklist';
  issueAck = true;

  regAssetId = `AST-LPT-${Math.floor(1000 + Math.random() * 8999)}`;
  regCategory: EquipmentCategory = 'Laptop';
  regNomenclature = 'Encrypted Administrative Field Laptop';
  regSerial = `SN-DEMO-${Math.floor(10000 + Math.random() * 89999)}`;
  regUnitId = 'unit-sig-regt';
  regLocation = '14 Sqn Secure Store';

  readonly filteredAssets = computed(() => {
    const cat = this.categoryFilter();
    return this.store.equipmentAssets().filter((a) => cat === 'All' || a.category === cat);
  });

  unitCode(id: string): string {
    return this.store.units().find((u) => u.id === id)?.code ?? id;
  }

  assetCode(docId: string): string {
    return this.store.equipmentAssets().find((a) => a.id === docId)?.assetId ?? docId;
  }

  personName(id: string): string {
    const p = this.store.people().find((x) => x.id === id);
    return p ? `${p.rank} ${p.surname} (${p.serviceId})` : id;
  }

  openIssueModal(asset: EquipmentAsset): void {
    this.issuingAsset.set(asset);
    this.issuePersonId = this.store.people()[0]?.id ?? '';
    this.issueLocation = asset.location;
    this.issueAck = true;
  }

  async submitIssue(): Promise<void> {
    const asset = this.issuingAsset();
    if (!asset) return;
    const ok = await this.store.issueOrTransferAsset({
      assetDocId: asset.id,
      toPersonId: this.issuePersonId,
      location: this.issueLocation,
      acknowledged: this.issueAck,
      notes: this.issueNotes,
    });
    if (ok) this.issuingAsset.set(null);
  }

  async returnToStores(asset: EquipmentAsset): Promise<void> {
    await this.store.returnAssetToStores(asset.id, `${this.unitCode(asset.ownerUnitId)} Stores Cage`);
  }

  async submitRegister(): Promise<void> {
    const created = await this.store.registerEquipmentAsset({
      assetId: this.regAssetId,
      category: this.regCategory,
      nomenclature: this.regNomenclature,
      serialNumber: this.regSerial,
      ownerUnitId: this.regUnitId,
      location: this.regLocation,
    });
    if (created) this.showRegisterModal.set(false);
  }
}
