import {ChangeDetectionStrategy, Component, computed, inject, signal} from '@angular/core';
import {FormsModule} from '@angular/forms';
import {Enrolment} from '../core/models';
import {StoreService} from '../core/store.service';

@Component({
  selector: 'app-training',
  imports: [FormsModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-6">
      <div class="flex flex-col gap-4 md:flex-row md:items-end md:justify-between border-b border-[#DDD8CB] pb-5">
        <div>
          <p class="text-xs font-medium tracking-wider text-[#5A625B] uppercase">
            Course Catalogue, Qualifications & Capacity Planning
          </p>
          <h1 class="mt-1 text-2xl font-semibold text-[#1C221E]">Training & Qualifications</h1>
          <p class="mt-1 text-sm text-[#4A524C]">
            Separates course attendance from qualification pass/fail, preserves criteria versions, and requires documented reasons for result corrections.
          </p>
        </div>
        <button
          type="button"
          (click)="showEnrolModal.set(true)"
          class="min-h-[44px] px-4 py-2.5 bg-[#9A7B3E] hover:bg-[#826630] text-[#FCFBF7] text-sm font-medium rounded cursor-pointer"
        >
          Enrol on Course
        </button>
      </div>

      <!-- Course Catalogue & Capacity Forecast -->
      <section class="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-4">
        @for (c of courseForecast(); track c.course.id) {
          <div class="bg-[#FCFBF7] border border-[#DDD8CB] rounded p-4 space-y-2">
            <div class="flex items-center justify-between text-xs font-mono text-[#5A625B]">
              <span>{{ c.course.code }}</span>
              <span>{{ c.course.durationDays }}d · Cap {{ c.course.capacity }}</span>
            </div>
            <h2 class="text-sm font-semibold text-[#1C221E]">{{ c.course.title }}</h2>
            <p class="text-xs text-[#4A524C]">
              Prerequisites: {{ c.course.prerequisites.length ? c.course.prerequisites.join(', ') : 'None' }}
            </p>
            <div class="pt-2 border-t border-[#EAE5D8] flex items-center justify-between text-xs">
              <span class="text-[#5A625B]">Active Enrolments</span>
              <span class="font-mono font-medium text-[#1C221E]">{{ c.enrolled }} / {{ c.course.capacity }}</span>
            </div>
          </div>
        }
      </section>

      <!-- Enrolments & Attendance vs Results -->
      <section class="bg-[#FCFBF7] border border-[#DDD8CB] rounded overflow-hidden">
        <div class="p-4 border-b border-[#DDD8CB]">
          <h2 class="text-base font-semibold text-[#1C221E]">Enrolments, Attendance & Assessment Results</h2>
        </div>
        <div class="overflow-x-auto">
          <table class="w-full text-left border-collapse text-sm">
            <thead>
              <tr class="border-b border-[#DDD8CB] bg-[#F5F2EA] text-xs text-[#5A625B]">
                <th class="py-3 px-4 font-medium">Course</th>
                <th class="py-3 px-4 font-medium">Candidate</th>
                <th class="py-3 px-4 font-medium">Session Date</th>
                <th class="py-3 px-4 font-medium">Attendance</th>
                <th class="py-3 px-4 font-medium">Result</th>
                <th class="py-3 px-4 font-medium">Provenance</th>
                <th class="py-3 px-4 font-medium text-right">Actions</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-[#EFECE2]">
              @for (e of store.enrolments(); track e.id) {
                <tr class="hover:bg-[#F5F2EA]/70">
                  <td class="py-3 px-4 font-mono text-xs text-[#2A3B30]">{{ courseCode(e.courseId) }}</td>
                  <td class="py-3 px-4 text-xs font-medium text-[#1C221E]">{{ personName(e.personId) }}</td>
                  <td class="py-3 px-4 font-mono text-xs text-[#5A625B]">{{ e.sessionDate }}</td>
                  <td class="py-3 px-4 text-xs text-[#1C221E]">{{ e.attendanceStatus }}</td>
                  <td class="py-3 px-4 text-xs font-medium">
                    <span
                      [class.text-[#1E6B43]]="e.resultStatus === 'Passed'"
                      [class.text-[#B91C1C]]="e.resultStatus === 'Failed'"
                      [class.text-[#A16207]]="e.resultStatus === 'Deferred' || e.resultStatus === 'Pending'"
                    >
                      {{ e.resultStatus }}
                    </span>
                    @if (e.originalResult) {
                      <span class="text-[#5A625B] font-normal"> (Orig: {{ e.originalResult }})</span>
                    }
                  </td>
                  <td class="py-3 px-4 text-xs text-[#4A524C] max-w-xs">
                    {{ e.correctionReason || 'Initial assessment record' }}
                  </td>
                  <td class="py-3 px-4 text-right whitespace-nowrap space-x-2">
                    @if (e.resultStatus === 'Pending') {
                      <button
                        type="button"
                        (click)="markAttendedAndPassed(e)"
                        class="min-h-[34px] px-3 py-1 bg-[#1E6B43] text-white text-xs font-medium rounded cursor-pointer"
                      >
                        Record Pass & Award
                      </button>
                    }
                    <button
                      type="button"
                      (click)="openCorrectionModal(e)"
                      class="min-h-[34px] px-3 py-1 bg-[#FCFBF7] border border-[#CFCAC0] text-[#1C221E] text-xs font-medium rounded cursor-pointer"
                    >
                      Correct Result
                    </button>
                  </td>
                </tr>
              }
            </tbody>
          </table>
        </div>
      </section>

      <!-- Qualifications & Expiry Monitor -->
      <section class="bg-[#FCFBF7] border border-[#DDD8CB] rounded overflow-hidden">
        <div class="p-4 border-b border-[#DDD8CB] flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h2 class="text-base font-semibold text-[#1C221E]">Qualification Awards & Expiry Register</h2>
            <p class="text-xs text-[#5A625B]">Criteria version and evidence reference retained at time of award.</p>
          </div>
          <div class="flex gap-1 bg-[#F5F2EA] p-1 rounded border border-[#DDD8CB]">
            @for (st of ['All', 'Current', 'Expiring Soon', 'Expired']; track st) {
              <button
                type="button"
                (click)="qualFilter.set(st)"
                class="px-3 py-1.5 text-xs font-medium rounded transition-colors cursor-pointer"
                [class.bg-[#222924]]="qualFilter() === st"
                [class.text-[#F5F2EA]]="qualFilter() === st"
                [class.text-[#4A524C]]="qualFilter() !== st"
              >
                {{ st }}
              </button>
            }
          </div>
        </div>
        <div class="overflow-x-auto">
          <table class="w-full text-left border-collapse text-sm">
            <thead>
              <tr class="border-b border-[#DDD8CB] bg-[#F5F2EA] text-xs text-[#5A625B]">
                <th class="py-3 px-4 font-medium">Qual Code</th>
                <th class="py-3 px-4 font-medium">Holder</th>
                <th class="py-3 px-4 font-medium">Criteria Version</th>
                <th class="py-3 px-4 font-medium">Awarded</th>
                <th class="py-3 px-4 font-medium">Expiry</th>
                <th class="py-3 px-4 font-medium">Evidence Ref</th>
                <th class="py-3 px-4 font-medium">Status</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-[#EFECE2]">
              @for (q of filteredQualifications(); track q.id) {
                <tr class="hover:bg-[#F5F2EA]/70">
                  <td class="py-3 px-4 font-mono text-xs text-[#2A3B30]">{{ q.qualCode }}</td>
                  <td class="py-3 px-4 text-xs font-medium text-[#1C221E]">{{ personName(q.personId) }}</td>
                  <td class="py-3 px-4 font-mono text-xs text-[#5A625B]">v{{ q.criteriaVersion }}</td>
                  <td class="py-3 px-4 font-mono text-xs text-[#5A625B]">{{ q.awardedDate }}</td>
                  <td class="py-3 px-4 font-mono text-xs text-[#1C221E]">{{ q.expiryDate }}</td>
                  <td class="py-3 px-4 font-mono text-xs text-[#5A625B]">{{ q.evidenceRef || '—' }}</td>
                  <td class="py-3 px-4 text-xs font-semibold">
                    <span
                      [class.text-[#1E6B43]]="q.status === 'Current'"
                      [class.text-[#A16207]]="q.status === 'Expiring Soon'"
                      [class.text-[#B91C1C]]="q.status === 'Expired' || q.status === 'Revoked'"
                    >
                      {{ q.status }}
                    </span>
                  </td>
                </tr>
              }
            </tbody>
          </table>
        </div>
      </section>

      <!-- Enrol Modal -->
      @if (showEnrolModal()) {
        <div class="fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4" role="dialog" aria-modal="true">
          <div class="bg-[#FCFBF7] border border-[#CFCAC0] rounded max-w-lg w-full p-6 space-y-4">
            <h2 class="text-lg font-semibold text-[#1C221E]">Enrol Personnel on Training Course</h2>
            <form (ngSubmit)="submitEnrol()" class="space-y-3 text-sm">
              <label class="block">
                <span class="block text-xs font-medium text-[#4A524C] mb-1">Course</span>
                <select [(ngModel)]="enrolCourseId" name="courseId" required class="w-full min-h-[40px] px-3 bg-white border border-[#CFCAC0] rounded">
                  @for (c of store.courses(); track c.id) {
                    <option [value]="c.id">{{ c.code }} · {{ c.title }} (Prereq: {{ c.prerequisites.join(', ') || 'None' }})</option>
                  }
                </select>
              </label>
              <label class="block">
                <span class="block text-xs font-medium text-[#4A524C] mb-1">Personnel</span>
                <select [(ngModel)]="enrolPersonId" name="personId" required class="w-full min-h-[40px] px-3 bg-white border border-[#CFCAC0] rounded">
                  @for (p of store.people(); track p.id) {
                    <option [value]="p.id">{{ p.serviceId }} · {{ p.rank }} {{ p.surname }}</option>
                  }
                </select>
              </label>
              <label class="block">
                <span class="block text-xs font-medium text-[#4A524C] mb-1">Session Date</span>
                <input type="date" [(ngModel)]="enrolSessionDate" name="sessionDate" required class="w-full min-h-[40px] px-3 bg-white border border-[#CFCAC0] rounded" />
              </label>
              <div class="flex justify-end gap-3 pt-2">
                <button type="button" (click)="showEnrolModal.set(false)" class="min-h-[40px] px-4 border border-[#CFCAC0] rounded cursor-pointer">Cancel</button>
                <button type="submit" class="min-h-[40px] px-5 bg-[#9A7B3E] text-[#FCFBF7] rounded font-medium cursor-pointer">Enrol</button>
              </div>
            </form>
          </div>
        </div>
      }

      <!-- Correction Modal -->
      @if (correctingEnrolment(); as enr) {
        <div class="fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4" role="dialog" aria-modal="true">
          <div class="bg-[#FCFBF7] border border-[#CFCAC0] rounded max-w-lg w-full p-6 space-y-4">
            <h2 class="text-lg font-semibold text-[#1C221E]">Authorised Result Correction</h2>
            <p class="text-xs text-[#4A524C]">
              Original result ({{ enr.originalResult || enr.resultStatus }}) is retained in audit history.
            </p>
            <form (ngSubmit)="submitCorrection()" class="space-y-3 text-sm">
              <div class="grid grid-cols-2 gap-3">
                <label class="block">
                  <span class="block text-xs font-medium text-[#4A524C] mb-1">Attendance</span>
                  <select [(ngModel)]="corrAttendance" name="corrAttendance" class="w-full min-h-[40px] px-3 bg-white border border-[#CFCAC0] rounded">
                    <option value="Attended">Attended</option>
                    <option value="Absent">Absent</option>
                    <option value="Withdrawn">Withdrawn</option>
                  </select>
                </label>
                <label class="block">
                  <span class="block text-xs font-medium text-[#4A524C] mb-1">Updated Result</span>
                  <select [(ngModel)]="corrResult" name="corrResult" class="w-full min-h-[40px] px-3 bg-white border border-[#CFCAC0] rounded">
                    <option value="Passed">Passed</option>
                    <option value="Failed">Failed</option>
                    <option value="Deferred">Deferred</option>
                  </select>
                </label>
              </div>
              <label class="block">
                <span class="block text-xs font-medium text-[#4A524C] mb-1">Authorised Correction Reason</span>
                <input [(ngModel)]="corrReason" name="corrReason" required class="w-full min-h-[40px] px-3 bg-white border border-[#CFCAC0] rounded" placeholder="Assessment board review reference..." />
              </label>
              <div class="flex justify-end gap-3 pt-2">
                <button type="button" (click)="correctingEnrolment.set(null)" class="min-h-[40px] px-4 border border-[#CFCAC0] rounded cursor-pointer">Cancel</button>
                <button type="submit" class="min-h-[40px] px-5 bg-[#9A7B3E] text-[#FCFBF7] rounded font-medium cursor-pointer">Record Correction</button>
              </div>
            </form>
          </div>
        </div>
      }
    </div>
  `,
})
export class TrainingComponent {
  readonly store = inject(StoreService);

  readonly qualFilter = signal('All');
  readonly showEnrolModal = signal(false);
  readonly correctingEnrolment = signal<Enrolment | null>(null);

  enrolCourseId = 'crs-adm-101';
  enrolPersonId = 'per-008';
  enrolSessionDate = '2026-12-01';

  corrAttendance: Enrolment['attendanceStatus'] = 'Attended';
  corrResult: Enrolment['resultStatus'] = 'Passed';
  corrReason = '';

  readonly courseForecast = computed(() =>
    this.store.courses().map((course) => ({
      course,
      enrolled: this.store.enrolments().filter((e) => e.courseId === course.id && e.attendanceStatus === 'Enrolled').length,
    })),
  );

  readonly filteredQualifications = computed(() => {
    const f = this.qualFilter();
    return this.store.qualifications().filter((q) => f === 'All' || q.status === f);
  });

  courseCode(id: string): string {
    return this.store.courses().find((c) => c.id === id)?.code ?? id;
  }

  personName(id: string): string {
    const p = this.store.people().find((x) => x.id === id);
    return p ? `${p.rank} ${p.surname} (${p.serviceId})` : id;
  }

  async submitEnrol(): Promise<void> {
    const res = await this.store.enrolInCourse({
      courseId: this.enrolCourseId,
      personId: this.enrolPersonId,
      sessionDate: this.enrolSessionDate,
    });
    if (res) this.showEnrolModal.set(false);
  }

  async markAttendedAndPassed(e: Enrolment): Promise<void> {
    await this.store.updateEnrolmentOutcome({
      enrolmentId: e.id,
      attendanceStatus: 'Attended',
      resultStatus: 'Passed',
    });
  }

  openCorrectionModal(e: Enrolment): void {
    this.correctingEnrolment.set(e);
    this.corrAttendance = e.attendanceStatus === 'Enrolled' ? 'Attended' : e.attendanceStatus;
    this.corrResult = e.resultStatus === 'Pending' ? 'Passed' : e.resultStatus;
    this.corrReason = '';
  }

  async submitCorrection(): Promise<void> {
    const e = this.correctingEnrolment();
    if (!e || !this.corrReason.trim()) return;
    const ok = await this.store.updateEnrolmentOutcome({
      enrolmentId: e.id,
      attendanceStatus: this.corrAttendance,
      resultStatus: this.corrResult,
      correctionReason: this.corrReason,
    });
    if (ok) this.correctingEnrolment.set(null);
  }
}
