import {ChangeDetectionStrategy, Component, inject, signal} from '@angular/core';
import {FormsModule} from '@angular/forms';
import {MaintenanceOrder} from '../core/models';
import {StoreService} from '../core/store.service';

@Component({
  selector: 'app-maintenance',
  imports: [FormsModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-6">
      <div class="flex flex-col gap-4 md:flex-row md:items-end md:justify-between border-b border-[#DDD8CB] pb-5">
        <div>
          <p class="text-xs font-medium tracking-wider text-[#5A625B] uppercase">
            Preventive Schedules, Fault Reports & Independent Release
          </p>
          <h1 class="mt-1 text-2xl font-semibold text-[#1C221E]">Maintenance & Inspection</h1>
          <p class="mt-1 text-sm text-[#4A524C]">
            Completing a repair transitions work orders to "Awaiting Inspection". Equipment is only declared Serviceable after authorised inspection and release.
          </p>
        </div>
        <button
          type="button"
          (click)="showFaultModal.set(true)"
          class="min-h-[44px] px-4 py-2.5 bg-[#9A7B3E] hover:bg-[#826630] text-[#FCFBF7] text-sm font-medium rounded cursor-pointer"
        >
          Report Fault / Open Order
        </button>
      </div>

      <section class="bg-[#FCFBF7] border border-[#DDD8CB] rounded overflow-hidden">
        <div class="overflow-x-auto">
          <table class="w-full text-left border-collapse text-sm">
            <thead>
              <tr class="border-b border-[#DDD8CB] bg-[#F5F2EA] text-xs text-[#5A625B]">
                <th class="py-3 px-4 font-medium">Order Ref</th>
                <th class="py-3 px-4 font-medium">Asset</th>
                <th class="py-3 px-4 font-medium">Type & Priority</th>
                <th class="py-3 px-4 font-medium">Fault / Scope</th>
                <th class="py-3 px-4 font-medium">Parts Reserved</th>
                <th class="py-3 px-4 font-medium">Workflow State</th>
                <th class="py-3 px-4 font-medium text-right">Actions</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-[#EFECE2]">
              @for (m of store.maintenanceOrders(); track m.id) {
                <tr class="hover:bg-[#F5F2EA]/70">
                  <td class="py-3 px-4 font-mono text-xs font-medium text-[#2A3B30] whitespace-nowrap">{{ m.orderRef }}</td>
                  <td class="py-3 px-4 text-xs">
                    <div class="font-mono text-[#1C221E]">{{ assetCode(m.assetId) }}</div>
                    <div class="text-[#5A625B]">{{ assetName(m.assetId) }}</div>
                  </td>
                  <td class="py-3 px-4 text-xs">
                    <div>{{ m.orderType }}</div>
                    <div
                      class="font-medium"
                      [class.text-[#B91C1C]]="m.priority === 'Safety Hold' || m.priority === 'Urgent'"
                      [class.text-[#4B5563]]="m.priority === 'Routine'"
                    >
                      {{ m.priority }}
                    </div>
                  </td>
                  <td class="py-3 px-4 text-xs text-[#3C443E] max-w-xs">{{ m.faultDescription }}</td>
                  <td class="py-3 px-4 font-mono text-xs text-[#5A625B]">{{ m.partsReserved || 'None' }}</td>
                  <td class="py-3 px-4 text-xs font-semibold">
                    <span
                      [class.text-[#1E6B43]]="m.status === 'Released Serviceable'"
                      [class.text-[#A16207]]="m.status === 'Repair Completed - Awaiting Inspection' || m.status === 'Open' || m.status === 'In Progress'"
                      [class.text-[#B91C1C]]="m.status === 'Closed Unserviceable'"
                    >
                      {{ m.status }}
                    </span>
                    @if (m.releasedAt) {
                      <div class="font-mono font-normal text-[11px] text-[#5A625B]">
                        Released {{ m.releasedAt.slice(0, 10) }}
                      </div>
                    }
                  </td>
                  <td class="py-3 px-4 text-right whitespace-nowrap space-x-2">
                    @if (m.status === 'Open' || m.status === 'In Progress') {
                      <button
                        type="button"
                        (click)="store.completeRepairAwaitingInspection(m.id)"
                        class="min-h-[34px] px-3 py-1 bg-[#222924] text-[#F5F2EA] text-xs font-medium rounded cursor-pointer"
                      >
                        Complete Repair
                      </button>
                    }
                    @if (m.status === 'Repair Completed - Awaiting Inspection') {
                      <button
                        type="button"
                        (click)="store.releaseMaintenanceOrder(m.id)"
                        class="min-h-[34px] px-3 py-1 bg-[#1E6B43] text-white text-xs font-medium rounded cursor-pointer"
                      >
                        Inspect & Release Serviceable
                      </button>
                    }
                  </td>
                </tr>
              } @empty {
                <tr>
                  <td colspan="7" class="py-8 text-center text-sm text-[#5A625B]">
                    No maintenance work orders found.
                  </td>
                </tr>
              }
            </tbody>
          </table>
        </div>
      </section>

      <!-- Fault Report Modal -->
      @if (showFaultModal()) {
        <div class="fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4" role="dialog" aria-modal="true">
          <div class="bg-[#FCFBF7] border border-[#CFCAC0] rounded max-w-lg w-full p-6 space-y-4">
            <h2 class="text-lg font-semibold text-[#1C221E]">Report Equipment Fault / Open Work Order</h2>
            <form (ngSubmit)="submitFault()" class="space-y-3 text-sm">
              <label class="block">
                <span class="block text-xs font-medium text-[#4A524C] mb-1">Equipment Asset</span>
                <select [(ngModel)]="faultAssetId" name="faultAssetId" required class="w-full min-h-[40px] px-3 bg-white border border-[#CFCAC0] rounded">
                  @for (a of store.equipmentAssets(); track a.id) {
                    <option [value]="a.id">{{ a.assetId }} · {{ a.nomenclature }}</option>
                  }
                </select>
              </label>
              <div class="grid grid-cols-2 gap-3">
                <label class="block">
                  <span class="block text-xs font-medium text-[#4A524C] mb-1">Order Type</span>
                  <select [(ngModel)]="faultOrderType" name="faultOrderType" class="w-full min-h-[40px] px-3 bg-white border border-[#CFCAC0] rounded">
                    <option value="Corrective Fault">Corrective Fault</option>
                    <option value="Preventive">Preventive</option>
                    <option value="Inspection">Inspection</option>
                  </select>
                </label>
                <label class="block">
                  <span class="block text-xs font-medium text-[#4A524C] mb-1">Priority</span>
                  <select [(ngModel)]="faultPriority" name="faultPriority" class="w-full min-h-[40px] px-3 bg-white border border-[#CFCAC0] rounded">
                    <option value="Routine">Routine</option>
                    <option value="Urgent">Urgent</option>
                    <option value="Safety Hold">Safety Hold</option>
                  </select>
                </label>
              </div>
              <label class="block">
                <span class="block text-xs font-medium text-[#4A524C] mb-1">Fault Description</span>
                <textarea [(ngModel)]="faultDesc" name="faultDesc" rows="3" required class="w-full p-3 bg-white border border-[#CFCAC0] rounded" placeholder="Describe observed fault or preventive schedule scope..."></textarea>
              </label>
              <label class="block">
                <span class="block text-xs font-medium text-[#4A524C] mb-1">Parts Reservation Reference (Optional)</span>
                <input [(ngModel)]="faultParts" name="faultParts" class="w-full min-h-[40px] px-3 bg-white border border-[#CFCAC0] rounded font-mono text-xs" placeholder="SKU-FLT-109 x1" />
              </label>
              <div class="flex justify-end gap-3 pt-2">
                <button type="button" (click)="showFaultModal.set(false)" class="min-h-[40px] px-4 border border-[#CFCAC0] rounded cursor-pointer">Cancel</button>
                <button type="submit" class="min-h-[40px] px-5 bg-[#9A7B3E] text-[#FCFBF7] rounded font-medium cursor-pointer">Open Work Order</button>
              </div>
            </form>
          </div>
        </div>
      }
    </div>
  `,
})
export class MaintenanceComponent {
  readonly store = inject(StoreService);
  readonly showFaultModal = signal(false);

  faultAssetId = 'eqp-002';
  faultOrderType: MaintenanceOrder['orderType'] = 'Corrective Fault';
  faultPriority: MaintenanceOrder['priority'] = 'Urgent';
  faultDesc = '';
  faultParts = '';

  assetCode(docId: string): string {
    return this.store.equipmentAssets().find((a) => a.id === docId)?.assetId ?? docId;
  }

  assetName(docId: string): string {
    return this.store.equipmentAssets().find((a) => a.id === docId)?.nomenclature ?? '';
  }

  async submitFault(): Promise<void> {
    if (!this.faultDesc.trim()) return;
    const created = await this.store.reportFaultAndOpenOrder({
      assetDocId: this.faultAssetId,
      orderType: this.faultOrderType,
      priority: this.faultPriority,
      faultDescription: this.faultDesc,
      partsReserved: this.faultParts,
    });
    if (created) {
      this.showFaultModal.set(false);
      this.faultDesc = '';
      this.faultParts = '';
    }
  }
}
