import {ChangeDetectionStrategy, Component, computed, inject, output, signal} from '@angular/core';
import {NavSection} from '../core/models';
import {StoreService} from '../core/store.service';

@Component({
  selector: 'app-overview',
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-8">
      <!-- Header & Primary Guided Workflow Action -->
      <div class="flex flex-col gap-4 md:flex-row md:items-end md:justify-between border-b border-[#DDD8CB] pb-6">
        <div>
          <p class="text-xs font-medium tracking-wider text-[#5A625B] uppercase">
            Operational Summary · Synthetic Demonstration Terminal
          </p>
          <h1 class="mt-1 text-2xl md:text-3xl font-semibold tracking-tight text-[#1C221E] text-balance">
            Administrative Readiness & Workflow Overview
          </h1>
          <p class="mt-1.5 text-sm text-[#4A524C] max-w-2xl">
            Inspect unit establishment, expiring qualifications, governed approval queues, equipment serviceability, and immutable audit events.
          </p>
        </div>
        <div class="flex flex-wrap items-center gap-3">
          <button
            type="button"
            (click)="runGuidedDemo()"
            [disabled]="runningDemo()"
            class="min-h-[44px] px-5 py-2.5 bg-[#9A7B3E] hover:bg-[#826630] disabled:opacity-50 text-[#FCFBF7] text-sm font-medium rounded transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            {{ runningDemo() ? 'Executing 10-Step Workflow...' : 'Run Complete 10-Step Workflow' }}
          </button>
          <button
            type="button"
            (click)="navigate.emit('personnel')"
            class="min-h-[44px] px-4 py-2.5 bg-[#FCFBF7] hover:bg-[#EDE9DE] border border-[#CEC8B8] text-[#1C221E] text-sm font-medium rounded transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            Open Personnel Register
          </button>
        </div>
      </div>

      <!-- Guided Workflow Log (visible when executed) -->
      @if (demoSteps().length > 0) {
        <section class="bg-[#FCFBF7] border border-[#DDD8CB] rounded p-6">
          <div class="flex items-center justify-between gap-4 border-b border-[#EAE5D8] pb-3 mb-4">
            <h2 class="text-base font-semibold text-[#1C221E]">
              Executed End-to-End Workflow Trace
            </h2>
            <button
              type="button"
              (click)="demoSteps.set([])"
              class="text-xs font-medium text-[#5A625B] hover:text-[#1C221E] cursor-pointer"
            >
              Dismiss Trace
            </button>
          </div>
          <ol class="grid grid-cols-1 md:grid-cols-2 gap-x-8 gap-y-2 text-sm text-[#2A332D]">
            @for (step of demoSteps(); track step) {
              <li class="py-1 border-b border-[#F0ECE0] font-mono text-xs">{{ step }}</li>
            }
          </ol>
        </section>
      }

      <!-- 4-Column KPI Strip -->
      <section class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4" aria-label="Key administrative metrics">
        <div class="bg-[#FCFBF7] border border-[#DDD8CB] rounded p-5">
          <p class="text-xs text-[#5A625B]">Authorised vs Filled Billets</p>
          <p class="mt-2 text-2xl font-semibold font-mono tabular-nums text-[#1C221E]">
            {{ filledPositions() }} / {{ store.positions().length }}
          </p>
          <p class="mt-1 text-xs text-[#4A524C]">
            {{ vacantPositions() }} vacant positions across {{ store.units().length }} units
          </p>
        </div>

        <div class="bg-[#FCFBF7] border border-[#DDD8CB] rounded p-5">
          <p class="text-xs text-[#5A625B]">Pending Approvals</p>
          <p class="mt-2 text-2xl font-semibold font-mono tabular-nums text-[#A16207]">
            {{ store.pendingRequestsCount() }}
          </p>
          <p class="mt-1 text-xs text-[#4A524C]">
            Leave & administrative requests awaiting decision
          </p>
        </div>

        <div class="bg-[#FCFBF7] border border-[#DDD8CB] rounded p-5">
          <p class="text-xs text-[#5A625B]">Qualification Renewal Alerts</p>
          <p class="mt-2 text-2xl font-semibold font-mono tabular-nums text-[#B91C1C]">
            {{ store.expiringOrExpiredQualsCount() }}
          </p>
          <p class="mt-1 text-xs text-[#4A524C]">
            Expired or expiring within renewal horizon
          </p>
        </div>

        <div class="bg-[#FCFBF7] border border-[#DDD8CB] rounded p-5">
          <p class="text-xs text-[#5A625B]">Open Maintenance Orders</p>
          <p class="mt-2 text-2xl font-semibold font-mono tabular-nums text-[#1C221E]">
            {{ store.openMaintenanceCount() }}
          </p>
          <p class="mt-1 text-xs text-[#4A524C]">
            {{ awaitingInspectionCount() }} awaiting independent release
          </p>
        </div>
      </section>

      <!-- Compact Analytical Charts -->
      <section class="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <!-- Chart 1: Unit Establishment Fill -->
        <div class="bg-[#FCFBF7] border border-[#DDD8CB] rounded p-6">
          <div class="flex items-center justify-between gap-4 mb-4">
            <div>
              <h2 class="text-base font-semibold text-[#1C221E]">Unit Establishment Fill</h2>
              <p class="text-xs text-[#5A625B]">Filled billets vs authorised establishment per unit</p>
            </div>
            <button
              type="button"
              (click)="navigate.emit('units')"
              class="text-xs font-medium text-[#9A7B3E] hover:underline cursor-pointer"
            >
              Manage Units
            </button>
          </div>
          <div class="space-y-4">
            @for (row of unitFillChart(); track row.code) {
              <div>
                <div class="flex items-center justify-between text-xs mb-1.5">
                  <span class="font-medium text-[#1C221E]">
                    <span class="font-mono text-[#5A625B]">{{ row.code }}</span> · {{ row.name }}
                  </span>
                  <span class="font-mono tabular-nums text-[#4A524C]">
                    {{ row.filled }} filled / {{ row.total }} billets ({{ row.pct }}%)
                  </span>
                </div>
                <svg viewBox="0 0 400 12" class="w-full h-3 block" role="img" [attr.aria-label]="row.code + ' fill ' + row.pct + '%'">
                  <rect x="0" y="0" width="400" height="12" rx="2" fill="#EAE5D8" />
                  <rect x="0" y="0" [attr.width]="row.barWidth" height="12" rx="2" fill="#2A3B30" />
                </svg>
              </div>
            }
          </div>
        </div>

        <!-- Chart 2: Stock & Qualification Health -->
        <div class="bg-[#FCFBF7] border border-[#DDD8CB] rounded p-6">
          <div class="flex items-center justify-between gap-4 mb-4">
            <div>
              <h2 class="text-base font-semibold text-[#1C221E]">Stores Stock Bucket Distribution</h2>
              <p class="text-xs text-[#5A625B]">Live separation across Available, Reserved, Quarantined, Damaged, In-Transit</p>
            </div>
            <button
              type="button"
              (click)="navigate.emit('stores')"
              class="text-xs font-medium text-[#9A7B3E] hover:underline cursor-pointer"
            >
              Inspect Ledger
            </button>
          </div>
          <div class="space-y-3">
            @for (bucket of stockSummary(); track bucket.label) {
              <div class="flex items-center gap-4">
                <span class="w-28 text-xs font-medium text-[#1C221E] shrink-0">{{ bucket.label }}</span>
                <div class="flex-1">
                  <svg viewBox="0 0 300 12" class="w-full h-3 block" role="img" [attr.aria-label]="bucket.label + ' ' + bucket.qty">
                    <rect x="0" y="0" width="300" height="12" rx="2" fill="#EAE5D8" />
                    <rect x="0" y="0" [attr.width]="bucket.barWidth" height="12" rx="2" [attr.fill]="bucket.color" />
                  </svg>
                </div>
                <span class="w-12 text-right font-mono tabular-nums text-xs text-[#1C221E]">{{ bucket.qty }}</span>
              </div>
            }
          </div>
        </div>
      </section>

      <!-- Core Workflow & Recent Audit Events -->
      <section class="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div class="lg:col-span-1 bg-[#FCFBF7] border border-[#DDD8CB] rounded p-6">
          <h2 class="text-base font-semibold text-[#1C221E]">Core Administrative Workflow</h2>
          <p class="mt-1 text-xs text-[#5A625B]">Standard auditable lifecycle across all records</p>
          <ol class="mt-4 space-y-3 text-sm text-[#2A332D]">
            <li class="flex items-baseline gap-3">
              <span class="font-mono text-xs text-[#9A7B3E] font-semibold">01</span>
              <span>Find a record via permission-aware search</span>
            </li>
            <li class="flex items-baseline gap-3">
              <span class="font-mono text-xs text-[#9A7B3E] font-semibold">02</span>
              <span>Inspect authorised current & historical state</span>
            </li>
            <li class="flex items-baseline gap-3">
              <span class="font-mono text-xs text-[#9A7B3E] font-semibold">03</span>
              <span>Submit validated change with policy context</span>
            </li>
            <li class="flex items-baseline gap-3">
              <span class="font-mono text-xs text-[#9A7B3E] font-semibold">04</span>
              <span>Obtain independent approval where required</span>
            </li>
            <li class="flex items-baseline gap-3">
              <span class="font-mono text-xs text-[#9A7B3E] font-semibold">05</span>
              <span>Update linked records & preserve audit trail</span>
            </li>
          </ol>
        </div>

        <div class="lg:col-span-2 bg-[#FCFBF7] border border-[#DDD8CB] rounded p-6">
          <div class="flex items-center justify-between gap-4 mb-4">
            <h2 class="text-base font-semibold text-[#1C221E]">Recent Append-Only Audit Events</h2>
            <button
              type="button"
              (click)="navigate.emit('administration')"
              class="text-xs font-medium text-[#9A7B3E] hover:underline cursor-pointer"
            >
              Full Audit Log
            </button>
          </div>
          <div class="overflow-x-auto">
            <table class="w-full text-left border-collapse text-sm">
              <thead>
                <tr class="border-b border-[#DDD8CB] text-xs text-[#5A625B]">
                  <th class="py-2 pr-4 font-medium">Timestamp</th>
                  <th class="py-2 pr-4 font-medium">Role</th>
                  <th class="py-2 pr-4 font-medium">Action</th>
                  <th class="py-2 font-medium">Summary</th>
                </tr>
              </thead>
              <tbody class="divide-y divide-[#EFECE2]">
                @for (ev of store.auditEvents().slice(0, 6); track ev.id) {
                  <tr class="hover:bg-[#F5F2EA]/70">
                    <td class="py-2.5 pr-4 font-mono text-xs text-[#5A625B] whitespace-nowrap">
                      {{ ev.timestamp.slice(0, 19).replace('T', ' ') }}
                    </td>
                    <td class="py-2.5 pr-4 text-xs text-[#1C221E] whitespace-nowrap">{{ ev.actorRole }}</td>
                    <td class="py-2.5 pr-4 font-mono text-xs text-[#2A3B30] whitespace-nowrap">{{ ev.action }}</td>
                    <td class="py-2.5 text-xs text-[#3C443E]">{{ ev.summary }}</td>
                  </tr>
                } @empty {
                  <tr>
                    <td colspan="4" class="py-6 text-center text-xs text-[#5A625B]">
                      No audit events recorded yet.
                    </td>
                  </tr>
                }
              </tbody>
            </table>
          </div>
        </div>
      </section>
    </div>
  `,
})
export class OverviewComponent {
  readonly store = inject(StoreService);
  readonly navigate = output<NavSection>();

  readonly runningDemo = signal(false);
  readonly demoSteps = signal<string[]>([]);

  readonly filledPositions = computed(
    () => this.store.positions().filter((p) => p.status === 'Filled').length,
  );
  readonly vacantPositions = computed(
    () => this.store.positions().filter((p) => p.status === 'Vacant').length,
  );
  readonly awaitingInspectionCount = computed(
    () =>
      this.store
        .maintenanceOrders()
        .filter((m) => m.status === 'Repair Completed - Awaiting Inspection').length,
  );

  readonly unitFillChart = computed(() => {
    const positions = this.store.positions();
    return this.store.units().map((u) => {
      const unitPositions = positions.filter((p) => p.unitId === u.id);
      const filled = unitPositions.filter((p) => p.status === 'Filled').length;
      const total = Math.max(unitPositions.length, 1);
      const pct = Math.round((filled / total) * 100);
      return {
        code: u.code,
        name: u.name,
        filled,
        total: unitPositions.length,
        pct,
        barWidth: Math.round((pct / 100) * 400),
      };
    });
  });

  readonly stockSummary = computed(() => {
    const items = this.store.stockItems();
    const sum = (fn: (i: (typeof items)[number]) => number) =>
      items.reduce((acc, item) => acc + fn(item), 0);

    const available = sum((i) => i.availableQty);
    const reserved = sum((i) => i.reservedQty);
    const quarantined = sum((i) => i.quarantinedQty);
    const damaged = sum((i) => i.damagedQty);
    const inTransit = sum((i) => i.inTransitQty);
    const maxVal = Math.max(available, reserved, quarantined, damaged, inTransit, 1);

    return [
      {label: 'Available', qty: available, color: '#1E6B43', barWidth: Math.round((available / maxVal) * 300)},
      {label: 'Reserved', qty: reserved, color: '#9A7B3E', barWidth: Math.round((reserved / maxVal) * 300)},
      {label: 'In Transit', qty: inTransit, color: '#334155', barWidth: Math.round((inTransit / maxVal) * 300)},
      {label: 'Quarantined', qty: quarantined, color: '#A16207', barWidth: Math.round((quarantined / maxVal) * 300)},
      {label: 'Damaged', qty: damaged, color: '#B91C1C', barWidth: Math.round((damaged / maxVal) * 300)},
    ];
  });

  async runGuidedDemo(): Promise<void> {
    this.runningDemo.set(true);
    try {
      const steps = await this.store.runEndToEndDemonstration();
      this.demoSteps.set(steps);
    } finally {
      this.runningDemo.set(false);
    }
  }
}
