import {ChangeDetectionStrategy, Component, inject, signal} from '@angular/core';
import {FormsModule} from '@angular/forms';
import {AdminRequest, LeaveRequest} from '../core/models';
import {StoreService} from '../core/store.service';

@Component({
  selector: 'app-requests',
  imports: [FormsModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-6">
      <div class="flex flex-col gap-4 md:flex-row md:items-end md:justify-between border-b border-[#DDD8CB] pb-5">
        <div>
          <p class="text-xs font-medium tracking-wider text-[#5A625B] uppercase">
            Leave, Administrative Requests & Document Approvals
          </p>
          <h1 class="mt-1 text-2xl font-semibold text-[#1C221E]">Governed Workflows & Documents</h1>
          <p class="mt-1 text-sm text-[#4A524C]">
            Draft -> Submitted -> Under Review -> Approved / Rejected -> Completed, with clarification, withdrawal, policy version, and self-approval prohibition.
          </p>
        </div>
        <div class="flex flex-wrap gap-3">
          <button
            type="button"
            (click)="showLeaveModal.set(true)"
            class="min-h-[44px] px-4 py-2.5 bg-[#9A7B3E] hover:bg-[#826630] text-[#FCFBF7] text-sm font-medium rounded cursor-pointer"
          >
            Submit Leave Request
          </button>
          <button
            type="button"
            (click)="showAdminModal.set(true)"
            class="min-h-[44px] px-4 py-2.5 bg-[#FCFBF7] hover:bg-[#EDE9DE] border border-[#CFCAC0] text-[#1C221E] text-sm font-medium rounded cursor-pointer"
          >
            New Admin Request
          </button>
          <button
            type="button"
            (click)="showDocModal.set(true)"
            class="min-h-[44px] px-4 py-2.5 bg-[#222924] hover:bg-[#313B34] text-[#F5F2EA] text-sm font-medium rounded cursor-pointer"
          >
            Upload Document
          </button>
        </div>
      </div>

      <!-- Leave Requests -->
      <section class="bg-[#FCFBF7] border border-[#DDD8CB] rounded overflow-hidden">
        <div class="p-4 border-b border-[#DDD8CB]">
          <h2 class="text-base font-semibold text-[#1C221E]">Leave & Absence Requests</h2>
        </div>
        <div class="overflow-x-auto">
          <table class="w-full text-left border-collapse text-sm">
            <thead>
              <tr class="border-b border-[#DDD8CB] bg-[#F5F2EA] text-xs text-[#5A625B]">
                <th class="py-3 px-4 font-medium">Reference</th>
                <th class="py-3 px-4 font-medium">Applicant</th>
                <th class="py-3 px-4 font-medium">Type & Dates</th>
                <th class="py-3 px-4 font-medium">Policy & Authority</th>
                <th class="py-3 px-4 font-medium">State</th>
                <th class="py-3 px-4 font-medium text-right">Workflow Actions</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-[#EFECE2]">
              @for (l of store.leaveRequests(); track l.id) {
                <tr class="hover:bg-[#F5F2EA]/70">
                  <td class="py-3 px-4 font-mono text-xs text-[#2A3B30] whitespace-nowrap">{{ l.requestRef }}</td>
                  <td class="py-3 px-4 text-xs font-medium text-[#1C221E]">{{ personName(l.personId) }}</td>
                  <td class="py-3 px-4 text-xs">
                    <div class="font-medium text-[#1C221E]">{{ l.leaveType }} ({{ l.daysCount }}d)</div>
                    <div class="font-mono text-[#5A625B]">{{ l.startDate }} .. {{ l.endDate }}</div>
                  </td>
                  <td class="py-3 px-4 text-xs text-[#4A524C] max-w-xs">
                    <div class="font-mono text-[11px] text-[#5A625B]">{{ l.policyVersion }}</div>
                    @if (l.approverAuthority) {
                      <div>By: {{ l.approverAuthority }}</div>
                    }
                    @if (l.clarificationNote && l.status === 'Clarification Requested') {
                      <div class="text-[#A16207]">Clarification: {{ l.clarificationNote }}</div>
                    }
                  </td>
                  <td class="py-3 px-4 text-xs font-semibold whitespace-nowrap">
                    <span
                      [class.text-[#1E6B43]]="l.status === 'Approved' || l.status === 'Completed'"
                      [class.text-[#A16207]]="l.status === 'Submitted' || l.status === 'Under Review' || l.status === 'Clarification Requested'"
                      [class.text-[#B91C1C]]="l.status === 'Rejected'"
                      [class.text-[#4B5563]]="l.status === 'Draft' || l.status === 'Withdrawn' || l.status === 'Cancelled'"
                    >
                      {{ l.status }}
                    </span>
                  </td>
                  <td class="py-3 px-4 text-right whitespace-nowrap space-x-1.5">
                    @if (l.status === 'Draft') {
                      <button type="button" (click)="store.transitionLeaveRequest(l.id, 'Submitted', 'Submitted for unit review')" class="px-2.5 py-1 bg-[#222924] text-[#F5F2EA] text-xs rounded cursor-pointer">Submit</button>
                    }
                    @if (l.status === 'Submitted' || l.status === 'Under Review' || l.status === 'Clarification Requested') {
                      <button type="button" (click)="store.transitionLeaveRequest(l.id, 'Approved', 'Approved under active leave policy')" class="px-2.5 py-1 bg-[#1E6B43] text-white text-xs rounded cursor-pointer">Approve</button>
                      <button type="button" (click)="store.transitionLeaveRequest(l.id, 'Clarification Requested', 'Confirm duty handover coverage')" class="px-2.5 py-1 bg-[#FCFBF7] border border-[#CFCAC0] text-[#1C221E] text-xs rounded cursor-pointer">Clarify</button>
                      <button type="button" (click)="store.transitionLeaveRequest(l.id, 'Rejected', 'Unit operational cover minimum not met')" class="px-2.5 py-1 bg-[#B91C1C] text-white text-xs rounded cursor-pointer">Reject</button>
                    }
                    @if (l.status === 'Approved') {
                      <button type="button" (click)="store.transitionLeaveRequest(l.id, 'Completed', 'Leave period concluded')" class="px-2.5 py-1 bg-[#222924] text-[#F5F2EA] text-xs rounded cursor-pointer">Complete</button>
                    }
                  </td>
                </tr>
              }
            </tbody>
          </table>
        </div>
      </section>

      <!-- Administrative Requests -->
      <section class="bg-[#FCFBF7] border border-[#DDD8CB] rounded overflow-hidden">
        <div class="p-4 border-b border-[#DDD8CB]">
          <h2 class="text-base font-semibold text-[#1C221E]">Administrative Change & Support Requests</h2>
        </div>
        <div class="overflow-x-auto">
          <table class="w-full text-left border-collapse text-sm">
            <thead>
              <tr class="border-b border-[#DDD8CB] bg-[#F5F2EA] text-xs text-[#5A625B]">
                <th class="py-3 px-4 font-medium">Reference</th>
                <th class="py-3 px-4 font-medium">Type</th>
                <th class="py-3 px-4 font-medium">Title & Details</th>
                <th class="py-3 px-4 font-medium">State</th>
                <th class="py-3 px-4 font-medium text-right">Actions</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-[#EFECE2]">
              @for (a of store.adminRequests(); track a.id) {
                <tr class="hover:bg-[#F5F2EA]/70">
                  <td class="py-3 px-4 font-mono text-xs text-[#2A3B30] whitespace-nowrap">{{ a.requestRef }}</td>
                  <td class="py-3 px-4 text-xs text-[#3C443E]">{{ a.requestType }}</td>
                  <td class="py-3 px-4 text-xs">
                    <div class="font-medium text-[#1C221E]">{{ a.title }}</div>
                    <div class="text-[#5A625B]">{{ a.details }}</div>
                  </td>
                  <td class="py-3 px-4 text-xs font-semibold">
                    <span
                      [class.text-[#1E6B43]]="a.status === 'Approved' || a.status === 'Completed'"
                      [class.text-[#A16207]]="a.status === 'Submitted' || a.status === 'Under Review'"
                      [class.text-[#B91C1C]]="a.status === 'Rejected'"
                    >
                      {{ a.status }}
                    </span>
                  </td>
                  <td class="py-3 px-4 text-right whitespace-nowrap space-x-1.5">
                    @if (a.status === 'Submitted' || a.status === 'Under Review') {
                      <button type="button" (click)="store.transitionAdminRequest(a.id, 'Approved', 'Approved by authorised officer')" class="px-2.5 py-1 bg-[#1E6B43] text-white text-xs rounded cursor-pointer">Approve</button>
                      <button type="button" (click)="store.transitionAdminRequest(a.id, 'Rejected', 'Insufficient administrative justification')" class="px-2.5 py-1 bg-[#B91C1C] text-white text-xs rounded cursor-pointer">Reject</button>
                    }
                  </td>
                </tr>
              }
            </tbody>
          </table>
        </div>
      </section>

      <!-- Document Workflow Table -->
      <section class="bg-[#FCFBF7] border border-[#DDD8CB] rounded overflow-hidden">
        <div class="p-4 border-b border-[#DDD8CB]">
          <h2 class="text-base font-semibold text-[#1C221E]">Validated Document Workflows</h2>
          <p class="text-xs text-[#5A625B]">Uploads treated as untrusted: restricted to PDF, TXT, CSV, PNG, JPEG under 10 MB.</p>
        </div>
        <div class="overflow-x-auto">
          <table class="w-full text-left border-collapse text-xs">
            <thead>
              <tr class="border-b border-[#DDD8CB] bg-[#F5F2EA] text-[#5A625B]">
                <th class="py-2.5 px-4 font-medium">Doc Ref</th>
                <th class="py-2.5 px-4 font-medium">Title & Category</th>
                <th class="py-2.5 px-4 font-medium">MIME & Size</th>
                <th class="py-2.5 px-4 font-medium">Status</th>
                <th class="py-2.5 px-4 font-medium text-right">Approval</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-[#EFECE2]">
              @for (d of store.documents(); track d.id) {
                <tr>
                  <td class="py-2.5 px-4 font-mono text-[#2A3B30]">{{ d.docRef }}</td>
                  <td class="py-2.5 px-4 font-medium text-[#1C221E]">{{ d.title }} · <span class="text-[#5A625B] font-normal">{{ d.category }}</span></td>
                  <td class="py-2.5 px-4 font-mono text-[#5A625B]">{{ d.mimeType }} · {{ (d.sizeBytes / 1024).toFixed(1) }} KB</td>
                  <td class="py-2.5 px-4 font-semibold" [class.text-[#1E6B43]]="d.status === 'Approved'" [class.text-[#A16207]]="d.status === 'Submitted'">{{ d.status }}</td>
                  <td class="py-2.5 px-4 text-right whitespace-nowrap space-x-1.5">
                    @if (d.status === 'Submitted') {
                      <button type="button" (click)="store.approveDocument(d.id, 'Approved')" class="px-2.5 py-1 bg-[#1E6B43] text-white rounded cursor-pointer">Approve</button>
                      <button type="button" (click)="store.approveDocument(d.id, 'Rejected')" class="px-2.5 py-1 bg-[#B91C1C] text-white rounded cursor-pointer">Reject</button>
                    }
                  </td>
                </tr>
              }
            </tbody>
          </table>
        </div>
      </section>

      <!-- Modals -->
      @if (showLeaveModal()) {
        <div class="fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4" role="dialog" aria-modal="true">
          <div class="bg-[#FCFBF7] border border-[#CFCAC0] rounded max-w-lg w-full p-6 space-y-4">
            <h2 class="text-lg font-semibold text-[#1C221E]">Submit Leave Request</h2>
            <form (ngSubmit)="submitLeave()" class="space-y-3 text-sm">
              <label class="block">
                <span class="block text-xs font-medium text-[#4A524C] mb-1">Applicant</span>
                <select [(ngModel)]="lvPersonId" name="lvPersonId" required class="w-full min-h-[40px] px-3 bg-white border border-[#CFCAC0] rounded">
                  @for (p of store.people(); track p.id) {
                    <option [value]="p.id">{{ p.serviceId }} · {{ p.rank }} {{ p.surname }}</option>
                  }
                </select>
              </label>
              <div class="grid grid-cols-2 gap-3">
                <label class="block">
                  <span class="block text-xs font-medium text-[#4A524C] mb-1">Leave Type</span>
                  <select [(ngModel)]="lvType" name="lvType" class="w-full min-h-[40px] px-3 bg-white border border-[#CFCAC0] rounded">
                    <option value="Annual">Annual</option>
                    <option value="Privilege">Privilege</option>
                    <option value="Compassionate">Compassionate</option>
                    <option value="Study">Study</option>
                    <option value="Sick Administrative">Sick Administrative</option>
                  </select>
                </label>
                <label class="block">
                  <span class="block text-xs font-medium text-[#4A524C] mb-1">Days</span>
                  <input type="number" min="1" [(ngModel)]="lvDays" name="lvDays" required class="w-full min-h-[40px] px-3 bg-white border border-[#CFCAC0] rounded" />
                </label>
              </div>
              <div class="grid grid-cols-2 gap-3">
                <label class="block">
                  <span class="block text-xs font-medium text-[#4A524C] mb-1">Start Date</span>
                  <input type="date" [(ngModel)]="lvStart" name="lvStart" required class="w-full min-h-[40px] px-3 bg-white border border-[#CFCAC0] rounded" />
                </label>
                <label class="block">
                  <span class="block text-xs font-medium text-[#4A524C] mb-1">End Date</span>
                  <input type="date" [(ngModel)]="lvEnd" name="lvEnd" required class="w-full min-h-[40px] px-3 bg-white border border-[#CFCAC0] rounded" />
                </label>
              </div>
              <label class="block">
                <span class="block text-xs font-medium text-[#4A524C] mb-1">Justification / Cover</span>
                <input [(ngModel)]="lvReason" name="lvReason" required class="w-full min-h-[40px] px-3 bg-white border border-[#CFCAC0] rounded" />
              </label>
              <div class="flex justify-end gap-3 pt-2">
                <button type="button" (click)="showLeaveModal.set(false)" class="min-h-[40px] px-4 border border-[#CFCAC0] rounded cursor-pointer">Cancel</button>
                <button type="submit" class="min-h-[40px] px-5 bg-[#9A7B3E] text-[#FCFBF7] rounded font-medium cursor-pointer">Submit Request</button>
              </div>
            </form>
          </div>
        </div>
      }

      @if (showAdminModal()) {
        <div class="fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4" role="dialog" aria-modal="true">
          <div class="bg-[#FCFBF7] border border-[#CFCAC0] rounded max-w-lg w-full p-6 space-y-4">
            <h2 class="text-lg font-semibold text-[#1C221E]">Submit Administrative Request</h2>
            <form (ngSubmit)="submitAdmin()" class="space-y-3 text-sm">
              <div class="grid grid-cols-2 gap-3">
                <label class="block">
                  <span class="block text-xs font-medium text-[#4A524C] mb-1">Request Type</span>
                  <select [(ngModel)]="admType" name="admType" class="w-full min-h-[40px] px-3 bg-white border border-[#CFCAC0] rounded">
                    <option value="Assignment Change">Assignment Change</option>
                    <option value="Qualification Correction">Qualification Correction</option>
                    <option value="Equipment Request">Equipment Request</option>
                    <option value="Document Approval">Document Approval</option>
                    <option value="Administrative Support">Administrative Support</option>
                  </select>
                </label>
                <label class="block">
                  <span class="block text-xs font-medium text-[#4A524C] mb-1">Unit</span>
                  <select [(ngModel)]="admUnitId" name="admUnitId" class="w-full min-h-[40px] px-3 bg-white border border-[#CFCAC0] rounded">
                    @for (u of store.units(); track u.id) {
                      <option [value]="u.id">{{ u.code }}</option>
                    }
                  </select>
                </label>
              </div>
              <label class="block">
                <span class="block text-xs font-medium text-[#4A524C] mb-1">Title</span>
                <input [(ngModel)]="admTitle" name="admTitle" required class="w-full min-h-[40px] px-3 bg-white border border-[#CFCAC0] rounded" />
              </label>
              <label class="block">
                <span class="block text-xs font-medium text-[#4A524C] mb-1">Details</span>
                <textarea [(ngModel)]="admDetails" name="admDetails" rows="3" required class="w-full p-3 bg-white border border-[#CFCAC0] rounded"></textarea>
              </label>
              <div class="flex justify-end gap-3 pt-2">
                <button type="button" (click)="showAdminModal.set(false)" class="min-h-[40px] px-4 border border-[#CFCAC0] rounded cursor-pointer">Cancel</button>
                <button type="submit" class="min-h-[40px] px-5 bg-[#9A7B3E] text-[#FCFBF7] rounded font-medium cursor-pointer">Submit</button>
              </div>
            </form>
          </div>
        </div>
      }

      @if (showDocModal()) {
        <div class="fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4" role="dialog" aria-modal="true">
          <div class="bg-[#FCFBF7] border border-[#CFCAC0] rounded max-w-lg w-full p-6 space-y-4">
            <h2 class="text-lg font-semibold text-[#1C221E]">Register Validated Document Attachment</h2>
            <form (ngSubmit)="submitDoc()" class="space-y-3 text-sm">
              <label class="block">
                <span class="block text-xs font-medium text-[#4A524C] mb-1">Select File (Validated Untrusted Input)</span>
                <input type="file" (change)="onFileSelected($event)" class="w-full text-xs py-2" />
              </label>
              <label class="block">
                <span class="block text-xs font-medium text-[#4A524C] mb-1">Document Title</span>
                <input [(ngModel)]="docTitle" name="docTitle" required class="w-full min-h-[40px] px-3 bg-white border border-[#CFCAC0] rounded" />
              </label>
              <div class="grid grid-cols-2 gap-3">
                <label class="block">
                  <span class="block text-xs font-medium text-[#4A524C] mb-1">Category</span>
                  <input [(ngModel)]="docCategory" name="docCategory" required class="w-full min-h-[40px] px-3 bg-white border border-[#CFCAC0] rounded" />
                </label>
                <label class="block">
                  <span class="block text-xs font-medium text-[#4A524C] mb-1">MIME Type</span>
                  <input [(ngModel)]="docMime" name="docMime" required class="w-full min-h-[40px] px-3 bg-white border border-[#CFCAC0] rounded font-mono text-xs" />
                </label>
              </div>
              <div class="flex justify-end gap-3 pt-2">
                <button type="button" (click)="showDocModal.set(false)" class="min-h-[40px] px-4 border border-[#CFCAC0] rounded cursor-pointer">Cancel</button>
                <button type="submit" class="min-h-[40px] px-5 bg-[#9A7B3E] text-[#FCFBF7] rounded font-medium cursor-pointer">Validate & Register</button>
              </div>
            </form>
          </div>
        </div>
      }
    </div>
  `,
})
export class RequestsComponent {
  readonly store = inject(StoreService);

  readonly showLeaveModal = signal(false);
  readonly showAdminModal = signal(false);
  readonly showDocModal = signal(false);

  lvPersonId = 'per-005';
  lvType: LeaveRequest['leaveType'] = 'Annual';
  lvStart = '2026-12-20';
  lvEnd = '2026-12-24';
  lvDays = 5;
  lvReason = 'Scheduled seasonal leave';

  admType: AdminRequest['requestType'] = 'Administrative Support';
  admUnitId = 'unit-sig-regt';
  admTitle = '';
  admDetails = '';

  docTitle = 'Unit Inspection Supporting Schedule';
  docCategory = 'Governance';
  docMime = 'application/pdf';
  docSizeBytes = 48200;

  personName(id: string): string {
    const p = this.store.people().find((x) => x.id === id);
    return p ? `${p.rank} ${p.surname} (${p.serviceId})` : id;
  }

  onFileSelected(event: Event): void {
    const input = event.target as HTMLInputElement;
    const file = input.files?.[0];
    if (!file) return;
    this.docTitle = file.name.replace(/\.[^.]+$/, '');
    this.docMime = file.type || 'application/octet-stream';
    this.docSizeBytes = file.size;
  }

  async submitLeave(): Promise<void> {
    const res = await this.store.submitLeaveRequest({
      personId: this.lvPersonId,
      leaveType: this.lvType,
      startDate: this.lvStart,
      endDate: this.lvEnd,
      daysCount: this.lvDays,
      reason: this.lvReason,
    });
    if (res) this.showLeaveModal.set(false);
  }

  async submitAdmin(): Promise<void> {
    if (!this.admTitle.trim() || !this.admDetails.trim()) return;
    const res = await this.store.submitAdminRequest({
      requestType: this.admType,
      unitId: this.admUnitId,
      title: this.admTitle,
      details: this.admDetails,
    });
    if (res) {
      this.showAdminModal.set(false);
      this.admTitle = '';
      this.admDetails = '';
    }
  }

  async submitDoc(): Promise<void> {
    const res = await this.store.registerValidatedDocument({
      title: this.docTitle,
      category: this.docCategory,
      unitId: 'unit-sig-regt',
      mimeType: this.docMime,
      sizeBytes: this.docSizeBytes,
    });
    if (res) this.showDocModal.set(false);
  }
}
