import {ChangeDetectionStrategy, Component, computed, inject, signal} from '@angular/core';
import {StoreService} from '../core/store.service';

type ReportKey =
  | 'establishment'
  | 'expiries'
  | 'attendance'
  | 'requests'
  | 'custody'
  | 'maintenance'
  | 'stores'
  | 'quality';

@Component({
  selector: 'app-reports',
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-6">
      <div class="flex flex-col gap-4 md:flex-row md:items-end md:justify-between border-b border-[#DDD8CB] pb-5">
        <div>
          <p class="text-xs font-medium tracking-wider text-[#5A625B] uppercase">
            Permission-Aware Reporting & Audited CSV Export
          </p>
          <h1 class="mt-1 text-2xl font-semibold text-[#1C221E]">Administrative Reports</h1>
          <p class="mt-1 text-sm text-[#4A524C]">
            Every metric carries an explicit definition and reporting date. Exports minimise personal information and write an audit event.
          </p>
        </div>
        <button
          type="button"
          (click)="exportActiveReport()"
          class="min-h-[44px] px-5 py-2.5 bg-[#9A7B3E] hover:bg-[#826630] text-[#FCFBF7] text-sm font-medium rounded cursor-pointer"
        >
          Export Authorised CSV
        </button>
      </div>

      <!-- Report Selector -->
      <div class="grid grid-cols-2 md:grid-cols-4 gap-2.5">
        @for (tab of reportTabs; track tab.key) {
          <button
            type="button"
            (click)="activeReport.set(tab.key)"
            class="min-h-[44px] p-3 text-left rounded border text-xs transition-colors cursor-pointer"
            [class.bg-[#222924]]="activeReport() === tab.key"
            [class.text-[#F5F2EA]]="activeReport() === tab.key"
            [class.border-[#222924]]="activeReport() === tab.key"
            [class.bg-[#FCFBF7]]="activeReport() !== tab.key"
            [class.text-[#1C221E]]="activeReport() !== tab.key"
            [class.border-[#DDD8CB]]="activeReport() !== tab.key"
          >
            <div class="font-semibold">{{ tab.title }}</div>
            <div class="text-[11px] opacity-80 mt-0.5">{{ tab.subtitle }}</div>
          </button>
        }
      </div>

      <!-- Report Definition & Timestamp -->
      <div class="bg-[#FCFBF7] border border-[#DDD8CB] rounded p-5 space-y-4">
        <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-[#EAE5D8] pb-3">
          <div>
            <h2 class="text-base font-semibold text-[#1C221E]">{{ activeMeta().title }}</h2>
            <p class="text-xs text-[#4A524C] mt-0.5">Definition: {{ activeMeta().definition }}</p>
          </div>
          <div class="font-mono text-xs text-[#5A625B] whitespace-nowrap">
            As at: {{ reportingDate }} · Rows: {{ activeRows().length }}
          </div>
        </div>

        <div class="overflow-x-auto">
          <table class="w-full text-left border-collapse text-xs">
            <thead>
              <tr class="border-b border-[#DDD8CB] bg-[#F5F2EA] text-[#5A625B]">
                @for (col of activeColumns(); track col) {
                  <th class="py-2.5 px-3 font-medium">{{ col }}</th>
                }
              </tr>
            </thead>
            <tbody class="divide-y divide-[#EFECE2]">
              @for (row of activeRows(); track $index) {
                <tr class="hover:bg-[#F5F2EA]/70">
                  @for (col of activeColumns(); track col) {
                    <td class="py-2.5 px-3 font-mono text-[#1C221E]">{{ row[col] }}</td>
                  }
                </tr>
              } @empty {
                <tr>
                  <td [attr.colspan]="activeColumns().length" class="py-6 text-center text-[#5A625B]">
                    No exceptions or records matched for this report.
                  </td>
                </tr>
              }
            </tbody>
          </table>
        </div>
      </div>
    </div>
  `,
})
export class ReportsComponent {
  readonly store = inject(StoreService);
  readonly activeReport = signal<ReportKey>('establishment');
  readonly reportingDate = new Date().toISOString().slice(0, 16).replace('T', ' ') + 'Z';

  readonly reportTabs: {key: ReportKey; title: string; subtitle: string; definition: string}[] = [
    {
      key: 'establishment',
      title: 'Establishment & Vacancies',
      subtitle: 'Authorised vs Filled',
      definition: 'Counts established positions per unit compared against filled incumbents as at reporting timestamp.',
    },
    {
      key: 'expiries',
      title: 'Qualification Expiries',
      subtitle: 'Expired & Due Renewal',
      definition: 'Qualifications whose status is Expired or Expiring Soon, using criteria version retained at award.',
    },
    {
      key: 'attendance',
      title: 'Course Attendance',
      subtitle: 'Enrolment Outcomes',
      definition: 'Course enrolments separating physical attendance status from assessment result status.',
    },
    {
      key: 'requests',
      title: 'Outstanding Requests',
      subtitle: 'Leave & Admin Queue',
      definition: 'Open leave and administrative requests in Submitted, Under Review, or Clarification Requested states.',
    },
    {
      key: 'custody',
      title: 'Equipment Custody',
      subtitle: 'Asset Accountability',
      definition: 'PII-minimised register of asset custody holders, location, and inspection status.',
    },
    {
      key: 'maintenance',
      title: 'Maintenance Backlog',
      subtitle: 'Open & Pending Release',
      definition: 'All work orders not yet released serviceable, highlighting orders awaiting independent inspection.',
    },
    {
      key: 'stores',
      title: 'Stores Reconciliation',
      subtitle: '5-Bucket Balances',
      definition: 'Available, Reserved, Quarantined, Damaged, and In-Transit quantities compared to reorder thresholds.',
    },
    {
      key: 'quality',
      title: 'Data-Quality Exceptions',
      subtitle: 'Duplicates & Gaps',
      definition: 'Detects duplicate service IDs, unassessed clearances, overdue inspections, and expired qualifications.',
    },
  ];

  readonly activeMeta = computed(
    () => this.reportTabs.find((t) => t.key === this.activeReport()) ?? this.reportTabs[0],
  );

  readonly activeRows = computed<Record<string, unknown>[]>(() => {
    switch (this.activeReport()) {
      case 'establishment':
        return this.store.units().map((u) => {
          const pos = this.store.positions().filter((p) => p.unitId === u.id);
          const filled = pos.filter((p) => p.status === 'Filled').length;
          return {
            unit_code: u.code,
            authorised_strength: u.authorisedStrength,
            established_billets: pos.length,
            filled_billets: filled,
            vacant_billets: pos.length - filled,
          };
        });
      case 'expiries':
        return this.store.qualifications().map((q) => ({
          qual_code: q.qualCode,
          service_id: this.store.people().find((p) => p.id === q.personId)?.serviceId ?? q.personId,
          criteria_version: q.criteriaVersion,
          expiry_date: q.expiryDate,
          status: q.status,
        }));
      case 'attendance':
        return this.store.enrolments().map((e) => ({
          course: this.store.courses().find((c) => c.id === e.courseId)?.code ?? e.courseId,
          service_id: this.store.people().find((p) => p.id === e.personId)?.serviceId ?? e.personId,
          session_date: e.sessionDate,
          attendance: e.attendanceStatus,
          result: e.resultStatus,
        }));
      case 'requests':
        return [
          ...this.store.leaveRequests()
            .filter((r) => ['Submitted', 'Under Review', 'Clarification Requested'].includes(r.status))
            .map((r) => ({
              request_ref: r.requestRef,
              category: r.leaveType,
              status: r.status,
              policy_version: r.policyVersion,
            })),
          ...this.store.adminRequests()
            .filter((r) => ['Submitted', 'Under Review', 'Clarification Requested'].includes(r.status))
            .map((r) => ({
              request_ref: r.requestRef,
              category: r.requestType,
              status: r.status,
              policy_version: r.policyVersion,
            })),
        ];
      case 'custody':
        return this.store.equipmentAssets().map((a) => ({
          asset_id: a.assetId,
          category: a.category,
          custodian_service_id: a.custodianPersonId
            ? (this.store.people().find((p) => p.id === a.custodianPersonId)?.serviceId ?? 'Assigned')
            : 'UNIT_STORES',
          serviceability: a.serviceability,
          inspection: a.inspectionStatus,
        }));
      case 'maintenance':
        return this.store
          .maintenanceOrders()
          .filter((m) => m.status !== 'Released Serviceable')
          .map((m) => ({
            order_ref: m.orderRef,
            priority: m.priority,
            status: m.status,
            inspection_passed: m.inspectionPassed ? 'YES' : 'NO',
          }));
      case 'stores':
        return this.store.stockItems().map((s) => ({
          sku: s.sku,
          available: s.availableQty,
          reserved: s.reservedQty,
          quarantined: s.quarantinedQty,
          damaged: s.damagedQty,
          in_transit: s.inTransitQty,
          reorder_flag: s.availableQty <= s.reorderLevel ? 'LOW' : 'OK',
        }));
      case 'quality': {
        const exceptions: Record<string, unknown>[] = [];
        for (const dup of this.store.duplicateServiceIds()) {
          exceptions.push({exception_type: 'DUPLICATE_SERVICE_ID', identifier: dup, severity: 'HIGH'});
        }
        for (const p of this.store.people().filter((x) => x.clearanceStatus === 'Not Assessed')) {
          exceptions.push({exception_type: 'CLEARANCE_NOT_ASSESSED', identifier: p.serviceId, severity: 'MEDIUM'});
        }
        for (const q of this.store.qualifications().filter((x) => x.status === 'Expired')) {
          exceptions.push({exception_type: 'EXPIRED_QUALIFICATION', identifier: `${q.qualCode}/${q.personId}`, severity: 'HIGH'});
        }
        return exceptions;
      }
    }
  });

  readonly activeColumns = computed(() => {
    const rows = this.activeRows();
    return rows.length > 0 ? Object.keys(rows[0]) : ['status'];
  });

  async exportActiveReport(): Promise<void> {
    await this.store.exportAuthorisedReport(this.activeMeta().title, this.activeRows());
  }
}
