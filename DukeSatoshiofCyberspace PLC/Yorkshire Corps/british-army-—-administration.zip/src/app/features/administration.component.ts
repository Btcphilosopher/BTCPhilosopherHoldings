import {ChangeDetectionStrategy, Component, inject, signal} from '@angular/core';
import {FormsModule} from '@angular/forms';
import {DELIVERABLE_DOCS} from '../core/deliverables-content';
import {AppRole, Delegation} from '../core/models';
import {ALL_PERMISSIONS, ALL_ROLES, ROLE_DEFINITIONS, hasPermission} from '../core/rbac';
import {StoreService} from '../core/store.service';

@Component({
  selector: 'app-administration',
  imports: [FormsModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-6">
      <div class="flex flex-col gap-4 md:flex-row md:items-end md:justify-between border-b border-[#DDD8CB] pb-5">
        <div>
          <p class="text-xs font-medium tracking-wider text-[#5A625B] uppercase">
            RBAC Governance, Offline Sync Recovery, Audit Trail & Deliverables
          </p>
          <h1 class="mt-1 text-2xl font-semibold text-[#1C221E]">System Administration</h1>
          <p class="mt-1 text-sm text-[#4A524C]">
            Switch demonstration roles to verify denied access, manage time-bounded delegations, test offline conflict resolution, and inspect PostgreSQL/FastAPI/Android deliverables.
          </p>
        </div>
        <button
          type="button"
          (click)="store.seedDemoEnvironment()"
          [disabled]="store.seedingInProgress()"
          class="min-h-[44px] px-4 py-2.5 bg-[#222924] hover:bg-[#313B34] text-[#F5F2EA] text-sm font-medium rounded cursor-pointer"
        >
          {{ store.seedingInProgress() ? 'Re-seeding...' : 'Restore Synthetic Seed Data' }}
        </button>
      </div>

      <!-- Sub-navigation Tabs -->
      <div class="flex flex-wrap gap-1.5 bg-[#FCFBF7] border border-[#DDD8CB] p-1.5 rounded">
        @for (tab of adminTabs; track tab.id) {
          <button
            type="button"
            (click)="activeTab.set(tab.id)"
            class="px-3.5 py-2 text-xs font-medium rounded transition-colors cursor-pointer"
            [class.bg-[#222924]]="activeTab() === tab.id"
            [class.text-[#F5F2EA]]="activeTab() === tab.id"
            [class.text-[#4A524C]]="activeTab() !== tab.id"
          >
            {{ tab.label }}
          </button>
        }
      </div>

      <!-- Tab 1: RBAC & Role Switcher -->
      @if (activeTab() === 'rbac') {
        <div class="space-y-6">
          <section class="bg-[#FCFBF7] border border-[#DDD8CB] rounded p-5 space-y-4">
            <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <div>
                <h2 class="text-base font-semibold text-[#1C221E]">Demonstration Role Perspective Switcher</h2>
                <p class="text-xs text-[#4A524C]">
                  Active Role: <span class="font-semibold text-[#9A7B3E]">{{ store.activeRoleLabel() }}</span>. Notice System Administrator is separated from unrestricted personal sensitive PII access.
                </p>
              </div>
              <button
                type="button"
                (click)="testDeniedAccess()"
                class="min-h-[38px] px-3 py-1.5 bg-[#B91C1C] text-white text-xs font-medium rounded cursor-pointer"
              >
                Verify Denied Access Check
              </button>
            </div>
            <div class="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
              @for (r of roles; track r) {
                <button
                  type="button"
                  (click)="store.switchDemoRole(r)"
                  class="p-3 text-left rounded border text-xs transition-colors cursor-pointer"
                  [class.bg-[#222924]]="store.activeRole() === r"
                  [class.text-[#F5F2EA]]="store.activeRole() === r"
                  [class.border-[#222924]]="store.activeRole() === r"
                  [class.bg-white]="store.activeRole() !== r"
                  [class.text-[#1C221E]]="store.activeRole() !== r"
                  [class.border-[#CFCAC0]]="store.activeRole() !== r"
                >
                  <div class="font-semibold">{{ roleDefs[r].label }}</div>
                  <div class="text-[11px] opacity-80 mt-0.5 line-clamp-2">{{ roleDefs[r].scopeSummary }}</div>
                </button>
              }
            </div>
          </section>

          <section class="bg-[#FCFBF7] border border-[#DDD8CB] rounded overflow-hidden">
            <div class="p-4 border-b border-[#DDD8CB]">
              <h2 class="text-base font-semibold text-[#1C221E]">Role-and-Permission Matrix</h2>
            </div>
            <div class="overflow-x-auto">
              <table class="w-full text-left border-collapse text-xs">
                <thead>
                  <tr class="border-b border-[#DDD8CB] bg-[#F5F2EA] text-[#5A625B]">
                    <th class="py-2.5 px-3 font-medium">Permission</th>
                    @for (r of roles; track r) {
                      <th class="py-2.5 px-2 font-medium text-center">{{ roleDefs[r].label }}</th>
                    }
                  </tr>
                </thead>
                <tbody class="divide-y divide-[#EFECE2]">
                  @for (perm of allPermissions; track perm.action) {
                    <tr>
                      <td class="py-2 px-3 font-medium text-[#1C221E]">{{ perm.label }}</td>
                      @for (r of roles; track r) {
                        <td class="py-2 px-2 text-center font-mono">
                          <span [class.text-[#1E6B43]]="checkPerm(r, perm.action)" [class.text-[#B5B0A4]]="!checkPerm(r, perm.action)">
                            {{ checkPerm(r, perm.action) ? 'ALLOW' : '—' }}
                          </span>
                        </td>
                      }
                    </tr>
                  }
                </tbody>
              </table>
            </div>
          </section>
        </div>
      }

      <!-- Tab 2: Time-Bounded Delegations -->
      @if (activeTab() === 'delegations') {
        <div class="grid grid-cols-1 lg:grid-cols-12 gap-6">
          <div class="lg:col-span-7 bg-[#FCFBF7] border border-[#DDD8CB] rounded p-5">
            <h2 class="text-base font-semibold text-[#1C221E] mb-3">Active & Historical Authority Delegations</h2>
            <div class="space-y-3">
              @for (d of store.delegations(); track d.id) {
                <div class="border-b border-[#EFECE2] pb-3 text-xs flex items-start justify-between gap-4">
                  <div>
                    <div class="font-semibold text-[#1C221E]">{{ d.delegateName }} -> {{ d.roleGranted }}</div>
                    <div class="text-[#5A625B]">Unit Scope: {{ d.unitScope }} · {{ d.reason }}</div>
                  </div>
                  <div class="text-right font-mono whitespace-nowrap">
                    <div class="text-[#1E6B43] font-semibold">{{ d.status }}</div>
                    <div class="text-[#5A625B]">{{ d.validFrom }} .. {{ d.validUntil }}</div>
                  </div>
                </div>
              }
            </div>
          </div>

          <div class="lg:col-span-5 bg-[#FCFBF7] border border-[#DDD8CB] rounded p-5">
            <h2 class="text-base font-semibold text-[#1C221E] mb-3">Grant Time-Bounded Delegation</h2>
            <form (ngSubmit)="submitDelegation()" class="space-y-3 text-sm">
              <label class="block">
                <span class="block text-xs font-medium text-[#4A524C] mb-1">Delegate Name & Appointment</span>
                <input [(ngModel)]="delName" name="delName" required class="w-full min-h-[40px] px-3 bg-white border border-[#CFCAC0] rounded" placeholder="Capt H. Bramwell (7 Log Sqn)" />
              </label>
              <div class="grid grid-cols-2 gap-3">
                <label class="block">
                  <span class="block text-xs font-medium text-[#4A524C] mb-1">Delegated Role</span>
                  <select [(ngModel)]="delRole" name="delRole" class="w-full min-h-[40px] px-3 bg-white border border-[#CFCAC0] rounded">
                    <option value="approver">Approver</option>
                    <option value="unit_admin">Unit Admin</option>
                    <option value="training_admin">Training Admin</option>
                    <option value="equipment_custodian">Equipment Custodian</option>
                  </select>
                </label>
                <label class="block">
                  <span class="block text-xs font-medium text-[#4A524C] mb-1">Unit Scope</span>
                  <select [(ngModel)]="delUnit" name="delUnit" class="w-full min-h-[40px] px-3 bg-white border border-[#CFCAC0] rounded">
                    @for (u of store.units(); track u.id) {
                      <option [value]="u.id">{{ u.code }}</option>
                    }
                  </select>
                </label>
              </div>
              <div class="grid grid-cols-2 gap-3">
                <label class="block">
                  <span class="block text-xs font-medium text-[#4A524C] mb-1">Valid From</span>
                  <input type="date" [(ngModel)]="delFrom" name="delFrom" required class="w-full min-h-[40px] px-3 bg-white border border-[#CFCAC0] rounded" />
                </label>
                <label class="block">
                  <span class="block text-xs font-medium text-[#4A524C] mb-1">Valid Until</span>
                  <input type="date" [(ngModel)]="delUntil" name="delUntil" required class="w-full min-h-[40px] px-3 bg-white border border-[#CFCAC0] rounded" />
                </label>
              </div>
              <label class="block">
                <span class="block text-xs font-medium text-[#4A524C] mb-1">Authority Reason</span>
                <input [(ngModel)]="delReason" name="delReason" required class="w-full min-h-[40px] px-3 bg-white border border-[#CFCAC0] rounded" />
              </label>
              <button type="submit" class="w-full min-h-[42px] bg-[#9A7B3E] text-[#FCFBF7] rounded font-medium cursor-pointer">Record Delegation</button>
            </form>
          </div>
        </div>
      }

      <!-- Tab 3: Offline Sync & Optimistic Concurrency Conflicts -->
      @if (activeTab() === 'sync') {
        <div class="space-y-4">
          <section class="bg-[#FCFBF7] border border-[#DDD8CB] rounded p-5 flex flex-wrap items-center justify-between gap-4">
            <div>
              <h2 class="text-base font-semibold text-[#1C221E]">Offline Synchronisation & Conflict Simulator</h2>
              <p class="text-xs text-[#4A524C]">
                Models Android Room + WorkManager queuing with idempotency keys, optimistic concurrency version checks, permission revalidation, and remote revocation limits.
              </p>
            </div>
            <div class="flex flex-wrap gap-2">
              <button
                type="button"
                (click)="store.offlineMode.set(!store.offlineMode())"
                class="min-h-[38px] px-3 py-1.5 border border-[#CFCAC0] rounded text-xs font-medium cursor-pointer"
                [class.bg-[#A16207]]="store.offlineMode()"
                [class.text-white]="store.offlineMode()"
              >
                {{ store.offlineMode() ? 'Device: Offline (Toggle Online)' : 'Device: Online (Toggle Offline)' }}
              </button>
              <button
                type="button"
                (click)="store.enqueueOfflineDemoMutation(false)"
                class="min-h-[38px] px-3 py-1.5 bg-[#222924] text-[#F5F2EA] rounded text-xs font-medium cursor-pointer"
              >
                Queue Normal Change
              </button>
              <button
                type="button"
                (click)="store.enqueueOfflineDemoMutation(true)"
                class="min-h-[38px] px-3 py-1.5 bg-[#9A7B3E] text-[#FCFBF7] rounded text-xs font-medium cursor-pointer"
              >
                Queue Conflicting Edit
              </button>
              <button
                type="button"
                (click)="store.synchronizeOfflineQueue()"
                class="min-h-[38px] px-3 py-1.5 bg-[#1E6B43] text-white rounded text-xs font-medium cursor-pointer"
              >
                Synchronise & Revalidate
              </button>
              <button
                type="button"
                (click)="store.remoteSessionRevoked.set(!store.remoteSessionRevoked())"
                class="min-h-[38px] px-3 py-1.5 border border-[#B91C1C] text-[#B91C1C] rounded text-xs font-medium cursor-pointer"
              >
                {{ store.remoteSessionRevoked() ? 'Clear Revocation' : 'Simulate Remote Revocation' }}
              </button>
            </div>
          </section>

          <section class="bg-[#FCFBF7] border border-[#DDD8CB] rounded overflow-hidden">
            <table class="w-full text-left border-collapse text-xs">
              <thead>
                <tr class="border-b border-[#DDD8CB] bg-[#F5F2EA] text-[#5A625B]">
                  <th class="py-2.5 px-4 font-medium">Idempotency Key</th>
                  <th class="py-2.5 px-4 font-medium">Mutation</th>
                  <th class="py-2.5 px-4 font-medium">Version</th>
                  <th class="py-2.5 px-4 font-medium">Status</th>
                  <th class="py-2.5 px-4 font-medium text-right">Resolution</th>
                </tr>
              </thead>
              <tbody class="divide-y divide-[#EFECE2]">
                @for (item of store.offlineQueue(); track item.id) {
                  <tr>
                    <td class="py-2.5 px-4 font-mono text-[#5A625B]">{{ item.idempotencyKey.slice(0, 18) }}...</td>
                    <td class="py-2.5 px-4">
                      <div class="font-medium text-[#1C221E]">{{ item.summary }}</div>
                      @if (item.conflictDetail) {
                        <div class="text-[#B91C1C]">{{ item.conflictDetail }}</div>
                      }
                    </td>
                    <td class="py-2.5 px-4 font-mono">v{{ item.expectedVersion }}</td>
                    <td class="py-2.5 px-4 font-semibold" [class.text-[#B91C1C]]="item.status === 'Conflict' || item.status === 'Rejected'" [class.text-[#1E6B43]]="item.status === 'Synced'">
                      {{ item.status }}
                    </td>
                    <td class="py-2.5 px-4 text-right whitespace-nowrap space-x-1.5">
                      @if (item.status === 'Conflict') {
                        <button type="button" (click)="store.resolveOfflineConflict(item.id, 'accept_server')" class="px-2 py-1 border border-[#CFCAC0] rounded cursor-pointer">Accept Server</button>
                        <button type="button" (click)="store.resolveOfflineConflict(item.id, 'retry_latest')" class="px-2 py-1 bg-[#9A7B3E] text-white rounded cursor-pointer">Rebase & Apply</button>
                      }
                    </td>
                  </tr>
                } @empty {
                  <tr>
                    <td colspan="5" class="py-6 text-center text-[#5A625B]">
                      Offline mutation queue is empty. Queue a normal or conflicting edit above to verify synchronisation behavior.
                    </td>
                  </tr>
                }
              </tbody>
            </table>
          </section>
        </div>
      }

      <!-- Tab 4: Append-Only Audit Log -->
      @if (activeTab() === 'audit') {
        <section class="bg-[#FCFBF7] border border-[#DDD8CB] rounded overflow-hidden">
          <div class="p-4 border-b border-[#DDD8CB] flex items-center justify-between">
            <h2 class="text-base font-semibold text-[#1C221E]">Append-Only Audit Trail ({{ store.auditEvents().length }} events)</h2>
            <span class="font-mono text-xs text-[#5A625B]">Immutable · Update/Delete Blocked</span>
          </div>
          <div class="overflow-x-auto">
            <table class="w-full text-left border-collapse text-xs">
              <thead>
                <tr class="border-b border-[#DDD8CB] bg-[#F5F2EA] text-[#5A625B]">
                  <th class="py-2.5 px-4 font-medium">Timestamp</th>
                  <th class="py-2.5 px-4 font-medium">Actor & Role</th>
                  <th class="py-2.5 px-4 font-medium">Action</th>
                  <th class="py-2.5 px-4 font-medium">Entity</th>
                  <th class="py-2.5 px-4 font-medium">Summary</th>
                </tr>
              </thead>
              <tbody class="divide-y divide-[#EFECE2]">
                @for (ev of store.auditEvents(); track ev.id) {
                  <tr>
                    <td class="py-2.5 px-4 font-mono text-[#5A625B] whitespace-nowrap">{{ ev.timestamp.slice(0, 19).replace('T', ' ') }}</td>
                    <td class="py-2.5 px-4 whitespace-nowrap">
                      <div class="text-[#1C221E]">{{ ev.actorEmail }}</div>
                      <div class="font-mono text-[#5A625B]">{{ ev.actorRole }}</div>
                    </td>
                    <td class="py-2.5 px-4 font-mono text-[#2A3B30] whitespace-nowrap">{{ ev.action }}</td>
                    <td class="py-2.5 px-4 font-mono text-[#5A625B] whitespace-nowrap">{{ ev.entityType }}/{{ ev.entityId }}</td>
                    <td class="py-2.5 px-4 text-[#3C443E]">{{ ev.summary }}</td>
                  </tr>
                }
              </tbody>
            </table>
          </div>
        </section>
      }

      <!-- Tab 5: Deliverables Hub -->
      @if (activeTab() === 'deliverables') {
        <div class="grid grid-cols-1 lg:grid-cols-12 gap-6">
          <div class="lg:col-span-4 space-y-2.5">
            @for (doc of deliverables; track doc.id) {
              <button
                type="button"
                (click)="selectedDeliverableId.set(doc.id)"
                class="w-full text-left p-4 rounded border transition-colors cursor-pointer"
                [class.bg-[#222924]]="selectedDeliverableId() === doc.id"
                [class.text-[#F5F2EA]]="selectedDeliverableId() === doc.id"
                [class.border-[#222924]]="selectedDeliverableId() === doc.id"
                [class.bg-[#FCFBF7]]="selectedDeliverableId() !== doc.id"
                [class.text-[#1C221E]]="selectedDeliverableId() !== doc.id"
                [class.border-[#DDD8CB]]="selectedDeliverableId() !== doc.id"
              >
                <div class="font-mono text-[11px] opacity-75">{{ doc.category }} · {{ doc.filename }}</div>
                <div class="font-semibold text-sm mt-1">{{ doc.title }}</div>
                <div class="text-xs opacity-85 mt-1">{{ doc.summary }}</div>
              </button>
            }
          </div>
          <div class="lg:col-span-8 bg-[#1C221E] text-[#F5F2EA] rounded border border-[#2E3731] p-5 overflow-hidden">
            @if (selectedDeliverable(); as doc) {
              <div class="flex items-center justify-between border-b border-[#2E3731] pb-3 mb-4">
                <div>
                  <div class="font-mono text-xs text-[#B4924B]">{{ doc.filename }}</div>
                  <h2 class="text-base font-semibold text-[#F5F2EA]">{{ doc.title }}</h2>
                </div>
              </div>
              <pre class="font-mono text-xs leading-relaxed overflow-x-auto max-h-[540px] text-[#E6E2D6]">{{ doc.content }}</pre>
            }
          </div>
        </div>
      }
    </div>
  `,
})
export class AdministrationComponent {
  readonly store = inject(StoreService);

  readonly adminTabs: {id: 'rbac' | 'delegations' | 'sync' | 'audit' | 'deliverables'; label: string}[] = [
    {id: 'rbac', label: 'Role Matrix & Persona Switch'},
    {id: 'delegations', label: 'Delegations'},
    {id: 'sync', label: 'Offline Sync & Conflicts'},
    {id: 'audit', label: 'Append-Only Audit Trail'},
    {id: 'deliverables', label: 'Architecture & Code Deliverables'},
  ];

  readonly activeTab = signal<'rbac' | 'delegations' | 'sync' | 'audit' | 'deliverables'>('rbac');
  readonly roles = ALL_ROLES;
  readonly roleDefs = ROLE_DEFINITIONS;
  readonly allPermissions = ALL_PERMISSIONS;
  readonly deliverables = DELIVERABLE_DOCS;
  readonly selectedDeliverableId = signal(DELIVERABLE_DOCS[0].id);

  delName = '';
  delRole: Delegation['roleGranted'] = 'approver';
  delUnit = 'unit-log-sqn';
  delFrom = '2026-11-21';
  delUntil = '2026-12-31';
  delReason = 'Temporary holiday cover';

  selectedDeliverable() {
    return this.deliverables.find((d) => d.id === this.selectedDeliverableId()) ?? this.deliverables[0];
  }

  checkPerm(role: AppRole, action: (typeof ALL_PERMISSIONS)[number]['action']): boolean {
    return hasPermission(role, action);
  }

  async testDeniedAccess(): Promise<void> {
    if (this.store.activeRole() !== 'individual_member') {
      await this.store.switchDemoRole('individual_member');
    }
    await this.store.loadPersonSensitive('per-002');
  }

  async submitDelegation(): Promise<void> {
    if (!this.delName.trim()) return;
    const ok = await this.store.createDelegation({
      delegateName: this.delName,
      roleGranted: this.delRole,
      unitScope: this.delUnit,
      validFrom: this.delFrom,
      validUntil: this.delUntil,
      reason: this.delReason,
    });
    if (ok) this.delName = '';
  }
}
