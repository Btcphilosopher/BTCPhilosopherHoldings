import {ChangeDetectionStrategy, Component, computed, inject, signal} from '@angular/core';
import {FormsModule} from '@angular/forms';
import {Assignment, Position} from '../core/models';
import {StoreService} from '../core/store.service';

@Component({
  selector: 'app-units',
  imports: [FormsModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-6">
      <div class="flex flex-col gap-4 md:flex-row md:items-end md:justify-between border-b border-[#DDD8CB] pb-5">
        <div>
          <p class="text-xs font-medium tracking-wider text-[#5A625B] uppercase">
            Organisational Hierarchy & Establishment
          </p>
          <h1 class="mt-1 text-2xl font-semibold text-[#1C221E]">Units & Authorised Positions</h1>
          <p class="mt-1 text-sm text-[#4A524C]">
            Separates authorised establishment billets from actual postings, temporary attachments, and vacancies. Circular hierarchies are blocked.
          </p>
        </div>
        <div class="flex flex-wrap gap-3">
          <button
            type="button"
            (click)="showUnitModal.set(true)"
            class="min-h-[44px] px-4 py-2.5 bg-[#FCFBF7] hover:bg-[#EDE9DE] border border-[#CFCAC0] text-[#1C221E] text-sm font-medium rounded cursor-pointer"
          >
            Establish Unit
          </button>
          <button
            type="button"
            (click)="showPosModal.set(true)"
            class="min-h-[44px] px-4 py-2.5 bg-[#9A7B3E] hover:bg-[#826630] text-[#FCFBF7] text-sm font-medium rounded cursor-pointer"
          >
            Add Position Billet
          </button>
        </div>
      </div>

      <!-- Unit Cards / Hierarchy -->
      <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
        @for (u of unitSummaries(); track u.unit.id) {
          <div class="bg-[#FCFBF7] border border-[#DDD8CB] rounded p-5 space-y-3">
            <div class="flex items-start justify-between gap-4">
              <div>
                <div class="font-mono text-xs text-[#5A625B]">
                  {{ u.unit.code }} · {{ u.parentCode ? 'Reports to ' + u.parentCode : 'Top-Level Command' }}
                </div>
                <h2 class="mt-0.5 text-base font-semibold text-[#1C221E]">{{ u.unit.name }}</h2>
                <p class="text-xs text-[#4A524C]">{{ u.unit.location }} · Effective {{ u.unit.effectiveDate }}</p>
              </div>
              <span class="text-xs font-medium text-[#1E6B43]">{{ u.unit.status }}</span>
            </div>
            <div class="grid grid-cols-4 gap-2 pt-2 border-t border-[#EAE5D8] text-xs">
              <div>
                <div class="text-[#5A625B]">Authorised</div>
                <div class="font-mono font-semibold text-[#1C221E]">{{ u.unit.authorisedStrength }}</div>
              </div>
              <div>
                <div class="text-[#5A625B]">Billets</div>
                <div class="font-mono font-semibold text-[#1C221E]">{{ u.totalPositions }}</div>
              </div>
              <div>
                <div class="text-[#5A625B]">Filled</div>
                <div class="font-mono font-semibold text-[#1E6B43]">{{ u.filled }}</div>
              </div>
              <div>
                <div class="text-[#5A625B]">Vacant</div>
                <div class="font-mono font-semibold text-[#A16207]">{{ u.vacant }}</div>
              </div>
            </div>
          </div>
        }
      </div>

      <!-- Establishment Position Roster -->
      <section class="bg-[#FCFBF7] border border-[#DDD8CB] rounded overflow-hidden">
        <div class="p-4 border-b border-[#DDD8CB] flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <h2 class="text-base font-semibold text-[#1C221E]">Establishment Positions & Assignments</h2>
          <select
            [(ngModel)]="unitFilter"
            aria-label="Filter positions by unit"
            class="min-h-[40px] px-3 bg-white border border-[#CFCAC0] rounded text-sm"
          >
            <option value="">All Units</option>
            @for (u of store.units(); track u.id) {
              <option [value]="u.id">{{ u.code }} · {{ u.name }}</option>
            }
          </select>
        </div>
        <div class="overflow-x-auto">
          <table class="w-full text-left border-collapse text-sm">
            <thead>
              <tr class="border-b border-[#DDD8CB] bg-[#F5F2EA] text-xs text-[#5A625B]">
                <th class="py-3 px-4 font-medium">Billet Code</th>
                <th class="py-3 px-4 font-medium">Title & Unit</th>
                <th class="py-3 px-4 font-medium">Type</th>
                <th class="py-3 px-4 font-medium">Req. Rank</th>
                <th class="py-3 px-4 font-medium">Status & Incumbent</th>
                <th class="py-3 px-4 font-medium text-right">Action</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-[#EFECE2]">
              @for (pos of filteredPositions(); track pos.id) {
                <tr class="hover:bg-[#F5F2EA]/70">
                  <td class="py-3 px-4 font-mono text-xs font-medium text-[#2A3B30] whitespace-nowrap">{{ pos.code }}</td>
                  <td class="py-3 px-4">
                    <div class="font-medium text-[#1C221E]">{{ pos.title }}</div>
                    <div class="text-xs text-[#5A625B]">{{ unitCode(pos.unitId) }}</div>
                  </td>
                  <td class="py-3 px-4 text-xs text-[#3C443E]">{{ pos.appointmentType }}</td>
                  <td class="py-3 px-4 font-mono text-xs text-[#1C221E]">{{ pos.requiredRank }}</td>
                  <td class="py-3 px-4 text-xs">
                    <span
                      class="font-medium"
                      [class.text-[#1E6B43]]="pos.status === 'Filled'"
                      [class.text-[#A16207]]="pos.status === 'Vacant'"
                      [class.text-[#4B5563]]="pos.status === 'Frozen'"
                    >
                      {{ pos.status }}
                    </span>
                    @if (pos.assignedPersonId) {
                      <span class="text-[#3C443E]"> · {{ personLabel(pos.assignedPersonId) }}</span>
                    }
                  </td>
                  <td class="py-3 px-4 text-right whitespace-nowrap">
                    <button
                      type="button"
                      (click)="openAssignModal(pos)"
                      class="min-h-[36px] px-3 py-1 bg-[#222924] hover:bg-[#313B34] text-[#F5F2EA] text-xs font-medium rounded cursor-pointer"
                    >
                      Assign Person
                    </button>
                  </td>
                </tr>
              }
            </tbody>
          </table>
        </div>
      </section>

      <!-- Assign Modal -->
      @if (assigningPosition(); as pos) {
        <div class="fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4" role="dialog" aria-modal="true">
          <div class="bg-[#FCFBF7] border border-[#CFCAC0] rounded max-w-lg w-full p-6 space-y-4">
            <h2 class="text-lg font-semibold text-[#1C221E]">Assign Personnel to {{ pos.code }} ({{ pos.title }})</h2>
            <form (ngSubmit)="submitAssign()" class="space-y-3 text-sm">
              <label class="block">
                <span class="block text-xs font-medium text-[#4A524C] mb-1">Personnel Record</span>
                <select [(ngModel)]="assignPersonId" name="personId" required class="w-full min-h-[40px] px-3 bg-white border border-[#CFCAC0] rounded">
                  @for (p of store.people(); track p.id) {
                    <option [value]="p.id">{{ p.serviceId }} · {{ p.rank }} {{ p.surname }}, {{ p.givenNames }}</option>
                  }
                </select>
              </label>
              <div class="grid grid-cols-2 gap-3">
                <label class="block">
                  <span class="block text-xs font-medium text-[#4A524C] mb-1">Assignment Type</span>
                  <select [(ngModel)]="assignType" name="assignType" class="w-full min-h-[40px] px-3 bg-white border border-[#CFCAC0] rounded">
                    <option value="Primary Posting">Primary Posting</option>
                    <option value="Temporary Attachment">Temporary Attachment</option>
                    <option value="Acting Appointment">Acting Appointment</option>
                  </select>
                </label>
                <label class="block">
                  <span class="block text-xs font-medium text-[#4A524C] mb-1">Effective Date</span>
                  <input type="date" [(ngModel)]="assignDate" name="assignDate" required class="w-full min-h-[40px] px-3 bg-white border border-[#CFCAC0] rounded" />
                </label>
              </div>
              <label class="block">
                <span class="block text-xs font-medium text-[#4A524C] mb-1">Posting Authority / Reason</span>
                <input [(ngModel)]="assignReason" name="reason" required class="w-full min-h-[40px] px-3 bg-white border border-[#CFCAC0] rounded" placeholder="Establishment fill / career posting" />
              </label>
              <div class="flex justify-end gap-3 pt-2">
                <button type="button" (click)="assigningPosition.set(null)" class="min-h-[40px] px-4 border border-[#CFCAC0] rounded cursor-pointer">Cancel</button>
                <button type="submit" class="min-h-[40px] px-5 bg-[#9A7B3E] text-[#FCFBF7] rounded font-medium cursor-pointer">Confirm Assignment</button>
              </div>
            </form>
          </div>
        </div>
      }

      <!-- Create Unit Modal -->
      @if (showUnitModal()) {
        <div class="fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4" role="dialog" aria-modal="true">
          <div class="bg-[#FCFBF7] border border-[#CFCAC0] rounded max-w-lg w-full p-6 space-y-4">
            <h2 class="text-lg font-semibold text-[#1C221E]">Establish New Fictional Unit</h2>
            <form (ngSubmit)="submitCreateUnit()" class="space-y-3 text-sm">
              <div class="grid grid-cols-2 gap-3">
                <label class="block">
                  <span class="block text-xs font-medium text-[#4A524C] mb-1">Unit Code</span>
                  <input [(ngModel)]="newUnitCode" name="unitCode" required class="w-full min-h-[40px] px-3 bg-white border border-[#CFCAC0] rounded font-mono text-xs" placeholder="9-ADM-DET" />
                </label>
                <label class="block">
                  <span class="block text-xs font-medium text-[#4A524C] mb-1">Authorised Strength</span>
                  <input type="number" min="1" [(ngModel)]="newUnitStrength" name="strength" required class="w-full min-h-[40px] px-3 bg-white border border-[#CFCAC0] rounded" />
                </label>
              </div>
              <label class="block">
                <span class="block text-xs font-medium text-[#4A524C] mb-1">Unit Name</span>
                <input [(ngModel)]="newUnitName" name="unitName" required class="w-full min-h-[40px] px-3 bg-white border border-[#CFCAC0] rounded" />
              </label>
              <label class="block">
                <span class="block text-xs font-medium text-[#4A524C] mb-1">Parent Unit</span>
                <select [(ngModel)]="newUnitParentId" name="parentId" class="w-full min-h-[40px] px-3 bg-white border border-[#CFCAC0] rounded">
                  <option value="">None (Top-level)</option>
                  @for (u of store.units(); track u.id) {
                    <option [value]="u.id">{{ u.code }} · {{ u.name }}</option>
                  }
                </select>
              </label>
              <div class="grid grid-cols-2 gap-3">
                <label class="block">
                  <span class="block text-xs font-medium text-[#4A524C] mb-1">Station Location</span>
                  <input [(ngModel)]="newUnitLocation" name="location" required class="w-full min-h-[40px] px-3 bg-white border border-[#CFCAC0] rounded" />
                </label>
                <label class="block">
                  <span class="block text-xs font-medium text-[#4A524C] mb-1">Effective Date</span>
                  <input type="date" [(ngModel)]="newUnitDate" name="effectiveDate" required class="w-full min-h-[40px] px-3 bg-white border border-[#CFCAC0] rounded" />
                </label>
              </div>
              <div class="flex justify-end gap-3 pt-2">
                <button type="button" (click)="showUnitModal.set(false)" class="min-h-[40px] px-4 border border-[#CFCAC0] rounded cursor-pointer">Cancel</button>
                <button type="submit" class="min-h-[40px] px-5 bg-[#9A7B3E] text-[#FCFBF7] rounded font-medium cursor-pointer">Establish Unit</button>
              </div>
            </form>
          </div>
        </div>
      }

      <!-- Create Position Modal -->
      @if (showPosModal()) {
        <div class="fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4" role="dialog" aria-modal="true">
          <div class="bg-[#FCFBF7] border border-[#CFCAC0] rounded max-w-lg w-full p-6 space-y-4">
            <h2 class="text-lg font-semibold text-[#1C221E]">Add Establishment Position</h2>
            <form (ngSubmit)="submitCreatePosition()" class="space-y-3 text-sm">
              <div class="grid grid-cols-2 gap-3">
                <label class="block">
                  <span class="block text-xs font-medium text-[#4A524C] mb-1">Billet Code</span>
                  <input [(ngModel)]="newPosCode" name="posCode" required class="w-full min-h-[40px] px-3 bg-white border border-[#CFCAC0] rounded font-mono text-xs" placeholder="SIG-CLK-09" />
                </label>
                <label class="block">
                  <span class="block text-xs font-medium text-[#4A524C] mb-1">Required Rank</span>
                  <input [(ngModel)]="newPosRank" name="posRank" required class="w-full min-h-[40px] px-3 bg-white border border-[#CFCAC0] rounded" />
                </label>
              </div>
              <label class="block">
                <span class="block text-xs font-medium text-[#4A524C] mb-1">Position Title</span>
                <input [(ngModel)]="newPosTitle" name="posTitle" required class="w-full min-h-[40px] px-3 bg-white border border-[#CFCAC0] rounded" />
              </label>
              <div class="grid grid-cols-2 gap-3">
                <label class="block">
                  <span class="block text-xs font-medium text-[#4A524C] mb-1">Unit</span>
                  <select [(ngModel)]="newPosUnitId" name="posUnitId" required class="w-full min-h-[40px] px-3 bg-white border border-[#CFCAC0] rounded">
                    @for (u of store.units(); track u.id) {
                      <option [value]="u.id">{{ u.code }}</option>
                    }
                  </select>
                </label>
                <label class="block">
                  <span class="block text-xs font-medium text-[#4A524C] mb-1">Appointment Type</span>
                  <select [(ngModel)]="newPosType" name="posType" class="w-full min-h-[40px] px-3 bg-white border border-[#CFCAC0] rounded">
                    <option value="Established">Established</option>
                    <option value="Temporary Attachment">Temporary Attachment</option>
                    <option value="Training Billet">Training Billet</option>
                  </select>
                </label>
              </div>
              <div class="flex justify-end gap-3 pt-2">
                <button type="button" (click)="showPosModal.set(false)" class="min-h-[40px] px-4 border border-[#CFCAC0] rounded cursor-pointer">Cancel</button>
                <button type="submit" class="min-h-[40px] px-5 bg-[#9A7B3E] text-[#FCFBF7] rounded font-medium cursor-pointer">Add Billet</button>
              </div>
            </form>
          </div>
        </div>
      }
    </div>
  `,
})
export class UnitsComponent {
  readonly store = inject(StoreService);

  readonly unitFilter = signal('');
  readonly assigningPosition = signal<Position | null>(null);
  readonly showUnitModal = signal(false);
  readonly showPosModal = signal(false);

  assignPersonId = '';
  assignType: Assignment['assignmentType'] = 'Primary Posting';
  assignDate = '2026-11-21';
  assignReason = 'Establishment fill';

  newUnitCode = '';
  newUnitName = '';
  newUnitParentId = 'unit-hq-demo';
  newUnitStrength = 6;
  newUnitLocation = 'York Barracks (Demo)';
  newUnitDate = '2026-11-21';

  newPosCode = '';
  newPosTitle = '';
  newPosUnitId = 'unit-sig-regt';
  newPosRank = 'Cpl';
  newPosType: Position['appointmentType'] = 'Established';

  readonly unitSummaries = computed(() => {
    const units = this.store.units();
    const positions = this.store.positions();
    return units.map((unit) => {
      const unitPos = positions.filter((p) => p.unitId === unit.id);
      const parent = unit.parentUnitId ? units.find((u) => u.id === unit.parentUnitId) : undefined;
      return {
        unit,
        parentCode: parent?.code ?? '',
        totalPositions: unitPos.length,
        filled: unitPos.filter((p) => p.status === 'Filled').length,
        vacant: unitPos.filter((p) => p.status === 'Vacant').length,
      };
    });
  });

  readonly filteredPositions = computed(() => {
    const uf = this.unitFilter();
    return this.store.positions().filter((p) => !uf || p.unitId === uf);
  });

  unitCode(unitId: string): string {
    return this.store.units().find((u) => u.id === unitId)?.code ?? unitId;
  }

  personLabel(personId: string): string {
    const p = this.store.people().find((x) => x.id === personId);
    return p ? `${p.rank} ${p.surname} (${p.serviceId})` : personId;
  }

  openAssignModal(pos: Position): void {
    this.assigningPosition.set(pos);
    this.assignPersonId = this.store.people()[0]?.id ?? '';
  }

  async submitAssign(): Promise<void> {
    const pos = this.assigningPosition();
    if (!pos || !this.assignPersonId) return;
    const ok = await this.store.assignPersonToPosition({
      personId: this.assignPersonId,
      positionId: pos.id,
      assignmentType: this.assignType,
      startDate: this.assignDate,
      reason: this.assignReason,
    });
    if (ok) this.assigningPosition.set(null);
  }

  async submitCreateUnit(): Promise<void> {
    if (!this.newUnitCode.trim() || !this.newUnitName.trim()) return;
    const created = await this.store.createUnit({
      code: this.newUnitCode,
      name: this.newUnitName,
      parentUnitId: this.newUnitParentId || undefined,
      authorisedStrength: this.newUnitStrength,
      location: this.newUnitLocation,
      effectiveDate: this.newUnitDate,
    });
    if (created) {
      this.showUnitModal.set(false);
      this.newUnitCode = '';
      this.newUnitName = '';
    }
  }

  async submitCreatePosition(): Promise<void> {
    if (!this.newPosCode.trim() || !this.newPosTitle.trim()) return;
    const created = await this.store.createPosition({
      code: this.newPosCode,
      title: this.newPosTitle,
      unitId: this.newPosUnitId,
      requiredRank: this.newPosRank,
      appointmentType: this.newPosType,
      effectiveDate: '2026-11-21',
    });
    if (created) {
      this.showPosModal.set(false);
      this.newPosCode = '';
      this.newPosTitle = '';
    }
  }
}
