import {ChangeDetectionStrategy, Component, inject, signal} from '@angular/core';
import {FormsModule} from '@angular/forms';
import {StockItem, StockMovement} from '../core/models';
import {StoreService} from '../core/store.service';

@Component({
  selector: 'app-stores',
  imports: [FormsModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-6">
      <div class="flex flex-col gap-4 md:flex-row md:items-end md:justify-between border-b border-[#DDD8CB] pb-5">
        <div>
          <p class="text-xs font-medium tracking-wider text-[#5A625B] uppercase">
            Consumables, Spares & Immutable Movement Ledger
          </p>
          <h1 class="mt-1 text-2xl font-semibold text-[#1C221E]">Stores & Stock Accounting</h1>
          <p class="mt-1 text-sm text-[#4A524C]">
            Distinguishes Available, Reserved, Quarantined, Damaged, and In-Transit stock. All changes append to an immutable stock-movement ledger.
          </p>
        </div>
        <button
          type="button"
          (click)="runReconciliation()"
          class="min-h-[44px] px-4 py-2.5 bg-[#222924] hover:bg-[#313B34] text-[#F5F2EA] text-sm font-medium rounded cursor-pointer"
        >
          Run Stores Reconciliation
        </button>
      </div>

      @if (reconciliationResult(); as rec) {
        <div class="bg-[#FCFBF7] border border-[#9A7B3E] rounded p-4 text-xs flex items-center justify-between gap-4">
          <div>
            <span class="font-semibold text-[#1C221E]">Reconciliation Verified:</span>
            <span class="text-[#3C443E]"> {{ rec }}</span>
          </div>
          <button type="button" (click)="reconciliationResult.set(null)" class="text-[#5A625B] hover:text-[#1C221E] cursor-pointer">Dismiss</button>
        </div>
      }

      <!-- Stock Inventory Balances -->
      <section class="bg-[#FCFBF7] border border-[#DDD8CB] rounded overflow-hidden">
        <div class="p-4 border-b border-[#DDD8CB]">
          <h2 class="text-base font-semibold text-[#1C221E]">Stock Inventory Buckets</h2>
        </div>
        <div class="overflow-x-auto">
          <table class="w-full text-left border-collapse text-sm">
            <thead>
              <tr class="border-b border-[#DDD8CB] bg-[#F5F2EA] text-xs text-[#5A625B]">
                <th class="py-3 px-4 font-medium">SKU</th>
                <th class="py-3 px-4 font-medium">Nomenclature & Unit</th>
                <th class="py-3 px-4 font-medium text-right">Available</th>
                <th class="py-3 px-4 font-medium text-right">Reserved</th>
                <th class="py-3 px-4 font-medium text-right">Quarantined</th>
                <th class="py-3 px-4 font-medium text-right">Damaged</th>
                <th class="py-3 px-4 font-medium text-right">In Transit</th>
                <th class="py-3 px-4 font-medium text-right">Action</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-[#EFECE2]">
              @for (s of store.stockItems(); track s.id) {
                <tr class="hover:bg-[#F5F2EA]/70">
                  <td class="py-3 px-4 font-mono text-xs font-medium text-[#2A3B30] whitespace-nowrap">{{ s.sku }}</td>
                  <td class="py-3 px-4">
                    <div class="font-medium text-[#1C221E]">{{ s.nomenclature }}</div>
                    <div class="text-xs text-[#5A625B]">{{ unitCode(s.unitId) }} · {{ s.unitOfMeasure }} · Reorder @ {{ s.reorderLevel }}</div>
                  </td>
                  <td class="py-3 px-4 text-right font-mono tabular-nums font-semibold" [class.text-[#B91C1C]]="s.availableQty <= s.reorderLevel" [class.text-[#1E6B43]]="s.availableQty > s.reorderLevel">
                    {{ s.availableQty }}
                  </td>
                  <td class="py-3 px-4 text-right font-mono tabular-nums text-[#9A7B3E]">{{ s.reservedQty }}</td>
                  <td class="py-3 px-4 text-right font-mono tabular-nums text-[#A16207]">{{ s.quarantinedQty }}</td>
                  <td class="py-3 px-4 text-right font-mono tabular-nums text-[#B91C1C]">{{ s.damagedQty }}</td>
                  <td class="py-3 px-4 text-right font-mono tabular-nums text-[#4B5563]">{{ s.inTransitQty }}</td>
                  <td class="py-3 px-4 text-right whitespace-nowrap">
                    <button
                      type="button"
                      (click)="openMoveModal(s)"
                      class="min-h-[34px] px-3 py-1 bg-[#9A7B3E] text-[#FCFBF7] text-xs font-medium rounded cursor-pointer"
                    >
                      Post Movement
                    </button>
                  </td>
                </tr>
              }
            </tbody>
          </table>
        </div>
      </section>

      <!-- Immutable Ledger -->
      <section class="bg-[#FCFBF7] border border-[#DDD8CB] rounded overflow-hidden">
        <div class="p-4 border-b border-[#DDD8CB]">
          <h2 class="text-base font-semibold text-[#1C221E]">Immutable Stock-Movement Ledger</h2>
          <p class="text-xs text-[#5A625B]">Append-only ledger entries; historical movements cannot be modified or deleted.</p>
        </div>
        <div class="overflow-x-auto">
          <table class="w-full text-left border-collapse text-xs">
            <thead>
              <tr class="border-b border-[#DDD8CB] bg-[#F5F2EA] text-[#5A625B]">
                <th class="py-2.5 px-4 font-medium">Movement Ref</th>
                <th class="py-2.5 px-4 font-medium">Timestamp</th>
                <th class="py-2.5 px-4 font-medium">SKU</th>
                <th class="py-2.5 px-4 font-medium">Type</th>
                <th class="py-2.5 px-4 font-medium text-right">Qty</th>
                <th class="py-2.5 px-4 font-medium">Bucket Transition</th>
                <th class="py-2.5 px-4 font-medium">Reference & Reason</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-[#EFECE2]">
              @for (m of store.stockMovements(); track m.id) {
                <tr>
                  <td class="py-2.5 px-4 font-mono text-[#2A3B30] whitespace-nowrap">{{ m.movementRef }}</td>
                  <td class="py-2.5 px-4 font-mono text-[#5A625B] whitespace-nowrap">{{ m.createdAt.slice(0, 19).replace('T', ' ') }}</td>
                  <td class="py-2.5 px-4 font-mono text-[#1C221E]">{{ m.sku }}</td>
                  <td class="py-2.5 px-4 font-medium">{{ m.movementType }}</td>
                  <td class="py-2.5 px-4 text-right font-mono tabular-nums">{{ m.quantity }}</td>
                  <td class="py-2.5 px-4 font-mono text-[#4A524C]">{{ m.bucketFrom }} -> {{ m.bucketTo }}</td>
                  <td class="py-2.5 px-4 text-[#3C443E]"><span class="font-mono">{{ m.referenceDoc }}</span> · {{ m.reason }}</td>
                </tr>
              }
            </tbody>
          </table>
        </div>
      </section>

      <!-- Post Movement Modal -->
      @if (movingItem(); as item) {
        <div class="fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4" role="dialog" aria-modal="true">
          <div class="bg-[#FCFBF7] border border-[#CFCAC0] rounded max-w-lg w-full p-6 space-y-4">
            <h2 class="text-lg font-semibold text-[#1C221E]">Post Ledger Movement: {{ item.sku }}</h2>
            <form (ngSubmit)="submitMovement()" class="space-y-3 text-sm">
              <div class="grid grid-cols-2 gap-3">
                <label class="block">
                  <span class="block text-xs font-medium text-[#4A524C] mb-1">Movement Type</span>
                  <select [(ngModel)]="moveType" name="moveType" class="w-full min-h-[40px] px-3 bg-white border border-[#CFCAC0] rounded">
                    <option value="Receipt">Receipt (+Available)</option>
                    <option value="Issue">Issue (-Available)</option>
                    <option value="Reserve">Reserve (Available -> Reserved)</option>
                    <option value="Release Reservation">Release Reservation</option>
                    <option value="Quarantine">Quarantine (Available -> Quarantined)</option>
                    <option value="Transfer">Transfer (Available -> In Transit)</option>
                    <option value="Return">Return (+Available)</option>
                    <option value="Adjustment">Adjustment (+Available)</option>
                  </select>
                </label>
                <label class="block">
                  <span class="block text-xs font-medium text-[#4A524C] mb-1">Quantity</span>
                  <input type="number" min="1" [(ngModel)]="moveQty" name="moveQty" required class="w-full min-h-[40px] px-3 bg-white border border-[#CFCAC0] rounded" />
                </label>
              </div>
              <label class="block">
                <span class="block text-xs font-medium text-[#4A524C] mb-1">Reference Document</span>
                <input [(ngModel)]="moveRefDoc" name="moveRefDoc" required class="w-full min-h-[40px] px-3 bg-white border border-[#CFCAC0] rounded font-mono text-xs" placeholder="REQ-2026-009" />
              </label>
              <label class="block">
                <span class="block text-xs font-medium text-[#4A524C] mb-1">Accounting Reason</span>
                <input [(ngModel)]="moveReason" name="moveReason" required class="w-full min-h-[40px] px-3 bg-white border border-[#CFCAC0] rounded" placeholder="Workshop issue / stocktake adjustment" />
              </label>
              <div class="flex justify-end gap-3 pt-2">
                <button type="button" (click)="movingItem.set(null)" class="min-h-[40px] px-4 border border-[#CFCAC0] rounded cursor-pointer">Cancel</button>
                <button type="submit" class="min-h-[40px] px-5 bg-[#9A7B3E] text-[#FCFBF7] rounded font-medium cursor-pointer">Post Ledger Entry</button>
              </div>
            </form>
          </div>
        </div>
      }
    </div>
  `,
})
export class StoresComponent {
  readonly store = inject(StoreService);
  readonly movingItem = signal<StockItem | null>(null);
  readonly reconciliationResult = signal<string | null>(null);

  moveType: StockMovement['movementType'] = 'Receipt';
  moveQty = 1;
  moveRefDoc = 'ST-2026-041';
  moveReason = 'Unit stores replenishment';

  unitCode(id: string): string {
    return this.store.units().find((u) => u.id === id)?.code ?? id;
  }

  openMoveModal(item: StockItem): void {
    this.movingItem.set(item);
    this.moveQty = 1;
  }

  async submitMovement(): Promise<void> {
    const item = this.movingItem();
    if (!item) return;
    const ok = await this.store.postStockMovement({
      stockItemId: item.id,
      movementType: this.moveType,
      quantity: this.moveQty,
      referenceDoc: this.moveRefDoc,
      reason: this.moveReason,
    });
    if (ok) this.movingItem.set(null);
  }

  async runReconciliation(): Promise<void> {
    const items = this.store.stockItems();
    const lowStock = items.filter((i) => i.availableQty <= i.reorderLevel).map((i) => i.sku);
    const totalMovements = this.store.stockMovements().length;
    const summary = `${items.length} SKU balances reconciled against ${totalMovements} immutable ledger movements. Low-stock alerts: ${lowStock.length ? lowStock.join(', ') : 'None'}.`;
    this.reconciliationResult.set(summary);
    await this.store.logAudit('STORES_RECONCILED', 'stock_items', 'all', summary);
  }
}
