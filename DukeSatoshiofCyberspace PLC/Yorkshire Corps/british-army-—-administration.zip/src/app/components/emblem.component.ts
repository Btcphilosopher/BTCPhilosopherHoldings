import {ChangeDetectionStrategy, Component, input} from '@angular/core';

@Component({
  selector: 'app-emblem',
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <svg
      [attr.width]="size()"
      [attr.height]="size()"
      viewBox="0 0 40 40"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      aria-hidden="true"
      class="shrink-0"
    >
      <polygon
        points="20,2 33,7.5 38,20 33,32.5 20,38 7,32.5 2,20 7,7.5"
        fill="#222924"
        stroke="#B4924B"
        stroke-width="1.5"
      />
      <polygon
        points="20,5.5 30.5,10 34.5,20 30.5,30 20,34.5 9.5,30 5.5,20 9.5,10"
        stroke="#B4924B"
        stroke-opacity="0.45"
        stroke-width="0.9"
      />
      <path
        d="M14 25V15.5L20 12L26 15.5V25C26 27.2 23.4 29 20 30C16.6 29 14 27.2 14 25Z"
        stroke="#F5F2EA"
        stroke-width="1.4"
        stroke-linejoin="round"
      />
      <path
        d="M20 15.5V26.5M16.5 19.5H23.5"
        stroke="#B4924B"
        stroke-width="1.5"
        stroke-linecap="round"
      />
    </svg>
  `,
})
export class EmblemComponent {
  readonly size = input<number>(36);
}
