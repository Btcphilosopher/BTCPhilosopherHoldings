import {ChangeDetectionStrategy, Component, computed, inject, signal} from '@angular/core';
import {FormsModule} from '@angular/forms';
import {EmblemComponent} from './components/emblem.component';
import {NavSection} from './core/models';
import {StoreService} from './core/store.service';
import {AdministrationComponent} from './features/administration.component';
import {EquipmentComponent} from './features/equipment.component';
import {MaintenanceComponent} from './features/maintenance.component';
import {OverviewComponent} from './features/overview.component';
import {PersonnelComponent} from './features/personnel.component';
import {ReportsComponent} from './features/reports.component';
import {RequestsComponent} from './features/requests.component';
import {StoresComponent} from './features/stores.component';
import {TrainingComponent} from './features/training.component';
import {UnitsComponent} from './features/units.component';

interface NavItem {
  id: NavSection;
  label: string;
  icon: string;
}

@Component({
  selector: 'app-root',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [
    FormsModule,
    EmblemComponent,
    OverviewComponent,
    PersonnelComponent,
    UnitsComponent,
    TrainingComponent,
    EquipmentComponent,
    MaintenanceComponent,
    StoresComponent,
    RequestsComponent,
    ReportsComponent,
    AdministrationComponent,
  ],
  templateUrl: './app.html',
  styleUrl: './app.css',
})
export class App {
  readonly store = inject(StoreService);

  readonly activeSection = signal<NavSection>('overview');
  readonly mobileMenuOpen = signal(false);
  readonly globalQuery = signal('');

  readonly navItems: NavItem[] = [
    {id: 'overview', label: 'Overview', icon: 'dashboard'},
    {id: 'personnel', label: 'Personnel', icon: 'badge'},
    {id: 'units', label: 'Units', icon: 'account_tree'},
    {id: 'training', label: 'Training', icon: 'school'},
    {id: 'equipment', label: 'Equipment', icon: 'inventory_2'},
    {id: 'maintenance', label: 'Maintenance', icon: 'build'},
    {id: 'stores', label: 'Stores', icon: 'warehouse'},
    {id: 'requests', label: 'Requests', icon: 'assignment_turned_in'},
    {id: 'reports', label: 'Reports', icon: 'assessment'},
    {id: 'administration', label: 'Administration', icon: 'admin_panel_settings'},
  ];

  readonly activeLabel = computed(
    () => this.navItems.find((n) => n.id === this.activeSection())?.label ?? 'Overview',
  );

  // Permission-aware search across authorised non-sensitive records only
  readonly quickSearchResults = computed(() => {
    const q = this.globalQuery().trim().toLowerCase();
    if (q.length < 2) return [];
    const results: {section: NavSection; code: string; label: string; meta: string}[] = [];

    for (const p of this.store.people()) {
      if (
        p.serviceId.toLowerCase().includes(q) ||
        p.surname.toLowerCase().includes(q) ||
        p.rank.toLowerCase().includes(q)
      ) {
        results.push({
          section: 'personnel',
          code: p.serviceId,
          label: `${p.rank} ${p.surname}, ${p.givenNames}`,
          meta: 'Personnel',
        });
      }
    }

    for (const u of this.store.units()) {
      if (u.code.toLowerCase().includes(q) || u.name.toLowerCase().includes(q)) {
        results.push({
          section: 'units',
          code: u.code,
          label: u.name,
          meta: 'Unit',
        });
      }
    }

    for (const a of this.store.equipmentAssets()) {
      if (
        a.assetId.toLowerCase().includes(q) ||
        a.nomenclature.toLowerCase().includes(q) ||
        a.serialNumber.toLowerCase().includes(q)
      ) {
        results.push({
          section: 'equipment',
          code: a.assetId,
          label: a.nomenclature,
          meta: a.serviceability,
        });
      }
    }

    for (const s of this.store.stockItems()) {
      if (s.sku.toLowerCase().includes(q) || s.nomenclature.toLowerCase().includes(q)) {
        results.push({
          section: 'stores',
          code: s.sku,
          label: s.nomenclature,
          meta: `Avail ${s.availableQty}`,
        });
      }
    }

    return results.slice(0, 8);
  });

  navigateTo(section: NavSection): void {
    this.activeSection.set(section);
    this.mobileMenuOpen.set(false);
    this.globalQuery.set('');
  }
}
