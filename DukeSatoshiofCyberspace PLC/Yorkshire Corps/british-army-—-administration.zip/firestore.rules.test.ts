import {readFileSync} from 'node:fs';
import {describe, expect, it} from 'vitest';

describe('Firestore Security Rules — Dirty Dozen Structural Verification', () => {
  const rulesText = readFileSync('firestore.rules', 'utf8');

  it('starts with global default-deny catch-all rule', () => {
    expect(rulesText).toContain('match /{document=**} {\n      allow read, write: if false;\n    }');
  });

  it('enforces email_verified == true and valid IDs across collections', () => {
    expect(rulesText).toContain('request.auth.token.email_verified == true');
    expect(rulesText).toContain("id.matches('^[a-zA-Z0-9_\\\\-]+$')");
  });

  it('isolates people_sensitive by forbidding list and restricting get away from system_admin', () => {
    const sensitiveBlock = rulesText.slice(rulesText.indexOf('match /people_sensitive/'));
    expect(sensitiveBlock).toContain('allow list: if false;');
    expect(sensitiveBlock).toContain('isUnitAdmin() || isApprover() || existing().ownerUid == request.auth.uid');
  });

  it('enforces append-only immutability on audit_events and stock_movements', () => {
    const auditBlock = rulesText.slice(rulesText.indexOf('match /audit_events/'));
    expect(auditBlock).toContain('allow update, delete: if false;');
    const movBlock = rulesText.slice(rulesText.indexOf('match /stock_movements/'));
    expect(movBlock).toContain('allow update, delete: if false;');
  });

  it('enforces terminal state locking and anti-self-approval on leave_requests', () => {
    expect(rulesText).toContain("!(existing().status in ['Completed', 'Cancelled', 'Withdrawn', 'Rejected'])");
    expect(rulesText).toContain('existing().ownerUid != request.auth.uid');
  });

  it('covers every collection declared in firebase-blueprint.json', () => {
    const blueprint = JSON.parse(readFileSync('firebase-blueprint.json', 'utf8')) as {
      firestore: Record<string, unknown>;
    };
    for (const path of Object.keys(blueprint.firestore)) {
      const col = path.split('/')[1];
      expect(rulesText).toContain(`match /${col}/`);
    }
  });
});
