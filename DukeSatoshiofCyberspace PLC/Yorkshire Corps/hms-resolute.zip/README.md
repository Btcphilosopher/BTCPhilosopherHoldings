# HMS RESOLUTE — Admiral Class Executive Command

Enterprise Android (Kotlin + Jetpack Compose) executive information, engineering readiness, maintenance, and deck-resource coordination terminal with an interactive Compose Canvas ship digital twin and a deterministic Python/FastAPI simulation backend.

> **System Boundary:** All ship, equipment, and operational data are fictional simulation data. Weapons control, targeting, combat planning, flight release authorisation, and machinery actuation remain strictly outside this application. Navigation displays are labelled **INFORMATION VIEW — NOT FOR NAVIGATION**.

## Project Structure
- `app/src/main/java/com/example/ui/` — Theme (`Color.kt`, `Type.kt`, `Theme.kt`), `ResoluteViewModel`, `ResoluteAppShell`, and 8 adaptive screens (`Overview`, `Navigation`, `Aviation`, `Engineering`, `Personnel`, `Logistics`, `Reports`, `Alerts`).
- `app/src/main/java/com/example/shipview/` — Single authoritative coordinate model (`ShipCoordinateModel`) and interactive Compose `Canvas` renderer (`ShipDigitalTwinPanel`) supporting `Deck` / `Hangar` / `Systems`, `Top` / `Isometric`, pan, pinch-zoom, zoom controls, centre, reset, side elevation, and state-driven animations.
- `app/src/main/java/com/example/tasks/` — Contextual `AssetInspectorCard` and `WorkOrderDetailDialog` (`Draft -> Assigned -> In Progress -> Awaiting Review -> Complete`, plus `Blocked`, `Cancelled`, `Reopened`).
- `app/src/main/java/com/example/engineering/` — Availability calculations and stale-green degradation (`AvailabilityCalculator`).
- `app/src/main/java/com/example/navigationinfo/` — Schematic route & weather panel (`NavigationWeatherPanel`).
- `app/src/main/java/com/example/simulation/` — Deterministic in-process simulation engine mirroring the 8 FastAPI scenarios.
- `app/src/main/java/com/example/data/` — Room database, DataStore preferences, Retrofit/Moshi API client, WorkManager sync worker, and seed data.
- `app/src/main/java/com/example/security/` — RBAC role enforcement (`OperatorRole`, `AuthorizationGuard`) and `AndroidKeyStore` AES-256-GCM credential vault.
- `backend/` — Python FastAPI simulation backend (`main.py`, `simulator.py`, `models.py`, `test_backend.py`, `API_DOCS.md`).

## Build & Installation Instructions

### 1. Android Application (Debug / Demo APK)
```bash
# Compile and run local JVM & Robolectric tests
gradle :app:testDebugUnitTest

# Build installable demonstration APK
gradle :app:assembleDebug
# Output: app/build/outputs/apk/debug/app-debug.apk
```

### 2. Python FastAPI Simulation Backend (Optional Live Link)
```bash
cd backend
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
uvicorn main:app --host 0.0.0.0 --port 8000
```
In the Android app under **Alerts -> Python FastAPI Backend**, leave the endpoint at `http://10.0.2.2:8000/` (for Android Emulator) or set your LAN host IP, enable **Prefer Remote FastAPI Backend**, and tap **Apply & Probe Backend**.
