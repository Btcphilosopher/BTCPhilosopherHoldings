package com.example.shipview

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CenterFocusStrong
import androidx.compose.material.icons.filled.MotionPhotosOff
import androidx.compose.material.icons.filled.MotionPhotosOn
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.ZoomIn
import androidx.compose.material.icons.filled.ZoomOut
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.TextMeasurer
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.assets.AssetCategory
import com.example.assets.CarrierAsset
import com.example.assets.DeckLevel
import com.example.assets.OperationalStatus
import com.example.assets.ViewProjectionMode
import com.example.ui.theme.BrassGold
import com.example.ui.theme.BrassGoldMuted
import com.example.ui.theme.DeckMarkingIvory
import com.example.ui.theme.FlightDeckAsphalt
import com.example.ui.theme.FoulLineAmber
import com.example.ui.theme.HangarDeckSteel
import com.example.ui.theme.HullArmorDark
import com.example.ui.theme.IslandStructure
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.MidnightAbyss
import com.example.ui.theme.MidnightNavy
import com.example.ui.theme.NavalBorderMuted
import com.example.ui.theme.NavalSlate
import com.example.ui.theme.SeaGridLine
import com.example.ui.theme.SeaWaterDeep
import com.example.ui.theme.SelectionCyan
import com.example.ui.theme.StatusCautionAmber
import com.example.ui.theme.StatusFaultRed
import com.example.ui.theme.StatusReadyGreen
import com.example.ui.theme.StatusStaleSlate
import com.example.ui.theme.SystemsDeckPlate
import com.example.ui.theme.WarmIvory
import kotlin.math.cos
import kotlin.math.sin

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ShipDigitalTwinPanel(
    assets: List<CarrierAsset>,
    activeDeck: DeckLevel,
    viewMode: ViewProjectionMode,
    viewport: ShipViewportTransform,
    selectedAssetId: String?,
    motionEnabled: Boolean,
    reducedMotion: Boolean,
    isAppForeground: Boolean,
    onSelectDeck: (DeckLevel) -> Unit,
    onSelectViewMode: (ViewProjectionMode) -> Unit,
    onViewportChange: (ShipViewportTransform) -> Unit,
    onZoomBy: (Float) -> Unit,
    onCentreView: () -> Unit,
    onResetView: () -> Unit,
    onToggleMotion: () -> Unit,
    onSelectAsset: (String?) -> Unit,
    modifier: Modifier = Modifier
) {
    val animateActive = motionEnabled && !reducedMotion && isAppForeground
    val textMeasurer = rememberTextMeasurer()
    var canvasSize by remember { mutableStateOf(IntSize.Zero) }

    // Smooth interpolated positions for moving service vehicles (separates reported vs rendered state)
    val tug01 = assets.find { it.id == "TUG-01" }
    val tug02 = assets.find { it.id == "TUG-02" }
    val tug01RenderX by animateFloatAsState(
        targetValue = tug01?.shipX ?: 590f,
        animationSpec = tween(durationMillis = if (animateActive) 1100 else 0),
        label = "tug01_x"
    )
    val tug01RenderY by animateFloatAsState(
        targetValue = tug01?.shipY ?: 205f,
        animationSpec = tween(durationMillis = if (animateActive) 1100 else 0),
        label = "tug01_y"
    )
    val tug02RenderX by animateFloatAsState(
        targetValue = tug02?.shipX ?: 355f,
        animationSpec = tween(durationMillis = if (animateActive) 1100 else 0),
        label = "tug02_x"
    )
    val tug02RenderY by animateFloatAsState(
        targetValue = tug02?.shipY ?: 212f,
        animationSpec = tween(durationMillis = if (animateActive) 1100 else 0),
        label = "tug02_y"
    )

    val pulsePhase = if (animateActive) {
        val infinite = rememberInfiniteTransition(label = "twin_pulse")
        val p by infinite.animateFloat(
            initialValue = 0f,
            targetValue = 1f,
            animationSpec = infiniteRepeatable(
                animation = tween(1600, easing = LinearEasing),
                repeatMode = RepeatMode.Reverse
            ),
            label = "pulse_phase"
        )
        p
    } else 0.5f

    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(8.dp),
        color = SeaWaterDeep,
        border = BorderStroke(1.2.dp, BrassGold),
        tonalElevation = 4.dp
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            // Top Controls Bar
            FlowRow(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(MidnightNavy)
                    .padding(horizontal = 10.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalArrangement = Arrangement.Center
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    DeckLevel.entries.forEach { deck ->
                        FilterChip(
                            selected = activeDeck == deck,
                            onClick = { onSelectDeck(deck) },
                            label = { Text(deck.label, fontSize = 11.sp) },
                            modifier = Modifier
                                .testTag("deck_tab_${deck.name.lowercase()}")
                                .minimumInteractiveComponentSize(),
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = BrassGold,
                                selectedLabelColor = MidnightAbyss,
                                containerColor = NavalSlate,
                                labelColor = WarmIvory
                            )
                        )
                    }
                    Spacer(Modifier.width(6.dp))
                    ViewProjectionMode.entries.forEach { mode ->
                        FilterChip(
                            selected = viewMode == mode,
                            onClick = { onSelectViewMode(mode) },
                            label = { Text(mode.label, fontSize = 11.sp) },
                            modifier = Modifier
                                .testTag("view_mode_${mode.name.lowercase()}")
                                .minimumInteractiveComponentSize(),
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = SelectionCyan,
                                selectedLabelColor = MidnightAbyss,
                                containerColor = NavalSlate,
                                labelColor = WarmIvory
                            )
                        )
                    }
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(2.dp)
                ) {
                    IconButton(
                        onClick = onToggleMotion,
                        modifier = Modifier.testTag("twin_motion_toggle")
                    ) {
                        Icon(
                            imageVector = if (animateActive) Icons.Default.MotionPhotosOn else Icons.Default.MotionPhotosOff,
                            contentDescription = if (animateActive) "Pause deck motion" else "Enable deck motion",
                            tint = if (animateActive) SelectionCyan else BrassGoldMuted
                        )
                    }
                    IconButton(
                        onClick = { onZoomBy(0.85f) },
                        modifier = Modifier.testTag("twin_zoom_out")
                    ) {
                        Icon(Icons.Default.ZoomOut, contentDescription = "Zoom out", tint = WarmIvory)
                    }
                    IconButton(
                        onClick = { onZoomBy(1.18f) },
                        modifier = Modifier.testTag("twin_zoom_in")
                    ) {
                        Icon(Icons.Default.ZoomIn, contentDescription = "Zoom in", tint = WarmIvory)
                    }
                    IconButton(
                        onClick = onCentreView,
                        modifier = Modifier.testTag("twin_centre")
                    ) {
                        Icon(Icons.Default.CenterFocusStrong, contentDescription = "Centre view", tint = WarmIvory)
                    }
                    IconButton(
                        onClick = onResetView,
                        modifier = Modifier.testTag("twin_reset")
                    ) {
                        Icon(Icons.Default.Refresh, contentDescription = "Reset viewport", tint = BrassGold)
                    }
                }
            }

            // Main Interactive Ship Canvas
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .clip(RoundedCornerShape(4.dp))
                    .onSizeChanged { canvasSize = it }
                    .pointerInput(activeDeck, viewMode, viewport, assets) {
                        detectTransformGestures { _, pan, zoom, _ ->
                            onViewportChange(
                                viewport.copy(
                                    zoom = (viewport.zoom * zoom).coerceIn(0.6f, 2.8f),
                                    panX = viewport.panX + pan.x,
                                    panY = viewport.panY + pan.y
                                )
                            )
                        }
                    }
                    .pointerInput(activeDeck, viewMode, viewport, assets) {
                        detectTapGestures { tapOffset ->
                            val hit = ShipCoordinateModel.hitTestAsset(
                                tapOffset = tapOffset,
                                activeDeck = activeDeck,
                                assets = assets,
                                viewMode = viewMode,
                                transform = viewport,
                                canvasWidth = canvasSize.width.toFloat(),
                                canvasHeight = canvasSize.height.toFloat()
                            )
                            onSelectAsset(hit?.id)
                        }
                    }
                    .testTag("ship_digital_twin_canvas")
                    .semantics {
                        contentDescription = "Interactive HMS Resolute ship digital twin on ${activeDeck.label} in ${viewMode.label} view"
                    }
            ) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    drawOceanGrid()

                    val activeZ = activeDeck.zElevation
                    fun p(x: Float, y: Float, z: Float = activeZ): Offset =
                        ShipCoordinateModel.project(x, y, z, viewMode, viewport, size.width, size.height)

                    when (activeDeck) {
                        DeckLevel.FLIGHT_DECK -> drawFlightDeckHullAndIslands(::p, viewMode, textMeasurer)
                        DeckLevel.HANGAR -> drawHangarDeck(::p, viewMode, textMeasurer)
                        DeckLevel.SYSTEMS -> drawSystemsDeck(::p, assets, textMeasurer)
                    }

                    // Render deck assets with interpolated positions for moving service tugs
                    val visibleAssets = assets.filter { it.deckLevel == activeDeck }
                    visibleAssets.forEach { asset ->
                        val renderX = when (asset.id) {
                            "TUG-01" -> tug01RenderX
                            "TUG-02" -> tug02RenderX
                            else -> asset.shipX
                        }
                        val renderY = when (asset.id) {
                            "TUG-01" -> tug01RenderY
                            "TUG-02" -> tug02RenderY
                            else -> asset.shipY
                        }
                        drawAssetSymbol(
                            asset = asset,
                            renderX = renderX,
                            renderY = renderY,
                            activeZ = activeZ,
                            isSelected = asset.id == selectedAssetId,
                            pulsePhase = pulsePhase,
                            project = ::p,
                            textMeasurer = textMeasurer
                        )
                    }
                }

                // Overlay Quick-Select Pills for accessibility & deterministic selection on crowded/small screens
                Row(
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        .padding(8.dp)
                        .background(MidnightNavy.copy(alpha = 0.85f), RoundedCornerShape(4.dp))
                        .border(0.8.dp, BrassGoldMuted, RoundedCornerShape(4.dp))
                        .padding(horizontal = 8.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "${activeDeck.label.uppercase()} • ${viewMode.label.uppercase()} • ${"%.0f".format(viewport.zoom * 100)}%",
                        fontFamily = JetBrainsMonoFontFamily,
                        fontSize = 10.sp,
                        color = BrassGold
                    )
                }

                // Quick Accessible Asset Strip at top-right for 1-tap keyboard/a11y selection
                Row(
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(8.dp),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    assets.filter { it.deckLevel == activeDeck }
                        .take(5)
                        .forEach { asset ->
                            val selected = asset.id == selectedAssetId
                            Surface(
                                shape = RoundedCornerShape(4.dp),
                                color = if (selected) SelectionCyan else MidnightNavy.copy(alpha = 0.88f),
                                border = BorderStroke(
                                    1.dp,
                                    if (selected) SelectionCyan else statusColor(asset.operationalStatus)
                                ),
                                modifier = Modifier
                                    .testTag("quick_asset_${asset.id}")
                                    .clickable { onSelectAsset(asset.id) }
                            ) {
                                Text(
                                    text = asset.id,
                                    fontFamily = JetBrainsMonoFontFamily,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (selected) MidnightAbyss else WarmIvory,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 4.dp)
                                )
                            }
                        }
                }
            }

            // Simplified Interactive Side Elevation Strip
            SideElevationProfileStrip(
                activeDeck = activeDeck,
                onSelectDeck = onSelectDeck
            )
        }
    }
}

@Composable
private fun SideElevationProfileStrip(
    activeDeck: DeckLevel,
    onSelectDeck: (DeckLevel) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(52.dp)
            .background(MidnightNavy)
            .border(0.8.dp, NavalBorderMuted)
            .padding(horizontal = 10.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = "ELEVATION",
            fontFamily = JetBrainsMonoFontFamily,
            fontSize = 10.sp,
            color = BrassGold,
            fontWeight = FontWeight.Bold
        )
        Spacer(Modifier.width(10.dp))
        Canvas(
            modifier = Modifier
                .weight(1f)
                .height(40.dp)
                .clickable {
                    val next = when (activeDeck) {
                        DeckLevel.FLIGHT_DECK -> DeckLevel.HANGAR
                        DeckLevel.HANGAR -> DeckLevel.SYSTEMS
                        DeckLevel.SYSTEMS -> DeckLevel.FLIGHT_DECK
                    }
                    onSelectDeck(next)
                }
        ) {
            val w = size.width
            val h = size.height
            // Hull keel & bow ski-jump profile
            val hull = Path().apply {
                moveTo(w * 0.05f, h * 0.42f)
                lineTo(w * 0.88f, h * 0.42f)
                lineTo(w * 0.96f, h * 0.28f) // ski jump bow
                lineTo(w * 0.93f, h * 0.88f)
                lineTo(w * 0.07f, h * 0.88f)
                close()
            }
            drawPath(hull, color = HullArmorDark)
            drawPath(hull, color = BrassGoldMuted, style = Stroke(1.2f))

            // Twin Islands silhouette on flight deck
            drawRect(
                color = IslandStructure,
                topLeft = Offset(w * 0.38f, h * 0.14f),
                size = Size(w * 0.06f, h * 0.28f)
            )
            drawRect(
                color = IslandStructure,
                topLeft = Offset(w * 0.60f, h * 0.12f),
                size = Size(w * 0.07f, h * 0.30f)
            )

            // Active deck highlight band
            val bandTop = when (activeDeck) {
                DeckLevel.FLIGHT_DECK -> h * 0.37f
                DeckLevel.HANGAR -> h * 0.54f
                DeckLevel.SYSTEMS -> h * 0.71f
            }
            drawRect(
                color = SelectionCyan.copy(alpha = 0.38f),
                topLeft = Offset(w * 0.08f, bandTop),
                size = Size(w * 0.82f, h * 0.15f)
            )
            drawLine(
                color = SelectionCyan,
                start = Offset(w * 0.08f, bandTop),
                end = Offset(w * 0.90f, bandTop),
                strokeWidth = 2f
            )
        }
        Spacer(Modifier.width(10.dp))
        Text(
            text = "ACTIVE: ${activeDeck.label.uppercase()}",
            fontFamily = JetBrainsMonoFontFamily,
            fontSize = 10.sp,
            color = SelectionCyan
        )
    }
}

private fun DrawScope.drawOceanGrid() {
    val step = 48f
    var x = 0f
    while (x < size.width) {
        drawLine(SeaGridLine, Offset(x, 0f), Offset(x, size.height), strokeWidth = 1f)
        x += step
    }
    var y = 0f
    while (y < size.height) {
        drawLine(SeaGridLine, Offset(0f, y), Offset(size.width, y), strokeWidth = 1f)
        y += step
    }
}

private fun DrawScope.drawFlightDeckHullAndIslands(
    p: (Float, Float, Float) -> Offset,
    viewMode: ViewProjectionMode,
    textMeasurer: TextMeasurer
) {
    val zDeck = DeckLevel.FLIGHT_DECK.zElevation
    val zKeel = 25f

    // Isometric lower hull extrusion when in ISOMETRIC mode
    if (viewMode == ViewProjectionMode.ISOMETRIC) {
        val hullSkirt = Path().apply {
            val s0 = p(45f, 65f, zDeck)
            val s1 = p(45f, 275f, zDeck)
            val s2 = p(940f, 235f, zDeck)
            val s3 = p(990f, 175f, zDeck)
            val b3 = p(990f, 175f, zKeel)
            val b2 = p(940f, 235f, zKeel)
            val b1 = p(45f, 275f, zKeel)
            val b0 = p(45f, 65f, zKeel)
            moveTo(s0.x, s0.y)
            lineTo(s1.x, s1.y)
            lineTo(s2.x, s2.y)
            lineTo(s3.x, s3.y)
            lineTo(b3.x, b3.y)
            lineTo(b2.x, b2.y)
            lineTo(b1.x, b1.y)
            lineTo(b0.x, b0.y)
            close()
        }
        drawPath(hullSkirt, color = HullArmorDark)
        drawPath(hullSkirt, color = BrassGoldMuted, style = Stroke(1.2f))
    }

    // Carrier Flight Deck Silhouette (stern transom, port angled sponson, ski-jump bow, stbd lift sponsons)
    val deckOutline = listOf(
        45f to 85f,
        180f to 62f,
        660f to 42f,
        830f to 80f,
        985f to 132f, // Ski jump port bow
        985f to 206f, // Ski jump stbd bow
        760f to 245f,
        640f to 292f, // Fwd lift sponson
        520f to 292f,
        490f to 275f,
        390f to 275f,
        380f to 294f, // Aft lift sponson
        290f to 294f,
        245f to 268f,
        45f to 255f
    )
    val deckPath = Path().apply {
        val first = p(deckOutline.first().first, deckOutline.first().second, zDeck)
        moveTo(first.x, first.y)
        deckOutline.drop(1).forEach { (sx, sy) ->
            val pt = p(sx, sy, zDeck)
            lineTo(pt.x, pt.y)
        }
        close()
    }
    drawPath(deckPath, color = FlightDeckAsphalt)
    drawPath(deckPath, color = BrassGold, style = Stroke(2.2f, join = StrokeJoin.Round))

    // Ski-jump ramp highlight lines
    val rampStart = p(880f, 145f, zDeck)
    val rampEnd = p(980f, 168f, zDeck)
    drawLine(BrassGold, p(880f, 134f, zDeck), p(980f, 136f, zDeck), strokeWidth = 2f)
    drawLine(BrassGold, p(880f, 200f, zDeck), p(980f, 202f, zDeck), strokeWidth = 2f)
    drawLine(DeckMarkingIvory.copy(alpha = 0.7f), rampStart, rampEnd, strokeWidth = 2.4f, pathEffect = PathEffect.dashPathEffect(floatArrayOf(14f, 10f)))

    // Main Runway Centreline & Foul Lines
    drawLine(
        color = DeckMarkingIvory.copy(alpha = 0.75f),
        start = p(85f, 145f, zDeck),
        end = p(880f, 168f, zDeck),
        strokeWidth = 2.4f,
        pathEffect = PathEffect.dashPathEffect(floatArrayOf(18f, 12f))
    )
    drawLine(
        color = FoulLineAmber.copy(alpha = 0.8f),
        start = p(110f, 196f, zDeck),
        end = p(860f, 210f, zDeck),
        strokeWidth = 1.6f,
        pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 8f))
    )

    // Twin Island Structures (Admiral-Class signature)
    drawIslandBox(p, 625f, 245f, 685f, 286f, zDeck, zDeck + 32f, "FWD ISLAND", textMeasurer)
    drawIslandBox(p, 405f, 248f, 465f, 286f, zDeck, zDeck + 28f, "AFT ISLAND", textMeasurer)
}

private fun DrawScope.drawIslandBox(
    p: (Float, Float, Float) -> Offset,
    x1: Float,
    y1: Float,
    x2: Float,
    y2: Float,
    zBase: Float,
    zTop: Float,
    label: String,
    textMeasurer: TextMeasurer
) {
    val wall = Path().apply {
        val b0 = p(x1, y1, zBase)
        val b1 = p(x1, y2, zBase)
        val b2 = p(x2, y2, zBase)
        val t2 = p(x2, y2, zTop)
        val t1 = p(x1, y2, zTop)
        val t0 = p(x1, y1, zTop)
        moveTo(b0.x, b0.y)
        lineTo(b1.x, b1.y)
        lineTo(b2.x, b2.y)
        lineTo(t2.x, t2.y)
        lineTo(t1.x, t1.y)
        lineTo(t0.x, t0.y)
        close()
    }
    drawPath(wall, color = HullArmorDark)

    val roof = Path().apply {
        val t0 = p(x1, y1, zTop)
        val t1 = p(x1, y2, zTop)
        val t2 = p(x2, y2, zTop)
        val t3 = p(x2, y1, zTop)
        moveTo(t0.x, t0.y)
        lineTo(t1.x, t1.y)
        lineTo(t2.x, t2.y)
        lineTo(t3.x, t3.y)
        close()
    }
    drawPath(roof, color = IslandStructure)
    drawPath(roof, color = BrassGold, style = Stroke(1.6f))

    val center = p((x1 + x2) * 0.5f, (y1 + y2) * 0.5f, zTop)
    val measured = textMeasurer.measure(
        label,
        TextStyle(color = WarmIvory, fontSize = 8.sp, fontFamily = JetBrainsMonoFontFamily, fontWeight = FontWeight.Bold)
    )
    drawText(measured, topLeft = Offset(center.x - measured.size.width / 2f, center.y - measured.size.height / 2f))
}

private fun DrawScope.drawHangarDeck(
    p: (Float, Float, Float) -> Offset,
    @Suppress("UNUSED_PARAMETER") viewMode: ViewProjectionMode,
    textMeasurer: TextMeasurer
) {
    val z = DeckLevel.HANGAR.zElevation
    val hangarBox = Path().apply {
        val c0 = p(160f, 95f, z)
        val c1 = p(820f, 95f, z)
        val c2 = p(820f, 250f, z)
        val c3 = p(160f, 250f, z)
        moveTo(c0.x, c0.y)
        lineTo(c1.x, c1.y)
        lineTo(c2.x, c2.y)
        lineTo(c3.x, c3.y)
        close()
    }
    drawPath(hangarBox, color = HangarDeckSteel)
    drawPath(hangarBox, color = BrassGold, style = Stroke(2f))

    // Fire curtain bulkhead divisions (Bay 1A, Bay 2B, Bay 3C)
    listOf(380f, 580f).forEach { divX ->
        drawLine(
            color = FoulLineAmber,
            start = p(divX, 95f, z),
            end = p(divX, 250f, z),
            strokeWidth = 2f,
            pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 6f))
        )
    }

    listOf(270f to "HANGAR BAY 3C", 480f to "HANGAR BAY 2B", 700f to "HANGAR BAY 1A").forEach { (bx, name) ->
        val pt = p(bx, 115f, z)
        val measured = textMeasurer.measure(
            name,
            TextStyle(color = BrassGold, fontSize = 9.sp, fontFamily = JetBrainsMonoFontFamily)
        )
        drawText(measured, topLeft = Offset(pt.x - measured.size.width / 2f, pt.y))
    }
}

private fun DrawScope.drawSystemsDeck(
    p: (Float, Float, Float) -> Offset,
    assets: List<CarrierAsset>,
    textMeasurer: TextMeasurer
) {
    val z = DeckLevel.SYSTEMS.zElevation
    val hullBox = Path().apply {
        val c0 = p(120f, 75f, z)
        val c1 = p(870f, 90f, z)
        val c2 = p(870f, 250f, z)
        val c3 = p(120f, 265f, z)
        moveTo(c0.x, c0.y)
        lineTo(c1.x, c1.y)
        lineTo(c2.x, c2.y)
        lineTo(c3.x, c3.y)
        close()
    }
    drawPath(hullBox, color = SystemsDeckPlate)
    drawPath(hullBox, color = BrassGoldMuted, style = Stroke(2f))

    // High-voltage distribution spine connecting engineering compartments
    val hvBus = assets.find { it.id == "HV-BUS-B" }
    val busColor = statusColor(hvBus?.operationalStatus ?: OperationalStatus.READY)
    drawLine(busColor, p(260f, 170f, z), p(740f, 170f, z), strokeWidth = 3f)
    drawLine(SelectionCyan.copy(alpha = 0.5f), p(290f, 145f, z), p(610f, 135f, z), strokeWidth = 1.6f)
    drawLine(SelectionCyan.copy(alpha = 0.5f), p(390f, 205f, z), p(520f, 115f, z), strokeWidth = 1.6f)

    val titlePos = p(500f, 92f, z)
    val measured = textMeasurer.measure(
        "11kV RING BUS & PROPULSION READ-ONLY SCHEMATIC",
        TextStyle(color = BrassGold, fontSize = 9.sp, fontFamily = JetBrainsMonoFontFamily)
    )
    drawText(measured, topLeft = Offset(titlePos.x - measured.size.width / 2f, titlePos.y))
}

private fun DrawScope.drawAssetSymbol(
    asset: CarrierAsset,
    renderX: Float,
    renderY: Float,
    activeZ: Float,
    isSelected: Boolean,
    pulsePhase: Float,
    project: (Float, Float, Float) -> Offset,
    textMeasurer: TextMeasurer
) {
    val center = project(renderX, renderY, activeZ)
    val sColor = statusColor(asset.operationalStatus)

    // Selection cyan halo
    if (isSelected) {
        val radius = 25f + pulsePhase * 6f
        drawCircle(
            color = SelectionCyan.copy(alpha = 0.20f),
            radius = radius,
            center = center
        )
        drawCircle(
            color = SelectionCyan,
            radius = radius,
            center = center,
            style = Stroke(width = 2.6f)
        )
    }

    when (asset.category) {
        AssetCategory.AIRCRAFT -> {
            // Swept-wing F-35B fighter silhouette rotated by headingDeg
            val rad = Math.toRadians(asset.headingDeg.toDouble())
            val cosA = cos(rad).toFloat()
            val sinA = sin(rad).toFloat()
            fun rot(lx: Float, ly: Float): Offset =
                Offset(center.x + lx * cosA - ly * sinA, center.y + lx * sinA + ly * cosA)

            val jetPath = Path().apply {
                val nose = rot(17f, 0f)
                val rWing = rot(-4f, 14f)
                val rTail = rot(-14f, 8f)
                val tail = rot(-11f, 0f)
                val lTail = rot(-14f, -8f)
                val lWing = rot(-4f, -14f)
                moveTo(nose.x, nose.y)
                lineTo(rWing.x, rWing.y)
                lineTo(rTail.x, rTail.y)
                lineTo(tail.x, tail.y)
                lineTo(lTail.x, lTail.y)
                lineTo(lWing.x, lWing.y)
                close()
            }
            drawPath(jetPath, color = sColor.copy(alpha = 0.28f))
            drawPath(jetPath, color = if (isSelected) SelectionCyan else sColor, style = Stroke(2.2f, join = StrokeJoin.Round))

            // Animated maintenance progress arc around aircraft in maintenance/inspection
            if (asset.maintenanceProgressPct < 100) {
                drawArc(
                    color = StatusCautionAmber,
                    startAngle = -90f,
                    sweepAngle = 360f * (asset.maintenanceProgressPct / 100f),
                    useCenter = false,
                    topLeft = Offset(center.x - 20f, center.y - 20f),
                    size = Size(40f, 40f),
                    style = Stroke(width = 2.6f, cap = StrokeCap.Round)
                )
            }
        }
        AssetCategory.HELICOPTER -> {
            drawCircle(sColor.copy(alpha = 0.25f), radius = 14f, center = center)
            drawCircle(if (isSelected) SelectionCyan else sColor, radius = 14f, center = center, style = Stroke(2f))
            // Rotor blades
            drawLine(WarmIvory, Offset(center.x - 14f, center.y - 8f), Offset(center.x + 14f, center.y + 8f), 1.8f)
            drawLine(WarmIvory, Offset(center.x - 14f, center.y + 8f), Offset(center.x + 14f, center.y - 8f), 1.8f)
        }
        AssetCategory.SERVICE_VEHICLE -> {
            drawRect(
                color = sColor.copy(alpha = 0.35f),
                topLeft = Offset(center.x - 11f, center.y - 8f),
                size = Size(22f, 16f)
            )
            drawRect(
                color = if (isSelected) SelectionCyan else sColor,
                topLeft = Offset(center.x - 11f, center.y - 8f),
                size = Size(22f, 16f),
                style = Stroke(2f)
            )
        }
        AssetCategory.AIRCRAFT_LIFT -> {
            drawRect(
                color = sColor.copy(alpha = 0.26f),
                topLeft = Offset(center.x - 20f, center.y - 12f),
                size = Size(40f, 24f)
            )
            drawRect(
                color = if (isSelected) SelectionCyan else sColor,
                topLeft = Offset(center.x - 20f, center.y - 12f),
                size = Size(40f, 24f),
                style = Stroke(2.2f)
            )
            if (asset.operationalStatus == OperationalStatus.UNAVAILABLE) {
                drawLine(StatusFaultRed, Offset(center.x - 16f, center.y - 9f), Offset(center.x + 16f, center.y + 9f), 2.5f)
                drawLine(StatusFaultRed, Offset(center.x + 16f, center.y - 9f), Offset(center.x - 16f, center.y + 9f), 2.5f)
            }
        }
        AssetCategory.MAINTENANCE_ZONE -> {
            drawCircle(
                color = sColor.copy(alpha = 0.65f),
                radius = 18f,
                center = center,
                style = Stroke(width = 1.8f, pathEffect = PathEffect.dashPathEffect(floatArrayOf(6f, 4f)))
            )
        }
        AssetCategory.ENGINEERING_SYSTEM -> {
            drawRect(
                color = sColor.copy(alpha = 0.24f),
                topLeft = Offset(center.x - 22f, center.y - 14f),
                size = Size(44f, 28f)
            )
            drawRect(
                color = if (isSelected) SelectionCyan else sColor,
                topLeft = Offset(center.x - 22f, center.y - 14f),
                size = Size(44f, 28f),
                style = Stroke(2.2f)
            )
        }
    }

    // Asset Callsign Badge
    val labelText = if (asset.operationalStatus == OperationalStatus.STALE) "${asset.id} [STALE]" else asset.id
    val labelMeasured = textMeasurer.measure(
        labelText,
        TextStyle(
            color = if (isSelected) SelectionCyan else WarmIvory,
            fontSize = 9.sp,
            fontFamily = JetBrainsMonoFontFamily,
            fontWeight = FontWeight.Bold
        )
    )
    drawRect(
        color = MidnightAbyss.copy(alpha = 0.78f),
        topLeft = Offset(center.x - labelMeasured.size.width / 2f - 3f, center.y + 15f),
        size = Size(labelMeasured.size.width + 6f, labelMeasured.size.height + 2f)
    )
    drawText(
        labelMeasured,
        topLeft = Offset(center.x - labelMeasured.size.width / 2f, center.y + 16f)
    )
}

fun statusColor(status: OperationalStatus): Color = when (status) {
    OperationalStatus.READY -> StatusReadyGreen
    OperationalStatus.INSPECTION, OperationalStatus.MAINTENANCE, OperationalStatus.CAUTION -> StatusCautionAmber
    OperationalStatus.UNAVAILABLE -> StatusFaultRed
    OperationalStatus.STALE -> StatusStaleSlate
}
