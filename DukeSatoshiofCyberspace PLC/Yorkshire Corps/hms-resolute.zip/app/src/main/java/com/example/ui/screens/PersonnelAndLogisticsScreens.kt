package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.ResoluteUiState
import com.example.ui.components.IvoryCommandCard
import com.example.ui.components.MonoMetricRow
import com.example.ui.components.NavalDarkPanel
import com.example.ui.theme.BrassGold
import com.example.ui.theme.InkMuted
import com.example.ui.theme.InkNavy
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.MidnightNavy
import com.example.ui.theme.StatusCautionAmber
import com.example.ui.theme.StatusReadyGreen
import com.example.ui.theme.WarmIvory
import com.example.ui.theme.WarmIvoryAlt

@Composable
fun PersonnelScreen(
    state: ResoluteUiState,
    onRecordHandover: (String, String, String, String, String, String?) -> Unit,
    onAcknowledgeHandover: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    var outgoingTeam by remember { mutableStateOf("ALPHA WATCH") }
    var incomingTeam by remember { mutableStateOf("BRAVO WATCH") }
    var outstandingTasks by remember { mutableStateOf("AC-04 inspection (WO-404) reviewed & availability updated; WO-412 Merlin oil sample under review.") }
    var equipmentIssues by remember { mutableStateOf("Monitor aft lift interlock telemetry; all main turbines nominal.") }
    var logisticsNotes by remember { mutableStateOf("F-44 at 76.7% measured; REQ-901 seal kit processed.") }

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        IvoryCommandCard(
            title = "Department Personnel Aggregates",
            subtitle = if (state.activeRole.canViewIndividualPersonnel) {
                "Scoped individual watch roster visible to ${state.activeRole.displayName}"
            } else {
                "Individual PII redacted for role '${state.activeRole.displayName}' — aggregates only"
            }
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                state.personnelDepartments.forEach { dept ->
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = WarmIvory,
                        border = BorderStroke(1.dp, BrassGold.copy(alpha = 0.6f))
                    ) {
                        Column(modifier = Modifier.fillMaxWidth().padding(10.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("${dept.departmentCode} — ${dept.departmentName}", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                Text(
                                    "${dept.totalAssigned} total",
                                    fontFamily = JetBrainsMonoFontFamily,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp
                                )
                            }
                            MonoMetricRow("On Watch / Off Watch / Leave", "${dept.onWatch} / ${dept.offWatch} / ${dept.medicalOrLeave}")
                            if (state.activeRole.canViewIndividualPersonnel) {
                                Text(
                                    text = "Key Watch Leads: ${dept.restrictedRosterSample.joinToString()}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = InkMuted
                                )
                            } else {
                                Text(
                                    text = "Individual roster names restricted (Supervisor/Admin permission required)",
                                    fontFamily = JetBrainsMonoFontFamily,
                                    fontSize = 10.sp,
                                    color = StatusCautionAmber
                                )
                            }
                        }
                    }
                }
            }
        }

        IvoryCommandCard(
            title = "Record Watch Shift Handover (Versioned)",
            subtitle = "Corrections or new handovers preserve all earlier versions"
        ) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = outgoingTeam,
                    onValueChange = { outgoingTeam = it },
                    label = { Text("Outgoing Watch") },
                    modifier = Modifier.weight(1f).testTag("handover_outgoing_input")
                )
                OutlinedTextField(
                    value = incomingTeam,
                    onValueChange = { incomingTeam = it },
                    label = { Text("Incoming Watch") },
                    modifier = Modifier.weight(1f).testTag("handover_incoming_input")
                )
            }
            Spacer(Modifier.height(6.dp))
            OutlinedTextField(
                value = outstandingTasks,
                onValueChange = { outstandingTasks = it },
                label = { Text("Outstanding Tasks") },
                modifier = Modifier.fillMaxWidth().testTag("handover_tasks_input")
            )
            Spacer(Modifier.height(6.dp))
            OutlinedTextField(
                value = equipmentIssues,
                onValueChange = { equipmentIssues = it },
                label = { Text("Equipment Issues") },
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(6.dp))
            OutlinedTextField(
                value = logisticsNotes,
                onValueChange = { logisticsNotes = it },
                label = { Text("Logistics Notes") },
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(8.dp))
            Button(
                onClick = {
                    val latestId = state.handovers.firstOrNull { it.isLatest }?.handoverId
                    onRecordHandover(outgoingTeam, incomingTeam, outstandingTasks, equipmentIssues, logisticsNotes, latestId)
                },
                modifier = Modifier.testTag("record_handover_btn"),
                colors = ButtonDefaults.buttonColors(containerColor = MidnightNavy, contentColor = BrassGold)
            ) {
                Text("Record Shift Handover (Preserve Prior Versions)")
            }
        }

        IvoryCommandCard(
            title = "Handover Version History (${state.handovers.size} versions)",
            subtitle = "Immutable audit lineage"
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                state.handovers.forEach { ho ->
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = if (ho.isLatest) WarmIvory else WarmIvoryAlt,
                        border = BorderStroke(if (ho.isLatest) 1.5.dp else 0.8.dp, BrassGold),
                        modifier = Modifier.testTag("handover_card_v${ho.versionNumber}")
                    ) {
                        Column(modifier = Modifier.fillMaxWidth().padding(10.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "${ho.handoverId} (v${ho.versionNumber}) • ${ho.outgoingTeam} → ${ho.incomingTeam}",
                                    fontFamily = JetBrainsMonoFontFamily,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp
                                )
                                Text(
                                    text = if (ho.isLatest) "LATEST" else "SUPERSEDED",
                                    fontFamily = JetBrainsMonoFontFamily,
                                    fontSize = 10.sp,
                                    color = if (ho.isLatest) StatusReadyGreen else InkMuted,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            if (ho.supersedesHandoverId != null) {
                                Text("Supersedes: ${ho.supersedesHandoverId}", fontFamily = JetBrainsMonoFontFamily, fontSize = 10.sp, color = InkMuted)
                            }
                            Text("Tasks: ${ho.outstandingTasksSummary}", style = MaterialTheme.typography.bodySmall)
                            Text("Equipment: ${ho.equipmentIssuesSummary}", style = MaterialTheme.typography.bodySmall)
                            Text("Logistics: ${ho.logisticsNotes}", style = MaterialTheme.typography.bodySmall)
                            Text(
                                text = "Created: ${ho.createdBy} @ ${ho.createdUtc} • Ack: ${ho.acknowledgedBy ?: "PENDING"}",
                                fontFamily = JetBrainsMonoFontFamily,
                                fontSize = 10.sp,
                                color = InkMuted
                            )
                            if (ho.acknowledgedBy == null) {
                                Spacer(Modifier.height(4.dp))
                                OutlinedButton(onClick = { onAcknowledgeHandover(ho.handoverId) }) {
                                    Text("Acknowledge Handover", fontSize = 11.sp, color = InkNavy)
                                }
                            }
                        }
                    }
                }
            }
        }

        NavalDarkPanel(title = "Full Command Event Log (${state.auditEvents.size} events)") {
            state.auditEvents.take(20).forEach { ev ->
                Text(
                    text = "[SIM ${ev.simTimeUtc} | DEV ${ev.deviceTimeUtc}] ${ev.actionType} (${ev.outcome}) ${ev.actorName}: ${ev.summary}",
                    fontFamily = JetBrainsMonoFontFamily,
                    fontSize = 10.sp,
                    color = WarmIvory,
                    modifier = Modifier.padding(vertical = 2.dp)
                )
            }
        }
    }
}

@Composable
fun LogisticsScreen(
    state: ResoluteUiState,
    onApproveStores: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val tankMetrics = state.telemetry.filter { it.category == "LOGISTICS" }.distinctBy { it.metricKey }

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        IvoryCommandCard(
            title = "Fuel, Fresh Water & Stores Inventories",
            subtitle = "Measured quantities explicitly separated from estimates"
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                tankMetrics.forEach { obs ->
                    val max = obs.capacityMax ?: 100.0
                    val value = obs.value ?: 0.0
                    val pct = ((value / max) * 100.0).coerceIn(0.0, 100.0)
                    Column {
                        MonoMetricRow(
                            label = "${obs.label} (${if (obs.isMeasured) "MEASURED" else "ESTIMATED"})",
                            value = "${"%.1f".format(value)} / ${"%.0f".format(max)} ${obs.unit} (${"%.1f".format(pct)}%)"
                        )
                        Spacer(Modifier.height(3.dp))
                        LinearProgressIndicator(
                            progress = { (pct / 100.0).toFloat() },
                            modifier = Modifier.fillMaxWidth().height(8.dp),
                            color = if (obs.isMeasured) StatusReadyGreen else StatusCautionAmber,
                            trackColor = WarmIvoryAlt
                        )
                        Text(
                            text = "Uncertainty: ${obs.uncertainty} • Source: ${obs.sourceId} @ ${obs.timestampUtc}",
                            fontFamily = JetBrainsMonoFontFamily,
                            fontSize = 10.sp,
                            color = InkMuted
                        )
                    }
                }
            }
        }

        IvoryCommandCard(
            title = "Stores Requests, Replenishments & Inventory Movements",
            subtitle = "Administrative approvals recorded to audit log"
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                state.logistics.forEach { rec ->
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = WarmIvory,
                        border = BorderStroke(1.dp, BrassGold.copy(alpha = 0.65f))
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "${rec.id} [${rec.kind}] • ${rec.itemCode}",
                                    fontFamily = JetBrainsMonoFontFamily,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 11.sp
                                )
                                Text(rec.description, style = MaterialTheme.typography.bodyMedium)
                                Text(
                                    text = "Qty: ${rec.quantity} ${rec.unit} (${if (rec.isMeasured) "Measured" else "Estimated"}) • Status: ${rec.status}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = InkMuted
                                )
                                Text(
                                    text = "Req: ${rec.requestedBy} • Approved: ${rec.approvedBy ?: "Pending"} @ ${rec.timestampUtc}",
                                    fontFamily = JetBrainsMonoFontFamily,
                                    fontSize = 10.sp,
                                    color = InkMuted
                                )
                            }
                            if (rec.status == "PENDING_APPROVAL") {
                                Button(
                                    onClick = { onApproveStores(rec.id) },
                                    modifier = Modifier.testTag("approve_stores_${rec.id}"),
                                    colors = ButtonDefaults.buttonColors(containerColor = MidnightNavy, contentColor = BrassGold)
                                ) {
                                    Text("Approve", fontSize = 11.sp)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
