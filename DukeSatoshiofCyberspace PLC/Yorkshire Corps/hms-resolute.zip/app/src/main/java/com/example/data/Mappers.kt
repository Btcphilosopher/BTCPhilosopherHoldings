package com.example.data

import com.example.assets.AssetCategory
import com.example.assets.AuditLogEntry
import com.example.assets.CarrierAsset
import com.example.assets.DeckLevel
import com.example.assets.LogisticsRecord
import com.example.assets.OperationalStatus
import com.example.assets.PendingSyncItem
import com.example.assets.ShiftHandoverRecord
import com.example.assets.TaskPriority
import com.example.assets.TelemetryObservation
import com.example.assets.TelemetryQuality
import com.example.assets.WorkOrder
import com.example.assets.WorkOrderReviewEntry
import com.example.assets.WorkOrderStatus
import com.example.data.local.AssetEntity
import com.example.data.local.AuditEventEntity
import com.example.data.local.LogisticsRecordEntity
import com.example.data.local.PendingSyncMutationEntity
import com.example.data.local.ShiftHandoverEntity
import com.example.data.local.TelemetryObservationEntity
import com.example.data.local.WorkOrderEntity
import org.json.JSONArray
import org.json.JSONObject

fun AssetEntity.toDomain(): CarrierAsset = CarrierAsset(
    id = id,
    callsign = callsign,
    assetType = assetType,
    category = enumValueOfOrDefault(category, AssetCategory.AIRCRAFT),
    deckLevel = enumValueOfOrDefault(deckLevel, DeckLevel.FLIGHT_DECK),
    shipX = shipX,
    shipY = shipY,
    headingDeg = headingDeg,
    locationLabel = locationLabel,
    maintenanceState = maintenanceState,
    operationalStatus = enumValueOfOrDefault(operationalStatus, OperationalStatus.READY),
    flightAuthorisationSeparateNote = flightAuthorisationSeparateNote,
    assignedTeam = assignedTeam,
    lastUpdateUtc = lastUpdateUtc,
    telemetryAgeSec = telemetryAgeSec,
    telemetryQuality = enumValueOfOrDefault(telemetryQuality, TelemetryQuality.LIVE),
    dataSource = dataSource,
    maintenanceProgressPct = maintenanceProgressPct,
    simulatedPathIndex = simulatedPathIndex,
    isSimulatedRelocation = isSimulatedRelocation
)

fun CarrierAsset.toEntity(): AssetEntity = AssetEntity(
    id = id,
    callsign = callsign,
    assetType = assetType,
    category = category.name,
    deckLevel = deckLevel.name,
    shipX = shipX,
    shipY = shipY,
    headingDeg = headingDeg,
    locationLabel = locationLabel,
    maintenanceState = maintenanceState,
    operationalStatus = operationalStatus.name,
    flightAuthorisationSeparateNote = flightAuthorisationSeparateNote,
    assignedTeam = assignedTeam,
    lastUpdateUtc = lastUpdateUtc,
    telemetryAgeSec = telemetryAgeSec,
    telemetryQuality = telemetryQuality.name,
    dataSource = dataSource,
    maintenanceProgressPct = maintenanceProgressPct,
    simulatedPathIndex = simulatedPathIndex,
    isSimulatedRelocation = isSimulatedRelocation
)

fun WorkOrderEntity.toDomain(): WorkOrder = WorkOrder(
    taskId = taskId,
    assetId = assetId,
    zoneLabel = zoneLabel,
    title = title,
    description = description,
    priority = enumValueOfOrDefault(priority, TaskPriority.ROUTINE),
    assignedTeam = assignedTeam,
    dueTimeUtc = dueTimeUtc,
    dependencies = dependenciesCsv.split("|").filter { it.isNotBlank() },
    status = enumValueOfOrDefault(status, WorkOrderStatus.DRAFT),
    checklistItems = checklistLines.split("\n").filter { it.isNotBlank() },
    completedChecklistCount = completedChecklistCount,
    completionEvidence = completionEvidence,
    notes = notes,
    attachments = attachmentsCsv.split("|").filter { it.isNotBlank() },
    reviewHistory = parseReviewHistory(reviewHistoryJson),
    version = version,
    lastChangedBy = lastChangedBy,
    lastChangedUtc = lastChangedUtc,
    dirtyPendingSync = dirtyPendingSync
)

fun WorkOrder.toEntity(): WorkOrderEntity = WorkOrderEntity(
    taskId = taskId,
    assetId = assetId,
    zoneLabel = zoneLabel,
    title = title,
    description = description,
    priority = priority.name,
    assignedTeam = assignedTeam,
    dueTimeUtc = dueTimeUtc,
    dependenciesCsv = dependencies.joinToString("|"),
    status = status.name,
    checklistLines = checklistItems.joinToString("\n"),
    completedChecklistCount = completedChecklistCount,
    completionEvidence = completionEvidence,
    notes = notes,
    attachmentsCsv = attachments.joinToString("|"),
    reviewHistoryJson = serializeReviewHistory(reviewHistory),
    version = version,
    lastChangedBy = lastChangedBy,
    lastChangedUtc = lastChangedUtc,
    dirtyPendingSync = dirtyPendingSync
)

fun TelemetryObservationEntity.toDomain(): TelemetryObservation = TelemetryObservation(
    id = id,
    category = category,
    metricKey = metricKey,
    label = label,
    value = value,
    unit = unit,
    isMeasured = isMeasured,
    capacityMax = capacityMax,
    uncertainty = uncertainty,
    sourceId = sourceId,
    timestampUtc = timestampUtc,
    ageSeconds = ageSeconds,
    quality = enumValueOfOrDefault(quality, TelemetryQuality.LIVE)
)

fun TelemetryObservation.toEntity(): TelemetryObservationEntity = TelemetryObservationEntity(
    id = id,
    category = category,
    metricKey = metricKey,
    label = label,
    value = value,
    unit = unit,
    isMeasured = isMeasured,
    capacityMax = capacityMax,
    uncertainty = uncertainty,
    sourceId = sourceId,
    timestampUtc = timestampUtc,
    ageSeconds = ageSeconds,
    quality = quality.name
)

fun ShiftHandoverEntity.toDomain(): ShiftHandoverRecord = ShiftHandoverRecord(
    handoverId = handoverId,
    versionNumber = versionNumber,
    supersedesHandoverId = supersedesHandoverId,
    outgoingTeam = outgoingTeam,
    incomingTeam = incomingTeam,
    outstandingTasksSummary = outstandingTasksSummary,
    equipmentIssuesSummary = equipmentIssuesSummary,
    logisticsNotes = logisticsNotes,
    acknowledgedBy = acknowledgedBy,
    acknowledgedUtc = acknowledgedUtc,
    createdBy = createdBy,
    createdUtc = createdUtc,
    isLatest = isLatest
)

fun ShiftHandoverRecord.toEntity(): ShiftHandoverEntity = ShiftHandoverEntity(
    handoverId = handoverId,
    versionNumber = versionNumber,
    supersedesHandoverId = supersedesHandoverId,
    outgoingTeam = outgoingTeam,
    incomingTeam = incomingTeam,
    outstandingTasksSummary = outstandingTasksSummary,
    equipmentIssuesSummary = equipmentIssuesSummary,
    logisticsNotes = logisticsNotes,
    acknowledgedBy = acknowledgedBy,
    acknowledgedUtc = acknowledgedUtc,
    createdBy = createdBy,
    createdUtc = createdUtc,
    isLatest = isLatest
)

fun AuditEventEntity.toDomain(): AuditLogEntry = AuditLogEntry(
    id = id,
    simTimeUtc = simTimeUtc,
    deviceTimeUtc = deviceTimeUtc,
    actorRole = actorRole,
    actorName = actorName,
    actionType = actionType,
    targetId = targetId,
    summary = summary,
    outcome = outcome
)

fun LogisticsRecordEntity.toDomain(): LogisticsRecord = LogisticsRecord(
    id = id,
    kind = kind,
    itemCode = itemCode,
    description = description,
    quantity = quantity,
    unit = unit,
    isMeasured = isMeasured,
    status = status,
    requestedBy = requestedBy,
    approvedBy = approvedBy,
    timestampUtc = timestampUtc
)

fun LogisticsRecord.toEntity(): LogisticsRecordEntity = LogisticsRecordEntity(
    id = id,
    kind = kind,
    itemCode = itemCode,
    description = description,
    quantity = quantity,
    unit = unit,
    isMeasured = isMeasured,
    status = status,
    requestedBy = requestedBy,
    approvedBy = approvedBy,
    timestampUtc = timestampUtc
)

fun PendingSyncMutationEntity.toDomain(): PendingSyncItem = PendingSyncItem(
    id = id,
    idempotencyKey = idempotencyKey,
    mutationType = mutationType,
    targetId = targetId,
    expectedVersion = expectedVersion,
    retryCount = retryCount,
    maxRetries = maxRetries,
    conflictMessage = conflictMessage,
    createdUtc = createdUtc
)

private inline fun <reified T : Enum<T>> enumValueOfOrDefault(name: String, default: T): T {
    return runCatching { enumValueOf<T>(name) }.getOrDefault(default)
}

fun serializeReviewHistory(entries: List<WorkOrderReviewEntry>): String {
    val array = JSONArray()
    entries.forEach { e ->
        array.put(
            JSONObject().apply {
                put("reviewer", e.reviewer)
                put("role", e.role)
                put("decision", e.decision)
                put("comment", e.comment)
                put("timestampUtc", e.timestampUtc)
            }
        )
    }
    return array.toString()
}

fun parseReviewHistory(json: String): List<WorkOrderReviewEntry> {
    if (json.isBlank()) return emptyList()
    return runCatching {
        val array = JSONArray(json)
        buildList {
            for (i in 0 until array.length()) {
                val obj = array.getJSONObject(i)
                add(
                    WorkOrderReviewEntry(
                        reviewer = obj.optString("reviewer"),
                        role = obj.optString("role"),
                        decision = obj.optString("decision"),
                        comment = obj.optString("comment"),
                        timestampUtc = obj.optString("timestampUtc")
                    )
                )
            }
        }
    }.getOrDefault(emptyList())
}
