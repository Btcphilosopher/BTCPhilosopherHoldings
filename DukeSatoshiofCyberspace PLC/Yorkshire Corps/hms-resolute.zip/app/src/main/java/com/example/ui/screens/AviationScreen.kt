package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.assets.AssetCategory
import com.example.assets.TaskPriority
import com.example.assets.WorkOrderStatus
import com.example.ui.ResoluteUiState
import com.example.ui.components.IvoryCommandCard
import com.example.ui.components.MonoMetricRow
import com.example.ui.components.StatusPill
import com.example.ui.components.WorkOrderStatusPill
import com.example.ui.theme.BrassGold
import com.example.ui.theme.InkMuted
import com.example.ui.theme.InkNavy
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.MidnightAbyss
import com.example.ui.theme.MidnightNavy
import com.example.ui.theme.StatusCautionAmber
import com.example.ui.theme.WarmIvory

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun AviationScreen(
    state: ResoluteUiState,
    onSelectAsset: (String) -> Unit,
    onOpenWorkOrder: (String) -> Unit,
    onCreateWorkOrder: (String, String, String, TaskPriority, String) -> Unit,
    modifier: Modifier = Modifier
) {
    var searchQuery by remember { mutableStateOf("") }
    var statusFilter by remember { mutableStateOf<WorkOrderStatus?>(null) }
    var showCreateDialog by remember { mutableStateOf(false) }

    val aviationAssets = state.assets.filter {
        it.category == AssetCategory.AIRCRAFT || it.category == AssetCategory.HELICOPTER
    }
    val filteredOrders = state.workOrders.filter { wo ->
        val matchesQuery = searchQuery.isBlank() ||
            wo.taskId.contains(searchQuery, ignoreCase = true) ||
            wo.assetId.contains(searchQuery, ignoreCase = true) ||
            wo.title.contains(searchQuery, ignoreCase = true) ||
            wo.assignedTeam.contains(searchQuery, ignoreCase = true)
        val matchesStatus = statusFilter == null || wo.status == statusFilter
        matchesQuery && matchesStatus
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        IvoryCommandCard(
            title = "Aircraft Maintenance Readiness (Separate from Flight Authorisation)",
            subtitle = state.aircraftAvailability.formulaExplanation
        ) {
            Text(
                text = "Notice: Maintenance availability reflects engineering inspection readiness only. Flight launch/recovery authorisation remains an external Air Ops authority.",
                style = MaterialTheme.typography.bodySmall,
                color = StatusCautionAmber,
                fontWeight = FontWeight.SemiBold
            )
            Spacer(Modifier.height(8.dp))
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                aviationAssets.forEach { ac ->
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = WarmIvory,
                        border = BorderStroke(1.dp, BrassGold),
                        modifier = Modifier
                            .width(240.dp)
                            .testTag("aviation_card_${ac.id}")
                            .clickable { onSelectAsset(ac.id) }
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = ac.id,
                                    fontFamily = JetBrainsMonoFontFamily,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp,
                                    color = InkNavy
                                )
                                StatusPill(status = ac.operationalStatus)
                            }
                            Text(ac.assetType, style = MaterialTheme.typography.bodySmall, color = InkMuted)
                            MonoMetricRow("Location", ac.locationLabel)
                            MonoMetricRow("Team", ac.assignedTeam)
                            MonoMetricRow("Maint", ac.maintenanceState)
                        }
                    }
                }
            }
        }

        IvoryCommandCard(
            title = "Work Orders & Maintenance Tasks",
            subtitle = "${filteredOrders.size} of ${state.workOrders.size} tasks displayed",
            headerAction = {
                Button(
                    onClick = { showCreateDialog = true },
                    modifier = Modifier.testTag("aviation_new_wo_btn"),
                    colors = ButtonDefaults.buttonColors(containerColor = MidnightNavy, contentColor = BrassGold)
                ) {
                    Icon(Icons.Default.Add, contentDescription = null)
                    Spacer(Modifier.width(4.dp))
                    Text("New Task", fontSize = 12.sp)
                }
            }
        ) {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Search tasks") },
                label = { Text("Search by Task ID, Asset, Title, or Team") },
                modifier = Modifier.fillMaxWidth().testTag("wo_search_input")
            )
            Spacer(Modifier.height(6.dp))
            FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                FilterChip(
                    selected = statusFilter == null,
                    onClick = { statusFilter = null },
                    label = { Text("All", fontSize = 11.sp) }
                )
                listOf(
                    WorkOrderStatus.DRAFT,
                    WorkOrderStatus.ASSIGNED,
                    WorkOrderStatus.IN_PROGRESS,
                    WorkOrderStatus.AWAITING_REVIEW,
                    WorkOrderStatus.COMPLETE,
                    WorkOrderStatus.BLOCKED
                ).forEach { st ->
                    FilterChip(
                        selected = statusFilter == st,
                        onClick = { statusFilter = if (statusFilter == st) null else st },
                        label = { Text(st.label, fontSize = 11.sp) }
                    )
                }
            }
            Spacer(Modifier.height(8.dp))
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                filteredOrders.forEach { wo ->
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = WarmIvory,
                        border = BorderStroke(1.dp, BrassGold.copy(alpha = 0.6f)),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("aviation_wo_row_${wo.taskId}")
                            .clickable { onOpenWorkOrder(wo.taskId) }
                    ) {
                        Row(
                            modifier = Modifier.padding(10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "${wo.taskId} • ${wo.assetId} • ${wo.priority.label}",
                                    fontFamily = JetBrainsMonoFontFamily,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp
                                )
                                Text(wo.title, style = MaterialTheme.typography.bodyMedium)
                                Text(
                                    text = "Team: ${wo.assignedTeam} • Due: ${wo.dueTimeUtc} • Checklist: ${wo.completedChecklistCount}/${wo.checklistItems.size}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = InkMuted
                                )
                            }
                            WorkOrderStatusPill(status = wo.status)
                        }
                    }
                }
            }
        }
    }

    if (showCreateDialog) {
        var assetId by remember { mutableStateOf("AC-04") }
        var title by remember { mutableStateOf("") }
        var desc by remember { mutableStateOf("") }
        var team by remember { mutableStateOf("Team E-2") }
        Dialog(onDismissRequest = { showCreateDialog = false }) {
            Surface(
                shape = RoundedCornerShape(10.dp),
                color = WarmIvory,
                contentColor = InkNavy,
                border = BorderStroke(1.5.dp, BrassGold)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("LOG MAINTENANCE WORK ORDER", style = MaterialTheme.typography.headlineSmall)
                    OutlinedTextField(value = assetId, onValueChange = { assetId = it }, label = { Text("Asset ID (e.g. AC-04, LIFT-AFT)") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text("Task Title") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = desc, onValueChange = { desc = it }, label = { Text("Description") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = team, onValueChange = { team = it }, label = { Text("Assigned Team") }, modifier = Modifier.fillMaxWidth())
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                        Button(
                            onClick = {
                                onCreateWorkOrder(assetId, title, desc, TaskPriority.URGENT, team)
                                showCreateDialog = false
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = MidnightNavy, contentColor = BrassGold)
                        ) {
                            Text("Create Work Order")
                        }
                    }
                }
            }
        }
    }
}
