package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.ResoluteAppShell
import com.example.ui.ResoluteViewModel
import com.example.ui.theme.ResoluteTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            ResoluteTheme {
                val vm: ResoluteViewModel = viewModel()
                ResoluteAppShell(viewModel = vm)
            }
        }
    }
}
