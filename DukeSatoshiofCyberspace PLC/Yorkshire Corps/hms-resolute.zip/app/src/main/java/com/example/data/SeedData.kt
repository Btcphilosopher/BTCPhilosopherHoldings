package com.example.data

import com.example.assets.AssetCategory
import com.example.assets.AuditLogEntry
import com.example.assets.CarrierAsset
import com.example.assets.DeckLevel
import com.example.assets.DepartmentPersonnelSummary
import com.example.assets.LogisticsRecord
import com.example.assets.NavigationWeatherState
import com.example.assets.OperationalStatus
import com.example.assets.ShiftHandoverRecord
import com.example.assets.TaskPriority
import com.example.assets.TelemetryObservation
import com.example.assets.TelemetryQuality
import com.example.assets.WorkOrder
import com.example.assets.WorkOrderReviewEntry
import com.example.assets.WorkOrderStatus

data class SimulationScenario(
    val id: String,
    val number: Int,
    val title: String,
    val description: String
)

object SeedData {
    const val INITIAL_SIM_TIME_UTC = "2026-11-21T08:00:00Z"

    val scenarios: List<SimulationScenario> = listOf(
        SimulationScenario("SCEN-01", 1, "Normal Operations", "Nominal deck posture, healthy telemetry across all sources."),
        SimulationScenario("SCEN-02", 2, "Aircraft Inspection (AC-04)", "AC-04 starboard hydraulic/avionics inspection active with Team E-2."),
        SimulationScenario("SCEN-03", 3, "Service Vehicle Tasking", "TUG-02 dispatched along starboard foul line to support AC-04."),
        SimulationScenario("SCEN-04", 4, "Aft Lift Unavailable", "LIFT-AFT safety interlock fault; lift marked UNAVAILABLE."),
        SimulationScenario("SCEN-05", 5, "Weather Information Update", "North Atlantic trough: wind 310°/26 kt, sea state 5, vis 4.5 NM."),
        SimulationScenario("SCEN-06", 6, "Stale Engineering Telemetry", "HV-BUS-B & GT-2 telemetry link interrupted; green indicators degrade to STALE."),
        SimulationScenario("SCEN-07", 7, "Shift Handover", "Watch transition ALPHA WATCH to BRAVO WATCH with outstanding inspection notes."),
        SimulationScenario("SCEN-08", 8, "Connection Loss & Recovery", "Simulated backend disconnect; offline administrative edits queue with version checks.")
    )

    fun initialAssets(): List<CarrierAsset> = listOf(
        // Flight Deck Aircraft (shipX: 0..1000 stern->bow, shipY: 0..340 port->stbd)
        CarrierAsset(
            id = "AC-01",
            callsign = "RESOLUTE-01",
            assetType = "F-35B Lightning II (Sim)",
            category = AssetCategory.AIRCRAFT,
            deckLevel = DeckLevel.FLIGHT_DECK,
            shipX = 740f,
            shipY = 105f,
            headingDeg = 12f,
            locationLabel = "Fwd Park Alpha-1",
            maintenanceState = "Serviceable / Scheduled Pre-check",
            operationalStatus = OperationalStatus.READY,
            flightAuthorisationSeparateNote = "Flight release managed externally by Air Ops Authority",
            assignedTeam = "Team A-1",
            lastUpdateUtc = "07:59:10Z",
            telemetryAgeSec = 50,
            telemetryQuality = TelemetryQuality.LIVE,
            dataSource = "Flight Deck Maintenance Bus",
            maintenanceProgressPct = 100
        ),
        CarrierAsset(
            id = "AC-02",
            callsign = "RESOLUTE-02",
            assetType = "F-35B Lightning II (Sim)",
            category = AssetCategory.AIRCRAFT,
            deckLevel = DeckLevel.FLIGHT_DECK,
            shipX = 650f,
            shipY = 95f,
            headingDeg = 14f,
            locationLabel = "Fwd Park Alpha-2",
            maintenanceState = "Ready — Daily Check Signed",
            operationalStatus = OperationalStatus.READY,
            flightAuthorisationSeparateNote = "Flight release managed externally by Air Ops Authority",
            assignedTeam = "Team A-1",
            lastUpdateUtc = "07:59:25Z",
            telemetryAgeSec = 35,
            telemetryQuality = TelemetryQuality.LIVE,
            dataSource = "Flight Deck Maintenance Bus",
            maintenanceProgressPct = 100
        ),
        CarrierAsset(
            id = "AC-03",
            callsign = "RESOLUTE-03",
            assetType = "F-35B Lightning II (Sim)",
            category = AssetCategory.AIRCRAFT,
            deckLevel = DeckLevel.FLIGHT_DECK,
            shipX = 520f,
            shipY = 92f,
            headingDeg = 22f,
            locationLabel = "Waist Spot Charlie-1",
            maintenanceState = "Ready — Refuelled",
            operationalStatus = OperationalStatus.READY,
            flightAuthorisationSeparateNote = "Flight release managed externally by Air Ops Authority",
            assignedTeam = "Team B-3",
            lastUpdateUtc = "07:58:50Z",
            telemetryAgeSec = 70,
            telemetryQuality = TelemetryQuality.LIVE,
            dataSource = "Flight Deck Maintenance Bus",
            maintenanceProgressPct = 100
        ),
        // Reference Example Aircraft: AC-04 — Maintenance — Inspection in progress — Team E-2
        CarrierAsset(
            id = "AC-04",
            callsign = "RESOLUTE-04",
            assetType = "F-35B Lightning II (Sim)",
            category = AssetCategory.AIRCRAFT,
            deckLevel = DeckLevel.FLIGHT_DECK,
            shipX = 415f,
            shipY = 232f,
            headingDeg = 270f,
            locationLabel = "Stbd Maint Spot Delta-4",
            maintenanceState = "Inspection in progress",
            operationalStatus = OperationalStatus.MAINTENANCE,
            flightAuthorisationSeparateNote = "Maintenance availability only — NOT flight authorised",
            assignedTeam = "Team E-2",
            lastUpdateUtc = "07:59:40Z",
            telemetryAgeSec = 20,
            telemetryQuality = TelemetryQuality.LIVE,
            dataSource = "Air Engineering Desk (AEMIS)",
            maintenanceProgressPct = 62
        ),
        CarrierAsset(
            id = "AC-05",
            callsign = "RESOLUTE-05",
            assetType = "F-35B Lightning II (Sim)",
            category = AssetCategory.AIRCRAFT,
            deckLevel = DeckLevel.FLIGHT_DECK,
            shipX = 275f,
            shipY = 112f,
            headingDeg = 35f,
            locationLabel = "Aft Spot Echo-1",
            maintenanceState = "Ready — Standby",
            operationalStatus = OperationalStatus.READY,
            flightAuthorisationSeparateNote = "Flight release managed externally by Air Ops Authority",
            assignedTeam = "Team C-1",
            lastUpdateUtc = "07:59:18Z",
            telemetryAgeSec = 42,
            telemetryQuality = TelemetryQuality.LIVE,
            dataSource = "Flight Deck Maintenance Bus",
            maintenanceProgressPct = 100
        ),
        CarrierAsset(
            id = "AC-06",
            callsign = "MERLIN-61",
            assetType = "Merlin HM2 Crowsnest (Sim)",
            category = AssetCategory.HELICOPTER,
            deckLevel = DeckLevel.FLIGHT_DECK,
            shipX = 165f,
            shipY = 135f,
            headingDeg = 5f,
            locationLabel = "Aft Helo Spot Foxtrot-1",
            maintenanceState = "Ready — Rotor Fold Verified",
            operationalStatus = OperationalStatus.READY,
            flightAuthorisationSeparateNote = "Flight release managed externally by Air Ops Authority",
            assignedTeam = "Team H-1",
            lastUpdateUtc = "07:59:05Z",
            telemetryAgeSec = 55,
            telemetryQuality = TelemetryQuality.LIVE,
            dataSource = "Flight Deck Maintenance Bus",
            maintenanceProgressPct = 100
        ),
        CarrierAsset(
            id = "AC-07",
            callsign = "MERLIN-62",
            assetType = "Merlin Mk4 Commando (Sim)",
            category = AssetCategory.HELICOPTER,
            deckLevel = DeckLevel.HANGAR,
            shipX = 480f,
            shipY = 175f,
            headingDeg = 0f,
            locationLabel = "Hangar Bay 2B",
            maintenanceState = "Scheduled 100-Hr Gearbox Inspection",
            operationalStatus = OperationalStatus.INSPECTION,
            flightAuthorisationSeparateNote = "Hangar maintenance hold — external release required",
            assignedTeam = "Team H-2",
            lastUpdateUtc = "07:57:30Z",
            telemetryAgeSec = 150,
            telemetryQuality = TelemetryQuality.LIVE,
            dataSource = "Hangar Control Console",
            maintenanceProgressPct = 45
        ),
        CarrierAsset(
            id = "AC-08",
            callsign = "RESOLUTE-08",
            assetType = "F-35B Lightning II (Sim)",
            category = AssetCategory.AIRCRAFT,
            deckLevel = DeckLevel.HANGAR,
            shipX = 635f,
            shipY = 165f,
            headingDeg = 0f,
            locationLabel = "Hangar Bay 1A",
            maintenanceState = "Ready — Hangar Stowage",
            operationalStatus = OperationalStatus.READY,
            flightAuthorisationSeparateNote = "Flight release managed externally by Air Ops Authority",
            assignedTeam = "Team B-2",
            lastUpdateUtc = "07:58:20Z",
            telemetryAgeSec = 100,
            telemetryQuality = TelemetryQuality.LIVE,
            dataSource = "Hangar Control Console",
            maintenanceProgressPct = 100
        ),

        // Service Vehicles
        CarrierAsset(
            id = "TUG-01",
            callsign = "DECK-TUG-01",
            assetType = "Douglas Aircraft Handler",
            category = AssetCategory.SERVICE_VEHICLE,
            deckLevel = DeckLevel.FLIGHT_DECK,
            shipX = 590f,
            shipY = 205f,
            headingDeg = 180f,
            locationLabel = "Mid-Deck Taxi Lane",
            maintenanceState = "Operational — Towing Ready",
            operationalStatus = OperationalStatus.READY,
            flightAuthorisationSeparateNote = "Deck tractor — illustrative position telemetry only",
            assignedTeam = "Deck Handling Team",
            lastUpdateUtc = "07:59:55Z",
            telemetryAgeSec = 5,
            telemetryQuality = TelemetryQuality.LIVE,
            dataSource = "Deck Telemetry Beacon",
            maintenanceProgressPct = 100,
            simulatedPathIndex = 0
        ),
        CarrierAsset(
            id = "TUG-02",
            callsign = "DECK-TUG-02",
            assetType = "Hydro-Utility Tow Tug",
            category = AssetCategory.SERVICE_VEHICLE,
            deckLevel = DeckLevel.FLIGHT_DECK,
            shipX = 355f,
            shipY = 212f,
            headingDeg = 90f,
            locationLabel = "Stbd Island Approach",
            maintenanceState = "Assigned — Supporting AC-04",
            operationalStatus = OperationalStatus.CAUTION,
            flightAuthorisationSeparateNote = "Deck tractor — illustrative position telemetry only",
            assignedTeam = "Team E-2",
            lastUpdateUtc = "07:59:52Z",
            telemetryAgeSec = 8,
            telemetryQuality = TelemetryQuality.LIVE,
            dataSource = "Deck Telemetry Beacon",
            maintenanceProgressPct = 100,
            simulatedPathIndex = 1
        ),
        CarrierAsset(
            id = "FIRE-01",
            callsign = "CRASH-RESCUE-1",
            assetType = "RIV Fire & Rescue Appliance",
            category = AssetCategory.SERVICE_VEHICLE,
            deckLevel = DeckLevel.FLIGHT_DECK,
            shipX = 505f,
            shipY = 258f,
            headingDeg = 270f,
            locationLabel = "Between Islands Standby",
            maintenanceState = "Standby — Foam Pressurised",
            operationalStatus = OperationalStatus.READY,
            flightAuthorisationSeparateNote = "Safety standby monitoring only",
            assignedTeam = "Deck Fire Party",
            lastUpdateUtc = "07:59:50Z",
            telemetryAgeSec = 10,
            telemetryQuality = TelemetryQuality.LIVE,
            dataSource = "Deck Telemetry Beacon",
            maintenanceProgressPct = 100
        ),

        // Aircraft Lifts
        CarrierAsset(
            id = "LIFT-FWD",
            callsign = "FWD-LIFT-1",
            assetType = "70-Tonne Stbd Aircraft Lift",
            category = AssetCategory.AIRCRAFT_LIFT,
            deckLevel = DeckLevel.FLIGHT_DECK,
            shipX = 580f,
            shipY = 298f,
            headingDeg = 0f,
            locationLabel = "Starboard Forward Lift",
            maintenanceState = "Operational — Flight Deck Flush",
            operationalStatus = OperationalStatus.READY,
            flightAuthorisationSeparateNote = "Lift mechanical actuation remains external",
            assignedTeam = "ME Hull Team",
            lastUpdateUtc = "07:59:45Z",
            telemetryAgeSec = 15,
            telemetryQuality = TelemetryQuality.LIVE,
            dataSource = "Platform Management Read-Only Adapter",
            maintenanceProgressPct = 100
        ),
        CarrierAsset(
            id = "LIFT-AFT",
            callsign = "AFT-LIFT-2",
            assetType = "70-Tonne Stbd Aircraft Lift",
            category = AssetCategory.AIRCRAFT_LIFT,
            deckLevel = DeckLevel.FLIGHT_DECK,
            shipX = 335f,
            shipY = 298f,
            headingDeg = 0f,
            locationLabel = "Starboard Aft Lift",
            maintenanceState = "Operational — Safety Pins Clear",
            operationalStatus = OperationalStatus.READY,
            flightAuthorisationSeparateNote = "Lift mechanical actuation remains external",
            assignedTeam = "ME Hull Team",
            lastUpdateUtc = "07:59:42Z",
            telemetryAgeSec = 18,
            telemetryQuality = TelemetryQuality.LIVE,
            dataSource = "Platform Management Read-Only Adapter",
            maintenanceProgressPct = 100
        ),

        // Maintenance Zones (Hangar & Flight Deck)
        CarrierAsset(
            id = "ZONE-MAINT-D4",
            callsign = "MAINT-DELTA-4",
            assetType = "Deck Maintenance Bay",
            category = AssetCategory.MAINTENANCE_ZONE,
            deckLevel = DeckLevel.FLIGHT_DECK,
            shipX = 415f,
            shipY = 232f,
            headingDeg = 0f,
            locationLabel = "Starboard Delta-4 Bay",
            maintenanceState = "Occupied by AC-04",
            operationalStatus = OperationalStatus.INSPECTION,
            flightAuthorisationSeparateNote = "Ground power & nitrogen cart connected",
            assignedTeam = "Team E-2",
            lastUpdateUtc = "07:59:40Z",
            telemetryAgeSec = 20,
            telemetryQuality = TelemetryQuality.LIVE,
            dataSource = "Deck Zone Monitor",
            maintenanceProgressPct = 62
        ),
        CarrierAsset(
            id = "BAY-1A",
            callsign = "HANGAR-BAY-1A",
            assetType = "Overhead Crane Maint Bay",
            category = AssetCategory.MAINTENANCE_ZONE,
            deckLevel = DeckLevel.HANGAR,
            shipX = 635f,
            shipY = 165f,
            headingDeg = 0f,
            locationLabel = "Forward Hangar Bay 1A",
            maintenanceState = "Available — 15t Gantry Clear",
            operationalStatus = OperationalStatus.READY,
            flightAuthorisationSeparateNote = "Hangar fire curtain normal",
            assignedTeam = "Hangar Control",
            lastUpdateUtc = "07:58:15Z",
            telemetryAgeSec = 105,
            telemetryQuality = TelemetryQuality.LIVE,
            dataSource = "Hangar Control Console",
            maintenanceProgressPct = 100
        ),

        // Systems Deck Engineering Units
        CarrierAsset(
            id = "GT-1",
            callsign = "GAS-TURBINE-1",
            assetType = "MT30 36 MW Alternator",
            category = AssetCategory.ENGINEERING_SYSTEM,
            deckLevel = DeckLevel.SYSTEMS,
            shipX = 610f,
            shipY = 135f,
            headingDeg = 0f,
            locationLabel = "Fwd Machinery Space (Sponson)",
            maintenanceState = "Online — 24.8 MW Load",
            operationalStatus = OperationalStatus.READY,
            flightAuthorisationSeparateNote = "Read-only engineering telemetry; no actuation",
            assignedTeam = "ME Power Watch",
            lastUpdateUtc = "07:59:50Z",
            telemetryAgeSec = 10,
            telemetryQuality = TelemetryQuality.LIVE,
            dataSource = "IPMS Read-Only Adapter",
            maintenanceProgressPct = 100
        ),
        CarrierAsset(
            id = "GT-2",
            callsign = "GAS-TURBINE-2",
            assetType = "MT30 36 MW Alternator",
            category = AssetCategory.ENGINEERING_SYSTEM,
            deckLevel = DeckLevel.SYSTEMS,
            shipX = 390f,
            shipY = 205f,
            headingDeg = 0f,
            locationLabel = "Aft Machinery Space",
            maintenanceState = "Online — 18.2 MW Load",
            operationalStatus = OperationalStatus.READY,
            flightAuthorisationSeparateNote = "Read-only engineering telemetry; no actuation",
            assignedTeam = "ME Power Watch",
            lastUpdateUtc = "07:59:48Z",
            telemetryAgeSec = 12,
            telemetryQuality = TelemetryQuality.LIVE,
            dataSource = "IPMS Read-Only Adapter",
            maintenanceProgressPct = 100
        ),
        CarrierAsset(
            id = "DG-1",
            callsign = "DIESEL-GEN-1",
            assetType = "Wartsila 11 MW Diesel Gen",
            category = AssetCategory.ENGINEERING_SYSTEM,
            deckLevel = DeckLevel.SYSTEMS,
            shipX = 520f,
            shipY = 115f,
            headingDeg = 0f,
            locationLabel = "Fwd Aux Machinery Room",
            maintenanceState = "Online — Base Load 6.4 MW",
            operationalStatus = OperationalStatus.READY,
            flightAuthorisationSeparateNote = "Read-only engineering telemetry",
            assignedTeam = "ME Aux Watch",
            lastUpdateUtc = "07:59:44Z",
            telemetryAgeSec = 16,
            telemetryQuality = TelemetryQuality.LIVE,
            dataSource = "IPMS Read-Only Adapter",
            maintenanceProgressPct = 100
        ),
        CarrierAsset(
            id = "HV-BUS-B",
            callsign = "HV-SWITCHBOARD-B",
            assetType = "11 kV Distribution Switchboard",
            category = AssetCategory.ENGINEERING_SYSTEM,
            deckLevel = DeckLevel.SYSTEMS,
            shipX = 460f,
            shipY = 225f,
            headingDeg = 0f,
            locationLabel = "Aft Main Switchboard",
            maintenanceState = "Closed Ring — Nominal 11.0 kV",
            operationalStatus = OperationalStatus.READY,
            flightAuthorisationSeparateNote = "Breaker control external to app",
            assignedTeam = "WE/ME Electrical",
            lastUpdateUtc = "07:59:46Z",
            telemetryAgeSec = 14,
            telemetryQuality = TelemetryQuality.LIVE,
            dataSource = "IPMS Read-Only Adapter",
            maintenanceProgressPct = 100
        ),
        CarrierAsset(
            id = "RO-PLANT-1",
            callsign = "RO-DESAL-1",
            assetType = "Reverse Osmosis Plant (240t/day)",
            category = AssetCategory.ENGINEERING_SYSTEM,
            deckLevel = DeckLevel.SYSTEMS,
            shipX = 290f,
            shipY = 145f,
            headingDeg = 0f,
            locationLabel = "Aft Aux Compartment",
            maintenanceState = "Producing — 9.8 t/hr",
            operationalStatus = OperationalStatus.READY,
            flightAuthorisationSeparateNote = "Read-only telemetry",
            assignedTeam = "ME Aux Watch",
            lastUpdateUtc = "07:59:30Z",
            telemetryAgeSec = 30,
            telemetryQuality = TelemetryQuality.LIVE,
            dataSource = "IPMS Read-Only Adapter",
            maintenanceProgressPct = 100
        )
    )

    fun initialWorkOrders(): List<WorkOrder> = listOf(
        WorkOrder(
            taskId = "WO-404",
            assetId = "AC-04",
            zoneLabel = "Stbd Maint Spot Delta-4",
            title = "Starboard Hydraulic Manifold & Avionics Bay Inspection",
            description = "Scheduled 50-hour borescope and pressure-decay inspection on AC-04 starboard actuator line and cooling loop.",
            priority = TaskPriority.URGENT,
            assignedTeam = "Team E-2",
            dueTimeUtc = "09:30:00Z",
            dependencies = listOf("DEP-GPU-CART", "DEP-NITROGEN-RIG"),
            status = WorkOrderStatus.IN_PROGRESS,
            checklistItems = listOf(
                "Lock out ground hydraulic cart & verify zero residual pressure",
                "Inspect starboard actuator seal & borescope manifold",
                "Verify avionics bay thermal sensor calibration",
                "Perform clean-area FOD sweep & tool count"
            ),
            completedChecklistCount = 3,
            completionEvidence = "Pressure decay 0.02 bar over 10 min (within spec); thermal loop calibrated.",
            notes = "Team E-2 awaiting final FOD sweep & supervisor authorised review before updating maintenance availability.",
            attachments = listOf("IMG_AC04_BORESCOPE_01.png", "LOG_HYD_TEST_404.csv"),
            reviewHistory = listOf(
                WorkOrderReviewEntry(
                    reviewer = "PO M. Thorne",
                    role = "Maintenance Lead",
                    decision = "STARTED",
                    comment = "Commenced 50-hr inspection at Delta-4.",
                    timestampUtc = "07:15:00Z"
                )
            ),
            version = 3,
            lastChangedBy = "PO M. Thorne",
            lastChangedUtc = "07:48:00Z"
        ),
        WorkOrder(
            taskId = "WO-409",
            assetId = "TUG-02",
            zoneLabel = "Stbd Island Approach",
            title = "Tow Tractor Hydraulic Tow-Head Check",
            description = "Verify tow-bar shear-pin torque prior to positioning near Delta-4.",
            priority = TaskPriority.ROUTINE,
            assignedTeam = "Team E-2",
            dueTimeUtc = "08:45:00Z",
            dependencies = emptyList(),
            status = WorkOrderStatus.ASSIGNED,
            checklistItems = listOf(
                "Inspect shear-pin collar",
                "Test emergency brake dead-man pedal"
            ),
            completedChecklistCount = 1,
            completionEvidence = "",
            notes = "Assigned for AC-04 support tow staging.",
            attachments = emptyList(),
            reviewHistory = emptyList(),
            version = 1,
            lastChangedBy = "CDR H. Vane",
            lastChangedUtc = "07:35:00Z"
        ),
        WorkOrder(
            taskId = "WO-412",
            assetId = "AC-07",
            zoneLabel = "Hangar Bay 2B",
            title = "Merlin Mk4 Main Rotor Gearbox Oil Sample & Inspection",
            description = "100-hour spectrometric oil analysis and chip-detector continuity check.",
            priority = TaskPriority.URGENT,
            assignedTeam = "Team H-2",
            dueTimeUtc = "10:15:00Z",
            dependencies = listOf("WO-404"),
            status = WorkOrderStatus.AWAITING_REVIEW,
            checklistItems = listOf(
                "Draw 100ml gearbox oil sample",
                "Verify magnetic chip plug clean",
                "Torque safety wire to Spec M-44"
            ),
            completedChecklistCount = 3,
            completionEvidence = "Spectrometric sample #SOA-8812 submitted; zero ferrous debris.",
            notes = "Checklist complete — awaiting Air & Eng Supervisor review to release availability.",
            attachments = listOf("SOA_REPORT_8812.pdf"),
            reviewHistory = listOf(
                WorkOrderReviewEntry(
                    reviewer = "CPO L. Evans",
                    role = "Maintenance Lead",
                    decision = "SUBMITTED_FOR_REVIEW",
                    comment = "All 3 steps verified with QA stamp.",
                    timestampUtc = "07:52:00Z"
                )
            ),
            version = 2,
            lastChangedBy = "CPO L. Evans",
            lastChangedUtc = "07:52:00Z"
        ),
        WorkOrder(
            taskId = "WO-415",
            assetId = "LIFT-AFT",
            zoneLabel = "Starboard Aft Lift",
            title = "Aft Lift Limit-Switch Calibration Verification",
            description = "Routine weekly calibration verification of upper deck lock dogs.",
            priority = TaskPriority.ROUTINE,
            assignedTeam = "ME Hull Team",
            dueTimeUtc = "11:30:00Z",
            dependencies = emptyList(),
            status = WorkOrderStatus.DRAFT,
            checklistItems = listOf(
                "Verify lock-dog proximity sensor gap",
                "Log hydraulic manifold pressure"
            ),
            completedChecklistCount = 0,
            completionEvidence = "",
            notes = "Draft prepared for afternoon watch window.",
            attachments = emptyList(),
            reviewHistory = emptyList(),
            version = 1,
            lastChangedBy = "LT J. Mercer",
            lastChangedUtc = "07:10:00Z"
        ),
        WorkOrder(
            taskId = "WO-418",
            assetId = "RO-PLANT-1",
            zoneLabel = "Aft Aux Compartment",
            title = "RO Membrane Differential Pressure Flush",
            description = "Routine fresh-water backflush and salinity probe check.",
            priority = TaskPriority.ROUTINE,
            assignedTeam = "ME Aux Watch",
            dueTimeUtc = "07:45:00Z",
            dependencies = emptyList(),
            status = WorkOrderStatus.COMPLETE,
            checklistItems = listOf(
                "Run 15-min permeate flush",
                "Verify conductivity < 220 ppm"
            ),
            completedChecklistCount = 2,
            completionEvidence = "Conductivity steady at 148 ppm.",
            notes = "Closed cleanly.",
            attachments = emptyList(),
            reviewHistory = listOf(
                WorkOrderReviewEntry(
                    reviewer = "CDR H. Vane",
                    role = "Air & Eng Supervisor",
                    decision = "APPROVED",
                    comment = "Verified nominal salinity reading.",
                    timestampUtc = "07:42:00Z"
                )
            ),
            version = 4,
            lastChangedBy = "CDR H. Vane",
            lastChangedUtc = "07:42:00Z"
        )
    )

    fun initialNavWeather(): NavigationWeatherState = NavigationWeatherState(
        positionSource = "Dual INS / GNSS (Read-Only Feed)",
        latitudeDisplay = "57° 44.2' N",
        longitudeDisplay = "006° 18.7' W",
        headingDeg = 284.0,
        courseOverGroundDeg = 281.5,
        speedThroughWaterKnots = 18.4,
        speedOverGroundKnots = 19.1,
        speedUncertaintyKnots = 0.2,
        windDirectionDeg = 295,
        windSpeedKnots = 18,
        visibilityNm = 8.5,
        seaStateCode = 4,
        seaStateDescription = "Moderate (1.25–2.5m swell)",
        nextWaypointName = "WP-HEBRIDES-04",
        nextWaypointEtaUtc = "11:20:00Z",
        waypointDistanceNm = 63.4,
        routeProgressRatio = 0.64f,
        timestampUtc = "07:59:50Z",
        ageSeconds = 10,
        quality = TelemetryQuality.LIVE
    )

    fun initialTelemetryObservations(): List<TelemetryObservation> = listOf(
        // Current latest metrics
        TelemetryObservation(1, "ENGINEERING", "ELEC_DEMAND_MW", "Electrical Demand", 49.4, "MW", true, 108.0, "±0.4 MW", "IPMS Bus A+B", "07:59:50Z", 10, TelemetryQuality.LIVE),
        TelemetryObservation(2, "LOGISTICS", "FUEL_F44_TONNES", "Aviation Fuel (F-44)", 1840.0, "t", true, 2400.0, "±8 t tank gauge", "Tank Sounding Bus", "07:59:15Z", 45, TelemetryQuality.LIVE),
        TelemetryObservation(3, "LOGISTICS", "FUEL_F76_TONNES", "Marine Diesel (F-76)", 3920.0, "t", true, 5200.0, "±15 t tank gauge", "Tank Sounding Bus", "07:59:15Z", 45, TelemetryQuality.LIVE),
        TelemetryObservation(4, "LOGISTICS", "FRESH_WATER_TONNES", "Fresh Water Potable", 468.0, "t", true, 600.0, "±2 t ultrasonic", "Aux Water Telemetry", "07:59:30Z", 30, TelemetryQuality.LIVE),
        TelemetryObservation(5, "LOGISTICS", "STORES_EST_DAYS", "Provisions Endurance", 24.5, "days", false, 35.0, "Estimated from issue rate", "Logistics Ledger", "07:50:00Z", 600, TelemetryQuality.LIVE),

        // Historical trend series for Electrical Demand (includes a genuine MISSING gap at 07:30!)
        TelemetryObservation(10, "TREND", "ELEC_TREND", "07:00Z", 44.2, "MW", true, 108.0, "±0.4", "IPMS", "07:00:00Z", 3600, TelemetryQuality.LIVE),
        TelemetryObservation(11, "TREND", "ELEC_TREND", "07:10Z", 45.8, "MW", true, 108.0, "±0.4", "IPMS", "07:10:00Z", 3000, TelemetryQuality.LIVE),
        TelemetryObservation(12, "TREND", "ELEC_TREND", "07:20Z", 46.5, "MW", true, 108.0, "±0.4", "IPMS", "07:20:00Z", 2400, TelemetryQuality.LIVE),
        TelemetryObservation(13, "TREND", "ELEC_TREND", "07:30Z", null, "MW", true, 108.0, "Gap: Bus Logger Reset", "IPMS", "07:30:00Z", 1800, TelemetryQuality.MISSING),
        TelemetryObservation(14, "TREND", "ELEC_TREND", "07:40Z", 48.1, "MW", true, 108.0, "±0.4", "IPMS", "07:40:00Z", 1200, TelemetryQuality.LIVE),
        TelemetryObservation(15, "TREND", "ELEC_TREND", "07:50Z", 49.0, "MW", true, 108.0, "±0.4", "IPMS", "07:50:00Z", 600, TelemetryQuality.LIVE),
        TelemetryObservation(16, "TREND", "ELEC_TREND", "08:00Z", 49.4, "MW", true, 108.0, "±0.4", "IPMS", "07:59:50Z", 10, TelemetryQuality.LIVE),

        // Historical trend for Fresh Water
        TelemetryObservation(20, "TREND", "WATER_TREND", "07:00Z", 460.0, "t", true, 600.0, "±2 t", "Aux", "07:00:00Z", 3600, TelemetryQuality.LIVE),
        TelemetryObservation(21, "TREND", "WATER_TREND", "07:20Z", 463.0, "t", true, 600.0, "±2 t", "Aux", "07:20:00Z", 2400, TelemetryQuality.LIVE),
        TelemetryObservation(22, "TREND", "WATER_TREND", "07:40Z", 465.5, "t", true, 600.0, "±2 t", "Aux", "07:40:00Z", 1200, TelemetryQuality.LIVE),
        TelemetryObservation(23, "TREND", "WATER_TREND", "08:00Z", 468.0, "t", true, 600.0, "±2 t", "Aux", "07:59:30Z", 30, TelemetryQuality.LIVE)
    )

    fun initialPersonnelDepartments(): List<DepartmentPersonnelSummary> = listOf(
        DepartmentPersonnelSummary("AIR", "Air & Flight Deck Dept", 248, 96, 144, 8, listOf("CDR A. Finch (Air Boss)", "PO M. Thorne (Team E-2)", "LH R. Patel (Deck Handler)")),
        DepartmentPersonnelSummary("ME", "Marine Engineering Dept", 184, 72, 106, 6, listOf("CDR E. Vance (MEO)", "CPOMEA K. Walsh", "LET D. Brooks")),
        DepartmentPersonnelSummary("WE", "Weapon & Sensor Eng (Info Only)", 112, 40, 68, 4, listOf("LT Cdr B. Lowe", "POET S. Clarke")),
        DepartmentPersonnelSummary("LOG", "Logistics & Supply Dept", 98, 38, 57, 3, listOf("LT S. Sterling (Logs)", "POSC N. Okafor")),
        DepartmentPersonnelSummary("OPS", "Executive & Ops Coordination", 84, 34, 48, 2, listOf("CAPT R. Sterling (CO)", "CDR H. Vane (XO)"))
    )

    fun initialLogisticsRecords(): List<LogisticsRecord> = listOf(
        LogisticsRecord("REQ-901", "STORES_REQUEST", "HYD-SEAL-F35", "Starboard Actuator Seal Kit (AC-04)", 2.0, "kits", true, "PENDING_APPROVAL", "PO M. Thorne (Team E-2)", null, "07:40:00Z"),
        LogisticsRecord("REQ-902", "STORES_REQUEST", "F44-FILTER-12", "Fuel Filter Coalescer Element", 6.0, "units", true, "APPROVED", "LET D. Brooks", "CDR H. Vane", "07:12:00Z"),
        LogisticsRecord("RPL-304", "REPLENISHMENT", "RAS-F76-08", "RFA Tideforce RAS Consolidation (Planned)", 650.0, "t (est)", false, "SCHEDULED", "LT S. Sterling", "CDR H. Vane", "06:30:00Z"),
        LogisticsRecord("MOV-712", "INVENTORY_MOVEMENT", "F44-TANK-2S", "Internal Fuel Transfer: Storage 2S -> Service Tank", 42.5, "t (measured)", true, "RECORDED", "ME Aux Watch", null, "07:25:00Z")
    )

    fun initialHandovers(): List<ShiftHandoverRecord> = listOf(
        ShiftHandoverRecord(
            handoverId = "HO-20261121-01",
            versionNumber = 1,
            supersedesHandoverId = null,
            outgoingTeam = "FOXTROT WATCH",
            incomingTeam = "ALPHA WATCH",
            outstandingTasksSummary = "WO-404 on AC-04 hydraulic manifold inspection at 60%; WO-412 Merlin oil analysis awaiting supervisor review.",
            equipmentIssuesSummary = "All primary propulsion & HV buses nominal. Monitor starboard aft lift limit-switch draft WO-415.",
            logisticsNotes = "F-44 at 76.7% measured; REQ-901 seal kit awaiting administrative sign-off.",
            acknowledgedBy = "CDR H. Vane (ALPHA WATCH)",
            acknowledgedUtc = "07:02:00Z",
            createdBy = "LT CDR B. Lowe (FOXTROT WATCH)",
            createdUtc = "06:58:00Z",
            isLatest = true
        )
    )

    fun initialAuditEvents(): List<AuditLogEntry> = listOf(
        AuditLogEntry(1, "07:02:00Z", "08:00:00Z", "DEPARTMENT_SUPERVISOR", "CDR H. Vane", "HANDOVER_ACK", "HO-20261121-01", "Acknowledged ALPHA WATCH handover from FOXTROT WATCH.", "SUCCESS"),
        AuditLogEntry(2, "07:15:00Z", "08:00:00Z", "MAINTENANCE_STAFF", "PO M. Thorne", "WO_PROGRESS", "WO-404", "Started AC-04 hydraulic manifold inspection (Team E-2).", "SUCCESS"),
        AuditLogEntry(3, "07:42:00Z", "08:00:00Z", "DEPARTMENT_SUPERVISOR", "CDR H. Vane", "WO_REVIEW", "WO-418", "Authorised review & closure of RO-PLANT-1 membrane flush.", "SUCCESS"),
        AuditLogEntry(4, "07:52:00Z", "08:00:00Z", "MAINTENANCE_STAFF", "CPO L. Evans", "WO_SUBMIT_REVIEW", "WO-412", "Submitted Merlin AC-07 oil analysis for supervisor review.", "SUCCESS")
    )
}
