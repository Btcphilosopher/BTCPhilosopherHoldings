package com.example.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.navigationinfo.NavigationWeatherPanel
import com.example.ui.ResoluteUiState
import com.example.ui.components.IvoryCommandCard
import com.example.ui.components.MonoMetricRow
import com.example.ui.components.QualityPill

@Composable
fun NavigationScreen(
    state: ResoluteUiState,
    modifier: Modifier = Modifier
) {
    val nav = state.runtime.navWeather
    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        NavigationWeatherPanel(navWeather = nav, modifier = Modifier.fillMaxWidth())

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            IvoryCommandCard(
                title = "Read-Only Adapter Boundaries",
                subtitle = "Uncertified Information Integration",
                headerAction = { QualityPill(nav.quality, nav.ageSeconds) },
                modifier = Modifier.weight(1f)
            ) {
                MonoMetricRow("INS/GNSS Feed", nav.positionSource)
                MonoMetricRow("ECDIS / Charting", "EXTERNAL (Read-Only Schematic Only)")
                MonoMetricRow("Heading vs COG", "${nav.headingDeg}° HDG / ${nav.courseOverGroundDeg}° COG (Never Substituted)")
                MonoMetricRow("STW vs SOG", "${nav.speedThroughWaterKnots} kt STW / ${nav.speedOverGroundKnots} kt SOG")
                MonoMetricRow("Speed Uncertainty", "±${nav.speedUncertaintyKnots} kt")
                Spacer(Modifier.height(6.dp))
                Text(
                    text = "INFORMATION VIEW — NOT FOR NAVIGATION. HMS Resolute Command displays administrative and situational summaries only; steering, ECDIS, and machinery actuation remain external systems.",
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }
    }
}
