package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.assets.OperationalStatus
import com.example.assets.TelemetryQuality
import com.example.assets.WorkOrderStatus
import com.example.ui.ResoluteUiState
import com.example.ui.components.IvoryCommandCard
import com.example.ui.components.MonoMetricRow
import com.example.ui.components.NavalDarkPanel
import com.example.ui.components.QualityPill
import com.example.ui.theme.BrassGold
import com.example.ui.theme.InkMuted
import com.example.ui.theme.InkNavy
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.MidnightNavy
import com.example.ui.theme.StatusFaultRed
import com.example.ui.theme.WarmIvory

@Composable
fun ReportsScreen(
    state: ResoluteUiState,
    onLoadScenario: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val latestHandover = state.handovers.firstOrNull { it.isLatest }
    val ac04 = state.assets.find { it.id == "AC-04" }
    val wo404 = state.workOrders.find { it.taskId == "WO-404" }

    val briefText = buildString {
        appendLine("HMS RESOLUTE — ADMIRAL CLASS EXECUTIVE COMMAND BRIEF")
        appendLine("SIM TIME: ${state.runtime.simTimeUtc} | DEVICE UTC: ${state.runtime.deviceTimeUtc}")
        appendLine("SCENARIO: ${state.runtime.scenarioId} | MODE: ${state.runtime.connectionMode.label}")
        appendLine("SHIP: SOG ${state.runtime.navWeather.speedOverGroundKnots} kt / STW ${state.runtime.navWeather.speedThroughWaterKnots} kt | HDG ${state.runtime.navWeather.headingDeg}° | COG ${state.runtime.navWeather.courseOverGroundDeg}°")
        appendLine("AIRCRAFT MAINT AVAIL: ${state.aircraftAvailability.availableUnits}/${state.aircraftAvailability.totalUnits} (${state.aircraftAvailability.percentage?.let { "%.1f%%".format(it) } ?: "UNKNOWN"})")
        appendLine("ENGINEERING AVAIL: ${state.engineeringAvailability.availableUnits}/${state.engineeringAvailability.totalUnits} (${state.engineeringAvailability.percentage?.let { "%.1f%%".format(it) } ?: "UNKNOWN"})")
        appendLine("AC-04 STATUS: ${ac04?.operationalStatus?.label} (${ac04?.maintenanceState}) | WO-404: ${wo404?.status?.label}")
        appendLine("LATEST HANDOVER: ${latestHandover?.handoverId} v${latestHandover?.versionNumber} (${latestHandover?.outgoingTeam} -> ${latestHandover?.incomingTeam})")
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        IvoryCommandCard(
            title = "Executive Command Readiness Report",
            subtitle = "Deterministic snapshot generated from Room + Simulation State"
        ) {
            Text(
                text = briefText,
                fontFamily = JetBrainsMonoFontFamily,
                fontSize = 11.sp,
                color = InkNavy
            )
            Spacer(Modifier.height(8.dp))
            MonoMetricRow("Open Work Orders", "${state.workOrders.count { it.status != WorkOrderStatus.COMPLETE }}")
            MonoMetricRow("Completed Work Orders", "${state.workOrders.count { it.status == WorkOrderStatus.COMPLETE }}")
            MonoMetricRow("Handover Lineage Count", "${state.handovers.size} versions stored")
            MonoMetricRow("Audit Events Logged", "${state.auditEvents.size} events")
        }

        IvoryCommandCard(
            title = "Bundled Simulation Scenarios (1–8)",
            subtitle = "Select any repeatable scenario to verify telemetry, faults, or offline recovery"
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                state.scenarios.forEach { scen ->
                    val active = state.runtime.scenarioId == scen.id
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = WarmIvory,
                        border = BorderStroke(if (active) 1.8.dp else 0.8.dp, BrassGold)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "${scen.number}. ${scen.title} (${scen.id})",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp
                                )
                                Text(scen.description, style = MaterialTheme.typography.bodySmall, color = InkMuted)
                            }
                            Button(
                                onClick = { onLoadScenario(scen.id) },
                                modifier = Modifier.testTag("load_scenario_${scen.id}"),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (active) BrassGold else MidnightNavy,
                                    contentColor = if (active) InkNavy else WarmIvory
                                )
                            ) {
                                Text(if (active) "Active" else "Run", fontSize = 11.sp)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun AlertsScreen(
    state: ResoluteUiState,
    onToggleReducedMotion: () -> Unit,
    onUpdateBackendConfig: (String, Boolean) -> Unit,
    onDropConflict: (Long) -> Unit,
    modifier: Modifier = Modifier
) {
    var endpointInput by remember(state.simulatorEndpointUrl) { mutableStateOf(state.simulatorEndpointUrl) }
    var preferRemote by remember(state.preferRemoteBackend) { mutableStateOf(state.preferRemoteBackend) }

    val alertAssets = state.assets.filter {
        it.operationalStatus == OperationalStatus.UNAVAILABLE ||
            it.operationalStatus == OperationalStatus.STALE ||
            it.telemetryQuality != TelemetryQuality.LIVE
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        IvoryCommandCard(
            title = "Active Equipment & Telemetry Staleness Alerts (${alertAssets.size})",
            subtitle = "Stale green indicators automatically degrade to STALE / UNKNOWN"
        ) {
            if (alertAssets.isEmpty()) {
                Text(
                    text = "No active stale-telemetry or unavailable-equipment alerts. Run Scenario 4 (Lift Unavailable) or Scenario 6 (Stale Telemetry) in Reports to demonstrate.",
                    style = MaterialTheme.typography.bodySmall,
                    color = InkMuted
                )
            } else {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    alertAssets.forEach { asset ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "${asset.id} • ${asset.operationalStatus.label}",
                                    fontFamily = JetBrainsMonoFontFamily,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp,
                                    color = StatusFaultRed
                                )
                                Text(asset.maintenanceState, style = MaterialTheme.typography.bodySmall)
                            }
                            QualityPill(asset.telemetryQuality, asset.telemetryAgeSec)
                        }
                    }
                }
            }
        }

        IvoryCommandCard(
            title = "Reliability, Offline Outbox & Conflict Queue (${state.pendingSync.size})",
            subtitle = "Idempotent mutations, version checks, and retry limits"
        ) {
            MonoMetricRow("Connection State", state.runtime.connectionMode.label)
            MonoMetricRow("Keystore AES-256-GCM", if (state.keystoreActive) "ACTIVE (Hardware/OS)" else "JVM Fallback")
            MonoMetricRow("Active Role", "${state.activeRole.displayName} (${state.activeRole.badgeCode})")
            Spacer(Modifier.height(6.dp))

            if (state.pendingSync.isEmpty()) {
                Text("Outbox clear — no pending offline mutations.", style = MaterialTheme.typography.bodySmall, color = InkMuted)
            } else {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    state.pendingSync.forEach { item ->
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = WarmIvory,
                            border = BorderStroke(1.dp, if (item.conflictMessage != null) StatusFaultRed else BrassGold)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth().padding(8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "${item.mutationType} -> ${item.targetId} (exp v${item.expectedVersion})",
                                        fontFamily = JetBrainsMonoFontFamily,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = "Key: ${item.idempotencyKey} • Retries: ${item.retryCount}/${item.maxRetries}",
                                        fontFamily = JetBrainsMonoFontFamily,
                                        fontSize = 10.sp,
                                        color = InkMuted
                                    )
                                    item.conflictMessage?.let {
                                        Text(it, fontSize = 10.sp, color = StatusFaultRed, fontWeight = FontWeight.Bold)
                                    }
                                }
                                OutlinedButton(onClick = { onDropConflict(item.id) }) {
                                    Text("Discard", fontSize = 11.sp, color = StatusFaultRed)
                                }
                            }
                        }
                    }
                }
            }
        }

        IvoryCommandCard(
            title = "Python FastAPI Backend & Accessibility Settings",
            subtitle = "Replaceable REST API client & Reduced Motion"
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("Reduced Motion Mode", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                    Text("Disables continuous pulse and tug interpolation animations", style = MaterialTheme.typography.bodySmall, color = InkMuted)
                }
                Switch(
                    checked = state.reducedMotion,
                    onCheckedChange = { onToggleReducedMotion() },
                    modifier = Modifier.testTag("reduced_motion_switch")
                )
            }
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(
                value = endpointInput,
                onValueChange = { endpointInput = it },
                label = { Text("FastAPI Simulator URL (e.g. http://10.0.2.2:8000/)") },
                modifier = Modifier.fillMaxWidth()
            )
            Row(
                modifier = Modifier.fillMaxWidth().padding(top = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Prefer Remote FastAPI Backend", fontSize = 13.sp)
                Switch(checked = preferRemote, onCheckedChange = { preferRemote = it })
            }
            Spacer(Modifier.height(6.dp))
            Button(
                onClick = { onUpdateBackendConfig(endpointInput, preferRemote) },
                modifier = Modifier.testTag("apply_backend_config_btn"),
                colors = ButtonDefaults.buttonColors(containerColor = MidnightNavy, contentColor = BrassGold)
            ) {
                Text("Apply & Probe Backend")
            }
        }

        NavalDarkPanel(title = "System Boundary Statement") {
            Text(
                text = "Aureom.AI Maritime Systems • HMS RESOLUTE Admiral Class Executive Command is an information, maintenance, and administrative coordination terminal. All shipboard data is fictional simulation data. Weapons control, targeting, combat planning, flight release, and machinery actuation remain strictly outside this application.",
                style = MaterialTheme.typography.bodySmall,
                color = WarmIvory
            )
        }
    }
}
