package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.assets.AuditLogEntry
import com.example.assets.AvailabilityComputation
import com.example.assets.CarrierAsset
import com.example.assets.ConnectionMode
import com.example.assets.DeckLevel
import com.example.assets.DepartmentPersonnelSummary
import com.example.assets.LogisticsRecord
import com.example.assets.OperationalStatus
import com.example.assets.PendingSyncItem
import com.example.assets.ShiftHandoverRecord
import com.example.assets.TaskPriority
import com.example.assets.TelemetryObservation
import com.example.assets.TelemetryQuality
import com.example.assets.ViewProjectionMode
import com.example.assets.WorkOrder
import com.example.assets.WorkOrderReviewEntry
import com.example.assets.WorkOrderStatus
import com.example.data.ResoluteRepository
import com.example.data.SeedData
import com.example.data.SimulationScenario
import com.example.engineering.AvailabilityCalculator
import com.example.security.AuthorizationGuard
import com.example.security.KeystoreCredentialVault
import com.example.security.OperatorRole
import com.example.shipview.ShipViewportTransform
import com.example.simulation.SimulationEngine
import com.example.simulation.SimulationRuntimeState
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import org.json.JSONObject
import java.util.UUID

enum class NavDestination(val route: String, val label: String) {
    OVERVIEW("overview", "Overview"),
    NAVIGATION("navigation", "Navigation"),
    AVIATION("aviation", "Aviation"),
    ENGINEERING("engineering", "Engineering"),
    PERSONNEL("personnel", "Personnel"),
    LOGISTICS("logistics", "Logistics"),
    REPORTS("reports", "Reports"),
    ALERTS("alerts", "Alerts")
}

data class ResoluteUiState(
    val runtime: SimulationRuntimeState = SimulationRuntimeState(),
    val assets: List<CarrierAsset> = emptyList(),
    val workOrders: List<WorkOrder> = emptyList(),
    val telemetry: List<TelemetryObservation> = emptyList(),
    val handovers: List<ShiftHandoverRecord> = emptyList(),
    val auditEvents: List<AuditLogEntry> = emptyList(),
    val logistics: List<LogisticsRecord> = emptyList(),
    val pendingSync: List<PendingSyncItem> = emptyList(),
    val personnelDepartments: List<DepartmentPersonnelSummary> = SeedData.initialPersonnelDepartments(),
    val scenarios: List<SimulationScenario> = SeedData.scenarios,
    val activeRole: OperatorRole = OperatorRole.DEPARTMENT_SUPERVISOR,
    val operatorCallsign: String = "CDR H. VANE",
    val keystoreActive: Boolean = false,
    val activeDeck: DeckLevel = DeckLevel.FLIGHT_DECK,
    val viewMode: ViewProjectionMode = ViewProjectionMode.TOP,
    val viewport: ShipViewportTransform = ShipViewportTransform(),
    val motionEnabled: Boolean = true,
    val reducedMotion: Boolean = false,
    val isAppForeground: Boolean = true,
    val selectedAssetId: String? = null,
    val selectedWorkOrderId: String? = null,
    val aircraftAvailability: AvailabilityComputation = AvailabilityCalculator.computeAircraftMaintenanceAvailability(emptyList()),
    val engineeringAvailability: AvailabilityComputation = AvailabilityCalculator.computeEngineeringAvailability(emptyList()),
    val bannerFeedback: String? = null,
    val isFeedbackError: Boolean = false,
    val simulatorEndpointUrl: String = "http://10.0.2.2:8000/",
    val preferRemoteBackend: Boolean = false
)

class ResoluteViewModel(application: Application) : AndroidViewModel(application) {

    private val repo = ResoluteRepository(application)
    private val vault = KeystoreCredentialVault(application)

    private val runtimeState = MutableStateFlow(SimulationRuntimeState())
    private val uiOverlayState = MutableStateFlow(
        UiOverlay(
            activeRole = vault.loadRole(),
            operatorCallsign = vault.loadOperatorCallsign(),
            keystoreActive = vault.isHardwareKeystoreActive()
        )
    )

    private data class UiOverlay(
        val activeRole: OperatorRole,
        val operatorCallsign: String,
        val keystoreActive: Boolean,
        val activeDeck: DeckLevel = DeckLevel.FLIGHT_DECK,
        val viewMode: ViewProjectionMode = ViewProjectionMode.TOP,
        val viewport: ShipViewportTransform = ShipViewportTransform(),
        val isAppForeground: Boolean = true,
        val selectedAssetId: String? = null,
        val selectedWorkOrderId: String? = null,
        val bannerFeedback: String? = null,
        val isFeedbackError: Boolean = false
    )

    val uiState: StateFlow<ResoluteUiState> = combine(
        runtimeState,
        repo.assetsFlow,
        repo.workOrdersFlow,
        repo.telemetryFlow,
        repo.handoversFlow,
        repo.auditEventsFlow,
        repo.logisticsFlow,
        repo.pendingSyncFlow,
        repo.preferencesFlow,
        uiOverlayState
    ) { values ->
        @Suppress("UNCHECKED_CAST")
        val runtime = values[0] as SimulationRuntimeState
        @Suppress("UNCHECKED_CAST")
        val assets = values[1] as List<CarrierAsset>
        @Suppress("UNCHECKED_CAST")
        val orders = values[2] as List<WorkOrder>
        @Suppress("UNCHECKED_CAST")
        val telemetry = values[3] as List<TelemetryObservation>
        @Suppress("UNCHECKED_CAST")
        val handovers = values[4] as List<ShiftHandoverRecord>
        @Suppress("UNCHECKED_CAST")
        val audits = values[5] as List<AuditLogEntry>
        @Suppress("UNCHECKED_CAST")
        val logistics = values[6] as List<LogisticsRecord>
        @Suppress("UNCHECKED_CAST")
        val pending = values[7] as List<PendingSyncItem>
        val prefs = values[8] as com.example.data.prefs.OperatorPreferences
        val overlay = values[9] as UiOverlay

        ResoluteUiState(
            runtime = runtime.copy(playbackSpeed = prefs.playbackSpeed),
            assets = assets,
            workOrders = orders,
            telemetry = telemetry,
            handovers = handovers,
            auditEvents = audits,
            logistics = logistics,
            pendingSync = pending,
            activeRole = overlay.activeRole,
            operatorCallsign = overlay.operatorCallsign,
            keystoreActive = overlay.keystoreActive,
            activeDeck = overlay.activeDeck,
            viewMode = overlay.viewMode,
            viewport = overlay.viewport,
            motionEnabled = prefs.motionEnabled,
            reducedMotion = prefs.reducedMotion,
            isAppForeground = overlay.isAppForeground,
            selectedAssetId = overlay.selectedAssetId,
            selectedWorkOrderId = overlay.selectedWorkOrderId,
            aircraftAvailability = AvailabilityCalculator.computeAircraftMaintenanceAvailability(assets),
            engineeringAvailability = AvailabilityCalculator.computeEngineeringAvailability(assets),
            bannerFeedback = overlay.bannerFeedback,
            isFeedbackError = overlay.isFeedbackError,
            simulatorEndpointUrl = prefs.simulatorBaseUrl,
            preferRemoteBackend = prefs.preferRemoteBackend
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = ResoluteUiState()
    )

    init {
        viewModelScope.launch {
            val existingAssets = repo.assetsFlow.first()
            if (existingAssets.isEmpty()) {
                repo.seedAllFresh()
            }
            val prefs = repo.preferencesFlow.first()
            uiOverlayState.value = uiOverlayState.value.copy(
                activeDeck = runCatching { DeckLevel.valueOf(prefs.activeDeckLevel) }.getOrDefault(DeckLevel.FLIGHT_DECK),
                viewMode = runCatching { ViewProjectionMode.valueOf(prefs.activeViewMode) }.getOrDefault(ViewProjectionMode.TOP)
            )
            runtimeState.value = runtimeState.value.copy(
                scenarioId = prefs.activeScenarioId,
                playbackSpeed = prefs.playbackSpeed
            )
        }

        // Bounded simulation ticker (pauses when paused or app backgrounded)
        viewModelScope.launch {
            while (isActive) {
                val state = uiState.value
                val delayMs = (2000L / state.runtime.playbackSpeed.coerceAtLeast(0.5f)).toLong()
                delay(delayMs)
                if (!state.runtime.isPaused && state.isAppForeground && state.assets.isNotEmpty()) {
                    advanceSimulationInternal(stepSeconds = 15, logToAudit = false)
                }
            }
        }
    }

    fun setAppForeground(foreground: Boolean) {
        uiOverlayState.value = uiOverlayState.value.copy(isAppForeground = foreground)
    }

    fun dismissBanner() {
        uiOverlayState.value = uiOverlayState.value.copy(bannerFeedback = null, isFeedbackError = false)
    }

    fun selectAsset(assetId: String?) {
        uiOverlayState.value = uiOverlayState.value.copy(selectedAssetId = assetId)
    }

    fun openWorkOrder(taskId: String?) {
        uiOverlayState.value = uiOverlayState.value.copy(selectedWorkOrderId = taskId)
    }

    fun selectDeckLevel(deck: DeckLevel) {
        uiOverlayState.value = uiOverlayState.value.copy(activeDeck = deck, selectedAssetId = null)
        viewModelScope.launch {
            repo.prefsRepo.setDeckAndView(deck.name, uiOverlayState.value.viewMode.name)
        }
    }

    fun selectViewMode(mode: ViewProjectionMode) {
        uiOverlayState.value = uiOverlayState.value.copy(viewMode = mode)
        viewModelScope.launch {
            repo.prefsRepo.setDeckAndView(uiOverlayState.value.activeDeck.name, mode.name)
        }
    }

    fun updateViewport(transform: ShipViewportTransform) {
        val clampedZoom = transform.zoom.coerceIn(0.6f, 2.8f)
        uiOverlayState.value = uiOverlayState.value.copy(
            viewport = transform.copy(zoom = clampedZoom)
        )
    }

    fun zoomBy(factor: Float) {
        val current = uiOverlayState.value.viewport
        updateViewport(current.copy(zoom = current.zoom * factor))
    }

    fun panBy(dx: Float, dy: Float) {
        val current = uiOverlayState.value.viewport
        updateViewport(current.copy(panX = current.panX + dx, panY = current.panY + dy))
    }

    fun centreViewport() {
        val current = uiOverlayState.value.viewport
        updateViewport(current.copy(panX = 0f, panY = 0f))
    }

    fun resetViewport() {
        updateViewport(ShipViewportTransform())
    }

    fun toggleMotionEnabled() {
        viewModelScope.launch {
            val next = !uiState.value.motionEnabled
            repo.prefsRepo.setMotionEnabled(next)
            recordSystemAudit("PREF_MOTION", "UI-TWIN", "Motion animations ${if (next) "enabled" else "paused"}.")
        }
    }

    fun toggleReducedMotion() {
        viewModelScope.launch {
            val next = !uiState.value.reducedMotion
            repo.prefsRepo.setReducedMotion(next)
            recordSystemAudit("PREF_REDUCED_MOTION", "UI-TWIN", "Reduced-motion mode ${if (next) "enabled" else "disabled"}.")
        }
    }

    fun switchRole(role: OperatorRole) {
        val callsign = when (role) {
            OperatorRole.EXECUTIVE_VIEWER -> "CAPT R. STERLING"
            OperatorRole.MAINTENANCE_STAFF -> "PO M. THORNE"
            OperatorRole.DEPARTMENT_SUPERVISOR -> "CDR H. VANE"
            OperatorRole.ADMINISTRATOR -> "SYSADMIN K. REID"
            OperatorRole.AUDITOR -> "AUDIT C. MARLOW"
        }
        vault.storeCredentials(role, callsign, "KEYSTORE-${role.badgeCode}")
        uiOverlayState.value = uiOverlayState.value.copy(
            activeRole = role,
            operatorCallsign = callsign,
            bannerFeedback = "Active role switched to ${role.displayName} (Keystore encrypted).",
            isFeedbackError = false
        )
        viewModelScope.launch {
            recordSystemAudit("ROLE_SWITCH", role.badgeCode, "Operator role set to ${role.displayName} ($callsign).")
        }
    }

    fun toggleSimulationPause() {
        val overlay = uiOverlayState.value
        val guard = AuthorizationGuard.check(overlay.activeRole, "control simulation playback") { it.canControlSimulator }
        if (!guard.permitted) {
            emitDenied("SIM_PAUSE", "SIMULATOR", guard.reason)
            return
        }
        val nextPaused = !runtimeState.value.isPaused
        runtimeState.value = runtimeState.value.copy(isPaused = nextPaused)
        viewModelScope.launch {
            recordSystemAudit("SIM_PLAYBACK", "SIMULATOR", if (nextPaused) "Simulation paused." else "Simulation resumed.")
        }
    }

    fun setPlaybackSpeed(speed: Float) {
        val overlay = uiOverlayState.value
        val guard = AuthorizationGuard.check(overlay.activeRole, "change simulation speed") { it.canControlSimulator }
        if (!guard.permitted) {
            emitDenied("SIM_SPEED", "SIMULATOR", guard.reason)
            return
        }
        viewModelScope.launch {
            repo.prefsRepo.setPlaybackSpeed(speed)
            runtimeState.value = runtimeState.value.copy(playbackSpeed = speed)
            recordSystemAudit("SIM_SPEED", "SIMULATOR", "Playback speed set to ${speed}x.")
        }
    }

    fun stepSimulation(stepSeconds: Int = 300) {
        val overlay = uiOverlayState.value
        val guard = AuthorizationGuard.check(overlay.activeRole, "advance simulation") { it.canControlSimulator }
        if (!guard.permitted) {
            emitDenied("SIM_STEP", "SIMULATOR", guard.reason)
            return
        }
        viewModelScope.launch {
            advanceSimulationInternal(stepSeconds = stepSeconds, logToAudit = true)
            showSuccess("Simulation advanced +${stepSeconds / 60} min (${runtimeState.value.simTimeUtc}).")
        }
    }

    fun loadScenario(scenarioId: String) {
        val overlay = uiOverlayState.value
        val guard = AuthorizationGuard.check(overlay.activeRole, "switch scenario") { it.canControlSimulator }
        if (!guard.permitted) {
            emitDenied("SCENARIO_LOAD", scenarioId, guard.reason)
            return
        }
        viewModelScope.launch {
            val bundle = SimulationEngine.applyScenario(scenarioId, runtimeState.value)
            runtimeState.value = bundle.runtime
            repo.prefsRepo.setActiveScenario(scenarioId)
            repo.saveAssets(bundle.assets)
            repo.saveWorkOrders(bundle.workOrders)
            if (bundle.extraHandover != null) {
                repo.saveHandover(bundle.extraHandover, markPreviousNotLatest = true)
            }
            recordSystemAudit("SCENARIO_LOAD", scenarioId, bundle.summary)
            showSuccess(bundle.summary)
        }
    }

    fun resetSimulation() {
        val overlay = uiOverlayState.value
        val guard = AuthorizationGuard.check(overlay.activeRole, "reset simulation") { it.canControlSimulator }
        if (!guard.permitted) {
            emitDenied("SIM_RESET", "SIMULATOR", guard.reason)
            return
        }
        viewModelScope.launch {
            repo.seedAllFresh()
            runtimeState.value = SimulationRuntimeState(scenarioId = "SCEN-02")
            repo.prefsRepo.setActiveScenario("SCEN-02")
            uiOverlayState.value = uiOverlayState.value.copy(
                selectedAssetId = null,
                selectedWorkOrderId = null,
                viewport = ShipViewportTransform()
            )
            recordSystemAudit("SIM_RESET", "SIMULATOR", "Simulation state reset to baseline Scenario 2.")
            showSuccess("Simulation reset to baseline Scenario 2 (AC-04 inspection).")
        }
    }

    fun assignWorkOrderTeam(taskId: String, newTeam: String) {
        val overlay = uiOverlayState.value
        val guard = AuthorizationGuard.check(overlay.activeRole, "assign work order teams") { it.canAssignWorkOrders }
        if (!guard.permitted) {
            emitDenied("WO_ASSIGN", taskId, guard.reason)
            return
        }
        viewModelScope.launch {
            val currentOrders = repo.workOrdersFlow.first()
            val target = currentOrders.find { it.taskId == taskId } ?: return@launch
            val shortUtc = SimulationRuntimeState.formatShortUtc(runtimeState.value.simEpochSeconds)
            val nextStatus = if (target.status == WorkOrderStatus.DRAFT) WorkOrderStatus.ASSIGNED else target.status
            val updated = target.copy(
                assignedTeam = newTeam,
                status = nextStatus,
                version = target.version + 1,
                lastChangedBy = overlay.operatorCallsign,
                lastChangedUtc = shortUtc,
                dirtyPendingSync = true
            )
            repo.saveWorkOrder(updated)

            // Sync assigned team onto asset if applicable
            val assets = repo.assetsFlow.first()
            assets.find { it.id == target.assetId }?.let { asset ->
                repo.saveAsset(asset.copy(assignedTeam = newTeam, lastUpdateUtc = shortUtc))
            }

            queueMutation(
                idempotencyKey = "WO_ASSIGN_${taskId}_v${target.version}_$newTeam",
                mutationType = "WORK_ORDER_TRANSITION",
                targetId = taskId,
                expectedVersion = target.version,
                payload = JSONObject().apply {
                    put("role", overlay.activeRole.name)
                    put("targetStatus", nextStatus.name)
                    put("assignedTeam", newTeam)
                    put("actorName", overlay.operatorCallsign)
                }
            )
            recordSystemAudit("WO_ASSIGN", taskId, "Assigned $taskId (${target.assetId}) to $newTeam.")
            showSuccess("$taskId assigned to $newTeam.")
        }
    }

    fun startWorkOrder(taskId: String) {
        val overlay = uiOverlayState.value
        val guard = AuthorizationGuard.check(overlay.activeRole, "start work orders") { it.canSubmitCompletion || it.canAssignWorkOrders }
        if (!guard.permitted) {
            emitDenied("WO_START", taskId, guard.reason)
            return
        }
        viewModelScope.launch {
            val target = repo.workOrdersFlow.first().find { it.taskId == taskId } ?: return@launch
            val shortUtc = SimulationRuntimeState.formatShortUtc(runtimeState.value.simEpochSeconds)
            val updated = target.copy(
                status = WorkOrderStatus.IN_PROGRESS,
                version = target.version + 1,
                lastChangedBy = overlay.operatorCallsign,
                lastChangedUtc = shortUtc,
                dirtyPendingSync = true
            )
            repo.saveWorkOrder(updated)
            recordSystemAudit("WO_START", taskId, "Moved $taskId to In Progress.")
            showSuccess("$taskId is now In Progress.")
        }
    }

    fun updateWorkOrderChecklistAndNotes(taskId: String, completedCount: Int, notes: String, attachment: String?) {
        val overlay = uiOverlayState.value
        val guard = AuthorizationGuard.check(overlay.activeRole, "update work order progress") { it.canSubmitCompletion }
        if (!guard.permitted) {
            emitDenied("WO_UPDATE", taskId, guard.reason)
            return
        }
        viewModelScope.launch {
            val target = repo.workOrdersFlow.first().find { it.taskId == taskId } ?: return@launch
            val shortUtc = SimulationRuntimeState.formatShortUtc(runtimeState.value.simEpochSeconds)
            val nextAttachments = if (!attachment.isNullOrBlank() && !target.attachments.contains(attachment)) {
                target.attachments + attachment
            } else target.attachments
            val updated = target.copy(
                completedChecklistCount = completedCount.coerceIn(0, target.checklistItems.size),
                notes = notes,
                attachments = nextAttachments,
                version = target.version + 1,
                lastChangedBy = overlay.operatorCallsign,
                lastChangedUtc = shortUtc,
                dirtyPendingSync = true
            )
            repo.saveWorkOrder(updated)
            recordSystemAudit("WO_NOTES", taskId, "Updated checklist ($completedCount/${target.checklistItems.size}) and notes on $taskId.")
            showSuccess("Saved checklist progress on $taskId (availability unchanged until review).")
        }
    }

    /**
     * Submits inspection completion for review. Explicitly does NOT release equipment availability
     * until authorised supervisor review occurs.
     */
    fun submitInspectionCompletion(taskId: String, evidence: String, idempotencySuffix: String = UUID.randomUUID().toString()) {
        val overlay = uiOverlayState.value
        val guard = AuthorizationGuard.check(overlay.activeRole, "submit inspection completion") { it.canSubmitCompletion }
        if (!guard.permitted) {
            emitDenied("WO_SUBMIT", taskId, guard.reason)
            return
        }
        viewModelScope.launch {
            val target = repo.workOrdersFlow.first().find { it.taskId == taskId } ?: return@launch
            if (target.status == WorkOrderStatus.AWAITING_REVIEW || target.status == WorkOrderStatus.COMPLETE) {
                showError("$taskId is already ${target.status.label}; duplicate transition prevented.")
                return@launch
            }
            val shortUtc = SimulationRuntimeState.formatShortUtc(runtimeState.value.simEpochSeconds)
            val entry = WorkOrderReviewEntry(
                reviewer = overlay.operatorCallsign,
                role = overlay.activeRole.displayName,
                decision = "SUBMITTED_FOR_REVIEW",
                comment = evidence.ifBlank { "Checklist complete; submitted for authorised review." },
                timestampUtc = shortUtc
            )
            val updated = target.copy(
                status = WorkOrderStatus.AWAITING_REVIEW,
                completedChecklistCount = target.checklistItems.size,
                completionEvidence = evidence.ifBlank { target.completionEvidence },
                reviewHistory = target.reviewHistory + entry,
                version = target.version + 1,
                lastChangedBy = overlay.operatorCallsign,
                lastChangedUtc = shortUtc,
                dirtyPendingSync = true
            )
            repo.saveWorkOrder(updated)

            repo.assetsFlow.first().find { it.id == target.assetId }?.let { asset ->
                repo.saveAsset(
                    asset.copy(
                        maintenanceProgressPct = 100,
                        maintenanceState = "Inspection Complete — Awaiting Authorised Review",
                        lastUpdateUtc = shortUtc
                    )
                )
            }

            queueMutation(
                idempotencyKey = "WO_SUBMIT_${taskId}_v${target.version}_$idempotencySuffix",
                mutationType = "WORK_ORDER_TRANSITION",
                targetId = taskId,
                expectedVersion = target.version,
                payload = JSONObject().apply {
                    put("role", overlay.activeRole.name)
                    put("targetStatus", WorkOrderStatus.AWAITING_REVIEW.name)
                    put("evidence", updated.completionEvidence)
                    put("actorName", overlay.operatorCallsign)
                }
            )
            recordSystemAudit("WO_SUBMIT", taskId, "Submitted $taskId completion for review (equipment remains held until review).")
            showSuccess("$taskId submitted for review. Equipment held until authorised review.")
        }
    }

    fun performAuthorisedReview(taskId: String, approved: Boolean, comment: String) {
        val overlay = uiOverlayState.value
        val guard = AuthorizationGuard.check(overlay.activeRole, "perform authorised maintenance review") { it.canAuthoriseReview }
        if (!guard.permitted) {
            emitDenied("WO_REVIEW", taskId, guard.reason)
            return
        }
        viewModelScope.launch {
            val target = repo.workOrdersFlow.first().find { it.taskId == taskId } ?: return@launch
            if (target.status != WorkOrderStatus.AWAITING_REVIEW) {
                showError("$taskId must be Awaiting Review before authorised sign-off.")
                return@launch
            }
            val shortUtc = SimulationRuntimeState.formatShortUtc(runtimeState.value.simEpochSeconds)
            val nextStatus = if (approved) WorkOrderStatus.COMPLETE else WorkOrderStatus.REOPENED
            val entry = WorkOrderReviewEntry(
                reviewer = overlay.operatorCallsign,
                role = overlay.activeRole.displayName,
                decision = if (approved) "AUTHORISED_COMPLETE" else "REOPENED",
                comment = comment.ifBlank { if (approved) "Authorised release from maintenance hold." else "Returned for rework." },
                timestampUtc = shortUtc
            )
            val updated = target.copy(
                status = nextStatus,
                reviewHistory = target.reviewHistory + entry,
                version = target.version + 1,
                lastChangedBy = overlay.operatorCallsign,
                lastChangedUtc = shortUtc,
                dirtyPendingSync = true
            )
            repo.saveWorkOrder(updated)

            queueMutation(
                idempotencyKey = "WO_REVIEW_${taskId}_v${target.version}_${nextStatus.name}",
                mutationType = "WORK_ORDER_TRANSITION",
                targetId = taskId,
                expectedVersion = target.version,
                payload = JSONObject().apply {
                    put("role", overlay.activeRole.name)
                    put("targetStatus", nextStatus.name)
                    put("reviewComment", entry.comment)
                    put("actorName", overlay.operatorCallsign)
                }
            )
            recordSystemAudit(
                "WO_REVIEW",
                taskId,
                if (approved) "Authorised review COMPLETED for $taskId by ${overlay.operatorCallsign}."
                else "Reopened $taskId after review."
            )
            showSuccess(
                if (approved) "Authorised review signed on $taskId. Availability may now be updated."
                else "$taskId reopened for additional maintenance."
            )
        }
    }

    fun updateAssetAvailability(assetId: String, newStatus: OperationalStatus, newMaintState: String) {
        val overlay = uiOverlayState.value
        val guard = AuthorizationGuard.check(overlay.activeRole, "update equipment/aircraft availability") { it.canUpdateAvailability }
        if (!guard.permitted) {
            emitDenied("AVAIL_UPDATE", assetId, guard.reason)
            return
        }
        viewModelScope.launch {
            val asset = repo.assetsFlow.first().find { it.id == assetId } ?: return@launch
            val openOrders = repo.workOrdersFlow.first().filter {
                it.assetId == assetId &&
                    it.status != WorkOrderStatus.COMPLETE &&
                    it.status != WorkOrderStatus.CANCELLED
            }
            if (newStatus == OperationalStatus.READY && openOrders.isNotEmpty()) {
                val blockingIds = openOrders.joinToString(", ") { "${it.taskId} (${it.status.label})" }
                emitDenied(
                    "AVAIL_UPDATE",
                    assetId,
                    "Cannot mark $assetId READY while unreviewed work orders remain: $blockingIds"
                )
                return@launch
            }

            val shortUtc = SimulationRuntimeState.formatShortUtc(runtimeState.value.simEpochSeconds)
            val updated = asset.copy(
                operationalStatus = newStatus,
                maintenanceState = newMaintState.ifBlank { "Maintenance Released — Availability Updated" },
                lastUpdateUtc = shortUtc,
                telemetryAgeSec = 0,
                telemetryQuality = TelemetryQuality.LIVE
            )
            repo.saveAsset(updated)
            queueMutation(
                idempotencyKey = "AVAIL_${assetId}_${newStatus.name}_${runtimeState.value.simEpochSeconds}",
                mutationType = "ASSET_AVAILABILITY",
                targetId = assetId,
                expectedVersion = 1,
                payload = JSONObject().apply {
                    put("role", overlay.activeRole.name)
                    put("operationalStatus", newStatus.name)
                    put("maintenanceState", updated.maintenanceState)
                    put("actorName", overlay.operatorCallsign)
                }
            )
            recordSystemAudit(
                "AVAIL_UPDATE",
                assetId,
                "Updated $assetId maintenance availability to ${newStatus.label} (${updated.maintenanceState})."
            )
            showSuccess("$assetId availability updated to ${newStatus.label} (Flight release remains external).")
        }
    }

    fun createWorkOrder(
        assetId: String,
        title: String,
        description: String,
        priority: TaskPriority,
        assignedTeam: String
    ) {
        val overlay = uiOverlayState.value
        val guard = AuthorizationGuard.check(overlay.activeRole, "create maintenance work orders") {
            it.canAssignWorkOrders || it.canSubmitCompletion
        }
        if (!guard.permitted) {
            emitDenied("WO_CREATE", assetId, guard.reason)
            return
        }
        viewModelScope.launch {
            val orders = repo.workOrdersFlow.first()
            val nextNum = 420 + orders.size
            val taskId = "WO-$nextNum"
            val asset = repo.assetsFlow.first().find { it.id == assetId }
            val shortUtc = SimulationRuntimeState.formatShortUtc(runtimeState.value.simEpochSeconds)
            val newOrder = WorkOrder(
                taskId = taskId,
                assetId = assetId,
                zoneLabel = asset?.locationLabel ?: "Shipboard Compartment",
                title = title.ifBlank { "Scheduled Inspection Request" },
                description = description.ifBlank { "Maintenance request logged via Executive Command." },
                priority = priority,
                assignedTeam = assignedTeam.ifBlank { "Unassigned" },
                dueTimeUtc = "12:00:00Z",
                dependencies = emptyList(),
                status = if (assignedTeam.isBlank()) WorkOrderStatus.DRAFT else WorkOrderStatus.ASSIGNED,
                checklistItems = listOf("Inspect & isolate system", "Verify post-work integrity"),
                completedChecklistCount = 0,
                completionEvidence = "",
                notes = "Created by ${overlay.operatorCallsign}",
                attachments = emptyList(),
                reviewHistory = emptyList(),
                version = 1,
                lastChangedBy = overlay.operatorCallsign,
                lastChangedUtc = shortUtc,
                dirtyPendingSync = true
            )
            repo.saveWorkOrder(newOrder)
            recordSystemAudit("WO_CREATE", taskId, "Logged $taskId for $assetId ($title).")
            showSuccess("Created work order $taskId for $assetId.")
        }
    }

    fun recordSimulatedRelocation(assetId: String, targetX: Float, targetY: Float, locationLabel: String) {
        val overlay = uiOverlayState.value
        val guard = AuthorizationGuard.check(overlay.activeRole, "simulate deck position") { it.canControlSimulator }
        if (!guard.permitted) {
            emitDenied("SIM_RELOCATE", assetId, guard.reason)
            return
        }
        viewModelScope.launch {
            val asset = repo.assetsFlow.first().find { it.id == assetId } ?: return@launch
            val shortUtc = SimulationRuntimeState.formatShortUtc(runtimeState.value.simEpochSeconds)
            repo.saveAsset(
                asset.copy(
                    shipX = targetX.coerceIn(80f, 920f),
                    shipY = targetY.coerceIn(45f, 295f),
                    locationLabel = locationLabel,
                    isSimulatedRelocation = true,
                    lastUpdateUtc = shortUtc
                )
            )
            recordSystemAudit(
                "SIM_RELOCATE",
                assetId,
                "ILLUSTRATIVE ONLY: Simulated relocation of $assetId to $locationLabel (not a real deck movement command)."
            )
            showSuccess("Simulated relocation recorded for $assetId (illustrative only).")
        }
    }

    fun recordShiftHandover(
        outgoingTeam: String,
        incomingTeam: String,
        outstandingTasks: String,
        equipmentIssues: String,
        logisticsNotes: String,
        supersedesHandoverId: String? = null
    ) {
        val overlay = uiOverlayState.value
        val guard = AuthorizationGuard.check(overlay.activeRole, "record shift handovers") { it.canCreateHandover }
        if (!guard.permitted) {
            emitDenied("HANDOVER_CREATE", "WATCH", guard.reason)
            return
        }
        viewModelScope.launch {
            val existing = repo.handoversFlow.first()
            val nextVersion = (existing.maxOfOrNull { it.versionNumber } ?: 0) + 1
            val id = "HO-20261121-${nextVersion.toString().padStart(2, '0')}"
            val shortUtc = SimulationRuntimeState.formatShortUtc(runtimeState.value.simEpochSeconds)
            val latestPrior = supersedesHandoverId ?: existing.firstOrNull { it.isLatest }?.handoverId

            val record = ShiftHandoverRecord(
                handoverId = id,
                versionNumber = nextVersion,
                supersedesHandoverId = latestPrior,
                outgoingTeam = outgoingTeam.ifBlank { "ALPHA WATCH" },
                incomingTeam = incomingTeam.ifBlank { "BRAVO WATCH" },
                outstandingTasksSummary = outstandingTasks,
                equipmentIssuesSummary = equipmentIssues,
                logisticsNotes = logisticsNotes,
                acknowledgedBy = "${overlay.operatorCallsign} (Recorded)",
                acknowledgedUtc = shortUtc,
                createdBy = overlay.operatorCallsign,
                createdUtc = shortUtc,
                isLatest = true
            )
            repo.saveHandover(record, markPreviousNotLatest = true)
            queueMutation(
                idempotencyKey = "HO_${id}_v$nextVersion",
                mutationType = "HANDOVER_CREATE",
                targetId = id,
                expectedVersion = nextVersion,
                payload = JSONObject().apply {
                    put("role", overlay.activeRole.name)
                    put("outgoingTeam", record.outgoingTeam)
                    put("incomingTeam", record.incomingTeam)
                    put("outstandingTasks", outstandingTasks)
                    put("equipmentIssues", equipmentIssues)
                    put("logisticsNotes", logisticsNotes)
                    put("supersedesId", latestPrior ?: "")
                    put("actorName", overlay.operatorCallsign)
                }
            )
            recordSystemAudit(
                "HANDOVER_RECORD",
                id,
                "Recorded shift handover v$nextVersion ($outgoingTeam -> $incomingTeam); prior versions preserved."
            )
            showSuccess("Shift handover $id (v$nextVersion) recorded with full prior history preserved.")
        }
    }

    fun acknowledgeHandover(handoverId: String) {
        val overlay = uiOverlayState.value
        val guard = AuthorizationGuard.check(overlay.activeRole, "acknowledge shift handovers") { it.canCreateHandover }
        if (!guard.permitted) {
            emitDenied("HANDOVER_ACK", handoverId, guard.reason)
            return
        }
        viewModelScope.launch {
            val target = repo.handoversFlow.first().find { it.handoverId == handoverId } ?: return@launch
            val shortUtc = SimulationRuntimeState.formatShortUtc(runtimeState.value.simEpochSeconds)
            repo.saveHandover(
                target.copy(acknowledgedBy = overlay.operatorCallsign, acknowledgedUtc = shortUtc),
                markPreviousNotLatest = false
            )
            recordSystemAudit("HANDOVER_ACK", handoverId, "Acknowledged handover $handoverId.")
            showSuccess("Handover $handoverId acknowledged.")
        }
    }

    fun approveStoresRequest(recordId: String) {
        val overlay = uiOverlayState.value
        val guard = AuthorizationGuard.check(overlay.activeRole, "approve stores requests") { it.canApproveStores }
        if (!guard.permitted) {
            emitDenied("STORES_APPROVE", recordId, guard.reason)
            return
        }
        viewModelScope.launch {
            val target = repo.logisticsFlow.first().find { it.id == recordId } ?: return@launch
            val shortUtc = SimulationRuntimeState.formatShortUtc(runtimeState.value.simEpochSeconds)
            repo.saveLogisticsRecord(
                target.copy(status = "APPROVED", approvedBy = overlay.operatorCallsign, timestampUtc = shortUtc)
            )
            recordSystemAudit("STORES_APPROVE", recordId, "Approved logistics request $recordId (${target.description}).")
            showSuccess("Stores request $recordId approved.")
        }
    }

    fun updateBackendConfiguration(url: String, preferRemote: Boolean) {
        viewModelScope.launch {
            repo.prefsRepo.setSimulatorBaseUrl(url)
            repo.prefsRepo.setPreferRemoteBackend(preferRemote)
            if (preferRemote) {
                val reachable = repo.checkRemoteHealth(url)
                runtimeState.value = runtimeState.value.copy(
                    connectionMode = if (reachable) ConnectionMode.FASTAPI_CONNECTED else ConnectionMode.OFFLINE_CACHED
                )
                if (reachable) {
                    repo.triggerBackgroundSync()
                    showSuccess("Connected to FastAPI simulation backend at $url")
                } else {
                    showError("FastAPI backend unreachable at $url — continuing with local Room cache.")
                }
            } else {
                runtimeState.value = runtimeState.value.copy(connectionMode = ConnectionMode.LOCAL_SIMULATOR)
                showSuccess("Using deterministic in-process local simulator.")
            }
        }
    }

    fun dropPendingConflict(mutationId: Long) {
        viewModelScope.launch {
            repo.resolveConflictDropLocal(mutationId)
            recordSystemAudit("SYNC_CONFLICT_DISCARD", mutationId.toString(), "Discarded conflicting local mutation #$mutationId to preserve newer authoritative record.")
            showSuccess("Conflicting local mutation #$mutationId cleared; newer server record preserved.")
        }
    }

    private suspend fun advanceSimulationInternal(stepSeconds: Int, logToAudit: Boolean) {
        val currentAssets = repo.assetsFlow.first()
        val currentOrders = repo.workOrdersFlow.first()
        val (nextRuntime, nextAssets, nextOrders) = SimulationEngine.stepSimulation(
            runtime = runtimeState.value,
            assets = currentAssets,
            workOrders = currentOrders,
            stepSeconds = stepSeconds
        )
        runtimeState.value = nextRuntime
        repo.saveAssets(nextAssets)
        if (nextOrders != currentOrders) {
            repo.saveWorkOrders(nextOrders)
        }
        if (logToAudit) {
            recordSystemAudit("SIM_STEP", "SIMULATOR", "Advanced simulation +${stepSeconds / 60}m to ${nextRuntime.simTimeUtc}.")
        }
    }

    private suspend fun queueMutation(
        idempotencyKey: String,
        mutationType: String,
        targetId: String,
        expectedVersion: Int,
        payload: JSONObject
    ) {
        val queued = repo.enqueueIdempotentMutation(
            idempotencyKey = idempotencyKey,
            mutationType = mutationType,
            targetId = targetId,
            expectedVersion = expectedVersion,
            payload = payload,
            createdUtc = runtimeState.value.simTimeUtc
        )
        if (queued && uiState.value.preferRemoteBackend) {
            repo.triggerBackgroundSync()
        }
    }

    private suspend fun recordSystemAudit(actionType: String, targetId: String, summary: String) {
        val overlay = uiOverlayState.value
        val rt = runtimeState.value
        repo.recordAudit(
            simTimeUtc = SimulationRuntimeState.formatShortUtc(rt.simEpochSeconds),
            deviceTimeUtc = SimulationRuntimeState.currentDeviceUtc().substringAfter("T"),
            actorRole = overlay.activeRole.name,
            actorName = overlay.operatorCallsign,
            actionType = actionType,
            targetId = targetId,
            summary = summary,
            outcome = if (rt.connectionMode == ConnectionMode.OFFLINE_CACHED) "QUEUED_OFFLINE" else "SUCCESS"
        )
    }

    private fun emitDenied(actionType: String, targetId: String, reason: String) {
        uiOverlayState.value = uiOverlayState.value.copy(bannerFeedback = reason, isFeedbackError = true)
        viewModelScope.launch {
            val overlay = uiOverlayState.value
            val rt = runtimeState.value
            repo.recordAudit(
                simTimeUtc = SimulationRuntimeState.formatShortUtc(rt.simEpochSeconds),
                deviceTimeUtc = SimulationRuntimeState.currentDeviceUtc().substringAfter("T"),
                actorRole = overlay.activeRole.name,
                actorName = overlay.operatorCallsign,
                actionType = actionType,
                targetId = targetId,
                summary = reason,
                outcome = "DENIED"
            )
        }
    }

    private fun showSuccess(msg: String) {
        uiOverlayState.value = uiOverlayState.value.copy(bannerFeedback = msg, isFeedbackError = false)
    }

    private fun showError(msg: String) {
        uiOverlayState.value = uiOverlayState.value.copy(bannerFeedback = msg, isFeedbackError = true)
    }
}
