package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Midnight-Navy Surfaces
val MidnightAbyss = Color(0xFF060E1A)
val MidnightNavy = Color(0xFF0A1628)
val NavalSlate = Color(0xFF10223A)
val NavalSurfaceElevated = Color(0xFF162E4D)
val NavalBorderMuted = Color(0xFF274266)

// Warm Ivory Information Panels
val WarmIvory = Color(0xFFF6F1E6)
val WarmIvoryAlt = Color(0xFFECE4D2)
val IvoryRule = Color(0xFFD2C5AA)
val InkNavy = Color(0xFF121F33)
val InkMuted = Color(0xFF475569)

// Restrained Brass-Gold Accents & Borders
val BrassGold = Color(0xFFC6A156)
val BrassGoldMuted = Color(0xFF8C6F35)
val BrassGoldBright = Color(0xFFE3C27A)

// Tactical / Selection Cyan
val SelectionCyan = Color(0xFF28E0FF)
val SelectionCyanGlow = Color(0x4428E0FF)

// Meaningful, Colour-Independent Operational Status Tokens
val StatusReadyGreen = Color(0xFF1B8A55)
val StatusReadyGreenBg = Color(0xFFDDF3E6)
val StatusCautionAmber = Color(0xFFC97A00)
val StatusCautionAmberBg = Color(0xFFFCF0D6)
val StatusFaultRed = Color(0xFFC23636)
val StatusFaultRedBg = Color(0xFFFBE2E2)
val StatusStaleSlate = Color(0xFF607085)
val StatusStaleSlateBg = Color(0xFFE5EAF0)

// Deck & Hull Rendering Palette
val SeaWaterDeep = Color(0xFF071322)
val SeaGridLine = Color(0xFF132944)
val HullArmorDark = Color(0xFF1D2939)
val FlightDeckAsphalt = Color(0xFF273445)
val HangarDeckSteel = Color(0xFF1F2B3D)
val SystemsDeckPlate = Color(0xFF172233)
val IslandStructure = Color(0xFF334155)
val DeckMarkingIvory = Color(0xFFE9E2D0)
val FoulLineAmber = Color(0xFFE09F3E)
