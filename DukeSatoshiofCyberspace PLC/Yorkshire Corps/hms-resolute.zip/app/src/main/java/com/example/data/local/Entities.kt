package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "assets")
data class AssetEntity(
    @PrimaryKey val id: String,
    val callsign: String,
    val assetType: String,
    val category: String,
    val deckLevel: String,
    val shipX: Float,
    val shipY: Float,
    val headingDeg: Float,
    val locationLabel: String,
    val maintenanceState: String,
    val operationalStatus: String,
    val flightAuthorisationSeparateNote: String,
    val assignedTeam: String,
    val lastUpdateUtc: String,
    val telemetryAgeSec: Int,
    val telemetryQuality: String,
    val dataSource: String,
    val maintenanceProgressPct: Int,
    val simulatedPathIndex: Int,
    val isSimulatedRelocation: Boolean
)

@Entity(tableName = "work_orders")
data class WorkOrderEntity(
    @PrimaryKey val taskId: String,
    val assetId: String,
    val zoneLabel: String,
    val title: String,
    val description: String,
    val priority: String,
    val assignedTeam: String,
    val dueTimeUtc: String,
    val dependenciesCsv: String,
    val status: String,
    val checklistLines: String,
    val completedChecklistCount: Int,
    val completionEvidence: String,
    val notes: String,
    val attachmentsCsv: String,
    val reviewHistoryJson: String,
    val version: Int,
    val lastChangedBy: String,
    val lastChangedUtc: String,
    val dirtyPendingSync: Boolean
)

@Entity(tableName = "telemetry_observations")
data class TelemetryObservationEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val category: String,
    val metricKey: String,
    val label: String,
    val value: Double?,
    val unit: String,
    val isMeasured: Boolean,
    val capacityMax: Double?,
    val uncertainty: String,
    val sourceId: String,
    val timestampUtc: String,
    val ageSeconds: Int,
    val quality: String
)

@Entity(tableName = "shift_handovers")
data class ShiftHandoverEntity(
    @PrimaryKey val handoverId: String,
    val versionNumber: Int,
    val supersedesHandoverId: String?,
    val outgoingTeam: String,
    val incomingTeam: String,
    val outstandingTasksSummary: String,
    val equipmentIssuesSummary: String,
    val logisticsNotes: String,
    val acknowledgedBy: String?,
    val acknowledgedUtc: String?,
    val createdBy: String,
    val createdUtc: String,
    val isLatest: Boolean
)

@Entity(tableName = "audit_events")
data class AuditEventEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val simTimeUtc: String,
    val deviceTimeUtc: String,
    val actorRole: String,
    val actorName: String,
    val actionType: String,
    val targetId: String,
    val summary: String,
    val outcome: String
)

@Entity(tableName = "logistics_records")
data class LogisticsRecordEntity(
    @PrimaryKey val id: String,
    val kind: String,
    val itemCode: String,
    val description: String,
    val quantity: Double,
    val unit: String,
    val isMeasured: Boolean,
    val status: String,
    val requestedBy: String,
    val approvedBy: String?,
    val timestampUtc: String
)

@Entity(tableName = "pending_sync_mutations")
data class PendingSyncMutationEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val idempotencyKey: String,
    val mutationType: String,
    val targetId: String,
    val expectedVersion: Int,
    val retryCount: Int,
    val maxRetries: Int,
    val conflictMessage: String?,
    val payloadJson: String,
    val createdUtc: String
)
