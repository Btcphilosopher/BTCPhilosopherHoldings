package com.example.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.filled.Flight
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.NavigationRailItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.R
import com.example.assets.ConnectionMode
import com.example.assets.OperationalStatus
import com.example.assets.TelemetryQuality
import com.example.security.OperatorRole
import com.example.tasks.WorkOrderDetailDialog
import com.example.ui.components.AnchorEmblem
import com.example.ui.screens.AlertsScreen
import com.example.ui.screens.AviationScreen
import com.example.ui.screens.EngineeringScreen
import com.example.ui.screens.LogisticsScreen
import com.example.ui.screens.NavigationScreen
import com.example.ui.screens.OverviewScreen
import com.example.ui.screens.PersonnelScreen
import com.example.ui.screens.ReportsScreen
import com.example.ui.theme.BrassGold
import com.example.ui.theme.BrassGoldMuted
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.MidnightAbyss
import com.example.ui.theme.MidnightNavy
import com.example.ui.theme.NavalBorderMuted
import com.example.ui.theme.NavalSlate
import com.example.ui.theme.SelectionCyan
import com.example.ui.theme.StatusCautionAmber
import com.example.ui.theme.StatusFaultRed
import com.example.ui.theme.StatusReadyGreen
import com.example.ui.theme.WarmIvory

@Composable
fun ResoluteAppShell(
    viewModel: ResoluteViewModel,
    modifier: Modifier = Modifier
) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    val navController = rememberNavController()
    val backStack by navController.currentBackStackEntryAsState()
    val currentRoute = backStack?.destination?.route ?: NavDestination.OVERVIEW.route

    // Lifecycle awareness: pause background simulation & animations when app leaves foreground
    val lifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_START -> viewModel.setAppForeground(true)
                Lifecycle.Event.ON_STOP -> viewModel.setAppForeground(false)
                else -> Unit
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    val alertBadgeCount = state.assets.count {
        it.operationalStatus == OperationalStatus.UNAVAILABLE ||
            it.operationalStatus == OperationalStatus.STALE ||
            it.telemetryQuality != TelemetryQuality.LIVE
    } + state.pendingSync.count { it.conflictMessage != null }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        containerColor = MidnightAbyss,
        contentWindowInsets = WindowInsets.safeDrawing
    ) { innerPadding ->
        BoxWithConstraints(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            val isWideTablet = maxWidth >= 840.dp

            Column(modifier = Modifier.fillMaxSize()) {
                CommandHeaderBar(
                    state = state,
                    isWide = isWideTablet,
                    onTogglePause = viewModel::toggleSimulationPause,
                    onStepSim = { viewModel.stepSimulation(300) },
                    onSetSpeed = viewModel::setPlaybackSpeed,
                    onResetSim = viewModel::resetSimulation,
                    onSelectRole = viewModel::switchRole,
                    onLoadScenario = viewModel::loadScenario
                )

                AnimatedVisibility(visible = state.bannerFeedback != null) {
                    val isErr = state.isFeedbackError
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(if (isErr) StatusFaultRed else NavalSlate)
                            .border(0.8.dp, if (isErr) WarmIvory else BrassGold)
                            .padding(horizontal = 12.dp, vertical = 4.dp)
                            .testTag("feedback_banner"),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = state.bannerFeedback.orEmpty(),
                            fontFamily = JetBrainsMonoFontFamily,
                            fontSize = 11.sp,
                            color = WarmIvory,
                            modifier = Modifier.weight(1f)
                        )
                        TextButton(onClick = viewModel::dismissBanner) {
                            Text("DISMISS", color = BrassGold, fontSize = 11.sp)
                        }
                    }
                }

                if (!isWideTablet) {
                    // Compact horizontal navigation strip for phones/portrait
                    CompactTopDestinationStrip(
                        currentRoute = currentRoute,
                        alertCount = alertBadgeCount,
                        onNavigate = { route ->
                            navController.navigate(route) {
                                popUpTo(NavDestination.OVERVIEW.route) { saveState = true }
                                launchSingleTop = true
                                restoreState = true
                            }
                        }
                    )
                }

                Row(modifier = Modifier.weight(1f).fillMaxWidth()) {
                    if (isWideTablet) {
                        NavigationRail(
                            containerColor = MidnightNavy,
                            contentColor = WarmIvory,
                            modifier = Modifier
                                .fillMaxHeight()
                                .border(0.8.dp, NavalBorderMuted)
                        ) {
                            Spacer(Modifier.height(6.dp))
                            NavDestination.entries.forEach { dest ->
                                val selected = currentRoute == dest.route
                                val labelText = if (dest == NavDestination.ALERTS && alertBadgeCount > 0) {
                                    "${dest.label} ($alertBadgeCount)"
                                } else dest.label
                                NavigationRailItem(
                                    selected = selected,
                                    onClick = {
                                        navController.navigate(dest.route) {
                                            popUpTo(NavDestination.OVERVIEW.route) { saveState = true }
                                            launchSingleTop = true
                                            restoreState = true
                                        }
                                    },
                                    icon = {
                                        Icon(
                                            imageVector = destIcon(dest),
                                            contentDescription = dest.label
                                        )
                                    },
                                    label = {
                                        Text(
                                            text = labelText,
                                            fontSize = 10.sp,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                    },
                                    modifier = Modifier.testTag("nav_${dest.route}"),
                                    colors = NavigationRailItemDefaults.colors(
                                        selectedIconColor = MidnightAbyss,
                                        selectedTextColor = BrassGold,
                                        indicatorColor = BrassGold,
                                        unselectedIconColor = WarmIvory.copy(alpha = 0.78f),
                                        unselectedTextColor = WarmIvory.copy(alpha = 0.78f)
                                    )
                                )
                            }
                        }
                    }

                    NavHost(
                        navController = navController,
                        startDestination = NavDestination.OVERVIEW.route,
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxHeight()
                            .navigationBarsPadding()
                    ) {
                        composable(NavDestination.OVERVIEW.route) {
                            OverviewScreen(
                                state = state,
                                onSelectDeck = viewModel::selectDeckLevel,
                                onSelectViewMode = viewModel::selectViewMode,
                                onViewportChange = viewModel::updateViewport,
                                onZoomBy = viewModel::zoomBy,
                                onCentreView = viewModel::centreViewport,
                                onResetView = viewModel::resetViewport,
                                onToggleMotion = viewModel::toggleMotionEnabled,
                                onSelectAsset = viewModel::selectAsset,
                                onOpenWorkOrder = viewModel::openWorkOrder,
                                onUpdateAvailability = viewModel::updateAssetAvailability,
                                onSimulateRelocation = viewModel::recordSimulatedRelocation
                            )
                        }
                        composable(NavDestination.NAVIGATION.route) {
                            NavigationScreen(state = state)
                        }
                        composable(NavDestination.AVIATION.route) {
                            AviationScreen(
                                state = state,
                                onSelectAsset = { id ->
                                    viewModel.selectAsset(id)
                                    navController.navigate(NavDestination.OVERVIEW.route) {
                                        popUpTo(NavDestination.OVERVIEW.route) { inclusive = true }
                                    }
                                },
                                onOpenWorkOrder = viewModel::openWorkOrder,
                                onCreateWorkOrder = viewModel::createWorkOrder
                            )
                        }
                        composable(NavDestination.ENGINEERING.route) {
                            EngineeringScreen(
                                state = state,
                                onSubmitMaintenanceRequest = viewModel::createWorkOrder
                            )
                        }
                        composable(NavDestination.PERSONNEL.route) {
                            PersonnelScreen(
                                state = state,
                                onRecordHandover = viewModel::recordShiftHandover,
                                onAcknowledgeHandover = viewModel::acknowledgeHandover
                            )
                        }
                        composable(NavDestination.LOGISTICS.route) {
                            LogisticsScreen(
                                state = state,
                                onApproveStores = viewModel::approveStoresRequest
                            )
                        }
                        composable(NavDestination.REPORTS.route) {
                            ReportsScreen(
                                state = state,
                                onLoadScenario = viewModel::loadScenario
                            )
                        }
                        composable(NavDestination.ALERTS.route) {
                            AlertsScreen(
                                state = state,
                                onToggleReducedMotion = viewModel::toggleReducedMotion,
                                onUpdateBackendConfig = viewModel::updateBackendConfiguration,
                                onDropConflict = viewModel::dropPendingConflict
                            )
                        }
                    }
                }
            }
        }
    }

    // Global Contextual Work Order Dialog
    val openWo = state.workOrders.find { it.taskId == state.selectedWorkOrderId }
    if (openWo != null) {
        WorkOrderDetailDialog(
            workOrder = openWo,
            onDismiss = { viewModel.openWorkOrder(null) },
            onAssignTeam = viewModel::assignWorkOrderTeam,
            onStartWorkOrder = viewModel::startWorkOrder,
            onSaveChecklistAndNotes = viewModel::updateWorkOrderChecklistAndNotes,
            onSubmitForReview = { id, ev -> viewModel.submitInspectionCompletion(id, ev) },
            onAuthoriseReview = viewModel::performAuthorisedReview
        )
    }
}

@Composable
private fun CommandHeaderBar(
    state: ResoluteUiState,
    isWide: Boolean,
    onTogglePause: () -> Unit,
    onStepSim: () -> Unit,
    onSetSpeed: (Float) -> Unit,
    onResetSim: () -> Unit,
    onSelectRole: (OperatorRole) -> Unit,
    onLoadScenario: (String) -> Unit
) {
    var roleMenuOpen by remember { mutableStateOf(false) }
    var scenarioMenuOpen by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(MidnightNavy)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Left: Anchor Emblem + Authoritative Serif Title
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                AnchorEmblem(size = if (isWide) 40.dp else 32.dp, tint = BrassGold)
                Spacer(Modifier.width(10.dp))
                Column {
                    Text(
                        text = stringResource(R.string.ship_name),
                        style = if (isWide) MaterialTheme.typography.displaySmall else MaterialTheme.typography.headlineMedium,
                        color = WarmIvory,
                        maxLines = 1
                    )
                    Text(
                        text = stringResource(R.string.ship_subtitle),
                        fontFamily = JetBrainsMonoFontFamily,
                        fontSize = 10.sp,
                        color = BrassGold,
                        letterSpacing = 1.2.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }

            // Center/Right: Prominent SIMULATION MODE badge + Simulation Controls + Role + UTC Clocks
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                // Prominent SIMULATION MODE badge
                Surface(
                    shape = RoundedCornerShape(4.dp),
                    color = StatusCautionAmber.copy(alpha = 0.22f),
                    border = BorderStroke(1.2.dp, StatusCautionAmber),
                    modifier = Modifier.testTag("simulation_mode_badge")
                ) {
                    Text(
                        text = stringResource(R.string.simulation_mode_badge),
                        fontFamily = JetBrainsMonoFontFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp,
                        color = StatusCautionAmber,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }

                if (isWide) {
                    val connColor = when (state.runtime.connectionMode) {
                        ConnectionMode.LOCAL_SIMULATOR -> SelectionCyan
                        ConnectionMode.FASTAPI_CONNECTED -> StatusReadyGreen
                        ConnectionMode.OFFLINE_CACHED -> StatusFaultRed
                    }
                    Surface(
                        shape = RoundedCornerShape(4.dp),
                        color = NavalSlate,
                        border = BorderStroke(1.dp, connColor)
                    ) {
                        Text(
                            text = state.runtime.connectionMode.label,
                            fontFamily = JetBrainsMonoFontFamily,
                            fontSize = 10.sp,
                            color = connColor,
                            modifier = Modifier.padding(horizontal = 7.dp, vertical = 4.dp)
                        )
                    }

                    // Scenario Selector
                    Box {
                        Surface(
                            shape = RoundedCornerShape(4.dp),
                            color = NavalSlate,
                            border = BorderStroke(1.dp, BrassGoldMuted),
                            modifier = Modifier
                                .clickable { scenarioMenuOpen = true }
                                .testTag("header_scenario_selector")
                        ) {
                            Text(
                                text = state.runtime.scenarioId,
                                fontFamily = JetBrainsMonoFontFamily,
                                fontSize = 11.sp,
                                color = WarmIvory,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                        DropdownMenu(expanded = scenarioMenuOpen, onDismissRequest = { scenarioMenuOpen = false }) {
                            state.scenarios.forEach { sc ->
                                DropdownMenuItem(
                                    text = { Text("${sc.number}. ${sc.title}", fontSize = 12.sp) },
                                    onClick = {
                                        scenarioMenuOpen = false
                                        onLoadScenario(sc.id)
                                    }
                                )
                            }
                        }
                    }

                    // Playback Controls
                    IconButton(onClick = onTogglePause, modifier = Modifier.testTag("sim_play_pause_btn")) {
                        Icon(
                            imageVector = if (state.runtime.isPaused) Icons.Default.PlayArrow else Icons.Default.Pause,
                            contentDescription = if (state.runtime.isPaused) "Resume simulation" else "Pause simulation",
                            tint = BrassGold
                        )
                    }
                    IconButton(onClick = onStepSim, modifier = Modifier.testTag("sim_step_btn")) {
                        Icon(Icons.Default.SkipNext, contentDescription = "Advance simulation +5m", tint = SelectionCyan)
                    }
                    Surface(
                        shape = RoundedCornerShape(4.dp),
                        color = NavalSlate,
                        modifier = Modifier
                            .clickable {
                                val next = when (state.runtime.playbackSpeed) {
                                    1.0f -> 2.0f
                                    2.0f -> 5.0f
                                    else -> 1.0f
                                }
                                onSetSpeed(next)
                            }
                            .testTag("sim_speed_btn")
                    ) {
                        Text(
                            text = "${state.runtime.playbackSpeed.toInt()}x",
                            fontFamily = JetBrainsMonoFontFamily,
                            fontSize = 11.sp,
                            color = WarmIvory,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 4.dp)
                        )
                    }
                    IconButton(onClick = onResetSim, modifier = Modifier.testTag("sim_reset_btn")) {
                        Icon(Icons.Default.Refresh, contentDescription = "Reset simulation", tint = WarmIvory)
                    }
                }

                // Role Switcher
                Box {
                    Surface(
                        shape = RoundedCornerShape(4.dp),
                        color = NavalSlate,
                        border = BorderStroke(1.dp, BrassGold),
                        modifier = Modifier
                            .clickable { roleMenuOpen = true }
                            .testTag("header_role_selector")
                    ) {
                        Text(
                            text = state.activeRole.badgeCode,
                            fontFamily = JetBrainsMonoFontFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp,
                            color = BrassGold,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                    DropdownMenu(expanded = roleMenuOpen, onDismissRequest = { roleMenuOpen = false }) {
                        OperatorRole.entries.forEach { role ->
                            DropdownMenuItem(
                                text = { Text("${role.displayName} (${role.badgeCode})", fontSize = 12.sp) },
                                onClick = {
                                    roleMenuOpen = false
                                    onSelectRole(role)
                                },
                                modifier = Modifier.testTag("role_option_${role.name}")
                            )
                        }
                    }
                }

                // Separate Simulation Time & Device UTC Clocks
                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = "SIM ${state.runtime.simTimeUtc.substringAfter("T")}",
                        fontFamily = JetBrainsMonoFontFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        color = WarmIvory,
                        modifier = Modifier.testTag("header_sim_clock")
                    )
                    Text(
                        text = "DEV ${state.runtime.deviceTimeUtc.substringAfter("T")}",
                        fontFamily = JetBrainsMonoFontFamily,
                        fontSize = 10.sp,
                        color = BrassGoldMuted
                    )
                }
            }
        }
        HorizontalDivider(thickness = 1.2.dp, color = BrassGold)
    }
}

@Composable
private fun CompactTopDestinationStrip(
    currentRoute: String,
    alertCount: Int,
    onNavigate: (String) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(MidnightNavy)
            .horizontalScroll(rememberScrollState())
            .padding(horizontal = 8.dp, vertical = 6.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        NavDestination.entries.forEach { dest ->
            val selected = currentRoute == dest.route
            val label = if (dest == NavDestination.ALERTS && alertCount > 0) "${dest.label} ($alertCount)" else dest.label
            Surface(
                shape = RoundedCornerShape(4.dp),
                color = if (selected) BrassGold else NavalSlate,
                border = BorderStroke(1.dp, if (selected) BrassGold else NavalBorderMuted),
                modifier = Modifier
                    .minimumInteractiveComponentSize()
                    .testTag("compact_nav_${dest.route}")
                    .clickable { onNavigate(dest.route) }
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = destIcon(dest),
                        contentDescription = dest.label,
                        tint = if (selected) MidnightAbyss else WarmIvory,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(Modifier.width(5.dp))
                    Text(
                        text = label,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = if (selected) MidnightAbyss else WarmIvory
                    )
                }
            }
        }
    }
}

private fun destIcon(dest: NavDestination): ImageVector = when (dest) {
    NavDestination.OVERVIEW -> DashboardIcon
    NavDestination.NAVIGATION -> Icons.Default.Explore
    NavDestination.AVIATION -> Icons.Default.Flight
    NavDestination.ENGINEERING -> Icons.Default.Build
    NavDestination.PERSONNEL -> Icons.Default.Groups
    NavDestination.LOGISTICS -> Icons.Default.Inventory2
    NavDestination.REPORTS -> Icons.Default.Description
    NavDestination.ALERTS -> Icons.Default.NotificationsActive
}

private val DashboardIcon: ImageVector get() = Icons.Default.Dashboard
