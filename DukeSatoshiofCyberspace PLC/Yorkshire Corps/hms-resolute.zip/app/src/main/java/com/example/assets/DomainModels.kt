package com.example.assets

enum class DeckLevel(val label: String, val zElevation: Float) {
    FLIGHT_DECK("Deck", 90f),
    HANGAR("Hangar", 45f),
    SYSTEMS("Systems", 12f)
}

enum class ViewProjectionMode(val label: String) {
    TOP("Top"),
    ISOMETRIC("Isometric")
}

enum class AssetCategory {
    AIRCRAFT,
    HELICOPTER,
    SERVICE_VEHICLE,
    AIRCRAFT_LIFT,
    MAINTENANCE_ZONE,
    ENGINEERING_SYSTEM
}

enum class OperationalStatus(val label: String, val symbol: String) {
    READY("READY", "OK"),
    INSPECTION("INSPECTION", "INSP"),
    MAINTENANCE("MAINTENANCE", "MNT"),
    CAUTION("CAUTION", "WARN"),
    UNAVAILABLE("UNAVAILABLE", "U/S"),
    STALE("STALE / UNKNOWN", "STALE")
}

enum class TelemetryQuality(val label: String) {
    LIVE("LIVE"),
    STALE("STALE"),
    MISSING("MISSING"),
    DISCONNECTED("OFFLINE")
}

enum class WorkOrderStatus(val label: String) {
    DRAFT("Draft"),
    ASSIGNED("Assigned"),
    IN_PROGRESS("In Progress"),
    AWAITING_REVIEW("Awaiting Review"),
    COMPLETE("Complete"),
    BLOCKED("Blocked"),
    CANCELLED("Cancelled"),
    REOPENED("Reopened")
}

enum class TaskPriority(val label: String, val rank: Int) {
    ROUTINE("Routine", 1),
    URGENT("Urgent", 2),
    CRITICAL("Critical", 3)
}

enum class ConnectionMode(val label: String) {
    LOCAL_SIMULATOR("SIMULATION ENGINE (LOCAL)"),
    FASTAPI_CONNECTED("FASTAPI BACKEND LIVE"),
    OFFLINE_CACHED("OFFLINE / CACHED")
}

data class CarrierAsset(
    val id: String,
    val callsign: String,
    val assetType: String,
    val category: AssetCategory,
    val deckLevel: DeckLevel,
    val shipX: Float,
    val shipY: Float,
    val headingDeg: Float,
    val locationLabel: String,
    val maintenanceState: String,
    val operationalStatus: OperationalStatus,
    val flightAuthorisationSeparateNote: String,
    val assignedTeam: String,
    val lastUpdateUtc: String,
    val telemetryAgeSec: Int,
    val telemetryQuality: TelemetryQuality,
    val dataSource: String,
    val maintenanceProgressPct: Int,
    val simulatedPathIndex: Int = 0,
    val isSimulatedRelocation: Boolean = false
)

data class WorkOrderReviewEntry(
    val reviewer: String,
    val role: String,
    val decision: String,
    val comment: String,
    val timestampUtc: String
)

data class WorkOrder(
    val taskId: String,
    val assetId: String,
    val zoneLabel: String,
    val title: String,
    val description: String,
    val priority: TaskPriority,
    val assignedTeam: String,
    val dueTimeUtc: String,
    val dependencies: List<String>,
    val status: WorkOrderStatus,
    val checklistItems: List<String>,
    val completedChecklistCount: Int,
    val completionEvidence: String,
    val notes: String,
    val attachments: List<String>,
    val reviewHistory: List<WorkOrderReviewEntry>,
    val version: Int,
    val lastChangedBy: String,
    val lastChangedUtc: String,
    val dirtyPendingSync: Boolean = false
)

data class TelemetryObservation(
    val id: Long = 0,
    val category: String,
    val metricKey: String,
    val label: String,
    val value: Double?,
    val unit: String,
    val isMeasured: Boolean,
    val capacityMax: Double?,
    val uncertainty: String,
    val sourceId: String,
    val timestampUtc: String,
    val ageSeconds: Int,
    val quality: TelemetryQuality
)

data class NavigationWeatherState(
    val positionSource: String,
    val latitudeDisplay: String,
    val longitudeDisplay: String,
    val headingDeg: Double,
    val courseOverGroundDeg: Double,
    val speedThroughWaterKnots: Double,
    val speedOverGroundKnots: Double,
    val speedUncertaintyKnots: Double,
    val windDirectionDeg: Int,
    val windSpeedKnots: Int,
    val visibilityNm: Double,
    val seaStateCode: Int,
    val seaStateDescription: String,
    val nextWaypointName: String,
    val nextWaypointEtaUtc: String,
    val waypointDistanceNm: Double,
    val routeProgressRatio: Float,
    val timestampUtc: String,
    val ageSeconds: Int,
    val quality: TelemetryQuality
)

data class DepartmentPersonnelSummary(
    val departmentCode: String,
    val departmentName: String,
    val totalAssigned: Int,
    val onWatch: Int,
    val offWatch: Int,
    val medicalOrLeave: Int,
    val restrictedRosterSample: List<String> // Only exposed when Role.canViewIndividualPersonnel == true
)

data class LogisticsRecord(
    val id: String,
    val kind: String, // STORES_REQUEST, REPLENISHMENT, INVENTORY_MOVEMENT
    val itemCode: String,
    val description: String,
    val quantity: Double,
    val unit: String,
    val isMeasured: Boolean,
    val status: String,
    val requestedBy: String,
    val approvedBy: String?,
    val timestampUtc: String
)

data class ShiftHandoverRecord(
    val handoverId: String,
    val versionNumber: Int,
    val supersedesHandoverId: String?,
    val outgoingTeam: String,
    val incomingTeam: String,
    val outstandingTasksSummary: String,
    val equipmentIssuesSummary: String,
    val logisticsNotes: String,
    val acknowledgedBy: String?,
    val acknowledgedUtc: String?,
    val createdBy: String,
    val createdUtc: String,
    val isLatest: Boolean
)

data class AuditLogEntry(
    val id: Long,
    val simTimeUtc: String,
    val deviceTimeUtc: String,
    val actorRole: String,
    val actorName: String,
    val actionType: String,
    val targetId: String,
    val summary: String,
    val outcome: String
)

data class PendingSyncItem(
    val id: Long,
    val idempotencyKey: String,
    val mutationType: String,
    val targetId: String,
    val expectedVersion: Int,
    val retryCount: Int,
    val maxRetries: Int,
    val conflictMessage: String?,
    val createdUtc: String
)

data class AvailabilityComputation(
    val label: String,
    val availableUnits: Int,
    val totalUnits: Int,
    val staleOrUnknownUnits: Int,
    val percentage: Double?,
    val formulaExplanation: String,
    val quality: TelemetryQuality
)
