package com.example.shipview

import androidx.compose.ui.geometry.Offset
import com.example.assets.CarrierAsset
import com.example.assets.DeckLevel
import com.example.assets.ViewProjectionMode
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.min
import kotlin.math.sin

data class ShipViewportTransform(
    val zoom: Float = 1.0f,
    val panX: Float = 0f,
    val panY: Float = 0f,
    val rotationDeg: Float = 0f
)

/**
 * Single authoritative coordinate model for HMS RESOLUTE digital twin.
 * Ship-space dimensions:
 *   X: 0f (stern) -> 1000f (bow ski-jump)
 *   Y: 0f (port beam) -> 340f (starboard beam)
 *   Z: 12f (Systems) -> 45f (Hangar) -> 90f (Flight Deck) -> 118f (Islands)
 *
 * Both Canvas rendering and pointer hit-testing share these exact projection and inverse functions.
 */
object ShipCoordinateModel {
    const val SHIP_LENGTH = 1000f
    const val SHIP_BEAM = 340f
    const val CENTER_X = 500f
    const val CENTER_Y = 170f
    const val BASE_Z = 45f

    // Isometric axonometric basis constants (explicitly defined projection)
    private const val ISO_COS = 0.8944272f  // cos(26.565 deg)
    private const val ISO_SIN = 0.4472136f  // sin(26.565 deg) -> 2:1 isometric ratio
    private const val ISO_Z_SCALE = 0.78f

    fun project(
        shipX: Float,
        shipY: Float,
        shipZ: Float,
        viewMode: ViewProjectionMode,
        transform: ShipViewportTransform,
        canvasWidth: Float,
        canvasHeight: Float
    ): Offset {
        if (canvasWidth <= 0f || canvasHeight <= 0f) return Offset.Zero

        val dx = shipX - CENTER_X
        val dy = shipY - CENTER_Y
        val dz = shipZ - BASE_Z

        // Optional viewport rotation around ship center
        val rad = Math.toRadians(transform.rotationDeg.toDouble())
        val c = cos(rad).toFloat()
        val s = sin(rad).toFloat()
        val rx = dx * c - dy * s
        val ry = dx * s + dy * c

        val (projX, projY) = when (viewMode) {
            ViewProjectionMode.TOP -> rx to ry
            ViewProjectionMode.ISOMETRIC -> {
                val ix = (rx - ry) * ISO_COS * 0.72f
                val iy = (rx + ry) * ISO_SIN * 0.72f - dz * ISO_Z_SCALE
                ix to iy
            }
        }

        val baseScale = computeBaseScale(viewMode, canvasWidth, canvasHeight)
        val totalScale = baseScale * transform.zoom

        val screenX = canvasWidth * 0.5f + transform.panX + projX * totalScale
        val screenY = canvasHeight * 0.5f + transform.panY + projY * totalScale
        return Offset(screenX, screenY)
    }

    /**
     * Exact inverse projection onto a horizontal deck plane (shipZ = constant).
     * Guarantees accurate coordinate recovery under any zoom, pan, rotation, or projection mode.
     */
    fun unprojectToDeckPlane(
        screenPoint: Offset,
        shipZ: Float,
        viewMode: ViewProjectionMode,
        transform: ShipViewportTransform,
        canvasWidth: Float,
        canvasHeight: Float
    ): Offset {
        if (canvasWidth <= 0f || canvasHeight <= 0f) return Offset(CENTER_X, CENTER_Y)

        val baseScale = computeBaseScale(viewMode, canvasWidth, canvasHeight)
        val totalScale = (baseScale * transform.zoom).coerceAtLeast(0.001f)

        val projX = (screenPoint.x - canvasWidth * 0.5f - transform.panX) / totalScale
        val projY = (screenPoint.y - canvasHeight * 0.5f - transform.panY) / totalScale
        val dz = shipZ - BASE_Z

        val (rx, ry) = when (viewMode) {
            ViewProjectionMode.TOP -> projX to projY
            ViewProjectionMode.ISOMETRIC -> {
                val adjY = projY + dz * ISO_Z_SCALE
                val a = projX / (ISO_COS * 0.72f)
                val b = adjY / (ISO_SIN * 0.72f)
                val x = (a + b) * 0.5f
                val y = (b - a) * 0.5f
                x to y
            }
        }

        // Inverse rotation
        val rad = Math.toRadians(-transform.rotationDeg.toDouble())
        val c = cos(rad).toFloat()
        val s = sin(rad).toFloat()
        val dx = rx * c - ry * s
        val dy = rx * s + ry * c

        return Offset(dx + CENTER_X, dy + CENTER_Y)
    }

    fun computeBaseScale(
        viewMode: ViewProjectionMode,
        canvasWidth: Float,
        canvasHeight: Float
    ): Float {
        return when (viewMode) {
            ViewProjectionMode.TOP -> min(canvasWidth / 1120f, canvasHeight / 430f)
            ViewProjectionMode.ISOMETRIC -> min(canvasWidth / 1160f, canvasHeight / 540f)
        }.coerceAtLeast(0.1f)
    }

    /**
     * Authoritative hit-test in ship-plane space using exact unprojection onto the active deck plane,
     * ensuring hit accuracy across TOP/ISOMETRIC, zoom, pan, and rotation.
     */
    fun hitTestAsset(
        tapOffset: Offset,
        activeDeck: DeckLevel,
        assets: List<CarrierAsset>,
        viewMode: ViewProjectionMode,
        transform: ShipViewportTransform,
        canvasWidth: Float,
        canvasHeight: Float,
        hitRadiusShipUnits: Float = 42f
    ): CarrierAsset? {
        val visibleAssets = assets.filter { it.deckLevel == activeDeck }
        val shipTap = unprojectToDeckPlane(
            screenPoint = tapOffset,
            shipZ = activeDeck.zElevation,
            viewMode = viewMode,
            transform = transform,
            canvasWidth = canvasWidth,
            canvasHeight = canvasHeight
        )

        return visibleAssets
            .map { asset ->
                val dist = hypot(shipTap.x - asset.shipX, shipTap.y - asset.shipY)
                asset to dist
            }
            .filter { (_, dist) -> dist <= hitRadiusShipUnits }
            .minByOrNull { (_, dist) -> dist }
            ?.first
    }
}
