package com.example.simulation

import com.example.assets.AssetCategory
import com.example.assets.AuditLogEntry
import com.example.assets.CarrierAsset
import com.example.assets.ConnectionMode
import com.example.assets.NavigationWeatherState
import com.example.assets.OperationalStatus
import com.example.assets.ShiftHandoverRecord
import com.example.assets.TelemetryObservation
import com.example.assets.TelemetryQuality
import com.example.assets.WorkOrder
import com.example.assets.WorkOrderReviewEntry
import com.example.assets.WorkOrderStatus
import com.example.data.SeedData
import com.example.engineering.AvailabilityCalculator
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import kotlin.math.roundToInt

data class SimulationRuntimeState(
    val simEpochSeconds: Long = 1795248000L, // 2026-11-21T08:00:00Z
    val simTimeUtc: String = SeedData.INITIAL_SIM_TIME_UTC,
    val deviceTimeUtc: String = currentDeviceUtc(),
    val scenarioId: String = "SCEN-02",
    val isPaused: Boolean = false,
    val playbackSpeed: Float = 1.0f,
    val tickCount: Int = 0,
    val connectionMode: ConnectionMode = ConnectionMode.LOCAL_SIMULATOR,
    val navWeather: NavigationWeatherState = SeedData.initialNavWeather(),
    val personnelAboardTotal: Int = 726,
    val personnelOnWatch: Int = 280
) {
    companion object {
        fun currentDeviceUtc(): String {
            val fmt = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US)
            fmt.timeZone = TimeZone.getTimeZone("UTC")
            return fmt.format(Date())
        }

        fun formatSimTime(epochSeconds: Long): String {
            val fmt = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US)
            fmt.timeZone = TimeZone.getTimeZone("UTC")
            return fmt.format(Date(epochSeconds * 1000L))
        }

        fun formatShortUtc(epochSeconds: Long): String {
            val fmt = SimpleDateFormat("HH:mm:ss'Z'", Locale.US)
            fmt.timeZone = TimeZone.getTimeZone("UTC")
            return fmt.format(Date(epochSeconds * 1000L))
        }
    }
}

/**
 * Deterministic in-process carrier simulator implementing all 8 demonstration scenarios,
 * telemetry staleness aging, illustrative service-vehicle waypoints, and AC-04 inspection progression.
 */
object SimulationEngine {

    private val tug01Path = listOf(
        590f to 205f,
        540f to 175f,
        490f to 155f,
        540f to 145f,
        610f to 160f,
        625f to 195f
    )

    private val tug02SupportPath = listOf(
        355f to 212f,
        375f to 220f,
        390f to 225f,
        378f to 218f
    )

    fun stepSimulation(
        runtime: SimulationRuntimeState,
        assets: List<CarrierAsset>,
        workOrders: List<WorkOrder>,
        stepSeconds: Int
    ): Triple<SimulationRuntimeState, List<CarrierAsset>, List<WorkOrder>> {
        val nextEpoch = runtime.simEpochSeconds + stepSeconds
        val nextTimeStr = SimulationRuntimeState.formatSimTime(nextEpoch)
        val shortUtc = SimulationRuntimeState.formatShortUtc(nextEpoch)
        val nextTick = runtime.tickCount + 1

        val isStaleScenario = runtime.scenarioId == "SCEN-06"
        val isOfflineScenario = runtime.scenarioId == "SCEN-08"

        val updatedAssets = assets.map { asset ->
            var nextAsset = asset

            // Illustrative deterministic tug motion along deck paths (never issues real deck commands)
            if (asset.id == "TUG-01") {
                val idx = (asset.simulatedPathIndex + 1) % tug01Path.size
                val (nx, ny) = tug01Path[idx]
                nextAsset = nextAsset.copy(
                    shipX = nx,
                    shipY = ny,
                    simulatedPathIndex = idx,
                    lastUpdateUtc = shortUtc,
                    telemetryAgeSec = 4
                )
            } else if (asset.id == "TUG-02") {
                val idx = (asset.simulatedPathIndex + 1) % tug02SupportPath.size
                val (nx, ny) = tug02SupportPath[idx]
                nextAsset = nextAsset.copy(
                    shipX = nx,
                    shipY = ny,
                    simulatedPathIndex = idx,
                    lastUpdateUtc = shortUtc,
                    telemetryAgeSec = 6
                )
            }

            // Advance AC-04 maintenance progress deterministically when inspection is in progress
            if (asset.id == "AC-04" && asset.operationalStatus == OperationalStatus.MAINTENANCE) {
                val wo404 = workOrders.find { it.taskId == "WO-404" }
                if (wo404 != null && wo404.status == WorkOrderStatus.IN_PROGRESS) {
                    val newPct = (asset.maintenanceProgressPct + 8).coerceAtMost(95)
                    nextAsset = nextAsset.copy(
                        maintenanceProgressPct = newPct,
                        lastUpdateUtc = shortUtc,
                        telemetryAgeSec = 10
                    )
                }
            }

            // Telemetry aging & staleness degradation rule
            if (isStaleScenario && (asset.id == "GT-2" || asset.id == "HV-BUS-B" || asset.id == "RO-PLANT-1")) {
                val agedSec = asset.telemetryAgeSec + stepSeconds + 120
                nextAsset = nextAsset.copy(
                    telemetryAgeSec = agedSec,
                    telemetryQuality = TelemetryQuality.STALE
                )
                nextAsset = AvailabilityCalculator.applyStalenessDegradation(nextAsset)
            } else if (isOfflineScenario) {
                val agedSec = asset.telemetryAgeSec + stepSeconds
                val q = if (agedSec > AvailabilityCalculator.STALE_THRESHOLD_SECONDS) {
                    TelemetryQuality.DISCONNECTED
                } else asset.telemetryQuality
                nextAsset = AvailabilityCalculator.applyStalenessDegradation(
                    nextAsset.copy(telemetryAgeSec = agedSec, telemetryQuality = q)
                )
            } else if (nextAsset.telemetryQuality == TelemetryQuality.LIVE) {
                nextAsset = nextAsset.copy(
                    lastUpdateUtc = shortUtc,
                    telemetryAgeSec = ((nextTick * 3 + asset.id.hashCode()) and 0x1F).coerceAtLeast(4)
                )
            }

            nextAsset
        }

        // Update nav & weather smoothly
        val nav = runtime.navWeather
        val distanceCovered = (nav.speedOverGroundKnots * (stepSeconds / 3600.0))
        val newDist = (nav.waypointDistanceNm - distanceCovered).coerceAtLeast(0.5)
        val newProgress = (nav.routeProgressRatio + (distanceCovered.toFloat() / 160f)).coerceAtMost(0.99f)
        val nextNav = nav.copy(
            waypointDistanceNm = (newDist * 10.0).roundToInt() / 10.0,
            routeProgressRatio = newProgress,
            timestampUtc = shortUtc,
            ageSeconds = if (isOfflineScenario) nav.ageSeconds + stepSeconds else 8,
            quality = if (isOfflineScenario && nav.ageSeconds + stepSeconds > 180) {
                TelemetryQuality.STALE
            } else if (isOfflineScenario) {
                TelemetryQuality.DISCONNECTED
            } else {
                TelemetryQuality.LIVE
            }
        )

        val nextRuntime = runtime.copy(
            simEpochSeconds = nextEpoch,
            simTimeUtc = nextTimeStr,
            deviceTimeUtc = SimulationRuntimeState.currentDeviceUtc(),
            tickCount = nextTick,
            navWeather = nextNav
        )

        return Triple(nextRuntime, updatedAssets, workOrders)
    }

    fun applyScenario(
        scenarioId: String,
        currentRuntime: SimulationRuntimeState
    ): ScenarioBundle {
        val baseAssets = SeedData.initialAssets().toMutableList()
        val baseOrders = SeedData.initialWorkOrders().toMutableList()
        var nav = SeedData.initialNavWeather()
        var connMode = ConnectionMode.LOCAL_SIMULATOR
        val shortUtc = SimulationRuntimeState.formatShortUtc(currentRuntime.simEpochSeconds)
        var extraHandover: ShiftHandoverRecord? = null
        var scenarioEventSummary = "Loaded Scenario $scenarioId"

        when (scenarioId) {
            "SCEN-01" -> {
                // Normal Operations: AC-04 ready too
                val idx = baseAssets.indexOfFirst { it.id == "AC-04" }
                if (idx >= 0) {
                    baseAssets[idx] = baseAssets[idx].copy(
                        operationalStatus = OperationalStatus.READY,
                        maintenanceState = "Serviceable — Normal Ops",
                        maintenanceProgressPct = 100
                    )
                }
                scenarioEventSummary = "Scenario 1: Normal Operations baseline restored."
            }
            "SCEN-02" -> {
                // Reference AC-04 Inspection in progress
                scenarioEventSummary = "Scenario 2: AC-04 Maintenance — Inspection in progress — Team E-2."
            }
            "SCEN-03" -> {
                // Service vehicle TUG-02 actively tasked near AC-04
                val tugIdx = baseAssets.indexOfFirst { it.id == "TUG-02" }
                if (tugIdx >= 0) {
                    baseAssets[tugIdx] = baseAssets[tugIdx].copy(
                        shipX = 388f,
                        shipY = 224f,
                        operationalStatus = OperationalStatus.CAUTION,
                        maintenanceState = "Active Task: Tow Support for AC-04 (WO-409)",
                        assignedTeam = "Team E-2"
                    )
                }
                scenarioEventSummary = "Scenario 3: Service vehicle TUG-02 assigned to AC-04 deck support."
            }
            "SCEN-04" -> {
                // Aft lift becomes unavailable
                val liftIdx = baseAssets.indexOfFirst { it.id == "LIFT-AFT" }
                if (liftIdx >= 0) {
                    baseAssets[liftIdx] = baseAssets[liftIdx].copy(
                        operationalStatus = OperationalStatus.UNAVAILABLE,
                        maintenanceState = "UNAVAILABLE — Hydraulic Interlock Fault #L2-09",
                        maintenanceProgressPct = 15,
                        lastUpdateUtc = shortUtc
                    )
                }
                val woIdx = baseOrders.indexOfFirst { it.taskId == "WO-415" }
                if (woIdx >= 0) {
                    baseOrders[woIdx] = baseOrders[woIdx].copy(
                        status = WorkOrderStatus.BLOCKED,
                        notes = "Escalated: safety interlock fault detected on Aft Lift."
                    )
                }
                scenarioEventSummary = "Scenario 4: LIFT-AFT marked UNAVAILABLE due to safety interlock fault."
            }
            "SCEN-05" -> {
                // Weather update
                nav = nav.copy(
                    windDirectionDeg = 310,
                    windSpeedKnots = 28,
                    visibilityNm = 4.2,
                    seaStateCode = 5,
                    seaStateDescription = "Rough (2.5–4.0m swell, pitch caution)",
                    speedThroughWaterKnots = 16.2,
                    speedOverGroundKnots = 15.6,
                    timestampUtc = shortUtc
                )
                scenarioEventSummary = "Scenario 5: Weather advisory updated — Wind 310°/28kt, Sea State 5."
            }
            "SCEN-06" -> {
                // Stale engineering telemetry: green indicators degrade to STALE/UNKNOWN
                for (i in baseAssets.indices) {
                    val a = baseAssets[i]
                    if (a.id == "GT-2" || a.id == "HV-BUS-B" || a.id == "RO-PLANT-1") {
                        baseAssets[i] = AvailabilityCalculator.applyStalenessDegradation(
                            a.copy(
                                telemetryAgeSec = 245,
                                telemetryQuality = TelemetryQuality.STALE,
                                dataSource = "IPMS Read-Only Adapter (LINK TIMEOUT)"
                            )
                        )
                    }
                }
                scenarioEventSummary = "Scenario 6: Stale telemetry simulated on GT-2, HV-BUS-B, RO-PLANT-1."
            }
            "SCEN-07" -> {
                extraHandover = ShiftHandoverRecord(
                    handoverId = "HO-20261121-02",
                    versionNumber = 2,
                    supersedesHandoverId = "HO-20261121-01",
                    outgoingTeam = "ALPHA WATCH",
                    incomingTeam = "BRAVO WATCH",
                    outstandingTasksSummary = "AC-04 inspection (WO-404) nearing completion; WO-412 Merlin oil analysis awaiting review.",
                    equipmentIssuesSummary = "Monitor Aft Lift interlock checks; all GT alternators nominal.",
                    logisticsNotes = "REQ-901 seal kit pending supervisor approval.",
                    acknowledgedBy = null,
                    acknowledgedUtc = null,
                    createdBy = "CDR H. Vane",
                    createdUtc = shortUtc,
                    isLatest = true
                )
                scenarioEventSummary = "Scenario 7: Watch shift handover ALPHA -> BRAVO staged for acknowledgement."
            }
            "SCEN-08" -> {
                connMode = ConnectionMode.OFFLINE_CACHED
                nav = nav.copy(
                    ageSeconds = 210,
                    quality = TelemetryQuality.DISCONNECTED
                )
                scenarioEventSummary = "Scenario 8: Backend link lost — operating on cached Room state with offline outbox."
            }
        }

        val nextRuntime = currentRuntime.copy(
            scenarioId = scenarioId,
            connectionMode = connMode,
            navWeather = nav,
            deviceTimeUtc = SimulationRuntimeState.currentDeviceUtc()
        )

        return ScenarioBundle(
            runtime = nextRuntime,
            assets = baseAssets,
            workOrders = baseOrders,
            extraHandover = extraHandover,
            summary = scenarioEventSummary
        )
    }
}

data class ScenarioBundle(
    val runtime: SimulationRuntimeState,
    val assets: List<CarrierAsset>,
    val workOrders: List<WorkOrder>,
    val extraHandover: ShiftHandoverRecord?,
    val summary: String
)
