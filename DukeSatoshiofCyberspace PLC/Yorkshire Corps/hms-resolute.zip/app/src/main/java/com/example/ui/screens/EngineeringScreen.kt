package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.assets.AssetCategory
import com.example.assets.TaskPriority
import com.example.assets.TelemetryObservation
import com.example.assets.TelemetryQuality
import com.example.ui.ResoluteUiState
import com.example.ui.components.IvoryCommandCard
import com.example.ui.components.MonoMetricRow
import com.example.ui.components.QualityPill
import com.example.ui.components.StatusPill
import com.example.ui.theme.BrassGold
import com.example.ui.theme.InkMuted
import com.example.ui.theme.InkNavy
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.MidnightAbyss
import com.example.ui.theme.MidnightNavy
import com.example.ui.theme.NavalSlate
import com.example.ui.theme.SelectionCyan
import com.example.ui.theme.StatusFaultRed
import com.example.ui.theme.StatusReadyGreen
import com.example.ui.theme.WarmIvory

@Composable
fun EngineeringScreen(
    state: ResoluteUiState,
    onSubmitMaintenanceRequest: (String, String, String, TaskPriority, String) -> Unit,
    modifier: Modifier = Modifier
) {
    val engAssets = state.assets.filter {
        it.category == AssetCategory.ENGINEERING_SYSTEM || it.category == AssetCategory.AIRCRAFT_LIFT
    }
    val elecTrend = state.telemetry.filter { it.metricKey == "ELEC_TREND" }.reversed()
    var reqTarget by remember { mutableStateOf("GT-2") }
    var reqTitle by remember { mutableStateOf("") }

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        IvoryCommandCard(
            title = "Engineering Availability & Calculation",
            subtitle = "Read-only IPMS integration • Actuation remains external",
            headerAction = { QualityPill(state.engineeringAvailability.quality) }
        ) {
            Text(
                text = state.engineeringAvailability.formulaExplanation,
                fontFamily = JetBrainsMonoFontFamily,
                fontSize = 11.sp,
                color = InkNavy
            )
            Spacer(Modifier.height(8.dp))
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                engAssets.forEach { unit ->
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = WarmIvory,
                        border = BorderStroke(1.dp, BrassGold.copy(alpha = 0.65f))
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "${unit.id} • ${unit.callsign}",
                                    fontFamily = JetBrainsMonoFontFamily,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp
                                )
                                Text(unit.maintenanceState, style = MaterialTheme.typography.bodySmall, color = InkMuted)
                                Text(
                                    text = "Source: ${unit.dataSource} • Age: ${unit.telemetryAgeSec}s",
                                    fontFamily = JetBrainsMonoFontFamily,
                                    fontSize = 10.sp,
                                    color = InkMuted
                                )
                            }
                            StatusPill(status = unit.operationalStatus)
                        }
                    }
                }
            }
        }

        IvoryCommandCard(
            title = "Electrical Demand Trend (Observed Series)",
            subtitle = "Missing observations produce explicit gap warnings (never fabricated continuous lines)"
        ) {
            ObservationTrendChartWithGaps(
                observations = elecTrend,
                minVal = 40.0,
                maxVal = 55.0,
                modifier = Modifier.fillMaxWidth().height(130.dp)
            )
            Spacer(Modifier.height(6.dp))
            val gaps = elecTrend.filter { it.value == null || it.quality == TelemetryQuality.MISSING }
            if (gaps.isNotEmpty()) {
                Text(
                    text = "DATA GAP WARNING: ${gaps.joinToString { "${it.label} (${it.uncertainty})" }}",
                    fontFamily = JetBrainsMonoFontFamily,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = StatusFaultRed
                )
            }
        }

        IvoryCommandCard(
            title = "Administrative Maintenance Request",
            subtitle = "Logs work order request without actuating machinery"
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = reqTarget,
                    onValueChange = { reqTarget = it },
                    label = { Text("Unit ID") },
                    modifier = Modifier.weight(0.35f)
                )
                OutlinedTextField(
                    value = reqTitle,
                    onValueChange = { reqTitle = it },
                    label = { Text("Requested Inspection / Action") },
                    modifier = Modifier.weight(0.65f)
                )
            }
            Spacer(Modifier.height(8.dp))
            Button(
                onClick = {
                    if (reqTitle.isNotBlank()) {
                        onSubmitMaintenanceRequest(reqTarget, reqTitle, "Engineering maintenance request", TaskPriority.ROUTINE, "ME Power Watch")
                        reqTitle = ""
                    }
                },
                modifier = Modifier.testTag("eng_submit_maint_req"),
                colors = ButtonDefaults.buttonColors(containerColor = MidnightNavy, contentColor = BrassGold)
            ) {
                Text("Log Maintenance Request")
            }
        }
    }
}

@Composable
fun ObservationTrendChartWithGaps(
    observations: List<TelemetryObservation>,
    minVal: Double,
    maxVal: Double,
    modifier: Modifier = Modifier
) {
    Canvas(
        modifier = modifier
            .background(MidnightAbyss, RoundedCornerShape(6.dp))
            .border(1.dp, BrassGold, RoundedCornerShape(6.dp))
            .padding(12.dp)
    ) {
        if (observations.isEmpty()) return@Canvas
        val w = size.width
        val h = size.height
        val count = observations.size.coerceAtLeast(2)
        val stepX = w / (count - 1).coerceAtLeast(1)

        // Horizontal reference lines
        drawLine(NavalSlate, Offset(0f, h * 0.25f), Offset(w, h * 0.25f), 1f)
        drawLine(NavalSlate, Offset(0f, h * 0.50f), Offset(w, h * 0.50f), 1f)
        drawLine(NavalSlate, Offset(0f, h * 0.75f), Offset(w, h * 0.75f), 1f)

        var prevValid: Offset? = null
        observations.forEachIndexed { idx, obs ->
            val x = idx * stepX
            val v = obs.value
            if (v == null || obs.quality == TelemetryQuality.MISSING) {
                // Draw explicit red dashed missing-data vertical marker and break the line!
                drawLine(
                    color = StatusFaultRed,
                    start = Offset(x, 4f),
                    end = Offset(x, h - 4f),
                    strokeWidth = 2f,
                    pathEffect = PathEffect.dashPathEffect(floatArrayOf(6f, 6f))
                )
                prevValid = null
            } else {
                val norm = ((v - minVal) / (maxVal - minVal)).toFloat().coerceIn(0.05f, 0.95f)
                val y = h - norm * h
                val pt = Offset(x, y)
                prevValid?.let { prev ->
                    drawLine(SelectionCyan, prev, pt, strokeWidth = 3f)
                }
                drawCircle(StatusReadyGreen, radius = 5f, center = pt)
                prevValid = pt
            }
        }
    }
}
