package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.assets.OperationalStatus
import com.example.assets.TelemetryQuality
import com.example.assets.WorkOrderStatus
import com.example.ui.theme.BrassGold
import com.example.ui.theme.BrassGoldMuted
import com.example.ui.theme.InkMuted
import com.example.ui.theme.InkNavy
import com.example.ui.theme.IvoryRule
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.MidnightNavy
import com.example.ui.theme.NavalBorderMuted
import com.example.ui.theme.NavalSlate
import com.example.ui.theme.StatusCautionAmber
import com.example.ui.theme.StatusCautionAmberBg
import com.example.ui.theme.StatusFaultRed
import com.example.ui.theme.StatusFaultRedBg
import com.example.ui.theme.StatusReadyGreen
import com.example.ui.theme.StatusReadyGreenBg
import com.example.ui.theme.StatusStaleSlate
import com.example.ui.theme.StatusStaleSlateBg
import com.example.ui.theme.WarmIvory

/**
 * Custom Royal Navy Admiralty Anchor vector emblem drawn via Compose Canvas.
 */
@Composable
fun AnchorEmblem(
    modifier: Modifier = Modifier,
    size: Dp = 36.dp,
    tint: Color = BrassGold
) {
    Canvas(modifier = modifier.size(size)) {
        val w = this.size.width
        val h = this.size.height
        val stroke = w * 0.085f

        // Ring at top
        drawCircle(
            color = tint,
            radius = w * 0.12f,
            center = Offset(w * 0.5f, h * 0.17f),
            style = Stroke(width = stroke)
        )
        // Vertical shank
        drawLine(
            color = tint,
            start = Offset(w * 0.5f, h * 0.29f),
            end = Offset(w * 0.5f, h * 0.86f),
            strokeWidth = stroke * 1.15f,
            cap = StrokeCap.Round
        )
        // Crossbar stock
        drawLine(
            color = tint,
            start = Offset(w * 0.26f, h * 0.38f),
            end = Offset(w * 0.74f, h * 0.38f),
            strokeWidth = stroke,
            cap = StrokeCap.Round
        )
        // Fluke arc
        val flukePath = Path().apply {
            moveTo(w * 0.18f, h * 0.64f)
            quadraticTo(w * 0.5f, h * 0.98f, w * 0.82f, h * 0.64f)
        }
        drawPath(
            path = flukePath,
            color = tint,
            style = Stroke(width = stroke * 1.1f, cap = StrokeCap.Round, join = StrokeJoin.Round)
        )
        // Fluke arrow tips
        val leftTip = Path().apply {
            moveTo(w * 0.14f, h * 0.60f)
            lineTo(w * 0.25f, h * 0.62f)
            lineTo(w * 0.19f, h * 0.72f)
            close()
        }
        val rightTip = Path().apply {
            moveTo(w * 0.86f, h * 0.60f)
            lineTo(w * 0.75f, h * 0.62f)
            lineTo(w * 0.81f, h * 0.72f)
            close()
        }
        drawPath(leftTip, color = tint)
        drawPath(rightTip, color = tint)
    }
}

/**
 * Warm ivory command information card with restrained brass-gold border.
 */
@Composable
fun IvoryCommandCard(
    title: String,
    modifier: Modifier = Modifier,
    subtitle: String? = null,
    headerAction: (@Composable () -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit
) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(8.dp),
        colors = CardDefaults.cardColors(containerColor = WarmIvory, contentColor = InkNavy),
        border = BorderStroke(1.2.dp, BrassGold),
        elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = title.uppercase(),
                        style = MaterialTheme.typography.titleSmall,
                        color = InkNavy,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    if (!subtitle.isNullOrBlank()) {
                        Text(
                            text = subtitle,
                            style = MaterialTheme.typography.bodySmall,
                            color = InkMuted,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
                if (headerAction != null) {
                    Spacer(Modifier.width(8.dp))
                    headerAction()
                }
            }
            HorizontalDivider(
                modifier = Modifier.padding(vertical = 7.dp),
                thickness = 1.dp,
                color = IvoryRule
            )
            content()
        }
    }
}

/**
 * Midnight-navy tactical frame with brass-gold hairline border.
 */
@Composable
fun NavalDarkPanel(
    title: String,
    modifier: Modifier = Modifier,
    headerTrailing: (@Composable () -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(8.dp),
        color = MidnightNavy,
        border = BorderStroke(1.dp, BrassGoldMuted),
        tonalElevation = 2.dp
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = title.uppercase(),
                    style = MaterialTheme.typography.titleSmall,
                    color = BrassGold,
                    fontWeight = FontWeight.Bold
                )
                if (headerTrailing != null) headerTrailing()
            }
            HorizontalDivider(
                modifier = Modifier.padding(vertical = 6.dp),
                thickness = 0.8.dp,
                color = NavalBorderMuted
            )
            content()
        }
    }
}

/**
 * Colour-independent operational status pill (combines icon, short text symbol, and semantic tint).
 */
@Composable
fun StatusPill(
    status: OperationalStatus,
    modifier: Modifier = Modifier
) {
    val (fg, bg, icon) = when (status) {
        OperationalStatus.READY -> Triple(StatusReadyGreen, StatusReadyGreenBg, Icons.Default.CheckCircle)
        OperationalStatus.INSPECTION, OperationalStatus.MAINTENANCE, OperationalStatus.CAUTION ->
            Triple(StatusCautionAmber, StatusCautionAmberBg, Icons.Default.Warning)
        OperationalStatus.UNAVAILABLE -> Triple(StatusFaultRed, StatusFaultRedBg, Icons.Default.Error)
        OperationalStatus.STALE -> Triple(StatusStaleSlate, StatusStaleSlateBg, Icons.Default.HelpOutline)
    }
    StatusChipRaw(
        text = status.label,
        icon = icon,
        fg = fg,
        bg = bg,
        modifier = modifier
    )
}

@Composable
fun QualityPill(
    quality: TelemetryQuality,
    ageSec: Int? = null,
    modifier: Modifier = Modifier
) {
    val (fg, bg, icon) = when (quality) {
        TelemetryQuality.LIVE -> Triple(StatusReadyGreen, StatusReadyGreenBg, Icons.Default.CheckCircle)
        TelemetryQuality.STALE -> Triple(StatusCautionAmber, StatusCautionAmberBg, Icons.Default.Warning)
        TelemetryQuality.MISSING, TelemetryQuality.DISCONNECTED ->
            Triple(StatusFaultRed, StatusFaultRedBg, Icons.Default.Error)
    }
    val label = if (ageSec != null) "${quality.label} (${ageSec}s)" else quality.label
    StatusChipRaw(text = label, icon = icon, fg = fg, bg = bg, modifier = modifier)
}

@Composable
fun WorkOrderStatusPill(status: WorkOrderStatus, modifier: Modifier = Modifier) {
    val (fg, bg, icon) = when (status) {
        WorkOrderStatus.COMPLETE -> Triple(StatusReadyGreen, StatusReadyGreenBg, Icons.Default.CheckCircle)
        WorkOrderStatus.AWAITING_REVIEW, WorkOrderStatus.IN_PROGRESS, WorkOrderStatus.ASSIGNED ->
            Triple(StatusCautionAmber, StatusCautionAmberBg, Icons.Default.Warning)
        WorkOrderStatus.BLOCKED, WorkOrderStatus.REOPENED ->
            Triple(StatusFaultRed, StatusFaultRedBg, Icons.Default.Error)
        WorkOrderStatus.DRAFT, WorkOrderStatus.CANCELLED ->
            Triple(StatusStaleSlate, StatusStaleSlateBg, Icons.Default.HelpOutline)
    }
    StatusChipRaw(text = status.label.uppercase(), icon = icon, fg = fg, bg = bg, modifier = modifier)
}

@Composable
fun StatusChipRaw(
    text: String,
    icon: ImageVector,
    fg: Color,
    bg: Color,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .background(bg, RoundedCornerShape(4.dp))
            .border(0.8.dp, fg.copy(alpha = 0.5f), RoundedCornerShape(4.dp))
            .padding(horizontal = 6.dp, vertical = 2.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = icon,
            contentDescription = text,
            tint = fg,
            modifier = Modifier.size(12.dp)
        )
        Spacer(Modifier.width(4.dp))
        Text(
            text = text,
            color = fg,
            fontFamily = JetBrainsMonoFontFamily,
            fontWeight = FontWeight.Bold,
            fontSize = 10.sp,
            maxLines = 1
        )
    }
}

@Composable
fun MonoMetricRow(
    label: String,
    value: String,
    modifier: Modifier = Modifier,
    valueColor: Color = InkNavy
) {
    Row(
        modifier = modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.bodySmall,
            color = InkMuted,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.weight(1f)
        )
        Spacer(Modifier.width(8.dp))
        Text(
            text = value,
            fontFamily = JetBrainsMonoFontFamily,
            fontWeight = FontWeight.SemiBold,
            fontSize = 12.sp,
            color = valueColor,
            maxLines = 1
        )
    }
}

@Composable
fun SimulationWatermarkBar(
    text: String,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .background(NavalSlate, RoundedCornerShape(4.dp))
            .border(1.dp, BrassGoldMuted, RoundedCornerShape(4.dp))
            .padding(horizontal = 10.dp, vertical = 4.dp)
    ) {
        Text(
            text = text,
            fontFamily = JetBrainsMonoFontFamily,
            fontWeight = FontWeight.SemiBold,
            fontSize = 10.sp,
            color = BrassGold,
            letterSpacing = 0.6.sp
        )
    }
}
