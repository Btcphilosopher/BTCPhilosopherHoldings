package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface AssetDao {
    @Query("SELECT * FROM assets ORDER BY id ASC")
    fun observeAll(): Flow<List<AssetEntity>>

    @Query("SELECT * FROM assets ORDER BY id ASC")
    suspend fun getAllOnce(): List<AssetEntity>

    @Query("SELECT * FROM assets WHERE id = :id LIMIT 1")
    suspend fun getById(id: String): AssetEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(items: List<AssetEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(item: AssetEntity)

    @Query("DELETE FROM assets")
    suspend fun clearAll()
}

@Dao
interface WorkOrderDao {
    @Query("SELECT * FROM work_orders ORDER BY taskId ASC")
    fun observeAll(): Flow<List<WorkOrderEntity>>

    @Query("SELECT * FROM work_orders ORDER BY taskId ASC")
    suspend fun getAllOnce(): List<WorkOrderEntity>

    @Query("SELECT * FROM work_orders WHERE taskId = :taskId LIMIT 1")
    suspend fun getById(taskId: String): WorkOrderEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(items: List<WorkOrderEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(item: WorkOrderEntity)

    @Query("DELETE FROM work_orders")
    suspend fun clearAll()
}

@Dao
interface TelemetryDao {
    @Query("SELECT * FROM telemetry_observations ORDER BY id DESC LIMIT 120")
    fun observeRecent(): Flow<List<TelemetryObservationEntity>>

    @Query("SELECT * FROM telemetry_observations WHERE metricKey = :key ORDER BY id ASC")
    suspend fun getSeriesForMetric(key: String): List<TelemetryObservationEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(items: List<TelemetryObservationEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(item: TelemetryObservationEntity)

    @Query("DELETE FROM telemetry_observations")
    suspend fun clearAll()
}

@Dao
interface HandoverDao {
    @Query("SELECT * FROM shift_handovers ORDER BY versionNumber DESC, createdUtc DESC")
    fun observeAll(): Flow<List<ShiftHandoverEntity>>

    @Query("SELECT * FROM shift_handovers ORDER BY versionNumber DESC, createdUtc DESC")
    suspend fun getAllOnce(): List<ShiftHandoverEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(items: List<ShiftHandoverEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(item: ShiftHandoverEntity)

    @Query("UPDATE shift_handovers SET isLatest = 0 WHERE isLatest = 1")
    suspend fun markAllNotLatest()

    @Query("DELETE FROM shift_handovers")
    suspend fun clearAll()
}

@Dao
interface AuditDao {
    @Query("SELECT * FROM audit_events ORDER BY id DESC LIMIT 150")
    fun observeRecent(): Flow<List<AuditEventEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(event: AuditEventEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(events: List<AuditEventEntity>)

    @Query("DELETE FROM audit_events")
    suspend fun clearAll()
}

@Dao
interface LogisticsDao {
    @Query("SELECT * FROM logistics_records ORDER BY timestampUtc DESC")
    fun observeAll(): Flow<List<LogisticsRecordEntity>>

    @Query("SELECT * FROM logistics_records ORDER BY timestampUtc DESC")
    suspend fun getAllOnce(): List<LogisticsRecordEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(items: List<LogisticsRecordEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(item: LogisticsRecordEntity)

    @Query("DELETE FROM logistics_records")
    suspend fun clearAll()
}

@Dao
interface PendingSyncDao {
    @Query("SELECT * FROM pending_sync_mutations ORDER BY id ASC")
    fun observeAll(): Flow<List<PendingSyncMutationEntity>>

    @Query("SELECT * FROM pending_sync_mutations ORDER BY id ASC")
    suspend fun getAllOnce(): List<PendingSyncMutationEntity>

    @Query("SELECT COUNT(*) FROM pending_sync_mutations WHERE idempotencyKey = :key")
    suspend fun countByIdempotencyKey(key: String): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(item: PendingSyncMutationEntity)

    @Query("DELETE FROM pending_sync_mutations WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("UPDATE pending_sync_mutations SET retryCount = :retryCount, conflictMessage = :conflict WHERE id = :id")
    suspend fun updateAttempt(id: Long, retryCount: Int, conflict: String?)

    @Query("DELETE FROM pending_sync_mutations")
    suspend fun clearAll()
}
