package com.example.security

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

enum class OperatorRole(
    val displayName: String,
    val badgeCode: String,
    val canAssignWorkOrders: Boolean,
    val canSubmitCompletion: Boolean,
    val canAuthoriseReview: Boolean,
    val canUpdateAvailability: Boolean,
    val canCreateHandover: Boolean,
    val canApproveStores: Boolean,
    val canControlSimulator: Boolean,
    val canViewIndividualPersonnel: Boolean,
    val canViewAuditLog: Boolean
) {
    EXECUTIVE_VIEWER(
        displayName = "Executive Viewer",
        badgeCode = "EXEC-01",
        canAssignWorkOrders = false,
        canSubmitCompletion = false,
        canAuthoriseReview = false,
        canUpdateAvailability = false,
        canCreateHandover = false,
        canApproveStores = false,
        canControlSimulator = true,
        canViewIndividualPersonnel = false,
        canViewAuditLog = true
    ),
    MAINTENANCE_STAFF(
        displayName = "Maintenance Lead",
        badgeCode = "MAINT-E2",
        canAssignWorkOrders = false,
        canSubmitCompletion = true,
        canAuthoriseReview = false,
        canUpdateAvailability = false,
        canCreateHandover = false,
        canApproveStores = false,
        canControlSimulator = true,
        canViewIndividualPersonnel = false,
        canViewAuditLog = true
    ),
    DEPARTMENT_SUPERVISOR(
        displayName = "Air & Eng Supervisor",
        badgeCode = "SUPV-04",
        canAssignWorkOrders = true,
        canSubmitCompletion = true,
        canAuthoriseReview = true,
        canUpdateAvailability = true,
        canCreateHandover = true,
        canApproveStores = true,
        canControlSimulator = true,
        canViewIndividualPersonnel = true,
        canViewAuditLog = true
    ),
    ADMINISTRATOR(
        displayName = "Command Administrator",
        badgeCode = "ADMIN-00",
        canAssignWorkOrders = true,
        canSubmitCompletion = true,
        canAuthoriseReview = true,
        canUpdateAvailability = true,
        canCreateHandover = true,
        canApproveStores = true,
        canControlSimulator = true,
        canViewIndividualPersonnel = true,
        canViewAuditLog = true
    ),
    AUDITOR(
        displayName = "Compliance Auditor",
        badgeCode = "AUDIT-09",
        canAssignWorkOrders = false,
        canSubmitCompletion = false,
        canAuthoriseReview = false,
        canUpdateAvailability = false,
        canCreateHandover = false,
        canApproveStores = false,
        canControlSimulator = false,
        canViewIndividualPersonnel = false,
        canViewAuditLog = true
    )
}

data class AuthCheckResult(
    val permitted: Boolean,
    val reason: String
)

object AuthorizationGuard {
    fun check(role: OperatorRole, action: String, predicate: (OperatorRole) -> Boolean): AuthCheckResult {
        return if (predicate(role)) {
            AuthCheckResult(true, "Permitted for ${role.displayName} (${role.badgeCode})")
        } else {
            AuthCheckResult(
                false,
                "Role '${role.displayName}' is not authorised to $action"
            )
        }
    }
}

/**
 * Keystore-backed credential vault encrypting operator session tokens and active role claims
 * using AndroidKeyStore AES-256-GCM when available, with safe test fallback in JVM unit tests.
 */
class KeystoreCredentialVault(context: Context) {
    private val prefs = context.getSharedPreferences("resolute_secure_vault", Context.MODE_PRIVATE)
    private val keyAlias = "hms_resolute_operator_aes_key"

    fun storeCredentials(role: OperatorRole, operatorCallsign: String, apiToken: String) {
        val payload = "${role.name}|$operatorCallsign|$apiToken"
        val encoded = encryptOrFallback(payload)
        prefs.edit().putString("encrypted_session", encoded).apply()
    }

    fun loadRole(): OperatorRole {
        val raw = prefs.getString("encrypted_session", null) ?: return OperatorRole.DEPARTMENT_SUPERVISOR
        val decrypted = decryptOrFallback(raw) ?: return OperatorRole.DEPARTMENT_SUPERVISOR
        val roleName = decrypted.split("|").firstOrNull() ?: return OperatorRole.DEPARTMENT_SUPERVISOR
        return runCatching { OperatorRole.valueOf(roleName) }.getOrDefault(OperatorRole.DEPARTMENT_SUPERVISOR)
    }

    fun loadOperatorCallsign(): String {
        val raw = prefs.getString("encrypted_session", null) ?: return "CDR H. VANE"
        val decrypted = decryptOrFallback(raw) ?: return "CDR H. VANE"
        return decrypted.split("|").getOrNull(1) ?: "CDR H. VANE"
    }

    fun loadApiToken(): String {
        val raw = prefs.getString("encrypted_session", null) ?: return "SIM-TOKEN-R09"
        val decrypted = decryptOrFallback(raw) ?: return "SIM-TOKEN-R09"
        return decrypted.split("|").getOrNull(2) ?: "SIM-TOKEN-R09"
    }

    fun isHardwareKeystoreActive(): Boolean {
        return runCatching {
            val ks = KeyStore.getInstance("AndroidKeyStore")
            ks.load(null)
            true
        }.getOrDefault(false)
    }

    private fun getOrCreateKey(): SecretKey? {
        return runCatching {
            val keyStore = KeyStore.getInstance("AndroidKeyStore")
            keyStore.load(null)
            (keyStore.getKey(keyAlias, null) as? SecretKey) ?: run {
                val keyGenerator = KeyGenerator.getInstance(
                    KeyProperties.KEY_ALGORITHM_AES,
                    "AndroidKeyStore"
                )
                keyGenerator.init(
                    KeyGenParameterSpec.Builder(
                        keyAlias,
                        KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
                    )
                        .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                        .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                        .setKeySize(256)
                        .build()
                )
                keyGenerator.generateKey()
            }
        }.getOrNull()
    }

    private fun encryptOrFallback(plaintext: String): String {
        val key = getOrCreateKey()
        if (key != null) {
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.ENCRYPT_MODE, key)
            val iv = cipher.iv
            val cipherBytes = cipher.doFinal(plaintext.toByteArray(Charsets.UTF_8))
            val ivB64 = Base64.encodeToString(iv, Base64.NO_WRAP)
            val ctB64 = Base64.encodeToString(cipherBytes, Base64.NO_WRAP)
            return "AK:$ivB64:$ctB64"
        }
        return "JVM:" + Base64.encodeToString(plaintext.toByteArray(Charsets.UTF_8), Base64.NO_WRAP)
    }

    private fun decryptOrFallback(stored: String): String? {
        return runCatching {
            if (stored.startsWith("AK:")) {
                val parts = stored.split(":")
                val iv = Base64.decode(parts[1], Base64.NO_WRAP)
                val ct = Base64.decode(parts[2], Base64.NO_WRAP)
                val key = getOrCreateKey() ?: return null
                val cipher = Cipher.getInstance("AES/GCM/NoPadding")
                cipher.init(Cipher.DECRYPT_MODE, key, GCMParameterSpec(128, iv))
                String(cipher.doFinal(ct), Charsets.UTF_8)
            } else if (stored.startsWith("JVM:")) {
                val b64 = stored.removePrefix("JVM:")
                String(Base64.decode(b64, Base64.NO_WRAP), Charsets.UTF_8)
            } else null
        }.getOrNull()
    }
}
