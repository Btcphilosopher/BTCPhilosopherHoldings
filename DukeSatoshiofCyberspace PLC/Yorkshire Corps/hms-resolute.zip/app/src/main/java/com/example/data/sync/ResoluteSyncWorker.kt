package com.example.data.sync

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.example.data.local.ResoluteDatabase
import com.example.data.prefs.PreferencesRepository
import com.example.data.remote.AvailabilityUpdateDto
import com.example.data.remote.HandoverCreateDto
import com.example.data.remote.SimulatorApiClientFactory
import com.example.data.remote.WorkOrderTransitionDto
import kotlinx.coroutines.flow.first
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * Background synchronization worker draining offline pending mutations to the FastAPI simulation backend
 * with explicit idempotency keys, expected-version conflict detection, and bounded retry limits.
 */
class ResoluteSyncWorker(
    appContext: Context,
    params: WorkerParameters
) : CoroutineWorker(appContext, params) {

    override suspend fun doWork(): Result {
        val db = ResoluteDatabase.getInstance(applicationContext)
        val prefs = PreferencesRepository(applicationContext).preferencesFlow.first()
        if (!prefs.preferRemoteBackend) {
            return Result.success()
        }

        val pending = db.pendingSyncDao().getAllOnce()
        if (pending.isEmpty()) return Result.success()

        val api = SimulatorApiClientFactory.create(prefs.simulatorBaseUrl)
        val healthOk = runCatching { api.getHealth().isSuccessful }.getOrDefault(false)
        if (!healthOk) return Result.retry()

        var needsRetry = false
        for (item in pending) {
            if (item.conflictMessage != null) continue
            if (item.retryCount >= item.maxRetries) {
                db.pendingSyncDao().updateAttempt(
                    item.id,
                    item.retryCount,
                    "Retry limit (${item.maxRetries}) reached; manual review required."
                )
                continue
            }

            val payload = runCatching { JSONObject(item.payloadJson) }.getOrNull()
            if (payload == null) {
                db.pendingSyncDao().deleteById(item.id)
                continue
            }

            val role = payload.optString("role", "DEPARTMENT_SUPERVISOR")
            val responseResult = runCatching {
                when (item.mutationType) {
                    "WORK_ORDER_TRANSITION" -> api.transitionWorkOrder(
                        taskId = item.targetId,
                        role = role,
                        body = WorkOrderTransitionDto(
                            idempotency_key = item.idempotencyKey,
                            expected_version = item.expectedVersion,
                            target_status = payload.optString("targetStatus"),
                            assigned_team = payload.optString("assignedTeam").ifBlank { null },
                            completion_evidence = payload.optString("evidence").ifBlank { null },
                            note = payload.optString("note").ifBlank { null },
                            review_comment = payload.optString("reviewComment").ifBlank { null },
                            actor_name = payload.optString("actorName", "Operator")
                        )
                    )
                    "ASSET_AVAILABILITY" -> api.updateAssetAvailability(
                        assetId = item.targetId,
                        role = role,
                        body = AvailabilityUpdateDto(
                            idempotency_key = item.idempotencyKey,
                            operational_status = payload.optString("operationalStatus"),
                            maintenance_state = payload.optString("maintenanceState"),
                            actor_name = payload.optString("actorName", "Operator")
                        )
                    )
                    "HANDOVER_CREATE" -> api.createHandover(
                        role = role,
                        body = HandoverCreateDto(
                            idempotency_key = item.idempotencyKey,
                            outgoing_team = payload.optString("outgoingTeam"),
                            incoming_team = payload.optString("incomingTeam"),
                            outstanding_tasks = payload.optString("outstandingTasks"),
                            equipment_issues = payload.optString("equipmentIssues"),
                            logistics_notes = payload.optString("logisticsNotes"),
                            supersedes_handover_id = payload.optString("supersedesId").ifBlank { null },
                            actor_name = payload.optString("actorName", "Operator")
                        )
                    )
                    else -> null
                }
            }

            val response = responseResult.getOrNull()
            if (response == null) {
                db.pendingSyncDao().updateAttempt(item.id, item.retryCount + 1, null)
                needsRetry = true
            } else if (response.isSuccessful) {
                val ack = response.body()
                if (ack?.conflict == true) {
                    db.pendingSyncDao().updateAttempt(
                        item.id,
                        item.retryCount + 1,
                        "Version conflict (${item.expectedVersion}): ${ack.message}"
                    )
                } else {
                    db.pendingSyncDao().deleteById(item.id)
                }
            } else if (response.code() == 409) {
                db.pendingSyncDao().updateAttempt(
                    item.id,
                    item.retryCount + 1,
                    "HTTP 409 Conflict: newer server record exists (expected v${item.expectedVersion})."
                )
            } else if (response.code() == 403) {
                db.pendingSyncDao().updateAttempt(
                    item.id,
                    item.retryCount + 1,
                    "HTTP 403 Forbidden: backend denied role '$role'."
                )
            } else {
                db.pendingSyncDao().updateAttempt(item.id, item.retryCount + 1, null)
                needsRetry = true
            }
        }

        return if (needsRetry) Result.retry() else Result.success()
    }

    companion object {
        private const val PERIODIC_WORK_NAME = "resolute_periodic_sync"

        fun schedulePeriodic(context: Context) {
            runCatching {
                val request = PeriodicWorkRequestBuilder<ResoluteSyncWorker>(15, TimeUnit.MINUTES).build()
                WorkManager.getInstance(context).enqueueUniquePeriodicWork(
                    PERIODIC_WORK_NAME,
                    ExistingPeriodicWorkPolicy.KEEP,
                    request
                )
            }
        }

        fun triggerImmediate(context: Context) {
            runCatching {
                val request = OneTimeWorkRequestBuilder<ResoluteSyncWorker>().build()
                WorkManager.getInstance(context).enqueue(request)
            }
        }
    }
}
