package com.example.data.prefs

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.resoluteDataStore: DataStore<Preferences> by preferencesDataStore(
    name = "resolute_operator_prefs"
)

data class OperatorPreferences(
    val motionEnabled: Boolean = true,
    val reducedMotion: Boolean = false,
    val playbackSpeed: Float = 1.0f,
    val simulatorBaseUrl: String = "http://10.0.2.2:8000/",
    val preferRemoteBackend: Boolean = false,
    val activeScenarioId: String = "SCEN-02",
    val activeDeckLevel: String = "FLIGHT_DECK",
    val activeViewMode: String = "TOP"
)

class PreferencesRepository(private val context: Context) {
    private object Keys {
        val MOTION_ENABLED = booleanPreferencesKey("motion_enabled")
        val REDUCED_MOTION = booleanPreferencesKey("reduced_motion")
        val PLAYBACK_SPEED = floatPreferencesKey("playback_speed")
        val SIMULATOR_BASE_URL = stringPreferencesKey("simulator_base_url")
        val PREFER_REMOTE_BACKEND = booleanPreferencesKey("prefer_remote_backend")
        val ACTIVE_SCENARIO_ID = stringPreferencesKey("active_scenario_id")
        val ACTIVE_DECK_LEVEL = stringPreferencesKey("active_deck_level")
        val ACTIVE_VIEW_MODE = stringPreferencesKey("active_view_mode")
    }

    val preferencesFlow: Flow<OperatorPreferences> = context.resoluteDataStore.data.map { prefs ->
        OperatorPreferences(
            motionEnabled = prefs[Keys.MOTION_ENABLED] ?: true,
            reducedMotion = prefs[Keys.REDUCED_MOTION] ?: false,
            playbackSpeed = prefs[Keys.PLAYBACK_SPEED] ?: 1.0f,
            simulatorBaseUrl = prefs[Keys.SIMULATOR_BASE_URL] ?: "http://10.0.2.2:8000/",
            preferRemoteBackend = prefs[Keys.PREFER_REMOTE_BACKEND] ?: false,
            activeScenarioId = prefs[Keys.ACTIVE_SCENARIO_ID] ?: "SCEN-02",
            activeDeckLevel = prefs[Keys.ACTIVE_DECK_LEVEL] ?: "FLIGHT_DECK",
            activeViewMode = prefs[Keys.ACTIVE_VIEW_MODE] ?: "TOP"
        )
    }

    suspend fun setMotionEnabled(enabled: Boolean) {
        context.resoluteDataStore.edit { it[Keys.MOTION_ENABLED] = enabled }
    }

    suspend fun setReducedMotion(reduced: Boolean) {
        context.resoluteDataStore.edit { it[Keys.REDUCED_MOTION] = reduced }
    }

    suspend fun setPlaybackSpeed(speed: Float) {
        context.resoluteDataStore.edit { it[Keys.PLAYBACK_SPEED] = speed }
    }

    suspend fun setSimulatorBaseUrl(url: String) {
        context.resoluteDataStore.edit { it[Keys.SIMULATOR_BASE_URL] = url }
    }

    suspend fun setPreferRemoteBackend(prefer: Boolean) {
        context.resoluteDataStore.edit { it[Keys.PREFER_REMOTE_BACKEND] = prefer }
    }

    suspend fun setActiveScenario(scenarioId: String) {
        context.resoluteDataStore.edit { it[Keys.ACTIVE_SCENARIO_ID] = scenarioId }
    }

    suspend fun setDeckAndView(deckLevel: String, viewMode: String) {
        context.resoluteDataStore.edit {
            it[Keys.ACTIVE_DECK_LEVEL] = deckLevel
            it[Keys.ACTIVE_VIEW_MODE] = viewMode
        }
    }
}
