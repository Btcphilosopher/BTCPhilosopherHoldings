package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        AssetEntity::class,
        WorkOrderEntity::class,
        TelemetryObservationEntity::class,
        ShiftHandoverEntity::class,
        AuditEventEntity::class,
        LogisticsRecordEntity::class,
        PendingSyncMutationEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class ResoluteDatabase : RoomDatabase() {
    abstract fun assetDao(): AssetDao
    abstract fun workOrderDao(): WorkOrderDao
    abstract fun telemetryDao(): TelemetryDao
    abstract fun handoverDao(): HandoverDao
    abstract fun auditDao(): AuditDao
    abstract fun logisticsDao(): LogisticsDao
    abstract fun pendingSyncDao(): PendingSyncDao

    companion object {
        @Volatile
        private var INSTANCE: ResoluteDatabase? = null

        fun getInstance(context: Context): ResoluteDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    ResoluteDatabase::class.java,
                    "hms_resolute_command.db"
                ).build().also { INSTANCE = it }
            }
        }
    }
}
