package com.example.tasks

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.assets.AssetCategory
import com.example.assets.CarrierAsset
import com.example.assets.OperationalStatus
import com.example.assets.WorkOrder
import com.example.assets.WorkOrderStatus
import com.example.ui.components.MonoMetricRow
import com.example.ui.components.QualityPill
import com.example.ui.components.StatusPill
import com.example.ui.components.WorkOrderStatusPill
import com.example.ui.theme.BrassGold
import com.example.ui.theme.InkMuted
import com.example.ui.theme.InkNavy
import com.example.ui.theme.IvoryRule
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.MidnightAbyss
import com.example.ui.theme.MidnightNavy
import com.example.ui.theme.SelectionCyan
import com.example.ui.theme.StatusCautionAmber
import com.example.ui.theme.StatusFaultRed
import com.example.ui.theme.StatusReadyGreen
import com.example.ui.theme.WarmIvory
import com.example.ui.theme.WarmIvoryAlt

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun AssetInspectorCard(
    asset: CarrierAsset,
    openWorkOrders: List<WorkOrder>,
    onClose: () -> Unit,
    onOpenWorkOrder: (String) -> Unit,
    onUpdateAvailability: (String, OperationalStatus, String) -> Unit,
    onSimulateRelocation: (String, Float, Float, String) -> Unit,
    modifier: Modifier = Modifier
) {
    var showDetailsSheet by remember { mutableStateOf(false) }

    Surface(
        modifier = modifier.testTag("asset_inspector_${asset.id}"),
        shape = RoundedCornerShape(8.dp),
        color = WarmIvory,
        contentColor = InkNavy,
        border = BorderStroke(1.8.dp, SelectionCyan),
        tonalElevation = 6.dp
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "${asset.id} — ${asset.operationalStatus.label}",
                        fontFamily = JetBrainsMonoFontFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        color = InkNavy
                    )
                    Text(
                        text = "${asset.maintenanceState} • ${asset.assignedTeam}",
                        style = MaterialTheme.typography.bodySmall,
                        color = InkMuted
                    )
                }
                StatusPill(status = asset.operationalStatus)
                IconButton(onClick = onClose, modifier = Modifier.testTag("inspector_close")) {
                    Icon(Icons.Default.Close, contentDescription = "Close inspector", tint = InkNavy)
                }
            }

            HorizontalDivider(color = IvoryRule, modifier = Modifier.padding(vertical = 6.dp))

            MonoMetricRow("Asset ID / Callsign", "${asset.id} (${asset.callsign})")
            MonoMetricRow("Type", asset.assetType)
            MonoMetricRow("Location", asset.locationLabel)
            MonoMetricRow("Maintenance State", asset.maintenanceState)
            MonoMetricRow("Assigned Team", asset.assignedTeam)
            MonoMetricRow("Open Work Orders", if (openWorkOrders.isEmpty()) "None" else openWorkOrders.joinToString { it.taskId })
            MonoMetricRow("Last Update", "${asset.lastUpdateUtc} (${asset.telemetryAgeSec}s ago)")
            MonoMetricRow("Data Source", asset.dataSource)

            Spacer(Modifier.height(6.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                QualityPill(quality = asset.telemetryQuality, ageSec = asset.telemetryAgeSec)
                if (asset.isSimulatedRelocation) {
                    Text(
                        text = "SIMULATED RELOCATION",
                        fontFamily = JetBrainsMonoFontFamily,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = StatusCautionAmber
                    )
                }
            }

            Spacer(Modifier.height(6.dp))
            Text(
                text = asset.flightAuthorisationSeparateNote,
                style = MaterialTheme.typography.bodySmall,
                color = StatusCautionAmber,
                fontWeight = FontWeight.SemiBold
            )

            Spacer(Modifier.height(8.dp))
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                OutlinedButton(
                    onClick = { showDetailsSheet = true },
                    modifier = Modifier.testTag("inspector_details_btn"),
                    border = BorderStroke(1.dp, InkNavy)
                ) {
                    Text("Details", color = InkNavy, fontSize = 12.sp)
                }
                val primaryWo = openWorkOrders.firstOrNull()
                if (primaryWo != null) {
                    Button(
                        onClick = { onOpenWorkOrder(primaryWo.taskId) },
                        modifier = Modifier.testTag("inspector_work_order_btn"),
                        colors = ButtonDefaults.buttonColors(containerColor = MidnightNavy, contentColor = BrassGold)
                    ) {
                        Text("Work Order (${primaryWo.taskId})", fontSize = 12.sp)
                    }
                }
                if (asset.operationalStatus != OperationalStatus.READY) {
                    Button(
                        onClick = {
                            onUpdateAvailability(asset.id, OperationalStatus.READY, "Serviceable — Availability Updated")
                        },
                        modifier = Modifier.testTag("inspector_mark_ready_btn"),
                        colors = ButtonDefaults.buttonColors(containerColor = StatusReadyGreen, contentColor = WarmIvory)
                    ) {
                        Text("Update Availability: Ready", fontSize = 12.sp)
                    }
                }
                if (asset.category == AssetCategory.AIRCRAFT || asset.category == AssetCategory.SERVICE_VEHICLE) {
                    OutlinedButton(
                        onClick = {
                            onSimulateRelocation(
                                asset.id,
                                (asset.shipX + 35f).coerceAtMost(840f),
                                asset.shipY,
                                "Sim Spot (${asset.locationLabel})"
                            )
                        },
                        modifier = Modifier.testTag("inspector_sim_relocate_btn"),
                        border = BorderStroke(1.dp, StatusCautionAmber)
                    ) {
                        Text("Sim Relocate (Demo Only)", color = InkNavy, fontSize = 11.sp)
                    }
                }
            }
        }
    }

    if (showDetailsSheet) {
        Dialog(onDismissRequest = { showDetailsSheet = false }) {
            Surface(
                shape = RoundedCornerShape(10.dp),
                color = WarmIvory,
                contentColor = InkNavy,
                border = BorderStroke(1.5.dp, BrassGold)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "ASSET DOSSIER: ${asset.id}",
                        style = MaterialTheme.typography.headlineSmall,
                        color = InkNavy
                    )
                    Spacer(Modifier.height(8.dp))
                    MonoMetricRow("Callsign", asset.callsign)
                    MonoMetricRow("Deck Level", asset.deckLevel.label)
                    MonoMetricRow("Ship Coords (X, Y)", "${asset.shipX.toInt()}, ${asset.shipY.toInt()}")
                    MonoMetricRow("Maintenance Progress", "${asset.maintenanceProgressPct}%")
                    Spacer(Modifier.height(6.dp))
                    LinearProgressIndicator(
                        progress = { asset.maintenanceProgressPct / 100f },
                        modifier = Modifier.fillMaxWidth(),
                        color = BrassGold,
                        trackColor = WarmIvoryAlt
                    )
                    Spacer(Modifier.height(10.dp))
                    Text(
                        text = "Authority Boundary: ${asset.flightAuthorisationSeparateNote}. Dragging or simulating relocation does not issue deck movement authority.",
                        style = MaterialTheme.typography.bodySmall,
                        color = InkMuted
                    )
                    Spacer(Modifier.height(12.dp))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                        Button(
                            onClick = { showDetailsSheet = false },
                            colors = ButtonDefaults.buttonColors(containerColor = MidnightNavy, contentColor = WarmIvory)
                        ) {
                            Text("Close")
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun WorkOrderDetailDialog(
    workOrder: WorkOrder,
    onDismiss: () -> Unit,
    onAssignTeam: (String, String) -> Unit,
    onStartWorkOrder: (String) -> Unit,
    onSaveChecklistAndNotes: (String, Int, String, String?) -> Unit,
    onSubmitForReview: (String, String) -> Unit,
    onAuthoriseReview: (String, Boolean, String) -> Unit
) {
    var selectedTeam by remember(workOrder.taskId, workOrder.assignedTeam) { mutableStateOf(workOrder.assignedTeam) }
    var notesInput by remember(workOrder.taskId, workOrder.notes) { mutableStateOf(workOrder.notes) }
    var evidenceInput by remember(workOrder.taskId, workOrder.completionEvidence) {
        mutableStateOf(workOrder.completionEvidence.ifBlank { "Inspection verified within tolerance; FOD sweep clear." })
    }
    var reviewComment by remember { mutableStateOf("Reviewed completion evidence & QA stamp; approved for availability update.") }
    var checkedCount by remember(workOrder.taskId, workOrder.completedChecklistCount) {
        mutableIntStateOf(workOrder.completedChecklistCount)
    }

    val teamChoices = listOf("Team A-1", "Team E-2", "Team H-2", "ME Hull Team", "ME Aux Watch")

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.92f)
                .heightIn(max = 680.dp)
                .testTag("work_order_dialog_${workOrder.taskId}"),
            shape = RoundedCornerShape(10.dp),
            color = WarmIvory,
            contentColor = InkNavy,
            border = BorderStroke(1.8.dp, BrassGold)
        ) {
            Column(
                modifier = Modifier
                    .padding(16.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "${workOrder.taskId} • ${workOrder.assetId} (v${workOrder.version})",
                            fontFamily = JetBrainsMonoFontFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            color = InkNavy
                        )
                        Text(
                            text = workOrder.title,
                            style = MaterialTheme.typography.titleMedium,
                            color = InkNavy
                        )
                    }
                    WorkOrderStatusPill(status = workOrder.status)
                    IconButton(onClick = onDismiss, modifier = Modifier.testTag("wo_dialog_close")) {
                        Icon(Icons.Default.Close, contentDescription = "Close work order", tint = InkNavy)
                    }
                }

                HorizontalDivider(color = IvoryRule, modifier = Modifier.padding(vertical = 8.dp))

                Text(text = workOrder.description, style = MaterialTheme.typography.bodyMedium)
                Spacer(Modifier.height(6.dp))
                MonoMetricRow("Zone", workOrder.zoneLabel)
                MonoMetricRow("Priority", workOrder.priority.label)
                MonoMetricRow("Due UTC", workOrder.dueTimeUtc)
                MonoMetricRow("Dependencies", if (workOrder.dependencies.isEmpty()) "None" else workOrder.dependencies.joinToString())
                MonoMetricRow("Last Modified", "${workOrder.lastChangedBy} @ ${workOrder.lastChangedUtc}")

                Spacer(Modifier.height(10.dp))
                Text("ASSIGNED TEAM", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    teamChoices.forEach { team ->
                        val active = selectedTeam == team
                        Surface(
                            shape = RoundedCornerShape(4.dp),
                            color = if (active) MidnightNavy else WarmIvoryAlt,
                            border = BorderStroke(1.dp, if (active) BrassGold else IvoryRule),
                            modifier = Modifier
                                .testTag("wo_team_chip_${team.replace(" ", "_")}")
                                .clickable { selectedTeam = team }
                        ) {
                            Text(
                                text = team,
                                fontSize = 11.sp,
                                color = if (active) BrassGold else InkNavy,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp)
                            )
                        }
                    }
                    Button(
                        onClick = { onAssignTeam(workOrder.taskId, selectedTeam) },
                        modifier = Modifier.testTag("wo_assign_team_btn"),
                        colors = ButtonDefaults.buttonColors(containerColor = MidnightNavy, contentColor = BrassGold)
                    ) {
                        Text("Assign Team", fontSize = 11.sp)
                    }
                }

                Spacer(Modifier.height(10.dp))
                Text(
                    "INSPECTION CHECKLIST ($checkedCount/${workOrder.checklistItems.size})",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold
                )
                workOrder.checklistItems.forEachIndexed { idx, step ->
                    val checked = idx < checkedCount
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                checkedCount = if (checked) idx else idx + 1
                            }
                            .padding(vertical = 2.dp)
                    ) {
                        Checkbox(
                            checked = checked,
                            onCheckedChange = { isChecked ->
                                checkedCount = if (isChecked) idx + 1 else idx
                            }
                        )
                        Text(text = step, style = MaterialTheme.typography.bodySmall)
                    }
                }

                OutlinedTextField(
                    value = notesInput,
                    onValueChange = { notesInput = it },
                    label = { Text("Technician Notes") },
                    modifier = Modifier.fillMaxWidth().padding(top = 6.dp)
                )

                OutlinedTextField(
                    value = evidenceInput,
                    onValueChange = { evidenceInput = it },
                    label = { Text("Completion Evidence") },
                    modifier = Modifier.fillMaxWidth().padding(top = 6.dp).testTag("wo_evidence_input")
                )

                if (workOrder.attachments.isNotEmpty()) {
                    Text(
                        text = "Attachments: ${workOrder.attachments.joinToString()}",
                        fontFamily = JetBrainsMonoFontFamily,
                        fontSize = 10.sp,
                        color = InkMuted,
                        modifier = Modifier.padding(top = 4.dp)
                    )
                }

                Spacer(Modifier.height(10.dp))
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    if (workOrder.status == WorkOrderStatus.DRAFT || workOrder.status == WorkOrderStatus.ASSIGNED) {
                        OutlinedButton(
                            onClick = { onStartWorkOrder(workOrder.taskId) },
                            modifier = Modifier.testTag("wo_start_btn")
                        ) {
                            Text("Start Work", fontSize = 12.sp, color = InkNavy)
                        }
                    }

                    OutlinedButton(
                        onClick = {
                            onSaveChecklistAndNotes(workOrder.taskId, checkedCount, notesInput, "QA_PHOTO_${workOrder.taskId}.png")
                        },
                        modifier = Modifier.testTag("wo_save_notes_btn")
                    ) {
                        Text("Save Progress & Attach", fontSize = 12.sp, color = InkNavy)
                    }

                    if (workOrder.status == WorkOrderStatus.IN_PROGRESS || workOrder.status == WorkOrderStatus.REOPENED || workOrder.status == WorkOrderStatus.ASSIGNED) {
                        Button(
                            onClick = { onSubmitForReview(workOrder.taskId, evidenceInput) },
                            modifier = Modifier.testTag("wo_submit_completion_btn"),
                            colors = ButtonDefaults.buttonColors(containerColor = StatusCautionAmber, contentColor = MidnightAbyss)
                        ) {
                            Text("Submit Inspection Completion", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                if (workOrder.status == WorkOrderStatus.AWAITING_REVIEW) {
                    Spacer(Modifier.height(10.dp))
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(WarmIvoryAlt, RoundedCornerShape(6.dp))
                            .border(1.dp, BrassGold, RoundedCornerShape(6.dp))
                            .padding(10.dp)
                    ) {
                        Text(
                            "AUTHORISED SUPERVISOR REVIEW REQUIRED",
                            style = MaterialTheme.typography.titleSmall,
                            color = InkNavy,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            "Equipment remains held from Ready availability until an authorised reviewer signs off.",
                            style = MaterialTheme.typography.bodySmall,
                            color = InkMuted
                        )
                        OutlinedTextField(
                            value = reviewComment,
                            onValueChange = { reviewComment = it },
                            label = { Text("Review Decision Comment") },
                            modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp)
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(
                                onClick = { onAuthoriseReview(workOrder.taskId, true, reviewComment) },
                                modifier = Modifier.testTag("wo_authorise_review_btn"),
                                colors = ButtonDefaults.buttonColors(containerColor = StatusReadyGreen, contentColor = WarmIvory)
                            ) {
                                Text("Authorise Review (Complete)", fontSize = 12.sp)
                            }
                            OutlinedButton(
                                onClick = { onAuthoriseReview(workOrder.taskId, false, reviewComment) },
                                modifier = Modifier.testTag("wo_reopen_review_btn"),
                                border = BorderStroke(1.dp, StatusFaultRed)
                            ) {
                                Text("Reject / Reopen", color = StatusFaultRed, fontSize = 12.sp)
                            }
                        }
                    }
                }

                if (workOrder.reviewHistory.isNotEmpty()) {
                    Spacer(Modifier.height(10.dp))
                    Text("REVIEW & AUDIT HISTORY", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                    workOrder.reviewHistory.forEach { rev ->
                        Text(
                            text = "• [${rev.timestampUtc}] ${rev.decision} by ${rev.reviewer} (${rev.role}): ${rev.comment}",
                            fontFamily = JetBrainsMonoFontFamily,
                            fontSize = 10.sp,
                            color = InkMuted,
                            modifier = Modifier.padding(top = 3.dp)
                        )
                    }
                }
            }
        }
    }
}
