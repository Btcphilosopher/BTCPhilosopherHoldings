package com.example.navigationinfo

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.assets.NavigationWeatherState
import com.example.assets.TelemetryQuality
import com.example.ui.components.IvoryCommandCard
import com.example.ui.components.MonoMetricRow
import com.example.ui.components.QualityPill
import com.example.ui.theme.BrassGold
import com.example.ui.theme.InkMuted
import com.example.ui.theme.InkNavy
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.MidnightAbyss
import com.example.ui.theme.MidnightNavy
import com.example.ui.theme.NavalSlate
import com.example.ui.theme.SelectionCyan
import com.example.ui.theme.StatusCautionAmber
import com.example.ui.theme.StatusFaultRed
import com.example.ui.theme.WarmIvory

@Composable
fun NavigationWeatherPanel(
    navWeather: NavigationWeatherState,
    modifier: Modifier = Modifier
) {
    IvoryCommandCard(
        title = "Navigation & Weather",
        subtitle = navWeather.positionSource,
        headerAction = {
            QualityPill(quality = navWeather.quality, ageSec = navWeather.ageSeconds)
        },
        modifier = modifier
    ) {
        // Explicit Information View disclaimer
        Text(
            text = stringResource(R.string.not_for_navigation),
            fontFamily = JetBrainsMonoFontFamily,
            fontWeight = FontWeight.Bold,
            fontSize = 10.sp,
            color = StatusCautionAmber,
            modifier = Modifier
                .fillMaxWidth()
                .background(MidnightNavy, RoundedCornerShape(4.dp))
                .border(0.8.dp, BrassGold, RoundedCornerShape(4.dp))
                .padding(horizontal = 8.dp, vertical = 4.dp)
        )

        Spacer(Modifier.height(8.dp))

        // Schematic fictional route canvas
        Canvas(
            modifier = Modifier
                .fillMaxWidth()
                .height(88.dp)
                .background(MidnightAbyss, RoundedCornerShape(6.dp))
                .border(1.dp, BrassGold, RoundedCornerShape(6.dp))
        ) {
            val w = size.width
            val h = size.height
            // Grid lines
            drawLine(NavalSlate, Offset(w * 0.25f, 0f), Offset(w * 0.25f, h), 1f)
            drawLine(NavalSlate, Offset(w * 0.50f, 0f), Offset(w * 0.50f, h), 1f)
            drawLine(NavalSlate, Offset(w * 0.75f, 0f), Offset(w * 0.75f, h), 1f)
            drawLine(NavalSlate, Offset(0f, h * 0.5f), Offset(w, h * 0.5f), 1f)

            val p0 = Offset(w * 0.10f, h * 0.76f)
            val p1 = Offset(w * 0.42f, h * 0.55f)
            val p2 = Offset(w * 0.78f, h * 0.30f)
            val p3 = Offset(w * 0.92f, h * 0.26f)

            val route = Path().apply {
                moveTo(p0.x, p0.y)
                lineTo(p1.x, p1.y)
                lineTo(p2.x, p2.y)
                lineTo(p3.x, p3.y)
            }
            drawPath(
                path = route,
                color = BrassGold,
                style = Stroke(width = 2f, pathEffect = PathEffect.dashPathEffect(floatArrayOf(8f, 6f)))
            )
            // Waypoints
            listOf(p0, p1, p2, p3).forEach { pt ->
                drawCircle(BrassGold, radius = 4f, center = pt)
            }
            // Ship position marker interpolated along track
            val shipPt = Offset(
                x = p0.x + (p2.x - p0.x) * navWeather.routeProgressRatio,
                y = p0.y + (p2.y - p0.y) * navWeather.routeProgressRatio
            )
            drawCircle(SelectionCyan.copy(alpha = 0.28f), radius = 10f, center = shipPt)
            drawCircle(SelectionCyan, radius = 5f, center = shipPt)
        }

        Spacer(Modifier.height(8.dp))

        if (navWeather.quality != TelemetryQuality.LIVE) {
            Text(
                text = "WARNING: Telemetry feed ${navWeather.quality.label} (${navWeather.ageSeconds}s old)",
                fontFamily = JetBrainsMonoFontFamily,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                color = StatusFaultRed,
                modifier = Modifier.padding(bottom = 4.dp)
            )
        }

        MonoMetricRow("Position (Fictional)", "${navWeather.latitudeDisplay} / ${navWeather.longitudeDisplay}")
        MonoMetricRow("Heading (HDG)", "${"%.1f".format(navWeather.headingDeg)}° TRUE")
        MonoMetricRow("Course Over Ground (COG)", "${"%.1f".format(navWeather.courseOverGroundDeg)}° TRUE")
        MonoMetricRow("Speed Through Water (STW)", "${"%.1f".format(navWeather.speedThroughWaterKnots)} kt")
        MonoMetricRow(
            "Speed Over Ground (SOG)",
            "${"%.1f".format(navWeather.speedOverGroundKnots)} ±${navWeather.speedUncertaintyKnots} kt"
        )
        MonoMetricRow("Wind (Rel/True)", "${navWeather.windDirectionDeg}° / ${navWeather.windSpeedKnots} kt")
        MonoMetricRow("Visibility", "${navWeather.visibilityNm} NM")
        MonoMetricRow("Sea State", "SS ${navWeather.seaStateCode} — ${navWeather.seaStateDescription}")
        MonoMetricRow("Next Waypoint", "${navWeather.nextWaypointName} (${navWeather.waypointDistanceNm} NM)")
        MonoMetricRow("Waypoint ETA / Obs UTC", "${navWeather.nextWaypointEtaUtc} / ${navWeather.timestampUtc}")

        Spacer(Modifier.height(4.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Read-only adapter • Uncertified schematic",
                style = MaterialTheme.typography.bodySmall,
                color = InkMuted
            )
            Text(
                text = "OBS ${navWeather.timestampUtc}",
                fontFamily = JetBrainsMonoFontFamily,
                fontSize = 10.sp,
                color = InkNavy
            )
        }
    }
}
