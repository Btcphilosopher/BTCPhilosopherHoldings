package com.example.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.dp

private val AdmiralDarkColorScheme = darkColorScheme(
    primary = BrassGold,
    onPrimary = MidnightAbyss,
    primaryContainer = NavalSurfaceElevated,
    onPrimaryContainer = BrassGoldBright,
    secondary = SelectionCyan,
    onSecondary = MidnightAbyss,
    secondaryContainer = NavalSlate,
    onSecondaryContainer = WarmIvory,
    tertiary = BrassGoldMuted,
    onTertiary = WarmIvory,
    background = MidnightAbyss,
    onBackground = WarmIvory,
    surface = MidnightNavy,
    onSurface = WarmIvory,
    surfaceVariant = WarmIvory,
    onSurfaceVariant = InkNavy,
    outline = BrassGold,
    outlineVariant = NavalBorderMuted,
    error = StatusFaultRed,
    onError = WarmIvory
)

val ResoluteShapes = Shapes(
    extraSmall = RoundedCornerShape(3.dp),
    small = RoundedCornerShape(6.dp),
    medium = RoundedCornerShape(8.dp),
    large = RoundedCornerShape(10.dp),
    extraLarge = RoundedCornerShape(14.dp)
)

@Composable
fun ResoluteTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = AdmiralDarkColorScheme,
        typography = ResoluteTypography,
        shapes = ResoluteShapes,
        content = content
    )
}
