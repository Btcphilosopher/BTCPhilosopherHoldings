package com.example

import android.app.Application
import androidx.work.Configuration
import com.example.data.sync.ResoluteSyncWorker

class ResoluteApplication : Application(), Configuration.Provider {

    override val workManagerConfiguration: Configuration
        get() = Configuration.Builder()
            .setMinimumLoggingLevel(android.util.Log.INFO)
            .build()

    override fun onCreate() {
        super.onCreate()
        runCatching { ResoluteSyncWorker.schedulePeriodic(this) }
    }
}
