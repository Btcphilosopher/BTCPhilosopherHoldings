package com.example.engineering

import com.example.assets.AssetCategory
import com.example.assets.AvailabilityComputation
import com.example.assets.CarrierAsset
import com.example.assets.OperationalStatus
import com.example.assets.TelemetryQuality

object AvailabilityCalculator {

    const val STALE_THRESHOLD_SECONDS = 180

    fun computeAircraftMaintenanceAvailability(assets: List<CarrierAsset>): AvailabilityComputation {
        val aircraft = assets.filter {
            it.category == AssetCategory.AIRCRAFT || it.category == AssetCategory.HELICOPTER
        }
        return computeForGroup(
            label = "Aircraft Maintenance Availability",
            group = aircraft,
            note = "Maintenance availability only — separate from external flight authorisation."
        )
    }

    fun computeEngineeringAvailability(assets: List<CarrierAsset>): AvailabilityComputation {
        val systems = assets.filter {
            it.category == AssetCategory.ENGINEERING_SYSTEM || it.category == AssetCategory.AIRCRAFT_LIFT
        }
        return computeForGroup(
            label = "Engineering & Lift Availability",
            group = systems,
            note = "Units with stale/missing telemetry (>180s) are excluded from Ready count and flagged."
        )
    }

    private fun computeForGroup(
        label: String,
        group: List<CarrierAsset>,
        note: String
    ): AvailabilityComputation {
        if (group.isEmpty()) {
            return AvailabilityComputation(
                label = label,
                availableUnits = 0,
                totalUnits = 0,
                staleOrUnknownUnits = 0,
                percentage = null,
                formulaExplanation = "No units configured. $note",
                quality = TelemetryQuality.MISSING
            )
        }

        val staleUnits = group.count {
            it.telemetryQuality != TelemetryQuality.LIVE ||
                it.telemetryAgeSec > STALE_THRESHOLD_SECONDS ||
                it.operationalStatus == OperationalStatus.STALE
        }
        val readyUnits = group.count {
            it.operationalStatus == OperationalStatus.READY &&
                it.telemetryQuality == TelemetryQuality.LIVE &&
                it.telemetryAgeSec <= STALE_THRESHOLD_SECONDS
        }
        val total = group.size
        val knownUnits = total - staleUnits
        val pct = if (knownUnits > 0) (readyUnits.toDouble() / total.toDouble()) * 100.0 else null
        val quality = when {
            staleUnits == total -> TelemetryQuality.MISSING
            staleUnits > 0 -> TelemetryQuality.STALE
            else -> TelemetryQuality.LIVE
        }
        val formula = "Formula: Ready ($readyUnits) / Total ($total) = " +
            (pct?.let { "%.1f%%".format(it) } ?: "UNKNOWN") +
            (if (staleUnits > 0) " [$staleUnits STALE/UNKNOWN]" else "") +
            ". $note"

        return AvailabilityComputation(
            label = label,
            availableUnits = readyUnits,
            totalUnits = total,
            staleOrUnknownUnits = staleUnits,
            percentage = pct,
            formulaExplanation = formula,
            quality = quality
        )
    }

    /**
     * Enforces reliability rule: a stale green indicator must become STALE/UNKNOWN
     * rather than continuing to imply healthy equipment.
     */
    fun applyStalenessDegradation(asset: CarrierAsset): CarrierAsset {
        val isStale = asset.telemetryQuality == TelemetryQuality.STALE ||
            asset.telemetryQuality == TelemetryQuality.MISSING ||
            asset.telemetryQuality == TelemetryQuality.DISCONNECTED ||
            asset.telemetryAgeSec > STALE_THRESHOLD_SECONDS

        return if (isStale && asset.operationalStatus == OperationalStatus.READY) {
            asset.copy(
                operationalStatus = OperationalStatus.STALE,
                maintenanceState = "Telemetry Stale (${asset.telemetryAgeSec}s) — Status Unknown"
            )
        } else if (isStale && asset.operationalStatus != OperationalStatus.UNAVAILABLE && asset.operationalStatus != OperationalStatus.STALE) {
            asset.copy(operationalStatus = OperationalStatus.STALE)
        } else {
            asset
        }
    }
}
