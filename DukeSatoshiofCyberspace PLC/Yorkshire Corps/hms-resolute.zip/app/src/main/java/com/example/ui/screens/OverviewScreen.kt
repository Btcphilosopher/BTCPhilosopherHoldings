package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.assets.DeckLevel
import com.example.assets.OperationalStatus
import com.example.assets.TelemetryQuality
import com.example.assets.ViewProjectionMode
import com.example.navigationinfo.NavigationWeatherPanel
import com.example.shipview.ShipDigitalTwinPanel
import com.example.shipview.ShipViewportTransform
import com.example.tasks.AssetInspectorCard
import com.example.ui.ResoluteUiState
import com.example.ui.components.IvoryCommandCard
import com.example.ui.components.MonoMetricRow
import com.example.ui.components.NavalDarkPanel
import com.example.ui.components.QualityPill
import com.example.ui.components.WorkOrderStatusPill
import com.example.ui.theme.BrassGold
import com.example.ui.theme.InkMuted
import com.example.ui.theme.InkNavy
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.MidnightAbyss
import com.example.ui.theme.MidnightNavy
import com.example.ui.theme.NavalSlate
import com.example.ui.theme.SelectionCyan
import com.example.ui.theme.StatusCautionAmber
import com.example.ui.theme.StatusFaultRed
import com.example.ui.theme.StatusReadyGreen
import com.example.ui.theme.StatusStaleSlate
import com.example.ui.theme.WarmIvory

@Composable
fun OverviewScreen(
    state: ResoluteUiState,
    onSelectDeck: (DeckLevel) -> Unit,
    onSelectViewMode: (ViewProjectionMode) -> Unit,
    onViewportChange: (ShipViewportTransform) -> Unit,
    onZoomBy: (Float) -> Unit,
    onCentreView: () -> Unit,
    onResetView: () -> Unit,
    onToggleMotion: () -> Unit,
    onSelectAsset: (String?) -> Unit,
    onOpenWorkOrder: (String) -> Unit,
    onUpdateAvailability: (String, OperationalStatus, String) -> Unit,
    onSimulateRelocation: (String, Float, Float, String) -> Unit,
    modifier: Modifier = Modifier
) {
    val selectedAsset = state.assets.find { it.id == state.selectedAssetId }
    val selectedOpenWos = state.workOrders.filter { it.assetId == state.selectedAssetId }

    BoxWithConstraints(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(10.dp)
    ) {
        val isWideTablet = maxWidth >= 840.dp

        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            // Top 4 KPI Cards Row (2x2 grid on narrow phones, 4-across on landscape tablets)
            TopExecutiveKpiGrid(state = state, isWide = isWideTablet)

            if (isWideTablet) {
                // Landscape Tablet / Fixed Workstation Layout matching terminal reference
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalAlignment = Alignment.Top
                ) {
                    Column(
                        modifier = Modifier.weight(1.75f),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        ShipDigitalTwinPanel(
                            assets = state.assets,
                            activeDeck = state.activeDeck,
                            viewMode = state.viewMode,
                            viewport = state.viewport,
                            selectedAssetId = state.selectedAssetId,
                            motionEnabled = state.motionEnabled,
                            reducedMotion = state.reducedMotion,
                            isAppForeground = state.isAppForeground,
                            onSelectDeck = onSelectDeck,
                            onSelectViewMode = onSelectViewMode,
                            onViewportChange = onViewportChange,
                            onZoomBy = onZoomBy,
                            onCentreView = onCentreView,
                            onResetView = onResetView,
                            onToggleMotion = onToggleMotion,
                            onSelectAsset = onSelectAsset,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(420.dp)
                        )

                        if (selectedAsset != null) {
                            AssetInspectorCard(
                                asset = selectedAsset,
                                openWorkOrders = selectedOpenWos,
                                onClose = { onSelectAsset(null) },
                                onOpenWorkOrder = onOpenWorkOrder,
                                onUpdateAvailability = onUpdateAvailability,
                                onSimulateRelocation = onSimulateRelocation,
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    }

                    NavigationWeatherPanel(
                        navWeather = state.runtime.navWeather,
                        modifier = Modifier.weight(1f)
                    )
                }

                // Bottom 3-Column Strip: Engineering Indicators | Deck Tasks | Command Log
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalAlignment = Alignment.Top
                ) {
                    EngineeringSummaryStripCard(state = state, modifier = Modifier.weight(1f))
                    DeckTasksStripCard(
                        state = state,
                        onOpenWorkOrder = onOpenWorkOrder,
                        modifier = Modifier.weight(1.1f)
                    )
                    CommandLogStripCard(state = state, modifier = Modifier.weight(1f))
                }
            } else {
                // Compact phone / portrait layout: reorganised panels for clarity without shrinking
                ShipDigitalTwinPanel(
                    assets = state.assets,
                    activeDeck = state.activeDeck,
                    viewMode = state.viewMode,
                    viewport = state.viewport,
                    selectedAssetId = state.selectedAssetId,
                    motionEnabled = state.motionEnabled,
                    reducedMotion = state.reducedMotion,
                    isAppForeground = state.isAppForeground,
                    onSelectDeck = onSelectDeck,
                    onSelectViewMode = onSelectViewMode,
                    onViewportChange = onViewportChange,
                    onZoomBy = onZoomBy,
                    onCentreView = onCentreView,
                    onResetView = onResetView,
                    onToggleMotion = onToggleMotion,
                    onSelectAsset = onSelectAsset,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(340.dp)
                )

                if (selectedAsset != null) {
                    AssetInspectorCard(
                        asset = selectedAsset,
                        openWorkOrders = selectedOpenWos,
                        onClose = { onSelectAsset(null) },
                        onOpenWorkOrder = onOpenWorkOrder,
                        onUpdateAvailability = onUpdateAvailability,
                        onSimulateRelocation = onSimulateRelocation,
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                NavigationWeatherPanel(
                    navWeather = state.runtime.navWeather,
                    modifier = Modifier.fillMaxWidth()
                )
                EngineeringSummaryStripCard(state = state, modifier = Modifier.fillMaxWidth())
                DeckTasksStripCard(
                    state = state,
                    onOpenWorkOrder = onOpenWorkOrder,
                    modifier = Modifier.fillMaxWidth()
                )
                CommandLogStripCard(state = state, modifier = Modifier.fillMaxWidth())
            }
        }
    }
}

@Composable
private fun TopExecutiveKpiGrid(state: ResoluteUiState, isWide: Boolean) {
    val nav = state.runtime.navWeather
    val acAvail = state.aircraftAvailability
    val engAvail = state.engineeringAvailability
    val totalCrew = state.personnelDepartments.sumOf { it.totalAssigned }
    val onWatch = state.personnelDepartments.sumOf { it.onWatch }

    val cards: List<@Composable (Modifier) -> Unit> = listOf(
        { mod ->
            IvoryCommandCard(
                title = "Ship Speed",
                subtitle = "SOG vs STW",
                headerAction = { QualityPill(nav.quality, nav.ageSeconds) },
                modifier = mod.testTag("kpi_ship_speed")
            ) {
                Text(
                    text = "${"%.1f".format(nav.speedOverGroundKnots)} kt SOG",
                    fontFamily = JetBrainsMonoFontFamily,
                    fontWeight = FontWeight.Bold,
                    fontSize = 20.sp,
                    color = InkNavy
                )
                MonoMetricRow("Through Water (STW)", "${"%.1f".format(nav.speedThroughWaterKnots)} kt")
                MonoMetricRow("Course / Heading", "${"%.0f".format(nav.courseOverGroundDeg)}° / ${"%.0f".format(nav.headingDeg)}°")
            }
        },
        { mod ->
            IvoryCommandCard(
                title = "Personnel Aboard",
                subtitle = "Department Aggregates",
                modifier = mod.testTag("kpi_personnel_aboard")
            ) {
                Text(
                    text = "$totalCrew ABOARD",
                    fontFamily = JetBrainsMonoFontFamily,
                    fontWeight = FontWeight.Bold,
                    fontSize = 20.sp,
                    color = InkNavy
                )
                MonoMetricRow("On Watch", "$onWatch crew")
                MonoMetricRow("Active Dept Feeds", "${state.personnelDepartments.size} departments")
            }
        },
        { mod ->
            IvoryCommandCard(
                title = "Aircraft Maint. Avail.",
                subtitle = "Excludes Flight Auth",
                headerAction = { QualityPill(acAvail.quality) },
                modifier = mod.testTag("kpi_aircraft_availability")
            ) {
                val pctStr = acAvail.percentage?.let { "${"%.0f".format(it)}%" } ?: "UNKNOWN"
                Text(
                    text = "$pctStr (${acAvail.availableUnits}/${acAvail.totalUnits})",
                    fontFamily = JetBrainsMonoFontFamily,
                    fontWeight = FontWeight.Bold,
                    fontSize = 20.sp,
                    color = if (acAvail.quality == TelemetryQuality.LIVE) StatusReadyGreen else StatusCautionAmber
                )
                MonoMetricRow("Ready (Maint)", "${acAvail.availableUnits} airframes")
                MonoMetricRow("Inspection / Hold", "${acAvail.totalUnits - acAvail.availableUnits} airframes")
            }
        },
        { mod ->
            IvoryCommandCard(
                title = "Engineering Availability",
                subtitle = "Machinery & Lifts",
                headerAction = { QualityPill(engAvail.quality) },
                modifier = mod.testTag("kpi_engineering_availability")
            ) {
                val pctStr = engAvail.percentage?.let { "${"%.0f".format(it)}%" } ?: "UNKNOWN"
                val valColor = when {
                    engAvail.staleOrUnknownUnits > 0 -> StatusStaleSlate
                    engAvail.availableUnits < engAvail.totalUnits -> StatusCautionAmber
                    else -> StatusReadyGreen
                }
                Text(
                    text = if (engAvail.staleOrUnknownUnits > 0) "$pctStr • STALE" else "$pctStr (${engAvail.availableUnits}/${engAvail.totalUnits})",
                    fontFamily = JetBrainsMonoFontFamily,
                    fontWeight = FontWeight.Bold,
                    fontSize = 20.sp,
                    color = valColor
                )
                MonoMetricRow("Healthy Online", "${engAvail.availableUnits} / ${engAvail.totalUnits} units")
                MonoMetricRow(
                    "Stale / Unknown",
                    "${engAvail.staleOrUnknownUnits} units",
                    valueColor = if (engAvail.staleOrUnknownUnits > 0) StatusFaultRed else InkNavy
                )
            }
        }
    )

    if (isWide) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            cards.forEach { card -> card(Modifier.weight(1f)) }
        }
    } else {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                cards[0](Modifier.weight(1f))
                cards[1](Modifier.weight(1f))
            }
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                cards[2](Modifier.weight(1f))
                cards[3](Modifier.weight(1f))
            }
        }
    }
}

@Composable
private fun EngineeringSummaryStripCard(state: ResoluteUiState, modifier: Modifier = Modifier) {
    val latest = state.telemetry.filter { it.category != "TREND" }.distinctBy { it.metricKey }
    val staleAssets = state.assets.filter { it.operationalStatus == OperationalStatus.STALE || it.operationalStatus == OperationalStatus.UNAVAILABLE }

    IvoryCommandCard(
        title = "Engineering Indicators",
        subtitle = "Measured vs Estimated",
        modifier = modifier.testTag("bottom_engineering_indicators")
    ) {
        latest.forEach { obs ->
            val cap = obs.capacityMax?.let { max ->
                obs.value?.let { v -> " (${"%.0f".format((v / max) * 100)}%)" } ?: ""
            } ?: ""
            val measureTag = if (obs.isMeasured) "MEAS" else "EST"
            MonoMetricRow(
                label = "${obs.label} [$measureTag]",
                value = (obs.value?.let { "${"%.1f".format(it)} ${obs.unit}" } ?: "MISSING") + cap,
                valueColor = if (obs.quality == TelemetryQuality.LIVE) InkNavy else StatusFaultRed
            )
        }
        Spacer(Modifier.height(6.dp))
        if (staleAssets.isNotEmpty()) {
            Text(
                text = "ALERT: ${staleAssets.joinToString { "${it.id} (${it.operationalStatus.label})" }}",
                fontFamily = JetBrainsMonoFontFamily,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                color = StatusFaultRed
            )
        } else {
            Text(
                text = state.engineeringAvailability.formulaExplanation,
                style = MaterialTheme.typography.bodySmall,
                color = InkMuted,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
private fun DeckTasksStripCard(
    state: ResoluteUiState,
    onOpenWorkOrder: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    IvoryCommandCard(
        title = "Deck Tasks & Work Orders",
        subtitle = "${state.workOrders.count { it.status.name != "COMPLETE" }} active • Tap row to inspect",
        modifier = modifier.testTag("bottom_deck_tasks")
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
            state.workOrders.take(5).forEach { wo ->
                Surface(
                    shape = RoundedCornerShape(4.dp),
                    color = WarmIvory.copy(alpha = 0.7f),
                    border = BorderStroke(0.8.dp, BrassGold.copy(alpha = 0.55f)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("overview_wo_row_${wo.taskId}")
                        .clickable { onOpenWorkOrder(wo.taskId) }
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "${wo.taskId} • ${wo.assetId} (${wo.assignedTeam})",
                                fontFamily = JetBrainsMonoFontFamily,
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp,
                                color = InkNavy
                            )
                            Text(
                                text = wo.title,
                                style = MaterialTheme.typography.bodySmall,
                                color = InkMuted,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                        Spacer(Modifier.width(6.dp))
                        WorkOrderStatusPill(status = wo.status)
                    }
                }
            }
        }
    }
}

@Composable
private fun CommandLogStripCard(state: ResoluteUiState, modifier: Modifier = Modifier) {
    NavalDarkPanel(
        title = "Command & Audit Log",
        headerTrailing = {
            Text(
                text = "LIVE EVENTS (${state.auditEvents.size})",
                fontFamily = JetBrainsMonoFontFamily,
                fontSize = 10.sp,
                color = SelectionCyan
            )
        },
        modifier = modifier.testTag("bottom_command_log")
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
            state.auditEvents.take(6).forEach { ev ->
                val badgeColor = when (ev.outcome) {
                    "DENIED" -> StatusFaultRed
                    "QUEUED_OFFLINE" -> StatusCautionAmber
                    else -> StatusReadyGreen
                }
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(NavalSlate, RoundedCornerShape(4.dp))
                        .padding(horizontal = 8.dp, vertical = 5.dp),
                    verticalAlignment = Alignment.Top
                ) {
                    Box(
                        modifier = Modifier
                            .background(badgeColor.copy(alpha = 0.2f), RoundedCornerShape(3.dp))
                            .padding(horizontal = 4.dp, vertical = 1.dp)
                    ) {
                        Text(
                            text = ev.simTimeUtc,
                            fontFamily = JetBrainsMonoFontFamily,
                            fontSize = 9.sp,
                            color = badgeColor,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Spacer(Modifier.width(8.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "${ev.actionType} • ${ev.actorName}",
                            fontFamily = JetBrainsMonoFontFamily,
                            fontSize = 10.sp,
                            color = BrassGold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = ev.summary,
                            style = MaterialTheme.typography.bodySmall,
                            color = WarmIvory,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }
        }
    }
}
