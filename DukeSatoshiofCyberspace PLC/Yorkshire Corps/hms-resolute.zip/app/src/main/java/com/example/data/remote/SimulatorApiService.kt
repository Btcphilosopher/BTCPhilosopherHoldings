package com.example.data.remote

import com.squareup.moshi.JsonClass
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.Header
import retrofit2.http.POST
import retrofit2.http.Path
import java.util.concurrent.TimeUnit

@JsonClass(generateAdapter = true)
data class SimHealthDto(
    val status: String,
    val ship: String,
    val simulation_mode: Boolean,
    val sim_time_utc: String,
    val scenario_id: String
)

@JsonClass(generateAdapter = true)
data class SimControlRequestDto(
    val action: String, // pause, play, reset, step, set_speed, load_scenario
    val speed: Float? = null,
    val scenario_id: String? = null,
    val step_minutes: Int? = null
)

@JsonClass(generateAdapter = true)
data class WorkOrderTransitionDto(
    val idempotency_key: String,
    val expected_version: Int,
    val target_status: String,
    val assigned_team: String? = null,
    val completion_evidence: String? = null,
    val note: String? = null,
    val review_comment: String? = null,
    val actor_name: String
)

@JsonClass(generateAdapter = true)
data class AvailabilityUpdateDto(
    val idempotency_key: String,
    val operational_status: String,
    val maintenance_state: String,
    val actor_name: String
)

@JsonClass(generateAdapter = true)
data class HandoverCreateDto(
    val idempotency_key: String,
    val outgoing_team: String,
    val incoming_team: String,
    val outstanding_tasks: String,
    val equipment_issues: String,
    val logistics_notes: String,
    val supersedes_handover_id: String? = null,
    val actor_name: String
)

@JsonClass(generateAdapter = true)
data class MutationAckDto(
    val accepted: Boolean,
    val idempotency_key: String,
    val new_version: Int? = null,
    val conflict: Boolean = false,
    val message: String
)

@JsonClass(generateAdapter = true)
data class RemoteSnapshotDto(
    val sim_time_utc: String,
    val scenario_id: String,
    val paused: Boolean,
    val speed: Float,
    val assets: List<RemoteAssetDto> = emptyList(),
    val work_orders: List<RemoteWorkOrderDto> = emptyList()
)

@JsonClass(generateAdapter = true)
data class RemoteAssetDto(
    val id: String,
    val callsign: String,
    val asset_type: String,
    val category: String,
    val deck_level: String,
    val ship_x: Float,
    val ship_y: Float,
    val heading_deg: Float,
    val location_label: String,
    val maintenance_state: String,
    val operational_status: String,
    val assigned_team: String,
    val last_update_utc: String,
    val telemetry_age_sec: Int,
    val telemetry_quality: String,
    val data_source: String,
    val maintenance_progress_pct: Int
)

@JsonClass(generateAdapter = true)
data class RemoteWorkOrderDto(
    val task_id: String,
    val asset_id: String,
    val status: String,
    val assigned_team: String,
    val version: Int
)

interface SimulatorApiService {
    @GET("health")
    suspend fun getHealth(): Response<SimHealthDto>

    @GET("api/v1/state")
    suspend fun getSnapshot(): Response<RemoteSnapshotDto>

    @POST("api/v1/simulation/control")
    suspend fun controlSimulation(
        @Header("X-Operator-Role") role: String,
        @Body body: SimControlRequestDto
    ): Response<SimHealthDto>

    @POST("api/v1/work-orders/{taskId}/transition")
    suspend fun transitionWorkOrder(
        @Path("taskId") taskId: String,
        @Header("X-Operator-Role") role: String,
        @Body body: WorkOrderTransitionDto
    ): Response<MutationAckDto>

    @POST("api/v1/assets/{assetId}/availability")
    suspend fun updateAssetAvailability(
        @Path("assetId") assetId: String,
        @Header("X-Operator-Role") role: String,
        @Body body: AvailabilityUpdateDto
    ): Response<MutationAckDto>

    @POST("api/v1/handovers")
    suspend fun createHandover(
        @Header("X-Operator-Role") role: String,
        @Body body: HandoverCreateDto
    ): Response<MutationAckDto>
}

object SimulatorApiClientFactory {
    fun create(baseUrl: String): SimulatorApiService {
        val sanitized = if (baseUrl.endsWith("/")) baseUrl else "$baseUrl/"
        val moshi = Moshi.Builder()
            .addLast(KotlinJsonAdapterFactory())
            .build()
        val logger = HttpLoggingInterceptor().apply {
            level = HttpLoggingInterceptor.Level.BASIC
        }
        val client = OkHttpClient.Builder()
            .connectTimeout(2500, TimeUnit.MILLISECONDS)
            .readTimeout(3500, TimeUnit.MILLISECONDS)
            .addInterceptor(logger)
            .build()
        return Retrofit.Builder()
            .baseUrl(sanitized)
            .client(client)
            .addConverterFactory(MoshiConverterFactory.create(moshi))
            .build()
            .create(SimulatorApiService::class.java)
    }
}
