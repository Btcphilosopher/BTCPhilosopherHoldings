package com.example

import android.content.Context
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onAllNodesWithTag
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performScrollTo
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.assets.OperationalStatus
import com.example.data.ResoluteRepository
import com.example.data.local.ResoluteDatabase
import com.example.ui.ResoluteAppShell
import com.example.ui.ResoluteViewModel
import com.example.ui.theme.ResoluteTheme
import kotlinx.coroutines.runBlocking
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36], qualifiers = "w1280dp-h800dp-land")
class ExampleRobolectricTest {

    @get:Rule
    val composeRule = createComposeRule()

    @Test
    fun `read string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("HMS Resolute", appName)
    }

    @Test
    fun `duplicate idempotent mutation is prevented in Room outbox`() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val db = Room.inMemoryDatabaseBuilder(context, ResoluteDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        val repo = ResoluteRepository(context, db)
        val key = "IDEMP-WO404-TEST"

        val first = repo.enqueueIdempotentMutation(
            idempotencyKey = key,
            mutationType = "WORK_ORDER_TRANSITION",
            targetId = "WO-404",
            expectedVersion = 3,
            payload = JSONObject().put("targetStatus", "AWAITING_REVIEW"),
            createdUtc = "2026-11-21T08:05:00Z"
        )
        val second = repo.enqueueIdempotentMutation(
            idempotencyKey = key,
            mutationType = "WORK_ORDER_TRANSITION",
            targetId = "WO-404",
            expectedVersion = 3,
            payload = JSONObject().put("targetStatus", "AWAITING_REVIEW"),
            createdUtc = "2026-11-21T08:05:00Z"
        )
        assertTrue(first)
        assertFalse(second)
        assertEquals(1, db.pendingSyncDao().getAllOnce().size)
        db.close()
    }

    @Test
    fun `end to end acceptance demonstration AC04 workflow and shift handover`() {
        val app = ApplicationProvider.getApplicationContext<android.app.Application>()
        val viewModel = ResoluteViewModel(app)
        viewModel.toggleSimulationPause() // keep deterministic during UI test

        composeRule.setContent {
            ResoluteTheme {
                ResoluteAppShell(viewModel = viewModel)
            }
        }

        // Wait until Room seed data is loaded and AC-04 quick pill is rendered
        composeRule.waitUntil(timeoutMillis = 8000) {
            org.robolectric.shadows.ShadowLooper.shadowMainLooper().idle()
            composeRule.onAllNodesWithTag("quick_asset_AC-04").fetchSemanticsNodes().isNotEmpty()
        }
        composeRule.waitForIdle()

        // 1. Overview shows HMS RESOLUTE and SIMULATION MODE
        composeRule.onNodeWithTag("simulation_mode_badge").assertIsDisplayed()
        composeRule.onNodeWithText("HMS RESOLUTE").assertIsDisplayed()

        // 2. Select AC-04 on interactive deck view
        composeRule.onNodeWithTag("quick_asset_AC-04").performClick()
        composeRule.waitForIdle()

        // 3. Inspect AC-04 state (reference: AC-04 — MAINTENANCE — Inspection in progress • Team E-2)
        composeRule.onNodeWithTag("asset_inspector_AC-04").performScrollTo().assertIsDisplayed()
        composeRule.onNodeWithText("Inspection in progress • Team E-2").assertIsDisplayed()

        // 4. Open work order WO-404
        composeRule.onNodeWithTag("inspector_work_order_btn").performScrollTo().performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("work_order_dialog_WO-404").assertIsDisplayed()

        // 5. Assign team & advance simulation
        composeRule.onNodeWithTag("wo_assign_team_btn").performScrollTo().performClick()
        composeRule.waitForIdle()
        viewModel.stepSimulation(300)
        org.robolectric.shadows.ShadowLooper.shadowMainLooper().idle()
        composeRule.waitForIdle()

        // 6. Submit inspection completion -> Awaiting Review (does not release AC-04 yet)
        composeRule.onNodeWithTag("wo_submit_completion_btn").performScrollTo().performClick()
        composeRule.waitUntil(timeoutMillis = 8000) {
            org.robolectric.shadows.ShadowLooper.shadowMainLooper().idle()
            composeRule.onAllNodesWithTag("wo_authorise_review_btn").fetchSemanticsNodes().isNotEmpty()
        }

        // 7. Perform authorised review -> Complete
        composeRule.onNodeWithTag("wo_authorise_review_btn").performScrollTo().performClick()
        composeRule.waitUntil(timeoutMillis = 5000) {
            org.robolectric.shadows.ShadowLooper.shadowMainLooper().idle()
            viewModel.uiState.value.workOrders.firstOrNull { it.taskId == "WO-404" }?.status == com.example.assets.WorkOrderStatus.COMPLETE
        }
        composeRule.onNodeWithTag("wo_dialog_close").performClick()
        composeRule.waitForIdle()

        // 8. Update AC-04 availability -> Ready
        composeRule.onNodeWithTag("inspector_mark_ready_btn").performScrollTo().performClick()
        composeRule.waitUntil(timeoutMillis = 5000) {
            org.robolectric.shadows.ShadowLooper.shadowMainLooper().idle()
            viewModel.uiState.value.assets.firstOrNull { it.id == "AC-04" }?.operationalStatus == OperationalStatus.READY
        }
        assertEquals(
            OperationalStatus.READY,
            viewModel.uiState.value.assets.first { it.id == "AC-04" }.operationalStatus
        )

        // 9. Navigate to Personnel & record shift handover preserving prior version
        composeRule.onNodeWithTag("nav_personnel").performClick()
        composeRule.waitUntil(timeoutMillis = 5000) {
            org.robolectric.shadows.ShadowLooper.shadowMainLooper().idle()
            composeRule.onAllNodesWithTag("record_handover_btn").fetchSemanticsNodes().isNotEmpty()
        }
        composeRule.onNodeWithTag("record_handover_btn").performScrollTo().performClick()
        composeRule.waitUntil(timeoutMillis = 5000) {
            org.robolectric.shadows.ShadowLooper.shadowMainLooper().idle()
            viewModel.uiState.value.handovers.size >= 2
        }

        val handovers = viewModel.uiState.value.handovers
        assertTrue(handovers.size >= 2)
        assertTrue(handovers.any { it.versionNumber == 1 && !it.isLatest })
        assertTrue(handovers.any { it.versionNumber == 2 && it.isLatest })
    }
}
