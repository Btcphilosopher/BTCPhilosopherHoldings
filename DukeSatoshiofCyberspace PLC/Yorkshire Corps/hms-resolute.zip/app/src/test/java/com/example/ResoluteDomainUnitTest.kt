package com.example

import androidx.compose.ui.geometry.Offset
import com.example.assets.DeckLevel
import com.example.assets.OperationalStatus
import com.example.assets.TelemetryQuality
import com.example.assets.ViewProjectionMode
import com.example.data.SeedData
import com.example.engineering.AvailabilityCalculator
import com.example.security.AuthorizationGuard
import com.example.security.OperatorRole
import com.example.shipview.ShipCoordinateModel
import com.example.shipview.ShipViewportTransform
import com.example.simulation.SimulationEngine
import com.example.simulation.SimulationRuntimeState
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ResoluteDomainUnitTest {

    @Test
    fun `hit testing remains exact across top, isometric, pan, zoom, and rotation`() {
        val assets = SeedData.initialAssets()
        val ac04 = assets.first { it.id == "AC-04" }
        val w = 1200f
        val h = 700f

        val transforms = listOf(
            ViewProjectionMode.TOP to ShipViewportTransform(zoom = 1.0f, panX = 0f, panY = 0f, rotationDeg = 0f),
            ViewProjectionMode.TOP to ShipViewportTransform(zoom = 1.85f, panX = 140f, panY = -95f, rotationDeg = 18f),
            ViewProjectionMode.ISOMETRIC to ShipViewportTransform(zoom = 1.0f, panX = 0f, panY = 0f, rotationDeg = 0f),
            ViewProjectionMode.ISOMETRIC to ShipViewportTransform(zoom = 2.1f, panX = -160f, panY = 85f, rotationDeg = -25f)
        )

        transforms.forEach { (mode, transform) ->
            val screenPoint = ShipCoordinateModel.project(
                shipX = ac04.shipX,
                shipY = ac04.shipY,
                shipZ = DeckLevel.FLIGHT_DECK.zElevation,
                viewMode = mode,
                transform = transform,
                canvasWidth = w,
                canvasHeight = h
            )
            val hit = ShipCoordinateModel.hitTestAsset(
                tapOffset = Offset(screenPoint.x + 2f, screenPoint.y - 2f),
                activeDeck = DeckLevel.FLIGHT_DECK,
                assets = assets,
                viewMode = mode,
                transform = transform,
                canvasWidth = w,
                canvasHeight = h
            )
            assertNotNull("Expected AC-04 hit in $mode with $transform", hit)
            assertEquals("AC-04", hit?.id)
        }
    }

    @Test
    fun `stale green equipment degrades to STALE and reduces engineering availability`() {
        val baseline = SeedData.initialAssets()
        val baseAvail = AvailabilityCalculator.computeEngineeringAvailability(baseline)
        assertEquals(7, baseAvail.availableUnits)
        assertEquals(7, baseAvail.totalUnits)
        assertEquals(0, baseAvail.staleOrUnknownUnits)
        assertEquals(100.0, baseAvail.percentage ?: 0.0, 0.01)

        val staleBundle = SimulationEngine.applyScenario("SCEN-06", SimulationRuntimeState())
        val hvBus = staleBundle.assets.first { it.id == "HV-BUS-B" }
        assertEquals(OperationalStatus.STALE, hvBus.operationalStatus)
        assertEquals(TelemetryQuality.STALE, hvBus.telemetryQuality)

        val staleAvail = AvailabilityCalculator.computeEngineeringAvailability(staleBundle.assets)
        assertEquals(3, staleAvail.staleOrUnknownUnits)
        assertEquals(4, staleAvail.availableUnits)
        assertEquals(TelemetryQuality.STALE, staleAvail.quality)
    }

    @Test
    fun `role permissions enforce executive viewer read only and supervisor review authority`() {
        val execReview = AuthorizationGuard.check(OperatorRole.EXECUTIVE_VIEWER, "authorise review") {
            it.canAuthoriseReview
        }
        assertFalse(execReview.permitted)

        val maintReview = AuthorizationGuard.check(OperatorRole.MAINTENANCE_STAFF, "authorise review") {
            it.canAuthoriseReview
        }
        assertFalse(maintReview.permitted)

        val maintSubmit = AuthorizationGuard.check(OperatorRole.MAINTENANCE_STAFF, "submit completion") {
            it.canSubmitCompletion
        }
        assertTrue(maintSubmit.permitted)

        val supvReview = AuthorizationGuard.check(OperatorRole.DEPARTMENT_SUPERVISOR, "authorise review") {
            it.canAuthoriseReview
        }
        assertTrue(supvReview.permitted)
    }
}
