from fastapi import FastAPI, Header, HTTPException
from fastapi.responses import JSONResponse

from models import (
    AvailabilityUpdateRequest,
    HandoverCreateRequest,
    OperatorRole,
    SimControlRequest,
    WorkOrderTransitionRequest,
)
from simulator import DeterministicSimulator, SCENARIOS

app = FastAPI(
    title="HMS RESOLUTE — Admiral Class Simulation Backend",
    version="1.0.0",
    description="Deterministic fictional aircraft carrier executive command simulator (Information & Coordination Only).",
)

sim = DeterministicSimulator()


def parse_role(x_operator_role: str) -> OperatorRole:
    try:
        return OperatorRole(x_operator_role)
    except ValueError:
        raise HTTPException(status_code=403, detail=f"Invalid operator role '{x_operator_role}'")


@app.get("/health")
def get_health():
    return {
        "status": "ok",
        "ship": "HMS RESOLUTE (R09)",
        "simulation_mode": True,
        "sim_time_utc": sim.sim_time_utc(),
        "scenario_id": sim.scenario_id,
    }


@app.get("/api/v1/scenarios")
def get_scenarios():
    return {"scenarios": SCENARIOS}


@app.get("/api/v1/state")
def get_state():
    return {
        "sim_time_utc": sim.sim_time_utc(),
        "scenario_id": sim.scenario_id,
        "paused": sim.paused,
        "speed": sim.speed,
        "assets": [a.model_dump() for a in sim.assets.values()],
        "work_orders": [w.model_dump() for w in sim.work_orders.values()],
        "handovers": [h.model_dump() for h in sim.handovers],
    }


@app.post("/api/v1/simulation/control")
def control_simulation(
    body: SimControlRequest,
    x_operator_role: str = Header(default="DEPARTMENT_SUPERVISOR"),
):
    role = parse_role(x_operator_role)
    if role == OperatorRole.AUDITOR:
        raise HTTPException(status_code=403, detail="Auditors cannot mutate simulation state.")

    if body.action == "pause":
        sim.paused = True
    elif body.action == "play":
        sim.paused = False
    elif body.action == "reset":
        sim.reset()
    elif body.action == "step":
        sim.step(body.step_minutes or 5)
    elif body.action == "set_speed" and body.speed is not None:
        sim.speed = body.speed
    elif body.action == "load_scenario" and body.scenario_id:
        sim.load_scenario(body.scenario_id)
    else:
        raise HTTPException(status_code=400, detail="Unsupported simulation control action.")

    return get_health()


@app.post("/api/v1/work-orders/{task_id}/transition")
def transition_work_order(
    task_id: str,
    body: WorkOrderTransitionRequest,
    x_operator_role: str = Header(default="MAINTENANCE_STAFF"),
):
    role = parse_role(x_operator_role)
    code, ack = sim.transition_work_order(task_id, role, body)
    return JSONResponse(status_code=code, content=ack.model_dump())


@app.post("/api/v1/assets/{asset_id}/availability")
def update_availability(
    asset_id: str,
    body: AvailabilityUpdateRequest,
    x_operator_role: str = Header(default="DEPARTMENT_SUPERVISOR"),
):
    role = parse_role(x_operator_role)
    code, ack = sim.update_availability(asset_id, role, body)
    return JSONResponse(status_code=code, content=ack.model_dump())


@app.post("/api/v1/handovers")
def create_handover(
    body: HandoverCreateRequest,
    x_operator_role: str = Header(default="DEPARTMENT_SUPERVISOR"),
):
    role = parse_role(x_operator_role)
    code, ack = sim.create_handover(role, body)
    return JSONResponse(status_code=code, content=ack.model_dump())


@app.get("/api/v1/audit")
def get_audit():
    return {"events": sim.audit_log}
