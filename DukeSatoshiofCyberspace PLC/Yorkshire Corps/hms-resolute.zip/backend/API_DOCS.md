# HMS RESOLUTE — FastAPI Simulation Backend API Documentation

Base URL (Android Emulator): `http://10.0.2.2:8000/`  
Base URL (Localhost): `http://127.0.0.1:8000/`

All mutating endpoints enforce RBAC via `X-Operator-Role`:
`EXECUTIVE_VIEWER`, `MAINTENANCE_STAFF`, `DEPARTMENT_SUPERVISOR`, `ADMINISTRATOR`, `AUDITOR`.

## Endpoints

### `GET /health`
Returns server status, simulation mode flag, current `sim_time_utc`, and active `scenario_id`.

### `GET /api/v1/scenarios`
Lists the 8 deterministic scenarios (`SCEN-01` .. `SCEN-08`).

### `GET /api/v1/state`
Returns full snapshot of `assets`, `work_orders`, and versioned `handovers`.

### `POST /api/v1/simulation/control`
Body: `{ "action": "pause" | "play" | "reset" | "step" | "set_speed" | "load_scenario", "step_minutes": 5, "speed": 2.0, "scenario_id": "SCEN-04" }`

### `POST /api/v1/work-orders/{task_id}/transition`
Body: `{ "idempotency_key": "...", "expected_version": 3, "target_status": "AWAITING_REVIEW", "assigned_team": "Team E-2", "completion_evidence": "...", "actor_name": "..." }`
- Returns `409 Conflict` if `expected_version` does not match server version.
- Deduplicates duplicate requests sharing the same `idempotency_key`.
- Returns `403 Forbidden` if operator role lacks permission.

### `POST /api/v1/assets/{asset_id}/availability`
Body: `{ "idempotency_key": "...", "operational_status": "READY", "maintenance_state": "Serviceable", "actor_name": "..." }`
- Blocks setting `READY` while unreviewed/open work orders exist on the asset (`409 Conflict`).

### `POST /api/v1/handovers`
Appends a new shift handover version (`version_number + 1`) while preserving all prior versions (`is_latest = false` on superseded records).

### `GET /api/v1/audit`
Returns application-generated audit events with simulation and device UTC timestamps.
