from fastapi.testclient import TestClient
from main import app, sim


client = TestClient(app)


def test_full_ac04_and_reliability_workflow():
    sim.reset()
    assert client.get("/health").status_code == 200

    # Executive Viewer cannot authorise work order transition
    denied = client.post(
        "/api/v1/work-orders/WO-404/transition",
        headers={"X-Operator-Role": "EXECUTIVE_VIEWER"},
        json={
            "idempotency_key": "k-denied",
            "expected_version": 3,
            "target_status": "AWAITING_REVIEW",
            "actor_name": "CAPT Sterling",
        },
    )
    assert denied.status_code == 403

    # Step simulation
    step = client.post(
        "/api/v1/simulation/control",
        headers={"X-Operator-Role": "DEPARTMENT_SUPERVISOR"},
        json={"action": "step", "step_minutes": 5},
    )
    assert step.status_code == 200

    # Submit completion as Maintenance Staff (v3 -> v4)
    submit = client.post(
        "/api/v1/work-orders/WO-404/transition",
        headers={"X-Operator-Role": "MAINTENANCE_STAFF"},
        json={
            "idempotency_key": "k-submit-1",
            "expected_version": 3,
            "target_status": "AWAITING_REVIEW",
            "completion_evidence": "Pressure test passed",
            "actor_name": "PO Thorne",
        },
    )
    assert submit.status_code == 200
    assert submit.json()["new_version"] == 4

    # Idempotent retry returns same v4 without conflict
    retry = client.post(
        "/api/v1/work-orders/WO-404/transition",
        headers={"X-Operator-Role": "MAINTENANCE_STAFF"},
        json={
            "idempotency_key": "k-submit-1",
            "expected_version": 3,
            "target_status": "AWAITING_REVIEW",
            "completion_evidence": "Pressure test passed",
            "actor_name": "PO Thorne",
        },
    )
    assert retry.status_code == 200
    assert retry.json()["new_version"] == 4

    # Cannot mark AC-04 READY before authorised review
    early_release = client.post(
        "/api/v1/assets/AC-04/availability",
        headers={"X-Operator-Role": "DEPARTMENT_SUPERVISOR"},
        json={
            "idempotency_key": "k-avail-early",
            "operational_status": "READY",
            "maintenance_state": "Ready",
            "actor_name": "CDR Vane",
        },
    )
    assert early_release.status_code == 409

    # Authorised review by Supervisor (v4 -> v5)
    review = client.post(
        "/api/v1/work-orders/WO-404/transition",
        headers={"X-Operator-Role": "DEPARTMENT_SUPERVISOR"},
        json={
            "idempotency_key": "k-review-1",
            "expected_version": 4,
            "target_status": "COMPLETE",
            "review_comment": "Approved",
            "actor_name": "CDR Vane",
        },
    )
    assert review.status_code == 200
    assert review.json()["new_version"] == 5

    # Now availability update succeeds
    release = client.post(
        "/api/v1/assets/AC-04/availability",
        headers={"X-Operator-Role": "DEPARTMENT_SUPERVISOR"},
        json={
            "idempotency_key": "k-avail-ok",
            "operational_status": "READY",
            "maintenance_state": "Serviceable",
            "actor_name": "CDR Vane",
        },
    )
    assert release.status_code == 200

    # Shift handover preserves prior version
    ho = client.post(
        "/api/v1/handovers",
        headers={"X-Operator-Role": "DEPARTMENT_SUPERVISOR"},
        json={
            "idempotency_key": "k-ho-2",
            "outgoing_team": "ALPHA WATCH",
            "incoming_team": "BRAVO WATCH",
            "outstanding_tasks": "WO-404 closed",
            "equipment_issues": "None",
            "logistics_notes": "Nominal",
            "supersedes_handover_id": "HO-20261121-01",
            "actor_name": "CDR Vane",
        },
    )
    assert ho.status_code == 200
    state = client.get("/api/v1/state").json()
    assert len(state["handovers"]) == 2
    assert state["handovers"][0]["is_latest"] is False
    assert state["handovers"][1]["is_latest"] is True
