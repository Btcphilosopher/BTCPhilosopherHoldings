from enum import Enum
from typing import List, Optional
from pydantic import BaseModel, Field


class OperatorRole(str, Enum):
    EXECUTIVE_VIEWER = "EXECUTIVE_VIEWER"
    MAINTENANCE_STAFF = "MAINTENANCE_STAFF"
    DEPARTMENT_SUPERVISOR = "DEPARTMENT_SUPERVISOR"
    ADMINISTRATOR = "ADMINISTRATOR"
    AUDITOR = "AUDITOR"


class SimControlRequest(BaseModel):
    action: str  # pause, play, reset, step, set_speed, load_scenario
    speed: Optional[float] = None
    scenario_id: Optional[str] = None
    step_minutes: Optional[int] = 5


class WorkOrderTransitionRequest(BaseModel):
    idempotency_key: str
    expected_version: int
    target_status: str
    assigned_team: Optional[str] = None
    completion_evidence: Optional[str] = None
    note: Optional[str] = None
    review_comment: Optional[str] = None
    actor_name: str


class AvailabilityUpdateRequest(BaseModel):
    idempotency_key: str
    operational_status: str
    maintenance_state: str
    actor_name: str


class HandoverCreateRequest(BaseModel):
    idempotency_key: str
    outgoing_team: str
    incoming_team: str
    outstanding_tasks: str
    equipment_issues: str
    logistics_notes: str
    supersedes_handover_id: Optional[str] = None
    actor_name: str


class AssetRecord(BaseModel):
    id: str
    callsign: str
    asset_type: str
    category: str
    deck_level: str
    ship_x: float
    ship_y: float
    heading_deg: float
    location_label: str
    maintenance_state: str
    operational_status: str
    assigned_team: str
    last_update_utc: str
    telemetry_age_sec: int
    telemetry_quality: str
    data_source: str
    maintenance_progress_pct: int


class WorkOrderRecord(BaseModel):
    task_id: str
    asset_id: str
    zone_label: str
    title: str
    status: str
    assigned_team: str
    version: int
    completion_evidence: str = ""
    notes: str = ""
    review_history: List[dict] = Field(default_factory=list)


class HandoverRecord(BaseModel):
    handover_id: str
    version_number: int
    supersedes_handover_id: Optional[str] = None
    outgoing_team: str
    incoming_team: str
    outstanding_tasks: str
    equipment_issues: str
    logistics_notes: str
    created_by: str
    created_utc: str
    is_latest: bool = True


class MutationAck(BaseModel):
    accepted: bool
    idempotency_key: str
    new_version: Optional[int] = None
    conflict: bool = False
    message: str
