from datetime import datetime, timezone, timedelta
from typing import Dict, List, Optional
from models import (
    AssetRecord,
    AvailabilityUpdateRequest,
    HandoverCreateRequest,
    HandoverRecord,
    MutationAck,
    OperatorRole,
    WorkOrderRecord,
    WorkOrderTransitionRequest,
)


SCENARIOS = [
    {"id": "SCEN-01", "number": 1, "title": "Normal Operations"},
    {"id": "SCEN-02", "number": 2, "title": "Aircraft Inspection (AC-04)"},
    {"id": "SCEN-03", "number": 3, "title": "Service Vehicle Tasking"},
    {"id": "SCEN-04", "number": 4, "title": "Aft Lift Unavailable"},
    {"id": "SCEN-05", "number": 5, "title": "Weather Information Update"},
    {"id": "SCEN-06", "number": 6, "title": "Stale Engineering Telemetry"},
    {"id": "SCEN-07", "number": 7, "title": "Shift Handover"},
    {"id": "SCEN-08", "number": 8, "title": "Connection Loss & Recovery"},
]


class DeterministicSimulator:
    def __init__(self):
        self.reset()

    def reset(self):
        self.sim_epoch = datetime(2026, 11, 21, 8, 0, 0, tzinfo=timezone.utc)
        self.scenario_id = "SCEN-02"
        self.paused = False
        self.speed = 1.0
        self.seen_idempotency_keys: Dict[str, MutationAck] = {}
        self.audit_log: List[dict] = []
        self.assets: Dict[str, AssetRecord] = {
            "AC-01": AssetRecord(
                id="AC-01", callsign="RESOLUTE-01", asset_type="F-35B Lightning II (Sim)",
                category="AIRCRAFT", deck_level="FLIGHT_DECK", ship_x=740, ship_y=105,
                heading_deg=12, location_label="Fwd Park Alpha-1",
                maintenance_state="Serviceable / Scheduled Pre-check",
                operational_status="READY", assigned_team="Team A-1",
                last_update_utc="07:59:10Z", telemetry_age_sec=50,
                telemetry_quality="LIVE", data_source="Flight Deck Maintenance Bus",
                maintenance_progress_pct=100,
            ),
            "AC-04": AssetRecord(
                id="AC-04", callsign="RESOLUTE-04", asset_type="F-35B Lightning II (Sim)",
                category="AIRCRAFT", deck_level="FLIGHT_DECK", ship_x=415, ship_y=232,
                heading_deg=270, location_label="Stbd Maint Spot Delta-4",
                maintenance_state="Inspection in progress",
                operational_status="MAINTENANCE", assigned_team="Team E-2",
                last_update_utc="07:59:40Z", telemetry_age_sec=20,
                telemetry_quality="LIVE", data_source="Air Engineering Desk (AEMIS)",
                maintenance_progress_pct=62,
            ),
            "TUG-02": AssetRecord(
                id="TUG-02", callsign="DECK-TUG-02", asset_type="Hydro-Utility Tow Tug",
                category="SERVICE_VEHICLE", deck_level="FLIGHT_DECK", ship_x=355, ship_y=212,
                heading_deg=90, location_label="Stbd Island Approach",
                maintenance_state="Assigned — Supporting AC-04",
                operational_status="CAUTION", assigned_team="Team E-2",
                last_update_utc="07:59:52Z", telemetry_age_sec=8,
                telemetry_quality="LIVE", data_source="Deck Telemetry Beacon",
                maintenance_progress_pct=100,
            ),
            "LIFT-AFT": AssetRecord(
                id="LIFT-AFT", callsign="AFT-LIFT-2", asset_type="70-Tonne Stbd Aircraft Lift",
                category="AIRCRAFT_LIFT", deck_level="FLIGHT_DECK", ship_x=335, ship_y=298,
                heading_deg=0, location_label="Starboard Aft Lift",
                maintenance_state="Operational — Safety Pins Clear",
                operational_status="READY", assigned_team="ME Hull Team",
                last_update_utc="07:59:42Z", telemetry_age_sec=18,
                telemetry_quality="LIVE", data_source="Platform Management Read-Only Adapter",
                maintenance_progress_pct=100,
            ),
            "HV-BUS-B": AssetRecord(
                id="HV-BUS-B", callsign="HV-SWITCHBOARD-B", asset_type="11 kV Distribution Switchboard",
                category="ENGINEERING_SYSTEM", deck_level="SYSTEMS", ship_x=460, ship_y=225,
                heading_deg=0, location_label="Aft Main Switchboard",
                maintenance_state="Closed Ring — Nominal 11.0 kV",
                operational_status="READY", assigned_team="WE/ME Electrical",
                last_update_utc="07:59:46Z", telemetry_age_sec=14,
                telemetry_quality="LIVE", data_source="IPMS Read-Only Adapter",
                maintenance_progress_pct=100,
            ),
        }
        self.work_orders: Dict[str, WorkOrderRecord] = {
            "WO-404": WorkOrderRecord(
                task_id="WO-404",
                asset_id="AC-04",
                zone_label="Stbd Maint Spot Delta-4",
                title="Starboard Hydraulic Manifold & Avionics Bay Inspection",
                status="IN_PROGRESS",
                assigned_team="Team E-2",
                version=3,
                completion_evidence="",
                notes="Team E-2 hydraulic pressure decay test active.",
            )
        }
        self.handovers: List[HandoverRecord] = [
            HandoverRecord(
                handover_id="HO-20261121-01",
                version_number=1,
                outgoing_team="FOXTROT WATCH",
                incoming_team="ALPHA WATCH",
                outstanding_tasks="WO-404 on AC-04 at 62%",
                equipment_issues="Nominal",
                logistics_notes="F-44 76.7%",
                created_by="LT CDR B. Lowe",
                created_utc="06:58:00Z",
                is_latest=True,
            )
        ]

    def sim_time_utc(self) -> str:
        return self.sim_epoch.strftime("%Y-%m-%dT%H:%M:%SZ")

    def short_utc(self) -> str:
        return self.sim_epoch.strftime("%H:%M:%SZ")

    def step(self, minutes: int):
        self.sim_epoch += timedelta(minutes=minutes)
        ac04 = self.assets.get("AC-04")
        if ac04 and ac04.operational_status == "MAINTENANCE":
            ac04.maintenance_progress_pct = min(98, ac04.maintenance_progress_pct + 10)
            ac04.last_update_utc = self.short_utc()
        if self.scenario_id == "SCEN-06":
            bus = self.assets.get("HV-BUS-B")
            if bus:
                bus.telemetry_age_sec += minutes * 60
                bus.telemetry_quality = "STALE"
                bus.operational_status = "STALE"
        self.log_event("SIM_STEP", "SIMULATOR", "SYSTEM", f"Stepped +{minutes}m to {self.sim_time_utc()}")

    def load_scenario(self, scenario_id: str):
        self.reset()
        self.scenario_id = scenario_id
        if scenario_id == "SCEN-01":
            self.assets["AC-04"].operational_status = "READY"
            self.assets["AC-04"].maintenance_progress_pct = 100
        elif scenario_id == "SCEN-04":
            self.assets["LIFT-AFT"].operational_status = "UNAVAILABLE"
            self.assets["LIFT-AFT"].maintenance_state = "UNAVAILABLE — Interlock Fault"
        elif scenario_id == "SCEN-06":
            bus = self.assets["HV-BUS-B"]
            bus.telemetry_age_sec = 245
            bus.telemetry_quality = "STALE"
            bus.operational_status = "STALE"
        self.log_event("SCENARIO_LOAD", scenario_id, "SYSTEM", f"Loaded {scenario_id}")

    def transition_work_order(self, task_id: str, role: OperatorRole, req: WorkOrderTransitionRequest) -> tuple[int, MutationAck]:
        if req.idempotency_key in self.seen_idempotency_keys:
            return 200, self.seen_idempotency_keys[req.idempotency_key]

        if req.target_status == "COMPLETE" and role not in (OperatorRole.DEPARTMENT_SUPERVISOR, OperatorRole.ADMINISTRATOR):
            return 403, MutationAck(accepted=False, idempotency_key=req.idempotency_key, message=f"Role {role.value} cannot authorise completion review.")
        if role in (OperatorRole.EXECUTIVE_VIEWER, OperatorRole.AUDITOR):
            return 403, MutationAck(accepted=False, idempotency_key=req.idempotency_key, message=f"Role {role.value} is read-only.")

        wo = self.work_orders.get(task_id)
        if not wo:
            return 404, MutationAck(accepted=False, idempotency_key=req.idempotency_key, message=f"Unknown task {task_id}")
        if wo.version != req.expected_version:
            ack = MutationAck(
                accepted=False,
                idempotency_key=req.idempotency_key,
                conflict=True,
                new_version=wo.version,
                message=f"Version conflict: expected v{req.expected_version}, current v{wo.version}.",
            )
            return 409, ack

        wo.status = req.target_status
        if req.assigned_team:
            wo.assigned_team = req.assigned_team
        if req.completion_evidence:
            wo.completion_evidence = req.completion_evidence
        if req.note:
            wo.notes = req.note
        wo.review_history.append({
            "actor": req.actor_name,
            "role": role.value,
            "target_status": req.target_status,
            "comment": req.review_comment or "",
            "timestamp_utc": self.short_utc(),
        })
        wo.version += 1
        ack = MutationAck(
            accepted=True,
            idempotency_key=req.idempotency_key,
            new_version=wo.version,
            message=f"{task_id} transitioned to {wo.status} (v{wo.version}).",
        )
        self.seen_idempotency_keys[req.idempotency_key] = ack
        self.log_event("WO_TRANSITION", task_id, req.actor_name, ack.message)
        return 200, ack

    def update_availability(self, asset_id: str, role: OperatorRole, req: AvailabilityUpdateRequest) -> tuple[int, MutationAck]:
        if req.idempotency_key in self.seen_idempotency_keys:
            return 200, self.seen_idempotency_keys[req.idempotency_key]
        if role not in (OperatorRole.DEPARTMENT_SUPERVISOR, OperatorRole.ADMINISTRATOR):
            return 403, MutationAck(accepted=False, idempotency_key=req.idempotency_key, message="Supervisor/Admin role required to release equipment availability.")

        asset = self.assets.get(asset_id)
        if not asset:
            return 404, MutationAck(accepted=False, idempotency_key=req.idempotency_key, message=f"Unknown asset {asset_id}")

        # Enforce review-before-release rule
        if req.operational_status == "READY":
            open_wos = [w for w in self.work_orders.values() if w.asset_id == asset_id and w.status not in ("COMPLETE", "CANCELLED")]
            if open_wos:
                return 409, MutationAck(
                    accepted=False,
                    idempotency_key=req.idempotency_key,
                    conflict=True,
                    message=f"Cannot mark {asset_id} READY until work orders complete authorised review: {[w.task_id for w in open_wos]}",
                )

        asset.operational_status = req.operational_status
        asset.maintenance_state = req.maintenance_state
        asset.last_update_utc = self.short_utc()
        asset.telemetry_age_sec = 0
        ack = MutationAck(accepted=True, idempotency_key=req.idempotency_key, message=f"{asset_id} availability set to {req.operational_status}.")
        self.seen_idempotency_keys[req.idempotency_key] = ack
        self.log_event("AVAILABILITY_UPDATE", asset_id, req.actor_name, ack.message)
        return 200, ack

    def create_handover(self, role: OperatorRole, req: HandoverCreateRequest) -> tuple[int, MutationAck]:
        if req.idempotency_key in self.seen_idempotency_keys:
            return 200, self.seen_idempotency_keys[req.idempotency_key]
        if role not in (OperatorRole.DEPARTMENT_SUPERVISOR, OperatorRole.ADMINISTRATOR):
            return 403, MutationAck(accepted=False, idempotency_key=req.idempotency_key, message="Supervisor/Admin role required for shift handover.")

        for h in self.handovers:
            h.is_latest = False
        next_ver = len(self.handovers) + 1
        ho_id = f"HO-20261121-{next_ver:02d}"
        self.handovers.append(
            HandoverRecord(
                handover_id=ho_id,
                version_number=next_ver,
                supersedes_handover_id=req.supersedes_handover_id,
                outgoing_team=req.outgoing_team,
                incoming_team=req.incoming_team,
                outstanding_tasks=req.outstanding_tasks,
                equipment_issues=req.equipment_issues,
                logistics_notes=req.logistics_notes,
                created_by=req.actor_name,
                created_utc=self.short_utc(),
                is_latest=True,
            )
        )
        ack = MutationAck(accepted=True, idempotency_key=req.idempotency_key, new_version=next_ver, message=f"Handover {ho_id} v{next_ver} recorded.")
        self.seen_idempotency_keys[req.idempotency_key] = ack
        self.log_event("HANDOVER_CREATE", ho_id, req.actor_name, ack.message)
        return 200, ack

    def log_event(self, action_type: str, target_id: str, actor: str, summary: str):
        self.audit_log.insert(0, {
            "sim_time_utc": self.sim_time_utc(),
            "device_time_utc": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
            "action_type": action_type,
            "target_id": target_id,
            "actor": actor,
            "summary": summary,
        })
