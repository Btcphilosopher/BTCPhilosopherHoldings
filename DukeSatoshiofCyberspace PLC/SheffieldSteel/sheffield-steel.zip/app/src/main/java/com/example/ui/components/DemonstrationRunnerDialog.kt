package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.ui.theme.*
import com.example.ui.viewmodel.DemoStepInfo

@Composable
fun DemonstrationRunnerDialog(
    steps: List<DemoStepInfo>,
    currentStepIndex: Int,
    onExecuteStep: (Int) -> Unit,
    onDismiss: () -> Unit
) {
    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            color = Color(0xFF14171D),
            shape = RoundedCornerShape(8.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, SheffieldBorder),
            modifier = Modifier
                .fillMaxWidth(0.90f)
                .fillMaxHeight(0.85f)
                .testTag("demonstration_runner_dialog")
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                // Header
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column {
                        Text(
                            text = "SHEFFIELD STEELWORKS · COMPLETE PRODUCTION JOURNEY",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MoltenGold
                        )
                        Text(
                            text = "11-Step Interactive Demonstration: Raw Scrap → Melt → Quality Hold & Release → Rolling → Dispatch",
                            style = MaterialTheme.typography.bodySmall,
                            color = SheffieldIvoryMuted
                        )
                    }

                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = SheffieldIvory)
                    }
                }

                HorizontalDivider(color = SheffieldBorder, modifier = Modifier.padding(vertical = 12.dp))

                // Steps List
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    itemsIndexed(steps) { idx, step ->
                        val isDone = idx < currentStepIndex
                        val isCurrent = idx == currentStepIndex

                        val itemBg = when {
                            isCurrent -> Color(0xFF2B2011)
                            isDone -> Color(0xFF112017)
                            else -> Color(0xFF191D24)
                        }

                        val borderColor = when {
                            isCurrent -> MoltenOrange
                            isDone -> SignalGreen
                            else -> SheffieldBorderSubtle
                        }

                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(6.dp))
                                .background(itemBg)
                                .border(1.dp, borderColor, RoundedCornerShape(6.dp))
                                .clickable { onExecuteStep(idx) }
                                .padding(12.dp)
                                .testTag("demo_step_$idx")
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(12.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                // Step Index Circle
                                Box(
                                    contentAlignment = Alignment.Center,
                                    modifier = Modifier
                                        .size(28.dp)
                                        .clip(CircleShape)
                                        .background(if (isDone) SignalGreen else if (isCurrent) MoltenOrange else SheffieldCardElevated)
                                ) {
                                    if (isDone) {
                                        Icon(Icons.Default.Check, contentDescription = null, tint = Color.Black, modifier = Modifier.size(16.dp))
                                    } else {
                                        Text(
                                            text = "${idx + 1}",
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 12.sp,
                                            color = if (isCurrent) Color.Black else SheffieldIvory
                                        )
                                    }
                                }

                                Column {
                                    Text(
                                        text = step.title,
                                        style = MaterialTheme.typography.titleSmall,
                                        fontWeight = FontWeight.Bold,
                                        color = if (isCurrent) MoltenGold else SheffieldIvory
                                    )
                                    Text(
                                        text = step.description,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = SheffieldIvoryMuted
                                    )
                                    Text(
                                        text = "WORKSPACE: ${step.targetTab.label.uppercase()}",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = ElectricArcBlue,
                                        fontSize = 9.sp
                                    )
                                }
                            }

                            Button(
                                onClick = { onExecuteStep(idx) },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (isCurrent) MoltenOrange else SheffieldCardElevated,
                                    contentColor = if (isCurrent) Color.Black else SheffieldIvory
                                ),
                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                                shape = RoundedCornerShape(4.dp)
                            ) {
                                Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = if (isDone) "RE-RUN" else "EXECUTE",
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }

                HorizontalDivider(color = SheffieldBorder, modifier = Modifier.padding(vertical = 12.dp))

                // Bottom Auto-Step Action
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "Current demonstration progress: ${currentStepIndex} of ${steps.size} steps executed",
                        style = MaterialTheme.typography.bodySmall,
                        color = SheffieldIvoryDim
                    )

                    Button(
                        onClick = {
                            val next = (currentStepIndex + 1) % steps.size
                            onExecuteStep(next)
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MoltenOrange,
                            contentColor = Color(0xFF0F0A05)
                        ),
                        shape = RoundedCornerShape(4.dp)
                    ) {
                        Text(
                            text = "EXECUTE NEXT STEP ▶",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}
