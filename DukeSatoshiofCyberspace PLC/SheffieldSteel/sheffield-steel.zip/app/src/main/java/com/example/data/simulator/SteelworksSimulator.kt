package com.example.data.simulator

import com.example.data.local.entities.*
import com.example.data.model.*
import kotlin.math.roundToInt

data class MassBalanceResult(
    val targetGrade: SteelGrade,
    val targetTonnes: Double,
    val totalChargeWeightTonnes: Double,
    val expectedLiquidSteelTonnes: Double,
    val expectedMetallicYieldPct: Double,
    val estimatedSlagTonnes: Double,
    val predictedCarbonPct: Double,
    val predictedSiliconPct: Double,
    val predictedManganesePct: Double,
    val predictedPhosphorusPct: Double,
    val predictedSulfurPct: Double,
    val isFeasible: Boolean,
    val limitingFactor: String,
    val estimatedMaterialCostGbp: Double,
    val estimatedCostPerTonneGbp: Double
)

object SteelworksSimulator {

    fun calculateMassBalance(
        grade: SteelGrade,
        targetLiquidTonnes: Double,
        hms1Ratio: Double = 0.50,
        psRatio: Double = 0.30,
        shreddedRatio: Double = 0.15,
        alloysRatio: Double = 0.05
    ): MassBalanceResult {
        // Metallic recovery factors based on industry Sheffield EAF practice
        val hmsRecovery = 0.94
        val psRecovery = 0.97
        val shredRecovery = 0.91
        val alloyRecovery = 0.88

        val weightedRecovery = (hms1Ratio * hmsRecovery) +
                (psRatio * psRecovery) +
                (shreddedRatio * shredRecovery) +
                (alloysRatio * alloyRecovery)

        val totalChargeWeight = targetLiquidTonnes / weightedRecovery
        val liquidSteelTonnes = targetLiquidTonnes
        val yieldPct = (liquidSteelTonnes / totalChargeWeight) * 100.0
        val slagAndLossTonnes = totalChargeWeight - liquidSteelTonnes

        // Element balances
        val predictedC = (hms1Ratio * 0.15) + (psRatio * 0.18) + (shreddedRatio * 0.22) + (alloysRatio * 0.85)
        val predictedSi = (hms1Ratio * 0.20) + (psRatio * 0.28) + (shreddedRatio * 0.18) + (alloysRatio * 1.50)
        val predictedMn = (hms1Ratio * 0.55) + (psRatio * 0.65) + (shreddedRatio * 0.45) + (alloysRatio * 14.5)
        val predictedP = (hms1Ratio * 0.025) + (psRatio * 0.018) + (shreddedRatio * 0.035) + (alloysRatio * 0.02)
        val predictedS = (hms1Ratio * 0.032) + (psRatio * 0.020) + (shreddedRatio * 0.040) + (alloysRatio * 0.015)

        // Limiting factors & feasibility
        var feasible = true
        var limiting = "All elements within specification envelope"
        if (predictedS > grade.maxSulfur) {
            feasible = false
            limiting = "Sulfur ${String.format("%.3f", predictedS)}% exceeds max ${grade.maxSulfur}% (Requires secondary desulfurizing slag flux)"
        } else if (predictedP > grade.maxPhosphorus) {
            feasible = false
            limiting = "Phosphorus ${String.format("%.3f", predictedP)}% exceeds max ${grade.maxPhosphorus}%"
        }

        // Cost estimation based on market scrap tariffs (£240/t HMS, £265/t P&S, £215/t Shred, £1,150/t Alloys)
        val hmsCost = (totalChargeWeight * hms1Ratio) * 242.0
        val psCost = (totalChargeWeight * psRatio) * 268.0
        val shredCost = (totalChargeWeight * shreddedRatio) * 218.0
        val alloyCost = (totalChargeWeight * alloysRatio) * 1120.0
        val totalCost = hmsCost + psCost + shredCost + alloyCost
        val costPerTonne = totalCost / liquidSteelTonnes

        return MassBalanceResult(
            targetGrade = grade,
            targetTonnes = targetLiquidTonnes,
            totalChargeWeightTonnes = (totalChargeWeight * 10.0).roundToInt() / 10.0,
            expectedLiquidSteelTonnes = liquidSteelTonnes,
            expectedMetallicYieldPct = (yieldPct * 10.0).roundToInt() / 10.0,
            estimatedSlagTonnes = (slagAndLossTonnes * 10.0).roundToInt() / 10.0,
            predictedCarbonPct = (predictedC * 100.0).roundToInt() / 100.0,
            predictedSiliconPct = (predictedSi * 100.0).roundToInt() / 100.0,
            predictedManganesePct = (predictedMn * 100.0).roundToInt() / 100.0,
            predictedPhosphorusPct = (predictedP * 1000.0).roundToInt() / 1000.0,
            predictedSulfurPct = (predictedS * 1000.0).roundToInt() / 1000.0,
            isFeasible = feasible,
            limitingFactor = limiting,
            estimatedMaterialCostGbp = totalCost,
            estimatedCostPerTonneGbp = (costPerTonne * 10.0).roundToInt() / 10.0
        )
    }

    // Default Seed Data that populates the terminal on fresh launch
    fun generateInitialSeedData(currentTime: Long = System.currentTimeMillis()): SeedDataBundle {
        val scrapItems = listOf(
            ScrapInventoryItem(
                id = "LOT-HMS1-4401",
                category = "HMS-1",
                supplier = "British Metal Recycling Ltd",
                availableTonnes = 840.0,
                reservedTonnes = 135.0,
                quarantinedTonnes = 0.0,
                unitCostGbp = 242.50,
                locationBay = "Yard Bay 1-A",
                fePct = 98.4,
                carbonPct = 0.16,
                siliconPct = 0.22,
                manganesePct = 0.58,
                phosphorusPct = 0.022,
                sulfurPct = 0.024,
                receiptTimestamp = currentTime - 86400000L * 2,
                weighbridgeTicket = "WB-2026-90412"
            ),
            ScrapInventoryItem(
                id = "LOT-PS-2209",
                category = "P&S",
                supplier = "Sheffield Forgemasters Recycled",
                availableTonnes = 520.0,
                reservedTonnes = 65.0,
                quarantinedTonnes = 0.0,
                unitCostGbp = 268.00,
                locationBay = "Yard Bay 2-B",
                fePct = 99.1,
                carbonPct = 0.18,
                siliconPct = 0.28,
                manganesePct = 0.65,
                phosphorusPct = 0.016,
                sulfurPct = 0.018,
                receiptTimestamp = currentTime - 86400000L * 1,
                weighbridgeTicket = "WB-2026-90488"
            ),
            ScrapInventoryItem(
                id = "LOT-SHRED-1190",
                category = "SHRED",
                supplier = "Yorkshire Feeder Yard",
                availableTonnes = 380.0,
                reservedTonnes = 40.0,
                quarantinedTonnes = 0.0,
                unitCostGbp = 218.00,
                locationBay = "Yard Bay 3-C",
                fePct = 95.8,
                carbonPct = 0.22,
                siliconPct = 0.18,
                manganesePct = 0.45,
                phosphorusPct = 0.032,
                sulfurPct = 0.038,
                receiptTimestamp = currentTime - 86400000L * 3,
                weighbridgeTicket = "WB-2026-90372"
            ),
            ScrapInventoryItem(
                id = "LOT-FEMN-088",
                category = "FE-MN-75",
                supplier = "Elkem Alloys UK",
                availableTonnes = 65.0,
                reservedTonnes = 5.2,
                quarantinedTonnes = 0.0,
                unitCostGbp = 1140.00,
                locationBay = "Alloy Bunker 4",
                fePct = 21.0,
                carbonPct = 6.8,
                siliconPct = 1.2,
                manganesePct = 76.4,
                phosphorusPct = 0.08,
                sulfurPct = 0.012,
                receiptTimestamp = currentTime - 86400000L * 5,
                weighbridgeTicket = "WB-2026-90114"
            ),
            ScrapInventoryItem(
                id = "LOT-LIME-552",
                category = "BURNT-LIME",
                supplier = "Buxton Lime Industries",
                availableTonnes = 110.0,
                reservedTonnes = 12.0,
                quarantinedTonnes = 0.0,
                unitCostGbp = 135.00,
                locationBay = "Flux Silo 1",
                fePct = 0.0,
                carbonPct = 0.0,
                siliconPct = 0.0,
                manganesePct = 0.0,
                phosphorusPct = 0.0,
                sulfurPct = 0.0,
                receiptTimestamp = currentTime - 86400000L * 4,
                weighbridgeTicket = "WB-2026-90299"
            ),
            ScrapInventoryItem(
                id = "LOT-TURNING-301",
                category = "TURNING",
                supplier = "Rotherham Engineering Scrap",
                availableTonnes = 0.0,
                reservedTonnes = 0.0,
                quarantinedTonnes = 95.0,
                unitCostGbp = 195.00,
                locationBay = "Quarantine Pad Q-1",
                fePct = 91.2,
                carbonPct = 0.35,
                siliconPct = 0.40,
                manganesePct = 0.70,
                phosphorusPct = 0.048,
                sulfurPct = 0.065,
                receiptTimestamp = currentTime - 86400000L * 1,
                weighbridgeTicket = "WB-2026-90510 (HOLD: High S content)"
            )
        )

        // The primary active Heat matching the user's reference mockup:
        // FURNACE 02 (ONLINE), 1,620 °C Bath Temp, 78 MW Active Power, Heat 2847, S355JR, Target 240 t
        val activeHeat = HeatRecord(
            heatNumber = 2847,
            plantFacility = PlantFacility.SHEFFIELD_DON_WORKS.label,
            grade = "S355JR",
            targetTonnes = 240.0,
            actualTonnes = 238.6,
            currentStage = "CAST",
            stageProgressPct = 15,
            bathTempC = 1620,
            activePowerMw = 78.0,
            totalEnergyMwh = 98.88,
            energyKwhPerTonne = 412.0,
            yieldPct = 96.8,
            furnaceId = "FURNACE-02",
            ladleId = "LADLE-09",
            casterLineSpeedMpm = 1.2,
            coolingWaterFlowM3h = 3480.0,
            coolingInletC = 28.0,
            coolingOutletC = 41.0,
            status = "ONLINE",
            startTimeEpoch = currentTime - 7200000L,
            completedTimeEpoch = null,
            operatorName = "J. Hargreaves (Shift Engineer)",
            notes = "Continuous casting strand 1 & 2 stable. Bath temp 1,620°C holding."
        )

        val upcomingHeats = listOf(
            HeatRecord(
                heatNumber = 2848,
                plantFacility = PlantFacility.SHEFFIELD_DON_WORKS.label,
                grade = "S355JR",
                targetTonnes = 240.0,
                actualTonnes = 0.0,
                currentStage = "CHARGE",
                stageProgressPct = 100,
                bathTempC = 25,
                activePowerMw = 0.0,
                totalEnergyMwh = 0.0,
                energyKwhPerTonne = 0.0,
                yieldPct = 97.0,
                furnaceId = "FURNACE-02",
                ladleId = "LADLE-04",
                casterLineSpeedMpm = 0.0,
                coolingWaterFlowM3h = 3200.0,
                coolingInletC = 26.0,
                coolingOutletC = 27.0,
                status = "QUEUED",
                startTimeEpoch = currentTime + 3600000L,
                completedTimeEpoch = null,
                operatorName = "M. Sterling",
                notes = "Bucket charge weighed and ready on transfer car"
            ),
            HeatRecord(
                heatNumber = 2849,
                plantFacility = PlantFacility.SHEFFIELD_DON_WORKS.label,
                grade = "S275JR",
                targetTonnes = 240.0,
                actualTonnes = 0.0,
                currentStage = "CHARGE",
                stageProgressPct = 0,
                bathTempC = 25,
                activePowerMw = 0.0,
                totalEnergyMwh = 0.0,
                energyKwhPerTonne = 0.0,
                yieldPct = 96.5,
                furnaceId = "FURNACE-02",
                ladleId = "LADLE-07",
                casterLineSpeedMpm = 0.0,
                coolingWaterFlowM3h = 3200.0,
                coolingInletC = 26.0,
                coolingOutletC = 27.0,
                status = "QUEUED",
                startTimeEpoch = currentTime + 7200000L,
                completedTimeEpoch = null,
                operatorName = "M. Sterling",
                notes = "Scheduled for 16:30 tapping"
            ),
            HeatRecord(
                heatNumber = 2850,
                plantFacility = PlantFacility.SHEFFIELD_DON_WORKS.label,
                grade = "S355J2",
                targetTonnes = 240.0,
                actualTonnes = 0.0,
                currentStage = "CHARGE",
                stageProgressPct = 0,
                bathTempC = 25,
                activePowerMw = 0.0,
                totalEnergyMwh = 0.0,
                energyKwhPerTonne = 0.0,
                yieldPct = 96.9,
                furnaceId = "FURNACE-02",
                ladleId = "LADLE-02",
                casterLineSpeedMpm = 0.0,
                coolingWaterFlowM3h = 3200.0,
                coolingInletC = 26.0,
                coolingOutletC = 27.0,
                status = "QUEUED",
                startTimeEpoch = currentTime + 10800000L,
                completedTimeEpoch = null,
                operatorName = "M. Sterling",
                notes = "Low-temp Charpy toughness heat with de-gassing"
            )
        )

        val labSamples = listOf(
            LabSample(
                sampleId = "SMP-2847-01",
                heatNumber = 2847,
                sampleType = "EAF_FLAT_BATH",
                timestampEpoch = currentTime - 5400000L,
                carbonPct = 0.12,
                siliconPct = 0.08,
                manganesePct = 0.42,
                phosphorusPct = 0.018,
                sulfurPct = 0.038, // Initially elevated sulfur!
                chromiumPct = 0.06,
                nickelPct = 0.05,
                molybdenumPct = 0.01,
                aluminumPct = 0.005,
                cevEquivalent = 0.22,
                yieldStrengthMpa = null,
                tensileStrengthMpa = null,
                elongationPct = null,
                charpyJoules = null,
                isPassed = false,
                qualityStatus = "QUARANTINE_HOLD",
                analystName = "Dr. E. Thorne (OES Lab)",
                notes = "Sulfur 0.038% exceeded S355JR upper bound. Prescribed +600kg basic refining slag + argon desulfurization."
            ),
            LabSample(
                sampleId = "SMP-2847-02",
                heatNumber = 2847,
                sampleType = "LF_FINAL_RELEASE",
                timestampEpoch = currentTime - 2400000L,
                carbonPct = 0.18,
                siliconPct = 0.32,
                manganesePct = 1.44,
                phosphorusPct = 0.016,
                sulfurPct = 0.019, // Corrected and passed!
                chromiumPct = 0.05,
                nickelPct = 0.04,
                molybdenumPct = 0.01,
                aluminumPct = 0.028,
                cevEquivalent = 0.43,
                yieldStrengthMpa = 382.0,
                tensileStrengthMpa = 538.0,
                elongationPct = 24.5,
                charpyJoules = 48.0,
                isPassed = true,
                qualityStatus = "APPROVED",
                analystName = "Dr. E. Thorne (OES Lab)",
                notes = "Corrective alloy & flux trim successful. Chemistry fully conforming to BS EN 10025-2 S355JR."
            )
        )

        val castBillets = listOf(
            CastBillet(
                billetId = "BLT-2847-S1-01",
                heatNumber = 2847,
                strandNumber = 1,
                sequenceNumber = 1,
                lengthMeters = 12.0,
                crossSectionMm = "200x200",
                weightTonnes = 3.76,
                surfaceQuality = "PASSED",
                internalQuality = "PASSED",
                dimensionsQuality = "PASSED",
                status = "READY_FOR_ROLLING"
            ),
            CastBillet(
                billetId = "BLT-2847-S2-01",
                heatNumber = 2847,
                strandNumber = 2,
                sequenceNumber = 2,
                lengthMeters = 12.0,
                crossSectionMm = "200x200",
                weightTonnes = 3.76,
                surfaceQuality = "PASSED",
                internalQuality = "PASSED",
                dimensionsQuality = "PASSED",
                status = "COOLING"
            ),
            CastBillet(
                billetId = "BLT-2847-S1-02",
                heatNumber = 2847,
                strandNumber = 1,
                sequenceNumber = 3,
                lengthMeters = 12.0,
                crossSectionMm = "200x200",
                weightTonnes = 3.76,
                surfaceQuality = "PASSED",
                internalQuality = "PASSED",
                dimensionsQuality = "PASSED",
                status = "IN_CASTING"
            )
        )

        val finishedBundles = listOf(
            FinishedBundle(
                bundleId = "BND-2846-HEB-01",
                batchId = "ROL-7719",
                heatNumber = 2846,
                grade = "S355JR",
                sectionDescription = "HEB 300 x 12.0m Universal Beams",
                weightTonnes = 4.88,
                pieces = 4,
                yardLocation = "Yard Bay 4 South",
                isQualityReleased = true,
                millCertId = "MTC-2026-EN10204-2846-01",
                allocatedOrderId = "ORD-2026-UK-884",
                status = "ALLOCATED"
            ),
            FinishedBundle(
                bundleId = "BND-2846-HEB-02",
                batchId = "ROL-7719",
                heatNumber = 2846,
                grade = "S355JR",
                sectionDescription = "HEB 300 x 12.0m Universal Beams",
                weightTonnes = 4.88,
                pieces = 4,
                yardLocation = "Yard Bay 4 South",
                isQualityReleased = true,
                millCertId = "MTC-2026-EN10204-2846-02",
                allocatedOrderId = "ORD-2026-UK-884",
                status = "ALLOCATED"
            ),
            FinishedBundle(
                bundleId = "BND-2845-PLT-01",
                batchId = "ROL-7712",
                heatNumber = 2845,
                grade = "S275JR",
                sectionDescription = "Heavy Plate 50mm x 2500 x 6000",
                weightTonnes = 5.89,
                pieces = 1,
                yardLocation = "Yard Bay 5 East",
                isQualityReleased = true,
                millCertId = "MTC-2026-EN10204-2845-01",
                allocatedOrderId = null,
                status = "IN_STOCK"
            ),
            FinishedBundle(
                bundleId = "BND-2844-RBR-01",
                batchId = "ROL-7698",
                heatNumber = 2844,
                grade = "S355JR",
                sectionDescription = "High Yield Rebar B500B 32mm",
                weightTonnes = 2.45,
                pieces = 32,
                yardLocation = "Yard Bay 3 West",
                isQualityReleased = false,
                millCertId = null,
                allocatedOrderId = null,
                status = "IN_STOCK" // Quality hold test case
            )
        )

        val customerOrders = listOf(
            CustomerOrder(
                orderId = "ORD-2026-UK-884",
                customerName = "Balfour Beatty Rail / HS2 Infrastructure",
                destination = "Doncaster Maintenance Depot, South Yorkshire",
                grade = "S355JR",
                section = "HEB 300 Universal Beam",
                targetTonnes = 120.0,
                allocatedTonnes = 120.0,
                status = "ALLOCATED",
                targetDeliveryEpoch = currentTime + 86400000L * 2
            ),
            CustomerOrder(
                orderId = "ORD-2026-UK-889",
                customerName = "Sheffield Forgemasters Engineering",
                destination = "Brightside Lane Works, Sheffield S9",
                grade = "S355J2",
                section = "200x200 Forging Billets",
                targetTonnes = 80.0,
                allocatedTonnes = 0.0,
                status = "OPEN",
                targetDeliveryEpoch = currentTime + 86400000L * 5
            ),
            CustomerOrder(
                orderId = "ORD-2026-UK-892",
                customerName = "Severfield UK Structural Steel",
                destination = "Dalton Airfield Industrial Estate, Thirsk",
                grade = "S355JR",
                section = "HEB 300 Universal Beam",
                targetTonnes = 160.0,
                allocatedTonnes = 0.0,
                status = "OPEN",
                targetDeliveryEpoch = currentTime + 86400000L * 7
            )
        )

        val equipment = listOf(
            EquipmentUnit(
                id = "FURNACE-02",
                name = "Electric Arc Furnace 02 (120 MVA)",
                area = "Melt Shop Bay 1",
                status = "ONLINE",
                availabilityPct = 98.2,
                activePowerRatingMw = 120.0,
                operatingHours = 4120,
                nextServiceHours = 180,
                activeAlarms = "Phase 2 electrode wear: 18% remaining. Delta roof water cooling flow normal."
            ),
            EquipmentUnit(
                id = "LADLE-FURNACE-01",
                name = "Ladle Refining Furnace LF-01",
                area = "Secondary Metallurgy",
                status = "ONLINE",
                availabilityPct = 99.4,
                activePowerRatingMw = 28.0,
                operatingHours = 3850,
                nextServiceHours = 350,
                activeAlarms = "Argon bottom plug pressure 4.2 bar (nominal)."
            ),
            EquipmentUnit(
                id = "CASTER-CCM-01",
                name = "Continuous Casting Machine CCM-01 (3 Strands)",
                area = "Casting Bay",
                status = "ONLINE",
                availabilityPct = 96.8,
                activePowerRatingMw = 4.5,
                operatingHours = 5210,
                nextServiceHours = 90,
                activeAlarms = "Strand 2 mould copper plate wear normal. Spray chamber flow: 3,480 m³/h."
            ),
            EquipmentUnit(
                id = "REHEAT-FURNACE-01",
                name = "Walking Beam Reheat Furnace RF-01",
                area = "Rolling Mill Entry",
                status = "ONLINE",
                availabilityPct = 97.5,
                activePowerRatingMw = 18.0,
                operatingHours = 6120,
                nextServiceHours = 280,
                activeAlarms = "Soaking zone 1,180°C. Gas recuperator efficiency 74%."
            ),
            EquipmentUnit(
                id = "ROLLING-MILL-01",
                name = "Heavy Section Reversible Breakdown & Universal Mill",
                area = "Rolling Mill Bay",
                status = "ONLINE",
                availabilityPct = 95.1,
                activePowerRatingMw = 32.0,
                operatingHours = 4890,
                nextServiceHours = 110,
                activeAlarms = "Stand 3 roll bearing temperature 44°C (Normal)."
            )
        )

        val auditLogs = listOf(
            AuditLogEntry(
                timestampEpoch = currentTime - 3600000L * 3,
                operatorName = "J. Hargreaves",
                role = "SHIFT_ENGINEER",
                actionType = "CHARGE_VERIFICATION",
                entityType = "HEAT",
                entityId = "2847",
                changeDetails = "Weighed scrap bucket charge verified: 246.2 t gross scrap loaded into EAF-02."
            ),
            AuditLogEntry(
                timestampEpoch = currentTime - 3600000L * 2,
                operatorName = "Dr. E. Thorne",
                role = "METALLURGIST",
                actionType = "QUALITY_ALERT",
                entityType = "LAB_SAMPLE",
                entityId = "SMP-2847-01",
                changeDetails = "Sulfur flagged at 0.038%. Heat placed on Quality Hold until LF desulfurization trim."
            ),
            AuditLogEntry(
                timestampEpoch = currentTime - 3600000L * 1,
                operatorName = "Dr. E. Thorne",
                role = "METALLURGIST",
                actionType = "QUALITY_RELEASE",
                entityType = "LAB_SAMPLE",
                entityId = "SMP-2847-02",
                changeDetails = "Sulfur reduced to 0.019%. LF final sample APPROVED for continuous casting."
            ),
            AuditLogEntry(
                timestampEpoch = currentTime - 1800000L,
                operatorName = "J. Hargreaves",
                role = "SHIFT_ENGINEER",
                actionType = "OPERATOR_CORRECTION",
                entityType = "HEAT",
                entityId = "2847",
                changeDetails = "Corrected tare weight entry on Ladle 09 from 48.2t to 47.9t following recalibration."
            )
        )

        return SeedDataBundle(
            scrapItems = scrapItems,
            heats = listOf(activeHeat) + upcomingHeats,
            labSamples = labSamples,
            castBillets = castBillets,
            finishedBundles = finishedBundles,
            customerOrders = customerOrders,
            equipment = equipment,
            auditLogs = auditLogs
        )
    }
}

data class SeedDataBundle(
    val scrapItems: List<ScrapInventoryItem>,
    val heats: List<HeatRecord>,
    val labSamples: List<LabSample>,
    val castBillets: List<CastBillet>,
    val finishedBundles: List<FinishedBundle>,
    val customerOrders: List<CustomerOrder>,
    val equipment: List<EquipmentUnit>,
    val auditLogs: List<AuditLogEntry>
)
