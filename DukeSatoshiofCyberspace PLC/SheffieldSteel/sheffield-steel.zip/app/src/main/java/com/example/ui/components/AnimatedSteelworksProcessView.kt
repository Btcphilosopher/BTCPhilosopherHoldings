package com.example.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.local.entities.HeatRecord
import com.example.ui.theme.*
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

@Composable
fun AnimatedSteelworksProcessView(
    heat: HeatRecord?,
    isSimulationRunning: Boolean,
    modifier: Modifier = Modifier
) {
    var viewMode3D by remember { mutableStateOf(true) } // Default to the photorealistic 3D render view from prompt!
    var zoomScale by remember { mutableFloatStateOf(1.0f) }
    var panOffsetX by remember { mutableFloatStateOf(0.0f) }
    var panOffsetY by remember { mutableFloatStateOf(0.0f) }

    val activePower = heat?.activePowerMw ?: 78.0
    val bathTemp = heat?.bathTempC ?: 1620
    val lineSpeed = heat?.casterLineSpeedMpm ?: 1.2
    val currentStage = heat?.currentStage ?: "CAST"

    // Infinite animation tickers
    val infiniteTransition = rememberInfiniteTransition(label = "process_anim")

    // Electrode arc spark oscillation
    val sparkPhase by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(250, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "spark"
    )

    // Molten pool heat pulse
    val moltenGlow by infiniteTransition.animateFloat(
        initialValue = 0.85f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "moltenGlow"
    )

    // Strand movement translation (0 to 1 continuous loop)
    val strandOffset by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 60f,
        animationSpec = infiniteRepeatable(
            animation = tween(if (isSimulationRunning) 2000 else 100000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "strandMotion"
    )

    Surface(
        color = Color(0xFF0F1216),
        shape = RoundedCornerShape(4.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, SheffieldBorder),
        modifier = modifier
            .fillMaxWidth()
            .testTag("animated_steelworks_process_view")
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .clipToBounds()
                .pointerInput(Unit) {
                    detectTransformGestures { _, pan, zoom, _ ->
                        zoomScale = (zoomScale * zoom).coerceIn(0.75f, 2.5f)
                        panOffsetX = (panOffsetX + pan.x).coerceIn(-400f, 400f)
                        panOffsetY = (panOffsetY + pan.y).coerceIn(-250f, 250f)
                    }
                }
        ) {
            if (viewMode3D) {
                // 3D Render View with loaded foundry asset & interactive overlays
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .graphicsLayer(
                            scaleX = zoomScale,
                            scaleY = zoomScale,
                            translationX = panOffsetX,
                            translationY = panOffsetY
                        )
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.melt_shop_render),
                        contentDescription = "Melt Shop 3D Render",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )

                    // Overlay dynamic thermal glow on EAF based on actual live power
                    if (activePower > 10.0) {
                        Canvas(modifier = Modifier.fillMaxSize()) {
                            val w = size.width
                            val h = size.height

                            // EAF hearth glow overlay (approx center-left of render)
                            drawCircle(
                                brush = Brush.radialGradient(
                                    colors = listOf(
                                        MoltenOrange.copy(alpha = 0.35f * moltenGlow),
                                        MoltenGold.copy(alpha = 0.15f * moltenGlow),
                                        Color.Transparent
                                    ),
                                    center = Offset(w * 0.28f, h * 0.42f),
                                    radius = w * 0.18f
                                )
                            )

                            // Continuous Caster strand glow overlay (center-right)
                            drawRect(
                                brush = Brush.horizontalGradient(
                                    colors = listOf(
                                        MoltenOrange.copy(alpha = 0.40f * moltenGlow),
                                        MoltenGold.copy(alpha = 0.25f),
                                        Color.Transparent
                                    ),
                                    startX = w * 0.58f,
                                    endX = w * 0.88f
                                ),
                                topLeft = Offset(w * 0.58f, h * 0.40f),
                                size = Size(w * 0.30f, h * 0.30f)
                            )
                        }
                    }
                }
            } else {
                // Live Vector Animated Process Schematic
                Canvas(
                    modifier = Modifier
                        .fillMaxSize()
                        .graphicsLayer(
                            scaleX = zoomScale,
                            scaleY = zoomScale,
                            translationX = panOffsetX,
                            translationY = panOffsetY
                        )
                ) {
                    val w = size.width
                    val h = size.height

                    // 1. Dark industrial plant floor & bay grid
                    drawRect(color = Color(0xFF111419))
                    val gridColor = Color(0xFF1B2028)
                    for (x in 0..w.toInt() step 50) {
                        drawLine(gridColor, Offset(x.toFloat(), 0f), Offset(x.toFloat(), h), 1f)
                    }
                    for (y in 0..h.toInt() step 50) {
                        drawLine(gridColor, Offset(0f, y.toFloat()), Offset(w, y.toFloat()), 1f)
                    }

                    // 2. Overhead crane gantry rail
                    drawRect(
                        color = Color(0xFF2C3440),
                        topLeft = Offset(0f, h * 0.12f),
                        size = Size(w, 14f)
                    )

                    // 3. ELECTRIC ARC FURNACE (EAF) on Left
                    val eafX = w * 0.22f
                    val eafY = h * 0.58f
                    val eafRadius = h * 0.26f

                    // Furnace Foundation & Tilt Platform
                    drawRoundRect(
                        color = Color(0xFF202630),
                        topLeft = Offset(eafX - eafRadius * 1.1f, eafY - eafRadius * 0.2f),
                        size = Size(eafRadius * 2.2f, eafRadius * 0.8f),
                        cornerRadius = CornerRadius(8f, 8f)
                    )

                    // Furnace Shell Body
                    drawCircle(
                        color = Color(0xFF333C4A),
                        radius = eafRadius,
                        center = Offset(eafX, eafY)
                    )

                    // Molten Bath Core (Orange/Gold Glow)
                    if (activePower > 5.0) {
                        drawCircle(
                            brush = Brush.radialGradient(
                                colors = listOf(MoltenWhiteHot, MoltenOrange, SlagGlow, Color(0xFF2A150A)),
                                center = Offset(eafX, eafY),
                                radius = eafRadius * 0.85f * moltenGlow
                            ),
                            radius = eafRadius * 0.85f,
                            center = Offset(eafX, eafY)
                        )

                        // 3 Graphite Electrodes & Arc Sparks
                        val electrodeWidth = 14f
                        val electrodeHeight = eafRadius * 1.3f
                        for (i in -1..1) {
                            val elX = eafX + (i * 28f)
                            drawRect(
                                color = Color(0xFF181818),
                                topLeft = Offset(elX - electrodeWidth / 2, eafY - electrodeHeight),
                                size = Size(electrodeWidth, electrodeHeight)
                            )
                            // Electrode glow tip
                            drawCircle(
                                color = MoltenWhiteHot,
                                radius = 7f,
                                center = Offset(elX, eafY - 10f)
                            )
                            // Electric arc discharge lines
                            drawLine(
                                color = ElectricArcBlue,
                                start = Offset(elX, eafY - 10f),
                                end = Offset(elX + (Random.nextFloat() - 0.5f) * 20f, eafY + 15f),
                                strokeWidth = 3f
                            )
                        }
                    }

                    // 4. LADLE TRANSFER TRACK & LADLE FURNACE (LF)
                    val lfX = w * 0.50f
                    val lfY = h * 0.58f

                    // Track rails between EAF and CCM
                    drawLine(
                        color = Color(0xFF3D4756),
                        start = Offset(eafX, eafY + eafRadius * 0.6f),
                        end = Offset(w * 0.85f, eafY + eafRadius * 0.6f),
                        strokeWidth = 6f
                    )

                    // Ladle Furnace Body
                    drawRoundRect(
                        color = Color(0xFF2B333F),
                        topLeft = Offset(lfX - 50f, lfY - 70f),
                        size = Size(100f, 120f),
                        cornerRadius = CornerRadius(12f, 12f)
                    )
                    // Molten steel interior
                    drawRoundRect(
                        brush = Brush.verticalGradient(
                            listOf(MoltenGold, MoltenOrange, SlagGlow),
                            startY = lfY - 40f,
                            endY = lfY + 40f
                        ),
                        topLeft = Offset(lfX - 42f, lfY - 40f),
                        size = Size(84f, 80f),
                        cornerRadius = CornerRadius(8f, 8f)
                    )

                    // 5. CONTINUOUS CASTER (CCM) on Right
                    val ccmX = w * 0.72f
                    val ccmY = h * 0.58f

                    // Tundish
                    drawRoundRect(
                        color = Color(0xFF374151),
                        topLeft = Offset(ccmX - 40f, ccmY - 80f),
                        size = Size(80f, 40f),
                        cornerRadius = CornerRadius(6f, 6f)
                    )
                    // Tundish liquid steel stream
                    drawLine(
                        color = MoltenWhiteHot,
                        start = Offset(ccmX, ccmY - 40f),
                        end = Offset(ccmX, ccmY - 10f),
                        strokeWidth = 6f
                    )

                    // Water Spray Cooling Mould
                    drawRect(
                        color = Color(0xFF1E293B),
                        topLeft = Offset(ccmX - 30f, ccmY - 10f),
                        size = Size(60f, 45f)
                    )

                    // Water spray cooling particles
                    for (k in 0..12) {
                        val px = ccmX - 25f + (k * 4f)
                        val py = ccmY + 5f + ((k % 3) * 8f)
                        drawCircle(
                            color = ElectricArcBlue.copy(alpha = 0.6f),
                            radius = 2.5f,
                            center = Offset(px, py)
                        )
                    }

                    // Continuous Casting Strand (Curving & Horizontal Run-out Table)
                    val strandLength = w * 0.24f
                    val rollerY = ccmY + 45f

                    // Motorized Roller Bed
                    for (r in 0..10) {
                        val rx = ccmX + (r * 26f)
                        drawCircle(
                            color = Color(0xFF475569),
                            radius = 8f,
                            center = Offset(rx, rollerY + 12f)
                        )
                    }

                    // Hot Glowing Steel Strand gliding across rollers
                    drawRoundRect(
                        brush = Brush.horizontalGradient(
                            listOf(
                                MoltenWhiteHot,
                                MoltenGold,
                                MoltenOrange,
                                Color(0xFFD9480F),
                                Color(0xFF862E08)
                            ),
                            startX = ccmX,
                            endX = ccmX + strandLength
                        ),
                        topLeft = Offset(ccmX, rollerY - 10f),
                        size = Size(strandLength, 20f),
                        cornerRadius = CornerRadius(4f, 4f)
                    )

                    // Flying Cutoff Torch Sparks
                    val cutX = ccmX + (strandLength * 0.85f)
                    drawCircle(color = Color.White, radius = 5f, center = Offset(cutX, rollerY))
                    for (s in 0..8) {
                        val sx = cutX + (sin(s + sparkPhase * 6f) * 16f)
                        val sy = rollerY + (cos(s + sparkPhase * 6f) * 16f)
                        drawCircle(color = MoltenGold, radius = 2f, center = Offset(sx, sy))
                    }
                }
            }

            // Top-Right View Controls Overlay (Pan, 3D Toggle, Zoom In, Zoom Out, Reset)
            Row(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(12.dp)
                    .background(SheffieldCard.copy(alpha = 0.9f), RoundedCornerShape(4.dp))
                    .border(1.dp, SheffieldBorder, RoundedCornerShape(4.dp))
                    .padding(4.dp)
            ) {
                // View Mode Switch: 3D Render vs Schematic
                IconButton(
                    onClick = { viewMode3D = !viewMode3D },
                    modifier = Modifier
                        .size(32.dp)
                        .testTag("toggle_3d_view_button")
                ) {
                    Icon(
                        imageVector = if (viewMode3D) Icons.Default.ViewInAr else Icons.Default.Schema,
                        contentDescription = "Switch view mode",
                        tint = if (viewMode3D) MoltenGold else SheffieldIvory,
                        modifier = Modifier.size(18.dp)
                    )
                }

                // Zoom in
                IconButton(
                    onClick = { zoomScale = (zoomScale * 1.2f).coerceAtMost(2.5f) },
                    modifier = Modifier.size(32.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.ZoomIn,
                        contentDescription = "Zoom in",
                        tint = SheffieldIvory,
                        modifier = Modifier.size(18.dp)
                    )
                }

                // Zoom out
                IconButton(
                    onClick = { zoomScale = (zoomScale / 1.2f).coerceAtLeast(0.75f) },
                    modifier = Modifier.size(32.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.ZoomOut,
                        contentDescription = "Zoom out",
                        tint = SheffieldIvory,
                        modifier = Modifier.size(18.dp)
                    )
                }

                // Reset view
                IconButton(
                    onClick = {
                        zoomScale = 1.0f
                        panOffsetX = 0f
                        panOffsetY = 0f
                    },
                    modifier = Modifier.size(32.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.FitScreen,
                        contentDescription = "Fit screen",
                        tint = SheffieldIvory,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }

            // Bottom-Left Mode Label
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .align(Alignment.BottomStart)
                    .padding(10.dp)
                    .background(Color(0xCC000000), RoundedCornerShape(4.dp))
                    .padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
                Text(
                    text = if (viewMode3D) "3D DIGITAL TWIN · FURNACE 02" else "DYNAMIC PROCESS SCHEMATIC · LIVE",
                    style = MaterialTheme.typography.labelSmall,
                    color = MoltenGold,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 0.8.sp
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "DRAG TO PAN · PINCH TO ZOOM",
                    style = MaterialTheme.typography.labelSmall,
                    color = SheffieldIvoryDim,
                    fontSize = 9.sp
                )
            }
        }
    }
}
