package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountTree
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CurrencyPound
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.entities.AuditLogEntry
import com.example.data.local.entities.HeatRecord
import com.example.ui.theme.*

@Composable
fun AnalyticsScreen(
    activeHeat: HeatRecord?,
    auditLogs: List<AuditLogEntry>,
    modifier: Modifier = Modifier
) {
    var sellingPricePerTonne by remember { mutableStateOf("580") }

    val rawScrapCost = 242.0
    val alloyCost = 48.0
    val energyCost = 52.0 // @ £88.40 / MWh
    val electrodeRefractoryCost = 18.0
    val labourPlantCost = 35.0
    val totalCostPerTonne = rawScrapCost + alloyCost + energyCost + electrodeRefractoryCost + labourPlantCost

    val price = sellingPricePerTonne.toDoubleOrNull() ?: 580.0
    val margin = price - totalCostPerTonne
    val marginPct = (margin / price) * 100.0

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(SheffieldBackground)
            .padding(16.dp)
            .verticalScroll(rememberScrollState())
            .testTag("analytics_screen"),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Header
        Column {
            Text(
                text = "UNIT COST, ENERGY ECONOMICS & END-TO-END GENEALOGY",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = SheffieldIvory
            )
            Text(
                text = "Dated spot power tariffs (£88.40/MWh) · Conversion cost per saleable tonne · Full audit trail",
                style = MaterialTheme.typography.bodySmall,
                color = SheffieldIvoryMuted
            )
        }

        // Top Financial Economics Summary
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            CostPill("PHYSICAL MELT COST", "£${totalCostPerTonne.toInt()} / t", "Scrap + Alloys + Energy", MoltenGold, Modifier.weight(1f))
            CostPill("SELLING PRICE", "£${price.toInt()} / t", "Entered Market Realisation", SheffieldIvory, Modifier.weight(1f))
            CostPill("CONTRIBUTION MARGIN", "+£${margin.toInt()} / t", "${String.format("%.1f", marginPct)}% Gross Contribution", if (margin >= 0) SignalGreen else DangerRed, Modifier.weight(1f))
            CostPill("SPECIFIC ENERGY", "412 kWh/t", "EAF & LF Combined Consumption", ElectricArcBlue, Modifier.weight(1f))
        }

        // 2 Panes: Left = Production Cost Breakdown · Right = Visual Heat Genealogy Explorer
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // LEFT: COST BREAKDOWN TABLE
            Surface(
                color = SheffieldCard,
                shape = RoundedCornerShape(4.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, SheffieldBorder),
                modifier = Modifier.weight(0.48f)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "COST PER SALEABLE TONNE BREAKDOWN",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = SheffieldIvory
                    )
                    Spacer(modifier = Modifier.height(10.dp))

                    CostLineItem("Raw Scrap Metal Mix (HMS-1, P&S, Shred)", "£$rawScrapCost / t", 61.2)
                    CostLineItem("Secondary Alloys (FeMn, FeSi, CaSi, Recarb)", "£$alloyCost / t", 12.1)
                    CostLineItem("Electrical Power (Grid Tariff £88.40/MWh)", "£$energyCost / t", 13.2)
                    CostLineItem("Consumables (Graphite Electrodes, Refractory)", "£$electrodeRefractoryCost / t", 4.6)
                    CostLineItem("Plant Overhead & Skilled Labour Allocation", "£$labourPlantCost / t", 8.9)

                    HorizontalDivider(color = SheffieldBorder, modifier = Modifier.padding(vertical = 8.dp))

                    Row(
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Total Conversion Cost:", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = SheffieldIvory)
                        Text("£$totalCostPerTonne / t", fontFamily = FontFamily.Monospace, fontSize = 16.sp, fontWeight = FontWeight.Black, color = MoltenOrange)
                    }

                    Spacer(modifier = Modifier.height(14.dp))
                    OutlinedTextField(
                        value = sellingPricePerTonne,
                        onValueChange = { sellingPricePerTonne = it },
                        label = { Text("Model Selling Price Realisation (£/t)") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }

            // RIGHT: VISUAL END-TO-END GENEALOGY TREE
            Surface(
                color = SheffieldCard,
                shape = RoundedCornerShape(4.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, SheffieldBorder),
                modifier = Modifier.weight(0.52f)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = "HEAT 2847 END-TO-END GENEALOGY",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MoltenGold
                        )
                        Icon(Icons.Default.AccountTree, contentDescription = null, tint = MoltenGold)
                    }
                    Text(
                        text = "Traceability preserved through raw lots, charge, melt, cast, roll, & dispatch",
                        style = MaterialTheme.typography.bodySmall,
                        color = SheffieldIvoryMuted
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    GenealogyNode(
                        title = "1. INCOMING MATERIAL LOTS",
                        details = "LOT-HMS1-4401 (135t) + LOT-PS-2209 (65t) + LOT-SHRED-1190 (40t)",
                        badge = "WEIGHBRIDGE CERTIFIED",
                        color = ElectricArcBlue
                    )
                    GenealogyConnector()

                    GenealogyNode(
                        title = "2. EAF-02 PRIMARY MELT & LADLE 09",
                        details = "Heat #2847 · 246.2t charged · 78MW tap-to-tap · Tap temp 1,640°C",
                        badge = "MELT COMPLETE",
                        color = MoltenOrange
                    )
                    GenealogyConnector()

                    GenealogyNode(
                        title = "3. LF-01 REFINING & DE-S TRIM",
                        details = "SMP-2847-01 (S=0.038% Hold) -> SMP-2847-02 (S=0.019% Approved)",
                        badge = "QA 10025-2 COMPLIANT",
                        color = SignalGreen
                    )
                    GenealogyConnector()

                    GenealogyNode(
                        title = "4. CONTINUOUS CASTER (CCM-01)",
                        details = "Cast 4 Billets (BLT-2847-S1-01 to S2-02) · 200x200mm · 15.04t",
                        badge = "COOLING BED",
                        color = MoltenGold
                    )
                    GenealogyConnector()

                    GenealogyNode(
                        title = "5. ROLLING & FINISHING MILL",
                        details = "Rolled Batch ROL-7719 · HEB 300 Universal Beams · Yield 96.5%",
                        badge = "HEB 300 x 12.0m",
                        color = SheffieldIvory
                    )
                    GenealogyConnector()

                    GenealogyNode(
                        title = "6. ALLOCATION & DISPATCH",
                        details = "Bundle BND-2846-HEB-01 -> Order ORD-2026-UK-884 (Balfour Beatty / HS2)",
                        badge = "WEIGHBRIDGE OUT-GATE",
                        color = SignalGreen
                    )
                }
            }
        }

        // AUDIT TRAIL LOGS
        Surface(
            color = SheffieldCard,
            shape = RoundedCornerShape(4.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, SheffieldBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text(
                    text = "IMMUTABLE AUDIT TRAIL LOG",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = SheffieldIvory
                )
                Spacer(modifier = Modifier.height(8.dp))

                auditLogs.take(6).forEach { log ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(log.operatorName, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = MoltenGold, modifier = Modifier.width(130.dp))
                        Text(log.actionType, style = MaterialTheme.typography.labelSmall, color = ElectricArcBlue, modifier = Modifier.width(160.dp))
                        Text(log.changeDetails, style = MaterialTheme.typography.bodySmall, color = SheffieldIvory, modifier = Modifier.weight(1f))
                    }
                    HorizontalDivider(color = SheffieldBorderSubtle)
                }
            }
        }
    }
}

@Composable
private fun CostPill(label: String, value: String, sublabel: String, color: Color, modifier: Modifier = Modifier) {
    Surface(
        color = SheffieldCard,
        shape = RoundedCornerShape(4.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, SheffieldBorder),
        modifier = modifier
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text(label, style = MaterialTheme.typography.labelSmall, color = SheffieldIvoryDim)
            Spacer(modifier = Modifier.height(4.dp))
            Text(value, fontFamily = FontFamily.Monospace, fontSize = 22.sp, fontWeight = FontWeight.Black, color = color)
            Spacer(modifier = Modifier.height(2.dp))
            Text(sublabel, style = MaterialTheme.typography.bodySmall, fontSize = 10.sp, color = SheffieldIvoryMuted)
        }
    }
}

@Composable
private fun CostLineItem(name: String, cost: String, pct: Double) {
    Row(
        horizontalArrangement = Arrangement.SpaceBetween,
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
    ) {
        Text(name, style = MaterialTheme.typography.bodySmall, color = SheffieldIvory)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(cost, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, color = SheffieldIvory)
            Text("(${pct}%)", fontFamily = FontFamily.Monospace, color = SheffieldIvoryDim)
        }
    }
}

@Composable
private fun GenealogyNode(title: String, details: String, badge: String, color: Color) {
    Surface(
        color = SheffieldSurface,
        shape = RoundedCornerShape(4.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, color.copy(alpha = 0.5f)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(10.dp)
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(title, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = color)
                Text(details, style = MaterialTheme.typography.bodySmall, color = SheffieldIvory)
            }
            Text(
                badge,
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Bold,
                color = color,
                modifier = Modifier
                    .background(color.copy(alpha = 0.15f), RoundedCornerShape(2.dp))
                    .padding(horizontal = 6.dp, vertical = 2.dp)
            )
        }
    }
}

@Composable
private fun GenealogyConnector() {
    Box(
        contentAlignment = Alignment.Center,
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 2.dp)
    ) {
        Icon(Icons.Default.ArrowDownward, contentDescription = null, tint = SheffieldBorder, modifier = Modifier.size(16.dp))
    }
}
