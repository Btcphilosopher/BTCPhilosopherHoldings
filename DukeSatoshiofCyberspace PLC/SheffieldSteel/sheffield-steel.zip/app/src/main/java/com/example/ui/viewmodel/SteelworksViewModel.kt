package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.entities.*
import com.example.data.model.*
import com.example.data.repository.SteelworksRepository
import com.example.data.simulator.MassBalanceResult
import com.example.data.simulator.SteelworksSimulator
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

enum class WorkspaceTab(val label: String, val technicalCode: String) {
    OVERVIEW("Overview", "OP-01"),
    MATERIALS("Materials", "MAT-02"),
    MELT_SHOP("Melt Shop", "EAF-03"),
    CASTING("Casting", "CCM-04"),
    ROLLING("Rolling", "ROL-05"),
    QUALITY("Quality", "LAB-06"),
    MAINTENANCE("Maintenance", "MNT-07"),
    DISPATCH("Dispatch", "DSP-08"),
    ANALYTICS("Analytics", "ANL-09")
}

data class DemoStepInfo(
    val stepIndex: Int,
    val title: String,
    val description: String,
    val targetTab: WorkspaceTab
)

class SteelworksViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = SteelworksRepository(application)

    // UI state
    val selectedPlant = repository.selectedPlant
    val connectionStatus = repository.connectionStatus
    val isSimulationActive = repository.simulationActive
    val currentShift = repository.currentShift
    val operatorUser = repository.operatorUser

    private val _currentTab = MutableStateFlow(WorkspaceTab.OVERVIEW)
    val currentTab: StateFlow<WorkspaceTab> = _currentTab.asStateFlow()

    // Domain data flows
    val activeHeat: StateFlow<HeatRecord?> = repository.activeHeat.stateIn(
        viewModelScope, SharingStarted.WhileSubscribed(5000), null
    )

    val upcomingHeats: StateFlow<List<HeatRecord>> = repository.upcomingHeats.stateIn(
        viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList()
    )

    val allHeats: StateFlow<List<HeatRecord>> = repository.allHeats.stateIn(
        viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList()
    )

    val scrapInventory: StateFlow<List<ScrapInventoryItem>> = repository.allScrap.stateIn(
        viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList()
    )

    val labSamples: StateFlow<List<LabSample>> = repository.allLabSamples.stateIn(
        viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList()
    )

    val castBillets: StateFlow<List<CastBillet>> = repository.allBillets.stateIn(
        viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList()
    )

    val rolledBatches: StateFlow<List<RolledBatch>> = repository.allRolledBatches.stateIn(
        viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList()
    )

    val finishedBundles: StateFlow<List<FinishedBundle>> = repository.allBundles.stateIn(
        viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList()
    )

    val customerOrders: StateFlow<List<CustomerOrder>> = repository.allOrders.stateIn(
        viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList()
    )

    val equipmentUnits: StateFlow<List<EquipmentUnit>> = repository.allEquipment.stateIn(
        viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList()
    )

    val auditLogs: StateFlow<List<AuditLogEntry>> = repository.auditLogs.stateIn(
        viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList()
    )

    // Telemetry chart data for active heat 2847
    val recentTelemetry: StateFlow<List<TelemetrySnapshot>> = repository.getTelemetryForHeat(2847).stateIn(
        viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList()
    )

    // Mass Balance Calculator interactive state
    private val _targetGrade = MutableStateFlow(SteelGrade.S355JR)
    val targetGrade: StateFlow<SteelGrade> = _targetGrade.asStateFlow()

    private val _targetLiquidTonnes = MutableStateFlow(240.0)
    val targetLiquidTonnes: StateFlow<Double> = _targetLiquidTonnes.asStateFlow()

    private val _hmsRatio = MutableStateFlow(0.50)
    val hmsRatio: StateFlow<Double> = _hmsRatio.asStateFlow()

    private val _psRatio = MutableStateFlow(0.30)
    val psRatio: StateFlow<Double> = _psRatio.asStateFlow()

    private val _shredRatio = MutableStateFlow(0.15)
    val shredRatio: StateFlow<Double> = _shredRatio.asStateFlow()

    private val _alloysRatio = MutableStateFlow(0.05)
    val alloysRatio: StateFlow<Double> = _alloysRatio.asStateFlow()

    val massBalanceResult: StateFlow<MassBalanceResult> = combine(
        _targetGrade, _targetLiquidTonnes, _hmsRatio, _psRatio, _shredRatio
    ) { grade, tonnes, hms, ps, shred ->
        SteelworksSimulator.calculateMassBalance(grade, tonnes, hms, ps, shred, _alloysRatio.value)
    }.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        SteelworksSimulator.calculateMassBalance(SteelGrade.S355JR, 240.0)
    )

    // Dialog state
    private val _selectedCertificate = MutableStateFlow<LabSample?>(null)
    val selectedCertificate: StateFlow<LabSample?> = _selectedCertificate.asStateFlow()

    private val _isDemoRunnerOpen = MutableStateFlow(false)
    val isDemoRunnerOpen: StateFlow<Boolean> = _isDemoRunnerOpen.asStateFlow()

    private val _demoCurrentStep = MutableStateFlow(0)
    val demoCurrentStep: StateFlow<Int> = _demoCurrentStep.asStateFlow()

    private val _snackbarMessage = MutableStateFlow<String?>(null)
    val snackbarMessage: StateFlow<String?> = _snackbarMessage.asStateFlow()

    init {
        // Live simulation coroutine
        viewModelScope.launch {
            while (isActive) {
                delay(2000)
                try {
                    repository.tickSimulation()
                } catch (e: Exception) {
                    // Ignore transient errors
                }
            }
        }
    }

    fun selectTab(tab: WorkspaceTab) {
        _currentTab.value = tab
    }

    fun selectPlant(plant: PlantFacility) {
        repository.selectPlant(plant)
    }

    fun setConnectionStatus(status: ConnectionStatus) {
        repository.setConnectionStatus(status)
    }

    fun toggleSimulation() {
        repository.toggleSimulation()
    }

    fun clearSnackbar() {
        _snackbarMessage.value = null
    }

    // Mass balance adjustment
    fun setTargetGrade(grade: SteelGrade) {
        _targetGrade.value = grade
    }

    fun setTargetLiquidTonnes(tonnes: Double) {
        _targetLiquidTonnes.value = tonnes
    }

    fun updateChargeRatios(hms: Double, ps: Double, shred: Double, alloys: Double) {
        _hmsRatio.value = hms
        _psRatio.value = ps
        _shredRatio.value = shred
        _alloysRatio.value = alloys
    }

    // Dialogs
    fun viewInspectionCertificate(sample: LabSample?) {
        _selectedCertificate.value = sample
    }

    fun toggleDemoRunner(isOpen: Boolean) {
        _isDemoRunnerOpen.value = isOpen
    }

    // --- Core Operations ---
    fun receiveScrap(category: String, supplier: String, weightTonnes: Double, cost: Double, bay: String) {
        viewModelScope.launch {
            repository.receiveScrapWeighbridge(category, supplier, weightTonnes, cost, bay)
            _snackbarMessage.value = "Weighed & received ${weightTonnes}t of $category into $bay"
        }
    }

    fun reserveScrap(lotId: String, tonnes: Double) {
        viewModelScope.launch {
            repository.reserveScrapForCharge(lotId, tonnes)
            _snackbarMessage.value = "Reserved ${tonnes}t from Lot $lotId for upcoming heat"
        }
    }

    fun createNewHeat(grade: String, tonnes: Double) {
        viewModelScope.launch {
            val num = repository.createNewHeat(grade, tonnes)
            _snackbarMessage.value = "Heat #$num created and queued for Melt Shop"
        }
    }

    fun advanceActiveHeatStage() {
        viewModelScope.launch {
            val current = activeHeat.value ?: return@launch
            repository.advanceHeatStage(current.heatNumber)
            _snackbarMessage.value = "Advanced Heat #${current.heatNumber} to next production stage"
        }
    }

    fun recordLabSample(
        heatNum: Int,
        sampleType: String,
        carbon: Double,
        silicon: Double,
        manganese: Double,
        p: Double,
        s: Double,
        isPassed: Boolean,
        status: String,
        notes: String
    ) {
        viewModelScope.launch {
            repository.recordLabSample(heatNum, sampleType, carbon, silicon, manganese, p, s, isPassed, status, notes)
            _snackbarMessage.value = "Lab sample registered: C=$carbon%, S=$s%. Status: $status"
        }
    }

    fun releaseQualityHold(sampleId: String, reason: String) {
        viewModelScope.launch {
            repository.releaseQualityHold(sampleId, reason)
            _snackbarMessage.value = "Quality hold on $sampleId released with authorised sign-off"
        }
    }

    fun correctOperatorEntry(heatNum: Int, param: String, oldVal: String, newVal: String, reason: String) {
        viewModelScope.launch {
            repository.correctOperatorEntry(heatNum, param, oldVal, newVal, reason)
            _snackbarMessage.value = "Audit recorded: Corrected $param to '$newVal'"
        }
    }

    fun castBilletsForActiveHeat() {
        viewModelScope.launch {
            val current = activeHeat.value ?: return@launch
            repository.castOutputBillets(current.heatNumber, 4)
            _snackbarMessage.value = "Continuous casting complete: 4 billets (15.04t) transferred to cooling bed"
        }
    }

    fun scheduleAndRollBatch(heatNum: Int, section: String) {
        viewModelScope.launch {
            val batchId = repository.scheduleAndRollBatch(heatNum, section)
            _snackbarMessage.value = "Rolled batch $batchId ($section) completed. Finished bundles stored in Yard."
        }
    }

    fun allocateOrder(orderId: String, bundleId: String) {
        viewModelScope.launch {
            val success = repository.allocateOrder(orderId, bundleId)
            if (success) {
                _snackbarMessage.value = "Bundle $bundleId successfully allocated to Order $orderId"
            } else {
                _snackbarMessage.value = "ALLOCATION REJECTED: Bundle is quarantined or on Quality Hold!"
            }
        }
    }

    fun dispatchOrder(orderId: String) {
        viewModelScope.launch {
            repository.dispatchOrder(orderId)
            _snackbarMessage.value = "Order $orderId dispatched via exit weighbridge!"
        }
    }

    fun toggleEquipmentDowntime(unitId: String) {
        viewModelScope.launch {
            repository.simulateEquipmentDowntime(unitId, "Hydraulic pressure sensor delta trip")
            _snackbarMessage.value = "Equipment state toggled for $unitId"
        }
    }

    // 11-step complete tour runner
    val demoSteps = listOf(
        DemoStepInfo(0, "1. Receive & Weigh Scrap", "Receive 85 tonnes of Heavy Melting Steel at the North Weighbridge.", WorkspaceTab.MATERIALS),
        DemoStepInfo(1, "2. Reserve Material for Charge", "Reserve scrap lot for the mass-balance charge calculation.", WorkspaceTab.MATERIALS),
        DemoStepInfo(2, "3. Create a Heat", "Schedule Heat #2851 for S355JR structural beam production.", WorkspaceTab.MELT_SHOP),
        DemoStepInfo(3, "4. Melt & Refine in EAF/LF", "Ignite electric arc furnace, melt charge, and transfer ladle to LF.", WorkspaceTab.MELT_SHOP),
        DemoStepInfo(4, "5. Record Lab Results & Corrective Trim", "Record spectrometer sample showing elevated sulfur and add desulfurizing flux.", WorkspaceTab.QUALITY),
        DemoStepInfo(5, "6. Continuous Casting", "Operate 3-strand caster and cut 200x200mm billets to 12m lengths.", WorkspaceTab.CASTING),
        DemoStepInfo(6, "7. Schedule Rolling", "Reheat billets to 1,180°C and roll HEB 300 universal beams.", WorkspaceTab.ROLLING),
        DemoStepInfo(7, "8. Inspect Finished Material", "Log ultrasonic surface, dimensional profile, and tensile mechanical tests.", WorkspaceTab.QUALITY),
        DemoStepInfo(8, "9. Authorised Release & Strapping", "Issue BS EN 10204 Type 3.1 Mill Test Certificate and strap bundles.", WorkspaceTab.QUALITY),
        DemoStepInfo(9, "10. Allocate & Dispatch Customer Order", "Reconcile order for HS2 Infrastructure and clear exit weighbridge.", WorkspaceTab.DISPATCH),
        DemoStepInfo(10, "11. Audit Genealogy, Energy & Costs", "Review complete heat genealogy from raw scrap to dispatched bundles.", WorkspaceTab.ANALYTICS)
    )

    fun executeDemoStep(stepIndex: Int) {
        _demoCurrentStep.value = stepIndex
        val step = demoSteps.getOrNull(stepIndex) ?: return
        selectTab(step.targetTab)

        viewModelScope.launch {
            when (stepIndex) {
                0 -> {
                    repository.receiveScrapWeighbridge("HMS-1", "British Metal Recycling Ltd", 85.0, 242.0, "Yard Bay 1-A")
                    _snackbarMessage.value = "Step 1: 85t HMS-1 received & ticket printed."
                }
                1 -> {
                    val lot = scrapInventory.value.firstOrNull { it.availableTonnes > 50 }
                    if (lot != null) {
                        repository.reserveScrapForCharge(lot.id, 50.0)
                        _snackbarMessage.value = "Step 2: Reserved 50t from ${lot.id} for charge plan."
                    }
                }
                2 -> {
                    val newNum = repository.createNewHeat("S355JR", 240.0)
                    _snackbarMessage.value = "Step 3: Created Heat #$newNum."
                }
                3 -> {
                    val current = activeHeat.value
                    if (current != null) {
                        repository.advanceHeatStage(current.heatNumber)
                        _snackbarMessage.value = "Step 4: Advanced Melt Shop stage to ${current.currentStage}."
                    }
                }
                4 -> {
                    val current = activeHeat.value ?: return@launch
                    repository.recordLabSample(
                        current.heatNumber,
                        "LF_INTERMEDIATE",
                        0.18, 0.32, 1.45, 0.018, 0.038,
                        false, "QUARANTINE_HOLD",
                        "Elevated sulfur 0.038% flagged. Dispatched +400kg calcium aluminate slag."
                    )
                    delay(800)
                    repository.recordLabSample(
                        current.heatNumber,
                        "LF_FINAL_RELEASE",
                        0.18, 0.34, 1.46, 0.016, 0.018,
                        true, "APPROVED",
                        "Desulfurization completed. Sulfur reduced to 0.018%. Chemistry APPROVED."
                    )
                    _snackbarMessage.value = "Step 5: Lab detected sulfur event, applied flux trim, and APPROVED release!"
                }
                5 -> {
                    val current = activeHeat.value ?: return@launch
                    repository.castOutputBillets(current.heatNumber, 4)
                    _snackbarMessage.value = "Step 6: Cast 4 billets (15.04t) on Continuous Caster."
                }
                6 -> {
                    val current = activeHeat.value ?: return@launch
                    val batchId = repository.scheduleAndRollBatch(current.heatNumber, "HEB 300 Universal Beam")
                    _snackbarMessage.value = "Step 7: Rolled batch $batchId produced."
                }
                7 -> {
                    _snackbarMessage.value = "Step 8: Surface, ultrasonic & dimensional checks conforming."
                }
                8 -> {
                    val samples = labSamples.value
                    val approved = samples.firstOrNull { it.isPassed }
                    if (approved != null) {
                        viewInspectionCertificate(approved)
                        _snackbarMessage.value = "Step 9: BS EN 10204 Type 3.1 Mill Certificate generated!"
                    }
                }
                9 -> {
                    val unallocatedBundle = finishedBundles.value.firstOrNull { it.allocatedOrderId == null && it.isQualityReleased }
                    val order = customerOrders.value.firstOrNull { it.status == "OPEN" }
                    if (unallocatedBundle != null && order != null) {
                        repository.allocateOrder(order.orderId, unallocatedBundle.bundleId)
                        repository.dispatchOrder(order.orderId)
                        _snackbarMessage.value = "Step 10: Allocated ${unallocatedBundle.bundleId} and dispatched Order ${order.orderId}!"
                    } else {
                        _snackbarMessage.value = "Step 10: Finished bundles reconciled with weighbridge delivery note."
                    }
                }
                10 -> {
                    _snackbarMessage.value = "Step 11: End-to-end genealogy and unit cost analysis verified!"
                }
            }
        }
    }
}
