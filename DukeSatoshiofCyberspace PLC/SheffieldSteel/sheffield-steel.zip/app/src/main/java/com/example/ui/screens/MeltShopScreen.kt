package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.entities.HeatRecord
import com.example.data.local.entities.LabSample
import com.example.ui.components.TechnicalLineChart
import com.example.ui.theme.*

@Composable
fun MeltShopScreen(
    activeHeat: HeatRecord?,
    allHeats: List<HeatRecord>,
    labSamples: List<LabSample>,
    onAdvanceStage: () -> Unit,
    onCorrectEntry: (heatNum: Int, param: String, oldVal: String, newVal: String, reason: String) -> Unit,
    onCreateHeat: (grade: String, tonnes: Double) -> Unit,
    modifier: Modifier = Modifier
) {
    var showCorrectEntryDialog by remember { mutableStateOf(false) }
    var showCreateHeatDialog by remember { mutableStateOf(false) }

    val heat = activeHeat
    val heatNum = heat?.heatNumber ?: 2847
    val bathTemp = heat?.bathTempC ?: 1620
    val power = heat?.activePowerMw ?: 78.0
    val totalEnergy = heat?.totalEnergyMwh ?: 98.88
    val energyPerTonne = heat?.energyKwhPerTonne ?: 412.0

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(SheffieldBackground)
            .padding(16.dp)
            .verticalScroll(rememberScrollState())
            .testTag("melt_shop_screen"),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Top Toolbar
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "ELECTRIC ARC FURNACE 02 & LADLE REFINING (LF-01)",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = SheffieldIvory
                )
                Text(
                    text = "River Don Melt Shop · 120 MVA Ultra-High Power Transformer · Water-cooled tubular panels",
                    style = MaterialTheme.typography.bodySmall,
                    color = SheffieldIvoryMuted
                )
            }

            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedButton(
                    onClick = { showCorrectEntryDialog = true },
                    shape = RoundedCornerShape(4.dp)
                ) {
                    Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("CORRECT OPERATOR ENTRY", style = MaterialTheme.typography.labelSmall)
                }

                Button(
                    onClick = { showCreateHeatDialog = true },
                    colors = ButtonDefaults.buttonColors(containerColor = MoltenOrange, contentColor = Color(0xFF0F0A05)),
                    shape = RoundedCornerShape(4.dp)
                ) {
                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("SCHEDULE NEW HEAT", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                }
            }
        }

        // Active Telemetry Grid
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            TelemetryTile("BATH TEMPERATURE", "${bathTemp} °C", "Celox Optical Probe (Measured)", MoltenGold, Modifier.weight(1f))
            TelemetryTile("ACTIVE POWER", "${power} MW", "120 MVA EAF Transformer", MoltenOrange, Modifier.weight(1f))
            TelemetryTile("ACCUMULATED ENERGY", "${totalEnergy} MWh", "Current Tap-to-Tap Heat", SheffieldIvory, Modifier.weight(1f))
            TelemetryTile("SPECIFIC CONSUMPTION", "${energyPerTonne.toInt()} kWh/t", "Target: <425 kWh/t (Good)", SignalGreen, Modifier.weight(1f))
        }

        // EAF vs Ladle Furnace Dual Status Panels
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // EAF Section
            Surface(
                color = SheffieldCard,
                shape = RoundedCornerShape(4.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, SheffieldBorder),
                modifier = Modifier.weight(1f)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("EAF-02 PRIMARY MELTING", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = MoltenOrange)
                        Text("ROOF: CLOSED & LOCKED", style = MaterialTheme.typography.labelSmall, color = SignalGreen)
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                    ParamRow("Electrode Consumption", "1.65 kg/t (Graphite Ø600mm)")
                    ParamRow("Oxygen Lance Rate", "3,200 Nm³/h Co-jet supersonic")
                    ParamRow("Foaming Slag Height", "420 mm (Optimal arc shielding)")
                    ParamRow("Tap Hole Status", "Sand filled · Slide-gate ready")
                    ParamRow("Delta Exhaust Gas Temp", "185 °C (Baghouse filtration active)")
                }
            }

            // LF Secondary Metallurgy Section
            Surface(
                color = SheffieldCard,
                shape = RoundedCornerShape(4.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, SheffieldBorder),
                modifier = Modifier.weight(1f)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("LF-01 SECONDARY REFINING", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = ElectricArcBlue)
                        Text("LADLE: 09 ON CAR", style = MaterialTheme.typography.labelSmall, color = MoltenGold)
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                    ParamRow("Argon Bottom Stirring", "4.2 bar · Flow 140 Nl/min (Active)")
                    ParamRow("Synthetic Slag Basicity (V)", "2.85 (CaO / SiO₂ desulfurizing)")
                    ParamRow("Wire Injection Feeder", "CaSi wire 2.2 m/s · Al wire armed")
                    ParamRow("Ladle Freeboard", "450 mm (Safe for vacuum degassing)")
                    ParamRow("Refractory Lining Wear", "82 heats remaining on barrel")
                }
            }
        }

        // Recent Lab Samples Registered for Current Heat
        Surface(
            color = SheffieldCard,
            shape = RoundedCornerShape(4.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, SheffieldBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text(
                    text = "RECORDED OES SPECTROMETER CHEMISTRY SAMPLES (HEAT #$heatNum)",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = SheffieldIvory
                )
                Spacer(modifier = Modifier.height(8.dp))

                val heatSamples = labSamples.filter { it.heatNumber == heatNum }
                if (heatSamples.isEmpty()) {
                    Text("No samples registered yet for Heat #$heatNum", color = SheffieldIvoryDim)
                } else {
                    heatSamples.forEach { sample ->
                        Surface(
                            color = SheffieldSurface,
                            shape = RoundedCornerShape(4.dp),
                            border = androidx.compose.foundation.BorderStroke(1.dp, if (sample.isPassed) SignalGreen.copy(alpha = 0.5f) else DangerRed.copy(alpha = 0.8f)),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween,
                                modifier = Modifier.padding(10.dp)
                            ) {
                                Column {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(sample.sampleId, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, color = MoltenGold)
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text(sample.sampleType, style = MaterialTheme.typography.labelSmall, color = SheffieldIvoryMuted)
                                    }
                                    Text(
                                        text = "C: ${sample.carbonPct}% | Si: ${sample.siliconPct}% | Mn: ${sample.manganesePct}% | P: ${sample.phosphorusPct}% | S: ${sample.sulfurPct}%",
                                        fontFamily = FontFamily.Monospace,
                                        fontSize = 12.sp,
                                        color = SheffieldIvory
                                    )
                                    Text(sample.notes, style = MaterialTheme.typography.bodySmall, color = SheffieldIvoryDim, fontSize = 11.sp)
                                }

                                Text(
                                    text = sample.qualityStatus,
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = if (sample.isPassed) SignalGreen else DangerRed
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    // Correct Entry Dialog (Audit Trail Requirement!)
    if (showCorrectEntryDialog) {
        var paramName by remember { mutableStateOf("Ladle 09 Tare Weight") }
        var oldVal by remember { mutableStateOf("48.2 t") }
        var newVal by remember { mutableStateOf("47.9 t") }
        var reason by remember { mutableStateOf("Weighbridge load cell zero-point calibration drift correction") }

        AlertDialog(
            onDismissRequest = { showCorrectEntryDialog = false },
            title = { Text("Correct Operator Entry (Audit Trail Logged)", color = SheffieldIvory) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Production records are auditable. Any correction records original, new value, and reason.", style = MaterialTheme.typography.bodySmall, color = SheffieldIvoryMuted)
                    OutlinedTextField(value = paramName, onValueChange = { paramName = it }, label = { Text("Parameter") })
                    OutlinedTextField(value = oldVal, onValueChange = { oldVal = it }, label = { Text("Original Recorded Value") })
                    OutlinedTextField(value = newVal, onValueChange = { newVal = it }, label = { Text("Corrected Value") })
                    OutlinedTextField(value = reason, onValueChange = { reason = it }, label = { Text("Reason for Correction") })
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        onCorrectEntry(heatNum, paramName, oldVal, newVal, reason)
                        showCorrectEntryDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MoltenOrange)
                ) {
                    Text("RECORD AUDIT CORRECTION")
                }
            },
            dismissButton = {
                TextButton(onClick = { showCorrectEntryDialog = false }) { Text("CANCEL") }
            }
        )
    }

    // Schedule New Heat Dialog
    if (showCreateHeatDialog) {
        var grade by remember { mutableStateOf("S355JR") }
        var tonnesStr by remember { mutableStateOf("240.0") }

        AlertDialog(
            onDismissRequest = { showCreateHeatDialog = false },
            title = { Text("Schedule Heat for Melt Shop", color = SheffieldIvory) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = grade, onValueChange = { grade = it }, label = { Text("Steel Grade") })
                    OutlinedTextField(value = tonnesStr, onValueChange = { tonnesStr = it }, label = { Text("Target Liquid Steel (t)") })
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val t = tonnesStr.toDoubleOrNull() ?: 240.0
                        onCreateHeat(grade, t)
                        showCreateHeatDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MoltenOrange)
                ) {
                    Text("CREATE HEAT")
                }
            },
            dismissButton = {
                TextButton(onClick = { showCreateHeatDialog = false }) { Text("CANCEL") }
            }
        )
    }
}

@Composable
private fun TelemetryTile(label: String, value: String, sublabel: String, color: Color, modifier: Modifier = Modifier) {
    Surface(
        color = SheffieldCard,
        shape = RoundedCornerShape(4.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, SheffieldBorder),
        modifier = modifier
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text(label, style = MaterialTheme.typography.labelSmall, color = SheffieldIvoryDim, letterSpacing = 0.8.sp)
            Spacer(modifier = Modifier.height(4.dp))
            Text(value, fontFamily = FontFamily.Monospace, fontSize = 24.sp, fontWeight = FontWeight.Black, color = color)
            Spacer(modifier = Modifier.height(2.dp))
            Text(sublabel, style = MaterialTheme.typography.bodySmall, fontSize = 10.sp, color = SheffieldIvoryMuted)
        }
    }
}

@Composable
private fun ParamRow(name: String, value: String) {
    Row(
        horizontalArrangement = Arrangement.SpaceBetween,
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 3.dp)
    ) {
        Text(name, style = MaterialTheme.typography.bodySmall, color = SheffieldIvoryDim)
        Text(value, style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold, color = SheffieldIvory)
    }
}
