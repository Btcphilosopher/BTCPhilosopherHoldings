package com.example.data.local.dao

import androidx.room.*
import com.example.data.local.entities.*
import kotlinx.coroutines.flow.Flow

@Dao
interface SteelworksDao {

    // --- Scrap Inventory ---
    @Query("SELECT * FROM scrap_inventory ORDER BY receiptTimestamp DESC")
    fun getAllScrap(): Flow<List<ScrapInventoryItem>>

    @Query("SELECT * FROM scrap_inventory WHERE id = :id LIMIT 1")
    suspend fun getScrapById(id: String): ScrapInventoryItem?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertScrap(items: List<ScrapInventoryItem>)

    @Update
    suspend fun updateScrap(item: ScrapInventoryItem)

    // --- Heats ---
    @Query("SELECT * FROM heats ORDER BY heatNumber DESC")
    fun getAllHeats(): Flow<List<HeatRecord>>

    @Query("SELECT * FROM heats WHERE heatNumber = :heatNumber LIMIT 1")
    fun getHeatFlow(heatNumber: Int): Flow<HeatRecord?>

    @Query("SELECT * FROM heats WHERE heatNumber = :heatNumber LIMIT 1")
    suspend fun getHeat(heatNumber: Int): HeatRecord?

    @Query("SELECT * FROM heats WHERE status = 'ONLINE' OR status = 'ACTIVE' LIMIT 1")
    fun getActiveHeatFlow(): Flow<HeatRecord?>

    @Query("SELECT * FROM heats WHERE status = 'QUEUED' ORDER BY heatNumber ASC")
    fun getUpcomingHeatsFlow(): Flow<List<HeatRecord>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertHeats(heats: List<HeatRecord>)

    @Update
    suspend fun updateHeat(heat: HeatRecord)

    // --- Telemetry ---
    @Query("SELECT * FROM telemetry_snapshots WHERE heatNumber = :heatNumber ORDER BY timestampEpoch DESC LIMIT 30")
    fun getRecentTelemetry(heatNumber: Int): Flow<List<TelemetrySnapshot>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTelemetry(snapshot: TelemetrySnapshot)

    // --- Lab Samples ---
    @Query("SELECT * FROM lab_samples ORDER BY timestampEpoch DESC")
    fun getAllLabSamples(): Flow<List<LabSample>>

    @Query("SELECT * FROM lab_samples WHERE heatNumber = :heatNumber ORDER BY timestampEpoch DESC")
    fun getSamplesForHeat(heatNumber: Int): Flow<List<LabSample>>

    @Query("SELECT * FROM lab_samples WHERE sampleId = :sampleId LIMIT 1")
    suspend fun getSampleById(sampleId: String): LabSample?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSample(sample: LabSample)

    @Update
    suspend fun updateSample(sample: LabSample)

    // --- Cast Billets ---
    @Query("SELECT * FROM cast_billets ORDER BY sequenceNumber DESC")
    fun getAllBillets(): Flow<List<CastBillet>>

    @Query("SELECT * FROM cast_billets WHERE heatNumber = :heatNumber ORDER BY sequenceNumber ASC")
    fun getBilletsForHeat(heatNumber: Int): Flow<List<CastBillet>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBillets(billets: List<CastBillet>)

    @Update
    suspend fun updateBillet(billet: CastBillet)

    // --- Rolled Batches ---
    @Query("SELECT * FROM rolled_batches ORDER BY rollingDateEpoch DESC")
    fun getAllRolledBatches(): Flow<List<RolledBatch>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRolledBatch(batch: RolledBatch)

    // --- Finished Bundles ---
    @Query("SELECT * FROM finished_bundles ORDER BY bundleId ASC")
    fun getAllBundles(): Flow<List<FinishedBundle>>

    @Query("SELECT * FROM finished_bundles WHERE isQualityReleased = 1 AND status = 'IN_STOCK'")
    fun getAvailableReleasedBundles(): Flow<List<FinishedBundle>>

    @Query("SELECT * FROM finished_bundles WHERE bundleId = :bundleId LIMIT 1")
    suspend fun getBundleById(bundleId: String): FinishedBundle?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBundles(bundles: List<FinishedBundle>)

    @Update
    suspend fun updateBundle(bundle: FinishedBundle)

    // --- Customer Orders ---
    @Query("SELECT * FROM customer_orders ORDER BY targetDeliveryEpoch ASC")
    fun getAllOrders(): Flow<List<CustomerOrder>>

    @Query("SELECT * FROM customer_orders WHERE orderId = :orderId LIMIT 1")
    suspend fun getOrderById(orderId: String): CustomerOrder?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrders(orders: List<CustomerOrder>)

    @Update
    suspend fun updateOrder(order: CustomerOrder)

    // --- Equipment ---
    @Query("SELECT * FROM equipment_units")
    fun getAllEquipment(): Flow<List<EquipmentUnit>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertEquipment(units: List<EquipmentUnit>)

    @Update
    suspend fun updateEquipment(unit: EquipmentUnit)

    // --- Audit Logs ---
    @Query("SELECT * FROM audit_logs ORDER BY timestampEpoch DESC LIMIT 100")
    fun getAuditLogs(): Flow<List<AuditLogEntry>>

    @Insert
    suspend fun insertAuditLog(log: AuditLogEntry)
}
