package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.components.*
import com.example.ui.screens.*
import com.example.ui.theme.SheffieldBackground
import com.example.ui.theme.SheffieldSteelTheme
import com.example.ui.viewmodel.SteelworksViewModel
import com.example.ui.viewmodel.WorkspaceTab

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            SheffieldSteelTheme {
                SteelTerminalApp()
            }
        }
    }
}

@Composable
fun SteelTerminalApp(
    viewModel: SteelworksViewModel = viewModel()
) {
    val currentTab by viewModel.currentTab.collectAsStateWithLifecycle()
    val selectedPlant by viewModel.selectedPlant.collectAsStateWithLifecycle()
    val connectionStatus by viewModel.connectionStatus.collectAsStateWithLifecycle()
    val isSimulationActive by viewModel.isSimulationActive.collectAsStateWithLifecycle()
    val currentShift by viewModel.currentShift.collectAsStateWithLifecycle()
    val operatorUser by viewModel.operatorUser.collectAsStateWithLifecycle()

    val activeHeat by viewModel.activeHeat.collectAsStateWithLifecycle()
    val upcomingHeats by viewModel.upcomingHeats.collectAsStateWithLifecycle()
    val allHeats by viewModel.allHeats.collectAsStateWithLifecycle()
    val scrapItems by viewModel.scrapInventory.collectAsStateWithLifecycle()
    val labSamples by viewModel.labSamples.collectAsStateWithLifecycle()
    val castBillets by viewModel.castBillets.collectAsStateWithLifecycle()
    val rolledBatches by viewModel.rolledBatches.collectAsStateWithLifecycle()
    val finishedBundles by viewModel.finishedBundles.collectAsStateWithLifecycle()
    val customerOrders by viewModel.customerOrders.collectAsStateWithLifecycle()
    val equipmentUnits by viewModel.equipmentUnits.collectAsStateWithLifecycle()
    val auditLogs by viewModel.auditLogs.collectAsStateWithLifecycle()
    val telemetryHistory by viewModel.recentTelemetry.collectAsStateWithLifecycle()

    val massBalanceResult by viewModel.massBalanceResult.collectAsStateWithLifecycle()
    val targetGrade by viewModel.targetGrade.collectAsStateWithLifecycle()
    val targetLiquidTonnes by viewModel.targetLiquidTonnes.collectAsStateWithLifecycle()

    val selectedCertificate by viewModel.selectedCertificate.collectAsStateWithLifecycle()
    val isDemoRunnerOpen by viewModel.isDemoRunnerOpen.collectAsStateWithLifecycle()
    val demoStepIndex by viewModel.demoCurrentStep.collectAsStateWithLifecycle()
    val snackbarMsg by viewModel.snackbarMessage.collectAsStateWithLifecycle()

    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(snackbarMsg) {
        if (snackbarMsg != null) {
            snackbarHostState.showSnackbar(
                message = snackbarMsg!!,
                duration = SnackbarDuration.Short
            )
            viewModel.clearSnackbar()
        }
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            Column(modifier = Modifier.statusBarsPadding()) {
                TopBarTerminal(
                    currentTab = currentTab,
                    selectedPlant = selectedPlant,
                    connectionStatus = connectionStatus,
                    isSimulationActive = isSimulationActive,
                    currentShift = currentShift,
                    operatorUser = operatorUser,
                    onSelectPlant = { viewModel.selectPlant(it) },
                    onSelectConnectionStatus = { viewModel.setConnectionStatus(it) },
                    onToggleSimulation = { viewModel.toggleSimulation() },
                    onOpenDemoRunner = { viewModel.toggleDemoRunner(true) }
                )
                SheffieldNavigationTabs(
                    selectedTab = currentTab,
                    onTabSelected = { viewModel.selectTab(it) }
                )
            }
        },
        containerColor = SheffieldBackground,
        modifier = Modifier
            .fillMaxSize()
            .navigationBarsPadding()
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(SheffieldBackground)
        ) {
            when (currentTab) {
                WorkspaceTab.OVERVIEW -> {
                    OverviewScreen(
                        activeHeat = activeHeat,
                        upcomingHeats = upcomingHeats,
                        telemetryHistory = telemetryHistory,
                        isSimulationRunning = isSimulationActive,
                        onAdvanceStage = { viewModel.advanceActiveHeatStage() }
                    )
                }

                WorkspaceTab.MATERIALS -> {
                    MaterialsScreen(
                        scrapItems = scrapItems,
                        massBalanceResult = massBalanceResult,
                        targetGrade = targetGrade,
                        targetTonnes = targetLiquidTonnes,
                        onSelectGrade = { viewModel.setTargetGrade(it) },
                        onUpdateTonnes = { viewModel.setTargetLiquidTonnes(it) },
                        onReceiveScrap = { cat, sup, w, c, bay ->
                            viewModel.receiveScrap(cat, sup, w, c, bay)
                        },
                        onReserveScrap = { lotId, tonnes ->
                            viewModel.reserveScrap(lotId, tonnes)
                        }
                    )
                }

                WorkspaceTab.MELT_SHOP -> {
                    MeltShopScreen(
                        activeHeat = activeHeat,
                        allHeats = allHeats,
                        labSamples = labSamples,
                        onAdvanceStage = { viewModel.advanceActiveHeatStage() },
                        onCorrectEntry = { hn, param, oldVal, newVal, reason ->
                            viewModel.correctOperatorEntry(hn, param, oldVal, newVal, reason)
                        },
                        onCreateHeat = { grade, tonnes ->
                            viewModel.createNewHeat(grade, tonnes)
                        }
                    )
                }

                WorkspaceTab.CASTING -> {
                    CastingScreen(
                        activeHeat = activeHeat,
                        castBillets = castBillets,
                        onCastBillets = { viewModel.castBilletsForActiveHeat() }
                    )
                }

                WorkspaceTab.ROLLING -> {
                    RollingScreen(
                        rolledBatches = rolledBatches,
                        finishedBundles = finishedBundles,
                        onRollBatch = { hn, section ->
                            viewModel.scheduleAndRollBatch(hn, section)
                        }
                    )
                }

                WorkspaceTab.QUALITY -> {
                    QualityScreen(
                        labSamples = labSamples,
                        onViewCertificate = { sample ->
                            viewModel.viewInspectionCertificate(sample)
                        },
                        onReleaseHold = { sampleId, reason ->
                            viewModel.releaseQualityHold(sampleId, reason)
                        },
                        onRegisterSample = { hn, type, c, si, mn, p, s, passed, status, notes ->
                            viewModel.recordLabSample(hn, type, c, si, mn, p, s, passed, status, notes)
                        }
                    )
                }

                WorkspaceTab.MAINTENANCE -> {
                    MaintenanceScreen(
                        equipmentList = equipmentUnits,
                        onToggleDowntime = { unitId ->
                            viewModel.toggleEquipmentDowntime(unitId)
                        }
                    )
                }

                WorkspaceTab.DISPATCH -> {
                    DispatchScreen(
                        orders = customerOrders,
                        bundles = finishedBundles,
                        onAllocateBundle = { ordId, bundleId ->
                            viewModel.allocateOrder(ordId, bundleId)
                        },
                        onDispatchOrder = { ordId ->
                            viewModel.dispatchOrder(ordId)
                        }
                    )
                }

                WorkspaceTab.ANALYTICS -> {
                    AnalyticsScreen(
                        activeHeat = activeHeat,
                        auditLogs = auditLogs
                    )
                }
            }

            // Inspection Certificate Dialog (BS EN 10204 Type 3.1)
            selectedCertificate?.let { sample ->
                InspectionCertificateDialog(
                    sample = sample,
                    onDismiss = { viewModel.viewInspectionCertificate(null) }
                )
            }

            // Demonstration 11-Step Complete Tour Dialog
            if (isDemoRunnerOpen) {
                DemonstrationRunnerDialog(
                    steps = viewModel.demoSteps,
                    currentStepIndex = demoStepIndex,
                    onExecuteStep = { stepIdx ->
                        viewModel.executeDemoStep(stepIdx)
                    },
                    onDismiss = { viewModel.toggleDemoRunner(false) }
                )
            }
        }
    }
}
