package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.entities.ScrapInventoryItem
import com.example.data.model.SteelGrade
import com.example.data.simulator.MassBalanceResult
import com.example.ui.theme.*

@Composable
fun MaterialsScreen(
    scrapItems: List<ScrapInventoryItem>,
    massBalanceResult: MassBalanceResult,
    targetGrade: SteelGrade,
    targetTonnes: Double,
    onSelectGrade: (SteelGrade) -> Unit,
    onUpdateTonnes: (Double) -> Unit,
    onReceiveScrap: (category: String, supplier: String, weight: Double, cost: Double, bay: String) -> Unit,
    onReserveScrap: (lotId: String, tonnes: Double) -> Unit,
    modifier: Modifier = Modifier
) {
    var showWeighbridgeDialog by remember { mutableStateOf(false) }
    var selectedLotForReserve by remember { mutableStateOf<ScrapInventoryItem?>(null) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(SheffieldBackground)
            .padding(16.dp)
            .testTag("materials_screen"),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // TOP SUMMARY ROW: Total scrap in stock, Reserved, Quarantined, Actions
        val totalAvailable = scrapItems.sumOf { it.availableTonnes }
        val totalReserved = scrapItems.sumOf { it.reservedTonnes }
        val totalQuarantined = scrapItems.sumOf { it.quarantinedTonnes }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(horizontalArrangement = Arrangement.spacedBy(24.dp)) {
                MetricPill("AVAILABLE SCRAP", "${String.format("%,d", totalAvailable.toInt())} t", SignalGreen)
                MetricPill("RESERVED IN CHARGE", "${String.format("%,d", totalReserved.toInt())} t", MoltenGold)
                MetricPill("QUARANTINE / HOLD", "${String.format("%,d", totalQuarantined.toInt())} t", if (totalQuarantined > 0) DangerRed else SheffieldIvoryDim)
            }

            Button(
                onClick = { showWeighbridgeDialog = true },
                colors = ButtonDefaults.buttonColors(containerColor = MoltenOrange, contentColor = Color(0xFF0F0A05)),
                shape = RoundedCornerShape(4.dp),
                modifier = Modifier.testTag("weighbridge_receive_button")
            ) {
                Icon(Icons.Default.Scale, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("WEIGHBRIDGE RECEIPT (NEW LOT)", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
            }
        }

        // MAIN WORKSPACE (Split 50/50: Left = Scrap Inventory Register · Right = Constrained Mass-Balance Charge Planner)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f),
            horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // LEFT: INVENTORY YARD & LOT REGISTER
            Surface(
                color = SheffieldCard,
                shape = RoundedCornerShape(4.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, SheffieldBorder),
                modifier = Modifier
                    .weight(0.5f)
                    .fillMaxHeight()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "SCRAP & ALLOY STORAGE REGISTER",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = SheffieldIvory,
                        letterSpacing = 0.8.sp
                    )
                    Spacer(modifier = Modifier.height(10.dp))

                    LazyColumn(
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxSize()
                    ) {
                        items(scrapItems) { item ->
                            val isQuarantined = item.quarantinedTonnes > 0
                            val cardBorder = if (isQuarantined) DangerRed else SheffieldBorderSubtle

                            Surface(
                                color = SheffieldSurface,
                                shape = RoundedCornerShape(4.dp),
                                border = androidx.compose.foundation.BorderStroke(1.dp, cardBorder),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(10.dp)) {
                                    Row(
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Text(
                                                text = item.id,
                                                fontFamily = FontFamily.Monospace,
                                                fontWeight = FontWeight.Bold,
                                                color = MoltenGold
                                            )
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Text(
                                                text = item.category,
                                                style = MaterialTheme.typography.labelSmall,
                                                color = SheffieldIvory,
                                                fontWeight = FontWeight.Bold,
                                                modifier = Modifier
                                                    .background(SheffieldCardElevated, RoundedCornerShape(2.dp))
                                                    .padding(horizontal = 4.dp, vertical = 2.dp)
                                            )
                                        }

                                        Text(
                                            text = item.locationBay,
                                            style = MaterialTheme.typography.labelSmall,
                                            color = ElectricArcBlue
                                        )
                                    }

                                    Spacer(modifier = Modifier.height(6.dp))

                                    Text(
                                        text = "Supplier: ${item.supplier}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = SheffieldIvoryMuted
                                    )

                                    Spacer(modifier = Modifier.height(6.dp))

                                    Row(
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Text("Available: ${item.availableTonnes} t", fontFamily = FontFamily.Monospace, fontSize = 12.sp, color = SignalGreen)
                                        Text("Reserved: ${item.reservedTonnes} t", fontFamily = FontFamily.Monospace, fontSize = 12.sp, color = MoltenGold)
                                        Text("Cost: £${item.unitCostGbp}/t", fontFamily = FontFamily.Monospace, fontSize = 12.sp, color = SheffieldIvory)
                                    }

                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = "Ticket: ${item.weighbridgeTicket}",
                                        style = MaterialTheme.typography.bodySmall,
                                        fontSize = 10.sp,
                                        color = SheffieldIvoryDim
                                    )

                                    if (item.availableTonnes > 0) {
                                        Spacer(modifier = Modifier.height(8.dp))
                                        OutlinedButton(
                                            onClick = { selectedLotForReserve = item },
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .height(30.dp),
                                            shape = RoundedCornerShape(2.dp),
                                            contentPadding = PaddingValues(0.dp)
                                        ) {
                                            Text("RESERVE FOR CHARGE PLAN", style = MaterialTheme.typography.labelSmall, color = MoltenOrange)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // RIGHT: CONSTRAINED MASS-BALANCE CHARGE PLANNER
            Surface(
                color = SheffieldCard,
                shape = RoundedCornerShape(4.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, SheffieldBorder),
                modifier = Modifier
                    .weight(0.5f)
                    .fillMaxHeight()
                    .testTag("charge_planner_panel")
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(14.dp)
                ) {
                    Text(
                        text = "CONSTRAINED MASS-BALANCE CHARGE MODEL",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = SheffieldIvory,
                        letterSpacing = 0.8.sp
                    )
                    Text(
                        text = "First-principles thermodynamic mass recovery & stoichiometric chemical calculation",
                        style = MaterialTheme.typography.bodySmall,
                        color = SheffieldIvoryMuted
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    // Target Grade Selector
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("TARGET GRADE:", style = MaterialTheme.typography.labelSmall, color = SheffieldIvoryDim)
                        SteelGrade.values().forEach { g ->
                            val isSelected = g == targetGrade
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(if (isSelected) MoltenOrange else SheffieldSurface)
                                    .clickable { onSelectGrade(g) }
                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Text(
                                    text = g.code,
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isSelected) Color.Black else SheffieldIvory
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Target Tonnes Slider / Display
                    Row(
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("TARGET LIQUID STEEL:", style = MaterialTheme.typography.labelSmall, color = SheffieldIvoryDim)
                        Text("${targetTonnes.toInt()} METRIC TONNES", fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, color = MoltenGold)
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Calculation Results Table
                    Surface(
                        color = SheffieldSurface,
                        shape = RoundedCornerShape(4.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, SheffieldBorderSubtle),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                                Text("Total Scrap & Alloy Charge Required:", style = MaterialTheme.typography.bodySmall, color = SheffieldIvoryMuted)
                                Text("${massBalanceResult.totalChargeWeightTonnes} t", fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, color = SheffieldIvory)
                            }
                            Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                                Text("Expected Metallic Yield:", style = MaterialTheme.typography.bodySmall, color = SheffieldIvoryMuted)
                                Text("${massBalanceResult.expectedMetallicYieldPct}%", fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, color = SignalGreen)
                            }
                            Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                                Text("Estimated Slag & Oxidation Loss:", style = MaterialTheme.typography.bodySmall, color = SheffieldIvoryMuted)
                                Text("${massBalanceResult.estimatedSlagTonnes} t", fontFamily = FontFamily.Monospace, color = SheffieldIvoryDim)
                            }
                            Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                                Text("Estimated Charge Cost:", style = MaterialTheme.typography.bodySmall, color = SheffieldIvoryMuted)
                                Text("£${String.format("%,d", massBalanceResult.estimatedMaterialCostGbp.toInt())} (£${massBalanceResult.estimatedCostPerTonneGbp}/t)", fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, color = MoltenOrange)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Predicted Chemistry Output
                    Text("PREDICTED TAP CHEMISTRY (WEIGHT %):", style = MaterialTheme.typography.labelSmall, color = SheffieldIvoryDim)
                    Spacer(modifier = Modifier.height(6.dp))

                    Row(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        ChemBox("C", massBalanceResult.predictedCarbonPct)
                        ChemBox("Si", massBalanceResult.predictedSiliconPct)
                        ChemBox("Mn", massBalanceResult.predictedManganesePct)
                        ChemBox("P", massBalanceResult.predictedPhosphorusPct)
                        ChemBox("S", massBalanceResult.predictedSulfurPct)
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Feasibility Badge & Limiting Inputs Callout
                    Surface(
                        color = if (massBalanceResult.isFeasible) Color(0xFF10261A) else Color(0xFF2C1014),
                        shape = RoundedCornerShape(4.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, if (massBalanceResult.isFeasible) SignalGreen else DangerRed),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(10.dp)
                        ) {
                            Icon(
                                imageVector = if (massBalanceResult.isFeasible) Icons.Default.CheckCircle else Icons.Default.Warning,
                                contentDescription = null,
                                tint = if (massBalanceResult.isFeasible) SignalGreen else DangerRed,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = if (massBalanceResult.isFeasible) "FEASIBILITY: OPTIMAL WITHIN SPECIFICATION" else "FEASIBILITY: CONSTRAINED LIMITING INPUT",
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = if (massBalanceResult.isFeasible) SignalGreen else DangerRed
                                )
                                Text(
                                    text = massBalanceResult.limitingFactor,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = SheffieldIvory
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    // Weighbridge Dialog
    if (showWeighbridgeDialog) {
        var category by remember { mutableStateOf("HMS-1") }
        var supplier by remember { mutableStateOf("British Metal Recycling Ltd") }
        var weightStr by remember { mutableStateOf("85.0") }
        var costStr by remember { mutableStateOf("242.0") }
        var bay by remember { mutableStateOf("Yard Bay 1-A") }

        AlertDialog(
            onDismissRequest = { showWeighbridgeDialog = false },
            title = { Text("Weighbridge Scrap Receipt", color = SheffieldIvory) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = category, onValueChange = { category = it }, label = { Text("Scrap Category") })
                    OutlinedTextField(value = supplier, onValueChange = { supplier = it }, label = { Text("Supplier Name") })
                    OutlinedTextField(value = weightStr, onValueChange = { weightStr = it }, label = { Text("Gross Tonnes") })
                    OutlinedTextField(value = costStr, onValueChange = { costStr = it }, label = { Text("Cost Per Tonne (£)") })
                    OutlinedTextField(value = bay, onValueChange = { bay = it }, label = { Text("Assigned Yard Bay") })
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val w = weightStr.toDoubleOrNull() ?: 50.0
                        val c = costStr.toDoubleOrNull() ?: 240.0
                        onReceiveScrap(category, supplier, w, c, bay)
                        showWeighbridgeDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MoltenOrange)
                ) {
                    Text("PRINT WEIGHBRIDGE TICKET & ACCEPT")
                }
            },
            dismissButton = {
                TextButton(onClick = { showWeighbridgeDialog = false }) { Text("CANCEL") }
            }
        )
    }

    // Reserve Dialog
    if (selectedLotForReserve != null) {
        val lot = selectedLotForReserve!!
        var reserveTonnes by remember { mutableStateOf("40.0") }

        AlertDialog(
            onDismissRequest = { selectedLotForReserve = null },
            title = { Text("Reserve Scrap for Charge", color = SheffieldIvory) },
            text = {
                Column {
                    Text("Lot: ${lot.id} (${lot.category} - ${lot.supplier})", color = SheffieldIvoryMuted)
                    Text("Available: ${lot.availableTonnes} t", color = SignalGreen)
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(value = reserveTonnes, onValueChange = { reserveTonnes = it }, label = { Text("Tonnes to Reserve") })
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val t = reserveTonnes.toDoubleOrNull() ?: 10.0
                        onReserveScrap(lot.id, t)
                        selectedLotForReserve = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MoltenOrange)
                ) {
                    Text("CONFIRM RESERVATION")
                }
            },
            dismissButton = {
                TextButton(onClick = { selectedLotForReserve = null }) { Text("CANCEL") }
            }
        )
    }
}

@Composable
private fun MetricPill(title: String, value: String, color: Color) {
    Column {
        Text(title, style = MaterialTheme.typography.labelSmall, color = SheffieldIvoryDim)
        Text(value, fontFamily = FontFamily.Monospace, fontSize = 20.sp, fontWeight = FontWeight.Bold, color = color)
    }
}

@Composable
private fun RowScope.ChemBox(element: String, value: Double) {
    Surface(
        color = SheffieldCardElevated,
        shape = RoundedCornerShape(4.dp),
        modifier = Modifier.weight(1f)
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.padding(6.dp)
        ) {
            Text(element, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = SheffieldIvoryDim)
            Text("${value}%", fontFamily = FontFamily.Monospace, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = SheffieldIvory)
        }
    }
}
