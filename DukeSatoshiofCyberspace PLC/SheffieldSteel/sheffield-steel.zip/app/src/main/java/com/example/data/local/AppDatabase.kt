package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.data.local.dao.SteelworksDao
import com.example.data.local.entities.*

@Database(
    entities = [
        ScrapInventoryItem::class,
        HeatRecord::class,
        TelemetrySnapshot::class,
        LabSample::class,
        CastBillet::class,
        RolledBatch::class,
        FinishedBundle::class,
        CustomerOrder::class,
        EquipmentUnit::class,
        AuditLogEntry::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun steelworksDao(): SteelworksDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "sheffield_steelworks.db"
                ).fallbackToDestructiveMigration().build()
                INSTANCE = instance
                instance
            }
        }
    }
}
