package com.example.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.entities.HeatRecord
import com.example.ui.theme.*

@Composable
fun ProductionTimeline(
    heat: HeatRecord?,
    onAdvanceStage: () -> Unit,
    modifier: Modifier = Modifier
) {
    val currentStageName = heat?.currentStage ?: "CAST"
    val progressPct = heat?.stageProgressPct ?: 15

    val stages = listOf(
        Pair("CHARGE", "COMPLETED"),
        Pair("MELT", "COMPLETED"),
        Pair("REFINE", "COMPLETED"),
        Pair("TAP", "COMPLETED"),
        Pair("CAST", "IN PROGRESS $progressPct%")
    )

    // Animated rotation for in-progress gear/sync icon
    val infiniteTransition = rememberInfiniteTransition(label = "spin")
    val rotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(3000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "spinRot"
    )

    Surface(
        color = SheffieldCard,
        shape = RoundedCornerShape(4.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, SheffieldBorder),
        modifier = modifier
            .fillMaxWidth()
            .testTag("production_timeline_panel")
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = "PRODUCTION TIMELINE / HEAT ${heat?.heatNumber ?: 2847}",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.0.sp,
                    color = SheffieldIvory
                )

                TextButton(
                    onClick = onAdvanceStage,
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                    modifier = Modifier.testTag("advance_stage_button")
                ) {
                    Text(
                        text = "ADVANCE STAGE ▶",
                        style = MaterialTheme.typography.labelSmall,
                        color = MoltenOrange,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Stages Row
            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                stages.forEachIndexed { index, (stageName, stageStatus) ->
                    val isCurrent = stageName == currentStageName || (currentStageName == "CAST" && stageName == "CAST")
                    val isPast = when (currentStageName) {
                        "CHARGE" -> false
                        "MELT" -> stageName == "CHARGE"
                        "REFINE" -> stageName in listOf("CHARGE", "MELT")
                        "TAP" -> stageName in listOf("CHARGE", "MELT", "REFINE")
                        "CAST" -> stageName in listOf("CHARGE", "MELT", "REFINE", "TAP")
                        "COMPLETED" -> true
                        else -> false
                    }

                    val borderColor = when {
                        isCurrent -> MoltenOrange
                        isPast -> SignalGreen
                        else -> SheffieldBorder
                    }

                    val bgColor = when {
                        isCurrent -> Color(0xFF261907)
                        isPast -> Color(0xFF0D2517)
                        else -> SheffieldSurface
                    }

                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(4.dp))
                            .background(bgColor)
                            .border(1.dp, borderColor, RoundedCornerShape(4.dp))
                            .padding(horizontal = 10.dp, vertical = 8.dp)
                            .testTag("timeline_stage_$stageName")
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            if (isPast) {
                                Icon(
                                    imageVector = Icons.Default.CheckCircle,
                                    contentDescription = "Completed",
                                    tint = SignalGreen,
                                    modifier = Modifier.size(18.dp)
                                )
                            } else if (isCurrent) {
                                Icon(
                                    imageVector = Icons.Default.Sync,
                                    contentDescription = "In progress",
                                    tint = MoltenOrange,
                                    modifier = Modifier
                                        .size(18.dp)
                                        .rotate(rotation)
                                )
                            } else {
                                Box(
                                    modifier = Modifier
                                        .size(16.dp)
                                        .border(1.dp, SheffieldIvoryDim, RoundedCornerShape(8.dp))
                                )
                            }

                            Column {
                                Text(
                                    text = stageName,
                                    style = MaterialTheme.typography.labelLarge,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isCurrent) MoltenGold else if (isPast) SheffieldIvory else SheffieldIvoryDim
                                )
                                Text(
                                    text = if (isCurrent) "IN PROGRESS $progressPct%" else if (isPast) "COMPLETED" else "QUEUED",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = if (isCurrent) MoltenOrange else if (isPast) SignalGreen else SheffieldIvoryDim,
                                    fontSize = 9.sp
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
