package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.entities.CastBillet
import com.example.data.local.entities.HeatRecord
import com.example.ui.theme.*

@Composable
fun CastingScreen(
    activeHeat: HeatRecord?,
    castBillets: List<CastBillet>,
    onCastBillets: () -> Unit,
    modifier: Modifier = Modifier
) {
    val speed = activeHeat?.casterLineSpeedMpm ?: 1.2
    val waterFlow = activeHeat?.coolingWaterFlowM3h ?: 3480.0
    val waterInlet = activeHeat?.coolingInletC ?: 28.0
    val waterOutlet = activeHeat?.coolingOutletC ?: 41.0

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(SheffieldBackground)
            .padding(16.dp)
            .testTag("casting_screen"),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Top Bar
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "CONTINUOUS CASTING MACHINE (CCM-01 · 3 STRANDS)",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = SheffieldIvory
                )
                Text(
                    text = "Curved mould continuous casting · 200x200 mm billet radius 9.0m · Flying torch cutoff",
                    style = MaterialTheme.typography.bodySmall,
                    color = SheffieldIvoryMuted
                )
            }

            Button(
                onClick = onCastBillets,
                colors = ButtonDefaults.buttonColors(containerColor = MoltenOrange, contentColor = Color(0xFF0F0A05)),
                shape = RoundedCornerShape(4.dp),
                modifier = Modifier.testTag("cut_billets_button")
            ) {
                Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("TRIGGER STRAND CUTOFF & PRODUCE BILLETS", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
            }
        }

        // Live CCM Telemetry Cards
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            CCMTile("LINE SPEED", "${String.format("%.1f", speed)} m/min", "Strands 1, 2 & 3 sync", MoltenGold, Modifier.weight(1f))
            CCMTile("COOLING WATER", "${waterFlow.toInt()} m³/h", "In: ${waterInlet.toInt()}°C | Out: ${waterOutlet.toInt()}°C (ΔT 13°C)", ElectricArcBlue, Modifier.weight(1f))
            CCMTile("TUNDISH WEIGHT", "28.4 t", "Stopper rod automatic level", SheffieldIvory, Modifier.weight(1f))
            CCMTile("SUPERHEAT", "+24 °C", "Liquid bath delta above liquidus", SignalGreen, Modifier.weight(1f))
        }

        // 3-Strand Real-Time Operational Matrix
        Surface(
            color = SheffieldCard,
            shape = RoundedCornerShape(4.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, SheffieldBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text(
                    text = "STRAND OPERATING STATUS",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = SheffieldIvory
                )
                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    StrandCard(strandNum = 1, speed = speed, mouldOsc = "135 cpm", copperTemp = "182 °C", isRunning = true, Modifier.weight(1f))
                    StrandCard(strandNum = 2, speed = speed, mouldOsc = "135 cpm", copperTemp = "179 °C", isRunning = true, Modifier.weight(1f))
                    StrandCard(strandNum = 3, speed = 0.0, mouldOsc = "0 cpm", copperTemp = "32 °C", isRunning = false, Modifier.weight(1f))
                }
            }
        }

        // Cast Billets Register
        Surface(
            color = SheffieldCard,
            shape = RoundedCornerShape(4.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, SheffieldBorder),
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text(
                    text = "CAST BILLETS INVENTORY & COOLING BED",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = SheffieldIvory
                )
                Spacer(modifier = Modifier.height(8.dp))

                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(castBillets) { billet ->
                        Surface(
                            color = SheffieldSurface,
                            shape = RoundedCornerShape(4.dp),
                            border = androidx.compose.foundation.BorderStroke(1.dp, SheffieldBorderSubtle),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween,
                                modifier = Modifier.padding(10.dp)
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = billet.billetId,
                                        fontFamily = FontFamily.Monospace,
                                        fontWeight = FontWeight.Bold,
                                        color = MoltenGold
                                    )
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Text("Heat #${billet.heatNumber}", fontFamily = FontFamily.Monospace, color = SheffieldIvoryMuted)
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Text("Strand ${billet.strandNumber}", style = MaterialTheme.typography.bodySmall, color = SheffieldIvoryDim)
                                }

                                Text(
                                    text = "${billet.crossSectionMm} · ${billet.lengthMeters}m · ${billet.weightTonnes} t",
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 12.sp,
                                    color = SheffieldIvory
                                )

                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.CheckCircle, contentDescription = null, tint = SignalGreen, modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(billet.status, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = SignalGreen)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun CCMTile(label: String, value: String, sublabel: String, color: Color, modifier: Modifier = Modifier) {
    Surface(
        color = SheffieldCard,
        shape = RoundedCornerShape(4.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, SheffieldBorder),
        modifier = modifier
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text(label, style = MaterialTheme.typography.labelSmall, color = SheffieldIvoryDim)
            Spacer(modifier = Modifier.height(4.dp))
            Text(value, fontFamily = FontFamily.Monospace, fontSize = 24.sp, fontWeight = FontWeight.Black, color = color)
            Spacer(modifier = Modifier.height(2.dp))
            Text(sublabel, style = MaterialTheme.typography.bodySmall, fontSize = 10.sp, color = SheffieldIvoryMuted)
        }
    }
}

@Composable
private fun StrandCard(
    strandNum: Int,
    speed: Double,
    mouldOsc: String,
    copperTemp: String,
    isRunning: Boolean,
    modifier: Modifier = Modifier
) {
    Surface(
        color = SheffieldSurface,
        shape = RoundedCornerShape(4.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, if (isRunning) SignalGreen.copy(alpha = 0.5f) else SheffieldBorderSubtle),
        modifier = modifier
    ) {
        Column(modifier = Modifier.padding(10.dp)) {
            Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                Text("STRAND 0$strandNum", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = SheffieldIvory)
                Text(if (isRunning) "CASTING" else "STANDBY", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = if (isRunning) SignalGreen else SheffieldIvoryDim)
            }
            Spacer(modifier = Modifier.height(6.dp))
            Text("Speed: ${speed} m/min", fontFamily = FontFamily.Monospace, fontSize = 12.sp, color = if (isRunning) MoltenGold else SheffieldIvoryDim)
            Text("Oscillation: $mouldOsc", style = MaterialTheme.typography.bodySmall, color = SheffieldIvoryMuted)
            Text("Mould Cu Temp: $copperTemp", style = MaterialTheme.typography.bodySmall, color = SheffieldIvoryMuted)
        }
    }
}
