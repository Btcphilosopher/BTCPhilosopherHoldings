package com.example.data.repository

import android.content.Context
import com.example.data.local.AppDatabase
import com.example.data.local.entities.*
import com.example.data.model.*
import com.example.data.simulator.SteelworksSimulator
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.util.UUID
import kotlin.math.sin
import kotlin.random.Random

class SteelworksRepository(context: Context) {

    private val db = AppDatabase.getInstance(context)
    private val dao = db.steelworksDao()
    private val coroutineScope = CoroutineScope(Dispatchers.IO)

    // Current operating terminal state
    private val _selectedPlant = MutableStateFlow(PlantFacility.SHEFFIELD_DON_WORKS)
    val selectedPlant: StateFlow<PlantFacility> = _selectedPlant.asStateFlow()

    private val _connectionStatus = MutableStateFlow(ConnectionStatus.CONNECTED)
    val connectionStatus: StateFlow<ConnectionStatus> = _connectionStatus.asStateFlow()

    private val _simulationActive = MutableStateFlow(true)
    val simulationActive: StateFlow<Boolean> = _simulationActive.asStateFlow()

    private val _currentShift = MutableStateFlow("Shift A - Days (06:00 - 18:00)")
    val currentShift: StateFlow<String> = _currentShift.asStateFlow()

    private val _operatorUser = MutableStateFlow("J. Hargreaves (Shift Engineer)")
    val operatorUser: StateFlow<String> = _operatorUser.asStateFlow()

    // Simulation tick counter
    private var tickCount = 0

    init {
        coroutineScope.launch {
            seedDatabaseIfEmpty()
            generateInitialTelemetryIfEmpty()
        }
    }

    private suspend fun seedDatabaseIfEmpty() {
        val existingHeats = dao.getAllHeats().firstOrNull() ?: emptyList()
        if (existingHeats.isEmpty()) {
            val seedBundle = SteelworksSimulator.generateInitialSeedData()
            dao.insertScrap(seedBundle.scrapItems)
            dao.insertHeats(seedBundle.heats)
            seedBundle.labSamples.forEach { dao.insertSample(it) }
            dao.insertBillets(seedBundle.castBillets)
            dao.insertBundles(seedBundle.finishedBundles)
            dao.insertOrders(seedBundle.customerOrders)
            dao.insertEquipment(seedBundle.equipment)
            seedBundle.auditLogs.forEach { dao.insertAuditLog(it) }
        }
    }

    private suspend fun generateInitialTelemetryIfEmpty() {
        val existing = dao.getRecentTelemetry(2847).firstOrNull() ?: emptyList()
        if (existing.isEmpty()) {
            val now = System.currentTimeMillis()
            for (i in 30 downTo 0) {
                val t = now - (i * 60000L)
                val noisePower = 78.0 + (sin(i.toDouble() * 0.4) * 3.5) + Random.nextDouble(-1.5, 1.5)
                val noiseTemp = 1620 + ((sin(i.toDouble() * 0.25) * 8).toInt()) + Random.nextInt(-3, 4)
                val noiseSpeed = 1.2 + (sin(i.toDouble() * 0.3) * 0.04)
                dao.insertTelemetry(
                    TelemetrySnapshot(
                        heatNumber = 2847,
                        timestampEpoch = t,
                        eafPowerMw = (noisePower * 10.0).toInt() / 10.0,
                        eafTempC = noiseTemp,
                        lfPowerMw = 14.5,
                        lfTempC = 1595,
                        castingSpeedMpm = (noiseSpeed * 100.0).toInt() / 100.0,
                        waterFlowM3h = 3480.0 + Random.nextDouble(-40.0, 40.0),
                        waterInletC = 28.0,
                        waterOutletC = 41.2
                    )
                )
            }
        }
    }

    // --- Exposed Data Flows ---
    val allScrap: Flow<List<ScrapInventoryItem>> = dao.getAllScrap()
    val allHeats: Flow<List<HeatRecord>> = dao.getAllHeats()
    val activeHeat: Flow<HeatRecord?> = dao.getActiveHeatFlow()
    val upcomingHeats: Flow<List<HeatRecord>> = dao.getUpcomingHeatsFlow()
    val allLabSamples: Flow<List<LabSample>> = dao.getAllLabSamples()
    val allBillets: Flow<List<CastBillet>> = dao.getAllBillets()
    val allRolledBatches: Flow<List<RolledBatch>> = dao.getAllRolledBatches()
    val allBundles: Flow<List<FinishedBundle>> = dao.getAllBundles()
    val allOrders: Flow<List<CustomerOrder>> = dao.getAllOrders()
    val allEquipment: Flow<List<EquipmentUnit>> = dao.getAllEquipment()
    val auditLogs: Flow<List<AuditLogEntry>> = dao.getAuditLogs()

    fun getTelemetryForHeat(heatNumber: Int): Flow<List<TelemetrySnapshot>> {
        return dao.getRecentTelemetry(heatNumber)
    }

    fun getSamplesForHeat(heatNumber: Int): Flow<List<LabSample>> {
        return dao.getSamplesForHeat(heatNumber)
    }

    fun getBilletsForHeat(heatNumber: Int): Flow<List<CastBillet>> {
        return dao.getBilletsForHeat(heatNumber)
    }

    // --- State Toggles ---
    fun selectPlant(facility: PlantFacility) {
        _selectedPlant.value = facility
    }

    fun setConnectionStatus(status: ConnectionStatus) {
        _connectionStatus.value = status
    }

    fun toggleSimulation() {
        _simulationActive.value = !_simulationActive.value
    }

    // --- Operational Actions ---
    suspend fun tickSimulation() {
        if (!_simulationActive.value) return
        val current = dao.getActiveHeatFlow().firstOrNull() ?: return
        tickCount++

        val now = System.currentTimeMillis()
        val powerNoise = (sin(tickCount * 0.3) * 4.0) + Random.nextDouble(-2.0, 2.0)
        val newPower = (78.0 + powerNoise).coerceIn(60.0, 92.0)
        val tempNoise = ((sin(tickCount * 0.2) * 5.0).toInt()) + Random.nextInt(-2, 3)
        val newTemp = (1620 + tempNoise).coerceIn(1590, 1645)
        val speedNoise = (sin(tickCount * 0.4) * 0.05) + Random.nextDouble(-0.02, 0.02)
        val newSpeed = (1.2 + speedNoise).coerceIn(1.05, 1.35)

        // Advance casting progress if in CAST stage
        var nextProgress = current.stageProgressPct
        var nextStage = current.currentStage
        if (current.currentStage == "CAST") {
            nextProgress = (current.stageProgressPct + 1)
            if (nextProgress > 100) {
                nextProgress = 100
                nextStage = "COMPLETED"
            }
        }

        val updated = current.copy(
            activePowerMw = (newPower * 10.0).toInt() / 10.0,
            bathTempC = newTemp,
            casterLineSpeedMpm = (newSpeed * 100.0).toInt() / 100.0,
            stageProgressPct = nextProgress,
            currentStage = nextStage,
            coolingWaterFlowM3h = 3480.0 + Random.nextDouble(-25.0, 25.0)
        )
        dao.updateHeat(updated)

        // Store live telemetry snapshot
        dao.insertTelemetry(
            TelemetrySnapshot(
                heatNumber = current.heatNumber,
                timestampEpoch = now,
                eafPowerMw = updated.activePowerMw,
                eafTempC = updated.bathTempC,
                lfPowerMw = 14.2,
                lfTempC = 1595,
                castingSpeedMpm = updated.casterLineSpeedMpm,
                waterFlowM3h = updated.coolingWaterFlowM3h,
                waterInletC = 28.0,
                waterOutletC = 41.2
            )
        )
    }

    suspend fun receiveScrapWeighbridge(
        category: String,
        supplier: String,
        weightTonnes: Double,
        unitCostGbp: Double,
        locationBay: String
    ) {
        val now = System.currentTimeMillis()
        val lotId = "LOT-${category.replace(" ", "")}-${Random.nextInt(1000, 9999)}"
        val ticket = "WB-2026-${Random.nextInt(10000, 99999)}"

        val item = ScrapInventoryItem(
            id = lotId,
            category = category,
            supplier = supplier,
            availableTonnes = weightTonnes,
            reservedTonnes = 0.0,
            quarantinedTonnes = 0.0,
            unitCostGbp = unitCostGbp,
            locationBay = locationBay,
            fePct = 98.2,
            carbonPct = 0.18,
            siliconPct = 0.25,
            manganesePct = 0.60,
            phosphorusPct = 0.020,
            sulfurPct = 0.022,
            receiptTimestamp = now,
            weighbridgeTicket = ticket
        )
        dao.insertScrap(listOf(item))

        dao.insertAuditLog(
            AuditLogEntry(
                timestampEpoch = now,
                operatorName = _operatorUser.value,
                role = "WEIGHBRIDGE_OPERATOR",
                actionType = "SCRAP_RECEIPT",
                entityType = "SCRAP_LOT",
                entityId = lotId,
                changeDetails = "Received ${weightTonnes}t of $category from $supplier. Weighed at $ticket, assigned to $locationBay."
            )
        )
    }

    suspend fun reserveScrapForCharge(lotId: String, tonnesToReserve: Double) {
        val item = dao.getScrapById(lotId) ?: return
        if (item.availableTonnes >= tonnesToReserve) {
            val updated = item.copy(
                availableTonnes = item.availableTonnes - tonnesToReserve,
                reservedTonnes = item.reservedTonnes + tonnesToReserve
            )
            dao.updateScrap(updated)

            dao.insertAuditLog(
                AuditLogEntry(
                    timestampEpoch = System.currentTimeMillis(),
                    operatorName = _operatorUser.value,
                    role = "CHARGE_PLANNER",
                    actionType = "MATERIAL_RESERVE",
                    entityType = "SCRAP_LOT",
                    entityId = lotId,
                    changeDetails = "Reserved ${tonnesToReserve}t from lot $lotId for upcoming heat charge plan."
                )
            )
        }
    }

    suspend fun createNewHeat(grade: String, targetTonnes: Double): Int {
        val existing = dao.getAllHeats().firstOrNull() ?: emptyList()
        val maxHeat = existing.maxOfOrNull { it.heatNumber } ?: 2850
        val newHeatNum = maxHeat + 1
        val now = System.currentTimeMillis()

        val newHeat = HeatRecord(
            heatNumber = newHeatNum,
            plantFacility = _selectedPlant.value.label,
            grade = grade,
            targetTonnes = targetTonnes,
            actualTonnes = 0.0,
            currentStage = "CHARGE",
            stageProgressPct = 0,
            bathTempC = 25,
            activePowerMw = 0.0,
            totalEnergyMwh = 0.0,
            energyKwhPerTonne = 0.0,
            yieldPct = 96.8,
            furnaceId = "FURNACE-02",
            ladleId = "LADLE-03",
            casterLineSpeedMpm = 0.0,
            coolingWaterFlowM3h = 3200.0,
            coolingInletC = 26.0,
            coolingOutletC = 27.0,
            status = "QUEUED",
            startTimeEpoch = now,
            completedTimeEpoch = null,
            operatorName = _operatorUser.value,
            notes = "Planned heat created for grade $grade."
        )
        dao.insertHeats(listOf(newHeat))

        dao.insertAuditLog(
            AuditLogEntry(
                timestampEpoch = now,
                operatorName = _operatorUser.value,
                role = "MELT_SHOP_SUPERVISOR",
                actionType = "CREATE_HEAT",
                entityType = "HEAT",
                entityId = newHeatNum.toString(),
                changeDetails = "Heat #$newHeatNum scheduled: Grade $grade, Target ${targetTonnes}t."
            )
        )
        return newHeatNum
    }

    suspend fun advanceHeatStage(heatNumber: Int) {
        val heat = dao.getHeat(heatNumber) ?: return
        val stages = listOf("CHARGE", "MELT", "REFINE", "TAP", "CAST", "COMPLETED")
        val currentIndex = stages.indexOf(heat.currentStage)
        val nextStage = if (currentIndex in 0 until stages.size - 1) stages[currentIndex + 1] else "COMPLETED"

        val updated = when (nextStage) {
            "MELT" -> heat.copy(currentStage = nextStage, stageProgressPct = 20, bathTempC = 1520, activePowerMw = 88.0, status = "ONLINE")
            "REFINE" -> heat.copy(currentStage = nextStage, stageProgressPct = 50, bathTempC = 1600, activePowerMw = 42.0)
            "TAP" -> heat.copy(currentStage = nextStage, stageProgressPct = 85, bathTempC = 1640, activePowerMw = 0.0)
            "CAST" -> heat.copy(currentStage = nextStage, stageProgressPct = 10, bathTempC = 1620, casterLineSpeedMpm = 1.2)
            "COMPLETED" -> heat.copy(currentStage = nextStage, stageProgressPct = 100, completedTimeEpoch = System.currentTimeMillis(), status = "COMPLETED")
            else -> heat.copy(currentStage = nextStage)
        }
        dao.updateHeat(updated)

        dao.insertAuditLog(
            AuditLogEntry(
                timestampEpoch = System.currentTimeMillis(),
                operatorName = _operatorUser.value,
                role = "MELT_SHOP_OPERATOR",
                actionType = "STAGE_TRANSITION",
                entityType = "HEAT",
                entityId = heatNumber.toString(),
                changeDetails = "Heat #$heatNumber transitioned from ${heat.currentStage} to $nextStage."
            )
        )
    }

    suspend fun recordLabSample(
        heatNumber: Int,
        sampleType: String,
        carbon: Double,
        silicon: Double,
        manganese: Double,
        p: Double,
        s: Double,
        isPassed: Boolean,
        status: String,
        notes: String
    ) {
        val sampleId = "SMP-$heatNumber-${Random.nextInt(10, 99)}"
        val sample = LabSample(
            sampleId = sampleId,
            heatNumber = heatNumber,
            sampleType = sampleType,
            timestampEpoch = System.currentTimeMillis(),
            carbonPct = carbon,
            siliconPct = silicon,
            manganesePct = manganese,
            phosphorusPct = p,
            sulfurPct = s,
            chromiumPct = 0.05,
            nickelPct = 0.04,
            molybdenumPct = 0.01,
            aluminumPct = 0.025,
            cevEquivalent = (carbon + (manganese / 6.0) + ((silicon + 0.05) / 5.0) * 100.0).toInt() / 100.0,
            yieldStrengthMpa = 370.0,
            tensileStrengthMpa = 525.0,
            elongationPct = 25.0,
            charpyJoules = 42.0,
            isPassed = isPassed,
            qualityStatus = status,
            analystName = "Dr. E. Thorne",
            notes = notes
        )
        dao.insertSample(sample)

        dao.insertAuditLog(
            AuditLogEntry(
                timestampEpoch = System.currentTimeMillis(),
                operatorName = "Dr. E. Thorne",
                role = "METALLURGIST",
                actionType = "LAB_SAMPLE_LOGGED",
                entityType = "LAB_SAMPLE",
                entityId = sampleId,
                changeDetails = "Sample logged for Heat #$heatNumber: C=$carbon%, Mn=$manganese%, S=$s%. Status: $status."
            )
        )
    }

    suspend fun releaseQualityHold(sampleId: String, reason: String) {
        val sample = dao.getSampleById(sampleId) ?: return
        val updated = sample.copy(
            qualityStatus = "APPROVED",
            isPassed = true,
            notes = "${sample.notes} | Authorised Release: $reason"
        )
        dao.updateSample(updated)

        dao.insertAuditLog(
            AuditLogEntry(
                timestampEpoch = System.currentTimeMillis(),
                operatorName = "Dr. E. Thorne (Chief Metallurgist)",
                role = "CHIEF_METALLURGIST",
                actionType = "AUTHORISED_RELEASE",
                entityType = "LAB_SAMPLE",
                entityId = sampleId,
                changeDetails = "Released quality hold on $sampleId. Reason: $reason."
            )
        )
    }

    suspend fun correctOperatorEntry(
        heatNumber: Int,
        parameterName: String,
        oldVal: String,
        newVal: String,
        reason: String
    ) {
        dao.insertAuditLog(
            AuditLogEntry(
                timestampEpoch = System.currentTimeMillis(),
                operatorName = _operatorUser.value,
                role = "SHIFT_ENGINEER",
                actionType = "CORRECTED_ENTRY",
                entityType = "HEAT",
                entityId = heatNumber.toString(),
                changeDetails = "Corrected $parameterName from '$oldVal' to '$newVal'. Reason: $reason."
            )
        )
    }

    suspend fun castOutputBillets(heatNumber: Int, count: Int = 4) {
        val billets = (1..count).map { seq ->
            CastBillet(
                billetId = "BLT-$heatNumber-S${(seq % 2) + 1}-$seq",
                heatNumber = heatNumber,
                strandNumber = (seq % 2) + 1,
                sequenceNumber = seq,
                lengthMeters = 12.0,
                crossSectionMm = "200x200",
                weightTonnes = 3.76,
                surfaceQuality = "PASSED",
                internalQuality = "PASSED",
                dimensionsQuality = "PASSED",
                status = "READY_FOR_ROLLING"
            )
        }
        dao.insertBillets(billets)

        dao.insertAuditLog(
            AuditLogEntry(
                timestampEpoch = System.currentTimeMillis(),
                operatorName = _operatorUser.value,
                role = "CONTINUOUS_CASTER_OPERATOR",
                actionType = "CAST_OUTPUT",
                entityType = "HEAT",
                entityId = heatNumber.toString(),
                changeDetails = "Cast $count 200x200 12.0m billets (${count * 3.76}t total). Transferred to cooling bed."
            )
        )
    }

    suspend fun scheduleAndRollBatch(heatNumber: Int, sectionType: String): String {
        val batchId = "ROL-${Random.nextInt(7800, 9999)}"
        val rolledBatch = RolledBatch(
            batchId = batchId,
            heatNumber = heatNumber,
            sectionType = sectionType,
            piecesCount = 36,
            totalWeightTonnes = 135.4,
            rollingDateEpoch = System.currentTimeMillis(),
            yieldPct = 96.6,
            scaleLossTonnes = 1.9,
            cropLossTonnes = 2.8,
            dimensionalCompliance = true,
            status = "PASSED"
        )
        dao.insertRolledBatch(rolledBatch)

        // Automatically create inspectable bundles
        val bundles = (1..3).map { idx ->
            FinishedBundle(
                bundleId = "BND-$heatNumber-${sectionType.take(3)}-$idx",
                batchId = batchId,
                heatNumber = heatNumber,
                grade = "S355JR",
                sectionDescription = "$sectionType x 12.0m",
                weightTonnes = 4.88,
                pieces = 4,
                yardLocation = "Yard Bay 4 South",
                isQualityReleased = true,
                millCertId = "MTC-2026-EN10204-$heatNumber-0$idx",
                allocatedOrderId = null,
                status = "IN_STOCK"
            )
        }
        dao.insertBundles(bundles)

        dao.insertAuditLog(
            AuditLogEntry(
                timestampEpoch = System.currentTimeMillis(),
                operatorName = _operatorUser.value,
                role = "ROLLING_MILL_OPERATOR",
                actionType = "ROLLING_COMPLETED",
                entityType = "ROLLED_BATCH",
                entityId = batchId,
                changeDetails = "Finished rolling batch $batchId ($sectionType). Created ${bundles.size} finished bundles in Yard Bay 4 South."
            )
        )
        return batchId
    }

    suspend fun allocateOrder(orderId: String, bundleId: String): Boolean {
        val bundle = dao.getBundleById(bundleId) ?: return false
        val order = dao.getOrderById(orderId) ?: return false

        // Crucial requirement: Prevent quarantined or unreleased material from being allocated!
        if (!bundle.isQualityReleased) {
            dao.insertAuditLog(
                AuditLogEntry(
                    timestampEpoch = System.currentTimeMillis(),
                    operatorName = _operatorUser.value,
                    role = "DISPATCH_SUPERVISOR",
                    actionType = "ALLOCATION_BLOCKED",
                    entityType = "BUNDLE",
                    entityId = bundleId,
                    changeDetails = "BLOCKED: Bundle $bundleId is under Quality Hold and cannot be allocated to $orderId without supervisor clearance."
                )
            )
            return false
        }

        val updatedBundle = bundle.copy(
            allocatedOrderId = orderId,
            status = "ALLOCATED"
        )
        dao.updateBundle(updatedBundle)

        val updatedOrder = order.copy(
            allocatedTonnes = order.allocatedTonnes + bundle.weightTonnes,
            status = if (order.allocatedTonnes + bundle.weightTonnes >= order.targetTonnes) "ALLOCATED" else "OPEN"
        )
        dao.updateOrder(updatedOrder)

        dao.insertAuditLog(
            AuditLogEntry(
                timestampEpoch = System.currentTimeMillis(),
                operatorName = _operatorUser.value,
                role = "DISPATCH_SUPERVISOR",
                actionType = "ORDER_ALLOCATION",
                entityType = "ORDER",
                entityId = orderId,
                changeDetails = "Allocated bundle $bundleId (${bundle.weightTonnes}t) to Order $orderId (${order.customerName})."
            )
        )
        return true
    }

    suspend fun dispatchOrder(orderId: String) {
        val order = dao.getOrderById(orderId) ?: return
        val updatedOrder = order.copy(status = "DISPATCHED")
        dao.updateOrder(updatedOrder)

        dao.insertAuditLog(
            AuditLogEntry(
                timestampEpoch = System.currentTimeMillis(),
                operatorName = _operatorUser.value,
                role = "DISPATCH_SUPERVISOR",
                actionType = "DISPATCH_WEIGHBRIDGE_EXIT",
                entityType = "ORDER",
                entityId = orderId,
                changeDetails = "Order $orderId dispatched via Weighbridge Exit Gate. Gross weight reconciled with carrier delivery note."
            )
        )
    }

    suspend fun simulateEquipmentDowntime(equipmentId: String, cause: String) {
        val all = dao.getAllEquipment().firstOrNull() ?: return
        val unit = all.find { it.id == equipmentId } ?: return
        val newStatus = if (unit.status == "ONLINE" || unit.status == "RUNNING") "MAINTENANCE" else "ONLINE"
        val updated = unit.copy(status = newStatus, activeAlarms = if (newStatus == "MAINTENANCE") "ALARM: $cause" else "Normal operation restored")
        dao.updateEquipment(updated)

        dao.insertAuditLog(
            AuditLogEntry(
                timestampEpoch = System.currentTimeMillis(),
                operatorName = _operatorUser.value,
                role = "MAINTENANCE_LEAD",
                actionType = "EQUIPMENT_STATUS_CHANGE",
                entityType = "EQUIPMENT",
                entityId = equipmentId,
                changeDetails = "Unit $equipmentId switched to $newStatus. Reason: $cause"
            )
        )
    }
}
