package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.entities.EquipmentUnit
import com.example.ui.theme.*

@Composable
fun MaintenanceScreen(
    equipmentList: List<EquipmentUnit>,
    onToggleDowntime: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .background(SheffieldBackground)
            .padding(16.dp)
            .testTag("maintenance_screen"),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "PLANT ASSET REGISTER & PREDICTIVE MAINTENANCE",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = SheffieldIvory
                )
                Text(
                    text = "Vibration telemetry · Thermal imaging anomalies · Work orders · Shift handover logs",
                    style = MaterialTheme.typography.bodySmall,
                    color = SheffieldIvoryMuted
                )
            }

            Text(
                text = "SHIFT AVAILABILITY: 98.2%",
                fontFamily = FontFamily.Monospace,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = SignalGreen
            )
        }

        // Equipment List
        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            items(equipmentList) { unit ->
                val isOnline = unit.status == "ONLINE" || unit.status == "RUNNING"
                val statusColor = if (isOnline) SignalGreen else DangerRed

                Surface(
                    color = SheffieldCard,
                    shape = RoundedCornerShape(4.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, if (isOnline) SheffieldBorder else DangerRed),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = unit.id,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold,
                                    color = MoltenGold
                                )
                                Spacer(modifier = Modifier.width(10.dp))
                                Text(
                                    text = unit.name,
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.SemiBold,
                                    color = SheffieldIvory
                                )
                            }

                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .background(if (isOnline) SignalGreenSurface else DangerRedSurface, RoundedCornerShape(12.dp))
                                        .border(1.dp, statusColor, RoundedCornerShape(12.dp))
                                        .padding(horizontal = 8.dp, vertical = 2.dp)
                                ) {
                                    Text(unit.status, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = statusColor)
                                }

                                Spacer(modifier = Modifier.width(10.dp))

                                OutlinedButton(
                                    onClick = { onToggleDowntime(unit.id) },
                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                    shape = RoundedCornerShape(4.dp)
                                ) {
                                    Icon(Icons.Default.Build, contentDescription = null, modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(if (isOnline) "SIMULATE DOWNTIME" else "RESTORE ONLINE", style = MaterialTheme.typography.labelSmall)
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Row(
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Area: ${unit.area}", style = MaterialTheme.typography.bodySmall, color = SheffieldIvoryMuted)
                            Text("Power Rating: ${unit.activePowerRatingMw} MW", style = MaterialTheme.typography.bodySmall, color = SheffieldIvoryMuted)
                            Text("Operating: ${unit.operatingHours} hrs", fontFamily = FontFamily.Monospace, fontSize = 12.sp, color = SheffieldIvory)
                            Text("Next Inspection: ${unit.nextServiceHours} hrs", fontFamily = FontFamily.Monospace, fontSize = 12.sp, color = MoltenGold)
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        // Alarms / Anomaly banner
                        Surface(
                            color = SheffieldSurface,
                            shape = RoundedCornerShape(4.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.padding(8.dp)
                            ) {
                                Icon(
                                    imageVector = if (isOnline) Icons.Default.Build else Icons.Default.Warning,
                                    contentDescription = null,
                                    tint = if (isOnline) SheffieldIvoryDim else DangerRed,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = unit.activeAlarms,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = if (isOnline) SheffieldIvoryMuted else DangerRed
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
