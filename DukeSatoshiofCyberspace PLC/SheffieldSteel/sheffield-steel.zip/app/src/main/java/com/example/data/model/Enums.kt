package com.example.data.model

enum class PlantFacility(val label: String, val locationName: String) {
    SHEFFIELD_DON_WORKS("Sheffield River Don Works", "Melt Shop 02 & Continuous Caster"),
    MEADOWHALL_ROLLING("Meadowhall Rolling Mill", "Heavy Section & Bar Mill"),
    STOCKSBRIDGE_ALLOY("Stocksbridge Special Steels", "Vacuum Arc & Alloy Melting")
}

enum class HeatStage(val label: String, val sequence: Int) {
    CHARGE("CHARGE", 1),
    MELT("MELT", 2),
    REFINE("REFINE", 3),
    TAP("TAP", 4),
    CAST("CAST", 5),
    ROLL("ROLL", 6),
    COMPLETED("COMPLETED", 7),
    ABORTED("ABORTED", 0)
}

enum class SteelGrade(
    val code: String,
    val description: String,
    val targetCarbon: Double,
    val targetSilicon: Double,
    val targetManganese: Double,
    val maxPhosphorus: Double,
    val maxSulfur: Double,
    val minYieldStrengthMpa: Double,
    val minTensileStrengthMpa: Double
) {
    S355JR("S355JR", "Structural Hot-Rolled Carbon-Manganese Steel", 0.18, 0.35, 1.45, 0.035, 0.035, 355.0, 510.0),
    S275JR("S275JR", "General Purpose Structural Weldable Steel", 0.16, 0.25, 1.20, 0.040, 0.040, 275.0, 430.0),
    S355J2("S355J2", "Low Temperature Toughness (-20°C 27J) Structural Steel", 0.17, 0.30, 1.40, 0.030, 0.025, 355.0, 520.0),
    AISI_1045("1045", "Medium Carbon Engineering Axle & Shaft Steel", 0.45, 0.25, 0.75, 0.030, 0.035, 310.0, 570.0),
    GRADE_316L("316L", "Molybdenum-Alloyed Corrosion Resistant Austenitic", 0.03, 0.75, 1.80, 0.040, 0.020, 220.0, 520.0),
    AISI_4140("4140", "Chromium-Molybdenum High-Strength Quench & Temper", 0.40, 0.25, 0.85, 0.035, 0.035, 650.0, 950.0)
}

enum class ConnectionStatus(val label: String) {
    CONNECTED("LIVE OPERATIONS"),
    SIMULATED("SIMULATED TELEMETRY"),
    CACHED("CACHED RECORDS"),
    STALE("STALE CONNECTION")
}

enum class QualityStatus(val label: String) {
    PENDING("ANALYSIS IN PROGRESS"),
    APPROVED("APPROVED / RELEASED"),
    REJECTED("REJECTED"),
    QUARANTINE_HOLD("QUALITY HOLD")
}

enum class EquipmentStatus(val label: String) {
    RUNNING("RUNNING"),
    ONLINE("ONLINE"),
    STANDBY("STANDBY"),
    MAINTENANCE("MAINTENANCE"),
    FAULT("FAULT / ALARM")
}

enum class ScrapCategory(val code: String, val label: String, val typicalFe: Double) {
    HMS_1("HMS-1", "Heavy Melting Steel #1 (>6mm)", 98.2),
    HMS_2("HMS-2", "Heavy Melting Steel #2 (<6mm)", 96.5),
    SHREDDED("SHRED", "Shredded Auto Scrap", 95.8),
    PLATE_STRUCTURAL("P&S", "Clean Plate & Structural Cut-offs", 99.1),
    DRI("DRI", "Direct Reduced Iron Pellets", 94.0),
    TURNINGS("TURNING", "Steel Borings & Turnings", 92.5)
}
