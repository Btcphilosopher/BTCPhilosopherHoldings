package com.example.data.local.entities

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "scrap_inventory")
data class ScrapInventoryItem(
    @PrimaryKey val id: String,
    val category: String,
    val supplier: String,
    val availableTonnes: Double,
    val reservedTonnes: Double,
    val quarantinedTonnes: Double,
    val unitCostGbp: Double,
    val locationBay: String,
    val fePct: Double,
    val carbonPct: Double,
    val siliconPct: Double,
    val manganesePct: Double,
    val phosphorusPct: Double,
    val sulfurPct: Double,
    val receiptTimestamp: Long,
    val weighbridgeTicket: String
)

@Entity(tableName = "heats")
data class HeatRecord(
    @PrimaryKey val heatNumber: Int,
    val plantFacility: String,
    val grade: String,
    val targetTonnes: Double,
    val actualTonnes: Double,
    val currentStage: String,
    val stageProgressPct: Int,
    val bathTempC: Int,
    val activePowerMw: Double,
    val totalEnergyMwh: Double,
    val energyKwhPerTonne: Double,
    val yieldPct: Double,
    val furnaceId: String,
    val ladleId: String,
    val casterLineSpeedMpm: Double,
    val coolingWaterFlowM3h: Double,
    val coolingInletC: Double,
    val coolingOutletC: Double,
    val status: String, // "ONLINE", "ACTIVE", "QUEUED", "COMPLETED"
    val startTimeEpoch: Long,
    val completedTimeEpoch: Long?,
    val operatorName: String,
    val notes: String
)

@Entity(tableName = "telemetry_snapshots")
data class TelemetrySnapshot(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val heatNumber: Int,
    val timestampEpoch: Long,
    val eafPowerMw: Double,
    val eafTempC: Int,
    val lfPowerMw: Double,
    val lfTempC: Int,
    val castingSpeedMpm: Double,
    val waterFlowM3h: Double,
    val waterInletC: Double,
    val waterOutletC: Double
)

@Entity(tableName = "lab_samples")
data class LabSample(
    @PrimaryKey val sampleId: String,
    val heatNumber: Int,
    val sampleType: String, // "EAF_BATH", "LF_FINAL", "TUNDISH", "ROLLED_MECHANICAL"
    val timestampEpoch: Long,
    val carbonPct: Double,
    val siliconPct: Double,
    val manganesePct: Double,
    val phosphorusPct: Double,
    val sulfurPct: Double,
    val chromiumPct: Double,
    val nickelPct: Double,
    val molybdenumPct: Double,
    val aluminumPct: Double,
    val cevEquivalent: Double,
    val yieldStrengthMpa: Double?,
    val tensileStrengthMpa: Double?,
    val elongationPct: Double?,
    val charpyJoules: Double?,
    val isPassed: Boolean,
    val qualityStatus: String, // "APPROVED", "QUARANTINE_HOLD", "REJECTED"
    val analystName: String,
    val notes: String
)

@Entity(tableName = "cast_billets")
data class CastBillet(
    @PrimaryKey val billetId: String,
    val heatNumber: Int,
    val strandNumber: Int,
    val sequenceNumber: Int,
    val lengthMeters: Double,
    val crossSectionMm: String,
    val weightTonnes: Double,
    val surfaceQuality: String,
    val internalQuality: String,
    val dimensionsQuality: String,
    val status: String // "COOLING", "READY_FOR_ROLLING", "ROLLED", "SCRAPPED"
)

@Entity(tableName = "rolled_batches")
data class RolledBatch(
    @PrimaryKey val batchId: String,
    val heatNumber: Int,
    val sectionType: String,
    val piecesCount: Int,
    val totalWeightTonnes: Double,
    val rollingDateEpoch: Long,
    val yieldPct: Double,
    val scaleLossTonnes: Double,
    val cropLossTonnes: Double,
    val dimensionalCompliance: Boolean,
    val status: String // "PASSED", "REWORK"
)

@Entity(tableName = "finished_bundles")
data class FinishedBundle(
    @PrimaryKey val bundleId: String,
    val batchId: String,
    val heatNumber: Int,
    val grade: String,
    val sectionDescription: String,
    val weightTonnes: Double,
    val pieces: Int,
    val yardLocation: String,
    val isQualityReleased: Boolean,
    val millCertId: String?,
    val allocatedOrderId: String?,
    val status: String // "IN_STOCK", "ALLOCATED", "DISPATCHED"
)

@Entity(tableName = "customer_orders")
data class CustomerOrder(
    @PrimaryKey val orderId: String,
    val customerName: String,
    val destination: String,
    val grade: String,
    val section: String,
    val targetTonnes: Double,
    val allocatedTonnes: Double,
    val status: String, // "OPEN", "ALLOCATED", "DISPATCHED"
    val targetDeliveryEpoch: Long
)

@Entity(tableName = "equipment_units")
data class EquipmentUnit(
    @PrimaryKey val id: String,
    val name: String,
    val area: String,
    val status: String,
    val availabilityPct: Double,
    val activePowerRatingMw: Double,
    val operatingHours: Int,
    val nextServiceHours: Int,
    val activeAlarms: String
)

@Entity(tableName = "audit_logs")
data class AuditLogEntry(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val timestampEpoch: Long,
    val operatorName: String,
    val role: String,
    val actionType: String,
    val entityType: String,
    val entityId: String,
    val changeDetails: String
)
