package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val SheffieldDarkColorScheme = darkColorScheme(
    primary = MoltenOrange,
    onPrimary = Color(0xFF0F0A05),
    primaryContainer = Color(0xFF4A1E05),
    onPrimaryContainer = MoltenWhiteHot,
    secondary = MoltenGold,
    onSecondary = Color(0xFF1E1400),
    secondaryContainer = Color(0xFF3E2D00),
    onSecondaryContainer = Color(0xFFFFE082),
    tertiary = ElectricArcBlue,
    onTertiary = Color(0xFF001F2B),
    background = SheffieldBackground,
    onBackground = SheffieldIvory,
    surface = SheffieldSurface,
    onSurface = SheffieldIvory,
    surfaceVariant = SheffieldCard,
    onSurfaceVariant = SheffieldIvoryMuted,
    outline = SheffieldBorder,
    outlineVariant = SheffieldBorderSubtle,
    error = DangerRed,
    onError = Color.White
)

@Composable
fun SheffieldSteelTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = SheffieldDarkColorScheme,
        typography = Typography,
        content = content
    )
}

// Backwards compatibility alias
@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true,
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    SheffieldSteelTheme(content = content)
}
