package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.entities.CustomerOrder
import com.example.data.local.entities.FinishedBundle
import com.example.ui.theme.*

@Composable
fun DispatchScreen(
    orders: List<CustomerOrder>,
    bundles: List<FinishedBundle>,
    onAllocateBundle: (orderId: String, bundleId: String) -> Unit,
    onDispatchOrder: (orderId: String) -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedOrderForAllocation by remember { mutableStateOf<CustomerOrder?>(null) }
    var selectedBundleToAllocate by remember { mutableStateOf<FinishedBundle?>(null) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(SheffieldBackground)
            .padding(16.dp)
            .testTag("dispatch_screen"),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Top Toolbar
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "FINISHED GOODS DISPATCH & WEIGHBRIDGE OUT-GATE",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = SheffieldIvory
                )
                Text(
                    text = "Customer contract order allocation · Automated QA release check · Outbound carrier delivery notes",
                    style = MaterialTheme.typography.bodySmall,
                    color = SheffieldIvoryMuted
                )
            }
        }

        // 2 Panes: Left = Customer Orders · Right = Finished Bundles in Yard
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f),
            horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // LEFT: CUSTOMER ORDERS
            Surface(
                color = SheffieldCard,
                shape = RoundedCornerShape(4.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, SheffieldBorder),
                modifier = Modifier
                    .weight(0.5f)
                    .fillMaxHeight()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "CUSTOMER CONTRACT ORDERS",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = SheffieldIvory
                    )
                    Spacer(modifier = Modifier.height(10.dp))

                    LazyColumn(
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxSize()
                    ) {
                        items(orders) { order ->
                            val isDispatched = order.status == "DISPATCHED"
                            val isFullAllocated = order.allocatedTonnes >= order.targetTonnes

                            Surface(
                                color = SheffieldSurface,
                                shape = RoundedCornerShape(4.dp),
                                border = androidx.compose.foundation.BorderStroke(1.dp, if (isDispatched) SignalGreen else SheffieldBorderSubtle),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Row(
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Text(order.orderId, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, color = MoltenGold)
                                        Text(
                                            text = order.status,
                                            style = MaterialTheme.typography.labelSmall,
                                            fontWeight = FontWeight.Bold,
                                            color = if (isDispatched) SignalGreen else if (isFullAllocated) MoltenOrange else WarningAmber
                                        )
                                    }
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(order.customerName, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold, color = SheffieldIvory)
                                    Text("Destination: ${order.destination}", style = MaterialTheme.typography.bodySmall, color = SheffieldIvoryMuted)
                                    Spacer(modifier = Modifier.height(6.dp))

                                    Row(
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Text("${order.grade} · ${order.section}", style = MaterialTheme.typography.bodySmall, color = SheffieldIvory)
                                        Text(
                                            "${order.allocatedTonnes} / ${order.targetTonnes} t",
                                            fontFamily = FontFamily.Monospace,
                                            fontWeight = FontWeight.Bold,
                                            color = if (isFullAllocated) SignalGreen else MoltenOrange
                                        )
                                    }

                                    if (!isDispatched) {
                                        Spacer(modifier = Modifier.height(10.dp))
                                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                            OutlinedButton(
                                                onClick = { selectedOrderForAllocation = order },
                                                modifier = Modifier.weight(1f),
                                                shape = RoundedCornerShape(2.dp),
                                                contentPadding = PaddingValues(0.dp)
                                            ) {
                                                Text("ALLOCATE BUNDLE", style = MaterialTheme.typography.labelSmall, color = MoltenOrange)
                                            }

                                            Button(
                                                onClick = { onDispatchOrder(order.orderId) },
                                                modifier = Modifier.weight(1f),
                                                shape = RoundedCornerShape(2.dp),
                                                colors = ButtonDefaults.buttonColors(containerColor = SignalGreen, contentColor = Color.Black),
                                                contentPadding = PaddingValues(0.dp)
                                            ) {
                                                Text("DISPATCH WEIGHBRIDGE", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // RIGHT: FINISHED BUNDLES IN YARD
            Surface(
                color = SheffieldCard,
                shape = RoundedCornerShape(4.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, SheffieldBorder),
                modifier = Modifier
                    .weight(0.5f)
                    .fillMaxHeight()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "FINISHED STOCK IN YARD (QUALITY CHECK ENFORCED)",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = SheffieldIvory
                    )
                    Spacer(modifier = Modifier.height(10.dp))

                    LazyColumn(
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxSize()
                    ) {
                        items(bundles) { bundle ->
                            val canAllocate = bundle.isQualityReleased && bundle.status == "IN_STOCK"

                            Surface(
                                color = SheffieldSurface,
                                shape = RoundedCornerShape(4.dp),
                                border = androidx.compose.foundation.BorderStroke(
                                    1.dp,
                                    if (bundle.isQualityReleased) SignalGreen.copy(alpha = 0.5f) else DangerRed
                                ),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(10.dp)) {
                                    Row(
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Text(bundle.bundleId, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, color = MoltenGold)
                                        Text(
                                            text = if (bundle.isQualityReleased) "QA RELEASED" else "HOLD (NO DISPATCH)",
                                            style = MaterialTheme.typography.labelSmall,
                                            fontWeight = FontWeight.Bold,
                                            color = if (bundle.isQualityReleased) SignalGreen else DangerRed
                                        )
                                    }
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(bundle.sectionDescription, style = MaterialTheme.typography.bodyMedium, color = SheffieldIvory)
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Row(
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Text("Weight: ${bundle.weightTonnes} t", fontFamily = FontFamily.Monospace, color = SheffieldIvory)
                                        Text("Location: ${bundle.yardLocation}", style = MaterialTheme.typography.bodySmall, color = ElectricArcBlue)
                                        Text("Status: ${bundle.status}", style = MaterialTheme.typography.bodySmall, color = SheffieldIvoryDim)
                                    }
                                    if (bundle.allocatedOrderId != null) {
                                        Text("Allocated to: ${bundle.allocatedOrderId}", style = MaterialTheme.typography.bodySmall, color = MoltenGold)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Allocate Bundle Dialog
    if (selectedOrderForAllocation != null) {
        val ord = selectedOrderForAllocation!!
        val availableBundles = bundles.filter { it.status == "IN_STOCK" }

        AlertDialog(
            onDismissRequest = { selectedOrderForAllocation = null },
            title = { Text("Allocate Bundle to Order ${ord.orderId}", color = SheffieldIvory) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Select a bundle from finished yard inventory. Quarantined stock will be blocked by QA policy.", style = MaterialTheme.typography.bodySmall, color = SheffieldIvoryMuted)
                    LazyColumn(modifier = Modifier.height(200.dp)) {
                        items(availableBundles) { b ->
                            Surface(
                                color = SheffieldSurface,
                                shape = RoundedCornerShape(4.dp),
                                border = androidx.compose.foundation.BorderStroke(1.dp, if (b.isQualityReleased) SignalGreen else DangerRed),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp)
                                    .clickable {
                                        onAllocateBundle(ord.orderId, b.bundleId)
                                        selectedOrderForAllocation = null
                                    }
                            ) {
                                Row(
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    modifier = Modifier.padding(8.dp)
                                ) {
                                    Column {
                                        Text(b.bundleId, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, color = MoltenGold)
                                        Text("${b.sectionDescription} · ${b.weightTonnes} t", style = MaterialTheme.typography.bodySmall, color = SheffieldIvory)
                                    }
                                    Text(if (b.isQualityReleased) "READY" else "QA HOLD", color = if (b.isQualityReleased) SignalGreen else DangerRed, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {},
            dismissButton = {
                TextButton(onClick = { selectedOrderForAllocation = null }) { Text("CANCEL") }
            }
        )
    }
}
