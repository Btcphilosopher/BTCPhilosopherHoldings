package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.entities.FinishedBundle
import com.example.data.local.entities.RolledBatch
import com.example.ui.theme.*

@Composable
fun RollingScreen(
    rolledBatches: List<RolledBatch>,
    finishedBundles: List<FinishedBundle>,
    onRollBatch: (heatNum: Int, section: String) -> Unit,
    modifier: Modifier = Modifier
) {
    var showScheduleDialog by remember { mutableStateOf(false) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(SheffieldBackground)
            .padding(16.dp)
            .testTag("rolling_screen"),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Top Bar
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "ROLLING & FINISHING MILL (MEADOWHALL HEAVY SECTION LINE)",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = SheffieldIvory
                )
                Text(
                    text = "Walking beam reheat furnace (1,180°C) · Reversible breakdown stand · Universal beam mill",
                    style = MaterialTheme.typography.bodySmall,
                    color = SheffieldIvoryMuted
                )
            }

            Button(
                onClick = { showScheduleDialog = true },
                colors = ButtonDefaults.buttonColors(containerColor = MoltenOrange, contentColor = Color(0xFF0F0A05)),
                shape = RoundedCornerShape(4.dp),
                modifier = Modifier.testTag("schedule_rolling_button")
            ) {
                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("SCHEDULE & ROLL BATCH", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
            }
        }

        // Mill KPI Row
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            MillKPI("REHEAT FURNACE", "1,180 °C", "Soaking Zone Uniformity ±8°C", MoltenGold, Modifier.weight(1f))
            MillKPI("FINISHED YIELD", "96.5%", "Scale Loss 1.4% · Crop Loss 2.1%", SignalGreen, Modifier.weight(1f))
            MillKPI("STAND 4 LOAD", "1,840 kN", "Rolling force within envelope", SheffieldIvory, Modifier.weight(1f))
            MillKPI("LINE SPEED", "6.4 m/s", "Finishing block exit velocity", ElectricArcBlue, Modifier.weight(1f))
        }

        // Rolled Batches & Finished Bundles Split View
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f),
            horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Left: Rolled Batches
            Surface(
                color = SheffieldCard,
                shape = RoundedCornerShape(4.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, SheffieldBorder),
                modifier = Modifier
                    .weight(0.5f)
                    .fillMaxHeight()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "ROLLED PRODUCTION BATCHES",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = SheffieldIvory
                    )
                    Spacer(modifier = Modifier.height(10.dp))

                    LazyColumn(
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxSize()
                    ) {
                        items(rolledBatches) { batch ->
                            Surface(
                                color = SheffieldSurface,
                                shape = RoundedCornerShape(4.dp),
                                border = androidx.compose.foundation.BorderStroke(1.dp, SheffieldBorderSubtle),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(10.dp)) {
                                    Row(
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Text(batch.batchId, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, color = MoltenGold)
                                        Text("Heat #${batch.heatNumber}", fontFamily = FontFamily.Monospace, color = SheffieldIvoryMuted)
                                    }
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(batch.sectionType, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold, color = SheffieldIvory)
                                    Spacer(modifier = Modifier.height(6.dp))
                                    Row(
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Text("Weight: ${batch.totalWeightTonnes} t", fontFamily = FontFamily.Monospace, fontSize = 12.sp, color = SheffieldIvory)
                                        Text("Yield: ${batch.yieldPct}%", fontFamily = FontFamily.Monospace, fontSize = 12.sp, color = SignalGreen)
                                        Text("Pieces: ${batch.piecesCount}", fontFamily = FontFamily.Monospace, fontSize = 12.sp, color = SheffieldIvoryMuted)
                                    }
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = "Scale loss: ${batch.scaleLossTonnes}t · Cropping loss: ${batch.cropLossTonnes}t",
                                        style = MaterialTheme.typography.bodySmall,
                                        fontSize = 11.sp,
                                        color = SheffieldIvoryDim
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Right: Finished Bundles Produced
            Surface(
                color = SheffieldCard,
                shape = RoundedCornerShape(4.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, SheffieldBorder),
                modifier = Modifier
                    .weight(0.5f)
                    .fillMaxHeight()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "FINISHED BUNDLES & STRAPPING YARD",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = SheffieldIvory
                    )
                    Spacer(modifier = Modifier.height(10.dp))

                    LazyColumn(
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxSize()
                    ) {
                        items(finishedBundles) { bundle ->
                            val isAllocated = bundle.allocatedOrderId != null

                            Surface(
                                color = SheffieldSurface,
                                shape = RoundedCornerShape(4.dp),
                                border = androidx.compose.foundation.BorderStroke(1.dp, if (bundle.isQualityReleased) SignalGreen.copy(alpha = 0.5f) else DangerRed.copy(alpha = 0.8f)),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(10.dp)) {
                                    Row(
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Text(bundle.bundleId, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, color = MoltenGold)
                                        Text(bundle.yardLocation, style = MaterialTheme.typography.labelSmall, color = ElectricArcBlue)
                                    }
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(bundle.sectionDescription, style = MaterialTheme.typography.bodyMedium, color = SheffieldIvory)
                                    Spacer(modifier = Modifier.height(6.dp))
                                    Row(
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Text("${bundle.weightTonnes} t (${bundle.pieces} pcs)", fontFamily = FontFamily.Monospace, fontSize = 12.sp, color = SheffieldIvory)
                                        Text(
                                            text = if (bundle.isQualityReleased) "QA RELEASED" else "QA HOLD",
                                            style = MaterialTheme.typography.labelSmall,
                                            fontWeight = FontWeight.Bold,
                                            color = if (bundle.isQualityReleased) SignalGreen else DangerRed
                                        )
                                        Text(
                                            text = bundle.status,
                                            style = MaterialTheme.typography.labelSmall,
                                            fontWeight = FontWeight.Bold,
                                            color = if (isAllocated) MoltenOrange else SignalGreen
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Schedule Rolling Dialog
    if (showScheduleDialog) {
        var heatNumberStr by remember { mutableStateOf("2847") }
        var sectionType by remember { mutableStateOf("HEB 300 Universal Beam") }

        AlertDialog(
            onDismissRequest = { showScheduleDialog = false },
            title = { Text("Schedule Rolling Mill Run", color = SheffieldIvory) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = heatNumberStr, onValueChange = { heatNumberStr = it }, label = { Text("Heat Number") })
                    OutlinedTextField(value = sectionType, onValueChange = { sectionType = it }, label = { Text("Target Rolled Section") })
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val hn = heatNumberStr.toIntOrNull() ?: 2847
                        onRollBatch(hn, sectionType)
                        showScheduleDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MoltenOrange)
                ) {
                    Text("START ROLLING RUN")
                }
            },
            dismissButton = {
                TextButton(onClick = { showScheduleDialog = false }) { Text("CANCEL") }
            }
        )
    }
}

@Composable
private fun MillKPI(label: String, value: String, sublabel: String, color: Color, modifier: Modifier = Modifier) {
    Surface(
        color = SheffieldCard,
        shape = RoundedCornerShape(4.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, SheffieldBorder),
        modifier = modifier
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text(label, style = MaterialTheme.typography.labelSmall, color = SheffieldIvoryDim)
            Spacer(modifier = Modifier.height(4.dp))
            Text(value, fontFamily = FontFamily.Monospace, fontSize = 22.sp, fontWeight = FontWeight.Black, color = color)
            Spacer(modifier = Modifier.height(2.dp))
            Text(sublabel, style = MaterialTheme.typography.bodySmall, fontSize = 10.sp, color = SheffieldIvoryMuted)
        }
    }
}
