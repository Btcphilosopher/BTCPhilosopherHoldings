package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.entities.HeatRecord
import com.example.data.local.entities.TelemetrySnapshot
import com.example.ui.components.AnimatedSteelworksProcessView
import com.example.ui.components.ProductionTimeline
import com.example.ui.components.TechnicalLineChart
import com.example.ui.theme.*

@Composable
fun OverviewScreen(
    activeHeat: HeatRecord?,
    upcomingHeats: List<HeatRecord>,
    telemetryHistory: List<TelemetrySnapshot>,
    isSimulationRunning: Boolean,
    onAdvanceStage: () -> Unit,
    modifier: Modifier = Modifier
) {
    val bathTemp = activeHeat?.bathTempC ?: 1620
    val activePower = activeHeat?.activePowerMw ?: 78.0
    val heatNumber = activeHeat?.heatNumber ?: 2847
    val grade = activeHeat?.grade ?: "S355JR"
    val targetTonnes = activeHeat?.targetTonnes ?: 240.0
    val lineSpeed = activeHeat?.casterLineSpeedMpm ?: 1.2
    val waterFlow = activeHeat?.coolingWaterFlowM3h ?: 3480.0
    val waterInlet = activeHeat?.coolingInletC ?: 28.0
    val waterOutlet = activeHeat?.coolingOutletC ?: 41.0

    val powerPoints = if (telemetryHistory.isNotEmpty()) {
        telemetryHistory.map { it.eafPowerMw }
    } else {
        listOf(74.0, 78.0, 82.0, 79.0, 76.0, 80.0, 78.0)
    }

    val tempPoints = if (telemetryHistory.isNotEmpty()) {
        telemetryHistory.map { it.eafTempC.toDouble() }
    } else {
        listOf(1580.0, 1600.0, 1610.0, 1618.0, 1622.0, 1620.0)
    }

    val speedPoints = if (telemetryHistory.isNotEmpty()) {
        telemetryHistory.map { it.castingSpeedMpm }
    } else {
        listOf(1.18, 1.22, 1.19, 1.21, 1.20, 1.22)
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(SheffieldBackground)
            .padding(14.dp)
            .verticalScroll(rememberScrollState())
            .testTag("overview_screen"),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // TOP MAIN GRID (Furnace 02 Left · Process 3D View & Charts Center · Continuous Casting Right)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(IntrinsicSize.Min),
            horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // LEFT PANEL: FURNACE 02 METRICS
            Surface(
                color = SheffieldCard,
                shape = RoundedCornerShape(4.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, SheffieldBorder),
                modifier = Modifier
                    .weight(0.25f)
                    .fillMaxHeight()
                    .testTag("furnace_metrics_panel")
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(14.dp),
                    verticalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        // Header with status pill
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = "FURNACE 02",
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.Bold,
                                color = SheffieldIvory,
                                letterSpacing = 1.0.sp
                            )

                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(SignalGreenSurface)
                                    .border(1.dp, SignalGreen, RoundedCornerShape(12.dp))
                                    .padding(horizontal = 8.dp, vertical = 2.dp)
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(
                                        modifier = Modifier
                                            .size(6.dp)
                                            .clip(RoundedCornerShape(3.dp))
                                            .background(SignalGreen)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = "ONLINE",
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = FontWeight.Bold,
                                        color = SignalGreen
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        // Large Monospaced Bath Temperature
                        Text(
                            text = "${String.format("%,d", bathTemp)} °C",
                            fontFamily = FontFamily.Monospace,
                            fontSize = 38.sp,
                            fontWeight = FontWeight.Black,
                            color = MoltenGold,
                            letterSpacing = (-1).sp
                        )
                        Text(
                            text = "BATH TEMPERATURE",
                            style = MaterialTheme.typography.labelSmall,
                            color = SheffieldIvoryDim,
                            letterSpacing = 1.0.sp
                        )

                        Spacer(modifier = Modifier.height(18.dp))

                        // Large Active Power
                        Text(
                            text = "${activePower.toInt()} MW",
                            fontFamily = FontFamily.Monospace,
                            fontSize = 38.sp,
                            fontWeight = FontWeight.Black,
                            color = MoltenOrange,
                            letterSpacing = (-1).sp
                        )
                        Text(
                            text = "ACTIVE POWER",
                            style = MaterialTheme.typography.labelSmall,
                            color = SheffieldIvoryDim,
                            letterSpacing = 1.0.sp
                        )

                        Spacer(modifier = Modifier.height(18.dp))

                        // Heat Number
                        Text(
                            text = "$heatNumber",
                            fontFamily = FontFamily.Monospace,
                            fontSize = 38.sp,
                            fontWeight = FontWeight.Black,
                            color = SheffieldIvory,
                            letterSpacing = (-1).sp
                        )
                        Text(
                            text = "HEAT",
                            style = MaterialTheme.typography.labelSmall,
                            color = SheffieldIvoryDim,
                            letterSpacing = 1.0.sp
                        )
                    }

                    // Bottom Grade & Target Bar
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(SheffieldSurface, RoundedCornerShape(4.dp))
                            .padding(8.dp)
                    ) {
                        Row(
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("GRADE", style = MaterialTheme.typography.labelSmall, color = SheffieldIvoryDim)
                            Text(grade, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = SheffieldIvory)
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("TARGET", style = MaterialTheme.typography.labelSmall, color = SheffieldIvoryDim)
                            Text("${targetTonnes.toInt()} t", fontFamily = FontFamily.Monospace, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = SheffieldIvory)
                        }
                    }
                }
            }

            // CENTER PANEL: ANIMATED PROCESS VIEW + 3 CHARTS
            Column(
                modifier = Modifier
                    .weight(0.50f)
                    .fillMaxHeight(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Central Animated Steelworks Visual (EAF · LF · CCM)
                AnimatedSteelworksProcessView(
                    heat = activeHeat,
                    isSimulationRunning = isSimulationRunning,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(260.dp)
                )

                // 3 Waveform Line Charts Underneath (Power, Temp, Speed)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    TechnicalLineChart(
                        title = "FURNACE POWER (MW)",
                        dataPoints = powerPoints,
                        minY = 0.0,
                        maxY = 100.0,
                        lineColor = MoltenOrange,
                        yUnit = "MW",
                        modifier = Modifier.weight(1f)
                    )

                    TechnicalLineChart(
                        title = "BATH TEMPERATURE (°C)",
                        dataPoints = tempPoints,
                        minY = 1560.0,
                        maxY = 1650.0,
                        lineColor = SignalGreen,
                        yUnit = "°C",
                        modifier = Modifier.weight(1f)
                    )

                    TechnicalLineChart(
                        title = "CASTING SPEED (m/min)",
                        dataPoints = speedPoints,
                        minY = 1.0,
                        maxY = 1.4,
                        lineColor = MoltenGold,
                        yUnit = "m/min",
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            // RIGHT PANEL: CONTINUOUS CASTING & AUXILIARY TELEMETRY
            Surface(
                color = SheffieldCard,
                shape = RoundedCornerShape(4.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, SheffieldBorder),
                modifier = Modifier
                    .weight(0.25f)
                    .fillMaxHeight()
                    .testTag("casting_metrics_panel")
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(14.dp),
                    verticalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        // Header with status pill
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = "CONTINUOUS CASTING",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = SheffieldIvory,
                                letterSpacing = 0.5.sp
                            )

                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(SignalGreenSurface)
                                    .border(1.dp, SignalGreen, RoundedCornerShape(12.dp))
                                    .padding(horizontal = 8.dp, vertical = 2.dp)
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(
                                        modifier = Modifier
                                            .size(6.dp)
                                            .clip(RoundedCornerShape(3.dp))
                                            .background(SignalGreen)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = "RUNNING",
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = FontWeight.Bold,
                                        color = SignalGreen
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        // Large Line Speed
                        Text(
                            text = "${String.format("%.1f", lineSpeed)} m/min",
                            fontFamily = FontFamily.Monospace,
                            fontSize = 36.sp,
                            fontWeight = FontWeight.Black,
                            color = MoltenGold,
                            letterSpacing = (-1).sp
                        )
                        Text(
                            text = "LINE SPEED",
                            style = MaterialTheme.typography.labelSmall,
                            color = SheffieldIvoryDim,
                            letterSpacing = 1.0.sp
                        )

                        Spacer(modifier = Modifier.height(16.dp))

                        // Quality Tracking Group
                        Text(
                            text = "QUALITY TRACKING",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            color = SheffieldIvory,
                            letterSpacing = 0.8.sp
                        )
                        Spacer(modifier = Modifier.height(6.dp))

                        QualityCheckItem(label = "Surface", isOk = true)
                        Spacer(modifier = Modifier.height(4.dp))
                        QualityCheckItem(label = "Internal", isOk = true)
                        Spacer(modifier = Modifier.height(4.dp))
                        QualityCheckItem(label = "Dimensions", isOk = true)

                        Spacer(modifier = Modifier.height(16.dp))

                        // Cooling Water Group
                        Text(
                            text = "COOLING WATER",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            color = SheffieldIvory,
                            letterSpacing = 0.8.sp
                        )
                        Spacer(modifier = Modifier.height(6.dp))

                        MetricRow(label = "Flow", value = "${String.format("%,d", waterFlow.toInt())} m³/h")
                        MetricRow(label = "Inlet", value = "${waterInlet.toInt()} °C")
                        MetricRow(label = "Outlet", value = "${waterOutlet.toInt()} °C")
                    }
                }
            }
        }

        // MIDDLE: PRODUCTION TIMELINE / HEAT 2847
        ProductionTimeline(
            heat = activeHeat,
            onAdvanceStage = onAdvanceStage
        )

        // BOTTOM: UPCOMING HEATS (Left) & SHIFT SUMMARY (Right)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // UPCOMING HEATS TABLE
            Surface(
                color = SheffieldCard,
                shape = RoundedCornerShape(4.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, SheffieldBorder),
                modifier = Modifier
                    .weight(0.48f)
                    .testTag("upcoming_heats_panel")
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "UPCOMING HEATS",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = SheffieldIvory,
                        letterSpacing = 0.8.sp
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    // Table Header
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(SheffieldSurface)
                            .padding(vertical = 6.dp, horizontal = 8.dp)
                    ) {
                        Text("HEAT", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = SheffieldIvoryDim, modifier = Modifier.weight(1f))
                        Text("GRADE", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = SheffieldIvoryDim, modifier = Modifier.weight(1.2f))
                        Text("TARGET", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = SheffieldIvoryDim, modifier = Modifier.weight(1.2f))
                        Text("STATUS", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = SheffieldIvoryDim, modifier = Modifier.weight(1.4f))
                    }
                    HorizontalDivider(color = SheffieldBorder)

                    upcomingHeats.take(4).forEach { heat ->
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 8.dp, horizontal = 8.dp)
                        ) {
                            Text("${heat.heatNumber}", fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, color = SheffieldIvory, modifier = Modifier.weight(1f))
                            Text(heat.grade, style = MaterialTheme.typography.bodyMedium, color = SheffieldIvory, modifier = Modifier.weight(1.2f))
                            Text("${heat.targetTonnes.toInt()} t", fontFamily = FontFamily.Monospace, color = SheffieldIvoryMuted, modifier = Modifier.weight(1.2f))

                            val (statusText, statusColor) = if (heat.heatNumber == 2848) Pair("READY", SignalGreen) else Pair("QUEUED", MoltenGold)
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier
                                    .clip(RoundedCornerShape(12.dp))
                                    .border(1.dp, statusColor.copy(alpha = 0.5f), RoundedCornerShape(12.dp))
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Icon(
                                    imageVector = if (statusText == "READY") Icons.Default.CheckCircle else Icons.Default.Schedule,
                                    contentDescription = null,
                                    tint = statusColor,
                                    modifier = Modifier.size(12.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(statusText, style = MaterialTheme.typography.labelSmall, color = statusColor, fontWeight = FontWeight.Bold)
                            }
                        }
                        HorizontalDivider(color = SheffieldBorderSubtle)
                    }
                }
            }

            // SHIFT SUMMARY PANEL
            Surface(
                color = SheffieldCard,
                shape = RoundedCornerShape(4.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, SheffieldBorder),
                modifier = Modifier
                    .weight(0.52f)
                    .testTag("shift_summary_panel")
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "SHIFT SUMMARY",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = SheffieldIvory,
                        letterSpacing = 0.8.sp
                    )
                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        ShiftSummaryMetric(label = "OUTPUT", value = "1,240 t", valueColor = MoltenGold)
                        ShiftSummaryMetric(label = "ENERGY", value = "412 kWh/t", valueColor = MoltenGold)
                        ShiftSummaryMetric(label = "YIELD", value = "96.8%", valueColor = MoltenGold)
                        ShiftSummaryMetric(label = "AVAILABILITY", value = "98.2%", valueColor = MoltenGold)
                    }
                }
            }
        }

        // FOOTER STATUS BAR
        Surface(
            color = SheffieldSurface,
            shape = RoundedCornerShape(4.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 6.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.CheckCircle,
                        contentDescription = "Status OK",
                        tint = SignalGreen,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "All critical systems normal · Telemetry synchronised · PLC safety interlocks engaged",
                        style = MaterialTheme.typography.bodySmall,
                        color = SheffieldIvory
                    )
                }

                Text(
                    text = "Aureom.AI · Sheffield Industrial Supermodernism",
                    style = MaterialTheme.typography.bodySmall,
                    color = SheffieldIvoryDim,
                    fontStyle = androidx.compose.ui.text.font.FontStyle.Italic
                )
            }
        }
    }
}

@Composable
private fun QualityCheckItem(label: String, isOk: Boolean) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Icon(
            imageVector = Icons.Default.CheckCircle,
            contentDescription = "OK",
            tint = SignalGreen,
            modifier = Modifier.size(16.dp)
        )
        Text(
            text = label,
            style = MaterialTheme.typography.bodyMedium,
            color = SheffieldIvory
        )
    }
}

@Composable
private fun MetricRow(label: String, value: String) {
    Row(
        horizontalArrangement = Arrangement.SpaceBetween,
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 2.dp)
    ) {
        Text(label, style = MaterialTheme.typography.bodySmall, color = SheffieldIvoryDim)
        Text(value, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, color = SheffieldIvory)
    }
}

@Composable
private fun ShiftSummaryMetric(label: String, value: String, valueColor: Color) {
    Column {
        Text(label, style = MaterialTheme.typography.labelSmall, color = SheffieldIvoryDim, letterSpacing = 0.8.sp)
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = value,
            fontFamily = FontFamily.Monospace,
            fontSize = 24.sp,
            fontWeight = FontWeight.Black,
            color = valueColor
        )
    }
}
