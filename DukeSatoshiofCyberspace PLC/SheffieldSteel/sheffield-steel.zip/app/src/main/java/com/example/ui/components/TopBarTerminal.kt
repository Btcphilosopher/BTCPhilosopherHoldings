package com.example.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ConnectionStatus
import com.example.data.model.PlantFacility
import com.example.ui.theme.*
import com.example.ui.viewmodel.WorkspaceTab
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun TopBarTerminal(
    currentTab: WorkspaceTab,
    selectedPlant: PlantFacility,
    connectionStatus: ConnectionStatus,
    isSimulationActive: Boolean,
    currentShift: String,
    operatorUser: String,
    onSelectPlant: (PlantFacility) -> Unit,
    onSelectConnectionStatus: (ConnectionStatus) -> Unit,
    onToggleSimulation: () -> Unit,
    onOpenDemoRunner: () -> Unit,
    modifier: Modifier = Modifier
) {
    var plantMenuExpanded by remember { mutableStateOf(false) }
    var statusMenuExpanded by remember { mutableStateOf(false) }

    // Live clock ticker
    var currentTimeString by remember { mutableStateOf("15:07:42") }
    LaunchedEffect(Unit) {
        val sdf = SimpleDateFormat("HH:mm:ss", Locale.UK)
        while (true) {
            currentTimeString = sdf.format(Date())
            delay(1000)
        }
    }

    // Pulsing LED for live connection
    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val alphaAnim by infiniteTransition.animateFloat(
        initialValue = 0.35f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(900, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "ledAlpha"
    )

    Surface(
        color = SheffieldSurface,
        border = null,
        modifier = modifier
            .fillMaxWidth()
            .testTag("terminal_top_bar")
    ) {
        Column {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp)
            ) {
                // Left: Sheffield Industrial Identity
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // Sheffield Steel Emblem Icon
                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier
                            .size(32.dp)
                            .clip(RoundedCornerShape(6.dp))
                            .background(MoltenOrange)
                    ) {
                        Icon(
                            imageVector = Icons.Default.PrecisionManufacturing,
                            contentDescription = "Sheffield Steelworks",
                            tint = Color(0xFF0F0A05),
                            modifier = Modifier.size(20.dp)
                        )
                    }

                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "SHEFFIELD STEEL",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Black,
                                letterSpacing = 1.2.sp,
                                color = SheffieldIvory
                            )
                            Text(
                                text = " / OPERATIONS",
                                style = MaterialTheme.typography.bodySmall,
                                fontWeight = FontWeight.Bold,
                                color = SheffieldIvoryDim,
                                letterSpacing = 1.0.sp
                            )
                        }
                        // Plant selector dropdown
                        Box {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier
                                    .clickable { plantMenuExpanded = true }
                                    .testTag("plant_selector_button")
                            ) {
                                Text(
                                    text = selectedPlant.label.uppercase(),
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MoltenGold,
                                    fontWeight = FontWeight.Bold
                                )
                                Icon(
                                    imageVector = Icons.Default.ArrowDropDown,
                                    contentDescription = "Select plant",
                                    tint = MoltenGold,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                            DropdownMenu(
                                expanded = plantMenuExpanded,
                                onDismissRequest = { plantMenuExpanded = false },
                                modifier = Modifier.background(SheffieldCard)
                            ) {
                                PlantFacility.values().forEach { plant ->
                                    DropdownMenuItem(
                                        text = {
                                            Column {
                                                Text(plant.label, color = SheffieldIvory, fontWeight = FontWeight.Bold)
                                                Text(plant.locationName, color = SheffieldIvoryMuted, style = MaterialTheme.typography.bodySmall)
                                            }
                                        },
                                        onClick = {
                                            onSelectPlant(plant)
                                            plantMenuExpanded = false
                                        }
                                    )
                                }
                            }
                        }
                    }
                }

                // Center Title: Active Workspace Indicator
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(SheffieldCard)
                        .border(1.dp, SheffieldBorderSubtle, RoundedCornerShape(4.dp))
                        .padding(horizontal = 14.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = "${currentTab.label.uppercase()} CONTROL",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.4.sp,
                        color = SheffieldIvory
                    )
                }

                // Right Status Cluster
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    // Connection Status Pill
                    Box {
                        val (pillColor, ledColor) = when (connectionStatus) {
                            ConnectionStatus.CONNECTED -> Pair(SignalGreenSurface, SignalGreen)
                            ConnectionStatus.SIMULATED -> Pair(Color(0xFF261D04), MoltenGold)
                            ConnectionStatus.CACHED -> Pair(Color(0xFF142436), ElectricArcBlue)
                            ConnectionStatus.STALE -> Pair(DangerRedSurface, DangerRed)
                        }

                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .clip(RoundedCornerShape(16.dp))
                                .background(pillColor)
                                .border(1.dp, ledColor.copy(alpha = 0.5f), RoundedCornerShape(16.dp))
                                .clickable { statusMenuExpanded = true }
                                .padding(horizontal = 10.dp, vertical = 4.dp)
                                .testTag("connection_status_pill")
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(8.dp)
                                    .clip(CircleShape)
                                    .background(ledColor.copy(alpha = if (connectionStatus == ConnectionStatus.CONNECTED) alphaAnim else 1.0f))
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = connectionStatus.label,
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = ledColor
                            )
                            Icon(
                                imageVector = Icons.Default.ArrowDropDown,
                                contentDescription = "Change connection status",
                                tint = ledColor,
                                modifier = Modifier.size(14.dp)
                            )
                        }

                        DropdownMenu(
                            expanded = statusMenuExpanded,
                            onDismissRequest = { statusMenuExpanded = false },
                            modifier = Modifier.background(SheffieldCard)
                        ) {
                            ConnectionStatus.values().forEach { st ->
                                DropdownMenuItem(
                                    text = { Text(st.label, color = SheffieldIvory) },
                                    onClick = {
                                        onSelectConnectionStatus(st)
                                        statusMenuExpanded = false
                                    }
                                )
                            }
                        }
                    }

                    // Live Digital Monospace Clock
                    Text(
                        text = currentTimeString,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = SheffieldIvory,
                        letterSpacing = 1.0.sp
                    )

                    // Shift Operator Badge
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(SheffieldCard)
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.AccountCircle,
                            contentDescription = "Operator",
                            tint = SheffieldIvoryMuted,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = operatorUser.split(" ").firstOrNull() ?: "OPERATOR",
                            style = MaterialTheme.typography.labelSmall,
                            color = SheffieldIvoryMuted,
                            fontWeight = FontWeight.SemiBold
                        )
                    }

                    // Interactive Tour / Demo Step Button
                    Button(
                        onClick = onOpenDemoRunner,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MoltenOrange,
                            contentColor = Color(0xFF0F0A05)
                        ),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                        shape = RoundedCornerShape(4.dp),
                        modifier = Modifier
                            .height(30.dp)
                            .testTag("open_demo_tour_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.PlayArrow,
                            contentDescription = null,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "GUIDED TOUR",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Black
                        )
                    }
                }
            }

            // Technical dividing rule
            HorizontalDivider(
                color = SheffieldBorder,
                thickness = 1.dp
            )
        }
    }
}
