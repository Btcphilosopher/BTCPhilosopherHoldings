package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Sheffield Industrial Supermodernism Palette
val SheffieldBackground = Color(0xFF0A0C0E)
val SheffieldSurface = Color(0xFF12151B)
val SheffieldCard = Color(0xFF1B2028)
val SheffieldCardElevated = Color(0xFF242B36)
val SheffieldBorder = Color(0xFF323B48)
val SheffieldBorderSubtle = Color(0xFF252C36)

// Typography: Warm Ivory & Technical Text
val SheffieldIvory = Color(0xFFF7F5EE)
val SheffieldIvoryMuted = Color(0xFFCAC5B8)
val SheffieldIvoryDim = Color(0xFF868277)

// Thermal & Molten Accents
val MoltenOrange = Color(0xFFFF6D1A)
val MoltenGold = Color(0xFFFFB300)
val MoltenGlow = Color(0xFFFF8F00)
val MoltenWhiteHot = Color(0xFFFFF3E0)
val SlagGlow = Color(0xFFD84315)

// Operational Status Colors
val SignalGreen = Color(0xFF00E676)
val SignalGreenSurface = Color(0xFF0F3820)
val WarningAmber = Color(0xFFFFB300)
val WarningAmberSurface = Color(0xFF3E2C06)
val DangerRed = Color(0xFFFF3344)
val DangerRedSurface = Color(0xFF3E1218)
val ElectricArcBlue = Color(0xFF38BDF8)
val SteelBlue = Color(0xFF64748B)

// Chart lines
val ChartLineOrange = Color(0xFFFF7A00)
val ChartLineGreen = Color(0xFF00E676)
val ChartLineYellow = Color(0xFFFFC107)
val ChartLineBlue = Color(0xFF38BDF8)
