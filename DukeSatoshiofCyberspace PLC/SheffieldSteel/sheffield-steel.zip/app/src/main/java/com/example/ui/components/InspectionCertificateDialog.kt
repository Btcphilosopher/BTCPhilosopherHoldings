package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.local.entities.LabSample
import com.example.ui.theme.*
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun InspectionCertificateDialog(
    sample: LabSample,
    onDismiss: () -> Unit
) {
    val dateFormat = SimpleDateFormat("dd MMM yyyy HH:mm", Locale.UK)
    val issueDate = dateFormat.format(Date(sample.timestampEpoch))

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            color = Color(0xFF14171D),
            shape = RoundedCornerShape(6.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, SheffieldBorder),
            modifier = Modifier
                .fillMaxWidth(0.92f)
                .fillMaxHeight(0.92f)
                .testTag("mill_inspection_certificate_dialog")
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(20.dp)
            ) {
                // Dialog Top Action Bar
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Verified,
                            contentDescription = null,
                            tint = SignalGreen,
                            modifier = Modifier.size(22.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "DEMONSTRATION INSPECTION CERTIFICATE (BS EN 10204 Type 3.1)",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = SheffieldIvory
                        )
                    }

                    Row {
                        Button(
                            onClick = onDismiss,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = MoltenOrange,
                                contentColor = Color(0xFF0F0A05)
                            ),
                            shape = RoundedCornerShape(4.dp),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                        ) {
                            Icon(Icons.Default.Print, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("EXPORT / PRINT", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        IconButton(onClick = onDismiss) {
                            Icon(Icons.Default.Close, contentDescription = "Close", tint = SheffieldIvory)
                        }
                    }
                }

                HorizontalDivider(color = SheffieldBorder, modifier = Modifier.padding(vertical = 12.dp))

                // Scrollable Certificate Body Styled Like Serious Sheffield Mill Sheet
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .background(Color(0xFF0C0E12), RoundedCornerShape(4.dp))
                        .border(1.dp, SheffieldBorderSubtle, RoundedCornerShape(4.dp))
                        .padding(18.dp)
                        .verticalScroll(rememberScrollState())
                ) {
                    // Header Letterhead
                    Row(
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column {
                            Text(
                                text = "SHEFFIELD STEELWORKS PLC",
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.Black,
                                letterSpacing = 1.2.sp,
                                color = SheffieldIvory
                            )
                            Text(
                                text = "River Don Works · Brightside Lane, Sheffield S9 2RZ, UK",
                                style = MaterialTheme.typography.bodySmall,
                                color = SheffieldIvoryMuted
                            )
                            Text(
                                text = "Accredited Testing Laboratory ISO/IEC 17025 · QA Reg. FM 00214",
                                style = MaterialTheme.typography.bodySmall,
                                color = SheffieldIvoryDim
                            )
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                text = "CERTIFICATE NO: MTC-${sample.heatNumber}-EN3.1",
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                color = MoltenGold
                            )
                            Text(
                                text = "Date of Issue: $issueDate",
                                style = MaterialTheme.typography.bodySmall,
                                color = SheffieldIvoryMuted
                            )
                            Text(
                                text = "Standard: BS EN 10025-2:2019",
                                style = MaterialTheme.typography.bodySmall,
                                color = SignalGreen
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Material & Order Identification Box
                    Surface(
                        color = Color(0xFF14181F),
                        shape = RoundedCornerShape(4.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, SheffieldBorder),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp)
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text("CUSTOMER / PROJECT", style = MaterialTheme.typography.labelSmall, color = SheffieldIvoryDim)
                                Text("Balfour Beatty Rail / HS2 Infrastructure", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold, color = SheffieldIvory)
                                Spacer(modifier = Modifier.height(6.dp))
                                Text("PRODUCT SPECIFICATION", style = MaterialTheme.typography.labelSmall, color = SheffieldIvoryDim)
                                Text("Hot Rolled Structural Steel Grade S355JR (+AR / +N)", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold, color = SheffieldIvory)
                            }
                            Column(modifier = Modifier.weight(1f)) {
                                Text("HEAT NUMBER", style = MaterialTheme.typography.labelSmall, color = SheffieldIvoryDim)
                                Text("${sample.heatNumber}", fontFamily = FontFamily.Monospace, style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.Bold, color = MoltenOrange)
                                Spacer(modifier = Modifier.height(6.dp))
                                Text("MELTING ROUTE", style = MaterialTheme.typography.labelSmall, color = SheffieldIvoryDim)
                                Text("EAF 120MVA + LF Basic Slag + Ar Stir + CCM 3-Strand", style = MaterialTheme.typography.bodySmall, color = SheffieldIvoryMuted)
                            }
                            Column(modifier = Modifier.weight(1f)) {
                                Text("SAMPLE REF / STAGE", style = MaterialTheme.typography.labelSmall, color = SheffieldIvoryDim)
                                Text(sample.sampleId, fontFamily = FontFamily.Monospace, style = MaterialTheme.typography.bodyMedium, color = SheffieldIvory)
                                Spacer(modifier = Modifier.height(6.dp))
                                Text("STATUS", style = MaterialTheme.typography.labelSmall, color = SheffieldIvoryDim)
                                Text(sample.qualityStatus, fontWeight = FontWeight.Bold, color = if (sample.isPassed) SignalGreen else DangerRed)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(18.dp))

                    // Chemical Analysis Table (Optical Emission Spectrometry OES)
                    Text(
                        text = "1. CHEMICAL COMPOSITION (Weight % · OES Spectrometer Heat Analysis)",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        color = MoltenGold
                    )
                    Spacer(modifier = Modifier.height(6.dp))

                    TableGrid(
                        headers = listOf("Element", "C", "Si", "Mn", "P", "S", "Cr", "Ni", "Mo", "Al", "CEV"),
                        specMin = listOf("Spec Min", "-", "-", "-", "-", "-", "-", "-", "-", "0.020", "-"),
                        specMax = listOf("Spec Max", "0.24", "0.55", "1.60", "0.035", "0.035", "0.30", "0.30", "0.10", "-", "0.45"),
                        actuals = listOf(
                            "Heat Result",
                            String.format("%.2f", sample.carbonPct),
                            String.format("%.2f", sample.siliconPct),
                            String.format("%.2f", sample.manganesePct),
                            String.format("%.3f", sample.phosphorusPct),
                            String.format("%.3f", sample.sulfurPct),
                            String.format("%.2f", sample.chromiumPct),
                            String.format("%.2f", sample.nickelPct),
                            String.format("%.2f", sample.molybdenumPct),
                            String.format("%.3f", sample.aluminumPct),
                            String.format("%.2f", sample.cevEquivalent)
                        ),
                        isPassed = sample.isPassed
                    )

                    Spacer(modifier = Modifier.height(18.dp))

                    // Mechanical Testing Table
                    Text(
                        text = "2. MECHANICAL PROPERTIES (Tensile & Charpy V-Notch at -20°C)",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        color = MoltenGold
                    )
                    Spacer(modifier = Modifier.height(6.dp))

                    MechanicalTable(
                        yieldVal = sample.yieldStrengthMpa ?: 375.0,
                        tensileVal = sample.tensileStrengthMpa ?: 530.0,
                        elongationVal = sample.elongationPct ?: 24.5,
                        charpyVal = sample.charpyJoules ?: 48.0
                    )

                    Spacer(modifier = Modifier.height(18.dp))

                    // Non-Destructive Inspection & Metallurgical Approval
                    Text(
                        text = "3. NON-DESTRUCTIVE TESTING & SURFACE INSPECTION",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        color = MoltenGold
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Surface(
                        color = Color(0xFF14181F),
                        shape = RoundedCornerShape(4.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Text("• Ultrasonic Testing (EN 10160): Class S1 / E1 Conforming - 100% Volumetric scan passed.", style = MaterialTheme.typography.bodySmall, color = SheffieldIvory)
                            Text("• Surface Defect Eddy Current: Conforming to Class B without surface imperfections.", style = MaterialTheme.typography.bodySmall, color = SheffieldIvory)
                            Text("• Dimensional Tolerances: EN 10034 Heavy Section Tolerance Class 1 Verified.", style = MaterialTheme.typography.bodySmall, color = SheffieldIvory)
                        }
                    }

                    Spacer(modifier = Modifier.height(20.dp))

                    // Signature & Legal Declaration
                    Row(
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.Bottom,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column {
                            Text("LEGAL NOTICE", style = MaterialTheme.typography.labelSmall, color = SheffieldIvoryDim)
                            Text(
                                "We hereby certify that the supplied material complies with the requirements of the purchase order\nand referenced British & European standards (BS EN 10025-2:2019 / Type 3.1).",
                                style = MaterialTheme.typography.bodySmall,
                                color = SheffieldIvoryMuted,
                                fontSize = 10.sp
                            )
                        }

                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                text = "Dr. E. Thorne",
                                fontFamily = FontFamily.Cursive,
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold,
                                color = SheffieldIvory
                            )
                            HorizontalDivider(color = SheffieldBorder, modifier = Modifier.width(160.dp))
                            Text("Head of Quality Assurance", style = MaterialTheme.typography.labelSmall, color = SheffieldIvory)
                            Text("Authorised Inspector Sign-off", style = MaterialTheme.typography.labelSmall, color = SignalGreen)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun TableGrid(
    headers: List<String>,
    specMin: List<String>,
    specMax: List<String>,
    actuals: List<String>,
    isPassed: Boolean
) {
    Surface(
        color = Color(0xFF14181F),
        shape = RoundedCornerShape(4.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, SheffieldBorder),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column {
            // Header Row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFF1F242D))
                    .padding(vertical = 6.dp, horizontal = 4.dp)
            ) {
                headers.forEachIndexed { idx, title ->
                    Text(
                        text = title,
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = SheffieldIvory,
                        modifier = Modifier.weight(if (idx == 0) 1.5f else 1f)
                    )
                }
            }
            HorizontalDivider(color = SheffieldBorder)

            // Spec Min
            Row(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp, horizontal = 4.dp)) {
                specMin.forEachIndexed { idx, valText ->
                    Text(
                        text = valText,
                        style = MaterialTheme.typography.bodySmall,
                        color = SheffieldIvoryDim,
                        modifier = Modifier.weight(if (idx == 0) 1.5f else 1f)
                    )
                }
            }

            // Spec Max
            Row(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp, horizontal = 4.dp)) {
                specMax.forEachIndexed { idx, valText ->
                    Text(
                        text = valText,
                        style = MaterialTheme.typography.bodySmall,
                        color = SheffieldIvoryDim,
                        modifier = Modifier.weight(if (idx == 0) 1.5f else 1f)
                    )
                }
            }
            HorizontalDivider(color = SheffieldBorder)

            // Actual Result
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(if (isPassed) Color(0xFF0F2618) else Color(0xFF2C1014))
                    .padding(vertical = 6.dp, horizontal = 4.dp)
            ) {
                actuals.forEachIndexed { idx, valText ->
                    Text(
                        text = valText,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (idx == 0) SheffieldIvory else if (isPassed) SignalGreen else DangerRed,
                        modifier = Modifier.weight(if (idx == 0) 1.5f else 1f)
                    )
                }
            }
        }
    }
}

@Composable
private fun MechanicalTable(
    yieldVal: Double,
    tensileVal: Double,
    elongationVal: Double,
    charpyVal: Double
) {
    Surface(
        color = Color(0xFF14181F),
        shape = RoundedCornerShape(4.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, SheffieldBorder),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFF1F242D))
                    .padding(vertical = 6.dp, horizontal = 6.dp)
            ) {
                Text("Parameter", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = SheffieldIvory, modifier = Modifier.weight(1.8f))
                Text("Standard Unit", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = SheffieldIvory, modifier = Modifier.weight(1.2f))
                Text("Specified Limits", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = SheffieldIvory, modifier = Modifier.weight(1.5f))
                Text("Tested Result", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = SheffieldIvory, modifier = Modifier.weight(1.5f))
                Text("Compliance", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = SheffieldIvory, modifier = Modifier.weight(1.2f))
            }
            HorizontalDivider(color = SheffieldBorder)

            val rows = listOf(
                listOf("Yield Strength (ReH)", "MPa (N/mm²)", "Min. 355", String.format("%.1f", yieldVal), "CONFORMS"),
                listOf("Tensile Strength (Rm)", "MPa (N/mm²)", "470 - 630", String.format("%.1f", tensileVal), "CONFORMS"),
                listOf("Elongation (A5)", "%", "Min. 22.0", String.format("%.1f%%", elongationVal), "CONFORMS"),
                listOf("Charpy Impact (-20°C)", "Joules (J)", "Min. 27 J", "${charpyVal.toInt()} J", "CONFORMS")
            )

            rows.forEach { row ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 5.dp, horizontal = 6.dp)
                ) {
                    Text(row[0], style = MaterialTheme.typography.bodySmall, color = SheffieldIvory, modifier = Modifier.weight(1.8f))
                    Text(row[1], style = MaterialTheme.typography.bodySmall, color = SheffieldIvoryDim, modifier = Modifier.weight(1.2f))
                    Text(row[2], style = MaterialTheme.typography.bodySmall, color = SheffieldIvoryMuted, modifier = Modifier.weight(1.5f))
                    Text(row[3], fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, color = SignalGreen, modifier = Modifier.weight(1.5f))
                    Text(row[4], style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = SignalGreen, modifier = Modifier.weight(1.2f))
                }
                HorizontalDivider(color = SheffieldBorderSubtle)
            }
        }
    }
}
