package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*

@Composable
fun TechnicalLineChart(
    title: String,
    dataPoints: List<Double>,
    minY: Double,
    maxY: Double,
    lineColor: Color,
    yUnit: String = "",
    yLabels: List<String> = emptyList(),
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .background(SheffieldCard, RoundedCornerShape(4.dp))
            .border(1.dp, SheffieldBorder, RoundedCornerShape(4.dp))
            .padding(10.dp)
    ) {
        // Chart Header
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(
                text = title,
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.Bold,
                color = SheffieldIvory,
                letterSpacing = 0.8.sp
            )
            val currentVal = dataPoints.lastOrNull()
            if (currentVal != null) {
                Text(
                    text = "${String.format("%.1f", currentVal)} $yUnit",
                    fontFamily = FontFamily.Monospace,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = lineColor
                )
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        // Canvas Area with Y-axis markers & Grid
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(90.dp)
        ) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val w = size.width
                val h = size.height

                // Draw horizontal grid lines (4 lines)
                val gridColor = Color(0xFF2A323D)
                for (i in 0..3) {
                    val y = h * (i / 3f)
                    drawLine(
                        color = gridColor,
                        start = Offset(0f, y),
                        end = Offset(w, y),
                        strokeWidth = 1f
                    )
                }

                // Draw vertical grid lines (-30 min, -20 min, -10 min, Now)
                for (i in 0..3) {
                    val x = w * (i / 3f)
                    drawLine(
                        color = gridColor,
                        start = Offset(x, 0f),
                        end = Offset(x, h),
                        strokeWidth = 1f
                    )
                }

                if (dataPoints.size < 2) return@Canvas

                val range = (maxY - minY).coerceAtLeast(0.001)
                val points = dataPoints.takeLast(30)
                val stepX = w / (points.size - 1).coerceAtLeast(1)

                val linePath = Path()
                val fillPath = Path()

                points.forEachIndexed { i, value ->
                    val normY = ((value - minY) / range).coerceIn(0.0, 1.0)
                    val x = i * stepX
                    val y = h - (normY * h).toFloat()

                    if (i == 0) {
                        linePath.moveTo(x, y)
                        fillPath.moveTo(x, h)
                        fillPath.lineTo(x, y)
                    } else {
                        linePath.lineTo(x, y)
                        fillPath.lineTo(x, y)
                    }
                }

                fillPath.lineTo(w, h)
                fillPath.close()

                // Translucent gradient fill under curve
                drawPath(
                    path = fillPath,
                    brush = Brush.verticalGradient(
                        colors = listOf(lineColor.copy(alpha = 0.25f), Color.Transparent),
                        startY = 0f,
                        endY = h
                    )
                )

                // Glowing crisp technical stroke
                drawPath(
                    path = linePath,
                    color = lineColor,
                    style = Stroke(width = 2.5f)
                )

                // Last point indicator dot
                val lastVal = points.last()
                val lastNormY = ((lastVal - minY) / range).coerceIn(0.0, 1.0)
                val lastX = w
                val lastY = h - (lastNormY * h).toFloat()
                drawCircle(
                    color = Color.White,
                    radius = 3.5f,
                    center = Offset(lastX, lastY)
                )
                drawCircle(
                    color = lineColor,
                    radius = 6f,
                    center = Offset(lastX, lastY),
                    style = Stroke(width = 2f)
                )
            }
        }

        Spacer(modifier = Modifier.height(4.dp))

        // Time Axis Labels (-30 min, -20 min, -10 min, Now)
        Row(
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("-30 min", style = MaterialTheme.typography.labelSmall, color = SheffieldIvoryDim, fontSize = 9.sp)
            Text("-20 min", style = MaterialTheme.typography.labelSmall, color = SheffieldIvoryDim, fontSize = 9.sp)
            Text("-10 min", style = MaterialTheme.typography.labelSmall, color = SheffieldIvoryDim, fontSize = 9.sp)
            Text("Now", style = MaterialTheme.typography.labelSmall, color = SheffieldIvoryDim, fontSize = 9.sp)
        }
    }
}
