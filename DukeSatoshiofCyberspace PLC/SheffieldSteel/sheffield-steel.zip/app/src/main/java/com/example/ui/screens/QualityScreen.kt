package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.entities.LabSample
import com.example.ui.theme.*

@Composable
fun QualityScreen(
    labSamples: List<LabSample>,
    onViewCertificate: (LabSample) -> Unit,
    onReleaseHold: (sampleId: String, reason: String) -> Unit,
    onRegisterSample: (heatNum: Int, type: String, c: Double, si: Double, mn: Double, p: Double, s: Double, passed: Boolean, status: String, notes: String) -> Unit,
    modifier: Modifier = Modifier
) {
    var showRegisterDialog by remember { mutableStateOf(false) }
    var selectedHoldSample by remember { mutableStateOf<LabSample?>(null) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(SheffieldBackground)
            .padding(16.dp)
            .testTag("quality_screen"),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Top Toolbar
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "METALLURGICAL QUALITY ASSURANCE & OES SPECTROMETRY",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = SheffieldIvory
                )
                Text(
                    text = "BS EN 10025-2 Specification Compliance · Optical Emission Spectrometry · Type 3.1 Mill Certs",
                    style = MaterialTheme.typography.bodySmall,
                    color = SheffieldIvoryMuted
                )
            }

            Button(
                onClick = { showRegisterDialog = true },
                colors = ButtonDefaults.buttonColors(containerColor = MoltenOrange, contentColor = Color(0xFF0F0A05)),
                shape = RoundedCornerShape(4.dp),
                modifier = Modifier.testTag("register_lab_sample_button")
            ) {
                Icon(Icons.Default.Science, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("REGISTER NEW LAB SAMPLE", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
            }
        }

        // Summary Counts: Approved vs Quality Holds vs Rejected
        val approvedCount = labSamples.count { it.isPassed }
        val holdCount = labSamples.count { it.qualityStatus == "QUARANTINE_HOLD" }
        val rejectedCount = labSamples.count { it.qualityStatus == "REJECTED" }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Surface(
                color = SheffieldCard,
                shape = RoundedCornerShape(4.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, SheffieldBorder),
                modifier = Modifier.weight(1f)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text("CONFORMING / APPROVED", style = MaterialTheme.typography.labelSmall, color = SheffieldIvoryDim)
                    Text("$approvedCount", fontFamily = FontFamily.Monospace, fontSize = 26.sp, fontWeight = FontWeight.Black, color = SignalGreen)
                }
            }

            Surface(
                color = SheffieldCard,
                shape = RoundedCornerShape(4.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, if (holdCount > 0) DangerRed else SheffieldBorder),
                modifier = Modifier.weight(1f)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text("ACTIVE QUALITY HOLDS", style = MaterialTheme.typography.labelSmall, color = SheffieldIvoryDim)
                    Text("$holdCount", fontFamily = FontFamily.Monospace, fontSize = 26.sp, fontWeight = FontWeight.Black, color = if (holdCount > 0) DangerRed else SheffieldIvoryMuted)
                }
            }

            Surface(
                color = SheffieldCard,
                shape = RoundedCornerShape(4.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, SheffieldBorder),
                modifier = Modifier.weight(1f)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text("REJECTED / SCRAPPED", style = MaterialTheme.typography.labelSmall, color = SheffieldIvoryDim)
                    Text("$rejectedCount", fontFamily = FontFamily.Monospace, fontSize = 26.sp, fontWeight = FontWeight.Black, color = SheffieldIvoryDim)
                }
            }
        }

        // Samples Register List
        Surface(
            color = SheffieldCard,
            shape = RoundedCornerShape(4.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, SheffieldBorder),
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text(
                    text = "LABORATORY SAMPLES & SPECIFICATION VERIFICATION",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = SheffieldIvory
                )
                Spacer(modifier = Modifier.height(10.dp))

                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(labSamples) { sample ->
                        val isHold = sample.qualityStatus == "QUARANTINE_HOLD"
                        val borderColor = when {
                            isHold -> DangerRed
                            sample.isPassed -> SignalGreen.copy(alpha = 0.5f)
                            else -> DangerRed.copy(alpha = 0.6f)
                        }

                        Surface(
                            color = SheffieldSurface,
                            shape = RoundedCornerShape(4.dp),
                            border = androidx.compose.foundation.BorderStroke(1.dp, borderColor),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Row(
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(sample.sampleId, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, color = MoltenGold)
                                        Spacer(modifier = Modifier.width(10.dp))
                                        Text("Heat #${sample.heatNumber}", fontFamily = FontFamily.Monospace, color = SheffieldIvory)
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text("· ${sample.sampleType}", style = MaterialTheme.typography.bodySmall, color = SheffieldIvoryMuted)
                                    }

                                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        if (isHold) {
                                            Button(
                                                onClick = { selectedHoldSample = sample },
                                                colors = ButtonDefaults.buttonColors(containerColor = DangerRed),
                                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                                shape = RoundedCornerShape(2.dp)
                                            ) {
                                                Text("AUTHORISE RELEASE", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                                            }
                                        }

                                        Button(
                                            onClick = { onViewCertificate(sample) },
                                            colors = ButtonDefaults.buttonColors(containerColor = SheffieldCardElevated, contentColor = SheffieldIvory),
                                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp),
                                            shape = RoundedCornerShape(2.dp),
                                            modifier = Modifier.testTag("view_cert_${sample.sampleId}")
                                        ) {
                                            Icon(Icons.Default.Description, contentDescription = null, modifier = Modifier.size(14.dp))
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text("VIEW 3.1 MILL CERT", style = MaterialTheme.typography.labelSmall)
                                        }
                                    }
                                }

                                Spacer(modifier = Modifier.height(8.dp))

                                // Chemistry numbers with high-contrast colored limits
                                Row(
                                    horizontalArrangement = Arrangement.spacedBy(16.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Text("C: ${sample.carbonPct}%", fontFamily = FontFamily.Monospace, fontSize = 12.sp, color = SheffieldIvory)
                                    Text("Si: ${sample.siliconPct}%", fontFamily = FontFamily.Monospace, fontSize = 12.sp, color = SheffieldIvory)
                                    Text("Mn: ${sample.manganesePct}%", fontFamily = FontFamily.Monospace, fontSize = 12.sp, color = SheffieldIvory)
                                    Text("P: ${sample.phosphorusPct}%", fontFamily = FontFamily.Monospace, fontSize = 12.sp, color = if (sample.phosphorusPct > 0.035) DangerRed else SheffieldIvory)
                                    Text("S: ${sample.sulfurPct}%", fontFamily = FontFamily.Monospace, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = if (sample.sulfurPct > 0.035) DangerRed else SignalGreen)
                                    Text("CEV: ${sample.cevEquivalent}", fontFamily = FontFamily.Monospace, fontSize = 12.sp, color = ElectricArcBlue)
                                }

                                Spacer(modifier = Modifier.height(4.dp))
                                Text(sample.notes, style = MaterialTheme.typography.bodySmall, color = SheffieldIvoryMuted)
                            }
                        }
                    }
                }
            }
        }
    }

    // Authorise Release Dialog
    if (selectedHoldSample != null) {
        val s = selectedHoldSample!!
        var releaseReason by remember { mutableStateOf("Desulfurization flux addition completed. Secondary LF sample verified conforming.") }

        AlertDialog(
            onDismissRequest = { selectedHoldSample = null },
            title = { Text("Authorised Metallurgical Release", color = SheffieldIvory) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Authorising release for Sample ${s.sampleId} (Heat #${s.heatNumber}). Digital signature will be logged in quality audit trail.", style = MaterialTheme.typography.bodySmall, color = SheffieldIvoryMuted)
                    OutlinedTextField(value = releaseReason, onValueChange = { releaseReason = it }, label = { Text("Metallurgical Justification & Action") })
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        onReleaseHold(s.sampleId, releaseReason)
                        selectedHoldSample = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = SignalGreen, contentColor = Color.Black)
                ) {
                    Text("SIGN & RELEASE HOLD")
                }
            },
            dismissButton = {
                TextButton(onClick = { selectedHoldSample = null }) { Text("CANCEL") }
            }
        )
    }

    // Register Sample Dialog
    if (showRegisterDialog) {
        var heatNumStr by remember { mutableStateOf("2847") }
        var type by remember { mutableStateOf("LF_INTERMEDIATE") }
        var cStr by remember { mutableStateOf("0.18") }
        var siStr by remember { mutableStateOf("0.32") }
        var mnStr by remember { mutableStateOf("1.44") }
        var pStr by remember { mutableStateOf("0.016") }
        var sStr by remember { mutableStateOf("0.019") }
        var notes by remember { mutableStateOf("OES test routine - fully within S355JR tolerances") }

        AlertDialog(
            onDismissRequest = { showRegisterDialog = false },
            title = { Text("Register OES Spectrometer Sample", color = SheffieldIvory) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedTextField(value = heatNumStr, onValueChange = { heatNumStr = it }, label = { Text("Heat #") })
                    OutlinedTextField(value = type, onValueChange = { type = it }, label = { Text("Stage Type") })
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        OutlinedTextField(value = cStr, onValueChange = { cStr = it }, label = { Text("C%") }, modifier = Modifier.weight(1f))
                        OutlinedTextField(value = mnStr, onValueChange = { mnStr = it }, label = { Text("Mn%") }, modifier = Modifier.weight(1f))
                        OutlinedTextField(value = sStr, onValueChange = { sStr = it }, label = { Text("S%") }, modifier = Modifier.weight(1f))
                    }
                    OutlinedTextField(value = notes, onValueChange = { notes = it }, label = { Text("Analyst Notes") })
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val hn = heatNumStr.toIntOrNull() ?: 2847
                        val c = cStr.toDoubleOrNull() ?: 0.18
                        val si = siStr.toDoubleOrNull() ?: 0.32
                        val mn = mnStr.toDoubleOrNull() ?: 1.44
                        val p = pStr.toDoubleOrNull() ?: 0.016
                        val s = sStr.toDoubleOrNull() ?: 0.019
                        val passed = s <= 0.035 && p <= 0.035
                        val status = if (passed) "APPROVED" else "QUARANTINE_HOLD"
                        onRegisterSample(hn, type, c, si, mn, p, s, passed, status, notes)
                        showRegisterDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MoltenOrange)
                ) {
                    Text("LOG SAMPLE RESULT")
                }
            },
            dismissButton = {
                TextButton(onClick = { showRegisterDialog = false }) { Text("CANCEL") }
            }
        )
    }
}
