package com.example

import com.example.data.model.SteelGrade
import com.example.data.simulator.SteelworksSimulator
import org.junit.Assert.*
import org.junit.Test

class SteelworksLogicTest {

    @Test
    fun massBalanceCalculation_isAccurateAndFeasible() {
        val result = SteelworksSimulator.calculateMassBalance(
            grade = SteelGrade.S355JR,
            targetLiquidTonnes = 240.0,
            hms1Ratio = 0.50,
            psRatio = 0.30,
            shreddedRatio = 0.15,
            alloysRatio = 0.05
        )

        assertEquals(240.0, result.targetTonnes, 0.01)
        assertTrue("Total charge weight must exceed liquid output due to scale/slag loss", result.totalChargeWeightTonnes > 240.0)
        assertTrue("Yield should be realistic for EAF (between 93% and 98%)", result.expectedMetallicYieldPct in 93.0..98.0)
        assertTrue("S355JR standard mix must be feasible", result.isFeasible)
        assertTrue("Predicted Carbon within specification (0.10 - 0.25%)", result.predictedCarbonPct in 0.10..0.25)
        assertTrue("Cost per tonne must be reasonable for UK structural steel (£300-£500/t)", result.estimatedCostPerTonneGbp in 300.0..500.0)
    }

    @Test
    fun massBalanceCalculation_flagsExcessSulfur() {
        // High sulfur scrap mix with strict grade S355J2 (max S 0.025%)
        val result = SteelworksSimulator.calculateMassBalance(
            grade = SteelGrade.S355J2,
            targetLiquidTonnes = 240.0,
            hms1Ratio = 0.70, // HMS has higher sulfur
            psRatio = 0.05,
            shreddedRatio = 0.25,
            alloysRatio = 0.0
        )

        assertFalse("High sulfur scrap mix must be flagged as non-feasible for S355J2", result.isFeasible)
        assertTrue("Limiting factor must mention Sulfur", result.limitingFactor.contains("Sulfur", ignoreCase = true))
    }

    @Test
    fun seedData_containsReferenceFurnace02AndHeat2847() {
        val seed = SteelworksSimulator.generateInitialSeedData(1000000L)

        val active = seed.heats.firstOrNull { it.heatNumber == 2847 }
        assertNotNull("Heat 2847 must exist in seed data", active)
        assertEquals("S355JR", active?.grade)
        assertEquals(240.0, active?.targetTonnes ?: 0.0, 0.01)
        assertEquals("FURNACE-02", active?.furnaceId)
        assertEquals("CAST", active?.currentStage)

        // Verify scrap items
        assertTrue("Must have scrap items in inventory", seed.scrapItems.isNotEmpty())
        assertTrue("Must include British Metal Recycling lot", seed.scrapItems.any { it.supplier.contains("British Metal Recycling") })

        // Verify lab samples including sulfur failure event and approval
        assertTrue("Must include QA samples", seed.labSamples.size >= 2)
        val initialSample = seed.labSamples.firstOrNull { it.sampleId == "SMP-2847-01" }
        assertNotNull(initialSample)
        assertFalse("Initial sample must be marked as hold/failed due to sulfur", initialSample!!.isPassed)

        val finalSample = seed.labSamples.firstOrNull { it.sampleId == "SMP-2847-02" }
        assertNotNull(finalSample)
        assertTrue("Final sample must be approved", finalSample!!.isPassed)
    }

    @Test
    fun costArithmetic_conversionCostPerTonne() {
        val scrapCost = 242.0
        val alloyCost = 48.0
        val energyCost = 52.0
        val consumablesCost = 18.0
        val labourCost = 35.0
        val totalCost = scrapCost + alloyCost + energyCost + consumablesCost + labourCost

        assertEquals(395.0, totalCost, 0.01)

        val sellingPrice = 580.0
        val grossMargin = sellingPrice - totalCost
        assertEquals(185.0, grossMargin, 0.01)
        val marginPct = (grossMargin / sellingPrice) * 100.0
        assertTrue("Gross margin percentage should be positive and realistic (~31.9%)", marginPct > 30.0)
    }
}
