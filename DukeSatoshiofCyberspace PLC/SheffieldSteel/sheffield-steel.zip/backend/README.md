# Sheffield Steel Terminal - Industrial Telemetry Gateway & Simulator

This service provides real-time telemetry, mass-balance stoichiometric calculations, and records synchronisation for the **Sheffield Steel Terminal** enterprise Android application.

## Quick Start

1. Install Python 3.10+ dependencies:
   ```bash
   pip install -r requirements.txt
   ```

2. Run the FastAPI server:
   ```bash
   uvicorn server:app --host 0.0.0.0 --port 8000 --reload
   ```

3. Open interactive OpenAPI Swagger docs in your browser:
   ```
   http://localhost:8000/docs
   ```

## Key Endpoints

- `GET /api/telemetry`: Real-time industrial telemetry (EAF power MW, bath temperature °C, casting line speed m/min, water flows).
- `POST /api/mass-balance`: Stoichiometric mass balance calculation for target grades (S355JR, S275JR, etc.).
- `GET /api/heats/active`: Current melt shop heat status.
