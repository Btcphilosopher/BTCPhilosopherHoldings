"""
Sheffield Steelworks Industrial Telemetry & Production Simulator Backend
FastAPI service exposing REST and WebSocket endpoints for steelworks operations.
"""

from fastapi import FastAPI, HTTPException, status
from pydantic import BaseModel, Field
from typing import List, Optional
import math
import time
import random

app = FastAPI(
    title="Sheffield Steelworks Terminal API",
    description="Enterprise Industrial API for Sheffield Steel Melt Shop, Continuous Casting, Rolling & Metallurgy QA.",
    version="1.0.0"
)

# --- Data Models ---
class TelemetryReadout(BaseModel):
    timestamp_epoch: int
    eaf_power_mw: float
    eaf_temp_c: int
    caster_speed_mpm: float
    cooling_water_flow_m3h: float
    cooling_inlet_c: float
    cooling_outlet_c: float
    status: str

class MassBalanceRequest(BaseModel):
    grade: str = Field(default="S355JR", description="Target steel grade")
    target_liquid_tonnes: float = Field(default=240.0, description="Target molten liquid steel output")
    hms1_ratio: float = 0.50
    ps_ratio: float = 0.30
    shredded_ratio: float = 0.15
    alloys_ratio: float = 0.05

class MassBalanceResponse(BaseModel):
    target_grade: str
    target_liquid_tonnes: float
    total_charge_weight_tonnes: float
    expected_yield_pct: float
    predicted_carbon_pct: float
    predicted_manganese_pct: float
    predicted_sulfur_pct: float
    is_feasible: bool
    limiting_factor: str
    cost_per_tonne_gbp: float

# --- Seed State ---
current_heat = {
    "heat_number": 2847,
    "grade": "S355JR",
    "target_tonnes": 240.0,
    "actual_tonnes": 238.6,
    "stage": "CAST",
    "stage_progress_pct": 15,
    "bath_temp_c": 1620,
    "active_power_mw": 78.0,
    "status": "ONLINE"
}

@app.get("/")
def root():
    return {
        "service": "Sheffield Steelworks Operations Gateway",
        "plant": "Sheffield River Don Works",
        "status": "OPERATIONAL",
        "docs_url": "/docs"
    }

@app.get("/api/telemetry", response_model=TelemetryReadout)
def get_live_telemetry():
    now = int(time.time() * 1000)
    power_noise = math.sin(time.time() * 0.5) * 4.0 + random.uniform(-1.5, 1.5)
    temp_noise = int(math.sin(time.time() * 0.3) * 6.0) + random.randint(-2, 2)
    speed_noise = math.sin(time.time() * 0.4) * 0.04

    return TelemetryReadout(
        timestamp_epoch=now,
        eaf_power_mw=round(78.0 + power_noise, 1),
        eaf_temp_c=1620 + temp_noise,
        caster_speed_mpm=round(1.2 + speed_noise, 2),
        cooling_water_flow_m3h=round(3480.0 + random.uniform(-20, 20), 1),
        cooling_inlet_c=28.0,
        cooling_outlet_c=41.2,
        status="ONLINE"
    )

@app.post("/api/mass-balance", response_model=MassBalanceResponse)
def calculate_mass_balance(req: MassBalanceRequest):
    weighted_recovery = (req.hms1_ratio * 0.94) + (req.ps_ratio * 0.97) + (req.shredded_ratio * 0.91) + (req.alloys_ratio * 0.88)
    charge_weight = req.target_liquid_tonnes / weighted_recovery
    yield_pct = (req.target_liquid_tonnes / charge_weight) * 100.0

    pred_c = (req.hms1_ratio * 0.15) + (req.ps_ratio * 0.18) + (req.shredded_ratio * 0.22) + (req.alloys_ratio * 0.85)
    pred_mn = (req.hms1_ratio * 0.55) + (req.ps_ratio * 0.65) + (req.shredded_ratio * 0.45) + (req.alloys_ratio * 14.5)
    pred_s = (req.hms1_ratio * 0.032) + (req.ps_ratio * 0.020) + (req.shredded_ratio * 0.040) + (req.alloys_ratio * 0.015)

    feasible = pred_s <= 0.035
    limiting = "Conforming" if feasible else f"Sulfur {pred_s:.3f}% exceeds 0.035% ceiling"
    cost_per_tonne = 242.0 * req.hms1_ratio + 268.0 * req.ps_ratio + 218.0 * req.shredded_ratio + 1120.0 * req.alloys_ratio

    return MassBalanceResponse(
        target_grade=req.grade,
        target_liquid_tonnes=req.target_liquid_tonnes,
        total_charge_weight_tonnes=round(charge_weight, 1),
        expected_yield_pct=round(yield_pct, 1),
        predicted_carbon_pct=round(pred_c, 2),
        predicted_manganese_pct=round(pred_mn, 2),
        predicted_sulfur_pct=round(pred_s, 3),
        is_feasible=feasible,
        limiting_factor=limiting,
        cost_per_tonne_gbp=round(cost_per_tonne, 1)
    )

@app.get("/api/heats/active")
def get_active_heat():
    return current_heat

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
