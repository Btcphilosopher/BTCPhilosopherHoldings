"""HDF5 run store (streams large histories to disk; never holds the full 4D history in RAM).
Layout:  /history/{times,T,f_alpha}  (resizable, chunked per snapshot)   /fields/<name> (3D, gzip)   /grid/{role,mat,act}
         /fill/<arrays>   /stress/<arrays>   attrs: manifest, scenario, results, criteria, timeline (JSON strings)"""
from __future__ import annotations
import json
import numpy as np
import h5py

class RunStore:
    def __init__(self, path, mode="w"):
        self.path = str(path); self.f = h5py.File(self.path, mode)
        self._n = 0
    # ---- history ----
    def init_history(self, n_act):
        h = self.f.require_group("history")
        h.create_dataset("times", shape=(0,), maxshape=(None,), dtype="f8")
        h.create_dataset("T", shape=(0, n_act), maxshape=(None, n_act), dtype="f4", chunks=(1, n_act), compression="gzip", compression_opts=1)
        h.create_dataset("f_alpha", shape=(0, n_act), maxshape=(None, n_act), dtype="f4", chunks=(1, n_act), compression="gzip", compression_opts=1)
    def append_history(self, t, T, fa):
        h = self.f["history"]; n = h["times"].shape[0]
        for k in ("times", "T", "f_alpha"): h[k].resize(n + 1, axis=0)
        h["times"][n] = t; h["T"][n] = T.astype(np.float32); h["f_alpha"][n] = fa.astype(np.float32); self._n = n + 1
    def truncate_history(self, n):
        h = self.f["history"]
        for k in ("times", "T", "f_alpha"): h[k].resize(n, axis=0)
        self._n = n
    @property
    def n_history(self):
        if "history" not in self.f: return 0
        return int(self.f["history"]["times"].shape[0])
    def times(self): return self.f["history"]["times"][:]
    def read_T(self, idx): return self.f["history"]["T"][idx]
    def read_f_alpha(self, idx): return self.f["history"]["f_alpha"][idx]
    # ---- generic ----
    def write_array(self, group, name, arr, compress=True):
        g = self.f.require_group(group)
        if name in g: del g[name]
        arr = np.asarray(arr)
        kw = dict(compression="gzip", compression_opts=2) if (compress and arr.ndim >= 1 and arr.size > 64) else {}
        g.create_dataset(name, data=arr, **kw)
    def write_json(self, name, obj): self.f.attrs[name] = json.dumps(obj, default=_jd)
    def close(self):
        try: self.f.flush(); self.f.close()
        except Exception: pass

def _jd(o):
    if isinstance(o, (np.floating,)): return float(o)
    if isinstance(o, (np.integer,)): return int(o)
    if isinstance(o, (np.bool_,)): return bool(o)
    if isinstance(o, np.ndarray): return o.tolist()
    return str(o)
