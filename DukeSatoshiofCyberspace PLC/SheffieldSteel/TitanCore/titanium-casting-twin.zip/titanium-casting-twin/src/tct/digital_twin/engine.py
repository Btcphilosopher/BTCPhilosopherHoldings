"""Time-series engine: step / run / pause / resume / rewind / replay with disk-backed snapshots and in-memory checkpoints.

Snapshot times are a deterministic function of the previous snapshot time  t_next = t + max(min_dt, growth * t),  so a
rewind-and-resume (restore the nearest earlier checkpoint, re-run) reproduces exactly the same history.
"""
from __future__ import annotations
import numpy as np
from ..thermal.solver import ThermalSolver

class TimeSeriesEngine:
    def __init__(self, solver: ThermalSolver, store, growth=0.05, min_dt=1.0, t_max=4000.0, stop_T_C=300.0, checkpoint_every=20,
                 callback=None):
        self.solver, self.store = solver, store
        self.growth, self.min_dt, self.t_max, self.stop_T = growth, min_dt, t_max, stop_T_C
        self.checkpoint_every = checkpoint_every
        self.checkpoints: dict[int, dict] = {}
        self.cursor = -1
        self._paused = False
        self.callback = callback
        if store.n_history == 0: store.init_history(len(solver.T))
        if store.n_history == 0: self._record()

    def _record(self):
        s = self.solver
        self.store.append_history(s.t, s.T, s.f_alpha)
        idx = self.store.n_history - 1
        if idx % self.checkpoint_every == 0: self.checkpoints[idx] = s.checkpoint()
        self.cursor = idx
        if self.callback: self.callback(idx, s.t)
        return idx

    def next_time(self):
        t = self.solver.t; return t + max(self.min_dt, self.growth * t)

    @property
    def finished(self): return self.solver.max_metal_T() < self.stop_T or self.solver.t >= self.t_max - 1e-9

    def step(self):
        if self.finished: return None
        self.solver.advance_to(min(self.next_time(), self.t_max))
        return self._record()

    def run(self):
        self._paused = False
        while not self.finished and not self._paused: self.step()
        return self.store.n_history

    def pause(self): self._paused = True
    def resume(self): return self.run()

    def rewind(self, t):
        """Move the VIEW cursor to the last snapshot <= t. (Solver state is unchanged until restart_from is used.)"""
        times = self.store.times(); self.cursor = int(max(np.searchsorted(times, t, side="right") - 1, 0)); return self.cursor

    def restart_from(self, idx):
        """Restore the nearest checkpoint <= idx, truncate later history and deterministically re-run up to snapshot idx."""
        c = max([k for k in self.checkpoints if k <= idx], default=None)
        if c is None: raise RuntimeError("no checkpoint available at or before the requested snapshot")
        self.solver.restore(self.checkpoints[c]); self.store.truncate_history(c + 1)
        for k in [k for k in self.checkpoints if k > c]: del self.checkpoints[k]
        self.cursor = c
        while self.store.n_history - 1 < idx and not self.finished: self.step()
        return self.cursor

    def view(self, idx):
        return self.store.read_T(idx), self.store.read_f_alpha(idx), float(self.store.times()[idx])

    def replay(self, start=0, stop=None, stride=1):
        n = self.store.n_history; stop = n if stop is None else min(stop, n)
        for i in range(start, stop, stride):
            T, fa, t = self.view(i); yield t, T, fa
