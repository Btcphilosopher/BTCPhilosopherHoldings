"""RunData: read-only access to a stored run (HDF5) + DigitalTwinState construction + the 'What happened here?' query."""
from __future__ import annotations
import json
import numpy as np
import h5py
from scipy.spatial import cKDTree
from ..geometry.grid import Grid
from ..materials.database import get_alloy
from .state import DigitalTwinState

class RunData:
    def __init__(self, path):
        self.path = str(path); self.f = h5py.File(self.path, "r")
        a = self.f.attrs
        self.manifest = json.loads(a["manifest"]); self.scenario = json.loads(a["scenario"]); self.results = json.loads(a["results"])
        self.criteria = json.loads(a["criteria"]); self.timeline = json.loads(a["timeline"]); self.alloy_info = json.loads(a["alloy"])
        self.warnings = json.loads(a["warnings"]) if "warnings" in a else []
        gd = json.loads(a["grid"]); self.grid = Grid(tuple(gd["shape"]), gd["dx_m"], tuple(gd["origin_m"]))
        self.thresholds_C = json.loads(a["thresholds_C"])
        self.alloy = get_alloy(self.alloy_info["name"])
        self.role = self.f["grid/role"][:]; self.mat = self.f["grid/mat"][:]; self.act = self.f["grid/act"][:]
        self.times = self.f["history/times"][:]
        sh = self.grid.shape
        lin = (self.act[:, 0] * sh[1] + self.act[:, 1]) * sh[2] + self.act[:, 2]
        self._lin_sorted = np.argsort(lin); self._lin = lin[self._lin_sorted]
        self._fields = {}
        self._metal_tree = None
    def close(self): self.f.close()
    def __enter__(self): return self
    def __exit__(self, *a): self.close()

    @property
    def field_names(self): return sorted(self.f["fields"].keys())
    def field(self, name):
        if name not in self._fields: self._fields[name] = self.f["fields"][name][:]
        return self._fields[name]

    def act_index(self, ijk):
        sh = self.grid.shape; v = (ijk[0] * sh[1] + ijk[1]) * sh[2] + ijk[2]
        p = np.searchsorted(self._lin, v)
        return int(self._lin_sorted[p]) if p < len(self._lin) and self._lin[p] == v else None

    def to_grid(self, a1d, fill=np.nan):
        out = np.full(self.grid.shape, fill, np.float32); out[tuple(self.act.T)] = a1d; return out

    def temperature_at_index(self, i): return self.to_grid(self.f["history/T"][i])
    def snapshot_index(self, t): return int(max(np.searchsorted(self.times, t, side="right") - 1, 0))

    # ---------- timeline ----------
    def stage_at(self, t_proc):
        for s in self.timeline:
            if s["t0"] <= t_proc < s["t1"]: return s, t_proc - s["t0"]
        return self.timeline[-1], self.timeline[-1]["t1"] - self.timeline[-1]["t0"]
    @property
    def process_duration(self): return self.timeline[-1]["t1"]

    def state_at(self, t_proc) -> DigitalTwinState:
        st, tl = self.stage_at(t_proc)
        s = DigitalTwinState(geometry={"grid": self.grid.to_dict(), "volumes_m3": self.results["geometry"]["volumes_m3"],
                                       "geometry_hash": self.manifest["geometry_hash"], "mesh_hash": self.manifest["mesh_hash"]},
                             material={"name": self.alloy_info["name"], "hash": self.alloy_info["hash"], "estimated_fraction": self.alloy_info["estimated_fraction"]},
                             process_parameters=self.scenario, time=float(t_proc), stage=st["name"], manifest=self.manifest)
        if st["kind"] == "fill":
            ft = self.f["fill/snap_times"][:]; k = int(np.clip(np.searchsorted(ft, tl, side="right") - 1, 0, len(ft) - 1))
            cells = self.f["fill/cells"][:]
            def c3(a, extra=()):
                out = np.full(self.grid.shape + extra, np.nan, np.float32); out[tuple(cells.T)] = a; return out
            s.fill_fraction = c3(self.f["fill/snap_fill_fraction"][k]); s.temperature_field = c3(self.f["fill/snap_temperature_C"][k])
            s.velocity_field = c3(self.f["fill/snap_velocity_m_s"][k], (3,)); s.pressure_field = c3(self.f["fill/snap_pressure_Pa"][k])
        elif st["kind"] == "thermal":
            i = self.snapshot_index(tl + (0.0 if st["name"] == "SOLIDIFICATION" else self._t_sol_end())) if st["name"] == "COOL" else self.snapshot_index(tl)
            T = self.f["history/T"][i]; s.temperature_field = self.to_grid(T)
            fs = self.alloy.solid_fraction(T); fsm = np.where(self.mat[tuple(self.act.T)] == 1, fs, np.nan); s.solid_fraction = self.to_grid(fsm)
            s.microstructure = {"alpha_fraction": self.to_grid(self.f["history/f_alpha"][i])}
        elif st["kind"] == "ht":
            pr = self.f["ht"]; Tt = float(np.interp(tl, pr["t_s"][:], pr["T_C"][:])) if "ht" in self.f else 20.0
            Tf = np.where(self.mat > 0, Tt, np.nan).astype(np.float32); s.temperature_field = Tf
        # static results
        if st["name"] in ("HEAT TREAT", "INSPECT", "COOL", "SOLIDIFICATION"):
            for k in ("lath_thickness_um", "morphology_class", "alpha_fraction"):
                if k in self.f["fields"]: s.microstructure[k] = self.field(k)
            for k in ("porosity_risk", "predicted_void_fraction", "feeding_risk"):
                if k in self.f["fields"]: s.porosity[k] = self.field(k)
            s.shrinkage = {k: self.field(k) for k in ("feeding_map", "macro_shrinkage_void_fraction") if k in self.f["fields"]}
            for k in ("residual_vm_Pa", "residual_principal1_Pa", "residual_sxx_Pa", "residual_syy_Pa", "residual_szz_Pa"):
                if k in self.f["fields"]: s.stress[k] = self.field(k)
            s.strain = {k: self.field(k) for k in ("plastic_strain_eq",) if k in self.f["fields"]}
            for k in ("distortion_dx_m", "distortion_dy_m", "distortion_dz_m", "distortion_mag_m"):
                if k in self.f["fields"]: s.distortion[k] = self.field(k)
        s.inspection = self.results.get("inspection", {})
        s.quality_indicators = self.criteria
        return s
    def _t_sol_end(self): return float(self.results["solidification"]["solidification_time_part_max_s"])

    # ---------- query ----------
    def nearest_metal_cell(self, xyz_m):
        if self._metal_tree is None:
            idx = np.argwhere(self.mat == 1); self._metal_idx = idx
            self._metal_tree = cKDTree(self.grid.origin_m + (idx + 0.5) * self.grid.dx_m)
        d, k = self._metal_tree.query(np.asarray(xyz_m, float))
        return tuple(int(x) for x in self._metal_idx[k]), float(d)

    def query(self, xyz_m, inspect_radius_m=6e-3):
        """What happened here?  Answered entirely from the stored simulation history of the nearest metal cell."""
        ijk, dist = self.nearest_metal_cell(xyz_m)
        ai = self.act_index(ijk)
        F = lambda n: (float(self.field(n)[ijk]) if n in self.f["fields"] else None)
        out = {"requested_xyz_mm": [float(x) * 1e3 for x in xyz_m], "cell_ijk": list(ijk),
               "cell_centre_mm": [float(x) * 1e3 for x in self.grid.center_of(ijk)], "snap_distance_mm": dist * 1e3,
               "role": {1: "part", 2: "riser", 3: "gate", 4: "runner", 5: "sprue", 6: "basin", 7: "filter"}.get(int(self.role[ijk]), "other")}
        T = self.f["history/T"][:, ai].astype(float); t = self.times
        cr = -np.gradient(T, t) if len(t) > 2 else np.zeros_like(T)
        fs = self.alloy.solid_fraction(T)
        fa = self.f["history/f_alpha"][:, ai].astype(float)
        out["thermal"] = {"t_s": t.tolist(), "T_C": T.tolist(), "cooling_rate_K_s": cr.tolist(), "solid_fraction": fs.tolist(), "alpha_fraction": fa.tolist(),
                          "peak_T_C": F("peak_temperature_C"), "time_above_beta_s": F("time_above_beta_s")}
        out["fill"] = {"arrival_time_s": F("fill_arrival_time_s"), "arrival_T_C": F("fill_T_arrival_C"), "front_speed_m_s": F("fill_front_speed_m_s"),
                       "misrun_risk": F("misrun_risk"), "cold_shut_risk": F("cold_shut_risk"), "air_entrainment_index": F("air_entrainment_index"),
                       "reynolds": F("reynolds")}
        out["solidification"] = {k: F(k) for k in ("t_liquidus_s", "t_solidus_s", "local_solidification_time_s", "cooling_rate_liquidus_K_s",
                                                   "thermal_gradient_K_m", "front_velocity_m_s", "niyama_sqrtKs_mm", "cooling_rate_beta_K_s")}
        out["feeding"] = {k: F(k) for k in ("feeding_distance_m", "isolation_time_s", "feeding_risk", "macro_shrinkage_void_fraction")}
        fm = F("feeding_map"); out["feeding"]["feeding_map"] = {0: "n/a", 1: "fed", 2: "fed-marginal", 3: "ISOLATED"}.get(int(fm) if fm is not None and np.isfinite(fm) else 0)
        out["porosity"] = {k: F(k) for k in ("porosity_risk", "predicted_void_fraction", "microshrinkage_risk", "macroshrinkage_risk", "gas_risk_hydrogen", "gas_risk_entrained")}
        out["microstructure"] = {k: F(k) for k in ("lath_thickness_um", "alpha_fraction", "morphology_class", "yield_estimate_MPa", "prior_beta_indicator")}
        mc = F("morphology_class"); out["microstructure"]["morphology"] = {0: "n/a", 1: "colony alpha", 2: "Widmanstatten", 3: "basketweave/massive", 4: "martensitic alpha'"}.get(int(mc) if mc is not None and np.isfinite(mc) else 0)
        # stress history
        st = {"residual_vm_Pa": F("residual_vm_Pa"), "principal1_Pa": F("residual_principal1_Pa"), "principal3_Pa": F("residual_principal3_Pa"),
              "components_Pa": {n: F(f"residual_{n}_Pa") for n in ("sxx", "syy", "szz", "txy", "tyz", "tzx")}, "plastic_strain_eq": F("plastic_strain_eq")}
        if "stress" in self.f:
            cells = self.f["stress/cells"][:]
            m = np.flatnonzero((cells == np.array(ijk)).all(axis=1))
            if m.size:
                st["history_times_s"] = self.f["stress/step_times"][:].tolist(); st["history_vm_Pa"] = self.f["stress/vm_hist"][:, m[0]].astype(float).tolist()
        st["vm_after_heat_treatment_Pa"] = F("residual_vm_after_ht_Pa")
        out["stress"] = st
        out["distortion"] = {k: F(k) for k in ("distortion_dx_m", "distortion_dy_m", "distortion_dz_m", "distortion_mag_m", "local_rotation_rad")}
        out["machining"] = {"alpha_case_depth_m": F("alpha_case_depth_m"), "margin_m": F("machining_margin_m")}
        c = self.grid.center_of(ijk); near = []
        for ind in self.results.get("inspection", {}).get("indications", []):
            d = float(np.linalg.norm(np.array(ind["centroid_m"]) - c))
            if d <= inspect_radius_m + 0.5 * ind["d_eq_m"]:
                near.append({k: ind[k] for k in ind if k.startswith("pod_") or k.startswith("detected_expected") or k in ("d_eq_m", "mechanism", "depth_m", "id")} | {"distance_m": d})
        out["inspection"] = {"simulated": True, "indications_nearby": near}
        return out

def format_query(q) -> str:
    L = []; a = L.append
    th = q["thermal"]; Tn = np.array(th["T_C"], float); t = np.array(th["t_s"])
    fmt = lambda v, f="{:.3g}", none="n/a": none if v is None or (isinstance(v, float) and not np.isfinite(v)) else f.format(v)
    a(f"WHAT HAPPENED HERE?   cell {q['cell_ijk']}  at {', '.join(f'{x:.1f}' for x in q['cell_centre_mm'])} mm  [{q['role']}]  (snap {q['snap_distance_mm']:.1f} mm)")
    a("-" * 92)
    f = q["fill"]
    a(f"FILL            metal arrived at {fmt(f['arrival_time_s'])} s, {fmt(f['arrival_T_C'], '{:.0f}')} C, front speed {fmt(f['front_speed_m_s'])} m/s, Re {fmt(f['reynolds'], '{:.0f}')}")
    a(f"                misrun {fmt(f['misrun_risk'])}  cold-shut {fmt(f['cold_shut_risk'])}  air-entrainment index {fmt(f['air_entrainment_index'])}   [REDUCED-ORDER / indicators]")
    s = q["solidification"]
    a(f"THERMAL         peak {fmt(th['peak_T_C'], '{:.0f}')} C; liquidus at {fmt(s['t_liquidus_s'])} s, solidus at {fmt(s['t_solidus_s'])} s  (local solidification time {fmt(s['local_solidification_time_s'])} s)")
    a(f"                cooling rate at liquidus {fmt(s['cooling_rate_liquidus_K_s'])} K/s; gradient {fmt(None if s['thermal_gradient_K_m'] is None else s['thermal_gradient_K_m']/1e3)} K/mm; 1000->800 C cooling rate {fmt(s['cooling_rate_beta_K_s'])} K/s")
    a(f"                temperature at end of run {Tn[-1]:.0f} C (t = {t[-1]:.0f} s); Niyama {fmt(s['niyama_sqrtKs_mm'])} (K s)^0.5/mm")
    m = q["microstructure"]
    a(f"PHASES          alpha fraction {fmt(m['alpha_fraction'])}  morphology: {m['morphology']}  lath {fmt(m['lath_thickness_um'])} um  (EMPIRICAL, uncalibrated)")
    fd = q["feeding"]
    a(f"FEEDING         {fd['feeding_map']}; distance to feeder {fmt(None if fd['feeding_distance_m'] is None else fd['feeding_distance_m']*1e3)} mm; isolation at {fmt(fd['isolation_time_s'])} s; cut-off liquid fraction {fmt(fd['feeding_risk'])}")
    p = q["porosity"]
    a(f"POROSITY        risk {fmt(p['porosity_risk'])} (micro {fmt(p['microshrinkage_risk'])}, macro {fmt(p['macroshrinkage_risk'])}, H2 {fmt(p['gas_risk_hydrogen'])}, entrained {fmt(p['gas_risk_entrained'])}); void fraction {fmt(p['predicted_void_fraction'])}")
    st = q["stress"]
    a(f"STRESS          residual von Mises {fmt(None if st['residual_vm_Pa'] is None else st['residual_vm_Pa']/1e6)} MPa; sigma1 {fmt(None if st['principal1_Pa'] is None else st['principal1_Pa']/1e6)} / sigma3 {fmt(None if st['principal3_Pa'] is None else st['principal3_Pa']/1e6)} MPa; after heat treatment {fmt(None if st['vm_after_heat_treatment_Pa'] is None else st['vm_after_heat_treatment_Pa']/1e6)} MPa")
    if "history_vm_Pa" in st:
        hv = np.array(st["history_vm_Pa"]) / 1e6
        a(f"                stress history (vM, MPa) over {len(hv)} increments: peak {hv.max():.1f} at t={st['history_times_s'][int(hv.argmax())]:.0f} s")
    d = q["distortion"]
    a(f"DISTORTION      warpage dx,dy,dz = {fmt(None if d['distortion_dx_m'] is None else d['distortion_dx_m']*1e3)}, {fmt(None if d['distortion_dy_m'] is None else d['distortion_dy_m']*1e3)}, {fmt(None if d['distortion_dz_m'] is None else d['distortion_dz_m']*1e3)} mm (after removing uniform contraction)")
    mc = q["machining"]
    a(f"MACHINING       alpha-case upper bound {fmt(None if mc['alpha_case_depth_m'] is None else mc['alpha_case_depth_m']*1e3)} mm; stock margin {fmt(None if mc['margin_m'] is None else mc['margin_m']*1e3)} mm")
    ins = q["inspection"]["indications_nearby"]
    if ins:
        for i in ins: a(f"INSPECTION      SIMULATED indication d_eq {i['d_eq_m']*1e3:.2f} mm ({i['mechanism']}) {i['distance_m']*1e3:.1f} mm away; POD CT {i.get('pod_ct',0):.2f}, X-ray {i.get('pod_xray',0):.2f}, UT {i.get('pod_ultrasonic',0):.2f}")
    else: a("INSPECTION      no simulated indication within the probe radius (SIMULATED data)")
    return "\n".join(L)
