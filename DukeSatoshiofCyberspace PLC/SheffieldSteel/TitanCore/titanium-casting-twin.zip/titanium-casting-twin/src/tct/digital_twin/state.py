"""Canonical DigitalTwinState. Everything shown by the viewer / dashboard / reports is derived from this object."""
from __future__ import annotations
from dataclasses import dataclass, field
import numpy as np

@dataclass
class DigitalTwinState:
    geometry: dict                  # casting-system summary + hashes
    material: dict                  # alloy name, hash, provenance summary
    process_parameters: dict        # scenario dump
    time: float                     # process time (s) of this view
    stage: str                      # timeline stage name
    temperature_field: np.ndarray | None = None      # (nx,ny,nz) C, NaN outside active domain
    velocity_field: np.ndarray | None = None         # (nx,ny,nz,3) m/s
    pressure_field: np.ndarray | None = None
    fill_fraction: np.ndarray | None = None
    solid_fraction: np.ndarray | None = None
    microstructure: dict = field(default_factory=dict)
    porosity: dict = field(default_factory=dict)
    shrinkage: dict = field(default_factory=dict)
    stress: dict = field(default_factory=dict)
    strain: dict = field(default_factory=dict)
    distortion: dict = field(default_factory=dict)
    inspection: dict = field(default_factory=dict)
    quality_indicators: list = field(default_factory=list)
    manifest: dict = field(default_factory=dict)
