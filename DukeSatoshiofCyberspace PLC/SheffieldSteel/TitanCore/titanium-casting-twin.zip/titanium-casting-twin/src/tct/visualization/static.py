"""Matplotlib (headless) figures derived from a RunData. Every figure is generated from stored simulation fields."""
from __future__ import annotations
import io, base64
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

PAL = {"graphite": "#2b2f33", "warm_white": "#f4f1ea", "steel": "#8a949c", "navy": "#14233b", "blue": "#3e6a9e", "amber": "#b8872e", "red": "#a63d33", "green": "#4f7a5a"}

def _style():
    plt.rcParams.update({"figure.facecolor": PAL["warm_white"], "axes.facecolor": PAL["warm_white"], "axes.edgecolor": PAL["graphite"],
                         "axes.labelcolor": PAL["graphite"], "xtick.color": PAL["graphite"], "ytick.color": PAL["graphite"],
                         "text.color": PAL["graphite"], "font.size": 8, "axes.titlesize": 9, "font.family": "DejaVu Sans"})
_style()

def fig_png(fig, dpi=110):
    buf = io.BytesIO(); fig.savefig(buf, format="png", dpi=dpi, facecolor=fig.get_facecolor(), bbox_inches="tight"); plt.close(fig)
    return buf.getvalue()
def b64(png): return base64.b64encode(png).decode()

def mid_plane(run, plane_axis=1, index=None):
    """Return the slice index through the part centroid along plane_axis."""
    if index is not None: return index
    idx = np.argwhere(run.role == 1)
    return int(round(idx[:, plane_axis].mean()))

def slice_image(a3, role, axis, index):
    sl = [slice(None)] * 3; sl[axis] = index
    A = a3[tuple(sl)]; R = role[tuple(sl)]
    keep = [i for i in range(3) if i != axis]
    return A.T if keep == [0, 2] else A.T, R.T, keep

def draw_slice(ax, run, a3, title, cmap="inferno", vmin=None, vmax=None, axis=1, index=None, label=""):
    index = mid_plane(run, axis, index)
    A, R, keep = slice_image(a3, run.role, axis, index)
    ext = [run.grid.origin_m[keep[0]] * 1e3, (run.grid.origin_m[keep[0]] + run.grid.shape[keep[0]] * run.grid.dx_m) * 1e3,
           run.grid.origin_m[keep[1]] * 1e3, (run.grid.origin_m[keep[1]] + run.grid.shape[keep[1]] * run.grid.dx_m) * 1e3]
    shell = np.where((R == 8) | (R == 9), 1.0, np.nan)
    ax.imshow(shell, origin="lower", extent=ext, cmap=matplotlib.colors.ListedColormap([PAL["steel"]]), alpha=0.35, interpolation="nearest")
    im = ax.imshow(A, origin="lower", extent=ext, cmap=cmap, vmin=vmin, vmax=vmax, interpolation="nearest")
    ax.set_title(title); ax.set_xlabel("xyz"[keep[0]] + " [mm]"); ax.set_ylabel("xyz"[keep[1]] + " [mm]"); ax.set_aspect("equal")
    return im

def field_figure(run, name, title=None, cmap="viridis", scale=1.0, unit="", axis=1, vmin=None, vmax=None):
    f = run.field(name).astype(float) * scale
    fig, ax = plt.subplots(figsize=(5.2, 4.0))
    im = draw_slice(ax, run, f, title or name, cmap, vmin, vmax, axis)
    cb = fig.colorbar(im, ax=ax, shrink=0.8); cb.set_label(unit)
    return fig

def thermal_history_figure(q):
    t = np.array(q["thermal"]["t_s"]); T = np.array(q["thermal"]["T_C"]); cr = np.array(q["thermal"]["cooling_rate_K_s"])
    fig, ax = plt.subplots(2, 1, figsize=(5.6, 4.4), sharex=True)
    ax[0].plot(t, T, color=PAL["navy"], lw=1.6)
    for k, c in (("t_liquidus_s", PAL["amber"]), ("t_solidus_s", PAL["red"])):
        v = q["solidification"].get(k)
        if v is not None and np.isfinite(v): ax[0].axvline(v, color=c, lw=0.8, ls="--")
    ax[0].set_ylabel("Temperature [C]"); ax[0].grid(alpha=0.25)
    ax[1].plot(t, np.clip(cr, 0, None), color=PAL["blue"], lw=1.2); ax[1].set_ylabel("Cooling rate [K/s]"); ax[1].set_xlabel("t [s]"); ax[1].grid(alpha=0.25)
    ax[1].set_xscale("symlog", linthresh=10)
    return fig

def timeline_figure(run):
    fig, ax = plt.subplots(figsize=(8, 1.1))
    tot = run.process_duration; cols = [PAL["steel"], PAL["blue"], PAL["amber"], PAL["navy"], PAL["blue"], PAL["red"], PAL["steel"], PAL["green"], PAL["graphite"]]
    for i, s in enumerate(run.timeline):
        w = max(s["t1"] - s["t0"], tot * 0.02)
        ax.barh(0, 1, left=i, color=cols[i % len(cols)], edgecolor=PAL["warm_white"])
        ax.text(i + 0.5, 0, f'{s["name"]}\n{s["t1"]-s["t0"]:.0f}s', ha="center", va="center", color="white", fontsize=6)
    ax.set_xlim(0, len(run.timeline)); ax.axis("off")
    return fig

def distortion_figure(run, amplification=200.0):
    sr = run.f["stress"]; X = sr["node_xyz"][:]; res = sr["node_residual"][:]; en = sr["elem_nodes"][:]; cells = sr["cells"][:]
    part = run.role[tuple(cells.T)] == 1
    fig, ax = plt.subplots(1, 2, figsize=(8.5, 3.6))
    for k, (a, b, nm) in enumerate(((0, 2, "x-z"), (1, 2, "y-z"))):
        nodes = np.unique(en[part].ravel()); P = X[nodes]; W = P + amplification * res[nodes]
        ax[k].scatter(P[:, a] * 1e3, P[:, b] * 1e3, s=1.2, color=PAL["steel"], label="nominal (as designed)")
        ax[k].scatter(W[:, a] * 1e3, W[:, b] * 1e3, s=1.2, color=PAL["red"], alpha=0.6, label=f"predicted (x{amplification:.0f} warpage)")
        ax[k].set_aspect("equal"); ax[k].set_title(f"Nominal vs predicted as-cast, {nm}"); ax[k].set_xlabel(nm[0] + " [mm]"); ax[k].set_ylabel(nm[2] + " [mm]")
    ax[0].legend(fontsize=6, loc="upper left", markerscale=4)
    return fig

def stress_maps_figure(run):
    names = [("residual_sxx_Pa", "sigma_x"), ("residual_syy_Pa", "sigma_y"), ("residual_szz_Pa", "sigma_z"), ("residual_txy_Pa", "tau_xy"),
             ("residual_vm_Pa", "von Mises"), ("residual_principal1_Pa", "principal 1")]
    fig, axs = plt.subplots(2, 3, figsize=(10.5, 6.2))
    for ax, (n, t) in zip(axs.ravel(), names):
        a = run.field(n).astype(float) / 1e6
        v = max(np.nanmax(np.abs(a)), 1e-3)
        cm = "magma" if n.endswith("vm_Pa") else "RdBu_r"
        im = draw_slice(ax, run, a, t + " [MPa]", cm, 0 if cm == "magma" else -v, v)
        fig.colorbar(im, ax=ax, shrink=0.75)
    fig.tight_layout(); return fig

def solidification_map_figure(run):
    fig, axs = plt.subplots(1, 3, figsize=(11, 3.6))
    cls = run.field("solidification_class").astype(float); cls[cls == 0] = np.nan
    im = draw_slice(axs[0], run, cls, "Solidification map (1 early, 2 mushy, 3 late)", matplotlib.colors.ListedColormap([PAL["blue"], PAL["amber"], PAL["red"]]), 0.5, 3.5)
    t = run.field("t_solidus_s").astype(float); im2 = draw_slice(axs[1], run, t, "Time to solidus [s]", "cividis"); fig.colorbar(im2, ax=axs[1], shrink=0.75)
    fm = run.field("feeding_map").astype(float); fm[fm == 0] = np.nan
    draw_slice(axs[2], run, fm, "Feeding map (1 fed, 2 marginal, 3 isolated)", matplotlib.colors.ListedColormap([PAL["green"], PAL["amber"], PAL["red"]]), 0.5, 3.5)
    fig.tight_layout(); return fig

def frames_for_slider(run, n_thermal=14, size=(3.4, 2.7)):
    """Pre-rendered mid-plane frames across the whole manufacturing timeline: [(t_proc, stage, png_bytes), ...]."""
    frames = []; vmin, vmax = 20.0, float(run.alloy_info["T_liquidus_C"]) + 250.0
    def render(T3, title, cmap="inferno", lo=vmin, hi=vmax, extra=None):
        fig, ax = plt.subplots(figsize=size)
        im = draw_slice(ax, run, T3, title, cmap, lo, hi)
        fig.colorbar(im, ax=ax, shrink=0.8, pad=0.02)
        return fig_png(fig, 70)
    for s in run.timeline:
        if s["kind"] == "melt":
            T = np.where(run.mat > 0, np.nan, np.nan)
            frames.append((s["t0"], s["name"], None)); continue
    st_fill = [s for s in run.timeline if s["kind"] == "fill"][0]
    ft = run.f["fill/snap_times"][:]; cells = run.f["fill/cells"][:]
    for k in np.linspace(1, len(ft) - 1, 6).astype(int):
        T3 = np.full(run.grid.shape, np.nan, np.float32); T3[tuple(cells.T)] = run.f["fill/snap_temperature_C"][k]
        frames.append((st_fill["t0"] + float(ft[k]), "FILL", render(T3, f"FILL  t={ft[k]:.2f} s  Temperature [C]")))
    st_sol = [s for s in run.timeline if s["name"] == "SOLIDIFICATION"][0]; st_cool = [s for s in run.timeline if s["name"] == "COOL"][0]
    tsol = run._t_sol_end(); times = run.times
    tt = np.unique(np.concatenate([np.geomspace(max(times[1], 1.0), times[-1], n_thermal)]))
    for t in tt:
        i = run.snapshot_index(t); T3 = run.temperature_at_index(i)
        name = "SOLIDIFICATION" if t < tsol else "COOL"
        t_proc = (st_sol["t0"] + t) if t < tsol else (st_cool["t0"] + (t - tsol))
        frames.append((t_proc, name, render(T3, f"{name}  t={times[i]:.0f} s  Temperature [C]")))
    ht = [s for s in run.timeline if s["name"] == "HEAT TREAT"][0]
    if "lath_thickness_um_ht" in run.f["fields"]:
        a = run.field("lath_thickness_um_ht").astype(float)
        frames.append((ht["t0"], "HEAT TREAT", render(a, "HEAT TREAT  alpha-lath thickness [um] (EMPIRICAL)", "viridis", 0, float(np.nanmax(a)) * 1.2)))
    ins = [s for s in run.timeline if s["name"] == "INSPECT"][0]
    pv_ = run.field("predicted_void_fraction").astype(float)
    frames.append((ins["t0"], "INSPECT", render(pv_, "INSPECT  predicted void fraction (SIMULATED NDE basis)", "magma", 0, max(float(np.nanmax(pv_)), 1e-3))))
    return frames
