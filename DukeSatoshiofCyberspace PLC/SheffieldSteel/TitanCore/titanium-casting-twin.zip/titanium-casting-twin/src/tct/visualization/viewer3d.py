"""PyVista 3D digital twin. Views: Geometry, Temperature, Velocity, Fill Fraction, Solid Fraction, Porosity, Microstructure,
Stress, Distortion, Inspection. Interactions: rotate/zoom (native), slice, clip, threshold, probe-by-click ('What happened here?'),
and a process-time slider that scrubs the whole manufacturing history.

Headless use: `render_view(run, view, t_proc, png_path)` renders off-screen (used by tests and `tct inspect --png`).
Interactive use: `launch(run)`; requires a display. (The interactive widgets could not be exercised in the headless build environment;
the off-screen path and the probe/query logic are tested.)"""
from __future__ import annotations
import numpy as np
from ..errors import MissingOptionalDependency

def _pv():
    try:
        import pyvista as pv; return pv
    except Exception as e:
        raise MissingOptionalDependency("PyVista is required for the 3D viewer: pip install pyvista") from e

VIEWS = {  # view: (stage-dependent source, cmap, label)
    "geometry": ("role", "tab10", "role"), "temperature": ("T", "inferno", "T [C]"), "velocity": ("vmag", "viridis", "|v| [m/s]"),
    "fill_fraction": ("ff", "Blues", "fill fraction"), "solid_fraction": ("fs", "coolwarm", "solid fraction"),
    "porosity": ("porosity_risk", "magma", "porosity risk (indicator)"), "microstructure": ("lath_thickness_um", "viridis", "alpha-lath [um] (EMPIRICAL)"),
    "stress": ("residual_vm_Pa", "turbo", "residual von Mises [Pa]"), "distortion": ("distortion_mag_m", "plasma", "warpage [m]"),
    "inspection": ("predicted_void_fraction", "magma", "predicted void fraction (SIMULATED NDE basis)")}

def build_grid(run, mask=None):
    pv = _pv(); g = run.grid
    grid = pv.ImageData(dimensions=tuple(s + 1 for s in g.shape), spacing=(g.dx_m * 1e3,) * 3, origin=tuple(o * 1e3 for o in g.origin_m))
    m = (run.mat == 1) if mask is None else mask
    grid.cell_data["metal"] = m.ravel(order="F").astype(np.uint8)
    grid.cell_data["role"] = run.role.ravel(order="F").astype(np.float32)
    return grid, m

def view_array(run, view, t_proc):
    st = run.state_at(t_proc); src = VIEWS[view][0]
    if src == "role": return run.role.astype(np.float32)
    if src == "T": return st.temperature_field
    if src == "vmag": return None if st.velocity_field is None else np.linalg.norm(st.velocity_field, axis=-1)
    if src == "ff": return st.fill_fraction if st.fill_fraction is not None else np.where(run.mat == 1, 1.0, np.nan)
    if src == "fs": return st.solid_fraction
    return run.field(src)

def extract(run, view, t_proc, clip=None, threshold=None):
    pv = _pv(); grid, m = build_grid(run)
    a = view_array(run, view, t_proc)
    if a is None: a = np.full(run.grid.shape, np.nan, np.float32)
    grid.cell_data["value"] = np.asarray(a, np.float32).ravel(order="F")
    sub = grid.extract_cells(np.flatnonzero(m.ravel(order="F") & np.isfinite(grid.cell_data["value"]) if view != "geometry" else m.ravel(order="F")))
    if threshold is not None: sub = sub.threshold(threshold, scalars="value")
    if clip is not None: sub = sub.clip(normal=clip[0], origin=clip[1])
    return sub

def render_view(run, view="temperature", t_proc=None, png_path="view.png", clip=None, threshold=None, size=(900, 700)):
    pv = _pv(); pv.OFF_SCREEN = True
    t_proc = run.process_duration * 0.5 if t_proc is None else t_proc
    sub = extract(run, view, t_proc, clip, threshold)
    pl = pv.Plotter(off_screen=True, window_size=size); pl.set_background("#f4f1ea")
    if sub.n_cells == 0: pl.add_text("no data for this view/time", color="#2b2f33")
    else:
        pl.add_mesh(sub, scalars="value", cmap=VIEWS[view][1], show_edges=False, scalar_bar_args={"title": VIEWS[view][2], "color": "#2b2f33"})
    pl.add_text(f"{view}  |  {run.state_at(t_proc).stage}  t={t_proc:.1f}s", font_size=9, color="#2b2f33")
    pl.camera_position = "iso"; pl.screenshot(png_path); pl.close(); return png_path

def probe_text(run, point_mm):
    from ..digital_twin.run_data import format_query
    return format_query(run.query(np.asarray(point_mm) * 1e-3))

def launch(run, view="temperature"):
    pv = _pv(); state = {"view": view, "t": 0.0, "clip": False}
    pl = pv.Plotter(window_size=(1200, 800)); pl.set_background("#f4f1ea")
    def redraw(*_):
        pl.clear(); sub = extract(run, state["view"], state["t"], clip=(("x", None) if False else None))
        if sub.n_cells: pl.add_mesh(sub, scalars="value", cmap=VIEWS[state["view"]][1], show_edges=False, pickable=True, name="casting")
        pl.add_text(f"{state['view']} | {run.state_at(state['t']).stage} | t={state['t']:.1f}s", name="hud", font_size=9, color="#2b2f33")
    def on_t(v): state["t"] = float(v); redraw()
    pl.add_slider_widget(on_t, [0.0, run.process_duration], value=0.0, title="process time [s]", pointa=(0.1, 0.06), pointb=(0.6, 0.06))
    for i, v in enumerate(VIEWS):
        pl.add_checkbox_button_widget(lambda flag, v=v: (state.update(view=v), redraw()), value=(v == view), position=(10, 10 + 36 * i), size=24)
    def pick(point):
        if point is None: return
        print(probe_text(run, point))
    pl.enable_point_picking(callback=pick, show_message="click a point on the casting: 'what happened here?'", left_clicking=True, pickable_window=False)
    redraw(); pl.show()
