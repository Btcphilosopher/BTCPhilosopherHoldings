"""Ti-6242S (Ti-6Al-2Sn-4Zr-2Mo-0.1Si): the silicon-bearing, creep-resistant variant.
NOTE: 'Ti-6242' and 'Ti-6Al-2Sn-4Zr-2Mo' name the same nominal composition; the distinct, useful variant
to register separately is the Si-bearing 6242S. Derived/ESTIMATED from Ti-6Al-4V."""
from ._derive import derive
from . import ti64
def build():
    return derive(ti64.build(), "Ti-6242S", {"Ti": 85.8, "Al": 6.0, "Sn": 2.0, "Zr": 4.0, "Mo": 2.0, "Si": 0.1},
                  liquidus=1672.0, solidus=1612.0, beta=1000.0,
                  scale={"yield_strength": 1.08, "density": 1.04})
