"""Enthalpy utilities for the alloy.

    h(T)  = integral_{T_ref}^{T} cp(T') dT'  +  L * (1 - fs(T))          [J/kg]
    Hv(T) = rho_ref * h(T)                                               [J/m^3]
with a FIXED reference density rho_ref per cell (mass is conserved by the fixed grid; density change
is handled by the shrinkage model, not by the conduction solver). h is strictly increasing in T,
which makes the inverse T(h) well defined and the explicit enthalpy scheme exactly conservative.
Validity: reduced-order; latent heat released per the fs(T) law (lever / power) inside [T_solidus, T_liquidus].
"""
from __future__ import annotations
import numpy as np

def solid_fraction(T_C, T_solidus_C, T_liquidus_C, exponent: float = 1.0):
    T = np.asarray(T_C, float)
    x = np.clip((T_liquidus_C - T) / (T_liquidus_C - T_solidus_C), 0.0, 1.0)
    return x ** exponent

def specific_enthalpy_table(T_grid_C, cp_fn, L_J_kg, fs_fn, T_ref_C=0.0):
    """Return h(T) on T_grid_C (J/kg), with h(T_ref)=0 for the sensible part, plus latent term L*(1-fs)."""
    T = np.asarray(T_grid_C, float)
    cp = cp_fn(T)
    sens = np.concatenate([[0.0], np.cumsum(0.5 * (cp[1:] + cp[:-1]) * np.diff(T))])
    sens -= np.interp(T_ref_C, T, sens)
    return sens + L_J_kg * (1.0 - fs_fn(T))
