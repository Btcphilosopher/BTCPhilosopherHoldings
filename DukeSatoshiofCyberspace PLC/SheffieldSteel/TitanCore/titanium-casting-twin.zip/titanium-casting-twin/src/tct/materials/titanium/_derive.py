"""Helper to derive a variant alloy from Ti-6Al-4V. All derived numbers are tagged `estimated`.

The variant keeps the Ti-6Al-4V tables but re-tags them as estimated (scaled), and overrides the
transformation temperatures with ESTIMATED values. This is a placeholder framework: replace with user-supplied
or measured data (tct supports YAML overrides, see materials/database.py).
"""
from dataclasses import replace
from ..properties import TabulatedProperty, Provenance, scalar

def derive(base, name, composition, liquidus, solidus, beta, latent=None, scale=None, note=""):
    scale = scale or {}
    tables = {}
    for k, t in base.tables.items():
        f = scale.get(k, 1.0)
        Tm = tuple({1605: solidus, 1655: liquidus}.get(int(x), x) for x in t.T_C)   # move freezing-range knots
        tables[k] = TabulatedProperty(t.name, t.unit, Tm, tuple(v * f for v in t.values),
                                      Provenance("estimated", f"scaled from {base.name} ({t.provenance.source})",
                                                 note or "placeholder pending user-supplied/measured data"))
    E = "estimated"; why = "estimated variant; replace with supplier/DSC/CALPHAD data"
    return replace(base, name=name, composition_wt=composition,
                   liquidus=scalar("liquidus", liquidus, "C", E, why), solidus=scalar("solidus", solidus, "C", E, why),
                   beta_transus=scalar("beta_transus", beta, "C", E, why + " (typical handbook beta transus)"),
                   latent_heat=scalar("latent_heat", latent or base.L_J_kg, "J/kg", E, "assumed equal to Ti-6Al-4V" if latent is None else why),
                   tables=tables)
