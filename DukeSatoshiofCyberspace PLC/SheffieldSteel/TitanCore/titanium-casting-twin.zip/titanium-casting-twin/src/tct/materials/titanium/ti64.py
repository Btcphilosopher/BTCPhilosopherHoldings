"""Ti-6Al-4V (Grade 5) property set.

SOURCE HONESTY: values below are approximate, hand-digitised from published compilations
(Mills, "Recommended Values of Thermophysical Properties for Selected Commercial Alloys", 2002;
Boivineau et al., Int. J. Thermophys. 27 (2006) pulse-heating data; ASM Handbook Vol. 2/Ti data sheets).
They are tagged `literature-derived` ONLY where they follow a published trend; elevated-temperature
mechanical properties and emissivity are `estimated`. VERIFY AGAINST YOUR SPECIFICATION / DSC / supplier data
before quantitative use; `tct validate` reports the estimated fraction of every alloy.
"""
from ..alloy import Alloy
from ..properties import table, scalar

LIT = "literature-derived"; EST = "estimated"
SRC_M = "Mills (2002) / Boivineau et al. (2006), approximate digitisation"

def build() -> Alloy:
    t = {
        "density": table("density", "kg/m^3",
            [(20, 4430), (400, 4370), (800, 4300), (1200, 4235), (1605, 4170), (1655, 3920), (1800, 3820), (2300, 3480)],
            LIT, SRC_M, "solid linear in T; liquid ~3920 kg/m^3 at liquidus, -0.68 kg/m^3/K; jump across freezing range is physical"),
        "specific_heat": table("specific_heat", "J/(kg K)",
            [(20, 546), (200, 584), (400, 625), (600, 665), (800, 710), (995, 760), (1200, 800), (1605, 870), (1655, 831), (2300, 831)],
            LIT, SRC_M, "sensible part only; latent heat carried separately; alpha->beta enthalpy not resolved (note)"),
        "thermal_conductivity": table("thermal_conductivity", "W/(m K)",
            [(20, 6.7), (200, 9.0), (400, 12.0), (600, 15.5), (800, 19.0), (995, 23.0), (1200, 27.0), (1605, 33.0), (1655, 33.0), (2300, 38.0)],
            LIT, SRC_M, "liquid value uncertain (+/-20%); electronic contribution via Wiedemann-Franz not enforced"),
        "electrical_resistivity": table("electrical_resistivity", "ohm m",
            [(20, 1.70e-6), (400, 1.75e-6), (800, 1.68e-6), (1200, 1.68e-6), (1605, 1.70e-6), (1655, 1.70e-6), (2300, 1.90e-6)],
            LIT, "Boivineau et al. (2006), approximate"),
        "viscosity": table("viscosity", "Pa s",
            [(1655, 3.5e-3), (1800, 3.1e-3), (2000, 2.6e-3), (2300, 2.2e-3)],
            EST, "Arrhenius-type extrapolation near ~3.4 mPa s at liquidus", "defined for liquid only; mushy zone via Krieger-Dougherty (EMPIRICAL)"),
        "surface_tension": table("surface_tension", "N/m",
            [(1655, 1.40), (1800, 1.36), (2000, 1.30), (2300, 1.22)],
            LIT, "Mills (2002), approximate slope -0.28 mN/m/K"),
        "elastic_modulus": table("elastic_modulus", "Pa",
            [(20, 114e9), (200, 105e9), (400, 96e9), (600, 87e9), (800, 70e9), (995, 40e9), (1200, 10e9), (1600, 1e9), (2300, 1e8)],
            EST, "ASM data to ~600 C; above that estimated (alpha->beta softening, creep-dominated)"),
        "poisson_ratio": table("poisson_ratio", "-",
            [(20, 0.342), (600, 0.35), (1000, 0.36), (1600, 0.38), (2300, 0.40)], LIT, "ASM data sheets, approximate"),
        "yield_strength": table("yield_strength", "Pa",
            [(20, 880e6), (200, 700e6), (400, 580e6), (600, 470e6), (700, 340e6), (800, 150e6), (900, 60e6), (1000, 25e6), (1200, 8e6), (1600, 1e6), (2300, 1e5)],
            EST, "cast+HIP typical RT value; high-T from hot-flow-stress ranges; strain-rate dependent in reality",
            "treated as perfectly-plastic limit in the reduced-order stress model"),
        "thermal_expansion": table("thermal_expansion", "1/K",
            [(20, 8.6e-6), (200, 9.2e-6), (400, 9.7e-6), (600, 10.2e-6), (800, 10.8e-6), (995, 11.4e-6), (1200, 12.0e-6), (1605, 12.5e-6), (2300, 12.5e-6)],
            LIT, "ASM / literature mean-CTE trends converted to instantaneous alpha, approximate"),
        "emissivity": table("emissivity", "-",
            [(20, 0.20), (600, 0.30), (1000, 0.40), (1655, 0.45), (2300, 0.45)],
            EST, "surface-condition dependent (oxide / alpha-case / vacuum-clean); calibrate to pyrometry"),
    }
    return Alloy(
        name="Ti-6Al-4V",
        composition_wt={"Ti": 89.9, "Al": 6.0, "V": 4.0, "Fe": 0.1, "O": 0.15},
        liquidus=scalar("liquidus", 1655.0, "C", LIT, "ASM / Mills (2002): ~1650-1660 C"),
        solidus=scalar("solidus", 1605.0, "C", LIT, "ASM / Mills (2002): ~1600-1610 C"),
        latent_heat=scalar("latent_heat", 286e3, "J/kg", LIT, "Mills (2002)"),
        beta_transus=scalar("beta_transus", 995.0, "C", LIT, "typical 980-1000 C; oxygen/iron dependent"),
        tables=t,
        composition_coeffs={  # ESTIMATED linear sensitivities, deg C per wt%
            "Al": {"beta_transus": 25.0, "liquidus": -2.0, "solidus": -2.0},
            "V":  {"beta_transus": -20.0, "liquidus": -6.0, "solidus": -8.0},
            "O":  {"beta_transus": 120.0, "liquidus": 8.0, "solidus": 8.0},
            "Fe": {"beta_transus": -25.0, "liquidus": -4.0, "solidus": -5.0},
        },
    )
