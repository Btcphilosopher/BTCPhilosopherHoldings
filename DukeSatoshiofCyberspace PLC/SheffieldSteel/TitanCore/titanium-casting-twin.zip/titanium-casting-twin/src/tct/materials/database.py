"""Versioned material database: builtin alloys + YAML import/export (machine-readable)."""
from __future__ import annotations
import hashlib, json, pathlib
import yaml
from .alloy import Alloy
from .titanium import ti64, ti6242, ti6242s, ti6246, ti525

DATABASE_VERSION = "0.1.0"
_BUILDERS = {"Ti-6Al-4V": ti64.build, "Ti-6242": ti6242.build, "Ti-6242S": ti6242s.build,
             "Ti-6246": ti6246.build, "Ti-5Al-2.5Sn": ti525.build}
_ALIASES = {"ti64": "Ti-6Al-4V", "ti-6al-4v": "Ti-6Al-4V", "ti6242": "Ti-6242", "ti-6al-2sn-4zr-2mo": "Ti-6242",
            "ti6242s": "Ti-6242S", "ti6246": "Ti-6246", "ti525": "Ti-5Al-2.5Sn", "ti-5al-2.5sn": "Ti-5Al-2.5Sn"}

def list_alloys(): return sorted(_BUILDERS)

def get_alloy(name: str, override_dir: str | None = None) -> Alloy:
    key = _ALIASES.get(name.lower(), name)
    if override_dir:
        p = pathlib.Path(override_dir) / f"{key}.yaml"
        if p.exists(): return load_yaml(p)
    if key not in _BUILDERS: raise KeyError(f"unknown alloy {name!r}; available: {list_alloys()}")
    return _BUILDERS[key]()

def register_alloy(name, builder): _BUILDERS[name] = builder

def alloy_hash(a: Alloy) -> str:
    return hashlib.sha256(json.dumps(a.to_dict(), sort_keys=True, default=float).encode()).hexdigest()[:16]

def dump_yaml(a: Alloy, path):
    pathlib.Path(path).write_text(yaml.safe_dump(a.to_dict(), sort_keys=False))

def load_yaml(path) -> Alloy:
    return Alloy.from_dict(yaml.safe_load(pathlib.Path(path).read_text()))
