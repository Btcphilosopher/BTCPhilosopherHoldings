"""Reduced phase model for alpha/beta titanium alloys.  MODEL STATUS: EMPIRICAL / ESTIMATED.

Equilibrium alpha fraction (saturating exponential below the beta transus):
    f_alpha_eq(T) = f_max * (1 - exp(-(T_beta - T)/T_scale))   for T < T_beta, else 0
Parameters f_max, T_scale are estimates tuned to the published shape of the Ti-6Al-4V curve
(~0.3 at 950C, ~0.5 at 900C, ~0.75 at 800C). They are NOT CALPHAD output; replace with
Thermo-Calc / Pandat tables via AlphaFractionModel(table=...) when available.
Validity: equilibrium only; for kinetic delay see materials.kinetics.
"""
from __future__ import annotations
from dataclasses import dataclass
import numpy as np
from .properties import Provenance

@dataclass(frozen=True)
class AlphaFractionModel:
    beta_transus_C: float
    f_max: float = 0.94
    T_scale_C: float = 125.0
    provenance: Provenance = Provenance("estimated", "tct reduced phase model",
                                        "shape tuned to published Ti-6Al-4V alpha-fraction curves; not CALPHAD")
    def f_alpha_eq(self, T_C):
        T = np.asarray(T_C, float)
        return np.where(T < self.beta_transus_C, self.f_max * (1.0 - np.exp(-(self.beta_transus_C - T) / self.T_scale_C)), 0.0)
