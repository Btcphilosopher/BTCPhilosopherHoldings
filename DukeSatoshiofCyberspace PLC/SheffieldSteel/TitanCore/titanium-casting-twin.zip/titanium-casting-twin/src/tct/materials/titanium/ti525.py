"""Ti-5Al-2.5Sn: near-alpha alloy with a narrow freezing range and high beta transus. ESTIMATED from Ti-6Al-4V."""
from ._derive import derive
from . import ti64
def build():
    return derive(ti64.build(), "Ti-5Al-2.5Sn", {"Ti": 92.5, "Al": 5.0, "Sn": 2.5},
                  liquidus=1680.0, solidus=1655.0, beta=1040.0,
                  scale={"yield_strength": 0.95, "density": 0.99})
