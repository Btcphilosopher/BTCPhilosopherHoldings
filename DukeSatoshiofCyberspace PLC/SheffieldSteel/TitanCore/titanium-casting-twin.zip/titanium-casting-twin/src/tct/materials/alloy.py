"""Alloy definition: temperature-dependent properties + transformation temperatures, all with provenance."""
from __future__ import annotations
from dataclasses import dataclass, field, replace
import numpy as np
from .properties import TabulatedProperty, ScalarProperty, Provenance
from .phase_diagram import AlphaFractionModel
from . import thermodynamics as thermo

T_GRID_C = np.arange(0.0, 2301.0, 1.0)    # common grid for solver lookup tables

TABLE_FIELDS = ("density", "specific_heat", "thermal_conductivity", "electrical_resistivity", "viscosity",
                "surface_tension", "elastic_modulus", "poisson_ratio", "yield_strength",
                "thermal_expansion", "emissivity")

@dataclass(frozen=True)
class Alloy:
    name: str
    composition_wt: dict
    liquidus: ScalarProperty
    solidus: ScalarProperty
    latent_heat: ScalarProperty
    beta_transus: ScalarProperty
    tables: dict                          # name -> TabulatedProperty (see TABLE_FIELDS)
    fs_exponent: float = 1.0              # fs = ((TL - T)/(TL - TS))^exponent
    hydrogen_solubility: dict = field(default_factory=dict)
    composition_coeffs: dict = field(default_factory=dict)   # d(property)/d(wt% element), ESTIMATED
    database_version: str = "0.1.0"

    # ---- scalar accessors (deg C) ----
    @property
    def T_liquidus_C(self): return float(self.liquidus.value)
    @property
    def T_solidus_C(self): return float(self.solidus.value)
    @property
    def T_beta_C(self): return float(self.beta_transus.value)
    @property
    def L_J_kg(self): return float(self.latent_heat.value)

    def phase_model(self) -> AlphaFractionModel:
        return AlphaFractionModel(beta_transus_C=self.T_beta_C)

    # ---- generic property access ----
    def __getattr__(self, item):
        t = object.__getattribute__(self, "tables")
        if item in t: return t[item]
        raise AttributeError(item)

    def solid_fraction(self, T_C):
        return thermo.solid_fraction(T_C, self.T_solidus_C, self.T_liquidus_C, self.fs_exponent)

    def density_kg_m3(self, T_C):
        """Mixture density across the mushy zone: rho = fs*rho_s(T) + (1-fs)*rho_l(T)."""
        T = np.asarray(T_C, float)
        rho = self.tables["density"]
        rho_s = rho(np.minimum(T, self.T_solidus_C))
        rho_l = rho(np.maximum(T, self.T_liquidus_C))
        fs = self.solid_fraction(T)
        return fs * rho_s + (1 - fs) * rho_l

    def apparent_viscosity_Pa_s(self, T_C, fs_max=0.6):
        """Liquid viscosity, with Krieger-Dougherty suspension law in the mushy zone (EMPIRICAL)."""
        T = np.asarray(T_C, float)
        eta_l = self.tables["viscosity"](np.maximum(T, self.T_liquidus_C))
        fs = np.clip(self.solid_fraction(T), 0.0, fs_max * 0.999)
        return eta_l * (1.0 - fs / fs_max) ** (-2.5 * fs_max)

    def specific_enthalpy_J_kg(self, T_C):
        T = np.asarray(T_C, float)
        h = thermo.specific_enthalpy_table(T_GRID_C, self.tables["specific_heat"], self.L_J_kg, self.solid_fraction)
        return np.interp(T, T_GRID_C, h)

    def enthalpy_table_J_kg(self):
        return thermo.specific_enthalpy_table(T_GRID_C, self.tables["specific_heat"], self.L_J_kg, self.solid_fraction)

    def T_from_specific_enthalpy(self, h_J_kg):
        return np.interp(np.asarray(h_J_kg, float), self.enthalpy_table_J_kg(), T_GRID_C)

    def volumetric_solidification_shrinkage(self):
        """(rho_s(T_sol) - rho_l(T_liq)) / rho_s(T_sol): fractional volume change liquid->solid (from tabulated density)."""
        rs = float(self.tables["density"](self.T_solidus_C)); rl = float(self.tables["density"](self.T_liquidus_C))
        return (rs - rl) / rs

    def thermal_strain(self, T_C, T_ref_C):
        """Linear thermal strain  eps(T) = integral_{T_ref}^{T} alpha(T') dT'  (negative below T_ref)."""
        a = self.tables["thermal_expansion"](T_GRID_C)
        cum = np.concatenate([[0.0], np.cumsum(0.5 * (a[1:] + a[:-1]) * np.diff(T_GRID_C))])
        return np.interp(np.asarray(T_C, float), T_GRID_C, cum) - np.interp(T_ref_C, T_GRID_C, cum)

    # ---- composition variation (ESTIMATED linear sensitivities) ----
    def with_composition_shift(self, delta_wt: dict) -> "Alloy":
        """Return a copy with liquidus/solidus/beta-transus shifted by linear, ESTIMATED coefficients."""
        d = {"liquidus": 0.0, "solidus": 0.0, "beta_transus": 0.0}
        for el, dw in delta_wt.items():
            for prop, c in self.composition_coeffs.get(el, {}).items():
                d[prop] += c * dw
        comp = dict(self.composition_wt)
        for el, dw in delta_wt.items(): comp[el] = comp.get(el, 0.0) + dw
        def sh(p, dv):
            return ScalarProperty(p.name, p.value + dv, p.unit,
                                  Provenance("estimated", "composition shift of " + p.provenance.source,
                                             f"linear estimated coefficients; shift {dv:+.2f} C"))
        return replace(self, composition_wt=comp, liquidus=sh(self.liquidus, d["liquidus"]),
                       solidus=sh(self.solidus, d["solidus"]), beta_transus=sh(self.beta_transus, d["beta_transus"]))

    # ---- reporting / serialisation ----
    def provenance_report(self):
        rows = []
        for p in (self.liquidus, self.solidus, self.latent_heat, self.beta_transus):
            rows.append((p.name, p.provenance.kind, p.provenance.source))
        for n, t in self.tables.items():
            rows.append((n, t.provenance.kind, t.provenance.source))
        return rows

    def fraction_estimated(self):
        rows = self.provenance_report()
        return sum(1 for r in rows if r[1] == "estimated") / len(rows)

    def to_dict(self):
        return {"name": self.name, "composition_wt": self.composition_wt, "fs_exponent": self.fs_exponent,
                "database_version": self.database_version,
                "liquidus": self.liquidus.to_dict(), "solidus": self.solidus.to_dict(),
                "latent_heat": self.latent_heat.to_dict(), "beta_transus": self.beta_transus.to_dict(),
                "composition_coeffs": self.composition_coeffs,
                "tables": {k: v.to_dict() for k, v in self.tables.items()}}

    @staticmethod
    def from_dict(d):
        def sc(name, x):
            p = x["provenance"]; return ScalarProperty(name, x["value"], x["unit"], Provenance(p["kind"], p["source"], p.get("note", "")))
        return Alloy(name=d["name"], composition_wt=d["composition_wt"], liquidus=sc("liquidus", d["liquidus"]),
                     solidus=sc("solidus", d["solidus"]), latent_heat=sc("latent_heat", d["latent_heat"]),
                     beta_transus=sc("beta_transus", d["beta_transus"]),
                     tables={k: TabulatedProperty.from_dict(k, v) for k, v in d["tables"].items()},
                     fs_exponent=d.get("fs_exponent", 1.0), composition_coeffs=d.get("composition_coeffs", {}),
                     database_version=d.get("database_version", "0.1.0"))
