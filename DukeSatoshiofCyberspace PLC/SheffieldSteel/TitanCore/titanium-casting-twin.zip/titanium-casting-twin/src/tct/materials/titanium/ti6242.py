"""Ti-6Al-2Sn-4Zr-2Mo (Ti-6242). Derived/ESTIMATED from Ti-6Al-4V; see _derive.py."""
from ._derive import derive
from . import ti64
def build():
    return derive(ti64.build(), "Ti-6242", {"Ti": 85.9, "Al": 6.0, "Sn": 2.0, "Zr": 4.0, "Mo": 2.0},
                  liquidus=1670.0, solidus=1620.0, beta=995.0,
                  scale={"yield_strength": 1.05, "elastic_modulus": 1.0, "density": 1.04})
