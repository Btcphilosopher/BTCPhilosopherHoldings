"""Ti-6Al-2Sn-4Zr-6Mo (Ti-6246): deep-hardening alpha-beta alloy, lower beta transus. ESTIMATED from Ti-6Al-4V."""
from ._derive import derive
from . import ti64
def build():
    return derive(ti64.build(), "Ti-6246", {"Ti": 81.9, "Al": 6.0, "Sn": 2.0, "Zr": 4.0, "Mo": 6.0},
                  liquidus=1650.0, solidus=1600.0, beta=940.0,
                  scale={"yield_strength": 1.15, "density": 1.07})
