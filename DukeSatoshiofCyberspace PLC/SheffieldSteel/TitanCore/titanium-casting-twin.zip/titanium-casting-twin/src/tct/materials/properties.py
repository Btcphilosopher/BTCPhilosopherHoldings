"""Property containers with mandatory provenance.

Every material number carries a Provenance(kind, source, note). Allowed kinds:
  literature-derived : taken (possibly digitised/approximated) from published data
  estimated          : engineering estimate or scaling from a related alloy -- NOT measured
  calibrated         : fitted to user/foundry data via tct.calibration
  user-supplied      : given explicitly by the user
There is deliberately no way to create a property without one.
"""
from __future__ import annotations
from dataclasses import dataclass, field
import numpy as np

KINDS = ("literature-derived", "estimated", "calibrated", "user-supplied")

@dataclass(frozen=True)
class Provenance:
    kind: str
    source: str
    note: str = ""
    def __post_init__(self):
        if self.kind not in KINDS:
            raise ValueError(f"provenance kind must be one of {KINDS}, got {self.kind!r}")
    def to_dict(self): return {"kind": self.kind, "source": self.source, "note": self.note}

@dataclass(frozen=True)
class ScalarProperty:
    name: str
    value: float
    unit: str
    provenance: Provenance
    def __float__(self): return float(self.value)
    def to_dict(self): return {"value": float(self.value), "unit": self.unit, "provenance": self.provenance.to_dict()}

@dataclass(frozen=True)
class TabulatedProperty:
    """Piecewise-linear property of temperature (deg C). Clamped outside the table (never extrapolated)."""
    name: str
    unit: str
    T_C: tuple
    values: tuple
    provenance: Provenance
    def __post_init__(self):
        t = np.asarray(self.T_C, float); v = np.asarray(self.values, float)
        if t.shape != v.shape or t.ndim != 1 or len(t) < 2:
            raise ValueError(f"{self.name}: need >=2 matching (T, value) points")
        if np.any(np.diff(t) <= 0):
            raise ValueError(f"{self.name}: temperatures must be strictly increasing")
    def __call__(self, T_C):
        return np.interp(np.asarray(T_C, float), np.asarray(self.T_C), np.asarray(self.values))
    @property
    def valid_range_C(self): return (float(self.T_C[0]), float(self.T_C[-1]))
    def out_of_range(self, T_C):
        T = np.asarray(T_C, float); return (T < self.T_C[0]) | (T > self.T_C[-1])
    def to_dict(self):
        return {"unit": self.unit, "T_C": [float(x) for x in self.T_C], "values": [float(x) for x in self.values],
                "provenance": self.provenance.to_dict()}
    @staticmethod
    def from_dict(name, d):
        p = d["provenance"]
        return TabulatedProperty(name, d["unit"], tuple(d["T_C"]), tuple(d["values"]),
                                 Provenance(p["kind"], p["source"], p.get("note", "")))

def table(name, unit, pts, kind, source, note=""):
    T, v = zip(*pts)
    return TabulatedProperty(name, unit, tuple(T), tuple(v), Provenance(kind, source, note))

def scalar(name, value, unit, kind, source, note=""):
    return ScalarProperty(name, float(value), unit, Provenance(kind, source, note))
