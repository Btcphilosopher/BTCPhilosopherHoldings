"""Kinetic / empirical relations used by the microstructure, contamination and heat-treatment models.

Every constant is a ScalarProperty with provenance. Most are `estimated`: they encode the *form* of the
physics (Arrhenius, power law, Hall-Petch) with order-of-magnitude constants and MUST be calibrated
against the user's own metallography / mechanical data before any quantitative use.
"""
from __future__ import annotations
import numpy as np
from ..units import R_GAS, c2k
from .properties import scalar

# --- alpha-case / oxygen diffusion in alpha-Ti:  D = D0 exp(-Q/RT) -------------------------------------
D0_O = scalar("D0_oxygen_in_Ti", 6.0e-5, "m^2/s", "estimated", "order-of-magnitude from Liu & Welsch-type data (~0.6 cm^2/s)")
Q_O = scalar("Q_oxygen_in_Ti", 2.02e5, "J/mol", "estimated", "order-of-magnitude (~200 kJ/mol)")
def D_oxygen_m2_s(T_C):
    return D0_O.value * np.exp(-Q_O.value / (R_GAS * c2k(T_C)))

# --- alpha-transformation kinetics: df/dt = (f_eq(T) - f)/tau(T),  tau = tau_ref*exp(Q/R (1/T - 1/Tref)) --
TAU_REF_S = scalar("alpha_tau_ref", 4.0, "s", "estimated", "tuned so ~1 K/s cooling gives near-equilibrium alpha, >400 K/s suppresses it")
TAU_TREF_C = scalar("alpha_tau_Tref", 900.0, "C", "estimated", "reference temperature for tau")
TAU_Q = scalar("alpha_tau_Q", 1.5e5, "J/mol", "estimated", "apparent activation energy for alpha growth")
def alpha_tau_s(T_C):
    T = c2k(T_C); Tr = c2k(TAU_TREF_C.value)
    return TAU_REF_S.value * np.exp(TAU_Q.value / R_GAS * (1.0 / T - 1.0 / Tr))

# --- alpha-lath thickness vs cooling rate through the alpha-precipitation range ---------------------
LATH_A_UM = scalar("lath_a", 3.0, "um", "estimated", "power-law prefactor at CR = 1 K/s; REQUIRES calibration to metallography")
LATH_N = scalar("lath_n", 0.45, "-", "estimated", "power-law exponent (literature spans ~0.3-0.6)")
def lath_thickness_um(cooling_rate_K_s):
    cr = np.maximum(np.asarray(cooling_rate_K_s, float), 1e-4)
    return LATH_A_UM.value * cr ** (-LATH_N.value)

# --- cooling-rate regime thresholds for Ti-6Al-4V (Ahmed & Rack 1998 style) -------------------------
CR_MARTENSITE_K_S = scalar("CR_martensite", 410.0, "K/s", "literature-derived", "Ahmed & Rack, Mater. Sci. Eng. A 243 (1998)", "above: alpha' martensite")
CR_MASSIVE_K_S = scalar("CR_massive", 20.0, "K/s", "literature-derived", "Ahmed & Rack (1998)", "20-410: massive/basketweave; below: Widmanstatten/colony")
CR_COLONY_K_S = scalar("CR_colony", 1.0, "K/s", "estimated", "below ~1 K/s colony alpha dominates in thick sections")

# --- heat-treatment kinetics -------------------------------------------------------------------------
COARSEN_K0 = scalar("lath_coarsen_k0", 1.0e-4, "um^3/s", "estimated", "LSW-type d^3-d0^3 = k0 exp(-Q/RT) t; needs calibration")
COARSEN_Q = scalar("lath_coarsen_Q", 2.2e5, "J/mol", "estimated", "bulk-diffusion-like activation energy")
RELAX_K0 = scalar("stress_relax_k0", 2.0e9, "1/s", "estimated", "Zener-Wert-Avrami: sigma/sigma0 = exp(-(k t)^n); needs calibration")
RELAX_Q = scalar("stress_relax_Q", 2.4e5, "J/mol", "estimated", "apparent activation energy")
RELAX_N = scalar("stress_relax_n", 0.5, "-", "estimated", "Avrami-type exponent")
HIP_A = scalar("hip_creep_A", 0.2, "1/(s MPa^n)", "estimated", "Norton law eps_dot = A exp(-Q/RT) sigma^n; tuned so ~100 MPa/920 C/2 h closes most internal voids (consistent with HIP practice); calibrate")
HIP_Q = scalar("hip_creep_Q", 2.0e5, "J/mol", "estimated", "")
HIP_N = scalar("hip_creep_n", 3.0, "-", "estimated", "")

# --- Hall-Petch strengthening for alpha-lath thickness (INDICATOR only) --------------------------------
HP_SIGMA0_MPa = scalar("HP_sigma0", 700.0, "MPa", "estimated", "friction stress (uncalibrated)")
HP_K_MPa_um05 = scalar("HP_k", 150.0, "MPa um^0.5", "estimated", "Hall-Petch slope vs lath thickness (uncalibrated)")
def yield_from_lath_MPa(d_um):
    return HP_SIGMA0_MPa.value + HP_K_MPa_um05.value / np.sqrt(np.maximum(d_um, 0.05))
