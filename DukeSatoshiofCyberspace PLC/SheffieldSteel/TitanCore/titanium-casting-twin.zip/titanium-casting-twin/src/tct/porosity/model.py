"""Porosity model: micro-shrinkage (Niyama), macro-shrinkage (isolated pools), gas (hydrogen + entrained gas).
STATUS: Niyama threshold = EMPIRICAL / ESTIMATED (must be calibrated); isolation voids REDUCED-ORDER; hydrogen = Sieverts (constants ESTIMATED).

Micro-shrinkage:   risk_micro = 1 / (1 + (Ny/Ny_crit)^p),   Ny = G[K/mm] / sqrt(CR[K/s]) at the feeding limit.
                   phi_micro_max = beta_s (1 - fs_c)  -- the physical upper bound: liquid left at the feeding limit shrinks unfed.
                   phi_micro = phi_micro_max * risk_micro
Macro-shrinkage:   void fraction allocated by the feeding module.
Hydrogen:          Scheil enrichment C_L = C0 (1 - fs)^(k-1) at fs_end; solubility C_s = K_s sqrt(p_local);
                   excess gas volume by ideal gas law, p_local = p_chamber + rho g h_metallostatic.
Entrained gas:     phi_entrap = phi_ref * (1 - exp(-air_entrainment_index))  with phi_ref ESTIMATED.
Combined (independent mechanisms): risk = 1 - prod(1 - r_i);  void fraction = min(1, sum phi_i).
No binary defect/no-defect output is produced: callers may apply an explicit user-supplied threshold.
"""
from __future__ import annotations
from dataclasses import dataclass
import numpy as np
from ..units import G_ACC, R_GAS, c2k

@dataclass
class PorosityParams:
    niyama_crit: float = 1.0          # (K s)^0.5 / mm, ESTIMATED -- calibrate to radiography
    niyama_exponent: float = 3.0
    fs_feed_limit: float = 0.7
    hydrogen_ppm_wt: float = 40.0     # melt hydrogen, user supplied
    k_hydrogen: float = 0.5           # equilibrium partition coefficient, ESTIMATED
    Ks_wt_per_sqrtPa: float = 2.0e-3  # Sieverts constant (liquid Ti), ESTIMATED
    fs_end: float = 0.95
    phi_entrap_ref: float = 0.005     # ESTIMATED
    chamber_pressure_Pa: float = 1.0

def compute(cs, alloy, sol_fields: dict, feed_fields: dict, fill_air_index3, basin_level_m, params: PorosityParams | None = None):
    p = params or PorosityParams(); g = cs.grid; metal = cs.metal
    beta_s = alloy.volumetric_solidification_shrinkage()
    ny = sol_fields["niyama_sqrtKs_mm"]
    with np.errstate(invalid="ignore", divide="ignore"):
        r_micro = 1.0 / (1.0 + (ny / p.niyama_crit) ** p.niyama_exponent)
    r_micro = np.where(np.isfinite(ny), r_micro, 0.0)
    phi_micro_max = beta_s * (1.0 - p.fs_feed_limit)
    phi_micro = phi_micro_max * r_micro
    phi_macro = np.nan_to_num(feed_fields["macro_shrinkage_void_fraction"], nan=0.0)
    r_macro = np.clip(phi_macro / max(phi_micro_max, 1e-9), 0.0, 1.0)
    # gas
    Z = g.centers()[2]
    rho_l = float(alloy.tables["density"](alloy.T_liquidus_C))
    p_loc = p.chamber_pressure_Pa + rho_l * G_ACC * np.maximum(basin_level_m - Z, 0.0)
    C0 = p.hydrogen_ppm_wt * 1e-6                                         # mass fraction
    C_L = C0 * (1.0 - p.fs_end) ** (p.k_hydrogen - 1.0)
    C_s = (p.Ks_wt_per_sqrtPa * 1e-2) * np.sqrt(np.maximum(p_loc, 1e-9))   # wt% -> mass fraction
    excess = np.maximum(C_L - C_s, 0.0) * (1.0 - p.fs_end)
    n_H2 = excess * rho_l / 2.016e-3
    T_fs = float(alloy.T_solidus_C)
    phi_H = np.minimum(n_H2 * R_GAS * c2k(T_fs) / np.maximum(p_loc, 1e-9), 1.0)
    r_H = 1.0 - np.exp(-phi_H / 1e-3)
    ai = np.nan_to_num(fill_air_index3, nan=0.0)
    phi_ent = p.phi_entrap_ref * (1.0 - np.exp(-ai)); r_ent = 1.0 - np.exp(-ai)
    risk = 1.0 - (1 - r_micro) * (1 - r_macro) * (1 - r_H) * (1 - r_ent)
    void = np.minimum(phi_micro + phi_macro + phi_H + phi_ent, 1.0)
    mk = lambda a: np.where(metal, a, np.nan)
    fields = {"porosity_risk": mk(risk), "predicted_void_fraction": mk(void), "microshrinkage_risk": mk(r_micro),
              "microshrinkage_void_fraction": mk(phi_micro), "macroshrinkage_risk": mk(r_macro),
              "gas_risk_hydrogen": mk(r_H), "gas_void_fraction_hydrogen": mk(phi_H),
              "gas_risk_entrained": mk(r_ent), "gas_void_fraction_entrained": mk(phi_ent)}
    fmap = feed_fields["feeding_map"].copy()
    marg = (fmap == 1) & (r_micro > 0.5) & cs.metal
    fmap[marg] = 2
    fields["feeding_map"] = fmap
    part = cs.mask(1)
    sc = {"porosity_risk_max_part": float(np.nanmax(fields["porosity_risk"][part])),
          "porosity_risk_mean_part": float(np.nanmean(fields["porosity_risk"][part])),
          "void_fraction_max_part": float(np.nanmax(fields["predicted_void_fraction"][part])),
          "void_fraction_mean_part": float(np.nanmean(fields["predicted_void_fraction"][part])),
          "niyama_min_part": float(np.nanmin(np.where(part, ny, np.nan))) if np.isfinite(ny[part]).any() else None,
          "phi_micro_physical_upper_bound": phi_micro_max,
          "model_status": {"micro": "EMPIRICAL (Niyama threshold ESTIMATED)", "macro": "REDUCED-ORDER",
                           "hydrogen": "PHYSICS-BASED form, constants ESTIMATED", "entrained": "EMPIRICAL indicator"}}
    return fields, sc
