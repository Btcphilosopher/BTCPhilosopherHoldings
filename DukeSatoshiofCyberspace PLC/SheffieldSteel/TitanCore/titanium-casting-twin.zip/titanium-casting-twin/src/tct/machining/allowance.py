"""Machining allowance: as-cast geometry, final (machined) geometry and stock margin.  STATUS: PHYSICS-BASED geometry + the upstream
(estimated) distortion and alpha-case depth.

The casting-system part is the AS-CAST shape. The final machined shape is the as-cast part eroded by the machining allowance
on machined faces (default: all outer faces). Margin on a surface cell:
    margin = allowance - alpha_case_depth - |distortion normal to the surface| - tolerance
margin < 0 means stock removal may not clear the alpha case / may not recover the geometry => REVIEW.
"""
from __future__ import annotations
import numpy as np
from scipy import ndimage as ndi
from ..geometry.casting_system import PART

def compute(cs, allowance_m, alpha_case_depth3, distortion_mag3, tolerance_m=0.0):
    g = cs.grid; part = cs.mask(PART)
    edt = (ndi.distance_transform_edt(part) - 0.5) * g.dx_m          # centre -> nearest outside surface (cell face)
    final = part & (edt > allowance_m)
    surface = part & ~ndi.binary_erosion(part)
    margin = np.where(surface, allowance_m - np.nan_to_num(alpha_case_depth3, nan=0.0) - np.nan_to_num(distortion_mag3, nan=0.0) - tolerance_m, np.nan)
    env_hi = ndi.binary_dilation(final, iterations=max(int(round(tolerance_m / g.dx_m)), 0)) if tolerance_m > 0 else final
    sc = {"allowance_m": allowance_m, "as_cast_volume_m3": float(part.sum()) * g.cell_volume_m3,
          "final_volume_m3": float(final.sum()) * g.cell_volume_m3,
          "stock_removal_volume_m3": float(part.sum() - final.sum()) * g.cell_volume_m3,
          "min_margin_m": float(np.nanmin(margin)) if np.isfinite(margin).any() else None,
          "fraction_surface_negative_margin": float((margin[surface] < 0).mean()) if surface.any() else 0.0,
          "tolerance_m": tolerance_m, "voxel_resolution_m": g.dx_m,
          "note": "voxel resolution limits the accuracy of the final-geometry envelope"}
    return {"final_geometry_mask": final, "machining_margin_m": margin, "tolerance_envelope_mask": env_hi}, sc
