"""Solidification metrics from the thermal solver's threshold-crossing events.  STATUS: REDUCED-ORDER (derived from the thermal solution).

Per metal cell (event crossings interpolated linearly inside the time step):
  t_liq, t_sol           time the cell crosses T_liquidus / T_solidus                         [s]
  local solidification time  t_f = t_sol - t_liq                                              [s]
  cooling rate at crossing   CR = -dT/dt at that crossing                                      [K/s]
  thermal gradient           G = |grad T| at the liquidus crossing                              [K/m]
  front velocity             R = CR / G   (isotherm speed)                                      [m/s]
  Niyama                     Ny = G[K/mm] / sqrt(CR[K/s]) evaluated at the feeding-limit crossing
Solidification map classes: 1 early, 2 mid (mushy-dominated), 3 late (feeding-sensitive), by t_sol tertiles of the metal.
"""
from __future__ import annotations
from dataclasses import dataclass
import numpy as np
from ..geometry.casting_system import MAT_METAL

EVENT_NAMES = ("liquidus", "solidus", "feeding_limit", "beta_transus", "T1000", "T800")

def event_thresholds(alloy, fs_feed_limit=0.7):
    TL, TS = alloy.T_liquidus_C, alloy.T_solidus_C
    T_fc = TL - fs_feed_limit ** (1.0 / alloy.fs_exponent) * (TL - TS)
    return [TL, TS, T_fc, alloy.T_beta_C, 1000.0, 800.0]

@dataclass
class SolidificationFields:
    fields: dict            # name -> 3D array (NaN outside metal)
    scalars: dict
    event_names: tuple = EVENT_NAMES
    model: str = "REDUCED-ORDER (from thermal solution)"

def compute(solver, fs_feed_limit=0.7) -> SolidificationFields:
    cs = solver.cs; ev = {n: i for i, n in enumerate(EVENT_NAMES)}
    metal = solver.is_metal
    def f(a): return solver.to_field(np.where(metal, a, np.nan))
    tl, ts, tfc = solver.t_cross[ev["liquidus"]], solver.t_cross[ev["solidus"]], solver.t_cross[ev["feeding_limit"]]
    t_f = ts - tl
    cr_l = solver.cr_cross[ev["liquidus"]]; g_l = solver.g_cross[ev["liquidus"]]
    R = np.where(g_l > 0, cr_l / np.maximum(g_l, 1e-12), np.nan)
    cr_fc = solver.cr_cross[ev["feeding_limit"]]; g_fc = solver.g_cross[ev["feeding_limit"]]
    ny = (g_fc / 1000.0) / np.sqrt(np.maximum(cr_fc, 1e-9))
    t1000, t800 = solver.t_cross[ev["T1000"]], solver.t_cross[ev["T800"]]
    cr_beta = 200.0 / np.maximum(t800 - t1000, 1e-6)
    fl = {"t_liquidus_s": f(tl), "t_solidus_s": f(ts), "t_feeding_limit_s": f(tfc), "local_solidification_time_s": f(t_f),
          "cooling_rate_liquidus_K_s": f(cr_l), "cooling_rate_solidus_K_s": f(solver.cr_cross[ev["solidus"]]),
          "thermal_gradient_K_m": f(g_l), "front_velocity_m_s": f(R), "niyama_sqrtKs_mm": f(ny),
          "cooling_rate_beta_K_s": f(cr_beta), "t_T1000_s": f(t1000), "t_T800_s": f(t800),
          "peak_temperature_C": f(solver.Tpeak), "time_above_beta_s": f(solver.t_above_beta)}
    # classes by tertiles of t_sol
    tsm = ts[metal & np.isfinite(ts)]
    cls = np.zeros(cs.grid.shape, np.int8)
    if tsm.size:
        q1, q2 = np.quantile(tsm, [1 / 3, 2 / 3])
        c1 = np.where(ts <= q1, 1, np.where(ts <= q2, 2, 3)); c1 = np.where(np.isfinite(ts), c1, 0)
        cls[tuple(solver.act[metal].T)] = c1[metal]
    fl["solidification_class"] = cls
    unsolid = int((metal & ~np.isfinite(ts)).sum())
    sc = {"solidification_complete": unsolid == 0, "cells_not_solidified": unsolid,
          "t_solidus_max_s": float(np.nanmax(ts[metal])) if np.isfinite(ts[metal]).any() else None,
          "t_liquidus_max_s": float(np.nanmax(tl[metal])) if np.isfinite(tl[metal]).any() else None}
    return SolidificationFields(fl, sc)

def chvorinov_B(t_sol_s, modulus_m):
    """Chvorinov constant B = t_s / M^2  [s/m^2] for comparison with the solver (consistency check)."""
    return t_sol_s / modulus_m ** 2

def local_fs_from_times(t, t_liq, t_sol):
    return np.clip((t - t_liq) / np.maximum(t_sol - t_liq, 1e-9), 0.0, 1.0)
