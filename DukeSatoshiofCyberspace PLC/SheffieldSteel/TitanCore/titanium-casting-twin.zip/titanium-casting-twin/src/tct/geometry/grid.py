"""Uniform Cartesian grid (SI metres). Fields are float64/float32 numpy arrays of shape (nx, ny, nz)."""
from __future__ import annotations
from dataclasses import dataclass
import numpy as np

@dataclass(frozen=True)
class Grid:
    shape: tuple          # (nx, ny, nz)
    dx_m: float           # cubic cell edge length [m]
    origin_m: tuple       # coordinates of the CORNER of cell (0,0,0) [m]
    @property
    def n_cells(self): return int(np.prod(self.shape))
    @property
    def cell_volume_m3(self): return self.dx_m ** 3
    def centers(self):
        ax = [self.origin_m[i] + (np.arange(self.shape[i]) + 0.5) * self.dx_m for i in range(3)]
        return np.meshgrid(*ax, indexing="ij")
    def center_of(self, ijk):
        ijk = np.asarray(ijk, float)
        return np.asarray(self.origin_m) + (ijk + 0.5) * self.dx_m
    def index_of(self, xyz_m):
        return np.floor((np.asarray(xyz_m, float) - np.asarray(self.origin_m)) / self.dx_m).astype(int)
    def contains_index(self, ijk):
        ijk = np.asarray(ijk); return bool(np.all(ijk >= 0) and np.all(ijk < np.asarray(self.shape)))
    def to_dict(self): return {"shape": list(self.shape), "dx_m": self.dx_m, "origin_m": list(self.origin_m)}
