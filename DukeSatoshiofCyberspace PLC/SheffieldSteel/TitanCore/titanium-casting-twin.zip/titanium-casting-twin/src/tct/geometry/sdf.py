"""Signed-distance-style solids (negative inside). CSG: union = min, intersection = max, subtract = max(a,-b).
Used for procedural CAD. Distances are exact for spheres/cylinders/boxes; half-space polygons are conservative."""
from __future__ import annotations
import numpy as np

class Solid:
    def __call__(self, x, y, z): raise NotImplementedError
    def __or__(self, o):  return _Op(np.minimum, self, o)
    def __and__(self, o): return _Op(np.maximum, self, o)
    def __sub__(self, o): return _Sub(self, o)

class _Op(Solid):
    def __init__(self, f, a, b): self.f, self.a, self.b = f, a, b
    def __call__(self, x, y, z): return self.f(self.a(x, y, z), self.b(x, y, z))
class _Sub(Solid):
    def __init__(self, a, b): self.a, self.b = a, b
    def __call__(self, x, y, z): return np.maximum(self.a(x, y, z), -self.b(x, y, z))

class Box(Solid):
    def __init__(self, center, half):
        self.c = np.asarray(center, float); self.h = np.asarray(half, float)
    def __call__(self, x, y, z):
        q = np.stack([np.abs(x - self.c[0]) - self.h[0], np.abs(y - self.c[1]) - self.h[1], np.abs(z - self.c[2]) - self.h[2]])
        return np.linalg.norm(np.maximum(q, 0), axis=0) + np.minimum(q.max(axis=0), 0)

class Cylinder(Solid):
    """Finite cylinder; axis in 'x','y','z'; z0..z1 are axial extents (absolute coordinates)."""
    def __init__(self, axis, center_xy, radius, a0, a1):
        self.axis, self.c, self.r, self.a0, self.a1 = axis, center_xy, radius, a0, a1
    def __call__(self, x, y, z):
        u, v, w = {"z": (x, y, z), "x": (y, z, x), "y": (x, z, y)}[self.axis]
        d_rad = np.hypot(u - self.c[0], v - self.c[1]) - self.r
        mid, half = 0.5 * (self.a0 + self.a1), 0.5 * (self.a1 - self.a0)
        d_ax = np.abs(w - mid) - half
        return np.linalg.norm(np.stack([np.maximum(d_rad, 0), np.maximum(d_ax, 0)]), axis=0) + np.minimum(np.maximum(d_rad, d_ax), 0)

class Prism(Solid):
    """Convex polygon in the (u,v) plane extruded along the third axis. polygon: CCW list of (u,v)."""
    def __init__(self, plane, polygon, w0, w1):
        self.plane, self.poly, self.w0, self.w1 = plane, np.asarray(polygon, float), w0, w1
    def __call__(self, x, y, z):
        u, v, w = {"xz": (x, z, y), "xy": (x, y, z), "yz": (y, z, x)}[self.plane]
        d = -np.inf * np.ones_like(u)
        n = len(self.poly)
        for i in range(n):
            p, q = self.poly[i], self.poly[(i + 1) % n]
            e = q - p; nrm = np.array([e[1], -e[0]]) / np.hypot(*e)      # outward normal for CCW polygon
            d = np.maximum(d, (u - p[0]) * nrm[0] + (v - p[1]) * nrm[1])
        mid, half = 0.5 * (self.w0 + self.w1), 0.5 * (self.w1 - self.w0)
        return np.maximum(d, np.abs(w - mid) - half)

def sample(solid, grid):
    X, Y, Z = grid.centers()
    return solid(X, Y, Z)


class Scale(Solid):
    """Wrap a solid defined in other units: evaluate solid(x/f, y/f, z/f)*f  (f = metres per source unit)."""
    def __init__(self, solid, factor): self.s, self.f = solid, factor
    def __call__(self, x, y, z): return self.s(x / self.f, y / self.f, z / self.f) * self.f
