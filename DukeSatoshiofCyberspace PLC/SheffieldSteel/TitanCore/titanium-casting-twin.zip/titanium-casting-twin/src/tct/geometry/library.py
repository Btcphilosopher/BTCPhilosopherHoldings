"""Procedural casting designs (all lengths metres; built from mm for readability)."""
from __future__ import annotations
import numpy as np
from .sdf import Box, Cylinder, Prism, Solid, Scale
from .casting_system import build_casting_system, CastingSystem
from .geometry import Geometry

mm = 1e-3

def _tag(solid: Solid, lo, hi):
    """Wrap an mm-defined solid into a metre-valued Solid carrying its bounding box (metres)."""
    w = Scale(solid, mm); w.bbox_m = (np.array(lo, float) * mm, np.array(hi, float) * mm); return w

def bracket_solids(riser_d_mm=34.0, riser_h_mm=36.0, gate_h_mm=8.0, sprue_d_mm=18.0):
    """Aerospace-style L-bracket: base plate, upright web, gusset rib, bolt boss with cored through-hole.
    Bottom-gated through two ingates from a transverse runner fed by a vertical sprue + pour basin; two risers
    (one on the boss, one on the web top). Dimensions in mm: part ~100 x 60 x 62."""
    plate = Box((0, 0, 6), (50, 30, 6))
    web = Box((-44, 0, 37), (6, 25, 25))
    rib = Prism("xz", [(-38, 12), (8, 12), (-38, 46)], -3, 3)
    boss = Cylinder("z", (30, 0), 14, 12, 40)
    core_mm = Cylinder("z", (30, 0), 5, -6, 41)
    part = (plate | web | rib | boss) - core_mm
    part = _tag(part, (-50, -30, 0), (50, 30, 62))
    core = _tag(core_mm, (25, -5, -6), (35, 5, 41))
    riser1 = Cylinder("z", (30, 0), riser_d_mm / 2, 38, 38 + riser_h_mm)
    riser2 = Box((-44, 0, 62 + 8), (10, 18, 10))
    rd = riser_d_mm / 2
    risers = _tag(riser1 | riser2, (-54, -max(18, rd), 38), (30 + rd, max(18, rd), max(80, 38 + riser_h_mm)))
    gates = _tag(Box((59.5, 18, 6), (10.5, 6, gate_h_mm / 2)) | Box((59.5, -18, 6), (10.5, 6, gate_h_mm / 2)),
                 (49, -24, 6 - gate_h_mm / 2), (70, 24, 6 + gate_h_mm / 2))
    runner = _tag(Box((75, 0, 6), (6, 30, 6)), (69, -30, 0), (81, 30, 12))
    sprue = _tag(Cylinder("z", (75, 0), sprue_d_mm / 2, 0, 105), (75 - sprue_d_mm / 2, -sprue_d_mm / 2, 0), (75 + sprue_d_mm / 2, sprue_d_mm / 2, 105))
    basin = _tag(Cylinder("z", (75, 0), 24, 90, 120), (51, -24, 90), (99, 24, 120))
    return {"part": part, "riser": risers, "gate": gates, "runner": runner, "sprue": sprue, "basin": basin, "core": core}

def build_bracket(dx_m=3e-3, shell_thickness_m=8e-3, **kw) -> CastingSystem:
    return build_casting_system(bracket_solids(**kw), dx_m, shell_thickness_m, name="ti64_aerospace_bracket")

def bracket_cad_geometry() -> Geometry:
    s = bracket_solids()
    cad = s["part"]
    return Geometry.procedural(cad, cad.bbox_m, name="bracket_part_cad")

def plate_casting(thickness_m=0.02, length_m=0.1, width_m=0.06, dx_m=4e-3, shell_thickness_m=8e-3, gated=False):
    """Plate coupon. gated=False: riserless, ungated (validation/regression cases). gated=True: side-gated plate with sprue, pour basin
    and a top riser (a small but complete feeding/filling system)."""
    t = thickness_m; L = length_m; W = width_m
    def tag(sol, lo, hi): sol.bbox_m = (np.array(lo, float), np.array(hi, float)); return sol
    plate = tag(Box((0, 0, t / 2), (L / 2, W / 2, t / 2)), (-L / 2, -W / 2, 0.0), (L / 2, W / 2, t))
    if not gated: return build_casting_system({"part": plate}, dx_m, shell_thickness_m, name="plate")
    rr = 0.3 * W
    riser = tag(Cylinder("z", (0.0, 0.0), rr, t - 0.002, t + 0.035), (-rr, -rr, t - 0.002), (rr, rr, t + 0.035))
    xs = L / 2 + 0.03
    gate = tag(Box((L / 2 + 0.018, 0, t / 2), (0.020, W / 4, max(t / 3, dx_m))), (L / 2 - 0.002, -W / 4, t / 2 - max(t / 3, dx_m)), (L / 2 + 0.038, W / 4, t / 2 + max(t / 3, dx_m)))
    sprue = tag(Cylinder("z", (xs, 0.0), 0.009, 0.0, 0.13), (xs - 0.009, -0.009, 0.0), (xs + 0.009, 0.009, 0.13))
    basin = tag(Cylinder("z", (xs, 0.0), 0.028, 0.11, 0.15), (xs - 0.028, -0.028, 0.11), (xs + 0.028, 0.028, 0.15))
    return build_casting_system({"part": plate, "riser": riser, "gate": gate, "sprue": sprue, "basin": basin}, dx_m, shell_thickness_m, name="plate_gated")
