"""Surface-mesh and voxel-model validation (spec section 5).

Checks: non-manifold edges, open boundary edges (holes), inconsistent winding / inverted faces,
self-intersections (spatial-hash + segment/triangle test), disconnected components, minimum feature size,
thin walls (voxel EDT based; resolution-limited).
"""
from __future__ import annotations
from dataclasses import dataclass, field, asdict
import numpy as np
from scipy import ndimage as ndi

@dataclass
class GeometryReport:
    n_vertices: int = 0
    n_faces: int = 0
    watertight: bool = False
    winding_consistent: bool = False
    signed_volume_m3: float = 0.0
    inverted: bool = False
    non_manifold_edges: int = 0
    open_boundary_edges: int = 0
    degenerate_faces: int = 0
    self_intersecting_pairs: int | None = 0
    n_components: int = 0
    min_wall_thickness_m: float | None = None
    thin_wall_cells: int = 0
    thin_wall_threshold_m: float | None = None
    messages: list = field(default_factory=list)
    @property
    def ok(self):
        return (self.watertight and self.winding_consistent and not self.inverted and self.non_manifold_edges == 0
                and (self.self_intersecting_pairs or 0) == 0 and self.n_components >= 1)
    def to_dict(self): return asdict(self)

def _segment_triangle(p0, p1, tri):
    """Vectorised Moller-Trumbore for segments p0->p1 against triangles tri[n,3,3]. True where they intersect strictly."""
    d = p1 - p0
    e1 = tri[:, 1] - tri[:, 0]; e2 = tri[:, 2] - tri[:, 0]
    h = np.cross(d, e2); a = np.einsum("ij,ij->i", e1, h)
    ok = np.abs(a) > 1e-14
    f = np.where(ok, 1.0 / np.where(ok, a, 1.0), 0.0)
    s = p0 - tri[:, 0]
    u = f * np.einsum("ij,ij->i", s, h)
    q = np.cross(s, e1)
    v = f * np.einsum("ij,ij->i", d, q)
    t = f * np.einsum("ij,ij->i", e2, q)
    eps = 1e-9
    return ok & (u > eps) & (v > eps) & (u + v < 1 - eps) & (t > eps) & (t < 1 - eps)

def count_self_intersections(mesh, max_faces=60000):
    """Count intersecting triangle pairs that do not share a vertex. Returns None if mesh too large."""
    F = mesh.faces; V = mesh.vertices; n = len(F)
    if n > max_faces: return None
    tri = V[F]
    lo, hi = tri.min(1), tri.max(1)
    cell = max(float(np.mean(np.linalg.norm(tri[:, 1] - tri[:, 0], axis=1))) * 2.0, 1e-9)
    buckets = {}
    ilo = np.floor(lo / cell).astype(int); ihi = np.floor(hi / cell).astype(int)
    for i in range(n):
        for a in range(ilo[i, 0], ihi[i, 0] + 1):
            for b in range(ilo[i, 1], ihi[i, 1] + 1):
                for c in range(ilo[i, 2], ihi[i, 2] + 1):
                    buckets.setdefault((a, b, c), []).append(i)
    pairs = set()
    for lst in buckets.values():
        if len(lst) < 2: continue
        arr = np.array(lst)
        for k in range(len(arr)):
            for m in range(k + 1, len(arr)):
                pairs.add((arr[k], arr[m]))
    if not pairs: return 0
    P = np.array(sorted(pairs)); i, j = P[:, 0], P[:, 1]
    share = (F[i][:, :, None] == F[j][:, None, :]).any(axis=(1, 2))
    i, j = i[~share], j[~share]
    box = np.all(lo[i] <= hi[j], axis=1) & np.all(lo[j] <= hi[i], axis=1)
    i, j = i[box], j[box]
    hit = np.zeros(len(i), bool)
    for A, B in ((i, j), (j, i)):
        for e in range(3):
            p0 = tri[A][:, e]; p1 = tri[A][:, (e + 1) % 3]
            hit |= _segment_triangle(p0, p1, tri[B])
    return int(hit.sum())

def validate_mesh(mesh, dx_m=None, min_wall_m=None, check_intersections=True) -> GeometryReport:
    import trimesh
    r = GeometryReport(n_vertices=len(mesh.vertices), n_faces=len(mesh.faces))
    edges = mesh.edges_sorted
    uniq, counts = np.unique(edges, axis=0, return_counts=True)
    r.open_boundary_edges = int((counts == 1).sum())
    r.non_manifold_edges = int((counts > 2).sum())
    r.watertight = bool(mesh.is_watertight)
    r.winding_consistent = bool(mesh.is_winding_consistent)
    r.signed_volume_m3 = float(mesh.volume)
    r.inverted = r.signed_volume_m3 < 0
    r.degenerate_faces = int((mesh.area_faces < 1e-18).sum())
    r.n_components = len(mesh.split(only_watertight=False))
    r.self_intersecting_pairs = count_self_intersections(mesh) if check_intersections else None
    if r.open_boundary_edges: r.messages.append(f"{r.open_boundary_edges} open boundary edges (holes)")
    if r.non_manifold_edges: r.messages.append(f"{r.non_manifold_edges} non-manifold edges")
    if r.inverted: r.messages.append("negative signed volume: faces inverted")
    if not r.winding_consistent: r.messages.append("inconsistent face winding")
    if r.self_intersecting_pairs is None: r.messages.append("self-intersection check skipped (mesh too large)")
    elif r.self_intersecting_pairs: r.messages.append(f"{r.self_intersecting_pairs} self-intersecting triangle pairs")
    if r.n_components > 1: r.messages.append(f"{r.n_components} disconnected components")
    return r

def thickness_report(mask, dx_m, min_wall_m=None, report: GeometryReport | None = None):
    """Voxel-based wall-thickness estimate. Resolution-limited: features thinner than ~2 dx are unreliable."""
    edt = ndi.distance_transform_edt(mask) * dx_m
    ridge = mask & (edt >= ndi.maximum_filter(edt, size=3) - 1e-12) & (edt > 0)
    tmin = float(2 * edt[ridge].min()) if ridge.any() else None
    thin = 0
    if min_wall_m:
        r_cells = max(1, int(np.ceil(0.5 * min_wall_m / dx_m)))
        local_max = ndi.maximum_filter(edt, size=2 * r_cells + 1)
        thin = int((mask & (2 * local_max < min_wall_m)).sum())
    if report is not None:
        report.min_wall_thickness_m = tmin; report.thin_wall_cells = thin; report.thin_wall_threshold_m = min_wall_m
        if thin: report.messages.append(f"{thin} cells in walls thinner than {min_wall_m*1e3:.1f} mm")
    return tmin, thin, edt

def component_count(mask):
    _, n = ndi.label(mask); return int(n)
