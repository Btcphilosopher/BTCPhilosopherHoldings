"""Geometry abstraction: procedural (SDF CSG) or imported surface mesh (STL/OBJ/VTK/PLY via trimesh/meshio).

Pipeline:  CAD/procedural  ->  surface mesh  ->  validation  ->  voxel (finite-volume) domain.
STEP is NOT read natively: it needs the optional `cadquery` (or gmsh) dependency; `from_step` raises a clear
error if unavailable.
"""
from __future__ import annotations
import hashlib
import numpy as np
from ..errors import GeometryError, MissingOptionalDependency
from .grid import Grid
from .sdf import Solid, sample
from . import validation as V

def mesh_hash(mesh) -> str:
    h = hashlib.sha256()
    h.update(np.round(np.asarray(mesh.vertices), 9).tobytes()); h.update(np.asarray(mesh.faces).tobytes())
    return h.hexdigest()[:16]

def voxel_surface_mesh(mask, grid: Grid):
    """Exact boundary-face mesh of a voxel set (blocky, watertight except at edge-diagonal contacts)."""
    import trimesh
    m = np.pad(mask, 1)
    quads = []
    for ax in range(3):
        for sgn in (-1, 1):
            nb = np.roll(m, sgn, axis=ax)
            face = m & ~nb
            idx = np.argwhere(face[1:-1, 1:-1, 1:-1]) if False else np.argwhere(face) - 1
            for (i, j, k) in idx:
                c = np.array([i, j, k], float)
                # face-plane corner offsets
                u = [1, 2, 0][ax]; v = [2, 0, 1][ax]
                base = c.copy(); base[ax] += 1 if sgn == 1 else 0
                e1 = np.zeros(3); e1[u] = 1; e2 = np.zeros(3); e2[v] = 1
                p = [base, base + e1, base + e1 + e2, base + e2]
                if sgn == -1: p = p[::-1]
                quads.append(p)
    if not quads: raise GeometryError("empty voxel set")
    q = np.array(quads)                                   # (n,4,3) in index units
    verts = q.reshape(-1, 3); faces = np.arange(len(verts)).reshape(-1, 4)
    tris = np.concatenate([faces[:, [0, 1, 2]], faces[:, [0, 2, 3]]])
    verts = grid.origin_m + verts * grid.dx_m
    mesh = trimesh.Trimesh(verts, tris, process=True)
    mesh.merge_vertices(); mesh.fix_normals()
    return mesh

class Geometry:
    """A solid, either procedural (callable SDF) or a triangle mesh."""
    def __init__(self, solid: Solid | None = None, mesh=None, name="geometry", bbox_m=None):
        if solid is None and mesh is None: raise GeometryError("need a solid or a mesh")
        self.solid, self.mesh, self.name = solid, mesh, name
        self._bbox = None if bbox_m is None else np.asarray(bbox_m, float)

    # ---- constructors ----
    @staticmethod
    def procedural(solid: Solid, bbox_m, name="procedural"):
        return Geometry(solid=solid, bbox_m=bbox_m, name=name)
    @staticmethod
    def from_mesh_file(path, scale_to_m=1.0):
        import trimesh
        m = trimesh.load(path, force="mesh")
        m.apply_scale(scale_to_m)
        return Geometry(mesh=m, name=str(path))
    @staticmethod
    def from_step(path, *a, **k):
        try:
            import cadquery  # noqa: F401
        except Exception as e:
            raise MissingOptionalDependency("STEP import requires the optional 'cadquery' package (pip install cadquery); "
                                            "alternatively export STL/OBJ/VTK from your CAD system") from e
        import cadquery as cq, tempfile, os
        shape = cq.importers.importStep(str(path))
        with tempfile.TemporaryDirectory() as td:
            stl = os.path.join(td, "m.stl"); cq.exporters.export(shape, stl, tolerance=0.01)
            return Geometry.from_mesh_file(stl, scale_to_m=1e-3)

    @property
    def bbox_m(self):
        if self._bbox is not None: return self._bbox
        b = self.mesh.bounds; return np.asarray(b)

    # ---- representations ----
    def mask_on(self, grid: Grid):
        if self.solid is not None: return sample(self.solid, grid) < 0
        import trimesh
        vox = trimesh.voxel.creation.voxelize(self.mesh, pitch=grid.dx_m).fill()
        mat = vox.matrix; origin = vox.translation - 0.5 * grid.dx_m
        out = np.zeros(grid.shape, bool)
        off = np.round((origin - np.asarray(grid.origin_m)) / grid.dx_m).astype(int)
        sl_src, sl_dst = [], []
        for a in range(3):
            s0 = max(0, -off[a]); d0 = max(0, off[a])
            n = min(mat.shape[a] - s0, grid.shape[a] - d0)
            if n <= 0: return out
            sl_src.append(slice(s0, s0 + n)); sl_dst.append(slice(d0, d0 + n))
        out[tuple(sl_dst)] = mat[tuple(sl_src)]
        return out

    def surface_mesh(self, pitch_m=None):
        """Triangle surface mesh. For procedural solids: marching cubes (scikit-image) on the SDF."""
        if self.mesh is not None: return self.mesh
        import trimesh
        b = self.bbox_m; pitch = pitch_m or float(np.min(b[1] - b[0])) / 60.0
        pad = 2 * pitch
        shape = tuple(int(np.ceil((b[1][i] - b[0][i] + 2 * pad) / pitch)) for i in range(3))
        g = Grid(shape, pitch, tuple(b[0] - pad))
        F = sample(self.solid, g)
        try:
            from skimage.measure import marching_cubes
            Fp = np.pad(F, 1, constant_values=1.0)
            verts, faces, _, _ = marching_cubes(Fp, level=0.0, spacing=(pitch,) * 3)
            verts = verts - pitch + np.asarray(g.origin_m) + 0.5 * pitch
            mesh = trimesh.Trimesh(verts, faces, process=True)
            mesh.update_faces(mesh.nondegenerate_faces())      # marching cubes emits zero-area slivers
            mesh.remove_unreferenced_vertices(); mesh.merge_vertices(); mesh.fix_normals()
        except ImportError:
            mesh = voxel_surface_mesh(F < 0, g)
        return mesh

    def validate(self, grid: Grid | None = None, min_wall_m=None, pitch_m=None):
        mesh = self.surface_mesh(pitch_m)
        rep = V.validate_mesh(mesh)
        if grid is not None:
            V.thickness_report(self.mask_on(grid), grid.dx_m, min_wall_m, rep)
        return rep, mesh

    def hash(self, pitch_m=None): return mesh_hash(self.surface_mesh(pitch_m))
