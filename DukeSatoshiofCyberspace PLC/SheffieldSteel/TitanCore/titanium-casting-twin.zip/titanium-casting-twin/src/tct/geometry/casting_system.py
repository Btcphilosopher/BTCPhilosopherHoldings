"""CastingSystem: Part, Mold/Shell, Sprue, Runner, Gate, Riser, Core, Filter, Pour basin, as one voxel model.

Roles (int8):   0 void/outside   1 part   2 riser   3 gate   4 runner   5 sprue   6 basin   7 filter
                8 shell/mold     9 core    10 chill
Thermal material ids (int8): 0 none, 1 metal(alloy), 2 mold(shell/graphite/...), 3 core(ceramic), 4 chill tooling.
"""
from __future__ import annotations
from dataclasses import dataclass, field
import numpy as np
from scipy import ndimage as ndi
from .grid import Grid
from .sdf import Solid, sample

PART, RISER, GATE, RUNNER, SPRUE, BASIN, FILTER, SHELL, CORE, CHILL = 1, 2, 3, 4, 5, 6, 7, 8, 9, 10
METAL_ROLES = (PART, RISER, GATE, RUNNER, SPRUE, BASIN, FILTER)
ROLE_NAMES = {0: "void", 1: "part", 2: "riser", 3: "gate", 4: "runner", 5: "sprue", 6: "basin", 7: "filter",
              8: "shell", 9: "core", 10: "chill"}
MAT_METAL, MAT_MOLD, MAT_CORE, MAT_CHILL = 1, 2, 3, 4

@dataclass
class CastingSystem:
    grid: Grid
    role: np.ndarray                  # int8 (nx,ny,nz)
    mat: np.ndarray                   # int8 thermal material id
    shell_thickness_m: float
    name: str = "casting"
    pour_axis: int = 2                # gravity along -z
    basin_fill_level_z_m: float = 0.0 # initial free surface of metal in the basin (absolute z)
    meta: dict = field(default_factory=dict)

    # ---- masks ----
    def mask(self, *roles): return np.isin(self.role, roles)
    @property
    def metal(self): return self.mat == MAT_METAL
    @property
    def mold(self): return self.mat == MAT_MOLD
    @property
    def cavity(self): return self.mask(PART, RISER, GATE, RUNNER, SPRUE, FILTER)   # filled progressively (basin pre-filled)

    def volume_m3(self, *roles): return float(self.mask(*roles).sum()) * self.grid.cell_volume_m3
    def volumes(self): return {ROLE_NAMES[r]: self.volume_m3(r) for r in ROLE_NAMES if self.mask(r).any()}

    def cooling_area_m2(self, *roles):
        """Surface area (m^2) of the given metal roles in contact with non-metal (mold/core/void)."""
        m = self.mask(*roles); metal_all = self.metal
        a = 0
        for ax in range(3):
            for s in (-1, 1):
                nb = np.roll(metal_all, s, axis=ax)
                # roll wraps; zero padding guaranteed by builder (>= 1 cell margin)
                a += (m & ~nb).sum()
        return float(a) * self.grid.dx_m ** 2

    def modulus_m(self, *roles):
        """Chvorinov modulus M = V/A_cool of a role group (rigorous, geometric)."""
        A = self.cooling_area_m2(*roles)
        return self.volume_m3(*roles) / A if A > 0 else 0.0

    def local_thickness_field_m(self):
        """2 x Euclidean distance to nearest non-metal cell (inscribed-diameter proxy); NOT a modulus."""
        return 2.0 * ndi.distance_transform_edt(self.metal) * self.grid.dx_m

    def feeder_mask(self): return self.mask(RISER, BASIN)

    def summary(self):
        return {"name": self.name, "grid": self.grid.to_dict(), "volumes_m3": self.volumes(),
                "shell_thickness_m": self.shell_thickness_m,
                "modulus_m": {n: self.modulus_m(r) for r, n in ((PART, "part"), (RISER, "riser"))
                              if self.mask(r).any()}}

def build_casting_system(solids: dict, dx_m: float, shell_thickness_m: float, pad_cells: int = 2,
                         name="casting", basin_fill_fraction=0.7, mold_kind="shell") -> CastingSystem:
    """solids: dict role-name -> Solid (SDF). Later roles in the order part,riser,gate,runner,sprue,filter,basin override earlier.
    'core' solid is a ceramic core (mold-like material) which is carved out of the metal."""
    order = ["part", "riser", "gate", "runner", "sprue", "filter", "basin"]
    ids = {"part": PART, "riser": RISER, "gate": GATE, "runner": RUNNER, "sprue": SPRUE, "filter": FILTER, "basin": BASIN}
    # bounding box from coarse probing: caller supplies bboxes through Solid.bbox if present; else use big probe
    lo = np.array([np.inf] * 3); hi = -lo.copy()
    for k, s in solids.items():
        bb = getattr(s, "bbox_m", None)
        if bb is None: raise ValueError(f"solid {k!r} needs .bbox_m = (lo, hi) in metres")
        lo = np.minimum(lo, bb[0]); hi = np.maximum(hi, bb[1])
    margin = shell_thickness_m + pad_cells * dx_m
    lo = lo - margin; hi = hi + margin
    shape = tuple(int(np.ceil((hi[i] - lo[i]) / dx_m)) for i in range(3))
    grid = Grid(shape, dx_m, tuple(lo))
    X, Y, Z = grid.centers()
    role = np.zeros(shape, np.int8)
    for k in order:
        if k in solids: role[solids[k](X, Y, Z) < 0] = ids[k]
    if "core" in solids:
        core = solids["core"](X, Y, Z) < 0
        role[core] = CORE
    metal = np.isin(role, METAL_ROLES)
    core = role == CORE
    dist = ndi.distance_transform_edt(~(metal | core)) * dx_m
    shell = (~metal) & (~core) & (dist <= shell_thickness_m + 1e-12)
    role[shell] = SHELL
    mat = np.zeros(shape, np.int8)
    mat[metal] = MAT_METAL; mat[shell] = MAT_MOLD; mat[core] = MAT_CORE
    # basin initial level (reservoir pre-filled to a fraction of basin height)
    bz = Z[role == BASIN]
    basin_level = (bz.min() + basin_fill_fraction * (bz.max() - bz.min() + dx_m)) if bz.size else float(lo[2])
    cs = CastingSystem(grid, role, mat, shell_thickness_m, name=name, basin_fill_level_z_m=float(basin_level),
                       meta={"mold_kind": mold_kind})
    return cs
