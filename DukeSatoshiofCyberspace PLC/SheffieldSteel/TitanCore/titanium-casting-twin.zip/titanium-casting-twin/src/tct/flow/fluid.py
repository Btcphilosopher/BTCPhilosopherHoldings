"""Temperature-dependent molten-titanium fluid properties and dimensionless numbers."""
from __future__ import annotations
import numpy as np
from ..units import G_ACC

def fluid_props(alloy, T_C):
    T = np.asarray(T_C, float)
    return {"rho": alloy.density_kg_m3(T), "mu": alloy.apparent_viscosity_Pa_s(T),
            "sigma": alloy.tables["surface_tension"](np.maximum(T, alloy.T_liquidus_C)),
            "cp": alloy.tables["specific_heat"](T), "k": alloy.tables["thermal_conductivity"](T)}

def reynolds(rho, v, D, mu): return rho * v * D / mu
def prandtl(mu, cp, k): return mu * cp / k
def weber(rho, v, L, sigma): return rho * v * v * L / sigma

def nusselt(Re, Pr):
    """Internal-flow Nusselt number. Laminar (Re<2300): 3.66 (const wall T, fully developed). Otherwise Gnielinski with
    Petukhov friction factor, blended linearly 2300..4000. EMPIRICAL correlations; validity 0.5<Pr<2000, 3e3<Re<5e6 (turbulent)."""
    Re = np.asarray(Re, float); Pr = np.asarray(Pr, float)
    f = (0.79 * np.log(np.maximum(Re, 3000.0)) - 1.64) ** -2
    nu_t = (f / 8) * (np.maximum(Re, 3000.0) - 1000.0) * Pr / (1 + 12.7 * np.sqrt(f / 8) * (Pr ** (2 / 3) - 1))
    w = np.clip((Re - 2300.0) / 1700.0, 0.0, 1.0)
    return (1 - w) * 3.66 + w * np.maximum(nu_t, 3.66)

def flow_regime(Re):
    Re = np.asarray(Re, float)
    return np.where(Re < 2300, 0, np.where(Re < 4000, 1, 2)).astype(np.int8)   # 0 laminar, 1 transitional, 2 turbulent
REGIME_NAMES = {0: "laminar", 1: "transitional", 2: "turbulent"}

def turbulence_intensity(Re):
    """Pipe-flow estimate I = 0.16 Re^(-1/8) for Re>2300 else 0 (EMPIRICAL approximation)."""
    Re = np.asarray(Re, float)
    return np.where(Re > 2300, 0.16 * np.maximum(Re, 1.0) ** (-0.125), 0.0)

def critical_velocity_m_s(sigma, rho):
    """Surface-turbulence critical velocity scale v = (4 g sigma / rho)^(1/4) (after Campbell's bifilm argument;
    literature-derived SCALING, order 0.3-0.5 m/s for light metals; not a sharp threshold)."""
    return (4.0 * G_ACC * sigma / rho) ** 0.25
