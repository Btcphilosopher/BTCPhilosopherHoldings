"""Reduced-order free-surface fill model.  STATUS: REDUCED-ORDER (graph / flux-conserving), not CFD.

Method
  1. Gating hydraulics (extended Bernoulli, lumped losses):
        Q = A_g * sqrt( 2 g H_eff / (1 + sum K) ),      H_eff = z_basin(t) - z_front(V_filled)
     with basin mass balance dz_b/dt = (Q_in - Q)/A_b. Optional Darcy-Forchheimer filter loss.
  2. Front kinematics: gravity-biased geodesic arrival cost c(x) (Dijkstra on the 6-connected cell graph,
     edge cost dx*(1 + beta*dz)). Cells fill in cost order; the cumulative filled volume V(t) from (1) fixes arrival times.
  3. Flux conservation: through every iso-cost surface the flow rate equals Q(t); local speed v = Q(t)/A(c), A(c)=dV/dc.
     Direction = grad c / |grad c|.  (A potential-flow-like, mass-conserving velocity field; no momentum equation.)
  4. Thermal: parcel lumped cooling (energy balance including latent heat) during transit and dwell,
        rho(D/4) dh/dt = -h_eff (T - T_mold),    h_eff = series(h_contact, Nu k / D_local).
  5. Indicators: misrun (arrival solid fraction), cold shut (front confluence + arrival superheat), air entrainment
        (v / v_crit, Campbell-type), Re, We, regime.
Architecture hook: `FillSolver` implements `run() -> FillResult`; a VOF / level-set / SPH / FV-CFD solver can replace it
by returning the same FillResult fields (arrival_time, T_end, snapshot()).
Validity: gravity-driven, quiescent-to-moderate fills of connected cavities. Momentum, jetting, splashing, gas-back-pressure
and surface-tension-driven front dynamics are NOT resolved.
"""
from __future__ import annotations
from dataclasses import dataclass, field
import numpy as np
from scipy import ndimage as ndi
from scipy.sparse import csr_matrix
from scipy.sparse.csgraph import dijkstra
from ..units import G_ACC
from ..errors import ConfigurationError, ConservationViolation
from ..geometry.casting_system import CastingSystem, PART, RISER, GATE, RUNNER, SPRUE, BASIN, FILTER
from ..materials.alloy import Alloy, T_GRID_C
from . import fluid as F

@dataclass
class FilterConfig:
    permeability_m2: float = 1e-8       # Darcy k1
    inertial_coeff_m: float = 1e-4      # Forchheimer k2
    thickness_m: float = 0.01

@dataclass
class PourConfig:
    pour_temperature_C: float = 1700.0
    pour_rate_kg_s: float | None = 1.0      # None => unlimited reservoir at constant level
    mold_temperature_C: float = 850.0
    chamber_pressure_Pa: float = 1.0
    gravity_bias: float = 0.5               # beta in edge cost (EMPIRICAL)
    contact_h_W_m2K: float = 1500.0         # metal/mold conductance during fill (EMPIRICAL, calibratable)
    K_entry: float = 0.5                    # sprue entry loss coefficient (ESTIMATED)
    K_bends: float = 0.6                    # lumped bends/junctions (ESTIMATED)
    friction_factor: float = 0.03           # Darcy f in runner (ESTIMATED)
    fs_coherency: float = 0.5               # solid fraction at which arriving metal is considered non-fillable
    cold_shut_margin_K: float = 40.0        # superheat at confluence below which risk -> 1 (ESTIMATED)
    filter: FilterConfig | None = None
    dt_s: float = 0.002
    shell_effusivity: float | None = None   # sqrt(k rho cp) of the mold at preheat; adds semi-infinite-wall resistance sqrt(pi t)/e in series

@dataclass
class FillResult:
    cs: CastingSystem
    cells: np.ndarray                  # (n,3) ijk of cavity cells
    arrival_time_s: np.ndarray         # (n,)
    cost_m: np.ndarray                 # (n,)
    T_arrival_C: np.ndarray            # (n,)
    T_end_C: np.ndarray                # (n,) temperature at end of fill
    speed_scale: np.ndarray            # (n,) 1/A(c)  [1/m^2]  (v = Q(t) * speed_scale)
    direction: np.ndarray              # (n,3)
    local_thickness_m: np.ndarray      # (n,)
    z_cell_m: np.ndarray
    t_hist: np.ndarray; Q_hist: np.ndarray; V_hist: np.ndarray; zb_hist: np.ndarray
    fill_time_s: float
    alloy: Alloy
    pour: PourConfig
    basin_cells: np.ndarray
    risks: dict
    scalars: dict
    checks: dict
    model: str = "REDUCED-ORDER"
    _transit: np.ndarray = None

    def Q_at(self, t): return float(np.interp(t, self.t_hist, self.Q_hist))
    def zb_at(self, t): return float(np.interp(t, self.t_hist, self.zb_hist))

    def to_grid(self, a, fill=np.nan, dtype=np.float64):
        out = np.full(self.cs.grid.shape, fill, dtype); out[tuple(self.cells.T)] = a; return out

    def snapshot(self, t):
        """Fields at time t on the cavity cells: fill_fraction, T, velocity (vx,vy,vz), pressure."""
        cell_vol = self.cs.grid.cell_volume_m3
        dt_cell = 0.5 * self.cs.grid.dx_m / max(self.scalars["mean_front_speed_m_s"], 1e-3)
        frac = np.clip((t - (self.arrival_time_s - dt_cell)) / (2 * dt_cell), 0.0, 1.0)
        filled = self.arrival_time_s <= t
        Q = self.Q_at(t)
        v = np.where(filled, Q * self.speed_scale, 0.0) if t < self.fill_time_s else np.zeros_like(self.speed_scale)
        vec = self.direction * v[:, None]
        rho = float(self.alloy.density_kg_m3(self.pour.pour_temperature_C))
        zb = self.zb_at(t)
        p = self.pour.chamber_pressure_Pa + rho * G_ACC * np.maximum(zb - self.z_cell_m, 0.0) - 0.5 * rho * v * v
        p = np.where(filled, np.maximum(p, 0.0), 0.0)
        T = self.temperature_at(t)
        return {"fill_fraction": frac, "temperature_C": T, "velocity_m_s": vec, "pressure_Pa": p}

    def temperature_at(self, t):
        dwell = np.clip(t - self.arrival_time_s, 0.0, None)
        T = _dwell_cool(self.alloy, self.T_arrival_C, dwell, self.local_thickness_m, self.pour, t_offset=self._transit)
        return np.where(self.arrival_time_s <= t, T, np.nan)

def _dwell_cool(alloy, T0, dwell, D, pour, nsub=60, t_offset=0.0, h_fluid=None):
    """Lumped parcel cooling with latent heat (vectorised explicit sub-stepping), EMPIRICAL / REDUCED-ORDER.
    Heat-transfer coefficient = series( interface contact h(fl), semi-infinite mold wall sqrt(pi t)/e , melt-side h_fluid )."""
    h_tab = alloy.enthalpy_table_J_kg()
    h = np.interp(T0, T_GRID_C, h_tab)
    T = np.asarray(T0, float).copy()
    rho = float(alloy.density_kg_m3(alloy.T_liquidus_C + 50.0))
    dts = np.asarray(dwell, float) / nsub
    Tm = pour.mold_temperature_C
    e = getattr(pour, "shell_effusivity", None)
    elapsed = np.asarray(t_offset, float) * np.ones_like(T)
    for _ in range(nsub):
        fl = np.clip((T - alloy.T_solidus_C) / (alloy.T_liquidus_C - alloy.T_solidus_C), 0, 1)
        hc = 350.0 + (pour.contact_h_W_m2K - 350.0) * fl
        R = 1.0 / hc
        if e: R = R + np.sqrt(np.pi * (elapsed + 0.02 + 0.5 * dts)) / e
        if h_fluid is not None: R = R + 1.0 / h_fluid
        h = h - (4.0 / (rho * np.maximum(D, 1e-4) * R)) * (T - Tm) * dts
        T = np.interp(h, h_tab, T_GRID_C); elapsed = elapsed + dts
    return T

class FillSolver:
    def __init__(self, cs: CastingSystem, alloy: Alloy, pour: PourConfig | None = None):
        self.cs, self.alloy = cs, alloy
        self.pour = pour or PourConfig()

    # ------------------------------------------------------------------
    def _cross_sections(self):
        g = self.cs.grid; dx = g.dx_m; cs = self.cs
        out = {}
        sp = cs.mask(SPRUE)
        if sp.any():
            counts = sp.sum(axis=(0, 1)); out["A_sprue"] = float(counts[counts > 0].min()) * dx * dx
        part = cs.mask(PART, RISER); gate = cs.mask(GATE)
        if gate.any():
            faces = 0
            for ax in range(3):
                for s in (-1, 1):
                    faces += (gate & np.roll(part, s, axis=ax)).sum()
            out["A_gate"] = float(max(faces, 1)) * dx * dx
        rn = cs.mask(RUNNER)
        if rn.any():
            idx = np.argwhere(rn); ext = (idx.max(0) - idx.min(0) + 1) * dx
            out["A_runner"] = float(rn.sum()) * dx ** 3 / float(ext.max()); out["L_runner"] = float(ext.max())
        fl = cs.mask(FILTER)
        if fl.any():
            counts = fl.sum(axis=(0, 1)); out["A_filter"] = float(counts[counts > 0].max()) * dx * dx
        return out

    def run(self) -> FillResult:
        cs, al, pour = self.cs, self.alloy, self.pour
        g = cs.grid; dx = g.dx_m
        if not (0 <= pour.gravity_bias < 1): raise ConfigurationError("gravity_bias must be in [0,1)")
        cav = cs.cavity
        cells = np.argwhere(cav); n = len(cells)
        if n == 0: raise ConfigurationError("empty cavity")
        lin = -np.ones(g.shape, np.int64); lin[tuple(cells.T)] = np.arange(n)
        # sources
        basin = cs.mask(BASIN)
        if basin.any():
            src_mask = np.zeros(g.shape, bool)
            for ax in range(3):
                for s in (-1, 1):
                    src_mask |= cav & np.roll(basin, s, axis=ax)
            src = np.flatnonzero(src_mask[tuple(cells.T)])
            z_basin_bottom = float(g.centers()[2][basin].min()); basin_area = float(basin.sum(axis=(0, 1)).max()) * dx * dx
            zb0 = cs.basin_fill_level_z_m; z_basin_top = float(g.centers()[2][basin].max() + 0.5 * dx)
        else:
            zc = cells[:, 2]; src = np.flatnonzero(zc == zc.min())
            z_basin_bottom = float(g.origin_m[2] + (zc.min()) * dx); basin_area = 1.0
            zb0 = z_basin_bottom + 0.1; z_basin_top = zb0
        if src.size == 0: raise ConfigurationError("basin does not touch the cavity (no sprue connection)")
        # graph
        rows, cols, w = [], [], []
        beta = pour.gravity_bias
        for ax in range(3):
            for s in (-1, 1):
                nb = cells.copy(); nb[:, ax] += s
                ok = (nb[:, ax] >= 0) & (nb[:, ax] < g.shape[ax])
                j = np.full(n, -1, np.int64); j[ok] = lin[tuple(nb[ok].T)]
                sel = j >= 0
                rows.append(np.flatnonzero(sel)); cols.append(j[sel])
                wt = dx * (1.0 + (beta * s if ax == 2 else 0.0))
                w.append(np.full(sel.sum(), wt))
        G = csr_matrix((np.concatenate(w), (np.concatenate(rows), np.concatenate(cols))), shape=(n, n))
        dist, pred, srcs = dijkstra(G, directed=True, indices=src, return_predecessors=True, min_only=True)
        if not np.all(np.isfinite(dist)):
            raise ConfigurationError(f"{int((~np.isfinite(dist)).sum())} cavity cells are not reachable from the pour basin (disconnected gating)")
        # ordering + volumes
        order = np.argsort(dist, kind="stable")
        vol = dx ** 3
        cumV = (np.arange(n) + 1.0) * vol
        Vmid = np.empty(n); Vmid[order] = cumV - 0.5 * vol
        V_total = n * vol
        cs_sorted = dist[order]
        zc_m = g.origin_m[2] + (cells[:, 2] + 0.5) * dx
        zs = zc_m[order]; csz = np.concatenate([[0.0], np.cumsum(zs)])
        start = np.searchsorted(cs_sorted, cs_sorted - 2.0 * dx, side="left")
        idx = np.arange(n)
        front_z_sorted = (csz[idx + 1] - csz[start]) / (idx + 1 - start)
        # A(c) = dV/dc
        D = 1.5 * dx
        Vc_hi = np.interp(dist + D, cs_sorted, cumV, right=V_total); Vc_lo = np.interp(dist - D, cs_sorted, cumV, left=0.0)
        Ac = np.maximum((Vc_hi - Vc_lo) / (np.minimum(dist + D, cs_sorted[-1]) - np.maximum(dist - D, 0.0) + 1e-12), 0.5 * dx * dx)
        # gating hydraulics
        xs = self._cross_sections()
        A_s = xs.get("A_sprue", np.inf); A_g = xs.get("A_gate", A_s if np.isfinite(A_s) else Ac.max())
        A_r = xs.get("A_runner", A_s if np.isfinite(A_s) else A_g)
        K = 0.0
        if np.isfinite(A_s): K += pour.K_entry * (A_g / A_s) ** 2
        K += pour.K_bends * (A_g / A_r) ** 2
        Dh = 2.0 * np.sqrt(A_r / np.pi)
        if "L_runner" in xs: K += pour.friction_factor * xs["L_runner"] / Dh * (A_g / A_r) ** 2
        K += 0.5 * (1.0 - min(A_g / A_r, 1.0)) ** 0.75
        rho_l = float(al.density_kg_m3(pour.pour_temperature_C)); mu_l = float(al.apparent_viscosity_Pa_s(pour.pour_temperature_C))
        flt = pour.filter
        # ODE
        Qin = (pour.pour_rate_kg_s / rho_l) if pour.pour_rate_kg_s else None
        t = 0.0; Vf = 0.0; zb = zb0; dt = pour.dt_s
        th, Qh, Vh, zbh = [0.0], [0.0], [0.0], [zb0]
        front_z_of_V = lambda V: np.interp(V, cumV, front_z_sorted)
        n_it = 0
        while Vf < V_total - 1e-12 and n_it < 2_000_000:
            H = max(zb - front_z_of_V(Vf), 0.0)
            denom = 1.0 + K
            Qout = A_g * np.sqrt(2 * G_ACC * H / denom)
            if flt is not None and "A_filter" in xs:
                v_f = Qout / xs["A_filter"]
                dP = (mu_l / flt.permeability_m2) * v_f * flt.thickness_m + (rho_l / flt.inertial_coeff_m) * v_f * v_f * flt.thickness_m
                Hf = dP / (rho_l * G_ACC)
                H = max(H - Hf, 0.0); Qout = A_g * np.sqrt(2 * G_ACC * H / denom)
            if Qin is None:
                Q = Qout; dzb = 0.0
            else:
                avail = Qin + max(zb - z_basin_bottom, 0.0) * basin_area / dt     # cannot drain more than present
                Q = min(Qout, avail)
                dzb = (Qin - Q) / basin_area
            if Q <= 0.0 and Qin is not None and zb >= z_basin_top - 1e-9:
                raise ConservationViolation("basin full and no outflow: cavity cannot fill (zero driving head)")
            Vf = min(Vf + Q * dt, V_total); zb = min(zb + dzb * dt, z_basin_top); t += dt; n_it += 1
            if n_it % 5 == 0 or Vf >= V_total: th.append(t); Qh.append(Q); Vh.append(Vf); zbh.append(zb)
            if H <= 1e-9 and Q <= 1e-15 and n_it > 1000 and Qin is None:
                raise ConservationViolation("zero driving head before cavity is full (insufficient metallostatic head): MISRUN")
        if n_it >= 2_000_000: raise ConservationViolation("fill did not complete (>2e6 steps)")
        th, Qh, Vh, zbh = map(np.array, (th, Qh, Vh, zbh))
        # arrival times (invert V(t))
        _, uniq = np.unique(Vh, return_index=True)
        arrival = np.interp(Vmid, Vh[uniq], th[uniq])
        t_fill = float(th[-1])
        # speeds / directions
        speed_scale = 1.0 / Ac
        grad = np.zeros((n, 3))
        for ax in range(3):
            jm = np.full(n, -1); jp = np.full(n, -1)
            for s, arr in ((-1, jm), (1, jp)):
                nb = cells.copy(); nb[:, ax] += s
                ok = (nb[:, ax] >= 0) & (nb[:, ax] < g.shape[ax]); arr[ok] = lin[tuple(nb[ok].T)]
            hm, hp = jm >= 0, jp >= 0
            gv = np.zeros(n)
            both = hm & hp; gv[both] = (dist[jp[both]] - dist[jm[both]]) / (2 * dx)
            only_p = hp & ~hm; gv[only_p] = (dist[jp[only_p]] - dist[only_p]) / dx
            only_m = hm & ~hp; gv[only_m] = (dist[only_m] - dist[jm[only_m]]) / dx
            grad[:, ax] = gv
        gn = np.linalg.norm(grad, axis=1); direction = grad / np.maximum(gn, 1e-12)[:, None]
        # local thickness
        thick = (2.0 * ndi.distance_transform_edt(cs.metal) * dx)[tuple(cells.T)]
        thick = np.maximum(thick, dx)
        # travel (transit) time along shortest-path tree
        Q_at_arr = np.interp(arrival, th, Qh)
        v_loc = np.maximum(Q_at_arr * speed_scale, 1e-3)
        transit = np.zeros(n)
        for k in order:
            p = pred[k]
            if p >= 0: transit[k] = transit[p] + dx / v_loc[k]
        # thermal state at arrival (transit cooling), then end-of-fill (dwell)
        Tpour = pour.pour_temperature_C
        fp = F.fluid_props(al, Tpour)
        Re_arr = F.reynolds(fp["rho"], v_loc, thick, fp["mu"]); Pr = F.prandtl(fp["mu"], fp["cp"], fp["k"])
        Nu = F.nusselt(Re_arr, Pr); h_fluid = Nu * fp["k"] / thick
        h_eff = 1.0 / (1.0 / pour.contact_h_W_m2K + 1.0 / h_fluid)
        T_arr = _dwell_cool(al, np.full(n, Tpour), transit, thick, pour, nsub=80, t_offset=0.0, h_fluid=h_fluid)
        T_end = _dwell_cool(al, T_arr, np.maximum(t_fill - arrival, 0.0), thick, pour, nsub=60, t_offset=transit)
        # indicators
        fs_arr = al.solid_fraction(T_arr)
        misrun = np.clip(fs_arr / pour.fs_coherency, 0.0, 1.0)
        # confluence (fronts from different gates meet)
        label = np.full(n, -1)
        gate_cells = cs.mask(GATE)[tuple(cells.T)]
        gl, ng = ndi.label(cs.mask(GATE)); gate_id = gl[tuple(cells.T)]
        for k in order:
            if gate_cells[k]: label[k] = gate_id[k]
            elif pred[k] >= 0: label[k] = label[pred[k]]
        confl = np.zeros(n, bool)
        for ax in range(3):
            nb = cells.copy(); nb[:, ax] += 1
            ok = nb[:, ax] < g.shape[ax]; j = np.full(n, -1); j[ok] = lin[tuple(nb[ok].T)]
            sel = (j >= 0)
            a = np.flatnonzero(sel); b = j[sel]
            diff = (label[a] != label[b]) & (label[a] >= 0) & (label[b] >= 0)
            # ignore interfaces inside the gating system itself
            part_like = np.isin(cs.role[tuple(cells.T)], (PART, RISER))
            diff &= part_like[a] & part_like[b]
            confl[a[diff]] = True; confl[b[diff]] = True
        cold_shut = np.where(confl, np.clip(1.0 - (T_arr - al.T_liquidus_C) / pour.cold_shut_margin_K, 0.0, 1.0), 0.0)
        v_crit = float(F.critical_velocity_m_s(fp["sigma"], fp["rho"]))
        air_idx = np.maximum(v_loc / v_crit - 1.0, 0.0)
        v_gate = float(np.sqrt(2 * G_ACC * max(zb0 - float(front_z_of_V(0.0)), 0.0) / (1.0 + K)))
        We = F.weber(fp["rho"], v_loc, thick, fp["sigma"])
        regime = F.flow_regime(Re_arr)
        # checks
        V_end = float(Vh[-1]); mass_err = abs(V_end - V_total) / V_total
        checks = {"volume_conservation_rel_err": mass_err,
                  "arrival_monotone_with_cost": bool(np.all(np.diff(arrival[order]) >= -1e-9)),
                  "all_cavity_reached": True}
        if mass_err > 1e-6: raise ConservationViolation(f"fill volume imbalance {mass_err:.2e}")
        part_sel = cs.role[tuple(cells.T)] == PART
        scal = {"fill_time_s": t_fill, "V_cavity_m3": V_total, "Q_peak_m3_s": float(Qh.max()), "Q_mean_m3_s": V_total / t_fill,
                "K_total": float(K), "A_gate_m2": float(A_g), "A_sprue_m2": float(A_s) if np.isfinite(A_s) else None,
                "v_gate_m_s": v_gate, "v_crit_m_s": v_crit, "gating_pressure_loss_Pa": float(K * 0.5 * rho_l * v_gate ** 2),
                "mean_front_speed_m_s": float(np.mean(v_loc)), "max_front_speed_m_s": float(v_loc.max()),
                "Re_max": float(Re_arr.max()), "Re_mean": float(Re_arr.mean()), "Pr": float(Pr),
                "Nu_mean": float(Nu.mean()), "regime_fraction_turbulent": float((regime == 2).mean()),
                "T_arrival_min_C": float(T_arr.min()), "T_arrival_part_min_C": float(T_arr[part_sel].min()) if part_sel.any() else None,
                "misrun_volume_fraction": float((misrun >= 1.0).mean()),
                "cold_shut_max": float(cold_shut.max()), "air_entrainment_index_max": float(air_idx.max()),
                "air_entrainment_index_part_max": float(air_idx[part_sel].max()) if part_sel.any() else None,
                "weber_max": float(We.max()), "basin_residual_level_m": float(zbh[-1])}
        risks = {"misrun_risk": misrun, "cold_shut_risk": cold_shut, "air_entrainment_index": air_idx,
                 "reynolds": Re_arr, "weber": We, "flow_regime": regime, "turbulence_intensity": F.turbulence_intensity(Re_arr),
                 "front_speed_m_s": v_loc, "confluence": confl.astype(np.int8), "local_thickness_m": thick}
        basin_cells = np.argwhere(basin) if basin.any() else np.zeros((0, 3), int)
        return FillResult(cs, cells, arrival, dist, T_arr, T_end, speed_scale, direction, thick, zc_m, th, Qh, Vh, zbh, t_fill,
                          al, pour, basin_cells, risks, scal, checks, _transit=transit)
