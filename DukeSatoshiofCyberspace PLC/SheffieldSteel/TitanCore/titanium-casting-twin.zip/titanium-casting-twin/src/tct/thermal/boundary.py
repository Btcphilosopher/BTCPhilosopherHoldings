"""Explicit thermal boundary conditions.

    BoundaryCondition(type="radiation", emissivity=..., surrounding_temperature_C=...)
Radiation:    q = eps * sigma * (T_s^4 - T_sur^4)   [W/m^2, kelvin inside]
Convection:   q = h (T_s - T_amb)
Vacuum radiation = radiation only (no convection term). Applied on faces of the active domain that border void.
The effective boundary law for a class is radiation + convection; `contact` / `mold_conduction` are interface models.
"""
from __future__ import annotations
from dataclasses import dataclass
from ..errors import ConfigurationError

_TYPES = ("radiation", "convection", "adiabatic", "fixed_temperature", "contact", "mold_conduction")

@dataclass
class BoundaryCondition:
    type: str
    emissivity: float | None = None                 # -1/None => use the surface material's own emissivity table
    surrounding_temperature_C: float | None = None
    h_W_m2K: float | None = None
    ambient_temperature_C: float | None = None
    fixed_temperature_C: float | None = None
    region: int = 0                                 # boundary class id (0 = default outer surface)
    def validate(self):
        if self.type not in _TYPES: raise ConfigurationError(f"unknown BC type {self.type!r}; {_TYPES}")
        if self.type == "radiation":
            if self.surrounding_temperature_C is None: raise ConfigurationError("radiation BC needs surrounding_temperature_C")
            if self.emissivity is not None and not (0.0 <= self.emissivity <= 1.0): raise ConfigurationError("emissivity must be in [0,1]")
        if self.type == "convection":
            if self.h_W_m2K is None or self.h_W_m2K < 0 or self.ambient_temperature_C is None:
                raise ConfigurationError("convection BC needs h_W_m2K >= 0 and ambient_temperature_C")
        if self.type == "fixed_temperature" and self.fixed_temperature_C is None:
            raise ConfigurationError("fixed_temperature BC needs fixed_temperature_C")
        return self

def compile_boundary(bcs, vacuum: bool):
    """-> arrays (eps, T_sur_C, h, T_amb_C, T_fix_C) indexed by region id; eps<0 means 'material emissivity'."""
    nreg = max([b.region for b in bcs] + [0]) + 1
    eps = -np_ones(nreg); Tsur = np_full(nreg, 20.0); h = np_zeros(nreg); Tamb = np_full(nreg, 20.0); Tfix = np_full(nreg, -1e9)
    for b in bcs:
        b.validate(); r = b.region
        if b.type == "radiation":
            eps[r] = -1.0 if b.emissivity is None else b.emissivity; Tsur[r] = b.surrounding_temperature_C
        elif b.type == "convection" and not vacuum:
            h[r] = b.h_W_m2K; Tamb[r] = b.ambient_temperature_C
        elif b.type == "adiabatic":
            eps[r] = 0.0; h[r] = 0.0
        elif b.type == "fixed_temperature":
            Tfix[r] = b.fixed_temperature_C
    return eps, Tsur, h, Tamb, Tfix

import numpy as _np
def np_ones(n): return _np.ones(n)
def np_zeros(n): return _np.zeros(n)
def np_full(n, v): return _np.full(n, float(v))
