"""ThermalSolver: wraps the kernel, owns the state, performs numerical-quality and conservation checks.

Never silently continues through instability: NaN / out-of-range temperature raises NumericalInstability.
Energy balance: dE_internal + E_lost_to_boundaries = 0 up to round-off (forward-Euler FV is exactly conservative).
"""
from __future__ import annotations
from dataclasses import dataclass
import numpy as np
from ..errors import NumericalInstability
from ..geometry.casting_system import CastingSystem, MAT_METAL
from ..materials.alloy import Alloy, T_GRID_C
from ..materials import kinetics
from .mold import MoldMaterial, ceramic_shell
from .boundary import BoundaryCondition, compile_boundary
from . import kernel as K

T0_GRID = float(T_GRID_C[0]); DT_GRID = float(T_GRID_C[1] - T_GRID_C[0])

@dataclass
class SolverConfig:
    safety: float = 0.45
    dt_max_s: float = 2.0
    max_steps_per_call: int = 2_000_000
    vacuum: bool = True

class ThermalSolver:
    def __init__(self, cs: CastingSystem, alloy: Alloy, mold: MoldMaterial | None = None,
                 core_mold: MoldMaterial | None = None, bcs=None, T_metal_C=None, T_mold0_C=850.0,
                 thresholds_C=None, config: SolverConfig | None = None, rho_ref_kg_m3=None):
        self.cs, self.alloy = cs, alloy
        self.cfg = config or SolverConfig()
        mold = mold or ceramic_shell(); core_mold = core_mold or mold
        self.mold, self.core_mold = mold, core_mold
        g = cs.grid
        act = np.argwhere(cs.mat > 0)
        self.act = act                                           # (n,3) ijk of active cells
        lin = -np.ones(g.shape, np.int64); lin[tuple(act.T)] = np.arange(len(act))
        self.lin = lin
        n = len(act)
        nbr = -np.ones((n, 6), np.int64)
        for ax in range(3):
            for s, col in ((-1, 2 * ax), (1, 2 * ax + 1)):
                nb = act.copy(); nb[:, ax] += s
                ok = (nb[:, ax] >= 0) & (nb[:, ax] < g.shape[ax])
                v = np.full(n, -1, np.int64)
                v[ok] = lin[tuple(nb[ok].T)]
                nbr[:, col] = v
        self.nbr = nbr
        self.mat = cs.mat[tuple(act.T)].astype(np.int64)
        self.is_metal = self.mat == MAT_METAL
        self.reg = np.zeros(n, np.int64)
        # tables [mat id 0..4]
        nT = len(T_GRID_C)
        self.ktab = np.ones((5, nT)); self.Htab = np.tile(np.arange(nT, dtype=float), (5, 1)); self.epstab = np.full((5, nT), 0.8)
        rho_ref = rho_ref_kg_m3 or float(alloy.density_kg_m3(alloy.T_liquidus_C + 50.0))   # conserved mass per cell (see thermodynamics.py)
        self.rho_ref = rho_ref
        h = alloy.enthalpy_table_J_kg()
        self.ktab[1] = alloy.tables["thermal_conductivity"](T_GRID_C)
        self.Htab[1] = rho_ref * h
        self.epstab[1] = alloy.tables["emissivity"](T_GRID_C)
        for mid, mm in ((2, mold), (3, core_mold), (4, mold)):
            self.ktab[mid] = mm.k_table(); self.Htab[mid] = mm.enthalpy_vol_table(); self.epstab[mid] = mm.eps_table()
        for r in range(5):
            if not np.all(np.diff(self.Htab[r]) > 0): raise NumericalInstability(f"non-monotone enthalpy table for material {r}")
        self.h_hot = np.array([1.0, 1.0, mold.h_contact_hot_W_m2K, core_mold.h_contact_hot_W_m2K, mold.h_contact_hot_W_m2K])
        self.h_cold = np.array([1.0, 1.0, mold.h_contact_cold_W_m2K, core_mold.h_contact_cold_W_m2K, mold.h_contact_cold_W_m2K])
        bcs = bcs if bcs is not None else [BoundaryCondition("radiation", emissivity=None, surrounding_temperature_C=100.0)]
        self.bcs = bcs
        self.eps_reg, self.Tsur_reg, self.h_reg, self.Tamb_reg, self.Tfix_reg = compile_boundary(bcs, self.cfg.vacuum)
        # initial state
        if T_metal_C is None: T_metal_C = alloy.T_liquidus_C + 100.0
        Tinit = np.where(self.is_metal, 0.0, T_mold0_C)
        if np.isscalar(T_metal_C): Tinit[self.is_metal] = T_metal_C
        else: Tinit[self.is_metal] = np.asarray(T_metal_C)[tuple(act[self.is_metal].T)]
        self.T = Tinit.astype(float)
        self.Hv = np.array([np.interp(self.T[i], T_GRID_C, self.Htab[self.mat[i]]) for i in range(n)]) if n < 3000 else \
                  self._Hv_from_T(self.T)
        self.t = 0.0
        self.steps = 0
        self.E_loss_J = 0.0
        self.E0_J = self.internal_energy_J()
        # events
        self.th = np.asarray(thresholds_C if thresholds_C is not None else
                             [alloy.T_liquidus_C, alloy.T_solidus_C, 1000.0, 800.0], float)
        self.th = np.ascontiguousarray(self.th)
        nth = len(self.th)
        self.t_cross = np.full((nth, n), np.nan); self.cr_cross = np.full((nth, n), np.nan); self.g_cross = np.full((nth, n), np.nan)
        self.Tpeak = self.T.copy(); self.t_above_beta = np.zeros(n); self.Dint = np.zeros(n)
        self.f_alpha = np.zeros(n)
        pm = alloy.phase_model()
        self.feq_lut = pm.f_alpha_eq(T_GRID_C).astype(float)
        self.tau_lut = np.maximum(kinetics.alpha_tau_s(T_GRID_C), 1e-3)
        self.D_lut = np.where(T_GRID_C > 600.0, kinetics.D_oxygen_m2_s(T_GRID_C), 0.0)
        # cells starting below a threshold: crossing at t=0
        for k, thr in enumerate(self.th):
            below = self.is_metal & (self.T <= thr)
            self.t_cross[k, below] = 0.0
        self.f_alpha[self.is_metal] = self.feq_lut_at(self.T[self.is_metal]) * 0.0
        self.dt_last = 0.0
        self.warnings: list = []
        if alloy.T_liquidus_C - alloy.T_solidus_C < 4.0:
            self.warnings.append(f"freezing range {alloy.T_liquidus_C-alloy.T_solidus_C:.1f} K is under-resolved by the 1 K enthalpy table (latent heat smeared); results unreliable")

    def _Hv_from_T(self, T):
        Hv = np.empty_like(T)
        for m in range(1, 5):
            sel = self.mat == m
            if sel.any(): Hv[sel] = np.interp(T[sel], T_GRID_C, self.Htab[m])
        return Hv
    def feq_lut_at(self, T): return np.interp(T, T_GRID_C, self.feq_lut)

    # ---- bookkeeping ----
    def internal_energy_J(self): return float(self.Hv.sum()) * self.cs.grid.cell_volume_m3
    def energy_balance(self):
        """Return (relative_error, dE, E_loss). Relative to the energy removed (or initial sensible energy if tiny)."""
        dE = self.internal_energy_J() - self.E0_J
        resid = dE + self.E_loss_J
        scale = max(abs(self.E_loss_J), 1e-30 + abs(dE))
        return float(abs(resid) / scale), dE, self.E_loss_J

    def to_field(self, a1d, fill=np.nan, dtype=np.float64):
        out = np.full(self.cs.grid.shape, fill, dtype)
        out[tuple(self.act.T)] = a1d
        return out
    def temperature_field(self, fill=np.nan): return self.to_field(self.T, fill)
    def solid_fraction_field(self):
        fs = np.zeros(self.cs.grid.shape); a = self.alloy.solid_fraction(self.T)
        fs[tuple(self.act.T)] = np.where(self.is_metal, a, np.nan); fs[self.cs.mat != MAT_METAL] = np.nan
        return fs

    def check_numerics(self):
        if not np.all(np.isfinite(self.T)): raise NumericalInstability(f"NaN/Inf temperature at t={self.t:.3f}s")
        Tm = self.T[self.is_metal]
        if Tm.size and (Tm.max() > 2300 or Tm.min() < -100): raise NumericalInstability(f"temperature out of bounds at t={self.t:.3f}s")
        fs = self.alloy.solid_fraction(Tm)
        # liquid_fraction + solid_fraction = 1 by construction; verify the construction survived
        if np.any(np.abs((1 - fs) + fs - 1) > 1e-9): self.warnings.append("phase-fraction inconsistency")

    def advance_to(self, t_end: float):
        dx = self.cs.grid.dx_m
        t, steps, El, flag = K.advance(self.Hv, self.T, self.f_alpha, self.mat, self.nbr, self.reg, dx, self.t, float(t_end),
                                       self.cfg.dt_max_s, self.cfg.safety, self.cfg.max_steps_per_call,
                                       self.ktab, self.Htab, self.epstab, T0_GRID, DT_GRID, self.h_hot, self.h_cold,
                                       self.alloy.T_solidus_C, self.alloy.T_liquidus_C,
                                       self.eps_reg, self.Tsur_reg, self.h_reg, self.Tamb_reg, self.Tfix_reg,
                                       self.th, self.t_cross, self.cr_cross, self.g_cross, self.Tpeak, self.t_above_beta,
                                       self.Dint, self.alloy.T_beta_C, self.feq_lut, self.tau_lut, self.D_lut, True)
        self.t = t; self.steps += steps; self.E_loss_J += El
        if flag: raise NumericalInstability(f"kernel flagged NaN/out-of-range temperature at t={t:.3f}s (step {self.steps})")
        self.check_numerics()
        return self.t

    # ---- checkpointing ----
    _STATE = ("Hv", "T", "f_alpha", "t_cross", "cr_cross", "g_cross", "Tpeak", "t_above_beta", "Dint")
    def checkpoint(self):
        d = {k: getattr(self, k).copy() for k in self._STATE}
        d.update(t=self.t, steps=self.steps, E_loss_J=self.E_loss_J); return d
    def restore(self, d):
        for k in self._STATE: getattr(self, k)[...] = d[k]
        self.t, self.steps, self.E_loss_J = d["t"], d["steps"], d["E_loss_J"]

    def max_metal_T(self): return float(self.T[self.is_metal].max())
    def stable_dt(self):
        return K.stable_dt(self.T, self.mat, self.nbr, self.reg, self.cs.grid.dx_m, self.ktab, self.Htab, self.epstab, T0_GRID, DT_GRID,
                           self.h_hot, self.h_cold, self.alloy.T_solidus_C, self.alloy.T_liquidus_C,
                           self.eps_reg, self.Tsur_reg, self.h_reg, self.Tamb_reg, self.Tfix_reg)
