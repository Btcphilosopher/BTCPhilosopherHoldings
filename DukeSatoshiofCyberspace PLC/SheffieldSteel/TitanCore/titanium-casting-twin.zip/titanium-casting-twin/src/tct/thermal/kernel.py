"""Numba kernel: explicit conservative enthalpy-method heat conduction on the compressed active-cell graph.

Equation:     d(Hv)/dt = div( k grad T ) + Q ,    T = T(Hv) from per-material monotone lookup tables.
Discretisation: finite volume, uniform cubic cells (edge dx). Face flux between cells i,j:
        q_ij = Kc_ij (T_j - T_i),   Kc = 1 / ( dx/(2 k_i) + R_int + dx/(2 k_j) )      [W/m^2/K]
(harmonic mean; R_int = 1/h at metal/mold interfaces, with h blended from h_hot to h_cold by metal liquid fraction).
Boundary faces (neighbour = void): radiation eps*sigma*(Ts^4-Tsur^4) + convection h*(Ts-Tamb), Ts = cell temperature.
Time integration: forward Euler on Hv (exactly conservative), adaptive dt from the local diffusive+boundary limit.
Events (threshold crossings) are interpolated linearly inside the step: crossing time, cooling rate, |grad T|.
Order of accuracy: first order in time, second order in space for smooth fields.
"""
import numpy as np
from numba import njit

SIGMA = 5.670374419e-8

@njit(cache=True)
def _lut(tab, T, T0, dT):
    x = (T - T0) / dT
    if x <= 0.0: return tab[0]
    n = tab.shape[0] - 1
    if x >= n: return tab[n]
    i = int(x); f = x - i
    return tab[i] * (1.0 - f) + tab[i + 1] * f

@njit(cache=True)
def _T_of_H(Hrow, Hv, T0, dT):
    # binary search for monotone Hrow
    n = Hrow.shape[0]
    if Hv <= Hrow[0]: return T0
    if Hv >= Hrow[n - 1]: return T0 + (n - 1) * dT
    lo = 0; hi = n - 1
    while hi - lo > 1:
        mid = (lo + hi) // 2
        if Hrow[mid] <= Hv: lo = mid
        else: hi = mid
    f = (Hv - Hrow[lo]) / (Hrow[hi] - Hrow[lo])
    return T0 + (lo + f) * dT

@njit(cache=True)
def _face_Kc(Ti, Tj, mi, mj, dx, ktab, T0, dT, h_hot, h_cold, Tsol, Tliq):
    ki = _lut(ktab[mi], Ti, T0, dT); kj = _lut(ktab[mj], Tj, T0, dT)
    R = 0.0
    if mi != mj:
        if mi == 1 or mj == 1:
            Tm = Ti if mi == 1 else Tj
            other = mj if mi == 1 else mi
            fl = (Tm - Tsol) / (Tliq - Tsol)
            if fl < 0.0: fl = 0.0
            if fl > 1.0: fl = 1.0
            h = h_cold[other] + (h_hot[other] - h_cold[other]) * fl
            R = 1.0 / h
    return 1.0 / (dx / (2.0 * ki) + R + dx / (2.0 * kj))

@njit(cache=True)
def _bnd_flux(T, m, reg, eps_reg, Tsur_reg, h_reg, Tamb_reg, Tfix_reg, epstab, T0, dT):
    if Tfix_reg[reg] > -1e8:
        return 1e6 * (T - Tfix_reg[reg]), 1e6          # very stiff fixed-temperature surrogate (W/m^2, coefficient)
    e = eps_reg[reg]
    if e < 0.0: e = _lut(epstab[m], T, T0, dT)
    Tk = T + 273.15; Ts = Tsur_reg[reg] + 273.15
    qr = e * SIGMA * (Tk ** 4 - Ts ** 4)
    qc = h_reg[reg] * (T - Tamb_reg[reg])
    hlin = 4.0 * e * SIGMA * Tk ** 3 + h_reg[reg]
    return qr + qc, hlin

@njit(cache=True)
def stable_dt(T, mat, nbr, reg, dx, ktab, Htab, epstab, T0, dT, h_hot, h_cold, Tsol, Tliq,
              eps_reg, Tsur_reg, h_reg, Tamb_reg, Tfix_reg):
    n = T.shape[0]; dtmin = 1e30
    for c in range(n):
        m = mat[c]; Ti = T[c]
        x = (Ti - T0) / dT
        ii = int(min(max(x, 0.0), Htab.shape[1] - 2))
        cap = (Htab[m, ii + 1] - Htab[m, ii]) / dT
        s = 0.0
        for f in range(6):
            j = nbr[c, f]
            if j >= 0:
                s += _face_Kc(Ti, T[j], m, mat[j], dx, ktab, T0, dT, h_hot, h_cold, Tsol, Tliq) / dx
            else:
                q, hl = _bnd_flux(Ti, m, reg[c], eps_reg, Tsur_reg, h_reg, Tamb_reg, Tfix_reg, epstab, T0, dT)
                s += hl / dx
        if s > 0.0:
            d = cap / s
            if d < dtmin: dtmin = d
    return dtmin

@njit(cache=True)
def advance(Hv, T, f_alpha, mat, nbr, reg, dx, t, t_end, dt_cap, safety, max_steps,
            ktab, Htab, epstab, T0, dT, h_hot, h_cold, Tsol, Tliq,
            eps_reg, Tsur_reg, h_reg, Tamb_reg, Tfix_reg,
            th, t_cross, cr_cross, g_cross, Tpeak, t_above_beta, Dint, Tbeta,
            feq_lut, tau_lut, D_lut, track_phase):
    n = T.shape[0]
    dH = np.zeros(n)
    Tnew = np.zeros(n)
    nth = th.shape[0]
    steps = 0; E_loss = 0.0; flag = 0
    dt = 0.0
    while t < t_end - 1e-12 and steps < max_steps:
        if steps % 8 == 0:
            dtc = stable_dt(T, mat, nbr, reg, dx, ktab, Htab, epstab, T0, dT, h_hot, h_cold, Tsol, Tliq,
                            eps_reg, Tsur_reg, h_reg, Tamb_reg, Tfix_reg)
            dt = safety * dtc
            if dt > dt_cap: dt = dt_cap
        dtu = dt
        if t + dtu > t_end: dtu = t_end - t
        # --- fluxes ---
        for c in range(n):
            m = mat[c]; Ti = T[c]; acc = 0.0
            for f in range(6):
                j = nbr[c, f]
                if j >= 0:
                    Kc = _face_Kc(Ti, T[j], m, mat[j], dx, ktab, T0, dT, h_hot, h_cold, Tsol, Tliq)
                    acc += Kc * (T[j] - Ti) / dx
                else:
                    q, hl = _bnd_flux(Ti, m, reg[c], eps_reg, Tsur_reg, h_reg, Tamb_reg, Tfix_reg, epstab, T0, dT)
                    acc -= q / dx
                    E_loss += q * dx * dx * dtu
            dH[c] = acc
        # --- update + events ---
        for c in range(n):
            m = mat[c]
            Hv[c] += dtu * dH[c]
            Tn = _T_of_H(Htab[m], Hv[c], T0, dT)
            Tnew[c] = Tn
        for c in range(n):
            if mat[c] != 1: 
                continue
            To = T[c]; Tn = Tnew[c]
            if Tn > Tpeak[c]: Tpeak[c] = Tn
            if Tn > Tbeta: t_above_beta[c] += dtu
            if track_phase:
                dD = _lut(D_lut, 0.5 * (To + Tn), T0, dT)
                Dint[c] += dD * dtu
                fe = _lut(feq_lut, Tn, T0, dT); ta = _lut(tau_lut, Tn, T0, dT)
                f_alpha[c] += (fe - f_alpha[c]) * (1.0 - np.exp(-dtu / ta))
            for k in range(nth):
                started_below = (To <= th[k]) and (t_cross[k, c] == 0.0) and np.isnan(cr_cross[k, c]) and (To > Tn)
                if (To > th[k] and Tn <= th[k] and np.isnan(t_cross[k, c])) or started_below:
                    if started_below:
                        fr = 0.0                      # crossing happened before t=0 (during fill): record the initial cooling rate / gradient
                    else:
                        fr = (To - th[k]) / (To - Tn)
                        t_cross[k, c] = t + fr * dtu
                    cr_cross[k, c] = (To - Tn) / dtu
                    # |grad T| from central differences on metal neighbours (new field)
                    g2 = 0.0
                    for ax in range(3):
                        jm = nbr[c, 2 * ax]; jp = nbr[c, 2 * ax + 1]
                        gm = jm >= 0 and mat[jm] == 1; gp = jp >= 0 and mat[jp] == 1
                        if gm and gp: g = (Tnew[jp] - Tnew[jm]) / (2 * dx)
                        elif gp: g = (Tnew[jp] - Tn) / dx
                        elif gm: g = (Tn - Tnew[jm]) / dx
                        else: g = 0.0
                        g2 += g * g
                    g_cross[k, c] = np.sqrt(g2)
        for c in range(n):
            T[c] = Tnew[c]
            if np.isnan(T[c]) or T[c] < -100.0 or T[c] > 2300.0: flag = 1
        t += dtu; steps += 1
        if flag != 0: break
    return t, steps, E_loss, flag
