"""Mold / shell / tooling materials. The mold is part of the digital twin.  STATUS: all presets are ESTIMATED.

Investment ceramic shell (zircon/alumina), rammed graphite, metal mold, water-cooled copper tooling and custom tooling.
Properties: conductivity k(T), specific heat cp(T), density, emissivity, plus metal/mold interface conductance
(contact resistance expressed as heat-transfer coefficient, hot = metal liquid-contact, cold = after gap formation).
"""
from __future__ import annotations
from dataclasses import dataclass, field
import numpy as np
from ..materials.properties import TabulatedProperty, Provenance, table, scalar
from ..materials.alloy import T_GRID_C

EST = "estimated"

@dataclass(frozen=True)
class MoldMaterial:
    name: str
    density_kg_m3: float
    specific_heat: TabulatedProperty
    thermal_conductivity: TabulatedProperty
    emissivity: TabulatedProperty
    h_contact_hot_W_m2K: float      # metal liquid -> mold interface conductance
    h_contact_cold_W_m2K: float     # after solidification / gap formation
    provenance: Provenance = Provenance(EST, "tct presets", "engineering estimates; calibrate to thermocouple data")
    def enthalpy_vol_table(self):
        cp = self.specific_heat(T_GRID_C)
        sens = np.concatenate([[0.0], np.cumsum(0.5 * (cp[1:] + cp[:-1]) * np.diff(T_GRID_C))])
        return self.density_kg_m3 * sens
    def effusivity(self, T_C):
        """Thermal effusivity sqrt(k rho cp) [W s^0.5 /(m^2 K)] at T_C."""
        return float(np.sqrt(self.thermal_conductivity(T_C) * self.density_kg_m3 * self.specific_heat(T_C)))
    def k_table(self): return self.thermal_conductivity(T_GRID_C)
    def eps_table(self): return self.emissivity(T_GRID_C)
    def to_dict(self):
        return {"name": self.name, "density_kg_m3": self.density_kg_m3, "h_hot": self.h_contact_hot_W_m2K,
                "h_cold": self.h_contact_cold_W_m2K, "k": self.thermal_conductivity.to_dict(), "cp": self.specific_heat.to_dict()}

def ceramic_shell():
    return MoldMaterial("ceramic_shell", 2900.0,
        table("cp", "J/(kg K)", [(20, 800), (600, 1050), (1200, 1200), (2300, 1300)], EST, "alumina/zircon shell, approximate"),
        table("k", "W/(m K)", [(20, 0.9), (600, 1.2), (1200, 1.8), (2300, 2.6)], EST, "porous investment shell; strongly process dependent"),
        table("eps", "-", [(20, 0.8), (1200, 0.85), (2300, 0.85)], EST, "ceramic emissivity"),
        h_contact_hot_W_m2K=1500.0, h_contact_cold_W_m2K=350.0)

def graphite_mold():
    return MoldMaterial("graphite", 1750.0,
        table("cp", "J/(kg K)", [(20, 710), (500, 1300), (1000, 1600), (2300, 1900)], EST, "graphite, approximate"),
        table("k", "W/(m K)", [(20, 90.0), (600, 55.0), (1200, 38.0), (2300, 28.0)], EST, "isotropic graphite, approximate"),
        table("eps", "-", [(20, 0.8), (2300, 0.85)], EST, "graphite emissivity"),
        h_contact_hot_W_m2K=3000.0, h_contact_cold_W_m2K=800.0)

def metal_mold():
    return MoldMaterial("metal_mold_steel", 7800.0,
        table("cp", "J/(kg K)", [(20, 470), (600, 620), (1200, 700), (2300, 750)], EST, "tool steel, approximate"),
        table("k", "W/(m K)", [(20, 30.0), (600, 28.0), (1200, 30.0), (2300, 32.0)], EST, "tool steel, approximate"),
        table("eps", "-", [(20, 0.35), (2300, 0.6)], EST, "oxidised steel"),
        h_contact_hot_W_m2K=2500.0, h_contact_cold_W_m2K=500.0)

def water_cooled_copper():
    return MoldMaterial("water_cooled_copper", 8900.0,
        table("cp", "J/(kg K)", [(20, 385), (1200, 450), (2300, 480)], EST, "copper, approximate"),
        table("k", "W/(m K)", [(20, 400.0), (1200, 320.0), (2300, 300.0)], EST, "copper, approximate"),
        table("eps", "-", [(20, 0.1), (2300, 0.3)], EST, "copper emissivity"),
        h_contact_hot_W_m2K=8000.0, h_contact_cold_W_m2K=3000.0)

def custom_tooling(name, density, k_W_mK, cp_J_kgK, emissivity, h_hot, h_cold):
    k = table("k", "W/(m K)", [(20, k_W_mK), (2300, k_W_mK)], "user-supplied", "user config")
    cp = table("cp", "J/(kg K)", [(20, cp_J_kgK), (2300, cp_J_kgK)], "user-supplied", "user config")
    e = table("eps", "-", [(20, emissivity), (2300, emissivity)], "user-supplied", "user config")
    return MoldMaterial(name, density, cp, k, e, h_hot, h_cold, Provenance("user-supplied", "user config"))

PRESETS = {"ceramic_shell": ceramic_shell, "graphite": graphite_mold, "metal_mold": metal_mold,
           "water_cooled_copper": water_cooled_copper}
