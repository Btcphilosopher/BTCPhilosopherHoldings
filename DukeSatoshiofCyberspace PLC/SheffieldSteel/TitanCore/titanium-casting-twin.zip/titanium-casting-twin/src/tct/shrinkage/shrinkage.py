"""Shrinkage bookkeeping: liquid/solidification contraction, solid thermal contraction, predicted dimensional change.
STATUS: PHYSICS-BASED bookkeeping from the alloy tables (no free parameters).

  beta_s = (rho_s(T_sol) - rho_l(T_liq)) / rho_s(T_sol)            volumetric solidification shrinkage  [-]
  eps_th(T) = integral_{T_rigid}^{T} alpha(T') dT'                  linear thermal strain               [-]
  linear contraction (pattern shrink allowance) = -eps_th(T_final)
  liquid contraction of superheat = 1 - rho_l(T_pour)/rho_l(T_liq)  (volume change that must be supplied before solidification)
"""
from __future__ import annotations
import numpy as np

def shrinkage_summary(alloy, T_pour_C, T_final_C=25.0):
    beta_s = alloy.volumetric_solidification_shrinkage()
    rho_l_pour = float(alloy.tables["density"](max(T_pour_C, alloy.T_liquidus_C + 0.0)))
    rho_l_liq = float(alloy.tables["density"](alloy.T_liquidus_C))
    liq = 1.0 - rho_l_pour / rho_l_liq
    eps = float(alloy.thermal_strain(T_final_C, alloy.T_solidus_C))
    return {"solidification_shrinkage_vol": beta_s, "liquid_contraction_vol": float(liq), "linear_thermal_contraction": -eps,
            "volumetric_thermal_contraction": 1.0 - (1.0 + eps) ** 3, "model": "PHYSICS-BASED bookkeeping from alloy tables"}

def feeding_demand_field(cs, alloy, solid_fraction_field=None):
    """Local shrinkage demand (volume fraction of cell volume still to contract on solidification) = beta_s * (1 - fs)."""
    beta = alloy.volumetric_solidification_shrinkage()
    fs = 0.0 if solid_fraction_field is None else solid_fraction_field
    return np.where(cs.metal, beta * (1.0 - fs), np.nan)
