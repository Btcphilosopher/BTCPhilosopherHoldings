"""Parameter calibration. Least squares (with parameter covariance from the Jacobian) and Bayesian (random-walk Metropolis).
Calibrated values are returned as ScalarProperty objects with provenance kind 'calibrated' -- they are NEVER mixed with independently
measured material properties (the provenance tag stays attached and appears in reports)."""
from __future__ import annotations
from dataclasses import dataclass
import numpy as np
from scipy.optimize import least_squares
from ..materials.properties import ScalarProperty, Provenance

@dataclass
class CalibrationResult:
    names: list
    values: np.ndarray
    std: np.ndarray
    cov: np.ndarray
    rmse: float
    n_data: int
    method: str
    samples: np.ndarray | None = None
    acceptance: float | None = None
    def as_properties(self, units, dataset):
        return [ScalarProperty(n, float(v), u, Provenance("calibrated", f"{self.method} to {dataset}", f"+/- {s:.3g} (1 sigma)")) for n, v, u, s in zip(self.names, self.values, units, self.std)]

def least_squares_calibrate(model, names, x0, bounds, data_x, data_y, sigma=1.0):
    """model(x_params, data_x) -> predicted y. Residuals are scaled by sigma."""
    lo = np.array([b[0] for b in bounds], float); hi = np.array([b[1] for b in bounds], float)
    scale = np.maximum(np.abs(np.asarray(x0, float)), 1e-12)
    res = lambda u: (model(u * scale, data_x) - data_y) / sigma
    sol = least_squares(res, np.asarray(x0, float) / scale, bounds=(lo / scale, hi / scale), x_scale=1.0, xtol=1e-12, ftol=1e-12)
    J = sol.jac / scale[None, :]; dof = max(len(data_y) - len(x0), 1)
    s2 = float((sol.fun ** 2).sum() / dof)
    try: cov = np.linalg.inv(J.T @ J) * s2
    except np.linalg.LinAlgError: cov = np.full((len(x0), len(x0)), np.nan)
    vals = sol.x * scale; cov = cov * np.outer(scale, scale) * 0 + np.linalg.inv(sol.jac.T @ sol.jac) * s2 * np.outer(scale, scale) if np.all(np.isfinite(cov)) else cov
    rmse = float(np.sqrt(np.mean((model(vals, data_x) - data_y) ** 2)))
    return CalibrationResult(list(names), vals, np.sqrt(np.diag(cov)), cov, rmse, len(data_y), "least squares")

def bayesian_calibrate(model, names, prior_mean, prior_std, data_x, data_y, sigma, n_steps=4000, burn=1000, seed=0, step_scale=0.3):
    """Gaussian priors, Gaussian likelihood, random-walk Metropolis."""
    rng = np.random.default_rng(seed); pm = np.asarray(prior_mean, float); ps = np.asarray(prior_std, float)
    def logp(th):
        r = (model(th, data_x) - data_y) / sigma
        return -0.5 * np.sum(r ** 2) - 0.5 * np.sum(((th - pm) / ps) ** 2)
    th = pm.copy(); lp = logp(th); chain = []; acc = 0
    for i in range(n_steps):
        prop = th + rng.normal(0, step_scale * ps)
        lq = logp(prop)
        if np.log(rng.random()) < lq - lp: th, lp = prop, lq; acc += 1
        chain.append(th.copy())
    ch = np.array(chain[burn:])
    return CalibrationResult(list(names), ch.mean(0), ch.std(0), np.cov(ch.T), float(np.sqrt(np.mean((model(ch.mean(0), data_x) - data_y) ** 2))),
                             len(data_y), "Bayesian (random-walk Metropolis)", ch, acc / n_steps)

def lumped_cooling_model(params, t, T0_C=1200.0, Ts_C=25.0, mass_per_area_kg_m2=4000.0 * 0.0033, cp=700.0):
    """Lumped radiative cooling T(t; emissivity) -- a cheap forward model used for calibration tests and tutorials."""
    from scipy.integrate import solve_ivp
    from ..units import SIGMA_SB, c2k
    eps = params[0]
    f = lambda tt, T: -eps * SIGMA_SB * (T ** 4 - c2k(Ts_C) ** 4) / (mass_per_area_kg_m2 * cp)
    sol = solve_ivp(f, [0, float(np.max(t))], [c2k(T0_C)], t_eval=np.asarray(t, float), rtol=1e-8, atol=1e-8)
    return sol.y[0] - 273.15

def calibrate_scenario_parameters(scn, observed: dict, params: dict, dx_mm=6.0, x0=None):
    """Calibrate scenario parameters (dotted paths -> (low, high)) so that model responses match user-measured scalars.
    observed: {response_name: (value, sigma)}. Uses the full coarse pipeline as the forward model."""
    from ..uncertainty import forward as F
    names = list(params); lo = [params[n][0] for n in names]; hi = [params[n][1] for n in names]
    x0 = x0 or [0.5 * (a + b) for a, b in zip(lo, hi)]
    keys = list(observed)
    def model(x, _): 
        o = F.evaluate(scn, {n: float(v) for n, v in zip(names, x)}, tuple(keys), dx_mm); return np.array([o[k] for k in keys])
    y = np.array([observed[k][0] for k in keys]); sg = np.array([observed[k][1] for k in keys])
    return least_squares_calibrate(model, names, x0, list(zip(lo, hi)), None, y, sg)
