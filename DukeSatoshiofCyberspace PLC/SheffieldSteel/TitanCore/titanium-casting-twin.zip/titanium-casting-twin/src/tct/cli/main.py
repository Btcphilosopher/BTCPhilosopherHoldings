"""tct command line interface."""
from __future__ import annotations
import json, pathlib, sys, time
import click
import numpy as np
from .. import __version__

def _status_of(criteria, *names):
    order = {"PASS": 0, "REPORTED": 0, "NOT-EVALUATED": 0, "REVIEW": 1, "HIGH-RISK": 2}; worst = "PASS"
    for c in criteria:
        if c["name"] in names and order[c["status"]] > order[worst]: worst = c["status"]
    return worst

def summary_text(run) -> str:
    R = run.results; crit = run.criteria; g = R["geometry"]
    por = R["porosity"]["porosity_risk_mean_part"]; porl = "LOW" if por < 0.3 else ("MODERATE" if por < 0.7 else "HIGH")
    stress = _status_of(crit, "residual_stress_vm_over_yield")
    stl = {"PASS": "within screening limits", "REVIEW": "REVIEW", "HIGH-RISK": "HIGH-RISK REGION DETECTED"}[stress]
    L = ["Simulation complete", "", f"Run: {run.manifest['simulation_id']}", "",
         f"Mesh: {g['n_cells_total']:,} cells ({g['n_metal_cells']:,} metal)",
         f"Duration: {run.times[-1]:.1f} s simulated (thermal), fill {R['fill']['fill_time_s']:.2f} s",
         f"Fill: {_status_of(crit, 'fill_integrity_misrun_fraction', 'fill_integrity_cold_shut_max', 'air_entrainment_index_max')}",
         f"Solidification: {'COMPLETE' if R['solidification']['solidification_complete'] else 'INCOMPLETE'}",
         f"Feeding: {_status_of(crit, 'feeding_isolated_volume_fraction')}",
         f"Porosity indicator: {porl} (mean {por:.2f}; max {R['porosity']['porosity_risk_max_part']:.2f})",
         f"Residual stress: {stl} (max von Mises {R['stress'].get('vm_max_part_MPa', float('nan')):.1f} MPa)",
         f"Distortion: {R['distortion'].get('max_warpage_m', 0)*1e3:.3f} mm maximum (after removing {R['distortion'].get('linear_contraction', 0)*100:.2f}% uniform contraction)",
         f"Conservation checks: {'OK' if R['conservation']['all_ok'] else 'FLAGGED'} (energy balance {R['conservation']['energy_balance_rel_error']:.1e})",
         "", "NOTE: reduced-order model with ESTIMATED constants; indicators, not certification. Inspection results are SIMULATED."]
    return "\n".join(L)

def _criteria_table(criteria):
    L = [f"{'criterion':40s} {'value':>14s} {'unit':14s} {'status':>12s}  confidence"]
    for c in criteria:
        v = "n/a" if c["value"] is None else f"{c['value']:.4g}"
        L.append(f"{c['name']:40s} {v:>14s} {c['unit']:14s} {c['status']:>12s}  {c['confidence']}")
    return "\n".join(L)

@click.group()
@click.version_option(__version__, prog_name="tct")
def main():
    """titanium-casting-twin: physics-first digital twin for Ti alloy castings (reduced-order, research-grade)."""

@main.command()
@click.argument("scenario", type=click.Path(exists=True))
@click.option("--out", default=None, help="output directory (default runs/<sim id>)")
@click.option("--quiet", is_flag=True)
@click.option("--report/--no-report", default=False, help="also write the HTML/PDF/JSON/CSV report")
def simulate(scenario, out, quiet, report):
    """Run a complete casting simulation."""
    from ..simulation.config import load_scenario
    from ..simulation.pipeline import run_simulation
    scn = load_scenario(scenario); t0 = time.time()
    run = run_simulation(scn, output_path=out, progress=None if quiet else (lambda m: click.echo(f"  [{time.time()-t0:6.1f}s] {m}")))
    click.echo(""); click.echo(summary_text(_wrap(run)))
    click.echo(f"\nRun store: {run.path}\nWall time: {run.timings['total']:.1f} s")
    if report:
        from ..reporting.report import generate
        w = generate(run.path); click.echo("Report: " + ", ".join(f"{k}={v}" for k, v in w.items()))

def _wrap(run):
    """RunResult -> object exposing the same attributes as RunData for summary_text."""
    class W: pass
    w = W(); w.results = run.results; w.criteria = [c.to_dict() for c in run.criteria]; w.manifest = run.manifest.to_dict()
    from ..digital_twin.run_data import RunData
    with RunData(run.path) as rd: w.times = rd.times
    return w

@main.command()
@click.argument("scenario", type=click.Path(exists=True))
@click.option("--full", is_flag=True, help="include the slower Chvorinov trend case")
@click.option("--save", default=None, help="write the verification rows to this JSON file")
def validate(scenario, full, save):
    """Validate the scenario (configuration + geometry) and run the built-in verification suite."""
    from ..simulation.config import load_scenario
    from ..simulation.pipeline import _casting_system, _geometry_report
    from ..materials.database import get_alloy
    from ..validation_cases import analytic as V
    try: scn = load_scenario(scenario)
    except Exception as e: click.echo(f"CONFIGURATION INVALID: {e}"); sys.exit(2)
    click.echo(f"configuration OK: {scn.name} ({scn.alloy})")
    al = get_alloy(scn.alloy); click.echo(f"alloy {al.name}: {al.fraction_estimated()*100:.0f}% of property entries are ESTIMATED (see provenance)")
    cs = _casting_system(scn); gd, mh, rep = _geometry_report(scn, cs)
    click.echo(f"geometry: grid {cs.grid.shape}, {int(cs.metal.sum())} metal cells; mesh valid: {rep.ok if rep else 'n/a'}; messages: {rep.messages if rep else gd}")
    rows = V.run_suite(quick=not full)
    click.echo(V.to_markdown(rows))
    bad = [r for r in rows if not r.passed and r.kind != "known-limitation"]
    lim = [r for r in rows if not r.passed and r.kind == "known-limitation"]
    if lim: click.echo(f"\n{len(lim)} documented known-limitation row(s) disagree with the reference (shown above, not hidden).")
    if save: pathlib.Path(save).write_text(json.dumps([r.to_dict() for r in rows], indent=1))
    click.echo(f"\nverification: {len(rows)-len(bad)-len(lim)} passed, {len(lim)} known limitations, {len(bad)} FAILED")
    sys.exit(1 if (bad or (rep is not None and not rep.ok)) else 0)

@main.command()
@click.argument("model", type=click.Path(exists=True))
@click.option("--dx-mm", default=3.0)
@click.option("--scale", default=1e-3, help="metres per model unit (STL in mm -> 1e-3)")
@click.option("--min-wall-mm", default=4.0)
def mesh(model, dx_mm, scale, min_wall_mm):
    """Load a geometry file (STL/OBJ/PLY/VTK; STEP needs cadquery), validate it and report the voxel (finite-volume) representation."""
    from ..geometry.geometry import Geometry
    from ..geometry.grid import Grid
    from ..errors import MissingOptionalDependency
    p = pathlib.Path(model)
    try:
        geo = Geometry.from_step(p) if p.suffix.lower() in (".step", ".stp") else Geometry.from_mesh_file(p, scale)
    except MissingOptionalDependency as e: click.echo(f"ERROR: {e}"); sys.exit(2)
    b = geo.bbox_m; dx = dx_mm * 1e-3; pad = 2 * dx
    shape = tuple(int(np.ceil((b[1][i] - b[0][i] + 2 * pad) / dx)) for i in range(3)); g = Grid(shape, dx, tuple(b[0] - pad))
    rep, m = geo.validate(g, min_wall_m=min_wall_mm * 1e-3)
    mask = geo.mask_on(g)
    click.echo(json.dumps(rep.to_dict(), indent=1))
    click.echo(f"voxel domain: {shape} ({int(np.prod(shape)):,} cells), solid cells {int(mask.sum()):,}, volume {mask.sum()*dx**3*1e6:.1f} cm^3, mesh hash {geo.hash()}")
    click.echo("RESULT: " + ("mesh valid" if rep.ok else "mesh has problems (see messages)")); sys.exit(0 if rep.ok else 1)

@main.command()
@click.argument("run", type=click.Path(exists=True))
@click.option("--at", nargs=3, type=float, default=None, help="probe point x y z in mm: 'what happened here?'")
@click.option("--png", default=None, help="write an off-screen 3D render to this PNG")
@click.option("--view", default="temperature")
@click.option("--time", "tproc", default=None, type=float)
def inspect(run, at, png, view, tproc):
    """Summarise a stored run; optionally probe a location or render a 3D view."""
    from ..digital_twin.run_data import RunData, format_query
    r = RunData(run); click.echo(summary_text(r)); click.echo(); click.echo(_criteria_table(r.criteria))
    click.echo("\nProcess timeline: " + " -> ".join(f"{s['name']}({s['t1']-s['t0']:.0f}s)" for s in r.timeline))
    if r.warnings: click.echo("WARNINGS: " + "; ".join(r.warnings))
    if at: click.echo("\n" + format_query(r.query(np.asarray(at) * 1e-3)))
    if png:
        from ..visualization import viewer3d
        viewer3d.render_view(r, view, r.process_duration * 0.5 if tproc is None else tproc, png); click.echo(f"wrote {png}")
    r.close()

@main.command()
@click.argument("run", type=click.Path(exists=True))
@click.option("--stride", default=10)
@click.option("--png-dir", default=None)
@click.option("--viewer", is_flag=True, help="open the interactive PyVista viewer")
def replay(run, stride, png_dir, viewer):
    """Replay the stored thermal history (snapshot by snapshot) or open the 3D viewer."""
    from ..digital_twin.run_data import RunData
    r = RunData(run)
    if viewer:
        from ..visualization import viewer3d; viewer3d.launch(r); return
    n = len(r.times); metal = r.mat[tuple(r.act.T)] == 1
    pathlib.Path(png_dir).mkdir(parents=True, exist_ok=True) if png_dir else None
    for i in range(0, n, stride):
        T = r.f["history/T"][i]; fs = r.alloy.solid_fraction(T[metal])
        click.echo(f"snapshot {i:4d}  t={r.times[i]:9.2f} s  Tmax(metal)={T[metal].max():7.1f} C  Tmin(metal)={T[metal].min():7.1f} C  mean solid fraction={fs.mean():.3f}")
        if png_dir:
            from ..visualization import static as S
            import matplotlib.pyplot as plt
            fig, ax = plt.subplots(figsize=(5, 4)); im = S.draw_slice(ax, r, r.temperature_at_index(i), f"t={r.times[i]:.1f} s", "inferno", 20, 1850); fig.colorbar(im, ax=ax)
            (pathlib.Path(png_dir) / f"frame_{i:04d}.png").write_bytes(S.fig_png(fig, 80))
    r.close()

@main.command("monte-carlo")
@click.argument("scenario", type=click.Path(exists=True))
@click.option("-n", default=1000, help="number of samples")
@click.option("--mode", type=click.Choice(["surrogate", "direct"]), default="surrogate")
@click.option("--n-train", default=40)
@click.option("--out", default=None)
def monte_carlo(scenario, n, mode, n_train, out):
    """Monte Carlo process variation (surrogate-based by default; --mode direct runs the full coarse pipeline N times)."""
    from ..simulation.config import load_scenario
    from ..uncertainty.monte_carlo import run_monte_carlo
    scn = load_scenario(scenario)
    res = run_monte_carlo(scn, n=n, mode=mode, n_train=n_train, progress=lambda i, N: click.echo(f"  sample {i}/{N}") if i % 10 == 0 else None)
    click.echo(f"Monte Carlo ({res['mode']}, N={res['n']}){'  ' + res.get('label','')}")
    for r, d in res["responses"].items():
        p = d["percentiles"]; click.echo(f"  {r:30s} mean {d['mean']:.4g}  std {d['std']:.3g}  p5 {p['p5']:.4g}  p50 {p['p50']:.4g}  p95 {p['p95']:.4g}")
    fp = res["failure_probability"]; click.echo("  failure probability: " + (f"{fp['probability']:.4g} +/- {fp['standard_error']:.2g} for {fp['criterion']}" if fp["computed"] else fp["reason"]))
    if fp.get("warning"): click.echo("  WARNING: " + fp["warning"])
    if res.get("unreliable_responses"): click.echo("  unreliable surrogate responses (LOO R2 < 0.8): " + ", ".join(res["unreliable_responses"]))
    if "surrogate" in res: click.echo("  surrogate quality (R2 train / leave-one-out): " + "; ".join(f"{k}: {v['R2_train']:.2f}/{v['R2_leave_one_out']:.2f} ({v['n_coefficients']} coef, {v['n_runs']} runs, {v['terms']})" for k, v in res["surrogate"]["quality"].items()))
    path = pathlib.Path(out or "uncertainty.json"); path.write_text(json.dumps(res, indent=1, default=str)); click.echo(f"wrote {path}")

@main.command()
@click.argument("scenario", type=click.Path(exists=True))
@click.option("--dx-mm", default=6.0)
def sensitivity(scenario, dx_mm):
    """Process sensitivity table (central differences of the full pipeline on a coarse grid)."""
    from ..simulation.config import load_scenario
    from ..uncertainty.sensitivity import one_at_a_time, format_table
    res = one_at_a_time(load_scenario(scenario), dx_mm=dx_mm, progress=lambda p: click.echo(f"  done {p}"))
    click.echo(format_table(res))

@main.command("optimise-riser")
@click.argument("scenario", type=click.Path(exists=True))
@click.option("--max-evals", default=24)
def optimise_riser_cmd(scenario, max_evals):
    """Iterative riser optimisation (coarse grid)."""
    from ..simulation.config import load_scenario
    from ..feeding.riser import optimise_riser
    r = optimise_riser(load_scenario(scenario), max_evals=max_evals, progress=lambda h: click.echo(f"  {h['x']} isolated={h['isolated_volume_fraction']:.4f} J={h['J']:.4f}"))
    click.echo("best: " + json.dumps(r["best"])); click.echo(r["note"])

@main.command()
@click.argument("run", type=click.Path(exists=True))
@click.option("--out", default=None)
@click.option("--formats", default="html,pdf,json,csv")
@click.option("--validation-json", default=None, help="verification rows saved by `tct validate --save`")
def report(run, out, formats, validation_json):
    """Generate the engineering report (HTML, PDF, JSON, CSV; HDF5 is the run store)."""
    from ..reporting.report import generate
    from ..validation_cases import analytic as V
    val = [V.ValidationRow(**x) for x in json.loads(pathlib.Path(validation_json).read_text())] if validation_json else None
    w = generate(run, out, validation=val, formats=tuple(formats.split(",")))
    for k, v in w.items(): click.echo(f"{k}: {v}")

@main.command()
@click.argument("run", type=click.Path(exists=True))
@click.option("--out", default=None)
def dashboard(run, out):
    """Write the HTML dashboard (scrubbable process timeline)."""
    from ..digital_twin.run_data import RunData
    from ..reporting.dashboard import write_dashboard
    r = RunData(run); p = write_dashboard(r, out or pathlib.Path(run).parent / "dashboard.html"); click.echo(p); r.close()

if __name__ == "__main__": main()
