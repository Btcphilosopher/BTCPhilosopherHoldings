"""Reduced-order thermo-mechanical model: incremental voxel finite elements with eigenstrain.  STATUS: REDUCED-ORDER.

Governing equations (quasi-static, small strain, no inertia):
    div(sigma) = 0,   sigma = D(E(T), nu) : ( eps_total - eps_thermal* - eps_transformation* - eps_plastic )
    eps_thermal*(T)       = isotropic  integral_{T_rigid}^{T} alpha(T') dT'   (accumulated only while the cell is below T_rigid)
    eps_transformation*   = isotropic  (Delta_V/3) * d f_alpha                 (optional, Delta_V ESTIMATED)
    plasticity: von Mises, perfectly plastic, yield(T) from the alloy table; radial return by fixed-point iteration.
Discretisation: trilinear hexahedra on the voxel grid (2x2x2 Gauss for stiffness; volume-averaged strain for the plastic
update), incremental in temperature snapshots, stiffness re-assembled every increment (E depends on T). A cell carries no
stress / stiffness (E floor) until its temperature falls below T_rigid (default: solidus).  Direct sparse LU solve.
Assumptions / limitations: the mold/shell restraint is NOT modelled (free contraction from the mold: `include_mold=False`),
rate-dependent creep is not modelled (stress relaxation above ~600 C is represented only via the yield limit), phase
transformation strain is small and ESTIMATED, nu is constant, no contact / hot-tear criterion.
Verification: uniform cooling of a free block gives zero stress (test); constrained bar gives -E*alpha*dT (test).
"""
from __future__ import annotations
from dataclasses import dataclass, field
import numpy as np
import scipy.sparse as sp
from scipy.sparse.linalg import splu
from ..errors import NumericalInstability

XI = np.array([[-1, -1, -1], [1, -1, -1], [1, 1, -1], [-1, 1, -1], [-1, -1, 1], [1, -1, 1], [1, 1, 1], [-1, 1, 1]], float)
OFF = ((0, 0, 0), (1, 0, 0), (1, 1, 0), (0, 1, 0), (0, 0, 1), (1, 0, 1), (1, 1, 1), (0, 1, 1))

def D_matrix(nu):
    c = 1.0 / ((1 + nu) * (1 - 2 * nu))
    D = np.zeros((6, 6))
    D[:3, :3] = c * nu; 
    for i in range(3): D[i, i] = c * (1 - nu)
    for i in range(3, 6): D[i, i] = c * (1 - 2 * nu) / 2.0
    return D

def hex8_ref(h, nu):
    g = 1.0 / np.sqrt(3.0); D1 = D_matrix(nu)
    Ke = np.zeros((24, 24)); Bsum = np.zeros((6, 24)); Gsum = np.zeros((9, 24))
    detJ = (h / 2.0) ** 3
    for gx in (-g, g):
        for gy in (-g, g):
            for gz in (-g, g):
                dN = np.zeros((8, 3))
                for a in range(8):
                    xa, ya, za = XI[a]
                    dN[a, 0] = 0.125 * xa * (1 + gy * ya) * (1 + gz * za)
                    dN[a, 1] = 0.125 * ya * (1 + gx * xa) * (1 + gz * za)
                    dN[a, 2] = 0.125 * za * (1 + gx * xa) * (1 + gy * ya)
                dN *= 2.0 / h
                B = np.zeros((6, 24)); Gm = np.zeros((9, 24))
                for a in range(8):
                    dx_, dy_, dz_ = dN[a]; c = 3 * a
                    B[0, c] = dx_; B[1, c + 1] = dy_; B[2, c + 2] = dz_
                    B[3, c] = dy_; B[3, c + 1] = dx_
                    B[4, c + 1] = dz_; B[4, c + 2] = dy_
                    B[5, c] = dz_; B[5, c + 2] = dx_
                    for comp in range(3):          # grad u: row 3*comp+dir  = d u_comp / d x_dir
                        Gm[3 * comp + 0, c + comp] = dx_; Gm[3 * comp + 1, c + comp] = dy_; Gm[3 * comp + 2, c + comp] = dz_
                Ke += B.T @ D1 @ B * detJ; Bsum += B * detJ; Gsum += Gm * detJ
    V = h ** 3
    return Ke, Bsum / V, Gsum / V, D1, V

def von_mises(s):
    sx, sy, sz, txy, tyz, tzx = s.T
    return np.sqrt(0.5 * ((sx - sy) ** 2 + (sy - sz) ** 2 + (sz - sx) ** 2) + 3 * (txy ** 2 + tyz ** 2 + tzx ** 2))

def principal(s):
    n = len(s); M = np.zeros((n, 3, 3))
    M[:, 0, 0], M[:, 1, 1], M[:, 2, 2] = s[:, 0], s[:, 1], s[:, 2]
    M[:, 0, 1] = M[:, 1, 0] = s[:, 3]; M[:, 1, 2] = M[:, 2, 1] = s[:, 4]; M[:, 0, 2] = M[:, 2, 0] = s[:, 5]
    return np.linalg.eigvalsh(M)[:, ::-1]      # descending: sigma1>=sigma2>=sigma3

@dataclass
class StressResult:
    cells: np.ndarray               # (ne,3)
    times_s: np.ndarray
    sigma_final: np.ndarray         # (ne,6) Pa  [sx, sy, sz, txy, tyz, tzx]
    vm_hist: np.ndarray             # (nsteps, ne) float32
    epl_eq_hist: np.ndarray         # (nsteps, ne) float32
    eps_total: np.ndarray           # (ne,6) cumulative total strain
    eps_plastic: np.ndarray         # (ne,6)
    eps_thermal_final: np.ndarray   # (ne,) isotropic linear thermal strain (free)
    node_xyz: np.ndarray            # (nn,3) m (nominal)
    node_u: np.ndarray              # (nn,3) m cumulative displacement
    elem_nodes: np.ndarray          # (ne,8)
    grad_u_elem: np.ndarray         # (ne,3,3)
    solve_info: dict = field(default_factory=dict)
    model: str = "REDUCED-ORDER incremental thermo-elastic-plastic voxel FE (no mold restraint, no creep)"

class ThermoMechanical:
    def __init__(self, cells_ijk, dx_m, origin_m, alloy, nu=0.34):
        self.cells = np.asarray(cells_ijk); self.dx = dx_m; self.origin = np.asarray(origin_m); self.alloy = alloy; self.nu = nu
        self.ne = len(self.cells)
        self.Ke1, self.Bavg, self.Gavg, self.D1, self.V = hex8_ref(dx_m, nu)
        # nodes
        corner = np.stack([self.cells + np.array(o) for o in OFF], axis=1)       # (ne,8,3)
        mx = self.cells.max(0) + 2
        lin = (corner[..., 0] * mx[1] + corner[..., 1]) * mx[2] + corner[..., 2]
        uniq, inv = np.unique(lin, return_inverse=True)
        self.elem_nodes = inv.reshape(self.ne, 8)
        self.nn = len(uniq)
        node_ijk = np.stack([uniq // (mx[1] * mx[2]), (uniq // mx[2]) % mx[1], uniq % mx[2]], axis=1)
        self.node_xyz = self.origin + node_ijk * dx_m
        self.dofs = (3 * self.elem_nodes[:, :, None] + np.arange(3)[None, None, :]).reshape(self.ne, 24)
        self.I = np.repeat(self.dofs, 24, axis=1).ravel(); self.J = np.tile(self.dofs, (1, 24)).ravel()
        self.ndof = 3 * self.nn
        self.BtD = self.Bavg.T @ self.D1                      # (24,6)
        self.invD1 = np.linalg.inv(self.D1)

    def _assemble(self, E):
        data = (E[:, None] * self.Ke1.ravel()[None, :]).ravel()
        K = sp.coo_matrix((data, (self.I, self.J)), shape=(self.ndof, self.ndof)).tocsc()
        reg = 1e-9 * K.diagonal().mean()
        return K + sp.identity(self.ndof, format="csc") * reg

    def run(self, T_steps, f_alpha_steps, times_s, T_rigid_C, transformation_vol_strain=0.0015, max_plastic_iter=12,
            E_floor_frac=1e-3, tol=2e-3, progress=None) -> StressResult:
        al = self.alloy; ne = self.ne; nst = len(T_steps)
        E_floor = E_floor_frac * float(al.tables["elastic_modulus"](20.0))
        sig = np.zeros((ne, 6)); epl = np.zeros((ne, 6)); etot = np.zeros((ne, 6)); u = np.zeros(self.ndof)
        grad = np.zeros((ne, 3, 3))
        vm_hist = np.zeros((nst, ne), np.float32); ep_hist = np.zeros((nst, ne), np.float32)
        eth_prev = al.thermal_strain(np.minimum(T_steps[0], T_rigid_C), T_rigid_C)
        f_prev = f_alpha_steps[0]
        info = {"plastic_iterations": [], "n_yielded_max": 0, "lu_seconds": 0.0}
        import time
        one = np.array([1, 1, 1, 0, 0, 0.0])
        for k in range(1, nst):
            T = T_steps[k]; rig = T < T_rigid_C
            E = np.where(rig, np.maximum(al.tables["elastic_modulus"](T), E_floor), E_floor)
            sy = np.maximum(al.tables["yield_strength"](T), 1e3)
            eth = al.thermal_strain(np.minimum(T, T_rigid_C), T_rigid_C)
            d_th = (eth - eth_prev) * rig
            d_pt = (transformation_vol_strain / 3.0) * (f_alpha_steps[k] - f_prev) * rig
            d_star = np.zeros((ne, 6)); d_star[:, :3] = (d_th + d_pt)[:, None]
            eth_prev = eth; f_prev = f_alpha_steps[k]
            t0 = time.time(); lu = splu(self._assemble(E)); info["lu_seconds"] += time.time() - t0
            dep = np.zeros((ne, 6))
            for it in range(max_plastic_iter):
                fe = ((d_star + dep) @ self.BtD.T) * (E * self.V)[:, None]
                rhs = np.bincount(self.dofs.ravel(), weights=fe.ravel(), minlength=self.ndof)
                du = lu.solve(rhs)
                due = du[self.dofs]
                d_eps = due @ self.Bavg.T
                d_sig = E[:, None] * ((d_eps - d_star - dep) @ self.D1.T)
                s_tr = np.where(rig[:, None], sig + d_sig, 0.0)
                vm = von_mises(s_tr)
                yld = rig & (vm > sy)
                scale = np.where(yld, sy / np.maximum(vm, 1e-9), 1.0)
                p = s_tr[:, :3].mean(axis=1)
                dev = s_tr - p[:, None] * one
                s_new = p[:, None] * one + dev * scale[:, None]
                add = ((s_tr - s_new) @ self.invD1.T) / E[:, None]
                dmax = np.abs(add).max(); ref = max(np.abs(d_star).max(), 1e-12)
                if dmax / ref < tol or not yld.any(): break
                dep = dep + add
            info["plastic_iterations"].append(it + 1); info["n_yielded_max"] = max(info["n_yielded_max"], int(yld.sum()))
            if not np.all(np.isfinite(s_new)): raise NumericalInstability("non-finite stress in thermo-mechanical solve")
            sig = np.where(rig[:, None], s_new, 0.0); epl = np.where(rig[:, None], epl + dep, 0.0)
            etot = np.where(rig[:, None], etot + d_eps, 0.0)
            u += du
            vm_hist[k] = von_mises(sig)
            ep_hist[k] = np.sqrt(2.0 / 3.0 * (epl[:, :3] ** 2).sum(1) + 1.0 / 3.0 * (epl[:, 3:] ** 2).sum(1))
            if progress: progress(k, nst)
        ue = u[self.dofs]
        grad = (ue @ self.Gavg.T).reshape(ne, 3, 3)
        return StressResult(self.cells, np.asarray(times_s), sig, vm_hist, ep_hist, etot, epl, eth_prev, self.node_xyz,
                            u.reshape(-1, 3), self.elem_nodes, grad, info)
