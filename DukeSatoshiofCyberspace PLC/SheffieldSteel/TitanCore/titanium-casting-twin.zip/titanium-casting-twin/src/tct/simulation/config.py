"""Scenario configuration (YAML) validated with Pydantic. Units are in the field names; mm/MPa appear only here at the user boundary."""
from __future__ import annotations
import copy, pathlib
from typing import Optional, Literal
import yaml
from pydantic import BaseModel, Field, field_validator
from ..errors import ConfigurationError

class GeometryCfg(BaseModel):
    kind: Literal["bracket", "plate", "mesh"] = "bracket"
    params: dict = Field(default_factory=dict)          # e.g. riser_d_mm, riser_h_mm, gate_h_mm, sprue_d_mm  (bracket)
    mesh_file: Optional[str] = None
    scale_to_m: float = 1e-3
    min_wall_mm: float = 4.0

class MeshCfg(BaseModel):
    dx_mm: float = 3.0
    shell_thickness_mm: float = 8.0
    @field_validator("dx_mm")
    @classmethod
    def _p(cls, v):
        if v <= 0: raise ValueError("dx_mm must be > 0")
        return v

class MoldCfg(BaseModel):
    kind: Literal["ceramic_shell", "graphite", "metal_mold", "water_cooled_copper"] = "ceramic_shell"
    preheat_C: float = 850.0
    h_contact_hot_W_m2K: Optional[float] = None
    h_contact_cold_W_m2K: Optional[float] = None

class MeltCfg(BaseModel):
    method: Literal["induction_skull", "var_skull", "ebm_hearth"] = "induction_skull"
    charge_mass_kg: float = 3.0
    charge_T0_C: float = 25.0
    target_superheat_C: float = 120.0
    hold_time_s: float = 20.0
    transfer_time_s: float = 4.0
    coil_power_W: Optional[float] = 150e3
    arc_current_A: Optional[float] = None
    arc_voltage_V: Optional[float] = None
    beam_power_W: Optional[float] = None
    efficiency: Optional[float] = None
    bath_area_m2: float = 0.02

class AtmosphereCfg(BaseModel):
    vacuum_pressure_Pa: float = 1.0
    argon_pressure_Pa: float = 0.0
    leak_rate_Pa_m3_s: float = 1e-3
    pump_speed_m3_s: float = 0.5
    h2_outgassing_Pa: float = 1e-2
    hydrogen_ppm_wt: float = 40.0

class PourCfg(BaseModel):
    pour_temperature_C: Optional[float] = None          # None => from melt model
    pour_rate_kg_s: Optional[float] = 0.5
    gravity_bias: float = 0.5
    contact_h_W_m2K: float = 1200.0
    cold_shut_margin_K: float = 40.0
    fs_coherency: float = 0.5

class ThermalCfg(BaseModel):
    surroundings_C: float = 100.0
    vacuum: bool = True
    convection_h_W_m2K: float = 10.0
    t_max_s: float = 4000.0
    cool_to_C: float = 300.0
    snapshot_growth: float = 0.05                      # relative spacing of snapshots
    snapshot_min_dt_s: float = 1.0
    fs_feed_limit: float = 0.7
    safety: float = 0.45

class StressCfg(BaseModel):
    enabled: bool = True
    n_steps: int = 12
    transformation_vol_strain: float = 0.0015
    mech_coarsen: int = 1

class HTSegmentCfg(BaseModel):
    kind: Literal["ramp", "hold", "cool", "age"]
    T_end_C: Optional[float] = None
    duration_s: Optional[float] = None
    rate_C_per_s: Optional[float] = None

class HTCfg(BaseModel):
    preset: Optional[Literal["none", "hip", "stress_relief", "beta_anneal"]] = "hip"
    segments: Optional[list[HTSegmentCfg]] = None
    hip_pressure_MPa: Optional[float] = None
    hip_T_C: float = 920.0
    hold_s: float = 7200.0

class MachiningCfg(BaseModel):
    allowance_mm: float = 1.0
    tolerance_mm: float = 0.1

class InspectionCfg(BaseModel):
    void_threshold: float = 1e-3
    methods: list[str] = ["ct", "xray", "ultrasonic", "dye_penetrant", "visual"]

class QualityCfg(BaseModel):
    overrides: dict = Field(default_factory=dict)       # name -> [review, high_risk]

class RunCfg(BaseModel):
    casting_id: str = "CAST-2047"
    run_number: int = 18
    seed: int = 20260101
    output_dir: str = "runs"

class UncertaintyParam(BaseModel):
    path: str                                           # dotted path into the scenario, e.g. pour.pour_temperature_C
    dist: Literal["normal", "uniform", "lognormal"] = "normal"
    mean: Optional[float] = None
    std: Optional[float] = None
    low: Optional[float] = None
    high: Optional[float] = None

class FailureCriterion(BaseModel):
    metric: str
    op: Literal[">", "<", ">=", "<="]
    threshold: float

class UncertaintyCfg(BaseModel):
    parameters: list[UncertaintyParam] = Field(default_factory=list)
    failure_criterion: Optional[FailureCriterion] = None
    fast_dx_mm: float = 6.0

class Scenario(BaseModel):
    name: str = "ti64_aerospace_bracket"
    alloy: str = "Ti-6Al-4V"
    geometry: GeometryCfg = GeometryCfg()
    mesh: MeshCfg = MeshCfg()
    mold: MoldCfg = MoldCfg()
    melt: MeltCfg = MeltCfg()
    atmosphere: AtmosphereCfg = AtmosphereCfg()
    pour: PourCfg = PourCfg()
    thermal: ThermalCfg = ThermalCfg()
    stress: StressCfg = StressCfg()
    heat_treatment: HTCfg = HTCfg()
    machining: MachiningCfg = MachiningCfg()
    inspection: InspectionCfg = InspectionCfg()
    quality: QualityCfg = QualityCfg()
    run: RunCfg = RunCfg()
    uncertainty: UncertaintyCfg = UncertaintyCfg()
    alloy_composition_shift_wt: dict = Field(default_factory=dict)   # e.g. {Al: +0.2, V: -0.1}; ESTIMATED linear transformation-temperature shifts
    alloy_property_scale: dict = Field(default_factory=dict)          # e.g. {thermal_conductivity: 1.05}  multiplicative property uncertainty

def load_scenario(path) -> Scenario:
    p = pathlib.Path(path)
    if not p.exists(): raise ConfigurationError(f"scenario file not found: {p}")
    raw = yaml.safe_load(p.read_text()) or {}
    try: return Scenario(**raw)
    except Exception as e: raise ConfigurationError(f"invalid scenario {p}: {e}") from e

def set_path(d: dict, path: str, value):
    keys = path.split("."); cur = d
    for k in keys[:-1]:
        if k not in cur: raise ConfigurationError(f"unknown config path {path!r} (at {k!r})")
        cur = cur[k]
    free = len(keys) >= 2 and keys[-2] in ("params", "alloy_composition_shift_wt", "alloy_property_scale")
    if keys[-1] not in cur and not free: raise ConfigurationError(f"unknown config path {path!r}")
    cur[keys[-1]] = value

def with_overrides(scn: Scenario, overrides: dict) -> Scenario:
    d = scn.model_dump()
    for k, v in overrides.items(): set_path(d, k, v)
    return Scenario(**d)

def get_path(scn: Scenario, path: str):
    cur = scn.model_dump()
    for k in path.split("."):
        if k not in cur: return None
        cur = cur[k]
    return cur
