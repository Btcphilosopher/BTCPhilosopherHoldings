"""End-to-end virtual foundry:  geometry -> mesh/validation -> melt -> atmosphere -> fill -> thermal/solidification ->
microstructure -> feeding -> porosity -> thermal stress -> residual stress -> distortion -> heat treatment -> machining ->
simulated inspection -> quality criteria -> manifest -> HDF5 run store."""
from __future__ import annotations
import dataclasses, json, os, pathlib, time
from dataclasses import dataclass, field
import numpy as np
from scipy import ndimage as ndi
from .config import Scenario
from ..errors import ConfigurationError, GeometryError
from ..geometry import library
from ..geometry.casting_system import PART, RISER, GATE, RUNNER, SPRUE, BASIN, METAL_ROLES, CastingSystem
from ..geometry.geometry import Geometry, mesh_hash
from ..materials.database import get_alloy, alloy_hash, DATABASE_VERSION
from ..melt.melt import MeltConfig, simulate_melt
from ..melt import atmosphere as atm_mod
from ..flow.fill import FillSolver, PourConfig
from ..thermal.solver import ThermalSolver, SolverConfig
from ..thermal.boundary import BoundaryCondition
from ..thermal import mold as mold_mod
from ..solidification import metrics as sol_mod
from ..feeding import analysis as feed_mod
from ..shrinkage.shrinkage import shrinkage_summary
from ..porosity import model as por_mod
from ..microstructure import model as mic_mod
from ..stress.fe import ThermoMechanical, von_mises, principal
from ..distortion import model as dist_mod
from ..heat_treatment import model as ht_mod
from ..machining import allowance as mach_mod
from ..inspection import simulate as insp_mod
from ..quality import engine as qe
from ..traceability.manifest import make_manifest, array_hash, json_hash
from ..digital_twin.store import RunStore
from ..digital_twin.engine import TimeSeriesEngine

F32 = np.float32

@dataclass
class RunResult:
    scenario: Scenario
    cs: CastingSystem
    alloy: object
    manifest: object
    results: dict
    fields: dict
    criteria: list
    fill: object
    timeline: list
    path: str | None = None
    timings: dict = field(default_factory=dict)
    stress: object = None
    distortion: object = None
    inspection: dict = field(default_factory=dict)
    warnings: list = field(default_factory=list)

def apply_alloy_variation(alloy, shift_wt, scale):
    """Composition shift (ESTIMATED linear coefficients) and multiplicative property scaling (uncertainty studies)."""
    from ..materials.properties import TabulatedProperty, Provenance
    if shift_wt: alloy = alloy.with_composition_shift(shift_wt)
    if scale:
        tables = dict(alloy.tables)
        for k, f in scale.items():
            if k not in tables: raise ConfigurationError(f"unknown property {k!r} in alloy_property_scale")
            t = tables[k]
            tables[k] = TabulatedProperty(t.name, t.unit, t.T_C, tuple(v * f for v in t.values),
                                          Provenance("user-supplied", f"{t.provenance.source} x {f:g}", "uncertainty scaling"))
        alloy = dataclasses.replace(alloy, tables=tables)
    return alloy

def _casting_system(scn: Scenario):
    g = scn.geometry; dx = scn.mesh.dx_mm * 1e-3; sh = scn.mesh.shell_thickness_mm * 1e-3
    if g.kind == "bracket": return library.build_bracket(dx, sh, **g.params)
    if g.kind == "plate": return library.plate_casting(dx_m=dx, shell_thickness_m=sh, **g.params)
    if g.kind == "mesh":
        if not g.mesh_file: raise ConfigurationError("geometry.kind=mesh needs mesh_file")
        geo = Geometry.from_mesh_file(g.mesh_file, g.scale_to_m)
        b = geo.bbox_m
        from ..geometry.sdf import Solid
        class _S(Solid):
            def __call__(self, x, y, z): return np.zeros_like(x)
        s = _S(); s.bbox_m = (b[0], b[1])
        cs = library.build_casting_system({"part": s}, dx, sh, name="imported_mesh")
        mask = geo.mask_on(cs.grid)
        role = np.zeros_like(cs.role); role[mask] = PART
        from scipy.ndimage import distance_transform_edt
        metal = role == PART
        dist = distance_transform_edt(~metal) * dx
        role[(~metal) & (dist <= sh)] = 8
        mat = np.zeros_like(cs.mat); mat[metal] = 1; mat[role == 8] = 2
        cs.role, cs.mat = role, mat
        cs.meta["note"] = "imported mesh: part only, bottom-fill assumption (no gating system)"
        return cs
    raise ConfigurationError(f"unknown geometry kind {g.kind}")

def _geometry_report(scn: Scenario, cs: CastingSystem):
    try:
        if scn.geometry.kind == "bracket":
            geo = library.bracket_cad_geometry()
            rep, mesh = geo.validate(cs.grid, min_wall_m=scn.geometry.min_wall_mm * 1e-3, pitch_m=2e-3)
            return rep.to_dict(), mesh_hash(mesh), rep
        mask = cs.mask(PART)
        from ..geometry import validation as V
        from ..geometry.geometry import voxel_surface_mesh
        mesh = voxel_surface_mesh(mask, cs.grid)
        rep = V.validate_mesh(mesh, check_intersections=False)
        V.thickness_report(mask, cs.grid.dx_m, scn.geometry.min_wall_mm * 1e-3, rep)
        return rep.to_dict(), mesh_hash(mesh), rep
    except Exception as e:           # report, never hide
        return {"error": f"geometry validation failed: {e}"}, "unavailable", None

def _to3(cs, cells, a, fill=np.nan, dtype=F32):
    out = np.full(cs.grid.shape, fill, dtype); out[tuple(cells.T)] = a; return out

def run_simulation(scn: Scenario, output_path=None, progress=None, verbose=False) -> RunResult:
    T_start = time.time(); timings = {}; warnings = []
    def log(msg):
        if progress: progress(msg)
    def tick(name, t0): timings[name] = time.time() - t0
    rng_seed = scn.run.seed; np.random.seed(rng_seed % (2 ** 32))
    sim_id = f"{scn.run.casting_id}-{scn.run.run_number:03d}"
    alloy = get_alloy(scn.alloy)
    alloy = apply_alloy_variation(alloy, scn.alloy_composition_shift_wt, scn.alloy_property_scale)
    t0 = time.time(); cs = _casting_system(scn); g = cs.grid; dx = g.dx_m
    part = cs.mask(PART); metal = cs.metal
    geom_dict, mhash, geo_rep = _geometry_report(scn, cs)
    tick("geometry", t0); log(f"geometry: grid {g.shape}, {int(metal.sum())} metal cells, {int(cs.mold.sum())} mold cells")
    results = {"geometry": {"grid": g.to_dict(), "volumes_m3": cs.volumes(), "summary": cs.summary(), "validation": geom_dict,
                            "n_cells_total": int((cs.mat > 0).sum()), "n_metal_cells": int(metal.sum())}}
    # ---------------- store ----------------
    target = pathlib.Path(output_path or pathlib.Path(scn.run.output_dir) / sim_id)
    if target.suffix == ".h5": outdir, h5path = target.parent, target
    else: outdir, h5path = target, target / "run.h5"
    outdir.mkdir(parents=True, exist_ok=True)
    store = RunStore(h5path, "w")
    # ---------------- melt + atmosphere ----------------
    t0 = time.time()
    mc = scn.melt
    melt_cfg = MeltConfig(method=mc.method, charge_mass_kg=mc.charge_mass_kg, charge_T0_C=mc.charge_T0_C, target_superheat_C=mc.target_superheat_C,
                          hold_time_s=mc.hold_time_s, transfer_time_s=mc.transfer_time_s, coil_power_W=mc.coil_power_W, arc_current_A=mc.arc_current_A,
                          arc_voltage_V=mc.arc_voltage_V, beam_power_W=mc.beam_power_W, efficiency=mc.efficiency, bath_area_m2=mc.bath_area_m2,
                          chamber_pressure_Pa=scn.atmosphere.vacuum_pressure_Pa)
    melt = simulate_melt(alloy, melt_cfg)
    a = scn.atmosphere
    atm = atm_mod.Atmosphere(a.vacuum_pressure_Pa, a.argon_pressure_Pa, a.leak_rate_Pa_m3_s, a.pump_speed_m3_s, a.h2_outgassing_Pa)
    contam = atm_mod.contamination_report(atm, melt.melt_temperature_C, melt.atmosphere_exposure_s, mc.bath_area_m2, mc.charge_mass_kg)
    T_pour = scn.pour.pour_temperature_C if scn.pour.pour_temperature_C is not None else melt.pour_temperature_C
    results["melt"] = dataclasses.asdict(melt); results["melt"]["al_loss_note"] = "UPPER BOUND (Langmuir/diffusion series); not applied to the alloy composition"
    results["contamination"] = contam
    results["shrinkage"] = shrinkage_summary(alloy, T_pour)
    tick("melt", t0); log(f"melt: pour temperature {T_pour:.0f} C")
    # ---------------- fill ----------------
    t0 = time.time()
    pc = PourConfig(pour_temperature_C=T_pour, pour_rate_kg_s=scn.pour.pour_rate_kg_s, mold_temperature_C=scn.mold.preheat_C,
                    chamber_pressure_Pa=atm.total_pressure_Pa, gravity_bias=scn.pour.gravity_bias, contact_h_W_m2K=scn.pour.contact_h_W_m2K,
                    cold_shut_margin_K=scn.pour.cold_shut_margin_K, fs_coherency=scn.pour.fs_coherency)
    mold0 = mold_mod.PRESETS[scn.mold.kind]()
    pc.shell_effusivity = mold0.effusivity(scn.mold.preheat_C)
    fill = FillSolver(cs, alloy, pc).run()
    fpart = cs.role[tuple(fill.cells.T)] == PART
    fs_ = dict(fill.scalars)
    fs_["misrun_part_volume_fraction"] = float((fill.risks["misrun_risk"][fpart] >= 1.0).mean()) if fpart.any() else 0.0
    fs_["cold_shut_max_part"] = float(fill.risks["cold_shut_risk"][fpart].max()) if fpart.any() else 0.0
    fs_["air_entrainment_index_part_max"] = float(fill.risks["air_entrainment_index"][fpart].max()) if fpart.any() else 0.0
    fs_["checks"] = fill.checks
    results["fill"] = fs_
    # fill snapshots to store
    nfs = 24; tsn = np.linspace(0.0, fill.fill_time_s, nfs)
    snaps = [fill.snapshot(t) for t in tsn]
    store.write_array("fill", "snap_times", tsn)
    for k in ("fill_fraction", "temperature_C", "velocity_m_s", "pressure_Pa"):
        store.write_array("fill", f"snap_{k}", np.stack([s[k] for s in snaps]).astype(F32))
    store.write_array("fill", "cells", fill.cells)
    for k, v in (("arrival_time_s", fill.arrival_time_s), ("T_arrival_C", fill.T_arrival_C), ("T_end_C", fill.T_end_C)):
        store.write_array("fill", k, v.astype(F32))
    for k, v in fill.risks.items(): store.write_array("fill", "risk_" + k, np.asarray(v, F32))
    store.write_array("fill", "t_hist", fill.t_hist); store.write_array("fill", "Q_hist", fill.Q_hist)
    tick("fill", t0); log(f"fill: {fill.fill_time_s:.2f} s, Q_peak={fill.scalars['Q_peak_m3_s']*1e3:.3f} L/s, misrun={fs_['misrun_part_volume_fraction']:.3f}")
    # oxidation exposure at the front (impingement-limited, indicative)
    t_exp = dx / np.maximum(fill.risks["front_speed_m_s"], 1e-3)
    ox = atm_mod.uptake_kg_m2(atm, "O2", T_pour, t_exp)
    # ---------------- thermal ----------------
    t0 = time.time()
    mold = mold_mod.PRESETS[scn.mold.kind]()
    if scn.mold.h_contact_hot_W_m2K or scn.mold.h_contact_cold_W_m2K:
        mold = dataclasses.replace(mold, h_contact_hot_W_m2K=scn.mold.h_contact_hot_W_m2K or mold.h_contact_hot_W_m2K,
                                   h_contact_cold_W_m2K=scn.mold.h_contact_cold_W_m2K or mold.h_contact_cold_W_m2K)
    th = scn.thermal
    bcs = [BoundaryCondition("radiation", emissivity=None, surrounding_temperature_C=th.surroundings_C)]
    if not th.vacuum: bcs.append(BoundaryCondition("convection", h_W_m2K=th.convection_h_W_m2K, ambient_temperature_C=th.surroundings_C))
    T0 = np.full(g.shape, np.nan); T0[tuple(fill.cells.T)] = fill.T_end_C
    T0[cs.mask(BASIN)] = T_pour
    thresholds = sol_mod.event_thresholds(alloy, th.fs_feed_limit)
    solver = ThermalSolver(cs, alloy, mold, mold, bcs, T_metal_C=T0, T_mold0_C=scn.mold.preheat_C, thresholds_C=thresholds,
                           config=SolverConfig(safety=th.safety, vacuum=th.vacuum))
    store.write_array("grid", "role", cs.role); store.write_array("grid", "mat", cs.mat); store.write_array("grid", "act", solver.act)
    engine = TimeSeriesEngine(solver, store, growth=th.snapshot_growth, min_dt=th.snapshot_min_dt_s, t_max=th.t_max_s, stop_T_C=th.cool_to_C,
                              callback=(lambda i, t: log(f"thermal t={t:8.1f}s  Tmax_metal={solver.max_metal_T():7.1f} C") if i % 25 == 0 else None))
    engine.run()
    eb, dE, Eloss = solver.energy_balance()
    tick("thermal", t0); log(f"thermal: {solver.steps} steps to t={solver.t:.0f}s, energy balance error {eb:.1e}")
    # ---------------- solidification, feeding, porosity, microstructure ----------------
    t0 = time.time()
    sol = sol_mod.compute(solver, th.fs_feed_limit)
    sf = sol.fields
    sol_sc = dict(sol.scalars)
    sol_sc["niyama_min_part"] = float(np.nanmin(np.where(part, sf["niyama_sqrtKs_mm"], np.nan))) if np.isfinite(sf["niyama_sqrtKs_mm"][part]).any() else None
    sol_sc["cooling_rate_beta_min_part"] = float(np.nanmin(np.where(part, sf["cooling_rate_beta_K_s"], np.nan))) if np.isfinite(sf["cooling_rate_beta_K_s"][part]).any() else None
    sol_sc["cooling_rate_beta_max_part"] = float(np.nanmax(np.where(part, sf["cooling_rate_beta_K_s"], np.nan))) if np.isfinite(sf["cooling_rate_beta_K_s"][part]).any() else None
    sol_sc["local_solidification_time_part_s"] = [float(np.nanmin(sf["local_solidification_time_s"][part])), float(np.nanmax(sf["local_solidification_time_s"][part]))]
    sol_sc["solidification_time_part_max_s"] = float(np.nanmax(np.where(part, sf["t_solidus_s"], np.nan)))
    sol_sc["thermal_gradient_part_K_mm"] = [float(np.nanmin(sf["thermal_gradient_K_m"][part]) / 1e3), float(np.nanmax(sf["thermal_gradient_K_m"][part]) / 1e3)]
    results["solidification"] = sol_sc
    feed = feed_mod.analyse(cs, alloy, sf["t_liquidus_s"], sf["t_solidus_s"], sf["t_feeding_limit_s"])
    results["feeding"] = feed.scalars
    air3 = _to3(cs, fill.cells, fill.risks["air_entrainment_index"], 0.0, np.float64)
    por_params = por_mod.PorosityParams(fs_feed_limit=th.fs_feed_limit, hydrogen_ppm_wt=scn.atmosphere.hydrogen_ppm_wt,
                                        chamber_pressure_Pa=atm.total_pressure_Pa)
    pf, ps = por_mod.compute(cs, alloy, sf, feed.fields, air3, fill.zb_at(fill.fill_time_s), por_params)
    results["porosity"] = ps
    mf, ms = mic_mod.compute(solver, sf, cs)
    results["microstructure"] = ms
    # alpha-case (mold-metal reaction, diffusion-limited upper bound): delta = 2 sqrt(integral D dt)
    depth = np.where(solver.is_metal, 2.0 * np.sqrt(solver.Dint), np.nan)
    ac3 = solver.to_field(depth).astype(F32)
    surface = metal & ~ndi.binary_erosion(metal)
    results["contamination"]["alpha_case_depth_mold_reaction_max_m"] = float(np.nanmax(np.where(surface & part, ac3, np.nan)))
    results["contamination"]["alpha_case_model"] = "REDUCED-ORDER upper bound: 2*sqrt(int D_O(T) dt) with unlimited oxygen supply at the mold interface; D_O ESTIMATED"
    tick("analysis", t0); log("analysis: solidification, feeding, porosity, microstructure done")
    # ---------------- stress ----------------
    t0 = time.time(); stress = None; dist = None
    fields = {}
    def put(d):
        for k, v in d.items(): fields[k] = np.asarray(v, F32) if np.asarray(v).dtype.kind == "f" else np.asarray(v)
    put(sf); put(feed.fields); put(pf); put(mf)
    fields["alpha_case_depth_m"] = ac3
    for k, v in (("fill_arrival_time_s", fill.arrival_time_s), ("fill_T_arrival_C", fill.T_arrival_C), ("fill_front_speed_m_s", fill.risks["front_speed_m_s"]),
                 ("misrun_risk", fill.risks["misrun_risk"]), ("cold_shut_risk", fill.risks["cold_shut_risk"]),
                 ("air_entrainment_index", fill.risks["air_entrainment_index"]), ("oxidation_uptake_kg_m2", ox),
                 ("flow_regime", fill.risks["flow_regime"].astype(float)), ("reynolds", fill.risks["reynolds"])):
        fields[k] = _to3(cs, fill.cells, v)
    times = store.times(); ns = len(times)
    st_res = {"enabled": False}
    if scn.stress.enabled:
        sel = solver.is_metal
        cells = np.argwhere(metal)
        Tm_all = store.read_T(slice(0, ns))[:, sel]
        T_rigid = alloy.T_solidus_C
        first_rig = int(np.argmax((Tm_all < T_rigid).any(axis=1)))
        start = max(first_rig - 1, 0)
        meanT = Tm_all.mean(axis=1)
        levels = np.linspace(meanT[start], meanT[-1], scn.stress.n_steps + 1)
        idx = sorted({start} | {int(np.argmin(np.abs(meanT[start:] - L))) + start for L in levels[1:]} | {ns - 1})
        T_steps = [Tm_all[i].astype(float) for i in idx]
        fa_steps = [store.read_f_alpha(i)[sel].astype(float) for i in idx]
        tm = ThermoMechanical(cells, dx, g.origin_m, alloy)
        stress = tm.run(T_steps, fa_steps, times[idx], T_rigid, scn.stress.transformation_vol_strain)
        sg = stress.sigma_final
        def c3(a): return _to3(cs, cells, a)
        names = ("sxx", "syy", "szz", "txy", "tyz", "tzx")
        for i, n_ in enumerate(names): fields[f"residual_{n_}_Pa"] = c3(sg[:, i])
        vm = von_mises(sg); p1 = principal(sg)
        fields["residual_vm_Pa"] = c3(vm); fields["residual_principal1_Pa"] = c3(p1[:, 0]); fields["residual_principal3_Pa"] = c3(p1[:, 2])
        fields["plastic_strain_eq"] = c3(stress.epl_eq_hist[-1])
        yRT = float(alloy.tables["yield_strength"](20.0))
        pm = part[tuple(cells.T)]
        st_res = {"enabled": True, "n_steps": len(idx), "step_times_s": [float(times[i]) for i in idx], "vm_max_part_MPa": float(vm[pm].max() / 1e6),
                  "vm_mean_part_MPa": float(vm[pm].mean() / 1e6), "vm_max_over_yield_RT": float(vm[pm].max() / yRT),
                  "principal1_max_part_MPa": float(p1[pm, 0].max() / 1e6), "principal3_min_part_MPa": float(p1[pm, 2].min() / 1e6),
                  "plastic_strain_eq_max_part": float(stress.epl_eq_hist[-1][pm].max()),
                  "yielded_cells_max": stress.solve_info["n_yielded_max"], "linear_thermal_contraction": float(-stress.eps_thermal_final.mean()),
                  "yield_RT_MPa": yRT / 1e6, "model": stress.model, "solve_info": {k: v for k, v in stress.solve_info.items()},
                  "limitations": "no mold restraint, no creep, constant nu, perfectly-plastic von Mises"}
        dist = dist_mod.compute(stress, cs, part)
        for k, v in dist.fields.items(): fields[k] = np.asarray(v, F32)
        results["distortion"] = dict(dist.scalars, model=dist.model)
        store.write_array("stress", "cells", cells); store.write_array("stress", "step_times", times[idx])
        store.write_array("stress", "vm_hist", stress.vm_hist); store.write_array("stress", "epl_eq_hist", stress.epl_eq_hist)
        store.write_array("stress", "sigma_final", sg.astype(F32)); store.write_array("stress", "node_xyz", stress.node_xyz)
        store.write_array("stress", "node_u", stress.node_u); store.write_array("stress", "elem_nodes", stress.elem_nodes)
        store.write_array("stress", "node_residual", dist.node_residual)
    else:
        results["distortion"] = {"max_warpage_m": 0.0, "note": "stress disabled"}
    results["stress"] = st_res
    tick("stress", t0); log("stress/distortion done")
    # ---------------- heat treatment ----------------
    t0 = time.time()
    hc = scn.heat_treatment
    ht = None
    if hc.segments:
        ht = ht_mod.HeatTreatment([ht_mod.Segment(s.kind, s.T_end_C, s.duration_s, s.rate_C_per_s) for s in hc.segments], hip_pressure_MPa=hc.hip_pressure_MPa)
    elif hc.preset == "hip": ht = ht_mod.cycle_hip(hc.hip_T_C, hc.hold_s, hc.hip_pressure_MPa or 100.0)
    elif hc.preset == "stress_relief": ht = ht_mod.cycle_stress_relief(hold_s=hc.hold_s)
    elif hc.preset == "beta_anneal": ht = ht_mod.cycle_beta_anneal()
    ht_profile = None
    if ht is not None:
        thick = cs.local_thickness_field_m()
        vf = np.nan_to_num(fields["predicted_void_fraction"], nan=0.0)
        edt_surf = ndi.distance_transform_edt(metal) * dx
        sigma_in = stress.sigma_final if stress is not None else None
        out, hsc = ht_mod.apply(ht, alloy, cs, {"lath_thickness_um": fields["lath_thickness_um"].astype(float), "alpha_fraction": fields["alpha_fraction"].astype(float)},
                                sigma_in, vf, float(np.median(thick[part])), edt_surf)
        for k, v in out.items():
            if k.startswith("_"): continue
            fields[k] = np.asarray(v, F32)
        if stress is not None:
            vm_rel = out["_vm_relaxed"]; sq = float(np.nanmedian(out["quench_stress_estimate_Pa"][part])) if "quench_stress_estimate_Pa" in out else 0.0
            fields["residual_vm_after_ht_Pa"] = _to3(cs, np.argwhere(metal), np.sqrt(vm_rel ** 2 + sq ** 2))
            hsc["residual_vm_after_ht_max_MPa"] = float(np.sqrt(vm_rel[part[tuple(np.argwhere(metal).T)]] ** 2 + sq ** 2).max() / 1e6)
        tH, TH, _ = ht.profile(dt=30.0); ht_profile = {"t_s": tH.tolist(), "T_C": TH.tolist()}
        hsc["profile"] = ht_profile; results["heat_treatment"] = hsc
        store.write_array("ht", "t_s", tH); store.write_array("ht", "T_C", TH)
    else:
        results["heat_treatment"] = {"applied": False}
    tick("heat_treatment", t0)
    # ---------------- machining ----------------
    mc_ = scn.machining
    dmag = fields.get("distortion_mag_m", np.zeros(g.shape, F32))
    mf_, msc = mach_mod.compute(cs, mc_.allowance_mm * 1e-3, fields["alpha_case_depth_m"], dmag, mc_.tolerance_mm * 1e-3)
    fields["machining_margin_m"] = mf_["machining_margin_m"].astype(F32)
    fields["final_geometry_mask"] = mf_["final_geometry_mask"].astype(np.int8)
    results["machining"] = msc
    # ---------------- inspection ----------------
    vf_i = fields.get("predicted_void_fraction_ht", fields["predicted_void_fraction"]).astype(float)
    scale = np.where(fields["predicted_void_fraction"] > 0, vf_i / np.maximum(fields["predicted_void_fraction"], 1e-12), 0.0)
    comp = lambda name: np.nan_to_num(fields[name].astype(float), nan=0.0) * np.nan_to_num(scale, nan=0.0)
    ic = insp_mod.InspectionConfig(void_threshold=scn.inspection.void_threshold, methods=tuple(scn.inspection.methods), seed=rng_seed)
    insp = insp_mod.simulate(cs, vf_i, comp("microshrinkage_void_fraction") + comp("macro_shrinkage_void_fraction"),
                             comp("macro_shrinkage_void_fraction"), comp("gas_void_fraction_hydrogen") + comp("gas_void_fraction_entrained"), ic,
                             distortion_mag3=fields.get("distortion_mag_m"))
    results["inspection"] = insp
    # ---------------- conservation / numerical-quality ----------------
    fs_all = alloy.solid_fraction(solver.T[solver.is_metal])
    cons = {"energy_balance_rel_error": eb, "energy_tolerance": 1e-6, "energy_ok": bool(eb < 1e-6),
            "fill_volume_rel_error": fill.checks["volume_conservation_rel_err"], "fill_ok": fill.checks["volume_conservation_rel_err"] < 1e-6,
            "phase_fraction_max_error": float(np.max(np.abs((1 - fs_all) + fs_all - 1.0))), "phase_ok": True,
            "boundary_conditions_validated": True, "nan_detected": False, "time_steps": solver.steps, "solver_warnings": solver.warnings,
            "solidification_complete": bool(sol.scalars["solidification_complete"])}
    cons["all_ok"] = bool(cons["energy_ok"] and cons["fill_ok"] and cons["phase_ok"] and cons["solidification_complete"])
    if not cons["all_ok"]: warnings.append("CONSERVATION/COMPLETENESS FLAG: see results['conservation']")
    results["conservation"] = cons
    # ---------------- quality criteria ----------------
    criteria = qe.evaluate(results, {k: tuple(v) for k, v in scn.quality.overrides.items()})
    # ---------------- manifest ----------------
    mesh_h = mhash
    geom_h = array_hash(cs.role.astype(np.int8))
    pcfg = json.loads(scn.model_dump_json()); scfg = {"safety": th.safety, "dt_max_s": solver.cfg.dt_max_s, "dx_m": dx, "n_active_cells": int(len(solver.act)),
                                                       "snapshot_growth": th.snapshot_growth, "fs_feed_limit": th.fs_feed_limit}
    manifest = make_manifest(sim_id, DATABASE_VERSION, alloy_hash(alloy), geom_h, mesh_h, pcfg, scfg, rng_seed)
    # ---------------- timeline (process time, s) ----------------
    t_ch = 60.0; t_melt = melt.time_to_liquidus_s if np.isfinite(melt.time_to_liquidus_s) else 0.0
    t_sh = (melt.time_to_superheat_s - melt.time_to_liquidus_s + melt.hold_time_s) if np.isfinite(melt.time_to_superheat_s) else melt.hold_time_s
    tl = []; cur = 0.0
    def stage(name, dur, kind):
        nonlocal cur; tl.append({"name": name, "t0": cur, "t1": cur + dur, "kind": kind}); cur += dur
    stage("CHARGE", t_ch, "melt"); stage("MELT", max(t_melt, 1.0), "melt"); stage("SUPERHEAT", max(t_sh, 1.0), "melt")
    stage("POUR", max(melt.transfer_loss_C * 0 + mc.transfer_time_s, 1.0), "melt")
    stage("FILL", fill.fill_time_s, "fill"); stage("SOLIDIFICATION", float(sol_sc["solidification_time_part_max_s"]), "thermal")
    stage("COOL", max(float(times[-1]) - float(sol_sc["solidification_time_part_max_s"]), 1.0), "thermal")
    stage("HEAT TREAT", (ht_profile["t_s"][-1] if ht_profile else 1.0), "ht"); stage("INSPECT", 1.0, "inspect")
    results["timeline"] = tl
    # ---------------- persist ----------------
    for k, v in fields.items(): store.write_array("fields", k, v)
    store.write_json("manifest", manifest.to_dict()); store.write_json("scenario", pcfg); store.write_json("results", results)
    store.write_json("criteria", [c.to_dict() for c in criteria]); store.write_json("timeline", tl)
    store.write_json("alloy", {"name": alloy.name, "hash": alloy_hash(alloy), "T_liquidus_C": alloy.T_liquidus_C, "T_solidus_C": alloy.T_solidus_C,
                               "T_beta_C": alloy.T_beta_C, "estimated_fraction": alloy.fraction_estimated()})
    store.write_json("grid", g.to_dict()); store.write_json("thresholds_C", thresholds)
    store.write_json("warnings", warnings)
    store.close()
    (outdir / "manifest.json").write_text(json.dumps(manifest.to_dict(), indent=2, default=str))
    timings["total"] = time.time() - T_start
    return RunResult(scn, cs, alloy, manifest, results, fields, criteria, fill, tl, str(h5path), timings, stress, dist, insp, warnings)
