"""Verification / validation against analytical solutions and literature values.  Disagreement is never hidden: every row reports
prediction, reference, absolute and relative error, tolerance, and whether the tolerance was met.

These are VERIFICATION cases (does the numerical scheme solve the stated equations?). They are NOT validation against foundry
experiments; that requires user-provided data (see tct.validation.compare_to_data and docs/validation)."""
from __future__ import annotations
from dataclasses import dataclass, asdict, replace
import numpy as np
from scipy.special import erfc, erf
from scipy.optimize import brentq
from scipy.integrate import solve_ivp
from ..geometry.grid import Grid
from ..geometry.casting_system import CastingSystem, MAT_METAL
from ..materials.database import get_alloy
from ..materials.properties import table
from ..thermal.solver import ThermalSolver, SolverConfig
from ..thermal.boundary import BoundaryCondition
from ..units import SIGMA_SB, c2k

@dataclass
class ValidationRow:
    case: str
    quantity: str
    prediction: float
    reference: float
    abs_error: float
    rel_error: float
    tolerance_rel: float
    passed: bool
    kind: str
    note: str = ""
    def to_dict(self): return asdict(self)

def _row(case, q, pred, ref, tol, kind, note=""):
    ae = abs(pred - ref); re = ae / abs(ref) if ref != 0 else float("inf")
    return ValidationRow(case, q, float(pred), float(ref), float(ae), float(re), tol, bool(re <= tol), kind, note)

def _const_alloy(k=30.0, cp=700.0, rho=4000.0, L=0.0, TL=1600.5, TS=1599.5, eps=0.4):
    a = get_alloy("ti64"); P = lambda n, u, v: table(n, u, [(0, v), (2300, v)], "user-supplied", "validation case (constant property)")
    t = dict(a.tables); t.update(thermal_conductivity=P("k", "W/mK", k), specific_heat=P("cp", "J/kgK", cp), density=P("rho", "kg/m3", rho), emissivity=P("eps", "-", eps))
    from ..materials.properties import ScalarProperty, Provenance
    pr = Provenance("user-supplied", "validation")
    return replace(a, tables=t, latent_heat=ScalarProperty("L", L, "J/kg", pr), liquidus=ScalarProperty("liq", TL, "C", pr), solidus=ScalarProperty("sol", TS, "C", pr),
                   beta_transus=ScalarProperty("beta", 5000.0, "C", pr))

def _bar_cs(n, dx):
    shape = (n + 2, 3, 3); role = np.zeros(shape, np.int8); mat = np.zeros(shape, np.int8)
    role[1:n + 1, 1, 1] = 1; mat[1:n + 1, 1, 1] = 1
    return CastingSystem(Grid(shape, dx, (0, 0, 0)), role, mat, 0.0, "bar")

def semi_infinite_conduction():
    a = _const_alloy(); dx = 1e-3; n = 120
    cs = _bar_cs(n, dx)
    bcs = [BoundaryCondition("adiabatic"), BoundaryCondition("fixed_temperature", fixed_temperature_C=0.0, region=1)]
    s = ThermalSolver(cs, a, T_metal_C=1000.0, bcs=bcs, thresholds_C=[900.0], config=SolverConfig(safety=0.4))
    first = (s.act[:, 0] == 1); s.reg[first] = 1
    t = 60.0; s.advance_to(t)
    x = (s.act[:, 0] - 1) * dx
    alpha = 30.0 / (4000.0 * 700.0)
    ref = 1000.0 * (1.0 - erfc(x / (2 * np.sqrt(alpha * t))))        # Dirichlet 0 C at the first cell centre
    err = np.max(np.abs(s.T - ref)) / 1000.0
    return _row("semi-infinite conduction (erfc)", "max |T - T_exact| / dT", err, 1e-12, 0.02, "analytical",
                "constant properties; reference value is 0, tolerance is on the normalised max error (reported in prediction)") if False else \
           ValidationRow("semi-infinite conduction (erfc)", "max |T-T_exact|/dT", float(err), 0.0, float(err), float(err), 0.02, bool(err <= 0.02), "analytical", "constant properties, Dirichlet at first cell centre; error is normalised by the 1000 K step")

def _stefan(TL, TS, dx, tol, case, kind="analytical", note=""):
    L = 286e3; c = 700.0; rho = 4000.0; k = 30.0
    a = _const_alloy(k, c, rho, L, TL=TL, TS=TS)
    Tm = 0.5 * (TL + TS); Tw = 1300.0; St = c * (Tm - Tw) / L
    lam = brentq(lambda l: l * np.exp(l * l) * erf(l) - St / np.sqrt(np.pi), 1e-6, 5.0)
    alpha = k / (rho * c); n = int(0.08 / dx)
    cs = _bar_cs(n, dx)
    bcs = [BoundaryCondition("adiabatic"), BoundaryCondition("fixed_temperature", fixed_temperature_C=Tw, region=1)]
    s = ThermalSolver(cs, a, T_metal_C=TL, bcs=bcs, thresholds_C=[Tm], config=SolverConfig(safety=0.4))
    s.reg[s.act[:, 0] == 1] = 1
    t = 25.0; s.advance_to(t)
    T = s.T; x = (s.act[:, 0] - 1) * dx
    i = np.argmax(T > Tm)
    xf = np.interp(Tm, [T[i - 1], T[i]], [x[i - 1], x[i]])
    ref = 2 * lam * np.sqrt(alpha * t)
    return _row(case, "front position at 25 s [m]", xf, ref, tol, kind, f"Stefan number {St:.3f}; zero superheat; enthalpy method. " + note)

def stefan_front():
    return [_stefan(1602.0, 1598.0, 0.5e-3, 0.03, "Stefan solidification front (Neumann), 4 K freezing range"),
            _stefan(1600.5, 1599.5, 0.5e-3, 0.03, "Stefan front, 1 K freezing range (KNOWN LIMITATION)", "known-limitation",
                    "freezing ranges narrower than ~3 K are under-resolved by the 1 K enthalpy lookup table; the solver warns at construction. All titanium alloys here have ranges >= 25 K")]

def radiative_cooling():
    a = _const_alloy(k=30.0, cp=700.0, rho=4000.0, eps=0.4)
    n = 4; dx = 5e-3; shape = (n + 2,) * 3; role = np.zeros(shape, np.int8); mat = np.zeros(shape, np.int8)
    role[1:n + 1, 1:n + 1, 1:n + 1] = 1; mat[1:n + 1, 1:n + 1, 1:n + 1] = 1
    cs = CastingSystem(Grid(shape, dx, (0, 0, 0)), role, mat, 0.0, "cube")
    s = ThermalSolver(cs, a, T_metal_C=1200.0, bcs=[BoundaryCondition("radiation", emissivity=0.4, surrounding_temperature_C=25.0)], thresholds_C=[900.0])
    t_end = 120.0; s.advance_to(t_end)
    V = (n * dx) ** 3; A = 6 * (n * dx) ** 2
    f = lambda t, T: -0.4 * SIGMA_SB * A * (T ** 4 - c2k(25.0) ** 4) / (4000.0 * 700.0 * V)
    ref = solve_ivp(f, [0, t_end], [c2k(1200.0)], rtol=1e-9, atol=1e-9).y[0, -1] - 273.15
    return _row("radiative cooling (lumped cube)", "T(120 s) [C]", float(s.T.mean()), float(ref), 0.01, "analytical",
                "Bi~0.02 so lumped ODE is the reference; boundary law eps*sigma*(T^4-Tsur^4)")

def energy_conservation_plate():
    from ..geometry.library import plate_casting
    cs = plate_casting(dx_m=5e-3, shell_thickness_m=10e-3); a = get_alloy("ti64")
    s = ThermalSolver(cs, a, T_metal_C=1750.0, T_mold0_C=800.0, bcs=[BoundaryCondition("radiation", surrounding_temperature_C=100.0)])
    s.advance_to(80.0); eb, dE, El = s.energy_balance()
    return ValidationRow("energy conservation (plate + shell, with latent heat)", "|dE + E_lost| / |E_lost|", float(eb), 0.0, float(eb), float(eb), 1e-9, bool(eb <= 1e-9), "conservation",
                         f"E_lost = {El/1e3:.1f} kJ, dE = {dE/1e3:.1f} kJ")

def gnielinski_benchmark():
    from ..flow.fluid import nusselt
    nu = float(nusselt(1e4, 0.7))
    return _row("Gnielinski correlation", "Nu(Re=1e4, Pr=0.7)", nu, 29.9, 0.03, "literature", "hand evaluation of Gnielinski/Petukhov; textbook value ~30")

def fill_torricelli():
    """Single orifice: with K=0 the model must reproduce Q = A sqrt(2 g H) (mass-balance + Bernoulli)."""
    from ..flow.fill import FillSolver, PourConfig
    from ..geometry.sdf import Box
    from ..geometry.casting_system import build_casting_system
    mm = 1e-3
    def box(c, h):
        b = Box(c, h); b.bbox_m = (np.array(c) - np.array(h), np.array(c) + np.array(h)); return b
    basin = box((0.0, 0.0, 0.18), (0.03, 0.03, 0.02)); sprue = box((0.0, 0.0, 0.10), (0.01, 0.01, 0.06))
    part = box((0.0, 0.0, 0.03), (0.02, 0.02, 0.03))
    cs = build_casting_system({"part": part, "sprue": sprue, "basin": basin}, 4e-3, 6e-3, basin_fill_fraction=1.0)
    a = get_alloy("ti64")
    pc = PourConfig(pour_temperature_C=1750, pour_rate_kg_s=None, K_entry=0.0, K_bends=0.0, friction_factor=0.0, gravity_bias=0.0)
    r = FillSolver(cs, a, pc).run()
    # initial rate
    Q0 = float(r.Q_hist[1:5].mean()); A = r.scalars["A_gate_m2"]
    H = r.zb_at(0.0) - float(np.mean(r.z_cell_m[np.argsort(r.cost_m)[:20]]))
    ref = A * np.sqrt(2 * 9.80665 * H / (1.0 + r.scalars["K_total"]))
    return _row("Torricelli outflow (K=0.5 contraction only)", "Q0 [m^3/s]", Q0, ref, 0.30, "analytical", "A_gate is the sprue/part interface; head from front-z estimate -> loose tolerance; checks order of magnitude and scaling")

def stress_free_contraction():
    from ..stress.fe import ThermoMechanical
    a = get_alloy("ti64"); n = 5; cells = np.argwhere(np.ones((n, n, n), bool)); tm = ThermoMechanical(cells, 1e-3, (0, 0, 0), a)
    T0 = np.full(len(cells), 1650.0); steps = [T0] + [np.full(len(cells), float(T)) for T in (1400, 1000, 600, 25)]
    r = tm.run(steps, [np.zeros(len(cells))] * len(steps), np.arange(len(steps)), 1605.0)
    ux = r.node_u[:, 0]; free = abs(float(a.thermal_strain(25.0, 1605.0))) * n * 1e-3
    return [ _row("FE free thermal contraction", "extent change [m]", float(ux.max() - ux.min()), free, 1e-4, "analytical", "uniform cooling of a free block: displacement = eps_th * L"),
             ValidationRow("FE free body is stress-free", "max von Mises [Pa] / E", float(r.vm_hist.max() / 114e9), 0.0, float(r.vm_hist.max() / 114e9), float(r.vm_hist.max() / 114e9), 1e-6, bool(r.vm_hist.max() / 114e9 <= 1e-6), "analytical", "no restraint, uniform T => zero stress")]

def stress_equilibrium():
    from ..stress.fe import ThermoMechanical
    a = get_alloy("ti64"); n = 6; c = np.argwhere(np.ones((n, n, n), bool)); tm = ThermoMechanical(c, 1e-3, (0, 0, 0), a)
    core = np.abs(c - 2.5).max(1) < 1.5; T0 = np.full(len(c), 1650.0); st = [T0]
    for Tc, Ts in ((1500, 1400), (1300, 1000), (1100, 700), (800, 400), (500, 300)): st.append(np.where(core, Tc, Ts).astype(float))
    r = tm.run(st, [np.zeros(len(c))] * len(st), np.arange(len(st)), 1605.0)
    F = r.sigma_final[:, 0].sum() / (np.abs(r.sigma_final[:, 0]).sum() + 1e-30)
    return ValidationRow("FE force equilibrium (gradient block)", "|sum sigma_xx| / sum|sigma_xx|", float(abs(F)), 0.0, float(abs(F)), float(abs(F)), 0.02, bool(abs(F) <= 0.02), "conservation", "free body: net force from residual stress must vanish")

def chvorinov_trend():
    """Informational: fit exponent n in t_sol ~ M^n over plates of different thickness. Chvorinov (infinite sand mold) gives n=2;
    for a thin radiating ceramic shell the interface/shell resistance dominates and n<2 is expected. We REPORT the model's exponent."""
    from ..geometry.library import plate_casting
    a = get_alloy("ti64"); ts = []; Ms = []
    for th in (0.010, 0.020, 0.030):
        cs = plate_casting(thickness_m=th, length_m=0.08, width_m=0.08, dx_m=2.5e-3, shell_thickness_m=8e-3)
        s = ThermalSolver(cs, a, T_metal_C=a.T_liquidus_C + 1.0, T_mold0_C=850.0, bcs=[BoundaryCondition("radiation", surrounding_temperature_C=100.0)],
                          thresholds_C=[a.T_liquidus_C, a.T_solidus_C])
        t = 0.0
        while np.isnan(s.t_cross[1][s.is_metal]).any() and t < 600: t += 20; s.advance_to(t)
        ts.append(float(np.nanmax(s.t_cross[1][s.is_metal]))); Ms.append(cs.modulus_m(1))
    n = np.polyfit(np.log(Ms), np.log(ts), 1)[0]
    return _row("Chvorinov trend (informational)", "exponent n in t_sol ~ M^n", float(n), 2.0, 0.60, "literature",
                "Chvorinov n=2 assumes a semi-infinite mold; for a thin radiating ceramic shell n<2 is expected, so a deviation is a physical finding, not a pass/fail of the solver")

def run_suite(quick=True):
    rows = []
    for fn in (semi_infinite_conduction, stefan_front, radiative_cooling, energy_conservation_plate, gnielinski_benchmark, fill_torricelli,
               stress_free_contraction, stress_equilibrium) + (() if quick else (chvorinov_trend,)):
        r = fn(); rows.extend(r if isinstance(r, list) else [r])
    return rows

def to_markdown(rows):
    L = ["| case | quantity | prediction | reference | abs err | rel err | tol | status |", "|---|---|---|---|---|---|---|---|"]
    for r in rows:
        L.append(f"| {r.case} | {r.quantity} | {r.prediction:.5g} | {r.reference:.5g} | {r.abs_error:.3g} | {r.rel_error:.3g} | {r.tolerance_rel:g} | {'PASS' if r.passed else 'DISAGREES'} |")
    return "\n".join(L)

def compare_to_data(name, quantity, predicted, measured, tolerance_rel=0.1, source="user-provided foundry data"):
    """Row for user data (e.g. thermocouple peak, solidification time). Always reported, including disagreements."""
    return _row(name, quantity, float(predicted), float(measured), tolerance_rel, "experimental", source)
