"""Static HTML dashboard (restrained British aerospace-laboratory look) generated from a stored run.
Layout follows the specification: header / 3D (mid-plane) view + PROCESS / THERMAL HISTORY + INTEGRITY, plus a scrubbable
process timeline whose frames are rendered from the stored simulation fields. All values derive from the run store."""
from __future__ import annotations
import html, json
import numpy as np
from ..visualization import static as S

CSS = """
:root{--g:#2b2f33;--w:#f4f1ea;--s:#8a949c;--n:#14233b;--b:#3e6a9e;--a:#b8872e;--r:#a63d33;--ok:#4f7a5a}
*{box-sizing:border-box}body{margin:0;background:var(--w);color:var(--g);font:13px/1.45 'Helvetica Neue',Arial,sans-serif}
header{background:var(--n);color:var(--w);padding:14px 22px;border-bottom:3px solid var(--b)}
header h1{margin:0;font-size:16px;letter-spacing:.14em;font-weight:600}header .sub{font-size:12px;color:#c9d2dc;margin-top:3px;letter-spacing:.05em}
.grid{display:grid;grid-template-columns:1.25fr 1fr;gap:1px;background:var(--s);margin:0}
.cell{background:var(--w);padding:14px 18px}.cell h2{margin:0 0 8px;font-size:11px;letter-spacing:.16em;color:var(--b);font-weight:700}
table{border-collapse:collapse;width:100%}td,th{padding:3px 6px;text-align:left;border-bottom:1px solid #dcd8cf;font-size:12px}th{color:var(--s);font-weight:600}
td.v{font-variant-numeric:tabular-nums;text-align:right}.PASS{color:var(--ok);font-weight:700}.REVIEW{color:var(--a);font-weight:700}.HIGH-RISK{color:var(--r);font-weight:700}.REPORTED,.NOT-EVALUATED{color:var(--s);font-weight:700}
.note{font-size:11px;color:#5d666d}.banner{background:#e8e3d6;border-left:3px solid var(--a);padding:6px 10px;margin:10px 18px;font-size:11.5px}
img{max-width:100%}.slider{padding:12px 22px;background:#ebe7dc;border-top:1px solid var(--s)}input[type=range]{width:100%}
.stage{display:flex;gap:2px;margin-bottom:6px}.stage div{flex:1;text-align:center;padding:4px 0;font-size:10px;letter-spacing:.08em;background:var(--s);color:#fff;cursor:pointer}
.stage div.on{background:var(--n)}.mono{font-family:Menlo,Consolas,monospace;font-size:11px}
"""

def _row(k, v, unit=""): return f"<tr><td>{html.escape(k)}</td><td class='v'>{html.escape(str(v))} {html.escape(unit)}</td></tr>"

def build_html(run, n_frames=14) -> str:
    R = run.results; sc = run.scenario; man = run.manifest
    fill = R["fill"]; sol = R["solidification"]; st = R["stress"]; di = R["distortion"]
    frames = S.frames_for_slider(run, n_thermal=n_frames)
    frames = [f for f in frames if f[2] is not None]
    q = run.query([0.03, 0.0, 0.03])
    hist = S.b64(S.fig_png(S.thermal_history_figure(q), 90))
    tl = S.b64(S.fig_png(S.timeline_figure(run), 90))
    stage_names = [s["name"] for s in run.timeline]
    status = {c["name"]: c for c in run.criteria}
    def st_(n): return status[n]["status"] if n in status else "NOT-EVALUATED"
    integ = [("Fill integrity", "fill_integrity_misrun_fraction"), ("Feeding", "feeding_isolated_volume_fraction"), ("Porosity", "porosity_indicator_max"),
             ("Stress", "residual_stress_vm_over_yield"), ("Distortion", "distortion_max_warpage_mm"), ("Machining margin", "machining_min_margin_mm"),
             ("Inspection (SIMULATED)", "inspection_largest_indication_mm")]
    integ_html = "".join(f"<tr><td>{a}</td><td class='v {st_(n)}'>{st_(n)}</td></tr>" for a, n in integ)
    crit_rows = "".join(
        f"<tr><td>{html.escape(c['name'])}</td><td class='v'>{'n/a' if c['value'] is None else format(c['value'], '.4g')} {html.escape(c['unit'])}</td>"
        f"<td class='v'>{c['review_threshold']:.3g} / {c['high_risk_threshold']:.3g}</td><td class='{c['status']}'>{c['status']}</td>"
        f"<td class='note'>{html.escape(c['confidence'])} | {html.escape(c['model'])}</td><td class='note'>{html.escape(c['source'])}</td></tr>" for c in run.criteria)
    fr_js = json.dumps([{"t": f[0], "stage": f[1], "img": S.b64(f[2])} for f in frames])
    stage_js = json.dumps(stage_names)
    T_pour = sc["pour"]["pour_temperature_C"] or R["melt"]["pour_temperature_C"]
    h = f"""<!doctype html><html><head><meta charset="utf-8"><title>Titanium Casting Digital Twin {html.escape(man['simulation_id'])}</title><style>{CSS}</style></head><body>
<header><h1>TITANIUM CASTING DIGITAL TWIN</h1><div class="sub">{html.escape(run.alloy_info['name'])} &nbsp;|&nbsp; {html.escape(sc['run']['casting_id'])} &nbsp;|&nbsp; RUN {sc['run']['run_number']:03d} &nbsp;|&nbsp; {html.escape(man['timestamp_utc'])}</div></header>
<div class="banner"><b>Reduced-order research model.</b> Results are indicators derived from explicit physics models with ESTIMATED constants; they are not a certification
and not validated against foundry data. Inspection results are SIMULATED. Model status is listed per criterion below.</div>
<div class="grid">
<div class="cell"><h2>3D CASTING &mdash; MID-PLANE VIEW (process timeline)</h2><div id="frame"></div></div>
<div class="cell"><h2>PROCESS</h2><table>
{_row('Pour temperature', f'{T_pour:.0f}', '&deg;C'.replace('&deg;','deg '))}{_row('Mold preheat', f"{sc['mold']['preheat_C']:.0f}", 'deg C')}
{_row('Fill', f"{fill['fill_time_s']:.2f}", 's')}{_row('Solidify (part, solidus)', f"{sol['solidification_time_part_max_s']:.1f}", 's')}
{_row('Mesh cells (active)', f"{R['geometry']['n_cells_total']:,}")}{_row('Metal cells', f"{R['geometry']['n_metal_cells']:,}")}
{_row('Melt method', R['melt'].get('notes') and sc['melt']['method'] or sc['melt']['method'])}{_row('Atmosphere', f"{sc['atmosphere']['vacuum_pressure_Pa']:g} Pa vacuum")}
{_row('Heat treatment', sc['heat_treatment']['preset'] or 'custom')}{_row('Energy balance error', f"{R['conservation']['energy_balance_rel_error']:.1e}")}
</table></div>
<div class="cell"><h2>THERMAL HISTORY (probe: boss region)</h2><img src="data:image/png;base64,{hist}"></div>
<div class="cell"><h2>INTEGRITY (screening thresholds; see criteria)</h2><table>{integ_html}</table>
<p class="note">Status uses default screening thresholds, not an acceptance specification. Alloy data: {run.alloy_info['estimated_fraction']*100:.0f}% of property entries are ESTIMATED.</p></div>
</div>
<div class="slider"><div class="stage" id="stages"></div><input type="range" id="sl" min="0" max="{len(frames)-1}" value="0" step="1"><div class="mono" id="lab"></div>
<img style="margin-top:6px" src="data:image/png;base64,{tl}"></div>
<div class="cell" style="padding:14px 22px"><h2>QUALITY CRITERIA (no aggregate score)</h2><table><tr><th>criterion</th><th>value</th><th>review / high-risk</th><th>status</th><th>confidence | model</th><th>threshold source</th></tr>{crit_rows}</table></div>
<div class="cell" style="padding:14px 22px"><h2>TRACEABILITY</h2><div class="mono">{html.escape(json.dumps({k: man[k] for k in ('simulation_id','timestamp_utc','software_version','git_commit','material_database_version','material_hash','geometry_hash','mesh_hash','random_seed')}, indent=1))}</div></div>
<script>const F={fr_js};const ST={stage_js};const img=document.createElement('img');document.getElementById('frame').appendChild(img);
const sl=document.getElementById('sl'),lab=document.getElementById('lab'),stg=document.getElementById('stages');
ST.forEach((n,i)=>{{const d=document.createElement('div');d.textContent=n;d.onclick=()=>{{const k=F.findIndex(f=>f.stage===n);if(k>=0){{sl.value=k;show(k)}}}};stg.appendChild(d)}});
function show(k){{const f=F[k];img.src='data:image/png;base64,'+f.img;lab.textContent='process time '+f.t.toFixed(1)+' s   |   stage: '+f.stage;[...stg.children].forEach(d=>d.className=d.textContent===f.stage?'on':'')}}
sl.oninput=()=>show(+sl.value);show(0);</script></body></html>"""
    return h

def write_dashboard(run, path, n_frames=14):
    import pathlib
    pathlib.Path(path).write_text(build_html(run, n_frames), encoding="utf-8"); return str(path)
