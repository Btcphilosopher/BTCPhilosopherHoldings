"""Engineering report generation: HTML (self-contained), PDF (reportlab), JSON, CSV; HDF5 is the run store itself.
Sections: process parameters, material (with provenance), geometry, mesh, thermal history, solidification, microstructure, porosity,
stress, distortion, heat treatment, machining, simulated inspection, uncertainty, validation, conservation, quality criteria, traceability.
Honesty rules: model class and confidence appear next to every criterion; disagreements in validation are listed, not hidden; inspection
is labelled SIMULATED; nothing in the report claims certification."""
from __future__ import annotations
import csv, html, io, json, pathlib
import numpy as np
from ..digital_twin.run_data import RunData
from ..visualization import static as S
from ..validation_cases import analytic as V

DISCLAIMER = ("This report is produced by a reduced-order research digital twin. Model constants flagged ESTIMATED have not been calibrated to "
              "foundry data. Results are risk INDICATORS, are not validated against experiment unless stated, and do not constitute certification "
              "or acceptance of any casting.")

def _fig_set(run):
    q = run.query([0.03, 0.0, 0.03]); figs = {}
    figs["Thermal history (probe: boss region)"] = S.fig_png(S.thermal_history_figure(q), 110)
    figs["Solidification and feeding maps (mid-plane)"] = S.fig_png(S.solidification_map_figure(run), 100)
    figs["Porosity risk indicator (mid-plane)"] = S.fig_png(S.field_figure(run, "porosity_risk", "Porosity risk (indicator)", "magma", 1.0, "-", vmin=0, vmax=1), 100)
    figs["Alpha-lath thickness (EMPIRICAL, uncalibrated)"] = S.fig_png(S.field_figure(run, "lath_thickness_um", "alpha-lath [um]", "viridis", 1.0, "um"), 100)
    if "residual_vm_Pa" in run.f["fields"]:
        figs["Residual stress maps (mid-plane)"] = S.fig_png(S.stress_maps_figure(run), 95)
    if "stress" in run.f: figs["Nominal vs predicted as-cast geometry"] = S.fig_png(S.distortion_figure(run), 100)
    figs["Process timeline"] = S.fig_png(S.timeline_figure(run), 100)
    return figs

def _validation(run_dir=None, validation=None):
    if validation is not None: return validation
    p = pathlib.Path(run_dir or ".") / "validation_latest.json"
    if p.exists(): return [V.ValidationRow(**r) for r in json.loads(p.read_text())]
    return V.run_suite(quick=True)

def _sections(run: RunData, validation, uncertainty):
    R = run.results; sc = run.scenario
    sec = []
    sec.append(("Process parameters", {"scenario": sc["name"], "alloy": run.alloy_info["name"], "pour temperature [C]": sc["pour"]["pour_temperature_C"] or R["melt"]["pour_temperature_C"],
                "mold": sc["mold"], "melt": sc["melt"], "atmosphere": sc["atmosphere"], "heat treatment": sc["heat_treatment"]}))
    sec.append(("Material", {"name": run.alloy_info["name"], "hash": run.alloy_info["hash"], "liquidus [C]": run.alloy_info["T_liquidus_C"], "solidus [C]": run.alloy_info["T_solidus_C"],
                             "beta transus [C]": run.alloy_info["T_beta_C"], "fraction of property entries ESTIMATED": round(run.alloy_info["estimated_fraction"], 3),
                             "note": "see materials database for per-property provenance (literature-derived / estimated / calibrated / user-supplied)"}))
    sec.append(("Geometry and mesh", {"grid": R["geometry"]["grid"], "volumes [m^3]": R["geometry"]["volumes_m3"], "validation": R["geometry"]["validation"],
                                      "active cells": R["geometry"]["n_cells_total"], "metal cells": R["geometry"]["n_metal_cells"]}))
    sec.append(("Melt and atmosphere", {"melt": {k: v for k, v in R["melt"].items()}, "contamination (upper bound)": R["contamination"]}))
    sec.append(("Fill", {k: v for k, v in R["fill"].items() if k != "checks"} | {"checks": R["fill"].get("checks")}))
    sec.append(("Thermal history and solidification", R["solidification"]))
    sec.append(("Microstructure", R["microstructure"]))
    sec.append(("Feeding and shrinkage", {"feeding": R["feeding"], "shrinkage bookkeeping": R["shrinkage"]}))
    sec.append(("Porosity", R["porosity"]))
    sec.append(("Residual stress", R["stress"])); sec.append(("Distortion", R["distortion"]))
    sec.append(("Heat treatment", {k: v for k, v in R["heat_treatment"].items() if k != "profile"}))
    sec.append(("Machining allowance", R["machining"]))
    ins = R["inspection"]
    sec.append(("Inspection (SIMULATED, not real inspection data)", {"summary": ins["summary"], "indications": ins["indications"], "cmm": ins["cmm"]}))
    sec.append(("Uncertainty", uncertainty if uncertainty else "No Monte Carlo / DOE study attached to this run (run `tct monte-carlo`)."))
    sec.append(("Validation / verification (all rows shown, including disagreements)", [r.to_dict() for r in validation]))
    sec.append(("Conservation and numerical quality", R["conservation"]))
    sec.append(("Traceability", run.manifest))
    return sec

def _fmt(v, d=0):
    if isinstance(v, dict):
        return "<table>" + "".join(f"<tr><td class='k'>{html.escape(str(k))}</td><td>{_fmt(x, d+1)}</td></tr>" for k, x in v.items()) + "</table>"
    if isinstance(v, list):
        if v and isinstance(v[0], dict) and d < 2:
            keys = list(v[0].keys())[:10]
            return "<table><tr>" + "".join(f"<th>{html.escape(k)}</th>" for k in keys) + "</tr>" + "".join("<tr>" + "".join(f"<td>{_fmt(r.get(k), d+1)}</td>" for k in keys) + "</tr>" for r in v) + "</table>"
        return html.escape(json.dumps(v, default=str)[:300])
    if isinstance(v, float): return f"{v:.5g}"
    return html.escape(str(v))

CSS = """body{font:13px/1.45 'Helvetica Neue',Arial,sans-serif;color:#2b2f33;background:#f4f1ea;margin:0}header{background:#14233b;color:#f4f1ea;padding:16px 28px;border-bottom:3px solid #3e6a9e}
h1{margin:0;font-size:17px;letter-spacing:.12em}h2{font-size:12px;letter-spacing:.14em;color:#3e6a9e;border-bottom:1px solid #8a949c;padding-bottom:3px;margin-top:26px}
main{padding:6px 28px 40px;max-width:1100px}table{border-collapse:collapse;font-size:12px;margin:4px 0}td,th{border-bottom:1px solid #dcd8cf;padding:2px 8px;vertical-align:top;text-align:left}td.k{color:#5d666d;white-space:nowrap}
.PASS{color:#4f7a5a;font-weight:700}.REVIEW{color:#b8872e;font-weight:700}.HIGH-RISK,.DISAGREES{color:#a63d33;font-weight:700}.REPORTED{color:#8a949c;font-weight:700}
.disc{background:#e8e3d6;border-left:3px solid #b8872e;padding:8px 12px;margin:14px 0}img{max-width:100%}"""

def build_html(run: RunData, validation=None, uncertainty=None):
    val = _validation(None, validation); figs = _fig_set(run); man = run.manifest
    parts = [f"<!doctype html><html><head><meta charset='utf-8'><title>Report {html.escape(man['simulation_id'])}</title><style>{CSS}</style></head><body>",
             f"<header><h1>TITANIUM CASTING DIGITAL TWIN &mdash; ENGINEERING REPORT</h1><div>{html.escape(run.alloy_info['name'])} | {html.escape(man['simulation_id'])} | {html.escape(man['timestamp_utc'])}</div></header><main>",
             f"<div class='disc'>{html.escape(DISCLAIMER)}</div>"]
    rows = "".join(f"<tr><td>{html.escape(c['name'])}</td><td>{'n/a' if c['value'] is None else format(c['value'], '.4g')} {html.escape(c['unit'])}</td><td>{c['review_threshold']:.3g} / {c['high_risk_threshold']:.3g}</td><td class='{c['status']}'>{c['status']}</td><td>{html.escape(c['confidence'])}</td><td>{html.escape(c['model'])}</td><td>{html.escape(c['source'])}</td></tr>" for c in run.criteria)
    parts.append("<h2>QUALITY CRITERIA (no aggregate score)</h2><table><tr><th>criterion</th><th>value</th><th>review / high-risk</th><th>status</th><th>confidence</th><th>model</th><th>threshold source</th></tr>" + rows + "</table>")
    vrows = "".join(f"<tr><td>{html.escape(r.case)}</td><td>{html.escape(r.quantity)}</td><td>{r.prediction:.5g}</td><td>{r.reference:.5g}</td><td>{r.abs_error:.3g}</td><td>{r.rel_error:.3g}</td><td>{r.tolerance_rel:g}</td><td class='{'PASS' if r.passed else 'DISAGREES'}'>{'PASS' if r.passed else 'DISAGREES'}</td><td>{html.escape(r.kind)}</td></tr>" for r in val)
    for title, body in _sections(run, val, uncertainty):
        if title.startswith("Validation"):
            parts.append(f"<h2>{html.escape(title.upper())}</h2><table><tr><th>case</th><th>quantity</th><th>prediction</th><th>reference</th><th>abs error</th><th>rel error</th><th>tol</th><th>status</th><th>kind</th></tr>{vrows}</table>")
        else: parts.append(f"<h2>{html.escape(title.upper())}</h2>{_fmt(body)}")
    for t, png in figs.items(): parts.append(f"<h2>{html.escape(t.upper())}</h2><img src='data:image/png;base64,{S.b64(png)}'>")
    parts.append("</main></body></html>"); return "".join(parts), figs, val

def build_pdf(run: RunData, path, figs, val):
    from reportlab.lib.pagesizes import A4
    from reportlab.lib import colors
    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
    from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, Image, PageBreak
    from reportlab.lib.units import mm
    ss = getSampleStyleSheet(); small = ParagraphStyle("s", parent=ss["Normal"], fontSize=7.5, leading=9); h = ParagraphStyle("h", parent=ss["Heading2"], textColor=colors.HexColor("#3e6a9e"), fontSize=10)
    doc = SimpleDocTemplate(str(path), pagesize=A4, leftMargin=14 * mm, rightMargin=14 * mm, topMargin=14 * mm, bottomMargin=14 * mm,
                            title=f"Titanium Casting Digital Twin report {run.manifest['simulation_id']}")
    P = lambda t, st=small: Paragraph(html.escape(str(t)), st)
    el = [Paragraph("TITANIUM CASTING DIGITAL TWIN - ENGINEERING REPORT", ss["Title"]), P(f"{run.alloy_info['name']} | {run.manifest['simulation_id']} | {run.manifest['timestamp_utc']}"), Spacer(1, 6), P(DISCLAIMER), Spacer(1, 8)]
    data = [["criterion", "value", "review/high", "status", "conf.", "model"]] + [[P(c["name"]), P("n/a" if c["value"] is None else f"{c['value']:.4g} {c['unit']}"), P(f"{c['review_threshold']:.3g}/{c['high_risk_threshold']:.3g}"), P(c["status"]), P(c["confidence"]), P(c["model"])] for c in run.criteria]
    t = Table(data, colWidths=[48 * mm, 28 * mm, 22 * mm, 20 * mm, 14 * mm, 50 * mm]); t.setStyle(TableStyle([("GRID", (0, 0), (-1, -1), 0.25, colors.HexColor("#8a949c")), ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#14233b")), ("TEXTCOLOR", (0, 0), (-1, 0), colors.white), ("FONTSIZE", (0, 0), (-1, -1), 7)]))
    el += [Paragraph("Quality criteria (no aggregate score)", h), t, Spacer(1, 8)]
    for title, body in _sections(run, val, None):
        if title.startswith("Validation"):
            d = [["case", "quantity", "prediction", "reference", "rel err", "status"]] + [[P(r.case), P(r.quantity), P(f"{r.prediction:.4g}"), P(f"{r.reference:.4g}"), P(f"{r.rel_error:.3g}"), P("PASS" if r.passed else "DISAGREES")] for r in val]
            tt = Table(d, colWidths=[55 * mm, 45 * mm, 22 * mm, 22 * mm, 16 * mm, 20 * mm]); tt.setStyle(TableStyle([("GRID", (0, 0), (-1, -1), 0.25, colors.HexColor("#8a949c")), ("FONTSIZE", (0, 0), (-1, -1), 7)]))
            el += [Paragraph(title, h), tt]
        elif title.startswith("Inspection"):
            el += [Paragraph(title, h), P(json.dumps(body["summary"], default=str)[:900])]
        else:
            el += [Paragraph(title, h), P(json.dumps(body, default=str)[:1400])]
    for tt_, png in figs.items():
        im = Image(io.BytesIO(png)); w = 175 * mm; im.drawHeight = im.drawHeight * w / im.drawWidth; im.drawWidth = w
        el += [Paragraph(tt_, h), im]
    doc.build(el)

def export_csv(run: RunData, path):
    with open(path, "w", newline="") as f:
        w = csv.writer(f); w.writerow(["criterion", "value", "unit", "review_threshold", "high_risk_threshold", "status", "confidence", "model", "threshold_source"])
        for c in run.criteria: w.writerow([c["name"], c["value"], c["unit"], c["review_threshold"], c["high_risk_threshold"], c["status"], c["confidence"], c["model"], c["source"]])
        w.writerow([]); w.writerow(["field", "part_min", "part_mean", "part_max"])
        part = run.role == 1
        for n in run.field_names:
            a = run.field(n).astype(float)
            if a.shape != part.shape or not part.any(): continue
            v = a[part]; v = v[np.isfinite(v)]
            if v.size: w.writerow([n, f"{v.min():.6g}", f"{v.mean():.6g}", f"{v.max():.6g}"])

def generate(run_path, out_dir=None, validation=None, uncertainty=None, formats=("html", "pdf", "json", "csv")):
    run = RunData(run_path); out = pathlib.Path(out_dir or pathlib.Path(run_path).parent); out.mkdir(parents=True, exist_ok=True)
    if uncertainty is None:
        up = pathlib.Path(run_path).parent / "uncertainty.json"
        if up.exists(): uncertainty = json.loads(up.read_text())
    h, figs, val = build_html(run, validation, uncertainty); written = {}
    sid = run.manifest["simulation_id"]
    if "html" in formats: (out / f"{sid}_report.html").write_text(h, encoding="utf-8"); written["html"] = str(out / f"{sid}_report.html")
    if "pdf" in formats: build_pdf(run, out / f"{sid}_report.pdf", figs, val); written["pdf"] = str(out / f"{sid}_report.pdf")
    if "json" in formats:
        (out / f"{sid}_report.json").write_text(json.dumps({"disclaimer": DISCLAIMER, "manifest": run.manifest, "scenario": run.scenario, "results": run.results, "criteria": run.criteria, "validation": [r.to_dict() for r in val], "uncertainty": uncertainty}, indent=1, default=str)); written["json"] = str(out / f"{sid}_report.json")
    if "csv" in formats: export_csv(run, out / f"{sid}_criteria.csv"); written["csv"] = str(out / f"{sid}_criteria.csv")
    written["hdf5"] = str(run_path); run.close(); return written
