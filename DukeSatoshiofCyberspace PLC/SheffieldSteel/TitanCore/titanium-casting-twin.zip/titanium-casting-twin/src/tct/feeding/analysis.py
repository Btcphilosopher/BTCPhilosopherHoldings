"""Feeding analysis: isolated liquid pools, shrinkage demand, void allocation, feeding distance, riser effectiveness.
STATUS: REDUCED-ORDER topological model on the simulated solidification sequence (no pressure-driven Darcy flow solve).

Algorithm
  * A cell is `feedable` while it has not reached the feeding-limit solid fraction fs_c (default 0.7), i.e. t < t_feeding_limit.
  * At a sequence of times tau, connected components (6-connectivity) of feedable cells are labelled. A component is FED
    if it contains a feeder cell (riser / pour basin) that is itself still feedable; otherwise it is an ISOLATED pool.
  * The first time a cell belongs to an isolated pool is its isolation time. Liquid fraction remaining at isolation:
    (1 - fs(tau)), fs(tau) = linear in (t_liq, t_sol) of that cell (consistent with the enthalpy plateau).
  * Shrinkage demand of a newly isolated pool:  V_void = beta_s * sum_cells (1 - fs) * V_cell,  beta_s = (rho_s - rho_l)/rho_s
    from the alloy density table. It is allocated to the cells that freeze last (largest t_feeding_limit - tau), up to 100% of a cell.
  * feeding_risk(cell) = liquid fraction cut off at isolation (0 for always-fed cells): a physical quantity in [0,1].
Feeding distance: geodesic distance (m) through metal from the nearest feeder cell.
Riser effectiveness: modulus ratio, solidification-time ratio, and volume budget (liquid riser volume at the time the last fed
casting cell stops being feedable vs shrinkage demand of the fed casting).
"""
from __future__ import annotations
from dataclasses import dataclass
import numpy as np
from scipy import ndimage as ndi
from scipy.sparse import csr_matrix
from scipy.sparse.csgraph import dijkstra
from ..geometry.casting_system import PART, RISER, GATE, RUNNER, SPRUE, BASIN, FILTER

STRUCT6 = ndi.generate_binary_structure(3, 1)

@dataclass
class FeedingResult:
    fields: dict
    scalars: dict
    model: str = "REDUCED-ORDER topological isolation model"

def feeding_distance(cs, feeder, metal):
    g = cs.grid; cells = np.argwhere(metal); n = len(cells)
    lin = -np.ones(g.shape, np.int64); lin[tuple(cells.T)] = np.arange(n)
    rows, cols = [], []
    for ax in range(3):
        for s in (-1, 1):
            nb = cells.copy(); nb[:, ax] += s
            ok = (nb[:, ax] >= 0) & (nb[:, ax] < g.shape[ax]); j = np.full(n, -1); j[ok] = lin[tuple(nb[ok].T)]
            sel = j >= 0; rows.append(np.flatnonzero(sel)); cols.append(j[sel])
    r = np.concatenate(rows); c = np.concatenate(cols)
    G = csr_matrix((np.full(len(r), g.dx_m), (r, c)), shape=(n, n))
    src = np.flatnonzero(feeder[tuple(cells.T)])
    out = np.full(g.shape, np.nan)
    if src.size == 0: return out
    d = dijkstra(G, directed=False, indices=src, min_only=True)
    out[tuple(cells.T)] = np.where(np.isfinite(d), d, np.nan)
    return out

def analyse(cs, alloy, t_liq3, t_sol3, t_fc3, n_slices=160) -> FeedingResult:
    g = cs.grid; dx3 = g.cell_volume_m3
    metal = cs.metal; part = cs.mask(PART); feeder_cells = cs.feeder_mask()
    beta_s = alloy.volumetric_solidification_shrinkage()
    tfc = np.where(metal, np.nan_to_num(t_fc3, nan=0.0), 0.0)          # NaN (never reached) -> treat as 0 (already non-feedable) only if not metal
    finite_fc = np.isfinite(t_fc3) & metal
    tfc_eff = np.where(finite_fc, t_fc3, np.inf)                        # cells that never reach fs_c within the run stay feedable
    tl = np.where(np.isfinite(t_liq3), t_liq3, 0.0); ts = np.where(np.isfinite(t_sol3), t_sol3, np.nanmax(t_sol3[metal]) * 2 if np.isfinite(t_sol3[metal]).any() else 1.0)
    times = tfc_eff[metal & np.isfinite(tfc_eff)]
    iso_time = np.full(g.shape, np.nan); iso_liq = np.zeros(g.shape); void = np.zeros(g.shape)
    if times.size:
        taus = np.unique(np.quantile(times, np.linspace(0.0, 1.0, n_slices)))
        for tau in taus:
            feasible = metal & (tfc_eff > tau + 1e-9)
            lab, nl = ndi.label(feasible, structure=STRUCT6)
            if nl == 0: continue
            fed_labels = np.unique(lab[feasible & feeder_cells]); 
            isolated = feasible & ~np.isin(lab, fed_labels)
            new = isolated & np.isnan(iso_time)
            if not new.any(): continue
            iso_time[new] = tau
            fs_tau = np.clip((tau - tl) / np.maximum(ts - tl, 1e-9), 0, 1)
            iso_liq[new] = (1.0 - fs_tau)[new]
            lab_new, nn = ndi.label(new, structure=STRUCT6)
            for k in range(1, nn + 1):
                cellsk = lab_new == k
                demand = beta_s * float(((1.0 - fs_tau)[cellsk]).sum())      # in cell-volume units
                w = np.where(np.isfinite(t_fc3), t_fc3, tau * 1.5)[cellsk] - tau
                idx = np.argwhere(cellsk); order = np.argsort(-w, kind="stable")
                left = demand
                for o in order:
                    if left <= 1e-12: break
                    put = min(1.0, left); void[tuple(idx[o])] += put; left -= put
    void = np.clip(void, 0.0, 1.0)
    isolated_flag = np.isfinite(iso_time)
    fields = {"isolation_time_s": np.where(metal, iso_time, np.nan),
              "feeding_risk": np.where(metal, iso_liq * isolated_flag, np.nan),
              "macro_shrinkage_void_fraction": np.where(metal, void, np.nan),
              "isolated_hot_spot": (isolated_flag & metal).astype(np.int8)}
    fdist = feeding_distance(cs, feeder_cells, metal)
    fields["feeding_distance_m"] = fdist
    fmap = np.zeros(g.shape, np.int8)
    fmap[metal] = 1
    fmap[metal & isolated_flag] = 3
    fields["feeding_map"] = fmap                                  # 0 n/a, 1 fed, 3 isolated (2 reserved for marginal, set by porosity module)
    # scalars
    Vp = float(part.sum()) * dx3
    iso_part = isolated_flag & part
    scalars = {"beta_solidification_shrinkage": beta_s,
               "isolated_part_volume_fraction": float(iso_part.sum() / max(part.sum(), 1)),
               "macro_void_volume_part_m3": float(void[part].sum()) * dx3,
               "macro_void_fraction_part": float(void[part].sum() / max(part.sum(), 1)),
               "n_isolated_part_cells": int(iso_part.sum()),
               "max_feeding_distance_part_m": float(np.nanmax(fdist[part])) if np.isfinite(fdist[part]).any() else None}
    # riser effectiveness
    riser = cs.mask(RISER)
    if riser.any() and part.any():
        ts_r = np.nanmax(np.where(riser, t_sol3, np.nan)); ts_p = np.nanmax(np.where(part, t_sol3, np.nan))
        scalars["riser_to_part_solidification_time_ratio"] = float(ts_r / ts_p) if ts_p > 0 else None
        scalars["riser_modulus_m"] = cs.modulus_m(RISER); scalars["part_modulus_m"] = cs.modulus_m(PART)
        scalars["riser_to_part_modulus_ratio"] = scalars["riser_modulus_m"] / scalars["part_modulus_m"]
        fed_part = part & ~isolated_flag
        t_ref = np.nanmax(np.where(fed_part, t_fc3, np.nan)) if fed_part.any() else 0.0
        fs_r = np.clip((t_ref - np.where(np.isfinite(t_liq3), t_liq3, 0)) / np.maximum(ts - np.where(np.isfinite(t_liq3), t_liq3, 0), 1e-9), 0, 1)
        Vliq_riser = float(((1 - fs_r) * (riser & (tfc_eff > t_ref))).sum()) * dx3
        demand = beta_s * float(fed_part.sum()) * dx3
        scalars["riser_liquid_volume_at_feeding_end_m3"] = Vliq_riser
        scalars["fed_part_shrinkage_demand_m3"] = demand
        scalars["riser_volume_budget_ratio"] = Vliq_riser / demand if demand > 0 else None
        ratio = scalars["riser_volume_budget_ratio"]; tr = scalars["riser_to_part_solidification_time_ratio"]
        scalars["riser_effective"] = bool(ratio is not None and ratio >= 1.0 and tr is not None and tr >= 1.0)
        scalars["riser_effectiveness_note"] = "effective if volume-budget ratio >= 1 AND riser freezes after the part (REDUCED-ORDER indicator)"
    return FeedingResult(fields, scalars)
