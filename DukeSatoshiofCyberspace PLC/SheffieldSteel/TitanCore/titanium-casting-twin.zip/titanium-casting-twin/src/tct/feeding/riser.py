"""Riser-design module: indicators + iterative optimisation + gating sensitivity.  STATUS: REDUCED-ORDER.
Indicators (from a completed run): modulus ratio, solidification-time ratio, volume-budget ratio, isolated hot spots, feeding path length.
Optimisation: minimise  J = isolated_part_volume_fraction + lambda * V_riser / V_part  over riser diameter/height (coarse-grid full pipeline)."""
from __future__ import annotations
import numpy as np
from scipy.optimize import minimize
from ..simulation.config import Scenario, with_overrides
from ..uncertainty import forward as F

def indicators(results: dict):
    f = results["feeding"]
    return {k: f.get(k) for k in ("riser_to_part_modulus_ratio", "riser_to_part_solidification_time_ratio", "riser_volume_budget_ratio",
                                  "riser_effective", "isolated_part_volume_fraction", "n_isolated_part_cells", "max_feeding_distance_part_m",
                                  "macro_void_fraction_part")} | {"porosity_shrinkage_risk_mean": results["porosity"]["porosity_risk_mean_part"]}

def optimise_riser(scn: Scenario, bounds=None, lam=0.05, method="nelder-mead", max_evals=24, dx_mm=6.0, x0=None, progress=None):
    bounds = bounds or {"geometry.params.riser_d_mm": (28.0, 60.0), "geometry.params.riser_h_mm": (30.0, 70.0)}
    names = list(bounds); lo = np.array([bounds[n][0] for n in names]); hi = np.array([bounds[n][1] for n in names])
    x0 = np.array(x0 if x0 is not None else [0.5 * (a + b) for a, b in zip(lo, hi)], float)
    hist = []
    def J(x):
        x = np.clip(x, lo, hi)
        r = F.evaluate(scn, {n: float(v) for n, v in zip(names, x)}, ("isolated_volume_fraction",), dx_mm)
        from ..geometry.library import build_bracket
        d = dict(zip(names, x)); rd = d.get("geometry.params.riser_d_mm", 34.0); rh = d.get("geometry.params.riser_h_mm", 36.0)
        vr = np.pi * (rd / 2) ** 2 * rh * 1e-9
        j = r["isolated_volume_fraction"] + lam * vr / 1.2e-4
        hist.append({"x": {n: float(v) for n, v in zip(names, x)}, "isolated_volume_fraction": r["isolated_volume_fraction"], "riser_volume_m3": float(vr), "J": float(j)})
        if progress: progress(hist[-1])
        return j
    if method == "grid":
        g = [np.linspace(a, b, 4) for a, b in zip(lo, hi)]
        for p in np.array(np.meshgrid(*g)).reshape(len(names), -1).T: J(p)
    else:
        minimize(J, x0, method="Nelder-Mead", options={"maxfev": max_evals, "xatol": 0.5, "fatol": 1e-4, "initial_simplex": np.vstack([x0, x0 + [0.15 * (hi - lo)[0], 0], x0 + [0, 0.15 * (hi - lo)[1]]]) if len(names) == 2 else None})
    best = min(hist, key=lambda h: h["J"])
    return {"best": best, "history": hist, "lambda": lam, "note": "coarse-grid REDUCED-ORDER optimisation: re-verify the optimum on the production grid"}

def gating_sensitivity(scn: Scenario, sweeps: dict):
    """Fill-only sensitivity (cheap): sweeps {path: [values]} for geometry.params.* and pour.* ; returns rows of fill metrics."""
    from ..simulation.pipeline import _casting_system, apply_alloy_variation
    from ..materials.database import get_alloy
    from ..flow.fill import FillSolver, PourConfig
    from ..thermal import mold as mold_mod
    from ..melt.melt import MeltConfig, simulate_melt
    rows = []
    for path, vals in sweeps.items():
        for v in vals:
            s = with_overrides(scn, {path: float(v)}); cs = _casting_system(s); al = get_alloy(s.alloy)
            Tp = s.pour.pour_temperature_C or 1800.0
            pc = PourConfig(pour_temperature_C=Tp, pour_rate_kg_s=s.pour.pour_rate_kg_s, mold_temperature_C=s.mold.preheat_C, contact_h_W_m2K=s.pour.contact_h_W_m2K,
                            gravity_bias=s.pour.gravity_bias)
            pc.shell_effusivity = mold_mod.PRESETS[s.mold.kind]().effusivity(s.mold.preheat_C)
            r = FillSolver(cs, al, pc).run()
            rows.append({"parameter": path, "value": float(v), "fill_time_s": r.scalars["fill_time_s"], "v_gate_m_s": r.scalars["v_gate_m_s"],
                         "Q_peak_L_s": r.scalars["Q_peak_m3_s"] * 1e3, "gating_pressure_loss_Pa": r.scalars["gating_pressure_loss_Pa"], "K_total": r.scalars["K_total"],
                         "T_arrival_min_C": r.scalars["T_arrival_min_C"], "air_entrainment_index_max": r.scalars["air_entrainment_index_max"]})
    return rows
