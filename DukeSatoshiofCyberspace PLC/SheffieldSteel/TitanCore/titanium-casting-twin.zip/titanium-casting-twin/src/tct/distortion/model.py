"""Distortion from the thermo-mechanical displacement field.  STATUS: REDUCED-ORDER (inherits FE assumptions: no mold restraint).

Decomposition of the nodal displacement u over the casting nodes (Umeyama similarity fit  x' = s R x + t):
  * s - 1        uniform linear contraction (the predicted pattern shrink allowance)           -- not 'distortion'
  * R, t         rigid-body motion (weakly constrained by the solver)                          -- removed
  * residual     u_res = (x + u) - (s R x + t)  -> warpage components dx, dy, dz              -- the distortion
Angular distortion: local rotation vector from the displacement gradient, relative to the global fitted rotation [rad].
"""
from __future__ import annotations
from dataclasses import dataclass
import numpy as np

def umeyama(X, Y):
    mx, my = X.mean(0), Y.mean(0); Xc, Yc = X - mx, Y - my
    cov = Yc.T @ Xc / len(X); U, S, Vt = np.linalg.svd(cov)
    d = np.sign(np.linalg.det(U) * np.linalg.det(Vt)); Dm = np.diag([1, 1, d])
    R = U @ Dm @ Vt; var = (Xc ** 2).sum() / len(X)
    s = float(np.trace(np.diag(S) @ Dm) / var); t = my - s * R @ mx
    return s, R, t

@dataclass
class DistortionResult:
    scale: float
    linear_contraction: float
    rotation_deg: float
    node_residual: np.ndarray       # (nn,3) m
    fields: dict                    # 3D cell fields (m, rad)
    scalars: dict
    model: str = "REDUCED-ORDER"

def compute(sr, cs, part_mask3, role_part=1) -> DistortionResult:
    g = cs.grid
    part_cells = part_mask3[tuple(sr.cells.T)]
    node_ids = np.unique(sr.elem_nodes[part_cells].ravel())
    X = sr.node_xyz[node_ids]; Y = X + sr.node_u[node_ids]
    s, R, t = umeyama(X, Y)
    fit = (s * (R @ sr.node_xyz.T)).T + t
    res = (sr.node_xyz + sr.node_u) - fit
    ang = np.degrees(np.arccos(np.clip((np.trace(R) - 1) / 2, -1, 1)))
    # element fields
    rese = res[sr.elem_nodes].mean(axis=1)                      # (ne,3)
    W = 0.5 * (sr.grad_u_elem - sr.grad_u_elem.transpose(0, 2, 1))
    om = np.stack([W[:, 2, 1], W[:, 0, 2], W[:, 1, 0]], axis=1)      # rotation vector components
    skewR = 0.5 * (R - R.T); omg = np.array([skewR[2, 1], skewR[0, 2], skewR[1, 0]])
    rel = np.linalg.norm(om - omg, axis=1)
    def to3(a):
        out = np.full(g.shape, np.nan); out[tuple(sr.cells.T)] = a; return out
    fields = {"distortion_dx_m": to3(rese[:, 0]), "distortion_dy_m": to3(rese[:, 1]), "distortion_dz_m": to3(rese[:, 2]),
              "distortion_mag_m": to3(np.linalg.norm(rese, axis=1)), "local_rotation_rad": to3(rel),
              "total_displacement_mag_m": to3(np.linalg.norm(sr.node_u[sr.elem_nodes].mean(axis=1), axis=0 if False else 1))}
    pm = part_cells
    mag = np.linalg.norm(rese, axis=1)
    sc = {"linear_contraction": 1.0 - s, "scale_factor": s, "rigid_rotation_deg": float(ang),
          "max_warpage_m": float(mag[pm].max()), "mean_warpage_m": float(mag[pm].mean()),
          "max_abs_dx_m": float(np.abs(rese[pm, 0]).max()), "max_abs_dy_m": float(np.abs(rese[pm, 1]).max()),
          "max_abs_dz_m": float(np.abs(rese[pm, 2]).max()), "max_local_rotation_rad": float(rel[pm].max()),
          "max_local_rotation_deg": float(np.degrees(rel[pm].max()))}
    return DistortionResult(float(s), float(1.0 - s), float(ang), res, fields, sc)

def warped_nodes(sr, res, amplification=20.0):
    """Nominal + amplified residual displacement for the nominal-vs-predicted visual."""
    return sr.node_xyz + amplification * res
