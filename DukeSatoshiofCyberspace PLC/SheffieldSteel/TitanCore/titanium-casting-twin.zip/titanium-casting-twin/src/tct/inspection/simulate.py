"""Simulated inspection layer. EVERYTHING produced here is SIMULATED data derived from predicted defects/geometry -- never
real inspection results (`is_simulated` is always True and propagates to reports).

Defects: connected components of predicted void fraction above a display threshold; each has volume, equivalent diameter,
centroid, depth below the nearest surface and a mechanism label.
Probability of detection (POD): log-normal in the equivalent size,  POD(d) = Phi( ln(d/d50) / s ).
  method          d50 (ESTIMATED, user-overridable)                                       limits
  CT              2.0 x voxel size (default voxel = max_dim/1000)                         any depth
  X-ray (film/DR) 2 % of section thickness along the beam (sensitivity rule)              any depth, orientation dependent
  ultrasonic      lambda = v/f (v=6.1 km/s Ti, f=5 MHz => 1.2 mm), d50 = lambda/2          depth >= near-surface dead zone
  dye penetrant   0.5 mm opening, only SURFACE-BREAKING indications                       depth < 1 mm
  visual          1.0 mm, only surface-breaking
  CMM             not a flaw method: simulated surface deviation points from the distortion field + Gaussian noise sigma_cmm
Detection outcome: deterministic expected POD plus one seeded random draw (reproducible).
"""
from __future__ import annotations
from dataclasses import dataclass, field
import numpy as np
from scipy import ndimage as ndi
from scipy.stats import norm
from ..geometry.casting_system import PART

@dataclass
class InspectionConfig:
    void_threshold: float = 1e-3
    methods: tuple = ("ct", "xray", "ultrasonic", "dye_penetrant", "visual")
    ct_voxel_m: float | None = None
    us_frequency_Hz: float = 5e6
    us_velocity_m_s: float = 6100.0
    us_dead_zone_m: float = 1.5e-3
    sigma_ln: float = 0.5
    cmm_sigma_m: float = 5e-6
    seed: int = 0
    surface_depth_m: float = 1.0e-3

def extract_indications(cs, void3, micro3, macro3, gas3, threshold):
    g = cs.grid; part = cs.mask(PART)
    v = np.where(part, np.nan_to_num(void3, nan=0.0), 0.0)
    lab, n = ndi.label(v > threshold, structure=ndi.generate_binary_structure(3, 2))
    edt = ndi.distance_transform_edt(part) * g.dx_m
    out = []
    for k in range(1, n + 1):
        sel = lab == k; vol = float(v[sel].sum()) * g.cell_volume_m3
        idx = np.argwhere(sel); c = g.origin_m + (idx.mean(0) + 0.5) * g.dx_m
        comp = {"shrinkage_macro": float(np.nansum(np.where(sel, macro3, 0))), "shrinkage_micro": float(np.nansum(np.where(sel, micro3, 0))),
                "gas": float(np.nansum(np.where(sel, gas3, 0)))}
        mech = max(comp, key=comp.get)
        sec = float(2 * edt[sel].max())
        out.append({"id": k, "volume_m3": vol, "d_eq_m": float((6 * vol / np.pi) ** (1 / 3)), "centroid_m": [float(x) for x in c],
                    "depth_m": float(edt[sel].min()), "section_thickness_m": max(sec, g.dx_m), "mechanism": mech, "n_cells": int(sel.sum())})
    return out

def simulate(cs, void3, micro3, macro3, gas3, cfg: InspectionConfig | None = None, distortion_mag3=None):
    cfg = cfg or InspectionConfig(); rng = np.random.default_rng(cfg.seed)
    ind = extract_indications(cs, void3, micro3, macro3, gas3, cfg.void_threshold)
    bb = cs.grid
    part_idx = np.argwhere(cs.mask(PART)); dims = (part_idx.max(0) - part_idx.min(0) + 1) * bb.dx_m
    voxel = cfg.ct_voxel_m or float(dims.max()) / 1000.0
    lam = cfg.us_velocity_m_s / cfg.us_frequency_Hz
    d50 = {"ct": 2.0 * voxel, "ultrasonic": lam / 2.0, "dye_penetrant": 0.5e-3, "visual": 1.0e-3}
    results = []
    for i in ind:
        row = dict(i); row["simulated"] = True
        for m in cfg.methods:
            if m == "xray": d = 0.02 * i["section_thickness_m"]
            else: d = d50[m]
            pod = float(norm.cdf(np.log(max(i["d_eq_m"], 1e-9) / d) / cfg.sigma_ln))
            if m in ("dye_penetrant", "visual") and i["depth_m"] > cfg.surface_depth_m: pod = 0.0
            if m == "ultrasonic" and i["depth_m"] < cfg.us_dead_zone_m: pod *= 0.2
            row[f"pod_{m}"] = pod; row[f"detected_{m}"] = bool(rng.random() < pod); row[f"detected_expected_{m}"] = pod >= 0.5
        results.append(row)
    cmm = None
    if distortion_mag3 is not None:
        part = cs.mask(PART)
        surf = part & ~ndi.binary_erosion(part)
        dev = np.nan_to_num(distortion_mag3, nan=0.0)[surf]
        cmm = {"n_points": int(surf.sum()), "mean_deviation_m": float(dev.mean()), "max_deviation_m": float(dev.max()),
               "measured_max_deviation_m": float((dev + rng.normal(0, cfg.cmm_sigma_m, dev.shape)).max()), "sigma_m": cfg.cmm_sigma_m}
    summary = {"is_simulated": True, "label": "SIMULATED inspection derived from predicted defects; not real inspection data",
               "n_indications": len(results), "ct_voxel_m": voxel, "ultrasonic_wavelength_m": lam,
               "largest_indication_d_eq_m": max([r["d_eq_m"] for r in results], default=0.0),
               "detected_by": {m: int(sum(r[f"detected_{m}"] for r in results)) for m in cfg.methods}}
    return {"indications": results, "summary": summary, "cmm": cmm}
