"""First-order Ti-6Al-4V microstructure indicators.  Each output carries an explicit model class:

  alpha_fraction            REDUCED-ORDER kinetic: df/dt = (f_eq(T) - f)/tau(T) integrated in the thermal solver (constants ESTIMATED)
  lath_thickness_um         EMPIRICAL power law in cooling rate through 1000->800 C (UNCALIBRATED: calibrate to metallography)
  morphology_class          EMPIRICAL regime map from cooling rate (Ahmed & Rack 1998 thresholds, literature-derived):
                              CR > 410 K/s martensitic alpha';  20-410 basketweave/massive;  1-20 Widmanstatten;  <1 colony/GB alpha
  prior_beta_indicator      QUALITATIVE: time above the beta transus (s) normalised -- NOT a grain-size prediction
  columnar_tendency         QUALITATIVE: G/R [K s/mm^2], higher => columnar prior-beta tendency
  yield_estimate_MPa        EMPIRICAL Hall-Petch on lath thickness (UNCALIBRATED, indicator only)
No metallographic prediction precision is claimed beyond these labels.
"""
from __future__ import annotations
import numpy as np
from ..materials import kinetics

MORPH = {0: "n/a", 1: "colony alpha", 2: "Widmanstatten", 3: "basketweave/massive", 4: "martensitic alpha'", 5: "equiaxed alpha + transformed beta"}

def classify_morphology(cr):
    cr = np.asarray(cr, float)
    out = np.full(cr.shape, 0, np.int8)
    ok = np.isfinite(cr)
    out[ok & (cr < kinetics.CR_COLONY_K_S.value)] = 1
    out[ok & (cr >= kinetics.CR_COLONY_K_S.value) & (cr < kinetics.CR_MASSIVE_K_S.value)] = 2
    out[ok & (cr >= kinetics.CR_MASSIVE_K_S.value) & (cr < kinetics.CR_MARTENSITE_K_S.value)] = 3
    out[ok & (cr >= kinetics.CR_MARTENSITE_K_S.value)] = 4
    return out

def compute(solver, sol_fields: dict, cs):
    metal = cs.metal
    cr = sol_fields["cooling_rate_beta_K_s"]
    lath = kinetics.lath_thickness_um(cr)
    lath = np.where(np.isfinite(cr), lath, np.nan)
    morph = classify_morphology(cr)
    morph = np.where(metal, morph, 0).astype(np.int8)
    f_alpha = solver.to_field(np.where(solver.is_metal, solver.f_alpha, np.nan))
    tab = sol_fields["time_above_beta_s"]
    pb = tab / max(float(np.nanmax(tab)), 1e-9)
    G = sol_fields["thermal_gradient_K_m"] / 1000.0; R = sol_fields["front_velocity_m_s"] * 1000.0
    with np.errstate(invalid="ignore", divide="ignore"):
        ct = G / R                                       # K s / mm^2
    yld = kinetics.yield_from_lath_MPa(lath)
    fields = {"alpha_fraction": f_alpha, "lath_thickness_um": lath, "morphology_class": morph,
              "prior_beta_indicator": pb, "columnar_tendency_Ks_mm2": ct, "yield_estimate_MPa": yld}
    part = cs.mask(1)
    sc = {"model_status": {"alpha_fraction": "REDUCED-ORDER kinetic (ESTIMATED constants)", "lath_thickness_um": "EMPIRICAL (uncalibrated)",
                           "morphology_class": "EMPIRICAL regime map (literature thresholds)", "prior_beta_indicator": "QUALITATIVE",
                           "columnar_tendency": "QUALITATIVE", "yield_estimate_MPa": "EMPIRICAL (uncalibrated indicator)"},
          "lath_thickness_um_mean_part": float(np.nanmean(lath[part])) if np.isfinite(lath[part]).any() else None,
          "lath_thickness_um_range_part": [float(np.nanmin(lath[part])), float(np.nanmax(lath[part]))] if np.isfinite(lath[part]).any() else None,
          "alpha_fraction_mean_part": float(np.nanmean(f_alpha[part])),
          "morphology_fractions_part": {MORPH[k]: float((morph[part] == k).mean()) for k in range(1, 5)}}
    return fields, sc
