"""Units and constants.

Convention (enforced by naming): SI throughout the solvers.
  lengths  m   (suffix _m)     temperatures  deg C at API boundaries (suffix _C),
  times    s   (suffix _s)     Kelvin only inside radiation / Arrhenius terms (suffix _K)
  pressure Pa  (suffix _Pa)    stress Pa (suffix _Pa); MPa only in user-facing config (suffix _MPa)
  mass     kg  (suffix _kg)
Conversion happens ONLY via the helpers below, at explicit boundaries (config parsing, reporting).
"""
from __future__ import annotations
import numpy as np

SIGMA_SB = 5.670374419e-8      # W m^-2 K^-4
G_ACC = 9.80665                # m s^-2
R_GAS = 8.314462618            # J mol^-1 K^-1
K_BOLTZ = 1.380649e-23         # J K^-1
N_AVOGADRO = 6.02214076e23     # mol^-1
KELVIN_OFFSET = 273.15
ATM_Pa = 101325.0

def c2k(T_C):  return np.asarray(T_C, dtype=float) + KELVIN_OFFSET
def k2c(T_K):  return np.asarray(T_K, dtype=float) - KELVIN_OFFSET
def mm2m(x):   return np.asarray(x, dtype=float) * 1e-3
def m2mm(x):   return np.asarray(x, dtype=float) * 1e3
def MPa2Pa(x): return np.asarray(x, dtype=float) * 1e6
def Pa2MPa(x): return np.asarray(x, dtype=float) * 1e-6
def mbar2Pa(x): return np.asarray(x, dtype=float) * 100.0
