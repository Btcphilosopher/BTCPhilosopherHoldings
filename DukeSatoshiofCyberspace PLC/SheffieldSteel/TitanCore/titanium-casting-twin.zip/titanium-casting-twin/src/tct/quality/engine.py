"""Transparent quality engine: individual criteria, each exposing value, unit, thresholds, source, confidence, model.
There is deliberately NO aggregate 'quality score'. Status mapping per criterion:  value <= review -> PASS;
review < value <= high_risk -> REVIEW; > high_risk -> HIGH-RISK.  Default thresholds are SCREENING defaults (not an acceptance
specification) and are overridable per scenario; `source` says where each default comes from.
"""
from __future__ import annotations
from dataclasses import dataclass, asdict
import numpy as np

@dataclass
class Criterion:
    name: str
    value: float | None
    unit: str
    review_threshold: float
    high_risk_threshold: float
    source: str
    confidence: str
    model: str
    note: str = ""
    higher_is_better: bool = False
    informational: bool = False
    @property
    def status(self):
        if self.value is None or not np.isfinite(self.value): return "NOT-EVALUATED"
        if self.informational: return "REPORTED"
        if self.higher_is_better:
            if self.value >= self.review_threshold: return "PASS"
            if self.value >= self.high_risk_threshold: return "REVIEW"
            return "HIGH-RISK"
        if self.value <= self.review_threshold: return "PASS"
        if self.value <= self.high_risk_threshold: return "REVIEW"
        return "HIGH-RISK"
    def to_dict(self): d = asdict(self); d["status"] = self.status; return d

DEFAULT = {  # name: (review, high_risk, source)
    "fill_integrity_misrun_fraction": (0.0, 0.005, "default screening: any misrun volume => REVIEW"),
    "fill_integrity_cold_shut_max": (0.2, 0.6, "default screening on cold-shut indicator"),
    "air_entrainment_index_max": (0.5, 2.0, "default screening: v/v_crit - 1 (Campbell-type scaling)"),
    "feeding_isolated_volume_fraction": (0.0, 0.03, "default screening: any isolated pool in the part => REVIEW"),
    "thermal_gradient_niyama_min": (None, None, ""),
    "cooling_rate_beta_min": (None, None, ""),
    "porosity_indicator_max": (0.3, 0.7, "default screening on combined porosity risk (indicator, not probability)"),
    "predicted_void_fraction_mean": (0.002, 0.01, "default screening on volume-mean predicted void fraction"),
    "microstructure_martensite_fraction": (0.0, 0.2, "default screening: alpha' regions flag need for heat treatment"),
    "residual_stress_vm_over_yield": (0.5, 0.9, "default screening: peak von Mises / RT yield"),
    "distortion_max_warpage_mm": (0.5, 1.5, "default screening; replace with drawing tolerance"),
    "machining_min_margin_mm": (0.0, -0.5, "larger is better: margin >= 0 mm PASS, >= -0.5 mm REVIEW (default screening)"),
    "inspection_largest_indication_mm": (1.0, 3.0, "default screening; replace with NDE acceptance class"),
    "contamination_risk_index": (0.5, 1.0, "ratio of upper-bound gas pick-up to spec limit"),
}

def evaluate(res: dict, overrides: dict | None = None):
    ov = overrides or {}
    def thr(name):
        r, h, s = DEFAULT[name]; r2, h2 = ov.get(name, (r, h)); return r2, h2, (s if name not in ov else "user-supplied")
    C = []
    def add(name, value, unit, conf, model, note="", invert=False):
        r, h, s = thr(name)
        if invert and value is not None:       # criterion where larger is better: convert to deficit
            value = -value
        C.append(Criterion(name, None if value is None else float(value), unit, r, h, s, conf, model, note))
    f = res["fill"]
    add("fill_integrity_misrun_fraction", f["misrun_part_volume_fraction"], "-", "LOW", "REDUCED-ORDER fill (lumped thermal)")
    add("fill_integrity_cold_shut_max", f["cold_shut_max_part"], "-", "LOW", "EMPIRICAL indicator")
    add("air_entrainment_index_max", f["air_entrainment_index_part_max"], "-", "LOW", "literature scaling (Campbell)")
    add("feeding_isolated_volume_fraction", res["feeding"]["isolated_part_volume_fraction"], "-", "MODERATE", "REDUCED-ORDER topological isolation")
    s = res["solidification"]
    C.append(Criterion("thermal_gradient_niyama_min", s.get("niyama_min_part"), "(K s)^0.5/mm", 0.0, 0.0, "reported, no default threshold (alloy/process specific)", "LOW", "REDUCED-ORDER thermal solution", informational=True))
    C.append(Criterion("cooling_rate_beta_min", s.get("cooling_rate_beta_min_part"), "K/s", 0.0, 0.0, "reported, no default threshold", "MODERATE", "REDUCED-ORDER thermal solution", informational=True))
    p = res["porosity"]
    add("porosity_indicator_max", p["porosity_risk_max_part"], "-", "LOW", "EMPIRICAL (Niyama ESTIMATED) + REDUCED-ORDER")
    add("predicted_void_fraction_mean", p["void_fraction_mean_part"], "-", "LOW", "EMPIRICAL / REDUCED-ORDER")
    add("microstructure_martensite_fraction", res["microstructure"]["morphology_fractions_part"].get("martensitic alpha'", 0.0), "-", "LOW", "EMPIRICAL regime map")
    st = res["stress"]
    add("residual_stress_vm_over_yield", st["vm_max_over_yield_RT"], "-", "LOW", "REDUCED-ORDER FE (no mold restraint)")
    d = res["distortion"]
    add("distortion_max_warpage_mm", d["max_warpage_m"] * 1e3, "mm", "LOW", "REDUCED-ORDER FE")
    m = res["machining"]; r_, h_, s_ = thr("machining_min_margin_mm")
    C.append(Criterion("machining_min_margin_mm", None if m["min_margin_m"] is None else m["min_margin_m"] * 1e3, "mm", r_, h_, s_, "LOW",
                       "alpha-case (ESTIMATED upper bound) + distortion vs allowance", "", higher_is_better=True))
    i = res["inspection"]["summary"]
    add("inspection_largest_indication_mm", i["largest_indication_d_eq_m"] * 1e3, "mm", "LOW", "SIMULATED inspection (not real data)")
    add("contamination_risk_index", res["contamination"]["contamination_risk_index"], "-", "LOW", "upper-bound impingement model")
    return C
