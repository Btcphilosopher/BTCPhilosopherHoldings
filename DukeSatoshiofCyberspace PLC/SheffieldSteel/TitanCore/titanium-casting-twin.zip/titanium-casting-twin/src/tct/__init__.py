"""titanium-casting-twin (tct): physics-first digital twin for Ti alloy castings."""
__version__ = "0.1.0"
