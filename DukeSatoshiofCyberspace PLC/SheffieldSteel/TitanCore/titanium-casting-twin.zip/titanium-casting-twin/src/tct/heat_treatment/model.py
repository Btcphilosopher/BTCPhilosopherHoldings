"""Heat-treatment simulation: ramp / hold / cool / age (+ optional HIP).  STATUS: EMPIRICAL / ESTIMATED kinetics (calibrate!).

The furnace cycle is applied uniformly (part thermal lag is neglected: valid for slow ramps / thin sections).
  Stress relaxation (Zener-Wert-Avrami):   sigma/sigma0 = exp( -X^n ),   X = integral k(T) dt,  k = K0 exp(-Q/RT)
  Alpha-lath coarsening (LSW-type):         d^3 = d0^3 + integral K0 exp(-Q/RT) dt            (T below beta transus)
  Beta-field excursion (T_hold > T_beta):   microstructure resets; new lath thickness from the cooling rate of the following cool segment
  Phase fraction:                           df/dt = (f_eq(T) - f)/tau(T) integrated along the whole cycle (vectorised over cells)
  Cooling-induced residual stress (EMPIRICAL estimate): sigma_q = E alpha/(1-nu) * CR * D^2/(8 kappa)  added in quadrature
  HIP closure of internal voids:            d ln V / dt = -(3/2) A exp(-Q/RT) P^n   (Norton creep, ESTIMATED);
                                            surface-connected voids (within `open_depth_m` of the mold interface) are NOT closed.
  Yield indicator: Hall-Petch on lath thickness (EMPIRICAL, uncalibrated).
"""
from __future__ import annotations
from dataclasses import dataclass, field
import numpy as np
from ..errors import ConfigurationError
from ..units import R_GAS, c2k
from ..materials import kinetics

@dataclass
class Segment:
    kind: str                                 # ramp | hold | cool | age
    T_end_C: float | None = None              # ramp/cool/age: target; hold: ignored (uses previous T)
    duration_s: float | None = None
    rate_C_per_s: float | None = None         # alternative to duration for ramp/cool
    def validate(self):
        if self.kind not in ("ramp", "hold", "cool", "age"): raise ConfigurationError(f"unknown HT segment {self.kind!r}")
        if self.kind == "hold" and not self.duration_s: raise ConfigurationError("hold needs duration_s")
        if self.kind in ("ramp", "cool") and self.T_end_C is None: raise ConfigurationError(f"{self.kind} needs T_end_C")

@dataclass
class HeatTreatment:
    segments: list
    start_C: float = 20.0
    hip_pressure_MPa: float | None = None
    open_depth_m: float = 2e-3
    def profile(self, dt=5.0):
        """-> (t[s], T[C], seg_index) piecewise-linear furnace profile sampled at <= dt."""
        t = [0.0]; T = [self.start_C]; seg = [0]; cur = self.start_C
        for i, s in enumerate(self.segments):
            s.validate()
            if s.kind == "hold": tgt, dur = cur, s.duration_s
            else:
                tgt = s.T_end_C
                dur = s.duration_s if s.duration_s else abs(tgt - cur) / max(s.rate_C_per_s or 0.1, 1e-6)
            n = max(int(np.ceil(dur / dt)), 1)
            for k in range(1, n + 1):
                t.append(t[-1] + dur / n); T.append(cur + (tgt - cur) * k / n); seg.append(i)
            cur = tgt
        return np.array(t), np.array(T), np.array(seg)

def cycle_hip(T_hold_C=920.0, hold_s=7200.0, P_MPa=100.0):
    return HeatTreatment([Segment("ramp", T_hold_C, rate_C_per_s=0.2), Segment("hold", duration_s=hold_s), Segment("cool", 100.0, rate_C_per_s=0.1)],
                         hip_pressure_MPa=P_MPa)

def cycle_stress_relief(T_C=650.0, hold_s=7200.0):
    return HeatTreatment([Segment("ramp", T_C, rate_C_per_s=0.2), Segment("hold", duration_s=hold_s), Segment("cool", 100.0, rate_C_per_s=0.05)])

def cycle_beta_anneal():
    return HeatTreatment([Segment("ramp", 1020.0, rate_C_per_s=0.3), Segment("hold", duration_s=3600.0), Segment("cool", 600.0, rate_C_per_s=1.0),
                          Segment("cool", 100.0, rate_C_per_s=0.2)])

def apply(ht: HeatTreatment, alloy, cs, fields: dict, sigma_final_Pa=None, void_fraction=None, thickness_m=None, dist_to_surface_m=None):
    """fields: dict with 'lath_thickness_um','alpha_fraction' (3D, NaN outside metal). Returns (new_fields, scalars)."""
    t, T, seg = ht.profile()
    dt = np.diff(t); Tm = 0.5 * (T[1:] + T[:-1])
    Tk = c2k(Tm)
    # stress relaxation
    k = kinetics.RELAX_K0.value * np.exp(-kinetics.RELAX_Q.value / (R_GAS * Tk))
    X = float(np.sum(k * dt)); relax = float(np.exp(-X ** kinetics.RELAX_N.value))
    # coarsening / beta excursion
    d0 = fields["lath_thickness_um"].copy(); metal = cs.metal
    kc = kinetics.COARSEN_K0.value * np.exp(-kinetics.COARSEN_Q.value / (R_GAS * Tk))
    above_beta = Tm > alloy.T_beta_C
    d3_add = float(np.sum((kc * dt)[~above_beta]))
    beta_excursion = bool(above_beta.any())
    d = np.cbrt(np.nan_to_num(d0, nan=0.0) ** 3 + d3_add)
    cr_after = np.nan
    if beta_excursion:
        last_hot = np.where(above_beta)[0].max()
        # cooling rate through 1000-800 C after the excursion
        sub_t, sub_T = t[last_hot + 1:], T[last_hot + 1:]
        mask = (sub_T <= 1000.0) & (sub_T >= 800.0)
        if mask.sum() >= 2: cr_after = float((sub_T[mask][0] - sub_T[mask][-1]) / (sub_t[mask][-1] - sub_t[mask][0]))
        else: cr_after = float(abs(np.diff(T)).max() / max(np.diff(t).min(), 1e-9))
        d = np.where(np.isfinite(d0), kinetics.lath_thickness_um(cr_after) * np.ones_like(d0), np.nan)
    d = np.where(metal & np.isfinite(d0), d, np.nan)
    # phase fraction
    pm = alloy.phase_model()
    f = np.nan_to_num(fields["alpha_fraction"], nan=0.0).copy()
    tt = np.arange(0.0, t[-1], 10.0)
    Ti = np.interp(tt + 5.0, t, T)
    tau = np.maximum(kinetics.alpha_tau_s(Ti), 1e-3); fe = pm.f_alpha_eq(Ti)
    for i in range(len(tt)):
        f = f + (fe[i] - f) * (1.0 - np.exp(-10.0 / tau[i]))
    f = np.where(metal & np.isfinite(fields["alpha_fraction"]), f, np.nan)
    out = {"lath_thickness_um_ht": d, "alpha_fraction_ht": f, "yield_estimate_MPa_ht": kinetics.yield_from_lath_MPa(d)}
    sc = {"relaxation_factor": relax, "relaxation_integral_X": X, "beta_excursion": beta_excursion,
          "cooling_rate_after_beta_K_s": None if not np.isfinite(cr_after) else cr_after,
          "total_time_s": float(t[-1]), "max_T_C": float(T.max()),
          "model_status": "EMPIRICAL / ESTIMATED kinetics (uncalibrated)"}
    # cooling-induced stress estimate (largest cooling rate in the cycle)
    crmax = float(np.max(-np.diff(T) / np.maximum(np.diff(t), 1e-9)).clip(0)) if len(T) > 1 else 0.0
    Eroom = float(alloy.tables["elastic_modulus"](Tm.min() if len(Tm) else 20.0)); al_ = float(alloy.tables["thermal_expansion"](500.0))
    kappa = float(alloy.tables["thermal_conductivity"](500.0)) / (float(alloy.density_kg_m3(500.0)) * float(alloy.tables["specific_heat"](500.0)))
    if thickness_m is not None:
        sig_q = Eroom * al_ / (1 - 0.34) * crmax * (thickness_m ** 2) / (8 * kappa)
        out["quench_stress_estimate_Pa"] = np.where(metal, sig_q, np.nan)
    if sigma_final_Pa is not None:
        sig_rel = sigma_final_Pa * relax
        from ..stress.fe import von_mises
        vm = von_mises(sig_rel)
        out["_sigma_relaxed"] = sig_rel; out["_vm_relaxed"] = vm
        sc["residual_vm_after_ht_max_MPa"] = float(vm.max() / 1e6)
    # HIP
    if ht.hip_pressure_MPa and void_fraction is not None:
        Th = c2k(Tm); P = ht.hip_pressure_MPa
        rate = 1.5 * kinetics.HIP_A.value * np.exp(-kinetics.HIP_Q.value / (R_GAS * Th)) * P ** kinetics.HIP_N.value
        # only the segments at which pressure is applied: treat the whole cycle at pressure (user HIP cycles are hold-dominated)
        Xh = float(np.sum(rate * dt)); close = float(np.exp(-Xh))
        vf = void_fraction.copy()
        open_mask = np.zeros_like(metal)
        if dist_to_surface_m is not None:
            # distances are cell-centre based: the surface layer sits one cell (dx) from the outside, so add dx to resolve open_depth on coarse grids
            open_mask = dist_to_surface_m <= ht.open_depth_m + cs.grid.dx_m * 1.01
        vf_after = np.where(open_mask, vf, vf * close)
        out["predicted_void_fraction_ht"] = vf_after
        sc.update({"hip_pressure_MPa": P, "hip_closure_integral": Xh, "hip_void_volume_ratio": close,
                   "hip_note": "internal voids scaled by exp(-X); surface-connected voids unchanged (ESTIMATED creep constants)"})
    return out, sc

