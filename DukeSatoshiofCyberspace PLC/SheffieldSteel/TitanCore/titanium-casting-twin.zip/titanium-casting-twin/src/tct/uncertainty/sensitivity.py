"""Process sensitivity from the model (never hard-coded): central finite differences of the full pipeline on a coarse grid.
Output: for each parameter, delta applied and the calculated change of every response (absolute and percent)."""
from __future__ import annotations
from dataclasses import dataclass
import numpy as np
from ..simulation.config import Scenario, get_path
from . import forward as F

DEFAULT_STEPS = {  # path: (absolute step, unit)
    "pour.pour_temperature_C": (12.0, "C"), "mold.preheat_C": (50.0, "C"), "pour.pour_rate_kg_s": (0.1, "kg/s"),
    "geometry.params.gate_h_mm": (2.0, "mm"), "geometry.params.riser_d_mm": (4.0, "mm"), "geometry.params.riser_h_mm": (6.0, "mm"),
    "thermal.surroundings_C": (50.0, "C"), "atmosphere.vacuum_pressure_Pa": (1.0, "Pa"), "mesh.shell_thickness_mm": (2.0, "mm"),
    "alloy_composition_shift_wt.Al": (0.2, "wt%"), "alloy_composition_shift_wt.V": (0.2, "wt%"),
}

def base_value(scn, path):
    v = get_path(scn, path)
    if v is not None: return float(v)
    if path == "pour.pour_temperature_C": return None
    if path.startswith("geometry.params."):
        from ..geometry.library import bracket_solids
        import inspect
        d = inspect.signature(bracket_solids).parameters[path.split(".")[-1]].default; return float(d)
    if path.startswith("alloy_composition_shift_wt."): return 0.0
    raise KeyError(path)

def one_at_a_time(scn: Scenario, steps: dict | None = None, responses=F.DEFAULT_RESPONSES, dx_mm=None, progress=None):
    steps = steps or {k: v for k, v in DEFAULT_STEPS.items()}
    base_T = None
    base = F.evaluate(scn, {}, responses, dx_mm)
    rows = []
    for path, (step, unit) in steps.items():
        b = base_value(scn, path)
        if b is None:        # parameter defaults to a model-derived value (e.g. pour temperature from the melt model)
            b = F.evaluate(scn, {}, ("pour_temperature_C",), dx_mm)["pour_temperature_C"]
        hi = F.evaluate(scn, {path: b + step}, responses, dx_mm); lo = F.evaluate(scn, {path: b - step}, responses, dx_mm)
        eff = {}
        for r in responses:
            d = 0.5 * (hi[r] - lo[r])
            eff[r] = {"change": d, "percent": 100.0 * d / base[r] if base[r] not in (0.0,) and np.isfinite(base[r]) else float("nan"),
                      "slope": (hi[r] - lo[r]) / (2 * step)}
        rows.append({"parameter": path, "unit": unit, "step": step, "base": b, "effects": eff})
        if progress: progress(path)
    return {"base": base, "rows": rows, "method": "central finite difference of the full pipeline (coarse grid)", "dx_mm": dx_mm}

def format_table(res, responses=None):
    responses = responses or list(res["base"].keys())
    out = [f"{'Parameter':44s} {'step':>8s} " + " ".join(f"{r[:18]:>18s}" for r in responses)]
    for row in res["rows"]:
        cells = []
        for r in responses:
            e = row["effects"][r]; cells.append(f"{e['change']:+9.3g} ({e['percent']:+5.1f}%)")
        out.append(f"{row['parameter']:44s} {row['step']:>6g}{row['unit'][:2]:>2s} " + " ".join(f"{c:>18s}" for c in cells))
    return "\n".join(out)
