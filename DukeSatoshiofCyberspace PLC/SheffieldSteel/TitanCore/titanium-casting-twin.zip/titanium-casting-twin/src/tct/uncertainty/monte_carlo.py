"""Monte Carlo process variation. Modes:
  direct    : N full-pipeline evaluations on the coarse grid (feasible for N <= ~100-300 on a single core)
  surrogate : fit a quadratic response surface on a Latin-hypercube training set (n_train direct runs), then evaluate N (1e3..1e4+)
              samples on the surrogate. The surrogate R^2 / leave-one-out R^2 are REPORTED and the output is labelled SURROGATE.
'Probability of failure' is computed ONLY if the scenario defines an explicit failure criterion (metric, operator, threshold);
otherwise the report says it is not computed."""
from __future__ import annotations
import numpy as np
from scipy.stats import spearmanr
from ..simulation.config import Scenario, UncertaintyParam
from ..errors import ConfigurationError
from . import forward as F
from . import doe as D

def _draw(p: UncertaintyParam, n, rng):
    if p.dist == "normal": return rng.normal(p.mean, p.std, n)
    if p.dist == "uniform": return rng.uniform(p.low, p.high, n)
    if p.dist == "lognormal": return rng.lognormal(np.log(p.mean), p.std, n)
    raise ConfigurationError(p.dist)

def _bounds(p: UncertaintyParam):
    if p.dist == "uniform": return (p.low, p.high)
    if p.dist == "normal": return (p.mean - 3 * p.std, p.mean + 3 * p.std)
    return (p.mean * np.exp(-3 * p.std), p.mean * np.exp(3 * p.std))

def _stats(y):
    return {"mean": float(np.mean(y)), "std": float(np.std(y, ddof=1)) if len(y) > 1 else 0.0,
            "percentiles": {f"p{q}": float(np.percentile(y, q)) for q in (1, 5, 25, 50, 75, 95, 99)}}

def failure_probability(y, crit):
    if crit is None: return {"computed": False, "reason": "no failure_criterion defined in the scenario; probability of failure is not computed"}
    op = {">": np.greater, "<": np.less, ">=": np.greater_equal, "<=": np.less_equal}[crit.op]
    k = int(op(y, crit.threshold).sum()); n = len(y); p = k / n
    se = float(np.sqrt(p * (1 - p) / n))
    return {"computed": True, "criterion": f"{crit.metric} {crit.op} {crit.threshold}", "probability": p, "standard_error": se, "n": n,
            "note": "probability that the stated criterion is met, under the stated input distributions and the (reduced-order, uncalibrated) model"}

def annotate_reliability(out, crit, loo_min=0.8):
    """Flag surrogate-based statistics whose leave-one-out R^2 is poor (e.g. step-like responses from voxel quantisation)."""
    q = out.get("surrogate", {}).get("quality", {})
    bad = [r for r, v in q.items() if v["R2_leave_one_out"] < loo_min]
    out["unreliable_responses"] = bad
    fp = out.get("failure_probability", {})
    if fp.get("computed") and crit is not None and crit.metric in bad:
        fp["reliable"] = False
        fp["warning"] = (f"UNRELIABLE: the surrogate for '{crit.metric}' has leave-one-out R^2 = {q[crit.metric]['R2_leave_one_out']:.2f} (< {loo_min}); "
                         "this probability reflects the surrogate, not the model. Use --mode direct (full coarse-grid runs) or more training runs.")
    elif fp.get("computed"): fp["reliable"] = True
    return out

def run_monte_carlo(scn: Scenario, n=100, mode="surrogate", n_train=40, seed=None, responses=F.DEFAULT_RESPONSES, dx_mm=None, progress=None):
    params = scn.uncertainty.parameters
    if not params: raise ConfigurationError("uncertainty.parameters is empty: define input distributions in the scenario")
    seed = scn.run.seed if seed is None else seed
    crit = scn.uncertainty.failure_criterion
    resp = list(responses)
    if crit and crit.metric not in resp:
        if crit.metric not in F.RESPONSES: raise ConfigurationError(f"unknown failure metric {crit.metric!r}; choices {sorted(F.RESPONSES)}")
        resp.append(crit.metric)
    rng = np.random.default_rng(seed); names = [p.path for p in params]
    fn = lambda ov: F.evaluate(scn, ov, tuple(resp), dx_mm)
    out = {"mode": mode, "n": n, "seed": seed, "parameters": [p.model_dump() for p in params], "responses": {}}
    if mode == "direct":
        X = np.stack([_draw(p, n, rng) for p in params], axis=1); Y = {r: [] for r in resp}
        for i, row in enumerate(X):
            o = fn({nm: float(v) for nm, v in zip(names, row)})
            for r in resp: Y[r].append(o[r])
            if progress: progress(i + 1, n)
        Y = {r: np.array(v) for r, v in Y.items()}
    elif mode == "surrogate":
        bnd = [_bounds(p) for p in params]
        Xt = D.design("latin_hypercube", bnd, n_train, seed)
        Yt = D.run_design(fn, names, Xt, resp)
        X = np.stack([_draw(p, n, rng) for p in params], axis=1)
        Y = {}; out["surrogate"] = {"n_train": n_train, "training_bounds": bnd, "quality": {}}
        for r in resp:
            m = np.isfinite(Yt[r]); rs = D.ResponseSurface(bnd).fit(Xt[m], Yt[r][m])
            out["surrogate"]["quality"][r] = {"R2_train": rs.r2, "R2_leave_one_out": rs.loo_r2(Xt[m], Yt[r][m]), "n_coefficients": rs.n_features, "n_runs": int(m.sum()),
                                              "terms": "linear+quadratic+interactions" if rs.inter else ("linear+quadratic" if rs.quad else "linear")}
            Xc = np.clip(X, np.array([b[0] for b in bnd]), np.array([b[1] for b in bnd]))
            Y[r] = rs.predict(Xc)
        out["label"] = "SURROGATE-BASED (quadratic response surface on a Latin-hypercube training set)"
    else: raise ConfigurationError("mode must be 'direct' or 'surrogate'")
    for r in resp:
        y = Y[r][np.isfinite(Y[r])]
        sens = {nm: float(spearmanr(X[:, i][np.isfinite(Y[r])], y).statistic) if np.std(y) > 0 else 0.0 for i, nm in enumerate(names)}
        out["responses"][r] = dict(_stats(y), spearman_sensitivity=sens)
    out["failure_probability"] = failure_probability(Y[crit.metric][np.isfinite(Y[crit.metric])], crit) if crit else failure_probability(np.array([]), None)
    annotate_reliability(out, crit)
    out["samples"] = {"X": X.tolist() if n <= 2000 else None, "names": names}
    return out
