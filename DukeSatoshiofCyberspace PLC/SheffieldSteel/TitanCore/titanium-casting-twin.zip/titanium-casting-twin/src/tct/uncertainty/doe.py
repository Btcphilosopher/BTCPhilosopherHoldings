"""Design of experiments + response surfaces.  Designs: Latin hypercube, factorial (full, n-level), Sobol sequence, Monte Carlo.
Analysis: quadratic response surface (least squares, with interactions), standardised main effects, two-factor interaction effects
(from 2-level factorial), variance-based Sobol indices (Saltelli estimators evaluated on the fitted surrogate -- state R^2 when quoting them)."""
from __future__ import annotations
import itertools
import numpy as np
from scipy.stats import qmc

def design(kind, bounds, n=32, seed=0, levels=2):
    """bounds: list of (low, high). Returns X (n_runs, n_params)."""
    lo = np.array([b[0] for b in bounds], float); hi = np.array([b[1] for b in bounds], float); d = len(bounds)
    if kind == "latin_hypercube": u = qmc.LatinHypercube(d=d, seed=seed).random(n)
    elif kind == "sobol": u = qmc.Sobol(d=d, scramble=True, seed=seed).random(n)
    elif kind == "monte_carlo": u = np.random.default_rng(seed).random((n, d))
    elif kind == "factorial":
        g = np.linspace(0, 1, levels); u = np.array(list(itertools.product(g, repeat=d)))
    else: raise ValueError(f"unknown design {kind!r}")
    return lo + u * (hi - lo)

def run_design(fn, names, X, responses):
    """fn(overrides: dict) -> {response: value}. Returns dict response -> array."""
    Y = {r: [] for r in responses}
    for row in X:
        out = fn({n: float(v) for n, v in zip(names, row)})
        for r in responses: Y[r].append(out[r])
    return {r: np.array(v) for r, v in Y.items()}

def n_features(d, interactions=True, quadratic=True):
    return 1 + d + (d if quadratic else 0) + (d * (d - 1) // 2 if interactions else 0)

def _features(Z, interactions=True, quadratic=True):
    n, d = Z.shape; cols = [np.ones(n)] + [Z[:, i] for i in range(d)]; names = ["1"] + [f"x{i}" for i in range(d)]
    if quadratic: cols += [Z[:, i] ** 2 for i in range(d)]; names += [f"x{i}^2" for i in range(d)]
    if interactions:
        for i in range(d):
            for j in range(i + 1, d): cols.append(Z[:, i] * Z[:, j]); names.append(f"x{i}*x{j}")
    return np.stack(cols, axis=1), names

class ResponseSurface:
    """Response surface in coded variables z in [-1, 1]. Model order is limited by the data: interactions need n >= p_full + max(3, d)
    runs, quadratic terms need n >= p_quad + 3, otherwise the fit falls back to quadratic-without-interactions, then to linear. This prevents the
    silent over-fitting (R^2 = 1 with more coefficients than runs) that a fixed quadratic model would produce."""
    def __init__(self, bounds, interactions=True):
        self.lo = np.array([b[0] for b in bounds], float); self.hi = np.array([b[1] for b in bounds], float); self.want_inter = interactions
    def code(self, X): return 2 * (np.asarray(X, float) - self.lo) / (self.hi - self.lo) - 1
    def fit(self, X, y):
        n, d = len(y), len(self.lo)
        self.inter = self.want_inter and n >= n_features(d, True, True) + max(3, d)
        self.quad = n >= n_features(d, False, True) + 3
        if not self.quad: self.inter = False
        A, self.feature_names = _features(self.code(X), self.inter, self.quad)
        self.n_features = A.shape[1]
        self.coef = np.linalg.lstsq(A, y, rcond=None)[0]
        pred = A @ self.coef; ss = ((y - y.mean()) ** 2).sum()
        self.r2 = float(1 - ((y - pred) ** 2).sum() / ss) if ss > 0 else 1.0
        self.n_train = n; return self
    def predict(self, X):
        A, _ = _features(self.code(np.atleast_2d(X)), self.inter, self.quad); return A @ self.coef
    def loo_r2(self, X, y):
        """Leave-one-out predictive R^2 (explicit refits for n <= 300; hat-matrix shortcut beyond)."""
        X = np.asarray(X, float); y = np.asarray(y, float); n = len(y); ss = ((y - y.mean()) ** 2).sum()
        if ss <= 0: return 1.0
        if n <= 300:
            res = []
            for i in range(n):
                keep = np.arange(n) != i
                m = ResponseSurface(list(zip(self.lo, self.hi)), self.want_inter); m.inter, m.quad = self.inter, self.quad
                A, _ = _features(m.code(X[keep]), m.inter, m.quad); c = np.linalg.lstsq(A, y[keep], rcond=None)[0]
                Ai, _ = _features(m.code(X[i:i + 1]), m.inter, m.quad); res.append(y[i] - (Ai @ c)[0])
            return float(1 - (np.array(res) ** 2).sum() / ss)
        A, _ = _features(self.code(X), self.inter, self.quad); H = A @ np.linalg.pinv(A.T @ A) @ A.T
        r = (y - H @ y) / np.maximum(1 - np.diag(H), 1e-9); return float(1 - (r ** 2).sum() / ss)

def main_effects(rs: ResponseSurface, names):
    d = len(names); c = rs.coef[1:1 + d]
    return {n: float(2 * c[i]) for i, n in enumerate(names)}        # change in response over the full range (linear term)

def interaction_effects(rs: ResponseSurface, names):
    """Two-factor interaction coefficients (empty if the data did not support an interaction model)."""
    d = len(names); out = {}
    for k, fn in enumerate(rs.feature_names):
        if "*" in fn:
            i, j = (int(t[1:]) for t in fn.split("*")); out[f"{names[i]} x {names[j]}"] = float(rs.coef[k])
    return out

def sobol_indices(rs: ResponseSurface, n=4096, seed=0):
    d = len(rs.lo); rng = np.random.default_rng(seed)
    A = rng.random((n, d)); B = rng.random((n, d))
    f = lambda U: rs.predict(rs.lo + U * (rs.hi - rs.lo))
    fA, fB = f(A), f(B); var = np.var(np.concatenate([fA, fB]))
    S1, ST = [], []
    for i in range(d):
        ABi = A.copy(); ABi[:, i] = B[:, i]; fAB = f(ABi)
        S1.append(float(np.mean(fB * (fAB - fA)) / var) if var > 0 else 0.0)
        ST.append(float(0.5 * np.mean((fA - fAB) ** 2) / var) if var > 0 else 0.0)
    return S1, ST

def influence(names, X, y):
    """Standardised regression coefficients (|beta| ranking) -- cheap influence screening independent of the quadratic fit."""
    Z = (X - X.mean(0)) / np.where(X.std(0) > 0, X.std(0), 1.0); yz = (y - y.mean()) / (y.std() if y.std() > 0 else 1.0)
    beta = np.linalg.lstsq(Z, yz, rcond=None)[0]
    return sorted(zip(names, beta.tolist()), key=lambda t: -abs(t[1]))
