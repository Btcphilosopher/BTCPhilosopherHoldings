"""Forward model wrappers for studies: run the FULL pipeline on a coarse grid and return a response dictionary.
Responses are computed by the same solvers as a production run (no surrogate here); coarse grids trade accuracy for speed."""
from __future__ import annotations
import tempfile, os
import numpy as np
from ..simulation.config import Scenario, with_overrides
from ..simulation.pipeline import run_simulation

RESPONSES = {
    "fill_time_s": lambda r: r["fill"]["fill_time_s"],
    "pour_temperature_C": lambda r: r["melt"]["pour_temperature_C"],
    "solidification_time_s": lambda r: r["solidification"]["solidification_time_part_max_s"],
    "cooling_rate_beta_min_K_s": lambda r: r["solidification"]["cooling_rate_beta_min_part"],
    "niyama_min": lambda r: r["solidification"]["niyama_min_part"],
    "porosity_risk_max": lambda r: r["porosity"]["porosity_risk_max_part"],
    "porosity_risk_mean": lambda r: r["porosity"]["porosity_risk_mean_part"],
    "void_fraction_mean": lambda r: r["porosity"]["void_fraction_mean_part"],
    "isolated_volume_fraction": lambda r: r["feeding"]["isolated_part_volume_fraction"],
    "misrun_fraction": lambda r: r["fill"]["misrun_part_volume_fraction"],
    "cold_shut_max": lambda r: r["fill"]["cold_shut_max_part"],
    "residual_vm_max_MPa": lambda r: r["stress"].get("vm_max_part_MPa", 0.0),
    "max_warpage_mm": lambda r: r["distortion"].get("max_warpage_m", 0.0) * 1e3,
}
DEFAULT_RESPONSES = ("fill_time_s", "solidification_time_s", "porosity_risk_mean", "cooling_rate_beta_min_K_s", "residual_vm_max_MPa", "isolated_volume_fraction")

def coarse(scn: Scenario, dx_mm=None):
    d = dx_mm or scn.uncertainty.fast_dx_mm
    return with_overrides(scn, {"mesh.dx_mm": d, "stress.n_steps": 6, "heat_treatment.preset": "none"})

def evaluate(scn: Scenario, overrides: dict, responses=DEFAULT_RESPONSES, dx_mm=None):
    s = coarse(with_overrides(scn, overrides), dx_mm)
    with tempfile.TemporaryDirectory() as td:
        run = run_simulation(s, output_path=os.path.join(td, "run.h5"))
    out = {}
    for k in responses:
        try: v = RESPONSES[k](run.results); out[k] = float(v) if v is not None else float("nan")
        except Exception: out[k] = float("nan")
    return out
