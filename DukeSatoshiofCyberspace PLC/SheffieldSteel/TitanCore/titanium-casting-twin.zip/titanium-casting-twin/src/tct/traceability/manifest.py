"""SimulationManifest: everything needed to reproduce a run."""
from __future__ import annotations
import hashlib, json, os, platform, subprocess, sys, datetime
from dataclasses import dataclass, asdict, field
import numpy as np
from .. import __version__

def _git_commit():
    try:
        here = os.path.dirname(os.path.abspath(__file__))
        out = subprocess.run(["git", "rev-parse", "HEAD"], cwd=here, capture_output=True, text=True, timeout=5)
        return out.stdout.strip() if out.returncode == 0 and out.stdout.strip() else "unavailable (not a git checkout)"
    except Exception:
        return "unavailable"

def array_hash(a) -> str:
    return hashlib.sha256(np.ascontiguousarray(a).tobytes()).hexdigest()[:16]

def json_hash(obj) -> str:
    return hashlib.sha256(json.dumps(obj, sort_keys=True, default=str).encode()).hexdigest()[:16]

@dataclass
class SimulationManifest:
    simulation_id: str
    timestamp_utc: str
    software_version: str
    git_commit: str
    material_database_version: str
    material_hash: str
    geometry_hash: str
    mesh_hash: str
    process_configuration: dict
    solver_configuration: dict
    random_seed: int
    hardware: dict
    dependencies: dict = field(default_factory=dict)
    def to_dict(self): return asdict(self)
    @staticmethod
    def from_dict(d): return SimulationManifest(**d)

def hardware_info():
    import numpy, scipy
    try: import numba; nb = numba.__version__
    except Exception: nb = "n/a"
    return {"platform": platform.platform(), "machine": platform.machine(), "processor": platform.processor() or "n/a",
            "cpu_count": os.cpu_count(), "python": sys.version.split()[0]}, {"numpy": numpy.__version__, "scipy": scipy.__version__, "numba": nb}

def make_manifest(sim_id, material_version, material_hash, geometry_hash, mesh_hash, process_cfg, solver_cfg, seed):
    hw, deps = hardware_info()
    return SimulationManifest(sim_id, datetime.datetime.now(datetime.timezone.utc).isoformat(timespec="seconds"), __version__, _git_commit(),
                              material_version, material_hash, geometry_hash, mesh_hash, process_cfg, solver_cfg, int(seed), hw, deps)
