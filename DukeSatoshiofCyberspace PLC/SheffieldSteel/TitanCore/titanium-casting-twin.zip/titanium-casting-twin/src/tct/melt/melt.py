"""Melt-state model: charge -> melt -> superheat -> hold -> transfer -> pour temperature.  STATUS: REDUCED-ORDER.

Energy balance for melting (lumped bath of mass m):
    m dh/dt = eta * P_in  -  eps * sigma * A_bath * (T^4 - T_wall^4)           T = T(h) from the alloy enthalpy table
Transfer (crucible -> mold), lumped radiation from the stream/ladle surface:
    m cp dT/dt = - eps * sigma * A_exposed * (T^4 - T_amb^4)
Methods are NOT interchangeable. Each has distinct required inputs and physical caveats:
  induction_skull : coil power through a water-cooled segmented crucible with solidified skull; eta low (skull absorbs heat)
  var_skull       : consumable-electrode vacuum arc melting into a skull crucible; arc power I*V*eta; superheat set by power balance
  ebm_hearth      : electron-beam cold-hearth melting; very high vacuum -> significant Al evaporation (Langmuir-limited)
Al evaporation: series resistance of Langmuir free evaporation and gas-phase diffusion (UPPER BOUND, ESTIMATED activity).
"""
from __future__ import annotations
from dataclasses import dataclass
import numpy as np
from ..errors import ConfigurationError
from ..units import SIGMA_SB, R_GAS, c2k, ATM_Pa
from ..materials.alloy import Alloy

METHODS = ("induction_skull", "var_skull", "ebm_hearth")
_REQUIRED = {"induction_skull": ("coil_power_W",), "var_skull": ("arc_current_A", "arc_voltage_V"), "ebm_hearth": ("beam_power_W",)}
_ETA_DEFAULT = {"induction_skull": 0.35, "var_skull": 0.60, "ebm_hearth": 0.70}   # ESTIMATED thermal coupling efficiencies

@dataclass
class MeltConfig:
    method: str = "induction_skull"
    charge_mass_kg: float = 3.0
    charge_T0_C: float = 25.0
    target_superheat_C: float = 60.0
    hold_time_s: float = 20.0
    transfer_time_s: float = 4.0
    coil_power_W: float | None = 150e3
    arc_current_A: float | None = None
    arc_voltage_V: float | None = None
    beam_power_W: float | None = None
    efficiency: float | None = None
    bath_area_m2: float = 0.02
    wall_temperature_C: float = 200.0
    bath_emissivity: float = 0.35
    stream_area_m2: float = 0.01
    ambient_temperature_C: float = 150.0
    chamber_pressure_Pa: float = 1.0
    al_activity: float = 0.03          # ESTIMATED activity of Al in Ti-6Al-4V melt
    def validate(self):
        if self.method not in METHODS: raise ConfigurationError(f"melt method must be one of {METHODS}")
        for k in _REQUIRED[self.method]:
            if getattr(self, k) is None: raise ConfigurationError(f"method {self.method!r} requires {k}")
        if self.charge_mass_kg <= 0: raise ConfigurationError("charge_mass_kg must be > 0")
        return self
    @property
    def power_W(self):
        eta = self.efficiency or _ETA_DEFAULT[self.method]
        P = {"induction_skull": lambda: self.coil_power_W, "var_skull": lambda: self.arc_current_A * self.arc_voltage_V,
             "ebm_hearth": lambda: self.beam_power_W}[self.method]()
        return eta * P

def al_vapour_pressure_Pa(T_C):
    """Pure-Al vapour pressure from Clausius-Clapeyron anchored at the normal boiling point (2792 K, dH ~ 294 kJ/mol)."""
    T = c2k(T_C); return ATM_Pa * np.exp(-(294e3 / R_GAS) * (1.0 / T - 1.0 / 2792.0))

def al_evaporation_flux_kg_m2_s(T_C, activity, chamber_pressure_Pa, boundary_layer_m=0.05):
    p = activity * al_vapour_pressure_Pa(T_C); M = 26.98e-3; T = c2k(T_C)
    J_L = p / np.sqrt(2 * np.pi * M * R_GAS * T)                                 # Langmuir (free evaporation)
    D = 2.0e-5 * (T / 273.15) ** 1.75 * (ATM_Pa / max(chamber_pressure_Pa, 1e-3))  # Al in inert gas, ESTIMATED
    J_D = (D / boundary_layer_m) * p / (R_GAS * T) * M                            # diffusion-limited
    return 1.0 / (1.0 / J_L + 1.0 / J_D)

@dataclass
class MeltResult:
    time_to_liquidus_s: float
    time_to_superheat_s: float
    hold_time_s: float
    melt_temperature_C: float
    pour_temperature_C: float
    transfer_loss_C: float
    al_loss_upper_bound_wt_pct: float
    atmosphere_exposure_s: float
    notes: list
    model: str = "REDUCED-ORDER lumped energy balance"

def simulate_melt(alloy: Alloy, cfg: MeltConfig) -> MeltResult:
    cfg.validate(); notes = []
    P = cfg.power_W; m = cfg.charge_mass_kg
    h_tab = alloy.enthalpy_table_J_kg()
    from ..materials.alloy import T_GRID_C
    h = float(np.interp(cfg.charge_T0_C, T_GRID_C, h_tab))
    T_target = alloy.T_liquidus_C + cfg.target_superheat_C
    t = 0.0; dt = 0.5; t_liq = None; t_sh = None
    while t < 6 * 3600:
        T = float(np.interp(h, h_tab, T_GRID_C))
        if t_liq is None and T >= alloy.T_liquidus_C: t_liq = t
        if T >= T_target: t_sh = t; break
        Prad = cfg.bath_emissivity * SIGMA_SB * cfg.bath_area_m2 * (c2k(T) ** 4 - c2k(cfg.wall_temperature_C) ** 4)
        net = P - Prad
        if net <= 0:
            notes.append("net power <= 0 before reaching target superheat: INSUFFICIENT POWER"); t_sh = float("inf"); break
        h += net * dt / m; t += dt
    if t_sh is None:
        notes.append("target superheat not reached within 6 h: INSUFFICIENT POWER"); t_sh = float("inf")
    if t_liq is None: t_liq = float("inf")
    # hold at target
    T_melt = T_target if np.isfinite(t_sh) else float(np.interp(h, h_tab, T_GRID_C))
    # transfer
    Tt = T_melt; n = max(int(cfg.transfer_time_s / 0.05), 1); dts = cfg.transfer_time_s / n
    eps = float(alloy.tables["emissivity"](T_melt))
    for _ in range(n):
        cp = float(alloy.tables["specific_heat"](Tt))
        qr = eps * SIGMA_SB * cfg.stream_area_m2 * (c2k(Tt) ** 4 - c2k(cfg.ambient_temperature_C) ** 4)
        Tt -= qr / (m * cp) * dts
    # Al loss (upper bound)
    exposure = (t_sh if np.isfinite(t_sh) else 0.0) - (t_liq if np.isfinite(t_liq) else 0.0) + cfg.hold_time_s
    J = al_evaporation_flux_kg_m2_s(T_melt, cfg.al_activity, cfg.chamber_pressure_Pa)
    al_loss_kg = J * cfg.bath_area_m2 * max(exposure, 0.0)
    al_loss_wt = 100.0 * al_loss_kg / m
    if cfg.method == "ebm_hearth": notes.append("EBM: high-vacuum Al evaporation can be significant; value is an upper bound")
    if cfg.method == "induction_skull": notes.append("skull melting: crucible contamination minimal but superheat limited by skull heat extraction")
    return MeltResult(float(t_liq), float(t_sh), cfg.hold_time_s, float(T_melt), float(Tt), float(T_melt - Tt),
                      float(al_loss_wt), float(max(exposure, 0.0) + cfg.transfer_time_s), notes)
