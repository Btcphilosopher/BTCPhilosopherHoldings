"""Furnace / chamber atmosphere and contamination-risk model.  STATUS: REDUCED-ORDER, impingement-limited UPPER BOUND.

Partial pressures: from user-specified vacuum level (total pressure), optional argon backfill, and an air-leak model
    p_leak = Q_leak / S_pump  (Pa)   split 21% O2 / 78% N2 (air),  plus outgassing H2 partial pressure (user).
Gas pick-up (per exposed area):
    Hertz-Knudsen impingement flux   J_i = p_i / sqrt(2 pi m_i k T)             [molecules m^-2 s^-1]
    uptake mass per area             m''_i = S_i * J_i * (atoms per molecule) * m_atom * t_exposure
  S_i (sticking/reaction probability) is ESTIMATED (O2 ~0.1, N2 ~1e-3 on clean hot Ti). With S=1 this is a hard upper bound.
Hydrogen is equilibrium-limited (Sieverts): [H] = K_s * sqrt(p_H2)  (K_s ESTIMATED).
Alpha-case equivalent depth: delta = m''_O / (rho * dC_O), dC_O = oxygen enrichment defining alpha case (default 0.5 wt%, ESTIMATED).
Outputs are RISK INDICATORS vs. specification limits, not predicted chemistry.
"""
from __future__ import annotations
from dataclasses import dataclass, field
import numpy as np
from ..units import K_BOLTZ, N_AVOGADRO, c2k, ATM_Pa

M_O2, M_N2, M_H2 = 31.998e-3, 28.014e-3, 2.016e-3      # kg/mol
LIMITS_WT = {"O": 0.20, "N": 0.05, "H": 0.015}         # Grade 5 / ASTM-style screening limits (user should override)

@dataclass
class Atmosphere:
    vacuum_pressure_Pa: float = 1.0                  # total chamber pressure before backfill
    argon_pressure_Pa: float = 0.0                   # partial pressure of argon backfill (0 = pure vacuum)
    leak_rate_Pa_m3_s: float = 1.0e-3                # air in-leak (throughput)
    pump_speed_m3_s: float = 0.5
    h2_outgassing_Pa: float = 1.0e-2                 # hydrogen partial pressure from outgassing
    sticking: dict = field(default_factory=lambda: {"O2": 0.1, "N2": 1.0e-3})
    @property
    def p_leak_Pa(self): return self.leak_rate_Pa_m3_s / self.pump_speed_m3_s
    def partial_pressures_Pa(self):
        pl = self.p_leak_Pa
        return {"O2": 0.21 * pl, "N2": 0.78 * pl, "H2": self.h2_outgassing_Pa, "Ar": self.argon_pressure_Pa}
    @property
    def total_pressure_Pa(self): return max(self.vacuum_pressure_Pa, sum(self.partial_pressures_Pa().values()))

def impingement_flux(p_Pa, M_kg_mol, T_C):
    m = M_kg_mol / N_AVOGADRO
    return p_Pa / np.sqrt(2.0 * np.pi * m * K_BOLTZ * c2k(T_C))

def uptake_kg_m2(atm: Atmosphere, species: str, T_C, t_s):
    """Impingement-limited uptake of the *element* (O or N) in kg per m^2 over t_s at surface temperature T_C."""
    p = atm.partial_pressures_Pa()[species]; M = {"O2": M_O2, "N2": M_N2}[species]
    J = impingement_flux(p, M, T_C)                                   # molecules/m^2/s
    return atm.sticking.get(species, 1.0) * J * 2.0 * (M / 2.0 / N_AVOGADRO) * np.asarray(t_s)   # 2 atoms/molecule

def alpha_case_equivalent_depth_m(oxygen_kg_m2, density_kg_m3=4200.0, dC_O_wt=0.5):
    return oxygen_kg_m2 / (density_kg_m3 * dC_O_wt / 100.0)

def hydrogen_equilibrium_wt(atm: Atmosphere, Ks_wt_per_sqrtPa=2.0e-3):
    """Sieverts-law equilibrium hydrogen (wt%) with ESTIMATED constant; shown for risk ranking only."""
    return Ks_wt_per_sqrtPa * np.sqrt(max(atm.partial_pressures_Pa()["H2"], 0.0))

def contamination_report(atm: Atmosphere, surface_T_C, exposure_s, exposed_area_m2, melt_mass_kg, limits=None):
    limits = limits or LIMITS_WT
    rep = {"model": "REDUCED-ORDER upper bound (impingement-limited; sticking coefficients ESTIMATED)", "species": {}}
    for sp, el in (("O2", "O"), ("N2", "N")):
        u = float(uptake_kg_m2(atm, sp, surface_T_C, exposure_s))
        bulk_wt = 100.0 * u * exposed_area_m2 / melt_mass_kg
        rep["species"][el] = {"partial_pressure_Pa": atm.partial_pressures_Pa()[sp], "uptake_kg_m2": u,
                              "bulk_pickup_wt_pct_upper_bound": bulk_wt, "limit_wt_pct": limits[el],
                              "ratio_to_limit": bulk_wt / limits[el]}
    h = float(hydrogen_equilibrium_wt(atm))
    rep["species"]["H"] = {"partial_pressure_Pa": atm.partial_pressures_Pa()["H2"], "equilibrium_wt_pct": h,
                           "limit_wt_pct": limits["H"], "ratio_to_limit": h / limits["H"]}
    dO = alpha_case_equivalent_depth_m(rep["species"]["O"]["uptake_kg_m2"])
    rep["alpha_case_equivalent_depth_m_atmosphere_upper_bound"] = float(dO)
    ratios = [v["ratio_to_limit"] for v in rep["species"].values()]
    rep["contamination_risk_index"] = float(max(ratios))      # max ratio to limit; >1 means the (upper-bound) limit is exceeded
    return rep
