"""Timing/scaling benchmark for the thermal kernel (profile hot spots before optimising). Usage: python benchmarks/run_benchmarks.py"""
import time, cProfile, pstats, io
import numpy as np
from tct.geometry.library import build_bracket
from tct.materials.database import get_alloy
from tct.thermal.solver import ThermalSolver
from tct.thermal.boundary import BoundaryCondition

def bench(dx):
    cs = build_bracket(dx, 8e-3); a = get_alloy("ti64")
    s = ThermalSolver(cs, a, T_metal_C=1800.0, T_mold0_C=850.0, bcs=[BoundaryCondition("radiation", surrounding_temperature_C=100.0)])
    s.advance_to(1.0); t = time.time(); n0 = s.steps; s.advance_to(40.0); dt = time.time() - t
    return len(s.act), (s.steps - n0), dt, dt / max(s.steps - n0, 1) / len(s.act) * 1e9

if __name__ == "__main__":
    print("dx_mm  active_cells  steps  wall_s  ns/cell/step")
    for dx in (6e-3, 4e-3, 3e-3): c, n, w, ns = bench(dx); print(f"{dx*1e3:5.1f} {c:12d} {n:6d} {w:7.2f} {ns:10.1f}")
    pr = cProfile.Profile(); pr.enable(); bench(4e-3); pr.disable()
    s = io.StringIO(); pstats.Stats(pr, stream=s).sort_stats("cumulative").print_stats(8); print(s.getvalue())
