# titanium-casting-twin (`tct`)

A physics-first **virtual foundry** for titanium alloy castings: alloy → melt → pour → fill → solidification → microstructure → feeding → porosity →
thermal/residual stress → distortion → heat treatment (incl. HIP) → machining → simulated NDE → engineering report, with full traceability.
*The physics is the product; the digital twin is the interface.*

> **Honest status.** This is a **reduced-order research platform**, not a certified or experimentally validated tool. Every model carries a status label
> (`PHYSICS-BASED`, `REDUCED-ORDER`, `EMPIRICAL`, `CALIBRATED`, `VALIDATED AGAINST EXPERIMENT`, `QUALITATIVE`); **none is labelled calibrated/validated for titanium casting** because
> no foundry data was available. Many constants are `estimated` and listed as such. Results are risk *indicators*. Verification against analytical solutions is documented and passes; validation against your foundry data is still to be done
> (the tooling for it is in place). See `docs/physics/physics.md`, `docs/validation/validation.md`, `docs/materials/materials.md`.

## Quick start
```bash
pip install -e .[dev,viz]
pytest                                                    # 91 tests (unit, numerical, conservation, system, regression, CLI)
tct validate scenarios/ti64_aerospace_bracket.yaml        # config + geometry + verification suite (disagreements shown, not hidden)
tct simulate scenarios/ti64_aerospace_bracket.yaml --out reports/CAST-2047-018    # ~4.5 min, single core
tct inspect  reports/CAST-2047-018/run.h5 --at 30 0 40    # "What happened here?" at x=30,y=0,z=40 mm
tct replay   reports/CAST-2047-018/run.h5 --viewer        # interactive PyVista twin (needs a display)
tct report   reports/CAST-2047-018/run.h5                 # HTML / PDF / JSON / CSV (+ the HDF5 run store)
tct dashboard reports/CAST-2047-018/run.h5                # scrubbable HTML dashboard
tct monte-carlo | sensitivity | optimise-riser | mesh     # see docs/user-guide/user-guide.md
```
Requires Python ≥ 3.10; core deps NumPy, SciPy, Numba, Pydantic, h5py, pandas, matplotlib, trimesh, scikit-image, click, reportlab; optional PyVista (3D), cadquery (STEP).

## Acceptance demonstration (Ti-6Al-4V bracket, run `CAST-2047-018`, shipped in `reports/CAST-2047-018/`)
Procedural CAD (L-bracket, cored boss) → marching-cubes surface mesh (validated: watertight, 1 component, 0 self-intersections) → 3 mm voxel domain (25,106 active cells, 10,709 metal) → induction-skull melt (pour 1827 °C) →
bottom-gated fill (1.91 s) → 1538 s thermal history (13,994 adaptive steps, energy balance 4.9e-15) → solidification/feeding/porosity/microstructure → incremental thermo-elastic-plastic FE (13 increments) → distortion → HIP → machining → simulated NDE → report.

Outcome (default screening thresholds; **all confidence LOW–MODERATE**):

| criterion | value | status |
|---|---|---|
| misrun fraction / cold-shut indicator | 0 / 1.0 | PASS / **HIGH-RISK** (fronts meet near the liquidus: ~1648 °C arrival at the weld line) |
| air-entrainment index (v/v_crit − 1) | 0.87 | REVIEW |
| isolated (unfed) part volume | 8.6 % | **HIGH-RISK** — see riser study below |
| porosity indicator (max / mean) | 1.0 / 0.15 | HIGH-RISK locally / low on average |
| residual stress (max von Mises / RT yield) | 40 MPa / 0.046 | PASS — **but see limitation: no mold restraint** |
| warpage after removing 1.44 % uniform contraction | 0.006 mm | PASS (same caveat) |
| machining margin (1 mm allowance vs alpha case 0.25 mm upper bound + distortion) | 0.67 mm | PASS |
| largest *simulated* indication after HIP | 5.0 mm | HIGH-RISK (near-surface voids are not closed by HIP) |

The model therefore says: *this bracket gating/riser layout is not acceptable as designed*, and *a bigger riser does not fix it* (`reports/riser_optimisation_bracket.txt`: Nelder–Mead over riser diameter/height moves the
isolated volume only between 8.3 % and 10.5 %) — the unfed pools sit at the web/plate/rib junction behind thin sections; a design change (riser position, chill, rib geometry) would be needed.
That is a result of the reduced-order model, not an engineering conclusion.

`reports/sensitivity_bracket.txt` is a **calculated** sensitivity table (central differences of the full pipeline on a 6 mm grid), e.g. +12 °C pour temperature → +1.1 s solidification time and −2.7 % mean porosity indicator;
+2 mm shell thickness → +17 % solidification time, −24 % mean porosity indicator. `reports/monte_carlo_bracket.txt` (2000 samples, surrogate on 40 Latin-hypercube runs): e.g. solidification time 56.1 ± 2.2 s, mean porosity indicator 0.34 ± 0.02. The surrogate for `isolated_volume_fraction` is **poor (leave-one-out R² = −0.29; a step-like response caused by voxel quantisation)**, so the
reported failure probability for the user-defined criterion `isolated_volume_fraction > 0.09` (0.97) is flagged **UNRELIABLE** by the tool — use `--mode direct`. The criterion and distributions are illustrative.

Some parameters show exactly zero effect (gate height at 6 mm voxels is quantised away; vacuum level only enters the fill pressure) — check resolution before trusting a zero.

## What is implemented (and what is not)
**Implemented**: alloy database with mandatory provenance (5 alloys; YAML); procedural CAD + STL/OBJ/PLY/VTK import + mesh validation (non-manifold, holes, inversion, self-intersection, components, thin walls); CastingSystem (part, riser, gate, runner, sprue, basin, filter role, core, shell);
enthalpy-method thermal solver (Numba, adaptive Δt, radiation/convection/contact/fixed-T BCs, ceramic/graphite/metal/water-cooled molds); melt models (induction-skull, VAR-skull, EBM hearth) and atmosphere/contamination upper bounds; reduced-order free-surface fill with Re/Pr/Nu/We and
misrun/cold-shut/air-entrainment indicators; solidification metrics (cooling rate, gradient, Niyama, local solidification time, maps); microstructure indicators; isolated-pool feeding, shrinkage bookkeeping, riser indicators and optimisation, gating sensitivity; porosity (micro/macro/H₂/entrained, no binary defect flag);
voxel FE thermo-elastic-plastic stress with residual stress tensors/principal stress, distortion decomposition; heat treatment (ramp/hold/cool/age, HIP); machining allowance; simulated CT/X-ray/UT/FPI/visual/CMM; transparent quality engine; manifest; HDF5 store; step/run/pause/resume/rewind/replay engine; DigitalTwinState;
PyVista viewer + HTML dashboard + reports; sensitivity, DOE (LHS/Sobol/factorial/MC, response surfaces, Sobol indices), Monte Carlo (direct/surrogate), calibration (least squares, Metropolis); verification suite; CLI.

**Not implemented / known gaps (please read)**
* **No experimental validation** and no calibration — constants flagged `estimated` are order-of-magnitude. Only Ti-6Al-4V has literature-derived (approximate, digitised) data; the other four alloys are 100 % estimated placeholders.
* **Stress/distortion omit the mold/shell restraint and creep** — expect under-prediction of real residual stress and warpage. Stress is verified for free-body behaviour and equilibrium only.
* **Fill is a graph/flux-conserving model, not CFD** (no momentum, jetting, gas back-pressure). VOF/level-set/SPH/FV-CFD are *interfaces only*.
* Voxel (staircase) geometry; boundary temperature at the cell centre; freezing ranges < ~3 K are under-resolved (solver warns).
* **JAX, CuPy, Dask, Zarr, Parquet, xarray, Polars are not wired in** — HDF5 + NumPy/Numba only. **STEP** needs the optional `cadquery`. Imported meshes are simulated part-only (no gating).
* The interactive PyVista widgets (`--viewer`) were **not exercised** in the headless build environment (off-screen rendering, probing and the query logic are tested). Water-cooled chills have a material preset but no placement helper. Filters are supported in the fill hydraulics but not in the demo scenario.
* Scale demonstrated: ~25 k cells (≈4.5 min single core). The specified 2.5 M-cell case was **not** run; the architecture (compressed active-cell graph, streamed HDF5, replaceable backends) is meant for it, but performance there is untested (`benchmarks/run_benchmarks.py`).
* `tct/thermodynamics/` is a stub reserved for CALPHAD/Thermo-Calc table import.

Layout and design rules: `docs/architecture/architecture.md`; solver notes `docs/architecture/solver.md`; security/traceability `docs/architecture/security_and_traceability.md`; uncertainty `docs/validation/uncertainty.md`.
License: Apache-2.0.
