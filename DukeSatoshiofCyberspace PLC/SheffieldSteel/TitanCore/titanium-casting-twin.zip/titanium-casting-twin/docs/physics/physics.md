# Physics model catalogue

Every model below lists: **equation · assumptions · parameters (units) · validity range · numerical method · validation status · limitations.**
Status labels used throughout the code and reports: `PHYSICS-BASED`, `REDUCED-ORDER`, `EMPIRICAL`, `CALIBRATED`, `VALIDATED AGAINST EXPERIMENT`,
`QUALITATIVE`. **Nothing in this repository is currently labelled `CALIBRATED` or `VALIDATED AGAINST EXPERIMENT` for titanium casting**:
no foundry data was available when it was built. Verification against analytical solutions is documented in `docs/validation/validation.md`.

Units: SI internally (m, s, Pa, kg, W); temperatures in °C at API boundaries and Kelvin only inside radiation/Arrhenius terms; MPa/mm only in
user-facing configuration. Variable suffixes (`_m`, `_C`, `_Pa`, `_s`, `_K_s`) carry the unit.

---
## 1. Transient heat conduction with phase change (enthalpy method)
* **Equation** `d(Hv)/dt = ∇·(k∇T) + Q`, `Hv = ρ_ref · h(T)`, `h(T) = ∫cp dT + L (1 − fs(T))`, `fs = ((T_liq − T)/(T_liq − T_sol))^p` (p = 1 default).
* **Assumptions** fixed reference density per cell (mass conserved on the fixed grid; density change handled by the shrinkage model); latent heat released over the
  freezing range by `fs(T)`; solid and liquid share one conductivity table `k(T)`; no convection in the melt (after fill); no electromagnetic stirring.
* **Parameters** `ρ(T)` kg/m³, `cp(T)` J/(kg K), `k(T)` W/(m K), `L` J/kg, `T_liq`, `T_sol` °C. All carry provenance (`materials/`).
* **Validity** temperature table 0–2300 °C at 1 K resolution. **Freezing ranges narrower than ~3 K are under-resolved** (the solver warns). All titanium alloys here have ≥ 25 K.
* **Numerics** finite volume on a uniform cubic voxel grid; face conductance by harmonic mean with interface resistance; forward Euler on `Hv` (exactly conservative);
  adaptive Δt from the local diffusive + boundary limit (safety 0.45); Numba kernel on a compressed active-cell graph; lookup-table `T(Hv)`.
* **Status** `PHYSICS-BASED`. Verified: erfc semi-infinite solution (0.08 %), Stefan/Neumann front (0.15 % for a 4 K range), lumped radiation (0.15 %),
  energy balance to round-off (≈1e-14), mesh and time-step convergence tests.
* **Limitations** first-order in time; voxel (staircase) geometry; boundary temperature taken at the cell centre (no half-cell correction).

## 2. Boundary conditions
* **Equation** radiation `q = ε σ (T_s⁴ − T_sur⁴)`; convection `q = h (T_s − T_amb)`; fixed-T (stiff surrogate); adiabatic. In vacuum the convective term is removed.
* **Interface** metal/mold conductance `h(fl) = h_cold + (h_hot − h_cold)·fl`, `fl` = liquid fraction of the metal cell (gap formation after solidification).
* **Parameters** `ε` (-) from the surface material table or the BC, `T_sur` °C, `h` W/(m² K) (`h_hot`, `h_cold` are EMPIRICAL and are the main calibration targets).
* **Status** radiation law verified; `h_hot/h_cold` presets are `estimated`. **Limitation** no view-factor/radiative exchange between surfaces; the outer shell sees a uniform surrounding temperature.

## 3. Mold / shell
Ceramic shell, graphite, metal mold, water-cooled copper, custom tooling (`thermal/mold.py`). Properties `k(T)`, `cp(T)`, ρ, ε, interface `h`. All presets are `estimated`.
Shell thickness comes from the geometry (distance from the metal). The mold is part of the thermal domain; **it is not part of the mechanical model** (see §13).

## 4. Melt model (`melt/melt.py`) — `REDUCED-ORDER`
* **Equation** `m dh/dt = η P − ε σ A (T⁴ − T_wall⁴)` (heat-up), lumped radiation during transfer `m cp dT/dt = −ε σ A (T⁴ − T_amb⁴)`.
* Methods are **not interchangeable**: `induction_skull` (coil power, low η), `var_skull` (I·V·η), `ebm_hearth` (beam power, high-vacuum evaporation). Missing method-specific inputs raise `ConfigurationError`.
* **Al evaporation**: Clausius–Clapeyron vapour pressure × activity (ESTIMATED 0.03) with Langmuir and gas-diffusion resistances in series. **An upper bound**, reported but **not** applied to the composition.
* **Limitations** no bath hydrodynamics, no skull thickness model, no electromagnetic effects, η are ESTIMATED.

## 5. Atmosphere and contamination (`melt/atmosphere.py`) — upper-bound `REDUCED-ORDER`
* **Equation** Hertz–Knudsen `J = p/√(2π m k T)` × sticking coefficient `S` (O₂ 0.1, N₂ 1e-3, ESTIMATED) × exposure time; hydrogen by Sieverts' law `[H] = K_s √p` (K_s ESTIMATED).
* Partial pressures from vacuum level, argon backfill, leak throughput / pump speed (air split 21/78 %), and outgassing H₂.
* **Output** ratios to specification limits (screening defaults O 0.20, N 0.05, H 0.015 wt %), an alpha-case-equivalent depth, and a `contamination_risk_index`. **Not a predicted chemistry.**
* **Alpha case from the mold reaction**: `δ = 2√(∫D_O(T) dt)` accumulated in the thermal kernel (D_O ESTIMATED), with unlimited oxygen supply at the interface ⇒ **upper bound**.

## 6. Free-surface fill (`flow/fill.py`) — `REDUCED-ORDER`, not CFD
* **Gating hydraulics** `Q = A_g √(2 g H_eff/(1 + ΣK))`, `H_eff = z_basin(t) − z_front(V)`, basin balance `dz_b/dt = (Q_in − Q)/A_b`; optional Darcy–Forchheimer filter loss.
  Loss coefficients (`K_entry`, `K_bends`, friction factor) are ESTIMATED.
* **Front kinematics** gravity-biased geodesic arrival cost (Dijkstra, edge cost `dx(1 + β dz)`), cells fill in cost order; cumulative volume `V(t)` fixes arrival times.
* **Velocity/pressure** flux conservation through iso-cost surfaces: `v = Q(t)/A(c)`, `A = dV/dc`, direction `∇c/|∇c|`; pressure `p = p_ch + ρ g (z_b − z) − ½ρv²` (Bernoulli, lumped losses neglected).
* **Thermal during fill** parcel energy balance with latent heat `ρ (D/4) dh/dt = −h_eff (T − T_mold)`, `h_eff` = series(interface contact, semi-infinite shell `√(πt)/e`, melt-side `Nu·k/D`).
* **Indicators** misrun (arrival solid fraction / coherency), cold shut (front confluence × arrival superheat), air entrainment `max(v/v_crit − 1, 0)` with `v_crit = (4 g σ/ρ)^¼` (Campbell-type scaling),
  Re, We, regime, turbulence intensity `0.16 Re^-1/8`.
* **Fluid numbers** `Re = ρvD/μ`, `Pr = μ cp/k` (≈0.08 for liquid Ti — liquid metal), `Nu` laminar 3.66 / Gnielinski (verified: 29.8 vs 29.9 textbook).
* **Validity** gravity-driven, connected cavities, moderate velocities. **Not resolved**: momentum/jetting/splashing, gas back-pressure, surface-tension-driven front dynamics, centrifugal/counter-gravity filling.
* **Extension point** `FillSolver.run() -> FillResult`; a VOF / level-set / SPH / FV-CFD solver can replace it by returning the same fields (`arrival_time`, `T_end`, `snapshot(t)`).
* **Status** mass conservation exact by construction (checked); Torricelli scaling within 15 % (tolerance 30 %); no experimental validation.

## 7. Solidification metrics (`solidification/metrics.py`)
From threshold crossings recorded **inside** the thermal kernel (linear interpolation within the step): `t_liq`, `t_sol`, local solidification time, cooling rate at liquidus/solidus,
`G = |∇T|` at liquidus, front velocity `R = CR/G`, Niyama `Ny = G[K/mm]/√CR[K/s]` at the feeding limit, cooling rate 1000→800 °C, peak T, time above β-transus.
Solidification map classes by `t_sol` tertiles. **Status** `REDUCED-ORDER` (as accurate as the thermal solution).

## 8. Microstructure (`microstructure/model.py`) — `EMPIRICAL` / `QUALITATIVE`
* α fraction: `df/dt = (f_eq(T) − f)/τ(T)` integrated in the thermal kernel; `f_eq = f_max(1 − e^{−(T_β − T)/T_s})`, `τ = τ_ref exp(Q/R(1/T − 1/T_ref))` — all ESTIMATED, not CALPHAD.
* α-lath thickness `d = a·CR^-n` (a = 3 µm, n = 0.45, ESTIMATED, **uncalibrated**). Morphology map (martensite > 410 K/s; massive/basketweave 20–410; Widmanstätten 1–20; colony < 1) from Ahmed & Rack (1998) thresholds.
* Prior-β indicator (time above transus) and columnar tendency `G/R` are `QUALITATIVE`. Yield estimate: Hall–Petch on lath thickness, an indicator only.
* **No metallographic prediction precision is claimed.** Equiaxed-α/transformed-β appears only after a heat treatment that models it (not implemented as a separate class).

## 9. Feeding and shrinkage (`feeding/analysis.py`, `shrinkage/shrinkage.py`) — `REDUCED-ORDER`
Isolated-pool topology on the simulated solidification sequence (§ module docstring). Shrinkage demand `β_s Σ(1 − fs)V`, `β_s = (ρ_s − ρ_l)/ρ_s` from the density table (≈6 % for the tabulated Ti-6Al-4V data),
allocated to the last-freezing cells. Feeding distance = geodesic distance from the nearest feeder; riser indicators = modulus ratio, `t_sol` ratio, volume budget. No Darcy pressure-driven feeding is solved.

## 10. Porosity (`porosity/model.py`)
Micro-shrinkage `1/(1 + (Ny/Ny_c)^p)` (**Ny_c = 1 is ESTIMATED**, EMPIRICAL) capped by the physical bound `β_s(1 − fs_c)`; macro-shrinkage from §9; hydrogen by Scheil enrichment + Sieverts + ideal-gas pore volume;
entrained gas `φ_ref (1 − e^{−index})`. Combined `1 − Π(1 − r_i)`. **No binary defect output.**

## 11. Thermal stress, residual stress (`stress/fe.py`) — `REDUCED-ORDER`
Incremental quasi-static thermo-elastic-plastic voxel FE (trilinear hexahedra, direct sparse LU), eigenstrain `∫α dT` accumulated below `T_rigid` (= solidus), optional transformation strain,
von Mises perfect plasticity with `σ_y(T)`, radial return by fixed-point iteration, temperature-dependent E. **Limitations: no mold/shell restraint, no creep/relaxation above ~600 °C
except through the yield limit, constant ν, no hot-tear criterion.** Verified: free body is stress-free, free contraction equals `ε_th·L` exactly, force equilibrium. Expect the model to **under-predict**
residual stress and distortion of real castings because the mold restraint is missing.

## 12. Distortion (`distortion/model.py`)
Umeyama similarity fit (scale + rotation + translation) of the FE nodal displacements; scale−1 = predicted uniform contraction (pattern shrink allowance), residual = warpage `dx, dy, dz`; local rotation from `∇u`.

## 13. Heat treatment (`heat_treatment/model.py`) — `EMPIRICAL`/ESTIMATED
Zener–Wert–Avrami stress relaxation, LSW lath coarsening, β-excursion reset, α-fraction kinetics, cooling-stress estimate, Norton-creep HIP closure of internal voids (surface-connected voids excluded), Hall–Petch yield indicator.
Uniform furnace temperature (no part thermal lag). All kinetic constants are `estimated`.

## 14. Machining allowance (`machining/allowance.py`)
Final geometry = as-cast part eroded by the allowance (resolved to the cell face); margin = allowance − alpha case − distortion − tolerance. Resolution-limited (≥ one cell).

## 15. Simulated inspection (`inspection/simulate.py`)
Log-normal POD per method on equivalent defect diameter (CT, X-ray, ultrasonic, dye penetrant, visual) + CMM deviation points. **Always SIMULATED**; `is_simulated=True` propagates to every report and CLI output.

## 16. Quality engine (`quality/engine.py`)
Per-criterion `value, unit, review/high-risk thresholds, threshold source, confidence, model`. No aggregate score. Default thresholds are screening defaults, not an acceptance specification.
