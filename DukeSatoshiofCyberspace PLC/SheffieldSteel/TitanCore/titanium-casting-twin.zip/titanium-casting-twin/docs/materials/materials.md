# Materials

Alloys: Ti-6Al-4V, Ti-6242, Ti-6242S, Ti-6246, Ti-5Al-2.5Sn. (The specification lists both "Ti-6242" and "Ti-6Al-2Sn-4Zr-2Mo"; these name the **same** nominal composition, so the second registered variant is the silicon-bearing **Ti-6242S**.)
Properties per alloy: ρ(T), cp(T), k(T), electrical resistivity(T), viscosity(T) (liquid; Krieger–Dougherty in the mush), surface tension(T), E(T), ν(T), σ_y(T), α(T), ε(T), liquidus, solidus, latent heat, β-transus, solid-fraction law, enthalpy (derived).

**Provenance is mandatory** (`estimated`, `literature-derived`, `calibrated`, `user-supplied`) and cannot be omitted. Honest state of the data:
* **Ti-6Al-4V**: 27 % of the entries are `estimated` (viscosity, high-temperature mechanical properties, emissivity); the rest follow published compilations (Mills 2002; Boivineau et al. 2006; ASM) **hand-digitised approximately** — verify against your specification, DSC and supplier data before quantitative use.
* **Ti-6242, 6242S, 6246, 5Al-2.5Sn**: 100 % `estimated` — Ti-6Al-4V tables scaled, with estimated transformation temperatures. They demonstrate the framework; replace with measured data (YAML override: `get_alloy(name, override_dir=...)`).
* The tabulated Ti-6Al-4V densities give a 6 % liquid→solid contraction, larger than some literature values (4–5 %); a direct consequence of the digitised density table.

Database: `materials/database.py` (versioned, YAML import/export, content hash). `Alloy.with_composition_shift` applies **estimated** linear coefficients (Al, V, O, Fe) to the liquidus/solidus/β-transus.
Add alloys with `register_alloy(name, builder)` or a YAML file. Calibrated values (from `calibration/`) carry `kind="calibrated"` and are never mixed with measured data.
