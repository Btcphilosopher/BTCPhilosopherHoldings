# Solver notes

**Thermal kernel** (`thermal/kernel.py`). State per active cell: `Hv` (J/m³), `T`, α-fraction, event arrays. Per step: (1) fluxes for 6 faces (`Kc = 1/(dx/2k_i + R + dx/2k_j)`),
boundary flux on faces bordering void; (2) `Hv += dt·dH`; (3) `T = T(Hv)` by binary search of the monotone material table; (4) event detection (crossing time, cooling rate, |∇T|), peak T, time above β, ∫D_O dt, α-fraction update.
`dt = safety · min_i cap_i/(Σ Kc/dx + Σ h_bnd)`, re-evaluated every 8 steps (`cap = dHv/dT`).

**Quality monitors** NaN/Inf and out-of-range detection every step; energy balance `ΔE + E_lost = 0` (round-off ≈ 1e-14); `fs + fl = 1`; monotone enthalpy tables; fill volume balance (< 1e-6, exact in practice);
solidification-complete flag. Any violation sets `results['conservation']['all_ok'] = False` and a run warning.

**Fill** is a graph algorithm plus a scalar ODE (Δt = 2 ms, explicit). **Stress** is a sparse direct solve per temperature increment (re-assembled because E(T) changes), plasticity by ≤ 12 fixed-point corrections.

**Performance** (single core, 3 GB): bracket, 3 mm voxels, 10.7 k metal / 25 k active cells ⇒ thermal ≈ 3 min for 1540 s of cooling (≈14 k steps), stress ≈ 1 min. Hot spots: the kernel (face loops) and `splu`. Cost scales ~N^(4/3) (explicit stability). For large aerospace castings:
use the compressed graph on a bigger machine, coarsen the stress mesh (`stress.mech_coarsen` is reserved), or swap in a GPU/implicit thermal backend behind `ThermalSolver`.
