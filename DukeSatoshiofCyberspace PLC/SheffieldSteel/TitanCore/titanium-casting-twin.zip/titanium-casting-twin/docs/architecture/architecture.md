# Architecture

```
scenario.yaml ──► simulation.config (Pydantic) ──► simulation.pipeline.run_simulation
                                                       │
 geometry ──► CastingSystem (roles: part/riser/gate/runner/sprue/basin/filter/shell/core)
 materials ─► Alloy (tables + provenance) ─► thermodynamics (enthalpy)
 melt ─► atmosphere ─► flow.fill (REDUCED-ORDER) ─► thermal.solver (Numba, enthalpy FV) ──► digital_twin.engine (step/run/pause/rewind/replay)
                                                                                   │ streams snapshots
                                                                                   ▼
                                                         digital_twin.store (HDF5, resizable, gzip) ◄── fields, stress history, fill snapshots
 solidification · feeding · shrinkage · porosity · microstructure · stress (FE) · distortion · heat_treatment · machining · inspection
 quality.engine ─► criteria      traceability.manifest ─► SimulationManifest
                                                       │
 digital_twin.run_data.RunData ◄── HDF5 ──►  DigitalTwinState / query ("what happened here?") ──► visualization (PyVista, matplotlib) · reporting (HTML/PDF/JSON/CSV) · cli
```

Design rules
* **The physics is the product.** Dashboards, reports, the viewer and the CLI read only from the stored run (`RunData`); none of them computes physics.
* **Single canonical state** `digital_twin.state.DigitalTwinState` (geometry, material, process parameters, time, temperature/velocity/pressure/fill/solid fraction, microstructure, porosity, shrinkage, stress, strain, distortion, inspection, quality indicators, manifest).
* **Solver backends are replaceable** behind small interfaces: `FillSolver.run() -> FillResult`; `ThermalSolver` (state + `advance_to`); `ThermoMechanical.run(T_steps, ...)`. The Numba kernel works on a compressed active-cell graph with explicit neighbour tables, so an unstructured/GPU backend can reuse the domain model.
* **Memory discipline.** The 4-D temperature history is streamed to HDF5 per snapshot (chunked per snapshot); stress selects the rows it needs; 3-D result fields are float32/gzip. Checkpoints (full solver state) are kept in memory every N snapshots for rewind-and-resume.
* **Failure is loud.** NaN/overflow ⇒ `NumericalInstability`; negative or non-monotone enthalpy ⇒ rejected at construction; disconnected gating ⇒ `ConfigurationError`; conservation flags appear in the results and the CLI; nothing swallows these.
* **Optional dependencies** (`pyvista`, `cadquery`, `jax/cupy/dask`) are never imported at package import time. JAX/CuPy/Dask are *not* wired in this version (the Numba backend is the only one implemented); the interfaces above are where they would plug in.

Package map (`src/tct/`): `geometry/` (grid, SDF CSG, mesh validation, casting system, library) · `materials/` (alloys, provenance, phase model, kinetics, database) · `thermal/` (mold, BCs, kernel, solver) · `melt/` · `flow/` ·
`solidification/` · `feeding/` · `shrinkage/` · `porosity/` · `microstructure/` · `stress/` · `distortion/` · `heat_treatment/` · `machining/` · `inspection/` · `quality/` · `uncertainty/` (forward model, sensitivity, DOE, Monte Carlo) · `calibration/` ·
`validation_cases/` · `simulation/` (config, pipeline) · `digital_twin/` (store, engine, state, run_data) · `visualization/` · `reporting/` · `traceability/` · `cli/`.

Note on the specification's layout: `src/tct/thermodynamics/` holds gas/thermo helpers reserved for CALPHAD/Thermo-Calc table import (currently only the package stub; enthalpy utilities live in `materials/thermodynamics.py`).
