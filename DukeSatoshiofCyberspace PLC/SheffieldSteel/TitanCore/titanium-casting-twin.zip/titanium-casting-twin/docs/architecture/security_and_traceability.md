# Security and traceability

**Reproducibility.** Every run writes a `SimulationManifest` (HDF5 attribute and `manifest.json`): simulation ID (`<casting>-<run>`), UTC timestamp, software version, git commit (or `unavailable (not a git checkout)`),
material-database version and content hash (SHA-256 of the full property set including provenance), geometry hash (role array), mesh hash (surface-mesh vertices/faces), full process configuration, solver configuration, random seed, hardware and key dependency versions.
The deterministic pipeline (no hidden randomness; seeded NumPy generators for inspection/Monte Carlo) reproduces results to round-off (tested).

**Honesty controls.** Provenance on every material number; model-status label on every criterion; inspection is always `SIMULATED`; the report lists validation disagreements; no "certification" language; a disclaimer heads every report and dashboard.

**Security notes.** Scenarios are YAML parsed with `yaml.safe_load` and validated by Pydantic; no code is executed from configuration. Mesh/STEP import goes through `trimesh`/`cadquery`: treat untrusted CAD files as untrusted input.
HDF5 files are plain data (no pickles). The package makes no network calls. Run stores are *not* signed or encrypted: if integrity/non-repudiation matters, sign `manifest.json` and the HDF5 file externally (e.g. detached signature of the file hash).
