# User guide

```
pip install -e .[dev,viz]
tct validate scenarios/ti64_aerospace_bracket.yaml --save validation/validation_latest.json
tct simulate scenarios/ti64_aerospace_bracket.yaml --out reports/CAST-2047-018      # ~4-5 min on one core
tct inspect reports/CAST-2047-018/run.h5 --at 30 0 40            # what happened at x=30,y=0,z=40 mm?
tct inspect reports/CAST-2047-018/run.h5 --png view.png --view stress
tct replay  reports/CAST-2047-018/run.h5 --stride 10             # or --viewer for the interactive PyVista twin
tct dashboard reports/CAST-2047-018/run.h5
tct report  reports/CAST-2047-018/run.h5 --validation-json validation/validation_latest.json
tct monte-carlo scenarios/ti64_aerospace_bracket.yaml -n 2000 --mode surrogate --n-train 30
tct sensitivity scenarios/ti64_aerospace_bracket.yaml
tct optimise-riser scenarios/ti64_aerospace_bracket.yaml
tct mesh part.stl --scale 1e-3                                  # geometry validation + voxel domain
```

**Scenario file** sections: `geometry` (bracket | plate | mesh), `mesh` (voxel size, shell thickness), `mold`, `melt` (method-specific inputs), `atmosphere`, `pour`, `thermal`, `stress`, `heat_treatment` (preset hip | stress_relief | beta_anneal | none, or explicit segments ramp/hold/cool/age), `machining`, `inspection`, `quality.overrides` (screening thresholds), `run`, `uncertainty`, `alloy_composition_shift_wt`, `alloy_property_scale`.

**Interactive viewer** `tct replay run.h5 --viewer`: views Geometry / Temperature / Velocity / Fill Fraction / Solid Fraction / Porosity / Microstructure / Stress / Distortion / Inspection; process-time slider scrubs CHARGE→INSPECT; click a point to print the "What happened here?" answer (thermal history, cooling rate, gradient, solidification time, phases, feeding, porosity, stress history, residual stress, distortion, simulated inspection).
*The interactive widgets need a display and could not be exercised in the headless build environment; the off-screen rendering (`tct inspect --png`) and the probe/query logic are tested.* The HTML dashboard (`tct dashboard`) is a self-contained alternative with a scrubbable mid-plane timeline.

**Importing geometry**: STL/OBJ/PLY/VTK through `trimesh` (units via `--scale`); STEP needs the optional `cadquery` package (clear error otherwise). Imported meshes are simulated as **part only** (no gating system, bottom fill) — design the gating in the scenario library for full fill/feeding studies.

**Reading results**: look at the quality criteria table first — status uses *screening* thresholds and every row carries confidence and model. Then use `inspect --at` on the regions flagged. Treat everything as risk indicators until calibrated.
