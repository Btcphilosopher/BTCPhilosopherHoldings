# Validation and verification

`tct validate scenario.yaml` validates the configuration and geometry and runs the verification suite (`validation_cases/analytic.py`). Every row reports prediction, reference, absolute and relative error, tolerance and status.

| case | result |
|---|---|
| semi-infinite conduction (erfc) | normalised max error 8e-4 (tol 2e-2) |
| Stefan/Neumann solidification front, 4 K freezing range | 0.15 % error (tol 3 %) |
| Stefan front, **1 K** freezing range | **13 % — DISAGREES; documented known limitation** (1 K enthalpy table under-resolves the latent heat; solver warns) |
| lumped radiative cooling | 0.15 % (tol 1 %) |
| energy conservation with latent heat | 2e-14 |
| Gnielinski Nu(Re=1e4, Pr=0.7) | 29.8 vs 29.9 |
| Torricelli-type outflow | 15 % (tol 30 %, loose by construction) |
| FE free contraction / free-body stress-free / force equilibrium | round-off |
| Chvorinov exponent (`--full`, informational) | n ≈ 1.6 vs 2: expected for a thin radiating shell (interface-controlled) |

**These are verification cases, not validation against foundry experiments.** No experimental titanium casting dataset was available. The framework for it exists: `validation_cases.analytic.compare_to_data` (always reports disagreement),
`calibration/fit.py` (least squares + Metropolis; calibrated values are tagged `calibrated`), and `tct report` (lists every validation row). Until you supply thermocouple, radiography, metallography and dimensional data,
**no model output should be treated as validated**; the confidence labels in the quality criteria say `LOW` for exactly that reason.

Test suite: `pytest` (unit, numerical convergence, conservation, system, regression). Regression baseline: `tests/regression_baseline.json` (regenerate only deliberately with `tests/make_baseline.py`).
