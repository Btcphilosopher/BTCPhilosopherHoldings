# Uncertainty, sensitivity, DOE, calibration

* **Sensitivity** (`tct sensitivity`): central finite differences of the **full pipeline** on a coarse grid (6 mm). Effects are calculated, never hard-coded. Coarse-grid sensitivities are indicative; re-run on the production grid for decisions.
* **DOE** (`uncertainty/doe.py`): Latin hypercube, factorial, Sobol sequence, Monte Carlo designs; quadratic response surfaces with leave-one-out R²; standardised main effects; two-factor interaction effects; Sobol indices from the surrogate (quote R² with them).
* **Monte Carlo** (`tct monte-carlo`): inputs declared in the scenario (`uncertainty.parameters`: pour temperature, mold temperature, contact conductance, pour rate, surroundings/cooling, property scaling, composition shift, geometry parameters, vacuum level).
  `direct` mode = N full coarse-grid runs (N ≈ 100–300 feasible on one core). `surrogate` mode (default for N = 1000–10 000) = quadratic response surface trained on a Latin-hypercube set; the output is labelled SURROGATE-BASED and reports train/LOO R².
  Output: mean, standard deviation, percentiles, Spearman sensitivities. **"Probability of failure" is computed only if the scenario defines an explicit `failure_criterion`**; otherwise the report states that it is not computed.
* **Calibration** (`calibration/fit.py`): least squares (with Jacobian covariance) and random-walk Metropolis; `calibrate_scenario_parameters` calibrates scenario parameters against measured scalar responses using the full model. Calibrated parameters are returned as `ScalarProperty(kind="calibrated")`.
* **Caveat** all distributions in the shipped scenario are illustrative, not measured process capability.
