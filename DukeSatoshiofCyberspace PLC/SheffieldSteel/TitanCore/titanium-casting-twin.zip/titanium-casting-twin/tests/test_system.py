import json, numpy as np, pytest, pathlib
from tct.digital_twin.run_data import RunData, format_query
from tct.digital_twin.engine import TimeSeriesEngine
from tct.digital_twin.store import RunStore
from tct.quality.engine import Criterion, evaluate
from tct.uncertainty import doe as D, monte_carlo as MC, forward as F
from tct.calibration import fit as C
from tct.simulation.config import load_scenario, with_overrides, Scenario
from tct.errors import ConfigurationError
from .conftest import coupon_scenario, ROOT

pytestmark = pytest.mark.slow

def test_complete_simulation_conserves_and_completes(coupon_run):
    c = coupon_run.results["conservation"]
    assert c["all_ok"] and c["energy_balance_rel_error"] < 1e-9 and c["fill_volume_rel_error"] < 1e-9
    assert coupon_run.results["solidification"]["solidification_complete"]

def test_every_stage_present_in_results(coupon_run):
    for k in ("melt", "contamination", "fill", "solidification", "feeding", "porosity", "microstructure", "stress", "distortion", "heat_treatment", "machining", "inspection", "conservation"):
        assert k in coupon_run.results
    assert [s["name"] for s in coupon_run.timeline] == ["CHARGE", "MELT", "SUPERHEAT", "POUR", "FILL", "SOLIDIFICATION", "COOL", "HEAT TREAT", "INSPECT"]

def test_quality_engine_exposes_all_fields_and_no_score(coupon_run):
    assert len(coupon_run.criteria) >= 12
    for c in coupon_run.criteria:
        d = c.to_dict()
        for k in ("value", "unit", "review_threshold", "high_risk_threshold", "source", "confidence", "model", "status"): assert k in d
    assert not any("score" in c.name for c in coupon_run.criteria)

def test_inspection_is_labelled_simulated(coupon_run):
    s = coupon_run.results["inspection"]["summary"]
    assert s["is_simulated"] is True and "SIMULATED" in s["label"]
    assert all(i["simulated"] for i in coupon_run.results["inspection"]["indications"])

def test_physical_sanity(coupon_run):
    r = coupon_run.results
    assert 0 < r["fill"]["fill_time_s"] < 20 and r["solidification"]["solidification_time_part_max_s"] > 5
    assert 0.5 < r["solidification"]["cooling_rate_beta_min_part"] < 100
    assert abs(r["stress"]["linear_thermal_contraction"] - 0.0145) < 0.004
    assert r["heat_treatment"]["relaxation_factor"] < 0.01 or r["heat_treatment"]["residual_vm_after_ht_max_MPa"] < r["stress"]["vm_max_part_MPa"] + 1

def test_store_roundtrip_and_query(coupon_run):
    with RunData(coupon_run.path) as r:
        assert r.manifest["simulation_id"] == coupon_run.manifest.simulation_id
        q = r.query([0.0, 0.0, 0.01]); txt = format_query(q)
        for key in ("FILL", "THERMAL", "PHASES", "FEEDING", "POROSITY", "STRESS", "DISTORTION", "INSPECTION"): assert key in txt
        T = np.array(q["thermal"]["T_C"]); assert T[0] > T[-1] and np.all(np.isfinite(T))
        st = r.state_at(r.timeline[5]["t0"] + 5.0); assert st.stage == "SOLIDIFICATION" and np.isfinite(st.temperature_field).any()
        assert r.state_at(r.timeline[4]["t0"] + 0.1).stage == "FILL"

def test_manifest_complete(coupon_run):
    m = coupon_run.manifest.to_dict()
    for k in ("simulation_id", "timestamp_utc", "software_version", "git_commit", "material_database_version", "material_hash", "geometry_hash", "mesh_hash",
              "process_configuration", "solver_configuration", "random_seed", "hardware"): assert m[k] not in (None, "")

def test_reproducible_with_same_seed(coupon_run, tmp_path):
    from tct.simulation.pipeline import run_simulation
    r2 = run_simulation(coupon_scenario(), output_path=str(tmp_path / "r2.h5"))
    assert r2.manifest.geometry_hash == coupon_run.manifest.geometry_hash and r2.manifest.material_hash == coupon_run.manifest.material_hash
    for k in ("fill", "solidification", "porosity"):
        for kk, v in coupon_run.results[k].items():
            if isinstance(v, float): assert r2.results[k][kk] == pytest.approx(v, rel=1e-9, abs=1e-12)

def test_regression_baseline(coupon_run):
    base = json.loads((ROOT / "tests" / "regression_baseline.json").read_text()); r = coupon_run.results
    cur = {"fill_time_s": r["fill"]["fill_time_s"], "solidification_time_part_max_s": r["solidification"]["solidification_time_part_max_s"],
           "cooling_rate_beta_min_part": r["solidification"]["cooling_rate_beta_min_part"], "porosity_risk_mean_part": r["porosity"]["porosity_risk_mean_part"],
           "vm_max_part_MPa": r["stress"]["vm_max_part_MPa"], "max_warpage_m": r["distortion"]["max_warpage_m"], "isolated_part_volume_fraction": r["feeding"]["isolated_part_volume_fraction"],
           "lath_thickness_um_mean_part": r["microstructure"]["lath_thickness_um_mean_part"], "stock_removal_volume_m3": r["machining"]["stock_removal_volume_m3"]}
    for k, v in base.items(): assert cur[k] == pytest.approx(v, rel=2e-4, abs=1e-12), f"physical output {k} changed: {cur[k]} vs baseline {v}"

def test_engine_rewind_resume_deterministic(tmp_path, ti64):
    from tct.geometry.library import plate_casting
    from tct.thermal.solver import ThermalSolver
    from tct.thermal.boundary import BoundaryCondition
    cs = plate_casting(dx_m=8e-3, shell_thickness_m=8e-3)
    s = ThermalSolver(cs, ti64, T_metal_C=1750., T_mold0_C=850., bcs=[BoundaryCondition("radiation", surrounding_temperature_C=100.)])
    st = RunStore(tmp_path / "e.h5"); eng = TimeSeriesEngine(s, st, growth=0.2, min_dt=1.0, t_max=60.0, stop_T_C=100.0, checkpoint_every=3)
    for _ in range(6): eng.step()
    n_before = st.n_history; T_ref = st.read_T(n_before - 1).copy()
    eng.pause(); assert eng.rewind(eng.store.times()[2]) == 2
    eng.restart_from(n_before - 1); assert st.n_history == n_before and np.array_equal(st.read_T(n_before - 1), T_ref)
    eng.run(); assert eng.finished and st.n_history > n_before
    frames = list(eng.replay(0, None, 4)); assert frames[0][0] == 0.0 and len(frames) >= 2
    st.close()

def test_monte_carlo_no_probability_without_criterion():
    scn = load_scenario(ROOT / "scenarios" / "ti64_aerospace_bracket.yaml")
    assert MC.failure_probability(np.array([1.0]), None)["computed"] is False
    crit = scn.uncertainty.failure_criterion
    fp = MC.failure_probability(np.array([0.01, 0.1, 0.2, 0.0]), crit); assert fp["computed"] and fp["probability"] == 0.5
    with pytest.raises(ConfigurationError): MC.run_monte_carlo(with_overrides(scn, {"uncertainty.parameters": []}), n=10)

def test_monte_carlo_surrogate_small(tmp_path):
    scn = with_overrides(coupon_scenario(8.0), {"uncertainty.parameters": [
        {"path": "pour.pour_temperature_C", "dist": "normal", "mean": 1800.0, "std": 15.0},
        {"path": "mold.preheat_C", "dist": "normal", "mean": 400.0, "std": 30.0}],
        "uncertainty.failure_criterion": {"metric": "solidification_time_s", "op": ">", "threshold": 40.0}})
    res = MC.run_monte_carlo(scn, n=2000, mode="surrogate", n_train=10, responses=("solidification_time_s", "fill_time_s"), dx_mm=8.0)
    d = res["responses"]["solidification_time_s"]; assert d["std"] > 0 and d["percentiles"]["p5"] < d["percentiles"]["p95"]
    assert res["failure_probability"]["computed"] and "SURROGATE" in res["label"] and "surrogate" in res
    assert d["spearman_sensitivity"]["pour.pour_temperature_C"] > 0                      # hotter pour -> longer solidification

def test_sensitivity_values_come_from_model():
    from tct.uncertainty.sensitivity import one_at_a_time
    scn = coupon_scenario(8.0)
    res = one_at_a_time(scn, {"pour.pour_temperature_C": (20.0, "C"), "mold.preheat_C": (50.0, "C")}, ("solidification_time_s", "fill_time_s"), dx_mm=8.0)
    row = {r["parameter"]: r for r in res["rows"]}
    assert row["pour.pour_temperature_C"]["effects"]["solidification_time_s"]["change"] > 0
    assert row["mold.preheat_C"]["effects"]["solidification_time_s"]["change"] > 0

def test_config_validation_errors():
    with pytest.raises(Exception): Scenario(mesh={"dx_mm": -1})
    with pytest.raises(ConfigurationError): load_scenario("does_not_exist.yaml")
    with pytest.raises(ConfigurationError): with_overrides(Scenario(), {"pour.nonexistent": 1})
