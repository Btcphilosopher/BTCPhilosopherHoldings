import numpy as np, pytest
from tct.geometry.library import plate_casting
from tct.thermal.solver import ThermalSolver, SolverConfig
from tct.thermal.boundary import BoundaryCondition, compile_boundary
from tct.thermal import mold as M
from tct.errors import ConfigurationError, NumericalInstability
from tct.validation_cases import analytic as V

def test_radiation_bc_validates():
    with pytest.raises(ConfigurationError): BoundaryCondition("radiation").validate()
    with pytest.raises(ConfigurationError): BoundaryCondition("radiation", emissivity=1.5, surrounding_temperature_C=20).validate()
    with pytest.raises(ConfigurationError): BoundaryCondition("convection", h_W_m2K=-1, ambient_temperature_C=20).validate()
    with pytest.raises(ConfigurationError): BoundaryCondition("teleport").validate()

def test_vacuum_removes_convection():
    bcs = [BoundaryCondition("radiation", 0.8, 100.0), BoundaryCondition("convection", h_W_m2K=15.0, ambient_temperature_C=20.0)]
    assert compile_boundary(bcs, vacuum=True)[2][0] == 0.0 and compile_boundary(bcs, vacuum=False)[2][0] == 15.0

def test_radiation_law_matches_lumped_ode():
    r = V.radiative_cooling(); assert r.passed, r

def test_semi_infinite_conduction_analytic():
    r = V.semi_infinite_conduction(); assert r.passed, r

def test_stefan_front_analytic():
    rows = V.stefan_front(); assert rows[0].passed, rows[0]
    assert not rows[1].passed and rows[1].kind == "known-limitation"      # documented, honest disagreement

def test_energy_conservation_to_roundoff():
    r = V.energy_conservation_plate(); assert r.abs_error < 1e-10

def test_narrow_freezing_range_warns():
    a = V._const_alloy(TL=1600.5, TS=1599.5); cs = V._bar_cs(10, 1e-3)
    s = ThermalSolver(cs, a, T_metal_C=1600.5, bcs=[BoundaryCondition("adiabatic")], thresholds_C=[1600.0])
    assert any("under-resolved" in w for w in s.warnings)

def test_mold_presets_have_estimated_provenance():
    for k, f in M.PRESETS.items(): assert f().provenance.kind == "estimated"

def test_instability_is_never_silent(ti64):
    cs = plate_casting(dx_m=6e-3, shell_thickness_m=8e-3)
    s = ThermalSolver(cs, ti64, T_metal_C=1750.0, bcs=[BoundaryCondition("radiation", surrounding_temperature_C=100.0)])
    s.T[0] = np.nan
    with pytest.raises(NumericalInstability): s.check_numerics()

def test_nonmonotone_enthalpy_rejected(ti64):
    # an absurd mold with negative specific heat must be rejected at construction
    import dataclasses
    from tct.materials.properties import table
    bad = dataclasses.replace(M.ceramic_shell(), specific_heat=table("cp", "J/kgK", [(0, -10.0), (2300, -10.0)], "user-supplied", "bad"))
    cs = plate_casting(dx_m=8e-3, shell_thickness_m=8e-3)
    with pytest.raises(NumericalInstability): ThermalSolver(cs, ti64, mold=bad)

def test_time_step_convergence(ti64):
    def ts(safety):
        cs = plate_casting(0.016, 0.06, 0.04, 4e-3, 8e-3)
        s = ThermalSolver(cs, ti64, T_metal_C=1750., T_mold0_C=850., bcs=[BoundaryCondition("radiation", surrounding_temperature_C=100.)],
                          thresholds_C=[ti64.T_liquidus_C, ti64.T_solidus_C], config=SolverConfig(safety=safety))
        t = 0
        while np.isnan(s.t_cross[1][s.is_metal]).any(): t += 10; s.advance_to(t)
        return float(np.nanmax(s.t_cross[1][s.is_metal]))
    a, b, c = ts(0.45), ts(0.2), ts(0.1)
    assert abs(a - b) > abs(b - c) * 0.9 and abs(a - c) / c < 0.01

def test_mesh_convergence(ti64):
    def ts(dx):
        cs = plate_casting(0.016, 0.06, 0.04, dx, 8e-3)
        s = ThermalSolver(cs, ti64, T_metal_C=1750., T_mold0_C=850., bcs=[BoundaryCondition("radiation", surrounding_temperature_C=100.)],
                          thresholds_C=[ti64.T_liquidus_C, ti64.T_solidus_C])
        t = 0
        while np.isnan(s.t_cross[1][s.is_metal]).any(): t += 10; s.advance_to(t)
        return float(np.nanmax(s.t_cross[1][s.is_metal]))
    t8, t4, t2 = ts(8e-3), ts(4e-3), ts(2.67e-3)
    assert abs(t4 - t2) < abs(t8 - t4)                      # successive refinements get closer

def test_checkpoint_restore_is_deterministic(ti64):
    cs = plate_casting(dx_m=6e-3, shell_thickness_m=8e-3)
    s = ThermalSolver(cs, ti64, T_metal_C=1750., T_mold0_C=850., bcs=[BoundaryCondition("radiation", surrounding_temperature_C=100.)])
    s.advance_to(5.0); ck = s.checkpoint(); s.advance_to(20.0); T1 = s.T.copy()
    s.restore(ck); s.advance_to(20.0); assert np.array_equal(T1, s.T)
