import numpy as np, pytest, yaml
from tct.materials.database import get_alloy, list_alloys, dump_yaml, load_yaml, alloy_hash
from tct.materials.properties import Provenance, TabulatedProperty, table
from tct.materials.alloy import T_GRID_C

def test_all_alloys_present():
    for n in ("Ti-6Al-4V", "Ti-6242", "Ti-6246", "Ti-5Al-2.5Sn", "Ti-6242S"): assert n in list_alloys()

def test_every_property_has_provenance(ti64):
    for name, kind, src in ti64.provenance_report():
        assert kind in ("literature-derived", "estimated", "calibrated", "user-supplied") and src

def test_provenance_cannot_be_invented():
    with pytest.raises(ValueError): Provenance("measured-i-promise", "x")

def test_table_clamps_and_validates():
    t = table("k", "W/mK", [(0, 1.0), (100, 3.0)], "estimated", "t")
    assert t(-50) == 1.0 and t(500) == 3.0 and t(50) == pytest.approx(2.0)
    with pytest.raises(ValueError): table("bad", "-", [(10, 1), (5, 2)], "estimated", "t")

def test_derived_alloys_flagged_estimated():
    for n in ("Ti-6242", "Ti-6246", "Ti-5Al-2.5Sn", "Ti-6242S"):
        assert get_alloy(n).fraction_estimated() == pytest.approx(1.0)

def test_enthalpy_monotone_and_latent_heat(ti64):
    h = ti64.enthalpy_table_J_kg(); assert np.all(np.diff(h) > 0)
    jump = ti64.specific_enthalpy_J_kg(ti64.T_liquidus_C) - ti64.specific_enthalpy_J_kg(ti64.T_solidus_C)
    assert jump > ti64.L_J_kg                      # latent + sensible across the freezing range
    assert jump == pytest.approx(ti64.L_J_kg + 50 * 850, rel=0.1)

def test_enthalpy_inverse_roundtrip(ti64):
    T = np.array([25.0, 700.0, 1620.0, 1640.0, 1800.0])
    assert ti64.T_from_specific_enthalpy(ti64.specific_enthalpy_J_kg(T)) == pytest.approx(T, abs=1.1)

def test_phase_fractions_sum_to_one(ti64):
    T = np.linspace(1500, 1800, 301); fs = ti64.solid_fraction(T)
    assert np.all((fs >= 0) & (fs <= 1)) and np.allclose((1 - fs) + fs, 1.0)
    assert fs[0] == 1.0 and fs[-1] == 0.0

def test_alpha_fraction_model(ti64):
    pm = ti64.phase_model()
    assert pm.f_alpha_eq(1100.0) == 0.0 and 0.2 < pm.f_alpha_eq(950.0) < 0.4 and pm.f_alpha_eq(20.0) > 0.9
    assert pm.provenance.kind == "estimated"

def test_solidification_shrinkage_physical(ti64):
    b = ti64.volumetric_solidification_shrinkage(); assert 0.03 < b < 0.08

def test_thermal_strain_sign_and_magnitude(ti64):
    e = float(ti64.thermal_strain(25.0, 1605.0)); assert -0.02 < e < -0.012

def test_composition_shift_moves_transus(ti64):
    s = ti64.with_composition_shift({"Al": 0.5}); assert s.T_beta_C == pytest.approx(ti64.T_beta_C + 12.5)
    assert s.beta_transus.provenance.kind == "estimated"

def test_yaml_roundtrip(tmp_path, ti64):
    p = tmp_path / "a.yaml"; dump_yaml(ti64, p); assert alloy_hash(load_yaml(p)) == alloy_hash(ti64)

def test_mushy_viscosity_diverges(ti64):
    assert ti64.apparent_viscosity_Pa_s(1620.0) > 5 * ti64.apparent_viscosity_Pa_s(1700.0)
