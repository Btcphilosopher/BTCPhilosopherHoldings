import numpy as np, pytest, trimesh
from tct.geometry import validation as GV
from tct.geometry.library import build_bracket, bracket_cad_geometry, plate_casting
from tct.geometry.geometry import Geometry
from tct.geometry.casting_system import PART, RISER, GATE, RUNNER, SPRUE, BASIN
from tct.errors import MissingOptionalDependency, ConfigurationError
from tct.flow import fluid as F
from tct.flow.fill import FillSolver, PourConfig

def test_cad_mesh_validates():
    rep, mesh = bracket_cad_geometry().validate(None, pitch_m=2.5e-3)
    assert rep.ok and rep.n_components == 1 and rep.self_intersecting_pairs == 0

def test_validation_detects_holes_inversion_and_components():
    box = trimesh.creation.box((1, 1, 1))
    holed = trimesh.Trimesh(box.vertices, box.faces[:-2], process=False)
    r = GV.validate_mesh(holed); assert not r.watertight and r.open_boundary_edges > 0 and not r.ok
    inv = box.copy(); inv.invert(); r2 = GV.validate_mesh(inv); assert r2.inverted and not r2.ok
    two = trimesh.util.concatenate([box, box.copy().apply_translation([5, 0, 0])]); assert GV.validate_mesh(two).n_components == 2

def test_validation_detects_self_intersection():
    a = trimesh.creation.box((1, 1, 1)); b = trimesh.creation.box((1, 1, 1)); b.apply_translation([0.5, 0.3, 0.2])
    m = trimesh.util.concatenate([a, b]); assert GV.count_self_intersections(m) > 0
    assert GV.count_self_intersections(a) == 0

def test_thin_wall_detection():
    m = np.zeros((30, 30, 30), bool); m[5:25, 5:25, 5:25] = True; m[:, :, 14] = m[:, :, 14]
    thin = np.zeros_like(m); thin[2:28, 2:28, 10:12] = True
    tmin, n, _ = GV.thickness_report(thin, 1e-3, min_wall_m=5e-3); assert n > 0 and tmin < 5e-3

def test_step_requires_optional_dependency():
    try:
        import cadquery  # noqa
    except Exception:
        with pytest.raises(MissingOptionalDependency): Geometry.from_step("x.step")

def test_mesh_file_roundtrip(tmp_path):
    p = tmp_path / "b.stl"; trimesh.creation.box((0.02, 0.02, 0.02)).export(p)
    g = Geometry.from_mesh_file(p, 1.0); rep, _ = g.validate(); assert rep.ok

def test_casting_system_relationships(bracket_cs):
    cs = bracket_cs
    for r in (PART, RISER, GATE, RUNNER, SPRUE, BASIN): assert cs.mask(r).any()
    assert cs.volume_m3(PART) > 0 and cs.modulus_m(RISER) > 0.9 * cs.modulus_m(PART)
    assert (cs.mold.sum() > 0) and not (cs.metal & cs.mold).any()

def test_nusselt_reference_values():
    assert float(F.nusselt(1000.0, 0.7)) == pytest.approx(3.66)
    assert float(F.nusselt(1e4, 0.7)) == pytest.approx(29.9, rel=0.03)

def test_flow_regime_and_critical_velocity(ti64):
    assert list(F.flow_regime([1000, 3000, 9000])) == [0, 1, 2]
    p = F.fluid_props(ti64, 1700.0); vc = F.critical_velocity_m_s(p["sigma"], p["rho"]); assert 0.2 < float(vc) < 0.6
    Pr = float(F.prandtl(p["mu"], p["cp"], p["k"])); assert 0.02 < Pr < 0.2     # liquid metals: Pr << 1

def test_fill_mass_conservation_and_monotone_arrival(bracket_cs, ti64):
    r = FillSolver(bracket_cs, ti64, PourConfig(pour_temperature_C=1800.0, pour_rate_kg_s=0.5)).run()
    assert r.checks["volume_conservation_rel_err"] < 1e-9 and r.checks["arrival_monotone_with_cost"]
    assert 0.2 < r.fill_time_s < 30 and np.all(np.diff(r.V_hist) >= 0)
    s = r.snapshot(0.5 * r.fill_time_s); assert 0 < (s["fill_fraction"] >= 0.5).mean() < 1

def test_fill_flux_conservation_through_isocost_surfaces(bracket_cs, ti64):
    r = FillSolver(bracket_cs, ti64, PourConfig(pour_temperature_C=1800.0, pour_rate_kg_s=0.5)).run()
    # v = Q / A(c) with A = dV/dc: the product v*A is the (constant) flow rate by construction
    assert np.all(r.speed_scale > 0) and np.isfinite(r.speed_scale).all()

def test_fill_raises_on_disconnected_cavity(ti64):
    from tct.geometry.sdf import Box
    from tct.geometry.casting_system import build_casting_system
    def box(c, h): b = Box(c, h); b.bbox_m = (np.array(c) - h, np.array(c) + h); return b
    cs = build_casting_system({"part": box((0, 0, 0.03), (0.01,) * 3), "sprue": box((0.1, 0, 0.06), (0.01, 0.01, 0.03)),
                               "basin": box((0.1, 0, 0.1), (0.02, 0.02, 0.01))}, 4e-3, 6e-3)
    with pytest.raises(ConfigurationError): FillSolver(cs, ti64, PourConfig(pour_rate_kg_s=None)).run()

def test_higher_superheat_reduces_misrun(bracket_cs, ti64):
    lo = FillSolver(bracket_cs, ti64, PourConfig(pour_temperature_C=1700.0, pour_rate_kg_s=0.5)).run().risks["misrun_risk"].mean()
    hi = FillSolver(bracket_cs, ti64, PourConfig(pour_temperature_C=1850.0, pour_rate_kg_s=0.5)).run().risks["misrun_risk"].mean()
    assert hi <= lo
