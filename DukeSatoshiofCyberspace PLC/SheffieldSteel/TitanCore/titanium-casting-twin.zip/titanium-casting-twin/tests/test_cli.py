import json, pathlib, yaml, pytest, trimesh
from click.testing import CliRunner
from tct.cli.main import main
from .conftest import ROOT

pytestmark = pytest.mark.slow

@pytest.fixture(scope="module")
def cli_run(tmp_path_factory):
    d = tmp_path_factory.mktemp("cli"); sc = yaml.safe_load((ROOT / "scenarios" / "ti6246_plate_coupon.yaml").read_text())
    sc["mesh"]["dx_mm"] = 8.0; sc["stress"]["n_steps"] = 4; sc["machining"]["allowance_mm"] = 4.0
    p = d / "s.yaml"; p.write_text(yaml.safe_dump(sc)); out = d / "out"
    r = CliRunner().invoke(main, ["simulate", str(p), "--out", str(out), "--quiet"])
    return r, p, out

def test_simulate_prints_summary(cli_run):
    r, p, out = cli_run
    assert r.exit_code == 0, r.output
    for k in ("Simulation complete", "Run: COUPON-0001-001", "Mesh:", "Fill:", "Solidification: COMPLETE", "Feeding:", "Porosity indicator:", "Residual stress:", "Distortion:", "SIMULATED"):
        assert k in r.output
    assert (out / "run.h5").exists() and (out / "manifest.json").exists()

def test_inspect_probe_and_png(cli_run, tmp_path):
    r, p, out = cli_run
    png = tmp_path / "v.png"
    res = CliRunner().invoke(main, ["inspect", str(out / "run.h5"), "--at", "0", "0", "10", "--png", str(png), "--view", "porosity"])
    assert res.exit_code == 0, res.output
    assert "WHAT HAPPENED HERE?" in res.output and png.exists() and png.stat().st_size > 1000

def test_replay_and_dashboard_and_report(cli_run, tmp_path):
    r, p, out = cli_run
    assert "snapshot" in CliRunner().invoke(main, ["replay", str(out / "run.h5"), "--stride", "20"]).output
    d = CliRunner().invoke(main, ["dashboard", str(out / "run.h5"), "--out", str(tmp_path / "d.html")]); assert d.exit_code == 0
    html = (tmp_path / "d.html").read_text(); assert "TITANIUM CASTING DIGITAL TWIN" in html and "SIMULATED" in html
    val = tmp_path / "val.json"
    from tct.validation_cases import analytic as V
    val.write_text(json.dumps([V.radiative_cooling().to_dict()]))
    rep = CliRunner().invoke(main, ["report", str(out / "run.h5"), "--out", str(tmp_path / "rep"), "--validation-json", str(val)])
    assert rep.exit_code == 0, rep.output
    for ext in ("html", "pdf", "json", "csv"): assert list((tmp_path / "rep").glob(f"*.{ext}")), ext
    j = json.loads(next((tmp_path / "rep").glob("*.json")).read_text()); assert "disclaimer" in j and j["validation"]

def test_mesh_command_and_step_error(tmp_path):
    stl = tmp_path / "b.stl"; trimesh.creation.box((20, 20, 20)).export(stl)
    r = CliRunner().invoke(main, ["mesh", str(stl), "--dx-mm", "4"]); assert r.exit_code == 0 and "mesh valid" in r.output
    step = tmp_path / "x.step"; step.write_text("ISO-10303-21;")
    try:
        import cadquery  # noqa
    except Exception:
        r2 = CliRunner().invoke(main, ["mesh", str(step)]); assert r2.exit_code == 2 and "cadquery" in r2.output

def test_validate_rejects_bad_config(tmp_path):
    p = tmp_path / "bad.yaml"; p.write_text("mesh: {dx_mm: -3}\n")
    r = CliRunner().invoke(main, ["validate", str(p)]); assert r.exit_code == 2 and "INVALID" in r.output
