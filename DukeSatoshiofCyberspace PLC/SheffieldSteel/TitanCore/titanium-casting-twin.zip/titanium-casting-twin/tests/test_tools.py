import numpy as np, pytest
from tct.uncertainty import doe as D
from tct.calibration import fit as C
from tct.inspection import simulate as I
from tct.machining import allowance as M
from tct.quality.engine import Criterion
from tct.validation_cases import analytic as V
from tct.geometry.casting_system import PART

def test_doe_designs_cover_bounds():
    b = [(0, 1), (10, 20)]
    for kind in ("latin_hypercube", "sobol", "monte_carlo"):
        X = D.design(kind, b, 32, 1); assert X.shape == (32, 2) and X[:, 1].min() >= 10 and X[:, 1].max() <= 20
    assert D.design("factorial", b, levels=3).shape == (9, 2)

def test_response_surface_recovers_quadratic_and_interactions():
    X = D.design("latin_hypercube", [(0, 1)] * 3, 60, 0); y = 3 * X[:, 0] + X[:, 1] ** 2 + 2 * X[:, 0] * X[:, 2]
    rs = D.ResponseSurface([(0, 1)] * 3).fit(X, y); assert rs.r2 > 0.999 and rs.loo_r2(X, y) > 0.99
    assert D.main_effects(rs, "abc")["a"] == pytest.approx(4.0, rel=1e-6)
    assert D.interaction_effects(rs, "abc")["a x c"] == pytest.approx(0.5, rel=1e-6)
    S1, ST = D.sobol_indices(rs, 4096); assert np.argmax(S1) == 0 and all(t >= s - 0.05 for s, t in zip(S1, ST))
    assert D.influence("abc", X, y)[0][0] == "a"

def test_least_squares_calibration_recovers_emissivity():
    t = np.linspace(5, 200, 25); y = C.lumped_cooling_model([0.55], t) + np.random.default_rng(1).normal(0, 2.0, 25)
    r = C.least_squares_calibrate(C.lumped_cooling_model, ["emissivity"], [0.3], [(0.05, 1.0)], t, y, sigma=2.0)
    assert r.values[0] == pytest.approx(0.55, abs=0.01) and r.std[0] < 0.01
    p = r.as_properties(["-"], "synthetic")[0]; assert p.provenance.kind == "calibrated"          # never confused with measured data

def test_bayesian_calibration_posterior_contains_truth():
    t = np.linspace(5, 200, 25); y = C.lumped_cooling_model([0.55], t) + np.random.default_rng(2).normal(0, 2.0, 25)
    b = C.bayesian_calibrate(C.lumped_cooling_model, ["emissivity"], [0.4], [0.2], t, y, 2.0, n_steps=1500, burn=300, seed=3)
    assert abs(b.values[0] - 0.55) < 4 * max(b.std[0], 1e-3) + 0.01

def test_inspection_pod_monotone_and_surface_rules(bracket_cs):
    cs = bracket_cs; part = cs.mask(PART); void = np.zeros(cs.grid.shape); idx = np.argwhere(part)
    c = idx[len(idx) // 2]; void[c[0] - 1:c[0] + 2, c[1] - 1:c[1] + 2, c[2] - 1:c[2] + 2] = 0.5
    res = I.simulate(cs, void, void, void * 0, void * 0, I.InspectionConfig(seed=1))
    ind = res["indications"][0]; assert ind["pod_ct"] >= ind["pod_dye_penetrant"]
    big = void.copy(); big[c[0] - 2:c[0] + 3, c[1] - 2:c[1] + 3, c[2] - 2:c[2] + 3] = 0.8
    assert I.simulate(cs, big, big, big * 0, big * 0)["indications"][0]["pod_ct"] >= ind["pod_ct"]
    assert res["summary"]["is_simulated"]

def test_machining_margin(bracket_cs):
    cs = bracket_cs; ac = np.where(cs.metal, 0.2e-3, np.nan); dm = np.where(cs.metal, 0.1e-3, np.nan)
    f, sc = M.compute(cs, 1.0e-3, ac, dm, 0.1e-3); assert sc["min_margin_m"] == pytest.approx(0.6e-3, abs=1e-9)   # 1.0 allowance - 0.2 alpha case - 0.1 distortion - 0.1 tolerance and sc["stock_removal_volume_m3"] > 0
    f2, sc2 = M.compute(cs, 0.2e-3, ac, dm, 0.0); assert sc2["min_margin_m"] < 0

def test_quality_status_semantics():
    c = Criterion("x", 0.4, "-", 0.3, 0.6, "s", "LOW", "m"); assert c.status == "REVIEW"
    assert Criterion("x", 0.2, "-", 0.3, 0.6, "s", "LOW", "m").status == "PASS" and Criterion("x", 0.9, "-", 0.3, 0.6, "s", "LOW", "m").status == "HIGH-RISK"
    assert Criterion("m", -0.1, "mm", 0.0, -0.5, "s", "LOW", "m", higher_is_better=True).status == "REVIEW"
    assert Criterion("x", None, "-", 0, 1, "s", "LOW", "m").status == "NOT-EVALUATED"

def test_compare_to_data_reports_disagreement():
    row = V.compare_to_data("TC1", "t_sol [s]", 50.0, 70.0, 0.1); assert not row.passed and row.rel_error == pytest.approx(20 / 70)


def test_response_surface_does_not_overfit_small_designs():
    rng = np.random.default_rng(0); X = D.design("latin_hypercube", [(0, 1)] * 7, 28, 0); y = X[:, 0] + rng.normal(0, 0.3, 28)     # mostly noise
    rs = D.ResponseSurface([(0, 1)] * 7).fit(X, y)
    assert not rs.inter and rs.n_features <= 28 - 3                                    # 36 coefficients would exceed the 28 runs
    assert rs.loo_r2(X, y) < rs.r2 and rs.loo_r2(X, y) < 0.99                          # honest: LOO is worse than the training fit
    full = D.ResponseSurface([(0, 1)] * 7).fit(D.design("latin_hypercube", [(0, 1)] * 7, 60, 1), rng.random(60)); assert full.inter


def test_unreliable_surrogate_is_flagged():
    from tct.uncertainty.monte_carlo import annotate_reliability
    from tct.simulation.config import FailureCriterion
    out = {"surrogate": {"quality": {"m": {"R2_leave_one_out": -0.3}, "k": {"R2_leave_one_out": 0.99}}}, "failure_probability": {"computed": True, "probability": 0.9}}
    annotate_reliability(out, FailureCriterion(metric="m", op=">", threshold=1.0))
    assert out["failure_probability"]["reliable"] is False and "UNRELIABLE" in out["failure_probability"]["warning"] and out["unreliable_responses"] == ["m"]
