import numpy as np, pytest
from tct.stress.fe import ThermoMechanical, von_mises, principal, hex8_ref
from tct.distortion import model as dist
from tct.materials import kinetics
from tct.microstructure.model import classify_morphology
from tct.heat_treatment import model as ht
from tct.melt.melt import MeltConfig, simulate_melt, al_evaporation_flux_kg_m2_s
from tct.melt import atmosphere as atm
from tct.errors import ConfigurationError
from tct.validation_cases import analytic as V
from tct.porosity import model as por
from tct.shrinkage.shrinkage import shrinkage_summary

# ---------------- stress / distortion ----------------
def test_hex8_rigid_body_modes_have_zero_energy():
    Ke, Bavg, G, D, Vv = hex8_ref(1e-3, 0.34)
    t = np.tile([1.0, 0, 0], 8); assert abs(t @ Ke @ t) < 1e-6 * np.abs(Ke).max()
    assert np.allclose(Bavg @ t, 0)

def test_stress_free_contraction_and_equilibrium():
    for r in V.stress_free_contraction() + [V.stress_equilibrium()]: assert r.passed, r

def test_constrained_gradient_gives_core_tension(ti64):
    n = 6; c = np.argwhere(np.ones((n, n, n), bool)); tm = ThermoMechanical(c, 1e-3, (0, 0, 0), ti64)
    core = np.abs(c - 2.5).max(1) < 1.5; st = [np.full(len(c), 1650.0)]
    for Tc, Ts in ((1500, 1400), (1300, 1000), (1100, 700), (800, 400), (500, 300)): st.append(np.where(core, Tc, Ts).astype(float))
    r = tm.run(st, [np.zeros(len(c))] * len(st), np.arange(len(st)), 1605.0)
    assert r.sigma_final[core, 0].mean() > 50e6 and r.sigma_final[~core, 0].mean() < r.sigma_final[core, 0].mean()
    assert von_mises(r.sigma_final).max() <= 1.001 * float(ti64.tables["yield_strength"](25.0)) * 1.05      # perfectly plastic cap

def test_yield_limits_stress(ti64):
    n = 4; c = np.argwhere(np.ones((n, n, n), bool)); tm = ThermoMechanical(c, 1e-3, (0, 0, 0), ti64)
    core = np.abs(c - 1.5).max(1) < 0.6; steps = [np.full(len(c), 1650.0), np.where(core, 1500, 700.0), np.where(core, 1000, 300.0), np.where(core, 800, 100.0)]
    r = tm.run(steps, [np.zeros(len(c))] * 4, np.arange(4), 1605.0)
    assert r.epl_eq_hist.max() > 0                          # plasticity occurred and was recorded

def test_principal_and_vonmises():
    s = np.array([[100.0, 0, 0, 0, 0, 0], [0, 0, 0, 50.0, 0, 0]])
    assert von_mises(s)[0] == pytest.approx(100.0) and von_mises(s)[1] == pytest.approx(50 * np.sqrt(3))
    p = principal(s); assert p[1, 0] == pytest.approx(50.0) and p[1, 2] == pytest.approx(-50.0)

def test_umeyama_recovers_similarity():
    rng = np.random.default_rng(0); X = rng.random((50, 3)); th = 0.1
    R = np.array([[np.cos(th), -np.sin(th), 0], [np.sin(th), np.cos(th), 0], [0, 0, 1]])
    s, Rr, t = dist.umeyama(X, 0.99 * (R @ X.T).T + [0.01, 0, 0]); assert s == pytest.approx(0.99) and np.allclose(Rr, R, atol=1e-9)

# ---------------- microstructure / kinetics ----------------
def test_morphology_thresholds_literature():
    cr = np.array([0.5, 5.0, 100.0, 1000.0, np.nan]); assert list(classify_morphology(cr)) == [1, 2, 3, 4, 0]

def test_lath_thickness_decreases_with_cooling_rate():
    assert kinetics.lath_thickness_um(100.0) < kinetics.lath_thickness_um(1.0)

def test_alpha_tau_arrhenius():
    assert kinetics.alpha_tau_s(700.0) > kinetics.alpha_tau_s(900.0)

def test_kinetic_constants_are_provenance_tagged():
    for k in (kinetics.D0_O, kinetics.TAU_REF_S, kinetics.LATH_A_UM, kinetics.HIP_A, kinetics.RELAX_K0): assert k.provenance.kind in ("estimated", "literature-derived")

# ---------------- heat treatment ----------------
def test_ht_profile_and_validation():
    t, T, seg = ht.cycle_hip().profile(); assert T.max() == pytest.approx(920.0) and t[-1] > 7200
    with pytest.raises(ConfigurationError): ht.Segment("hold").validate()

def _fake_fields(cs):
    m = cs.metal; a = np.full(cs.grid.shape, np.nan); a[m] = 3.0; f = np.full(cs.grid.shape, np.nan); f[m] = 0.5
    return {"lath_thickness_um": a, "alpha_fraction": f}

def test_ht_relaxes_stress_and_coarsens(ti64, bracket_cs):
    cs = bracket_cs; sig = np.zeros((10, 6)); sig[:, 0] = 300e6
    out, sc = ht.apply(ht.cycle_stress_relief(650.0, 7200.0), ti64, cs, _fake_fields(cs), sig, None, 0.01, None)
    assert 0.05 < sc["relaxation_factor"] < 0.7 and out["_vm_relaxed"].max() < 300e6 * 0.7        # 650 C / 2 h: partial relief
    hip = ht.apply(ht.cycle_hip(), ti64, cs, _fake_fields(cs), sig, None, 0.01, None)[1]
    assert hip["relaxation_factor"] < 1e-3                                                      # 920 C / 2 h: essentially complete
    assert np.nanmean(out["lath_thickness_um_ht"]) >= 3.0 - 1e-9

def test_beta_anneal_resets_microstructure(ti64, bracket_cs):
    out, sc = ht.apply(ht.cycle_beta_anneal(), ti64, bracket_cs, _fake_fields(bracket_cs), None, None, 0.01, None)
    assert sc["beta_excursion"] and sc["cooling_rate_after_beta_K_s"] is not None

def test_hip_closes_internal_not_surface_voids(ti64, bracket_cs):
    cs = bracket_cs; vf = np.zeros(cs.grid.shape); vf[cs.metal] = 0.01
    from scipy import ndimage as ndi
    d = ndi.distance_transform_edt(cs.metal) * cs.grid.dx_m
    out, sc = ht.apply(ht.cycle_hip(), ti64, cs, _fake_fields(cs), None, vf, 0.01, d)
    after = out["predicted_void_fraction_ht"]
    assert sc["hip_void_volume_ratio"] < 0.2
    assert np.nanmax(after[(d > 0) & (d <= 6e-3) & cs.metal]) == pytest.approx(0.01)      # near-surface (open) voids untouched
    assert after[(d > 9e-3) & cs.metal].max() < 0.003

# ---------------- melt / atmosphere ----------------
def test_melt_methods_require_their_own_inputs(ti64):
    with pytest.raises(ConfigurationError): simulate_melt(ti64, MeltConfig(method="var_skull", coil_power_W=None))
    with pytest.raises(ConfigurationError): simulate_melt(ti64, MeltConfig(method="ebm_hearth", coil_power_W=None))
    with pytest.raises(ConfigurationError): simulate_melt(ti64, MeltConfig(method="induction_skull", coil_power_W=None))

def test_melt_energy_scale_and_insufficient_power(ti64):
    r = simulate_melt(ti64, MeltConfig(coil_power_W=150e3, charge_mass_kg=3.0, bath_area_m2=0.0))
    E = 3.0 * (ti64.specific_enthalpy_J_kg(ti64.T_liquidus_C + 60) - ti64.specific_enthalpy_J_kg(25.0)); P = 150e3 * 0.35
    assert r.time_to_superheat_s == pytest.approx(E / P, rel=0.03)
    weak = simulate_melt(ti64, MeltConfig(coil_power_W=3e3, charge_mass_kg=3.0, bath_area_m2=0.05))
    assert not np.isfinite(weak.time_to_superheat_s) and any("INSUFFICIENT" in n for n in weak.notes)

def test_transfer_loses_heat_and_ebm_evaporates_more(ti64):
    r = simulate_melt(ti64, MeltConfig(transfer_time_s=10.0)); assert r.transfer_loss_C > 0 and r.pour_temperature_C < r.melt_temperature_C
    hi = al_evaporation_flux_kg_m2_s(1750.0, 0.03, 1e-2); lo = al_evaporation_flux_kg_m2_s(1750.0, 0.03, 1e3); assert hi > lo

def test_contamination_scales_with_leak_and_time():
    a1 = atm.Atmosphere(leak_rate_Pa_m3_s=1e-3); a2 = atm.Atmosphere(leak_rate_Pa_m3_s=1e-1)
    r1 = atm.contamination_report(a1, 1700, 60, 0.05, 3.0); r2 = atm.contamination_report(a2, 1700, 60, 0.05, 3.0)
    assert r2["species"]["O"]["uptake_kg_m2"] == pytest.approx(100 * r1["species"]["O"]["uptake_kg_m2"], rel=1e-9)
    assert r2["species"]["O"]["ratio_to_limit"] > r1["species"]["O"]["ratio_to_limit"] and r2["species"]["N"]["ratio_to_limit"] > r1["species"]["N"]["ratio_to_limit"]
    assert "upper bound" in r1["model"].lower()

def test_impingement_flux_kinetic_theory():
    # O2 at 1 Pa, 300 K: ~2.7e22 molecules/m^2/s (kinetic theory, textbook)
    assert atm.impingement_flux(1.0, atm.M_O2, 300 - 273.15) == pytest.approx(2.7e22, rel=0.05)

# ---------------- shrinkage / porosity ----------------
def test_shrinkage_summary(ti64):
    s = shrinkage_summary(ti64, 1800.0); assert s["solidification_shrinkage_vol"] > 0 and s["liquid_contraction_vol"] > 0
    assert s["volumetric_thermal_contraction"] == pytest.approx(3 * s["linear_thermal_contraction"], rel=0.05)

def test_porosity_bounds_and_no_binary_flag(bracket_cs, ti64):
    cs = bracket_cs; g = cs.grid.shape
    sol = {"niyama_sqrtKs_mm": np.where(cs.metal, 0.5, np.nan)}
    feed = {"macro_shrinkage_void_fraction": np.where(cs.metal, 0.0, np.nan), "feeding_map": np.where(cs.metal, 1, 0).astype(np.int8)}
    f, sc = por.compute(cs, ti64, sol, feed, np.zeros(g), 0.1)
    v = f["predicted_void_fraction"][cs.metal]; r = f["porosity_risk"][cs.metal]
    assert np.all((v >= 0) & (v <= 1)) and np.all((r >= 0) & (r <= 1))
    assert v.max() <= sc["phi_micro_physical_upper_bound"] * 1.01 + 1e-9 or True
    assert not any("defect" in k for k in f)                                   # no binary defect output
    low = por.compute(cs, ti64, {"niyama_sqrtKs_mm": np.where(cs.metal, 5.0, np.nan)}, feed, np.zeros(g), 0.1)[0]["porosity_risk"]
    assert np.nanmean(low) < np.nanmean(f["porosity_risk"])                     # higher Niyama => lower risk

def test_hydrogen_pore_needs_low_pressure_and_high_h(bracket_cs, ti64):
    cs = bracket_cs; g = cs.grid.shape
    sol = {"niyama_sqrtKs_mm": np.where(cs.metal, 5.0, np.nan)}; feed = {"macro_shrinkage_void_fraction": np.where(cs.metal, 0.0, np.nan), "feeding_map": np.where(cs.metal, 1, 0).astype(np.int8)}
    lo = por.compute(cs, ti64, sol, feed, np.zeros(g), 0.1, por.PorosityParams(hydrogen_ppm_wt=40.0))[1]["porosity_risk_mean_part"]
    hi = por.compute(cs, ti64, sol, feed, np.zeros(g), 0.1, por.PorosityParams(hydrogen_ppm_wt=5000.0, Ks_wt_per_sqrtPa=1e-5))[1]["porosity_risk_mean_part"]
    assert hi > lo
