"""Regenerate tests/regression_baseline.json. Run ONLY when a physical change is intentional and reviewed:  python tests/make_baseline.py"""
import json, os, sys, tempfile, pathlib
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1]))
from tests.conftest import coupon_scenario
from tct.simulation.pipeline import run_simulation
with tempfile.TemporaryDirectory() as td:
    R = run_simulation(coupon_scenario(), output_path=os.path.join(td, "r.h5")).results
base = {"fill_time_s": R["fill"]["fill_time_s"], "solidification_time_part_max_s": R["solidification"]["solidification_time_part_max_s"],
        "cooling_rate_beta_min_part": R["solidification"]["cooling_rate_beta_min_part"], "porosity_risk_mean_part": R["porosity"]["porosity_risk_mean_part"],
        "vm_max_part_MPa": R["stress"]["vm_max_part_MPa"], "max_warpage_m": R["distortion"]["max_warpage_m"],
        "isolated_part_volume_fraction": R["feeding"]["isolated_part_volume_fraction"], "lath_thickness_um_mean_part": R["microstructure"]["lath_thickness_um_mean_part"],
        "stock_removal_volume_m3": R["machining"]["stock_removal_volume_m3"]}
json.dump(base, open(pathlib.Path(__file__).with_name("regression_baseline.json"), "w"), indent=1); print(base)
