import os, pathlib, tempfile
import numpy as np
import pytest
from tct.simulation.config import load_scenario, with_overrides
from tct.simulation.pipeline import run_simulation

ROOT = pathlib.Path(__file__).resolve().parents[1]

def coupon_scenario(dx_mm=6.0):
    scn = load_scenario(ROOT / "scenarios" / "ti6246_plate_coupon.yaml")
    return with_overrides(scn, {"mesh.dx_mm": dx_mm, "stress.n_steps": 6, "heat_treatment.preset": "hip", "heat_treatment.hip_pressure_MPa": 100.0, "machining.allowance_mm": 4.0})

@pytest.fixture(scope="session")
def coupon_run(tmp_path_factory):
    p = tmp_path_factory.mktemp("run") / "run.h5"
    run = run_simulation(coupon_scenario(), output_path=str(p))
    return run

@pytest.fixture(scope="session")
def bracket_cs():
    from tct.geometry.library import build_bracket
    return build_bracket(4e-3, 8e-3)

@pytest.fixture(scope="session")
def ti64():
    from tct.materials.database import get_alloy
    return get_alloy("ti64")
