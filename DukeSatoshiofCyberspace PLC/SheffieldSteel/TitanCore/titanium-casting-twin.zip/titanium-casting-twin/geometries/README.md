`ti64_aerospace_bracket_part.stl` — the as-cast part of the demonstration bracket (metres), exported by marching cubes (1 mm) from the procedural CAD in `tct.geometry.library.bracket_solids()`.
Gating, risers, sprue and pour basin are procedural (`build_bracket`); import your own part with `tct mesh part.stl` (STEP needs the optional `cadquery`).
