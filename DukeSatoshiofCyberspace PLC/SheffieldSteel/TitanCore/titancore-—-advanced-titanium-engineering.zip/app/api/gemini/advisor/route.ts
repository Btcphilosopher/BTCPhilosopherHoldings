import { GoogleGenAI } from '@google/genai';
import { NextRequest, NextResponse } from 'next/server';

export async function POST(req: NextRequest) {
  try {
    const { query, context } = await req.json();

    if (!query || typeof query !== 'string') {
      return NextResponse.json({ error: 'Query is required' }, { status: 400 });
    }

    const apiKey = process.env.GEMINI_API_KEY;

    // Metallurgical system prompt for TitanCore Sheffield Engineering Assistant
    const systemInstruction = `You are TitanCore's Chief Metallurgical Engineer and Materials Science Technical Advisor based at TitanCore Sheffield, UK.
You advise design engineers, aerospace procurement directors, machining specialists, and industrial clients on titanium metallurgy, alloy selection, manufacturing practices, standards (ASTM, AMS, ISO, BS EN), machining parameters, heat treatments, and corrosion risks.

TitanCore context:
- Headquarters: Sheffield, South Yorkshire, UK (Olympic Legacy Park & AMRC partnership corridor)
- Core alloys: Ti-6Al-4V Grade 5, Ti-6Al-4V ELI Grade 23 (medical/cryo), Commercially Pure CP Grades 1-4, Ti-0.2Pd Grade 7/11 (reducing acids/brine), Ti-6242 (elevated temp to 540°C), Beta-C (NACE MR0175 sour gas).
- Processing capabilities: Abrasive waterjet, 5-axis high-speed CNC milling, centerless grinding, sawing, CMM dimensional inspection, EN 10204 3.1 & 3.2 mill test cert verification.
- Safety: Explicitly emphasize titanium fire safety protocols (Class D dry powder extinguishers, heavy flood coolant, prevention of dry tool rubbing, and segregation of fine titanium swarf/chips).

Respond with structured, authoritative, professional British engineering clarity:
1. Executive Metallurgical Recommendation (Grade, specification, rationale)
2. Material Properties & Standards (ASTM/AMS/EN references)
3. Manufacturing & Machining Advice (speeds, feeds, tooling, heat generation control)
4. Traceability & Certification Requirement (EN 10204 3.1, ultrasonic inspection)
Keep tone technically rigorous, commercially realistic, and avoid exaggerated or speculative claims.`;

    if (apiKey) {
      const ai = new GoogleGenAI({
        apiKey: apiKey,
        httpOptions: {
          headers: {
            'User-Agent': 'aistudio-build',
          },
        },
      });

      const prompt = `Client / Engineer Query: "${query}"\n${context ? `Additional Context: ${JSON.stringify(context)}` : ''}`;

      const response = await ai.models.generateContent({
        model: 'gemini-3.8-flash',
        contents: prompt,
        config: {
          systemInstruction: systemInstruction,
          temperature: 0.2, // Low temperature for metallurgical accuracy
        },
      });

      const responseText = response.text || 'No response generated.';
      return NextResponse.json({ text: responseText, source: 'gemini-3.8-flash' });
    }

    // High-fidelity metallurgical knowledge fallback if no API key is provided
    const fallbackAnswer = generateMetallurgicalFallback(query);
    return NextResponse.json({ text: fallbackAnswer, source: 'sheffield-metallurgical-engine' });
  } catch (error: unknown) {
    console.error('TitanCore Gemini Advisor API error:', error);
    // Provide graceful domain response
    const errorMessage = error instanceof Error ? error.message : 'Unknown processing error';
    return NextResponse.json({
      text: `### TitanCore Technical Advisory System\n\n**Notice:** Live Gemini service encountered a temporary network constraint (${errorMessage}).\n\n**Standard Metallurgical Guideline:**\nFor titanium applications requiring extreme strength-to-weight, Ti-6Al-4V Grade 5 (AMS 4911/4928) is standard up to 400°C. For medical implants or cryogenic vessels down to -196°C, specify Ti-6Al-4V ELI Grade 23 (ASTM F136). For severe marine or chemical service, specify CP Grade 2 (ASTM B265) or Grade 7 (0.2% Pd) for boiling chlorides.\n\nPlease contact our Sheffield metallurgy desk directly at +44 (0)114 296 8800 or submit an RFQ.`,
      source: 'offline-fallback',
    });
  }
}

function generateMetallurgicalFallback(q: string): string {
  const queryLower = q.toLowerCase();

  if (queryLower.includes('marine') || queryLower.includes('seawater') || queryLower.includes('salt') || queryLower.includes('corrosion')) {
    return `### TitanCore Metallurgical Advisory: Marine & Seawater Service

#### 1. Material Recommendation
- **Primary Selection:** Commercially Pure Titanium Grade 2 (ASTM B265 for plate/sheet, ASTM B338 for condenser tubes) or Ti-6Al-4V Grade 5 (ASTM B348) where structural load-bearing capacity is required.
- **Severe/High Temperature Chlorides (>80°C):** Ti-0.2Pd Grade 7 (ASTM B265 / B348). The 0.12–0.25% palladium shifts the open circuit potential into the passive noble region, completely preventing crevice corrosion in boiling brine.

#### 2. Technical Rationale & Passivation
Titanium forms an instantaneous, adherent, chemically inert rutile titanium dioxide (TiO2) film upon exposure to oxygen or moisture. In ambient seawater, pit initiation potential is well above +1.2V vs SCE (practically unattainable in natural seawater), giving titanium an effective corrosion rate of <0.001 mm/year.

#### 3. Critical Engineering Considerations
- **Galvanic Coupling Warning:** Titanium is highly noble (+0.05V to -0.05V vs SCE in seawater). When directly coupled to structural carbon steel (-0.6V), aluminium (-0.8V), or stainless steel without isolation, the non-titanium anode will undergo accelerated galvanic corrosion. Always specify neoprene/PTFE isolating sleeves or Monel/Inconel fasteners.
- **Biofouling:** While titanium does not corrode under marine organisms, it is non-toxic and will accumulate macro-fouling (barnacles/algae). Periodic mechanical or low-chlorination cleaning is advised.

#### 4. Traceability & Sheffield Delivery
Available from TitanCore Sheffield stock with EN 10204 3.1 Mill Test Certification verifying 100% positive material identification (PMI) and hydrostatic/ultrasonic testing.`;
  }

  if (queryLower.includes('speed') || queryLower.includes('feed') || queryLower.includes('machin') || queryLower.includes('cut')) {
    return `### TitanCore Technical Advisory: Titanium Machining Parameters

#### 1. Cutting Dynamics for Ti-6Al-4V (Grade 5)
Titanium has very low thermal conductivity (~6.7 W/m·K vs ~50 for steel). Approximately 80% of cutting heat concentrates directly in the cutting tool tip and shear zone, which rapidly degrades carbide cutters if proper cutting regimes are not maintained.

#### 2. Recommended Speeds & Feeds (Solid Carbide / Coated TiAlN)
- **Face Milling / Roughing:**
  - Cutting Speed ($V_c$): 45 – 65 m/min
  - Feed per tooth ($f_z$): 0.08 – 0.14 mm/tooth
  - Axial Depth ($a_p$): 2.0 – 4.0 mm with high radial engagement
- **Finishing / Profile Milling:**
  - Cutting Speed ($V_c$): 60 – 85 m/min
  - Feed per tooth ($f_z$): 0.04 – 0.08 mm/tooth
- **Turning (Rigid Set-up):**
  - Cutting Speed ($V_c$): 45 – 70 m/min
  - Feed ($f$): 0.15 – 0.25 mm/rev

#### 3. Coolant & Rigidity Protocol
- **Coolant:** High-pressure flood coolant (minimum 20 to 70 bar directed straight into the tool-chip interface). Emulsion concentration: 8–12%.
- **Sharp Tools:** Never allow tools to dwell or rub. Dull cutting edges work-harden the titanium surface layer (Alpha-case) and generate excessive friction.
- **Climb Milling:** Always utilize climb milling (down milling) to generate maximum chip thickness at entry and minimum at exit.

#### 4. Critical Health & Safety: Pyrophoric Chip Hazard
- Titanium fine swarf, dust, and thin ribbons ignite easily at temperatures above 330°C.
- Keep dedicated **Class D (dry metal powder)** fire extinguishers in the CNC bay. Never apply water or standard CO2 extinguishers to a titanium metal fire.
- Segregate titanium chips in airtight dry steel drums. Clean swarf trays every shift.`;
  }

  if (queryLower.includes('medical') || queryLower.includes('implant') || queryLower.includes('f136') || queryLower.includes('eli')) {
    return `### TitanCore Metallurgical Advisory: Medical Implants & Biocompatibility

#### 1. Material Specification: Ti-6Al-4V ELI (Grade 23)
- **Specification:** ASTM F136 / ISO 5832-3 / BS EN 3.7165.1
- **Key Interstitial Restrictions:**
  - Oxygen: Max 0.13% (vs 0.20% in standard Grade 5)
  - Iron: Max 0.25% (vs 0.40% in standard Grade 5)
  - Carbon: Max 0.08%, Nitrogen: Max 0.05%, Hydrogen: Max 0.012% (120 ppm)

#### 2. Biomechanical Compatibility
- **Tensile Strength:** Min 860 MPa (Typical: 910 MPa)
- **Yield Strength:** Min 790 MPa (Typical: 835 MPa)
- **Elongation at Break:** Min 10% (Typical: 15%)
- **Elastic Modulus:** ~110 GPa (significantly closer to bone than cobalt-chrome at 220 GPa or 316LVM at 190 GPa, mitigating stress-shielding osteoporosis).

#### 3. Osseointegration & Surface Integrity
Titanium is biologically inert and exhibits immediate osseointegration. For permanent orthopaedic and dental fixations, TitanCore supplies centerless-ground bars (h7/h8 tolerance) with vacuum-degassed heat treatment to guarantee zero surface alpha-case contamination.

#### 4. Quality Governance
Supplied with EN 10204 3.1 Medical-grade certs including full melt origin (Triple Vacuum Arc Remelt - VAR), vacuum gas analysis (LECO hydrogen/oxygen/nitrogen), and ultrasonic testing per AMS 2631 Class AA.`;
  }

  return `### TitanCore Sheffield Metallurgical Technical Advisory

#### 1. Primary Recommendation
For general advanced engineering and structural applications, **Ti-6Al-4V Grade 5 (ASTM B348 / AMS 4928)** provides the optimal balance of tensile strength (~950 MPa), fracture toughness, and density (4.43 g/cm³).

#### 2. Key Material Classifications
- **Commercially Pure (CP Grades 1–4):** Unalloyed titanium for chemical vessels, marine piping, plate heat exchangers, and cryogenic service where maximum cold formability and corrosion resistance are prioritized over tensile strength.
- **Alpha-Beta Alloys (Grade 5, Grade 23 ELI):** Workhorse aerospace and biomedical alloys with heat-treatable microstructures providing twice the strength of CP grades.
- **Near-Alpha Alloys (Ti-6242):** Elevated temperature creep resistance up to 540°C for gas turbine hot sections.
- **Metastable Beta Alloys (Beta-C / Grade 19):** Cold-formable, deep-hardenable alloys exceeding 1150 MPa yield strength with NACE MR0175 sour service compliance.

#### 3. Quality Assurance & Certification
All TitanCore Sheffield dispatches are governed by:
- Full heat and melt batch traceability from qualified Western/Japanese mills.
- Verified EN 10204 3.1 chemical and mechanical inspection certificates.
- Positive Material Identification (PMI) by calibrated XRF spectrometer.
- Ultrasonic volumetric inspection conforming to ASTM / AMS standards.

Please submit an RFQ or contact TitanCore's technical sales team at **enquiries@titancore.co.uk** for application-specific finite element, corrosion, or machining guidance.`;
}
