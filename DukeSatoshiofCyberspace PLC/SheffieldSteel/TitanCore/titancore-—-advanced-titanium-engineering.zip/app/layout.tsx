import type {Metadata} from 'next';
import './globals.css'; // Global styles

export const metadata: Metadata = {
  title: 'TitanCore — Advanced Titanium Engineering',
  description: 'British titanium engineering, materials distribution, precision processing, and commercial operating system based in Sheffield, UK.',
  openGraph: {
    title: 'TitanCore — Advanced Titanium Engineering',
    description: 'British titanium engineering, materials distribution, precision processing, and commercial operating system based in Sheffield, UK.',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'TitanCore — Advanced Titanium Engineering',
    description: 'British titanium engineering, materials distribution, precision processing, and commercial operating system based in Sheffield, UK.',
  },
};

export default function RootLayout({children}: {children: React.ReactNode}) {
  return (
    <html lang="en">
      <body suppressHydrationWarning>{children}</body>
    </html>
  );
}
