'use client';

import React, { useState } from 'react';
import { Navbar } from '@/components/layout/Navbar';
import { Footer } from '@/components/layout/Footer';
import { HeroSection } from '@/components/home/HeroSection';
import { IndustriesSection } from '@/components/home/IndustriesSection';
import { SustainabilityBanner } from '@/components/home/SustainabilityBanner';
import { PillarsSection } from '@/components/home/PillarsSection';
import { MaterialsCatalogue } from '@/components/materials/MaterialsCatalogue';
import { LiveStockViewer } from '@/components/stock/LiveStockViewer';
import { ProcessingCapabilities } from '@/components/processing/ProcessingCapabilities';
import { TechnicalCalculators } from '@/components/calculator/TechnicalCalculators';
import { QualityTraceability } from '@/components/quality/QualityTraceability';
import { SheffieldHeritage } from '@/components/sheffield/SheffieldHeritage';
import { TitanOsDashboard } from '@/components/os/TitanOsDashboard';
import { RfqWizard } from '@/components/rfq/RfqWizard';
import { GeminiAdvisorModal } from '@/components/advisor/GeminiAdvisorModal';
import { TitaniumMaterial, InventoryItem, Quotation } from '@/lib/types';
import { SECTOR_GUIDES } from '@/lib/data';
import { Plane, Wind, PlusSquare, Factory, Car, CheckCircle2, ArrowRight } from 'lucide-react';

export default function Home() {
  const [currentTab, setCurrentTab] = useState<string>('home');
  const [titanOsActive, setTitanOsActive] = useState<boolean>(false);
  const [advisorOpen, setAdvisorOpen] = useState<boolean>(false);
  const [advisorInitialQuery, setAdvisorInitialQuery] = useState<string>('');
  const [rfqOpen, setRfqOpen] = useState<boolean>(false);
  const [rfqMaterial, setRfqMaterial] = useState<TitaniumMaterial | null>(null);
  const [activeSectorId, setActiveSectorId] = useState<string>('aerospace');

  // Open Advisor with prefilled question
  const handleAskAi = (promptText: string) => {
    setAdvisorInitialQuery(promptText);
    setAdvisorOpen(true);
  };

  // RFQ handlers
  const handleSelectMaterialForRfq = (material: TitaniumMaterial) => {
    setRfqMaterial(material);
    setRfqOpen(true);
  };

  const handleSelectStockForRfq = (stockItem: InventoryItem) => {
    setRfqOpen(true);
  };

  const handleQuoteAdded = (newQuote: Quotation) => {
    // When a quote is submitted from public RFQ, we notify user and offer them to see it in TitanOS
    console.log('New quote registered:', newQuote);
  };

  return (
    <div className="min-h-screen bg-[#070b0f] text-slate-100 flex flex-col font-sans selection:bg-cyan-500 selection:text-black">
      {/* Navigation */}
      <Navbar
        currentTab={currentTab}
        onSelectTab={(tab) => {
          setTitanOsActive(false);
          setCurrentTab(tab);
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }}
        onOpenAdvisor={() => handleAskAi('')}
        onOpenRfq={() => setRfqOpen(true)}
        titanOsActive={titanOsActive}
        onToggleTitanOs={() => setTitanOsActive(!titanOsActive)}
      />

      {/* Main View Router */}
      <main className="flex-1">
        {titanOsActive ? (
          /* TITANOS COMMERCIAL OPERATING SYSTEM (Internal ERP / MES) */
          <TitanOsDashboard
            onExitToPublic={() => setTitanOsActive(false)}
            onAskAi={handleAskAi}
          />
        ) : (
          /* PUBLIC CORPORATE WEBSITE & TECHNICAL PORTAL */
          <>
            {currentTab === 'home' && (
              <>
                {/* 1. Hero Section matching user reference image */}
                <HeroSection
                  onExploreMaterials={() => {
                    setCurrentTab('materials');
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                  }}
                  onExploreProcessing={() => {
                    setCurrentTab('processing');
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                  }}
                  onOpenRfq={() => setRfqOpen(true)}
                  onToggleTitanOs={() => setTitanOsActive(true)}
                  onOpenAdvisor={() => handleAskAi('')}
                />

                {/* 2. Industries Section matching user reference image */}
                <IndustriesSection
                  onSelectSector={(sectorId) => {
                    setActiveSectorId(sectorId);
                    setCurrentTab('applications');
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                  }}
                  onViewAllApplications={() => {
                    setCurrentTab('applications');
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                  }}
                />

                {/* 3. Sustainability Banner matching user reference image */}
                <SustainabilityBanner
                  onLearnMore={() => {
                    setCurrentTab('quality');
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                  }}
                />

                {/* 4. The 5 Foundational Principles */}
                <PillarsSection />
              </>
            )}

            {currentTab === 'materials' && (
              <MaterialsCatalogue
                onSelectForRfq={handleSelectMaterialForRfq}
                onAskAi={handleAskAi}
              />
            )}

            {currentTab === 'stock' && (
              <LiveStockViewer
                onSelectStockForRfq={handleSelectStockForRfq}
              />
            )}

            {currentTab === 'applications' && (
              <div className="bg-[#090d12] text-slate-100 py-12 lg:py-16">
                <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                  <div className="max-w-3xl mb-10 pb-6 border-b border-slate-800">
                    <span className="text-xs font-mono font-semibold uppercase tracking-widest text-cyan-400">
                      SECTOR SOLUTIONS & CORROSION ENGINEERING
                    </span>
                    <h1 className="text-3xl sm:text-4xl font-extrabold text-white mt-1 tracking-tight">
                      Industrial Applications & Engineering Guidance
                    </h1>
                    <p className="text-slate-300 text-sm mt-2 leading-relaxed">
                      We never claim titanium is universal. We identify specific thermal, corrosion, 
                      and strength-to-weight conditions where titanium delivers superior lifecycle payback.
                    </p>
                  </div>

                  {/* Sector Pills */}
                  <div className="flex flex-wrap gap-2 mb-8">
                    {SECTOR_GUIDES.map((sec) => (
                      <button
                        key={sec.id}
                        onClick={() => setActiveSectorId(sec.id)}
                        className={`px-4 py-2 rounded-xl text-xs font-semibold transition-all ${
                          activeSectorId === sec.id
                            ? 'bg-cyan-600 text-white shadow-md'
                            : 'bg-slate-900 text-slate-300 hover:bg-slate-800 border border-slate-800'
                        }`}
                      >
                        {sec.name}
                      </button>
                    ))}
                  </div>

                  {/* Active Sector Display */}
                  {(() => {
                    const activeSec = SECTOR_GUIDES.find(s => s.id === activeSectorId) || SECTOR_GUIDES[0];
                    return (
                      <div className="bg-slate-950 rounded-2xl border border-slate-800 overflow-hidden shadow-2xl">
                        <div className="grid grid-cols-1 lg:grid-cols-12">
                          <div className="lg:col-span-5 relative h-64 lg:h-auto min-h-[300px]">
                            <div
                              className="absolute inset-0 bg-cover bg-center filter brightness-90"
                              style={{ backgroundImage: `url('${activeSec.image}')` }}
                            />
                            <div className="absolute inset-0 bg-gradient-to-t lg:bg-gradient-to-r from-slate-950 via-slate-950/40 to-transparent" />
                          </div>

                          <div className="lg:col-span-7 p-6 sm:p-8 space-y-6">
                            <div>
                              <span className="text-xs font-mono font-bold text-cyan-400 uppercase tracking-wider">
                                {activeSec.eyebrow}
                              </span>
                              <h2 className="text-2xl sm:text-3xl font-bold text-white mt-1">
                                {activeSec.name}
                              </h2>
                              <p className="text-sm font-semibold text-slate-200 mt-2">
                                {activeSec.headline}
                              </p>
                            </div>

                            <div className="space-y-4 text-xs sm:text-sm text-slate-300 leading-relaxed border-t border-slate-800 pt-4">
                              <div>
                                <h4 className="font-bold text-white font-mono text-xs uppercase mb-1">The Engineering Problem:</h4>
                                <p>{activeSec.engineeringChallenge}</p>
                              </div>

                              <div>
                                <h4 className="font-bold text-white font-mono text-xs uppercase mb-1">Why Titanium Is Specified:</h4>
                                <p>{activeSec.titaniumAdvantage}</p>
                              </div>

                              <div className="bg-slate-900/80 p-4 rounded-xl border border-slate-800 space-y-2">
                                <h4 className="font-bold text-cyan-400 font-mono text-xs uppercase">TitanCore Products & Standards:</h4>
                                <ul className="list-disc list-inside space-y-1 text-xs text-slate-200">
                                  {activeSec.titanCoreProducts.map((p, idx) => (
                                    <li key={idx}>{p}</li>
                                  ))}
                                </ul>
                                <div className="pt-2 text-[11px] text-slate-400 font-mono">
                                  Quality Requirements: {activeSec.certificationsRequired}
                                </div>
                              </div>
                            </div>

                            <div className="pt-2 flex flex-wrap gap-3">
                              <button
                                onClick={() => setRfqOpen(true)}
                                className="px-5 py-2.5 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-semibold shadow-md active:scale-95 transition-all"
                              >
                                Request Technical RFQ for {activeSec.name}
                              </button>
                              <button
                                onClick={() => handleAskAi(`What are the critical metallurgy and certification requirements for titanium in ${activeSec.name}?`)}
                                className="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-cyan-300 text-xs font-semibold border border-slate-700"
                              >
                                Consult AI Advisor on this Sector
                              </button>
                            </div>
                          </div>
                        </div>
                      </div>
                    );
                  })()}
                </div>
              </div>
            )}

            {currentTab === 'processing' && (
              <ProcessingCapabilities
                onOpenRfq={() => setRfqOpen(true)}
                onAskAi={handleAskAi}
              />
            )}

            {currentTab === 'calculators' && (
              <TechnicalCalculators
                onOpenRfqWithData={() => setRfqOpen(true)}
                onAskAi={handleAskAi}
              />
            )}

            {currentTab === 'quality' && (
              <QualityTraceability />
            )}

            {currentTab === 'sheffield' && (
              <SheffieldHeritage
                onExploreStock={() => setCurrentTab('stock')}
                onOpenRfq={() => setRfqOpen(true)}
              />
            )}
          </>
        )}
      </main>

      {/* RFQ Modal Wizard */}
      {rfqOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/85 backdrop-blur-md overflow-y-auto animate-in fade-in">
          <div className="my-auto w-full max-w-5xl">
            <RfqWizard
              initialMaterial={rfqMaterial}
              onClose={() => {
                setRfqOpen(false);
                setRfqMaterial(null);
              }}
              onSubmitSuccess={(newQuote) => {
                handleQuoteAdded(newQuote);
              }}
            />
          </div>
        </div>
      )}

      {/* Gemini Metallurgical Advisor Modal */}
      <GeminiAdvisorModal
        isOpen={advisorOpen}
        onClose={() => setAdvisorOpen(false)}
        initialQuery={advisorInitialQuery}
      />

      {/* Footer */}
      <Footer
        onSelectTab={(tab) => {
          setTitanOsActive(false);
          setCurrentTab(tab);
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }}
        onOpenAdvisor={() => handleAskAi('')}
      />
    </div>
  );
}
