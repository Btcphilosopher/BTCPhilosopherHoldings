export type GradeCategory = 'commercially_pure' | 'alpha_beta' | 'near_alpha' | 'beta' | 'specialty';

export type ProductForm = 'plate' | 'sheet' | 'bar' | 'billet' | 'tube' | 'wire' | 'forgings' | 'fasteners';

export interface TitaniumMaterial {
  id: string;
  name: string;
  designation: string; // e.g. Ti-6Al-4V Grade 5
  commonName: string;
  category: GradeCategory;
  standards: {
    astm?: string[];
    ams?: string[];
    iso?: string[];
    en?: string[];
    uns?: string;
  };
  densityGPerCm3: number; // e.g. 4.43
  elasticModulusGpa: number; // e.g. 114
  tensileStrengthMpa: { min: number; typical: number };
  yieldStrengthMpa: { min: number; typical: number };
  elongationPercent: { min: number; typical: number };
  hardnessHrc?: number;
  maxServiceTempC: number;
  corrosionCharacteristics: string;
  machinabilityRating: number; // e.g. 22% of B1112 steel
  weldability: 'Excellent' | 'Good' | 'Moderate' | 'Specialist Shielding Required';
  heatTreatmentConditions: string[];
  typicalApplications: string[];
  availableForms: ProductForm[];
  basePricePerKgEstimateGbp: number;
  sheffieldStockStatus: 'Immediate Stock' | 'Supplier 3-5 Days' | 'Mill Order 4-6 Weeks';
  description: string;
}

export interface InventoryItem {
  id: string;
  stockId: string;
  materialId: string;
  grade: string;
  form: ProductForm;
  dimensionsMm: {
    thicknessOrOd: number;
    widthOrWt?: number;
    length: number;
    unitDesc: string;
  };
  heatNumber: string;
  batchNumber: string;
  millSource: string;
  millCountry: string;
  certificateType: 'EN 10204 3.1' | 'EN 10204 3.2';
  certificateId: string;
  weightKg: number;
  location: string;
  status: 'In Stock' | 'Allocated' | 'Quarantined' | 'In Inspection';
  quarantineReason?: string;
  unitCostGbp: number;
  receivedDate: string;
}

export interface SupplierProfile {
  id: string;
  name: string;
  country: string;
  productionFacility: string;
  productsSupplied: ProductForm[];
  gradesSupplied: string[];
  certifications: string[];
  approvalStatus: 'Approved (ASL)' | 'Evaluation' | 'Conditional' | 'Suspended';
  qualityRatingScore: number; // 0-100
  onTimeDeliveryRate: number; // 0-100%
  averageLeadTimeDays: number;
  minimumOrderQuantityKg: number;
  paymentTerms: string;
  traceabilityVerified: boolean;
  lastAuditDate: string;
}

export interface QuotationLineItem {
  id: string;
  materialId: string;
  materialName: string;
  form: ProductForm;
  dimensions: string;
  quantityUnits: number;
  netWeightKgPerUnit: number;
  totalNetWeightKg: number;
  grossWeightKgWithYield: number;
  rawMaterialCostPerKgGbp: number;
  machiningHoursPerUnit: number;
  machiningHourlyRateGbp: number;
  testingInspectionFeeGbp: number;
  packagingTransportGbp: number;
  scrapYieldLossPercent: number; // e.g. 15%
}

export interface Quotation {
  id: string;
  quoteNumber: string;
  clientCompany: string;
  contactName: string;
  contactEmail: string;
  industrySector: string;
  requestDate: string;
  validityDays: number;
  status: 'Draft' | 'Sent' | 'Approved' | 'Declined' | 'Ordered';
  lines: QuotationLineItem[];
  pricingMode: 'margin' | 'markup';
  targetMarginOrMarkupPercent: number;
  currencyRiskHedgingPercent: number;
  overheadAllocationGbp: number;
  totalRawCostGbp: number;
  totalProcessingCostGbp: number;
  totalQualityInspectionCostGbp: number;
  totalLogisticsCostGbp: number;
  totalCostBasisGbp: number;
  totalQuotedPriceGbp: number;
  calculatedGrossProfitGbp: number;
  effectiveGrossMarginPercent: number;
  effectiveMarkupPercent: number;
  notes: string;
}

export interface NonConformanceReport {
  id: string;
  ncrNumber: string;
  heatNumber: string;
  materialGrade: string;
  supplier: string;
  discrepancyType: 'Dimensional' | 'Chemical Composition' | 'Surface Defect' | 'Documentation / Cert Error';
  description: string;
  status: 'Open - Quarantined' | 'Under Investigation' | 'Resolved - Scrap' | 'Resolved - Downgrade' | 'Closed - Concession Granted';
  openedDate: string;
  assignedEngineer: string;
  capaAction: string;
}

export interface MakeOrBuyScenario {
  operationName: string;
  monthlyPartsVolume: number;
  vendorCostPerPartGbp: number;
  inHouseMachineCapExGbp: number;
  inHouseToolingMonthlyGbp: number;
  inHouseLaborPerHourGbp: number;
  cycleTimeHoursPerPart: number;
  facilityOverheadMonthlyGbp: number;
}
