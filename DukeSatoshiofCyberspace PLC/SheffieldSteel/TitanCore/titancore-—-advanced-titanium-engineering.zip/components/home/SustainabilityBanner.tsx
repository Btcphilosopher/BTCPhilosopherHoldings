'use client';

import React from 'react';
import { Leaf, ArrowRight, Recycle, ShieldCheck, Sparkles } from 'lucide-react';

interface SustainabilityBannerProps {
  onLearnMore?: () => void;
}

export const SustainabilityBanner: React.FC<SustainabilityBannerProps> = ({
  onLearnMore,
}) => {
  return (
    <section className="relative overflow-hidden bg-gradient-to-r from-[#070b10] via-slate-900 to-[#070b10] border-b border-slate-800 text-white py-12 lg:py-16">
      {/* Background panoramic landscape aesthetic matching user reference image */}
      <div 
        className="absolute inset-0 opacity-20 bg-cover bg-center pointer-events-none filter contrast-125 brightness-75"
        style={{
          backgroundImage: `url('https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=crop&w=1600&q=80')`
        }}
      />
      <div className="absolute inset-0 bg-gradient-to-r from-[#070b10] via-slate-950/90 to-[#070b10]" />

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
          {/* Left Title */}
          <div className="lg:col-span-4">
            <span className="text-xs font-mono font-semibold uppercase tracking-widest text-emerald-400">
              OUR COMMITMENT
            </span>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-white mt-1 leading-snug">
              Sustainable titanium. <br />
              For generations to come.
            </h2>
          </div>

          {/* Middle Description */}
          <div className="lg:col-span-5 border-l-0 lg:border-l lg:border-slate-800 lg:pl-8">
            <p className="text-slate-300 text-sm leading-relaxed">
              We are committed to responsible sourcing, low-carbon production and a circular future 
              for titanium. Because high performance should never come at the planet’s expense.
            </p>
            <div className="mt-4 flex items-center gap-4">
              <button 
                onClick={onLearnMore}
                className="inline-flex items-center gap-1.5 text-xs font-semibold text-emerald-400 hover:text-emerald-300 transition-colors"
              >
                <span>Our sustainability approach</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
              <span className="text-slate-600">•</span>
              <span className="text-xs text-slate-400">100% Recyclable Scrap Stream</span>
            </div>
          </div>

          {/* Right Badge matching reference image */}
          <div className="lg:col-span-3 flex justify-start lg:justify-end">
            <div 
              onClick={onLearnMore}
              className="cursor-pointer group flex items-center gap-3 bg-slate-900/80 hover:bg-slate-800/90 border border-slate-700/80 rounded-2xl p-4 transition-all hover:border-emerald-500/50"
            >
              <div className="w-12 h-12 rounded-full border-2 border-emerald-400/80 flex items-center justify-center text-emerald-400 bg-emerald-950/40 group-hover:scale-105 transition-transform">
                <Leaf className="w-5 h-5" />
              </div>
              <div>
                <div className="text-xs font-bold text-white group-hover:text-emerald-300 transition-colors">
                  Lower impact.
                </div>
                <div className="text-xs text-slate-400">
                  Greater possibility.
                </div>
                <div className="text-[11px] text-emerald-400 font-medium flex items-center gap-1 mt-0.5">
                  <span>Learn more</span>
                  <ArrowRight className="w-3 h-3 group-hover:translate-x-0.5 transition-transform" />
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
