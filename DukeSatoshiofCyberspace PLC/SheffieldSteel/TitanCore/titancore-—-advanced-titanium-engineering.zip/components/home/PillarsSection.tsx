'use client';

import React from 'react';
import { Microscope, Crosshair, Factory, FileCheck2, TrendingUp, CheckCircle2 } from 'lucide-react';

export const PillarsSection: React.FC = () => {
  const principles = [
    {
      num: '01',
      title: 'Metallurgical Integrity',
      icon: Microscope,
      description: 'Validated chemical compositions, verified phase balances (Alpha/Beta), and precise heat-treatment documentation per ASTM, AMS, and BS EN standards. Never compromise on interstitial gas limits.',
    },
    {
      num: '02',
      title: 'Engineering Precision',
      icon: Crosshair,
      description: 'Tight-tolerance waterjet cutting, CNC machining, and rigorous CMM metrology. Verified dimensional conformance with calibrated coordinate measuring systems before dispatch.',
    },
    {
      num: '03',
      title: 'British Industrial Capability',
      icon: Factory,
      description: 'Grounding next-generation titanium supply in Sheffield’s centuries-old reputation for steelmaking, alloy development, and manufacturing talent along the Don Valley corridor.',
    },
    {
      num: '04',
      title: 'Transparent Traceability',
      icon: FileCheck2,
      description: 'Full heat and melt lot batch traceability from ingot to finished component. Complete EN 10204 3.1 & 3.2 inspection records and quarantine containment systems.',
    },
    {
      num: '05',
      title: 'Commercially Disciplined',
      icon: TrendingUp,
      description: 'A realistic, staged commercial model that delivers positive margins through distribution and processing partnerships before capital-intensive mill expansion.',
    },
  ];

  return (
    <section className="bg-[#0b0f14] py-16 lg:py-20 border-b border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-3xl mb-12">
          <span className="text-xs font-mono font-semibold uppercase tracking-widest text-cyan-400">
            THE TITANCORE CONSTITUTION
          </span>
          <h2 className="text-3xl font-extrabold text-white mt-1 tracking-tight">
            Built on Five Core Principles
          </h2>
          <p className="text-slate-300 text-sm mt-3 leading-relaxed">
            We avoid exaggerated claims about proprietary alloys or overnight gigafactories. 
            Instead, we build technical competence and genuine trust with procurement directors, 
            metallurgists, and quality engineers.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {principles.map((item) => {
            const Icon = item.icon;
            return (
              <div 
                key={item.num}
                className="bg-slate-900/60 border border-slate-800 rounded-xl p-6 hover:border-slate-700 transition-colors relative overflow-hidden"
              >
                <div className="text-xs font-mono font-bold text-slate-500 mb-4 flex items-center justify-between">
                  <span>PRINCIPLE {item.num}</span>
                  <div className="p-2 rounded-lg bg-slate-800/80 text-cyan-400">
                    <Icon className="w-4 h-4" />
                  </div>
                </div>
                <h3 className="text-lg font-bold text-white mb-2">
                  {item.title}
                </h3>
                <p className="text-xs sm:text-sm text-slate-400 leading-relaxed">
                  {item.description}
                </p>
              </div>
            );
          })}

          {/* Sheffield Commitment Box */}
          <div className="bg-gradient-to-br from-cyan-950/40 via-slate-900 to-slate-950 border border-cyan-800/40 rounded-xl p-6 flex flex-col justify-between">
            <div>
              <span className="text-[10px] font-mono uppercase tracking-wider text-cyan-400 font-bold">
                SHEFFIELD SOUTH YORKSHIRE
              </span>
              <h3 className="text-lg font-bold text-white mt-1 mb-2">
                The UK Titanium Advantage
              </h3>
              <p className="text-xs text-slate-300 leading-relaxed">
                Partnered with the Advanced Manufacturing Research Centre (AMRC) ecosystem and local 
                specialist precision machine shops for zero-risk, high-margin component delivery.
              </p>
            </div>
            <div className="pt-4 mt-4 border-t border-slate-800/80 flex items-center gap-2 text-xs text-cyan-300 font-mono">
              <CheckCircle2 className="w-4 h-4 text-cyan-400" />
              <span>Full Raw Material Certificate Included</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
