'use client';

import React from 'react';
import { 
  Plane, 
  Wind, 
  PlusSquare, 
  Factory, 
  Car, 
  ArrowRight,
  ExternalLink
} from 'lucide-react';
import { SECTOR_GUIDES } from '@/lib/data';

interface IndustriesSectionProps {
  onSelectSector: (sectorId: string) => void;
  onViewAllApplications: () => void;
}

export const IndustriesSection: React.FC<IndustriesSectionProps> = ({
  onSelectSector,
  onViewAllApplications,
}) => {
  const cards = [
    {
      id: 'aerospace',
      icon: Plane,
      title: 'Aerospace',
      tagline: 'Higher performance. Lower weight.',
      image: 'https://images.unsplash.com/photo-1540959733332-eab4deabeeaf?auto=format&fit=crop&w=600&q=80',
      alt: 'Aircraft jet engine turbine blades',
    },
    {
      id: 'clean-energy',
      icon: Wind,
      title: 'Clean Energy',
      tagline: 'Enabling a net zero future.',
      image: 'https://images.unsplash.com/photo-1466611653911-95081537e5b7?auto=format&fit=crop&w=600&q=80',
      alt: 'Clean wind turbine farm and hydrogen infrastructure',
    },
    {
      id: 'medical',
      icon: PlusSquare,
      title: 'Medical',
      tagline: 'Biocompatible. Reliable. Life-changing.',
      image: 'https://images.unsplash.com/photo-1579684385127-1ef15d508118?auto=format&fit=crop&w=600&q=80',
      alt: 'Titanium orthopedic hip stem implant',
    },
    {
      id: 'industrial',
      icon: Factory,
      title: 'Industrial',
      tagline: "Built for the world's harshest environments.",
      image: 'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?auto=format&fit=crop&w=600&q=80',
      alt: 'Offshore industrial platform and chemical processing reactors',
    },
    {
      id: 'automotive',
      icon: Car,
      title: 'Automotive & Performance',
      tagline: 'Lighter. Faster. Stronger.',
      image: 'https://images.unsplash.com/photo-1617814076367-b759c7d7e738?auto=format&fit=crop&w=600&q=80',
      alt: 'High-performance lightweight racing car',
    },
  ];

  return (
    <section className="bg-slate-900/40 py-16 lg:py-24 border-y border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header matching user reference image */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-10 pb-4 border-b border-slate-800/80 gap-6">
          <div className="max-w-2xl">
            <span className="text-xs font-mono font-semibold uppercase tracking-widest text-cyan-400">
              TITANIUM FOR A WIDER WORLD
            </span>
            <h2 className="text-3xl sm:text-4xl font-extrabold text-white mt-1 tracking-tight">
              Engineered for demanding industries
            </h2>
            <p className="text-slate-300 text-sm sm:text-base mt-3 leading-relaxed">
              Our titanium materials and components help our partners build lighter, stronger 
              and more sustainable solutions — from the skies to the depths, and beyond.
            </p>
          </div>

          <div>
            <button
              onClick={onViewAllApplications}
              className="inline-flex items-center gap-1.5 text-sm font-semibold text-cyan-400 hover:text-cyan-300 group transition-colors"
            >
              <span>View all applications</span>
              <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </button>
          </div>
        </div>

        {/* 5 Cards Row matching screenshot exactly */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4 lg:gap-5">
          {cards.map((card) => {
            const Icon = card.icon;
            return (
              <div
                key={card.id}
                onClick={() => onSelectSector(card.id)}
                className="group cursor-pointer bg-slate-950/80 rounded-xl overflow-hidden border border-slate-800 hover:border-cyan-500/50 transition-all duration-300 hover:shadow-xl hover:-translate-y-1 flex flex-col"
              >
                {/* Image Container */}
                <div className="relative h-44 overflow-hidden bg-slate-900">
                  <div
                    className="absolute inset-0 bg-cover bg-center group-hover:scale-105 transition-transform duration-500 filter brightness-90 contrast-105"
                    style={{ backgroundImage: `url('${card.image}')` }}
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-transparent to-transparent opacity-80" />
                </div>

                {/* Content */}
                <div className="p-4 flex-1 flex flex-col justify-between">
                  <div>
                    <div className="flex items-center gap-2 mb-2">
                      <div className="p-1 rounded bg-slate-800 text-cyan-400">
                        <Icon className="w-3.5 h-3.5" />
                      </div>
                      <h3 className="font-bold text-white text-base group-hover:text-cyan-300 transition-colors">
                        {card.title}
                      </h3>
                    </div>
                    <p className="text-xs text-slate-400 line-clamp-2 leading-relaxed">
                      {card.tagline}
                    </p>
                  </div>

                  <div className="pt-4 mt-2 border-t border-slate-800/60 flex items-center justify-between text-xs font-medium text-cyan-400 group-hover:text-cyan-300">
                    <span>Learn more</span>
                    <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
