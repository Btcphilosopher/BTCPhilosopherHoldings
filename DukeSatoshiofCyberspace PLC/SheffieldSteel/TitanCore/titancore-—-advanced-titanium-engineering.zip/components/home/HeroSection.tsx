'use client';

import React from 'react';
import { 
  ArrowRight, 
  ShieldCheck, 
  ThermometerSun, 
  RefreshCw, 
  Terminal, 
  Sparkles,
  Award
} from 'lucide-react';

interface HeroSectionProps {
  onExploreMaterials: () => void;
  onExploreProcessing: () => void;
  onOpenRfq: () => void;
  onToggleTitanOs: () => void;
  onOpenAdvisor: () => void;
}

export const HeroSection: React.FC<HeroSectionProps> = ({
  onExploreMaterials,
  onExploreProcessing,
  onOpenRfq,
  onToggleTitanOs,
  onOpenAdvisor,
}) => {
  return (
    <section className="relative overflow-hidden bg-[#090d12] text-white">
      {/* Background Graphic Layer - High-tech industrial mood with mountains and precision components */}
      <div className="absolute inset-0 z-0 opacity-40 mix-blend-screen pointer-events-none">
        <div 
          className="absolute inset-0 bg-cover bg-center filter brightness-[0.7] contrast-[1.2]"
          style={{
            backgroundImage: `radial-gradient(circle at 75% 35%, rgba(56, 189, 248, 0.15) 0%, transparent 60%),
                              radial-gradient(circle at 20% 70%, rgba(30, 58, 138, 0.25) 0%, transparent 50%),
                              linear-gradient(to bottom, #090d12 0%, rgba(9, 13, 18, 0.7) 40%, #090d12 100%)`
          }}
        />
        {/* Subtle engineering grid */}
        <div 
          className="absolute inset-0 opacity-[0.07]" 
          style={{
            backgroundImage: 'linear-gradient(to right, #ffffff 1px, transparent 1px), linear-gradient(to bottom, #ffffff 1px, transparent 1px)',
            backgroundSize: '48px 48px'
          }} 
        />
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-12 pb-16 lg:pt-20 lg:pb-24">
        {/* Top Eyebrow Tag */}
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-slate-800/80 border border-slate-700/80 text-cyan-400 text-xs font-mono font-medium tracking-widest uppercase mb-6 shadow-sm">
          <span className="w-2 h-2 rounded-full bg-cyan-400 animate-ping" />
          HIGH-PERFORMANCE TITANIUM SOLUTIONS — SHEFFIELD, UK
        </div>

        {/* Hero Grid with Content on Left and Precision Machined Titanium Visuals on Right */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-center">
          <div className="lg:col-span-7 space-y-6">
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight text-white leading-[1.1]">
              Stronger materials. <br />
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-slate-100 via-cyan-100 to-cyan-300">
                A cleaner, more resilient future.
              </span>
            </h1>

            <p className="text-base sm:text-lg text-slate-300 max-w-2xl leading-relaxed">
              TitanCore is a British high-tech engineering start-up supplying advanced titanium 
              materials and precision components for aerospace, clean energy, medical and 
              high-performance industries. Grounded in Sheffield’s metallurgical heritage.
            </p>

            {/* Action Buttons */}
            <div className="pt-2 flex flex-wrap items-center gap-3 sm:gap-4">
              <button
                onClick={onExploreMaterials}
                className="px-6 py-3.5 rounded-xl font-semibold text-sm bg-cyan-600 hover:bg-cyan-500 text-white shadow-lg shadow-cyan-900/30 flex items-center gap-2 transition-all group active:scale-95"
              >
                <span>Explore Our Titanium</span>
                <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </button>

              <button
                onClick={onExploreProcessing}
                className="px-5 py-3.5 rounded-xl font-semibold text-sm bg-slate-900 hover:bg-slate-800 text-slate-200 border border-slate-700 flex items-center gap-2 transition-all active:scale-95"
              >
                <span>Our Capabilities</span>
                <ArrowRight className="w-4 h-4 opacity-70" />
              </button>

              <button
                onClick={onToggleTitanOs}
                className="px-5 py-3.5 rounded-xl font-mono text-xs font-bold bg-amber-500/10 hover:bg-amber-500/20 text-amber-300 border border-amber-500/40 flex items-center gap-2 transition-all"
                title="Open TitanCore Internal ERP/MES Operational Operating System"
              >
                <Terminal className="w-4 h-4 text-amber-400" />
                <span>Launch TitanOS Platform</span>
              </button>
            </div>

            {/* Quick status line */}
            <div className="pt-4 flex items-center gap-4 text-xs text-slate-400 font-mono">
              <span className="flex items-center gap-1.5">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
                Stock at Sheffield Warehouse
              </span>
              <span>•</span>
              <span>Mill Certs EN 10204 3.1</span>
              <span>•</span>
              <span>ASTM / AMS Standards</span>
            </div>
          </div>

          {/* Right Visual Component Showcase matching screenshot */}
          <div className="lg:col-span-5 relative">
            <div className="relative rounded-2xl overflow-hidden border border-slate-700/80 bg-slate-900/60 p-2 shadow-2xl backdrop-blur-sm">
              <div className="relative h-72 sm:h-84 rounded-xl overflow-hidden bg-gradient-to-tr from-slate-950 via-slate-900 to-slate-800">
                {/* Visual rendering of precision titanium blisk and seamless extruded pipe */}
                <div 
                  className="absolute inset-0 bg-cover bg-center opacity-85 transition-transform duration-700 hover:scale-105"
                  style={{
                    backgroundImage: `url('https://images.unsplash.com/photo-1581092160607-ee22621dd758?auto=format&fit=crop&w=1000&q=80')`
                  }}
                />
                <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/40 to-transparent" />

                {/* Overlay Component Badges */}
                <div className="absolute bottom-4 left-4 right-4 flex items-end justify-between">
                  <div className="bg-slate-900/90 backdrop-blur-md border border-slate-700/80 rounded-lg p-3 text-xs">
                    <div className="text-[10px] uppercase font-mono text-cyan-400 font-semibold tracking-wider">
                      Featured Sheffield Component
                    </div>
                    <div className="font-bold text-white text-sm">
                      5-Axis Machined Ti-6Al-4V Impeller
                    </div>
                    <div className="text-[11px] text-slate-300">
                      Tolerance: ±0.012mm • Heat # TC-2026-HT884
                    </div>
                  </div>

                  <button
                    onClick={onOpenAdvisor}
                    className="p-2.5 rounded-lg bg-cyan-500/20 hover:bg-cyan-500/30 text-cyan-300 border border-cyan-500/40 backdrop-blur-md text-xs font-semibold flex items-center gap-1.5 transition-colors"
                  >
                    <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
                    <span>Ask AI</span>
                  </button>
                </div>

                {/* Top Corner Technical Badge */}
                <div className="absolute top-3 right-3 px-2.5 py-1 rounded bg-slate-950/80 border border-slate-700 text-[10px] font-mono text-slate-300">
                  PMI VERIFIED XRF
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* 4 Value Pillars Bar matching reference image */}
        <div className="mt-14 pt-8 border-t border-slate-800/80">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {/* Pillar 1 */}
            <div className="flex items-start gap-3.5 p-3 rounded-xl hover:bg-slate-800/30 transition-colors">
              <div className="p-2.5 rounded-lg bg-slate-800/80 border border-slate-700 text-cyan-400 shrink-0">
                <ShieldCheck className="w-5 h-5" />
              </div>
              <div>
                <h4 className="text-sm font-bold text-white tracking-wide">
                  Exceptional Strength
                </h4>
                <p className="text-xs text-slate-400 mt-0.5">
                  High strength-to-weight ratio; ~40% lighter than structural steel.
                </p>
              </div>
            </div>

            {/* Pillar 2 */}
            <div className="flex items-start gap-3.5 p-3 rounded-xl hover:bg-slate-800/30 transition-colors">
              <div className="p-2.5 rounded-lg bg-slate-800/80 border border-slate-700 text-cyan-400 shrink-0">
                <ThermometerSun className="w-5 h-5" />
              </div>
              <div>
                <h4 className="text-sm font-bold text-white tracking-wide">
                  Extreme Temperature Performance
                </h4>
                <p className="text-xs text-slate-400 mt-0.5">
                  Reliable from cryogenic (-196°C) up to 540°C in jet hot sections.
                </p>
              </div>
            </div>

            {/* Pillar 3 */}
            <div className="flex items-start gap-3.5 p-3 rounded-xl hover:bg-slate-800/30 transition-colors">
              <div className="p-2.5 rounded-lg bg-slate-800/80 border border-slate-700 text-emerald-400 shrink-0">
                <RefreshCw className="w-5 h-5" />
              </div>
              <div>
                <h4 className="text-sm font-bold text-white tracking-wide">
                  Long Lifecycle
                </h4>
                <p className="text-xs text-slate-400 mt-0.5">
                  Immune to seawater & chlorides. Durable, recyclable, sustainable.
                </p>
              </div>
            </div>

            {/* Pillar 4 */}
            <div className="flex items-start gap-3.5 p-3 rounded-xl hover:bg-slate-800/30 transition-colors">
              <div className="p-2.5 rounded-lg bg-slate-800/80 border border-slate-700 text-amber-400 shrink-0">
                <Award className="w-5 h-5" />
              </div>
              <div>
                <h4 className="text-sm font-bold text-white tracking-wide flex items-center gap-1.5">
                  <span>British Innovation</span>
                  <span className="text-[10px] px-1.5 py-0.2 rounded bg-amber-500/20 text-amber-300 font-mono">UK</span>
                </h4>
                <p className="text-xs text-slate-400 mt-0.5">
                  Engineering excellence rooted in Sheffield’s metallurgical cluster.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
