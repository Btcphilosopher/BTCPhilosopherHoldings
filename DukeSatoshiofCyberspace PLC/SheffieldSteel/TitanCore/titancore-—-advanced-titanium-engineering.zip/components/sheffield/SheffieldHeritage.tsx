'use client';

import React from 'react';
import { Building2, Compass, Landmark, Lightbulb, Users, ArrowRight } from 'lucide-react';

interface SheffieldHeritageProps {
  onExploreStock: () => void;
  onOpenRfq: () => void;
}

export const SheffieldHeritage: React.FC<SheffieldHeritageProps> = ({
  onExploreStock,
  onOpenRfq,
}) => {
  return (
    <div className="bg-[#090d12] text-slate-100 py-12 lg:py-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="max-w-3xl mb-12">
          <span className="text-xs font-mono font-semibold uppercase tracking-widest text-cyan-400">
            METALLURGICAL ROOTS & INDUSTRIAL ECOSYSTEM
          </span>
          <h1 className="text-3xl sm:text-4xl font-extrabold text-white mt-1 tracking-tight">
            Sheffield: The Steel Capital Reborn in Titanium
          </h1>
          <p className="text-slate-300 text-sm sm:text-base mt-3 leading-relaxed">
            From Huntsman’s crucible steel to Harry Brearley’s invention of stainless steel in 1913, 
            Sheffield forged the modern materials age. TitanCore carries that legacy into the titanium era.
          </p>
        </div>

        {/* Heritage Story Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center mb-16">
          <div className="lg:col-span-7 space-y-4 text-sm text-slate-300 leading-relaxed">
            <p>
              South Yorkshire possesses a density of metallurgical knowledge, precision machining talent, 
              and materials testing infrastructure unmatched anywhere in Europe. Along the River Don, where 
              Bessemer converters once supplied the globe, TitanCore coordinates advanced titanium distribution, 
              sawing, waterjet profile cutting, and subsea engineering packages.
            </p>
            <p>
              Rather than attempting to build an unviable, capital-intensive primary titanium sponge reduction mill, 
              TitanCore’s disciplined staged model capitalizes on Sheffield’s existing high-value engineering cluster: 
              high-speed 5-axis machine shops, heat treatment specialists, UKAS testing laboratories, and aerospace 
              metrology centers.
            </p>
            <div className="pt-2 flex flex-wrap gap-4 text-xs font-mono text-cyan-400">
              <span className="bg-slate-900 px-3 py-1.5 rounded-lg border border-slate-800">
                • Olympic Legacy Park Facility
              </span>
              <span className="bg-slate-900 px-3 py-1.5 rounded-lg border border-slate-800">
                • AMRC Engineering Corridor
              </span>
              <span className="bg-slate-900 px-3 py-1.5 rounded-lg border border-slate-800">
                • High-Value Manufacturing Catapult
              </span>
            </div>
          </div>

          <div className="lg:col-span-5 bg-gradient-to-br from-slate-900 to-slate-950 p-6 rounded-2xl border border-slate-800 shadow-xl">
            <h3 className="text-sm font-mono font-bold text-white uppercase tracking-wider mb-4 flex items-center gap-2">
              <Landmark className="w-4 h-4 text-cyan-400" />
              Sheffield Regional Partnerships Roadmap
            </h3>

            <div className="space-y-4 text-xs">
              <div className="border-l-2 border-cyan-500 pl-3">
                <div className="font-bold text-white">University of Sheffield & AMRC</div>
                <div className="text-slate-400">
                  Collaborative process research on cryogenic machining and tool wear suppression for Ti-6Al-4V.
                </div>
              </div>

              <div className="border-l-2 border-cyan-500 pl-3">
                <div className="font-bold text-white">Sheffield Testing Laboratories (UKAS #0142)</div>
                <div className="text-slate-400">
                  Independent third-party verification for tensile testing, Charpy impact, and chemical LECO gas combustion.
                </div>
              </div>

              <div className="border-l-2 border-cyan-500 pl-3">
                <div className="font-bold text-white">Henry Royce Institute for Advanced Materials</div>
                <div className="text-slate-400">
                  Investigating near-net-shape titanium powder metallurgy and sustainable circular scrap recovery.
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* 3-Stage Business Model Walkthrough */}
        <div className="border-t border-slate-800 pt-12">
          <div className="max-w-2xl mb-8">
            <span className="text-[10px] font-mono text-cyan-400 font-bold uppercase tracking-wider">
              COMMERCIAL DISCIPLINE & CAPITAL EFFICIENCY
            </span>
            <h3 className="text-2xl font-bold text-white mt-1">
              TitanCore Staged Business Model
            </h3>
            <p className="text-xs text-slate-400 mt-1">
              How we generate commercial revenue and build customer trust before capital expenditure.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="bg-slate-950 p-6 rounded-xl border border-cyan-800/60 relative">
              <div className="text-[10px] font-mono text-cyan-400 font-bold uppercase mb-2">
                STAGE ONE (ACTIVE)
              </div>
              <h4 className="text-lg font-bold text-white mb-2">Technical Distribution</h4>
              <p className="text-xs text-slate-300 leading-relaxed">
                Stocking proven grades (Ti-6Al-4V Gr 5, Gr 23 ELI, CP Gr 2) with certified mill traceability. 
                Immediate revenue generation via cut-to-size plate, bar, billet, and tube packages.
              </p>
            </div>

            <div className="bg-slate-950 p-6 rounded-xl border border-slate-800 relative">
              <div className="text-[10px] font-mono text-amber-400 font-bold uppercase mb-2">
                STAGE TWO (ACTIVE)
              </div>
              <h4 className="text-lg font-bold text-white mb-2">Precision Partner Processing</h4>
              <p className="text-xs text-slate-300 leading-relaxed">
                Leveraging Sheffield&apos;s qualified machine shops for 5-axis milling, waterjet cutting, and CMM inspection. 
                Capturing high-margin processing revenue without early machinery debt.
              </p>
            </div>

            <div className="bg-slate-950 p-6 rounded-xl border border-slate-800 relative">
              <div className="text-[10px] font-mono text-slate-500 font-bold uppercase mb-2">
                STAGE THREE (EXPANSION)
              </div>
              <h4 className="text-lg font-bold text-white mb-2">In-House Advanced Cells</h4>
              <p className="text-xs text-slate-300 leading-relaxed">
                Targeted CapEx investments in dedicated 5-axis CNC cells, specialized titanium finishing, and powder handling once throughput justifies the investment case.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
