'use client';

import React, { useState } from 'react';
import { 
  FileText, 
  Send, 
  CheckCircle2, 
  Calculator, 
  ShieldCheck, 
  Sparkles, 
  Clock, 
  Building2, 
  User, 
  Mail, 
  MapPin, 
  Calendar,
  X
} from 'lucide-react';
import { TITANIUM_MATERIALS } from '@/lib/data';
import { TitaniumMaterial, ProductForm, Quotation } from '@/lib/types';

interface RfqWizardProps {
  initialMaterial?: TitaniumMaterial | null;
  onClose?: () => void;
  onSubmitSuccess?: (newQuote: Quotation) => void;
}

export const RfqWizard: React.FC<RfqWizardProps> = ({
  initialMaterial,
  onClose,
  onSubmitSuccess,
}) => {
  const [selectedMaterialId, setSelectedMaterialId] = useState<string>(
    initialMaterial ? initialMaterial.id : 'ti-gr5'
  );
  const [form, setForm] = useState<ProductForm>('plate');
  const [dimensions, setDimensions] = useState<string>('25mm x 500mm x 1000mm');
  const [quantity, setQuantity] = useState<number>(4);
  const [unitDesc, setUnitDesc] = useState<string>('pcs');
  const [requiredStandard, setRequiredStandard] = useState<string>('AMS 4911 / ASTM B265');
  const [processingRequirement, setProcessingRequirement] = useState<string>('waterjet_cut');
  const [certRequirement, setCertRequirement] = useState<'3.1' | '3.2'>('3.1');
  const [ultrasonicTesting, setUltrasonicTesting] = useState<boolean>(true);
  
  // Client details
  const [companyName, setCompanyName] = useState<string>('AeroTech Dynamics Ltd');
  const [contactName, setContactName] = useState<string>('Mark Reynolds');
  const [contactEmail, setContactEmail] = useState<string>('m.reynolds@aerotech.co.uk');
  const [sector, setSector] = useState<string>('Aerospace');
  const [deliveryLocation, setDeliveryLocation] = useState<string>('Sheffield / UK Dispatch');
  const [targetDeliveryWeeks, setTargetDeliveryWeeks] = useState<number>(2);
  const [notes, setNotes] = useState<string>('Components required for structural flight brackets. Edge condition to be waterjet cut with ±0.5mm tolerance.');

  const [submitted, setSubmitted] = useState<boolean>(false);
  const [generatedQuoteRef, setGeneratedQuoteRef] = useState<string>('');

  const selectedMaterial = TITANIUM_MATERIALS.find(m => m.id === selectedMaterialId) || TITANIUM_MATERIALS[0];

  // Preliminary live cost calculation estimate
  // Estimate weight based on typical dimensions
  const approxWeightPerUnitKg = form === 'plate' ? 27.6 : (form === 'bar' ? 14.2 : 8.5);
  const totalWeightKg = approxWeightPerUnitKg * quantity;
  const rawMaterialCost = totalWeightKg * selectedMaterial.basePricePerKgEstimateGbp;
  const processingCost = processingRequirement === 'waterjet_cut' ? 450 : (processingRequirement === 'cnc_machined' ? 1200 : 80);
  const certFee = certRequirement === '3.2' ? 450 : 85;
  const utFee = ultrasonicTesting ? 220 : 0;
  const totalCostBasis = rawMaterialCost + processingCost + certFee + utFee + 120; // +120 logistics
  // Target 28% margin: Price = Cost / (1 - 0.28)
  const targetMargin = 0.28;
  const estimatedQuotedPrice = Math.round(totalCostBasis / (1 - targetMargin));

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const quoteSeq = (quantity * 17 + dimensions.length * 3) % 900 + 100;
    const newQuoteNum = `TC-QT-2026-${quoteSeq}`;
    setGeneratedQuoteRef(newQuoteNum);

    const newQuotation: Quotation = {
      id: `qt-${quoteSeq}`,
      quoteNumber: newQuoteNum,
      clientCompany: companyName,
      contactName: contactName,
      contactEmail: contactEmail,
      industrySector: sector,
      requestDate: '2026-10-13',
      validityDays: 14,
      status: 'Draft',
      pricingMode: 'margin',
      targetMarginOrMarkupPercent: 28.0,
      currencyRiskHedgingPercent: 1.5,
      overheadAllocationGbp: 250,
      lines: [
        {
          id: `ln-${quoteSeq}`,
          materialId: selectedMaterial.id,
          materialName: `${selectedMaterial.name} (${requiredStandard})`,
          form: form,
          dimensions: dimensions,
          quantityUnits: quantity,
          netWeightKgPerUnit: approxWeightPerUnitKg,
          totalNetWeightKg: totalWeightKg,
          grossWeightKgWithYield: totalWeightKg * 1.15,
          rawMaterialCostPerKgGbp: selectedMaterial.basePricePerKgEstimateGbp,
          machiningHoursPerUnit: processingRequirement === 'cnc_machined' ? 4 : 1,
          machiningHourlyRateGbp: 85,
          testingInspectionFeeGbp: certFee + utFee,
          packagingTransportGbp: 120,
          scrapYieldLossPercent: 15,
        },
      ],
      totalRawCostGbp: rawMaterialCost,
      totalProcessingCostGbp: processingCost,
      totalQualityInspectionCostGbp: certFee + utFee,
      totalLogisticsCostGbp: 120,
      totalCostBasisGbp: totalCostBasis,
      totalQuotedPriceGbp: estimatedQuotedPrice,
      calculatedGrossProfitGbp: estimatedQuotedPrice - totalCostBasis,
      effectiveGrossMarginPercent: 28.0,
      effectiveMarkupPercent: ( (estimatedQuotedPrice - totalCostBasis) / totalCostBasis ) * 100,
      notes: notes,
    };

    if (onSubmitSuccess) {
      onSubmitSuccess(newQuotation);
    }
    setSubmitted(true);
  };

  return (
    <div className="bg-[#090d12] text-slate-100 py-12 lg:py-16">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Top Header */}
        <div className="flex items-start justify-between mb-8 pb-6 border-b border-slate-800">
          <div>
            <span className="text-xs font-mono font-semibold uppercase tracking-widest text-cyan-400">
              COMMERCIAL PROCUREMENT GATEWAY
            </span>
            <h1 className="text-3xl font-extrabold text-white mt-1">
              Request a Technical Quotation (RFQ)
            </h1>
            <p className="text-slate-300 text-sm mt-1 max-w-2xl">
              Submit your materials or machined component requirements. Our Sheffield estimating desk 
              evaluates material availability, certification requirements, and provides formal pricing within 4 business hours.
            </p>
          </div>

          {onClose && (
            <button
              onClick={onClose}
              className="p-2 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800"
            >
              <X className="w-5 h-5" />
            </button>
          )}
        </div>

        {submitted ? (
          <div className="bg-slate-950 p-8 rounded-2xl border border-emerald-800/80 text-center space-y-4 animate-in fade-in">
            <div className="w-16 h-16 rounded-full bg-emerald-950/80 border-2 border-emerald-500 text-emerald-400 flex items-center justify-center mx-auto">
              <CheckCircle2 className="w-8 h-8" />
            </div>
            <h2 className="text-2xl font-bold text-white">
              Quotation Enquiry Successfully Registered
            </h2>
            <p className="text-slate-300 text-sm max-w-lg mx-auto font-mono">
              Reference: <span className="text-cyan-400 font-bold">{generatedQuoteRef}</span>
            </p>
            <p className="text-xs text-slate-400 max-w-md mx-auto">
              Your technical enquiry has been routed directly into the <strong>TitanCore Commercial Operating System (TitanOS)</strong>.
              A senior metallurgist is reviewing the batch certificates and waterjet schedule.
            </p>

            <div className="pt-6 flex justify-center gap-4">
              <button
                onClick={() => {
                  setSubmitted(false);
                  if (onClose) onClose();
                }}
                className="px-6 py-2.5 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-semibold"
              >
                Return to Materials Portal
              </button>
            </div>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="grid grid-cols-1 lg:grid-cols-12 gap-8">
            {/* Left Column: Form Inputs */}
            <div className="lg:col-span-7 space-y-6 bg-slate-950 p-6 rounded-2xl border border-slate-800">
              <h3 className="text-sm font-mono font-bold text-cyan-400 uppercase tracking-wider flex items-center gap-2">
                <FileText className="w-4 h-4" />
                1. Material & Dimensional Specifications
              </h3>

              {/* Alloy & Form */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-mono text-slate-400 mb-1">Titanium Grade</label>
                  <select
                    value={selectedMaterialId}
                    onChange={(e) => setSelectedMaterialId(e.target.value)}
                    className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2.5 text-xs text-white"
                  >
                    {TITANIUM_MATERIALS.map((m) => (
                      <option key={m.id} value={m.id}>
                        {m.name}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-mono text-slate-400 mb-1">Product Form</label>
                  <select
                    value={form}
                    onChange={(e) => setForm(e.target.value as ProductForm)}
                    className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2.5 text-xs text-white capitalize"
                  >
                    <option value="plate">Plate</option>
                    <option value="sheet">Sheet</option>
                    <option value="bar">Round Bar</option>
                    <option value="billet">Forged Billet</option>
                    <option value="tube">Tube / Pipe</option>
                    <option value="forgings">Near-Net Forging</option>
                    <option value="fasteners">Precision Fasteners</option>
                  </select>
                </div>
              </div>

              {/* Dimensions & Standard */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-mono text-slate-400 mb-1">Dimensions & Tolerances</label>
                  <input
                    type="text"
                    value={dimensions}
                    onChange={(e) => setDimensions(e.target.value)}
                    placeholder="e.g. 25mm x 500mm x 1000mm"
                    required
                    className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2.5 text-xs text-white font-mono"
                  />
                </div>

                <div>
                  <label className="block text-xs font-mono text-slate-400 mb-1">Required Standard</label>
                  <input
                    type="text"
                    value={requiredStandard}
                    onChange={(e) => setRequiredStandard(e.target.value)}
                    placeholder="e.g. AMS 4911 / ASTM B265"
                    required
                    className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2.5 text-xs text-white font-mono"
                  />
                </div>
              </div>

              {/* Quantity & Processing */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-mono text-slate-400 mb-1">Quantity</label>
                  <div className="flex gap-2">
                    <input
                      type="number"
                      min={1}
                      value={quantity}
                      onChange={(e) => setQuantity(Math.max(1, Number(e.target.value)))}
                      required
                      className="w-24 bg-slate-900 border border-slate-700 rounded-lg p-2.5 text-xs text-white font-mono"
                    />
                    <select
                      value={unitDesc}
                      onChange={(e) => setUnitDesc(e.target.value)}
                      className="flex-1 bg-slate-900 border border-slate-700 rounded-lg p-2.5 text-xs text-white"
                    >
                      <option value="pcs">Pieces</option>
                      <option value="meters">Meters</option>
                      <option value="kg">Kilograms (kg)</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-mono text-slate-400 mb-1">Processing Required</label>
                  <select
                    value={processingRequirement}
                    onChange={(e) => setProcessingRequirement(e.target.value)}
                    className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2.5 text-xs text-white"
                  >
                    <option value="saw_cut">Raw Saw Cut to Length</option>
                    <option value="waterjet_cut">5-Axis Abrasive Waterjet Profile</option>
                    <option value="cnc_machined">Precision CNC Finish Machined</option>
                    <option value="as_rolled">As Mill Stocked</option>
                  </select>
                </div>
              </div>

              {/* Quality & Certifications */}
              <div className="pt-2 border-t border-slate-800 space-y-3">
                <label className="block text-xs font-mono text-slate-400 uppercase">
                  Quality & Inspection Certifications Required
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                  <label className="flex items-center gap-2 text-slate-300 cursor-pointer">
                    <input
                      type="radio"
                      name="certReq"
                      checked={certRequirement === '3.1'}
                      onChange={() => setCertRequirement('3.1')}
                      className="text-cyan-500"
                    />
                    <span>EN 10204 3.1 Mill Test Report</span>
                  </label>
                  <label className="flex items-center gap-2 text-slate-300 cursor-pointer">
                    <input
                      type="radio"
                      name="certReq"
                      checked={certRequirement === '3.2'}
                      onChange={() => setCertRequirement('3.2')}
                      className="text-cyan-500"
                    />
                    <span>EN 10204 3.2 Third-Party Inspection</span>
                  </label>
                </div>

                <div className="pt-1">
                  <label className="flex items-center gap-2 text-xs text-slate-300 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={ultrasonicTesting}
                      onChange={(e) => setUltrasonicTesting(e.target.checked)}
                      className="text-cyan-500 rounded"
                    />
                    <span>Ultrasonic Volumetric Flaw Inspection (AMS 2631 / ASTM B388)</span>
                  </label>
                </div>
              </div>

              {/* Client & Logistics Details */}
              <div className="pt-4 border-t border-slate-800 space-y-4">
                <h3 className="text-sm font-mono font-bold text-cyan-400 uppercase tracking-wider flex items-center gap-2">
                  <Building2 className="w-4 h-4" />
                  2. Procurement & Contact Information
                </h3>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-mono text-slate-400 mb-1">Company Name</label>
                    <input
                      type="text"
                      value={companyName}
                      onChange={(e) => setCompanyName(e.target.value)}
                      required
                      className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2.5 text-xs text-white"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-mono text-slate-400 mb-1">Sector</label>
                    <select
                      value={sector}
                      onChange={(e) => setSector(e.target.value)}
                      className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2.5 text-xs text-white"
                    >
                      <option value="Aerospace">Aerospace & Defence</option>
                      <option value="Energy">Clean Energy & Offshore</option>
                      <option value="Medical">Medical Devices & Implants</option>
                      <option value="Industrial">Chemical & Process Plant</option>
                      <option value="Automotive">Motorsport & Automotive</option>
                      <option value="Other">Other Advanced Engineering</option>
                    </select>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-mono text-slate-400 mb-1">Contact Name</label>
                    <input
                      type="text"
                      value={contactName}
                      onChange={(e) => setContactName(e.target.value)}
                      required
                      className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2.5 text-xs text-white"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-mono text-slate-400 mb-1">Business Email</label>
                    <input
                      type="email"
                      value={contactEmail}
                      onChange={(e) => setContactEmail(e.target.value)}
                      required
                      className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2.5 text-xs text-white"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-mono text-slate-400 mb-1">Application Notes / Technical Drawings</label>
                  <textarea
                    rows={2}
                    value={notes}
                    onChange={(e) => setNotes(e.target.value)}
                    className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2.5 text-xs text-white"
                  />
                </div>
              </div>
            </div>

            {/* Right Column: Live Quotation Summary & Preliminary Estimate */}
            <div className="lg:col-span-5 space-y-6">
              <div className="bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950 p-6 rounded-2xl border border-slate-800 space-y-5">
                <div>
                  <span className="text-[10px] font-mono text-cyan-400 font-bold uppercase tracking-wider">
                    INDICATIVE COST BASIS ENGINE
                  </span>
                  <h4 className="text-xl font-bold text-white mt-1">
                    Preliminary Estimate Breakdown
                  </h4>
                  <p className="text-xs text-slate-400 mt-1">
                    Transparent formula based on current raw titanium spot index and Sheffield processing rates.
                  </p>
                </div>

                {/* Breakdown List */}
                <div className="space-y-2.5 text-xs font-mono">
                  <div className="bg-slate-900/80 p-3 rounded-lg border border-slate-800 flex justify-between">
                    <span className="text-slate-400">Net Titanium Material (~{totalWeightKg.toFixed(1)} kg):</span>
                    <span className="text-white font-semibold">£{rawMaterialCost.toFixed(2)}</span>
                  </div>
                  <div className="bg-slate-900/80 p-3 rounded-lg border border-slate-800 flex justify-between">
                    <span className="text-slate-400">Processing & Waterjet Setup:</span>
                    <span className="text-white font-semibold">£{processingCost.toFixed(2)}</span>
                  </div>
                  <div className="bg-slate-900/80 p-3 rounded-lg border border-slate-800 flex justify-between">
                    <span className="text-slate-400">Certification ({certRequirement} + UT):</span>
                    <span className="text-white font-semibold">£{(certFee + utFee).toFixed(2)}</span>
                  </div>
                  <div className="bg-slate-900/80 p-3 rounded-lg border border-slate-800 flex justify-between">
                    <span className="text-slate-400">Packaging, Crating & Logistics:</span>
                    <span className="text-white font-semibold">£120.00</span>
                  </div>

                  <div className="pt-2 border-t border-slate-800 flex justify-between text-sm">
                    <span className="text-slate-300 font-sans font-bold">Total Estimated Cost Basis:</span>
                    <span className="text-slate-200 font-bold">£{totalCostBasis.toFixed(2)}</span>
                  </div>

                  <div className="bg-cyan-950/60 border border-cyan-800/80 p-4 rounded-xl flex justify-between items-center text-sm">
                    <div>
                      <div className="text-[10px] text-cyan-400 font-bold uppercase font-mono">Indicative Budget Price</div>
                      <div className="text-slate-400 text-[11px] font-sans">Target Margin: ~28%</div>
                    </div>
                    <div className="text-right">
                      <div className="text-2xl font-black text-cyan-300 font-mono">
                        £{estimatedQuotedPrice.toLocaleString()}
                      </div>
                      <div className="text-[10px] text-slate-400 font-mono">ex VAT</div>
                    </div>
                  </div>
                </div>

                <div className="text-[11px] text-slate-400 space-y-1">
                  <div className="flex items-center gap-2">
                    <ShieldCheck className="w-4 h-4 text-emerald-400" />
                    <span>EN 10204 3.1 Certified Batch with Full Traceability</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Clock className="w-4 h-4 text-cyan-400" />
                    <span>Target Dispatch: ~{targetDeliveryWeeks} Weeks from Order</span>
                  </div>
                </div>

                <button
                  type="submit"
                  className="w-full py-3.5 rounded-xl bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white font-semibold text-sm shadow-xl flex items-center justify-center gap-2 active:scale-95 transition-all"
                >
                  <Send className="w-4 h-4" />
                  <span>Submit RFQ to TitanCore Engineering</span>
                </button>
              </div>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};
