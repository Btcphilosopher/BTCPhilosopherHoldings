'use client';

import React from 'react';
import { 
  Crosshair, 
  Flame, 
  ShieldAlert, 
  Cog, 
  Cpu, 
  CheckCircle, 
  AlertTriangle, 
  ArrowRight,
  Sparkles,
  Layers
} from 'lucide-react';

interface ProcessingCapabilitiesProps {
  onOpenRfq: () => void;
  onAskAi: (query: string) => void;
}

export const ProcessingCapabilities: React.FC<ProcessingCapabilitiesProps> = ({
  onOpenRfq,
  onAskAi,
}) => {
  const capabilities = [
    {
      title: 'Abrasive Waterjet Profile Cutting',
      tagline: 'Zero Heat-Affected Zone (HAZ)',
      description: 'Dynamic 5-axis waterjet cutting of titanium plate up to 150mm thickness. Taper-compensated cutting heads achieve ±0.2mm profile tolerances with no thermal microstructural degradation or alpha-case phase transformation.',
      specs: ['Max plate thickness: 150mm', 'Tolerances: ±0.2mm', 'Zero thermal stress / HAZ', 'Complex nesting for yield optimization'],
      icon: Crosshair,
    },
    {
      title: 'High-Precision 5-Axis CNC Machining',
      tagline: 'High-Pressure Flood Coolant (70 bar)',
      description: 'Specialist titanium machining cells utilizing rigid DMG MORI and Hermle 5-axis platforms. Equipped with 70-bar through-spindle coolant to immediately evacuate heat and prevent tool-edge galling.',
      specs: ['Envelopes up to 1250 x 1000 x 1000mm', 'Through-spindle coolant: 70 bar', 'Custom trochoidal roughing toolpaths', 'Tolerance down to ±0.008mm'],
      icon: Cog,
    },
    {
      title: 'Precision Billet & Bar Sawing',
      tagline: 'Cold Carbide Band Sawing',
      description: 'High-capacity automatic band saws with dedicated titanium carbide blades and flooded synthetic emulsion. Cuts billets up to Ø450mm with clean square face tolerances for downstream forging or turning.',
      specs: ['Capacity: Ø10mm to Ø450mm', 'Squareness tolerance: ±0.3mm', 'Cold cutting with zero surface hardening', 'Rapid batch cutting capability'],
      icon: Layers,
    },
    {
      title: 'Metrology, CMM & PMI Inspection',
      tagline: 'Zeiss Contura & Niton XRF',
      description: 'Comprehensive dimensional verification inside a climate-controlled inspection lab (20°C ±0.5°C). Handheld XRF spectrometer for 100% Positive Material Identification (PMI) and immersion ultrasonic flaw detection.',
      specs: ['Zeiss Contura CMM (0.9µm + L/350)', 'Thermo Scientific Niton XRF Analyzer', 'Ultrasonic AMS 2631 Class AA', 'Full AS9100 Rev D FAI reports'],
      icon: Cpu,
    },
  ];

  return (
    <div className="bg-[#090d12] text-slate-100 py-12 lg:py-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="max-w-3xl mb-12">
          <span className="text-xs font-mono font-semibold uppercase tracking-widest text-cyan-400">
            SHEFFIELD ADVANCED MANUFACTURING NETWORK
          </span>
          <h1 className="text-3xl sm:text-4xl font-extrabold text-white mt-1 tracking-tight">
            Precision Titanium Processing
          </h1>
          <p className="text-slate-300 text-sm sm:text-base mt-3 leading-relaxed">
            TitanCore bridges raw material distribution and finished engineering through a qualified 
            network of Sheffield machining partners and rigorous in-house quality controls.
          </p>
        </div>

        {/* 4 Core Capabilities Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-16">
          {capabilities.map((cap, idx) => {
            const Icon = cap.icon;
            return (
              <div
                key={idx}
                className="bg-slate-950/80 border border-slate-800 rounded-xl p-6 hover:border-cyan-500/40 transition-all flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between mb-4">
                    <span className="text-[11px] font-mono text-cyan-400 font-semibold uppercase bg-cyan-950/60 px-2 py-0.5 rounded border border-cyan-800/60">
                      {cap.tagline}
                    </span>
                    <div className="p-2 rounded-lg bg-slate-800/80 text-cyan-400">
                      <Icon className="w-5 h-5" />
                    </div>
                  </div>

                  <h3 className="text-xl font-bold text-white mb-2">
                    {cap.title}
                  </h3>
                  <p className="text-xs sm:text-sm text-slate-300 leading-relaxed mb-4">
                    {cap.description}
                  </p>

                  <div className="space-y-1.5 pt-3 border-t border-slate-800 text-xs font-mono text-slate-400">
                    {cap.specs.map((spec, sIdx) => (
                      <div key={sIdx} className="flex items-center gap-2">
                        <CheckCircle className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
                        <span>{spec}</span>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="pt-6 mt-4 border-t border-slate-800 flex items-center justify-between">
                  <button
                    onClick={() => onAskAi(`What are the optimal parameters for ${cap.title}?`)}
                    className="text-xs text-slate-400 hover:text-cyan-400 flex items-center gap-1.5 transition-colors"
                  >
                    <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
                    <span>Machining Consultation</span>
                  </button>

                  <button
                    onClick={onOpenRfq}
                    className="text-xs font-semibold text-cyan-400 hover:text-cyan-300 flex items-center gap-1 group"
                  >
                    <span>Request processing</span>
                    <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>

        {/* Safety & Pyrophoric Engineering Protocol Box */}
        <div className="bg-gradient-to-r from-red-950/40 via-slate-900 to-amber-950/30 border border-red-800/50 rounded-2xl p-6 sm:p-8">
          <div className="flex flex-col lg:flex-row gap-6 items-start lg:items-center justify-between">
            <div className="max-w-3xl space-y-3">
              <div className="flex items-center gap-2 text-red-400 font-mono text-xs font-bold uppercase tracking-wider">
                <Flame className="w-4 h-4 text-red-400 animate-pulse" />
                <span>TITANIUM PROCESS ENGINEERING & PYROPHORIC FIRE SAFETY</span>
              </div>
              <h3 className="text-xl sm:text-2xl font-bold text-white">
                Mandatory Operational Safety Protocols
              </h3>
              <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
                Titanium chips, fines, and dust exhibit extreme chemical reactivity with oxygen at elevated temperatures. 
                Frictional rubbing of dull tools can ignite thin titanium ribbons at temperatures above 330°C. 
                TitanCore enforces strictly audited workshop standards:
              </p>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2 text-xs font-mono">
                <div className="flex items-start gap-2 text-slate-200 bg-slate-950/60 p-2.5 rounded-lg border border-slate-800">
                  <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                  <span><strong>Class D Extinguishers Only:</strong> Sodium chloride dry powder. Never use water or CO2.</span>
                </div>
                <div className="flex items-start gap-2 text-slate-200 bg-slate-950/60 p-2.5 rounded-lg border border-slate-800">
                  <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                  <span><strong>Swarf Containment:</strong> Daily clearance into airtight dry steel drums.</span>
                </div>
                <div className="flex items-start gap-2 text-slate-200 bg-slate-950/60 p-2.5 rounded-lg border border-slate-800">
                  <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                  <span><strong>High Flood Coolant:</strong> Minimum 8–10% emulsion; tool dwelling strictly forbidden.</span>
                </div>
                <div className="flex items-start gap-2 text-slate-200 bg-slate-950/60 p-2.5 rounded-lg border border-slate-800">
                  <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                  <span><strong>Explosion-Proof Extraction:</strong> Wet scrubber dust collectors for grinding bays.</span>
                </div>
              </div>
            </div>

            <div className="shrink-0 flex flex-col gap-3">
              <button
                onClick={() => onAskAi('What are the fire safety and coolant guidelines for titanium CNC milling?')}
                className="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white text-xs font-semibold flex items-center gap-2 border border-slate-700"
              >
                <Sparkles className="w-4 h-4 text-cyan-400" />
                <span>AI Safety Briefing</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
