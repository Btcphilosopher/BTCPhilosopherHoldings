'use client';

import React, { useState } from 'react';
import { 
  ShieldCheck, 
  FileCheck2, 
  Search, 
  CheckCircle2, 
  AlertTriangle, 
  Eye, 
  Download, 
  Building,
  Microscope,
  FileSpreadsheet
} from 'lucide-react';

export const QualityTraceability: React.FC = () => {
  const [sampleCertOpen, setSampleCertOpen] = useState(false);

  return (
    <div className="bg-[#090d12] text-slate-100 py-12 lg:py-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="max-w-3xl mb-12">
          <span className="text-xs font-mono font-semibold uppercase tracking-widest text-cyan-400">
            METALLURGICAL ASSURANCE & CERTIFICATION
          </span>
          <h1 className="text-3xl sm:text-4xl font-extrabold text-white mt-1 tracking-tight">
            Quality Management & Traceability
          </h1>
          <p className="text-slate-300 text-sm sm:text-base mt-3 leading-relaxed">
            TitanCore operates with zero tolerance for undocumented titanium. Every delivery is 
            physically tracked from vacuum arc remelting (VAR) ingot heats to dispatch with 
            positive material identification (PMI) and EN 10204 3.1 certification.
          </p>
        </div>

        {/* 4 Pillars of Quality */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-16">
          <div className="bg-slate-950 p-6 rounded-xl border border-slate-800 space-y-3">
            <div className="p-2.5 rounded-lg bg-cyan-950/80 border border-cyan-800 text-cyan-400 w-fit">
              <Microscope className="w-5 h-5" />
            </div>
            <h3 className="font-bold text-white text-base">Incoming Inspection & PMI</h3>
            <p className="text-xs text-slate-400 leading-relaxed">
              100% of incoming stock is verified using a calibrated handheld XRF spectrometer to guarantee elemental composition before binning into warehouse bays.
            </p>
          </div>

          <div className="bg-slate-950 p-6 rounded-xl border border-slate-800 space-y-3">
            <div className="p-2.5 rounded-lg bg-cyan-950/80 border border-cyan-800 text-cyan-400 w-fit">
              <FileCheck2 className="w-5 h-5" />
            </div>
            <h3 className="font-bold text-white text-base">EN 10204 3.1 & 3.2 Certs</h3>
            <p className="text-xs text-slate-400 leading-relaxed">
              Complete mill test reports validating mechanical properties, chemical interstitials (O, N, C, H), and heat treatment histories from accredited Western & Japanese mills.
            </p>
          </div>

          <div className="bg-slate-950 p-6 rounded-xl border border-slate-800 space-y-3">
            <div className="p-2.5 rounded-lg bg-cyan-950/80 border border-cyan-800 text-cyan-400 w-fit">
              <AlertTriangle className="w-5 h-5" />
            </div>
            <h3 className="font-bold text-white text-base">Quarantine Segregation</h3>
            <p className="text-xs text-slate-400 leading-relaxed">
              Physical locked quarantine bay (Zone Q-01) for material pending lab re-tests or discrepancy resolution. Quarantined stock is electronically barred from sale.
            </p>
          </div>

          <div className="bg-slate-950 p-6 rounded-xl border border-slate-800 space-y-3">
            <div className="p-2.5 rounded-lg bg-cyan-950/80 border border-cyan-800 text-cyan-400 w-fit">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <h3 className="font-bold text-white text-base">AS9100 / ISO 9001 Roadmap</h3>
            <p className="text-xs text-slate-400 leading-relaxed">
              Built on ISO 9001:2015 quality manuals with active transition to AS9100 Rev D for aerospace supply chain qualification, with UKAS audit milestones clearly defined.
            </p>
          </div>
        </div>

        {/* Interactive Sample Certificate Section */}
        <div className="bg-slate-950 p-6 sm:p-8 rounded-2xl border border-slate-800">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 pb-6 border-b border-slate-800">
            <div>
              <span className="text-[10px] font-mono text-cyan-400 font-bold uppercase tracking-wider">
                DOCUMENTATION INTEGRITY
              </span>
              <h3 className="text-2xl font-bold text-white mt-1">
                Standard Inspection Certificate Dossier
              </h3>
              <p className="text-xs text-slate-300 mt-1 max-w-xl">
                Inspect a real TitanCore demonstration EN 10204 3.1 Mill Test Report for Ti-6Al-4V Grade 5 plate.
              </p>
            </div>

            <button
              onClick={() => setSampleCertOpen(!sampleCertOpen)}
              className="px-4 py-2.5 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-semibold flex items-center gap-2 self-start md:self-auto transition-all"
            >
              <Eye className="w-4 h-4" />
              <span>{sampleCertOpen ? 'Hide Certificate Preview' : 'Inspect Sample EN 10204 3.1 MTR'}</span>
            </button>
          </div>

          {sampleCertOpen && (
            <div className="mt-6 p-6 rounded-xl bg-slate-900 border border-slate-700 text-slate-200 font-mono text-xs space-y-6 animate-in fade-in">
              {/* Header block */}
              <div className="flex flex-col sm:flex-row justify-between border-b border-slate-800 pb-4 gap-4">
                <div>
                  <div className="text-base font-bold text-white uppercase tracking-wider">
                    TITANCORE SHEFFIELD METALLURGICAL LABORATORY
                  </div>
                  <div className="text-[10px] text-slate-400">
                    Olympic Legacy Park, Sheffield S9, United Kingdom • UKAS Calibration Traceable
                  </div>
                </div>
                <div className="text-right sm:text-right">
                  <div className="text-cyan-400 font-bold">CERTIFICATE ID: TC-MTR-2026-884</div>
                  <div className="text-[10px] text-slate-400">ACCORDING TO BS EN 10204:2004 TYPE 3.1</div>
                </div>
              </div>

              {/* Order and Material specifics */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 bg-slate-950 p-4 rounded-lg border border-slate-800">
                <div>
                  <span className="text-[10px] text-slate-500 block uppercase">Product:</span>
                  <span className="text-white font-bold">Titanium Alloy Plate (Annealed)</span>
                </div>
                <div>
                  <span className="text-[10px] text-slate-500 block uppercase">Material Grade:</span>
                  <span className="text-cyan-400 font-bold">Ti-6Al-4V Grade 5 (AMS 4911)</span>
                </div>
                <div>
                  <span className="text-[10px] text-slate-500 block uppercase">Melt / Heat Number:</span>
                  <span className="text-white font-bold">TC-2026-HT884</span>
                </div>
                <div>
                  <span className="text-[10px] text-slate-500 block uppercase">Batch Lot:</span>
                  <span className="text-white font-bold">B-7712A</span>
                </div>
              </div>

              {/* Chemical Analysis */}
              <div>
                <h4 className="text-[11px] font-bold text-white uppercase tracking-wider mb-2">
                  Chemical Composition (% Weight by LECO & ICP-OES)
                </h4>
                <div className="overflow-x-auto">
                  <table className="w-full text-left bg-slate-950 border border-slate-800">
                    <thead className="bg-slate-900 text-slate-400 text-[10px] uppercase">
                      <tr>
                        <th className="p-2">Element</th>
                        <th className="p-2">Al</th>
                        <th className="p-2">V</th>
                        <th className="p-2">Fe</th>
                        <th className="p-2">O</th>
                        <th className="p-2">C</th>
                        <th className="p-2">N</th>
                        <th className="p-2">H</th>
                        <th className="p-2">Ti</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-800">
                      <tr>
                        <td className="p-2 text-slate-400">AMS 4911 Limits:</td>
                        <td className="p-2">5.50 - 6.75</td>
                        <td className="p-2">3.50 - 4.50</td>
                        <td className="p-2">&le; 0.30</td>
                        <td className="p-2">&le; 0.20</td>
                        <td className="p-2">&le; 0.08</td>
                        <td className="p-2">&le; 0.05</td>
                        <td className="p-2">&le; 0.015</td>
                        <td className="p-2">Balance</td>
                      </tr>
                      <tr className="text-cyan-300 font-bold">
                        <td className="p-2 text-white">Heat HT884 Actual:</td>
                        <td className="p-2">6.12</td>
                        <td className="p-2">4.08</td>
                        <td className="p-2">0.18</td>
                        <td className="p-2">0.14</td>
                        <td className="p-2">0.02</td>
                        <td className="p-2">0.01</td>
                        <td className="p-2">0.005</td>
                        <td className="p-2">Balance</td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>

              {/* Mechanical Properties */}
              <div>
                <h4 className="text-[11px] font-bold text-white uppercase tracking-wider mb-2">
                  Mechanical Properties (Tensile Tested at 21°C per ASTM E8M)
                </h4>
                <div className="overflow-x-auto">
                  <table className="w-full text-left bg-slate-950 border border-slate-800">
                    <thead className="bg-slate-900 text-slate-400 text-[10px] uppercase">
                      <tr>
                        <th className="p-2">Property</th>
                        <th className="p-2">Tensile Strength (Rm)</th>
                        <th className="p-2">Yield Strength (Rp 0.2%)</th>
                        <th className="p-2">Elongation (A5)</th>
                        <th className="p-2">Hardness</th>
                        <th className="p-2">Ultrasonic Test</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-800">
                      <tr>
                        <td className="p-2 text-slate-400">AMS 4911 Min Spec:</td>
                        <td className="p-2">&ge; 895 MPa</td>
                        <td className="p-2">&ge; 828 MPa</td>
                        <td className="p-2">&ge; 10 %</td>
                        <td className="p-2">30 - 39 HRC</td>
                        <td className="p-2">AMS 2631 Cl AA</td>
                      </tr>
                      <tr className="text-emerald-400 font-bold">
                        <td className="p-2 text-white">Batch Test Actual:</td>
                        <td className="p-2">952 MPa</td>
                        <td className="p-2">884 MPa</td>
                        <td className="p-2">14.2 %</td>
                        <td className="p-2">36 HRC</td>
                        <td className="p-2">CONFORMING</td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>

              {/* Sign-off */}
              <div className="pt-4 border-t border-slate-800 flex justify-between items-center text-[10px] text-slate-400">
                <div>
                  Quality Manager Sign-off: <span className="text-white font-bold">G. Butterworth (Lead Metrologist)</span>
                </div>
                <div className="flex items-center gap-1 text-emerald-400 font-bold">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>MATERIAL COMPLIANT — APPROVED FOR AEROSPACE DISPATCH</span>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
