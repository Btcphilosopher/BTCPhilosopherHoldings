'use client';

import React, { useState } from 'react';
import { 
  Search, 
  Filter, 
  Layers, 
  Sparkles, 
  ArrowRight, 
  X, 
  ShieldCheck, 
  Activity, 
  Thermometer, 
  Gauge, 
  FileSpreadsheet,
  Check
} from 'lucide-react';
import { TITANIUM_MATERIALS } from '@/lib/data';
import { TitaniumMaterial, GradeCategory, ProductForm } from '@/lib/types';

interface MaterialsCatalogueProps {
  onSelectForRfq: (material: TitaniumMaterial) => void;
  onAskAi: (query: string) => void;
}

export const MaterialsCatalogue: React.FC<MaterialsCatalogueProps> = ({
  onSelectForRfq,
  onAskAi,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [activeModalMaterial, setActiveModalMaterial] = useState<TitaniumMaterial | null>(null);

  const categories = [
    { id: 'all', label: 'All Titanium Grades' },
    { id: 'alpha_beta', label: 'Alpha-Beta (Grade 5, Grade 23)' },
    { id: 'commercially_pure', label: 'Commercially Pure (CP Gr 1–4)' },
    { id: 'near_alpha', label: 'Near-Alpha (Ti-6242 High Temp)' },
    { id: 'beta', label: 'Beta Alloys (Beta-C High Strength)' },
    { id: 'specialty', label: 'Palladium Enhanced (Grade 7 / 11)' },
  ];

  const filteredMaterials = TITANIUM_MATERIALS.filter((mat) => {
    const matchesCategory = selectedCategory === 'all' || mat.category === selectedCategory;
    const query = searchTerm.toLowerCase();
    const matchesSearch = 
      mat.name.toLowerCase().includes(query) ||
      mat.designation.toLowerCase().includes(query) ||
      mat.commonName.toLowerCase().includes(query) ||
      mat.typicalApplications.some(app => app.toLowerCase().includes(query)) ||
      (mat.standards.astm && mat.standards.astm.some(s => s.toLowerCase().includes(query))) ||
      (mat.standards.ams && mat.standards.ams.some(s => s.toLowerCase().includes(query)));

    return matchesCategory && matchesSearch;
  });

  return (
    <div className="bg-[#090d12] text-slate-100 py-12 lg:py-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-10 pb-6 border-b border-slate-800">
          <div>
            <span className="text-xs font-mono font-semibold uppercase tracking-widest text-cyan-400">
              SHEFFIELD TECHNICAL MATERIALS DATABASE
            </span>
            <h1 className="text-3xl sm:text-4xl font-extrabold text-white mt-1 tracking-tight">
              Titanium Grades & Specifications
            </h1>
            <p className="text-slate-300 text-sm sm:text-base mt-2 max-w-2xl">
              Verified metallurgical specifications across ASTM, AMS, ISO, and BS EN standards. 
              Each batch is tracked with physical heat number traceability and EN 10204 3.1 mill certification.
            </p>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={() => onAskAi('Compare Ti-6Al-4V Grade 5 vs Grade 23 ELI for cryogenic tanks')}
              className="px-4 py-2 rounded-lg bg-cyan-950/80 text-cyan-300 border border-cyan-800/80 hover:bg-cyan-900 text-xs font-semibold flex items-center gap-2 transition-colors"
            >
              <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
              <span>Ask AI: Compare Grades</span>
            </button>
          </div>
        </div>

        {/* Filter and Search Bar */}
        <div className="space-y-4 mb-8">
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="relative flex-1">
              <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Search by alloy, ASTM/AMS spec, application (e.g. 'AMS 4911', 'Medical', '6242')..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-10 pr-4 py-2.5 rounded-lg bg-slate-900/90 border border-slate-700 text-sm text-white placeholder-slate-400 focus:outline-none focus:border-cyan-500"
              />
              {searchTerm && (
                <button 
                  onClick={() => setSearchTerm('')}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white"
                >
                  <X className="w-4 h-4" />
                </button>
              )}
            </div>

            <div className="flex items-center gap-2 text-xs font-mono text-slate-400 px-3 py-2 bg-slate-900/60 rounded-lg border border-slate-800 shrink-0">
              <Activity className="w-4 h-4 text-cyan-400" />
              <span>{filteredMaterials.length} of {TITANIUM_MATERIALS.length} Alloys Displayed</span>
            </div>
          </div>

          {/* Category Tabs */}
          <div className="flex flex-wrap gap-2 pt-1">
            {categories.map((cat) => (
              <button
                key={cat.id}
                onClick={() => setSelectedCategory(cat.id)}
                className={`px-3 py-1.5 rounded-md text-xs font-medium transition-all ${
                  selectedCategory === cat.id
                    ? 'bg-cyan-600 text-white shadow-sm'
                    : 'bg-slate-900 text-slate-300 hover:bg-slate-800 border border-slate-800'
                }`}
              >
                {cat.label}
              </button>
            ))}
          </div>
        </div>

        {/* Materials Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredMaterials.map((mat) => (
            <div
              key={mat.id}
              className="bg-slate-950/80 border border-slate-800 hover:border-slate-700 rounded-xl overflow-hidden flex flex-col justify-between transition-all hover:shadow-xl group"
            >
              <div className="p-5">
                {/* Top Badge Row */}
                <div className="flex items-center justify-between mb-3">
                  <span className="text-[11px] font-mono px-2 py-0.5 rounded bg-slate-900 border border-slate-800 text-cyan-400 uppercase font-semibold">
                    {mat.category.replace('_', ' ')}
                  </span>
                  <span className={`text-[11px] font-mono px-2 py-0.5 rounded border ${
                    mat.sheffieldStockStatus === 'Immediate Stock'
                      ? 'bg-emerald-950/80 text-emerald-400 border-emerald-800/80'
                      : 'bg-amber-950/80 text-amber-400 border-amber-800/80'
                  }`}>
                    {mat.sheffieldStockStatus}
                  </span>
                </div>

                {/* Title */}
                <h3 className="text-xl font-bold text-white group-hover:text-cyan-300 transition-colors">
                  {mat.name}
                </h3>
                <div className="text-xs text-slate-400 font-mono mt-0.5">
                  {mat.designation}
                </div>

                <p className="text-xs text-slate-300 mt-3 line-clamp-3 leading-relaxed">
                  {mat.description}
                </p>

                {/* Key Properties Grid */}
                <div className="grid grid-cols-2 gap-2 mt-4 pt-3 border-t border-slate-800/80 text-xs">
                  <div className="bg-slate-900/60 p-2 rounded border border-slate-800/60">
                    <span className="text-[10px] text-slate-500 uppercase block font-mono">Tensile (Typical)</span>
                    <span className="font-mono font-bold text-white">{mat.tensileStrengthMpa.typical} MPa</span>
                  </div>
                  <div className="bg-slate-900/60 p-2 rounded border border-slate-800/60">
                    <span className="text-[10px] text-slate-500 uppercase block font-mono">Yield Strength</span>
                    <span className="font-mono font-bold text-white">{mat.yieldStrengthMpa.typical} MPa</span>
                  </div>
                  <div className="bg-slate-900/60 p-2 rounded border border-slate-800/60">
                    <span className="text-[10px] text-slate-500 uppercase block font-mono">Density / Modulus</span>
                    <span className="font-mono font-bold text-white">{mat.densityGPerCm3} g/cm³ · {mat.elasticModulusGpa} GPa</span>
                  </div>
                  <div className="bg-slate-900/60 p-2 rounded border border-slate-800/60">
                    <span className="text-[10px] text-slate-500 uppercase block font-mono">Max Service Temp</span>
                    <span className="font-mono font-bold text-amber-300">{mat.maxServiceTempC}°C</span>
                  </div>
                </div>

                {/* Available Forms */}
                <div className="mt-3">
                  <span className="text-[10px] text-slate-400 uppercase font-mono block mb-1">Available Product Forms:</span>
                  <div className="flex flex-wrap gap-1">
                    {mat.availableForms.map((form) => (
                      <span
                        key={form}
                        className="text-[10px] px-1.5 py-0.5 rounded bg-slate-800 text-slate-300 font-medium capitalize"
                      >
                        {form}
                      </span>
                    ))}
                  </div>
                </div>
              </div>

              {/* Action Footer */}
              <div className="px-5 py-3 bg-slate-900/80 border-t border-slate-800 flex items-center justify-between">
                <button
                  onClick={() => setActiveModalMaterial(mat)}
                  className="text-xs font-semibold text-cyan-400 hover:text-cyan-300 transition-colors"
                >
                  View Full Metallurgical Sheet →
                </button>

                <button
                  onClick={() => onSelectForRfq(mat)}
                  className="px-3 py-1.5 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-semibold transition-all shadow-sm active:scale-95"
                >
                  Request Quote
                </button>
              </div>
            </div>
          ))}
        </div>

        {/* Technical Specification Modal */}
        {activeModalMaterial && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in">
            <div className="bg-slate-900 border border-slate-700 rounded-2xl max-w-3xl w-full max-h-[90vh] overflow-y-auto shadow-2xl text-slate-200">
              {/* Modal Header */}
              <div className="p-6 border-b border-slate-800 flex items-start justify-between bg-slate-950/50 sticky top-0 z-10 backdrop-blur-md">
                <div>
                  <span className="text-xs font-mono font-semibold text-cyan-400 uppercase tracking-wider">
                    METALLURGICAL DATA SHEET — REVISION 2026.4
                  </span>
                  <h2 className="text-2xl font-bold text-white mt-1">
                    {activeModalMaterial.name}
                  </h2>
                  <div className="text-xs text-slate-400 font-mono mt-0.5">
                    {activeModalMaterial.designation}
                  </div>
                </div>

                <button
                  onClick={() => setActiveModalMaterial(null)}
                  className="p-2 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Modal Body */}
              <div className="p-6 space-y-6">
                {/* Description */}
                <div>
                  <h4 className="text-xs font-mono uppercase text-slate-400 font-semibold mb-1">
                    Material Overview
                  </h4>
                  <p className="text-sm text-slate-200 leading-relaxed">
                    {activeModalMaterial.description}
                  </p>
                </div>

                {/* Applicable Standards Box */}
                <div className="bg-slate-950 p-4 rounded-xl border border-slate-800">
                  <h4 className="text-xs font-mono uppercase text-cyan-400 font-semibold mb-2 flex items-center gap-2">
                    <FileSpreadsheet className="w-4 h-4" />
                    Applicable International Standards
                  </h4>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                    {activeModalMaterial.standards.astm && (
                      <div>
                        <span className="text-slate-400 font-mono">ASTM: </span>
                        <span className="text-slate-200">{activeModalMaterial.standards.astm.join(', ')}</span>
                      </div>
                    )}
                    {activeModalMaterial.standards.ams && (
                      <div>
                        <span className="text-slate-400 font-mono">AMS (Aerospace): </span>
                        <span className="text-slate-200">{activeModalMaterial.standards.ams.join(', ')}</span>
                      </div>
                    )}
                    {activeModalMaterial.standards.iso && (
                      <div>
                        <span className="text-slate-400 font-mono">ISO: </span>
                        <span className="text-slate-200">{activeModalMaterial.standards.iso.join(', ')}</span>
                      </div>
                    )}
                    {activeModalMaterial.standards.uns && (
                      <div>
                        <span className="text-slate-400 font-mono">UNS Number: </span>
                        <span className="text-slate-200 font-mono">{activeModalMaterial.standards.uns}</span>
                      </div>
                    )}
                  </div>
                </div>

                {/* Verified Mechanical & Physical Properties */}
                <div>
                  <h4 className="text-xs font-mono uppercase text-slate-400 font-semibold mb-3">
                    Validated Mechanical & Physical Properties (Typical Room Temp 20°C)
                  </h4>
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs font-mono">
                    <div className="bg-slate-950 p-3 rounded-lg border border-slate-800">
                      <span className="text-slate-400 block text-[10px]">DENSITY</span>
                      <span className="text-white font-bold text-sm">{activeModalMaterial.densityGPerCm3} g/cm³</span>
                    </div>
                    <div className="bg-slate-950 p-3 rounded-lg border border-slate-800">
                      <span className="text-slate-400 block text-[10px]">ELASTIC MODULUS</span>
                      <span className="text-white font-bold text-sm">{activeModalMaterial.elasticModulusGpa} GPa</span>
                    </div>
                    <div className="bg-slate-950 p-3 rounded-lg border border-slate-800">
                      <span className="text-slate-400 block text-[10px]">TENSILE (MIN / TYP)</span>
                      <span className="text-white font-bold text-sm">{activeModalMaterial.tensileStrengthMpa.min} / {activeModalMaterial.tensileStrengthMpa.typical} MPa</span>
                    </div>
                    <div className="bg-slate-950 p-3 rounded-lg border border-slate-800">
                      <span className="text-slate-400 block text-[10px]">YIELD (MIN / TYP)</span>
                      <span className="text-white font-bold text-sm">{activeModalMaterial.yieldStrengthMpa.min} / {activeModalMaterial.yieldStrengthMpa.typical} MPa</span>
                    </div>
                  </div>
                </div>

                {/* Fabrication & Machinability Guidelines */}
                <div className="space-y-3">
                  <h4 className="text-xs font-mono uppercase text-slate-400 font-semibold">
                    Fabrication & Corrosion Considerations
                  </h4>
                  <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-2 text-xs">
                    <div>
                      <span className="font-semibold text-white">Corrosion Performance: </span>
                      <span className="text-slate-300">{activeModalMaterial.corrosionCharacteristics}</span>
                    </div>
                    <div>
                      <span className="font-semibold text-white">Machinability Rating: </span>
                      <span className="text-cyan-400 font-mono font-bold">{activeModalMaterial.machinabilityRating}%</span>
                      <span className="text-slate-400"> (relative to AISI B1112 free-cutting steel = 100%). High pressure flood coolant mandatory.</span>
                    </div>
                    <div>
                      <span className="font-semibold text-white">Weldability: </span>
                      <span className="text-slate-300">{activeModalMaterial.weldability}. Strict trailing argon shielding required to avoid embrittling alpha-case contamination.</span>
                    </div>
                    <div>
                      <span className="font-semibold text-white">Standard Heat Treatment Conditions: </span>
                      <span className="text-slate-300">{activeModalMaterial.heatTreatmentConditions.join('; ')}</span>
                    </div>
                  </div>
                </div>

                {/* Applications list */}
                <div>
                  <h4 className="text-xs font-mono uppercase text-slate-400 font-semibold mb-2">
                    Primary Industrial Applications
                  </h4>
                  <div className="flex flex-wrap gap-2">
                    {activeModalMaterial.typicalApplications.map((app, i) => (
                      <span key={i} className="text-xs px-2.5 py-1 rounded bg-slate-800 text-slate-300 border border-slate-700">
                        {app}
                      </span>
                    ))}
                  </div>
                </div>
              </div>

              {/* Modal Footer */}
              <div className="p-6 border-t border-slate-800 bg-slate-950/60 flex flex-wrap items-center justify-between gap-4">
                <button
                  onClick={() => {
                    const mat = activeModalMaterial;
                    setActiveModalMaterial(null);
                    onAskAi(`What are the recommended cutting speeds, feed rates, and coolant requirements for ${mat.name}?`);
                  }}
                  className="px-4 py-2.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-cyan-400 text-xs font-semibold flex items-center gap-2 border border-slate-700"
                >
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>Consult AI Advisor on Speeds & Feeds</span>
                </button>

                <div className="flex items-center gap-3">
                  <button
                    onClick={() => setActiveModalMaterial(null)}
                    className="px-4 py-2.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold"
                  >
                    Close Sheet
                  </button>
                  <button
                    onClick={() => {
                      const mat = activeModalMaterial;
                      setActiveModalMaterial(null);
                      onSelectForRfq(mat);
                    }}
                    className="px-5 py-2.5 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-semibold flex items-center gap-2 shadow-md active:scale-95"
                  >
                    <span>Request Quotation for {activeModalMaterial.name}</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
