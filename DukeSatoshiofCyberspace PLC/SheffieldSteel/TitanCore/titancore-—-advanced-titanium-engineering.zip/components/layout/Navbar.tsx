'use client';

import React, { useState } from 'react';
import { 
  ShieldCheck, 
  ChevronDown, 
  Search, 
  Terminal, 
  Calculator, 
  Sparkles, 
  Menu, 
  X,
  Layers,
  Flame,
  Building2,
  FileText
} from 'lucide-react';

interface NavbarProps {
  currentTab: string;
  onSelectTab: (tab: string) => void;
  onOpenAdvisor: () => void;
  onOpenRfq: () => void;
  titanOsActive: boolean;
  onToggleTitanOs: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentTab,
  onSelectTab,
  onOpenAdvisor,
  onOpenRfq,
  titanOsActive,
  onToggleTitanOs,
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [materialsDropdownOpen, setMaterialsDropdownOpen] = useState(false);

  const handleNavClick = (tabId: string) => {
    onSelectTab(tabId);
    setMobileMenuOpen(false);
    setMaterialsDropdownOpen(false);
  };

  return (
    <header className="sticky top-0 z-50 bg-[#0c1015]/95 backdrop-blur-md border-b border-slate-800 text-slate-100">
      {/* Top Engineering & Quality Announcement Bar */}
      <div className="bg-gradient-to-r from-slate-900 via-slate-800 to-slate-900 border-b border-slate-800/80 px-4 py-1.5 text-xs text-slate-300">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-3">
            <span className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded text-[11px] font-medium bg-emerald-950/80 text-emerald-400 border border-emerald-800/50">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
              Sheffield Facility Active
            </span>
            <span className="hidden sm:inline text-slate-400">
              AS9100 Rev D & ISO 9001:2015 Framework • EN 10204 3.1 Certified Batches • Sheffield Olympic Legacy Park
            </span>
          </div>

          <div className="flex items-center gap-4 text-[11px]">
            <button 
              onClick={onOpenAdvisor}
              className="flex items-center gap-1.5 text-cyan-400 hover:text-cyan-300 font-medium transition-colors"
            >
              <Sparkles className="w-3 h-3 text-cyan-400" />
              <span>AI Metallurgical Advisor</span>
            </button>
            <span className="text-slate-600 hidden md:inline">|</span>
            <span className="text-slate-400 hidden md:inline">Tel: +44 (0)114 296 8800</span>
          </div>
        </div>
      </div>

      {/* Main Navigation Bar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          {/* Logo matching uploaded reference image */}
          <div 
            onClick={() => handleNavClick('home')}
            className="flex items-center gap-3 cursor-pointer group"
          >
            {/* Geometric faceted triangle icon */}
            <div className="relative w-10 h-10 flex items-center justify-center bg-gradient-to-br from-slate-700 via-slate-800 to-slate-950 rounded-lg border border-slate-700/80 shadow-md group-hover:border-cyan-500/50 transition-all">
              <svg 
                viewBox="0 0 32 32" 
                className="w-6 h-6 text-slate-200 fill-none stroke-current stroke-[2.2] group-hover:text-cyan-400 transition-colors"
              >
                <path d="M16 4 L28 26 L4 26 Z" strokeLinejoin="round" />
                <path d="M16 4 L16 26" strokeLinecap="round" strokeOpacity="0.4" />
                <path d="M10 15 L22 15" strokeLinecap="round" strokeOpacity="0.6" />
                <path d="M16 11 L23 23" strokeLinecap="round" strokeOpacity="0.3" />
              </svg>
            </div>

            <div className="flex flex-col">
              <span className="text-xl sm:text-2xl font-black tracking-widest text-white uppercase font-mono">
                TITANCORE
              </span>
              <span className="text-[9px] sm:text-[10px] tracking-[0.25em] text-cyan-400 font-semibold uppercase">
                TITANIUM FOR A STRONGER TOMORROW
              </span>
            </div>
          </div>

          {/* Desktop Nav Items */}
          <nav className="hidden lg:flex items-center gap-1 xl:gap-2 text-sm font-medium text-slate-300">
            <button
              onClick={() => handleNavClick('home')}
              className={`px-3 py-2 rounded-md transition-colors ${
                currentTab === 'home' && !titanOsActive ? 'text-white bg-slate-800/80 font-semibold' : 'hover:text-white hover:bg-slate-800/40'
              }`}
            >
              Home
            </button>

            {/* Materials Dropdown */}
            <div className="relative">
              <button
                onClick={() => setMaterialsDropdownOpen(!materialsDropdownOpen)}
                onMouseEnter={() => setMaterialsDropdownOpen(true)}
                className={`flex items-center gap-1 px-3 py-2 rounded-md transition-colors ${
                  currentTab === 'materials' && !titanOsActive ? 'text-white bg-slate-800/80 font-semibold' : 'hover:text-white hover:bg-slate-800/40'
                }`}
              >
                <span>Our Titanium</span>
                <ChevronDown className="w-3.5 h-3.5 opacity-70" />
              </button>

              {materialsDropdownOpen && (
                <div 
                  onMouseLeave={() => setMaterialsDropdownOpen(false)}
                  className="absolute left-0 mt-1 w-64 rounded-lg bg-slate-900 border border-slate-700 shadow-xl py-2 z-50 text-xs"
                >
                  <div className="px-3 py-1.5 text-[10px] font-bold uppercase tracking-wider text-slate-500">
                    Product Catalogue & Grades
                  </div>
                  <button
                    onClick={() => handleNavClick('materials')}
                    className="w-full text-left px-3 py-2 hover:bg-slate-800 text-slate-200 flex items-center justify-between"
                  >
                    <span>Full Materials Database</span>
                    <span className="text-[10px] text-cyan-400">ASTM / AMS</span>
                  </button>
                  <button
                    onClick={() => handleNavClick('stock')}
                    className="w-full text-left px-3 py-2 hover:bg-slate-800 text-slate-200 flex items-center justify-between"
                  >
                    <span>Sheffield Stock & Batches</span>
                    <span className="text-[10px] text-emerald-400">EN 10204 3.1</span>
                  </button>
                  <div className="my-1 border-t border-slate-800" />
                  <div className="px-3 py-1 text-[11px] text-slate-400">
                    • Ti-6Al-4V Grade 5 & Grade 23 ELI
                  </div>
                  <div className="px-3 py-1 text-[11px] text-slate-400">
                    • Commercially Pure CP Grades 1–4
                  </div>
                  <div className="px-3 py-1 text-[11px] text-slate-400">
                    • Ti-6242 Near-Alpha & Beta-C
                  </div>
                </div>
              )}
            </div>

            <button
              onClick={() => handleNavClick('applications')}
              className={`px-3 py-2 rounded-md transition-colors ${
                currentTab === 'applications' && !titanOsActive ? 'text-white bg-slate-800/80 font-semibold' : 'hover:text-white hover:bg-slate-800/40'
              }`}
            >
              Applications
            </button>

            <button
              onClick={() => handleNavClick('processing')}
              className={`px-3 py-2 rounded-md transition-colors ${
                currentTab === 'processing' && !titanOsActive ? 'text-white bg-slate-800/80 font-semibold' : 'hover:text-white hover:bg-slate-800/40'
              }`}
            >
              Precision Processing
            </button>

            <button
              onClick={() => handleNavClick('calculators')}
              className={`flex items-center gap-1 px-3 py-2 rounded-md transition-colors ${
                currentTab === 'calculators' && !titanOsActive ? 'text-white bg-slate-800/80 font-semibold' : 'hover:text-white hover:bg-slate-800/40'
              }`}
            >
              <Calculator className="w-3.5 h-3.5 text-slate-400" />
              <span>Technical Hub</span>
            </button>

            <button
              onClick={() => handleNavClick('quality')}
              className={`px-3 py-2 rounded-md transition-colors ${
                currentTab === 'quality' && !titanOsActive ? 'text-white bg-slate-800/80 font-semibold' : 'hover:text-white hover:bg-slate-800/40'
              }`}
            >
              Quality & Traceability
            </button>

            <button
              onClick={() => handleNavClick('sheffield')}
              className={`px-3 py-2 rounded-md transition-colors ${
                currentTab === 'sheffield' && !titanOsActive ? 'text-white bg-slate-800/80 font-semibold' : 'hover:text-white hover:bg-slate-800/40'
              }`}
            >
              Sheffield Base
            </button>
          </nav>

          {/* Right Action Elements */}
          <div className="flex items-center gap-3">
            {/* TitanOS Commercial Operating System Toggle */}
            <button
              onClick={onToggleTitanOs}
              className={`relative px-3.5 py-2 rounded-lg text-xs font-mono font-bold tracking-wider uppercase transition-all flex items-center gap-2 border ${
                titanOsActive 
                  ? 'bg-amber-500/20 text-amber-300 border-amber-500/80 shadow-[0_0_15px_rgba(245,158,11,0.2)]'
                  : 'bg-slate-900/90 text-slate-300 border-slate-700 hover:border-amber-500/50 hover:text-amber-300'
              }`}
              title="Launch TitanCore Internal Commercial & Costing Operating System"
            >
              <Terminal className="w-3.5 h-3.5 text-amber-400" />
              <span className="hidden sm:inline">TitanOS</span>
              <span className="text-[10px] px-1.5 py-0.2 rounded bg-amber-500/30 text-amber-200">
                {titanOsActive ? 'ACTIVE' : 'INTERNAL OS'}
              </span>
            </button>

            {/* Request RFQ Button */}
            <button
              onClick={onOpenRfq}
              className="px-4 py-2 rounded-lg text-xs sm:text-sm font-semibold tracking-wide bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white shadow-md transition-all border border-cyan-400/30 active:scale-95"
            >
              Request a Quotation
            </button>

            {/* Mobile Hamburger */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="lg:hidden p-2 rounded-md text-slate-400 hover:text-white hover:bg-slate-800"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="lg:hidden bg-slate-950 border-b border-slate-800 px-4 pt-2 pb-6 space-y-2">
          <button
            onClick={() => handleNavClick('home')}
            className="w-full text-left px-3 py-2 text-sm text-slate-200 hover:bg-slate-800 rounded-md"
          >
            Home
          </button>
          <button
            onClick={() => handleNavClick('materials')}
            className="w-full text-left px-3 py-2 text-sm text-slate-200 hover:bg-slate-800 rounded-md"
          >
            Materials Database (Grades 1-4, 5, 23, 6242, Beta-C)
          </button>
          <button
            onClick={() => handleNavClick('stock')}
            className="w-full text-left px-3 py-2 text-sm text-slate-200 hover:bg-slate-800 rounded-md"
          >
            Sheffield Stock & Batch Register
          </button>
          <button
            onClick={() => handleNavClick('applications')}
            className="w-full text-left px-3 py-2 text-sm text-slate-200 hover:bg-slate-800 rounded-md"
          >
            Applications & Industry Sectors
          </button>
          <button
            onClick={() => handleNavClick('processing')}
            className="w-full text-left px-3 py-2 text-sm text-slate-200 hover:bg-slate-800 rounded-md"
          >
            Precision Processing & Waterjet
          </button>
          <button
            onClick={() => handleNavClick('calculators')}
            className="w-full text-left px-3 py-2 text-sm text-slate-200 hover:bg-slate-800 rounded-md"
          >
            Technical Calculators & Speeds/Feeds
          </button>
          <button
            onClick={() => handleNavClick('quality')}
            className="w-full text-left px-3 py-2 text-sm text-slate-200 hover:bg-slate-800 rounded-md"
          >
            Quality, MTR Certs & AS9100 Roadmap
          </button>
          <button
            onClick={() => handleNavClick('sheffield')}
            className="w-full text-left px-3 py-2 text-sm text-slate-200 hover:bg-slate-800 rounded-md"
          >
            Sheffield Metallurgy Heritage & AMRC
          </button>
          <div className="pt-2 border-t border-slate-800 flex flex-col gap-2">
            <button
              onClick={() => {
                onToggleTitanOs();
                setMobileMenuOpen(false);
              }}
              className="w-full py-2.5 text-center text-xs font-mono font-bold bg-amber-500/20 text-amber-300 border border-amber-500/50 rounded-lg"
            >
              {titanOsActive ? 'Switch to Public Website' : 'Launch TitanOS Commercial OS'}
            </button>
            <button
              onClick={() => {
                onOpenAdvisor();
                setMobileMenuOpen(false);
              }}
              className="w-full py-2.5 text-center text-xs font-semibold bg-cyan-950/80 text-cyan-300 border border-cyan-800/80 rounded-lg flex items-center justify-center gap-2"
            >
              <Sparkles className="w-3.5 h-3.5" />
              Ask AI Metallurgical Advisor
            </button>
          </div>
        </div>
      )}
    </header>
  );
};
