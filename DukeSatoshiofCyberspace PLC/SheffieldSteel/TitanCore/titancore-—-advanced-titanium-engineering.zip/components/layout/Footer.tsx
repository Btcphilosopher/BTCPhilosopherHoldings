'use client';

import React from 'react';
import { ShieldCheck, MapPin, Phone, Mail, Award, ArrowUpRight } from 'lucide-react';

interface FooterProps {
  onSelectTab: (tab: string) => void;
  onOpenAdvisor: () => void;
}

export const Footer: React.FC<FooterProps> = ({
  onSelectTab,
  onOpenAdvisor,
}) => {
  return (
    <footer className="bg-slate-950 border-t border-slate-800 text-slate-400 text-xs">
      {/* Upper Footer */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 lg:py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-8">
          {/* Brand & Sheffield Info */}
          <div className="lg:col-span-2 space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 flex items-center justify-center bg-slate-900 rounded-lg border border-slate-700 text-cyan-400">
                <svg viewBox="0 0 32 32" className="w-5 h-5 fill-none stroke-current stroke-2">
                  <path d="M16 4 L28 26 L4 26 Z" strokeLinejoin="round" />
                  <path d="M16 4 L16 26" strokeOpacity="0.4" />
                </svg>
              </div>
              <div>
                <span className="text-base font-black text-white uppercase font-mono tracking-wider">
                  TITANCORE
                </span>
                <span className="text-[9px] block text-cyan-400 font-semibold tracking-widest uppercase">
                  ADVANCED TITANIUM ENGINEERING
                </span>
              </div>
            </div>

            <p className="text-slate-400 text-xs leading-relaxed max-w-sm">
              British titanium materials, precision engineering, and technical distribution. 
              Combining Sheffield’s historic metallurgical reputation with modern titanium materials science.
            </p>

            <div className="space-y-1.5 text-xs font-mono text-slate-300 pt-2">
              <div className="flex items-center gap-2">
                <MapPin className="w-3.5 h-3.5 text-cyan-400" />
                <span>Olympic Legacy Park, Sheffield S9 3TY, United Kingdom</span>
              </div>
              <div className="flex items-center gap-2">
                <Phone className="w-3.5 h-3.5 text-cyan-400" />
                <span>+44 (0)114 296 8800</span>
              </div>
              <div className="flex items-center gap-2">
                <Mail className="w-3.5 h-3.5 text-cyan-400" />
                <span>enquiries@titancore.co.uk</span>
              </div>
            </div>
          </div>

          {/* Titanium Materials */}
          <div>
            <h4 className="font-bold text-white uppercase tracking-wider text-[11px] font-mono mb-3">
              Titanium Materials
            </h4>
            <ul className="space-y-2">
              <li>
                <button onClick={() => onSelectTab('materials')} className="hover:text-cyan-400 transition-colors">
                  Ti-6Al-4V Grade 5 (AMS 4911)
                </button>
              </li>
              <li>
                <button onClick={() => onSelectTab('materials')} className="hover:text-cyan-400 transition-colors">
                  Ti-6Al-4V ELI Grade 23 (ASTM F136)
                </button>
              </li>
              <li>
                <button onClick={() => onSelectTab('materials')} className="hover:text-cyan-400 transition-colors">
                  Commercially Pure CP Gr 1–4
                </button>
              </li>
              <li>
                <button onClick={() => onSelectTab('materials')} className="hover:text-cyan-400 transition-colors">
                  Ti-6242 Near-Alpha (High Temp)
                </button>
              </li>
              <li>
                <button onClick={() => onSelectTab('materials')} className="hover:text-cyan-400 transition-colors">
                  Beta-C Titanium (Sour Service)
                </button>
              </li>
              <li>
                <button onClick={() => onSelectTab('stock')} className="text-cyan-400 font-semibold hover:underline">
                  Live Stock & Heat Register →
                </button>
              </li>
            </ul>
          </div>

          {/* Precision Capabilities */}
          <div>
            <h4 className="font-bold text-white uppercase tracking-wider text-[11px] font-mono mb-3">
              Processing & Engineering
            </h4>
            <ul className="space-y-2">
              <li>
                <button onClick={() => onSelectTab('processing')} className="hover:text-cyan-400 transition-colors">
                  5-Axis Abrasive Waterjet
                </button>
              </li>
              <li>
                <button onClick={() => onSelectTab('processing')} className="hover:text-cyan-400 transition-colors">
                  High-Speed 5-Axis Milling
                </button>
              </li>
              <li>
                <button onClick={() => onSelectTab('processing')} className="hover:text-cyan-400 transition-colors">
                  Billet Cold Sawing up to Ø450mm
                </button>
              </li>
              <li>
                <button onClick={() => onSelectTab('processing')} className="hover:text-cyan-400 transition-colors">
                  Zeiss CMM & Metrology
                </button>
              </li>
              <li>
                <button onClick={() => onSelectTab('calculators')} className="hover:text-cyan-400 transition-colors">
                  Speeds & Feeds Calculator
                </button>
              </li>
              <li>
                <button onClick={onOpenAdvisor} className="text-cyan-400 font-semibold hover:underline flex items-center gap-1">
                  <span>AI Metallurgical Advisor</span>
                  <ArrowUpRight className="w-3 h-3" />
                </button>
              </li>
            </ul>
          </div>

          {/* Quality & Governance */}
          <div>
            <h4 className="font-bold text-white uppercase tracking-wider text-[11px] font-mono mb-3">
              Quality & Governance
            </h4>
            <ul className="space-y-2">
              <li>
                <button onClick={() => onSelectTab('quality')} className="hover:text-cyan-400 transition-colors">
                  EN 10204 3.1 & 3.2 Certificates
                </button>
              </li>
              <li>
                <button onClick={() => onSelectTab('quality')} className="hover:text-cyan-400 transition-colors">
                  AS9100 Rev D Transition Plan
                </button>
              </li>
              <li>
                <button onClick={() => onSelectTab('quality')} className="hover:text-cyan-400 transition-colors">
                  Non-Conformance & Quarantine
                </button>
              </li>
              <li>
                <button onClick={() => onSelectTab('sheffield')} className="hover:text-cyan-400 transition-colors">
                  AMRC & University Partnerships
                </button>
              </li>
              <li>
                <button onClick={() => onSelectTab('quality')} className="hover:text-cyan-400 transition-colors">
                  Pyrophoric Chip Safety Guidelines
                </button>
              </li>
            </ul>
          </div>
        </div>
      </div>

      {/* Compliance & Legal Disclaimer Banner */}
      <div className="bg-[#05070a] border-t border-slate-900 px-4 py-6">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4 text-[11px] text-slate-300">
          <div>
            © 2026 TitanCore Ltd. Registered in England & Wales. Sheffield, South Yorkshire. All rights reserved.
          </div>

          <div className="flex flex-wrap items-center gap-4 text-slate-300 font-mono">
            <span>ASTM B265 / B348</span>
            <span>•</span>
            <span>AMS 4911 / 4928</span>
            <span>•</span>
            <span>ISO 5832-3</span>
            <span>•</span>
            <span>BS EN 10204 3.1</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
