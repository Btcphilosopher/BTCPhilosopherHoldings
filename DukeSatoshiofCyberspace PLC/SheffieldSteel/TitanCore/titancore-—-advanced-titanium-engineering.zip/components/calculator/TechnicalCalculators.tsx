'use client';

import React, { useState } from 'react';
import { 
  Calculator, 
  Gauge, 
  Layers, 
  Sparkles, 
  ArrowRight, 
  AlertTriangle, 
  CheckCircle2, 
  HelpCircle,
  ShieldCheck
} from 'lucide-react';
import { TITANIUM_MATERIALS } from '@/lib/data';

interface TechnicalCalculatorsProps {
  onOpenRfqWithData?: (data: any) => void;
  onAskAi: (query: string) => void;
}

export const TechnicalCalculators: React.FC<TechnicalCalculatorsProps> = ({
  onOpenRfqWithData,
  onAskAi,
}) => {
  const [activeTab, setActiveTab] = useState<'weight' | 'machining' | 'galvanic'>('weight');

  // Weight calculator state
  const [shape, setShape] = useState<'plate' | 'round_bar' | 'tube'>('plate');
  const [selectedMaterialId, setSelectedMaterialId] = useState<string>('ti-gr5');
  const [thicknessMm, setThicknessMm] = useState<number>(25);
  const [widthMm, setWidthMm] = useState<number>(1000);
  const [lengthMm, setLengthMm] = useState<number>(2000);
  const [diameterMm, setDiameterMm] = useState<number>(80);
  const [wallThicknessMm, setWallThicknessMm] = useState<number>(3.5);
  const [quantity, setQuantity] = useState<number>(1);

  // Machining calculator state
  const [machiningOperation, setMachiningOperation] = useState<'milling' | 'turning' | 'drilling'>('milling');
  const [toolDiameterMm, setToolDiameterMm] = useState<number>(16);
  const [numTeeth, setNumTeeth] = useState<number>(4);
  const [machiningMaterialId, setMachiningMaterialId] = useState<string>('ti-gr5');

  const selectedMaterial = TITANIUM_MATERIALS.find(m => m.id === selectedMaterialId) || TITANIUM_MATERIALS[0];
  const machiningMaterial = TITANIUM_MATERIALS.find(m => m.id === machiningMaterialId) || TITANIUM_MATERIALS[0];

  // Weight calculations
  const density = selectedMaterial.densityGPerCm3; // g/cm3

  let singleVolumeCm3 = 0;
  if (shape === 'plate') {
    singleVolumeCm3 = (thicknessMm * widthMm * lengthMm) / 1000;
  } else if (shape === 'round_bar') {
    const radiusCm = (diameterMm / 2) / 10;
    const lengthCm = lengthMm / 10;
    singleVolumeCm3 = Math.PI * Math.pow(radiusCm, 2) * lengthCm;
  } else if (shape === 'tube') {
    const outerRadiusCm = (diameterMm / 2) / 10;
    const innerRadiusCm = Math.max(0, ((diameterMm - 2 * wallThicknessMm) / 2) / 10);
    const lengthCm = lengthMm / 10;
    singleVolumeCm3 = Math.PI * (Math.pow(outerRadiusCm, 2) - Math.pow(innerRadiusCm, 2)) * lengthCm;
  }

  const singleWeightKg = (singleVolumeCm3 * density) / 1000;
  const totalWeightKg = singleWeightKg * quantity;
  const estimatedCostGbp = totalWeightKg * selectedMaterial.basePricePerKgEstimateGbp;

  // Speeds & feeds calculations
  // Ti-6Al-4V: standard Vc ~ 55 m/min for carbide milling
  let baseVc = 55;
  if (machiningMaterial.category === 'commercially_pure') {
    baseVc = 75;
  } else if (machiningMaterial.category === 'near_alpha' || machiningMaterial.category === 'beta') {
    baseVc = 40;
  }

  if (machiningOperation === 'turning') {
    baseVc = baseVc * 1.15;
  } else if (machiningOperation === 'drilling') {
    baseVc = baseVc * 0.65;
  }

  // RPM = (Vc * 1000) / (pi * D)
  const spindleRpm = Math.round((baseVc * 1000) / (Math.PI * toolDiameterMm));
  // fz mm/tooth
  const feedPerTooth = machiningOperation === 'milling' ? 0.08 : (machiningOperation === 'turning' ? 0.18 : 0.06);
  // Vf = RPM * z * fz (for milling)
  const tableFeedVf = Math.round(spindleRpm * numTeeth * feedPerTooth);

  return (
    <div className="bg-[#090d12] text-slate-100 py-12 lg:py-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="max-w-3xl mb-8">
          <span className="text-xs font-mono font-semibold uppercase tracking-widest text-cyan-400">
            ENGINEERING & METALLURGY TOOLKIT
          </span>
          <h1 className="text-3xl sm:text-4xl font-extrabold text-white mt-1 tracking-tight">
            Titanium Technical Calculators
          </h1>
          <p className="text-slate-300 text-sm mt-2 leading-relaxed">
            Validated engineering tools for calculating piece weights, cutting parameters (speeds & feeds), 
            and galvanic compatibility ratings for British industrial designers and machine shops.
          </p>
        </div>

        {/* Tab Switcher */}
        <div className="flex border-b border-slate-800 mb-8 space-x-2">
          <button
            onClick={() => setActiveTab('weight')}
            className={`pb-3 px-4 text-sm font-semibold border-b-2 transition-all flex items-center gap-2 ${
              activeTab === 'weight'
                ? 'border-cyan-500 text-cyan-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Calculator className="w-4 h-4" />
            <span>Weight & Raw Cost Estimator</span>
          </button>

          <button
            onClick={() => setActiveTab('machining')}
            className={`pb-3 px-4 text-sm font-semibold border-b-2 transition-all flex items-center gap-2 ${
              activeTab === 'machining'
                ? 'border-cyan-500 text-cyan-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Gauge className="w-4 h-4" />
            <span>Machining Speeds & Feeds (Vc, RPM, Vf)</span>
          </button>

          <button
            onClick={() => setActiveTab('galvanic')}
            className={`pb-3 px-4 text-sm font-semibold border-b-2 transition-all flex items-center gap-2 ${
              activeTab === 'galvanic'
                ? 'border-cyan-500 text-cyan-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <ShieldCheck className="w-4 h-4" />
            <span>Seawater Galvanic Coupling Matrix</span>
          </button>
        </div>

        {/* TAB 1: Weight & Cost Estimator */}
        {activeTab === 'weight' && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
            <div className="lg:col-span-7 bg-slate-950 p-6 rounded-2xl border border-slate-800 space-y-5">
              <h3 className="text-lg font-bold text-white flex items-center gap-2">
                <Layers className="w-5 h-5 text-cyan-400" />
                Geometry & Alloy Parameters
              </h3>

              {/* Alloy selection */}
              <div>
                <label className="block text-xs font-mono text-slate-400 uppercase mb-1">
                  Titanium Grade / Alloy
                </label>
                <select
                  value={selectedMaterialId}
                  onChange={(e) => setSelectedMaterialId(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2.5 text-sm text-white focus:outline-none focus:border-cyan-500"
                >
                  {TITANIUM_MATERIALS.map((m) => (
                    <option key={m.id} value={m.id}>
                      {m.name} ({m.densityGPerCm3} g/cm³ · ~£{m.basePricePerKgEstimateGbp}/kg)
                    </option>
                  ))}
                </select>
              </div>

              {/* Shape selection */}
              <div>
                <label className="block text-xs font-mono text-slate-400 uppercase mb-1">
                  Product Profile Shape
                </label>
                <div className="grid grid-cols-3 gap-2">
                  <button
                    type="button"
                    onClick={() => setShape('plate')}
                    className={`p-2.5 rounded-lg text-xs font-semibold border transition-all ${
                      shape === 'plate'
                        ? 'bg-cyan-600 text-white border-cyan-500'
                        : 'bg-slate-900 text-slate-300 border-slate-800 hover:bg-slate-850'
                    }`}
                  >
                    Rectangular Plate / Sheet
                  </button>
                  <button
                    type="button"
                    onClick={() => setShape('round_bar')}
                    className={`p-2.5 rounded-lg text-xs font-semibold border transition-all ${
                      shape === 'round_bar'
                        ? 'bg-cyan-600 text-white border-cyan-500'
                        : 'bg-slate-900 text-slate-300 border-slate-800 hover:bg-slate-850'
                    }`}
                  >
                    Solid Round Bar / Billet
                  </button>
                  <button
                    type="button"
                    onClick={() => setShape('tube')}
                    className={`p-2.5 rounded-lg text-xs font-semibold border transition-all ${
                      shape === 'tube'
                        ? 'bg-cyan-600 text-white border-cyan-500'
                        : 'bg-slate-900 text-slate-300 border-slate-800 hover:bg-slate-850'
                    }`}
                  >
                    Hollow Tube / Pipe
                  </button>
                </div>
              </div>

              {/* Dimensional Inputs */}
              {shape === 'plate' && (
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  <div>
                    <label className="block text-xs text-slate-400 font-mono mb-1">Thickness (mm)</label>
                    <input
                      type="number"
                      min={0.5}
                      value={thicknessMm}
                      onChange={(e) => setThicknessMm(Number(e.target.value))}
                      className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2 text-sm text-white focus:outline-none focus:border-cyan-500 font-mono"
                    />
                  </div>
                  <div>
                    <label className="block text-xs text-slate-400 font-mono mb-1">Width (mm)</label>
                    <input
                      type="number"
                      min={10}
                      value={widthMm}
                      onChange={(e) => setWidthMm(Number(e.target.value))}
                      className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2 text-sm text-white focus:outline-none focus:border-cyan-500 font-mono"
                    />
                  </div>
                  <div>
                    <label className="block text-xs text-slate-400 font-mono mb-1">Length (mm)</label>
                    <input
                      type="number"
                      min={10}
                      value={lengthMm}
                      onChange={(e) => setLengthMm(Number(e.target.value))}
                      className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2 text-sm text-white focus:outline-none focus:border-cyan-500 font-mono"
                    />
                  </div>
                </div>
              )}

              {shape === 'round_bar' && (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs text-slate-400 font-mono mb-1">Diameter (Ø mm)</label>
                    <input
                      type="number"
                      min={2}
                      value={diameterMm}
                      onChange={(e) => setDiameterMm(Number(e.target.value))}
                      className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2 text-sm text-white focus:outline-none focus:border-cyan-500 font-mono"
                    />
                  </div>
                  <div>
                    <label className="block text-xs text-slate-400 font-mono mb-1">Length (mm)</label>
                    <input
                      type="number"
                      min={10}
                      value={lengthMm}
                      onChange={(e) => setLengthMm(Number(e.target.value))}
                      className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2 text-sm text-white focus:outline-none focus:border-cyan-500 font-mono"
                    />
                  </div>
                </div>
              )}

              {shape === 'tube' && (
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  <div>
                    <label className="block text-xs text-slate-400 font-mono mb-1">Outer Dia (OD mm)</label>
                    <input
                      type="number"
                      min={6}
                      value={diameterMm}
                      onChange={(e) => setDiameterMm(Number(e.target.value))}
                      className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2 text-sm text-white focus:outline-none focus:border-cyan-500 font-mono"
                    />
                  </div>
                  <div>
                    <label className="block text-xs text-slate-400 font-mono mb-1">Wall Thickness (WT mm)</label>
                    <input
                      type="number"
                      min={0.5}
                      step={0.1}
                      value={wallThicknessMm}
                      onChange={(e) => setWallThicknessMm(Number(e.target.value))}
                      className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2 text-sm text-white focus:outline-none focus:border-cyan-500 font-mono"
                    />
                  </div>
                  <div>
                    <label className="block text-xs text-slate-400 font-mono mb-1">Length (mm)</label>
                    <input
                      type="number"
                      min={10}
                      value={lengthMm}
                      onChange={(e) => setLengthMm(Number(e.target.value))}
                      className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2 text-sm text-white focus:outline-none focus:border-cyan-500 font-mono"
                    />
                  </div>
                </div>
              )}

              {/* Quantity */}
              <div className="pt-2">
                <label className="block text-xs text-slate-400 font-mono mb-1">Quantity of Pieces</label>
                <input
                  type="number"
                  min={1}
                  value={quantity}
                  onChange={(e) => setQuantity(Math.max(1, Number(e.target.value)))}
                  className="w-32 bg-slate-900 border border-slate-700 rounded-lg p-2 text-sm text-white focus:outline-none focus:border-cyan-500 font-mono"
                />
              </div>
            </div>

            {/* Output Calculation Card */}
            <div className="lg:col-span-5 bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950 p-6 rounded-2xl border border-slate-800 space-y-6">
              <div>
                <span className="text-[10px] font-mono text-cyan-400 font-bold uppercase tracking-wider">
                  METALLURGICAL MASS CALCULATION
                </span>
                <h4 className="text-xl font-bold text-white mt-1">
                  Estimated Physical Output
                </h4>
              </div>

              <div className="space-y-3 font-mono text-xs">
                <div className="bg-slate-900/80 p-3 rounded-xl border border-slate-800 flex justify-between items-center">
                  <span className="text-slate-400">Single Piece Weight:</span>
                  <span className="text-white font-bold text-base">{singleWeightKg.toFixed(2)} kg</span>
                </div>
                <div className="bg-slate-900/80 p-3 rounded-xl border border-slate-800 flex justify-between items-center">
                  <span className="text-slate-400">Total Batch Net Weight ({quantity} pcs):</span>
                  <span className="text-cyan-400 font-bold text-lg">{totalWeightKg.toFixed(2)} kg</span>
                </div>
                <div className="bg-slate-900/80 p-3 rounded-xl border border-slate-800 flex justify-between items-center">
                  <span className="text-slate-400">Calculated Volume:</span>
                  <span className="text-slate-200">{(singleVolumeCm3 * quantity / 1000).toFixed(3)} dm³</span>
                </div>
                <div className="bg-slate-900/80 p-3 rounded-xl border border-slate-800 flex justify-between items-center">
                  <span className="text-slate-400">Estimated Raw Base Material:</span>
                  <span className="text-emerald-400 font-bold text-base">£{estimatedCostGbp.toFixed(2)}</span>
                </div>
              </div>

              <div className="text-[11px] text-slate-400 bg-slate-950 p-3 rounded-lg border border-slate-800/80">
                * Note: Prices are indicative base estimates excluding yield loss / drop allowance, waterjet/saw cutting, and EN 10204 3.1 certification fees. Use TitanOS or RFQ for formal quotation.
              </div>

              <button
                onClick={() => onAskAi(`I need to machine a ${selectedMaterial.name} part measuring ${shape === 'plate' ? `${thicknessMm}x${widthMm}x${lengthMm}mm` : `Ø${diameterMm}x${lengthMm}mm`}. What is the optimal stock allowance and cutting regime?`)}
                className="w-full py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-cyan-400 text-xs font-semibold flex items-center justify-center gap-2 border border-slate-700 transition-colors"
              >
                <Sparkles className="w-3.5 h-3.5" />
                <span>Ask AI Advisor about this Geometry</span>
              </button>
            </div>
          </div>
        )}

        {/* TAB 2: Speeds & Feeds Advisor */}
        {activeTab === 'machining' && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
            <div className="lg:col-span-7 bg-slate-950 p-6 rounded-2xl border border-slate-800 space-y-5">
              <h3 className="text-lg font-bold text-white flex items-center gap-2">
                <Gauge className="w-5 h-5 text-cyan-400" />
                Tooling & Machining Setup
              </h3>

              <div>
                <label className="block text-xs font-mono text-slate-400 uppercase mb-1">
                  Select Titanium Alloy
                </label>
                <select
                  value={machiningMaterialId}
                  onChange={(e) => setMachiningMaterialId(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2.5 text-sm text-white focus:outline-none focus:border-cyan-500"
                >
                  {TITANIUM_MATERIALS.map((m) => (
                    <option key={m.id} value={m.id}>
                      {m.name} (Machinability Rating: {m.machinabilityRating}%)
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-mono text-slate-400 uppercase mb-1">
                  Machining Operation
                </label>
                <div className="grid grid-cols-3 gap-2">
                  <button
                    type="button"
                    onClick={() => setMachiningOperation('milling')}
                    className={`p-2.5 rounded-lg text-xs font-semibold border transition-all ${
                      machiningOperation === 'milling'
                        ? 'bg-cyan-600 text-white border-cyan-500'
                        : 'bg-slate-900 text-slate-300 border-slate-800'
                    }`}
                  >
                    Solid Carbide End Milling
                  </button>
                  <button
                    type="button"
                    onClick={() => setMachiningOperation('turning')}
                    className={`p-2.5 rounded-lg text-xs font-semibold border transition-all ${
                      machiningOperation === 'turning'
                        ? 'bg-cyan-600 text-white border-cyan-500'
                        : 'bg-slate-900 text-slate-300 border-slate-800'
                    }`}
                  >
                    CNC Turning
                  </button>
                  <button
                    type="button"
                    onClick={() => setMachiningOperation('drilling')}
                    className={`p-2.5 rounded-lg text-xs font-semibold border transition-all ${
                      machiningOperation === 'drilling'
                        ? 'bg-cyan-600 text-white border-cyan-500'
                        : 'bg-slate-900 text-slate-300 border-slate-800'
                    }`}
                  >
                    Carbide Drilling
                  </button>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs text-slate-400 font-mono mb-1">
                    Tool / Workpiece Diameter (Ø mm)
                  </label>
                  <input
                    type="number"
                    min={1}
                    value={toolDiameterMm}
                    onChange={(e) => setToolDiameterMm(Math.max(1, Number(e.target.value)))}
                    className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2 text-sm text-white font-mono"
                  />
                </div>

                {machiningOperation === 'milling' && (
                  <div>
                    <label className="block text-xs text-slate-400 font-mono mb-1">
                      Number of Flutes / Teeth (z)
                    </label>
                    <input
                      type="number"
                      min={2}
                      max={8}
                      value={numTeeth}
                      onChange={(e) => setNumTeeth(Number(e.target.value))}
                      className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2 text-sm text-white font-mono"
                    />
                  </div>
                )}
              </div>
            </div>

            {/* Machining Output */}
            <div className="lg:col-span-5 bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950 p-6 rounded-2xl border border-slate-800 space-y-6">
              <div>
                <span className="text-[10px] font-mono text-cyan-400 font-bold uppercase tracking-wider">
                  TITANCORE MACHINING REGIME
                </span>
                <h4 className="text-xl font-bold text-white mt-1">
                  Recommended Speeds & Feeds
                </h4>
              </div>

              <div className="space-y-3 font-mono text-xs">
                <div className="bg-slate-900/80 p-3 rounded-xl border border-slate-800 flex justify-between items-center">
                  <span className="text-slate-400">Cutting Speed (Vc):</span>
                  <span className="text-cyan-400 font-bold text-base">{baseVc} m/min</span>
                </div>
                <div className="bg-slate-900/80 p-3 rounded-xl border border-slate-800 flex justify-between items-center">
                  <span className="text-slate-400">Spindle Speed (n):</span>
                  <span className="text-white font-bold text-lg">{spindleRpm} RPM</span>
                </div>
                <div className="bg-slate-900/80 p-3 rounded-xl border border-slate-800 flex justify-between items-center">
                  <span className="text-slate-400">Feed per Tooth / Rev:</span>
                  <span className="text-slate-200">{feedPerTooth} mm</span>
                </div>
                <div className="bg-slate-900/80 p-3 rounded-xl border border-slate-800 flex justify-between items-center">
                  <span className="text-slate-400">Table Feed (Vf):</span>
                  <span className="text-emerald-400 font-bold text-base">{tableFeedVf} mm/min</span>
                </div>
              </div>

              <div className="bg-amber-950/40 border border-amber-800/60 p-4 rounded-xl text-xs space-y-1.5 text-amber-200">
                <div className="font-bold flex items-center gap-1.5 text-amber-300">
                  <AlertTriangle className="w-3.5 h-3.5" />
                  Engineering Rules of Thumb
                </div>
                <p>• Always use <strong>climb milling</strong>. Never dwell tool in the cut.</p>
                <p>• High-pressure coolant (&gt;20 bar) directed precisely at tool shear zone.</p>
                <p>• Ensure dedicated Class D fire extinguisher nearby.</p>
              </div>
            </div>
          </div>
        )}

        {/* TAB 3: Galvanic Compatibility Matrix */}
        {activeTab === 'galvanic' && (
          <div className="bg-slate-950 p-6 rounded-2xl border border-slate-800 space-y-6">
            <div>
              <span className="text-[10px] font-mono text-cyan-400 font-bold uppercase tracking-wider">
                ELECTROCHEMICAL GALVANIC SERIES IN SEAWATER (25°C)
              </span>
              <h3 className="text-xl font-bold text-white mt-1">
                Titanium Galvanic Coupling & Compatibility Guide
              </h3>
              <p className="text-xs text-slate-300 mt-1 max-w-3xl">
                Titanium is one of the most electrochemically noble metals (+0.05V vs Standard Calomel Electrode). 
                When bolted directly to less noble metals in seawater or electrolyte, titanium acts as a cathode and 
                <strong> will accelerate the corrosion rate of the coupled metal</strong>.
              </p>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-xs text-left">
                <thead className="bg-slate-900 text-slate-400 font-mono text-[10px] uppercase border-b border-slate-800">
                  <tr>
                    <th className="p-3">Coupled Metal / Material</th>
                    <th className="p-3">Corrosion Potential (V vs SCE)</th>
                    <th className="p-3">Coupling Risk</th>
                    <th className="p-3">Engineering Mitigation / Recommendation</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800 font-mono">
                  <tr className="hover:bg-slate-900/50">
                    <td className="p-3 font-bold text-white">Carbon Fibre Reinforced Polymer (CFRP)</td>
                    <td className="p-3 text-cyan-400">+0.20 V</td>
                    <td className="p-3"><span className="px-2 py-0.5 rounded bg-emerald-950 text-emerald-400 border border-emerald-800">Safe / Highly Compatible</span></td>
                    <td className="p-3 text-slate-300 font-sans">Ideal combination in modern airframes. Titanium replaces aluminium to prevent CFRP galvanic attack.</td>
                  </tr>
                  <tr className="hover:bg-slate-900/50">
                    <td className="p-3 font-bold text-white">Inconel 718 / 625</td>
                    <td className="p-3 text-cyan-400">+0.00 V</td>
                    <td className="p-3"><span className="px-2 py-0.5 rounded bg-emerald-950 text-emerald-400 border border-emerald-800">Excellent</span></td>
                    <td className="p-3 text-slate-300 font-sans">Minimal potential differential; direct coupling permitted in aerospace jet engines & offshore manifolds.</td>
                  </tr>
                  <tr className="hover:bg-slate-900/50">
                    <td className="p-3 font-bold text-white">AISI 316L Stainless Steel</td>
                    <td className="p-3 text-cyan-400">-0.08 V</td>
                    <td className="p-3"><span className="px-2 py-0.5 rounded bg-blue-950 text-blue-400 border border-blue-800">Moderate / Low Risk</span></td>
                    <td className="p-3 text-slate-300 font-sans">Generally acceptable if titanium surface area is not excessively larger than the 316L anode area.</td>
                  </tr>
                  <tr className="hover:bg-slate-900/50">
                    <td className="p-3 font-bold text-white">Nickel Aluminium Bronze (NAB)</td>
                    <td className="p-3 text-amber-400">-0.22 V</td>
                    <td className="p-3"><span className="px-2 py-0.5 rounded bg-amber-950 text-amber-400 border border-amber-800">Moderate Warning</span></td>
                    <td className="p-3 text-slate-300 font-sans">NAB undergoes slight sacrificial loss. Maintain cathode/anode ratio &lt; 1:1 or isolate.</td>
                  </tr>
                  <tr className="hover:bg-slate-900/50">
                    <td className="p-3 font-bold text-white">Carbon Steel / Low Alloy Steel</td>
                    <td className="p-3 text-red-400">-0.61 V</td>
                    <td className="p-3"><span className="px-2 py-0.5 rounded bg-red-950 text-red-400 border border-red-800">Severe Galvanic Attack</span></td>
                    <td className="p-3 text-slate-300 font-sans">Mandatory electrical isolation via dielectric G-10 gaskets, mylar sleeves, and insulating washers.</td>
                  </tr>
                  <tr className="hover:bg-slate-900/50">
                    <td className="p-3 font-bold text-white">Aluminium Alloys (e.g. 7075-T6, 6082)</td>
                    <td className="p-3 text-red-400">-0.79 V</td>
                    <td className="p-3"><span className="px-2 py-0.5 rounded bg-red-950 text-red-400 border border-red-800">Critical Rapid Attack</span></td>
                    <td className="p-3 text-slate-300 font-sans">Aluminium will corrode aggressively within weeks. Direct metal-to-metal contact strictly forbidden in wet/marine environments.</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
