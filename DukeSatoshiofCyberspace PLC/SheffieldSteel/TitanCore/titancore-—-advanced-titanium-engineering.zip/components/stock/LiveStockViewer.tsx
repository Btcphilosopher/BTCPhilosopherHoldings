'use client';

import React, { useState } from 'react';
import { 
  Boxes, 
  Search, 
  FileCheck, 
  ShieldAlert, 
  Download, 
  Eye, 
  X, 
  CheckCircle2, 
  Building, 
  Layers,
  ArrowRight
} from 'lucide-react';
import { INITIAL_INVENTORY } from '@/lib/data';
import { InventoryItem } from '@/lib/types';

interface LiveStockViewerProps {
  onSelectStockForRfq: (item: InventoryItem) => void;
}

export const LiveStockViewer: React.FC<LiveStockViewerProps> = ({
  onSelectStockForRfq,
}) => {
  const [inventoryList, setInventoryList] = useState<InventoryItem[]>(INITIAL_INVENTORY);
  const [filterForm, setFilterForm] = useState<string>('all');
  const [filterStatus, setFilterStatus] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [inspectingItem, setInspectingItem] = useState<InventoryItem | null>(null);

  const filteredItems = inventoryList.filter((item) => {
    const matchesForm = filterForm === 'all' || item.form === filterForm;
    const matchesStatus = filterStatus === 'all' || item.status === filterStatus;
    const q = searchQuery.toLowerCase();
    const matchesSearch = 
      item.grade.toLowerCase().includes(q) ||
      item.heatNumber.toLowerCase().includes(q) ||
      item.batchNumber.toLowerCase().includes(q) ||
      item.millSource.toLowerCase().includes(q) ||
      item.dimensionsMm.unitDesc.toLowerCase().includes(q) ||
      item.stockId.toLowerCase().includes(q);

    return matchesForm && matchesStatus && matchesSearch;
  });

  return (
    <div className="bg-[#090d12] text-slate-100 py-12 lg:py-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-8 pb-6 border-b border-slate-800">
          <div>
            <span className="text-xs font-mono font-semibold uppercase tracking-widest text-emerald-400">
              SHEFFIELD PHYSICAL LOGISTICS REGISTER
            </span>
            <h1 className="text-3xl sm:text-4xl font-extrabold text-white mt-1 tracking-tight">
              Live Titanium Stock & Heat Traceability
            </h1>
            <p className="text-slate-300 text-sm mt-2 max-w-2xl">
              Physical material held at TitanCore’s Sheffield warehouse. Every lot is linked to an 
              authenticated EN 10204 3.1 or 3.2 Mill Test Certificate, heat number, and positive material identification.
            </p>
          </div>

          <div className="flex items-center gap-3">
            <div className="px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-800 text-xs font-mono text-slate-300">
              Total Stock Weight: <span className="text-white font-bold">446.4 kg</span>
            </div>
            <div className="px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-800 text-xs font-mono text-slate-300">
              Valuation: <span className="text-white font-bold">£21,438.40</span>
            </div>
          </div>
        </div>

        {/* Filter Controls */}
        <div className="bg-slate-950/80 p-4 rounded-xl border border-slate-800 mb-6 flex flex-col md:flex-row gap-4 items-stretch md:items-center justify-between">
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search by Heat #, Batch, Grade, Mill (e.g., 'TC-2026-HT884', 'VDM', 'Plate')..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-9 pr-4 py-2 bg-slate-900 border border-slate-700 rounded-lg text-xs text-white placeholder-slate-400 focus:outline-none focus:border-cyan-500"
            />
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <select
              value={filterForm}
              onChange={(e) => setFilterForm(e.target.value)}
              className="bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-xs text-slate-200 focus:outline-none focus:border-cyan-500"
            >
              <option value="all">All Forms</option>
              <option value="plate">Plate</option>
              <option value="bar">Bar</option>
              <option value="sheet">Sheet</option>
              <option value="billet">Billet</option>
              <option value="tube">Tube</option>
            </select>

            <select
              value={filterStatus}
              onChange={(e) => setFilterStatus(e.target.value)}
              className="bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-xs text-slate-200 focus:outline-none focus:border-cyan-500"
            >
              <option value="all">All Statuses</option>
              <option value="In Stock">In Stock (Available)</option>
              <option value="Allocated">Allocated to Order</option>
              <option value="Quarantined">Quarantined (NCR Hold)</option>
            </select>
          </div>
        </div>

        {/* Stock Table */}
        <div className="bg-slate-950/90 rounded-xl border border-slate-800 overflow-hidden shadow-xl">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-900/90 text-slate-400 font-mono uppercase text-[11px] border-b border-slate-800">
                <tr>
                  <th className="py-3.5 px-4 font-semibold">Stock ID / Grade</th>
                  <th className="py-3.5 px-4 font-semibold">Form & Dimensions</th>
                  <th className="py-3.5 px-4 font-semibold">Heat & Batch #</th>
                  <th className="py-3.5 px-4 font-semibold">Mill Source</th>
                  <th className="py-3.5 px-4 font-semibold">Weight</th>
                  <th className="py-3.5 px-4 font-semibold">Location</th>
                  <th className="py-3.5 px-4 font-semibold">Status</th>
                  <th className="py-3.5 px-4 font-semibold text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/80 font-mono">
                {filteredItems.map((item) => (
                  <tr key={item.id} className="hover:bg-slate-900/40 transition-colors">
                    <td className="py-3.5 px-4">
                      <div className="font-bold text-white">{item.grade}</div>
                      <div className="text-[10px] text-slate-400 font-mono">{item.stockId}</div>
                    </td>

                    <td className="py-3.5 px-4">
                      <div className="text-slate-200 font-semibold">{item.dimensionsMm.unitDesc}</div>
                      <div className="text-[10px] text-slate-400 capitalize">{item.form}</div>
                    </td>

                    <td className="py-3.5 px-4">
                      <div className="text-cyan-400 font-bold">{item.heatNumber}</div>
                      <div className="text-[10px] text-slate-400">Batch {item.batchNumber}</div>
                    </td>

                    <td className="py-3.5 px-4">
                      <div className="text-slate-200">{item.millSource}</div>
                      <div className="text-[10px] text-slate-400">{item.millCountry}</div>
                    </td>

                    <td className="py-3.5 px-4 font-bold text-white">
                      {item.weightKg} kg
                    </td>

                    <td className="py-3.5 px-4 text-slate-300">
                      {item.location}
                    </td>

                    <td className="py-3.5 px-4">
                      <span className={`inline-flex items-center gap-1.5 px-2 py-0.5 rounded text-[10px] font-semibold uppercase ${
                        item.status === 'In Stock'
                          ? 'bg-emerald-950/80 text-emerald-300 border border-emerald-800'
                          : item.status === 'Allocated'
                          ? 'bg-blue-950/80 text-blue-300 border border-blue-800'
                          : 'bg-red-950/80 text-red-300 border border-red-800'
                      }`}>
                        {item.status === 'Quarantined' ? <ShieldAlert className="w-3 h-3" /> : <CheckCircle2 className="w-3 h-3" />}
                        {item.status}
                      </span>
                    </td>

                    <td className="py-3.5 px-4 text-right">
                      <div className="flex items-center justify-end gap-2">
                        <button
                          onClick={() => setInspectingItem(item)}
                          className="p-1.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white"
                          title="Inspect Mill Certificate"
                        >
                          <Eye className="w-3.5 h-3.5" />
                        </button>
                        {item.status === 'In Stock' && (
                          <button
                            onClick={() => onSelectStockForRfq(item)}
                            className="px-2.5 py-1 rounded bg-cyan-600 hover:bg-cyan-500 text-white font-sans text-xs font-semibold active:scale-95"
                          >
                            Quote
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Mill Test Report Inspection Modal */}
        {inspectingItem && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in">
            <div className="bg-slate-900 border border-slate-700 rounded-2xl max-w-2xl w-full p-6 shadow-2xl text-slate-200">
              <div className="flex items-start justify-between border-b border-slate-800 pb-4 mb-4">
                <div>
                  <span className="text-[10px] font-mono uppercase text-emerald-400 font-bold">
                    MILL TEST CERTIFICATE INSPECTION (EN 10204 3.1)
                  </span>
                  <h3 className="text-xl font-bold text-white mt-1">
                    Heat Traceability Dossier: {inspectingItem.heatNumber}
                  </h3>
                  <div className="text-xs text-slate-400 font-mono">
                    Stock Reference: {inspectingItem.stockId} • Mill: {inspectingItem.millSource} ({inspectingItem.millCountry})
                  </div>
                </div>
                <button
                  onClick={() => setInspectingItem(null)}
                  className="p-2 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Certificate content details */}
              <div className="space-y-4 text-xs font-mono">
                <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-2">
                  <div className="flex justify-between border-b border-slate-800 pb-2">
                    <span className="text-slate-400">Material Grade:</span>
                    <span className="text-white font-bold">{inspectingItem.grade}</span>
                  </div>
                  <div className="flex justify-between border-b border-slate-800 pb-2">
                    <span className="text-slate-400">Dimensions:</span>
                    <span className="text-white">{inspectingItem.dimensionsMm.unitDesc}</span>
                  </div>
                  <div className="flex justify-between border-b border-slate-800 pb-2">
                    <span className="text-slate-400">Lot / Batch Number:</span>
                    <span className="text-cyan-400">{inspectingItem.batchNumber}</span>
                  </div>
                  <div className="flex justify-between border-b border-slate-800 pb-2">
                    <span className="text-slate-400">Certificate Document ID:</span>
                    <span className="text-white">{inspectingItem.certificateId}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">Physical Location:</span>
                    <span className="text-slate-200">{inspectingItem.location}</span>
                  </div>
                </div>

                {inspectingItem.status === 'Quarantined' ? (
                  <div className="bg-red-950/60 border border-red-800/80 p-4 rounded-xl text-red-200 font-sans">
                    <div className="flex items-center gap-2 font-bold text-red-300 text-sm mb-1">
                      <ShieldAlert className="w-4 h-4 text-red-400" />
                      QUARANTINE ENFORCED: NON-CONFORMANCE OPEN
                    </div>
                    <p className="text-xs leading-relaxed text-red-300">
                      {inspectingItem.quarantineReason}
                    </p>
                    <div className="mt-2 text-[11px] text-red-400 font-mono">
                      Strict Quality Isolation: Material cannot be transferred, quoted, or loaded without Quality Manager electronic sign-off.
                    </div>
                  </div>
                ) : (
                  <div className="bg-emerald-950/50 border border-emerald-800/60 p-4 rounded-xl text-emerald-200 font-sans">
                    <div className="flex items-center gap-2 font-bold text-emerald-300 text-sm mb-1">
                      <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                      CERTIFICATION VERIFIED & APPROVED FOR DISPATCH
                    </div>
                    <p className="text-xs text-emerald-300">
                      Positive Material Identification (PMI) confirmed via handheld XRF spectrometer. Mechanical tensile testing conforms to ASTM B348 / AMS 4928.
                    </p>
                  </div>
                )}
              </div>

              <div className="mt-6 pt-4 border-t border-slate-800 flex justify-end gap-3">
                <button
                  onClick={() => setInspectingItem(null)}
                  className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-xs font-semibold rounded-lg text-slate-300"
                >
                  Close Dossier
                </button>
                {inspectingItem.status === 'In Stock' && (
                  <button
                    onClick={() => {
                      const item = inspectingItem;
                      setInspectingItem(null);
                      onSelectStockForRfq(item);
                    }}
                    className="px-4 py-2 bg-cyan-600 hover:bg-cyan-500 text-xs font-semibold rounded-lg text-white"
                  >
                    Select Batch for Quotation
                  </button>
                )}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
