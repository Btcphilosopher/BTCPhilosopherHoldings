'use client';

import React, { useState } from 'react';
import { Sparkles, Send, X, Bot, User, Loader2, Copy, Check, ShieldCheck } from 'lucide-react';

interface GeminiAdvisorModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialQuery?: string;
}

export const GeminiAdvisorModal: React.FC<GeminiAdvisorModalProps> = ({
  isOpen,
  onClose,
  initialQuery = '',
}) => {
  const [query, setQuery] = useState(initialQuery);
  const [messages, setMessages] = useState<Array<{ sender: 'user' | 'assistant'; text: string; source?: string }>>([
    {
      sender: 'assistant',
      text: `### Welcome to the TitanCore Metallurgical & Engineering Advisory Desk\n\nI am TitanCore's chief materials science and manufacturing advisor based at our Sheffield engineering facility. I provide grounded metallurgical advice on:\n\n- **Alloy Selection & Standards:** ASTM B265, ASTM B348, AMS 4911/4928, ISO 5832-3, BS EN specifications.\n- **Machining Dynamics:** Speeds ($V_c$), feeds ($f_z$), flood coolant (70-bar), and carbide tooling.\n- **Corrosion & Galvanic Coupling:** Seawater pitting resistance, reducing acid exposure, and noble galvanic potentials.\n- **Process Safety:** Titanium pyrophoric swarf control and Class D fire extinguishing protocols.\n\nHow can our Sheffield engineering team assist your design or procurement today?`,
      source: 'sheffield-metallurgical-engine',
    },
  ]);
  const [loading, setLoading] = useState(false);
  const [copiedIndex, setCopiedIndex] = useState<number | null>(null);

  const samplePrompts = [
    'Which grade is optimal for seawater heat exchangers at 85°C?',
    'Compare Grade 5 annealed vs Grade 23 ELI for cryogenic tanks',
    'What are the speeds and feeds for turning Ti-6Al-4V bar?',
    'What are the mandatory fire safety protocols for titanium CNC swarf?',
    'Explain EN 10204 3.1 vs 3.2 mill certificate requirements',
  ];

  const handleSend = async (textToSend?: string) => {
    const promptText = textToSend || query;
    if (!promptText.trim() || loading) return;

    const userMsg = { sender: 'user' as const, text: promptText };
    setMessages(prev => [...prev, userMsg]);
    setQuery('');
    setLoading(true);

    try {
      const response = await fetch('/api/gemini/advisor', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ query: promptText }),
      });

      const data = await response.json();
      const assistantMsg = {
        sender: 'assistant' as const,
        text: data.text || 'No response returned from the metallurgical engine.',
        source: data.source,
      };
      setMessages(prev => [...prev, assistantMsg]);
    } catch (error) {
      console.error('Advisor query failed:', error);
      setMessages(prev => [
        ...prev,
        {
          sender: 'assistant',
          text: 'Technical connection interrupted. Please ensure your query relates to titanium metallurgy or contact TitanCore directly at enquiries@titancore.co.uk.',
        },
      ]);
    } finally {
      setLoading(false);
    }
  };

  const handleCopy = (text: string, idx: number) => {
    navigator.clipboard.writeText(text);
    setCopiedIndex(idx);
    setTimeout(() => setCopiedIndex(null), 2000);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/80 backdrop-blur-sm animate-in fade-in">
      <div className="bg-slate-900 border border-slate-700 rounded-2xl max-w-3xl w-full h-[85vh] flex flex-col shadow-2xl text-slate-100 overflow-hidden">
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-slate-800 bg-slate-950 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-lg bg-cyan-950 border border-cyan-800 text-cyan-400">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-bold text-white text-base">
                  TitanCore Metallurgical Advisor
                </h3>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-cyan-950 text-cyan-300 border border-cyan-800">
                  Gemini 3.8 Flash Engine
                </span>
              </div>
              <div className="text-xs text-slate-400 font-mono">
                Materials Science • Standards ASTM/AMS • Speeds & Feeds • Sheffield HQ
              </div>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Quick Sample Prompt Chips */}
        <div className="bg-slate-950/60 px-4 py-2 border-b border-slate-800/80 overflow-x-auto">
          <div className="flex items-center gap-2 whitespace-nowrap text-xs">
            <span className="text-[10px] text-slate-500 font-mono uppercase">Quick Prompts:</span>
            {samplePrompts.map((p, idx) => (
              <button
                key={idx}
                onClick={() => handleSend(p)}
                disabled={loading}
                className="px-2.5 py-1 rounded-full bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white text-[11px] border border-slate-700 transition-colors"
              >
                {p}
              </button>
            ))}
          </div>
        </div>

        {/* Chat Stream */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-4 font-sans text-sm">
          {messages.map((m, idx) => (
            <div
              key={idx}
              className={`flex gap-3 ${m.sender === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              {m.sender === 'assistant' && (
                <div className="w-8 h-8 rounded-lg bg-cyan-950 border border-cyan-800 text-cyan-400 flex items-center justify-center shrink-0 mt-1">
                  <Bot className="w-4 h-4" />
                </div>
              )}

              <div
                className={`max-w-[85%] rounded-2xl p-4 space-y-2 text-xs sm:text-sm leading-relaxed ${
                  m.sender === 'user'
                    ? 'bg-cyan-600 text-white rounded-br-none'
                    : 'bg-slate-950/90 border border-slate-800 text-slate-200 rounded-bl-none font-sans'
                }`}
              >
                <div className="whitespace-pre-wrap">
                  {m.text}
                </div>

                {m.sender === 'assistant' && (
                  <div className="pt-2 mt-2 border-t border-slate-800/80 flex items-center justify-between text-[10px] text-slate-400 font-mono">
                    <span>Source: {m.source || 'gemini-3.8-flash'}</span>
                    <button
                      onClick={() => handleCopy(m.text, idx)}
                      className="flex items-center gap-1 hover:text-white transition-colors"
                    >
                      {copiedIndex === idx ? (
                        <>
                          <Check className="w-3 h-3 text-emerald-400" />
                          <span className="text-emerald-400">Copied</span>
                        </>
                      ) : (
                        <>
                          <Copy className="w-3 h-3" />
                          <span>Copy Response</span>
                        </>
                      )}
                    </button>
                  </div>
                )}
              </div>

              {m.sender === 'user' && (
                <div className="w-8 h-8 rounded-lg bg-slate-800 border border-slate-700 text-white flex items-center justify-center shrink-0 mt-1">
                  <User className="w-4 h-4" />
                </div>
              )}
            </div>
          ))}

          {loading && (
            <div className="flex gap-3 items-center text-xs text-slate-400 font-mono">
              <div className="w-8 h-8 rounded-lg bg-cyan-950 border border-cyan-800 text-cyan-400 flex items-center justify-center shrink-0">
                <Loader2 className="w-4 h-4 animate-spin" />
              </div>
              <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 text-slate-300">
                Consulting TitanCore Sheffield metallurgical knowledge base & calculating parameters...
              </div>
            </div>
          )}
        </div>

        {/* Input Bar */}
        <div className="p-4 bg-slate-950 border-t border-slate-800">
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleSend();
            }}
            className="flex gap-2"
          >
            <input
              type="text"
              placeholder="Ask a metallurgical question (e.g., 'What feed rate should I use for Grade 5 milling?')..."
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              disabled={loading}
              className="flex-1 bg-slate-900 border border-slate-700 rounded-xl px-4 py-3 text-xs sm:text-sm text-white placeholder-slate-400 focus:outline-none focus:border-cyan-500"
            />
            <button
              type="submit"
              disabled={loading || !query.trim()}
              className="px-5 py-3 rounded-xl bg-cyan-600 hover:bg-cyan-500 disabled:opacity-50 text-white font-semibold text-xs flex items-center gap-2 transition-all shadow-md active:scale-95 shrink-0"
            >
              {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
              <span className="hidden sm:inline">Consult</span>
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};
