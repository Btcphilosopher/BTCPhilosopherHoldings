'use client';

import React, { useState } from 'react';
import { 
  Terminal, 
  TrendingUp, 
  DollarSign, 
  FileText, 
  Boxes, 
  Building2, 
  ShieldAlert, 
  Calculator, 
  CheckCircle2, 
  AlertTriangle, 
  Sparkles, 
  ArrowRight, 
  Plus, 
  Download, 
  RefreshCw,
  Users,
  Eye,
  X
} from 'lucide-react';
import { INITIAL_INVENTORY, INITIAL_SUPPLIERS, INITIAL_QUOTATIONS, INITIAL_NCRS, TITANIUM_MATERIALS } from '@/lib/data';
import { Quotation, InventoryItem, SupplierProfile, NonConformanceReport, MakeOrBuyScenario } from '@/lib/types';

interface TitanOsDashboardProps {
  onExitToPublic: () => void;
  onAskAi: (query: string) => void;
}

export const TitanOsDashboard: React.FC<TitanOsDashboardProps> = ({
  onExitToPublic,
  onAskAi,
}) => {
  const [currentRole, setCurrentRole] = useState<'Executive' | 'Sales' | 'Procurement' | 'Quality'>('Executive');
  const [activeTab, setActiveTab] = useState<'overview' | 'quotes' | 'inventory' | 'suppliers' | 'make_or_buy' | 'ncrs'>('overview');

  // Operational State
  const [quotations, setQuotations] = useState<Quotation[]>(INITIAL_QUOTATIONS);
  const [inventory, setInventory] = useState<InventoryItem[]>(INITIAL_INVENTORY);
  const [suppliers, setSuppliers] = useState<SupplierProfile[]>(INITIAL_SUPPLIERS);
  const [ncrs, setNcrs] = useState<NonConformanceReport[]>(INITIAL_NCRS);

  // Active Quote in editor/detail
  const [selectedQuote, setSelectedQuote] = useState<Quotation | null>(quotations[0]);
  const [quotePricingMode, setQuotePricingMode] = useState<'margin' | 'markup'>('margin');
  const [targetMargin, setTargetMargin] = useState<number>(28.5);

  // Make or Buy Scenario State
  const [makeOrBuy, setMakeOrBuy] = useState<MakeOrBuyScenario>({
    operationName: '5-Axis Machining of Ti-6Al-4V Impeller Blisks',
    monthlyPartsVolume: 65,
    vendorCostPerPartGbp: 420,
    inHouseMachineCapExGbp: 340000,
    inHouseToolingMonthlyGbp: 3800,
    inHouseLaborPerHourGbp: 32,
    cycleTimeHoursPerPart: 3.2,
    facilityOverheadMonthlyGbp: 2500,
  });

  // Calculate Make-or-Buy metrics
  const monthlyOutsourceCost = makeOrBuy.monthlyPartsVolume * makeOrBuy.vendorCostPerPartGbp;
  const inHousePartLaborCost = makeOrBuy.cycleTimeHoursPerPart * makeOrBuy.inHouseLaborPerHourGbp;
  const monthlyInHouseOpEx = (makeOrBuy.monthlyPartsVolume * inHousePartLaborCost) + makeOrBuy.inHouseToolingMonthlyGbp + makeOrBuy.facilityOverheadMonthlyGbp;
  const monthlyNetSavings = monthlyOutsourceCost - monthlyInHouseOpEx;
  const breakEvenPartsPerMonth = Math.ceil(
    (makeOrBuy.inHouseToolingMonthlyGbp + makeOrBuy.facilityOverheadMonthlyGbp) / 
    Math.max(1, (makeOrBuy.vendorCostPerPartGbp - inHousePartLaborCost))
  );
  const paybackMonths = monthlyNetSavings > 0 
    ? (makeOrBuy.inHouseMachineCapExGbp / monthlyNetSavings).toFixed(1)
    : 'Never (Volume too low)';

  // Executive Financial Metrics
  const totalStockValuation = inventory.reduce((sum, item) => sum + (item.weightKg * item.unitCostGbp), 0);
  const totalStockWeightKg = inventory.reduce((sum, item) => sum + item.weightKg, 0);
  const activePipelineGbp = quotations.reduce((sum, q) => sum + q.totalQuotedPriceGbp, 0);

  return (
    <div className="bg-[#070b0f] text-slate-100 min-h-screen">
      {/* Top OS Navigation Header */}
      <div className="bg-slate-950 border-b border-slate-800 px-4 sm:px-6 lg:px-8 py-3">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-lg bg-amber-500/10 border border-amber-500/40 text-amber-400">
              <Terminal className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-mono text-base font-bold text-white tracking-wider">
                  TITANOS COMMERCIAL OS
                </span>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-950 text-emerald-400 border border-emerald-800">
                  SHEFFIELD LIVE NODE
                </span>
              </div>
              <div className="text-[11px] text-slate-400 font-mono">
                Integrated Commercial Operating System: Quotations • ERP • Traceability • Analytics
              </div>
            </div>
          </div>

          <div className="flex items-center gap-3">
            {/* Role Switcher */}
            <div className="flex items-center gap-2 bg-slate-900 px-2.5 py-1.5 rounded-lg border border-slate-800 text-xs">
              <Users className="w-3.5 h-3.5 text-cyan-400" />
              <span className="text-slate-400 hidden sm:inline">Role:</span>
              <select
                value={currentRole}
                onChange={(e) => setCurrentRole(e.target.value as any)}
                className="bg-transparent text-white font-semibold focus:outline-none cursor-pointer"
              >
                <option value="Executive">Executive / Commercial Director</option>
                <option value="Sales">Sales & Estimating Engineer</option>
                <option value="Procurement">Procurement Specialist</option>
                <option value="Quality">Quality & Metrology Lead</option>
              </select>
            </div>

            <button
              onClick={onExitToPublic}
              className="px-3 py-1.5 rounded-lg bg-slate-900 hover:bg-slate-850 text-slate-300 border border-slate-700 text-xs font-semibold"
            >
              Back to Public Portal
            </button>
          </div>
        </div>
      </div>

      {/* Internal Navigation Tabs */}
      <div className="bg-slate-950/60 border-b border-slate-800 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto flex overflow-x-auto space-x-1 py-2 text-xs font-mono">
          <button
            onClick={() => setActiveTab('overview')}
            className={`px-3 py-2 rounded-lg transition-colors flex items-center gap-2 ${
              activeTab === 'overview' ? 'bg-amber-500/20 text-amber-300 font-bold border border-amber-500/40' : 'text-slate-400 hover:text-white'
            }`}
          >
            <TrendingUp className="w-3.5 h-3.5" />
            <span>Executive Dashboard</span>
          </button>

          <button
            onClick={() => setActiveTab('quotes')}
            className={`px-3 py-2 rounded-lg transition-colors flex items-center gap-2 ${
              activeTab === 'quotes' ? 'bg-amber-500/20 text-amber-300 font-bold border border-amber-500/40' : 'text-slate-400 hover:text-white'
            }`}
          >
            <DollarSign className="w-3.5 h-3.5" />
            <span>Costing & Quotations ({quotations.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('inventory')}
            className={`px-3 py-2 rounded-lg transition-colors flex items-center gap-2 ${
              activeTab === 'inventory' ? 'bg-amber-500/20 text-amber-300 font-bold border border-amber-500/40' : 'text-slate-400 hover:text-white'
            }`}
          >
            <Boxes className="w-3.5 h-3.5" />
            <span>Inventory & Batch Traceability</span>
          </button>

          <button
            onClick={() => setActiveTab('suppliers')}
            className={`px-3 py-2 rounded-lg transition-colors flex items-center gap-2 ${
              activeTab === 'suppliers' ? 'bg-amber-500/20 text-amber-300 font-bold border border-amber-500/40' : 'text-slate-400 hover:text-white'
            }`}
          >
            <Building2 className="w-3.5 h-3.5" />
            <span>Approved Suppliers (ASL)</span>
          </button>

          <button
            onClick={() => setActiveTab('make_or_buy')}
            className={`px-3 py-2 rounded-lg transition-colors flex items-center gap-2 ${
              activeTab === 'make_or_buy' ? 'bg-amber-500/20 text-amber-300 font-bold border border-amber-500/40' : 'text-slate-400 hover:text-white'
            }`}
          >
            <Calculator className="w-3.5 h-3.5" />
            <span>Make-or-Buy CapEx Simulator</span>
          </button>

          <button
            onClick={() => setActiveTab('ncrs')}
            className={`px-3 py-2 rounded-lg transition-colors flex items-center gap-2 ${
              activeTab === 'ncrs' ? 'bg-amber-500/20 text-amber-300 font-bold border border-amber-500/40' : 'text-slate-400 hover:text-white'
            }`}
          >
            <ShieldAlert className="w-3.5 h-3.5 text-red-400" />
            <span>Non-Conformance (NCRs) ({ncrs.length})</span>
          </button>
        </div>
      </div>

      {/* Main Content Area */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* TAB 1: EXECUTIVE DASHBOARD */}
        {activeTab === 'overview' && (
          <div className="space-y-8">
            {/* Top KPI Cards */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              <div className="bg-slate-950 p-5 rounded-xl border border-slate-800 space-y-2">
                <div className="text-[10px] font-mono text-slate-400 uppercase tracking-wider">
                  YTD Invoiced Revenue
                </div>
                <div className="text-2xl font-black text-white font-mono">
                  £1,842,500
                </div>
                <div className="text-xs text-emerald-400 font-mono flex items-center gap-1">
                  <span>+24.2% vs target</span>
                  <span className="text-slate-500">• Cashflow +ve</span>
                </div>
              </div>

              <div className="bg-slate-950 p-5 rounded-xl border border-slate-800 space-y-2">
                <div className="text-[10px] font-mono text-slate-400 uppercase tracking-wider">
                  Target Gross Margin vs Realised
                </div>
                <div className="text-2xl font-black text-cyan-400 font-mono">
                  28.4%
                </div>
                <div className="text-xs text-slate-400 font-mono">
                  Formula: ((Rev - COGS) / Rev) * 100
                </div>
              </div>

              <div className="bg-slate-950 p-5 rounded-xl border border-slate-800 space-y-2">
                <div className="text-[10px] font-mono text-slate-400 uppercase tracking-wider">
                  Physical Inventory Valuation
                </div>
                <div className="text-2xl font-black text-white font-mono">
                  £{Math.round(totalStockValuation).toLocaleString()}
                </div>
                <div className="text-xs text-slate-400 font-mono">
                  {totalStockWeightKg.toFixed(1)} kg Sheffield Stock
                </div>
              </div>

              <div className="bg-slate-950 p-5 rounded-xl border border-slate-800 space-y-2">
                <div className="text-[10px] font-mono text-slate-400 uppercase tracking-wider">
                  Working Capital Runway
                </div>
                <div className="text-2xl font-black text-amber-300 font-mono">
                  14.2 Months
                </div>
                <div className="text-xs text-emerald-400 font-mono">
                  Zero external long-term debt
                </div>
              </div>
            </div>

            {/* Stage Pipeline & Commercial Analytics */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
              <div className="lg:col-span-8 bg-slate-950 p-6 rounded-2xl border border-slate-800 space-y-4">
                <h3 className="text-base font-bold text-white flex items-center justify-between">
                  <span>Sales & Quotation Pipeline Funnel</span>
                  <span className="text-xs font-mono text-cyan-400 font-normal">Active Value: £{activePipelineGbp.toLocaleString()}</span>
                </h3>

                <div className="space-y-3 font-mono text-xs">
                  <div>
                    <div className="flex justify-between text-slate-400 mb-1">
                      <span>1. Technical Enquiries & Specifications</span>
                      <span className="text-white">18 Leads (£620,000)</span>
                    </div>
                    <div className="w-full bg-slate-900 h-2 rounded-full overflow-hidden">
                      <div className="bg-cyan-500 h-full w-[85%]" />
                    </div>
                  </div>

                  <div>
                    <div className="flex justify-between text-slate-400 mb-1">
                      <span>2. Active Costed Quotations (Sent)</span>
                      <span className="text-white">8 Quotes (£184,000)</span>
                    </div>
                    <div className="w-full bg-slate-900 h-2 rounded-full overflow-hidden">
                      <div className="bg-blue-500 h-full w-[55%]" />
                    </div>
                  </div>

                  <div>
                    <div className="flex justify-between text-slate-400 mb-1">
                      <span>3. Confirmed Purchase Orders (Fulfillment)</span>
                      <span className="text-white">6 Orders (£112,500)</span>
                    </div>
                    <div className="w-full bg-slate-900 h-2 rounded-full overflow-hidden">
                      <div className="bg-emerald-500 h-full w-[38%]" />
                    </div>
                  </div>

                  <div>
                    <div className="flex justify-between text-slate-400 mb-1">
                      <span>4. Inspection, CMM & Dispatched</span>
                      <span className="text-white">4 Batches (£68,000)</span>
                    </div>
                    <div className="w-full bg-slate-900 h-2 rounded-full overflow-hidden">
                      <div className="bg-purple-500 h-full w-[25%]" />
                    </div>
                  </div>
                </div>

                <div className="pt-4 border-t border-slate-800 text-xs text-slate-400">
                  Average conversion from Technical Enquiry to Ordered: <strong className="text-white">32.4%</strong>. Mean cycle time: <strong className="text-white">11.8 days</strong>.
                </div>
              </div>

              {/* Quality & Risk Box */}
              <div className="lg:col-span-4 bg-slate-950 p-6 rounded-2xl border border-slate-800 space-y-4">
                <h3 className="text-base font-bold text-white flex items-center gap-2">
                  <ShieldAlert className="w-4 h-4 text-red-400" />
                  <span>Quality & Risk Health</span>
                </h3>

                <div className="space-y-3 font-mono text-xs">
                  <div className="bg-slate-900 p-3 rounded-xl border border-slate-800 flex justify-between">
                    <span className="text-slate-400">Quality Incident Rate:</span>
                    <span className="text-emerald-400 font-bold">0.32%</span>
                  </div>
                  <div className="bg-slate-900 p-3 rounded-xl border border-slate-800 flex justify-between">
                    <span className="text-slate-400">Open NCR Quarantine:</span>
                    <span className="text-amber-400 font-bold">1 Lot (HT620)</span>
                  </div>
                  <div className="bg-slate-900 p-3 rounded-xl border border-slate-800 flex justify-between">
                    <span className="text-slate-400">Supplier On-Time:</span>
                    <span className="text-cyan-400 font-bold">95.4%</span>
                  </div>
                </div>

                <button
                  onClick={() => onAskAi('Provide an executive metallurgical audit briefing on TitanCore quality metrics and aerospace readiness.')}
                  className="w-full py-2.5 rounded-lg bg-slate-900 hover:bg-slate-850 text-cyan-400 text-xs font-semibold flex items-center justify-center gap-2 border border-slate-800"
                >
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>Executive AI Audit Summary</span>
                </button>
              </div>
            </div>
          </div>
        )}

        {/* TAB 2: COSTING & QUOTATION MANAGEMENT */}
        {activeTab === 'quotes' && (
          <div className="space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-800">
              <div>
                <h3 className="text-xl font-bold text-white">
                  Sales Quotations & Costing Engine
                </h3>
                <p className="text-xs text-slate-400 font-mono">
                  Full cost basis breakdown: Raw titanium + Scrap yield allowance + Machining + Inspection fees + Hedging.
                </p>
              </div>

              <div className="flex items-center gap-3">
                <div className="bg-slate-900 p-1 rounded-lg border border-slate-800 flex text-xs font-mono">
                  <button
                    onClick={() => setQuotePricingMode('margin')}
                    className={`px-3 py-1.5 rounded-md ${
                      quotePricingMode === 'margin' ? 'bg-cyan-600 text-white font-bold' : 'text-slate-400'
                    }`}
                  >
                    Target Margin %
                  </button>
                  <button
                    onClick={() => setQuotePricingMode('markup')}
                    className={`px-3 py-1.5 rounded-md ${
                      quotePricingMode === 'markup' ? 'bg-cyan-600 text-white font-bold' : 'text-slate-400'
                    }`}
                  >
                    Target Markup %
                  </button>
                </div>
              </div>
            </div>

            {/* Quotes Table and Detail Inspector */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
              {/* Quotes List */}
              <div className="lg:col-span-5 bg-slate-950 rounded-xl border border-slate-800 overflow-hidden">
                <div className="p-3 bg-slate-900/80 border-b border-slate-800 text-xs font-mono font-bold text-slate-400 uppercase">
                  Existing Quotations
                </div>
                <div className="divide-y divide-slate-800">
                  {quotations.map((q) => (
                    <div
                      key={q.id}
                      onClick={() => setSelectedQuote(q)}
                      className={`p-4 cursor-pointer transition-colors ${
                        selectedQuote?.id === q.id ? 'bg-slate-900/90 border-l-4 border-cyan-500' : 'hover:bg-slate-900/40'
                      }`}
                    >
                      <div className="flex items-start justify-between">
                        <div>
                          <div className="font-bold text-white text-sm">{q.clientCompany}</div>
                          <div className="text-xs text-cyan-400 font-mono">{q.quoteNumber}</div>
                        </div>
                        <div className="text-right">
                          <div className="font-mono font-bold text-white text-sm">£{q.totalQuotedPriceGbp.toLocaleString()}</div>
                          <span className={`text-[10px] px-1.5 py-0.5 rounded font-mono ${
                            q.status === 'Sent' ? 'bg-blue-950 text-blue-300' : 'bg-amber-950 text-amber-300'
                          }`}>
                            {q.status}
                          </span>
                        </div>
                      </div>
                      <div className="mt-2 text-xs text-slate-400 line-clamp-1">
                        {q.lines[0]?.materialName}
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Quotation Detail / Costing Engine */}
              {selectedQuote && (
                <div className="lg:col-span-7 bg-slate-950 p-6 rounded-2xl border border-slate-800 space-y-6">
                  <div className="flex items-start justify-between border-b border-slate-800 pb-4">
                    <div>
                      <span className="text-[10px] font-mono text-cyan-400 font-bold uppercase">
                        QUOTATION WORKSHEET
                      </span>
                      <h4 className="text-2xl font-bold text-white mt-1">
                        {selectedQuote.quoteNumber} — {selectedQuote.clientCompany}
                      </h4>
                      <div className="text-xs text-slate-400 font-mono">
                        Contact: {selectedQuote.contactName} ({selectedQuote.contactEmail})
                      </div>
                    </div>

                    <div className="text-right font-mono">
                      <div className="text-xs text-slate-400">Validity: {selectedQuote.validityDays} Days</div>
                      <div className="text-xs text-emerald-400 font-bold">Standard FCA Sheffield</div>
                    </div>
                  </div>

                  {/* Pricing Mode Explicit Formula Callout */}
                  <div className="bg-slate-900 p-3 rounded-xl border border-slate-800 text-xs font-mono space-y-1">
                    <div className="text-cyan-400 font-bold">
                      {quotePricingMode === 'margin' ? 'GROSS MARGIN FORMULA ACTIVATED:' : 'MARKUP FORMULA ACTIVATED:'}
                    </div>
                    <div className="text-slate-300">
                      {quotePricingMode === 'margin' 
                        ? 'Price = CostBasis / (1 - TargetMargin%)  •  Effective Margin = ((Price - Cost) / Price) * 100'
                        : 'Price = CostBasis * (1 + TargetMarkup%)  •  Effective Markup = ((Price - Cost) / Cost) * 100'}
                    </div>
                  </div>

                  {/* Cost Items Grid */}
                  <div className="space-y-3 font-mono text-xs">
                    <div className="flex justify-between p-2.5 bg-slate-900 rounded-lg">
                      <span className="text-slate-400">Raw Material Purchase Cost:</span>
                      <span className="text-white font-bold">£{selectedQuote.totalRawCostGbp.toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between p-2.5 bg-slate-900 rounded-lg">
                      <span className="text-slate-400">Machining & Cutting Operations:</span>
                      <span className="text-white font-bold">£{selectedQuote.totalProcessingCostGbp.toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between p-2.5 bg-slate-900 rounded-lg">
                      <span className="text-slate-400">Testing & EN 10204 3.1 Certification:</span>
                      <span className="text-white font-bold">£{selectedQuote.totalQualityInspectionCostGbp.toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between p-2.5 bg-slate-900 rounded-lg">
                      <span className="text-slate-400">Packaging, Crating & Logistics:</span>
                      <span className="text-white font-bold">£{selectedQuote.totalLogisticsCostGbp.toFixed(2)}</span>
                    </div>

                    <div className="pt-2 border-t border-slate-800 flex justify-between text-sm">
                      <span className="text-slate-300 font-sans font-bold">Total Operational Cost Basis:</span>
                      <span className="text-slate-100 font-bold">£{selectedQuote.totalCostBasisGbp.toFixed(2)}</span>
                    </div>

                    <div className="bg-cyan-950/50 border border-cyan-800/80 p-4 rounded-xl flex justify-between items-center text-sm">
                      <div>
                        <div className="text-[10px] text-cyan-400 font-bold uppercase">Quoted Customer Total</div>
                        <div className="text-slate-400 text-xs">
                          Gross Profit: £{selectedQuote.calculatedGrossProfitGbp.toFixed(2)} ({selectedQuote.effectiveGrossMarginPercent.toFixed(1)}% margin)
                        </div>
                      </div>
                      <div className="text-2xl font-black text-cyan-300 font-mono">
                        £{selectedQuote.totalQuotedPriceGbp.toLocaleString()}
                      </div>
                    </div>
                  </div>

                  <div className="text-xs text-slate-300 bg-slate-900 p-3 rounded-lg border border-slate-800 font-sans">
                    <strong>Technical Notes:</strong> {selectedQuote.notes}
                  </div>
                </div>
              )}
            </div>
          </div>
        )}

        {/* TAB 3: INVENTORY & PHYSICAL BATCH TRACEABILITY */}
        {activeTab === 'inventory' && (
          <div className="space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-800">
              <div>
                <h3 className="text-xl font-bold text-white">
                  Warehouse Inventory & Batch Heat Register
                </h3>
                <p className="text-xs text-slate-400 font-mono">
                  Full physical traceability: Ingot Heat Number, Mill Test Report ID, Storage Bay, and Quarantine Isolation.
                </p>
              </div>

              <div className="text-xs font-mono text-slate-300 bg-slate-900 px-3 py-1.5 rounded-lg border border-slate-800">
                Active Bays: Bay A-02, Bay B-04, CS-01, Quarantine Q-01
              </div>
            </div>

            <div className="bg-slate-950 rounded-xl border border-slate-800 overflow-hidden shadow-xl">
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs font-mono">
                  <thead className="bg-slate-900 text-slate-400 uppercase text-[10px] border-b border-slate-800">
                    <tr>
                      <th className="p-3">Stock Ref / Grade</th>
                      <th className="p-3">Profile & Dimensions</th>
                      <th className="p-3">Heat / Batch</th>
                      <th className="p-3">Weight</th>
                      <th className="p-3">Unit Cost</th>
                      <th className="p-3">Location</th>
                      <th className="p-3">Status</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800">
                    {inventory.map((item) => (
                      <tr key={item.id} className="hover:bg-slate-900/50">
                        <td className="p-3">
                          <div className="text-white font-bold">{item.grade}</div>
                          <div className="text-[10px] text-slate-500">{item.stockId}</div>
                        </td>
                        <td className="p-3 text-slate-300">{item.dimensionsMm.unitDesc}</td>
                        <td className="p-3">
                          <div className="text-cyan-400 font-bold">{item.heatNumber}</div>
                          <div className="text-[10px] text-slate-500">Batch {item.batchNumber}</div>
                        </td>
                        <td className="p-3 font-bold text-white">{item.weightKg} kg</td>
                        <td className="p-3 text-slate-300">£{item.unitCostGbp}/kg</td>
                        <td className="p-3 text-slate-300">{item.location}</td>
                        <td className="p-3">
                          <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                            item.status === 'In Stock'
                              ? 'bg-emerald-950 text-emerald-400 border border-emerald-800'
                              : item.status === 'Allocated'
                              ? 'bg-blue-950 text-blue-400 border border-blue-800'
                              : 'bg-red-950 text-red-400 border border-red-800'
                          }`}>
                            {item.status}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* TAB 4: APPROVED SUPPLIERS LIST (ASL) */}
        {activeTab === 'suppliers' && (
          <div className="space-y-6">
            <div className="pb-4 border-b border-slate-800">
              <h3 className="text-xl font-bold text-white">
                Approved Supplier List (ASL) & Mill Qualifications
              </h3>
              <p className="text-xs text-slate-400 font-mono">
                Strict vendor accreditation scope: ISO 9001, AS9100 Rev D, Nadcap testing, and lead time reliability.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {suppliers.map((sup) => (
                <div key={sup.id} className="bg-slate-950 p-6 rounded-2xl border border-slate-800 space-y-4">
                  <div className="flex items-start justify-between">
                    <div>
                      <span className={`text-[10px] font-mono px-2 py-0.5 rounded border uppercase font-bold ${
                        sup.approvalStatus === 'Approved (ASL)'
                          ? 'bg-emerald-950 text-emerald-400 border-emerald-800'
                          : 'bg-amber-950 text-amber-400 border-amber-800'
                      }`}>
                        {sup.approvalStatus}
                      </span>
                      <h4 className="text-lg font-bold text-white mt-2">{sup.name}</h4>
                      <div className="text-xs text-slate-400">{sup.productionFacility} ({sup.country})</div>
                    </div>

                    <div className="text-right font-mono text-xs">
                      <div className="text-cyan-400 font-bold">{sup.qualityRatingScore}%</div>
                      <div className="text-[10px] text-slate-500">Quality Score</div>
                    </div>
                  </div>

                  <div className="space-y-2 text-xs font-mono pt-2 border-t border-slate-800/80">
                    <div className="flex justify-between">
                      <span className="text-slate-400">On-Time Delivery Rate:</span>
                      <span className="text-white font-bold">{sup.onTimeDeliveryRate}%</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-400">Average Mill Lead Time:</span>
                      <span className="text-white">{sup.averageLeadTimeDays} Days</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-400">Minimum Order Qty (MOQ):</span>
                      <span className="text-white">{sup.minimumOrderQuantityKg} kg</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-400">Commercial Terms:</span>
                      <span className="text-slate-200">{sup.paymentTerms}</span>
                    </div>
                  </div>

                  <div className="pt-2">
                    <span className="text-[10px] font-mono text-slate-500 block uppercase mb-1">Audit Certifications:</span>
                    <div className="flex flex-wrap gap-1">
                      {sup.certifications.map((c, i) => (
                        <span key={i} className="text-[10px] px-2 py-0.5 rounded bg-slate-900 text-slate-300 border border-slate-800">
                          {c}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* TAB 5: MAKE-OR-BUY CAPEX SIMULATOR */}
        {activeTab === 'make_or_buy' && (
          <div className="space-y-6">
            <div className="pb-4 border-b border-slate-800">
              <h3 className="text-xl font-bold text-white">
                Make-or-Buy CapEx & Throughput Decision Simulator
              </h3>
              <p className="text-xs text-slate-400 font-mono">
                Compare outsourced partner machining against in-house 5-axis CNC machining cell investment (Stage 2 vs Stage 3).
              </p>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
              {/* Inputs */}
              <div className="lg:col-span-6 bg-slate-950 p-6 rounded-2xl border border-slate-800 space-y-4">
                <h4 className="text-sm font-mono font-bold text-cyan-400 uppercase">
                  Operation & Cost Inputs
                </h4>

                <div>
                  <label className="block text-xs font-mono text-slate-400 mb-1">
                    Monthly Part Throughput (Volume): <strong className="text-white">{makeOrBuy.monthlyPartsVolume} parts/month</strong>
                  </label>
                  <input
                    type="range"
                    min={10}
                    max={250}
                    value={makeOrBuy.monthlyPartsVolume}
                    onChange={(e) => setMakeOrBuy({ ...makeOrBuy, monthlyPartsVolume: Number(e.target.value) })}
                    className="w-full accent-cyan-500"
                  />
                </div>

                <div className="grid grid-cols-2 gap-4 text-xs font-mono">
                  <div>
                    <label className="block text-slate-400 mb-1">Subcontractor Price / Part (£)</label>
                    <input
                      type="number"
                      value={makeOrBuy.vendorCostPerPartGbp}
                      onChange={(e) => setMakeOrBuy({ ...makeOrBuy, vendorCostPerPartGbp: Number(e.target.value) })}
                      className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2 text-white"
                    />
                  </div>
                  <div>
                    <label className="block text-slate-400 mb-1">In-House Cell CapEx (£)</label>
                    <input
                      type="number"
                      value={makeOrBuy.inHouseMachineCapExGbp}
                      onChange={(e) => setMakeOrBuy({ ...makeOrBuy, inHouseMachineCapExGbp: Number(e.target.value) })}
                      className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2 text-white"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4 text-xs font-mono">
                  <div>
                    <label className="block text-slate-400 mb-1">Cycle Time (Hours/Part)</label>
                    <input
                      type="number"
                      step={0.1}
                      value={makeOrBuy.cycleTimeHoursPerPart}
                      onChange={(e) => setMakeOrBuy({ ...makeOrBuy, cycleTimeHoursPerPart: Number(e.target.value) })}
                      className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2 text-white"
                    />
                  </div>
                  <div>
                    <label className="block text-slate-400 mb-1">Machinist Labor Rate (£/hr)</label>
                    <input
                      type="number"
                      value={makeOrBuy.inHouseLaborPerHourGbp}
                      onChange={(e) => setMakeOrBuy({ ...makeOrBuy, inHouseLaborPerHourGbp: Number(e.target.value) })}
                      className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2 text-white"
                    />
                  </div>
                </div>
              </div>

              {/* Outputs */}
              <div className="lg:col-span-6 bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950 p-6 rounded-2xl border border-slate-800 space-y-6 font-mono text-xs">
                <div>
                  <span className="text-[10px] text-cyan-400 font-bold uppercase">
                    SIMULATION RESULTS
                  </span>
                  <h4 className="text-xl font-bold text-white mt-1">
                    Monthly Commercial Payoff
                  </h4>
                </div>

                <div className="space-y-3">
                  <div className="bg-slate-900 p-3 rounded-lg flex justify-between">
                    <span className="text-slate-400">Current Outsourced Monthly Cost:</span>
                    <span className="text-white font-bold">£{monthlyOutsourceCost.toLocaleString()}</span>
                  </div>
                  <div className="bg-slate-900 p-3 rounded-lg flex justify-between">
                    <span className="text-slate-400">In-House Estimated Monthly OpEx:</span>
                    <span className="text-slate-200 font-bold">£{Math.round(monthlyInHouseOpEx).toLocaleString()}</span>
                  </div>
                  <div className="bg-slate-900 p-3 rounded-lg flex justify-between">
                    <span className="text-slate-400">Net Monthly Cash Savings:</span>
                    <span className={`font-bold text-base ${monthlyNetSavings > 0 ? 'text-emerald-400' : 'text-red-400'}`}>
                      £{Math.round(monthlyNetSavings).toLocaleString()} / month
                    </span>
                  </div>
                  <div className="bg-slate-900 p-3 rounded-lg flex justify-between">
                    <span className="text-slate-400">Break-even Volume Threshold:</span>
                    <span className="text-cyan-400 font-bold">{breakEvenPartsPerMonth} parts / month</span>
                  </div>
                  <div className="bg-cyan-950/60 border border-cyan-800 p-4 rounded-xl flex justify-between items-center text-sm">
                    <div>
                      <div className="text-[10px] uppercase font-bold text-cyan-400">CapEx Payback Horizon</div>
                      <div className="text-[11px] text-slate-400">Against £{makeOrBuy.inHouseMachineCapExGbp.toLocaleString()} DMG MORI Cell</div>
                    </div>
                    <div className="text-2xl font-black text-cyan-300">
                      {paybackMonths} {typeof paybackMonths === 'string' && paybackMonths.includes('Never') ? '' : 'Months'}
                    </div>
                  </div>
                </div>

                <div className="text-[11px] text-slate-400">
                  {makeOrBuy.monthlyPartsVolume < breakEvenPartsPerMonth ? (
                    <span className="text-amber-300">
                      Recommendation: <strong>Remain in Stage 2 (Outsourced partner processing)</strong>. Current volume of {makeOrBuy.monthlyPartsVolume} parts does not yet cover in-house tooling, operator fixed costs, and depreciation.
                    </span>
                  ) : (
                    <span className="text-emerald-300">
                      Recommendation: <strong>Strong Business Case for Stage 3 In-House Investment</strong>. Monthly volume of {makeOrBuy.monthlyPartsVolume} parts amortizes the £340k cell within {paybackMonths} months.
                    </span>
                  )}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* TAB 6: NON-CONFORMANCE (NCRS) */}
        {activeTab === 'ncrs' && (
          <div className="space-y-6">
            <div className="pb-4 border-b border-slate-800">
              <h3 className="text-xl font-bold text-white">
                Quality Non-Conformance Reports (NCR) & CAPA Register
              </h3>
              <p className="text-xs text-slate-400 font-mono">
                Mandatory containment workflow per ISO 9001:2015 Clause 8.7 & AS9100 Rev D.
              </p>
            </div>

            <div className="space-y-4">
              {ncrs.map((ncr) => (
                <div key={ncr.id} className="bg-slate-950 p-6 rounded-2xl border border-slate-800 space-y-3">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                    <div className="flex items-center gap-3">
                      <span className={`px-2 py-0.5 rounded text-xs font-mono font-bold ${
                        ncr.status.includes('Open') ? 'bg-red-950 text-red-300 border border-red-800' : 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                      }`}>
                        {ncr.status}
                      </span>
                      <h4 className="font-bold text-white text-base">{ncr.ncrNumber}: {ncr.materialGrade}</h4>
                    </div>
                    <div className="text-xs font-mono text-slate-400">
                      Opened: {ncr.openedDate} • Engineer: {ncr.assignedEngineer}
                    </div>
                  </div>

                  <p className="text-xs text-slate-300 font-sans">
                    <strong>Discrepancy:</strong> {ncr.description}
                  </p>

                  <div className="bg-slate-900 p-3 rounded-lg border border-slate-800 text-xs font-mono text-cyan-300">
                    <strong>CAPA Action:</strong> {ncr.capaAction}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
