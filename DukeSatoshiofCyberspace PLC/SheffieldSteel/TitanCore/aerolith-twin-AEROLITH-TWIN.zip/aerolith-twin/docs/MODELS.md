# Model governance register

Generated from `aerolith.governance.MODEL_REGISTRY` (`python docs/generate_docs.py`).

35 models. Every model records its equation, parameter source, validity range, calibration dataset, uncertainty and revision.

## `abstract_extrusion_johnson`

- **fidelity**: EMPIRICAL
- **equation**: `eps = ln R ; p = sigma (a + b ln R) ; mean strain rate = 6 v D^2 tan(alpha)/(D^2-d^2)-like abstraction (v/Lc ln R)`
- **parameter source**: registry ext.*, def.* (ILLUSTRATIVE)
- **validity range**: abstract: only reduction ratio, ram speed and billet geometry; no die/dead-zone geometry; direct extrusion
- **calibration dataset**: NONE (uncalibrated)
- **uncertainty**: see parameter registry / Monte Carlo ensemble
- **revision**: 0.1.0

## `ageing_precipitation_state`

- **fidelity**: REDUCED-ORDER
- **equation**: `KWN precipitation along the ageing thermal cycle; regime from the precipitation-strengthening trajectory`
- **parameter source**: registry precip.*, thermo.*, diff.* and age.*
- **validity range**: natural ageing 273-320 K (vacancy-assisted); artificial ageing 400-520 K; isothermal holds with linear heat-up
- **calibration dataset**: NONE (uncalibrated)
- **uncertainty**: see parameter registry / Monte Carlo ensemble
- **revision**: 0.1.0

## `anisotropy_metrics`

- **fidelity**: ANALYTICAL
- **equation**: `ratios sigma_T/sigma_L, E_T/E_L, K_TL/K_LT; planar anisotropy (s_L + s_T - 2 s_45)/(2 s_iso)`
- **parameter source**: none (derived)
- **validity range**: inherits the texture and property models
- **calibration dataset**: NONE (uncalibrated)
- **uncertainty**: see parameter registry / Monte Carlo ensemble
- **revision**: 0.1.0

## `as_cast_grain_growth_restriction`

- **fidelity**: REDUCED-ORDER
- **equation**: `Q = -sum m_i c_i (k_i - 1) ; d = (d_a + d_b/Q) / (1 + c_ref sqrt(Ti)) * (Tdot/1 K/s)^-n ; columnar = 1/(1+(GV_crit/(G/V))^2)`
- **parameter source**: registry cast.grain.* (ILLUSTRATIVE) with cast.mL.*, cast.k.*
- **validity range**: equiaxed DC/ingot-like structures; no grain-refiner fade; no fluid flow; qualitative CET
- **calibration dataset**: NONE (uncalibrated)
- **uncertainty**: see parameter registry / Monte Carlo ensemble
- **revision**: 0.1.0

## `casting_defect_population`

- **fidelity**: EMPIRICAL
- **equation**: `f_gas = eta_H (H - H_s)/100 rho T/273 ; f_shr = beta eta_s /(1+(Ny/Ny_c)^4) ; Poisson tail of lognormal size law`
- **parameter source**: registry cast.* (ILLUSTRATIVE unless calibrated)
- **validity range**: screening-level defect statistics for a reference volume; not a defect-location prediction for a specific casting
- **calibration dataset**: NONE (uncalibrated)
- **uncertainty**: see parameter registry / Monte Carlo ensemble
- **revision**: 0.1.0

## `constituent_dissolution_stationary_interface`

- **fidelity**: REDUCED-ORDER
- **equation**: `r^2 = r0^2 - 2 lambda int D dt ; f/f0 = (r/r0)^3`
- **parameter source**: registry homog.* (ILLUSTRATIVE), diff.*
- **validity range**: diffusion-limited dissolution of spherical particles of one controlling solute (Cu); stationary-interface approximation
- **calibration dataset**: NONE (uncalibrated)
- **uncertainty**: see parameter registry / Monte Carlo ensemble
- **revision**: 0.1.0

## `corrosion_susceptibility_index`

- **fidelity**: EMPIRICAL
- **equation**: `R = 1 - exp(-(w_p I_pit + w_i I_igc + w_e I_exf))`
- **parameter source**: registry corr.* (ILLUSTRATIVE)
- **validity range**: relative ranking of tempers/routes only; no environment, no coating; not validated against any corrosion test standard
- **calibration dataset**: NONE (uncalibrated)
- **uncertainty**: see parameter registry / Monte Carlo ensemble
- **revision**: 0.1.0

## `density_volume_additivity`

- **fidelity**: EMPIRICAL
- **equation**: `1/rho = sum_i (w_i/100) r_i / rho_i ; rho(T) = rho(293)/(1+3 alpha (T-293))`
- **parameter source**: pure-element densities (REFERENCE); partial-volume ratios r_i (ILLUSTRATIVE unless calibrated)
- **validity range**: solid solution / dilute alloys, 273-373 K for the room-temperature value
- **calibration dataset**: NONE (uncalibrated)
- **uncertainty**: see parameter registry / Monte Carlo ensemble
- **revision**: 0.1.0

## `eddy_current_surface`

- **fidelity**: REDUCED-ORDER
- **equation**: `delta = 1/sqrt(pi f mu0 sigma_e) ; S = (1-exp(-a/delta)) exp(-z/delta) l/(l+l0) ; POD = Phi((ln(S/N) - ln thr)/sigma_ln)`
- **parameter source**: registry ect.* (ILLUSTRATIVE)
- **validity range**: surface and near-surface flaws in non-magnetic plate; single-frequency absolute coil; no edge effects
- **calibration dataset**: NONE (uncalibrated)
- **uncertainty**: see parameter registry / Monte Carlo ensemble
- **revision**: 0.1.0

## `elastic_vrh_texture`

- **fidelity**: ANALYTICAL
- **equation**: `C_ij(c) = (1 + sum_i kE_i w_i) C_ij(Al) ; VRH average of orientation-resolved C and S over texture components`
- **parameter source**: single-crystal Al constants (handbook, verify); kE registry elastic.kE.*
- **validity range**: solid-solution scaling linear in wt% (Li < 3 wt%); precipitate stiffness contribution not separately modelled; room temperature
- **calibration dataset**: NONE (uncalibrated)
- **uncertainty**: see parameter registry / Monte Carlo ensemble
- **revision**: 0.1.0

## `fatigue_basquin_goodman_elhaddad`

- **fidelity**: EMPIRICAL
- **equation**: ``
- **parameter source**: registry fat.* (ILLUSTRATIVE); user datasets override via fit_basquin
- **validity range**: 1e4-1e8 cycles, constant amplitude, ambient air, R in [-1, 0.7]; no environment/frequency effects
- **calibration dataset**: NONE (uncalibrated)
- **uncertainty**: see parameter registry / Monte Carlo ensemble
- **revision**: 0.1.0

## `fracture_toughness_process_zone`

- **fidelity**: EMPIRICAL
- **equation**: `K_Ic = sqrt(E' m sigma_y eps_c l0) ; l0 = d_c (pi/(6 f_c))^(1/3) ; a_c = (K/(Y sigma))^2/pi ; da/dN = C dK^m`
- **parameter source**: registry frac.* (ILLUSTRATIVE); Paris C, m are UNKNOWN by default
- **validity range**: plane-strain-like toughness trends from constituent spacing and yield strength; comparative use only
- **calibration dataset**: NONE (uncalibrated)
- **uncertainty**: see parameter registry / Monte Carlo ensemble
- **revision**: 0.1.0

## `furnace_part_thermal_lag`

- **fidelity**: REDUCED-ORDER
- **equation**: `tau_f dTf/dt = Tset + dT_off - Tf ; tau_p dTp/dt = Tf - Tp ; tau_p = rho cp (H/2)/h`
- **parameter source**: registry furnace.* (ILLUSTRATIVE)
- **validity range**: air furnaces, plates up to ~0.5 m; lumped part (Bi < ~1); no load-dependent recovery
- **calibration dataset**: NONE (uncalibrated)
- **uncertainty**: see parameter registry / Monte Carlo ensemble
- **revision**: 0.1.0

## `homogenisation_cosine_mode_diffusion`

- **fidelity**: ANALYTICAL
- **equation**: `c(x,t)=sum a_n cos(n pi x/L) exp(-(n pi/L)^2 int D dt)`
- **parameter source**: registry diff.* ; lambda2 from segregation model
- **validity range**: 1-D dendrite-arm cell with no-flux boundaries; independent solutes; D from dilute lattice diffusion
- **calibration dataset**: NONE (uncalibrated)
- **uncertainty**: see parameter registry / Monte Carlo ensemble
- **revision**: 0.1.0

## `hot_flow_stress_sinh`

- **fidelity**: EMPIRICAL
- **equation**: `Z = edot exp(Q/RT); sigma = (1/alpha) asinh((Z/A)^(1/n))`
- **parameter source**: registry def.* (ILLUSTRATIVE)
- **validity range**: hot working 573-833 K; 1e-2 .. 1e2 1/s; no strain hardening/softening transient
- **calibration dataset**: NONE (uncalibrated)
- **uncertainty**: see parameter registry / Monte Carlo ensemble
- **revision**: 0.1.0

## `kwn_multiphase_precipitation`

- **fidelity**: REDUCED-ORDER
- **equation**: `see module docstring (classical nucleation + diffusion-limited growth + Gibbs-Thomson, mass balance, vacancy-enhanced D)`
- **parameter source**: registry precip.*, thermo.*, diff.* (ILLUSTRATIVE unless calibrated)
- **validity range**: 250-850 K; equivalent-sphere particles 0.2-60 nm; no shape evolution; no solute-trapping; mean-field matrix
- **calibration dataset**: NONE (uncalibrated)
- **uncertainty**: see parameter registry / Monte Carlo ensemble
- **revision**: 0.1.0

## `microsegregation_clyne_kurz`

- **fidelity**: REDUCED-ORDER
- **equation**: `Cs = k C0 [1-(1-2 a' k) fs]^((k-1)/(1-2 a' k)); a' = a(1-exp(-1/a)) - 0.5 exp(-1/(2a)); a = Ds tf / L^2`
- **parameter source**: registry cast.k.*, cast.mL.*, cast.Ce.*, diff.* (mixed LITERATURE_APPROX / ILLUSTRATIVE)
- **validity range**: dilute multicomponent alloy treated as independent binaries; no solute-solute coupling; no coarsening term; 0.05 < k < 10
- **calibration dataset**: NONE (uncalibrated)
- **uncertainty**: see parameter registry / Monte Carlo ensemble
- **revision**: 0.1.0

## `open_die_upset_forging`

- **fidelity**: EMPIRICAL
- **equation**: `eps = ln(h0/h1); p_avg = sigma (1 + mu d/(3 h)); temperature rise from plastic work`
- **parameter source**: registry forge.*, def.* (ILLUSTRATIVE)
- **validity range**: axisymmetric upset, no barrelling model, abstract multi-step schedule; no die chill
- **calibration dataset**: NONE (uncalibrated)
- **uncertainty**: see parameter registry / Monte Carlo ensemble
- **revision**: 0.1.0

## `plate_quench_conduction_elastoplastic`

- **fidelity**: REDUCED-ORDER
- **equation**: `rho cp dT/dt = d/dx(k dT/dx); -k dT/dx|s = h(Ts-Tm)(Ts-Tm); QFA: Q=int dt/Ct(T), retained = exp(k1 Q); equibiaxial elastic-perfectly-plastic stress with force balance`
- **parameter source**: registry quench.*, qfa.* (ILLUSTRATIVE); media boiling-curve shapes are illustrative
- **validity range**: symmetric flat plate quenched from both faces; no part distortion feedback; no phase-transformation strain; h depends on surface temperature only
- **calibration dataset**: NONE (uncalibrated)
- **uncertainty**: see parameter registry / Monte Carlo ensemble
- **revision**: 0.1.0

## `plate_rolling_multipass`

- **fidelity**: EMPIRICAL
- **equation**: `eps=ln(h0/h1); edot = v eps / sqrt(R dh); F = sigma_ps w Lc (1 + mu Lc/(2 h_m)); dT = eta sigma eps/(rho cp)`
- **parameter source**: registry roll.*, def.* (ILLUSTRATIVE)
- **validity range**: flat rolling of plate, plane strain, constant width, no roll flattening; reductions 5-40 % per pass
- **calibration dataset**: NONE (uncalibrated)
- **uncertainty**: see parameter registry / Monte Carlo ensemble
- **revision**: 0.1.0

## `plate_solidification_enthalpy_1d`

- **fidelity**: REDUCED-ORDER
- **equation**: `d(H)/dt = d/dx(k dT/dx); H(T)=rho cp T + rho L f_l(T); -k dT/dx|s = h (T_s - T_mould)`
- **parameter source**: registry cast.* (mixed LITERATURE_APPROX / ILLUSTRATIVE)
- **validity range**: plate/slab sections 5 mm - 500 mm; single effective interface coefficient; no convection, no mould heating
- **calibration dataset**: NONE (uncalibrated)
- **uncertainty**: see parameter registry / Monte Carlo ensemble
- **revision**: 0.1.0

## `quench_tank_energy_balance`

- **fidelity**: ANALYTICAL
- **equation**: `h_scale = (flow/flow_nom)^n ; m_t c_m dT_tank = m_p c_p (T_part_initial - T_final)`
- **parameter source**: registry qsys.* (ILLUSTRATIVE)
- **validity range**: well-mixed tank; neglects surface evaporation and refrigeration
- **calibration dataset**: NONE (uncalibrated)
- **uncertainty**: see parameter registry / Monte Carlo ensemble
- **revision**: 0.1.0

## `radiography_rose_criterion`

- **fidelity**: ANALYTICAL
- **equation**: `C = (mu_m - mu_d) t_d ; CNR = C sqrt(N_ph) ; POD = Phi((ln CNR - ln CNR_thr)/sigma)`
- **parameter source**: registry rt.* (Rose criterion REFERENCE; others ILLUSTRATIVE)
- **validity range**: monoenergetic projection radiography through plate thickness; no scatter, no geometric unsharpness model beyond pixel size
- **calibration dataset**: NONE (uncalibrated)
- **uncertainty**: see parameter registry / Monte Carlo ensemble
- **revision**: 0.1.0

## `recrystallisation_jmak_zener`

- **fidelity**: REDUCED-ORDER
- **equation**: `E=0.5 rho G b^2; E_eff=E-P_Z; t_x = t_ref (E_ref/E_eff)^p exp(Q/R(1/T-1/Tref)); X=1-exp(-(t/t_x)^n); d_Z=4r/(3f)`
- **parameter source**: registry rx.*, kocks.* (ILLUSTRATIVE), disp.*
- **validity range**: static recrystallisation of Al-Li plate; isothermal segments; no dynamic recrystallisation; no texture-dependent mobility
- **calibration dataset**: NONE (uncalibrated)
- **uncertainty**: see parameter registry / Monte Carlo ensemble
- **revision**: 0.1.0

## `rolling_mill_capacity`

- **fidelity**: ANALYTICAL
- **equation**: `dh = F / K_mill ; checks F <= F_max, P <= P_max`
- **parameter source**: registry mill.* (ILLUSTRATIVE)
- **validity range**: single stand, quasi-static; no roll thermal crown, no roll flattening
- **calibration dataset**: NONE (uncalibrated)
- **uncertainty**: see parameter registry / Monte Carlo ensemble
- **revision**: 0.1.0

## `route_cost_and_complexity`

- **fidelity**: EMPIRICAL
- **equation**: `cost = sum w_i c_i / yield + conversion + energy ; complexity = weighted count of operations, tight windows, scarce elements`
- **parameter source**: registry cost.* (ILLUSTRATIVE)
- **validity range**: screening / ranking of routes, not a quotation
- **calibration dataset**: NONE (uncalibrated)
- **uncertainty**: see parameter registry / Monte Carlo ensemble
- **revision**: 0.1.0

## `solubility_product_equilibrium`

- **fidelity**: REDUCED-ORDER
- **equation**: `prod_s x_s^e_ps = K0_p exp(-Q_p/RT); c_s (1 - sum phi) + sum_p phi_p s_ps = c0_s`
- **parameter source**: registry thermo.* (ILLUSTRATIVE unless calibrated)
- **validity range**: dilute Al-rich matrix (solute < ~10 at%); 250-850 K; metastable phases treated as equilibrium phases
- **calibration dataset**: NONE (uncalibrated)
- **uncertainty**: see parameter registry / Monte Carlo ensemble
- **revision**: 0.1.0

## `solute_diffusion_arrhenius`

- **fidelity**: ANALYTICAL
- **equation**: `D(T) = D0 exp(-Q/(R T)); sinusoidal/cosine-mode decay exp(-(n pi/L)^2 int D dt)`
- **parameter source**: registry diff.* (mixed LITERATURE_APPROX / ILLUSTRATIVE)
- **validity range**: dilute solutes in Al, 600-850 K; lattice diffusion only (no pipe/boundary diffusion, no vacancy excess)
- **calibration dataset**: NONE (uncalibrated)
- **uncertainty**: see parameter registry / Monte Carlo ensemble
- **revision**: 0.1.0

## `solution_treatment`

- **fidelity**: REDUCED-ORDER
- **equation**: `constituent dissolution (stationary interface) + KWN dissolution of nano-precipitates + Zener-limited JMAK recrystallisation`
- **parameter source**: inherits from the underlying models
- **validity range**: isothermal hold 700-850 K after a linear ramp; part temperature equals furnace set-point (see furnace model for lag)
- **calibration dataset**: NONE (uncalibrated)
- **uncertainty**: see parameter registry / Monte Carlo ensemble
- **revision**: 0.1.0

## `texture_component_evolution`

- **fidelity**: EMPIRICAL
- **equation**: `w_def += (S(eps+d eps)-S(eps)) (target - w) ; S = Smax(1-exp(-eps/eps0)); recrystallisation moves X of the mass to Cube/Goss/Random`
- **parameter source**: registry tex.* (ILLUSTRATIVE)
- **validity range**: qualitative trends for rolled / extruded Al alloys; component set {Cube,Goss,Brass,S,Copper,Fibre<111>,Fibre<100>,Random}
- **calibration dataset**: NONE (uncalibrated)
- **uncertainty**: see parameter registry / Monte Carlo ensemble
- **revision**: 0.1.0

## `transport_matthiessen_wiedemann_franz`

- **fidelity**: EMPIRICAL
- **equation**: `rho_e = rho0 + sum k_i w_i,matrix + k_p f ; kappa = L T / rho_e + kappa_ph`
- **parameter source**: registry th.* (LITERATURE_APPROX / ILLUSTRATIVE)
- **validity range**: dilute solid solutions near 293 K; additive resistivity contributions; no texture dependence
- **calibration dataset**: NONE (uncalibrated)
- **uncertainty**: see parameter registry / Monte Carlo ensemble
- **revision**: 0.1.0

## `ultrasonic_pulse_echo`

- **fidelity**: REDUCED-ORDER
- **equation**: `alpha = smooth_min(aR f^4 d^3, aS f^2 d, aG/d) + alpha_abs ; S = (pi a_eq^2/(lambda z)) exp(-2 alpha z) cos^2(theta) ; POD = Phi((20log10(S/N) - thr)/sigma)`
- **parameter source**: registry us.* (ILLUSTRATIVE; requires NDT procedure qualification)
- **validity range**: normal-incidence longitudinal waves, 1-15 MHz, far-field disc-reflector response; no focused beams or phased arrays
- **calibration dataset**: NONE (uncalibrated)
- **uncertainty**: see parameter registry / Monte Carlo ensemble
- **revision**: 0.1.0

## `virtual_metallography`

- **fidelity**: ANALYTICAL
- **equation**: `L_meas = L (1+b)(1 + cv/sqrt(N) xi) ; r_meas = r (1+b)(1 + cv/sqrt(N) xi)`
- **parameter source**: registry mic.* (ILLUSTRATIVE)
- **validity range**: mean-lineal-intercept and TEM particle sizing; Gaussian counting error; independent fields
- **calibration dataset**: NONE (uncalibrated)
- **uncertainty**: see parameter registry / Monte Carlo ensemble
- **revision**: 0.1.0

## `yield_strength_mechanism_sum`

- **fidelity**: REDUCED-ORDER
- **equation**: `Yield strength built from separately modelled mechanisms; UTS and elongation from a Voce/Considere model.`
- **parameter source**: registry str.* (ILLUSTRATIVE/LITERATURE_APPROX); microstructure state from the process chain
- **validity range**: age-hardened Al-Li-Cu alloys, room temperature, quasi-static; precipitate strengthening from mean radius per phase; no PFZ model
- **calibration dataset**: NONE (uncalibrated)
- **uncertainty**: see parameter registry / Monte Carlo ensemble
- **revision**: 0.1.0

## `zener_pinning`

- **fidelity**: ANALYTICAL
- **equation**: `P_Z = 1.5 gamma_gb f / r ; d_Z = 4 r / (3 f)`
- **parameter source**: registry disp.*
- **validity range**: spherical, incoherent-to-coherent hard particles; f < 0.05; random distribution
- **calibration dataset**: NONE (uncalibrated)
- **uncertainty**: see parameter registry / Monte Carlo ensemble
- **revision**: 0.1.0
