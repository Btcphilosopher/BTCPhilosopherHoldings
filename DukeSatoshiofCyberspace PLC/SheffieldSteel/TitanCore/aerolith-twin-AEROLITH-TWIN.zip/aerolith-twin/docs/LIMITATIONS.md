# Limitations and intended use

AEROLITH-TWIN is a **research, engineering-development and manufacturing digital twin**. It is **not** a substitute for certified materials
qualification, metallurgical laboratory testing, aerospace standards compliance, destructive testing, NDT qualification, production
process qualification, finite-element certification or airworthiness approval. The qualification module screens against a user-supplied
envelope and always reports `NOT QUALIFIED`.

## State of the shipped parameters
No validated Al-Li dataset ships with the code. 273 of the 356 default parameters are **ILLUSTRATIVE** placeholders chosen to give plausible
trends (e.g. quench C-curve, nucleation prefactors, strengthening efficiencies, NDT POD curves); 58 are LITERATURE_APPROX values to verify;
6 are UNKNOWN (Sc liquidus slope and partition coefficient, Paris C and m, Coffin–Manson parameters). Consequences:
* simulated numbers show **mechanisms and trends**, not predictions of a specific alloy or plant until calibrated;
* the uncertainty bands of an uncalibrated run are dominated by the placeholder widths of these parameters;
* `--strict` makes that explicit by refusing to run.

## Model limits (see `docs/MODELS.md` for each model's validity range)
* casting is a 1-D reduced-order plate model with one effective interface coefficient (no flow, no 3-D, no mould heating); no CALPHAD database is bundled — solidus, partition coefficients and eutectic compositions are registry parameters;
* microsegregation treats solutes as independent binaries; macrosegregation is only a screening count;
* precipitation uses equivalent-sphere radii (plate-shaped T1/θ′ shape evolution and Al-Li-Cu coupling beyond the shared solute pools are not resolved); δ′/T1/θ′/Al3Zr/Al3Sc only — S′, η′, Ω, GP zones and Al3(Sc,Zr) core–shell are not modelled;
* recrystallisation is static, JMAK-type, with Zener limits; no dynamic recrystallisation, no texture-dependent mobility;
* texture is a component-weight ODF (Cube, Goss, Brass, S, Copper, two fibres, random), not a measured ODF;
* residual stress is a through-thickness equibiaxial elastic–perfectly-plastic model (no bending, no 3-D, no machining redistribution);
* fatigue and fracture are empirical/process-zone trend models; da/dN and ε–N need datasets; corrosion is a comparative index only;
* NDT models use far-field disc-reflector UT, absolute-coil ECT and photon-limited RT; POD parameters need procedure qualification;
* defects above a reporting threshold are enumerated; the sub-threshold bulk is carried as statistics.
