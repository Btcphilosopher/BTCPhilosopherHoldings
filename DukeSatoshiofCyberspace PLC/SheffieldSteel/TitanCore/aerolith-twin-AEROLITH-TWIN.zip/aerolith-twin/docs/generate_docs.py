"""Generate docs/MODELS.md and docs/PARAMETERS.md and models/parameters_default.yaml from the live registries."""
from __future__ import annotations

from pathlib import Path

from aerolith.governance import MODEL_REGISTRY
from aerolith.params import default_registry

root = Path(__file__).resolve().parents[1]
reg = default_registry()
reg.to_yaml(root / "models" / "parameters_default.yaml")

lines = ["# Model governance register", "", "Generated from `aerolith.governance.MODEL_REGISTRY` (`python docs/generate_docs.py`).", "",
         f"{len(MODEL_REGISTRY)} models. Every model records its equation, parameter source, validity range, calibration dataset, uncertainty and revision.", ""]
for name, m in sorted(MODEL_REGISTRY.items()):
    lines += [f"## `{name}`", "", f"- **fidelity**: {m.fidelity}", f"- **equation**: `{m.equation}`", f"- **parameter source**: {m.parameter_source}",
              f"- **validity range**: {m.validity_range}", f"- **calibration dataset**: {m.calibration_dataset}", f"- **uncertainty**: {m.uncertainty}",
              f"- **revision**: {m.revision}", ""]
(root / "docs" / "MODELS.md").write_text("\n".join(lines))

counts = reg.status_counts()
lines = ["# Parameter register", "", f"Parameter version `{reg.version()}`.  Status counts: {counts}.", "",
         "| status | meaning |", "|---|---|",
         "| REFERENCE | physical constant / handbook value of a pure element |", "| LITERATURE_APPROX | widely quoted value; verify before relying on it |",
         "| ILLUSTRATIVE | placeholder that lets the model run; **not a validated material value** |", "| CALIBRATED | fitted to a named dataset |",
         "| USER_SUPPLIED | supplied by the user |", "| UNKNOWN | no value exists; models that need it refuse to run |", "",
         "Uncertainty is 1-sigma (absolute, or on ln(value) for log-scale parameters).  Uncertainties of ILLUSTRATIVE parameters are placeholder prior widths.", "",
         "| parameter | value | units | status | 1σ | valid range | note |", "|---|---|---|---|---|---|---|"]
for n in reg.names():
    p = reg.get(n)
    rng = "" if p.valid_min is None and p.valid_max is None else f"{p.valid_min:g} … {p.valid_max:g}" if p.valid_min is not None and p.valid_max is not None else ""
    v = "**UNKNOWN**" if p.value is None else f"{p.value:.4g}"
    lines.append(f"| `{n}`{' (log)' if p.log_scale else ''} | {v} | {p.units} | {p.status.value} | {p.uncertainty:g} | {rng} | {p.source.replace('|', '/')[:90]} |")
(root / "docs" / "PARAMETERS.md").write_text("\n".join(lines))
print(f"{len(MODEL_REGISTRY)} models, {len(reg.names())} parameters documented")
