# User guide

## Install and test
```bash
pip install -e .[dev]
pytest                                   # 58 tests incl. analytical validation
python validation/run_validation.py      # independent validation report -> validation/output/
python docs/generate_docs.py             # regenerates MODELS.md / PARAMETERS.md / models/parameters_default.yaml
```

## Python API
```python
from aerolith.chemistry.composition import Composition
from aerolith.manufacturing.spec import RouteSpec
from aerolith.digital_twin.twin import AerolithTwin

comp = Composition(Li=1.0, Cu=4.0, Mg=0.4, Ag=0.4, Zr=0.12)   # Al = balance; sum checked to ±0.05 wt% (configurable)
run = AerolithTwin().run(comp, RouteSpec(), n_ensemble=24)       # chain + sensors + NDT + estimation + uncertainty
run.true_state.chain.properties.q["yield_strength"]              # Quantity(value, unit, sigma, provenance)
```

## CLI
| command | input | does |
|---|---|---|
| `aerolith simulate alloy.yaml` | composition (+route) | melt, casting, homogenisation |
| `aerolith process process.yaml` | composition + route | … through thermomechanical processing |
| `aerolith heat-treatment recipe.yaml` | composition + route | … solution, quench, stretch, ageing, properties |
| `aerolith predict sample.yaml [-n 24] [--fast]` | sample | full chain + Monte Carlo uncertainty by source |
| `aerolith calibrate dataset.parquet --fit str.k_y …` | experiments | bounded least squares with held-out validation; writes `calibrated_parameters.yaml` |
| `aerolith optimise objective.yaml` | objectives, constraints, bounds | NSGA-II over composition + route; writes the Pareto set |
| `aerolith inspect batch.yaml` | batch | simulated UT/ECT/RT, POD, missed-defect bookkeeping |
| `aerolith report batch.yaml` | batch | everything + HDF5/Parquet/JSON/CSV + `report.html` |

Common flags: `--outdir`, `--params calibrated_parameters.yaml`, `--strict` (refuse ILLUSTRATIVE/UNKNOWN parameters).

## Input YAML
See `examples/aerospace_panel/sample.yaml` (all temperatures in °C, times in h/min/s, lengths in mm — converted once to SI).
`objective.yaml`:
```yaml
objectives: [specific_strength, fracture_toughness, cost_usd_kg]   # directions come from the objective table (max/min)
constraints: [{output: yield_strength, minimum: 420}]
bounds: {Li: [0.8, 2.4], ageing_T_C: [150, 185]}
population: 16
generations: 6
```
Available objectives: specific_strength, specific_modulus, fracture_toughness, fatigue_strength_1e7, density, corrosion_index, complexity, cost_usd_kg.

## Supplying real data
* Replace UNKNOWN/ILLUSTRATIVE values: `registry.override(name, value, Status.USER_SUPPLIED, uncertainty=…, source="…")` or edit a copy of `models/parameters_default.yaml` and pass `--params`.
* Experiments follow `experiments/SCHEMA.md`; `validation/compare_experiment.py` draws MODEL vs EXPERIMENT with uncertainty bands.
* Fatigue data override Basquin: `properties.fatigue.fit_basquin`. Paris/Coffin–Manson parameters unlock da/dN and ε–N.

## Reading results
Every result file carries `model_version`, `parameter_version`, `simulation_timestamp`, `input_hash`, `dataset_version`, `units`, `uncertainty`
(HDF5 attributes, Parquet schema metadata, JSON `metadata`). Properties carry `provenance`; a pure simulation has no MEASURED values.
