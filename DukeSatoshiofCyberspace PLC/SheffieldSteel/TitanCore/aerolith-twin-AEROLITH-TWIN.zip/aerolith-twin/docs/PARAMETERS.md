# Parameter register

Parameter version `AEROLITH-PARAMS-0.1.0+3815d38192`.  Status counts: {'ILLUSTRATIVE': 273, 'LITERATURE_APPROX': 58, 'REFERENCE': 19, 'UNKNOWN': 6}.

| status | meaning |
|---|---|
| REFERENCE | physical constant / handbook value of a pure element |
| LITERATURE_APPROX | widely quoted value; verify before relying on it |
| ILLUSTRATIVE | placeholder that lets the model run; **not a validated material value** |
| CALIBRATED | fitted to a named dataset |
| USER_SUPPLIED | supplied by the user |
| UNKNOWN | no value exists; models that need it refuse to run |

Uncertainty is 1-sigma (absolute, or on ln(value) for log-scale parameters).  Uncertainties of ILLUSTRATIVE parameters are placeholder prior widths.

| parameter | value | units | status | 1σ | valid range | note |
|---|---|---|---|---|---|---|
| `age.overage_gb` | 0.25 | - | ILLUSTRATIVE | 0.4 | 0 … 2 | grain-boundary precipitate coverage gained per unit of over-ageing (t/t_peak - 1) |
| `age.peak_tol` | 0.03 | - | REFERENCE | 0 |  | strength within this fraction of the sweep maximum is classed 'peak-aged' |
| `aniso.note` | 0 | - | REFERENCE | 0 |  | no free parameters: metrics are ratios of directional model outputs |
| `cast.Ce.Ag` | 69 | wt% | ILLUSTRATIVE | 5 | 1 … 95 | binary eutectic composition |
| `cast.Ce.Cu` | 33 | wt% | LITERATURE_APPROX | 2 | 1 … 60 | Al-Cu eutectic composition (binary) |
| `cast.Ce.Fe` | 1.8 | wt% | LITERATURE_APPROX | 0.3 | 0.5 … 20 | Al-Fe eutectic composition (binary) |
| `cast.Ce.Li` | 9.9 | wt% | ILLUSTRATIVE | 2 | 1 … 40 | terminal liquid composition used for eutectic cut-off |
| `cast.Ce.Mg` | 35 | wt% | LITERATURE_APPROX | 3 | 1 … 60 | Al-Mg eutectic composition (binary) |
| `cast.Ce.Mn` | 1.9 | wt% | ILLUSTRATIVE | 0.5 | 0.5 … 20 | terminal liquid composition |
| `cast.Ce.Si` | 12.6 | wt% | LITERATURE_APPROX | 0.8 | 1 … 40 | Al-Si eutectic composition (binary) |
| `cast.Ce.Zn` | 95 | wt% | ILLUSTRATIVE | 3 | 1 … 99 | effectively no eutectic cut-off in dilute range |
| `cast.H_pore_efficiency` (log) | 0.05 | - | ILLUSTRATIVE | 0.5 | 0.001 … 1 | fraction of rejected H forming pore volume (nucleation-limited) |
| `cast.H_solid_solubility` | 0.036 | mL STP/100 g | LITERATURE_APPROX | 0.01 | 0.005 … 0.2 | hydrogen solubility in solid Al near the solidus; Li/Mg melts pick up more H |
| `cast.T_eutectic` | 773 | K | ILLUSTRATIVE | 15 | 650 … 900 | effective non-equilibrium solidus used by the thermal solver; replace with CALPHAD Scheil  |
| `cast.T_melt_Al` | 933.5 | K | REFERENCE | 0.1 |  | melting point of pure Al |
| `cast.cp` | 1050 | J/kg/K | LITERATURE_APPROX | 80 | 800 … 1400 | Handbook-order value for Al alloys; verify against measured alloy data |
| `cast.grain.GV_crit` (log) | 3e+05 | K s/m2 | ILLUSTRATIVE | 0.5 | 1000 … 1e+08 | G/V above which columnar growth dominates (CET) |
| `cast.grain.d_a` (log) | 6e-05 | m | ILLUSTRATIVE | 0.3 | 1e-05 … 0.001 | d = d_a + d_b/Q + refiner term; placeholder |
| `cast.grain.d_b` (log) | 0.003 | m K | ILLUSTRATIVE | 0.3 | 0.0001 … 0.1 | d = d_a + d_b/Q; placeholder |
| `cast.grain.rate_exp` | 0.15 | - | ILLUSTRATIVE | 0.05 | 0 … 0.5 | d ~ Tdot^-n around 1 K/s |
| `cast.grain.sigma_ln` | 0.45 | - | ILLUSTRATIVE | 0.08 | 0.1 … 1 | log-std of equiaxed grain-size distribution |
| `cast.grain.ti_refine` (log) | 6 | 1/wt%^0.5 | ILLUSTRATIVE | 0.4 | 0 … 50 | grain-refiner (Ti/B) efficiency |
| `cast.h_interface` (log) | 1500 | W/m2/K | ILLUSTRATIVE | 0.3 | 50 … 100000 | effective DC-casting-like interface coefficient; calibrate |
| `cast.hot_tear_crit` | 1.5 | - | ILLUSTRATIVE | 0.1 | 0.05 … 2 | Clyne-Davies CSC above which hot tears are generated |
| `cast.hot_tear_rate` (log) | 6 | 1/m3 per unit CSC excess | ILLUSTRATIVE | 0.6 | 0 … 10000 | hot-tear count per m3 |
| `cast.inclusion_d50` (log) | 0.00015 | m | ILLUSTRATIVE | 0.3 | 1e-05 … 0.002 | median inclusion size |
| `cast.k.Ag` | 0.5 | - | ILLUSTRATIVE | 0.15 | 0.05 … 3 | Engineering placeholder; calibrate to casting trials |
| `cast.k.Cu` | 0.17 | - | LITERATURE_APPROX | 0.03 | 0.05 … 3 | Handbook-order value for Al alloys; verify against measured alloy data |
| `cast.k.Fe` | 0.03 | - | LITERATURE_APPROX | 0.01 | 0.005 … 3 | Handbook-order value for Al alloys; verify against measured alloy data |
| `cast.k.Li` | 0.5 | - | ILLUSTRATIVE | 0.1 | 0.05 … 3 | Engineering placeholder; calibrate to casting trials |
| `cast.k.Mg` | 0.51 | - | LITERATURE_APPROX | 0.08 | 0.05 … 3 | Handbook-order value for Al alloys; verify against measured alloy data |
| `cast.k.Mn` | 0.9 | - | ILLUSTRATIVE | 0.1 | 0.05 … 3 | Engineering placeholder; calibrate to casting trials |
| `cast.k.Sc` | **UNKNOWN** | - | UNKNOWN | 0 |  | supply a validated Al-Sc partition coefficient |
| `cast.k.Si` | 0.12 | - | LITERATURE_APPROX | 0.03 | 0.05 … 3 | Handbook-order value for Al alloys; verify against measured alloy data |
| `cast.k.Ti` | 7 | - | ILLUSTRATIVE | 2 | 1 … 20 | peritectic partitioning k>>1 |
| `cast.k.Zn` | 0.4 | - | LITERATURE_APPROX | 0.08 | 0.05 … 3 | Handbook-order value for Al alloys; verify against measured alloy data |
| `cast.k.Zr` | 2.5 | - | ILLUSTRATIVE | 0.5 | 1 … 10 | peritectic partitioning k>1 |
| `cast.k_liquid` | 80 | W/m/K | ILLUSTRATIVE | 15 | 30 … 200 | Engineering placeholder; calibrate to casting trials |
| `cast.k_solid` | 110 | W/m/K | ILLUSTRATIVE | 15 | 40 … 240 | Al-Li-Cu alloys are poorer conductors than pure Al; value is a placeholder |
| `cast.latent_heat` | 3.7e+05 | J/kg | LITERATURE_APPROX | 20000 | 250000 … 420000 | pure Al ~397 kJ/kg; alloys lower |
| `cast.mL.Ag` | 2 | K/wt% | ILLUSTRATIVE | 1 | -10 … 20 | Engineering placeholder; calibrate to casting trials |
| `cast.mL.Cu` | 3.4 | K/wt% | LITERATURE_APPROX | 0.4 | -10 … 20 | Handbook-order value for Al alloys; verify against measured alloy data |
| `cast.mL.Fe` | 3 | K/wt% | ILLUSTRATIVE | 1 | -10 … 20 | Engineering placeholder; calibrate to casting trials |
| `cast.mL.Li` | 5.5 | K/wt% | ILLUSTRATIVE | 1.5 | -10 … 20 | Engineering placeholder; calibrate to casting trials |
| `cast.mL.Mg` | 6 | K/wt% | LITERATURE_APPROX | 0.6 | -10 … 20 | Handbook-order value for Al alloys; verify against measured alloy data |
| `cast.mL.Mn` | 2 | K/wt% | ILLUSTRATIVE | 1 | -10 … 20 | Engineering placeholder; calibrate to casting trials |
| `cast.mL.Sc` | **UNKNOWN** | K/wt% | UNKNOWN | 0 |  | supply a validated Al-Sc liquidus slope |
| `cast.mL.Si` | 6.6 | K/wt% | LITERATURE_APPROX | 0.7 | -10 … 20 | Handbook-order value for Al alloys; verify against measured alloy data |
| `cast.mL.Ti` | -30 | K/wt% | ILLUSTRATIVE | 10 | -80 … 20 | peritectic: liquidus rises steeply |
| `cast.mL.Zn` | 1.6 | K/wt% | LITERATURE_APPROX | 0.4 | -10 … 20 | Handbook-order value for Al alloys; verify against measured alloy data |
| `cast.mL.Zr` | -4 | K/wt% | ILLUSTRATIVE | 3 | -60 … 20 | peritectic: liquidus rises |
| `cast.niyama_crit` (log) | 1 | (K s)^0.5/mm | ILLUSTRATIVE | 0.4 | 0.1 … 5 | Niyama threshold for feeding-limited shrinkage porosity |
| `cast.oxide_rate` (log) | 800 | 1/m3 | ILLUSTRATIVE | 0.6 | 0 … 1e+06 | large oxide-film/inclusion count per m3 of nominal melt |
| `cast.pore_d_factor` (log) | 0.6 | - | ILLUSTRATIVE | 0.3 | 0.1 … 5 | median pore diameter / lambda2 |
| `cast.pore_report_size` | 0.0004 | m | ILLUSTRATIVE | 0 |  | individual-reporting threshold for pores |
| `cast.pore_sigma_ln` | 0.45 | - | ILLUSTRATIVE | 0.1 | 0.2 … 1.5 | log-std of pore diameter |
| `cast.sdas_A` (log) | 5e-05 | m K^(1/3) s^(-1/3) | ILLUSTRATIVE | 0.25 | 5e-06 … 0.0005 | lambda2 = A * Tdot^(-n); calibrate to metallography |
| `cast.sdas_n` | 0.3333 | - | LITERATURE_APPROX | 0.04 | 0.2 … 0.5 | classical coarsening exponent for secondary arm spacing |
| `cast.seg_zone_rate` (log) | 0.3 | 1/m3 per unit (index-1) | ILLUSTRATIVE | 0.6 | 0 … 100 | macro-segregation zones per m3 |
| `cast.shrink_efficiency` (log) | 0.04 | - | ILLUSTRATIVE | 0.5 | 0.001 … 1 | fraction of solidification shrinkage appearing as distributed porosity when feeding fails |
| `cast.shrinkage_beta` | 0.065 | - | LITERATURE_APPROX | 0.01 | 0.03 … 0.09 | solidification shrinkage of Al ~6-7 % |
| `corr.const_ref` | 0.005 | - | ILLUSTRATIVE | 0 |  | constituent volume fraction giving unit pitting driver |
| `corr.cu_ref` | 4 | wt% | ILLUSTRATIVE | 0 |  | Cu in solution giving unit galvanic driver |
| `corr.li_igc` | 0.25 | 1/wt% | ILLUSTRATIVE | 0.1 | 0 … 2 | Li-bearing grain-boundary phase contribution per wt% Li |
| `corr.w_exf` | 0.8 | - | ILLUSTRATIVE | 0.3 | 0 … 10 | weight of exfoliation driver |
| `corr.w_igc` | 1.5 | - | ILLUSTRATIVE | 0.4 | 0 … 10 | weight of intergranular driver |
| `corr.w_pit` | 1 | - | ILLUSTRATIVE | 0.3 | 0 … 10 | weight of galvanic/pitting driver |
| `cost.conversion_base` | 2.5 | USD/kg | ILLUSTRATIVE | 0.3 | 0 … 100 | casting + rolling conversion cost excluding furnace energy |
| `cost.element.Ag` | 900 | USD/kg | ILLUSTRATIVE | 0.3 | 0 … 100000 | market-dependent placeholder; replace with contract prices |
| `cost.element.Al` | 3 | USD/kg | ILLUSTRATIVE | 0.3 | 0 … 100000 | market-dependent placeholder; replace with contract prices |
| `cost.element.Cu` | 9 | USD/kg | ILLUSTRATIVE | 0.3 | 0 … 100000 | market-dependent placeholder; replace with contract prices |
| `cost.element.Fe` | 0.2 | USD/kg | ILLUSTRATIVE | 0.3 | 0 … 100000 | market-dependent placeholder; replace with contract prices |
| `cost.element.Li` | 90 | USD/kg | ILLUSTRATIVE | 0.3 | 0 … 100000 | market-dependent placeholder; replace with contract prices |
| `cost.element.Mg` | 3.5 | USD/kg | ILLUSTRATIVE | 0.3 | 0 … 100000 | market-dependent placeholder; replace with contract prices |
| `cost.element.Mn` | 2.5 | USD/kg | ILLUSTRATIVE | 0.3 | 0 … 100000 | market-dependent placeholder; replace with contract prices |
| `cost.element.Sc` | 3500 | USD/kg | ILLUSTRATIVE | 0.3 | 0 … 100000 | market-dependent placeholder; replace with contract prices |
| `cost.element.Si` | 2.5 | USD/kg | ILLUSTRATIVE | 0.3 | 0 … 100000 | market-dependent placeholder; replace with contract prices |
| `cost.element.Ti` | 14 | USD/kg | ILLUSTRATIVE | 0.3 | 0 … 100000 | market-dependent placeholder; replace with contract prices |
| `cost.element.Zn` | 3 | USD/kg | ILLUSTRATIVE | 0.3 | 0 … 100000 | market-dependent placeholder; replace with contract prices |
| `cost.element.Zr` | 45 | USD/kg | ILLUSTRATIVE | 0.3 | 0 … 100000 | market-dependent placeholder; replace with contract prices |
| `cost.energy` | 0.12 | USD/kWh | ILLUSTRATIVE | 0.3 | 0 … 2 | energy price |
| `cost.furnace_loss_kw` | 25 | kW | ILLUSTRATIVE | 0.3 | 1 … 5000 | furnace holding loss (average) |
| `cost.melt_yield` | 0.88 | - | ILLUSTRATIVE | 0.03 | 0.5 … 1 | casting/scalping/trim yield from melt to plate |
| `cost.stretch` | 0.25 | USD/kg | ILLUSTRATIVE | 0.3 | 0 … 10 | stretching operation |
| `def.Q` | 1.56e+05 | J/mol | ILLUSTRATIVE | 15000 | 100000 … 300000 | Placeholder typical of hot-working Al alloys; calibrate to hot-compression/rolling-force d |
| `def.alpha` | 0.015 | 1/MPa | ILLUSTRATIVE | 0.002 | 0.003 … 0.05 | Placeholder typical of hot-working Al alloys; calibrate to hot-compression/rolling-force d |
| `def.cp` | 1050 | J/kg/K | LITERATURE_APPROX | 80 | 800 … 1400 | specific heat of Al alloys |
| `def.heat_fraction` | 0.9 | - | LITERATURE_APPROX | 0.05 | 0.5 … 1 | fraction of plastic work converted to heat (Taylor-Quinney) |
| `def.lnA` | 27.63 | - | ILLUSTRATIVE | 1 | 10 … 50 | Placeholder typical of hot-working Al alloys; calibrate to hot-compression/rolling-force d |
| `def.n` | 5 | - | ILLUSTRATIVE | 0.5 | 2 … 12 | Placeholder typical of hot-working Al alloys; calibrate to hot-compression/rolling-force d |
| `density.alpha_lin` | 2.3e-05 | 1/K | LITERATURE_APPROX | 1.5e-06 | 1e-05 … 4e-05 | linear CTE of Al alloys near room temperature |
| `density.vratio.Ag` | 1 | - | ILLUSTRATIVE | 0.03 | 0.5 … 1.3 | Ideal volume additivity assumed; calibrate against measured density |
| `density.vratio.Cu` | 1 | - | ILLUSTRATIVE | 0.03 | 0.5 … 1.3 | Ideal volume additivity assumed; calibrate against measured density |
| `density.vratio.Fe` | 1 | - | ILLUSTRATIVE | 0.03 | 0.5 … 1.3 | Ideal volume additivity assumed; calibrate against measured density |
| `density.vratio.Li` | 0.81 | - | ILLUSTRATIVE | 0.04 | 0.5 … 1.3 | chosen to reproduce ~3%/wt% density reduction per wt% Li |
| `density.vratio.Mg` | 1 | - | ILLUSTRATIVE | 0.03 | 0.5 … 1.3 | Ideal volume additivity assumed; calibrate against measured density |
| `density.vratio.Mn` | 1 | - | ILLUSTRATIVE | 0.03 | 0.5 … 1.3 | Ideal volume additivity assumed; calibrate against measured density |
| `density.vratio.Sc` | 1 | - | ILLUSTRATIVE | 0.03 | 0.5 … 1.3 | Ideal volume additivity assumed; calibrate against measured density |
| `density.vratio.Si` | 1 | - | ILLUSTRATIVE | 0.03 | 0.5 … 1.3 | Ideal volume additivity assumed; calibrate against measured density |
| `density.vratio.Ti` | 1 | - | ILLUSTRATIVE | 0.03 | 0.5 … 1.3 | Ideal volume additivity assumed; calibrate against measured density |
| `density.vratio.Zn` | 1 | - | ILLUSTRATIVE | 0.03 | 0.5 … 1.3 | Ideal volume additivity assumed; calibrate against measured density |
| `density.vratio.Zr` | 1 | - | ILLUSTRATIVE | 0.03 | 0.5 … 1.3 | Ideal volume additivity assumed; calibrate against measured density |
| `diff.Ag.D0` (log) | 0.000118 | m2/s | LITERATURE_APPROX | 0.4 | 1e-09 … 0.01 | Commonly quoted tracer/impurity diffusion values for Al; verify against your reference bef |
| `diff.Ag.Q` | 1.24e+05 | J/mol | LITERATURE_APPROX | 5000 | 50000 … 300000 | Commonly quoted tracer/impurity diffusion values for Al; verify against your reference bef |
| `diff.Cu.D0` (log) | 6.5e-05 | m2/s | LITERATURE_APPROX | 0.4 | 1e-09 … 0.01 | Commonly quoted tracer/impurity diffusion values for Al; verify against your reference bef |
| `diff.Cu.Q` | 1.36e+05 | J/mol | LITERATURE_APPROX | 2000 | 50000 … 300000 | Commonly quoted tracer/impurity diffusion values for Al; verify against your reference bef |
| `diff.Fe.D0` (log) | 0.0053 | m2/s | ILLUSTRATIVE | 0.8 | 1e-09 … 0.1 | Order-of-magnitude placeholder; replace with measured/assessed value |
| `diff.Fe.Q` | 1.85e+05 | J/mol | ILLUSTRATIVE | 15000 | 100000 … 400000 | Order-of-magnitude placeholder; replace with measured/assessed value |
| `diff.Li.D0` (log) | 4.5e-06 | m2/s | ILLUSTRATIVE | 0.7 | 1e-09 … 0.01 | Order-of-magnitude placeholder; replace with measured/assessed value |
| `diff.Li.Q` | 1.35e+05 | J/mol | ILLUSTRATIVE | 10000 | 50000 … 300000 | Order-of-magnitude placeholder; replace with measured/assessed value |
| `diff.Mg.D0` (log) | 0.000124 | m2/s | LITERATURE_APPROX | 0.4 | 1e-09 … 0.01 | Commonly quoted tracer/impurity diffusion values for Al; verify against your reference bef |
| `diff.Mg.Q` | 1.31e+05 | J/mol | LITERATURE_APPROX | 5000 | 50000 … 300000 | Commonly quoted tracer/impurity diffusion values for Al; verify against your reference bef |
| `diff.Mn.D0` (log) | 0.000135 | m2/s | ILLUSTRATIVE | 0.8 | 1e-09 … 0.1 | Order-of-magnitude placeholder; replace with measured/assessed value |
| `diff.Mn.Q` | 2e+05 | J/mol | ILLUSTRATIVE | 15000 | 100000 … 400000 | Order-of-magnitude placeholder; replace with measured/assessed value |
| `diff.Sc.D0` (log) | 0.000531 | m2/s | LITERATURE_APPROX | 0.6 | 1e-09 … 0.1 | Commonly quoted tracer/impurity diffusion values for Al; verify against your reference bef |
| `diff.Sc.Q` | 1.73e+05 | J/mol | LITERATURE_APPROX | 8000 | 100000 … 400000 | Commonly quoted tracer/impurity diffusion values for Al; verify against your reference bef |
| `diff.Si.D0` (log) | 0.000202 | m2/s | ILLUSTRATIVE | 0.6 | 1e-09 … 0.1 | Order-of-magnitude placeholder; replace with measured/assessed value |
| `diff.Si.Q` | 1.36e+05 | J/mol | ILLUSTRATIVE | 10000 | 50000 … 300000 | Order-of-magnitude placeholder; replace with measured/assessed value |
| `diff.Ti.D0` (log) | 0.112 | m2/s | ILLUSTRATIVE | 1 | 1e-09 … 100 | Order-of-magnitude placeholder; replace with measured/assessed value |
| `diff.Ti.Q` | 2.6e+05 | J/mol | ILLUSTRATIVE | 20000 | 100000 … 400000 | Order-of-magnitude placeholder; replace with measured/assessed value |
| `diff.Zn.D0` (log) | 2.59e-05 | m2/s | LITERATURE_APPROX | 0.4 | 1e-09 … 0.01 | Commonly quoted tracer/impurity diffusion values for Al; verify against your reference bef |
| `diff.Zn.Q` | 1.21e+05 | J/mol | LITERATURE_APPROX | 5000 | 50000 … 300000 | Commonly quoted tracer/impurity diffusion values for Al; verify against your reference bef |
| `diff.Zr.D0` (log) | 0.0728 | m2/s | LITERATURE_APPROX | 0.8 | 1e-09 … 100 | Commonly quoted tracer/impurity diffusion values for Al; verify against your reference bef |
| `diff.Zr.Q` | 2.42e+05 | J/mol | LITERATURE_APPROX | 10000 | 100000 … 400000 | Commonly quoted tracer/impurity diffusion values for Al; verify against your reference bef |
| `disp.gamma_gb` | 0.32 | J/m2 | LITERATURE_APPROX | 0.06 | 0.1 … 0.6 | high-angle grain boundary energy of Al (order 0.3 J/m2) |
| `disp.zener_coeff` | 1.5 | - | LITERATURE_APPROX | 0.3 | 0.3 … 4 | Zener pinning pressure P = c gamma f / r (c = 3/2 classical) |
| `ect.cond_noise_rel` (log) | 0.005 | - | ILLUSTRATIVE | 0.3 | 0 … 0.1 | relative repeatability (1 sigma) of a conductivity reading |
| `ect.l0` (log) | 0.001 | m | ILLUSTRATIVE | 0.3 | 0.0001 … 0.01 | crack length at which the length factor is 0.5 |
| `ect.noise` (log) | 0.05 | - | ILLUSTRATIVE | 0.3 | 0 … 1 | lift-off / conductivity-variation noise relative to a unit crack signal |
| `ect.sigma_ln` | 0.35 | - | ILLUSTRATIVE | 0.1 | 0.05 … 1.5 | log-scatter of the crack signal |
| `ect.thr` | 2.5 | - | ILLUSTRATIVE | 0 |  | detection threshold in noise units; to be set by procedure qualification |
| `elastic.kE.Ag` | 0 | 1/wt% | ILLUSTRATIVE | 0.003 | -0.03 … 0.05 | assumed negligible |
| `elastic.kE.Cu` | 0.002 | 1/wt% | ILLUSTRATIVE | 0.003 | -0.03 … 0.05 | small stiffness change per wt% Cu |
| `elastic.kE.Li` | 0.06 | 1/wt% | LITERATURE_APPROX | 0.015 | 0 … 0.15 | fractional stiffness increase per wt% Li in solid solution (widely quoted ~6 %/wt%) |
| `elastic.kE.Mg` | -0.002 | 1/wt% | ILLUSTRATIVE | 0.003 | -0.03 … 0.05 | small stiffness change per wt% Mg |
| `elastic.kE.Sc` | 0 | 1/wt% | ILLUSTRATIVE | 0.01 | -0.1 … 0.1 | assumed negligible |
| `elastic.kE.Zn` | 0 | 1/wt% | ILLUSTRATIVE | 0.003 | -0.03 … 0.05 | assumed negligible |
| `elastic.kE.Zr` | 0 | 1/wt% | ILLUSTRATIVE | 0.01 | -0.1 … 0.1 | assumed negligible |
| `ext.johnson_a` | 0.8 | - | ILLUSTRATIVE | 0.15 | 0.3 … 1.5 | Johnson extrusion-pressure constant a |
| `ext.johnson_b` | 1.5 | - | ILLUSTRATIVE | 0.3 | 0.8 … 3 | Johnson extrusion-pressure constant b |
| `fat.Y` | 1.12 | - | REFERENCE | 0.05 |  | geometry factor |
| `fat.b` | -0.075 | - | ILLUSTRATIVE | 0.015 | -0.2 … -0.02 | Basquin exponent |
| `fat.c` | **UNKNOWN** | - | UNKNOWN | 0 |  | Coffin-Manson fatigue ductility exponent: supply from strain-controlled tests |
| `fat.dK_th` | 1.8 | MPa m^0.5 | ILLUSTRATIVE | 0.4 | 0.3 … 6 | long-crack fatigue threshold (R~0.1) |
| `fat.eps_f` | **UNKNOWN** | - | UNKNOWN | 0 |  | Coffin-Manson fatigue ductility coefficient: supply from strain-controlled tests |
| `fat.scatter_log10N` | 0.3 | decades | ILLUSTRATIVE | 0.05 | 0.05 … 1 | 1-sigma scatter of log10(life) |
| `fat.sigma_f_ratio` | 1 | - | ILLUSTRATIVE | 0.1 | 0.4 … 2 | Basquin sigma_f' / UTS |
| `fat.stressed_volume` | 2e-05 | m3 | ILLUSTRATIVE | 0 | 1e-09 … 1 | stressed volume of the reference specimen/feature for the defect-size extreme-value argume |
| `fat.surface.anodised` | 0.72 | - | ILLUSTRATIVE | 0.04 | 0.3 … 1.05 | surface-condition fatigue knock-down factor |
| `fat.surface.as_rolled` | 0.8 | - | ILLUSTRATIVE | 0.04 | 0.3 … 1.05 | surface-condition fatigue knock-down factor |
| `fat.surface.chemically_milled` | 0.88 | - | ILLUSTRATIVE | 0.04 | 0.3 … 1.05 | surface-condition fatigue knock-down factor |
| `fat.surface.machined` | 0.92 | - | ILLUSTRATIVE | 0.04 | 0.3 … 1.05 | surface-condition fatigue knock-down factor |
| `fat.surface.polished` | 1 | - | ILLUSTRATIVE | 0.04 | 0.3 … 1.05 | surface-condition fatigue knock-down factor |
| `forge.h_cool` (log) | 120 | W/m2/K | ILLUSTRATIVE | 0.4 | 5 … 3000 | inter-step cooling coefficient |
| `forge.mu` | 0.35 | - | ILLUSTRATIVE | 0.1 | 0.05 … 0.8 | friction coefficient at the die interface |
| `frac.E_eff` | 7.8e+10 | Pa | LITERATURE_APPROX | 3e+09 | 5e+10 … 1e+11 | plane-strain modulus E/(1-nu^2) |
| `frac.Y` | 1.12 | - | REFERENCE | 0.05 |  | geometry factor for a shallow surface crack |
| `frac.d_constituent` (log) | 5e-06 | m | ILLUSTRATIVE | 0.3 | 5e-07 … 5e-05 | mean constituent particle diameter |
| `frac.delam_gain` | 0.04 | - | ILLUSTRATIVE | 0.05 | 0 … 0.6 | T-L toughening/loss per ln(grain aspect ratio) from delamination |
| `frac.eps_c` (log) | 0.3 | - | ILLUSTRATIVE | 0.2 | 0.05 … 3 | critical local strain for void coalescence in the process zone |
| `frac.gb_loss` | 0.25 | - | ILLUSTRATIVE | 0.1 | 0 … 0.8 | toughness loss at full grain-boundary precipitate coverage |
| `frac.m_cod` | 1 | - | ILLUSTRATIVE | 0.2 | 0.5 … 3 | J = m sigma_y delta constraint factor |
| `frac.paris_C` | **UNKNOWN** | m/cycle/(MPa m^0.5)^m | UNKNOWN | 0 |  | Paris-law coefficient: supply from a fatigue-crack-growth dataset |
| `frac.paris_m` | **UNKNOWN** | - | UNKNOWN | 0 |  | Paris-law exponent: supply from a fatigue-crack-growth dataset |
| `frac.rex_loss` | 0.15 | - | ILLUSTRATIVE | 0.07 | 0 … 0.6 | toughness loss when fully recrystallised (vs fibrous unrecrystallised) |
| `furnace.h_part` (log) | 35 | W/m2/K | ILLUSTRATIVE | 0.3 | 5 … 500 | furnace-to-part heat-transfer coefficient (air furnace) |
| `furnace.tau_air` (log) | 240 | s | ILLUSTRATIVE | 0.3 | 5 … 3600 | furnace air first-order lag behind the set-point |
| `furnace.uniformity_K` | 3 | K | ILLUSTRATIVE | 0 | 0 … 30 | 1-sigma temperature uniformity/offset error of the furnace at the part |
| `homog.burn_void_rate` (log) | 400 | 1/m3 per K excess | ILLUSTRATIVE | 0.8 | 0 … 1e+06 | incipient-melting void count per m3 per K above limit |
| `homog.burning_margin_after_homog` | 30 | K | ILLUSTRATIVE | 10 | 0 … 80 | rise of incipient-melting limit once eutectic is dissolved |
| `homog.constituent_density` | 3500 | kg/m3 | ILLUSTRATIVE | 500 | 2500 … 6000 | density of soluble eutectic constituent phases |
| `homog.constituent_size_factor` (log) | 0.1 | - | ILLUSTRATIVE | 0.25 | 0.01 … 0.5 | constituent particle radius / lambda2 |
| `homog.dissolution_lambda` (log) | 0.05 | - | ILLUSTRATIVE | 0.5 | 0.001 … 1 | stationary-interface dissolution parameter (cI-cM)/(cp-cI) |
| `homog.eutectic_phase_fraction` | 0.5 | - | ILLUSTRATIVE | 0.2 | 0.05 … 1 | volume fraction of the interdendritic eutectic region occupied by the soluble constituent  |
| `homog.fe_mass_fraction` | 0.15 | - | ILLUSTRATIVE | 0.03 | 0.05 … 0.5 | Fe mass fraction in Fe-bearing constituent (Al7Cu2Fe-like) |
| `homog.insoluble_density` | 4400 | kg/m3 | ILLUSTRATIVE | 400 | 3000 … 7000 | density of insoluble Fe/Si-bearing constituents |
| `homog.si_mass_fraction` | 0.15 | - | ILLUSTRATIVE | 0.03 | 0.05 … 0.5 | Si mass fraction in Si-bearing constituent |
| `homog.sol_mass_fraction` | 0.45 | - | ILLUSTRATIVE | 0.1 | 0.1 … 0.9 | mass fraction of Cu+Li+Mg in the soluble eutectic constituent |
| `kocks.M` | 3.06 | - | REFERENCE | 0.05 |  | Taylor factor of a random FCC polycrystal |
| `kocks.Q_dr` | 5000 | J/mol | ILLUSTRATIVE | 1500 | 0 … 100000 | activation energy of dynamic recovery |
| `kocks.T0` | 300 | K | REFERENCE | 0 |  | reference temperature of k2_cold |
| `kocks.k1` (log) | 5e+08 | 1/m | ILLUSTRATIVE | 0.3 | 1e+07 … 1e+10 | Kocks-Mecking storage coefficient |
| `kocks.k2_cold` (log) | 15 | - | ILLUSTRATIVE | 0.3 | 0.5 … 500 | Kocks-Mecking dynamic-recovery coefficient at the reference temperature |
| `mic.grain_bias` | 0 | - | ILLUSTRATIVE | 0.03 | -0.3 … 0.3 | systematic relative bias of the grain-size estimate (etching/threshold) |
| `mic.intercept_cv` | 0.9 | - | ILLUSTRATIVE | 0.2 | 0.2 … 3 | coefficient of variation of a single lineal intercept |
| `mic.particle_bias` | -0.05 | - | ILLUSTRATIVE | 0.03 | -0.3 … 0.3 | systematic bias of TEM radius (projection / truncation) |
| `mic.particle_cv` | 0.35 | - | ILLUSTRATIVE | 0.1 | 0.05 … 1.5 | coefficient of variation of measured particle radius |
| `mill.max_force` (log) | 3e+07 | N | ILLUSTRATIVE | 0.1 | 100000 … 1e+09 | stand separating-force limit |
| `mill.max_power` (log) | 8e+06 | W | ILLUSTRATIVE | 0.1 | 10000 … 1e+09 | main-drive power limit |
| `mill.stiffness` (log) | 8e+09 | N/m | ILLUSTRATIVE | 0.3 | 1e+08 … 1e+11 | mill modulus (stand stretch stiffness) |
| `precip.Al3Sc.gamma` (log) | 0.1 | J/m2 | ILLUSTRATIVE | 0.04 | 0.01 … 0.6 | Placeholder tuned for plausible kinetics; calibrate to TEM/SAXS/hardness data |
| `precip.Al3Sc.nuc_pref` (log) | 1e-07 | - | ILLUSTRATIVE | 1 | 1e-08 … 1e+08 | as above |
| `precip.Al3Zr.gamma` (log) | 0.1 | J/m2 | ILLUSTRATIVE | 0.04 | 0.01 … 0.6 | Placeholder tuned for plausible kinetics; calibrate to TEM/SAXS/hardness data |
| `precip.Al3Zr.nuc_pref` (log) | 1e-07 | - | ILLUSTRATIVE | 1 | 1e-08 … 1e+08 | as above |
| `precip.T1.gamma` (log) | 0.1 | J/m2 | ILLUSTRATIVE | 0.03 | 0.01 … 0.6 | Placeholder tuned for plausible kinetics; calibrate to TEM/SAXS/hardness data |
| `precip.T1.het_phi` (log) | 0.12 | - | ILLUSTRATIVE | 0.3 | 0.01 … 1 | heterogeneous nucleation barrier factor on dislocations |
| `precip.T1.nuc_pref` (log) | 1e-06 | - | ILLUSTRATIVE | 1 | 1e-08 … 1e+08 | as above |
| `precip.delta_prime.gamma` (log) | 0.02 | J/m2 | ILLUSTRATIVE | 0.04 | 0.005 … 0.2 | Placeholder tuned for plausible kinetics; calibrate to TEM/SAXS/hardness data |
| `precip.delta_prime.nuc_pref` (log) | 0.0001 | - | ILLUSTRATIVE | 1 | 1e-08 … 1e+08 | multiplicative factor on classical J (Z, beta* approximations) |
| `precip.het_Ag_gain` (log) | 2 | 1/wt% | ILLUSTRATIVE | 0.4 | 0 … 20 | Ag lowers T1 nucleation barrier: phi_eff = phi/(1+gAg wAg+gMg wMg) |
| `precip.het_Mg_gain` (log) | 1 | 1/wt% | ILLUSTRATIVE | 0.4 | 0 … 20 | Mg lowers T1 nucleation barrier |
| `precip.het_site_efficiency` (log) | 0.05 | - | ILLUSTRATIVE | 0.5 | 0.0001 … 1 | fraction of dislocation length that acts as nucleation sites |
| `precip.theta_prime.gamma` (log) | 0.12 | J/m2 | ILLUSTRATIVE | 0.04 | 0.01 … 0.6 | Placeholder tuned for plausible kinetics; calibrate to TEM/SAXS/hardness data |
| `precip.theta_prime.het_phi` (log) | 0.25 | - | ILLUSTRATIVE | 0.3 | 0.01 … 1 | heterogeneous nucleation barrier factor on dislocations |
| `precip.theta_prime.nuc_pref` (log) | 1e-08 | - | ILLUSTRATIVE | 1 | 1e-08 … 1e+08 | as above |
| `precip.vac_Ef` | 6.46e+04 | J/mol | LITERATURE_APPROX | 3000 | 40000 … 90000 | vacancy formation energy in Al (~0.67 eV) |
| `precip.vac_Q` | 5.35e+04 | J/mol | ILLUSTRATIVE | 5000 | 10000 … 150000 | vacancy sink annealing activation energy |
| `precip.vac_k0` (log) | 2.4e+05 | 1/s | ILLUSTRATIVE | 1 | 1 … 1e+12 | vacancy sink annealing rate prefactor |
| `qfa.cooling_window_hi` | 673 | K | REFERENCE | 0 |  | upper bound of the critical cooling-rate window used for reporting |
| `qfa.cooling_window_lo` | 523 | K | REFERENCE | 0 |  | lower bound of the critical cooling-rate window used for reporting |
| `qfa.k1` | -0.005013 | - | REFERENCE | 0 |  | ln(fraction of max transformation tolerated) by convention |
| `qfa.k2` (log) | 8.01e-06 | s | ILLUSTRATIVE | 1 | 1e-30 … 1e-05 | reciprocal of the constant associated with the nucleation sites |
| `qfa.k3` | 650 | J/mol | ILLUSTRATIVE | 1500 | 500 … 50000 | constant related to the energy required to form a nucleus |
| `qfa.k4` | 790 | K | ILLUSTRATIVE | 20 | 600 … 900 | solvus temperature of the quench-sensitive phase |
| `qfa.k5` | 8.3e+04 | J/mol | ILLUSTRATIVE | 10000 | 50000 … 300000 | activation energy for diffusion |
| `qfa.loss_to_gb` | 0.6 | - | ILLUSTRATIVE | 0.3 | 0 … 1 | share of quench-lost solute that decorates grain boundaries (vs matrix coarse phases) |
| `qsys.cp_medium` | 4180 | J/kg/K | REFERENCE | 40 |  | specific heat of water-based quenchant |
| `qsys.flow_exp` | 0.5 | - | ILLUSTRATIVE | 0.1 | 0.1 … 1 | h scales as (flow/flow_nom)^exp |
| `qsys.flow_nom` | 1 | m/s | ILLUSTRATIVE | 0 |  | nominal tank agitation velocity at which the h-curve was defined |
| `qsys.tank_mass` (log) | 2e+04 | kg | ILLUSTRATIVE | 0.1 | 100 … 1e+07 | mass of quenchant in the tank |
| `quench.E` | 7e+10 | Pa | LITERATURE_APPROX | 2e+09 | 5e+10 … 8e+10 | Young's modulus for quench-stress calculation |
| `quench.T_medium_water` | 293 | K | REFERENCE | 0 |  | nominal cold-water temperature (user input overrides) |
| `quench.alpha` | 2.35e-05 | 1/K | LITERATURE_APPROX | 1.5e-06 | 1e-05 … 4e-05 | CTE during quench |
| `quench.dT_peak.cold_water` | 150 | K | ILLUSTRATIVE | 30 | 30 … 400 | surface-medium temperature difference at peak heat flux |
| `quench.dT_peak.forced_air` | 100 | K | ILLUSTRATIVE | 30 | 30 … 400 | surface-medium temperature difference at peak heat flux |
| `quench.dT_peak.hot_water` | 120 | K | ILLUSTRATIVE | 30 | 30 … 400 | surface-medium temperature difference at peak heat flux |
| `quench.dT_peak.polymer_glycol` | 130 | K | ILLUSTRATIVE | 30 | 30 … 400 | surface-medium temperature difference at peak heat flux |
| `quench.dT_peak.still_air` | 100 | K | ILLUSTRATIVE | 30 | 30 … 400 | surface-medium temperature difference at peak heat flux |
| `quench.h_conv.cold_water` (log) | 1000 | W/m2/K | ILLUSTRATIVE | 0.25 | 5 … 50000 | illustrative boiling-curve point; measure for your quench tank |
| `quench.h_conv.forced_air` (log) | 70 | W/m2/K | ILLUSTRATIVE | 0.25 | 5 … 50000 | illustrative boiling-curve point; measure for your quench tank |
| `quench.h_conv.hot_water` (log) | 800 | W/m2/K | ILLUSTRATIVE | 0.25 | 5 … 50000 | illustrative boiling-curve point; measure for your quench tank |
| `quench.h_conv.polymer_glycol` (log) | 600 | W/m2/K | ILLUSTRATIVE | 0.25 | 5 … 50000 | illustrative boiling-curve point; measure for your quench tank |
| `quench.h_conv.still_air` (log) | 15 | W/m2/K | ILLUSTRATIVE | 0.25 | 5 … 50000 | illustrative boiling-curve point; measure for your quench tank |
| `quench.h_film.cold_water` (log) | 4000 | W/m2/K | ILLUSTRATIVE | 0.25 | 5 … 50000 | illustrative boiling-curve point |
| `quench.h_film.forced_air` (log) | 100 | W/m2/K | ILLUSTRATIVE | 0.25 | 5 … 50000 | illustrative boiling-curve point |
| `quench.h_film.hot_water` (log) | 2500 | W/m2/K | ILLUSTRATIVE | 0.25 | 5 … 50000 | illustrative boiling-curve point |
| `quench.h_film.polymer_glycol` (log) | 1800 | W/m2/K | ILLUSTRATIVE | 0.25 | 5 … 50000 | illustrative boiling-curve point |
| `quench.h_film.still_air` (log) | 35 | W/m2/K | ILLUSTRATIVE | 0.25 | 5 … 50000 | illustrative boiling-curve point |
| `quench.h_peak.cold_water` (log) | 1.4e+04 | W/m2/K | ILLUSTRATIVE | 0.25 | 5 … 100000 | illustrative boiling-curve point |
| `quench.h_peak.forced_air` (log) | 90 | W/m2/K | ILLUSTRATIVE | 0.25 | 5 … 100000 | illustrative boiling-curve point |
| `quench.h_peak.hot_water` (log) | 8000 | W/m2/K | ILLUSTRATIVE | 0.25 | 5 … 100000 | illustrative boiling-curve point |
| `quench.h_peak.polymer_glycol` (log) | 4500 | W/m2/K | ILLUSTRATIVE | 0.25 | 5 … 100000 | illustrative boiling-curve point |
| `quench.h_peak.still_air` (log) | 25 | W/m2/K | ILLUSTRATIVE | 0.25 | 5 … 100000 | illustrative boiling-curve point |
| `quench.nu` | 0.33 | - | LITERATURE_APPROX | 0.01 | 0.25 … 0.4 | Poisson ratio |
| `quench.relief_eps` (log) | 0.01 | - | ILLUSTRATIVE | 0.4 | 0.001 … 0.1 | stretch strain scale for residual-stress relief: 1-exp(-eps/eps_s) |
| `quench.stretch_hardening_cap` (log) | 3e+14 | 1/m2 | ILLUSTRATIVE | 0.5 | 1e+13 … 1e+16 | dislocation-density ceiling for cold stretch at room temperature |
| `quench.sy_cold` (log) | 1.4e+08 | Pa | ILLUSTRATIVE | 0.15 | 3e+07 … 5e+08 | yield stress of the as-quenched (W) alloy at room temperature |
| `quench.sy_hot` (log) | 3e+07 | Pa | ILLUSTRATIVE | 0.3 | 1e+06 … 2e+08 | yield stress of the solutionised alloy at the solution temperature |
| `roll.edge_crack_rate` (log) | 6 | 1/m3 per unit strain-rate-ratio | ILLUSTRATIVE | 0.8 | 0 … 10000 | surface/edge crack count per m3 when flow-stress ratio exceeds threshold |
| `roll.h_cool` (log) | 80 | W/m2/K | ILLUSTRATIVE | 0.4 | 5 … 2000 | inter-pass cooling coefficient of the slab surface to the surroundings |
| `roll.mu` | 0.3 | - | ILLUSTRATIVE | 0.08 | 0.05 … 0.6 | Coulomb friction coefficient in the roll bite |
| `roll.pore_close_thickness` (log) | 5e-05 | m | ILLUSTRATIVE | 0.5 | 1e-07 … 0.001 | pore thickness below which the pore is closed by rolling |
| `roll.rho` | 2650 | kg/m3 | LITERATURE_APPROX | 60 | 2400 … 2900 | plate density for thermal bookkeeping |
| `roll.unbonded_fraction` | 0.03 | - | ILLUSTRATIVE | 0.3 | 0 … 1 | fraction of closed pores left as unbonded (oxide-lined) laminar flaws |
| `rt.cnr_thr` | 3 | - | REFERENCE | 0.5 | 2 … 6 | Rose-criterion contrast-to-noise ratio for visibility |
| `rt.mu_rho` | 0.001704 | m2/kg | REFERENCE | 1e-05 |  | mass attenuation coefficient of Al at 100 keV (0.1704 cm2/g) |
| `rt.photons` (log) | 2e+04 | photons/pixel | ILLUSTRATIVE | 0.4 | 100 … 1e+08 | detected photons per pixel behind the unattenuated plate |
| `rt.pixel` (log) | 0.0001 | m | ILLUSTRATIVE | 0.2 | 1e-05 … 0.001 | effective pixel / unsharpness size |
| `rt.sigma_ln` | 0.3 | - | ILLUSTRATIVE | 0.1 | 0.05 … 1.5 | log-scatter of visibility |
| `rx.E_c` (log) | 5e+04 | J/m3 | ILLUSTRATIVE | 0.5 | 1000 … 1e+07 | stored energy scale for nucleation-site activation |
| `rx.E_ref` | 1e+05 | J/m3 | ILLUSTRATIVE | 0 |  | reference stored energy for t_ref |
| `rx.G` | 2.6e+10 | Pa | LITERATURE_APPROX | 1e+09 | 2e+10 … 3e+10 | shear modulus of Al near room temperature |
| `rx.Q` | 1.8e+05 | J/mol | ILLUSTRATIVE | 20000 | 80000 … 350000 | Placeholder; calibrate to recrystallisation kinetics / EBSD |
| `rx.T_ref` | 723 | K | ILLUSTRATIVE | 0 |  | reference temperature for t_ref |
| `rx.abnormal_rate` (log) | 200 | 1/m3 | ILLUSTRATIVE | 1 | 0 … 1e+06 | abnormal (coarse) grain count per m3 at X(1-X)=0.25 |
| `rx.d_rx0` (log) | 3e-05 | m | ILLUSTRATIVE | 0.5 | 1e-06 … 0.0005 | recrystallised grain size at E = E_ref |
| `rx.d_rx_min` | 3e-06 | m | ILLUSTRATIVE | 0 |  | floor on recrystallised grain size |
| `rx.n` | 2 | - | ILLUSTRATIVE | 0.3 | 1 … 4 | JMAK exponent |
| `rx.p` | 2 | - | ILLUSTRATIVE | 0.5 | 0.5 … 5 | stored-energy exponent of recrystallisation time |
| `rx.rec_Q` | 1.4e+05 | J/mol | ILLUSTRATIVE | 15000 | 50000 … 300000 | static recovery activation energy |
| `rx.rec_k` (log) | 3e+06 | 1/s | ILLUSTRATIVE | 1 | 1 … 1e+12 | static recovery rate prefactor |
| `rx.rho_floor` (log) | 1e+12 | 1/m2 | ILLUSTRATIVE | 0.5 | 1e+10 … 1e+14 | dislocation density retained in stable subgrain structure |
| `rx.rho_rx` (log) | 1e+12 | 1/m2 | ILLUSTRATIVE | 0.5 | 1e+10 … 1e+14 | dislocation density inside recrystallised grains |
| `rx.sigma_ln` | 0.4 | - | ILLUSTRATIVE | 0.1 | 0.1 … 1 | log-std of recrystallised grain-size distribution |
| `rx.sub_K` (log) | 10 | - | ILLUSTRATIVE | 0.2 | 1 … 50 | subgrain size = K / sqrt(rho) |
| `rx.t_ref` (log) | 100 | s | ILLUSTRATIVE | 1 | 0.1 … 1e+06 | Placeholder; calibrate to recrystallisation kinetics / EBSD |
| `sol.T_ref_dummy` | 0 | - | REFERENCE | 0 |  | unused placeholder to keep module parameter block non-empty |
| `str.G` | 2.6e+10 | Pa | LITERATURE_APPROX | 1e+09 | 2e+10 … 3e+10 | shear modulus of Al |
| `str.M` | 3.06 | - | REFERENCE | 0.05 |  | Taylor factor of random FCC polycrystal |
| `str.alpha_taylor` | 0.25 | - | LITERATURE_APPROX | 0.03 | 0.1 … 0.5 | Taylor dislocation-strengthening constant |
| `str.apb.Al3Sc` | 0.4 | J/m2 | ILLUSTRATIVE | 0.1 | 0.05 … 0.8 | APB energy of Al3Sc dispersoids |
| `str.apb.Al3Zr` | 0.25 | J/m2 | ILLUSTRATIVE | 0.08 | 0.05 … 0.6 | APB energy of Al3Zr dispersoids |
| `str.apb.delta_prime` | 0.14 | J/m2 | ILLUSTRATIVE | 0.03 | 0.05 … 0.3 | antiphase-boundary energy of delta' |
| `str.damage_c` (log) | 60 | - | ILLUSTRATIVE | 0.4 | 0 … 10000 | ductility knock-down per unit constituent volume fraction |
| `str.damage_gb` | 0.35 | - | ILLUSTRATIVE | 0.1 | 0 … 0.9 | ductility knock-down at full grain-boundary precipitate coverage |
| `str.damage_p` (log) | 400 | - | ILLUSTRATIVE | 0.4 | 0 … 100000 | ductility knock-down per unit porosity volume fraction |
| `str.eff.Al3Sc` | 0.5 | - | ILLUSTRATIVE | 0.2 | 0.05 … 2 | efficiency of Al3Sc dispersoids |
| `str.eff.Al3Zr` | 0.4 | - | ILLUSTRATIVE | 0.2 | 0.05 … 2 | efficiency of Al3Zr dispersoids |
| `str.eff.T1` | 1 | - | ILLUSTRATIVE | 0.12 | 0.1 … 3 | plate-geometry efficiency of T1 relative to spheres of equal volume |
| `str.eff.delta_prime` | 1 | - | ILLUSTRATIVE | 0.15 | 0.1 … 2 | strengthening efficiency of delta' |
| `str.eff.theta_prime` | 0.5 | - | ILLUSTRATIVE | 0.2 | 0.1 … 3 | efficiency of theta' |
| `str.eps_neck0` | 0.04 | - | ILLUSTRATIVE | 0.03 | 0.01 … 0.5 | post-uniform (local) true strain of a defect-free material |
| `str.k_ss.Ag` | 300 | MPa | ILLUSTRATIVE | 0.3 | 0 … 5000 | Fleischer-Labusch coefficient per at-fraction^(2/3) |
| `str.k_ss.Cu` | 400 | MPa | ILLUSTRATIVE | 0.3 | 0 … 5000 | Fleischer-Labusch coefficient per at-fraction^(2/3) |
| `str.k_ss.Fe` | 0 | MPa | ILLUSTRATIVE | 0 | 0 … 5000 | Fleischer-Labusch coefficient per at-fraction^(2/3) |
| `str.k_ss.Li` | 250 | MPa | ILLUSTRATIVE | 0.3 | 0 … 5000 | Fleischer-Labusch coefficient per at-fraction^(2/3) |
| `str.k_ss.Mg` | 500 | MPa | ILLUSTRATIVE | 0.3 | 0 … 5000 | Fleischer-Labusch coefficient per at-fraction^(2/3) |
| `str.k_ss.Mn` | 600 | MPa | ILLUSTRATIVE | 0.3 | 0 … 5000 | Fleischer-Labusch coefficient per at-fraction^(2/3) |
| `str.k_ss.Sc` | 0 | MPa | ILLUSTRATIVE | 0 | 0 … 5000 | Fleischer-Labusch coefficient per at-fraction^(2/3) |
| `str.k_ss.Si` | 300 | MPa | ILLUSTRATIVE | 0.3 | 0 … 5000 | Fleischer-Labusch coefficient per at-fraction^(2/3) |
| `str.k_ss.Ti` | 0 | MPa | ILLUSTRATIVE | 0 | 0 … 5000 | Fleischer-Labusch coefficient per at-fraction^(2/3) |
| `str.k_ss.Zn` | 150 | MPa | ILLUSTRATIVE | 0.3 | 0 … 5000 | Fleischer-Labusch coefficient per at-fraction^(2/3) |
| `str.k_ss.Zr` | 0 | MPa | ILLUSTRATIVE | 0 | 0 … 5000 | Fleischer-Labusch coefficient per at-fraction^(2/3) |
| `str.k_sub` | 0.04 | MPa m^0.5 | ILLUSTRATIVE | 0.015 | 0 … 0.3 | subgrain Hall-Petch slope |
| `str.k_y` | 0.06 | MPa m^0.5 | LITERATURE_APPROX | 0.015 | 0 … 0.3 | Hall-Petch slope of Al alloys (pure Al ~0.04) |
| `str.nu` | 0.33 | - | LITERATURE_APPROX | 0.01 | 0.25 … 0.4 | Poisson ratio |
| `str.q_disl_ppt` | 2 | - | ILLUSTRATIVE | 0.3 | 1 … 4 | superposition exponent between dislocation and precipitate contributions |
| `str.q_ppt` | 2 | - | ILLUSTRATIVE | 0.3 | 1 … 4 | superposition exponent between precipitate phases |
| `str.q_shear_orowan` | 6 | - | ILLUSTRATIVE | 1 | 2 … 20 | sharpness of the shear/Orowan transition (smooth minimum) |
| `str.sat_fraction` | 0.2 | - | ILLUSTRATIVE | 0.08 | 0.05 … 1 | Voce saturation stress increment as a fraction of yield strength |
| `str.sigma0` | 10 | MPa | LITERATURE_APPROX | 3 | 0 … 40 | lattice friction of Al (Peierls) plus residual impurities |
| `str.theta0_orowan` | 2.5e+09 | Pa | ILLUSTRATIVE | 4e+08 | 1e+08 … 1e+10 | initial work-hardening rate when Orowan looping dominates |
| `str.theta0_shear` | 1.2e+09 | Pa | ILLUSTRATIVE | 2e+08 | 1e+08 … 1e+10 | initial work-hardening rate when shearable precipitates dominate |
| `tex.cube_share` | 0.3 | - | ILLUSTRATIVE | 0.1 | 0 … 1 | Cube share of recrystallisation texture without particle-stimulated nucleation |
| `tex.eps_scale` (log) | 1.5 | - | ILLUSTRATIVE | 0.3 | 0.2 … 10 | equivalent strain scale for deformation-texture saturation |
| `tex.goss_share` | 0.05 | - | ILLUSTRATIVE | 0.03 | 0 … 1 | Goss share of recrystallisation texture |
| `tex.max_def_fraction` | 0.65 | - | ILLUSTRATIVE | 0.1 | 0.1 … 1 | maximum fraction of material in deformation components |
| `tex.psn_gain` (log) | 25 | - | ILLUSTRATIVE | 0.5 | 0 … 500 | randomisation of recrystallisation texture by constituent particles per unit volume fracti |
| `th.L` | 2.44e-08 | W Ohm/K2 | REFERENCE | 1e-10 |  | Lorenz number |
| `th.cte_Li` | -3.5e-07 | 1/K per wt% | ILLUSTRATIVE | 3e-07 | -3e-06 … 3e-06 | CTE change per wt% Li |
| `th.k_ph` | 5 | W/m/K | ILLUSTRATIVE | 3 | 0 … 30 | lattice thermal conductivity |
| `th.rho0` | 2.65e-08 | Ohm m | REFERENCE | 5e-11 |  | resistivity of pure Al at 293 K |
| `th.rho_ppt` (log) | 1.5e-07 | Ohm m per unit volume fraction | ILLUSTRATIVE | 0.5 | 0 … 1e-05 | scattering by precipitates per unit volume fraction |
| `th.rho_wt.Ag` | 0.1 | uOhm cm/wt% | ILLUSTRATIVE | 0.025 | 0 … 10 | resistivity increment of solute in Al solid solution (Matthiessen); verify |
| `th.rho_wt.Cu` | 0.344 | uOhm cm/wt% | LITERATURE_APPROX | 0.086 | 0 … 10 | resistivity increment of solute in Al solid solution (Matthiessen); verify |
| `th.rho_wt.Fe` | 2.56 | uOhm cm/wt% | LITERATURE_APPROX | 0.64 | 0 … 10 | resistivity increment of solute in Al solid solution (Matthiessen); verify |
| `th.rho_wt.Li` | 3.3 | uOhm cm/wt% | LITERATURE_APPROX | 0.825 | 0 … 10 | resistivity increment of solute in Al solid solution (Matthiessen); verify |
| `th.rho_wt.Mg` | 0.54 | uOhm cm/wt% | LITERATURE_APPROX | 0.135 | 0 … 10 | resistivity increment of solute in Al solid solution (Matthiessen); verify |
| `th.rho_wt.Mn` | 2.94 | uOhm cm/wt% | LITERATURE_APPROX | 0.735 | 0 … 10 | resistivity increment of solute in Al solid solution (Matthiessen); verify |
| `th.rho_wt.Sc` | 1 | uOhm cm/wt% | ILLUSTRATIVE | 0.25 | 0 … 10 | resistivity increment of solute in Al solid solution (Matthiessen); verify |
| `th.rho_wt.Si` | 1.02 | uOhm cm/wt% | LITERATURE_APPROX | 0.255 | 0 … 10 | resistivity increment of solute in Al solid solution (Matthiessen); verify |
| `th.rho_wt.Ti` | 2.88 | uOhm cm/wt% | LITERATURE_APPROX | 0.72 | 0 … 10 | resistivity increment of solute in Al solid solution (Matthiessen); verify |
| `th.rho_wt.Zn` | 0.094 | uOhm cm/wt% | LITERATURE_APPROX | 0.0235 | 0 … 10 | resistivity increment of solute in Al solid solution (Matthiessen); verify |
| `th.rho_wt.Zr` | 1.74 | uOhm cm/wt% | LITERATURE_APPROX | 0.435 | 0 … 10 | resistivity increment of solute in Al solid solution (Matthiessen); verify |
| `thermo.Al3Sc.K0` (log) | 100 | - | ILLUSTRATIVE | 0.2 | 0.01 … 1e+09 | Illustrative reduced-order solubility relation tuned to give physically plausible solvus o |
| `thermo.Al3Sc.Q` | 8e+04 | J/mol | ILLUSTRATIVE | 2500 | 20000 … 300000 | Illustrative reduced-order solubility relation tuned to give physically plausible solvus o |
| `thermo.Al3Zr.K0` (log) | 2300 | - | ILLUSTRATIVE | 0.2 | 1 … 1e+09 | Illustrative reduced-order solubility relation tuned to give physically plausible solvus o |
| `thermo.Al3Zr.Q` | 1.02e+05 | J/mol | ILLUSTRATIVE | 2500 | 20000 … 300000 | Illustrative reduced-order solubility relation tuned to give physically plausible solvus o |
| `thermo.T1.K0` (log) | 64 | - | ILLUSTRATIVE | 0.12 | 0.01 … 1e+06 | Illustrative reduced-order solubility relation tuned to give physically plausible solvus o |
| `thermo.T1.Q` | 5.7e+04 | J/mol | ILLUSTRATIVE | 1500 | 10000 … 200000 | Illustrative reduced-order solubility relation tuned to give physically plausible solvus o |
| `thermo.delta_prime.K0` (log) | 7.1 | - | ILLUSTRATIVE | 0.12 | 0.1 … 1000 | Illustrative reduced-order solubility relation tuned to give physically plausible solvus o |
| `thermo.delta_prime.Q` | 1.87e+04 | J/mol | ILLUSTRATIVE | 800 | 5000 … 60000 | Illustrative reduced-order solubility relation tuned to give physically plausible solvus o |
| `thermo.molar_volume` | 9.99e-06 | m3/mol | REFERENCE | 5e-08 |  | molar volume of pure Al; precipitate molar volume assumed equal |
| `thermo.theta_prime.K0` (log) | 1.36 | - | ILLUSTRATIVE | 0.12 | 0.01 … 10000 | Illustrative reduced-order solubility relation tuned to give physically plausible solvus o |
| `thermo.theta_prime.Q` | 2.63e+04 | J/mol | ILLUSTRATIVE | 1000 | 5000 … 100000 | Illustrative reduced-order solubility relation tuned to give physically plausible solvus o |
| `thermo.volume_ratio` | 1 | - | ILLUSTRATIVE | 0.03 | 0.8 … 1.3 | precipitate/matrix atomic volume ratio assumed 1 (small misfit) |
| `us.aG` (log) | 0.004 | - | ILLUSTRATIVE | 0.5 | 0 … 1000 | geometric scatter coefficient: alpha = aG / d (SI) |
| `us.aR` (log) | 6.4e-14 | - | ILLUSTRATIVE | 0.5 | 0 … 1000 | Rayleigh scatter coefficient: alpha = aR f^4 d^3 (SI); regimes cross near d ~ lambda/(2 pi |
| `us.aS` (log) | 4e-09 | - | ILLUSTRATIVE | 0.5 | 0 … 1000 | stochastic scatter coefficient: alpha = aS f^2 d (SI) |
| `us.alpha_abs` (log) | 0.4 | Np/m at 5 MHz | ILLUSTRATIVE | 0.4 | 0 … 20 | intrinsic absorption |
| `us.dead_zone` | 0.002 | m | ILLUSTRATIVE | 0 |  | near-surface dead zone |
| `us.noise_el` (log) | 0.01 | - | ILLUSTRATIVE | 0.3 | 0 … 1 | electronic noise relative to back-wall echo |
| `us.noise_gr` (log) | 0.02 | - | ILLUSTRATIVE | 0.4 | 0 … 1 | structural-noise coefficient: n = c (d/lambda)^1.5 |
| `us.sigma_dB` | 3 | dB | ILLUSTRATIVE | 0.5 | 0.5 … 12 | scatter of the signal response (POD curve width) |
| `us.thr_dB` | 6 | dB | ILLUSTRATIVE | 0 |  | detection threshold above noise; to be set by NDT procedure qualification |
| `us.v_L` | 6320 | m/s | LITERATURE_APPROX | 40 | 6000 … 6600 | longitudinal wave speed in Al alloys |