# Architecture

AEROLITH-TWIN treats an alloy as a **process history**. The central object is `MaterialState`
(`microstructure/state.py`): composition, segregation profiles, constituent particles, a number-density-per-radius
precipitate field for five phases, vacancy fraction, grain ensemble (lognormal ellipsoids), dislocation density, texture
components, defect population and residual stress. Every stage takes a state and returns the evolved state; a hash-chained
genealogy node records parameters and summary.

```
CHEMISTRY → MELT → CAST → HOMOGENISATION → DEFORMATION → SOLUTION → QUENCH (+STRETCH) → (NATURAL) AGEING → PROPERTIES → INSPECTION → SCREENING
```

| layer | package | what it holds |
|---|---|---|
| inputs | `chemistry`, `manufacturing/spec.py` | typed composition (wt%/at%), YAML route with explicit units (°C, h, mm → SI at one boundary) |
| thermodynamics | `thermodynamics` | solubility-product equilibrium, nucleation theory pieces, activities |
| casting | `casting` | 1-D enthalpy solidification, Clyne–Kurz microsegregation, growth-restriction grain size, defect generation |
| homogenisation | `homogenisation` | exact cosine-mode diffusion, constituent dissolution, thermal cycles |
| processing | `processing` | rolling / forging / abstract extrusion, sinh flow stress, Kocks–Mecking storage, Zener-limited JMAK, texture |
| heat treatment | `heat_treatment` | multi-phase KWN kernel (numba), solution, quench (conduction + QFA + elastoplastic stress), ageing |
| properties | `properties` | density, elastic (VRH over texture), strength mechanisms, fracture, fatigue, corrosion index, transport |
| inspection | `inspection` | UT, ECT, RT, virtual metallography, combined POD |
| plant | `manufacturing` | furnace lag, quench tank balance, mill limits, cost/complexity, traceability, process chain |
| twin | `digital_twin` | sensors, Kalman estimation, importance-weighted posterior, ensembles, robustness, screening, scorecard |
| learning | `calibration` | bounded least squares, adaptive-Metropolis Bayesian inference, MC utilities |
| decisions | `optimisation` | candidate comparison, NSGA-II over the whole route, Sobol/local sensitivity |
| output | `io`, `results.py`, `report.py`, `viz` | HDF5/Parquet/JSON/CSV with mandatory metadata, HTML report, lab-style figures |

## Provenance discipline
* `params.py`: every parameter has units, source, status, validity range and uncertainty; `UNKNOWN` has no value and models refuse to run without one.
* `RunContext.ledger` records which parameters (and statuses) each run exercised; reports list them and label ILLUSTRATIVE/UNKNOWN as ASSUMED.
* `provenance.Quantity`: MEASURED / SIMULATED / ESTIMATED / ASSUMED; `as_measured()` refuses anything not MEASURED. Virtual-instrument readings are SIMULATED.
* `--strict` (`StrictModeError`) forbids ILLUSTRATIVE/UNKNOWN parameters entirely.

## Three states
`TrueMaterialState` (ground truth inside the simulation) · `MeasuredProcessState` (sensor telemetry with bias/noise/drift/resolution/rate/dropout, virtual metallography, NDT) · `EstimatedMaterialState` (Kalman process estimates + importance-weighted ensemble posterior).

## Precipitation kernel
KWN with classical nucleation (homogeneous + dislocation-heterogeneous), diffusion-limited growth with Gibbs–Thomson,
exact solute mass balance across phases, vacancy-enhanced diffusion, semi-Lagrangian size-space transport (unconditionally stable),
time step set by growth and by the solute-mass coupling. See `heat_treatment/precipitation.py` for equations and limits.
