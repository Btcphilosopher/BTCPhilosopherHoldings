"""MODEL vs EXPERIMENT with uncertainty bands for an imported experiment table (Parquet/CSV).

python validation/compare_experiment.py datasets/synthetic_strength_v1.parquet [--params calibrated_parameters.yaml]
Real laboratory data enter exactly like the synthetic file: see experiments/SCHEMA.md.
"""
from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
import pandas as pd

from aerolith.calibration.models import strength_from_microstructure
from aerolith.calibration.parameter_fit import split_dataset
from aerolith.context import RunContext
from aerolith.io.parquet import read_table
from aerolith.params import ParameterRegistry, default_registry
from aerolith.viz.figures import model_vs_experiment

ap = argparse.ArgumentParser()
ap.add_argument("dataset")
ap.add_argument("--params")
ap.add_argument("--target", default="yield_strength")
ap.add_argument("--out", default="validation/output")
a = ap.parse_args()
reg = ParameterRegistry.from_yaml(a.params) if a.params else default_registry()
p = Path(a.dataset)
df, meta = read_table(p) if p.suffix == ".parquet" else (pd.read_csv(p), {})
_, val = split_dataset(df)
pred = np.array([strength_from_microstructure(RunContext(reg), r.to_dict())[a.target] for _, r in val.iterrows()])
obs = val[a.target].to_numpy(float)
sig = val.get(f"{a.target}_sigma", pd.Series(np.zeros(len(val)))).to_numpy(float)
rmse = float(np.sqrt(np.mean((pred - obs) ** 2)))
print(f"validation samples: {len(val)}  RMSE {rmse:.2f}  dataset: {meta.get('dataset_id', p.name)}  provenance: {meta.get('provenance', 'unspecified')}")
Path(a.out).mkdir(parents=True, exist_ok=True)
fig = model_vs_experiment(pred, obs, sig, np.full(len(pred), rmse), a.target)
fig.savefig(Path(a.out) / f"model_vs_experiment_{a.target}.png", bbox_inches="tight")
