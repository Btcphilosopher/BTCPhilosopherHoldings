"""Independent validation report: analytical, numerical-convergence and conservation checks.

Writes validation/output/validation_report.json and PNG figures.  Run:  python validation/run_validation.py
"""
from __future__ import annotations

import json
import math
import sys
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
from scipy.special import erfc

from aerolith.casting.cooling import lumped_cooling
from aerolith.casting.solidification import CastingInputs, simulate_solidification
from aerolith.chemistry.composition import Composition
from aerolith.context import RunContext
from aerolith.homogenisation.diffusion import D_arrhenius, cosine_modes_evolve, sinusoid_amplitude_decay
from aerolith.microstructure.grains import GrainState
from aerolith.microstructure.state import MaterialState
from aerolith.microstructure.texture import component_taylor_factors, textured_elastic
from aerolith.numerics import observed_order, slab_conduction_implicit
from aerolith.params import default_registry
from aerolith.properties.strength import grain_boundary
from aerolith.units import R_GAS
from aerolith.viz import style as S

OUT = Path(__file__).parent / "output"
OUT.mkdir(exist_ok=True)
ctx = RunContext(default_registry())
report: dict[str, dict] = {}


def record(name: str, ok: bool, **kw):
    report[name] = {"pass": bool(ok), **{k: (float(v) if isinstance(v, (int, float, np.floating)) else v) for k, v in kw.items()}}
    print(f"[{'PASS' if ok else 'FAIL'}] {name}  " + "  ".join(f"{k}={v:.4g}" if isinstance(v, (int, float, np.floating)) else f"{k}={v}" for k, v in kw.items()))


# 1. Arrhenius: slope of ln D vs 1/T equals -Q/R
T = np.array([600.0, 700.0, 800.0]); D = np.array([D_arrhenius(1e-5, 1.5e5, t) for t in T])
slope = np.polyfit(1 / T, np.log(D), 1)[0]
record("arrhenius_slope", abs(slope + 1.5e5 / R_GAS) / (1.5e5 / R_GAS) < 1e-9, relative_error=abs(slope + 1.5e5 / R_GAS) / (1.5e5 / R_GAS))

# 2. diffusion: cosine-mode solution vs analytical sinusoid decay; solute conservation
L, n = 5e-5, 256
x = (np.arange(n) + 0.5) / n * L
prof = 4 + np.cos(np.pi * x / L)
fig, ax = plt.subplots(figsize=(5, 3.2))
errs = []
for Dt in (1e-16, 1e-15, 1e-14):
    out = cosine_modes_evolve(prof, L, Dt)
    ex = 4 + np.cos(np.pi * x / L) * sinusoid_amplitude_decay(Dt, 2 * L)
    errs.append(np.max(np.abs(out - ex)))
    ax.plot(x * 1e6, out, label=f"D t = {Dt:.0e} m²"); ax.plot(x * 1e6, ex, "k:", lw=0.8)
ax.set_xlabel("x (µm)"); ax.set_ylabel("concentration (wt%)"); ax.set_title("Homogenisation: model (solid) vs analytical (dotted)"); ax.legend(fontsize=7)
S.stamp(fig); fig.savefig(OUT / "diffusion.png", bbox_inches="tight"); plt.close(fig)
record("diffusion_sinusoid", max(errs) < 1e-6, max_abs_error=max(errs), mean_conservation_error=abs(out.mean() - prof.mean()))

# 3. heat transfer: lumped limit, semi-infinite exact solution, timestep convergence (first order)
k, rho, cp = 150.0, 2700.0, 900.0; alpha = k / (rho * cp)
half, nn = 0.005, 21; dx = half / (nn - 1); Tt = np.full(nn, 800.0); t = 0.0
while t < 60.0:
    Tt = slab_conduction_implicit(Tt, dx, 0.05, alpha, 50.0, 300.0, k); t += 0.05
ref = lumped_cooling(800.0, 300.0, 50.0, half, rho, cp, 60.0)
record("heat_lumped_limit", abs(Tt.mean() - ref) < 1.0, error_K=abs(Tt.mean() - ref))
h, half, nn, tend = 8000.0, 0.2, 401, 2.0; dx = half / (nn - 1); dts = [0.2, 0.1, 0.05, 0.025]; errs = []
for dt in dts:
    Tt = np.full(nn, 800.0)
    for _ in range(int(round(tend / dt))):
        Tt = slab_conduction_implicit(Tt, dx, dt, alpha, h, 300.0, k)
    b = h * math.sqrt(alpha * tend) / k
    errs.append(abs(Tt[0] - (800 - 500 * (1 - math.exp(b**2) * erfc(b)))))
order = observed_order(np.array(dts), np.array(errs))
fig, ax = plt.subplots(figsize=(4.4, 3.2)); ax.loglog(dts, errs, "o-"); ax.set_xlabel("time step (s)"); ax.set_ylabel("surface-T error (K)")
ax.set_title(f"Time-step convergence (observed order {order:.2f})"); S.stamp(fig); fig.savefig(OUT / "heat_convergence.png", bbox_inches="tight"); plt.close(fig)
record("heat_semi_infinite_convergence", 0.7 < order < 1.4, observed_order=order, finest_error_K=errs[-1])

# 4. Hall-Petch slope
ky = ctx.p("str.k_y"); ds = np.array([10e-6, 40e-6, 160e-6]); vals = []
for d in ds:
    st = MaterialState(Composition(Li=1.0), (1, 1, 1)); st.grains = GrainState(d, d, d, 0.4, recrystallised_fraction=1.0); vals.append(grain_boundary(ctx, st))
sl = np.polyfit(ds**-0.5, vals, 1)[0]
record("hall_petch_slope", abs(sl - ky) / ky < 1e-6, slope=sl, k_y=ky)

# 5. casting energy balance and mesh independence
c = Composition(Li=1.0, Cu=4.0, Mg=0.4, Ag=0.4, Zr=0.12)
tt = []
for nodes in (20, 40, 80):
    r = simulate_solidification(RunContext(default_registry()), c, CastingInputs(1013.0, 330.0, 0.1), n_nodes=nodes); tt.append(r.local_solidification_time_s[-1])
record("casting_energy_balance", r.energy_balance_error < 1e-9, relative_error=r.energy_balance_error)
record("casting_mesh_independence", abs(tt[2] - tt[1]) / tt[2] < 0.03, solidification_time_20_40_80_s=str([round(float(v), 2) for v in tt]), relative_change_last=abs(tt[2] - tt[1]) / tt[2])

# 6. texture / elasticity
tf = component_taylor_factors()["Random"]; el = textured_elastic({"Random": 1.0})
record("taylor_factor_random", all(abs(v - 3.06) < 0.12 for v in tf.values()), L=tf["L"], T=tf["T"], D=tf["D"])
record("elastic_random_aluminium", 69e9 < el.E_iso < 73e9, E_GPa=el.E_iso / 1e9, nu=el.nu_iso)

# 7. Monte Carlo convergence
rng = np.random.default_rng(3); xs = rng.normal(500, 20, 20000)
se = [xs[:m].std(ddof=1) / math.sqrt(m) for m in (100, 400, 1600, 6400)]
record("monte_carlo_standard_error_scaling", abs(se[0] / se[-1] - 8) / 8 < 0.25, ratio=se[0] / se[-1])

(OUT / "validation_report.json").write_text(json.dumps(report, indent=2))
print(f"\n{sum(v['pass'] for v in report.values())}/{len(report)} validation checks passed -> {OUT / 'validation_report.json'}")
sys.exit(0 if all(v["pass"] for v in report.values()) else 1)
