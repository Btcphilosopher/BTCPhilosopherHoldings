`synthetic_strength_v1.*` — SYNTHETIC data for verifying the calibration code (parameter recovery). Not material data.
Regenerate with `python datasets/make_synthetic_dataset.py`. Real laboratory datasets follow `experiments/SCHEMA.md`.
