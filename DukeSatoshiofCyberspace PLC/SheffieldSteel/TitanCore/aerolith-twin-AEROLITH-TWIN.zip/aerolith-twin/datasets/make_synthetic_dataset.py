"""Generate a SYNTHETIC strength dataset for verifying the calibration machinery.

The numbers come from this software's own microstructure->strength model with perturbed 'true' parameters plus noise.
They are NOT material data and must never be used to calibrate for real material predictions.  The Parquet metadata and every
row say so.  Replace with laboratory data using the same schema (experiments/SCHEMA.md).
"""
from __future__ import annotations

import json
from pathlib import Path

import numpy as np
import pandas as pd

from aerolith.calibration.models import strength_from_microstructure
from aerolith.context import RunContext
from aerolith.io.parquet import write_table
from aerolith.params import default_registry

rng = np.random.default_rng(20261022)
truth = default_registry()
truth.override("str.k_y", 0.085); truth.override("str.alpha_taylor", 0.29); truth.override("str.eff.T1", 0.8)
rows = []
for i in range(60):
    rec = {"sample_id": f"SYN-{i:04d}", "Li": 1.0, "Cu": float(rng.uniform(3.4, 4.4)), "Mg": 0.4, "Ag": 0.4, "Zr": 0.12,
           "grain_size_um": float(rng.uniform(8, 150)), "grain_aspect_ratio": 1.0, "recrystallised_fraction": 1.0, "subgrain_size_um": 3.0,
           "dislocation_density_m2": float(10 ** rng.uniform(13, 14.5)), "T1_fraction": float(rng.uniform(0.01, 0.055)),
           "T1_radius_nm": float(rng.uniform(3, 10))}
    y = strength_from_microstructure(RunContext(truth), rec)["yield_strength"]
    s = 0.015 * y
    rec.update({"yield_strength": float(y + rng.normal(0, s)), "yield_strength_sigma": float(s), "provenance": "SYNTHETIC-FOR-SOFTWARE-VERIFICATION"})
    rows.append(rec)
df = pd.DataFrame(rows)
meta = {"dataset_id": "SYNTHETIC-strength-v1", "dataset_version": "1", "provenance": "SYNTHETIC-FOR-SOFTWARE-VERIFICATION",
        "warning": "generated from the software's own model; NOT material data",
        "true_parameters_used_to_generate": {"str.k_y": 0.085, "str.alpha_taylor": 0.29, "str.eff.T1": 0.8}}
here = Path(__file__).parent
write_table(df, here / "synthetic_strength_v1.parquet", meta)
df.to_csv(here / "synthetic_strength_v1.csv", index=False)
(here / "synthetic_strength_v1.meta.json").write_text(json.dumps(meta, indent=2))
exp = here.parent / "experiments"
for _, r in df.head(5).iterrows():
    doc = {"sample_id": r.sample_id, "provenance": "SYNTHETIC-FOR-SOFTWARE-VERIFICATION",
           "composition_wt": {e: float(r[e]) for e in ("Li", "Cu", "Mg", "Ag", "Zr")},
           "processing_history": "not recorded (synthetic microstructure-level record)", "heat_treatment": "not recorded",
           "microstructure": {k: float(r[k]) for k in ("grain_size_um", "dislocation_density_m2", "T1_fraction", "T1_radius_nm", "recrystallised_fraction")},
           "mechanical_properties": {"yield_strength_MPa": float(r.yield_strength)}, "inspection_results": "none",
           "measurement_uncertainty": {"yield_strength_MPa_1sigma": float(r.yield_strength_sigma)}}
    (exp / f"{r.sample_id}.json").write_text(json.dumps(doc, indent=2))
print("wrote", here / "synthetic_strength_v1.parquet", len(df), "rows")
