# Example: aerospace panel blank (Candidate A chemistry)

`python examples/aerospace_panel/run.py` (about 8-10 min; `--quick` for a smoke run) executes, from `sample.yaml`:

candidate composition → casting → homogenisation → rolling → solution treatment → quench + stretch → ageing → microstructure → properties → NDT → screening report

and writes `output/`:

| file | content |
|---|---|
| `report.html` | engineering report: material, process history/genealogy, thermal history, microstructure, properties, defects, inspection, uncertainty, twin scorecard, qualification **screening**, assumptions, model governance — every value labelled MEASURED/SIMULATED/ESTIMATED/ASSUMED |
| `result.json`, `result.h5` | complete machine-readable result (metadata: model_version, parameter_version, simulation_timestamp, input_hash, dataset_version, units, uncertainty) |
| `result_properties.{csv,parquet}`, `result_defects.{csv,parquet}`, `result_telemetry.parquet`, `result_assumptions.csv` | tables |
| `candidate_comparison.csv`, `candidate_pareto.png` | Candidates A–D with `NON-DOMINATED` / `DOMINATED` status — no "best alloy" |
| `process_sensitivity.{csv,png}` | local process sensitivities; robustness (yield probability, process windows) is printed |
| `pareto_front.{csv,png}` | non-dominated material/process combinations (composition + route as one vector) under a yield constraint |
| `microstructure_3d_STATISTICAL_REPRESENTATION.html` | optional 3-D statistical view (labelled; not atomistic) |

The acceptance criteria and property envelope in `sample.yaml` are **example inputs**, not standards. The result is never a qualification.
Most parameters are ILLUSTRATIVE placeholders (see the report's assumptions table): treat numbers as mechanism-level trends until calibrated.
