"""Complete AEROLITH-TWIN example: candidate composition -> casting -> homogenisation -> rolling -> solution treatment
-> quench -> ageing -> microstructure -> properties -> NDT -> qualification-screening report, with machine-readable results.

python examples/aerospace_panel/run.py [--quick]
"""
from __future__ import annotations

import argparse
import time
from pathlib import Path

import numpy as np

from aerolith.context import RunContext
from aerolith.digital_twin.twin import AerolithTwin, ProcessVariation, robustness
from aerolith.manufacturing.process_chain import run_route
from aerolith.optimisation.composition import compare_candidates
from aerolith.optimisation.process import Constraint, optimise_route
from aerolith.report import build_report
from aerolith.results import save_all
from aerolith.specs import load_spec
from aerolith.viz import figures as F
from aerolith.viz.microstructure3d import build_figure

ap = argparse.ArgumentParser()
ap.add_argument("--quick", action="store_true", help="small ensembles (fast smoke run)")
a = ap.parse_args()
here = Path(__file__).parent
out = here / "output"
out.mkdir(exist_ok=True)
spec = load_spec(here / "sample.yaml")
tw = AerolithTwin(seed=spec.options.seed)
n_ens, n_post = (6, 6) if a.quick else (spec.options.n_ensemble, spec.options.n_posterior)

t0 = time.time()
print("1/5  digital-twin run (chain, sensors, inspection, estimation, uncertainty, screening) ...")
run = tw.run(spec.composition, spec.route, spec.batch_id, n_ensemble=n_ens, n_posterior=n_post, criteria=spec.criteria,
             qual=spec.qualification, methods=spec.options.inspect_methods, frozen_time=spec.options.frozen_time)
paths = save_all(run, tw.registry, out, "result")
rp = build_report(run, tw.registry, out, "report")
build_figure(run.true_state.material).write_html(out / "microstructure_3d_STATISTICAL_REPRESENTATION.html", include_plotlyjs="cdn")
print("     report:", rp.name, f"({time.time() - t0:.0f} s)")

print("2/5  candidate comparison (Pareto status, no ranking) ...")
objs = ["specific_strength", "specific_modulus", "fracture_toughness", "fatigue_strength_1e7", "density", "corrosion_index", "complexity", "cost_usd_kg"]
cmp = compare_candidates(tw.registry, spec.route, objectives=objs)
cmp.to_csv(out / "candidate_comparison.csv")
F.pareto_plot(cmp, ["specific_strength", "fracture_toughness", "density", "cost_usd_kg"], "Candidates A-D: Pareto status over the stated objectives").savefig(out / "candidate_pareto.png", bbox_inches="tight")
print(cmp[["specific_strength", "fracture_toughness", "density", "cost_usd_kg", "pareto_status"]].round(2).to_string())

print("3/5  manufacturing robustness (Monte Carlo process variation) ...")
rob = robustness(tw.registry, spec.composition, spec.route, n=10 if a.quick else 40, var=ProcessVariation(), do_windows=not a.quick)
rob.sensitivities.to_csv(out / "process_sensitivity.csv", index=False)
F.sensitivity_bars(rob.sensitivities).savefig(out / "process_sensitivity.png", bbox_inches="tight")
print(f"     yield probability {rob.yield_probability:.2f} over envelope [{rob.envelope.source}]; windows: {rob.windows}")

print("4/5  route optimisation (composition + process as one vector) ...")
res, front, _ = optimise_route(tw.registry, ["specific_strength", "fracture_toughness", "cost_usd_kg"],
                               [Constraint("yield_strength", minimum=420.0)], pop=8 if a.quick else 16, gens=2 if a.quick else 6, seed=1)
front.to_csv(out / "pareto_front.csv", index=False)
F.pareto_plot(front, ["specific_strength", "fracture_toughness", "cost_usd_kg"], "Non-dominated material/process combinations").savefig(out / "pareto_front.png", bbox_inches="tight")
print(f"     {len(front)} non-dominated combinations from {res.n_evaluations} evaluations")

print(f"5/5  done in {time.time() - t0:.0f} s; outputs in {out}")
for k, v in {**paths, "report": rp}.items():
    print(f"     {k:20s} {v.relative_to(here.parent.parent)}")
_ = (np, run_route, RunContext)
