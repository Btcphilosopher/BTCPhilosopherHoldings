import pytest
from hypothesis import given, settings
from hypothesis import strategies as st

from aerolith.chemistry.composition import Composition
from aerolith.chemistry.phase_rules import expected_phases
from aerolith.chemistry.validation import check_composition
from aerolith.errors import CompositionError
from aerolith.properties.density import density_kg_m3


def test_balance_and_sum():
    c = Composition(Li=1.0, Cu=4.0)
    assert abs(sum(c.wt().values()) - 100.0) < 1e-9
    assert abs(c.Al - 95.0) < 1e-9


def test_sum_validation_with_configurable_tolerance():
    with pytest.raises(CompositionError):
        Composition(Al=90.0, Li=1.0, Cu=4.0)
    Composition(Al=94.9, Li=1.0, Cu=4.0, sum_tolerance_wt=0.2)  # within widened tolerance
    with pytest.raises(CompositionError):
        Composition(Li=60.0, Cu=50.0)


def test_atomic_fraction_roundtrip():
    c = Composition(Li=2.0, Cu=3.0, Mg=0.5)
    d = Composition.from_atomic_percent(**{k: v for k, v in c.at_percent().items() if k != "Al"})
    for e in c.wt():
        assert d.wt()[e] == pytest.approx(c.wt()[e], rel=1e-9, abs=1e-9)
    assert sum(c.at_fraction().values()) == pytest.approx(1.0)


@settings(max_examples=40, deadline=None)
@given(li=st.floats(0, 3), cu=st.floats(0, 5), mg=st.floats(0, 1.5), zr=st.floats(0, 0.2))
def test_hypothesis_roundtrip(li, cu, mg, zr):
    c = Composition(Li=li, Cu=cu, Mg=mg, Zr=zr)
    x = c.at_fraction()
    assert sum(x.values()) == pytest.approx(1.0)
    d = Composition.from_atomic_percent(**{k: 100 * v for k, v in x.items() if k != "Al"})
    assert d.Li == pytest.approx(c.Li, abs=1e-7)


def test_density_decreases_with_lithium_about_3_percent(ctx):
    r0 = density_kg_m3(ctx, Composition(Li=0.0)).value
    r1 = density_kg_m3(ctx, Composition(Li=1.0)).value
    assert 0.025 < (r0 - r1) / r0 < 0.035  # widely quoted ~3 %/wt% (r_Li is ILLUSTRATIVE, calibrate)


def test_density_has_uncertainty_and_provenance(ctx, comp_a):
    q = density_kg_m3(ctx, comp_a)
    assert q.sigma and q.sigma > 0 and q.provenance.value == "SIMULATED"


def test_screening_and_phase_rules(comp_a):
    assert any(i.severity == "INFO" for i in check_composition(comp_a))
    ph = {p.phase: p.likelihood for p in expected_phases(comp_a)}
    assert ph["T1 (Al2CuLi)"] == "expected" and ph["Al3Zr dispersoid"] == "expected"
