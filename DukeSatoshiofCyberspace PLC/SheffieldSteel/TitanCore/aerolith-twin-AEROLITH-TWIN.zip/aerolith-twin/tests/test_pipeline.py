import numpy as np
import pytest

from aerolith.context import RunContext
from aerolith.errors import ProvenanceError
from aerolith.manufacturing.process_chain import STAGES, run_route
from aerolith.manufacturing.spec import RouteSpec
from aerolith.provenance import Provenance, Quantity


def _run(registry, comp, route=None, seed=0, **kw):
    ctx = RunContext(registry, np.random.default_rng(seed))
    return run_route(ctx, comp, route or RouteSpec(), keep_snapshots=False, frozen_time="2026-01-01T00:00:00+00:00", **kw)


def test_full_chain_physically_plausible(registry, comp_a):
    ch = _run(registry, comp_a)
    v = ch.properties.values()
    assert 2600 < v["density"] < 2750
    assert 300 < v["yield_strength"] < 800 and v["uts"] > v["yield_strength"]
    assert 70 < v["E_L"] < 85
    assert v["elongation"] > 0 and v["fracture_toughness"] > 10
    assert ch.reached == "aged"


def test_reproducible_with_same_seed(registry, comp_a):
    a, b = _run(registry, comp_a, seed=5), _run(registry, comp_a, seed=5)
    assert a.properties.values() == b.properties.values()
    assert a.genealogy.to_dict()["nodes"][-1]["node_hash"] == b.genealogy.to_dict()["nodes"][-1]["node_hash"]


def test_genealogy_chain_and_tamper_detection(registry, comp_a):
    ch = _run(registry, comp_a)
    g = ch.genealogy
    kinds = [n.kind for n in g.nodes]
    assert kinds[:2] == ["MELT", "CAST"] and "AGEING" in kinds and "QUENCH" in kinds
    assert g.verify()
    g.nodes[3].parameters["T_K"] = 1.0
    assert not g.verify()


def test_each_stage_passes_state_forward(registry, comp_a):
    seen = []
    for s in STAGES:
        ch = _run(registry, comp_a, until=s, evaluate=False)
        seen.append(ch.state.stage)
    assert seen == ["cast", "homogenised", "rolled", "solution_treated", "quenched", "aged"]


def test_ageing_regimes_depend_on_time_and_are_not_hardcoded(registry, comp_a):
    r = RouteSpec()
    out = {}
    for h in (2.0, 48.0, 400.0):
        rr = r.model_copy(deep=True)
        rr.ageing.time_h = h
        ch = _run(registry, comp_a, rr)
        out[h] = (ch.stage_results["ageing"]["result"].regime, ch.properties.values()["yield_strength"])
    assert out[2.0][0] == "UNDER-AGED"
    assert out[2.0][1] < out[48.0][1]


def test_stretch_promotes_T1(registry, comp_a):
    r0, r3 = RouteSpec(), RouteSpec()
    r0.quench.stretch_percent = 0.0
    a, b = _run(registry, comp_a, r0), _run(registry, comp_a, r3)
    assert b.properties.values()["yield_strength"] > a.properties.values()["yield_strength"]


def test_burning_risk_flagged(registry, comp_a):
    r = RouteSpec()
    r.solution.temperature_C = 560.0
    ch = _run(registry, comp_a, r, until="solution_treated", evaluate=False)
    assert any("BURNING" in w or "INCIPIENT" in w for w in ch.warnings)


def test_unit_mistakes_are_rejected(registry, comp_a):
    r = RouteSpec()
    r.casting.pour_temperature_C = 1013.0  # kelvin typed into a degC field
    with pytest.raises(ValueError):
        _run(registry, comp_a, r)
    r2 = RouteSpec()
    r2.solution.temperature_C = 20.0
    with pytest.raises(ValueError):
        _run(registry, comp_a, r2, until="solution_treated", evaluate=False)


def test_assumed_cannot_masquerade_as_measured():
    q = Quantity("yield", 500.0, "MPa", 10.0, Provenance.SIMULATED)
    with pytest.raises(ProvenanceError):
        q.as_measured()
    assert Quantity("yield", 500.0, "MPa", 10.0, Provenance.MEASURED).as_measured()


def test_alloys_are_not_ranked_universally(registry):
    from aerolith.optimisation.composition import CANDIDATES, compare_candidates
    df = compare_candidates(registry, RouteSpec(), {k: CANDIDATES[k] for k in ("Candidate A", "Candidate B")},
                            ["specific_strength", "density", "cost_usd_kg"])
    assert set(df.pareto_status) <= {"NON-DOMINATED", "DOMINATED"}
    assert df.loc["Candidate B", "density"] < df.loc["Candidate A", "density"]  # Li-rich is lighter
    assert (df.pareto_status == "NON-DOMINATED").sum() >= 1
