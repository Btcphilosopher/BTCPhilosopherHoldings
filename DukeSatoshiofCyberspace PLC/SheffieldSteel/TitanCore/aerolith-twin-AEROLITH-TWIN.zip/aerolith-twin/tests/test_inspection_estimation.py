import numpy as np
import pytest

from aerolith.context import RunContext
from aerolith.digital_twin.estimation import (
    KalmanFilter,
    estimate_hold_temperature,
    gaussian_update,
    importance_posterior,
)
from aerolith.digital_twin.telemetry import SensorSpec, measure
from aerolith.inspection import eddy_current as ect
from aerolith.inspection import radiography as rt
from aerolith.inspection import ultrasonic as us
from aerolith.inspection.defect_detection import AcceptanceCriteria, inspect_batch
from aerolith.inspection.microscopy import measure_grain_size
from aerolith.manufacturing.process_chain import run_route
from aerolith.manufacturing.spec import RouteSpec
from aerolith.microstructure.defects import Defect, DefectType


@pytest.fixture(scope="module")
def chain(registry, comp_a):
    ctx = RunContext(registry, np.random.default_rng(2))
    return ctx, run_route(ctx, comp_a, RouteSpec(), keep_snapshots=False)


def test_pod_monotonic_in_size(chain):
    ctx, ch = chain
    sizes = np.array([0.2, 0.5, 1.0, 2.0, 5.0]) * 1e-3
    for dt in (DefectType.CRACK,):
        p = us.pod_curve(ctx, ch.state, us.UTSettings(), sizes, dt)
        assert np.all(np.diff(p) >= -1e-9) and p[-1] > p[0]
    for mod, settings in ((rt, rt.RTSettings()),):
        ps = [mod.pod(ctx, ch.state, Defect(0, DefectType.VOID, s, (0.5, 0.5, 0.5), (1, 0, 0), 4.0), settings) for s in sizes]
        assert np.all(np.diff(ps) >= -1e-9)
    pe = [ect.pod(ctx, ch.state, Defect(0, DefectType.CRACK, s, (0.5, 0.5, 0.01), (0, 0, 1), 3.0, surface=True), ect.ECTSettings()) for s in sizes]
    assert np.all(np.diff(pe) >= -1e-9)


def test_ultrasonic_attenuation_grows_with_grain_size(chain):
    ctx, ch = chain
    st = ch.state.copy()
    a1 = us.attenuation_np_m(ctx, st, 5e6)
    st.grains.d_N *= 3  # Rayleigh/stochastic regime: attenuation rises with grain size
    assert us.attenuation_np_m(ctx, st, 5e6) > a1
    assert us.attenuation_np_m(ctx, st, 10e6) > a1  # and with frequency


def test_surface_dead_zone(chain):
    ctx, ch = chain
    d = Defect(0, DefectType.CRACK, 5e-3, (0.5, 0.5, 0.01), (0, 0, 1), 3.0)
    assert us.pod(ctx, ch.state, d, us.UTSettings()) == 0.0


def test_inspection_bookkeeping_and_no_invented_criteria(chain):
    ctx, ch = chain
    nd = inspect_batch(ctx, ch.state, ["UT", "RT"], None, 2700.0)
    assert nd.n_detected + len(nd.missed_ids) == nd.n_true
    assert nd.rejected is None  # no acceptance criterion supplied -> not assessed
    crit = AcceptanceCriteria("test", {"crack": 1e-4}, "unit test")
    nd2 = inspect_batch(ctx, ch.state, ["UT", "RT", "ECT"], crit, 2700.0)
    assert nd2.rejected in (True, False)


def test_virtual_microscopy_unbiased_and_labelled(chain):
    ctx, ch = chain
    vals = [measure_grain_size(RunContext(ctx.registry, np.random.default_rng(i)), ch.state, 400).equivalent_size_m.value for i in range(60)]
    truth = ch.state.grains.mean_size_m
    assert np.mean(vals) == pytest.approx(truth, rel=0.03)
    q = measure_grain_size(ctx, ch.state).equivalent_size_m
    assert q.provenance.value == "SIMULATED"  # synthetic measurement never claims to be MEASURED


def test_sensor_model_bias_noise_drift_resolution_missing():
    rng = np.random.default_rng(0)
    spec = SensorSpec("T", "K", bias=2.0, noise_sigma=0.5, drift_per_hour=1.0, resolution=0.5, sampling_hz=1.0, missing_prob=0.1)
    t = np.linspace(0, 7200, 50)
    df = measure(spec, t, np.full(50, 700.0), rng)
    assert len(df) > 7000
    miss = df.y_meas.isna().mean()
    assert 0.07 < miss < 0.13
    ok = df.dropna()
    assert (ok.y_meas % 0.5).abs().max() < 1e-9 or np.allclose(np.mod(ok.y_meas, 0.5), 0, atol=1e-9)
    early, late = ok[ok.t_s < 600].y_meas.mean(), ok[ok.t_s > 6600].y_meas.mean()
    assert late - early == pytest.approx(1.0 * (6900 - 300) / 3600, abs=0.15)  # drift
    assert early - 700 == pytest.approx(2.0 + 0.5 * 300 / 3600, abs=0.2)  # bias


def test_kalman_reduces_uncertainty_and_estimates_constant():
    rng = np.random.default_rng(1)
    kf = KalmanFilter(np.eye(1), np.eye(1), np.zeros((1, 1)), np.array([[4.0]]), np.array([0.0]), np.array([[100.0]]))
    for z in 10.0 + rng.normal(0, 2.0, 200):
        x, P = kf.step(z)
    assert abs(x[0] - 10.0) < 0.5 and P[0, 0] < 0.05


def test_hold_temperature_estimate_includes_bias_uncertainty():
    rng = np.random.default_rng(2)
    spec = SensorSpec("T", "K", bias=0.0, noise_sigma=0.5, sampling_hz=0.1)
    df = measure(spec, np.array([0.0, 3600.0]), np.array([438.0, 438.0]), rng)
    e = estimate_hold_temperature(df, spec)
    assert abs(e.mean_temperature_K - 438.0) < 1.0
    assert e.sigma_K > 0.5  # bias is not observable from one sensor: its prior uncertainty remains


def test_gaussian_update_and_importance_posterior():
    m, s = gaussian_update(500.0, 20.0, 480.0, 10.0)
    assert 480 < m < 500 and s < 10
    rng = np.random.default_rng(0)
    obs_var = rng.normal(0, 1, 4000)
    out = importance_posterior(2.0 * obs_var + 5.0, {"x": obs_var}, {"x": (1.0, 0.2)})
    assert out["mean"] == pytest.approx(7.0, abs=0.3) and out["sigma"] < 1.0
