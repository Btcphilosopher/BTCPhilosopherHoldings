import numpy as np
import pytest

from aerolith.chemistry.composition import Composition
from aerolith.context import RunContext
from aerolith.params import default_registry


@pytest.fixture(scope="session")
def registry():
    return default_registry()


@pytest.fixture()
def ctx(registry):
    return RunContext(registry, np.random.default_rng(1))


@pytest.fixture(scope="session")
def comp_a():
    return Composition(Li=1.0, Cu=4.0, Mg=0.4, Ag=0.4, Zr=0.12, label="A")
