import json

import numpy as np
import pandas as pd
import pytest

from aerolith.optimisation.multiobjective import (
    crowding_distance,
    dominates,
    hypervolume_2d,
    non_dominated_sort,
    nsga2,
    pareto_mask,
)


def test_dominance_and_fronts():
    F = np.array([[1.0, 4.0], [2.0, 2.0], [4.0, 1.0], [3.0, 3.0], [5.0, 5.0]])
    assert dominates(F[1], F[3]) and not dominates(F[0], F[1])
    m = pareto_mask(F)
    assert m.tolist() == [True, True, True, False, False]
    fr = non_dominated_sort(F)
    assert set(fr[0]) == {0, 1, 2} and fr[1] == [3] and fr[2] == [4]
    cd = crowding_distance(F[:3])
    assert np.isinf(cd[0]) and np.isinf(cd[2]) and np.isfinite(cd[1])


def test_constraint_dominance():
    F = np.array([[1.0, 1.0], [2.0, 2.0]])
    fr = non_dominated_sort(F, np.array([1.0, 0.0]))  # first violates a constraint
    assert fr[0] == [1]


def test_nsga2_finds_zdt1_front():
    d = 6
    def zdt1(x):
        g = 1 + 9 * np.mean(x[1:])
        return np.array([x[0], g * (1 - np.sqrt(x[0] / g))]), 0.0
    res = nsga2(zdt1, np.zeros(d), np.ones(d), pop=40, gens=40, seed=1)
    F = res.F[res.fronts[0]]
    true_f2 = 1 - np.sqrt(F[:, 0])
    assert np.mean(F[:, 1] - true_f2) < 0.15
    assert hypervolume_2d(F, np.array([1.1, 1.1])) > 0.55  # ideal front HV ~ 0.77


def test_save_all_formats_and_metadata(tmp_path, registry, comp_a):
    from aerolith.digital_twin.twin import AerolithTwin
    from aerolith.io.hdf5 import REQUIRED_META, read_hdf5_meta, write_hdf5
    from aerolith.io.parquet import read_table
    from aerolith.manufacturing.spec import RouteSpec
    from aerolith.results import save_all
    tw = AerolithTwin(registry)
    run = tw.run(comp_a, RouteSpec())
    paths = save_all(run, registry, tmp_path)
    for k in ("json", "hdf5", "parquet_properties", "parquet_defects", "csv_properties", "csv_defects"):
        assert paths[k].exists() and paths[k].stat().st_size > 0, k
    meta = read_hdf5_meta(paths["hdf5"])
    for k in REQUIRED_META:
        assert k in meta
    doc = json.loads(paths["json"].read_text())
    for k in ("model_version", "parameter_version", "simulation_timestamp", "input_hash", "dataset_version", "units", "uncertainty"):
        assert k in doc["metadata"]
    df, pm = read_table(paths["parquet_properties"])
    assert {"value", "unit", "sigma", "provenance"} <= set(df.columns) and pm["parameter_version"] == meta["parameter_version"]
    assert set(df.provenance) == {"SIMULATED"}  # no simulated value may carry MEASURED
    with pytest.raises(ValueError):
        write_hdf5(tmp_path / "bad.h5", {"model_version": "x"}, {}, {})


def test_cli_simulate(tmp_path, capsys):
    from aerolith.cli import main
    spec = tmp_path / "alloy.yaml"
    spec.write_text("composition_wt: {Li: 1.0, Cu: 4.0, Mg: 0.4, Ag: 0.4, Zr: 0.12}\nlabel: t\n")
    assert main(["simulate", str(spec), "--outdir", str(tmp_path / "o")]) == 0
    assert (tmp_path / "o" / "alloy_homogenised.json").exists()
    assert "stage reached: homogenised" in capsys.readouterr().out


def test_cli_strict_mode_refuses_illustrative(tmp_path):
    from aerolith.cli import main
    from aerolith.errors import StrictModeError
    spec = tmp_path / "a.yaml"
    spec.write_text("composition_wt: {Li: 1.0, Cu: 4.0, Zr: 0.12}\n")
    with pytest.raises(StrictModeError):
        main(["simulate", str(spec), "--outdir", str(tmp_path), "--strict"])


def test_calibration_recovers_parameters_on_synthetic_data(registry):
    from aerolith.calibration.models import strength_from_microstructure
    from aerolith.calibration.parameter_fit import calibrate
    from aerolith.context import RunContext
    rng = np.random.default_rng(4)
    truth = registry.copy()
    truth.override("str.k_y", 0.09)
    truth.override("str.alpha_taylor", 0.31)
    rows = []
    for i in range(36):
        rec = {"sample_id": f"S{i:03d}", "Li": 1.0, "Cu": 3.6 + 0.8 * rng.random(), "Mg": 0.4, "Ag": 0.4, "Zr": 0.12,
               "grain_size_um": float(rng.uniform(8, 120)), "grain_aspect_ratio": 1.0, "recrystallised_fraction": 1.0, "subgrain_size_um": 3.0,
               "dislocation_density_m2": float(10 ** rng.uniform(13, 14.4)), "T1_fraction": float(rng.uniform(0.01, 0.05)), "T1_radius_nm": float(rng.uniform(3, 9))}
        y = strength_from_microstructure(RunContext(truth), rec)["yield_strength"]
        rec["yield_strength"] = y + rng.normal(0, 2.0)
        rec["yield_strength_sigma"] = 2.0
        rows.append(rec)
    df = pd.DataFrame(rows)
    res = calibrate(registry, df, strength_from_microstructure, ["str.k_y", "str.alpha_taylor"], ["yield_strength"], {"yield_strength": "yield_strength_sigma"},
                    dataset_id="SYNTHETIC-test", validation_fraction=0.3)
    assert res.n_validation > 4 and res.n_train > 15
    assert res.validation_rmse["yield_strength"] < 8.0  # held-out data predicted within a few MPa
    assert res.calibrated_registry.get("str.k_y").status.value == "CALIBRATED"
    assert registry.get("str.k_y").status.value != "CALIBRATED"  # the base registry is untouched
