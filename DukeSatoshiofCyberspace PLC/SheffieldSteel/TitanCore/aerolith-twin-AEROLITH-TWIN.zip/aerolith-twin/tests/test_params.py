import numpy as np
import pytest

from aerolith.context import RunContext
from aerolith.errors import ParameterUnknownError, StrictModeError
from aerolith.params import Status, default_registry
from aerolith.properties.fracture import paris_growth_rate


def test_every_parameter_documented(registry):
    for n in registry.names():
        p = registry.get(n)
        assert p.units and p.source and isinstance(p.status, Status), n
        if p.status is Status.UNKNOWN:
            assert p.value is None, f"{n}: UNKNOWN parameters must not carry a value"
        if p.value is not None and p.valid_min is not None:
            assert p.valid_min <= p.value, n
        if p.value is not None and p.valid_max is not None:
            assert p.value <= p.valid_max, n
        if p.log_scale:
            assert p.uncertainty < 3.0 and (p.value is None or p.value > 0), n


def test_unknown_parameter_raises_not_invented(ctx):
    with pytest.raises(ParameterUnknownError):
        paris_growth_rate(ctx, 10.0)


def test_unknown_can_be_supplied(registry):
    reg = registry.copy()
    reg.override("frac.paris_C", 1e-11, Status.USER_SUPPLIED, source="test dataset")
    reg.override("frac.paris_m", 3.0, Status.USER_SUPPLIED, source="test dataset")
    ctx = RunContext(reg)
    assert paris_growth_rate(ctx, 10.0) == pytest.approx(1e-11 * 1000.0)


def test_strict_mode_blocks_illustrative(registry):
    ctx = RunContext(registry, strict=True)
    with pytest.raises(StrictModeError):
        ctx.p("precip.T1.gamma")
    assert ctx.p("thermo.molar_volume") > 0  # REFERENCE is allowed


def test_sampling_respects_bounds_and_version(registry):
    rng = np.random.default_rng(0)
    s = registry.sampled(rng)
    for n in registry.names():
        p = s.get(n)
        if p.value is not None and p.valid_min is not None:
            assert p.value >= p.valid_min - 1e-12
    assert s.version() != registry.version()
    assert default_registry().version() == registry.version()


def test_ledger_records_status(registry):
    ctx = RunContext(registry)
    ctx.p("precip.T1.gamma")
    ctx.p("thermo.molar_volume")
    assert ctx.ledger_summary() == {"ILLUSTRATIVE": 1, "REFERENCE": 1}


def test_yaml_roundtrip(tmp_path, registry):
    reg = registry.copy()
    reg.override("str.k_y", 0.07, Status.CALIBRATED, source="unit test")
    f = tmp_path / "p.yaml"
    reg.to_yaml(f)
    from aerolith.params import ParameterRegistry
    back = ParameterRegistry.from_yaml(f)
    assert back.value("str.k_y") == 0.07 and back.get("str.k_y").status is Status.CALIBRATED
