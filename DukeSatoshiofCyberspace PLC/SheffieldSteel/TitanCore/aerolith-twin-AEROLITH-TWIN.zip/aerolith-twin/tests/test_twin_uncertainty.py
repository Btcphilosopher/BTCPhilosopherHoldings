import pytest

from aerolith.digital_twin.twin import (
    AerolithTwin,
    ProcessVariation,
    PropertyEnvelope,
    robustness,
    run_ensemble,
    uncertainty_report,
)
from aerolith.manufacturing.spec import RouteSpec


@pytest.mark.slow
def test_ensemble_has_spread_from_each_source(registry, comp_a):
    var = ProcessVariation(model_scale=0.3)
    sds = {}
    for s in ("composition", "temperature", "processing", "model"):
        m = run_ensemble(registry, comp_a, RouteSpec(), 8, (s,), var, seed=3)
        sds[s] = m["yield_strength"].std(ddof=1)
    assert all(v > 0 for v in sds.values()), sds


@pytest.mark.slow
def test_uncertainty_report_structure(registry, comp_a):
    rep = uncertainty_report(registry, comp_a, RouteSpec(), n=8, per_source=False, outputs=["yield_strength", "density"])
    t = rep.table
    assert {"mean", "sigma_total", "ci95_lo", "ci95_hi"} <= set(t.columns)
    assert t.loc["yield_strength", "ci95_hi"] > t.loc["yield_strength", "ci95_lo"]


@pytest.mark.slow
def test_robustness_penalises_narrow_window(registry, comp_a):
    r = RouteSpec()
    base = robustness(registry, comp_a, r, n=10, var=ProcessVariation(), do_windows=False)
    tight = PropertyEnvelope({"yield_strength": (base.members["yield_strength"].mean() * 1.15, None)})
    strict = robustness(registry, comp_a, r, n=10, envelope=tight, do_windows=False)
    assert strict.yield_probability < base.yield_probability or base.yield_probability == 0
    assert 0.0 <= base.robustness_index <= 1.0 and len(base.sensitivities) >= 5


def test_twin_separates_true_measured_estimated(registry, comp_a):
    tw = AerolithTwin(registry)
    run = tw.run(comp_a, RouteSpec())
    assert run.true_state.material is run.true_state.chain.state
    assert not run.measured.telemetry.empty and {"y_true", "y_meas"} <= set(run.measured.telemetry.columns)
    assert "ageing" in run.estimated.process
    e = run.estimated.process["ageing"]
    assert abs(e["estimated_T_K"] - e["true_hold_T_K_for_validation"]) < 6 * e["sigma_K"] + 3.0
    assert set(run.scorecard) == {"MATERIAL STATE", "PROCESS STATE", "CONFIDENCE"}
    assert "NOT QUALIFIED" in __import__("aerolith.digital_twin.qualification", fromlist=["x"]).QUAL_STATEMENT
