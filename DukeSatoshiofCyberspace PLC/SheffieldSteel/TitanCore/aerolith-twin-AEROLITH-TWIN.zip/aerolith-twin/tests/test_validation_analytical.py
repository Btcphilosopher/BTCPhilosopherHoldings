"""Independent analytical / numerical validation of the building blocks."""
import math

import numpy as np
import pytest
from scipy.special import erfc

from aerolith.casting.cooling import lumped_cooling
from aerolith.homogenisation.diffusion import D_arrhenius, cosine_modes_evolve, sinusoid_amplitude_decay
from aerolith.homogenisation.thermal_cycle import ThermalCycle
from aerolith.microstructure.grains import GrainState
from aerolith.microstructure.state import MaterialState
from aerolith.microstructure.texture import TextureState, component_taylor_factors, textured_elastic
from aerolith.numerics import observed_order, slab_conduction_implicit
from aerolith.properties.strength import grain_boundary
from aerolith.units import R_GAS, arrhenius


def test_arrhenius_exact_and_slope():
    assert arrhenius(2.0e-5, 1.3e5, 700.0) == pytest.approx(2.0e-5 * math.exp(-1.3e5 / (R_GAS * 700.0)))
    T = np.array([600.0, 700.0, 800.0])
    D = np.array([D_arrhenius(1e-5, 1.5e5, t) for t in T])
    slope = np.polyfit(1.0 / T, np.log(D), 1)[0]
    assert slope == pytest.approx(-1.5e5 / R_GAS, rel=1e-9)
    with pytest.raises(ValueError):
        arrhenius(1.0, 1e5, 25.0 - 25.0)  # temperature must be kelvin and > 0


def test_diffusion_sinusoid_matches_analytical():
    L, n = 5e-5, 256
    x = (np.arange(n) + 0.5) / n * L
    prof = 4.0 + 1.0 * np.cos(np.pi * x / L)  # half-wavelength = L  -> wavelength 2L
    Dt = 3e-15
    out = cosine_modes_evolve(prof, L, Dt)
    expect = 4.0 + 1.0 * np.cos(np.pi * x / L) * sinusoid_amplitude_decay(Dt, 2 * L)
    assert np.max(np.abs(out - expect)) < 1e-6
    assert out.mean() == pytest.approx(prof.mean(), rel=1e-12)  # solute conservation


def test_diffusion_variable_temperature_uses_integral():
    cyc = ThermalCycle(np.array([0.0, 3600.0, 7200.0]), np.array([700.0, 760.0, 700.0]))
    I = cyc.effective_diffusion_integral(1e-4, 1.3e5, n=20000)
    t = np.linspace(0, 7200, 200001)
    ref = np.trapezoid(1e-4 * np.exp(-1.3e5 / (R_GAS * cyc.T_at(t))), t)
    assert I == pytest.approx(ref, rel=1e-4)


def test_heat_transfer_lumped_limit():
    # low-Biot slab vs lumped capacitance
    k, rho, cp, half, h = 150.0, 2700.0, 900.0, 0.005, 50.0
    alpha = k / (rho * cp)
    n = 21
    dx = half / (n - 1)
    T = np.full(n, 800.0)
    t, dt = 0.0, 0.05
    while t < 60.0:
        T = slab_conduction_implicit(T, dx, dt, alpha, h, 300.0, k)
        t += dt
    ref = lumped_cooling(800.0, 300.0, h, half, rho, cp, 60.0)
    assert abs(T.mean() - ref) < 1.0
    assert (T.max() - T.min()) < 0.5  # Bi = h L/k ~ 1.7e-3


def test_heat_transfer_semi_infinite_exact_and_convergence():
    k, rho, cp, h = 150.0, 2700.0, 900.0, 8000.0
    alpha = k / (rho * cp)
    half, n = 0.2, 401  # thick enough to be semi-infinite for t = 2 s
    dx = half / (n - 1)
    t_end = 2.0
    errs, dts = [], [0.2, 0.1, 0.05, 0.025]
    for dt in dts:
        T = np.full(n, 800.0)
        for _ in range(int(round(t_end / dt))):
            T = slab_conduction_implicit(T, dx, dt, alpha, h, 300.0, k)
        beta = h * math.sqrt(alpha * t_end) / k
        Ts_exact = 800.0 - 500.0 * (1.0 - math.exp(beta**2) * erfc(beta))
        errs.append(abs(T[0] - Ts_exact))
    assert errs[-1] < 2.0
    assert 0.7 < observed_order(np.array(dts), np.array(errs)) < 1.4  # backward Euler: first order in dt


def test_hall_petch_slope():
    from aerolith.context import RunContext
    from aerolith.params import default_registry
    ctx = RunContext(default_registry())
    ky = ctx.p("str.k_y")
    vals = []
    for d in (10e-6, 40e-6, 160e-6):
        st = MaterialState(None, (1, 1, 1))  # type: ignore[arg-type]
        st.grains = GrainState(d, d, d, 0.4, recrystallised_fraction=1.0)
        vals.append(grain_boundary(ctx, st))
    inv_sqrt = np.array([10e-6, 40e-6, 160e-6]) ** -0.5
    slope = np.polyfit(inv_sqrt, vals, 1)[0]
    assert slope == pytest.approx(ky, rel=1e-6)


def test_energy_balance_casting(registry, comp_a):
    from aerolith.casting.solidification import CastingInputs, simulate_solidification
    from aerolith.context import RunContext
    ctx = RunContext(registry)
    r = simulate_solidification(ctx, comp_a, CastingInputs(1013.0, 330.0, 0.1), n_nodes=30)
    assert r.energy_balance_error < 1e-9


def test_casting_mesh_independence(registry, comp_a):
    from aerolith.casting.solidification import CastingInputs, simulate_solidification
    from aerolith.context import RunContext
    t = []
    for n in (20, 40, 80):
        r = simulate_solidification(RunContext(registry), comp_a, CastingInputs(1013.0, 330.0, 0.1), n_nodes=n)
        t.append(r.local_solidification_time_s[-1])
    assert abs(t[2] - t[1]) < abs(t[1] - t[0]) + 1e-9
    assert abs(t[2] - t[1]) / t[2] < 0.03


def test_solute_mass_balance_in_precipitation(registry, comp_a):
    from aerolith.context import RunContext
    from aerolith.heat_treatment import ageing
    from aerolith.manufacturing.process_chain import run_route
    from aerolith.manufacturing.spec import RouteSpec
    from aerolith.thermodynamics.equilibrium import PHASES, SOLUTE_INDEX
    ctx = RunContext(registry, np.random.default_rng(0))
    ch = run_route(ctx, comp_a, RouteSpec(), keep_snapshots=False)
    st = ch.state
    # total solute in precipitates can never exceed what the pool contained
    for el, i in SOLUTE_INDEX.items():
        held = sum(st.precip.volume_fraction(p.key) * p.s[i] for p in PHASES)
        assert held <= st.solute_pool_at.get(el, 0.0) * 1.0005 + 1e-12, el
    assert ageing is not None


def test_taylor_factor_random_polycrystal():
    tf = component_taylor_factors()["Random"]
    for d in ("L", "T", "D"):
        assert tf[d] == pytest.approx(3.06, abs=0.12)


def test_elastic_random_matches_aluminium():
    r = textured_elastic({"Random": 1.0})
    assert 69e9 < r.E_iso < 73e9 and 0.33 < r.nu_iso < 0.36
    c = textured_elastic({"Cube": 1.0})
    assert c.E_L < r.E_iso  # <100> is the compliant direction of Al
    G = r.E_iso / (2 * (1 + r.nu_iso))
    assert G == pytest.approx(r.G_iso, rel=0.03)  # isotropic relation G = E/(2(1+nu))


def test_texture_changes_directional_modulus():
    base = TextureState()
    rolled = TextureState({"Brass": 0.4, "S": 0.3, "Copper": 0.3, "Random": 0.0})
    assert abs(rolled.taylor_factor("L") - rolled.taylor_factor("T")) > 0.02
    assert base.taylor_factor("L") == pytest.approx(base.taylor_factor("T"), abs=0.15)


def test_monte_carlo_convergence():
    rng = np.random.default_rng(3)
    x = rng.normal(500.0, 20.0, 20000)
    se = [x[:n].std(ddof=1) / math.sqrt(n) for n in (100, 400, 1600, 6400)]
    assert se[0] / se[-1] == pytest.approx(8.0, rel=0.25)


def test_equilibrium_conserves_solute_and_respects_solubility(registry):
    from aerolith.context import RunContext
    from aerolith.thermodynamics.equilibrium import K_of_T, equilibrium
    ctx = RunContext(registry)
    c0 = {"Li": 0.0387, "Cu": 0.0169, "Zr": 3.5e-4, "Sc": 0.0}
    for T in (298.0, 438.0, 600.0, 783.0):
        r = equilibrium(ctx, c0, T)
        # the Li-Cu system and the independent Zr dispersoid system each conserve their own solute
        phi_c = r.phi["delta_prime"] + r.phi["T1"] + r.phi["theta_prime"]
        for el, s_i, phi in (("Li", {"delta_prime": 0.25, "T1": 0.25}, phi_c), ("Cu", {"T1": 0.25, "theta_prime": 1 / 3}, phi_c),
                             ("Zr", {"Al3Zr": 0.25}, r.phi["Al3Zr"])):
            held = sum(r.phi[k] * v for k, v in s_i.items())
            assert (r.matrix[el] * (1 - phi) + held) == pytest.approx(c0[el], rel=1e-6)
        assert r.matrix["Li"] <= K_of_T(ctx, "delta_prime", T) * (1 + 1e-6)
