"""Strongly typed alloy composition (wt%) with atomic-fraction support."""

from __future__ import annotations

import hashlib
import json

from pydantic import BaseModel, ConfigDict, Field, model_validator

from ..errors import CompositionError
from .elements import ATOMIC_MASS_G_MOL, ELEMENTS, SOLUTES

DEFAULT_SUM_TOLERANCE_WT = 0.05


class Composition(BaseModel):
    """Alloy composition in weight percent.

    ``Al`` may be omitted, in which case it is the balance.  If given, the total
    must be within ``sum_tolerance_wt`` of 100.  ``uncertainty_wt`` holds 1-sigma
    analytical uncertainties (e.g. OES) per element for Monte Carlo propagation.
    """

    model_config = ConfigDict(frozen=True, extra="forbid")

    Al: float | None = Field(default=None, ge=0.0)
    Li: float = Field(default=0.0, ge=0.0)
    Cu: float = Field(default=0.0, ge=0.0)
    Mg: float = Field(default=0.0, ge=0.0)
    Zn: float = Field(default=0.0, ge=0.0)
    Ag: float = Field(default=0.0, ge=0.0)
    Zr: float = Field(default=0.0, ge=0.0)
    Sc: float = Field(default=0.0, ge=0.0)
    Mn: float = Field(default=0.0, ge=0.0)
    Fe: float = Field(default=0.0, ge=0.0)
    Si: float = Field(default=0.0, ge=0.0)
    Ti: float = Field(default=0.0, ge=0.0)
    sum_tolerance_wt: float = Field(default=DEFAULT_SUM_TOLERANCE_WT, gt=0.0)
    uncertainty_wt: dict[str, float] = Field(default_factory=dict)
    label: str = ""

    @model_validator(mode="before")
    @classmethod
    def _fill_balance(cls, data):  # type: ignore[no-untyped-def]
        if isinstance(data, dict) and data.get("Al") is None:
            solutes = sum(float(data.get(e, 0.0)) for e in SOLUTES)
            if solutes >= 100.0:
                raise CompositionError(f"solute total {solutes:.3f} wt% leaves no aluminium balance")
            data = {**data, "Al": 100.0 - solutes}
        return data

    @model_validator(mode="after")
    def _check_sum(self) -> Composition:
        total = sum(self.wt().values())
        if abs(total - 100.0) > self.sum_tolerance_wt:
            raise CompositionError(
                f"composition sums to {total:.4f} wt% (tolerance ±{self.sum_tolerance_wt} wt%)"
            )
        for k in self.uncertainty_wt:
            if k not in ELEMENTS:
                raise CompositionError(f"unknown element '{k}' in uncertainty_wt")
        return self

    # -- views ----------------------------------------------------------------
    def wt(self) -> dict[str, float]:
        return {e: float(getattr(self, e) or 0.0) for e in ELEMENTS}

    def present(self) -> dict[str, float]:
        return {e: v for e, v in self.wt().items() if v > 0.0}

    def at_fraction(self) -> dict[str, float]:
        moles = {e: w / ATOMIC_MASS_G_MOL[e] for e, w in self.wt().items()}
        tot = sum(moles.values())
        return {e: m / tot for e, m in moles.items()}

    def at_percent(self) -> dict[str, float]:
        return {e: 100.0 * x for e, x in self.at_fraction().items()}

    def solute_wt_total(self) -> float:
        return sum(v for e, v in self.wt().items() if e != "Al")

    # -- construction ---------------------------------------------------------
    @classmethod
    def from_atomic_percent(cls, **at_pct: float) -> Composition:
        """Build from solute atomic percent (Al = balance)."""
        solutes = {e: float(v) for e, v in at_pct.items() if e != "Al"}
        x_al = 1.0 - sum(solutes.values()) / 100.0
        if x_al <= 0:
            raise CompositionError("solute atomic percent >= 100")
        mass = {e: (v / 100.0) * ATOMIC_MASS_G_MOL[e] for e, v in solutes.items()}
        mass["Al"] = x_al * ATOMIC_MASS_G_MOL["Al"]
        tot = sum(mass.values())
        return cls(**{e: 100.0 * m / tot for e, m in mass.items()})  # type: ignore[arg-type]

    def with_changes(self, **kw: float) -> Composition:
        d = self.model_dump()
        d.update(kw)
        if "Al" not in kw:
            d["Al"] = None
        return Composition(**d)

    def content_hash(self) -> str:
        blob = json.dumps({k: round(v, 6) for k, v in self.wt().items()}, sort_keys=True).encode()
        return hashlib.sha256(blob).hexdigest()[:12]

    def perturbed(self, rng) -> Composition:  # type: ignore[no-untyped-def]
        """Draw an analytical-uncertainty realisation (Al re-balanced)."""
        d = {}
        for e in SOLUTES:
            v = getattr(self, e)
            s = self.uncertainty_wt.get(e, 0.0)
            d[e] = max(0.0, float(v + rng.normal(0.0, s))) if (s > 0 and v > 0) else v
        return Composition(**d, sum_tolerance_wt=self.sum_tolerance_wt,  # type: ignore[arg-type]
                           uncertainty_wt=self.uncertainty_wt, label=self.label)

    def __str__(self) -> str:
        return " ".join(f"{e}{v:.3g}" for e, v in self.present().items()) + " (wt%)"
