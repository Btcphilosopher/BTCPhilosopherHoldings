"""Composition screening.  These are screening heuristics, NOT product specifications."""

from __future__ import annotations

from dataclasses import dataclass

from .composition import Composition

# Typical envelope for wrought Al-Li-Cu(-Mg-Ag-Zn) aerospace chemistries (screening only).
SCREEN_RANGES_WT: dict[str, tuple[float, float]] = {
    "Li": (0.0, 3.0), "Cu": (0.0, 5.0), "Mg": (0.0, 1.8), "Zn": (0.0, 1.5), "Ag": (0.0, 0.8),
    "Zr": (0.0, 0.2), "Sc": (0.0, 0.3), "Mn": (0.0, 0.6), "Fe": (0.0, 0.15), "Si": (0.0, 0.12),
    "Ti": (0.0, 0.15),
}


@dataclass
class Issue:
    severity: str  # "INFO" | "WARNING" | "ERROR"
    message: str


def check_composition(c: Composition) -> list[Issue]:
    issues: list[Issue] = []
    wt = c.wt()
    for e, (lo, hi) in SCREEN_RANGES_WT.items():
        if not lo <= wt[e] <= hi:
            issues.append(Issue("WARNING", f"{e}={wt[e]:.3g} wt% outside screening envelope [{lo}, {hi}]"))
    if wt["Li"] == 0.0:
        issues.append(Issue("INFO", "no lithium: not an Al-Li alloy; density benefit of Li absent"))
    if wt["Li"] > 0 and wt["Zr"] + wt["Sc"] == 0:
        issues.append(Issue("WARNING", "no Zr/Sc dispersoid former: recrystallisation control will be weak"))
    if wt["Fe"] + wt["Si"] > 0.2:
        issues.append(Issue("WARNING", "Fe+Si > 0.2 wt%: constituent particle population will reduce toughness"))
    if wt["Cu"] > 0 and wt["Li"] > 0:
        r = wt["Cu"] / wt["Li"]
        issues.append(Issue("INFO", f"Cu/Li weight ratio = {r:.2f} (controls T1 vs theta'/delta' balance)"))
    if wt["Mg"] > 0 and wt["Zn"] > 0 and wt["Cu"] > 0:
        issues.append(Issue("INFO", "Cu+Mg+Zn present: multi-phase competition (T1/S'/eta') is only partly represented"))
    return issues
