"""Qualitative phase-expectation rules.

These flag which strengthening/impurity phases are *plausible* for a chemistry.
They do not drive the kinetics (solubility products in thermodynamics/equilibrium.py
do).  Thresholds are ASSUMED screening values, reported as such.
"""

from __future__ import annotations

from dataclasses import dataclass

from .composition import Composition


@dataclass
class PhaseExpectation:
    phase: str
    likelihood: str  # expected | possible | unlikely
    reason: str
    basis: str = "ASSUMED screening rule"


def expected_phases(c: Composition) -> list[PhaseExpectation]:
    w = c.wt()
    out: list[PhaseExpectation] = []

    def add(phase: str, cond_exp: bool, cond_pos: bool, reason: str) -> None:
        out.append(PhaseExpectation(phase, "expected" if cond_exp else "possible" if cond_pos else "unlikely", reason))

    add("delta' (Al3Li)", w["Li"] >= 1.0, w["Li"] >= 0.6, f"Li = {w['Li']:.2f} wt%")
    add("T1 (Al2CuLi)", w["Cu"] >= 1.5 and w["Li"] >= 0.8, w["Cu"] >= 0.8 and w["Li"] >= 0.5,
        f"Cu = {w['Cu']:.2f}, Li = {w['Li']:.2f} wt%; Ag/Mg promote nucleation")
    add("theta' (Al2Cu)", w["Cu"] >= 1.5 and w["Cu"] / max(w["Li"], 1e-9) > 3.0, w["Cu"] >= 1.0,
        f"Cu/Li = {w['Cu'] / max(w['Li'], 1e-9):.1f}")
    add("S' (Al2CuMg)", w["Mg"] >= 0.8 and w["Cu"] >= 0.8, w["Mg"] >= 0.3 and w["Cu"] >= 0.5, f"Mg = {w['Mg']:.2f} wt%")
    add("Al3Zr dispersoid", w["Zr"] >= 0.08, w["Zr"] >= 0.04, f"Zr = {w['Zr']:.2f} wt%")
    add("Al3(Sc,Zr) dispersoid", w["Sc"] >= 0.05, w["Sc"] > 0.0, f"Sc = {w['Sc']:.2f} wt%")
    add("Fe/Si constituents", w["Fe"] + w["Si"] > 0.0, False, f"Fe+Si = {w['Fe'] + w['Si']:.3f} wt%")
    return out
