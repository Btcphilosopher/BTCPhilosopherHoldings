"""Element data (handbook values for the pure elements, REFERENCE status)."""

from __future__ import annotations

ELEMENTS: tuple[str, ...] = ("Al", "Li", "Cu", "Mg", "Zn", "Ag", "Zr", "Sc", "Mn", "Fe", "Si", "Ti")

ATOMIC_MASS_G_MOL: dict[str, float] = {
    "Al": 26.9815, "Li": 6.941, "Cu": 63.546, "Mg": 24.305, "Zn": 65.38, "Ag": 107.868,
    "Zr": 91.224, "Sc": 44.956, "Mn": 54.938, "Fe": 55.845, "Si": 28.086, "Ti": 47.867,
}

# Pure-element density at ~293 K, kg m-3 (handbook values)
DENSITY_PURE_KG_M3: dict[str, float] = {
    "Al": 2698.9, "Li": 534.0, "Cu": 8960.0, "Mg": 1738.0, "Zn": 7134.0, "Ag": 10490.0,
    "Zr": 6506.0, "Sc": 2985.0, "Mn": 7470.0, "Fe": 7874.0, "Si": 2329.0, "Ti": 4506.0,
}

SOLUTES: tuple[str, ...] = tuple(e for e in ELEMENTS if e != "Al")

# Elements that can precipitate as nano-scale phases in the KWN module
PRECIP_SOLUTES: tuple[str, ...] = ("Li", "Cu", "Zr", "Sc")
