"""Stored energy, static recovery, and Zener-limited JMAK recrystallisation (reduced order)."""

from __future__ import annotations

import math
from dataclasses import dataclass

from ..governance import ModelMeta, register
from ..microstructure.defects import DefectType
from ..microstructure.dispersoids import zener_limit_grain_size, zener_pressure
from ..microstructure.grains import GrainState
from ..microstructure.state import MaterialState
from ..params import P, Status, declare
from ..units import AL_BURGERS_M, R_GAS
from . import texture as tex_evolution

_I = "Placeholder; calibrate to recrystallisation kinetics / EBSD"
declare(
    P("rx.G", 2.6e10, "Pa", Status.LITERATURE_APPROX, "shear modulus of Al near room temperature", 1e9, 2e10, 3e10),
    P("rx.rho_floor", 1.0e12, "1/m2", Status.ILLUSTRATIVE, "dislocation density retained in stable subgrain structure", 0.5, 1e10, 1e14, True),
    P("rx.rho_rx", 1.0e12, "1/m2", Status.ILLUSTRATIVE, "dislocation density inside recrystallised grains", 0.5, 1e10, 1e14, True),
    P("rx.rec_k", 3.0e6, "1/s", Status.ILLUSTRATIVE, "static recovery rate prefactor", 1.0, 1.0, 1e12, True),
    P("rx.rec_Q", 1.4e5, "J/mol", Status.ILLUSTRATIVE, "static recovery activation energy", 1.5e4, 5e4, 3e5),
    P("rx.sub_K", 10.0, "-", Status.ILLUSTRATIVE, "subgrain size = K / sqrt(rho)", 0.2, 1.0, 50.0, True),
    P("rx.t_ref", 100.0, "s", Status.ILLUSTRATIVE, _I, 1.0, 0.1, 1e6, True),
    P("rx.T_ref", 723.0, "K", Status.ILLUSTRATIVE, "reference temperature for t_ref", 0.0),
    P("rx.E_ref", 1.0e5, "J/m3", Status.ILLUSTRATIVE, "reference stored energy for t_ref", 0.0),
    P("rx.p", 2.0, "-", Status.ILLUSTRATIVE, "stored-energy exponent of recrystallisation time", 0.5, 0.5, 5.0),
    P("rx.Q", 1.8e5, "J/mol", Status.ILLUSTRATIVE, _I, 2.0e4, 8e4, 3.5e5),
    P("rx.n", 2.0, "-", Status.ILLUSTRATIVE, "JMAK exponent", 0.3, 1.0, 4.0),
    P("rx.d_rx0", 3.0e-5, "m", Status.ILLUSTRATIVE, "recrystallised grain size at E = E_ref", 0.5, 1e-6, 5e-4, True),
    P("rx.d_rx_min", 3.0e-6, "m", Status.ILLUSTRATIVE, "floor on recrystallised grain size", 0.0),
    P("rx.sigma_ln", 0.4, "-", Status.ILLUSTRATIVE, "log-std of recrystallised grain-size distribution", 0.1, 0.1, 1.0),
    P("rx.E_c", 5.0e4, "J/m3", Status.ILLUSTRATIVE, "stored energy scale for nucleation-site activation", 0.5, 1e3, 1e7, True),
    P("rx.abnormal_rate", 2.0e2, "1/m3", Status.ILLUSTRATIVE, "abnormal (coarse) grain count per m3 at X(1-X)=0.25", 1.0, 0.0, 1e6, True),
    P("kocks.k1", 5.0e8, "1/m", Status.ILLUSTRATIVE, "Kocks-Mecking storage coefficient", 0.3, 1e7, 1e10, True),
    P("kocks.k2_cold", 15.0, "-", Status.ILLUSTRATIVE, "Kocks-Mecking dynamic-recovery coefficient at the reference temperature", 0.3, 0.5, 500.0, True),
    P("kocks.Q_dr", 5.0e3, "J/mol", Status.ILLUSTRATIVE, "activation energy of dynamic recovery", 1500.0, 0.0, 1e5),
    P("kocks.T0", 300.0, "K", Status.REFERENCE, "reference temperature of k2_cold", 0.0),
    P("kocks.M", 3.06, "-", Status.REFERENCE, "Taylor factor of a random FCC polycrystal", 0.05),
)

META = register(ModelMeta(
    model_name="recrystallisation_jmak_zener",
    equation="E=0.5 rho G b^2; E_eff=E-P_Z; t_x = t_ref (E_ref/E_eff)^p exp(Q/R(1/T-1/Tref)); X=1-exp(-(t/t_x)^n); d_Z=4r/(3f)",
    parameter_source="registry rx.*, kocks.* (ILLUSTRATIVE), disp.*",
    validity_range="static recrystallisation of Al-Li plate; isothermal segments; no dynamic recrystallisation; no texture-dependent mobility",
))


def stored_energy(ctx, rho: float) -> float:  # type: ignore[no-untyped-def]
    return 0.5 * rho * ctx.p("rx.G") * AL_BURGERS_M**2


def kocks_mecking_density(ctx, rho0: float, eps_eq: float, T: float) -> float:  # type: ignore[no-untyped-def]
    """Analytic Kocks-Mecking storage: sqrt(rho)(eps) relaxes to k1/k2 with k2 thermally activated."""
    M = ctx.p("kocks.M")
    k2 = ctx.p("kocks.k2_cold") * math.exp(ctx.p("kocks.Q_dr") / R_GAS * (1.0 / ctx.p("kocks.T0") - 1.0 / T))
    sqrt_sat = ctx.p("kocks.k1") / k2
    sr = sqrt_sat + (math.sqrt(rho0) - sqrt_sat) * math.exp(-0.5 * M * k2 * eps_eq)
    return max(sr * sr, 1.0)


def static_recovery(ctx, rho: float, t: float, T: float) -> float:  # type: ignore[no-untyped-def]
    floor = ctx.p("rx.rho_floor")
    if rho <= floor:
        return rho
    K = ctx.p("rx.rec_k") * math.exp(-ctx.p("rx.rec_Q") / (R_GAS * T))
    return floor + (rho - floor) / (1.0 + K * t)


@dataclass
class RxResult:
    X: float
    nucleation_fraction: float
    stored_energy_pa: float
    zener_pressure_pa: float
    d_rx_m: float
    rho_after: float


def jmak_fraction(ctx, E_eff: float, t: float, T: float) -> float:  # type: ignore[no-untyped-def]
    if E_eff <= 0 or t <= 0:
        return 0.0
    tx = ctx.p("rx.t_ref") * (ctx.p("rx.E_ref") / E_eff) ** ctx.p("rx.p") * math.exp(
        ctx.p("rx.Q") / R_GAS * (1.0 / T - 1.0 / ctx.p("rx.T_ref")))
    return 1.0 - math.exp(-((t / tx) ** ctx.p("rx.n")))


def anneal(ctx, state: MaterialState, t: float, T: float, update_texture: bool = True) -> RxResult:  # type: ignore[no-untyped-def]
    """Isothermal anneal segment (inter-pass hold or solution treatment): recovery then recrystallisation."""
    ctx.use(META.model_name)
    g = state.grains
    assert g is not None
    rho_rec = static_recovery(ctx, state.dislocation_density, t, T)
    E = stored_energy(ctx, rho_rec)
    Pz = zener_pressure(ctx, state)
    dff = float(min(max(state.dispersoid_free_fraction, 0.0), 1.0))
    X_pinned = jmak_fraction(ctx, E - Pz, t, T)
    X_free = jmak_fraction(ctx, E, t, T)
    X = dff * X_free + (1.0 - dff) * X_pinned
    X = min(max(X, 0.0), 1.0)
    E_eff = max(E - Pz * (1.0 - dff), 0.0)
    nuc = 1.0 - math.exp(-E_eff / ctx.p("rx.E_c"))
    d_rx = max(ctx.p("rx.d_rx0") * (ctx.p("rx.E_ref") / max(E_eff, 1.0)) ** 0.5, ctx.p("rx.d_rx_min"))
    d_rx = min(d_rx, zener_limit_grain_size(state))
    rho_after = (1.0 - X) * rho_rec + X * ctx.p("rx.rho_rx")
    if X > 1e-6:
        # mixture of retained deformed grains and new equiaxed recrystallised grains (volume-weighted in ln d)
        def mix(d_old: float, d_new: float) -> float:
            return math.exp((1.0 - X) * math.log(d_old) + X * math.log(d_new))
        state.grains = GrainState(
            d_L=mix(g.d_L, d_rx), d_T=mix(g.d_T, d_rx), d_N=mix(g.d_N, d_rx),
            sigma_ln=math.sqrt((1 - X) * g.sigma_ln**2 + X * ctx.p("rx.sigma_ln") ** 2 + X * (1 - X) * 0.3),
            recrystallised_fraction=X, subgrain_size_m=g.subgrain_size_m, columnar_fraction=g.columnar_fraction * (1 - X),
        )
        if update_texture:
            tex_evolution.recrystallise(ctx, state.texture, X, state.insoluble_constituent_fraction)
        # coarse abnormal grains arise in the partially recrystallised, partly pinned regime
        V = state.dims_m[0] * state.dims_m[1] * state.dims_m[2]
        mu = ctx.p("rx.abnormal_rate") * 4.0 * X * (1.0 - X) * dff * V
        for _ in range(int(min(ctx.rng.poisson(mu), 500))):
            state.defects.add(DefectType.GRAIN_ABNORMALITY, float(ctx.rng.lognormal(math.log(8 * d_rx), 0.4)),
                              (ctx.rng.uniform(), ctx.rng.uniform(), ctx.rng.uniform()), ctx.rng.normal(size=3),
                              confidence=0.3, origin="recrystallisation: abnormal grain growth")
    state.dislocation_density = rho_after
    assert state.grains is not None
    state.grains.subgrain_size_m = ctx.p("rx.sub_K") / math.sqrt(max(rho_after, 1.0))
    return RxResult(X, nuc, E, Pz, d_rx, rho_after)
