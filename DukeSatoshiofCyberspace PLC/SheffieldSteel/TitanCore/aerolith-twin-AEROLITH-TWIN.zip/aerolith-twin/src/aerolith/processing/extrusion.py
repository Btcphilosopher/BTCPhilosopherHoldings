"""Abstract extrusion model (no die geometry): reduction ratio, Johnson ram pressure, fibre texture."""

from __future__ import annotations

import math
from dataclasses import dataclass

import numpy as np

from ..governance import ModelMeta, register
from ..microstructure.grains import GrainState
from ..microstructure.state import MaterialState
from ..params import P, Status, declare
from . import recrystallisation as rx
from . import texture as tex_evolution
from .rolling import deform_defects
from .strain import DeformationStep, StrainHistory, flow_stress_pa

declare(
    P("ext.johnson_a", 0.8, "-", Status.ILLUSTRATIVE, "Johnson extrusion-pressure constant a", 0.15, 0.3, 1.5),
    P("ext.johnson_b", 1.5, "-", Status.ILLUSTRATIVE, "Johnson extrusion-pressure constant b", 0.3, 0.8, 3.0),
)
META = register(ModelMeta(
    model_name="abstract_extrusion_johnson",
    equation="eps = ln R ; p = sigma (a + b ln R) ; mean strain rate = 6 v D^2 tan(alpha)/(D^2-d^2)-like abstraction (v/Lc ln R)",
    parameter_source="registry ext.*, def.* (ILLUSTRATIVE)",
    validity_range="abstract: only reduction ratio, ram speed and billet geometry; no die/dead-zone geometry; direct extrusion",
    fidelity="EMPIRICAL",
))


@dataclass
class ExtrusionSchedule:
    billet_temperature_K: float
    reduction_ratio: float
    ram_speed_m_s: float = 0.005
    billet_diameter_m: float = 0.3
    billet_length_m: float = 0.8
    die_land_length_m: float = 0.05

    def validate(self) -> None:
        if self.reduction_ratio <= 1.0:
            raise ValueError("reduction ratio must exceed 1")
        if not 300 < self.billet_temperature_K < 900:
            raise ValueError("billet temperature must be in kelvin")


@dataclass
class ExtrusionResult:
    history: StrainHistory
    ram_pressure_pa: float
    ram_force_n: float
    exit_temperature_K: float
    realised: dict[str, np.ndarray]


def extrude(ctx, state: MaterialState, sched: ExtrusionSchedule) -> ExtrusionResult:  # type: ignore[no-untyped-def]
    ctx.use(META.model_name)
    sched.validate()
    R = sched.reduction_ratio
    eps = math.log(R)
    T = sched.billet_temperature_K
    deform_len = 0.5 * sched.billet_diameter_m
    exit_speed = sched.ram_speed_m_s * R
    edot = exit_speed / deform_len * eps / R if R > 1 else 0.0
    edot = max(edot, 1e-3)
    sig = flow_stress_pa(ctx, edot, T)
    p = sig * (ctx.p("ext.johnson_a") + ctx.p("ext.johnson_b") * eps)
    area = math.pi * sched.billet_diameter_m**2 / 4.0
    T_exit = T + ctx.p("def.heat_fraction") * sig * eps / (2650.0 * ctx.p("def.cp"))
    state.dislocation_density = rx.kocks_mecking_density(ctx, state.dislocation_density, eps, T_exit)
    tex_evolution.deform(ctx, state.texture, state.total_true_strain, eps, "extrusion")
    g = state.grains
    assert g is not None
    # fibre structure: elongation along the extrusion (rolling) direction, equal contraction transversely
    state.grains = GrainState(g.d_L * R ** 0.5 * 1.0, g.d_T * R ** -0.25, g.d_N * R ** -0.25, g.sigma_ln,
                              g.recrystallised_fraction * 0.5, g.subgrain_size_m, g.columnar_fraction)
    deform_defects(ctx, state.defects, 1.0 / R ** 0.5, eps)
    L, W, H = state.dims_m
    state.dims_m = (L * R, W / R**0.5, H / R**0.5)
    state.total_true_strain += eps
    state.cumulative_reduction_ratio *= R
    rx.anneal(ctx, state, 10.0, T_exit)
    state.peak_temperature_K = max(state.peak_temperature_K, T_exit)
    hist = StrainHistory()
    hist.add(DeformationStep("extrusion", 1, eps, eps, edot, T_exit, sched.billet_length_m / sched.ram_speed_m_s, sig, p * area))
    state.stage = "extruded"
    state.log("extrusion", reduction_ratio=R, ram_pressure_pa=p, exit_T_K=T_exit)
    return ExtrusionResult(hist, p, p * area, T_exit, {"t_s": np.array([0.0, 1.0]), "T_K": np.array([T, T_exit])})
