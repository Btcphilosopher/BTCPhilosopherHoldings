"""Strain bookkeeping and hot-flow-stress model."""

from __future__ import annotations

import math
from dataclasses import asdict, dataclass, field

import pandas as pd

from ..governance import ModelMeta, register
from ..params import P, Status, declare
from ..units import MPA, R_GAS

_I = "Placeholder typical of hot-working Al alloys; calibrate to hot-compression/rolling-force data"
declare(
    P("def.Q", 1.56e5, "J/mol", Status.ILLUSTRATIVE, _I, 1.5e4, 1e5, 3e5),
    P("def.alpha", 0.015, "1/MPa", Status.ILLUSTRATIVE, _I, 0.002, 0.003, 0.05),
    P("def.n", 5.0, "-", Status.ILLUSTRATIVE, _I, 0.5, 2.0, 12.0),
    P("def.lnA", math.log(1.0e12), "-", Status.ILLUSTRATIVE, _I, 1.0, 10.0, 50.0),
    P("def.heat_fraction", 0.9, "-", Status.LITERATURE_APPROX, "fraction of plastic work converted to heat (Taylor-Quinney)", 0.05, 0.5, 1.0),
    P("def.cp", 1050.0, "J/kg/K", Status.LITERATURE_APPROX, "specific heat of Al alloys", 80.0, 800, 1400),
)

META = register(ModelMeta(
    model_name="hot_flow_stress_sinh",
    equation="Z = edot exp(Q/RT); sigma = (1/alpha) asinh((Z/A)^(1/n))",
    parameter_source="registry def.* (ILLUSTRATIVE)",
    validity_range="hot working 573-833 K; 1e-2 .. 1e2 1/s; no strain hardening/softening transient",
    fidelity="EMPIRICAL",
))


def zener_hollomon(ctx, strain_rate: float, T: float) -> float:  # type: ignore[no-untyped-def]
    return strain_rate * math.exp(ctx.p("def.Q") / (R_GAS * T))


def flow_stress_pa(ctx, strain_rate: float, T: float) -> float:  # type: ignore[no-untyped-def]
    """Equivalent (von Mises) hot flow stress in Pa."""
    ctx.use(META.model_name)
    Z = zener_hollomon(ctx, strain_rate, T)
    A = math.exp(ctx.p("def.lnA"))
    x = (Z / A) ** (1.0 / ctx.p("def.n"))
    return math.asinh(x) / ctx.p("def.alpha") * MPA


def equivalent_strain_plane(true_thickness_strain: float) -> float:
    return 2.0 / math.sqrt(3.0) * true_thickness_strain


@dataclass
class DeformationStep:
    stage: str
    index: int
    true_strain: float  # thickness (or axial) true strain of this step
    plastic_strain: float  # equivalent plastic strain increment
    strain_rate_s: float
    temperature_K: float
    time_s: float  # cumulative process time at step end
    flow_stress_pa: float = 0.0
    force_n: float = 0.0
    note: str = ""


@dataclass
class StrainHistory:
    steps: list[DeformationStep] = field(default_factory=list)

    def add(self, s: DeformationStep) -> None:
        self.steps.append(s)

    @property
    def total_true_strain(self) -> float:
        return sum(s.true_strain for s in self.steps)

    @property
    def total_plastic_strain(self) -> float:
        return sum(s.plastic_strain for s in self.steps)

    def to_dataframe(self) -> pd.DataFrame:
        return pd.DataFrame([asdict(s) for s in self.steps])
