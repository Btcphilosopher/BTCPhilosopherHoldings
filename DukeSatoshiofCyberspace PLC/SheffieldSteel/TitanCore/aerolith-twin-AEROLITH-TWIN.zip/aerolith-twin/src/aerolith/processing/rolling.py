"""Hot/warm plate rolling: pass schedule, flow stress, force, deformation heating, microstructure update."""

from __future__ import annotations

import math
from dataclasses import dataclass, field

import numpy as np

from ..governance import ModelMeta, register
from ..microstructure.defects import DefectPopulation, DefectType
from ..microstructure.grains import GrainState
from ..microstructure.state import MaterialState
from ..params import P, Status, declare
from . import recrystallisation as rx
from . import texture as tex_evolution
from .strain import DeformationStep, StrainHistory, equivalent_strain_plane, flow_stress_pa

declare(
    P("roll.mu", 0.3, "-", Status.ILLUSTRATIVE, "Coulomb friction coefficient in the roll bite", 0.08, 0.05, 0.6),
    P("roll.h_cool", 80.0, "W/m2/K", Status.ILLUSTRATIVE, "inter-pass cooling coefficient of the slab surface to the surroundings", 0.4, 5.0, 2000.0, True),
    P("roll.rho", 2650.0, "kg/m3", Status.LITERATURE_APPROX, "plate density for thermal bookkeeping", 60.0, 2400, 2900),
    P("roll.pore_close_thickness", 5.0e-5, "m", Status.ILLUSTRATIVE, "pore thickness below which the pore is closed by rolling", 0.5, 1e-7, 1e-3, True),
    P("roll.unbonded_fraction", 0.03, "-", Status.ILLUSTRATIVE, "fraction of closed pores left as unbonded (oxide-lined) laminar flaws", 0.3, 0.0, 1.0),
    P("roll.edge_crack_rate", 6.0, "1/m3 per unit strain-rate-ratio", Status.ILLUSTRATIVE, "surface/edge crack count per m3 when flow-stress ratio exceeds threshold", 0.8, 0.0, 1e4, True),
)

META = register(ModelMeta(
    model_name="plate_rolling_multipass",
    equation="eps=ln(h0/h1); edot = v eps / sqrt(R dh); F = sigma_ps w Lc (1 + mu Lc/(2 h_m)); dT = eta sigma eps/(rho cp)",
    parameter_source="registry roll.*, def.* (ILLUSTRATIVE)",
    validity_range="flat rolling of plate, plane strain, constant width, no roll flattening; reductions 5-40 % per pass",
    fidelity="EMPIRICAL",
))


@dataclass
class RollingSchedule:
    initial_thickness_m: float
    final_thickness_m: float
    n_passes: int
    width_m: float = 1.0
    roll_radius_m: float = 0.5
    roll_speed_m_s: float = 1.0
    entry_temperature_K: float = 723.0
    roll_temperature_K: float = 373.0
    interpass_time_s: float = 30.0
    reduction_per_pass: list[float] | None = None  # fractional reductions; None -> equal true-strain passes

    def thicknesses(self) -> list[float]:
        h = [self.initial_thickness_m]
        if self.reduction_per_pass is not None:
            for r in self.reduction_per_pass:
                h.append(h[-1] * (1.0 - r))
        else:
            ratio = (self.final_thickness_m / self.initial_thickness_m) ** (1.0 / self.n_passes)
            for _ in range(self.n_passes):
                h.append(h[-1] * ratio)
        return h

    def validate(self) -> None:
        if self.final_thickness_m >= self.initial_thickness_m:
            raise ValueError("final thickness must be smaller than initial thickness")
        if not 300 < self.entry_temperature_K < 900:
            raise ValueError("entry temperature must be in kelvin (300-900 K)")
        if self.reduction_per_pass is not None and any(not 0 < r < 0.6 for r in self.reduction_per_pass):
            raise ValueError("per-pass reduction must be in (0, 0.6)")


@dataclass
class RollingResult:
    history: StrainHistory
    thickness_m: list[float]
    temperature_K: list[float]
    time_s: list[float]
    max_force_n: float
    max_torque_nm: float
    max_power_w: float
    X_final: float
    realised: dict[str, np.ndarray] = field(default_factory=dict)


def deform_defects(ctx, pop: DefectPopulation, h_ratio: float, eps_t: float) -> None:  # type: ignore[no-untyped-def]
    """Flatten, close or leave unbonded the defect population after a reduction h1/h0."""
    keep = []
    for d in pop.defects:
        if d.type in (DefectType.POROSITY, DefectType.VOID):
            thickness = d.size_m / max(d.aspect_ratio, 1.0) * h_ratio
            if thickness < ctx.p("roll.pore_close_thickness"):
                if ctx.rng.random() < ctx.p("roll.unbonded_fraction"):
                    d.type = DefectType.CRACK
                    d.size_m = d.size_m * h_ratio ** (-0.5)
                    d.aspect_ratio = 8.0
                    d.confidence *= 0.7
                    d.origin += " -> unbonded after rolling"
                    d.orientation = (1.0, 0.05, 0.0)
                    keep.append(d)
                continue
            d.size_m *= h_ratio ** (-0.5)
            d.aspect_ratio = max(d.aspect_ratio, 1.0) * h_ratio ** (-1.5)
            d.orientation = (1.0, 0.1, 0.0)
        elif d.type in (DefectType.INCLUSION, DefectType.SEGREGATION, DefectType.CRACK):
            d.size_m *= h_ratio ** (-0.5) if d.type is not DefectType.INCLUSION else h_ratio ** (-0.25)
            d.aspect_ratio *= h_ratio ** (-0.5)
            d.orientation = (1.0, 0.1, 0.0)
        d.position = (d.position[0], d.position[1], d.position[2])  # normalised coordinates are volume-preserving
        keep.append(d)
    pop.defects = keep


def roll_plate(ctx, state: MaterialState, sched: RollingSchedule, t0_s: float = 0.0) -> RollingResult:  # type: ignore[no-untyped-def]
    ctx.use(META.model_name)
    sched.validate()
    hs = sched.thicknesses()
    T = sched.entry_temperature_K
    t = t0_s
    hist = StrainHistory()
    Ts, ts = [T], [t]
    F_max = M_max = P_max = 0.0
    rho, cp = ctx.p("roll.rho"), ctx.p("def.cp")
    mu = ctx.p("roll.mu")
    X_last = 0.0
    n_pass = len(hs) - 1
    for i in range(n_pass):
        h0, h1 = hs[i], hs[i + 1]
        dh = h0 - h1
        Lc = math.sqrt(sched.roll_radius_m * dh)
        eps_t = math.log(h0 / h1)
        eps_eq = equivalent_strain_plane(eps_t)
        edot = sched.roll_speed_m_s * eps_t / Lc
        ctx.check_range("rolling strain rate", edot, 1e-2, 1e2, " 1/s")
        sig = flow_stress_pa(ctx, edot, T)
        sig_ps = 2.0 / math.sqrt(3.0) * sig
        hm = 0.5 * (h0 + h1)
        F = sig_ps * sched.width_m * Lc * (1.0 + mu * Lc / (2.0 * hm))
        torque = F * Lc * 0.5  # per roll
        power = 2.0 * torque * sched.roll_speed_m_s / sched.roll_radius_m
        F_max, M_max, P_max = max(F_max, F), max(M_max, torque), max(P_max, power)
        # microstructure: deformation
        state.dislocation_density = rx.kocks_mecking_density(ctx, state.dislocation_density, eps_eq, T)
        tex_evolution.deform(ctx, state.texture, state.total_true_strain, eps_eq, "rolling")
        g = state.grains
        assert g is not None
        state.grains = GrainState(g.d_L * math.exp(eps_t), g.d_T, g.d_N * math.exp(-eps_t), g.sigma_ln,
                                  g.recrystallised_fraction * 0.5, g.subgrain_size_m, g.columnar_fraction)
        deform_defects(ctx, state.defects, h1 / h0, eps_t)
        state.total_true_strain += eps_t
        state.cumulative_reduction_ratio *= h0 / h1
        L, W, H = state.dims_m
        state.dims_m = (L * h0 / h1, W, H * h1 / h0)
        # deformation heating
        T += ctx.p("def.heat_fraction") * sig * eps_eq / (rho * cp)
        t += Lc / sched.roll_speed_m_s
        hist.add(DeformationStep("rolling", i + 1, eps_t, eps_eq, edot, T, t, sig, F))
        state.peak_temperature_K = max(state.peak_temperature_K, T)
        # inter-pass: cooling, recovery, recrystallisation
        if i < n_pass - 1 or True:
            tau = rho * cp * 0.5 * h1 / ctx.p("roll.h_cool")
            T_mid = sched.roll_temperature_K + (T - sched.roll_temperature_K) * math.exp(-sched.interpass_time_s / tau)
            T_hold = 0.5 * (T + T_mid)
            res = rx.anneal(ctx, state, sched.interpass_time_s, T_hold)
            X_last = res.X
            T = T_mid
            t += sched.interpass_time_s
        Ts.append(T)
        ts.append(t)
    state.stage = "rolled"
    state.log("rolling", passes=n_pass, thickness_m=hs[-1], reduction_ratio=hs[0] / hs[-1], X_final=X_last,
              max_force_n=F_max, final_T_K=T)
    return RollingResult(hist, hs, Ts, ts, F_max, M_max, P_max, X_last,
                         {"t_s": np.array(ts), "T_K": np.array(Ts)})
