"""Texture evolution during deformation and recrystallisation (reduced-order, component weights)."""

from __future__ import annotations

import math

from ..governance import ModelMeta, register
from ..microstructure.texture import TextureState
from ..params import P, Status, declare

declare(
    P("tex.eps_scale", 1.5, "-", Status.ILLUSTRATIVE, "equivalent strain scale for deformation-texture saturation", 0.3, 0.2, 10.0, True),
    P("tex.max_def_fraction", 0.65, "-", Status.ILLUSTRATIVE, "maximum fraction of material in deformation components", 0.1, 0.1, 1.0),
    P("tex.cube_share", 0.30, "-", Status.ILLUSTRATIVE, "Cube share of recrystallisation texture without particle-stimulated nucleation", 0.1, 0.0, 1.0),
    P("tex.goss_share", 0.05, "-", Status.ILLUSTRATIVE, "Goss share of recrystallisation texture", 0.03, 0.0, 1.0),
    P("tex.psn_gain", 25.0, "-", Status.ILLUSTRATIVE, "randomisation of recrystallisation texture by constituent particles per unit volume fraction", 0.5, 0.0, 500.0, True),
)

META = register(ModelMeta(
    model_name="texture_component_evolution",
    equation="w_def += (S(eps+d eps)-S(eps)) (target - w) ; S = Smax(1-exp(-eps/eps0)); recrystallisation moves X of the mass to Cube/Goss/Random",
    parameter_source="registry tex.* (ILLUSTRATIVE)",
    validity_range="qualitative trends for rolled / extruded Al alloys; component set {Cube,Goss,Brass,S,Copper,Fibre<111>,Fibre<100>,Random}",
    fidelity="EMPIRICAL",
))

_TARGETS = {
    "rolling": {"Brass": 0.30, "S": 0.40, "Copper": 0.30},
    "extrusion": {"Fibre111": 0.5, "Fibre100": 0.5},
    "forging": {"Brass": 0.15, "S": 0.15, "Copper": 0.20, "Goss": 0.05},
}


def deform(ctx, tex: TextureState, eps_total_before: float, d_eps: float, mode: str = "rolling") -> None:  # type: ignore[no-untyped-def]
    ctx.use(META.model_name)
    smax = ctx.p("tex.max_def_fraction") * (0.45 if mode == "forging" else 1.0)
    e0 = ctx.p("tex.eps_scale")
    s0 = smax * (1.0 - math.exp(-eps_total_before / e0))
    s1 = smax * (1.0 - math.exp(-(eps_total_before + d_eps) / e0))
    ds = max(s1 - s0, 0.0) / max(1.0 - s0, 1e-6)
    w = tex.normalised()
    target = _TARGETS[mode]
    new = {k: (1.0 - ds) * v for k, v in w.items()}
    for k, share in target.items():
        new[k] = new.get(k, 0.0) + ds * share
    tex.weights = new


def recrystallise(ctx, tex: TextureState, X: float, insoluble_fraction: float = 0.0) -> None:  # type: ignore[no-untyped-def]
    """Move fraction X of the volume into Cube/Goss/random recrystallisation components."""
    ctx.use(META.model_name)
    cube = ctx.p("tex.cube_share") / (1.0 + ctx.p("tex.psn_gain") * insoluble_fraction)
    goss = ctx.p("tex.goss_share")
    w = tex.normalised()
    new = {k: (1.0 - X) * v for k, v in w.items()}
    new["Cube"] = new.get("Cube", 0.0) + X * cube
    new["Goss"] = new.get("Goss", 0.0) + X * goss
    new["Random"] = new.get("Random", 0.0) + X * (1.0 - cube - goss)
    tex.weights = new
