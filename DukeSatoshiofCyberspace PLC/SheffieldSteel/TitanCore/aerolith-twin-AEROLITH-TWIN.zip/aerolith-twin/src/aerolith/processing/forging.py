"""Open-die upset forging (abstract): strain, flow stress, forging pressure, microstructure update."""

from __future__ import annotations

import math
from dataclasses import dataclass

import numpy as np

from ..governance import ModelMeta, register
from ..microstructure.grains import GrainState
from ..microstructure.state import MaterialState
from ..params import P, Status, declare
from . import recrystallisation as rx
from . import texture as tex_evolution
from .rolling import deform_defects
from .strain import DeformationStep, StrainHistory, flow_stress_pa

declare(
    P("forge.mu", 0.35, "-", Status.ILLUSTRATIVE, "friction coefficient at the die interface", 0.1, 0.05, 0.8),
    P("forge.h_cool", 120.0, "W/m2/K", Status.ILLUSTRATIVE, "inter-step cooling coefficient", 0.4, 5.0, 3000.0, True),
)
META = register(ModelMeta(
    model_name="open_die_upset_forging",
    equation="eps = ln(h0/h1); p_avg = sigma (1 + mu d/(3 h)); temperature rise from plastic work",
    parameter_source="registry forge.*, def.* (ILLUSTRATIVE)",
    validity_range="axisymmetric upset, no barrelling model, abstract multi-step schedule; no die chill",
    fidelity="EMPIRICAL",
))


@dataclass
class ForgingSchedule:
    forging_temperature_K: float
    true_strain_per_step: float
    n_steps: int
    strain_rate_s: float = 0.1
    step_time_s: float = 20.0
    rest_time_s: float = 20.0
    die_temperature_K: float = 473.0

    def validate(self) -> None:
        if not 300 < self.forging_temperature_K < 900:
            raise ValueError("forging temperature must be in kelvin")
        if self.true_strain_per_step <= 0 or self.n_steps < 1:
            raise ValueError("strain and number of steps must be positive")


@dataclass
class ForgingResult:
    history: StrainHistory
    max_pressure_pa: float
    final_T_K: float
    realised: dict[str, np.ndarray]


def forge(ctx, state: MaterialState, sched: ForgingSchedule) -> ForgingResult:  # type: ignore[no-untyped-def]
    ctx.use(META.model_name)
    sched.validate()
    T = sched.forging_temperature_K
    hist = StrainHistory()
    rho, cp = 2650.0, ctx.p("def.cp")
    t = 0.0
    Ts, ts = [T], [0.0]
    p_max = 0.0
    for i in range(sched.n_steps):
        eps = sched.true_strain_per_step
        sig = flow_stress_pa(ctx, sched.strain_rate_s, T)
        L, W, H = state.dims_m
        h1 = H * math.exp(-eps)
        d = math.sqrt(L * W)
        p_avg = sig * (1.0 + ctx.p("forge.mu") * d * math.exp(eps / 2) / (3.0 * 0.5 * (H + h1)))
        p_max = max(p_max, p_avg)
        state.dislocation_density = rx.kocks_mecking_density(ctx, state.dislocation_density, eps, T)
        tex_evolution.deform(ctx, state.texture, state.total_true_strain, eps, "forging")
        g = state.grains
        assert g is not None
        f = math.exp(eps / 2.0)
        state.grains = GrainState(g.d_L * f, g.d_T * f, g.d_N * math.exp(-eps), g.sigma_ln, g.recrystallised_fraction * 0.5,
                                  g.subgrain_size_m, g.columnar_fraction)
        deform_defects(ctx, state.defects, math.exp(-eps), eps)
        state.total_true_strain += eps
        state.cumulative_reduction_ratio *= math.exp(eps)
        state.dims_m = (L * f, W * f, h1)
        T += ctx.p("def.heat_fraction") * sig * eps / (rho * cp)
        t += sched.step_time_s
        hist.add(DeformationStep("forging", i + 1, eps, eps, sched.strain_rate_s, T, t, sig, p_avg * L * W))
        tau = rho * cp * 0.5 * h1 / ctx.p("forge.h_cool")
        T_mid = sched.die_temperature_K + (T - sched.die_temperature_K) * math.exp(-sched.rest_time_s / tau)
        rx.anneal(ctx, state, sched.rest_time_s, 0.5 * (T + T_mid))
        T = T_mid
        t += sched.rest_time_s
        Ts.append(T)
        ts.append(t)
        state.peak_temperature_K = max(state.peak_temperature_K, T)
    state.stage = "forged"
    state.log("forging", steps=sched.n_steps, total_strain=hist.total_true_strain, final_T_K=T)
    return ForgingResult(hist, p_max, T, {"t_s": np.array(ts), "T_K": np.array(Ts)})
