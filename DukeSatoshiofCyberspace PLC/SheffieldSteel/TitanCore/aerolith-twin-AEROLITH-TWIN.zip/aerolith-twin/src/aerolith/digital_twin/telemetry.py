"""Sensor digital twin: bias, noise, drift, resolution, sampling frequency, missing data."""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import pandas as pd


@dataclass
class SensorSpec:
    name: str
    unit: str
    bias: float = 0.0
    noise_sigma: float = 0.0
    drift_per_hour: float = 0.0
    resolution: float = 0.0  # quantisation step (0 = continuous)
    sampling_hz: float = 1.0
    missing_prob: float = 0.0

    def validate(self) -> None:
        if self.sampling_hz <= 0:
            raise ValueError("sampling frequency must be positive")
        if not 0.0 <= self.missing_prob < 1.0:
            raise ValueError("missing probability must be in [0, 1)")


# Default virtual sensors; values are ILLUSTRATIVE instrument assumptions (edit to match your instrumentation)
DEFAULT_SENSORS: dict[str, SensorSpec] = {
    "homogenisation_furnace_T": SensorSpec("homogenisation_furnace_T", "K", bias=1.5, noise_sigma=0.8, drift_per_hour=0.05, resolution=0.1, sampling_hz=1 / 60, missing_prob=0.01),
    "solution_furnace_T": SensorSpec("solution_furnace_T", "K", bias=1.0, noise_sigma=0.6, drift_per_hour=0.05, resolution=0.1, sampling_hz=1 / 10, missing_prob=0.01),
    "ageing_furnace_T": SensorSpec("ageing_furnace_T", "K", bias=0.8, noise_sigma=0.4, drift_per_hour=0.03, resolution=0.1, sampling_hz=1 / 60, missing_prob=0.01),
    "quench_surface_T": SensorSpec("quench_surface_T", "K", bias=0.0, noise_sigma=2.0, resolution=0.5, sampling_hz=5.0, missing_prob=0.02),
    "quench_centre_T": SensorSpec("quench_centre_T", "K", bias=0.0, noise_sigma=1.5, resolution=0.5, sampling_hz=5.0, missing_prob=0.02),
    "quench_tank_T": SensorSpec("quench_tank_T", "K", bias=0.2, noise_sigma=0.1, resolution=0.1, sampling_hz=0.2),
    "quench_flow": SensorSpec("quench_flow", "m/s", bias=0.0, noise_sigma=0.03, resolution=0.01, sampling_hz=1.0),
    "rolling_force": SensorSpec("rolling_force", "N", bias=0.0, noise_sigma=2.0e4, resolution=1.0e3, sampling_hz=1.0),
    "rolling_speed": SensorSpec("rolling_speed", "m/s", bias=0.0, noise_sigma=0.01, resolution=0.005, sampling_hz=1.0),
    "strain": SensorSpec("strain", "-", bias=0.0, noise_sigma=0.01, resolution=0.001, sampling_hz=1.0),
    "strain_rate": SensorSpec("strain_rate", "1/s", bias=0.0, noise_sigma=0.02, resolution=0.001, sampling_hz=1.0),
    "ageing_time": SensorSpec("ageing_time", "h", bias=0.0, noise_sigma=0.0, resolution=0.01, sampling_hz=1 / 600),
}


def measure(spec: SensorSpec, t_s: np.ndarray, y_true: np.ndarray, rng: np.random.Generator) -> pd.DataFrame:
    """Sample a true signal through a sensor.  Returns t, y_true (sampled), y_meas (NaN where missing)."""
    spec.validate()
    t_s = np.asarray(t_s, float)
    y_true = np.asarray(y_true, float)
    if t_s.size < 2:
        ts = t_s.copy()
    else:
        dt = 1.0 / spec.sampling_hz
        n = max(int((t_s[-1] - t_s[0]) / dt) + 1, 2)
        ts = t_s[0] + np.arange(n) * min(dt, (t_s[-1] - t_s[0]))
        if dt > (t_s[-1] - t_s[0]):
            ts = np.array([t_s[0], t_s[-1]])
    yt = np.interp(ts, t_s, y_true)
    drift = spec.drift_per_hour * (ts - ts[0]) / 3600.0
    y = yt + spec.bias + drift + rng.normal(0.0, spec.noise_sigma, ts.size) if spec.noise_sigma > 0 else yt + spec.bias + drift
    if spec.resolution > 0:
        y = np.round(y / spec.resolution) * spec.resolution
    miss = rng.random(ts.size) < spec.missing_prob
    y = np.where(miss, np.nan, y)
    return pd.DataFrame({"t_s": ts, "y_true": yt, "y_meas": y, "channel": spec.name, "unit": spec.unit})


def telemetry_from_signals(signals: dict[str, tuple[np.ndarray, np.ndarray, str]], rng: np.random.Generator,
                           sensors: dict[str, SensorSpec] | None = None) -> pd.DataFrame:
    sensors = sensors or DEFAULT_SENSORS
    frames = []
    for name, (t, y, _unit) in signals.items():
        spec = sensors.get(name)
        if spec is None:
            continue
        frames.append(measure(spec, t, y, rng))
    return pd.concat(frames, ignore_index=True) if frames else pd.DataFrame()
