"""State estimation: Kalman filtering of process signals and Bayesian (importance-weighted) material-state posterior."""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import pandas as pd

from .telemetry import SensorSpec


class KalmanFilter:
    """Linear Kalman filter x_k = F x_{k-1} + w, z_k = H x_k + v  (Joseph-form covariance update)."""

    def __init__(self, F: np.ndarray, H: np.ndarray, Q: np.ndarray, R: np.ndarray, x0: np.ndarray, P0: np.ndarray):
        self.F, self.H, self.Q, self.R = map(np.atleast_2d, (F, H, Q, R))
        self.x = np.asarray(x0, float).copy()
        self.P = np.atleast_2d(P0).astype(float).copy()

    def step(self, z: float | None, F: np.ndarray | None = None, Q: np.ndarray | None = None) -> tuple[np.ndarray, np.ndarray]:
        F = self.F if F is None else F
        Q = self.Q if Q is None else Q
        self.x = F @ self.x
        self.P = F @ self.P @ F.T + Q
        if z is not None and np.isfinite(z):
            S = self.H @ self.P @ self.H.T + self.R
            K = self.P @ self.H.T @ np.linalg.inv(S)
            y = np.atleast_1d(z) - self.H @ self.x
            self.x = self.x + K @ y
            I = np.eye(self.P.shape[0])
            self.P = (I - K @ self.H) @ self.P @ (I - K @ self.H).T + K @ self.R @ K.T
        return self.x.copy(), self.P.copy()


@dataclass
class HoldEstimate:
    mean_temperature_K: float
    sigma_K: float
    bias_estimate_K: float
    bias_sigma_K: float
    n_valid: int
    n_missing: int


def estimate_hold_temperature(df: pd.DataFrame, spec: SensorSpec, window: tuple[float, float] | None = None,
                              bias_prior_sigma: float = 2.0, process_sigma_per_sqrt_s: float = 0.02) -> HoldEstimate:
    """Estimate the true mean temperature in a time window from a biased, drifting, noisy sensor.

    State = [true temperature, sensor bias]; temperature is a random walk, bias is a (nearly) constant state with a
    prior N(spec.bias_nominal_guess = 0, bias_prior_sigma^2) — i.e. the filter does NOT know the bias.
    The bias is only weakly observable from one sensor; its uncertainty is carried into the temperature estimate.
    """
    d = df if window is None else df[(df.t_s >= window[0]) & (df.t_s <= window[1])]
    d = d.sort_values("t_s")
    t = d.t_s.to_numpy()
    z = d.y_meas.to_numpy()
    if t.size == 0:
        raise ValueError("no samples in window")
    z0 = np.nanmean(z) if np.isfinite(z).any() else 0.0
    kf = KalmanFilter(np.eye(2), np.array([[1.0, 1.0]]), np.diag([0.0, 0.0]), np.array([[max(spec.noise_sigma, 1e-3) ** 2 + (spec.resolution**2) / 12.0]]),
                      np.array([z0, 0.0]), np.diag([25.0, bias_prior_sigma**2]))
    nmiss = 0
    last = t[0]
    for ti, zi in zip(t, z, strict=True):
        dt = max(ti - last, 0.0)
        Q = np.diag([process_sigma_per_sqrt_s**2 * dt, 1e-10 * dt])
        if not np.isfinite(zi):
            nmiss += 1
        kf.step(zi if np.isfinite(zi) else None, Q=Q)
        last = ti
    P = kf.P
    return HoldEstimate(float(kf.x[0]), float(np.sqrt(P[0, 0])), float(kf.x[1]), float(np.sqrt(P[1, 1])), int(t.size - nmiss), nmiss)


def gaussian_update(prior_mean: float, prior_sigma: float, obs: float, obs_sigma: float) -> tuple[float, float]:
    """Conjugate normal update (scalar)."""
    w0, w1 = 1.0 / prior_sigma**2, 1.0 / obs_sigma**2
    var = 1.0 / (w0 + w1)
    return (prior_mean * w0 + obs * w1) * var, float(np.sqrt(var))


def importance_posterior(values: np.ndarray, prior_samples: dict[str, np.ndarray], observations: dict[str, tuple[float, float]]) -> dict[str, float]:
    """Importance weights of an ensemble given Gaussian observations of ensemble outputs.

    ``prior_samples`` maps an output name to its ensemble values; ``observations`` maps the same names to (measured value, sigma).
    Returns weights (normalised), effective sample size and weighted summaries of ``values``.
    """
    n = len(values)
    logw = np.zeros(n)
    for k, (obs, sig) in observations.items():
        x = prior_samples[k]
        logw += -0.5 * ((x - obs) / sig) ** 2
    logw -= logw.max()
    w = np.exp(logw)
    w /= w.sum()
    m = float(np.sum(w * values))
    s = float(np.sqrt(np.sum(w * (values - m) ** 2)))
    return {"mean": m, "sigma": s, "ess": float(1.0 / np.sum(w**2)), "n": float(n)}
