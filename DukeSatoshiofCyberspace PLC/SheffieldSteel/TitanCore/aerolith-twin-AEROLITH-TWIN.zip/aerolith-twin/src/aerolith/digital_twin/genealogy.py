"""Genealogy helpers (the graph itself lives in manufacturing.traceability)."""

from __future__ import annotations

from ..manufacturing.process_chain import ChainResult
from ..manufacturing.traceability import BatchGenealogy, GenealogyNode

__all__ = ["BatchGenealogy", "GenealogyNode", "genealogy_table"]


def genealogy_table(chain: ChainResult):  # type: ignore[no-untyped-def]
    import pandas as pd

    g = chain.genealogy
    assert g is not None
    return pd.DataFrame([{"node": n.node_id, "kind": n.kind, "parents": ",".join(n.parents), "timestamp": n.timestamp,
                          "input_hash": n.input_hash[:12], "node_hash": n.node_hash[:12]} for n in g.nodes])
