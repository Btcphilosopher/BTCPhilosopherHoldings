"""Screening against a user-supplied property envelope.  The twin NEVER issues a qualification."""

from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np
import pandas as pd

QUAL_STATEMENT = ("NOT QUALIFIED: this is a simulation-based screening result.  Qualification requires certified materials "
                  "testing, NDT qualification, process qualification and airworthiness approval.")


@dataclass
class Requirement:
    property: str
    minimum: float | None = None
    maximum: float | None = None
    source: str = "user supplied"


@dataclass
class QualificationSpec:
    name: str = "UNSPECIFIED"
    requirements: list[Requirement] = field(default_factory=list)
    min_pass_probability: float = 0.90
    source: str = "none supplied"


@dataclass
class QualificationResult:
    spec_name: str
    rows: list[dict[str, object]]
    screening_status: str
    qualification_status: str
    data_basis: str


def screen(members: pd.DataFrame, spec: QualificationSpec, n_illustrative: int, n_unknown: int) -> QualificationResult:
    rows: list[dict[str, object]] = []
    ok_all, any_marginal = True, False
    for r in spec.requirements:
        x = members[r.property].to_numpy(float)
        ok = np.ones(x.size, bool)
        if r.minimum is not None:
            ok &= x >= r.minimum
        if r.maximum is not None:
            ok &= x <= r.maximum
        p = float(ok.mean())
        status = "PASS" if p >= spec.min_pass_probability else "MARGINAL" if p >= 0.5 else "FAIL"
        any_marginal |= status == "MARGINAL"
        ok_all &= status == "PASS"
        rows.append({"property": r.property, "minimum": r.minimum, "maximum": r.maximum, "mean": float(x.mean()), "sigma": float(x.std(ddof=1)) if x.size > 1 else 0.0,
                     "pass_probability": p, "status": status, "requirement_source": r.source})
    if not spec.requirements:
        scr = "NO ENVELOPE SUPPLIED"
    else:
        scr = "PASS (screening)" if ok_all else "MARGINAL (screening)" if any_marginal and all(r["status"] != "FAIL" for r in rows) else "FAIL (screening)"
    basis = (f"{n_illustrative} ILLUSTRATIVE and {n_unknown} UNKNOWN parameters in use: results are not validated predictions"
             if n_illustrative or n_unknown else "no ILLUSTRATIVE/UNKNOWN parameters in use")
    return QualificationResult(spec.name, rows, scr, QUAL_STATEMENT, basis)
