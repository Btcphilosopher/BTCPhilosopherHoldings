"""AerolithTwin: runs the process chain as a digital twin with sensors, state estimation, ensembles, robustness and scorecard."""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from datetime import UTC, datetime
from typing import Any

import numpy as np
import pandas as pd

from .. import MODEL_VERSION
from ..calibration.uncertainty import summarise, variance_fractions
from ..chemistry.composition import Composition
from ..context import RunContext
from ..errors import NumericalInstabilityError
from ..inspection.defect_detection import AcceptanceCriteria, DetectionSummary, inspect_batch
from ..inspection.eddy_current import measure_conductivity_iacs
from ..inspection.microscopy import (
    measure_grain_size,
    measure_precipitate_radius,
    measure_recrystallised_fraction,
)
from ..manufacturing.process_chain import ChainResult, route_hash, run_route
from ..manufacturing.spec import RouteSpec
from ..microstructure.defects import assess_severity
from ..params import ParameterRegistry, Status, default_registry
from ..units import KELVIN_OFFSET
from .estimation import estimate_hold_temperature, importance_posterior
from .qualification import QualificationResult, QualificationSpec, screen
from .state import EstimatedMaterialState, MeasuredProcessState, TrueMaterialState
from .telemetry import DEFAULT_SENSORS, SensorSpec, telemetry_from_signals

SOURCES = ("composition", "temperature", "processing", "model")
KEY_OUTPUTS = ["density", "E_L", "yield_strength", "yield_strength_T", "uts", "elongation", "fracture_toughness",
               "fatigue_strength_1e7", "corrosion_index", "grain_size", "residual_stress_max", "specific_strength",
               "specific_modulus", "T1_fraction", "T1_radius_nm", "recrystallised_fraction", "quench_factor", "cost_usd_kg",
               "complexity", "defect_critical_count"]


@dataclass
class ProcessVariation:
    """1-sigma process variation (ILLUSTRATIVE defaults: set from plant capability data)."""

    homog_T_K: float = 3.0
    solution_T_K: float = 3.0
    ageing_T_K: float = 2.5  # nominal tolerance +/-5 K treated as 2 sigma
    entry_T_K: float = 5.0
    quench_T_K: float = 1.5
    ageing_time_rel: float = 0.02
    solution_hold_rel: float = 0.03
    quench_flow_rel: float = 0.10
    stretch_abs: float = 0.002
    thickness_rel: float = 0.003
    composition_rel: float = 0.015  # used when the composition carries no uncertainty_wt
    model_scale: float = 1.0  # multiplies the registered 1-sigma of every model parameter when sampling the 'model' source


def perturb_composition(comp: Composition, var: ProcessVariation, rng: np.random.Generator) -> Composition:
    if comp.uncertainty_wt:
        return comp.perturbed(rng)
    d: dict[str, float] = {}
    for e, v in comp.wt().items():
        if e == "Al":
            continue
        d[e] = float(max(0.0, v + rng.normal(0.0, var.composition_rel * v))) if v > 0 else 0.0
    return Composition(**d, sum_tolerance_wt=comp.sum_tolerance_wt, label=comp.label)  # type: ignore[arg-type]


def perturb_route(route: RouteSpec, var: ProcessVariation, rng: np.random.Generator, sources: tuple[str, ...],
                  centre: dict[str, float] | None = None) -> RouteSpec:
    """Return a perturbed copy of the route.  ``centre`` overrides nominal temperatures (degC) e.g. with Kalman estimates."""
    r = route.model_copy(deep=True)
    centre = centre or {}
    if "temperature" in sources:
        for st in r.homogenisation.steps:
            st.temperature_C += rng.normal(0, var.homog_T_K)
        r.solution.temperature_C = centre.get("solution_C", r.solution.temperature_C) + rng.normal(0, var.solution_T_K)
        r.ageing.temperature_C = centre.get("ageing_C", r.ageing.temperature_C) + rng.normal(0, var.ageing_T_K)
        r.quench.tank_temperature_C += rng.normal(0, var.quench_T_K)
        r.deformation.rolling.entry_temperature_C += rng.normal(0, var.entry_T_K)
    else:
        if "solution_C" in centre:
            r.solution.temperature_C = centre["solution_C"]
        if "ageing_C" in centre:
            r.ageing.temperature_C = centre["ageing_C"]
    if "processing" in sources:
        r.ageing.time_h *= 1.0 + rng.normal(0, var.ageing_time_rel)
        r.solution.hold_min *= 1.0 + rng.normal(0, var.solution_hold_rel)
        r.quench.flow_m_s *= max(0.2, 1.0 + rng.normal(0, var.quench_flow_rel))
        r.quench.stretch_percent = max(0.0, r.quench.stretch_percent + 100.0 * rng.normal(0, var.stretch_abs))
        r.deformation.rolling.final_thickness_mm *= 1.0 + rng.normal(0, var.thickness_rel)
    return r


def outputs_of(ctx: RunContext, ch: ChainResult, design_stress_fraction: float = 0.5) -> dict[str, float]:
    ps = ch.properties
    assert ps is not None
    v = dict(ps.values())
    st = ch.state
    assess_severity(st.defects, design_stress_fraction * v["yield_strength"] * 1e6, v["fracture_toughness"] * 1e6)
    v["defect_critical_count"] = float(sum(1 for d in st.defects.defects if (d.severity or 0.0) >= 1.0))
    v["T1_fraction"] = st.precip.volume_fraction("T1")
    v["T1_radius_nm"] = st.precip.mean_radius("T1") * 1e9
    v["recrystallised_fraction"] = st.grains.recrystallised_fraction if st.grains else 0.0
    v["quench_factor"] = st.quench_factor_mean
    v["grain_size_m"] = st.grains.mean_size_m if st.grains else 0.0
    v["cost_usd_kg"] = ch.cost.usd_per_kg if ch.cost else float("nan")
    v["complexity"] = ch.cost.complexity if ch.cost else float("nan")
    v["n_defects"] = float(len(st.defects.defects))
    return v


def run_member(registry: ParameterRegistry, comp: Composition, route: RouteSpec, seed: int, sources: tuple[str, ...],
               var: ProcessVariation, centre: dict[str, float] | None = None, strict: bool = False) -> dict[str, float]:
    rng = np.random.default_rng(seed)
    reg = registry.sampled(rng, scale=var.model_scale) if "model" in sources else registry
    ctx = RunContext(reg, np.random.default_rng(seed + 7919), strict)
    c = perturb_composition(comp, var, rng) if "composition" in sources else comp
    r = perturb_route(route, var, rng, sources, centre)
    ch = run_route(ctx, c, r, "ENSEMBLE", keep_snapshots=False)
    out = outputs_of(ctx, ch)
    out["seed"] = float(seed)
    return out


def run_ensemble(registry: ParameterRegistry, comp: Composition, route: RouteSpec, n: int, sources: tuple[str, ...] = SOURCES,
                 var: ProcessVariation | None = None, seed: int = 0, centre: dict[str, float] | None = None) -> pd.DataFrame:
    var = var or ProcessVariation()
    rows: list[dict[str, float]] = []
    failed: list[int] = []
    for i in range(n):
        try:
            rows.append(run_member(registry, comp, route, seed * 100003 + i, sources, var, centre))
        except NumericalInstabilityError:
            failed.append(seed * 100003 + i)  # a numerically failed member is counted and reported, never silently dropped
    if not rows:
        raise NumericalInstabilityError("every ensemble member failed numerically")
    df = pd.DataFrame(rows)
    df.attrs["n_failed"] = len(failed)
    df.attrs["failed_seeds"] = failed
    return df


@dataclass
class UncertaintyReport:
    n: int
    table: pd.DataFrame  # one row per output: mean, sigma_ensemble, sigma_model_form, sigma_total, ci95_lo/hi, source fractions
    members: pd.DataFrame
    per_source_sigma: dict[str, dict[str, float]]
    n_failed: int = 0


def uncertainty_report(registry: ParameterRegistry, comp: Composition, route: RouteSpec, n: int = 24,
                       var: ProcessVariation | None = None, seed: int = 1, per_source: bool = True,
                       outputs: list[str] | None = None) -> UncertaintyReport:
    var = var or ProcessVariation()
    allm = run_ensemble(registry, comp, route, n, SOURCES, var, seed)
    outputs = outputs or [c for c in allm.columns if c not in ("seed", "n_defects")]
    per: dict[str, dict[str, float]] = {k: {} for k in outputs}
    if per_source:
        for s in SOURCES:
            m = run_ensemble(registry, comp, route, max(8, n // 2), (s,), var, seed + 17)
            for k in outputs:
                per[k][s] = float(m[k].std(ddof=1))
    rows = []
    for k in outputs:
        x = allm[k].to_numpy(float)
        sm = summarise(x)
        key = _REL.get(k) or _REL.get(k.rsplit("_", 1)[0])
        rel = registry.get(f"unc.model_rel.{key}").value if key and registry.has(f"unc.model_rel.{key}") else 0.0
        s_form = abs(sm.mean) * (rel or 0.0)
        s_tot = math.hypot(sm.sigma, s_form)
        fr = variance_fractions({**per[k], "model_form": s_form}) if per_source else {}
        lo_b, hi_b = _BOUNDS.get(k, (None, None))
        lo, hi = sm.mean - 1.96 * s_tot, sm.mean + 1.96 * s_tot
        lo = max(lo, lo_b) if lo_b is not None else lo
        hi = min(hi, hi_b) if hi_b is not None else hi
        rows.append({"output": k, "mean": sm.mean, "sigma_ensemble": sm.sigma, "sigma_model_form": s_form, "sigma_total": s_tot,
                     "ci95_lo": lo, "ci95_hi": hi, "p05": sm.p05, "p95": sm.p95,
                     **{f"frac_{s}": fr.get(s, float("nan")) for s in (*SOURCES, "model_form")}})
    return UncertaintyReport(n, pd.DataFrame(rows).set_index("output"), allm, per, int(allm.attrs.get("n_failed", 0)))


_BOUNDS: dict[str, tuple[float | None, float | None]] = {"corrosion_index": (0.0, 1.0), "elongation": (0.0, None), "recrystallised_fraction": (0.0, 1.0),
                                                           "fracture_toughness": (0.0, None), "defect_critical_count": (0.0, None)}
_REL = {"density": "density", "E_L": "elastic_modulus", "yield_strength": "yield_strength", "yield_strength_T": "yield_strength",
        "uts": "uts", "elongation": "elongation", "fracture_toughness": "fracture_toughness", "fatigue_strength_1e7": "fatigue_strength",
        "E_T": "elastic_modulus", "G_LT": "elastic_modulus", "E_iso": "elastic_modulus", "yield_strength_L": "yield_strength", "yield_strength_45": "yield_strength",
        "fracture_toughness_LT": "fracture_toughness", "fracture_toughness_TL": "fracture_toughness", "specific_strength": "yield_strength",
        "specific_modulus": "elastic_modulus",
        "corrosion_index": "corrosion_index"}


@dataclass
class PropertyEnvelope:
    """Acceptance envelope for robustness: property -> (min, max).  If None, a retention envelope around the nominal is used."""

    limits: dict[str, tuple[float | None, float | None]] = field(default_factory=dict)
    source: str = "retention envelope around nominal (YS>=95%, K>=90%, A>=80%)"

    @staticmethod
    def retention(nominal: dict[str, float]) -> PropertyEnvelope:
        return PropertyEnvelope({"yield_strength": (0.95 * nominal["yield_strength"], None),
                                 "fracture_toughness": (0.90 * nominal["fracture_toughness"], None),
                                 "elongation": (0.80 * nominal["elongation"], None)})

    def satisfied(self, row: pd.Series | dict[str, float]) -> bool:
        for k, (lo, hi) in self.limits.items():
            x = row[k]
            if (lo is not None and x < lo) or (hi is not None and x > hi):
                return False
        return True


@dataclass
class RobustnessResult:
    yield_probability: float
    property_cv: dict[str, float]
    sensitivities: pd.DataFrame
    windows: dict[str, dict[str, float]]
    robustness_index: float
    envelope: PropertyEnvelope
    members: pd.DataFrame


_SENS_PARAMS: dict[str, tuple[str, float]] = {  # name -> (route attribute path, +/- tolerance)
    "ageing temperature [K]": ("ageing.temperature_C", 5.0),
    "ageing time [%]": ("ageing.time_h", 0.10),
    "solution temperature [K]": ("solution.temperature_C", 5.0),
    "solution hold [%]": ("solution.hold_min", 0.10),
    "quench flow [%]": ("quench.flow_m_s", 0.20),
    "stretch [% strain]": ("quench.stretch_percent", 0.5),
    "rolling entry temperature [K]": ("deformation.rolling.entry_temperature_C", 10.0),
}


def _set(route: RouteSpec, path: str, delta: float, relative: bool) -> RouteSpec:
    r = route.model_copy(deep=True)
    obj: Any = r
    parts = path.split(".")
    for p in parts[:-1]:
        obj = getattr(obj, p)
    cur = getattr(obj, parts[-1])
    setattr(obj, parts[-1], cur * (1.0 + delta) if relative else cur + delta)
    return r


def robustness(registry: ParameterRegistry, comp: Composition, route: RouteSpec, n: int = 40, var: ProcessVariation | None = None,
               envelope: PropertyEnvelope | None = None, seed: int = 3, do_windows: bool = True) -> RobustnessResult:
    var = var or ProcessVariation()
    nominal_ctx = RunContext(registry, np.random.default_rng(seed))
    nominal = outputs_of(nominal_ctx, run_route(nominal_ctx, comp, route, "NOMINAL", keep_snapshots=False))
    env = envelope or PropertyEnvelope.retention(nominal)
    mem = run_ensemble(registry, comp, route, n, ("temperature", "processing"), var, seed)
    p_yield = float(np.mean([env.satisfied(mem.iloc[i]) for i in range(len(mem))]))
    cv = {k: float(mem[k].std(ddof=1) / abs(mem[k].mean())) if mem[k].mean() else float("nan")
          for k in ("yield_strength", "uts", "elongation", "fracture_toughness")}
    rows = []
    for name, (path, tol) in _SENS_PARAMS.items():
        rel = "%" in name
        tol_eff = tol
        res = {}
        for sign in (-1, 1):
            rr = _set(route, path, sign * tol_eff, rel)
            c = RunContext(registry, np.random.default_rng(seed))
            res[sign] = outputs_of(c, run_route(c, comp, rr, "SENS", keep_snapshots=False))
        row = {"parameter": name, "tolerance": tol_eff}
        for k in ("yield_strength", "fracture_toughness", "elongation"):
            row[f"d{k}_pct_over_tolerance"] = 100.0 * (res[1][k] - res[-1][k]) / 2.0 / nominal[k]
        rows.append(row)
    windows: dict[str, dict[str, float]] = {}
    if do_windows:
        for label, path, grid, relative in (("ageing temperature", "ageing.temperature_C", np.linspace(-15, 15, 9), False),
                                            ("ageing time", "ageing.time_h", np.linspace(-0.5, 0.5, 9), True)):
            ok = []
            for g in grid:
                rr = _set(route, path, float(g), relative)
                c = RunContext(registry, np.random.default_rng(seed))
                ok.append(env.satisfied(outputs_of(c, run_route(c, comp, rr, "WIN", keep_snapshots=False))))
            ok_a = np.array(ok)
            width = float(grid[ok_a].max() - grid[ok_a].min()) if ok_a.any() else 0.0
            windows[label] = {"window_width": width, "scanned_range": float(grid.max() - grid.min()),
                              "fraction_of_scan_acceptable": float(ok_a.mean()), "is_relative": float(relative)}
    return RobustnessResult(p_yield, cv, pd.DataFrame(rows), windows, p_yield, env, mem)


@dataclass
class TwinRun:
    batch_id: str
    composition: Composition
    route: RouteSpec
    true_state: TrueMaterialState
    measured: MeasuredProcessState
    estimated: EstimatedMaterialState
    inspection: DetectionSummary | None
    uncertainty: UncertaintyReport | None
    qualification: QualificationResult | None
    scorecard: dict[str, Any]
    meta: dict[str, Any]


class AerolithTwin:
    def __init__(self, registry: ParameterRegistry | None = None, strict: bool = False, seed: int = 0,
                 sensors: dict[str, SensorSpec] | None = None, variation: ProcessVariation | None = None):
        self.registry = registry or default_registry()
        self.strict = strict
        self.seed = seed
        self.sensors = sensors or DEFAULT_SENSORS
        self.variation = variation or ProcessVariation()

    def ctx(self, seed: int | None = None) -> RunContext:
        return RunContext(self.registry, np.random.default_rng(self.seed if seed is None else seed), self.strict)

    # -- full twin run ---------------------------------------------------------------------------------------------------
    def run(self, comp: Composition, route: RouteSpec, batch_id: str = "AL-LI-000421", n_ensemble: int = 0,
            inspect: bool = True, criteria: AcceptanceCriteria | None = None, qual: QualificationSpec | None = None,
            methods: list[str] | None = None, frozen_time: str | None = None, n_posterior: int = 0) -> TwinRun:
        ctx = self.ctx()
        chain = run_route(ctx, comp, route, batch_id, keep_snapshots=True, frozen_time=frozen_time)
        st = chain.state
        ps = chain.properties
        assert ps is not None
        truth = outputs_of(ctx, chain)
        # virtual plant instrumentation
        rng_s = np.random.default_rng(self.seed + 101)
        tel = telemetry_from_signals(chain.signals, rng_s, self.sensors)
        mctx = self.ctx(self.seed + 202)
        gm = measure_grain_size(mctx, st)
        t1r = measure_precipitate_radius(mctx, st, "T1")
        xr = measure_recrystallised_fraction(mctx, st)
        cond = measure_conductivity_iacs(mctx, st, mctx.rng)
        from ..provenance import Provenance, Quantity

        measured = MeasuredProcessState(tel, {"grain_size": gm.equivalent_size_m, "T1_radius": t1r, "recrystallised_fraction": xr},
                                        Quantity("electrical_conductivity_iacs", cond, "%IACS", 0.005 * cond, Provenance.SIMULATED,
                                                 "virtual instrument", "synthetic measurement"))
        ndt = None
        if inspect:
            ndt = inspect_batch(ctx, st, methods, criteria, ps.density_kg_m3, 0.5 * truth["yield_strength"], truth["fracture_toughness"])
            measured.ndt = ndt
        # estimation: Kalman estimates of the thermal states from telemetry
        est = EstimatedMaterialState()
        centre: dict[str, float] = {}
        for key, ch_name, label in (("ageing_C", "ageing_furnace_T", "ageing"), ("solution_C", "solution_furnace_T", "solution")):
            d = tel[tel.channel == ch_name]
            if d.empty:
                continue
            if label == "solution":
                T_K = route.solution.temperature_C + KELVIN_OFFSET
                ramp = (T_K - 293.0) / (route.solution.heating_rate_K_min / 60.0)
                hold = route.solution.hold_min * 60.0
            else:
                T_K = route.ageing.temperature_C + KELVIN_OFFSET
                ramp = (T_K - 293.0) / 0.05
                hold = route.ageing.time_h * 3600.0
            window = (ramp + 0.3 * hold, ramp + hold)
            e = estimate_hold_temperature(d, self.sensors[ch_name], window)
            t_true, y_true, _u = chain.signals[ch_name]
            sel = (t_true >= window[0]) & (t_true <= window[1])
            truth_hold = float(np.mean(y_true[sel])) if sel.any() else float(y_true[-1])
            est.process[label] = {"estimated_T_K": e.mean_temperature_K, "sigma_K": e.sigma_K, "bias_estimate_K": e.bias_estimate_K,
                                  "true_hold_T_K_for_validation": truth_hold, "n_valid": e.n_valid, "n_missing": e.n_missing}
            centre[key] = e.mean_temperature_K - KELVIN_OFFSET
        # Bayesian posterior (importance-weighted ensemble)
        unc = None
        if n_ensemble > 0:
            unc = uncertainty_report(self.registry, comp, route, n_ensemble, self.variation, self.seed + 5, per_source=True)
        if n_posterior > 0:
            prior = run_ensemble(self.registry, comp, route, n_posterior, ("temperature", "processing", "composition"), self.variation, self.seed + 9)
            post = run_ensemble(self.registry, comp, route, n_posterior, ("temperature", "processing", "composition"), self.variation, self.seed + 11, centre)
            obs = {"grain_size_m": (gm.equivalent_size_m.value, max(gm.equivalent_size_m.sigma or 1e-6, 1e-6) * 1.5),
                   "T1_radius_nm": (t1r.value * 1e9, max((t1r.sigma or 1e-10) * 1e9, 0.05) * 1.5)}
            for k in ("yield_strength", "uts", "fracture_toughness"):
                est.prior[k] = {"mean": float(prior[k].mean()), "sigma": float(prior[k].std(ddof=1))}
                w = importance_posterior(post[k].to_numpy(float), {kk: post[kk].to_numpy(float) for kk in obs}, obs)
                est.posterior[k] = {"mean": w["mean"], "sigma": w["sigma"]}
                est.effective_sample_size = w["ess"]
            est.n_members = n_posterior
        card = self.scorecard(chain, truth, ndt, unc, est, ctx.ledger_summary())
        qres = None
        if qual is not None:
            members = unc.members if unc is not None else pd.DataFrame([truth])
            counts = ctx.ledger_summary()
            qres = screen(members, qual, counts.get("ILLUSTRATIVE", 0), counts.get("UNKNOWN", 0))
        meta = self.metadata(chain, ctx, comp, route)
        return TwinRun(batch_id, comp, route, TrueMaterialState(st, chain), measured, est, ndt, unc, qres, card, meta)

    def metadata(self, chain: ChainResult, ctx: RunContext, comp: Composition, route: RouteSpec) -> dict[str, Any]:
        return {
            "model_version": MODEL_VERSION, "parameter_version": self.registry.version(),
            "simulation_timestamp": datetime.now(UTC).isoformat(timespec="seconds"),
            "input_hash": route_hash(comp, route), "dataset_version": "none (uncalibrated)" if not any(
                p.status is Status.CALIBRATED for p in (self.registry.get(n) for n in self.registry.names())) else "calibrated parameters present",
            "units": "SI internally (K, Pa, m, s); reporting units stated per quantity",
            "uncertainty": "1-sigma / 95% intervals from Monte Carlo ensembles (composition, temperature, processing, model) plus model-form term",
            "parameter_status_in_use": ctx.ledger_summary(),
            "parameters_in_use": dict(ctx.ledger),
            "models_used": sorted(ctx.models_used),
        }

    def scorecard(self, chain: ChainResult, truth: dict[str, float], ndt: DetectionSummary | None,
                  unc: UncertaintyReport | None, est: EstimatedMaterialState, ledger: dict[str, int] | None = None) -> dict[str, Any]:
        st = chain.state
        ps = chain.properties
        assert ps is not None
        sr = chain.stage_results
        prec = st.precip.summary()
        tex = st.texture.normalised()
        dom = sorted(((k, v) for k, v in tex.items() if v > 0.02), key=lambda kv: -kv[1])[:4]
        card: dict[str, Any] = {
            "MATERIAL STATE": {
                "Density [kg/m3]": truth["density"], "Elastic Modulus E_L [GPa]": truth["E_L"],
                "Yield Strength L [MPa]": truth["yield_strength"], "UTS L [MPa]": truth["uts"],
                "Fracture Toughness L-T [MPa m^0.5]": truth["fracture_toughness"], "Fatigue strength 1e7, R=-1 [MPa]": truth["fatigue_strength_1e7"],
                "Grain Size [um]": truth["grain_size"], "Grain aspect ratio": st.grains.aspect_ratio if st.grains else None,
                "Precipitate State": {k: v for k, v in prec.items() if v["volume_fraction"] > 1e-6},
                "Texture": {"index": st.texture.index(), "dominant": dom},
                "Residual Stress max [MPa]": truth["residual_stress_max"],
                "Defect Probability (P[any defect with a >= a_crit])": (float((unc.members["defect_critical_count"] > 0).mean()) if unc is not None
                                                                         else float(truth["defect_critical_count"] > 0)),
            },
            "PROCESS STATE": {
                "Furnace": {
                    "solution": {"peak_part_T_K": float(sr["solution"]["furnace"].part.peak_K()) if "solution" in sr else None,
                                 "furnace_offset_K": sr["solution"]["furnace"].offset_K if "solution" in sr else None},
                    "ageing": {"furnace_offset_K": sr["ageing"]["furnace"].offset_K if "ageing" in sr else None}},
                "Rolling": ({"passes": len(sr["deformation"]["result"].history.steps), "max_force_MN": sr["deformation"]["result"].max_force_n / 1e6,
                             "mill_force_utilisation": sr["deformation"]["mill"].force_utilisation} if "deformation" in sr and "mill" in sr["deformation"] else {}),
                "Quench": ({"cooling_rate_window_centre_K_s": sr["quench"]["result"].cooling_rate_window_centre_K_s,
                            "quench_factor_mean": sr["quench"]["result"].quench_factor_mean,
                            "distortion_risk": sr["quench"]["result"].residual.distortion_risk} if "quench" in sr else {}),
                "Ageing": ({"regime": sr["ageing"]["result"].regime, "t_peak_h": sr["ageing"]["result"].t_peak_s / 3600.0} if "ageing" in sr else {}),
                "Inspection": ({"true_defects": ndt.n_true, "detected": ndt.n_detected, "methods": ndt.methods} if ndt else {}),
            },
        }
        ledger = ledger or {}
        n_ill, n_unk = ledger.get("ILLUSTRATIVE", 0), ledger.get("UNKNOWN", 0)
        n_lit, n_cal = ledger.get("LITERATURE_APPROX", 0), ledger.get("CALIBRATED", 0) + ledger.get("USER_SUPPLIED", 0)
        yv = (unc.table.loc["yield_strength", "sigma_total"] / unc.table.loc["yield_strength", "mean"]) if unc is not None else None
        cv = self.registry.get("mic.intercept_cv").value or 0.0
        card["CONFIDENCE"] = {
            "Model confidence": ("LOW — " + f"{n_ill} ILLUSTRATIVE parameters in use (placeholders; results are trends, not validated predictions)" if n_ill or n_unk else
                                 "MEDIUM — LITERATURE_APPROX parameters in use (verify)" if n_lit else "HIGH — only REFERENCE/CALIBRATED/USER_SUPPLIED parameters"),
            "Data confidence": (f"{n_cal} calibrated/user-supplied parameters in use" if n_cal else "NONE — no experimental calibration dataset applied"),
            "Measurement confidence": f"virtual grain-size measurement relative error {100 * cv / math.sqrt(400):.1f}% (1 sigma, 400 intercepts); thermal sensors per DEFAULT_SENSORS",
            "Prediction uncertainty (yield strength, 1-sigma relative)": yv,
        }
        _ = est
        return card
