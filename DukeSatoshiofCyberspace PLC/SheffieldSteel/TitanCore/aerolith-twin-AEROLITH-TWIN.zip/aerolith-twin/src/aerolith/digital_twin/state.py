"""The three states the twin keeps apart: TRUE material state, MEASURED process state, ESTIMATED material state."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

import pandas as pd

from ..manufacturing.process_chain import ChainResult
from ..microstructure.state import MaterialState
from ..provenance import Quantity


@dataclass
class TrueMaterialState:
    """Ground truth *inside the simulation*.  (In a real plant this is never directly observable.)"""

    material: MaterialState
    chain: ChainResult


@dataclass
class MeasuredProcessState:
    """Everything the plant would actually see: sensor telemetry and instrument readings (virtual instruments, SIMULATED)."""

    telemetry: pd.DataFrame
    microscopy: dict[str, Quantity] = field(default_factory=dict)
    conductivity_iacs: Quantity | None = None
    ndt: Any = None


@dataclass
class EstimatedMaterialState:
    """Twin posterior: process-state Kalman estimates + importance-weighted ensemble posterior of material properties."""

    process: dict[str, dict[str, float]] = field(default_factory=dict)
    prior: dict[str, dict[str, float]] = field(default_factory=dict)
    posterior: dict[str, dict[str, float]] = field(default_factory=dict)
    effective_sample_size: float = 0.0
    n_members: int = 0
