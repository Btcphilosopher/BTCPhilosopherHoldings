"""As-cast grain structure: growth-restriction (Greer-type) model + columnar/equiaxed tendency."""

from __future__ import annotations

import math

from ..chemistry.composition import Composition
from ..governance import ModelMeta, register
from ..microstructure.grains import GrainState
from ..params import P, Status, declare
from .solidification import SolidificationResult

declare(
    P("cast.grain.d_a", 6.0e-5, "m", Status.ILLUSTRATIVE, "d = d_a + d_b/Q + refiner term; placeholder", 0.3, 1e-5, 1e-3, True),
    P("cast.grain.d_b", 3.0e-3, "m K", Status.ILLUSTRATIVE, "d = d_a + d_b/Q; placeholder", 0.3, 1e-4, 1e-1, True),
    P("cast.grain.ti_refine", 6.0, "1/wt%^0.5", Status.ILLUSTRATIVE, "grain-refiner (Ti/B) efficiency", 0.4, 0.0, 50.0, True),
    P("cast.grain.rate_exp", 0.15, "-", Status.ILLUSTRATIVE, "d ~ Tdot^-n around 1 K/s", 0.05, 0.0, 0.5),
    P("cast.grain.sigma_ln", 0.45, "-", Status.ILLUSTRATIVE, "log-std of equiaxed grain-size distribution", 0.08, 0.1, 1.0),
    P("cast.grain.GV_crit", 3.0e5, "K s/m2", Status.ILLUSTRATIVE, "G/V above which columnar growth dominates (CET)", 0.5, 1e3, 1e8, True),
)

META = register(ModelMeta(
    model_name="as_cast_grain_growth_restriction",
    equation="Q = -sum m_i c_i (k_i - 1) ; d = (d_a + d_b/Q) / (1 + c_ref sqrt(Ti)) * (Tdot/1 K/s)^-n ; columnar = 1/(1+(GV_crit/(G/V))^2)",
    parameter_source="registry cast.grain.* (ILLUSTRATIVE) with cast.mL.*, cast.k.*",
    validity_range="equiaxed DC/ingot-like structures; no grain-refiner fade; no fluid flow; qualitative CET",
))


def growth_restriction_factor(ctx, comp: Composition) -> float:  # type: ignore[no-untyped-def]
    q = 0.0
    for el, w in comp.present().items():
        if el == "Al" or not (ctx.registry.is_known(f"cast.k.{el}") and ctx.registry.is_known(f"cast.mL.{el}")):
            continue
        q -= ctx.p(f"cast.mL.{el}") * w * (ctx.p(f"cast.k.{el}") - 1.0)
    return max(q, 1e-3)


def as_cast_grains(ctx, comp: Composition, sol: SolidificationResult) -> GrainState:  # type: ignore[no-untyped-def]
    ctx.use(META.model_name)
    Q = growth_restriction_factor(ctx, comp)
    rate = float(sol.cooling_rate_K_s[-1])
    d = ctx.p("cast.grain.d_a") + ctx.p("cast.grain.d_b") / Q
    d /= 1.0 + ctx.p("cast.grain.ti_refine") * math.sqrt(max(comp.Ti, 0.0))
    d *= max(rate, 1e-3) ** (-ctx.p("cast.grain.rate_exp"))
    i = int(0.5 * len(sol.x_m))
    gv = float(sol.gradient_K_m[i]) / max(float(sol.front_velocity_m_s[i]), 1e-9)
    col = 1.0 / (1.0 + (ctx.p("cast.grain.GV_crit") / max(gv, 1e-9)) ** 2)
    ar = 1.0 + 2.0 * col  # columnar zones are elongated along the heat-flow (normal) direction
    # as-cast: elongation along ND (heat-flow), so d_N is the long axis; express in sample frame L,T,N
    base = d / ar ** (1.0 / 3.0)
    return GrainState(d_L=base, d_T=base, d_N=base * ar, sigma_ln=ctx.p("cast.grain.sigma_ln"),
                      recrystallised_fraction=0.0, columnar_fraction=col)
