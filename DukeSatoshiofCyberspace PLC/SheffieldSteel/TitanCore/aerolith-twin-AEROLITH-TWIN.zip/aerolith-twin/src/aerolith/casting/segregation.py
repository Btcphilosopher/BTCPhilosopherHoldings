"""Microsegregation: Scheil-Gulliver with Clyne-Kurz back diffusion and eutectic cut-off.

C_s(f_s) = k C0 [1 - (1 - 2 alpha' k) f_s]^{(k-1)/(1 - 2 alpha' k)}
alpha' = alpha (1 - exp(-1/alpha)) - 0.5 exp(-1/(2 alpha)),  alpha = D_s t_f / L^2,  L = lambda2/2
(alpha' -> 0 recovers Scheil-Gulliver).  Partition coefficients, liquidus slopes and
eutectic compositions come from the parameter registry; elements without them (UNKNOWN)
are excluded and reported.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field

import numpy as np

from ..chemistry.composition import Composition
from ..governance import ModelMeta, register
from ..homogenisation.diffusion import diffusivity
from ..params import P, Status, declare
from .solidification import SolidificationResult

declare(
    P("cast.sdas_A", 5.0e-5, "m K^(1/3) s^(-1/3)", Status.ILLUSTRATIVE, "lambda2 = A * Tdot^(-n); calibrate to metallography", 0.25, 5e-6, 5e-4, True),
    P("cast.sdas_n", 1.0 / 3.0, "-", Status.LITERATURE_APPROX, "classical coarsening exponent for secondary arm spacing", 0.04, 0.2, 0.5),
    P("cast.Ce.Li", 9.9, "wt%", Status.ILLUSTRATIVE, "terminal liquid composition used for eutectic cut-off", 2.0, 1.0, 40),
    P("cast.Ce.Cu", 33.0, "wt%", Status.LITERATURE_APPROX, "Al-Cu eutectic composition (binary)", 2.0, 1.0, 60),
    P("cast.Ce.Mg", 35.0, "wt%", Status.LITERATURE_APPROX, "Al-Mg eutectic composition (binary)", 3.0, 1.0, 60),
    P("cast.Ce.Zn", 95.0, "wt%", Status.ILLUSTRATIVE, "effectively no eutectic cut-off in dilute range", 3.0, 1.0, 99),
    P("cast.Ce.Ag", 69.0, "wt%", Status.ILLUSTRATIVE, "binary eutectic composition", 5.0, 1.0, 95),
    P("cast.Ce.Mn", 1.9, "wt%", Status.ILLUSTRATIVE, "terminal liquid composition", 0.5, 0.5, 20),
    P("cast.Ce.Fe", 1.8, "wt%", Status.LITERATURE_APPROX, "Al-Fe eutectic composition (binary)", 0.3, 0.5, 20),
    P("cast.Ce.Si", 12.6, "wt%", Status.LITERATURE_APPROX, "Al-Si eutectic composition (binary)", 0.8, 1.0, 40),
)

META = register(ModelMeta(
    model_name="microsegregation_clyne_kurz",
    equation="Cs = k C0 [1-(1-2 a' k) fs]^((k-1)/(1-2 a' k)); a' = a(1-exp(-1/a)) - 0.5 exp(-1/(2a)); a = Ds tf / L^2",
    parameter_source="registry cast.k.*, cast.mL.*, cast.Ce.*, diff.* (mixed LITERATURE_APPROX / ILLUSTRATIVE)",
    validity_range="dilute multicomponent alloy treated as independent binaries; no solute-solute coupling; no coarsening term; 0.05 < k < 10",
))


def _cs_profile(k: float, C0: float, alpha_ck: float, fs: np.ndarray) -> np.ndarray:
    a = 1.0 - 2.0 * alpha_ck * k
    if abs(a) < 1e-9:
        a = 1e-9
    base = np.clip(1.0 - a * fs, 1e-12, None)
    return k * C0 * base ** ((k - 1.0) / a)


def clyne_kurz_alpha(alpha: float) -> float:
    if alpha <= 0:
        return 0.0
    if alpha > 50:
        return 0.5
    return alpha * (1.0 - math.exp(-1.0 / alpha)) - 0.5 * math.exp(-1.0 / (2.0 * alpha))


@dataclass
class SegregationResult:
    fs: np.ndarray
    C_solid_wt: dict[str, np.ndarray]
    C_liquid_wt: dict[str, np.ndarray]
    C0_wt: dict[str, float]
    f_eutectic: float
    eutectic_element: str | None
    eutectic_solute_wt: dict[str, float]  # solute held in eutectic constituent, wt% of alloy
    lambda2_m: float
    solidification_time_s: float
    alpha: dict[str, float]
    segregation_index: dict[str, float]  # max solid composition / C0 in the dendrite
    hot_tearing_index: float
    excluded: list[str] = field(default_factory=list)

    def solid_cut_index(self) -> int:
        return int(np.searchsorted(self.fs, 1.0 - self.f_eutectic))

    def matrix_profile(self, element: str, n: int = 128) -> np.ndarray:
        """Solid-phase composition (wt%) on n equal-width cells from dendrite core (0) to boundary (1),
        eutectic region excluded and the profile re-sampled on the solid range."""
        fs_cut = max(1.0 - self.f_eutectic, 1e-6)
        x = (np.arange(n) + 0.5) / n * fs_cut
        return np.interp(x, self.fs, self.C_solid_wt[element])


def microsegregation(ctx, comp: Composition, sol: SolidificationResult, position: str = "centre") -> SegregationResult:  # type: ignore[no-untyped-def]
    ctx.use(META.model_name)
    i = -1 if position == "centre" else int(len(sol.x_m) * 0.5)
    t_f = float(sol.local_solidification_time_s[i])
    rate = float(sol.cooling_rate_K_s[i])
    lam2 = ctx.p("cast.sdas_A") * rate ** (-ctx.p("cast.sdas_n"))
    L = 0.5 * lam2
    T_mid = 0.5 * (sol.T_liquidus_K + sol.T_solidus_K)
    fs = np.linspace(0.0, 0.9995, 2000)
    Cs: dict[str, np.ndarray] = {}
    Cl: dict[str, np.ndarray] = {}
    alphas: dict[str, float] = {}
    excluded: list[str] = []
    fs_eut: dict[str, float] = {}
    C0s: dict[str, float] = {}
    for el, w in comp.present().items():
        if el == "Al":
            continue
        if not (ctx.registry.is_known(f"cast.k.{el}") and ctx.registry.is_known(f"cast.mL.{el}")):
            excluded.append(el)
            continue
        k = ctx.p(f"cast.k.{el}")
        Ds = diffusivity(ctx, el, T_mid)
        alpha = Ds * t_f / L**2
        a_ck = clyne_kurz_alpha(alpha)
        cs = _cs_profile(k, w, a_ck, fs)
        Cs[el], Cl[el], alphas[el], C0s[el] = cs, cs / k, alpha, w
        if k < 1.0 and ctx.registry.has(f"cast.Ce.{el}"):
            Ce = ctx.p(f"cast.Ce.{el}")
            hit = np.nonzero(cs / k >= Ce)[0]
            if hit.size:
                fs_eut[el] = float(fs[hit[0]])
    f_e, e_el = 0.0, None
    if fs_eut:
        e_el = min(fs_eut, key=lambda e: fs_eut[e])
        f_e = 1.0 - fs_eut[e_el]
    cut = int(np.searchsorted(fs, 1.0 - f_e)) if f_e > 0 else len(fs)
    eut_solute: dict[str, float] = {}
    sindex: dict[str, float] = {}
    for el in Cs:
        # mass balance: C0 = int_0^1 Cs dfs; solute left for the terminal eutectic
        solid_part = float(np.trapezoid(Cs[el][:cut], fs[:cut])) if cut > 1 else 0.0
        eut_solute[el] = max(0.0, C0s[el] - solid_part) if f_e > 0 else 0.0
        sindex[el] = float(Cs[el][:max(cut, 2)].max() / C0s[el])
    # Clyne-Davies hot-cracking susceptibility from the temperature-fs relation of the retained solutes
    T_of_fs = ctx.p("cast.T_melt_Al") - sum(ctx.p(f"cast.mL.{e}") * Cl[e] for e in Cl)
    def t_at(f: float) -> float:
        return float(np.interp(f, fs, T_of_fs))
    denom = t_at(0.40) - t_at(0.90)
    csc = (t_at(0.90) - t_at(0.99)) / denom if abs(denom) > 1e-6 else 0.0
    return SegregationResult(fs, Cs, Cl, C0s, f_e, e_el, eut_solute, lam2, t_f, alphas, sindex, float(abs(csc)), excluded)
