"""Casting defect generation: gas + shrinkage porosity, oxide/inclusion population, hot tears, centreline segregation.

The population is generated for a reference material volume.  Defects above a reporting
threshold are enumerated individually (Poisson tail of a lognormal size law); the
sub-threshold bulk is carried as statistics in ``pop.bulk``.
"""

from __future__ import annotations

import math

import numpy as np
from scipy.stats import norm

from ..chemistry.composition import Composition
from ..governance import ModelMeta, register
from ..microstructure.defects import DefectPopulation, DefectType
from ..params import P, Status, declare
from .segregation import SegregationResult
from .solidification import CastingInputs, SolidificationResult

declare(
    P("cast.H_solid_solubility", 0.036, "mL STP/100 g", Status.LITERATURE_APPROX, "hydrogen solubility in solid Al near the solidus; Li/Mg melts pick up more H", 0.01, 0.005, 0.2),
    P("cast.H_pore_efficiency", 0.05, "-", Status.ILLUSTRATIVE, "fraction of rejected H forming pore volume (nucleation-limited)", 0.5, 1e-3, 1.0, True),
    P("cast.niyama_crit", 1.0, "(K s)^0.5/mm", Status.ILLUSTRATIVE, "Niyama threshold for feeding-limited shrinkage porosity", 0.4, 0.1, 5.0, True),
    P("cast.shrink_efficiency", 0.04, "-", Status.ILLUSTRATIVE, "fraction of solidification shrinkage appearing as distributed porosity when feeding fails", 0.5, 1e-3, 1.0, True),
    P("cast.pore_d_factor", 0.6, "-", Status.ILLUSTRATIVE, "median pore diameter / lambda2", 0.3, 0.1, 5.0, True),
    P("cast.pore_sigma_ln", 0.45, "-", Status.ILLUSTRATIVE, "log-std of pore diameter", 0.1, 0.2, 1.5),
    P("cast.pore_report_size", 4.0e-4, "m", Status.ILLUSTRATIVE, "individual-reporting threshold for pores", 0.0),
    P("cast.oxide_rate", 8.0e2, "1/m3", Status.ILLUSTRATIVE, "large oxide-film/inclusion count per m3 of nominal melt", 0.6, 0.0, 1e6, True),
    P("cast.inclusion_d50", 1.5e-4, "m", Status.ILLUSTRATIVE, "median inclusion size", 0.3, 1e-5, 2e-3, True),
    P("cast.hot_tear_crit", 1.5, "-", Status.ILLUSTRATIVE, "Clyne-Davies CSC above which hot tears are generated", 0.1, 0.05, 2.0),
    P("cast.hot_tear_rate", 6.0, "1/m3 per unit CSC excess", Status.ILLUSTRATIVE, "hot-tear count per m3", 0.6, 0.0, 1e4, True),
    P("cast.seg_zone_rate", 0.3, "1/m3 per unit (index-1)", Status.ILLUSTRATIVE, "macro-segregation zones per m3", 0.6, 0.0, 100.0, True),
)

META = register(ModelMeta(
    model_name="casting_defect_population",
    equation="f_gas = eta_H (H - H_s)/100 rho T/273 ; f_shr = beta eta_s /(1+(Ny/Ny_c)^4) ; Poisson tail of lognormal size law",
    parameter_source="registry cast.* (ILLUSTRATIVE unless calibrated)",
    validity_range="screening-level defect statistics for a reference volume; not a defect-location prediction for a specific casting",
    fidelity="EMPIRICAL",
))


def _tail_sizes(rng: np.random.Generator, n_total: float, median: float, sigma: float, threshold: float,
                cap: int = 3000) -> np.ndarray:
    mu = math.log(median)
    p_tail = float(norm.sf((math.log(threshold) - mu) / sigma))
    n = int(min(rng.poisson(max(n_total * p_tail, 0.0)), cap))
    if n == 0:
        return np.empty(0)
    u = rng.uniform(0.0, p_tail, n)  # inverse-CDF sampling inside the tail
    return np.exp(mu + sigma * norm.isf(np.clip(u, 1e-300, 1 - 1e-12)))


def generate_cast_defects(ctx, comp: Composition, sol: SolidificationResult, seg: SegregationResult,  # type: ignore[no-untyped-def]
                          inp: CastingInputs, volume_m3: float,
                          dims_m: tuple[float, float, float]) -> DefectPopulation:
    ctx.use(META.model_name)
    rng = ctx.rng
    from ..properties.density import density_kg_m3

    pop = DefectPopulation(volume_m3, dims_m)
    rho = density_kg_m3(ctx, comp).value
    ci = -1
    G = float(sol.gradient_K_m[ci]) / 1000.0  # K/mm
    rate = float(sol.cooling_rate_K_s[ci])
    ny = G / math.sqrt(max(rate, 1e-9))
    ny_c = ctx.p("cast.niyama_crit")
    f_sh = ctx.p("cast.shrinkage_beta") * ctx.p("cast.shrink_efficiency") / (1.0 + (ny / ny_c) ** 4)
    excess = max(0.0, inp.hydrogen_ml_per_100g - ctx.p("cast.H_solid_solubility"))
    gas_ml_per_g = excess / 100.0
    f_h = ctx.p("cast.H_pore_efficiency") * gas_ml_per_g * (rho / 1.0e6) * 1.0e6 / 1000.0 * (sol.T_solidus_K / 273.15)
    f_h = min(f_h, 0.05)
    f_p = f_sh + f_h
    d50 = ctx.p("cast.pore_d_factor") * seg.lambda2_m
    sg = ctx.p("cast.pore_sigma_ln")
    mean_vol = math.pi / 6.0 * d50**3 * math.exp(4.5 * sg**2)
    n_total = f_p * volume_m3 / mean_vol if mean_vol > 0 else 0.0
    thr = ctx.p("cast.pore_report_size")
    sizes = _tail_sizes(rng, n_total, d50, sg, thr)
    for s in sizes:
        pos = (rng.uniform(), rng.uniform(), float(np.clip(rng.beta(4.0, 4.0), 0.0, 1.0)))  # centre-biased through thickness
        ori = rng.normal(size=3)
        pop.add(DefectType.POROSITY, float(s), pos, ori, aspect_ratio=1.0 + 0.5 * rng.random(), confidence=0.4,
                origin="cast: gas+shrinkage")
    pop.bulk.update({
        "cast_porosity_fraction": f_p, "gas_porosity_fraction": f_h, "shrink_porosity_fraction": f_sh,
        "niyama": ny, "pore_d50_m": d50, "sub_threshold_count": max(0.0, n_total - len(sizes)),
    })
    # oxide films / inclusions
    n_inc = rng.poisson(ctx.p("cast.oxide_rate") * inp.oxide_film_index * volume_m3)
    d50i = ctx.p("cast.inclusion_d50")
    for _ in range(int(min(n_inc, 5000))):
        s = float(rng.lognormal(math.log(d50i), 0.5))
        pop.add(DefectType.INCLUSION, s, (rng.uniform(), rng.uniform(), rng.uniform()), rng.normal(size=3),
                aspect_ratio=1.0 + 3.0 * rng.random(), confidence=0.3, origin="cast: oxide film / inclusion")
    # hot tears
    csc = seg.hot_tearing_index
    mu_ht = ctx.p("cast.hot_tear_rate") * max(0.0, csc - ctx.p("cast.hot_tear_crit")) * volume_m3
    for _ in range(int(min(rng.poisson(mu_ht), 500))):
        s = float(rng.lognormal(math.log(2.0e-3), 0.6))
        pop.add(DefectType.CRACK, s, (rng.uniform(), rng.uniform(), float(rng.beta(2.0, 2.0))), rng.normal(size=3),
                aspect_ratio=3.0, confidence=0.25, origin="cast: hot tear")
    pop.bulk["hot_tearing_index"] = csc
    # macro-segregation zones
    idx = max(seg.segregation_index.values(), default=1.0)
    mu_sz = ctx.p("cast.seg_zone_rate") * max(0.0, idx - 1.0) * volume_m3
    for _ in range(int(min(rng.poisson(mu_sz), 200))):
        s = float(rng.lognormal(math.log(6.0e-3), 0.5))
        pop.add(DefectType.SEGREGATION, s, (rng.uniform(), rng.uniform(), float(np.clip(rng.normal(0.5, 0.05), 0, 1))),
                rng.normal(size=3), aspect_ratio=4.0, confidence=0.3, origin="cast: macro-segregation")
    return pop
