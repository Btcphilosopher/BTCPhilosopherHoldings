"""Cooling helpers and analytical references."""

from __future__ import annotations

import math
from dataclasses import dataclass

import numpy as np


@dataclass
class CoolingHistory:
    t_s: np.ndarray
    T_surface_K: np.ndarray
    T_centre_K: np.ndarray

    def rate_centre_K_s(self) -> np.ndarray:
        return np.gradient(self.T_centre_K, self.t_s)


def biot(h: float, half_thickness: float, k: float) -> float:
    return h * half_thickness / k


def lumped_cooling(T0: float, T_inf: float, h: float, volume_per_area: float, rho: float, cp: float,
                   t: np.ndarray | float) -> np.ndarray | float:
    """T(t) = T_inf + (T0 - T_inf) exp(-h t / (rho cp V/A)).  Valid for Bi << 1."""
    tau = rho * cp * volume_per_area / h
    return T_inf + (T0 - T_inf) * np.exp(-np.asarray(t) / tau)


def semi_infinite_surface_temperature(T0: float, T_wall: float, t: float, alpha: float, k: float, h: float) -> float:
    """Surface temperature of a semi-infinite solid with convective BC (exact, erfc form)."""
    from scipy.special import erfc

    if t <= 0:
        return T0
    beta = h * math.sqrt(alpha * t) / k
    theta = 1.0 - (math.exp(beta**2) * erfc(beta) if beta < 20 else 1.0 / (beta * math.sqrt(math.pi)))
    # theta_surface = (T0 - Ts)/(T0 - Tinf) = 1 - exp(b^2) erfc(b)
    return T0 - (T0 - T_wall) * theta


def chvorinov_time(volume: float, area: float, B: float, n: float = 2.0) -> float:
    """t = B (V/A)^n  (B in s m^-n)."""
    return B * (volume / area) ** n
