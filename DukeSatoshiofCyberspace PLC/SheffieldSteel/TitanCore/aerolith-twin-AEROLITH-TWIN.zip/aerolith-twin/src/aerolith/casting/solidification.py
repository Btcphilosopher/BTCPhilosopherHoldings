"""Reduced-order 1-D plate solidification (enthalpy method, finite volume).

Half-thickness slab, symmetry at the mid-plane, convective interface to a mould/chill
at constant temperature.  This is NOT a CFD casting package: no fluid flow, no 3-D
geometry, no mould heating.  The effective interface coefficient can be back-solved so
the mean mushy-zone cooling rate at the section centre matches a supplied cooling rate.
"""

from __future__ import annotations

import math
from dataclasses import dataclass

import numpy as np
from numba import njit
from scipy.optimize import brentq

from ..chemistry.composition import Composition
from ..errors import NumericalInstabilityError
from ..governance import ModelMeta, register
from ..params import P, Status, declare
from .cooling import CoolingHistory

_LIT = "Handbook-order value for Al alloys; verify against measured alloy data"
_ILL = "Engineering placeholder; calibrate to casting trials"
declare(
    P("cast.T_melt_Al", 933.47, "K", Status.REFERENCE, "melting point of pure Al", 0.1),
    P("cast.cp", 1050.0, "J/kg/K", Status.LITERATURE_APPROX, _LIT, 80.0, 800.0, 1400.0),
    P("cast.k_solid", 110.0, "W/m/K", Status.ILLUSTRATIVE, "Al-Li-Cu alloys are poorer conductors than pure Al; value is a placeholder", 15.0, 40.0, 240.0),
    P("cast.k_liquid", 80.0, "W/m/K", Status.ILLUSTRATIVE, _ILL, 15.0, 30.0, 200.0),
    P("cast.latent_heat", 3.7e5, "J/kg", Status.LITERATURE_APPROX, "pure Al ~397 kJ/kg; alloys lower", 2.0e4, 2.5e5, 4.2e5),
    P("cast.h_interface", 1500.0, "W/m2/K", Status.ILLUSTRATIVE, "effective DC-casting-like interface coefficient; calibrate", 0.3, 50.0, 1e5, True),
    P("cast.T_eutectic", 773.0, "K", Status.ILLUSTRATIVE, "effective non-equilibrium solidus used by the thermal solver; replace with CALPHAD Scheil solidus", 15.0, 650.0, 900.0),
    P("cast.shrinkage_beta", 0.065, "-", Status.LITERATURE_APPROX, "solidification shrinkage of Al ~6-7 %", 0.01, 0.03, 0.09),
    # liquidus slopes (K per wt%, positive = lowers liquidus) and partition coefficients
    P("cast.mL.Li", 5.5, "K/wt%", Status.ILLUSTRATIVE, _ILL, 1.5, -10, 20),
    P("cast.mL.Cu", 3.4, "K/wt%", Status.LITERATURE_APPROX, _LIT, 0.4, -10, 20),
    P("cast.mL.Mg", 6.0, "K/wt%", Status.LITERATURE_APPROX, _LIT, 0.6, -10, 20),
    P("cast.mL.Zn", 1.6, "K/wt%", Status.LITERATURE_APPROX, _LIT, 0.4, -10, 20),
    P("cast.mL.Ag", 2.0, "K/wt%", Status.ILLUSTRATIVE, _ILL, 1.0, -10, 20),
    P("cast.mL.Zr", -4.0, "K/wt%", Status.ILLUSTRATIVE, "peritectic: liquidus rises", 3.0, -60, 20),
    P("cast.mL.Sc", None, "K/wt%", Status.UNKNOWN, "supply a validated Al-Sc liquidus slope", 0.0, note="Sc is excluded from liquidus/segregation until supplied"),
    P("cast.mL.Mn", 2.0, "K/wt%", Status.ILLUSTRATIVE, _ILL, 1.0, -10, 20),
    P("cast.mL.Fe", 3.0, "K/wt%", Status.ILLUSTRATIVE, _ILL, 1.0, -10, 20),
    P("cast.mL.Si", 6.6, "K/wt%", Status.LITERATURE_APPROX, _LIT, 0.7, -10, 20),
    P("cast.mL.Ti", -30.0, "K/wt%", Status.ILLUSTRATIVE, "peritectic: liquidus rises steeply", 10.0, -80, 20),
    P("cast.k.Li", 0.5, "-", Status.ILLUSTRATIVE, _ILL, 0.1, 0.05, 3.0),
    P("cast.k.Cu", 0.17, "-", Status.LITERATURE_APPROX, _LIT, 0.03, 0.05, 3.0),
    P("cast.k.Mg", 0.51, "-", Status.LITERATURE_APPROX, _LIT, 0.08, 0.05, 3.0),
    P("cast.k.Zn", 0.40, "-", Status.LITERATURE_APPROX, _LIT, 0.08, 0.05, 3.0),
    P("cast.k.Ag", 0.5, "-", Status.ILLUSTRATIVE, _ILL, 0.15, 0.05, 3.0),
    P("cast.k.Zr", 2.5, "-", Status.ILLUSTRATIVE, "peritectic partitioning k>1", 0.5, 1.0, 10.0),
    P("cast.k.Sc", None, "-", Status.UNKNOWN, "supply a validated Al-Sc partition coefficient", 0.0, note="Sc excluded from microsegregation until supplied"),
    P("cast.k.Mn", 0.9, "-", Status.ILLUSTRATIVE, _ILL, 0.1, 0.05, 3.0),
    P("cast.k.Fe", 0.03, "-", Status.LITERATURE_APPROX, _LIT, 0.01, 0.005, 3.0),
    P("cast.k.Si", 0.12, "-", Status.LITERATURE_APPROX, _LIT, 0.03, 0.05, 3.0),
    P("cast.k.Ti", 7.0, "-", Status.ILLUSTRATIVE, "peritectic partitioning k>>1", 2.0, 1.0, 20.0),
)

META = register(ModelMeta(
    model_name="plate_solidification_enthalpy_1d",
    equation="d(H)/dt = d/dx(k dT/dx); H(T)=rho cp T + rho L f_l(T); -k dT/dx|s = h (T_s - T_mould)",
    parameter_source="registry cast.* (mixed LITERATURE_APPROX / ILLUSTRATIVE)",
    validity_range="plate/slab sections 5 mm - 500 mm; single effective interface coefficient; no convection, no mould heating",
))


@dataclass
class CastingInputs:
    pour_temperature_K: float
    mould_temperature_K: float
    section_thickness_m: float
    cooling_rate_K_s: float | None = None  # if set, back-solve h so mean mushy cooling rate at centre matches
    hydrogen_ml_per_100g: float = 0.15
    oxide_film_index: float = 1.0  # relative melt cleanliness (1 = nominal)
    melt_hold_s: float = 3600.0

    def validate(self) -> None:
        if self.pour_temperature_K < 800 or self.pour_temperature_K > 1100:
            raise ValueError("pour temperature must be given in kelvin (800-1100 K)")
        if self.mould_temperature_K >= self.pour_temperature_K:
            raise ValueError("mould must be colder than the melt")
        if not 0.003 <= self.section_thickness_m <= 1.0:
            raise ValueError("section thickness outside 3 mm - 1 m")


@dataclass
class SolidificationResult:
    T_liquidus_K: float
    T_solidus_K: float
    x_m: np.ndarray  # node positions from surface
    t_liq_s: np.ndarray
    t_sol_s: np.ndarray
    local_solidification_time_s: np.ndarray
    cooling_rate_K_s: np.ndarray  # mean through mushy range
    gradient_K_m: np.ndarray  # at liquidus crossing
    front_velocity_m_s: np.ndarray
    history: CoolingHistory
    h_interface: float
    energy_balance_error: float
    excluded_elements: list[str]
    thickness_m: float

    def at_centre(self) -> dict[str, float]:
        i = -1
        return {
            "solidification_time_s": float(self.local_solidification_time_s[i]),
            "cooling_rate_K_s": float(self.cooling_rate_K_s[i]),
            "gradient_K_m": float(self.gradient_K_m[i]),
            "front_velocity_m_s": float(self.front_velocity_m_s[i]),
        }


def liquidus_solidus(ctx, comp: Composition) -> tuple[float, float, list[str]]:  # type: ignore[no-untyped-def]
    ctx.use(META.model_name)
    T_liq = ctx.p("cast.T_melt_Al")
    dT_eq = 0.0
    excluded: list[str] = []
    for el, w in comp.present().items():
        if el == "Al":
            continue
        if not (ctx.registry.is_known(f"cast.mL.{el}") and ctx.registry.is_known(f"cast.k.{el}")):
            excluded.append(el)
            ctx.warn(f"UNKNOWN liquidus slope / partition coefficient for {el}: excluded from solidification thermodynamics")
            continue
        m = ctx.p(f"cast.mL.{el}")
        T_liq -= m * w
    T_sol = max(ctx.p("cast.T_eutectic"), T_liq - 250.0)
    if T_liq - T_sol < 5.0:
        T_sol = T_liq - 5.0
    _ = dT_eq
    return T_liq, T_sol, excluded


@njit(cache=True)
def _fl(T: float, T_liq: float, T_sol: float) -> float:
    if T >= T_liq:
        return 1.0
    if T <= T_sol:
        return 0.0
    return (T - T_sol) / (T_liq - T_sol)


@njit(cache=True)
def _fd(n: int, dx: float, T_init: float, T_mould: float, h: float, rho: float, cp: float, kS: float, kL: float,
        L: float, T_liq: float, T_sol: float, n_out: int, t_cap: float):
    """Explicit finite-volume enthalpy scheme.  Node 0 = surface half-cell, node n-1 = mid-plane half-cell."""
    nt = 600
    T_tab = np.linspace(T_mould - 50.0, T_init + 50.0, nt)
    H_tab = np.empty(nt)
    for j in range(nt):
        H_tab[j] = rho * cp * T_tab[j] + rho * L * _fl(T_tab[j], T_liq, T_sol)
    H = np.empty(n)
    T = np.full(n, T_init)
    for i in range(n):
        H[i] = np.interp(T_init, T_tab, H_tab)
    w = np.full(n, dx)
    w[0] = 0.5 * dx
    w[n - 1] = 0.5 * dx
    kmax = max(kS, kL)
    dt = 0.3 * dx * dx * rho * cp / kmax
    t = 0.0
    t_liq = np.full(n, -1.0)
    t_sol = np.full(n, -1.0)
    grad = np.zeros(n)
    ts_ = np.empty(n_out)
    Ts_ = np.empty(n_out)
    Tc_ = np.empty(n_out)
    n_rec = 0
    stride = 1
    q_int = 0.0
    H0_sum = 0.0
    for i in range(n):
        H0_sum += H[i] * w[i]
    J = np.zeros(n + 1)
    step = 0
    done = False
    while (not done) and t < t_cap and step < 40_000_000:
        J[0] = h * (T[0] - T_mould)
        for i in range(1, n):
            fsa = 1.0 - 0.5 * (_fl(T[i - 1], T_liq, T_sol) + _fl(T[i], T_liq, T_sol))
            k = kS * fsa + kL * (1.0 - fsa)
            J[i] = k * (T[i] - T[i - 1]) / dx
        J[n] = 0.0
        for i in range(n):
            H[i] += dt * (J[i + 1] - J[i]) / w[i]
        q_int += J[0] * dt
        t += dt
        step += 1
        for i in range(n):
            Tn = np.interp(H[i], H_tab, T_tab)
            if T[i] > T_liq and Tn <= T_liq and t_liq[i] < 0.0:
                t_liq[i] = t
                if 0 < i < n - 1:
                    grad[i] = abs(T[i + 1] - T[i - 1]) / (2.0 * dx)
                elif i == 0:
                    grad[i] = abs(T[1] - T[0]) / dx
                else:
                    grad[i] = abs(T[i] - T[i - 1]) / dx
            if T[i] > T_sol and Tn <= T_sol and t_sol[i] < 0.0:
                t_sol[i] = t
            T[i] = Tn
        if step % stride == 0:
            if n_rec == n_out:
                for j in range(n_out // 2):
                    ts_[j] = ts_[2 * j]
                    Ts_[j] = Ts_[2 * j]
                    Tc_[j] = Tc_[2 * j]
                n_rec = n_out // 2
                stride *= 2
            ts_[n_rec] = t
            Ts_[n_rec] = T[0]
            Tc_[n_rec] = T[n - 1]
            n_rec += 1
        done = t_sol[n - 1] > 0.0 and T[n - 1] < T_sol - 30.0
    H_sum = 0.0
    for i in range(n):
        H_sum += H[i] * w[i]
    return t, t_liq, t_sol, grad, ts_[:n_rec].copy(), Ts_[:n_rec].copy(), Tc_[:n_rec].copy(), q_int, H0_sum - H_sum, step


def _run_fd(ctx, comp, inp: CastingInputs, h: float, n_nodes: int, t_cap: float):  # type: ignore[no-untyped-def]
    from ..properties.density import density_kg_m3

    rho = density_kg_m3(ctx, comp, 293.0).value * 0.95  # hot-metal density reduction ~5 % (assumed)
    cp, kS, kL, L = ctx.p("cast.cp"), ctx.p("cast.k_solid"), ctx.p("cast.k_liquid"), ctx.p("cast.latent_heat")
    T_liq, T_sol, excl = liquidus_solidus(ctx, comp)
    half = 0.5 * inp.section_thickness_m
    dx = half / (n_nodes - 1)
    out = _fd(n_nodes, dx, inp.pour_temperature_K, inp.mould_temperature_K, h, rho, cp, kS, kL, L,
              T_liq, T_sol, 240, t_cap)
    return out, (rho, cp, T_liq, T_sol, excl, dx)


def simulate_solidification(ctx, comp: Composition, inp: CastingInputs, n_nodes: int = 60) -> SolidificationResult:  # type: ignore[no-untyped-def]
    inp.validate()
    h0 = ctx.p("cast.h_interface")
    half = 0.5 * inp.section_thickness_m
    t_cap = 3.0e5

    def centre_rate(logh: float) -> float:
        out, meta = _run_fd(ctx, comp, inp, math.exp(logh), max(20, n_nodes // 2), t_cap)
        _, t_liq, t_sol, *_ = out
        _, _, T_liq, T_sol, _, _ = meta
        if t_sol[-1] <= 0 or t_liq[-1] <= 0:
            return 0.0
        return (T_liq - T_sol) / max(t_sol[-1] - t_liq[-1], 1e-9)

    h = h0
    if inp.cooling_rate_K_s is not None:
        target = inp.cooling_rate_K_s
        lo, hi = math.log(10.0), math.log(2.0e5)
        flo, fhi = centre_rate(lo) - target, centre_rate(hi) - target
        if flo * fhi > 0:
            ctx.warn("cooling_rate_K_s not reachable within h in [10, 2e5] W/m2/K; using bounding value")
            h = math.exp(lo if abs(flo) < abs(fhi) else hi)
        else:
            h = math.exp(brentq(lambda x: centre_rate(x) - target, lo, hi, xtol=1e-3))
    ctx.check_range("section thickness", inp.section_thickness_m, 0.005, 0.5, " m")
    out, (rho, cp, T_liq, T_sol, excl, dx) = _run_fd(ctx, comp, inp, h, n_nodes, t_cap)
    t_end, t_liq, t_sol, grad, ts, Ts, Tc, q_int, dH, steps = out
    if np.any(t_sol <= 0) or np.any(t_liq <= 0):
        raise NumericalInstabilityError("solidification did not complete within the time cap")
    x = np.linspace(0.0, half, n_nodes)
    tf = t_sol - t_liq
    rate = (T_liq - T_sol) / np.maximum(tf, 1e-9)
    # front velocity from liquidus arrival-time gradient
    dt_liq = np.gradient(t_liq, x)
    v = 1.0 / np.maximum(np.abs(dt_liq), 1e-12)
    err = abs(dH - q_int) / max(abs(dH), 1e-30)
    return SolidificationResult(
        T_liq, T_sol, x, t_liq, t_sol, tf, rate, grad, v,
        CoolingHistory(ts, Ts, Tc), h, float(err), excl, inp.section_thickness_m,
    )
