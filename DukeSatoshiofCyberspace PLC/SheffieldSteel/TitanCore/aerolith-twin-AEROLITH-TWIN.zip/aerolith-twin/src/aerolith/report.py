"""Engineering report (HTML) with MEASURED / SIMULATED / ESTIMATED / ASSUMED labelling."""

from __future__ import annotations

import base64
import html
import io
from pathlib import Path
from typing import Any

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from . import DISCLAIMER, MODEL_VERSION
from .context import RunContext
from .digital_twin.qualification import QUAL_STATEMENT
from .digital_twin.twin import TwinRun
from .params import ParameterRegistry
from .results import assumptions_table, properties_table
from .viz import figures as F

CSS = """
:root{--navy:#0b2447;--graphite:#2b2f36;--al:#b8bec6;--steel:#5f6b7a;--blue:#2f5d8c;--amber:#c98a1b;--red:#a8322d;--paper:#f6f7f8}
@media (prefers-color-scheme: dark){:root{--paper:#14181d}}
*{box-sizing:border-box}body{margin:0;font:14px/1.5 "Helvetica Neue",Arial,sans-serif;color:var(--graphite);background:#fff}
header{background:var(--navy);color:#fff;padding:22px 40px}header h1{margin:0;font-size:21px;letter-spacing:.04em}header p{margin:4px 0 0;color:var(--al);font-size:12px}
main{max-width:1100px;margin:0 auto;padding:10px 40px 60px}h2{border-bottom:2px solid var(--navy);padding-bottom:4px;margin-top:38px;font-size:16px;letter-spacing:.05em;text-transform:uppercase;color:var(--navy)}
h3{font-size:13px;color:var(--steel);text-transform:uppercase;letter-spacing:.05em}table{border-collapse:collapse;width:100%;font-size:12.5px;margin:8px 0}
th{background:var(--paper);text-align:left;color:var(--steel);font-weight:600}td,th{padding:5px 8px;border-bottom:1px solid #e3e6ea;vertical-align:top}
.badge{display:inline-block;font-size:10.5px;padding:1px 7px;border-radius:2px;font-weight:600;letter-spacing:.04em;color:#fff}
.MEASURED{background:var(--navy)}.SIMULATED{background:var(--blue)}.ESTIMATED{background:var(--steel)}.ASSUMED{background:var(--amber)}
.warn{border-left:4px solid var(--amber);background:#fbf5e8;padding:8px 12px;margin:10px 0;font-size:12.5px}.bad{border-left-color:var(--red);background:#faeceb}
.note{color:var(--steel);font-size:12px}figure{margin:12px 0}figure img{max-width:100%;border:1px solid #e3e6ea}figcaption{font-size:11.5px;color:var(--steel)}
.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(300px,1fr));gap:14px}.card{border:1px solid #e3e6ea;padding:10px 14px}
code{font-family:ui-monospace,Menlo,monospace;font-size:11.5px}
"""


def _img(fig: plt.Figure | None, caption: str) -> str:
    if fig is None:
        return ""
    buf = io.BytesIO()
    fig.savefig(buf, format="png", bbox_inches="tight")
    plt.close(fig)
    b = base64.b64encode(buf.getvalue()).decode()
    return f'<figure><img alt="{html.escape(caption)}" src="data:image/png;base64,{b}"><figcaption>{html.escape(caption)}</figcaption></figure>'


def _badge(p: str) -> str:
    return f'<span class="badge {p}">{p}</span>'


def _fmt(v: Any, nd: int = 4) -> str:
    if v is None or (isinstance(v, float) and not np.isfinite(v)):
        return "—"
    if isinstance(v, float):
        return f"{v:.{nd}g}"
    return html.escape(str(v))


def _table(df: pd.DataFrame, cols: list[str], heads: list[str] | None = None, nd: int = 4) -> str:
    heads = heads or cols
    rows = ["<tr>" + "".join(f"<th>{html.escape(h)}</th>" for h in heads) + "</tr>"]
    for _, r in df.iterrows():
        rows.append("<tr>" + "".join(f"<td>{_fmt(r[c], nd)}</td>" for c in cols) + "</tr>")
    return "<table>" + "".join(rows) + "</table>"


def build_report(run: TwinRun, registry: ParameterRegistry, outdir: str | Path, stem: str = "report", experiments: pd.DataFrame | None = None) -> Path:
    out = Path(outdir)
    out.mkdir(parents=True, exist_ok=True)
    ch = run.true_state.chain
    st = ch.state
    ps = ch.properties
    assert ps is not None
    ctx = RunContext(registry)
    props = properties_table(run)
    assum = assumptions_table(run, registry)
    n_ill = int((assum.status == "ILLUSTRATIVE").sum())
    n_unk = int((assum.status == "UNKNOWN").sum())
    h: list[str] = []
    h.append(f"<header><h1>AEROLITH-TWIN · Engineering report · batch {html.escape(run.batch_id)}</h1>"
             f"<p>{html.escape(run.composition.label or str(run.composition))} · model {MODEL_VERSION} · parameters {html.escape(run.meta['parameter_version'])} · "
             f"input hash {run.meta['input_hash']} · {run.meta['simulation_timestamp']}</p></header><main>")
    h.append(f'<div class="warn bad"><b>Status.</b> {html.escape(QUAL_STATEMENT)}</div>')
    if n_ill or n_unk:
        h.append(f'<div class="warn"><b>Data basis.</b> {n_ill} ILLUSTRATIVE and {n_unk} UNKNOWN parameters were used in this run. Every simulated value below is '
                 f'conditional on those assumptions and is not a validated prediction until calibrated against measured data. {_badge("ASSUMED")} marks them in the assumptions table.</div>')
    h.append(f'<p class="note">Legend: {_badge("MEASURED")} real laboratory/plant data · {_badge("SIMULATED")} computed by a model here · '
             f'{_badge("ESTIMATED")} twin posterior (model + virtual measurements) · {_badge("ASSUMED")} assumed/illustrative parameter. '
             f'No MEASURED value exists in a pure simulation run; virtual-instrument readings are labelled SIMULATED.</p>')
    # ---- MATERIAL
    h.append("<h2>1 · Material</h2>")
    wt = run.composition.wt(); at = run.composition.at_percent()
    h.append("<table><tr><th>Element</th><th>wt%</th><th>at%</th><th>1σ analytical (wt%)</th></tr>" + "".join(
        f"<tr><td>{e}</td><td>{wt[e]:.3f}</td><td>{at[e]:.3f}</td><td>{_fmt(run.composition.uncertainty_wt.get(e))}</td></tr>" for e in wt if wt[e] > 0) + "</table>")
    h.append(_img(F.composition_map(run.composition), "Composition (weight and atomic)"))
    # ---- PROCESS
    h.append("<h2>2 · Process history</h2>")
    g = ch.genealogy
    assert g is not None
    h.append(_img(F.genealogy_graph(ch), "Manufacturing genealogy (hash-chained)"))
    h.append("<table><tr><th>Node</th><th>Kind</th><th>Parameters</th><th>Summary</th></tr>" + "".join(
        f"<tr><td>{html.escape(n.node_id)}</td><td>{n.kind}</td><td><code>{html.escape(str(n.parameters)[:220])}</code></td><td><code>{html.escape(str({k: (round(v, 4) if isinstance(v, float) else v) for k, v in n.summary.items()})[:260])}</code></td></tr>"
        for n in g.nodes) + "</table>")
    h.append(f'<p class="note">Genealogy verification: <b>{"PASSED" if g.verify() else "FAILED"}</b> (each node hashes its parameters, summary and parent).</p>')
    # ---- THERMAL
    h.append("<h2>3 · Thermal history</h2>")
    h.append(_img(F.process_history(ch), "Furnace, part, rolling and quench histories (TRUE simulated state)"))
    h.append(_img(F.casting_and_quench_curves(ch), "Casting and quench cooling curves"))
    if run.estimated.process:
        h.append("<h3>Process-state estimation from telemetry (Kalman filter) " + _badge("ESTIMATED") + "</h3>")
        rows = "".join(f"<tr><td>{k}</td><td>{v['estimated_T_K']:.2f}</td><td>{v['sigma_K']:.2f}</td><td>{v['true_hold_T_K_for_validation']:.2f}</td><td>{v['bias_estimate_K']:.2f}</td><td>{int(v['n_valid'])}/{int(v['n_missing'])}</td></tr>" for k, v in run.estimated.process.items())
        h.append("<table><tr><th>stage</th><th>estimated hold T (K)</th><th>1σ (K)</th><th>true furnace T in simulation (K) — validation only</th><th>bias estimate (K)</th><th>valid/missing samples</th></tr>" + rows + "</table>")
    # ---- MICROSTRUCTURE
    h.append("<h2>4 · Microstructure</h2>")
    h.append("<div class=\"grid\"><div class=\"card\"><h3>Precipitate state " + _badge("SIMULATED") + "</h3><table><tr><th>phase</th><th>f (%)</th><th>r̄ (nm)</th><th>N (m⁻³)</th></tr>" + "".join(
        f"<tr><td>{k}</td><td>{v['volume_fraction'] * 100:.3g}</td><td>{v['mean_radius_m'] * 1e9:.3g}</td><td>{v['number_density_m3']:.2e}</td></tr>"
        for k, v in st.precip.summary().items() if v["volume_fraction"] > 1e-7) + "</table></div>")
    gs = st.grains.summary() if st.grains else {}
    h.append("<div class=\"card\"><h3>Grain structure " + _badge("SIMULATED") + "</h3><table>" + "".join(
        f"<tr><td>{k}</td><td>{_fmt(v)}</td></tr>" for k, v in gs.items()) + f"<tr><td>dislocation density (m⁻²)</td><td>{st.dislocation_density:.3g}</td></tr></table></div></div>")
    h.append(_img(F.precipitation_kinetics(ch), "Ageing kinetics: phase fraction, radius and strengthening"))
    h.append(_img(F.grain_size_distribution(st), "Grain-size distribution"))
    h.append(_img(F.texture_plot(st), "Texture components and Taylor-factor anisotropy"))
    if run.measured.microscopy:
        h.append("<h3>Virtual metallography vs twin truth</h3><table><tr><th>quantity</th><th>virtual measurement</th><th>1σ</th><th>twin truth</th><th>label</th></tr>")
        truth = {"grain_size": st.grains.mean_size_m if st.grains else 0, "T1_radius": st.precip.mean_radius("T1"), "recrystallised_fraction": st.grains.recrystallised_fraction if st.grains else 0}
        for k, q in run.measured.microscopy.items():
            h.append(f"<tr><td>{k}</td><td>{q.value:.4g} {q.unit}</td><td>{_fmt(q.sigma)}</td><td>{truth[k]:.4g}</td><td>{_badge('SIMULATED')} synthetic instrument</td></tr>")
        h.append("</table>")
    # ---- PROPERTIES
    h.append("<h2>5 · Mechanical and physical properties</h2>")
    show = ["density", "E_L", "E_T", "G_LT", "nu_LT", "yield_strength_L", "yield_strength_T", "yield_strength_45", "uts", "elongation", "fracture_toughness_LT",
            "fracture_toughness_TL", "fatigue_strength_1e7", "specific_strength", "specific_modulus", "corrosion_index", "electrical_conductivity_iacs", "thermal_conductivity"]
    pt = props.set_index("name").loc[[s for s in show if s in set(props.name)]].reset_index()
    pt["label"] = "SIMULATED"
    h.append(_table(pt, ["name", "value", "unit", "sigma", "ci95_lo", "ci95_hi", "uncertainty_basis", "label"],
                    ["property", "value", "unit", "1σ", "95% low", "95% high", "uncertainty basis", "provenance"]))
    c = ps.strength.contributions()
    h.append("<h3>Strengthening contributions (isotropic yield)</h3><table><tr>" + "".join(f"<th>{k}</th>" for k in c) + "</tr><tr>" + "".join(f"<td>{v:.1f} MPa</td>" for v in c.values()) + "</tr></table>")
    h.append("<table><tr><th>precipitate</th><th>f</th><th>r̄ (nm)</th><th>shearing (MPa)</th><th>Orowan (MPa)</th><th>used (MPa)</th><th>regime</th></tr>" + "".join(
        f"<tr><td>{p.phase}</td><td>{p.volume_fraction:.3g}</td><td>{p.mean_radius_m * 1e9:.3g}</td><td>{_fmt(p.shear_mpa, 3)}</td><td>{p.orowan_mpa:.3g}</td><td>{p.chosen_mpa:.3g}</td><td>{p.regime}</td></tr>" for p in ps.strength.precip if p.volume_fraction > 1e-7) + "</table>")
    h.append(_img(F.stress_strain(ch), "Reduced-order tensile response"))
    h.append(_img(F.fatigue_curve(ctx, ch), "S–N curves"))
    h.append('<div class="warn">Paris-law crack-growth parameters and Coffin–Manson strain-life parameters are <b>UNKNOWN</b> in the default registry and are not invented. '
             'Supply a fatigue-crack-growth / strain-life dataset to enable da/dN and ε–N.</div>')
    # ---- DEFECTS
    h.append("<h2>6 · Defect state</h2>")
    ds = st.defects.summary()
    h.append("<table>" + "".join(f"<tr><td>{k}</td><td>{_fmt(v)}</td></tr>" for k, v in ds.items()) + "</table>")
    h.append(f'<p class="note">Bulk statistics: {html.escape(str({k: (round(v, 6) if isinstance(v, float) else v) for k, v in st.defects.bulk.items()}))}. {_badge("SIMULATED")} '
             'Defects above the reporting threshold are enumerated; the sub-threshold population is carried as statistics.</p>')
    h.append(_img(F.defect_map(st), "Defect map and size distribution"))
    # ---- INSPECTION
    h.append("<h2>7 · Inspection</h2>")
    nd = run.inspection
    if nd:
        h.append(f"<table><tr><td>methods</td><td>{', '.join(nd.methods)}</td></tr><tr><td>defects in twin truth</td><td>{nd.n_true}</td></tr>"
                 f"<tr><td>detected</td><td>{nd.n_detected} (expected {nd.expected_detections:.1f})</td></tr><tr><td>largest missed defect</td><td>{nd.largest_missed_size_m * 1e3:.2f} mm "
                 f"(severity a/a_c = {nd.largest_missed_severity:.2f})</td></tr><tr><td>acceptance criteria</td><td>{html.escape(nd.criteria.name)} — {html.escape(nd.criteria.source)}</td></tr>"
                 f"<tr><td>rejected</td><td>{'not assessed: no acceptance criterion supplied' if nd.rejected is None else nd.rejected}</td></tr></table>")
        h.append('<p class="note">NDT probability-of-detection parameters are ILLUSTRATIVE: real POD requires NDT procedure qualification. Truth is known only inside the twin.</p>')
    # ---- UNCERTAINTY
    h.append("<h2>8 · Uncertainty</h2>")
    if run.uncertainty is not None:
        u = run.uncertainty.table.reset_index()
        h.append(f"<p>Monte Carlo ensemble of {run.uncertainty.n} members over composition, temperature, processing and model-parameter uncertainty, plus a model-form term. "
                 f"Numerically failed members: <b>{run.uncertainty.n_failed}</b> (excluded and counted; a non-zero count means the sampled parameter region contains stiff kinetics).</p>")
        h.append(_table(u, ["output", "mean", "sigma_ensemble", "sigma_model_form", "sigma_total", "ci95_lo", "ci95_hi", "frac_composition", "frac_temperature", "frac_processing", "frac_model", "frac_model_form"],
                        ["output", "mean", "σ ens.", "σ model-form", "σ total", "95% low", "95% high", "f comp.", "f temp.", "f proc.", "f params", "f form"], 3))
        tb = run.uncertainty.table
        if "yield_strength" in tb.index and tb.loc["yield_strength", "frac_model"] > 0.6:
            h.append(f'<div class="warn"><b>Parameter uncertainty dominates</b> ({100 * tb.loc["yield_strength", "frac_model"]:.0f}% of the yield-strength variance). '
                     'These widths are the prior widths of the registry parameters (placeholders for ILLUSTRATIVE ones), not a measured scatter. '
                     'Calibrating the influential parameters against measured microstructure/property data is the lever that narrows them.</div>')
        keys = [k for k in ("yield_strength", "uts", "fracture_toughness") if k in run.uncertainty.table.index]
        h.append(_img(F.uncertainty_distribution(run.uncertainty.members, run.uncertainty.table, keys), "Ensemble distributions with 95% intervals"))
    else:
        h.append('<p class="note">No ensemble was run: model-form uncertainty only is shown in the property table.</p>')
    if run.estimated.posterior:
        h.append("<h3>Twin posterior vs prior " + _badge("ESTIMATED") + "</h3><table><tr><th>property</th><th>prior mean ± σ</th><th>posterior mean ± σ</th></tr>" + "".join(
            f"<tr><td>{k}</td><td>{run.estimated.prior[k]['mean']:.4g} ± {run.estimated.prior[k]['sigma']:.2g}</td><td>{v['mean']:.4g} ± {v['sigma']:.2g}</td></tr>" for k, v in run.estimated.posterior.items()) +
            f"</table><p class='note'>Importance-weighted ensemble (n={run.estimated.n_members}, effective sample size {run.estimated.effective_sample_size:.1f}) conditioned on virtual microscopy and Kalman-estimated process temperatures.</p>")
    # ---- SCORECARD
    h.append("<h2>9 · Digital twin scorecard</h2>")
    for sec, d in run.scorecard.items():
        h.append(f"<h3>{sec}</h3><table>")
        for k, v in d.items():
            if isinstance(v, dict):
                v = "; ".join(f"{a}: {_fmt(b) if not isinstance(b, dict) else {x: _fmt(y, 3) for x, y in b.items()}}" for a, b in v.items())
            h.append(f"<tr><td>{html.escape(str(k))}</td><td>{html.escape(_fmt(v) if not isinstance(v, str) else v)}</td></tr>")
        h.append("</table>")
    # ---- EXPERIMENTS
    if experiments is not None and len(experiments):
        h.append("<h2>Experimental comparison " + _badge("MEASURED") + "</h2>")
        h.append(_table(experiments.head(30), list(experiments.columns[:10])))
    # ---- QUALIFICATION
    h.append("<h2>10 · Qualification status</h2>")
    if run.qualification is not None:
        qr = run.qualification
        h.append(f"<p><b>Screening against “{html.escape(qr.spec_name)}”: {html.escape(qr.screening_status)}</b></p>")
        h.append(_table(pd.DataFrame(qr.rows), ["property", "minimum", "maximum", "mean", "sigma", "pass_probability", "status", "requirement_source"]))
        h.append(f'<div class="warn">{html.escape(qr.data_basis)}</div>')
    else:
        h.append("<p>No qualification envelope was supplied: nothing to screen against. The twin does not invent requirements.</p>")
    h.append(f'<div class="warn bad"><b>{html.escape(QUAL_STATEMENT)}</b></div>')
    # ---- ASSUMPTIONS
    h.append("<h2>Assumptions and parameter provenance</h2>")
    h.append(f"<p class=\"note\">{len(assum)} parameters were exercised in this run. Status counts: {html.escape(str(run.meta['parameter_status_in_use']))}.</p>")
    a2 = assum.copy()
    a2["badge"] = a2.status.map(lambda s: "ASSUMED" if s in ("ILLUSTRATIVE", "UNKNOWN") else "—")
    h.append(_table(a2.sort_values(["status", "parameter"]).head(400), ["parameter", "value", "units", "status", "uncertainty_1sigma", "validity_min", "validity_max", "source"], nd=4))
    mods = pd.DataFrame([m.to_dict() for m in ctx.models_used.values()]) if ctx.models_used else pd.DataFrame()
    from .governance import MODEL_REGISTRY

    h.append("<h2>Model governance</h2>")
    gm = pd.DataFrame([MODEL_REGISTRY[m].to_dict() for m in run.meta["models_used"] if m in MODEL_REGISTRY])
    h.append(_table(gm, ["model_name", "fidelity", "equation", "parameter_source", "validity_range", "calibration_dataset", "uncertainty", "revision"]))
    h.append(f'<p class="note">{html.escape(DISCLAIMER)}</p></main>')
    _ = mods
    path = out / f"{stem}.html"
    path.write_text("<!doctype html><html lang=\"en\"><head><meta charset=\"utf-8\"><meta name=\"viewport\" content=\"width=device-width,initial-scale=1\">"
                    f"<title>AEROLITH-TWIN report {html.escape(run.batch_id)}</title><style>{CSS}</style></head><body>" + "\n".join(h) + "</body></html>")
    return path
