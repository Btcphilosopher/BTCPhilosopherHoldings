"""Engineering figures (static, matplotlib).  Each function returns a Figure."""

from __future__ import annotations

import math

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from ..manufacturing.process_chain import ChainResult
from ..microstructure.state import MaterialState
from ..thermodynamics.equilibrium import PHASES
from ..units import KELVIN_OFFSET, R_GAS
from . import style as S

C = S.PALETTE


def _kC(T: np.ndarray) -> np.ndarray:
    return np.asarray(T) - KELVIN_OFFSET


def composition_map(comp) -> plt.Figure:  # type: ignore[no-untyped-def]
    wt, at = comp.present(), comp.at_percent()
    els = [e for e in wt if e != "Al"]
    fig, ax = plt.subplots(1, 2, figsize=(7.2, 2.8))
    ax[0].barh(els, [wt[e] for e in els], color=C["navy"])
    ax[0].set_xlabel("wt%"); ax[0].set_title("Composition (weight)")
    ax[1].barh(els, [at[e] for e in els], color=C["blue"])
    ax[1].set_xlabel("at%"); ax[1].set_title("Composition (atomic)")
    for a in ax:
        a.invert_yaxis()
    fig.suptitle(f"{comp.label or 'Alloy'}   Al balance {wt['Al']:.2f} wt%", fontsize=9, x=0.02, ha="left")
    fig.tight_layout(); S.stamp(fig)
    return fig


def solubility_curves(registry) -> plt.Figure:  # type: ignore[no-untyped-def]
    T = np.linspace(373, 873, 200)
    fig, ax = plt.subplots(figsize=(5.4, 3.4))
    for p in PHASES:
        K = registry.value(f"thermo.{p.key}.K0") * np.exp(-registry.value(f"thermo.{p.key}.Q") / (R_GAS * T))
        ax.semilogy(_kC(T), K, label=p.label)
    ax.set_xlabel("temperature (°C)"); ax.set_ylabel("solubility relation K(T)  (atomic fraction or product)")
    ax.set_title("Reduced-order solubility relations — ILLUSTRATIVE, not a phase diagram")
    ax.text(0.02, 0.04, "No CALPHAD database bundled: a phase diagram is shown only where data supports one.", transform=ax.transAxes, fontsize=7, color=C["amber"])
    ax.legend(fontsize=7); fig.tight_layout(); S.stamp(fig)
    return fig


def casting_and_quench_curves(chain: ChainResult) -> plt.Figure:
    fig, ax = plt.subplots(1, 2, figsize=(7.6, 3.1))
    sol = chain.stage_results["casting"]["solidification"]
    h = sol.history
    ax[0].plot(h.t_s / 60, _kC(h.T_centre_K), label="centre"); ax[0].plot(h.t_s / 60, _kC(h.T_surface_K), label="surface")
    ax[0].axhline(_kC(sol.T_liquidus_K), color=C["amber"], lw=0.8, ls="--"); ax[0].axhline(_kC(sol.T_solidus_K), color=C["red"], lw=0.8, ls="--")
    ax[0].set_xlabel("time (min)"); ax[0].set_ylabel("°C"); ax[0].set_title("Casting cooling curves (reduced-order 1-D)"); ax[0].legend(fontsize=7)
    q = chain.stage_results.get("quench", {}).get("result")
    if q is not None:
        ax[1].plot(q.t_s, _kC(q.history.T_centre_K[-len(q.t_s):]), label="mid-thickness"); ax[1].plot(q.t_s, _kC(q.history.T_surface_K[-len(q.t_s):]), label="surface")
        ax[1].set_xscale("symlog", linthresh=1.0); ax[1].set_xlabel("time after immersion (s)"); ax[1].set_ylabel("°C"); ax[1].set_title("Quench cooling curves"); ax[1].legend(fontsize=7)
    fig.tight_layout(); S.stamp(fig)
    return fig


def process_history(chain: ChainResult) -> plt.Figure:
    fig, ax = plt.subplots(2, 3, figsize=(9.2, 5.0))
    k = chain.signals
    def th(a, f, p, title):  # type: ignore[no-untyped-def]
        if f in k:
            ax_ = a; ax_.plot(k[f][0] / 3600, _kC(k[f][1]), label="furnace air"); ax_.plot(k[p][0] / 3600, _kC(k[p][1]), label="part")
            ax_.set_title(title); ax_.set_xlabel("time (h)"); ax_.set_ylabel("°C"); ax_.legend(fontsize=7)
    th(ax[0, 0], "homogenisation_furnace_T", "homogenisation_part_T", "Homogenisation")
    if "rolling_temperature" in k:
        ax[0, 1].plot(k["rolling_temperature"][0] / 60, _kC(k["rolling_temperature"][1]), marker="o", ms=3)
        ax[0, 1].set_title("Rolling: slab temperature"); ax[0, 1].set_xlabel("time (min)"); ax[0, 1].set_ylabel("°C")
    if "rolling_force" in k:
        a2 = ax[0, 2]; a2.bar(np.arange(len(k["rolling_force"][1])) + 1, k["rolling_force"][1] / 1e6, color=C["navy"])
        a2.set_title("Rolling force per pass"); a2.set_xlabel("pass"); a2.set_ylabel("MN")
    th(ax[1, 0], "solution_furnace_T", "solution_part_T", "Solution treatment")
    if "quench_centre_T" in k:
        ax[1, 1].plot(k["quench_centre_T"][0], _kC(k["quench_centre_T"][1]), label="mid"); ax[1, 1].plot(k["quench_surface_T"][0], _kC(k["quench_surface_T"][1]), label="surface")
        ax[1, 1].set_xscale("symlog", linthresh=1); ax[1, 1].set_title("Quench"); ax[1, 1].set_xlabel("time (s)"); ax[1, 1].legend(fontsize=7)
    th(ax[1, 2], "ageing_furnace_T", "ageing_part_T", "Ageing")
    fig.tight_layout(); S.stamp(fig)
    return fig


def precipitation_kinetics(chain: ChainResult) -> plt.Figure | None:
    ar = chain.stage_results.get("ageing", {}).get("result")
    if ar is None:
        return None
    pr = ar.precipitation
    fig, ax = plt.subplots(1, 3, figsize=(9.4, 3.0))
    for p in PHASES:
        f = pr.volume_fraction[p.key]
        if f.max() > 1e-6:
            ax[0].plot(pr.t_s / 3600, f * 100, label=p.label); ax[1].plot(pr.t_s / 3600, pr.mean_radius_m[p.key] * 1e9, label=p.label)
    ax[0].set_ylabel("volume fraction (%)"); ax[1].set_ylabel("mean radius (nm, equivalent sphere)")
    ax[2].plot(pr.t_s / 3600, ar.strengthening_mpa, color=C["navy"]); ax[2].axvline(ar.t_peak_s / 3600, color=C["amber"], ls="--", lw=0.9)
    ax[2].set_ylabel("precipitation strengthening (MPa)"); ax[2].set_title(f"{ar.regime}")
    for a in ax:
        a.set_xlabel("ageing time (h)")
    ax[0].legend(fontsize=7); ax[0].set_title("Phase fraction"); ax[1].set_title("Particle radius")
    fig.tight_layout(); S.stamp(fig)
    return fig


def grain_size_distribution(state: MaterialState) -> plt.Figure:
    g = state.grains
    assert g is not None
    d, pdf = g.size_distribution()
    fig, ax = plt.subplots(figsize=(4.8, 3.0))
    ax.plot(d * 1e6, pdf / pdf.max(), color=C["navy"]); ax.fill_between(d * 1e6, 0, pdf / pdf.max(), color=C["aluminium"], alpha=0.5)
    ax.set_xscale("log"); ax.set_xlabel("equivalent grain diameter (µm)"); ax.set_ylabel("normalised density")
    ax.set_title(f"Grain-size distribution (lognormal, σ_ln={g.sigma_ln:.2f}; X_rex={g.recrystallised_fraction:.2f}; AR={g.aspect_ratio:.1f})", fontsize=8)
    fig.tight_layout(); S.stamp(fig)
    return fig


def texture_plot(state: MaterialState, chain: ChainResult | None = None) -> plt.Figure:
    w = state.texture.normalised()
    tf = state.texture.taylor_factors()
    fig, ax = plt.subplots(1, 2, figsize=(7.4, 3.0))
    ks = [k for k, v in w.items() if v > 1e-4]
    ax[0].bar(ks, [w[k] for k in ks], color=C["navy"]); ax[0].set_ylabel("weight"); ax[0].set_title(f"Texture components (index {state.texture.index():.2f})")
    ax[0].tick_params(axis="x", rotation=30)
    ax[1].bar(["L (RD)", "45°", "T (TD)"], [tf["L"], tf["D"], tf["T"]], color=[C["blue"], C["steel"], C["blue"]])
    ax[1].axhline(3.06, color=C["amber"], ls="--", lw=0.9); ax[1].set_ylabel("Taylor factor"); ax[1].set_title("Plastic anisotropy (full-constraint Taylor)")
    fig.tight_layout(); S.stamp(fig)
    return fig


def stress_strain(chain: ChainResult) -> plt.Figure:
    ps = chain.properties
    assert ps is not None
    sr = ps.strength
    fig, ax = plt.subplots(figsize=(5.2, 3.3))
    for lab, key, col in (("L", "L", C["navy"]), ("T", "T", C["blue"]), ("45°", "D", C["steel"])):
        sy = sr.yield_dir[key] * 1e6
        ds, th = sr.delta_sat_pa * sy / (sr.yield_iso * 1e6), sr.theta0_pa
        eps_u = sr.uniform_elongation
        e = np.linspace(0, max(eps_u, 1e-4), 60)
        st = sy + ds * (1 - np.exp(-th * e / max(ds, 1.0)))
        eng_e, eng_s = np.exp(e) - 1, st / np.exp(e)
        e_f = np.exp(eps_u + sr.eps_neck) - 1
        xe = np.append(eng_e, e_f); xs = np.append(eng_s, 0.82 * eng_s[-1])
        ax.plot(xe * 100, xs / 1e6, color=col, label=f"{lab}")
    ax.set_xlabel("engineering strain (%)"); ax.set_ylabel("engineering stress (MPa)"); ax.set_title("Reduced-order tensile response (Voce + Considère; post-uniform segment schematic)", fontsize=8)
    ax.legend(fontsize=7); fig.tight_layout(); S.stamp(fig)
    return fig


def fatigue_curve(ctx, chain: ChainResult) -> plt.Figure:  # type: ignore[no-untyped-def]
    from ..properties.fatigue import sn_curve

    ps = chain.properties
    assert ps is not None
    fig, ax = plt.subplots(figsize=(5.0, 3.3))
    for R, col in ((-1.0, C["navy"]), (0.1, C["blue"])):
        c = sn_curve(ctx, ps.fatigue, ps.strength.uts, R)
        ax.loglog(c["N"], c["sigma_a_mpa"], color=col, label=f"R={R}"); ax.fill_between(c["N"], c["lo95"], c["hi95"], color=col, alpha=0.15)
    ax.set_xlabel("cycles to failure N"); ax.set_ylabel("stress amplitude (MPa)"); ax.set_title("S–N (Basquin/Goodman; band = 95% life scatter) — empirical data should override", fontsize=8)
    ax.legend(fontsize=7); fig.tight_layout(); S.stamp(fig)
    return fig


def defect_map(state: MaterialState) -> plt.Figure:
    df = state.defects.to_dataframe()
    fig, ax = plt.subplots(1, 2, figsize=(8.4, 3.2))
    if df.empty:
        ax[0].text(0.5, 0.5, "no enumerated defects", ha="center")
    else:
        cols = {"porosity": C["navy"], "inclusion": C["steel"], "crack": C["red"], "segregation": C["amber"], "void": C["blue"], "grain_abnormality": "#7d8a99", "surface_defect": C["red"]}
        for t, g in df.groupby("type"):
            det = g.detected_by.astype(str) != ""
            ax[0].scatter(g.u[det], g.v[det], s=6 + 400 * g.size_m[det], c=cols.get(t, C["steel"]), alpha=0.6, label=f"{t} (detected)")
            ax[0].scatter(g.u[~det], g.v[~det], s=6 + 400 * g.size_m[~det], facecolors="none", edgecolors=cols.get(t, C["steel"]), alpha=0.8, label=f"{t} (missed)" if (~det).any() else None)
        ax[0].set_xlabel("u  (rolling direction, normalised)"); ax[0].set_ylabel("v  (transverse, normalised)"); ax[0].set_title("Defect map (plan view; filled = detected by NDT)")
        ax[0].legend(fontsize=6, ncol=2)
        ax[1].hist(np.log10(df.size_m * 1e3), bins=30, color=C["navy"]); ax[1].set_xlabel("log10 size (mm)"); ax[1].set_ylabel("count"); ax[1].set_title("Defect size distribution")
    fig.tight_layout(); S.stamp(fig)
    return fig


def genealogy_graph(chain: ChainResult) -> plt.Figure:
    g = chain.genealogy
    assert g is not None
    n = len(g.nodes) + 2
    fig, ax = plt.subplots(figsize=(9.0, 2.2)); ax.axis("off"); ax.set_xlim(0, n); ax.set_ylim(0, 1)
    labels = ["CHEMISTRY"] + [nd.node_id for nd in g.nodes]
    for i, lab in enumerate(labels):
        ax.add_patch(plt.Rectangle((i + 0.05, 0.3), 0.9, 0.4, fc=C["navy"] if i else C["steel"], ec="none"))
        ax.text(i + 0.5, 0.5, lab, ha="center", va="center", color="white", fontsize=6.3)
        if i < len(labels) - 1:
            ax.annotate("", xy=(i + 1.05, 0.5), xytext=(i + 0.95, 0.5), arrowprops={"arrowstyle": "->", "color": C["graphite"]})
    ax.set_title(f"Batch {g.batch_id}: hash-chained genealogy (verified: {g.verify()})", fontsize=9, loc="left")
    S.stamp(fig)
    return fig


def pareto_plot(df: pd.DataFrame, objectives: list[str], title: str = "Pareto status") -> plt.Figure:
    pairs = [(objectives[i], objectives[j]) for i in range(len(objectives)) for j in range(i + 1, len(objectives))][:6]
    nc = min(3, len(pairs)); nr = math.ceil(len(pairs) / nc)
    fig, axs = plt.subplots(nr, nc, figsize=(3.2 * nc, 2.8 * nr), squeeze=False)
    nd = (df.pareto_status == "NON-DOMINATED").to_numpy() if "pareto_status" in df else np.ones(len(df), bool)
    for a, (x, y) in zip(axs.flat, pairs, strict=False):
        a.scatter(df[x][~nd], df[y][~nd], c=C["aluminium"], s=22, label="dominated")
        a.scatter(df[x][nd], df[y][nd], c=C["navy"], s=26, label="non-dominated")
        for i, name in enumerate(df.index if df.index.dtype == object else []):
            a.annotate(str(name).replace("Candidate ", ""), (df[x].iloc[i], df[y].iloc[i]), fontsize=6, xytext=(3, 3), textcoords="offset points")
        a.set_xlabel(x, fontsize=7); a.set_ylabel(y, fontsize=7)
    axs.flat[0].legend(fontsize=6)
    fig.suptitle(title, fontsize=9, x=0.02, ha="left"); fig.tight_layout(); S.stamp(fig)
    return fig


def uncertainty_distribution(members: pd.DataFrame, table: pd.DataFrame, keys: list[str]) -> plt.Figure:
    fig, axs = plt.subplots(1, len(keys), figsize=(3.0 * len(keys), 2.8))
    for a, k in zip(np.atleast_1d(axs), keys, strict=True):
        a.hist(members[k], bins=14, color=C["aluminium"], ec=C["steel"])
        t = table.loc[k]
        a.axvline(t["mean"], color=C["navy"]); a.axvspan(t.ci95_lo, t.ci95_hi, color=C["blue"], alpha=0.15)
        a.set_title(f"{k}\n{t['mean']:.4g} ± {1.96 * t.sigma_total:.2g} (95%)", fontsize=8)
    fig.tight_layout(); S.stamp(fig)
    return fig


def model_vs_experiment(pred: np.ndarray, obs: np.ndarray, sigma_obs: np.ndarray | None, sigma_pred: np.ndarray | None, label: str,
                        unit: str = "") -> plt.Figure:
    fig, ax = plt.subplots(figsize=(3.8, 3.6))
    lo, hi = float(min(pred.min(), obs.min())), float(max(pred.max(), obs.max()))
    pad = 0.05 * (hi - lo + 1e-9)
    xs = np.array([lo - pad, hi + pad])
    ax.plot(xs, xs, color=C["steel"], lw=1)
    if sigma_pred is not None:
        ax.fill_between(xs, xs - 1.96 * np.mean(sigma_pred), xs + 1.96 * np.mean(sigma_pred), color=C["blue"], alpha=0.15, label="model 95% band")
    ax.errorbar(obs, pred, xerr=None if sigma_obs is None else 1.96 * sigma_obs, fmt="o", color=C["navy"], ms=4, capsize=2, label="validation samples")
    ax.set_xlabel(f"EXPERIMENT {label} {unit}"); ax.set_ylabel(f"MODEL {label} {unit}"); ax.set_title("MODEL vs EXPERIMENT (measured data)", fontsize=9)
    ax.legend(fontsize=7); fig.tight_layout(); S.stamp(fig)
    return fig


def sensitivity_bars(sens: pd.DataFrame, col: str = "dyield_strength_pct_over_tolerance") -> plt.Figure:
    fig, ax = plt.subplots(figsize=(5.4, 3.0))
    s = sens.set_index("parameter")[col].sort_values()
    ax.barh(s.index, s.values, color=[C["amber"] if abs(v) > 3 else C["navy"] for v in s.values])
    ax.set_xlabel("% change in yield strength per +tolerance"); ax.set_title("Process sensitivity (local, central difference)")
    fig.tight_layout(); S.stamp(fig)
    return fig
