"""Visual language: aerospace materials laboratory.  White, graphite, aluminium, deep navy, steel, restrained blue/amber/red."""

from __future__ import annotations

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402

PALETTE = {
    "white": "#ffffff", "paper": "#f6f7f8", "graphite": "#2b2f36", "aluminium": "#b8bec6", "navy": "#0b2447", "steel": "#5f6b7a",
    "blue": "#2f5d8c", "amber": "#c98a1b", "red": "#a8322d", "grid": "#dfe3e8",
}
SERIES = [PALETTE["navy"], PALETTE["blue"], PALETTE["steel"], PALETTE["amber"], PALETTE["red"], "#7d8a99", "#8aa4c2"]


def apply() -> None:
    plt.rcParams.update({
        "figure.facecolor": PALETTE["white"], "axes.facecolor": PALETTE["white"], "axes.edgecolor": PALETTE["steel"],
        "axes.labelcolor": PALETTE["graphite"], "xtick.color": PALETTE["graphite"], "ytick.color": PALETTE["graphite"],
        "text.color": PALETTE["graphite"], "axes.grid": True, "grid.color": PALETTE["grid"], "grid.linewidth": 0.6,
        "axes.spines.top": False, "axes.spines.right": False, "font.size": 9, "axes.titlesize": 10, "axes.titleweight": "bold",
        "axes.prop_cycle": plt.cycler(color=SERIES), "legend.frameon": False, "figure.dpi": 110, "savefig.dpi": 140,
        "lines.linewidth": 1.6,
    })


apply()

STAMP = "AEROLITH-TWIN · simulation output · not a qualification"


def stamp(fig, extra: str = "") -> None:  # type: ignore[no-untyped-def]
    fig.text(0.995, 0.005, (STAMP + (" · " + extra if extra else "")), ha="right", va="bottom", fontsize=6.5, color=PALETTE["steel"])
