"""Optional 3-D statistical microstructure view (plotly).  Clearly labelled: not atomistic, not a reconstruction."""

from __future__ import annotations

import numpy as np

from ..microstructure.state import MaterialState

LABEL = "STATISTICAL MICROSTRUCTURE REPRESENTATION"


def build_figure(state: MaterialState, seed: int = 0, n_grains: int = 60, n_particles: int = 800):  # type: ignore[no-untyped-def]
    import plotly.graph_objects as go

    rng = np.random.default_rng(seed)
    g = state.grains
    assert g is not None
    # window of ~6 mean-grain lengths along L, scaled to the grain dimensions
    box = np.array([5.0 * g.d_L, 5.0 * g.d_T, 5.0 * g.d_N])
    diam = g.sample_diameters(rng, n_grains) / g.mean_size_m
    fig = go.Figure()
    u, v = np.mgrid[0 : 2 * np.pi : 14j, 0 : np.pi : 8j]
    for i in range(n_grains):
        c = rng.random(3) * box
        a = np.array([g.d_L, g.d_T, g.d_N]) * diam[i] * 0.5
        x = c[0] + a[0] * np.cos(u) * np.sin(v)
        y = c[1] + a[1] * np.sin(u) * np.sin(v)
        z = c[2] + a[2] * np.cos(v)
        fig.add_trace(go.Surface(x=x * 1e6, y=y * 1e6, z=z * 1e6, showscale=False, opacity=0.35,
                                 colorscale=[[0, "#b8bec6"], [1, "#5f6b7a"]], hoverinfo="skip", showlegend=False))
    # precipitates (visualised enlarged by a stated factor)
    ptot = state.precip.total_volume_fraction()
    if ptot > 0:
        pts = rng.random((n_particles, 3)) * box
        fig.add_trace(go.Scatter3d(x=pts[:, 0] * 1e6, y=pts[:, 1] * 1e6, z=pts[:, 2] * 1e6, mode="markers", name="precipitates (enlarged, count not to scale)",
                                   marker={"size": 1.6, "color": "#2f5d8c"}))
    df = state.defects.to_dataframe()
    if not df.empty:
        k = min(len(df), 150)
        d = df.nlargest(k, "size_m")
        fig.add_trace(go.Scatter3d(x=d.u * box[0] * 1e6, y=d.v * box[1] * 1e6, z=d.w * box[2] * 1e6, mode="markers", name="largest defects (position schematic)",
                                   marker={"size": 4, "color": "#a8322d", "symbol": "diamond"}))
    fig.update_layout(title=f"{LABEL} — grains as lognormal ellipsoids; boundaries implied by ellipsoid surfaces; not atomistic",
                      scene={"xaxis_title": "RD (µm)", "yaxis_title": "TD (µm)", "zaxis_title": "ND (µm)", "aspectmode": "data"},
                      paper_bgcolor="white", font={"color": "#2b2f36", "size": 11}, margin={"l": 0, "r": 0, "t": 50, "b": 0})
    return fig
