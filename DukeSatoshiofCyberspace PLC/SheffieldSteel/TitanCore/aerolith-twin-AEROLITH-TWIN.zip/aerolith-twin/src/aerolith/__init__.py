"""AEROLITH-TWIN: aerospace aluminium-lithium alloy manufacturing digital twin.

Research / engineering-development software.  It is NOT a substitute for certified
materials qualification, laboratory testing, standards compliance, destructive
testing, NDT qualification, production process qualification, finite-element
certification or airworthiness approval.
"""

__version__ = "0.1.0"
MODEL_VERSION = "AEROLITH-MODELS-0.1.0"

DISCLAIMER = (
    "AEROLITH-TWIN is a research, engineering-development and manufacturing digital twin. "
    "It is not a substitute for certified materials qualification, metallurgical laboratory "
    "testing, aerospace standards compliance, destructive testing, NDT qualification, "
    "production process qualification, finite-element certification or airworthiness approval."
)
