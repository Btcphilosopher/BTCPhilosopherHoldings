"""Homogenisation physics: constituent dissolution, dispersoid precipitation, burning limit."""

from __future__ import annotations

import math

import numpy as np

from ..chemistry.composition import Composition
from ..chemistry.elements import ATOMIC_MASS_G_MOL
from ..governance import ModelMeta, register
from ..microstructure.defects import DefectType
from ..microstructure.state import MaterialState, wt_to_atom_fraction_scale
from ..params import P, Status, declare
from ..thermodynamics.equilibrium import K_of_T
from .diffusion import cosine_modes_evolve, diffusivity
from .thermal_cycle import ThermalCycle

declare(
    P("homog.eutectic_phase_fraction", 0.5, "-", Status.ILLUSTRATIVE, "volume fraction of the interdendritic eutectic region occupied by the soluble constituent phase", 0.2, 0.05, 1.0),
    P("homog.sol_mass_fraction", 0.45, "-", Status.ILLUSTRATIVE, "mass fraction of Cu+Li+Mg in the soluble eutectic constituent", 0.1, 0.1, 0.9),
    P("homog.constituent_density", 3500.0, "kg/m3", Status.ILLUSTRATIVE, "density of soluble eutectic constituent phases", 500.0, 2500, 6000),
    P("homog.constituent_size_factor", 0.10, "-", Status.ILLUSTRATIVE, "constituent particle radius / lambda2", 0.25, 0.01, 0.5, True),
    P("homog.dissolution_lambda", 0.05, "-", Status.ILLUSTRATIVE, "stationary-interface dissolution parameter (cI-cM)/(cp-cI)", 0.5, 1e-3, 1.0, True),
    P("homog.burning_margin_after_homog", 30.0, "K", Status.ILLUSTRATIVE, "rise of incipient-melting limit once eutectic is dissolved", 10.0, 0.0, 80.0),
    P("homog.burn_void_rate", 4.0e2, "1/m3 per K excess", Status.ILLUSTRATIVE, "incipient-melting void count per m3 per K above limit", 0.8, 0.0, 1e6, True),
    P("homog.fe_mass_fraction", 0.15, "-", Status.ILLUSTRATIVE, "Fe mass fraction in Fe-bearing constituent (Al7Cu2Fe-like)", 0.03, 0.05, 0.5),
    P("homog.si_mass_fraction", 0.15, "-", Status.ILLUSTRATIVE, "Si mass fraction in Si-bearing constituent", 0.03, 0.05, 0.5),
    P("homog.insoluble_density", 4400.0, "kg/m3", Status.ILLUSTRATIVE, "density of insoluble Fe/Si-bearing constituents", 400.0, 3000, 7000),
)

META_DISS = register(ModelMeta(
    model_name="constituent_dissolution_stationary_interface",
    equation="r^2 = r0^2 - 2 lambda int D dt ; f/f0 = (r/r0)^3",
    parameter_source="registry homog.* (ILLUSTRATIVE), diff.*",
    validity_range="diffusion-limited dissolution of spherical particles of one controlling solute (Cu); stationary-interface approximation",
))
META_HOMOG = register(ModelMeta(
    model_name="homogenisation_cosine_mode_diffusion",
    equation="c(x,t)=sum a_n cos(n pi x/L) exp(-(n pi/L)^2 int D dt)",
    parameter_source="registry diff.* ; lambda2 from segregation model",
    validity_range="1-D dendrite-arm cell with no-flux boundaries; independent solutes; D from dilute lattice diffusion",
    fidelity="ANALYTICAL",
))


def initial_constituents(ctx, comp: Composition, rho_kg_m3: float) -> float:  # type: ignore[no-untyped-def]
    """Volume fraction of insoluble Fe/Si-bearing constituents from mass balance (all Fe and Si assumed bound)."""
    ctx.use(META_DISS.model_name)
    w = comp.wt()
    mass = w["Fe"] / 100.0 / ctx.p("homog.fe_mass_fraction") + w["Si"] / 100.0 / ctx.p("homog.si_mass_fraction")
    return float(mass * rho_kg_m3 / ctx.p("homog.insoluble_density"))


def burning_limit_K(ctx, state: MaterialState) -> float:  # type: ignore[no-untyped-def]
    base = ctx.p("cast.T_eutectic")
    if state.eutectic_fraction > 0.2 * max(state.eutectic_fraction_initial, 1e-12):
        return base
    return base + ctx.p("homog.burning_margin_after_homog")


def apply_homogenisation(ctx, state: MaterialState, cycle: ThermalCycle) -> dict[str, float]:  # type: ignore[no-untyped-def]
    """Dissolve eutectic constituents and diffuse the segregation profile through ``cycle``."""
    ctx.use(META_HOMOG.model_name)
    ctx.use(META_DISS.model_name)
    T_peak = cycle.peak_K()
    out: dict[str, float] = {"peak_K": T_peak}
    limit = burning_limit_K(ctx, state)
    out["burning_limit_K"] = limit
    if T_peak > limit:
        excess = T_peak - limit
        ctx.warn(f"INCIPIENT MELTING RISK: homogenisation peak {T_peak:.0f} K exceeds limit {limit:.0f} K by {excess:.0f} K")
        state.flags.append("incipient_melting_risk")
        V = state.dims_m[0] * state.dims_m[1] * state.dims_m[2]
        n = ctx.rng.poisson(ctx.p("homog.burn_void_rate") * excess * V)
        for _ in range(int(min(n, 2000))):
            state.defects.add(DefectType.VOID, float(ctx.rng.lognormal(math.log(4e-5), 0.5)),
                              (ctx.rng.uniform(), ctx.rng.uniform(), ctx.rng.uniform()), ctx.rng.normal(size=3),
                              confidence=0.4, origin="homogenisation: incipient melting")
    # --- eutectic constituent dissolution (Cu is the slow, controlling solute) -------------------------------
    if state.eutectic_fraction > 0:
        r0 = state.constituent_radius_m
        int_D = cycle.effective_diffusion_integral(ctx.p("diff.Cu.D0"), ctx.p("diff.Cu.Q"))
        r2 = r0**2 - 2.0 * ctx.p("homog.dissolution_lambda") * int_D
        remaining = (max(r2, 0.0) / r0**2) ** 1.5
        out["eutectic_remaining_fraction"] = remaining
        dissolved = 1.0 - remaining
        scale = wt_to_atom_fraction_scale(state.composition)
        released_wt: dict[str, float] = {}
        for el, w_locked in state.eutectic_solute_wt.items():
            rel = w_locked * dissolved
            released_wt[el] = rel
            state.eutectic_solute_wt[el] = w_locked - rel
            if el in state.solute_pool_at:
                state.solute_pool_at[el] += rel / ATOMIC_MASS_G_MOL[el] / scale
        state.eutectic_fraction *= remaining
        state.constituent_radius_m = math.sqrt(max(r2, 0.0))
        # released solute enters the interdendritic region of the profiles
        for el, rel in released_wt.items():
            if el in state.profiles_wt and rel > 0:
                prof = state.profiles_wt[el]
                m = max(2, prof.size // 10)
                prof[-m:] += rel / (m / prof.size)
    # --- diffusion of segregation profiles ---------------------------------------------------------------------
    L = 0.5 * state.lambda2_m
    resid: dict[str, float] = {}
    for el, prof in list(state.profiles_wt.items()):
        int_D = cycle.effective_diffusion_integral(ctx.p(f"diff.{el}.D0"), ctx.p(f"diff.{el}.Q"))
        new = cosine_modes_evolve(prof, L, int_D)
        state.profiles_wt[el] = new
        resid[el] = float((new.max() - new.min()) / max(new.mean(), 1e-12))
        out[f"residual_segregation_{el}"] = resid[el]
    state.peak_temperature_K = max(state.peak_temperature_K, T_peak)
    return out


def dispersoid_free_fraction(ctx, state: MaterialState, T_hold_K: float) -> float:  # type: ignore[no-untyped-def]
    """Fraction of the dendrite cell where local Zr (after homogenisation) is below the Al3Zr solubility."""
    if "Zr" not in state.profiles_wt:
        return 0.0
    scale = wt_to_atom_fraction_scale(state.composition)
    x_local = state.profiles_wt["Zr"] / ATOMIC_MASS_G_OMEGA("Zr") / scale
    K = K_of_T(ctx, "Al3Zr", T_hold_K)
    return float(np.mean(x_local <= 1.5 * K))


def ATOMIC_MASS_G_OMEGA(el: str) -> float:  # noqa: N802
    return ATOMIC_MASS_G_MOL[el]


_ = diffusivity
