"""Solute diffusion in the Al matrix: D(T) = D0 exp(-Q/RT), and exact cosine-mode evolution."""

from __future__ import annotations

import math

import numpy as np
from scipy.fft import dct, idct

from ..governance import ModelMeta, register
from ..params import P, Status, declare
from ..units import R_GAS

_LIT = "Commonly quoted tracer/impurity diffusion values for Al; verify against your reference before relying on them"
_ILL = "Order-of-magnitude placeholder; replace with measured/assessed value"
declare(
    P("diff.Li.D0", 4.5e-6, "m2/s", Status.ILLUSTRATIVE, _ILL, 0.7, 1e-9, 1e-2, True),
    P("diff.Li.Q", 1.35e5, "J/mol", Status.ILLUSTRATIVE, _ILL, 1.0e4, 5e4, 3e5),
    P("diff.Cu.D0", 6.5e-5, "m2/s", Status.LITERATURE_APPROX, _LIT, 0.4, 1e-9, 1e-2, True),
    P("diff.Cu.Q", 1.36e5, "J/mol", Status.LITERATURE_APPROX, _LIT, 2.0e3, 5e4, 3e5),
    P("diff.Mg.D0", 1.24e-4, "m2/s", Status.LITERATURE_APPROX, _LIT, 0.4, 1e-9, 1e-2, True),
    P("diff.Mg.Q", 1.31e5, "J/mol", Status.LITERATURE_APPROX, _LIT, 5.0e3, 5e4, 3e5),
    P("diff.Zn.D0", 2.59e-5, "m2/s", Status.LITERATURE_APPROX, _LIT, 0.4, 1e-9, 1e-2, True),
    P("diff.Zn.Q", 1.21e5, "J/mol", Status.LITERATURE_APPROX, _LIT, 5.0e3, 5e4, 3e5),
    P("diff.Ag.D0", 1.18e-4, "m2/s", Status.LITERATURE_APPROX, _LIT, 0.4, 1e-9, 1e-2, True),
    P("diff.Ag.Q", 1.24e5, "J/mol", Status.LITERATURE_APPROX, _LIT, 5.0e3, 5e4, 3e5),
    P("diff.Zr.D0", 7.28e-2, "m2/s", Status.LITERATURE_APPROX, _LIT, 0.8, 1e-9, 1e2, True),
    P("diff.Zr.Q", 2.42e5, "J/mol", Status.LITERATURE_APPROX, _LIT, 1.0e4, 1e5, 4e5),
    P("diff.Sc.D0", 5.31e-4, "m2/s", Status.LITERATURE_APPROX, _LIT, 0.6, 1e-9, 1e-1, True),
    P("diff.Sc.Q", 1.73e5, "J/mol", Status.LITERATURE_APPROX, _LIT, 8.0e3, 1e5, 4e5),
    P("diff.Mn.D0", 1.35e-4, "m2/s", Status.ILLUSTRATIVE, _ILL, 0.8, 1e-9, 1e-1, True),
    P("diff.Mn.Q", 2.0e5, "J/mol", Status.ILLUSTRATIVE, _ILL, 1.5e4, 1e5, 4e5),
    P("diff.Fe.D0", 5.3e-3, "m2/s", Status.ILLUSTRATIVE, _ILL, 0.8, 1e-9, 1e-1, True),
    P("diff.Fe.Q", 1.85e5, "J/mol", Status.ILLUSTRATIVE, _ILL, 1.5e4, 1e5, 4e5),
    P("diff.Si.D0", 2.02e-4, "m2/s", Status.ILLUSTRATIVE, _ILL, 0.6, 1e-9, 1e-1, True),
    P("diff.Si.Q", 1.36e5, "J/mol", Status.ILLUSTRATIVE, _ILL, 1.0e4, 5e4, 3e5),
    P("diff.Ti.D0", 1.12e-1, "m2/s", Status.ILLUSTRATIVE, _ILL, 1.0, 1e-9, 1e2, True),
    P("diff.Ti.Q", 2.60e5, "J/mol", Status.ILLUSTRATIVE, _ILL, 2.0e4, 1e5, 4e5),
)

META = register(ModelMeta(
    model_name="solute_diffusion_arrhenius",
    equation="D(T) = D0 exp(-Q/(R T)); sinusoidal/cosine-mode decay exp(-(n pi/L)^2 int D dt)",
    parameter_source="registry diff.* (mixed LITERATURE_APPROX / ILLUSTRATIVE)",
    validity_range="dilute solutes in Al, 600-850 K; lattice diffusion only (no pipe/boundary diffusion, no vacancy excess)",
    fidelity="ANALYTICAL",
))


def D_arrhenius(D0: float, Q: float, T: float) -> float:
    return D0 * math.exp(-Q / (R_GAS * T))


def diffusivity(ctx, element: str, T: float) -> float:  # type: ignore[no-untyped-def]
    ctx.use(META.model_name)
    return D_arrhenius(ctx.p(f"diff.{element}.D0"), ctx.p(f"diff.{element}.Q"), T)


def cosine_modes_evolve(profile: np.ndarray, length: float, int_D_dt: float) -> np.ndarray:
    """Exact solution of c_t = D c_xx on [0, L] with no-flux ends, for a sampled profile.

    ``profile`` is sampled at cell centres.  The result depends on the temperature
    history only through int D dt (m2), so any thermal cycle is handled exactly.
    """
    n = profile.size
    a = dct(profile, type=2, norm="ortho")
    k = np.arange(n)
    decay = np.exp(-((k * math.pi / length) ** 2) * int_D_dt)
    return idct(a * decay, type=2, norm="ortho")


def sinusoid_amplitude_decay(D_t: float, wavelength: float) -> float:
    """Analytic decay factor of a sinusoid of the given wavelength: exp(-4 pi^2 D t / lambda^2)."""
    return math.exp(-4.0 * math.pi**2 * D_t / wavelength**2)
