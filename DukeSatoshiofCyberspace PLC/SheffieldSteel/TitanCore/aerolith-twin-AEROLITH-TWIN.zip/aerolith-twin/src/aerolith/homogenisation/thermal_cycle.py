"""Piecewise-linear thermal cycles (SI: K, s)."""

from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np

from ..units import R_GAS


@dataclass
class ThermalCycle:
    """Time-temperature schedule as breakpoints; linear in between."""

    t_s: np.ndarray
    T_K: np.ndarray
    label: str = ""

    def __post_init__(self) -> None:
        self.t_s = np.asarray(self.t_s, float)
        self.T_K = np.asarray(self.T_K, float)
        if self.t_s.shape != self.T_K.shape or self.t_s.size < 2:
            raise ValueError("thermal cycle needs >= 2 matching breakpoints")
        if np.any(np.diff(self.t_s) < 0):
            raise ValueError("time must be non-decreasing")
        if np.any(self.T_K <= 0):
            raise ValueError("temperatures must be in kelvin")

    @property
    def duration(self) -> float:
        return float(self.t_s[-1] - self.t_s[0])

    def T_at(self, t: float | np.ndarray) -> np.ndarray:
        return np.interp(t, self.t_s, self.T_K)

    def resample(self, n: int = 400) -> tuple[np.ndarray, np.ndarray]:
        t = np.linspace(self.t_s[0], self.t_s[-1], n)
        return t, self.T_at(t)

    def effective_diffusion_integral(self, D0: float, Q: float, n: int = 4000) -> float:
        """int D(T(t)) dt in m2 (trapezoid on a fine grid)."""
        t = np.linspace(self.t_s[0], self.t_s[-1], n)
        D = D0 * np.exp(-Q / (R_GAS * self.T_at(t)))
        return float(np.trapezoid(D, t))

    def peak_K(self) -> float:
        return float(self.T_K.max())

    @staticmethod
    def ramp_hold_cool(T_start: float, T_hold: float, heat_rate_K_s: float, hold_s: float,
                       T_end: float | None = None, cool_rate_K_s: float = 0.05, label: str = "") -> ThermalCycle:
        if heat_rate_K_s <= 0:
            raise ValueError("heating rate must be positive")
        t_heat = abs(T_hold - T_start) / heat_rate_K_s
        ts = [0.0, t_heat, t_heat + hold_s]
        Ts = [T_start, T_hold, T_hold]
        if T_end is not None:
            ts.append(ts[-1] + abs(T_hold - T_end) / cool_rate_K_s)
            Ts.append(T_end)
        return ThermalCycle(np.array(ts), np.array(Ts), label)


@dataclass
class ThermalRecord:
    """Realised (true) temperature history of a unit operation, for sensors/genealogy."""

    name: str
    t_s: np.ndarray
    T_K: np.ndarray
    extras: dict[str, np.ndarray] = field(default_factory=dict)
