"""Classical nucleation-theory building blocks (dilute-solution, stoichiometric precipitate)."""

from __future__ import annotations

import math

from ..governance import ModelMeta, register
from ..units import K_B, N_A, R_GAS

META_CNT = register(ModelMeta(
    model_name="classical_nucleation_theory",
    equation="dGv = -(R T / Vm) ln S ; r* = 2 gamma / |dGv| ; dG* = 16 pi gamma^3 / (3 dGv^2)",
    parameter_source="interfacial energies: ILLUSTRATIVE (see parameter registry)",
    validity_range="S in (1, ~50); dilute ideal solution; isotropic interfacial energy; coherent/semi-coherent only",
    fidelity="REDUCED-ORDER",
))


def driving_force_per_volume(supersaturation: float, T: float, molar_volume: float) -> float:
    """|dGv| in J m-3 for geometric-mean supersaturation S = (prod x^e / K)^(1/sum e)."""
    if supersaturation <= 1.0:
        return 0.0
    return R_GAS * T / molar_volume * math.log(supersaturation)


def critical_radius(gamma: float, dGv: float) -> float:
    return math.inf if dGv <= 0 else 2.0 * gamma / dGv


def nucleation_barrier(gamma: float, dGv: float, shape_factor: float = 1.0) -> float:
    """dG* in J (shape_factor < 1 for heterogeneous nucleation on defects)."""
    if dGv <= 0:
        return math.inf
    return shape_factor * 16.0 * math.pi * gamma**3 / (3.0 * dGv**2)


def gibbs_thomson_length(gamma: float, molar_volume: float, T: float) -> float:
    """r_GT = 2 gamma Vm / (R T); equilibrium solubility at radius r is c_eq exp(r_GT / r)."""
    return 2.0 * gamma * molar_volume / (R_GAS * T)


def boltzmann_factor(dG: float, T: float) -> float:
    x = dG / (K_B * T)
    return 0.0 if x > 700 else math.exp(-x)


def atomic_volume(molar_volume: float) -> float:
    return molar_volume / N_A
