"""Activity models for the dilute matrix."""

from __future__ import annotations

import math

from ..units import R_GAS


def activity_regular_solution(x: float, omega_j_mol: float, T: float) -> float:
    """Activity of a solute in a regular solution: a = x exp(Omega (1-x)^2 / R T)."""
    return x * math.exp(omega_j_mol * (1.0 - x) ** 2 / (R_GAS * T))


def henrian_activity(x: float, gamma0: float = 1.0) -> float:
    """a = gamma0 * x (dilute limit)."""
    return gamma0 * x


def ideal_mixing_gibbs(x: float, T: float) -> float:
    """Ideal molar Gibbs energy of mixing for a binary, J mol-1."""
    if x <= 0.0 or x >= 1.0:
        return 0.0
    return R_GAS * T * (x * math.log(x) + (1 - x) * math.log(1 - x))
