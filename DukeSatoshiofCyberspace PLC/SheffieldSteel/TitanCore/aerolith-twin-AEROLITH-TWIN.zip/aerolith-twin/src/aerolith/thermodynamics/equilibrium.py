"""Reduced-order equilibrium: solubility products + solute mass balance.

No CALPHAD database is bundled.  Each precipitating phase p is described by a
solubility-product relation  prod_s x_s^{e_ps} = K_p(T) = K0_p exp(-Q_p / R T)
(x = atomic fraction of free solute in the Al matrix).  Equilibrium follows from
complementary slackness over the possible active-phase sets, with solute
conservation.  K0 and Q are registry parameters (ILLUSTRATIVE by default).
"""

from __future__ import annotations

import itertools
import math
from dataclasses import dataclass

import numpy as np
from scipy.optimize import root

from ..governance import ModelMeta, register
from ..params import P, Status, declare
from ..units import R_GAS

SOLUTE_INDEX = {"Li": 0, "Cu": 1, "Zr": 2, "Sc": 3}
N_SOL = 4


@dataclass(frozen=True)
class PhaseDef:
    key: str  # parameter prefix
    label: str
    ctrl: str  # controlling (rate-limiting) solute
    e: tuple[float, float, float, float]  # solubility-product exponents [Li, Cu, Zr, Sc]
    s: tuple[float, float, float, float]  # solute atomic fractions in the precipitate
    shape: str  # sphere | plate


PHASES: tuple[PhaseDef, ...] = (
    PhaseDef("delta_prime", "delta' (Al3Li)", "Li", (1, 0, 0, 0), (0.25, 0, 0, 0), "sphere"),
    PhaseDef("T1", "T1 (Al2CuLi)", "Cu", (1, 1, 0, 0), (0.25, 0.25, 0, 0), "plate"),
    PhaseDef("theta_prime", "theta' (Al2Cu)", "Cu", (0, 1, 0, 0), (0, 1 / 3, 0, 0), "plate"),
    PhaseDef("Al3Zr", "Al3Zr (L1_2)", "Zr", (0, 0, 1, 0), (0, 0, 0.25, 0), "sphere"),
    PhaseDef("Al3Sc", "Al3Sc (L1_2)", "Sc", (0, 0, 0, 1), (0, 0, 0, 0.25), "sphere"),
)
PHASE_KEYS = tuple(p.key for p in PHASES)

_L = "Illustrative reduced-order solubility relation tuned to give physically plausible solvus ordering; replace with CALPHAD/experiment"
declare(
    P("thermo.delta_prime.K0", 7.1, "-", Status.ILLUSTRATIVE, _L, 0.12, 0.1, 1e3, True),
    P("thermo.delta_prime.Q", 18700.0, "J/mol", Status.ILLUSTRATIVE, _L, 800.0, 5e3, 6e4),
    P("thermo.T1.K0", 64.0, "-", Status.ILLUSTRATIVE, _L, 0.12, 1e-2, 1e6, True),
    P("thermo.T1.Q", 57000.0, "J/mol", Status.ILLUSTRATIVE, _L, 1500.0, 1e4, 2e5),
    P("thermo.theta_prime.K0", 1.36, "-", Status.ILLUSTRATIVE, _L, 0.12, 1e-2, 1e4, True),
    P("thermo.theta_prime.Q", 26300.0, "J/mol", Status.ILLUSTRATIVE, _L, 1000.0, 5e3, 1e5),
    P("thermo.Al3Zr.K0", 2.3e3, "-", Status.ILLUSTRATIVE, _L, 0.2, 1.0, 1e9, True),
    P("thermo.Al3Zr.Q", 102000.0, "J/mol", Status.ILLUSTRATIVE, _L, 2500.0, 2e4, 3e5),
    P("thermo.Al3Sc.K0", 100.0, "-", Status.ILLUSTRATIVE, _L, 0.2, 1e-2, 1e9, True),
    P("thermo.Al3Sc.Q", 80000.0, "J/mol", Status.ILLUSTRATIVE, _L, 2500.0, 2e4, 3e5),
    P("thermo.molar_volume", 9.99e-6, "m3/mol", Status.REFERENCE, "molar volume of pure Al; precipitate molar volume assumed equal", 5e-8),
    P("thermo.volume_ratio", 1.0, "-", Status.ILLUSTRATIVE, "precipitate/matrix atomic volume ratio assumed 1 (small misfit)", 0.03, 0.8, 1.3),
)

META = register(ModelMeta(
    model_name="solubility_product_equilibrium",
    equation="prod_s x_s^e_ps = K0_p exp(-Q_p/RT); c_s (1 - sum phi) + sum_p phi_p s_ps = c0_s",
    parameter_source="registry thermo.* (ILLUSTRATIVE unless calibrated)",
    validity_range="dilute Al-rich matrix (solute < ~10 at%); 250-850 K; metastable phases treated as equilibrium phases",
))


def K_of_T(ctx, key: str, T: float) -> float:  # type: ignore[no-untyped-def]
    return ctx.p(f"thermo.{key}.K0") * math.exp(-ctx.p(f"thermo.{key}.Q") / (R_GAS * T))


@dataclass
class EquilibriumResult:
    temperature_K: float
    phi: dict[str, float]  # atomic (~volume) fraction of each phase
    matrix: dict[str, float]  # free solute atomic fractions
    active: list[str]


def equilibrium(ctx, c0: dict[str, float], T: float) -> EquilibriumResult:  # type: ignore[no-untyped-def]
    """Equilibrium phase fractions and matrix concentrations at temperature T (K).

    ``c0`` holds total precipitating-solute atomic fractions {Li, Cu, Zr, Sc}.
    """
    ctx.use(META.model_name)
    phi: dict[str, float] = dict.fromkeys(PHASE_KEYS, 0.0)
    matrix = dict(c0)

    # independent single-solute dispersoid systems
    for pd in PHASES:
        if pd.key in ("Al3Zr", "Al3Sc"):
            K = K_of_T(ctx, pd.key, T)
            c = c0.get(pd.ctrl, 0.0)
            if c > K:
                f_disp = (c - K) / (pd.s[SOLUTE_INDEX[pd.ctrl]] - K)
                phi[pd.key] = f_disp
                matrix[pd.ctrl] = K
    # coupled Li-Cu system
    coupled = [p for p in PHASES if p.key in ("delta_prime", "T1", "theta_prime")]
    cLi, cCu = c0.get("Li", 0.0), c0.get("Cu", 0.0)
    Ks = {p.key: K_of_T(ctx, p.key, T) for p in coupled}

    def matrix_conc(f: np.ndarray, subset: tuple[PhaseDef, ...]) -> tuple[float, float]:
        tot = float(np.sum(f))
        li = cLi - sum(fi * p.s[0] for fi, p in zip(f, subset, strict=True))
        cu = cCu - sum(fi * p.s[1] for fi, p in zip(f, subset, strict=True))
        return li / (1 - tot), cu / (1 - tot)

    def prod(p: PhaseDef, li: float, cu: float) -> float:
        return (max(li, 1e-30) ** p.e[0]) * (max(cu, 1e-30) ** p.e[1])

    chosen: tuple[tuple[PhaseDef, ...], np.ndarray] | None = None
    for size in range(0, 4):
        for subset in itertools.combinations(coupled, size):
            if size == 0:
                li, cu = cLi, cCu
                ok = all(prod(p, li, cu) <= Ks[p.key] * (1 + 1e-9) for p in coupled)
                if ok:
                    chosen = (subset, np.zeros(0))
                    break
                continue

            def resid(logf: np.ndarray, subset=subset) -> np.ndarray:  # noqa: B008
                f = np.exp(logf)
                if np.sum(f) >= 0.9:
                    return np.full(len(subset), 1e3)
                li, cu = matrix_conc(f, subset)
                if li <= 0 or cu <= 0:
                    return np.full(len(subset), 1e3)
                return np.array([math.log(prod(p, li, cu) / Ks[p.key]) for p in subset])

            for guess in (-6.0, -4.5, -3.0):
                sol = root(resid, np.full(size, guess), method="hybr", tol=1e-12)
                if sol.success and np.max(np.abs(sol.fun)) < 1e-8:
                    f = np.exp(sol.x)
                    li, cu = matrix_conc(f, subset)
                    inactive_ok = all(
                        prod(p, li, cu) <= Ks[p.key] * (1 + 1e-7) for p in coupled if p not in subset
                    )
                    if inactive_ok and li > 0 and cu > 0:
                        chosen = (subset, f)
                        break
            if chosen:
                break
        if chosen:
            break
    if chosen is not None:
        subset, f = chosen
        for fi, p in zip(f, subset, strict=True):
            phi[p.key] = float(fi)
        li, cu = matrix_conc(f, subset) if len(subset) else (cLi, cCu)
        matrix["Li"], matrix["Cu"] = float(li), float(cu)
    else:
        ctx.warn(f"equilibrium: no consistent active-phase set found at T={T:.0f} K; returning unprecipitated state")
    return EquilibriumResult(T, phi, matrix, [k for k, v in phi.items() if v > 1e-12])


def solvus_temperature(ctx, key: str, c_ctrl: float, c_other: float = 1.0) -> float:  # type: ignore[no-untyped-def]
    """Temperature (K) at which the phase's solubility relation equals the supplied composition.

    For the product-form phase (T1) ``c_ctrl`` and ``c_other`` are the two solute fractions.
    """
    K0, Q = ctx.p(f"thermo.{key}.K0"), ctx.p(f"thermo.{key}.Q")
    target = c_ctrl * c_other
    if target >= K0:
        return math.inf
    return Q / (R_GAS * math.log(K0 / target))
