"""Phase-fraction conversions."""

from __future__ import annotations


def lever_rule(c0: float, c_alpha: float, c_beta: float) -> float:
    """Fraction of phase beta in a two-phase mixture of alpha (c_alpha) and beta (c_beta)."""
    if c_beta == c_alpha:
        return 0.0
    return min(1.0, max(0.0, (c0 - c_alpha) / (c_beta - c_alpha)))


def volume_fraction_from_atomic(phi: float, volume_ratio: float = 1.0) -> float:
    """Volume fraction from atomic fraction; volume_ratio = (atomic volume in precipitate)/(in matrix)."""
    num = phi * volume_ratio
    return num / (num + (1.0 - phi))
