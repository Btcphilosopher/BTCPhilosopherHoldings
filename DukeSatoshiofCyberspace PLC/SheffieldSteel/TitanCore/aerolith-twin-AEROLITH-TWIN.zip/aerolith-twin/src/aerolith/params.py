"""Parameter registry with explicit provenance.

Every model parameter has: value, units, source, status, validity range and
uncertainty.  Status vocabulary (honest by construction):

REFERENCE          physical constant or handbook value of a pure element/phase
LITERATURE_APPROX  order-of-magnitude / widely quoted value; verify before relying on it
ILLUSTRATIVE       engineering placeholder enabling the model to run; NOT a validated
                   material value.  Results depending on it are not predictions.
CALIBRATED         fitted to user data (dataset id recorded in `source`)
USER_SUPPLIED      provided by the user (e.g. validated dataset)
UNKNOWN            no value; models that need it raise ParameterUnknownError
                   (or skip the dependent effect and record a warning)

Nothing in this file claims a citation that the author cannot stand behind:
``source`` strings say what the number *is*, not that it is validated.
"""

from __future__ import annotations

import hashlib
import json
import math
from dataclasses import asdict, dataclass, replace
from enum import StrEnum
from pathlib import Path
from typing import Any

import numpy as np
import yaml

from .errors import ParameterUnknownError

PARAM_REVISION = "0.1.0"


class Status(StrEnum):
    REFERENCE = "REFERENCE"
    LITERATURE_APPROX = "LITERATURE_APPROX"
    ILLUSTRATIVE = "ILLUSTRATIVE"
    CALIBRATED = "CALIBRATED"
    USER_SUPPLIED = "USER_SUPPLIED"
    UNKNOWN = "UNKNOWN"


@dataclass(frozen=True)
class Parameter:
    name: str
    value: float | None
    units: str
    source: str
    status: Status
    uncertainty: float = 0.0  # 1-sigma; relative on ln(value) if log_scale else absolute
    valid_min: float | None = None
    valid_max: float | None = None
    log_scale: bool = False
    note: str = ""
    revision: str = PARAM_REVISION


_DEFAULTS: dict[str, Parameter] = {}


def declare(*params: Parameter) -> None:
    for p in params:
        if p.name in _DEFAULTS:
            raise ValueError(f"duplicate parameter declaration: {p.name}")
        _DEFAULTS[p.name] = p


def P(name: str, value: float | None, units: str, status: Status, source: str, unc: float = 0.0,
      lo: float | None = None, hi: float | None = None, log: bool = False, note: str = "") -> Parameter:
    """Short constructor used by the declaration tables."""
    return Parameter(name, value, units, source, status, unc, lo, hi, log, note)


class ParameterRegistry:
    def __init__(self, params: dict[str, Parameter], label: str = "default"):
        self._p: dict[str, Parameter] = dict(params)
        self.label = label

    # -- access ---------------------------------------------------------------
    def get(self, name: str) -> Parameter:
        try:
            return self._p[name]
        except KeyError as exc:
            raise KeyError(f"undeclared parameter '{name}'") from exc

    def has(self, name: str) -> bool:
        return name in self._p

    def names(self) -> list[str]:
        return sorted(self._p)

    def value(self, name: str) -> float:
        p = self.get(name)
        if p.value is None or p.status is Status.UNKNOWN and p.value is None:
            raise ParameterUnknownError(
                f"parameter '{name}' ({p.units}) is UNKNOWN: supply a validated value "
                f"(registry.override) or a dataset. {p.note}"
            )
        return float(p.value)

    def is_known(self, name: str) -> bool:
        p = self.get(name)
        return p.value is not None

    # -- modification ---------------------------------------------------------
    def override(self, name: str, value: float, status: Status = Status.USER_SUPPLIED,
                 uncertainty: float | None = None, source: str = "user supplied") -> None:
        p = self.get(name)
        self._p[name] = replace(
            p, value=float(value), status=status, source=source,
            uncertainty=p.uncertainty if uncertainty is None else uncertainty,
        )

    def copy(self, label: str | None = None) -> ParameterRegistry:
        return ParameterRegistry(dict(self._p), label or self.label)

    def sampled(self, rng: np.random.Generator, names: list[str] | None = None,
                scale: float = 1.0) -> ParameterRegistry:
        """Return a registry with parameters drawn from their stated uncertainty.

        Draws are N(value, sigma) (or lognormal for log_scale), truncated to the
        validity range.  Parameters with zero uncertainty or UNKNOWN value are unchanged.
        """
        new = dict(self._p)
        for name in (names if names is not None else list(new)):
            p = new[name]
            if p.value is None or p.uncertainty <= 0.0:
                continue
            for _ in range(20):
                if p.log_scale:
                    v = p.value * math.exp(rng.normal(0.0, p.uncertainty * scale))
                else:
                    v = p.value + rng.normal(0.0, p.uncertainty * scale)
                if (p.valid_min is None or v >= p.valid_min) and (p.valid_max is None or v <= p.valid_max):
                    break
            else:
                v = p.value
            new[name] = replace(p, value=float(v))
        return ParameterRegistry(new, self.label + "+sampled")

    # -- metadata -------------------------------------------------------------
    def version(self) -> str:
        blob = json.dumps(
            {k: [v.value, v.status.value, v.uncertainty] for k, v in sorted(self._p.items())},
            sort_keys=True,
        ).encode()
        return f"AEROLITH-PARAMS-{PARAM_REVISION}+{hashlib.sha256(blob).hexdigest()[:10]}"

    def status_counts(self, names: list[str] | None = None) -> dict[str, int]:
        out: dict[str, int] = {}
        for n in names if names is not None else list(self._p):
            s = self._p[n].status.value
            out[s] = out.get(s, 0) + 1
        return out

    def to_dict(self) -> dict[str, Any]:
        return {k: {**asdict(v), "status": v.status.value} for k, v in sorted(self._p.items())}

    def to_yaml(self, path: str | Path) -> None:
        Path(path).write_text(yaml.safe_dump(self.to_dict(), sort_keys=True))

    @classmethod
    def from_yaml(cls, path: str | Path, base: ParameterRegistry | None = None) -> ParameterRegistry:
        data = yaml.safe_load(Path(path).read_text())
        reg = (base or default_registry()).copy(label=Path(path).stem)
        for name, d in data.items():
            if not reg.has(name):
                raise KeyError(f"unknown parameter in {path}: {name}")
            d = dict(d)
            d["status"] = Status(d["status"])
            reg._p[name] = Parameter(**d)
        return reg


def default_registry() -> ParameterRegistry:
    # importing the model packages populates _DEFAULTS through declare()
    from . import parameters  # noqa: F401

    return ParameterRegistry(_DEFAULTS, label="aerolith-default")
