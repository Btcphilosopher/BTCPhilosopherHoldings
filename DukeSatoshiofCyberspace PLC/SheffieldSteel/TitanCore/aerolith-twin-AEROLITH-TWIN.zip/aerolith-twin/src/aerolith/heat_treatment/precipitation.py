"""Kampmann-Wagner-type multi-phase precipitation kernel (reduced order).

State: number density per radius bin for each phase (nucleation + diffusion-limited growth
+ Gibbs-Thomson coarsening/dissolution), shared solute pools (Li, Cu, Zr, Sc) tied together
by exact mass balance, and a quenched-in vacancy fraction that enhances diffusion.

Equations (per phase p, controlling solute c):
  S_p      = (prod_s x_s^e_ps / K_p(T))^(1/sum e)            geometric-mean supersaturation
  dG_v     = -(R T / Vm) ln S_p ;  r* = 2 gamma / |dG_v| ;  dG* = 16 pi gamma^3 / (3 dG_v^2)
  J        = N_sites Z beta* exp(-dG*/kT)  (homogeneous + heterogeneous on dislocations)
  dr/dt    = (D_eff / r) (x_c - x_c,eq exp(r_GT/r)) / (s_c - x_c,eq exp(r_GT/r))
  D_eff    = D(T) * max(1, C_v / C_v,eq(T))
  x_s      = (c0_s - sum_p f_p s_ps) / (1 - sum_p f_p)       (mass balance)
Particles are transported on the radius grid with a semi-Lagrangian linear-split remap
(unconditionally stable; first-order numerical diffusion ~ dr/2 per nm of growth).
Plate-shaped phases (T1, theta') are represented by equivalent-sphere radii: this is a
documented limitation (no shape evolution).
"""

from __future__ import annotations

import math
from dataclasses import dataclass

import numpy as np
from numba import njit

from ..errors import NumericalInstabilityError
from ..governance import ModelMeta, register
from ..homogenisation.thermal_cycle import ThermalCycle
from ..microstructure.precipitates import DR, NB, R_GRID, PrecipitateField
from ..microstructure.state import MaterialState
from ..params import P, Status, declare
from ..thermodynamics.equilibrium import N_SOL, PHASES, SOLUTE_INDEX
from ..units import AL_BURGERS_M, K_B, N_A, R_GAS

_I = "Placeholder tuned for plausible kinetics; calibrate to TEM/SAXS/hardness data"
declare(
    P("precip.delta_prime.gamma", 0.020, "J/m2", Status.ILLUSTRATIVE, _I, 0.04, 0.005, 0.2, True),
    P("precip.T1.gamma", 0.10, "J/m2", Status.ILLUSTRATIVE, _I, 0.03, 0.01, 0.6, True),
    P("precip.theta_prime.gamma", 0.12, "J/m2", Status.ILLUSTRATIVE, _I, 0.04, 0.01, 0.6, True),
    P("precip.Al3Zr.gamma", 0.10, "J/m2", Status.ILLUSTRATIVE, _I, 0.04, 0.01, 0.6, True),
    P("precip.Al3Sc.gamma", 0.10, "J/m2", Status.ILLUSTRATIVE, _I, 0.04, 0.01, 0.6, True),
    P("precip.delta_prime.nuc_pref", 1.0e-4, "-", Status.ILLUSTRATIVE, "multiplicative factor on classical J (Z, beta* approximations)", 1.0, 1e-8, 1e8, True),
    P("precip.T1.nuc_pref", 1.0e-6, "-", Status.ILLUSTRATIVE, "as above", 1.0, 1e-8, 1e8, True),
    P("precip.theta_prime.nuc_pref", 1.0e-8, "-", Status.ILLUSTRATIVE, "as above", 1.0, 1e-8, 1e8, True),
    P("precip.Al3Zr.nuc_pref", 1.0e-7, "-", Status.ILLUSTRATIVE, "as above", 1.0, 1e-8, 1e8, True),
    P("precip.Al3Sc.nuc_pref", 1.0e-7, "-", Status.ILLUSTRATIVE, "as above", 1.0, 1e-8, 1e8, True),
    P("precip.T1.het_phi", 0.12, "-", Status.ILLUSTRATIVE, "heterogeneous nucleation barrier factor on dislocations", 0.3, 0.01, 1.0, True),
    P("precip.theta_prime.het_phi", 0.25, "-", Status.ILLUSTRATIVE, "heterogeneous nucleation barrier factor on dislocations", 0.3, 0.01, 1.0, True),
    P("precip.het_Ag_gain", 2.0, "1/wt%", Status.ILLUSTRATIVE, "Ag lowers T1 nucleation barrier: phi_eff = phi/(1+gAg wAg+gMg wMg)", 0.4, 0.0, 20.0, True),
    P("precip.het_Mg_gain", 1.0, "1/wt%", Status.ILLUSTRATIVE, "Mg lowers T1 nucleation barrier", 0.4, 0.0, 20.0, True),
    P("precip.het_site_efficiency", 0.05, "-", Status.ILLUSTRATIVE, "fraction of dislocation length that acts as nucleation sites", 0.5, 1e-4, 1.0, True),
    P("precip.vac_Ef", 64600.0, "J/mol", Status.LITERATURE_APPROX, "vacancy formation energy in Al (~0.67 eV)", 3000.0, 4e4, 9e4),
    P("precip.vac_k0", 2.4e5, "1/s", Status.ILLUSTRATIVE, "vacancy sink annealing rate prefactor", 1.0, 1.0, 1e12, True),
    P("precip.vac_Q", 5.35e4, "J/mol", Status.ILLUSTRATIVE, "vacancy sink annealing activation energy", 5000.0, 1e4, 1.5e5),
)

META = register(ModelMeta(
    model_name="kwn_multiphase_precipitation",
    equation="see module docstring (classical nucleation + diffusion-limited growth + Gibbs-Thomson, mass balance, vacancy-enhanced D)",
    parameter_source="registry precip.*, thermo.*, diff.* (ILLUSTRATIVE unless calibrated)",
    validity_range="250-850 K; equivalent-sphere particles 0.2-60 nm; no shape evolution; no solute-trapping; mean-field matrix",
))

_LIMITED_PHASES = len(PHASES)
MAX_STEPS = 1_200_000
LAST_LIMITERS: list[int] = [0, 0, 0, 0, 0]  # diagnostic: steps limited by [geometric, schedule, growth, shrink, nucleation]


@njit(cache=True)
def _interp(t: float, tn: np.ndarray, Tn: np.ndarray) -> float:
    return np.interp(t, tn, Tn)


@njit(cache=True)
def _kernel(t_nodes, T_nodes, r, dr, n_init, c_tot, cv0, ctrl, e_mat, s_mat, lnK0, Qs, D0, Qd, gamma,
            nuc_pref, het_phi, het_sites, Vm, Ef, kann0, Qann, t_out, max_steps, R, kB, NA):
    Pn, B = n_init.shape
    S = c_tot.shape[0]
    n = n_init.copy()
    cv = cv0
    t = 0.0
    t_end = t_nodes[t_nodes.shape[0] - 1]
    M = t_out.shape[0]
    f_out = np.zeros((M, Pn))
    rb_out = np.zeros((M, Pn))
    N_out = np.zeros((M, Pn))
    c_out = np.zeros((M, S))
    T_out = np.zeros(M)
    cv_out = np.zeros(M)
    nxt = 0
    omega = Vm / NA
    a4 = omega ** (4.0 / 3.0)
    four_pi_3 = 4.0 * np.pi / 3.0
    r_min = r[0]
    f = np.zeros(Pn)
    c = np.zeros(S)
    v = np.zeros((Pn, B))
    J = np.zeros(Pn)
    rnuc = np.zeros(Pn)
    favail = np.zeros(Pn)
    jh = np.zeros(Pn)
    step = 0
    cnt = np.zeros(5, np.int64)
    nseg = t_nodes.shape[0] - 1
    while t < t_end - 1e-12 and step < max_steps:
        T = np.interp(t, t_nodes, T_nodes)
        RT = R * T
        ftot = 0.0
        for p in range(Pn):
            s = 0.0
            for b in range(B):
                s += n[p, b] * r[b] ** 3
            f[p] = four_pi_3 * s
            ftot += f[p]
        if ftot > 0.9:
            ftot = 0.9
        for si in range(S):
            acc = c_tot[si]
            for p in range(Pn):
                acc -= f[p] * s_mat[p, si]
            cc = acc / (1.0 - ftot)
            c[si] = cc if cc > 1e-14 else 1e-14
        while nxt < M and t >= t_out[nxt] - 1e-9:
            for p in range(Pn):
                f_out[nxt, p] = f[p]
                Nn = 0.0
                rs = 0.0
                for b in range(B):
                    Nn += n[p, b]
                    rs += n[p, b] * r[b]
                N_out[nxt, p] = Nn
                rb_out[nxt, p] = rs / Nn if Nn > 0 else 0.0
            for si in range(S):
                c_out[nxt, si] = c[si]
            T_out[nxt] = T
            cv_out[nxt] = cv
            nxt += 1
        cv_eq = np.exp(-Ef / RT)
        enh = cv / cv_eq
        if enh < 1.0:
            enh = 1.0
        # time-step limits from the temperature schedule
        j = int(np.searchsorted(t_nodes, t, side="right")) - 1
        if j < 0:
            j = 0
        if j > nseg - 1:
            j = nseg - 1
        dt = t_nodes[j + 1] - t
        if dt <= 1e-12:
            dt = t_end - t
        slope = abs(T_nodes[j + 1] - T_nodes[j]) / max(t_nodes[j + 1] - t_nodes[j], 1e-12)
        if slope > 0.0:
            dt = min(dt, 4.0 / slope)
        reason = 1
        if 0.05 * t + 1e-3 < dt:
            dt = 0.05 * t + 1e-3
            reason = 0
        if dt < 1e-9:
            dt = 1e-9
        for p in range(Pn):
            J[p] = 0.0
            jh[p] = 0.0
            favail[p] = 0.0
            rnuc[p] = 0.0
            for b in range(B):
                v[p, b] = 0.0
            K = np.exp(lnK0[p] - Qs[p] / RT)
            prod = 1.0
            sum_e = 0.0
            for si in range(S):
                if e_mat[p, si] > 0.0:
                    prod *= c[si] ** e_mat[p, si]
                    sum_e += e_mat[p, si]
            if sum_e <= 0.0:
                continue
            ic = ctrl[p]
            others = 1.0
            for si in range(S):
                if si != ic and e_mat[p, si] > 0.0:
                    others *= c[si] ** e_mat[p, si]
            x_eq = (K / others) ** (1.0 / e_mat[p, ic])
            Seff = (prod / K) ** (1.0 / sum_e)
            D = D0[p] * np.exp(-Qd[p] / RT) * enh
            rgt = 2.0 * gamma[p] * Vm / RT
            sc = s_mat[p, ic]
            dfdt = 0.0
            for b in range(B):
                if n[p, b] <= 0.0:
                    continue
                ex = rgt / r[b]
                if ex > 20.0:
                    ex = 20.0
                xr = x_eq * np.exp(ex)
                if xr > 0.95 * sc:
                    xr = 0.95 * sc
                vb = D / r[b] * (c[ic] - xr) / (sc - xr)
                v[p, b] = vb
                dfdt += n[p, b] * 4.0 * np.pi * r[b] * r[b] * vb
                if vb > 0.0:
                    lim = 1.5 * dr / vb
                    if lim < dt:
                        dt = lim
                        reason = 2
            # shrinking particles never cross the critical radius (v is monotonic in r), so only the
            # coupling through the solute mass balance limits the step
            if dfdt != 0.0:
                lim = 0.15 * max(f[p], 1e-5) / abs(dfdt)
                if lim < dt:
                    dt = lim
                    reason = 3
            if Seff > 1.0:
                dGv = RT / Vm * np.log(Seff)
                rs = 2.0 * gamma[p] / dGv
                rs_eff = max(rs, 0.4e-9)
                dGs = 16.0 * np.pi * gamma[p] ** 3 / (3.0 * dGv * dGv)
                beta = 4.0 * np.pi * rs_eff * rs_eff * D * c[ic] / a4
                Z = omega / (2.0 * np.pi * rs_eff * rs_eff) * np.sqrt(gamma[p] / (kB * T))
                arg = dGs / (kB * T)
                jhom = 0.0
                if arg < 600.0:
                    jhom = (1.0 / omega) * Z * beta * np.exp(-arg) * nuc_pref[p]
                jhet = 0.0
                if het_sites[p] > 0.0:
                    argh = het_phi[p] * dGs / (kB * T)
                    if argh < 600.0:
                        jhet = het_sites[p] * Z * beta * np.exp(-argh) * nuc_pref[p]
                J[p] = jhom + jhet
                jh[p] = jhet
                rnuc[p] = max(1.05 * rs_eff, r_min)
                favail[p] = max(0.0, (c[ic] - x_eq) / (sc - x_eq)) * (1.0 - ftot)
                if J[p] > 0.0 and rnuc[p] < r[B - 1]:
                    vn = four_pi_3 * rnuc[p] ** 3
                    lim = 0.1 * favail[p] / (J[p] * vn) if favail[p] > 0 else dt
                    if lim < dt:
                        dt = lim
                        reason = 4
        if dt < 1e-9:
            dt = 1e-9
        cnt[reason] += 1
        if t + dt > t_end:
            dt = t_end - t
        # apply transport (semi-Lagrangian linear split) and nucleation
        for p in range(Pn):
            new = np.zeros(B)
            for b in range(B):
                nb = n[p, b]
                if nb <= 0.0:
                    continue
                rn = r[b] + v[p, b] * dt
                u = (rn - r[0]) / dr
                if u < -0.5:
                    continue
                if u < 0.0:
                    u = 0.0
                i0 = int(np.floor(u))
                w = u - i0
                if i0 >= B - 1:
                    new[B - 1] += nb
                else:
                    new[i0] += nb * (1.0 - w)
                    new[i0 + 1] += nb * w
            if J[p] > 0.0 and rnuc[p] < r[B - 1]:
                vn = four_pi_3 * rnuc[p] ** 3
                dN = J[p] * dt
                cap = 0.3 * favail[p] / vn if vn > 0 else 0.0
                if dN > cap:
                    dN = cap
                if het_sites[p] > 0.0 and jh[p] > 0.0:
                    tot = 0.0
                    for b in range(B):
                        tot += new[b]
                    room = 0.5 * (het_sites[p] - tot)
                    hetN = jh[p] * dt
                    if hetN > room:
                        dN = dN - (hetN - max(room, 0.0))
                        if dN < 0.0:
                            dN = 0.0
                ib = int((rnuc[p] - r[0]) / dr + 0.5)
                if ib < 0:
                    ib = 0
                if ib > B - 1:
                    ib = B - 1
                new[ib] += dN
            for b in range(B):
                n[p, b] = new[b] if new[b] > 1e-3 else 0.0
        # vacancy annihilation at sinks
        kann = kann0 * np.exp(-Qann / RT)
        cv = cv_eq + (cv - cv_eq) * np.exp(-kann * dt)
        t += dt
        step += 1
    # final record
    T = np.interp(t_end, t_nodes, T_nodes)
    ftot = 0.0
    for p in range(Pn):
        s = 0.0
        for b in range(B):
            s += n[p, b] * r[b] ** 3
        f[p] = four_pi_3 * s
        ftot += f[p]
    for si in range(S):
        acc = c_tot[si]
        for p in range(Pn):
            acc -= f[p] * s_mat[p, si]
        c[si] = max(acc / (1.0 - ftot), 1e-14)
    while nxt < M:
        for p in range(Pn):
            f_out[nxt, p] = f[p]
            Nn = 0.0
            rs = 0.0
            for b in range(B):
                Nn += n[p, b]
                rs += n[p, b] * r[b]
            N_out[nxt, p] = Nn
            rb_out[nxt, p] = rs / Nn if Nn > 0 else 0.0
        for si in range(S):
            c_out[nxt, si] = c[si]
        T_out[nxt] = T
        cv_out[nxt] = cv
        nxt += 1
    return n, cv, f_out, rb_out, N_out, c_out, T_out, cv_out, step, cnt


@dataclass
class PrecipitationResult:
    t_s: np.ndarray
    T_K: np.ndarray
    volume_fraction: dict[str, np.ndarray]
    mean_radius_m: dict[str, np.ndarray]
    number_density_m3: dict[str, np.ndarray]
    matrix_atom_fraction: dict[str, np.ndarray]
    vacancy_fraction: np.ndarray
    steps: int


def solute_pool_to_array(pool: dict[str, float]) -> np.ndarray:
    a = np.zeros(N_SOL)
    for k, i in SOLUTE_INDEX.items():
        a[i] = pool.get(k, 0.0)
    return a


def run_precipitation(ctx, state: MaterialState, cycle: ThermalCycle, n_out: int = 80,  # type: ignore[no-untyped-def]
                      het_boost: float = 1.0) -> PrecipitationResult:
    """Advance ``state.precip`` and ``state.vacancy_cv`` through a thermal cycle."""
    ctx.use(META.model_name)
    Pn = len(PHASES)
    ctrl = np.array([SOLUTE_INDEX[p.ctrl] for p in PHASES], dtype=np.int64)
    e_mat = np.array([p.e for p in PHASES], float)
    s_mat = np.array([p.s for p in PHASES], float)
    lnK0 = np.array([math.log(ctx.p(f"thermo.{p.key}.K0")) for p in PHASES])
    Qs = np.array([ctx.p(f"thermo.{p.key}.Q") for p in PHASES])
    D0 = np.array([ctx.p(f"diff.{p.ctrl}.D0") for p in PHASES])
    Qd = np.array([ctx.p(f"diff.{p.ctrl}.Q") for p in PHASES])
    gamma = np.array([ctx.p(f"precip.{p.key}.gamma") for p in PHASES])
    nuc = np.array([ctx.p(f"precip.{p.key}.nuc_pref") for p in PHASES])
    wt = state.composition.wt()
    gain = 1.0 + ctx.p("precip.het_Ag_gain") * wt["Ag"] + ctx.p("precip.het_Mg_gain") * wt["Mg"]
    het_phi = np.zeros(Pn)
    het_sites = np.zeros(Pn)
    site_density = state.dislocation_density / AL_BURGERS_M * ctx.p("precip.het_site_efficiency") * het_boost
    for i, p in enumerate(PHASES):
        if ctx.registry.has(f"precip.{p.key}.het_phi"):
            het_phi[i] = min(1.0, ctx.p(f"precip.{p.key}.het_phi") / (gain if p.key == "T1" else 1.0))
            het_sites[i] = site_density
    n0 = np.vstack([state.precip.n[p.key] for p in PHASES])
    c_tot = solute_pool_to_array(state.solute_pool_at)
    t_nodes = cycle.t_s - cycle.t_s[0]
    T_nodes = cycle.T_K
    t_out = np.linspace(0.0, t_nodes[-1], n_out)
    cv0 = state.vacancy_cv if state.vacancy_cv > 0 else math.exp(-ctx.p("precip.vac_Ef") / (R_GAS * T_nodes[0]))
    Vm = ctx.p("thermo.molar_volume")
    n_f, cv_f, f_o, rb_o, N_o, c_o, T_o, cv_o, steps, cnt = _kernel(
        t_nodes, T_nodes, R_GRID, DR, n0, c_tot, cv0, ctrl, e_mat, s_mat, lnK0, Qs, D0, Qd, gamma, nuc, het_phi,
        het_sites, Vm, ctx.p("precip.vac_Ef"), ctx.p("precip.vac_k0"), ctx.p("precip.vac_Q"), t_out, MAX_STEPS,
        R_GAS, K_B, N_A,
    )
    for i, p in enumerate(PHASES):
        state.precip.n[p.key] = n_f[i].copy()
    if int(steps) >= MAX_STEPS:
        raise NumericalInstabilityError(f"precipitation kernel exceeded {MAX_STEPS} steps (stiff growth/dissolution); refusing to continue silently")
    state.vacancy_cv = float(cv_f)
    LAST_LIMITERS[:] = [int(x) for x in cnt]
    keys = [p.key for p in PHASES]
    inv = {v: k for k, v in SOLUTE_INDEX.items()}
    return PrecipitationResult(
        t_out, T_o,
        {k: f_o[:, i] for i, k in enumerate(keys)}, {k: rb_o[:, i] for i, k in enumerate(keys)},
        {k: N_o[:, i] for i, k in enumerate(keys)}, {inv[i]: c_o[:, i] for i in range(N_SOL)}, cv_o, int(steps),
    )


def vacancy_equilibrium(ctx, T: float) -> float:  # type: ignore[no-untyped-def]
    return math.exp(-ctx.p("precip.vac_Ef") / (R_GAS * T))


def new_field() -> PrecipitateField:
    return PrecipitateField()


_ = NB
