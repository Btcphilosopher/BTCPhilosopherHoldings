"""Natural and artificial ageing, with under-/peak-/over-age classification (no hard-coded optimum)."""

from __future__ import annotations

import math
from dataclasses import dataclass, field

import numpy as np

from ..governance import ModelMeta, register
from ..homogenisation.thermal_cycle import ThermalCycle
from ..microstructure.state import MaterialState
from ..params import P, Status, declare
from ..properties.strength import precipitation_strengthening_from_means
from ..thermodynamics.equilibrium import PHASE_KEYS
from .precipitation import PrecipitationResult, run_precipitation

declare(
    P("age.overage_gb", 0.25, "-", Status.ILLUSTRATIVE, "grain-boundary precipitate coverage gained per unit of over-ageing (t/t_peak - 1)", 0.4, 0.0, 2.0),
    P("age.peak_tol", 0.03, "-", Status.REFERENCE, "strength within this fraction of the sweep maximum is classed 'peak-aged'", 0.0),
)
META = register(ModelMeta(
    model_name="ageing_precipitation_state",
    equation="KWN precipitation along the ageing thermal cycle; regime from the precipitation-strengthening trajectory",
    parameter_source="registry precip.*, thermo.*, diff.* and age.*",
    validity_range="natural ageing 273-320 K (vacancy-assisted); artificial ageing 400-520 K; isothermal holds with linear heat-up",
))


@dataclass
class AgeingTreatment:
    temperature_K: float
    time_s: float
    heating_rate_K_s: float = 0.05
    start_temperature_K: float = 293.0
    kind: str = "artificial"  # natural | artificial

    def validate(self) -> None:
        lim = (250.0, 330.0) if self.kind == "natural" else (380.0, 560.0)
        if not lim[0] <= self.temperature_K <= lim[1]:
            raise ValueError(f"{self.kind} ageing temperature {self.temperature_K} K outside {lim} K (kelvin required)")
        if self.time_s <= 0:
            raise ValueError("ageing time must be positive")

    def cycle(self) -> ThermalCycle:
        if self.kind == "natural":
            return ThermalCycle(np.array([0.0, self.time_s]), np.array([self.temperature_K, self.temperature_K]), "natural-ageing")
        return ThermalCycle.ramp_hold_cool(self.start_temperature_K, self.temperature_K, self.heating_rate_K_s, self.time_s,
                                           T_end=self.start_temperature_K, cool_rate_K_s=0.1, label="artificial-ageing")


@dataclass
class AgeingResult:
    precipitation: PrecipitationResult
    strengthening_mpa: np.ndarray
    t_s: np.ndarray
    regime: str
    t_peak_s: float
    peak_mpa: float
    final_mpa: float
    final_state: dict[str, dict[str, float]] = field(default_factory=dict)


def classify_regime(t: np.ndarray, s: np.ndarray, tol: float) -> tuple[str, float, float]:
    """UNDER / PEAK / OVER-AGED from the strengthening trajectory of this very run (no universal optimum)."""
    ipk = int(np.argmax(s))
    peak = float(s[ipk])
    final = float(s[-1])
    if peak <= 0.0:
        return "UNAGED", float(t[-1]), peak
    if final >= (1.0 - tol) * peak:
        k = max(1, len(s) // 12)
        still_rising = (s[-1] - s[-1 - k]) / peak > 0.02
        return ("UNDER-AGED" if still_rising else "PEAK-AGED"), float(t[ipk]), peak
    return "OVER-AGED", float(t[ipk]), peak


def strengthening_trajectory(ctx, res: PrecipitationResult) -> np.ndarray:  # type: ignore[no-untyped-def]
    n = res.t_s.size
    out = np.zeros(n)
    for i in range(n):
        out[i] = precipitation_strengthening_from_means(
            ctx, {k: float(res.volume_fraction[k][i]) for k in PHASE_KEYS}, {k: float(res.mean_radius_m[k][i]) for k in PHASE_KEYS})
    return out


def age(ctx, state: MaterialState, cond: AgeingTreatment, n_out: int = 160) -> AgeingResult:  # type: ignore[no-untyped-def]
    ctx.use(META.model_name)
    cond.validate()
    cyc = cond.cycle()
    res = run_precipitation(ctx, state, cyc, n_out=n_out)
    s = strengthening_trajectory(ctx, res)
    # the regime is judged at the end of the hold (heat-up included, cool-down excluded)
    t_hold_end = float(cyc.t_s[2]) if cond.kind == "artificial" and cyc.t_s.size > 2 else float(cyc.t_s[-1])
    m = res.t_s <= t_hold_end + 1.0
    regime, tpk, peak = classify_regime(res.t_s[m], s[m], ctx.p("age.peak_tol"))
    if cond.kind == "artificial" and regime == "OVER-AGED":
        over = max(0.0, res.t_s[-1] / max(tpk, 1.0) - 1.0)
        state.gb_precipitate_coverage = float(min(1.0, state.gb_precipitate_coverage + ctx.p("age.overage_gb") * over))
    if cond.kind == "natural":
        state.time_since_quench_s += cond.time_s
        state.temper = "T3-like (naturally aged)"
    else:
        state.temper = f"artificially aged ({regime.lower()})"
    state.stage = "aged"
    state.log("ageing", kind=cond.kind, T_K=cond.temperature_K, time_s=cond.time_s, regime=regime, peak_mpa=peak)
    return AgeingResult(res, s, res.t_s, regime, tpk, peak, float(s[-1]), state.precip.summary())


def ageing_curve(ctx, state: MaterialState, T_K: float, times_s: np.ndarray) -> dict[str, np.ndarray]:  # type: ignore[no-untyped-def]
    """Precipitation-strengthening versus ageing time for an isothermal hold (state is not modified)."""
    st = state.copy()
    t_end = float(np.max(times_s))
    cyc = ThermalCycle(np.array([0.0, t_end]), np.array([T_K, T_K]))
    res = run_precipitation(ctx, st, cyc, n_out=max(len(times_s), 60))
    s = strengthening_trajectory(ctx, res)
    return {"t_s": res.t_s, "strengthening_mpa": s, **{f"f_{k}": res.volume_fraction[k] for k in PHASE_KEYS},
            **{f"r_{k}": res.mean_radius_m[k] for k in PHASE_KEYS}}


_ = math
