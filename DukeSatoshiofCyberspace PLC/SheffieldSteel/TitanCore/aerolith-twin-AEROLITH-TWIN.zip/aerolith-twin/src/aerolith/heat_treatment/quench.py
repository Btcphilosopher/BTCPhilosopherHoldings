"""Quench: transient conduction, quench-factor precipitation loss, elastoplastic residual stress, distortion risk."""

from __future__ import annotations

import math
from dataclasses import dataclass, field

import numpy as np

from ..casting.cooling import CoolingHistory
from ..governance import ModelMeta, register
from ..microstructure.state import MaterialState, ResidualStressState
from ..numerics import slab_conduction_implicit
from ..params import P, Status, declare
from ..processing import recrystallisation as rx
from ..units import R_GAS

MEDIA = ("cold_water", "hot_water", "polymer_glycol", "forced_air", "still_air")
_H = {  # (h_conv, h_peak, h_film, dT_peak) W/m2/K, K  (ILLUSTRATIVE boiling-curve shapes)
    "cold_water": (1000.0, 14000.0, 4000.0, 150.0),
    "hot_water": (800.0, 8000.0, 2500.0, 120.0),
    "polymer_glycol": (600.0, 4500.0, 1800.0, 130.0),
    "forced_air": (70.0, 90.0, 100.0, 100.0),
    "still_air": (15.0, 25.0, 35.0, 100.0),
}
for _m, (_c, _pk, _f, _dt) in _H.items():
    declare(
        P(f"quench.h_conv.{_m}", _c, "W/m2/K", Status.ILLUSTRATIVE, "illustrative boiling-curve point; measure for your quench tank", 0.25, 5.0, 5e4, True),
        P(f"quench.h_peak.{_m}", _pk, "W/m2/K", Status.ILLUSTRATIVE, "illustrative boiling-curve point", 0.25, 5.0, 1e5, True),
        P(f"quench.h_film.{_m}", _f, "W/m2/K", Status.ILLUSTRATIVE, "illustrative boiling-curve point", 0.25, 5.0, 5e4, True),
        P(f"quench.dT_peak.{_m}", _dt, "K", Status.ILLUSTRATIVE, "surface-medium temperature difference at peak heat flux", 30.0, 30.0, 400.0),
    )
declare(
    P("quench.T_medium_water", 293.0, "K", Status.REFERENCE, "nominal cold-water temperature (user input overrides)", 0.0),
    P("quench.E", 7.0e10, "Pa", Status.LITERATURE_APPROX, "Young's modulus for quench-stress calculation", 2e9, 5e10, 8e10),
    P("quench.nu", 0.33, "-", Status.LITERATURE_APPROX, "Poisson ratio", 0.01, 0.25, 0.4),
    P("quench.sy_hot", 3.0e7, "Pa", Status.ILLUSTRATIVE, "yield stress of the solutionised alloy at the solution temperature", 0.3, 1e6, 2e8, True),
    P("quench.sy_cold", 1.4e8, "Pa", Status.ILLUSTRATIVE, "yield stress of the as-quenched (W) alloy at room temperature", 0.15, 3e7, 5e8, True),
    P("quench.alpha", 2.35e-5, "1/K", Status.LITERATURE_APPROX, "CTE during quench", 1.5e-6, 1e-5, 4e-5),
    P("quench.relief_eps", 0.01, "-", Status.ILLUSTRATIVE, "stretch strain scale for residual-stress relief: 1-exp(-eps/eps_s)", 0.4, 1e-3, 0.1, True),
    # quench-factor analysis (Evancho-Staley form); constants are ILLUSTRATIVE for an Al-Li-Cu alloy
    P("qfa.k1", math.log(0.995), "-", Status.REFERENCE, "ln(fraction of max transformation tolerated) by convention", 0.0),
    P("qfa.k2", 8.01e-06, "s", Status.ILLUSTRATIVE, "reciprocal of the constant associated with the nucleation sites", 1.0, 1e-30, 1e-5, True),
    P("qfa.k3", 650.0, "J/mol", Status.ILLUSTRATIVE, "constant related to the energy required to form a nucleus", 1500.0, 500, 5e4),
    P("qfa.k4", 790.0, "K", Status.ILLUSTRATIVE, "solvus temperature of the quench-sensitive phase", 20.0, 600, 900),
    P("qfa.k5", 8.3e4, "J/mol", Status.ILLUSTRATIVE, "activation energy for diffusion", 1.0e4, 5e4, 3e5),
    P("qfa.loss_to_gb", 0.6, "-", Status.ILLUSTRATIVE, "share of quench-lost solute that decorates grain boundaries (vs matrix coarse phases)", 0.3, 0.0, 1.0),
    P("qfa.cooling_window_hi", 673.0, "K", Status.REFERENCE, "upper bound of the critical cooling-rate window used for reporting", 0.0),
    P("qfa.cooling_window_lo", 523.0, "K", Status.REFERENCE, "lower bound of the critical cooling-rate window used for reporting", 0.0),
    P("quench.stretch_hardening_cap", 3.0e14, "1/m2", Status.ILLUSTRATIVE, "dislocation-density ceiling for cold stretch at room temperature", 0.5, 1e13, 1e16, True),
)

META = register(ModelMeta(
    model_name="plate_quench_conduction_elastoplastic",
    equation="rho cp dT/dt = d/dx(k dT/dx); -k dT/dx|s = h(Ts-Tm)(Ts-Tm); QFA: Q=int dt/Ct(T), retained = exp(k1 Q); equibiaxial elastic-perfectly-plastic stress with force balance",
    parameter_source="registry quench.*, qfa.* (ILLUSTRATIVE); media boiling-curve shapes are illustrative",
    validity_range="symmetric flat plate quenched from both faces; no part distortion feedback; no phase-transformation strain; h depends on surface temperature only",
))


def surface_h(ctx, medium: str, dT: float) -> float:  # type: ignore[no-untyped-def]
    hc, hp, hf, dtp = (ctx.p(f"quench.{k}.{medium}") for k in ("h_conv", "h_peak", "h_film", "dT_peak"))
    return float(np.interp(dT, [0.0, dtp, 3.0 * dtp, 1.0e4], [hc, hp, hf, hf]))


def quench_time_constant_ct(ctx, T: np.ndarray) -> np.ndarray:  # type: ignore[no-untyped-def]
    """Critical time C_t(T) (s) of the Evancho-Staley C-curve."""
    k1, k2, k3, k4, k5 = (ctx.p(f"qfa.k{i}") for i in range(1, 6))
    T = np.asarray(T, float)
    out = np.full_like(T, np.inf)
    ok = (T < k4 - 1.0) & (T > 250.0)
    Tk = T[ok]
    expo = k3 * k4**2 / (R_GAS * Tk * (k4 - Tk) ** 2) + k5 / (R_GAS * Tk)
    out[ok] = -k1 * k2 * np.exp(np.minimum(expo, 700.0))
    return out


def quench_factor(ctx, t: np.ndarray, T: np.ndarray) -> float:  # type: ignore[no-untyped-def]
    ct = quench_time_constant_ct(ctx, T)
    integrand = np.where(np.isfinite(ct), 1.0 / ct, 0.0)
    return float(np.trapezoid(integrand, t))


@dataclass
class QuenchInputs:
    initial_temperature_K: float
    medium: str
    component_thickness_m: float
    medium_temperature_K: float = 293.0
    h_scale: float = 1.0  # multiplies the medium's boiling curve (surface heat transfer variation)
    asymmetry: float = 1.0  # ratio of heat-transfer coefficients on the two faces (1 = symmetric)
    transfer_delay_s: float = 10.0  # time in air between furnace and quench tank
    stretch_after_quench: float = 0.0

    def validate(self) -> None:
        if self.medium not in MEDIA:
            raise ValueError(f"quench medium must be one of {MEDIA}")
        if self.initial_temperature_K < 500:
            raise ValueError("initial quench temperature must be in kelvin (>= 500 K)")
        if not 0.002 <= self.component_thickness_m <= 0.5:
            raise ValueError("component thickness outside 2 mm - 0.5 m")


@dataclass
class QuenchResult:
    t_s: np.ndarray
    x_m: np.ndarray
    T_xt_K: np.ndarray  # (nt, nx)
    history: CoolingHistory
    cooling_rate_window_centre_K_s: float
    cooling_rate_window_surface_K_s: float
    max_gradient_K_m: float
    max_core_surface_dT_K: float
    quench_factor_centre: float
    quench_factor_surface: float
    quench_factor_mean: float
    residual: ResidualStressState
    notes: list[str] = field(default_factory=list)


def _window_rate(t: np.ndarray, T: np.ndarray, hi: float, lo: float) -> float:
    if T.min() > hi:
        return 0.0
    i_hi = int(np.argmax(T <= hi))
    below = np.nonzero(T <= lo)[0]
    if below.size == 0:
        return float((hi - T[-1]) / max(t[-1] - t[i_hi], 1e-9))
    i_lo = int(below[0])
    return float((hi - lo) / max(t[i_lo] - t[i_hi], 1e-9))


def _elastoplastic_stress(ctx, T_xt: np.ndarray, w: np.ndarray, T_sol: float, T_med: float) -> tuple[np.ndarray, np.ndarray]:  # type: ignore[no-untyped-def]
    E, nu, alpha = ctx.p("quench.E"), ctx.p("quench.nu"), ctx.p("quench.alpha")
    Eb = E / (1.0 - nu)
    sy_hot, sy_cold = ctx.p("quench.sy_hot"), ctx.p("quench.sy_cold")
    n = T_xt.shape[1]
    eps_p = np.zeros(n)
    T0 = T_xt[0].copy()
    sigma = np.zeros(n)
    for k in range(1, T_xt.shape[0]):
        theta = T_xt[k] - T0
        sy = np.interp(T_xt[k], [T_med, T_sol], [sy_cold, sy_hot])
        plastic = np.zeros(n, bool)
        sig_pl = np.zeros(n)
        eps = 0.0
        for _ in range(12):
            el = ~plastic
            denom = float(np.sum(w[el])) * Eb
            if denom <= 0:
                break
            num = float(np.sum(w[el] * Eb * (alpha * theta[el] + eps_p[el])) - np.sum(w[plastic] * sig_pl[plastic]))
            eps = num / denom
            s = Eb * (eps - alpha * theta - eps_p)
            new_plastic = np.abs(s) > sy
            sig_pl = np.where(new_plastic, np.sign(s) * sy, 0.0)
            if np.array_equal(new_plastic, plastic):
                break
            plastic = new_plastic
        sigma = np.where(plastic, sig_pl, Eb * (eps - alpha * theta - eps_p))
        eps_p = np.where(plastic, eps - alpha * theta - sigma / Eb, eps_p)
    return sigma, eps_p


def quench_plate(ctx, state: MaterialState, q: QuenchInputs, n_nodes: int = 41) -> QuenchResult:  # type: ignore[no-untyped-def]
    ctx.use(META.model_name)
    q.validate()
    k, cp, rho = ctx.p("cast.k_solid"), ctx.p("def.cp"), ctx.p("roll.rho")
    alpha_th = k / (rho * cp)
    half = 0.5 * q.component_thickness_m
    dx = half / (n_nodes - 1)
    x = np.linspace(0.0, half, n_nodes)
    T = np.full(n_nodes, q.initial_temperature_K)
    t = 0.0
    ts, Ts = [0.0], [T.copy()]
    # transfer delay: slow air cooling before immersion
    if q.transfer_delay_s > 0:
        hair = surface_h(ctx, "still_air", 300.0)
        tt = 0.0
        while tt < q.transfer_delay_s - 1e-12:
            dt = min(0.5, q.transfer_delay_s - tt)
            T = slab_conduction_implicit(T, dx, dt, alpha_th, hair, 293.0, k)
            tt += dt
            t += dt
            ts.append(t)
            Ts.append(T.copy())
    t_hist_start = t
    h_scale_surface = q.h_scale
    t_max = 4 * 3600.0
    step = 0
    while T[-1] > q.medium_temperature_K + 8.0 and t - t_hist_start < t_max:
        dt = min(max(0.002 * (t - t_hist_start) + 0.02, 0.02), 2.0 if q.medium in ("cold_water", "hot_water", "polymer_glycol") else 20.0)
        h = surface_h(ctx, q.medium, T[0] - q.medium_temperature_K) * h_scale_surface
        h_eff = h * (1.0 if q.asymmetry == 1.0 else 2.0 * q.asymmetry / (1.0 + q.asymmetry))
        T = slab_conduction_implicit(T, dx, dt, alpha_th, h_eff, q.medium_temperature_K, k)
        t += dt
        step += 1
        if step % 2 == 0 or T[-1] < q.medium_temperature_K + 20:
            ts.append(t)
            Ts.append(T.copy())
    ts_a = np.array(ts)
    T_xt = np.array(Ts)
    # energy bookkeeping check (heat removed vs enthalpy change is exact for the implicit scheme only in the limit; report instead the monotonic cooling)
    w = np.full(n_nodes, dx)
    w[0] = w[-1] = 0.5 * dx
    T_mean = (T_xt * w).sum(axis=1) / w.sum()
    after = ts_a >= t_hist_start
    hi, lo = ctx.p("qfa.cooling_window_hi"), ctx.p("qfa.cooling_window_lo")
    rate_c = _window_rate(ts_a[after], T_xt[after, -1], hi, lo)
    rate_s = _window_rate(ts_a[after], T_xt[after, 0], hi, lo)
    grad = np.abs(np.gradient(T_xt, dx, axis=1)).max(axis=1)
    dT_core_surf = T_xt[:, -1] - T_xt[:, 0]
    Qc = quench_factor(ctx, ts_a, T_xt[:, -1])
    Qs = quench_factor(ctx, ts_a, T_xt[:, 0])
    Qm = quench_factor(ctx, ts_a, T_mean)
    sigma, eps_p = _elastoplastic_stress(ctx, T_xt, w, q.initial_temperature_K, q.medium_temperature_K)
    relief = 1.0 - math.exp(-q.stretch_after_quench / ctx.p("quench.relief_eps")) if q.stretch_after_quench > 0 else 0.0
    sigma_final = sigma * (1.0 - relief)
    sy_c = ctx.p("quench.sy_cold")
    idx = float(np.max(np.abs(sigma_final)) / sy_c) * (1.0 + 3.0 * abs(math.log(q.asymmetry))) * (state.dims_m[0] / max(state.dims_m[2], 1e-3)) ** 0.1
    distortion = float(1.0 - math.exp(-idx))
    res = ResidualStressState(x_m=x, sigma_pa=sigma_final, surface_pa=float(sigma_final[0]), core_pa=float(sigma_final[-1]),
                              max_abs_pa=float(np.max(np.abs(sigma_final))), plastic_strain_max=float(np.max(np.abs(eps_p))),
                              distortion_risk=distortion, stress_relief_fraction=relief)
    # --- microstructural consequences ----------------------------------------------------------------------
    retained = math.exp(ctx.p("qfa.k1") * Qm)
    lost = 1.0 - retained
    state.quench_factor_mean, state.quench_factor_centre = Qm, Qc
    state.quench_loss_fraction = lost
    state.gb_precipitate_coverage = float(min(1.0, ctx.p("qfa.loss_to_gb") * lost * 20.0))
    for el in ("Cu", "Li"):
        if el in state.solute_pool_at:
            state.solute_pool_at[el] *= retained
    # vacancy supersaturation: integrate annealing along the actual quench path via the precipitation kernel
    from ..homogenisation.thermal_cycle import ThermalCycle
    from .precipitation import run_precipitation, vacancy_equilibrium

    state.vacancy_cv = vacancy_equilibrium(ctx, q.initial_temperature_K)
    tq = ts_a[after] - t_hist_start
    cyc = ThermalCycle(tq + 1e-6 * np.arange(tq.size), T_mean[after], "quench-mean")
    run_precipitation(ctx, state, cyc, n_out=10)
    state.time_since_quench_s = 0.0
    state.residual_stress = res
    state.stage = "quenched"
    state.temper = "W"
    notes = []
    if rate_c < 1.0:
        notes.append("critical-window cooling rate at mid-thickness < 1 K/s: significant quench sensitivity expected")
    state.log("quench", medium=q.medium, thickness_m=q.component_thickness_m, quench_factor=Qm, quench_factor_centre=Qc,
              cooling_rate_window_centre=rate_c, sigma_max_pa=res.max_abs_pa, distortion_risk=distortion)
    if q.stretch_after_quench > 0:
        apply_stretch(ctx, state, q.stretch_after_quench, relief)
    return QuenchResult(ts_a - t_hist_start, x, T_xt, CoolingHistory(ts_a, T_xt[:, 0], T_xt[:, -1]), rate_c, rate_s,
                        float(grad.max()), float(dT_core_surf.min() if abs(dT_core_surf.min()) > dT_core_surf.max() else dT_core_surf.max()),
                        Qc, Qs, Qm, res, notes)


def apply_stretch(ctx, state: MaterialState, strain: float, relief: float | None = None) -> None:  # type: ignore[no-untyped-def]
    """Controlled cold stretch after quench: adds dislocations (nucleation sites for T1) and relieves residual stress."""
    rho = rx.kocks_mecking_density(ctx, state.dislocation_density, strain * 1.0, 300.0)
    state.dislocation_density = min(rho, ctx.p("quench.stretch_hardening_cap"))
    state.stretch_strain += strain
    if relief is not None and state.residual_stress is not None:
        state.residual_stress.stress_relief_fraction = relief
    state.temper = "W51"
    state.log("stretch", strain=strain, rho=state.dislocation_density)
