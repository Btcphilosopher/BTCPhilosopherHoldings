"""Solution heat treatment: dissolution, grain stability, recrystallisation."""

from __future__ import annotations

import math
from dataclasses import dataclass

import numpy as np

from ..governance import ModelMeta, register
from ..homogenisation.precipitation_dissolution import (
    apply_homogenisation,
    burning_limit_K,
    dispersoid_free_fraction,
)
from ..homogenisation.thermal_cycle import ThermalCycle
from ..microstructure.dispersoids import zener_limit_grain_size, zener_pressure
from ..microstructure.state import MaterialState
from ..params import P, Status, declare
from ..processing import recrystallisation as rx
from ..thermodynamics.equilibrium import SOLUTE_INDEX, solvus_temperature
from .precipitation import run_precipitation

declare(P("sol.T_ref_dummy", 0.0, "-", Status.REFERENCE, "unused placeholder to keep module parameter block non-empty", 0.0))
META = register(ModelMeta(
    model_name="solution_treatment",
    equation="constituent dissolution (stationary interface) + KWN dissolution of nano-precipitates + Zener-limited JMAK recrystallisation",
    parameter_source="inherits from the underlying models",
    validity_range="isothermal hold 700-850 K after a linear ramp; part temperature equals furnace set-point (see furnace model for lag)",
))


@dataclass
class SolutionTreatment:
    solution_temperature_K: float
    hold_time_s: float
    heating_rate_K_s: float = 0.05
    start_temperature_K: float = 293.0

    def validate(self) -> None:
        if not 600 < self.solution_temperature_K < 900:
            raise ValueError("solution temperature must be in kelvin (600-900 K)")
        if self.hold_time_s <= 0 or self.heating_rate_K_s <= 0:
            raise ValueError("hold time and heating rate must be positive")

    def cycle(self) -> ThermalCycle:
        return ThermalCycle.ramp_hold_cool(self.start_temperature_K, self.solution_temperature_K, self.heating_rate_K_s,
                                           self.hold_time_s, label="solution")


@dataclass
class SolutionResult:
    cycle: ThermalCycle
    fraction_dissolved: dict[str, float]  # fraction of the available solute in solution at end of hold
    cu_in_solution_wt: float
    li_in_solution_wt: float
    recrystallised_fraction: float
    zener_pressure_pa: float
    zener_limit_grain_size_m: float
    burning_limit_K: float
    burning_margin_K: float
    solvus_K: dict[str, float]
    notes: list[str]


def solution_treat(ctx, state: MaterialState, cond: SolutionTreatment, cycle: ThermalCycle | None = None) -> SolutionResult:  # type: ignore[no-untyped-def]
    ctx.use(META.model_name)
    cond.validate()
    cyc = cycle if cycle is not None else cond.cycle()
    notes: list[str] = []
    state.dispersoid_free_fraction = dispersoid_free_fraction(ctx, state, cyc.peak_K())
    homog = apply_homogenisation(ctx, state, cyc)
    run_precipitation(ctx, state, cyc, n_out=20)
    T_hold = float(np.max(cyc.T_K))
    res = rx.anneal(ctx, state, cyc.duration, 0.5 * (T_hold + float(cyc.T_K[0])) if cyc.duration < 10 else T_hold)
    limit = burning_limit_K(ctx, state)
    margin = limit - T_hold
    if margin < 0:
        notes.append(f"BURNING RISK: {-margin:.0f} K above the incipient-melting limit")
    # dissolution metrics from the final precipitate field
    scale = None
    mw = state.matrix_wt()
    frac: dict[str, float] = {}
    for el in ("Li", "Cu"):
        nominal = state.composition.wt()[el]
        frac[el] = float(min(mw[el] / nominal, 1.0)) if nominal > 0 else 1.0
    solvus: dict[str, float] = {}
    x = state.solute_pool_at
    try:
        solvus["delta_prime"] = solvus_temperature(ctx, "delta_prime", max(x.get("Li", 0.0), 1e-9))
        solvus["T1"] = solvus_temperature(ctx, "T1", max(x.get("Cu", 0.0), 1e-9), max(x.get("Li", 0.0), 1e-9))
        solvus["theta_prime"] = solvus_temperature(ctx, "theta_prime", max(x.get("Cu", 0.0), 1e-9))
    except (ValueError, ZeroDivisionError):
        pass
    for k, v in solvus.items():
        if math.isfinite(v) and v > T_hold:
            notes.append(f"{k} solvus ({v:.0f} K) above the hold temperature: incomplete dissolution expected")
    state.stage = "solution_treated"
    state.temper = "W"
    state.log("solution_treatment", T_K=T_hold, hold_s=cond.hold_time_s, X_rex=res.X, margin_K=margin, **{
        k: v for k, v in homog.items() if isinstance(v, float)})
    _ = (scale, SOLUTE_INDEX)
    return SolutionResult(cyc, frac, mw["Cu"], mw["Li"], res.X, zener_pressure(ctx, state), zener_limit_grain_size(state),
                          limit, margin, solvus, notes)
