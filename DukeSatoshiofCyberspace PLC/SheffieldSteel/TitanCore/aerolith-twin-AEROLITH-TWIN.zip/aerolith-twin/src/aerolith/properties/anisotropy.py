"""Anisotropy metrics derived from texture, grain morphology and the directional property models."""

from __future__ import annotations

from dataclasses import dataclass

from ..governance import ModelMeta, register
from ..params import P, Status, declare

declare(P("aniso.note", 0.0, "-", Status.REFERENCE, "no free parameters: metrics are ratios of directional model outputs", 0.0))
META = register(ModelMeta(
    model_name="anisotropy_metrics",
    equation="ratios sigma_T/sigma_L, E_T/E_L, K_TL/K_LT; planar anisotropy (s_L + s_T - 2 s_45)/(2 s_iso)",
    parameter_source="none (derived)",
    validity_range="inherits the texture and property models",
    fidelity="ANALYTICAL",
))


@dataclass
class Anisotropy:
    yield_T_over_L: float
    yield_45_over_L: float
    planar_anisotropy: float
    E_T_over_L: float
    K_TL_over_LT: float


def anisotropy(yield_dir: dict[str, float], yield_iso: float, E_L: float, E_T: float, K_LT: float, K_TL: float) -> Anisotropy:
    sL, sT, sD = yield_dir["L"], yield_dir["T"], yield_dir["D"]
    return Anisotropy(sT / sL, sD / sL, (sL + sT - 2.0 * sD) / (2.0 * yield_iso), E_T / E_L, K_TL / K_LT)
