"""Elastic properties: composition-scaled single-crystal constants + texture-weighted VRH aggregate."""

from __future__ import annotations

import math
from dataclasses import dataclass

from ..chemistry.composition import Composition
from ..governance import ModelMeta, register
from ..microstructure.state import MaterialState
from ..microstructure.texture import ElasticResult, textured_elastic
from ..params import P, Status, declare
from ..provenance import Provenance, Quantity

declare(
    P("elastic.kE.Li", 0.060, "1/wt%", Status.LITERATURE_APPROX, "fractional stiffness increase per wt% Li in solid solution (widely quoted ~6 %/wt%)", 0.015, 0.0, 0.15),
    P("elastic.kE.Cu", 0.002, "1/wt%", Status.ILLUSTRATIVE, "small stiffness change per wt% Cu", 0.003, -0.03, 0.05),
    P("elastic.kE.Mg", -0.002, "1/wt%", Status.ILLUSTRATIVE, "small stiffness change per wt% Mg", 0.003, -0.03, 0.05),
    P("elastic.kE.Zn", 0.0, "1/wt%", Status.ILLUSTRATIVE, "assumed negligible", 0.003, -0.03, 0.05),
    P("elastic.kE.Ag", 0.0, "1/wt%", Status.ILLUSTRATIVE, "assumed negligible", 0.003, -0.03, 0.05),
    P("elastic.kE.Sc", 0.0, "1/wt%", Status.ILLUSTRATIVE, "assumed negligible", 0.01, -0.1, 0.1),
    P("elastic.kE.Zr", 0.0, "1/wt%", Status.ILLUSTRATIVE, "assumed negligible", 0.01, -0.1, 0.1),
)
META = register(ModelMeta(
    model_name="elastic_vrh_texture",
    equation="C_ij(c) = (1 + sum_i kE_i w_i) C_ij(Al) ; VRH average of orientation-resolved C and S over texture components",
    parameter_source="single-crystal Al constants (handbook, verify); kE registry elastic.kE.*",
    validity_range="solid-solution scaling linear in wt% (Li < 3 wt%); precipitate stiffness contribution not separately modelled; room temperature",
    fidelity="ANALYTICAL",
))


@dataclass
class ElasticProps:
    E_L: Quantity
    E_T: Quantity
    E_N: Quantity
    G_LT: Quantity
    nu_LT: Quantity
    E_iso: Quantity
    G_iso: Quantity
    nu_iso: Quantity


def stiffness_scale(ctx, comp: Composition) -> tuple[float, float]:  # type: ignore[no-untyped-def]
    wt = comp.wt()
    s, var = 1.0, 0.0
    for el, w in wt.items():
        if el == "Al" or w == 0:
            continue
        name = f"elastic.kE.{el}"
        if ctx.registry.has(name) and ctx.registry.is_known(name):
            s += ctx.p(name) * w
            var += (ctx.registry.get(name).uncertainty * w) ** 2
    return s, math.sqrt(var)


def elastic_properties(ctx, state: MaterialState) -> ElasticProps:  # type: ignore[no-untyped-def]
    ctx.use(META.model_name)
    scale, s_unc = stiffness_scale(ctx, state.composition)
    r: ElasticResult = textured_elastic(state.texture.normalised(), scale)

    def q(name: str, v: float, unit: str, rel: float = 0.0) -> Quantity:
        return Quantity(name, v, unit, abs(v) * rel, Provenance.SIMULATED, META.model_name)

    return ElasticProps(
        q("E_L", r.E_L / 1e9, "GPa", s_unc / scale), q("E_T", r.E_T / 1e9, "GPa", s_unc / scale),
        q("E_N", r.E_N / 1e9, "GPa", s_unc / scale), q("G_LT", r.G_LT / 1e9, "GPa", s_unc / scale),
        q("nu_LT", r.nu_LT, "-", 0.02), q("E_iso", r.E_iso / 1e9, "GPa", s_unc / scale),
        q("G_iso", r.G_iso / 1e9, "GPa", s_unc / scale), q("nu_iso", r.nu_iso, "-", 0.02),
    )


def isotropic_shear_modulus(E: float, nu: float) -> float:
    """G = E / (2 (1 + nu))."""
    return E / (2.0 * (1.0 + nu))
