"""Yield strength built from separately modelled mechanisms; UTS and elongation from a Voce/Considere model.

sigma_y = sigma_0 + d_ss + d_gb + sqrt(d_disl^2 + d_ppt^2)          (superposition documented in the parameter table)
d_ss    = sum_i k_i x_i^(2/3)                                       Fleischer-Labusch solid solution (matrix x_i)
d_gb    = X k_y d^-1/2 + (1-X)[k_y d_N^-1/2 + k_sub d_sub^-1/2]     Hall-Petch with recrystallised / unrecrystallised mix
d_disl  = M alpha G b sqrt(rho)                                     Taylor
d_ppt   = (sum_p d_p^q)^(1/q); d_p = M min_smooth(tau_shear, tau_Orowan)
tau_sh  = (g_apb/2b) [ (4 g_apb f r /(pi T))^1/2 - f ],  T = G b^2/2  (Brown-Ham)
tau_or  = 0.4 G b ln(2 r_s/b) / (pi sqrt(1-nu) lambda),  r_s = sqrt(2/3) r,  lambda = 2 r_s (sqrt(pi/(4f)) - 1)  (Ashby-Orowan)
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field

import numpy as np

from ..chemistry.elements import ATOMIC_MASS_G_MOL
from ..governance import ModelMeta, register
from ..microstructure.precipitates import PrecipitateField
from ..microstructure.state import MaterialState, wt_to_atom_fraction_scale
from ..microstructure.texture import DIRECTIONS
from ..numerics import smooth_min
from ..params import P, Status, declare
from ..thermodynamics.equilibrium import PHASE_KEYS
from ..units import AL_BURGERS_M, MPA

_I = "Placeholder tuned to typical Al-Li strength levels; calibrate to tensile data"
_K = {"Li": 250.0, "Cu": 400.0, "Mg": 500.0, "Zn": 150.0, "Ag": 300.0, "Mn": 600.0, "Si": 300.0, "Fe": 0.0,
      "Ti": 0.0, "Zr": 0.0, "Sc": 0.0}
declare(*[P(f"str.k_ss.{e}", k, "MPa", Status.ILLUSTRATIVE, "Fleischer-Labusch coefficient per at-fraction^(2/3)", 0.3 if k else 0.0, 0.0, 5000.0)
          for e, k in _K.items()])
declare(
    P("str.sigma0", 10.0, "MPa", Status.LITERATURE_APPROX, "lattice friction of Al (Peierls) plus residual impurities", 3.0, 0.0, 40.0),
    P("str.alpha_taylor", 0.25, "-", Status.LITERATURE_APPROX, "Taylor dislocation-strengthening constant", 0.03, 0.1, 0.5),
    P("str.G", 2.6e10, "Pa", Status.LITERATURE_APPROX, "shear modulus of Al", 1e9, 2e10, 3e10),
    P("str.nu", 0.33, "-", Status.LITERATURE_APPROX, "Poisson ratio", 0.01, 0.25, 0.4),
    P("str.k_y", 0.06, "MPa m^0.5", Status.LITERATURE_APPROX, "Hall-Petch slope of Al alloys (pure Al ~0.04)", 0.015, 0.0, 0.3),
    P("str.k_sub", 0.04, "MPa m^0.5", Status.ILLUSTRATIVE, "subgrain Hall-Petch slope", 0.015, 0.0, 0.3),
    P("str.M", 3.06, "-", Status.REFERENCE, "Taylor factor of random FCC polycrystal", 0.05),
    P("str.q_ppt", 2.0, "-", Status.ILLUSTRATIVE, "superposition exponent between precipitate phases", 0.3, 1.0, 4.0),
    P("str.q_disl_ppt", 2.0, "-", Status.ILLUSTRATIVE, "superposition exponent between dislocation and precipitate contributions", 0.3, 1.0, 4.0),
    P("str.q_shear_orowan", 6.0, "-", Status.ILLUSTRATIVE, "sharpness of the shear/Orowan transition (smooth minimum)", 1.0, 2.0, 20.0),
    P("str.apb.delta_prime", 0.14, "J/m2", Status.ILLUSTRATIVE, "antiphase-boundary energy of delta'", 0.03, 0.05, 0.3),
    P("str.apb.Al3Zr", 0.25, "J/m2", Status.ILLUSTRATIVE, "APB energy of Al3Zr dispersoids", 0.08, 0.05, 0.6),
    P("str.apb.Al3Sc", 0.40, "J/m2", Status.ILLUSTRATIVE, "APB energy of Al3Sc dispersoids", 0.1, 0.05, 0.8),
    P("str.eff.delta_prime", 1.0, "-", Status.ILLUSTRATIVE, "strengthening efficiency of delta'", 0.15, 0.1, 2.0),
    P("str.eff.T1", 1.0, "-", Status.ILLUSTRATIVE, "plate-geometry efficiency of T1 relative to spheres of equal volume", 0.12, 0.1, 3.0),
    P("str.eff.theta_prime", 0.5, "-", Status.ILLUSTRATIVE, "efficiency of theta'", 0.2, 0.1, 3.0),
    P("str.eff.Al3Zr", 0.4, "-", Status.ILLUSTRATIVE, "efficiency of Al3Zr dispersoids", 0.2, 0.05, 2.0),
    P("str.eff.Al3Sc", 0.5, "-", Status.ILLUSTRATIVE, "efficiency of Al3Sc dispersoids", 0.2, 0.05, 2.0),
    P("str.theta0_shear", 1.2e9, "Pa", Status.ILLUSTRATIVE, "initial work-hardening rate when shearable precipitates dominate", 0.2e9, 1e8, 1e10, False),
    P("str.theta0_orowan", 2.5e9, "Pa", Status.ILLUSTRATIVE, "initial work-hardening rate when Orowan looping dominates", 0.4e9, 1e8, 1e10, False),
    P("str.sat_fraction", 0.20, "-", Status.ILLUSTRATIVE, "Voce saturation stress increment as a fraction of yield strength", 0.08, 0.05, 1.0),
    P("str.eps_neck0", 0.04, "-", Status.ILLUSTRATIVE, "post-uniform (local) true strain of a defect-free material", 0.03, 0.01, 0.5),
    P("str.damage_c", 60.0, "-", Status.ILLUSTRATIVE, "ductility knock-down per unit constituent volume fraction", 0.4, 0.0, 1e4, True),
    P("str.damage_p", 400.0, "-", Status.ILLUSTRATIVE, "ductility knock-down per unit porosity volume fraction", 0.4, 0.0, 1e5, True),
    P("str.damage_gb", 0.35, "-", Status.ILLUSTRATIVE, "ductility knock-down at full grain-boundary precipitate coverage", 0.1, 0.0, 0.9),
)

META = register(ModelMeta(
    model_name="yield_strength_mechanism_sum",
    equation=__doc__.strip().splitlines()[0] if __doc__ else "see module docstring",
    parameter_source="registry str.* (ILLUSTRATIVE/LITERATURE_APPROX); microstructure state from the process chain",
    validity_range="age-hardened Al-Li-Cu alloys, room temperature, quasi-static; precipitate strengthening from mean radius per phase; no PFZ model",
))


@dataclass
class PrecipContribution:
    phase: str
    volume_fraction: float
    mean_radius_m: float
    shear_mpa: float
    orowan_mpa: float
    chosen_mpa: float
    regime: str  # shearing | orowan | transition | none


def _tau_shear(ctx, key: str, f: float, r: float) -> float:  # type: ignore[no-untyped-def]
    if not ctx.registry.has(f"str.apb.{key}"):
        return math.inf
    G, b = ctx.p("str.G"), AL_BURGERS_M
    g = ctx.p(f"str.apb.{key}")
    T = 0.5 * G * b * b
    val = (4.0 * g * f * r / (math.pi * T)) ** 0.5 - f
    return max(g / (2.0 * b) * val, 0.0)


def _tau_orowan(ctx, f: float, r: float) -> float:  # type: ignore[no-untyped-def]
    G, b, nu = ctx.p("str.G"), AL_BURGERS_M, ctx.p("str.nu")
    rs = math.sqrt(2.0 / 3.0) * r
    lam = 2.0 * rs * (math.sqrt(math.pi / (4.0 * max(f, 1e-9))) - 1.0)
    if lam <= 0 or 2 * rs <= b:
        return 0.0
    return 0.4 * G * b * math.log(2.0 * rs / b) / (math.pi * math.sqrt(1.0 - nu) * lam)


def phase_contribution(ctx, key: str, f: float, r: float) -> PrecipContribution:  # type: ignore[no-untyped-def]
    if f <= 1e-8 or r <= 0:
        return PrecipContribution(key, f, r, 0, 0, 0, "none")
    M, eff = ctx.p("str.M"), ctx.p(f"str.eff.{key}")
    ts, to = _tau_shear(ctx, key, f, r), _tau_orowan(ctx, f, r)
    if math.isinf(ts):
        tau, reg = to, "orowan"
    else:
        tau = smooth_min(max(ts, 1e-3), max(to, 1e-3), ctx.p("str.q_shear_orowan"))
        reg = "shearing" if ts < 0.8 * to else "orowan" if to < 0.8 * ts else "transition"
    return PrecipContribution(key, f, r, M * ts / MPA * eff if math.isfinite(ts) else math.inf, M * to / MPA * eff,
                              M * tau / MPA * eff, reg)


def precipitation_strengthening(ctx, precip: PrecipitateField) -> tuple[float, list[PrecipContribution]]:  # type: ignore[no-untyped-def]
    contribs = []
    for key in PHASE_KEYS:
        f = precip.volume_fraction(key)
        r = precip.mean_radius(key)
        contribs.append(phase_contribution(ctx, key, f, r))
    q = ctx.p("str.q_ppt")
    tot = sum(c.chosen_mpa**q for c in contribs) ** (1.0 / q)
    return float(tot), contribs


def precipitation_strengthening_from_means(ctx, f: dict[str, float], r: dict[str, float]) -> float:  # type: ignore[no-untyped-def]
    q = ctx.p("str.q_ppt")
    return float(sum(phase_contribution(ctx, k, f.get(k, 0.0), r.get(k, 0.0)).chosen_mpa ** q for k in PHASE_KEYS) ** (1 / q))


def solid_solution(ctx, matrix_wt: dict[str, float], comp) -> float:  # type: ignore[no-untyped-def]
    scale = wt_to_atom_fraction_scale(comp)
    tot = 0.0
    for el, w in matrix_wt.items():
        if el == "Al" or w <= 0:
            continue
        name = f"str.k_ss.{el}"
        if not ctx.registry.has(name):
            continue
        x = w / ATOMIC_MASS_G_MOL[el] / scale
        tot += ctx.p(name) * x ** (2.0 / 3.0)
    return tot


def grain_boundary(ctx, state: MaterialState) -> float:  # type: ignore[no-untyped-def]
    g = state.grains
    assert g is not None
    ky, ks = ctx.p("str.k_y"), ctx.p("str.k_sub")
    X = g.recrystallised_fraction
    d_rx = g.mean_size_m
    unrex = ky / math.sqrt(g.d_N) + ks / math.sqrt(max(g.subgrain_size_m, 1e-8))
    return float(X * ky / math.sqrt(d_rx) + (1.0 - X) * unrex)


def dislocation(ctx, rho: float) -> float:  # type: ignore[no-untyped-def]
    return ctx.p("str.M") * ctx.p("str.alpha_taylor") * ctx.p("str.G") * AL_BURGERS_M * math.sqrt(max(rho, 0.0)) / MPA


@dataclass
class StrengthResult:
    sigma0: float
    solid_solution: float
    grain_boundary: float
    dislocation: float
    precipitation: float
    yield_iso: float
    yield_dir: dict[str, float]
    taylor_factors: dict[str, float]
    uts: float
    uniform_elongation: float
    elongation: float
    precip: list[PrecipContribution] = field(default_factory=list)
    shear_share: float = 0.0
    net_section_factor: float = 1.0
    theta0_pa: float = 0.0
    delta_sat_pa: float = 0.0
    eps_neck: float = 0.0

    def contributions(self) -> dict[str, float]:
        return {"sigma0": self.sigma0, "solid_solution": self.solid_solution, "grain_boundary": self.grain_boundary,
                "dislocation": self.dislocation, "precipitation": self.precipitation}


def evaluate_strength(ctx, state: MaterialState) -> StrengthResult:  # type: ignore[no-untyped-def]
    ctx.use(META.model_name)
    s0 = ctx.p("str.sigma0")
    mw = state.matrix_wt()
    ss = solid_solution(ctx, mw, state.composition)
    gb = grain_boundary(ctx, state)
    dis = dislocation(ctx, state.dislocation_density)
    ppt, contribs = precipitation_strengthening(ctx, state.precip)
    qd = ctx.p("str.q_disl_ppt")
    y_iso = s0 + ss + gb + (dis**qd + ppt**qd) ** (1.0 / qd)
    # defects: net-section reduction from the porosity volume fraction (area fraction ~ f^(2/3))
    f_p = state.defects.porosity_volume_fraction() + state.defects.bulk.get("cast_porosity_fraction", 0.0) * 0.0
    net = 1.0 - f_p ** (2.0 / 3.0)
    y_iso *= net
    tf = state.texture.taylor_factors()
    y_dir = {d: y_iso * tf[d] / ctx.p("str.M") for d in DIRECTIONS}
    # work hardening: Voce with Considere necking
    shear_w = sum(c.chosen_mpa for c in contribs if c.regime == "shearing")
    tot_w = sum(c.chosen_mpa for c in contribs) or 1.0
    sf = shear_w / tot_w
    theta0 = sf * ctx.p("str.theta0_shear") + (1.0 - sf) * ctx.p("str.theta0_orowan")
    sy = y_iso * MPA
    ds = ctx.p("str.sat_fraction") * sy
    u = (sy + ds) / (theta0 + ds)
    if u >= 1.0:
        eps_u = 0.0
        uts_true = sy
    else:
        eps_u = -(ds / theta0) * math.log(u)
        uts_true = sy + ds * (1.0 - u)
    uts_eng = uts_true * math.exp(-eps_u) / MPA
    f_c = state.insoluble_constituent_fraction + state.eutectic_fraction
    knock = 1.0 / (1.0 + ctx.p("str.damage_c") * f_c + ctx.p("str.damage_p") * f_p) * (1.0 - ctx.p("str.damage_gb") * state.gb_precipitate_coverage)
    eps_f = eps_u + ctx.p("str.eps_neck0") * knock
    elong = (math.exp(eps_f) - 1.0) * 100.0
    return StrengthResult(s0, ss, gb, dis, ppt, y_iso, y_dir, tf, max(uts_eng, y_iso), eps_u, elong, contribs, sf, net,
                          theta0, ds, ctx.p("str.eps_neck0") * knock)


_ = np
