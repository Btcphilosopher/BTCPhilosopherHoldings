"""Composition-dependent density.

Mixing rule (documented assumption): ideal volume additivity with a per-element
partial-volume ratio r_i (r_i = 1 is ideal mixing of pure-element densities):

    1/rho = sum_i (w_i/100) r_i / rho_i

Li contracts strongly in the Al lattice relative to the pure-metal volume, so r_Li < 1.
The default r_Li is ILLUSTRATIVE (chosen to reproduce the widely quoted ~3 % density
reduction per wt% Li); calibrate against measured densities (calibration module).
"""

from __future__ import annotations

import math

from ..chemistry.composition import Composition
from ..chemistry.elements import DENSITY_PURE_KG_M3, ELEMENTS
from ..governance import ModelMeta, register
from ..params import P, Status, declare
from ..provenance import Provenance, Quantity

_IDEAL = "Ideal volume additivity assumed; calibrate against measured density"
declare(*[
    P(f"density.vratio.{e}", 0.81 if e == "Li" else 1.0, "-", Status.ILLUSTRATIVE,
      "chosen to reproduce ~3%/wt% density reduction per wt% Li" if e == "Li" else _IDEAL,
      0.04 if e == "Li" else 0.03, 0.5, 1.3)
    for e in ELEMENTS if e != "Al"
])
declare(P("density.alpha_lin", 23.0e-6, "1/K", Status.LITERATURE_APPROX, "linear CTE of Al alloys near room temperature", 1.5e-6, 1e-5, 4e-5))

META = register(ModelMeta(
    model_name="density_volume_additivity",
    equation="1/rho = sum_i (w_i/100) r_i / rho_i ; rho(T) = rho(293)/(1+3 alpha (T-293))",
    parameter_source="pure-element densities (REFERENCE); partial-volume ratios r_i (ILLUSTRATIVE unless calibrated)",
    validity_range="solid solution / dilute alloys, 273-373 K for the room-temperature value",
    fidelity="EMPIRICAL",
))


def density_kg_m3(ctx, comp: Composition, T_K: float = 293.0) -> Quantity:  # type: ignore[no-untyped-def]
    ctx.use(META.model_name)
    wt = comp.wt()
    inv = 0.0
    r: dict[str, float] = {}
    for e, w in wt.items():
        ri = 1.0 if e == "Al" else ctx.p(f"density.vratio.{e}")
        r[e] = ri
        inv += (w / 100.0) * ri / DENSITY_PURE_KG_M3[e]
    rho = 1.0 / inv
    var = 0.0
    for e, w in wt.items():
        if e == "Al" or w == 0.0:
            continue
        s = ctx.registry.get(f"density.vratio.{e}").uncertainty
        d = rho**2 * (w / 100.0) / DENSITY_PURE_KG_M3[e]
        var += (d * s) ** 2
    alpha = ctx.p("density.alpha_lin")
    rho_T = rho / (1.0 + 3.0 * alpha * (T_K - 293.0))
    return Quantity("density", rho_T, "kg/m3", math.sqrt(var), Provenance.SIMULATED, META.model_name)


def specific_strength(strength_pa: float, rho: float) -> float:
    """Specific strength in N m / kg (= Pa m3 / kg)."""
    return strength_pa / rho


def specific_modulus(E_pa: float, rho: float) -> float:
    return E_pa / rho
