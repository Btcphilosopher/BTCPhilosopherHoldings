"""Electrical/thermal transport (Matthiessen + Wiedemann-Franz) and thermal expansion."""

from __future__ import annotations

import math
from dataclasses import dataclass

from ..governance import ModelMeta, register
from ..microstructure.state import MaterialState
from ..params import P, Status, declare

_RHO_PER_WT = {"Li": 3.3, "Cu": 0.344, "Mg": 0.54, "Zn": 0.094, "Ag": 0.1, "Zr": 1.74, "Sc": 1.0, "Mn": 2.94, "Fe": 2.56,
               "Si": 1.02, "Ti": 2.88}  # micro-ohm cm per wt% in solid solution
declare(*[P(f"th.rho_wt.{e}", v, "uOhm cm/wt%", Status.LITERATURE_APPROX if e in ("Li", "Cu", "Mg", "Zn", "Mn", "Fe", "Si", "Ti", "Zr") else Status.ILLUSTRATIVE,
            "resistivity increment of solute in Al solid solution (Matthiessen); verify", 0.25 * v, 0.0, 10.0) for e, v in _RHO_PER_WT.items()])
declare(
    P("th.rho0", 2.65e-8, "Ohm m", Status.REFERENCE, "resistivity of pure Al at 293 K", 5e-11),
    P("th.rho_ppt", 1.5e-7, "Ohm m per unit volume fraction", Status.ILLUSTRATIVE, "scattering by precipitates per unit volume fraction", 0.5, 0.0, 1e-5, True),
    P("th.L", 2.44e-8, "W Ohm/K2", Status.REFERENCE, "Lorenz number", 1e-10),
    P("th.k_ph", 5.0, "W/m/K", Status.ILLUSTRATIVE, "lattice thermal conductivity", 3.0, 0.0, 30.0),
    P("th.cte_Li", -0.35e-6, "1/K per wt%", Status.ILLUSTRATIVE, "CTE change per wt% Li", 0.3e-6, -3e-6, 3e-6),
)
META = register(ModelMeta(
    model_name="transport_matthiessen_wiedemann_franz",
    equation="rho_e = rho0 + sum k_i w_i,matrix + k_p f ; kappa = L T / rho_e + kappa_ph",
    parameter_source="registry th.* (LITERATURE_APPROX / ILLUSTRATIVE)",
    validity_range="dilute solid solutions near 293 K; additive resistivity contributions; no texture dependence",
    fidelity="EMPIRICAL",
))


@dataclass
class ThermalProps:
    resistivity_ohm_m: float
    conductivity_ms_m: float
    iacs_percent: float
    thermal_conductivity_w_mk: float
    cte_1_k: float


def thermal_properties(ctx, state: MaterialState, T: float = 293.0) -> ThermalProps:  # type: ignore[no-untyped-def]
    ctx.use(META.model_name)
    mw = state.matrix_wt()
    rho = ctx.p("th.rho0")
    for el, w in mw.items():
        if el == "Al":
            continue
        if ctx.registry.has(f"th.rho_wt.{el}"):
            rho += ctx.p(f"th.rho_wt.{el}") * w * 1.0e-8
    rho += ctx.p("th.rho_ppt") * state.precip.total_volume_fraction()
    sigma = 1.0 / rho
    kappa = ctx.p("th.L") * T / rho + ctx.p("th.k_ph")
    cte = ctx.p("density.alpha_lin") + ctx.p("th.cte_Li") * state.composition.Li
    return ThermalProps(rho, sigma / 1e6, sigma / 1e6 / 58.0 * 100.0, kappa, cte)


_ = math
