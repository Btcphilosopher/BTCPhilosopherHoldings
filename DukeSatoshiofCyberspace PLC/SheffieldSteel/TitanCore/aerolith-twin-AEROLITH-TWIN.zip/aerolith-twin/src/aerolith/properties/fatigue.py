"""Reduced-order fatigue: Basquin S-N, Goodman mean-stress, surface factor, El Haddad defect correction.

sigma_ar = sigma_a / (1 - sigma_m/UTS)            Goodman equivalent fully-reversed amplitude
S-N      : sigma_ar = k_s sigma_f' (2N)^b          Basquin (empirical datasets override, see fit_basquin)
defect   : sigma_w(a) = sigma_w0 sqrt(a0/(a0 + a)),  a0 = (1/pi) (dK_th/(Y sigma_w0))^2   El Haddad / Kitagawa-Takahashi
eps-N    : Coffin-Manson parameters UNKNOWN unless supplied.
"""

from __future__ import annotations

import math
from dataclasses import dataclass

import numpy as np

from ..governance import ModelMeta, register
from ..microstructure.state import MaterialState
from ..params import P, Status, declare

SURFACE = {"polished": 1.0, "machined": 0.92, "as_rolled": 0.80, "chemically_milled": 0.88, "anodised": 0.72}
declare(*[P(f"fat.surface.{k}", v, "-", Status.ILLUSTRATIVE, "surface-condition fatigue knock-down factor", 0.04, 0.3, 1.05) for k, v in SURFACE.items()])
declare(
    P("fat.sigma_f_ratio", 1.0, "-", Status.ILLUSTRATIVE, "Basquin sigma_f' / UTS", 0.1, 0.4, 2.0),
    P("fat.b", -0.075, "-", Status.ILLUSTRATIVE, "Basquin exponent", 0.015, -0.2, -0.02),
    P("fat.dK_th", 1.8, "MPa m^0.5", Status.ILLUSTRATIVE, "long-crack fatigue threshold (R~0.1)", 0.4, 0.3, 6.0),
    P("fat.scatter_log10N", 0.30, "decades", Status.ILLUSTRATIVE, "1-sigma scatter of log10(life)", 0.05, 0.05, 1.0),
    P("fat.stressed_volume", 2.0e-5, "m3", Status.ILLUSTRATIVE, "stressed volume of the reference specimen/feature for the defect-size extreme-value argument", 0.0, 1e-9, 1.0),
    P("fat.Y", 1.12, "-", Status.REFERENCE, "geometry factor", 0.05),
    P("fat.eps_f", None, "-", Status.UNKNOWN, "Coffin-Manson fatigue ductility coefficient: supply from strain-controlled tests", 0.0),
    P("fat.c", None, "-", Status.UNKNOWN, "Coffin-Manson fatigue ductility exponent: supply from strain-controlled tests", 0.0),
)
META = register(ModelMeta(
    model_name="fatigue_basquin_goodman_elhaddad",
    equation=__doc__.strip().splitlines()[1] if __doc__ else "",
    parameter_source="registry fat.* (ILLUSTRATIVE); user datasets override via fit_basquin",
    validity_range="1e4-1e8 cycles, constant amplitude, ambient air, R in [-1, 0.7]; no environment/frequency effects",
    fidelity="EMPIRICAL",
))


@dataclass
class FatigueResult:
    endurance_1e7_mpa: float  # fully reversed amplitude, k_s and defects included
    endurance_defect_free_mpa: float
    defect_size_m: float
    a0_m: float
    sigma_f_prime_mpa: float
    b: float
    surface: str


def goodman_equivalent(sigma_a: float, R: float, uts: float) -> float:
    sm = sigma_a * (1.0 + R) / (1.0 - R)
    if sm >= uts:
        return math.inf
    return sigma_a / (1.0 - sm / uts)


def _largest_relevant_defect(ctx, state: MaterialState) -> float:  # type: ignore[no-untyped-def]
    """Characteristic defect size for a specimen-sized stressed volume (extreme-value argument).

    In a population with N defects in volume V_pop, the largest defect expected in a stressed volume V_s is the
    j-th largest with j = V_pop / V_s.  If the enumerated list is shorter than j, the bulk pore median is used.
    """
    vs = ctx.p("fat.stressed_volume")
    L, W, H = state.dims_m
    vpop = max(L * W * H, 1e-12)
    sizes = sorted((d.size_m for d in state.defects.defects), reverse=True)
    j = max(1, int(round(vpop / vs)))
    if j <= len(sizes):
        a = sizes[j - 1]
    else:
        a = state.defects.bulk.get("pore_d50_m", 0.0)
    return 0.4 * a


def evaluate_fatigue(ctx, state: MaterialState, uts_mpa: float, surface: str = "machined") -> FatigueResult:  # type: ignore[no-untyped-def]
    ctx.use(META.model_name)
    ks = ctx.p(f"fat.surface.{surface}")
    sf = ctx.p("fat.sigma_f_ratio") * uts_mpa
    b = ctx.p("fat.b")
    sw0 = ks * sf * (2.0e7) ** b
    a0 = (1.0 / math.pi) * (ctx.p("fat.dK_th") / (ctx.p("fat.Y") * max(sw0, 1.0))) ** 2
    a = _largest_relevant_defect(ctx, state)
    sw = sw0 * math.sqrt(a0 / (a0 + a))
    return FatigueResult(sw, sw0, a, a0, sf, b, surface)


def sn_curve(ctx, fr: FatigueResult, uts_mpa: float, R: float = -1.0, N: np.ndarray | None = None) -> dict[str, np.ndarray]:  # type: ignore[no-untyped-def]
    """S-N curve in terms of the applied stress amplitude at ratio R, with a 95 % scatter band (in life)."""
    N = np.geomspace(1e3, 1e8, 60) if N is None else N
    sar = (fr.endurance_1e7_mpa / (2.0e7**fr.b)) * (2.0 * N) ** fr.b  # equivalent fully-reversed amplitude
    # invert Goodman for the applied amplitude at R
    k = (1.0 + R) / (1.0 - R)
    sa = sar / (1.0 + k * sar / uts_mpa)
    sc = ctx.p("fat.scatter_log10N")
    lo = sa * 10 ** (1.96 * sc * fr.b)  # life scatter of +/-1.96 sigma maps to amplitude factors 10^(+/-1.96 sc b)
    hi = sa * 10 ** (-1.96 * sc * fr.b)
    return {"N": N, "sigma_a_mpa": sa, "lo95": np.minimum(lo, hi), "hi95": np.maximum(lo, hi)}


def fit_basquin(stress_amp_mpa: np.ndarray, cycles: np.ndarray) -> tuple[float, float]:
    """Least-squares Basquin fit log(sigma_a) = log(sigma_f') + b log(2N); returns (sigma_f', b)."""
    b, a = np.polyfit(np.log(2.0 * np.asarray(cycles)), np.log(np.asarray(stress_amp_mpa)), 1)
    return float(math.exp(a)), float(b)


def strain_life(ctx, eps_a: float, E_pa: float, sigma_f_prime_pa: float, b: float) -> float:  # type: ignore[no-untyped-def]
    """Coffin-Manson-Basquin total strain-life solved for N.  Requires fat.eps_f and fat.c (UNKNOWN by default)."""
    from scipy.optimize import brentq

    ef, c = ctx.p("fat.eps_f"), ctx.p("fat.c")

    def f(lnN: float) -> float:
        n2 = 2.0 * math.exp(lnN)
        return sigma_f_prime_pa / E_pa * n2**b + ef * n2**c - eps_a

    return float(math.exp(brentq(f, 0.0, 40.0)))
