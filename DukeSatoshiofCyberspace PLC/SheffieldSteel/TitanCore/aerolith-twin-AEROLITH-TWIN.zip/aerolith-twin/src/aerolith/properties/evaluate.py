"""One-call property evaluation of a MaterialState -> PropertySet of provenance-tagged Quantities."""

from __future__ import annotations

from dataclasses import dataclass

from ..context import RunContext
from ..microstructure.state import MaterialState
from ..params import P, Status, declare
from ..provenance import Provenance, Quantity, QuantitySet
from . import anisotropy as an
from . import corrosion, density, elastic, fatigue, fracture, strength, thermal

declare(*[P(f"unc.model_rel.{k}", v, "-", Status.ILLUSTRATIVE, "relative model-form (1-sigma) uncertainty of the reduced-order model; replace by calibration residuals", 0.0)
          for k, v in {"yield_strength": 0.08, "uts": 0.07, "elongation": 0.25, "fracture_toughness": 0.18, "fatigue_strength": 0.20,
                       "density": 0.003, "elastic_modulus": 0.02, "corrosion_index": 0.35}.items()])


@dataclass
class PropertySet:
    q: QuantitySet
    strength: strength.StrengthResult
    elastic: elastic.ElasticProps
    fracture: fracture.FractureResult
    fatigue: fatigue.FatigueResult
    thermal: thermal.ThermalProps
    corrosion: corrosion.CorrosionResult
    anisotropy: an.Anisotropy
    density_kg_m3: float

    def values(self) -> dict[str, float]:
        return self.q.values()


def evaluate_properties(ctx: RunContext, state: MaterialState, surface: str = "machined", design_stress_fraction: float = 0.6) -> PropertySet:
    rho = density.density_kg_m3(ctx, state.composition)
    el = elastic.elastic_properties(ctx, state)
    st = strength.evaluate_strength(ctx, state)
    fr = fracture.fracture_toughness(ctx, state, st.yield_dir["L"])
    fa = fatigue.evaluate_fatigue(ctx, state, st.uts, surface)
    th = thermal.thermal_properties(ctx, state)
    co = corrosion.corrosion_risk(ctx, state)
    ani = an.anisotropy(st.yield_dir, st.yield_iso, el.E_L.value, el.E_T.value, fr.K_LT_mpa_sqrt_m, fr.K_TL_mpa_sqrt_m)
    ctx.use(an.META.model_name)
    qs = QuantitySet()
    S = Provenance.SIMULATED

    def add(name: str, v: float, unit: str, model: str, rel_key: str | None = None, sigma: float | None = None) -> None:
        s = sigma
        if rel_key is not None:
            s = abs(v) * ctx.p(f"unc.model_rel.{rel_key}")
        qs.add(Quantity(name, v, unit, s, S, model))

    add("density", rho.value, "kg/m3", density.META.model_name, "density")
    add("E_L", el.E_L.value, "GPa", elastic.META.model_name, "elastic_modulus")
    add("E_T", el.E_T.value, "GPa", elastic.META.model_name, "elastic_modulus")
    add("G_LT", el.G_LT.value, "GPa", elastic.META.model_name, "elastic_modulus")
    add("nu_LT", el.nu_LT.value, "-", elastic.META.model_name, "elastic_modulus")
    add("E_iso", el.E_iso.value, "GPa", elastic.META.model_name, "elastic_modulus")
    add("yield_strength_L", st.yield_dir["L"], "MPa", strength.META.model_name, "yield_strength")
    add("yield_strength_T", st.yield_dir["T"], "MPa", strength.META.model_name, "yield_strength")
    add("yield_strength_45", st.yield_dir["D"], "MPa", strength.META.model_name, "yield_strength")
    add("yield_strength", st.yield_dir["L"], "MPa", strength.META.model_name, "yield_strength")
    add("uts", st.uts * st.yield_dir["L"] / st.yield_iso, "MPa", strength.META.model_name, "uts")
    add("elongation", st.elongation, "%", strength.META.model_name, "elongation")
    add("fracture_toughness_LT", fr.K_LT_mpa_sqrt_m, "MPa m^0.5", fracture.META.model_name, "fracture_toughness")
    add("fracture_toughness_TL", fr.K_TL_mpa_sqrt_m, "MPa m^0.5", fracture.META.model_name, "fracture_toughness")
    add("fracture_toughness", fr.K_LT_mpa_sqrt_m, "MPa m^0.5", fracture.META.model_name, "fracture_toughness")
    add("fatigue_strength_1e7", fa.endurance_1e7_mpa, "MPa (R=-1 amplitude)", fatigue.META.model_name, "fatigue_strength")
    add("corrosion_index", co.index, "-", corrosion.META.model_name, "corrosion_index")
    add("electrical_conductivity_iacs", th.iacs_percent, "%IACS", thermal.META.model_name, sigma=0.03 * th.iacs_percent)
    add("thermal_conductivity", th.thermal_conductivity_w_mk, "W/m/K", thermal.META.model_name, sigma=0.05 * th.thermal_conductivity_w_mk)
    add("specific_strength", st.yield_dir["L"] * 1e6 / rho.value / 1e3, "kN m/kg", density.META.model_name, "yield_strength")
    add("specific_modulus", el.E_L.value * 1e9 / rho.value / 1e6, "MN m/kg", density.META.model_name, "elastic_modulus")
    add("grain_size", (state.grains.mean_size_m * 1e6) if state.grains else 0.0, "um", "grain_state")
    add("residual_stress_max", (state.residual_stress.max_abs_pa / 1e6) if state.residual_stress else 0.0, "MPa", "quench_model")
    add("porosity_fraction", state.defects.porosity_volume_fraction() + state.defects.bulk.get("cast_porosity_fraction", 0.0), "-", "defect_population")
    _ = design_stress_fraction
    return PropertySet(qs, st, el, fr, fa, th, co, ani, rho.value)
