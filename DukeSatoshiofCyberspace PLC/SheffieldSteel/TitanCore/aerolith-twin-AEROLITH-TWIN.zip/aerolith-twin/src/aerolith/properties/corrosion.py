"""Comparative corrosion-susceptibility index (0 low .. 1 high).  NOT an EXCO/ASTM G34/G110 prediction."""

from __future__ import annotations

import math
from dataclasses import dataclass

from ..governance import ModelMeta, register
from ..microstructure.state import MaterialState
from ..params import P, Status, declare

declare(
    P("corr.w_pit", 1.0, "-", Status.ILLUSTRATIVE, "weight of galvanic/pitting driver", 0.3, 0.0, 10.0),
    P("corr.w_igc", 1.5, "-", Status.ILLUSTRATIVE, "weight of intergranular driver", 0.4, 0.0, 10.0),
    P("corr.w_exf", 0.8, "-", Status.ILLUSTRATIVE, "weight of exfoliation driver", 0.3, 0.0, 10.0),
    P("corr.cu_ref", 4.0, "wt%", Status.ILLUSTRATIVE, "Cu in solution giving unit galvanic driver", 0.0),
    P("corr.const_ref", 0.005, "-", Status.ILLUSTRATIVE, "constituent volume fraction giving unit pitting driver", 0.0),
    P("corr.li_igc", 0.25, "1/wt%", Status.ILLUSTRATIVE, "Li-bearing grain-boundary phase contribution per wt% Li", 0.1, 0.0, 2.0),
)
META = register(ModelMeta(
    model_name="corrosion_susceptibility_index",
    equation="R = 1 - exp(-(w_p I_pit + w_i I_igc + w_e I_exf))",
    parameter_source="registry corr.* (ILLUSTRATIVE)",
    validity_range="relative ranking of tempers/routes only; no environment, no coating; not validated against any corrosion test standard",
    fidelity="EMPIRICAL",
))


@dataclass
class CorrosionResult:
    index: float
    pitting: float
    intergranular: float
    exfoliation: float


def corrosion_risk(ctx, state: MaterialState) -> CorrosionResult:  # type: ignore[no-untyped-def]
    ctx.use(META.model_name)
    mw = state.matrix_wt()
    pit = mw["Cu"] / ctx.p("corr.cu_ref") + (state.insoluble_constituent_fraction + state.eutectic_fraction) / ctx.p("corr.const_ref")
    igc = state.gb_precipitate_coverage * (1.0 + ctx.p("corr.li_igc") * state.composition.Li)
    g = state.grains
    ar = g.aspect_ratio if g else 1.0
    exf = (1.0 - (g.recrystallised_fraction if g else 0.0)) * math.log(max(ar, 1.0)) / math.log(10.0) * (1.0 + 0.3 * state.composition.Li)
    r = 1.0 - math.exp(-(ctx.p("corr.w_pit") * pit + ctx.p("corr.w_igc") * igc + ctx.p("corr.w_exf") * exf))
    return CorrosionResult(r, pit, igc, exf)
