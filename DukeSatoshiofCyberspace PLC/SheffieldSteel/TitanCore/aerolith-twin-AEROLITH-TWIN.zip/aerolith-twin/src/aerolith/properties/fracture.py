"""Fracture toughness (void-nucleation process-zone model), critical flaw size, Paris-law framework."""

from __future__ import annotations

import math
from dataclasses import dataclass

import numpy as np

from ..errors import ParameterUnknownError
from ..governance import ModelMeta, register
from ..microstructure.state import MaterialState
from ..params import P, Status, declare
from ..units import MPA

declare(
    P("frac.eps_c", 0.3, "-", Status.ILLUSTRATIVE, "critical local strain for void coalescence in the process zone", 0.2, 0.05, 3.0, True),
    P("frac.m_cod", 1.0, "-", Status.ILLUSTRATIVE, "J = m sigma_y delta constraint factor", 0.2, 0.5, 3.0),
    P("frac.d_constituent", 5.0e-6, "m", Status.ILLUSTRATIVE, "mean constituent particle diameter", 0.3, 5e-7, 5e-5, True),
    P("frac.delam_gain", 0.04, "-", Status.ILLUSTRATIVE, "T-L toughening/loss per ln(grain aspect ratio) from delamination", 0.05, 0.0, 0.6),
    P("frac.gb_loss", 0.25, "-", Status.ILLUSTRATIVE, "toughness loss at full grain-boundary precipitate coverage", 0.1, 0.0, 0.8),
    P("frac.rex_loss", 0.15, "-", Status.ILLUSTRATIVE, "toughness loss when fully recrystallised (vs fibrous unrecrystallised)", 0.07, 0.0, 0.6),
    P("frac.E_eff", 7.8e10, "Pa", Status.LITERATURE_APPROX, "plane-strain modulus E/(1-nu^2)", 3e9, 5e10, 1e11),
    P("frac.Y", 1.12, "-", Status.REFERENCE, "geometry factor for a shallow surface crack", 0.05),
    P("frac.paris_C", None, "m/cycle/(MPa m^0.5)^m", Status.UNKNOWN, "Paris-law coefficient: supply from a fatigue-crack-growth dataset", 0.0,
      note="no default invented; provide a material dataset"),
    P("frac.paris_m", None, "-", Status.UNKNOWN, "Paris-law exponent: supply from a fatigue-crack-growth dataset", 0.0,
      note="no default invented; provide a material dataset"),
)
META = register(ModelMeta(
    model_name="fracture_toughness_process_zone",
    equation="K_Ic = sqrt(E' m sigma_y eps_c l0) ; l0 = d_c (pi/(6 f_c))^(1/3) ; a_c = (K/(Y sigma))^2/pi ; da/dN = C dK^m",
    parameter_source="registry frac.* (ILLUSTRATIVE); Paris C, m are UNKNOWN by default",
    validity_range="plane-strain-like toughness trends from constituent spacing and yield strength; comparative use only",
    fidelity="EMPIRICAL",
))


@dataclass
class FractureResult:
    K_LT_mpa_sqrt_m: float
    K_TL_mpa_sqrt_m: float
    l0_m: float
    constituent_fraction: float


def fracture_toughness(ctx, state: MaterialState, yield_mpa: float) -> FractureResult:  # type: ignore[no-untyped-def]
    ctx.use(META.model_name)
    f_c = max(state.insoluble_constituent_fraction + 0.5 * state.eutectic_fraction, 1e-5)
    l0 = ctx.p("frac.d_constituent") * (math.pi / (6.0 * f_c)) ** (1.0 / 3.0)
    K = math.sqrt(ctx.p("frac.E_eff") * ctx.p("frac.m_cod") * yield_mpa * MPA * ctx.p("frac.eps_c") * l0) / MPA
    g = state.grains
    X = g.recrystallised_fraction if g else 0.0
    K *= 1.0 - ctx.p("frac.gb_loss") * state.gb_precipitate_coverage
    K *= 1.0 - ctx.p("frac.rex_loss") * X
    ar = g.aspect_ratio if g else 1.0
    delam = ctx.p("frac.delam_gain") * math.log(max(ar, 1.0))
    return FractureResult(K * (1.0 + 0.0 * delam), K * (1.0 - delam), l0, f_c)


def critical_flaw_size(ctx, K_mpa_sqrt_m: float, applied_stress_mpa: float) -> float:  # type: ignore[no-untyped-def]
    """a_c in m: (K / (Y sigma))^2 / pi."""
    return (K_mpa_sqrt_m / (ctx.p("frac.Y") * applied_stress_mpa)) ** 2 / math.pi


def paris_growth_rate(ctx, delta_K_mpa_sqrt_m: float) -> float:  # type: ignore[no-untyped-def]
    """da/dN (m/cycle).  Raises ParameterUnknownError until a dataset supplies C and m."""
    ctx.use(META.model_name)
    C, m = ctx.p("frac.paris_C"), ctx.p("frac.paris_m")
    return C * delta_K_mpa_sqrt_m**m


def cycles_to_grow(ctx, a0: float, a_c: float, delta_sigma_mpa: float, n: int = 400) -> float:  # type: ignore[no-untyped-def]
    a = np.geomspace(a0, a_c, n)
    dK = ctx.p("frac.Y") * delta_sigma_mpa * np.sqrt(np.pi * a)
    C, m = ctx.p("frac.paris_C"), ctx.p("frac.paris_m")
    return float(np.trapezoid(1.0 / (C * dK**m), a))


_ = ParameterUnknownError
