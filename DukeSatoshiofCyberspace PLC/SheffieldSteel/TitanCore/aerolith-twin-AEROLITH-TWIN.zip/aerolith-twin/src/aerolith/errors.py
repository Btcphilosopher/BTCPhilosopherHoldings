"""Exception hierarchy."""


class AerolithError(Exception):
    """Base class for all AEROLITH errors."""


class ParameterUnknownError(AerolithError):
    """A model needs a parameter whose value is UNKNOWN and has not been supplied."""


class StrictModeError(AerolithError):
    """Strict mode forbids use of ILLUSTRATIVE / UNKNOWN parameters."""


class CompositionError(AerolithError):
    """Invalid alloy composition."""


class NumericalInstabilityError(AerolithError):
    """A numerical scheme became unstable or failed an internal consistency check."""


class ProvenanceError(AerolithError):
    """Attempt to let an assumed/simulated value masquerade as measured data."""
