"""Shared numerical helpers: implicit slab conduction, convergence tools."""

from __future__ import annotations

import numpy as np
from scipy.linalg import solve_banded


def slab_conduction_implicit(
    T0: np.ndarray, dx: float, dt: float, alpha: float, h_left: float, T_inf_left: float,
    k: float, symmetric_right: bool = True,
) -> np.ndarray:
    """One backward-Euler step of 1-D conduction on a half-slab.

    Node 0 is the surface (convective BC: -k dT/dx = h (T - T_inf)); node n-1 is the
    mid-plane (symmetry).  Finite-volume cell-centred formulation: node 0 is a half cell.
    """
    n = T0.size
    r = alpha * dt / dx**2
    ab = np.zeros((3, n))
    rhs = T0.copy()
    # interior
    ab[1, :] = 1 + 2 * r
    ab[0, 1:] = -r
    ab[2, :-1] = -r
    # surface half-cell: dT/dt = (2/dx)[ (k/dx)(T1-T0) - h(T0-Tinf) ] / (rho cp) ; alpha = k/(rho cp)
    beta = 2.0 * h_left * dt * alpha / (k * dx)
    ab[1, 0] = 1 + 2 * r + beta
    ab[0, 1] = -2 * r
    rhs[0] = T0[0] + beta * T_inf_left
    # mid-plane symmetry: T_n = T_{n-2}
    if symmetric_right:
        ab[1, -1] = 1 + 2 * r
        ab[2, -2] = -2 * r
    return solve_banded((1, 1), ab, rhs)


def observed_order(h: np.ndarray, err: np.ndarray) -> float:
    """Least-squares slope of log(err) vs log(h): observed convergence order."""
    h = np.asarray(h, float)
    err = np.asarray(err, float)
    m = err > 0
    return float(np.polyfit(np.log(h[m]), np.log(err[m]), 1)[0])


def smooth_min(a: float, b: float, q: float = 6.0) -> float:
    """Smooth minimum of two positive numbers (p-norm of reciprocals)."""
    if a <= 0 or b <= 0:
        return 0.0
    return float((a ** (-q) + b ** (-q)) ** (-1.0 / q))


def smoothstep(x: float, lo: float, hi: float) -> float:
    t = np.clip((x - lo) / (hi - lo), 0.0, 1.0)
    return float(t * t * (3 - 2 * t))
