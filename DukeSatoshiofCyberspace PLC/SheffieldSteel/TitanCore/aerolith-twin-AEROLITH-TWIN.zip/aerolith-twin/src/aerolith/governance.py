"""Model governance: every physical model carries metadata."""

from __future__ import annotations

from dataclasses import asdict, dataclass

MODEL_REGISTRY: dict[str, ModelMeta] = {}


@dataclass(frozen=True)
class ModelMeta:
    model_name: str
    equation: str
    parameter_source: str
    validity_range: str
    calibration_dataset: str = "NONE (uncalibrated)"
    uncertainty: str = "see parameter registry / Monte Carlo ensemble"
    revision: str = "0.1.0"
    fidelity: str = "REDUCED-ORDER"  # REDUCED-ORDER / EMPIRICAL / ANALYTICAL / CALIBRATED

    def to_dict(self) -> dict[str, str]:
        return asdict(self)


def register(meta: ModelMeta) -> ModelMeta:
    MODEL_REGISTRY[meta.model_name] = meta
    return meta
