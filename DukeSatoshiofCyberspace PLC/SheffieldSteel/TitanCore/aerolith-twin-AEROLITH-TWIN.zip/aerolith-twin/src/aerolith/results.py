"""Assemble and save machine-readable results (HDF5, Parquet, JSON, CSV) for a TwinRun."""

from __future__ import annotations

from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd

from .digital_twin.twin import TwinRun
from .io.hdf5 import write_hdf5
from .io.json import to_jsonable, write_json
from .io.parquet import write_table
from .params import ParameterRegistry
from .provenance import Provenance


def properties_table(run: TwinRun) -> pd.DataFrame:
    ch = run.true_state.chain
    assert ch.properties is not None
    rows = []
    unc = run.uncertainty.table if run.uncertainty is not None else None
    for name, q in ch.properties.q.items.items():
        row = q.to_dict()
        row["status"] = "SIMULATED"
        if unc is not None and name in unc.index:
            u = unc.loc[name]
            row.update({"sigma": float(u.sigma_total), "ci95": [float(u.ci95_lo), float(u.ci95_hi)], "uncertainty_basis": "Monte Carlo ensemble + model-form"})
        else:
            row["uncertainty_basis"] = "model-form only (no ensemble run)" if q.sigma is not None else "none"
        rows.append(row)
    df = pd.DataFrame(rows)
    df["ci95_lo"] = df.ci95.map(lambda c: c[0] if c else np.nan)
    df["ci95_hi"] = df.ci95.map(lambda c: c[1] if c else np.nan)
    return df.drop(columns=["ci95"])


def assumptions_table(run: TwinRun, registry: ParameterRegistry) -> pd.DataFrame:
    rows = []
    for n, status in sorted(run.meta.get("parameters_in_use", {}).items()):
        p = registry.get(n)
        rows.append({"parameter": n, "value": p.value, "units": p.units, "status": status, "uncertainty_1sigma": p.uncertainty,
                     "validity_min": p.valid_min, "validity_max": p.valid_max, "source": p.source,
                     "label": "ASSUMED" if status in ("ILLUSTRATIVE", "UNKNOWN") else "REFERENCE/LITERATURE" if status != "CALIBRATED" else "CALIBRATED"})
    return pd.DataFrame(rows)


def result_document(run: TwinRun, registry: ParameterRegistry) -> dict[str, Any]:
    ch = run.true_state.chain
    st = ch.state
    props = properties_table(run)
    doc: dict[str, Any] = {
        "metadata": run.meta,
        "disclaimer": "Research / engineering-development digital twin. Not a substitute for certified qualification, laboratory testing, "
                      "standards compliance, destructive testing, NDT qualification, production process qualification, FE certification or airworthiness approval.",
        "batch_id": run.batch_id,
        "composition_wt_percent": run.composition.wt(),
        "route": run.route.model_dump(),
        "genealogy": ch.genealogy.to_dict() if ch.genealogy else None,
        "properties": props,
        "provenance_legend": {p.value: d for p, d in {
            Provenance.MEASURED: "from real laboratory/plant measurements (none in a pure simulation run)",
            Provenance.SIMULATED: "computed by a model in this twin",
            Provenance.ESTIMATED: "twin posterior combining model and (virtual) measurements",
            Provenance.ASSUMED: "parameter/property taken as an assumption (ILLUSTRATIVE or UNKNOWN)"}.items()},
        "material_state": st.summary(),
        "strength_contributions_MPa": ch.properties.strength.contributions() if ch.properties else None,
        "scorecard": run.scorecard,
        "estimated_state": run.estimated,
        "inspection": ({k: v for k, v in to_jsonable(run.inspection).items() if k not in ("pod_by_id",)} if run.inspection else None),
        "qualification": run.qualification,
        "warnings": ch.warnings,
        "assumptions": assumptions_table(run, registry),
    }
    if run.uncertainty is not None:
        doc["uncertainty"] = run.uncertainty.table.reset_index()
    return doc


def save_all(run: TwinRun, registry: ParameterRegistry, outdir: str | Path, stem: str = "result") -> dict[str, Path]:
    out = Path(outdir)
    out.mkdir(parents=True, exist_ok=True)
    ch = run.true_state.chain
    meta = {**run.meta, "batch_id": run.batch_id}
    props = properties_table(run)
    defects = ch.state.defects.to_dataframe()
    tel = run.measured.telemetry
    assum = assumptions_table(run, registry)
    paths = {
        "json": out / f"{stem}.json", "hdf5": out / f"{stem}.h5", "parquet_properties": out / f"{stem}_properties.parquet",
        "parquet_defects": out / f"{stem}_defects.parquet", "parquet_telemetry": out / f"{stem}_telemetry.parquet",
        "csv_properties": out / f"{stem}_properties.csv", "csv_defects": out / f"{stem}_defects.csv", "csv_assumptions": out / f"{stem}_assumptions.csv",
    }
    write_json(result_document(run, registry), paths["json"])
    write_table(props, paths["parquet_properties"], meta)
    write_table(defects, paths["parquet_defects"], meta)
    if not tel.empty:
        write_table(tel, paths["parquet_telemetry"], meta)
    props.to_csv(paths["csv_properties"], index=False)
    defects.to_csv(paths["csv_defects"], index=False)
    assum.to_csv(paths["csv_assumptions"], index=False)
    arrays: dict[str, dict[str, np.ndarray]] = {}
    st = ch.state
    arrays["precipitates"] = {"radius_m": st.precip.r, **{f"n_{k}": v for k, v in st.precip.n.items()}}
    ar = ch.stage_results.get("ageing", {}).get("result")
    if ar is not None:
        pr = ar.precipitation
        arrays["ageing"] = {"t_s": pr.t_s, "T_K": pr.T_K, "strengthening_MPa": ar.strengthening_mpa,
                            **{f"f_{k}": v for k, v in pr.volume_fraction.items()}, **{f"r_{k}_m": v for k, v in pr.mean_radius_m.items()}}
    qr = ch.stage_results.get("quench", {}).get("result")
    if qr is not None:
        arrays["quench"] = {"t_s": qr.t_s, "x_m": qr.x_m, "T_xt_K": qr.T_xt_K, "residual_stress_Pa": qr.residual.sigma_pa}
    sol = ch.stage_results["casting"]["solidification"]
    arrays["casting"] = {"x_m": sol.x_m, "t_liq_s": sol.t_liq_s, "t_sol_s": sol.t_sol_s, "cooling_rate_K_s": sol.cooling_rate_K_s}
    if st.grains:
        d, pdf = st.grains.size_distribution()
        arrays["grains"] = {"diameter_m": d, "pdf": pdf}
    arrays["texture"] = {"weights": np.array(list(st.texture.normalised().values())), "components": np.array(list(st.texture.normalised().keys()), dtype="S")}
    write_hdf5(paths["hdf5"], meta, {"properties": props.set_index("name"), "defects": defects, "assumptions": assum}, arrays,
               {"genealogy": ch.genealogy.to_dict() if ch.genealogy else {}, "scorecard": run.scorecard})
    return paths
