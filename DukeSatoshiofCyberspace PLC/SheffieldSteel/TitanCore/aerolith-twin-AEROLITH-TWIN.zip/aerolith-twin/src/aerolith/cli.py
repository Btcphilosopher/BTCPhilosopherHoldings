"""Command-line interface:  aerolith simulate|process|heat-treatment|predict|calibrate|optimise|inspect|report <file>"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np
import pandas as pd
import yaml

from . import DISCLAIMER, __version__
from .context import RunContext
from .digital_twin.twin import AerolithTwin, uncertainty_report
from .io.json import to_jsonable, write_json
from .manufacturing.process_chain import run_route
from .params import ParameterRegistry, default_registry
from .specs import Spec, load_spec


def _registry(args: argparse.Namespace) -> ParameterRegistry:
    reg = default_registry()
    if getattr(args, "params", None):
        reg = ParameterRegistry.from_yaml(args.params, reg)
    return reg


def _banner(reg: ParameterRegistry) -> None:
    print(f"AEROLITH-TWIN {__version__} · {reg.version()}")
    print(DISCLAIMER, file=sys.stderr)


def _outdir(spec: Spec, args: argparse.Namespace) -> Path:
    p = Path(args.outdir or spec.options.outdir)
    p.mkdir(parents=True, exist_ok=True)
    return p


def _print_props(ch) -> None:  # type: ignore[no-untyped-def]
    assert ch.properties is not None
    for name in ("density", "E_L", "yield_strength", "uts", "elongation", "fracture_toughness", "fatigue_strength_1e7", "specific_strength", "corrosion_index"):
        print("  " + str(ch.properties.q[name]).replace("[SIMULATED]", "[SIMULATED]").ljust(60), name)


def cmd_stage(args: argparse.Namespace, until: str) -> int:
    spec = load_spec(args.file)
    reg = _registry(args)
    _banner(reg)
    ctx = RunContext(reg, np.random.default_rng(spec.options.seed), strict=args.strict or spec.options.strict)
    ch = run_route(ctx, spec.composition, spec.route, spec.batch_id, until=until, keep_snapshots=False)
    out = _outdir(spec, args)
    print(ch.genealogy.to_text() if ch.genealogy else "")
    st = ch.state
    print(f"\nstage reached: {ch.reached}")
    print("microstructure:", json.dumps(to_jsonable({k: v for k, v in st.summary().items() if k in ("eutectic_fraction", "dislocation_density_m2", "grains", "texture_index")}), indent=1)[:900])
    if ch.properties is not None:
        print("properties (SIMULATED):")
        _print_props(ch)
    for w in ch.warnings:
        print("WARNING:", w, file=sys.stderr)
    write_json({"stage": ch.reached, "summary": st.summary(), "genealogy": ch.genealogy.to_dict() if ch.genealogy else None, "warnings": ch.warnings,
                "parameter_status_in_use": ctx.ledger_summary(), "parameter_version": reg.version()}, out / f"{Path(args.file).stem}_{until}.json")
    print(f"\nwritten: {out / (Path(args.file).stem + '_' + until + '.json')}")
    return 0


def cmd_predict(args: argparse.Namespace) -> int:
    spec = load_spec(args.file)
    reg = _registry(args)
    _banner(reg)
    n = args.n or spec.options.n_ensemble or 24
    rep = uncertainty_report(reg, spec.composition, spec.route, n, seed=spec.options.seed + 1, per_source=not args.fast)
    t = rep.table
    pd.set_option("display.width", 200)
    print(t[["mean", "sigma_total", "ci95_lo", "ci95_hi"]].round(3).to_string())
    out = _outdir(spec, args)
    t.reset_index().to_csv(out / "prediction.csv", index=False)
    write_json({"parameter_version": reg.version(), "n": n, "table": t.reset_index()}, out / "prediction.json")
    print("\nNOTE: intervals reflect prior widths of the parameters in the registry; ILLUSTRATIVE parameters give placeholder widths.")
    print(f"written: {out / 'prediction.csv'}")
    return 0


def cmd_inspect(args: argparse.Namespace) -> int:
    from .inspection.defect_detection import inspect_batch

    spec = load_spec(args.file)
    reg = _registry(args)
    _banner(reg)
    ctx = RunContext(reg, np.random.default_rng(spec.options.seed))
    ch = run_route(ctx, spec.composition, spec.route, spec.batch_id, keep_snapshots=False)
    assert ch.properties is not None
    nd = inspect_batch(ctx, ch.state, spec.options.inspect_methods, spec.criteria, ch.properties.density_kg_m3,
                       0.5 * ch.properties.values()["yield_strength"], ch.properties.values()["fracture_toughness"])
    print(f"methods {nd.methods}: true defects {nd.n_true}, detected {nd.n_detected} (expected {nd.expected_detections:.1f}); "
          f"largest missed {nd.largest_missed_size_m * 1e3:.2f} mm (a/a_c = {nd.largest_missed_severity:.2f})")
    print("rejected:", "not assessed — no acceptance criteria supplied" if nd.rejected is None else nd.rejected, nd.reject_reasons[:5])
    out = _outdir(spec, args)
    df = ch.state.defects.to_dataframe()
    df["pod"] = df.id.map(nd.pod_by_id)
    df.to_csv(out / "inspection_defects.csv", index=False)
    write_json({"summary": {k: v for k, v in to_jsonable(nd).items() if k != "pod_by_id"}, "parameter_version": reg.version()}, out / "inspection.json")
    print(f"written: {out / 'inspection.csv'}" if False else f"written: {out / 'inspection.json'}")
    return 0


def cmd_report(args: argparse.Namespace) -> int:
    from .report import build_report
    from .results import save_all

    spec = load_spec(args.file)
    reg = _registry(args)
    _banner(reg)
    tw = AerolithTwin(reg, strict=args.strict or spec.options.strict, seed=spec.options.seed)
    run = tw.run(spec.composition, spec.route, spec.batch_id, n_ensemble=args.n or spec.options.n_ensemble, n_posterior=spec.options.n_posterior,
                 criteria=spec.criteria, qual=spec.qualification, methods=spec.options.inspect_methods, frozen_time=spec.options.frozen_time)
    out = _outdir(spec, args)
    paths = save_all(run, reg, out, "result")
    rp = build_report(run, reg, out, "report")
    for k, v in {**paths, "report": rp}.items():
        print(f"{k:22s} {v}")
    return 0


def cmd_calibrate(args: argparse.Namespace) -> int:
    from .calibration.models import strength_from_microstructure
    from .calibration.parameter_fit import calibrate
    from .io.parquet import read_table

    reg = _registry(args)
    _banner(reg)
    p = Path(args.file)
    if p.suffix == ".parquet":
        df, meta = read_table(p)
    else:
        df, meta = pd.read_csv(p), {}
    if meta.get("provenance", "").startswith("SYNTHETIC"):
        print("NOTE: dataset is SYNTHETIC (software-verification data); calibrated values must not be used as material data.", file=sys.stderr)
    params = args.fit or ["str.k_y", "str.alpha_taylor", "str.eff.T1", "str.k_ss.Cu"]
    targets = args.targets or ["yield_strength"]
    sig = {t: f"{t}_sigma" for t in targets}
    res = calibrate(reg, df, strength_from_microstructure, params, targets, sig, dataset_id=str(meta.get("dataset_id", p.stem)))
    print(f"train n={res.n_train}  validation n={res.n_validation}  converged={res.success}")
    for n, v in res.parameters.items():
        print(f"  {n:24s} {res.initial[n]:.4g} -> {v:.4g}  (±{res.sigma_estimate[n]:.2g})")
    print("  train RMSE", {k: round(v, 3) for k, v in res.train_rmse.items()}, " validation RMSE", {k: round(v, 3) for k, v in res.validation_rmse.items()})
    out = Path(args.outdir or "results")
    out.mkdir(parents=True, exist_ok=True)
    res.calibrated_registry.to_yaml(out / "calibrated_parameters.yaml")
    write_json({"parameters": res.parameters, "initial": res.initial, "sigma": res.sigma_estimate, "train_rmse": res.train_rmse, "validation_rmse": res.validation_rmse,
                "train_r2": res.train_r2, "validation_r2": res.validation_r2, "dataset_id": res.dataset_id,
                "parameter_version": res.calibrated_registry.version()}, out / "calibration.json")
    print(f"written: {out / 'calibrated_parameters.yaml'}")
    return 0


def cmd_optimise(args: argparse.Namespace) -> int:
    from .optimisation.multiobjective import OBJECTIVES
    from .optimisation.process import Constraint, DesignSpace, optimise_route

    raw = yaml.safe_load(Path(args.file).read_text())
    reg = _registry(args)
    _banner(reg)
    objectives = raw.get("objectives") or ["specific_strength", "fracture_toughness", "cost_usd_kg"]
    bad = [o for o in objectives if o not in OBJECTIVES or o == "robustness"]
    if bad:
        raise SystemExit(f"unknown objective(s) {bad}; available: {[o for o in OBJECTIVES if o != 'robustness']}")
    cons = [Constraint(c["output"], c.get("minimum"), c.get("maximum")) for c in raw.get("constraints", [])]
    space = DesignSpace()
    space.bounds.update({k: tuple(v) for k, v in (raw.get("bounds") or {}).items()})
    print("objectives:", ", ".join(f"{'MAX' if OBJECTIVES[o][0] > 0 else 'MIN'} {o}" for o in objectives))
    print("constraints:", cons or "none")
    res, df, _ = optimise_route(reg, objectives, cons, space, int(raw.get("population", 16)), int(raw.get("generations", 6)), int(raw.get("seed", 0)))
    out = Path(args.outdir or raw.get("outdir", "results"))
    out.mkdir(parents=True, exist_ok=True)
    df.to_csv(out / "pareto_front.csv", index=False)
    print(f"\n{len(df)} NON-DOMINATED material/process combinations after {res.n_evaluations} evaluations (no single 'best' alloy):")
    pd.set_option("display.width", 220)
    print(df.round(3).head(15).to_string())
    from .viz.figures import pareto_plot

    pareto_plot(df, objectives).savefig(out / "pareto_front.png", bbox_inches="tight")
    print(f"written: {out / 'pareto_front.csv'}")
    return 0


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(prog="aerolith", description="AEROLITH-TWIN: aerospace Al-Li manufacturing digital twin (research software)")
    ap.add_argument("--version", action="version", version=__version__)
    sub = ap.add_subparsers(dest="cmd", required=True)

    def add(name: str, help_: str):  # type: ignore[no-untyped-def]
        p = sub.add_parser(name, help=help_)
        p.add_argument("file")
        p.add_argument("--outdir")
        p.add_argument("--params", help="parameter YAML (e.g. calibrated_parameters.yaml)")
        p.add_argument("--strict", action="store_true", help="refuse to run with ILLUSTRATIVE/UNKNOWN parameters")
        return p

    add("simulate", "alloy.yaml: melt, casting and homogenisation")
    add("process", "process.yaml: through thermomechanical processing")
    add("heat-treatment", "recipe.yaml: solution, quench, stretch and ageing (full chain)")
    p = add("predict", "sample.yaml: full chain with Monte Carlo uncertainty"); p.add_argument("-n", type=int); p.add_argument("--fast", action="store_true")
    p = add("calibrate", "dataset.parquet: calibrate microstructure->strength parameters"); p.add_argument("--fit", nargs="+"); p.add_argument("--targets", nargs="+")
    add("optimise", "objective.yaml: multi-objective material + process optimisation")
    add("inspect", "batch.yaml: simulated NDT of the batch")
    p = add("report", "batch.yaml: full twin run, results files and engineering report"); p.add_argument("-n", type=int)
    a = ap.parse_args(argv)
    return {"simulate": lambda: cmd_stage(a, "homogenised"), "process": lambda: cmd_stage(a, "deformed"), "heat-treatment": lambda: cmd_stage(a, "aged"),
            "predict": lambda: cmd_predict(a), "calibrate": lambda: cmd_calibrate(a), "optimise": lambda: cmd_optimise(a), "inspect": lambda: cmd_inspect(a),
            "report": lambda: cmd_report(a)}[a.cmd]()


if __name__ == "__main__":
    raise SystemExit(main())
