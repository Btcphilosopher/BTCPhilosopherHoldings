"""Rolling-mill stand: capacity checks and gauge (mill-stretch) deviation."""

from __future__ import annotations

from dataclasses import dataclass, field

from ..governance import ModelMeta, register
from ..params import P, Status, declare
from ..processing.rolling import RollingResult

declare(
    P("mill.stiffness", 8.0e9, "N/m", Status.ILLUSTRATIVE, "mill modulus (stand stretch stiffness)", 0.3, 1e8, 1e11, True),
    P("mill.max_force", 3.0e7, "N", Status.ILLUSTRATIVE, "stand separating-force limit", 0.1, 1e5, 1e9, True),
    P("mill.max_power", 8.0e6, "W", Status.ILLUSTRATIVE, "main-drive power limit", 0.1, 1e4, 1e9, True),
)
META = register(ModelMeta(
    model_name="rolling_mill_capacity",
    equation="dh = F / K_mill ; checks F <= F_max, P <= P_max",
    parameter_source="registry mill.* (ILLUSTRATIVE)",
    validity_range="single stand, quasi-static; no roll thermal crown, no roll flattening",
    fidelity="ANALYTICAL",
))


@dataclass
class MillReport:
    gauge_deviation_m: float
    force_utilisation: float
    power_utilisation: float
    warnings: list[str] = field(default_factory=list)


def check_mill(ctx, res: RollingResult) -> MillReport:  # type: ignore[no-untyped-def]
    ctx.use(META.model_name)
    w: list[str] = []
    fu = res.max_force_n / ctx.p("mill.max_force")
    pu = res.max_power_w / ctx.p("mill.max_power")
    if fu > 1.0:
        w.append(f"mill force limit exceeded ({fu:.2f}x): reduce per-pass reduction or raise temperature")
    if pu > 1.0:
        w.append(f"mill power limit exceeded ({pu:.2f}x)")
    return MillReport(res.max_force_n / ctx.p("mill.stiffness"), fu, pu, w)
