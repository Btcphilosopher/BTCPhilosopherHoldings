"""User-facing process specification (explicit units in field names) and conversion to SI."""

from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, ConfigDict, Field

from ..units import KELVIN_OFFSET


def C(t_c: float) -> float:
    """degC -> K (single explicit conversion point for the specification layer)."""
    return t_c + KELVIN_OFFSET


class _M(BaseModel):
    model_config = ConfigDict(extra="forbid")


class CastSpec(_M):
    pour_temperature_C: float = 740.0
    mould_temperature_C: float = 60.0
    section_thickness_mm: float = 400.0
    cooling_rate_K_s: float | None = None
    hydrogen_ml_per_100g: float = 0.12
    oxide_film_index: float = 1.0
    block_length_mm: float = 300.0
    block_width_mm: float = 300.0


class HomogStep(_M):
    temperature_C: float
    hold_h: float


class HomogSpec(_M):
    steps: list[HomogStep] = Field(default_factory=lambda: [HomogStep(temperature_C=440.0, hold_h=12.0),
                                                            HomogStep(temperature_C=500.0, hold_h=12.0)])
    heating_rate_K_min: float = 3.0
    cool_to_C: float = 400.0
    cool_rate_K_min: float = 1.2


class RollingSpec(_M):
    final_thickness_mm: float = 25.0
    passes: int = 12
    entry_temperature_C: float = 430.0
    roll_radius_mm: float = 500.0
    roll_speed_m_s: float = 1.0
    interpass_s: float = 30.0
    roll_temperature_C: float = 100.0
    reduction_per_pass: list[float] | None = None


class ForgingSpec(_M):
    forging_temperature_C: float = 430.0
    true_strain_per_step: float = 0.25
    n_steps: int = 4
    strain_rate_s: float = 0.1
    die_temperature_C: float = 200.0


class ExtrusionSpec(_M):
    billet_temperature_C: float = 430.0
    reduction_ratio: float = 15.0
    ram_speed_m_s: float = 0.005


class DeformationSpec(_M):
    type: Literal["rolling", "forging", "extrusion"] = "rolling"
    rolling: RollingSpec = Field(default_factory=RollingSpec)
    forging: ForgingSpec = Field(default_factory=ForgingSpec)
    extrusion: ExtrusionSpec = Field(default_factory=ExtrusionSpec)


class SolutionSpec(_M):
    temperature_C: float = 510.0
    hold_min: float = 60.0
    heating_rate_K_min: float = 3.0


class QuenchSpec(_M):
    medium: str = "cold_water"
    tank_temperature_C: float = 20.0
    flow_m_s: float = 1.0
    asymmetry: float = 1.0
    transfer_delay_s: float = 10.0
    stretch_percent: float = 3.0


class AgeingSpec(_M):
    natural_h: float = 0.0
    temperature_C: float = 165.0
    time_h: float = 48.0


class RouteSpec(_M):
    casting: CastSpec = Field(default_factory=CastSpec)
    homogenisation: HomogSpec = Field(default_factory=HomogSpec)
    deformation: DeformationSpec = Field(default_factory=DeformationSpec)
    solution: SolutionSpec = Field(default_factory=SolutionSpec)
    quench: QuenchSpec = Field(default_factory=QuenchSpec)
    ageing: AgeingSpec = Field(default_factory=AgeingSpec)
    surface_condition: str = "machined"
