"""Furnace / part thermal response: set-point -> furnace air -> part (lumped) with offset and uniformity error."""

from __future__ import annotations

import math
from dataclasses import dataclass

import numpy as np

from ..governance import ModelMeta, register
from ..homogenisation.thermal_cycle import ThermalCycle, ThermalRecord
from ..params import P, Status, declare

declare(
    P("furnace.tau_air", 240.0, "s", Status.ILLUSTRATIVE, "furnace air first-order lag behind the set-point", 0.3, 5.0, 3600.0, True),
    P("furnace.h_part", 35.0, "W/m2/K", Status.ILLUSTRATIVE, "furnace-to-part heat-transfer coefficient (air furnace)", 0.3, 5.0, 500.0, True),
    P("furnace.uniformity_K", 3.0, "K", Status.ILLUSTRATIVE, "1-sigma temperature uniformity/offset error of the furnace at the part", 0.0, 0.0, 30.0),
)
META = register(ModelMeta(
    model_name="furnace_part_thermal_lag",
    equation="tau_f dTf/dt = Tset + dT_off - Tf ; tau_p dTp/dt = Tf - Tp ; tau_p = rho cp (H/2)/h",
    parameter_source="registry furnace.* (ILLUSTRATIVE)",
    validity_range="air furnaces, plates up to ~0.5 m; lumped part (Bi < ~1); no load-dependent recovery",
))


@dataclass
class FurnaceRealisation:
    furnace: ThermalRecord
    part: ThermalCycle
    offset_K: float
    tau_part_s: float


def realise(ctx, setpoint: ThermalCycle, thickness_m: float, name: str = "furnace", offset_K: float | None = None,  # type: ignore[no-untyped-def]
            n: int = 600, T_start_K: float | None = None) -> FurnaceRealisation:
    """True furnace-air and part temperature histories for a set-point schedule."""
    ctx.use(META.model_name)
    off = float(ctx.rng.normal(0.0, ctx.p("furnace.uniformity_K"))) if offset_K is None else offset_K
    tau_f = ctx.p("furnace.tau_air")
    tau_p = 2650.0 * ctx.p("def.cp") * 0.5 * thickness_m / ctx.p("furnace.h_part")
    t = np.linspace(setpoint.t_s[0], setpoint.t_s[-1], n)
    Tset = setpoint.T_at(t) + off
    Tf = np.empty(n)
    Tp = np.empty(n)
    Tf[0] = Tp[0] = T_start_K if T_start_K is not None else setpoint.T_K[0]
    for i in range(1, n):
        dt = t[i] - t[i - 1]
        a = math.exp(-dt / tau_f)
        Tf[i] = Tset[i - 1] * (1 - a) + Tf[i - 1] * a
        b = math.exp(-dt / tau_p)
        Tp[i] = Tf[i] * (1 - b) + Tp[i - 1] * b
    part = ThermalCycle(t - t[0], Tp, name + "-part")
    return FurnaceRealisation(ThermalRecord(name, t - t[0], Tf, {"setpoint_K": Tset}), part, off, tau_p)
