"""Quench tank: agitation -> heat-transfer scaling, and tank energy balance (bulk temperature rise)."""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from ..governance import ModelMeta, register
from ..heat_treatment.quench import QuenchInputs
from ..params import P, Status, declare

declare(
    P("qsys.flow_nom", 1.0, "m/s", Status.ILLUSTRATIVE, "nominal tank agitation velocity at which the h-curve was defined", 0.0),
    P("qsys.flow_exp", 0.5, "-", Status.ILLUSTRATIVE, "h scales as (flow/flow_nom)^exp", 0.1, 0.1, 1.0),
    P("qsys.tank_mass", 2.0e4, "kg", Status.ILLUSTRATIVE, "mass of quenchant in the tank", 0.1, 100.0, 1e7, True),
    P("qsys.cp_medium", 4180.0, "J/kg/K", Status.REFERENCE, "specific heat of water-based quenchant", 40.0),
)
META = register(ModelMeta(
    model_name="quench_tank_energy_balance",
    equation="h_scale = (flow/flow_nom)^n ; m_t c_m dT_tank = m_p c_p (T_part_initial - T_final)",
    parameter_source="registry qsys.* (ILLUSTRATIVE)",
    validity_range="well-mixed tank; neglects surface evaporation and refrigeration",
    fidelity="ANALYTICAL",
))


@dataclass
class QuenchTank:
    medium: str = "cold_water"
    temperature_K: float = 293.0
    flow_m_s: float = 1.0
    asymmetry: float = 1.0
    transfer_delay_s: float = 10.0

    def inputs(self, ctx, initial_T_K: float, thickness_m: float, stretch: float) -> QuenchInputs:  # type: ignore[no-untyped-def]
        ctx.use(META.model_name)
        hs = (self.flow_m_s / ctx.p("qsys.flow_nom")) ** ctx.p("qsys.flow_exp")
        return QuenchInputs(initial_T_K, self.medium, thickness_m, self.temperature_K, hs, self.asymmetry,
                            self.transfer_delay_s, stretch)


def tank_temperature_rise(ctx, part_mass_kg: float, T_part_initial: float, T_final: float) -> float:  # type: ignore[no-untyped-def]
    """Bulk tank temperature rise (K) from the energy balance."""
    return float(part_mass_kg * ctx.p("def.cp") * (T_part_initial - T_final) / (ctx.p("qsys.tank_mass") * ctx.p("qsys.cp_medium")))


def tank_trace(ctx, t: np.ndarray, T_mean_part: np.ndarray, part_mass_kg: float, T_tank0: float) -> np.ndarray:  # type: ignore[no-untyped-def]
    """Tank temperature vs time from the instantaneous heat removed from the part."""
    removed = part_mass_kg * ctx.p("def.cp") * (T_mean_part[0] - T_mean_part)
    return T_tank0 + removed / (ctx.p("qsys.tank_mass") * ctx.p("qsys.cp_medium"))
