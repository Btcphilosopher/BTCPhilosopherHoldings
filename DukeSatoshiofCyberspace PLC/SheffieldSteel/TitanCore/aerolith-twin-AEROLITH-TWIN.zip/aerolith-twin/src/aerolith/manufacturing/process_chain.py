"""The complete process chain: composition -> melt -> casting -> homogenisation -> deformation -> solution
-> quench (+stretch) -> ageing -> properties.  Every stage passes the MaterialState to the next and
writes a node into the batch genealogy."""

from __future__ import annotations

import hashlib
import json
import math
from dataclasses import dataclass, field
from typing import Any

import numpy as np

from ..casting import defects as cast_defects
from ..casting import grain as cast_grain
from ..casting import segregation as cast_seg
from ..casting import solidification as cast_sol
from ..chemistry.composition import Composition
from ..chemistry.elements import ATOMIC_MASS_G_MOL
from ..chemistry.validation import check_composition
from ..context import RunContext
from ..heat_treatment import ageing as ht_age
from ..heat_treatment import precipitation as ht_prec
from ..heat_treatment import quench as ht_quench
from ..heat_treatment import solution as ht_sol
from ..homogenisation import precipitation_dissolution as hom
from ..homogenisation.thermal_cycle import ThermalCycle
from ..microstructure.state import MaterialState, wt_to_atom_fraction_scale
from ..processing import extrusion as p_ext
from ..processing import forging as p_forge
from ..processing import rolling as p_roll
from ..properties import density
from ..properties.evaluate import PropertySet, evaluate_properties
from . import furnace, quench_system, rolling_mill
from .cost import CostResult, route_cost
from .spec import C, RouteSpec
from .traceability import BatchGenealogy

STAGES = ("cast", "homogenised", "deformed", "solution_treated", "quenched", "aged")

_CAST_CACHE: dict[str, Any] = {}


@dataclass
class ChainResult:
    batch_id: str
    composition: Composition
    route: RouteSpec
    state: MaterialState
    snapshots: dict[str, MaterialState] = field(default_factory=dict)
    stage_results: dict[str, Any] = field(default_factory=dict)
    signals: dict[str, tuple[np.ndarray, np.ndarray, str]] = field(default_factory=dict)
    genealogy: BatchGenealogy | None = None
    properties: PropertySet | None = None
    cost: CostResult | None = None
    warnings: list[str] = field(default_factory=list)
    reached: str = "cast"
    input_hash: str = ""


def route_hash(comp: Composition, route: RouteSpec) -> str:
    blob = json.dumps({"c": comp.wt(), "r": route.model_dump()}, sort_keys=True, default=str).encode()
    return hashlib.sha256(blob).hexdigest()[:16]


def homogenisation_setpoint(spec) -> ThermalCycle:  # type: ignore[no-untyped-def]
    rate = spec.heating_rate_K_min / 60.0
    t, T = [0.0], [293.0]
    for st in spec.steps:
        Ts = C(st.temperature_C)
        t.append(t[-1] + abs(Ts - T[-1]) / rate)
        T.append(Ts)
        t.append(t[-1] + st.hold_h * 3600.0)
        T.append(Ts)
    Tend = C(spec.cool_to_C)
    t.append(t[-1] + abs(T[-1] - Tend) / (spec.cool_rate_K_min / 60.0))
    T.append(Tend)
    return ThermalCycle(np.array(t), np.array(T), "homogenisation-setpoint")


def _cast_key(ctx: RunContext, comp: Composition, inp: cast_sol.CastingInputs) -> str:
    cp = {n: ctx.registry.get(n).value for n in ctx.registry.names() if n.startswith("cast.") or n.startswith("density.")}
    wt = {k: round(v * 4) / 4 for k, v in comp.wt().items()}
    return hashlib.sha256(json.dumps([wt, inp.__dict__, cp], sort_keys=True, default=str).encode()).hexdigest()


def cast_stage(ctx: RunContext, comp: Composition, spec, use_cache: bool = True) -> tuple[MaterialState, Any, Any, cast_sol.CastingInputs]:  # type: ignore[no-untyped-def]
    inp = cast_sol.CastingInputs(C(spec.pour_temperature_C), C(spec.mould_temperature_C), spec.section_thickness_mm / 1000.0,
                                 spec.cooling_rate_K_s, spec.hydrogen_ml_per_100g, spec.oxide_film_index)
    key = _cast_key(ctx, comp, inp)
    if use_cache and key in _CAST_CACHE:
        sol = _CAST_CACHE[key]
        ctx.use(cast_sol.META.model_name)
    else:
        sol = cast_sol.simulate_solidification(ctx, comp, inp)
        if use_cache:
            _CAST_CACHE[key] = sol
    seg = cast_seg.microsegregation(ctx, comp, sol)
    gr = cast_grain.as_cast_grains(ctx, comp, sol)
    L, W, H = spec.block_length_mm / 1000.0, spec.block_width_mm / 1000.0, inp.section_thickness_m
    pop = cast_defects.generate_cast_defects(ctx, comp, sol, seg, inp, L * W * H, (L, W, H))
    st = MaterialState(comp, (L, W, H), "cast", "as-cast")
    st.grains, st.defects, st.lambda2_m = gr, pop, seg.lambda2_m
    for el in seg.C0_wt:
        st.profiles_wt[el] = seg.matrix_profile(el, 64).copy()
    st.eutectic_solute_wt = dict(seg.eutectic_solute_wt)
    st.eutectic_fraction_initial = st.eutectic_fraction = seg.f_eutectic * ctx.p("homog.eutectic_phase_fraction")
    rho = density.density_kg_m3(ctx, comp).value
    st.insoluble_constituent_fraction = hom.initial_constituents(ctx, comp, rho)
    st.constituent_radius_m = ctx.p("homog.constituent_size_factor") * seg.lambda2_m
    scale = wt_to_atom_fraction_scale(comp)
    st.solute_pool_at = {el: max(comp.wt()[el] - seg.eutectic_solute_wt.get(el, 0.0), 0.0) / ATOMIC_MASS_G_MOL[el] / scale
                         for el in ("Li", "Cu", "Zr", "Sc")}
    st.peak_temperature_K = inp.pour_temperature_K
    st.log("cast", **{k: float(v) for k, v in sol.at_centre().items()}, f_eutectic=seg.f_eutectic, lambda2_m=seg.lambda2_m)
    return st, sol, seg, inp


def run_route(ctx: RunContext, comp: Composition, route: RouteSpec, batch_id: str = "AL-LI-000421", until: str = "aged",
              keep_snapshots: bool = True, mass_kg: float = 1000.0, evaluate: bool = True,
              frozen_time: str | None = None, use_cast_cache: bool = True) -> ChainResult:
    if until not in STAGES:
        raise ValueError(f"until must be one of {STAGES}")
    last = STAGES.index(until)
    gen = BatchGenealogy(batch_id, chemistry=comp.wt(), frozen_time=frozen_time)
    res = ChainResult(batch_id, comp, route, None, genealogy=gen, input_hash=route_hash(comp, route))  # type: ignore[arg-type]
    for iss in check_composition(comp):
        if iss.severity != "INFO":
            ctx.warn(f"composition: {iss.message}")
    # ---- melt + cast -----------------------------------------------------------------------------------------------
    gen.add("MELT", {"composition_wt": comp.wt(), "hydrogen_ml_per_100g": route.casting.hydrogen_ml_per_100g,
                     "oxide_film_index": route.casting.oxide_film_index}, {"label": comp.label})
    st, sol, seg, inp = cast_stage(ctx, comp, route.casting, use_cast_cache)
    res.stage_results["casting"] = {"solidification": sol, "segregation": seg, "inputs": inp}
    gen.add("CAST", {"pour_K": inp.pour_temperature_K, "mould_K": inp.mould_temperature_K, "thickness_m": inp.section_thickness_m},
            {**sol.at_centre(), "f_eutectic": seg.f_eutectic, "defects": st.defects.summary()})
    res.signals["cast_centre_T"] = (sol.history.t_s, sol.history.T_centre_K, "K")
    res.signals["cast_surface_T"] = (sol.history.t_s, sol.history.T_surface_K, "K")
    if keep_snapshots:
        res.snapshots["cast"] = st.copy()
    res.state, res.reached = st, "cast"
    # ---- homogenisation ----------------------------------------------------------------------------------------------
    if last >= 1:
        sp = homogenisation_setpoint(route.homogenisation)
        fr = furnace.realise(ctx, sp, st.dims_m[2], "homogenisation")
        t_steps = [C(s.temperature_C) for s in route.homogenisation.steps]
        st.dispersoid_free_fraction = hom.dispersoid_free_fraction(ctx, st, float(max(t_steps)))
        info = hom.apply_homogenisation(ctx, st, fr.part)
        ht_prec.run_precipitation(ctx, st, fr.part, n_out=12)
        st.dispersoid_free_fraction = hom.dispersoid_free_fraction(ctx, st, float(fr.part.peak_K()))
        st.stage, st.temper = "homogenised", "H"
        res.stage_results["homogenisation"] = {"info": info, "furnace": fr}
        res.signals["homogenisation_furnace_T"] = (fr.furnace.t_s, fr.furnace.T_K, "K")
        res.signals["homogenisation_part_T"] = (fr.part.t_s, fr.part.T_K, "K")
        gen.add("HOMOGENISATION", {"steps": [s.model_dump() for s in route.homogenisation.steps]},
                {k: float(v) for k, v in info.items() if isinstance(v, float)})
        st.log("homogenisation", **{k: float(v) for k, v in info.items() if isinstance(v, float)})
        if keep_snapshots:
            res.snapshots["homogenised"] = st.copy()
        res.reached = "homogenised"
    # ---- deformation --------------------------------------------------------------------------------------------------
    if last >= 2:
        d = route.deformation
        if d.type == "rolling":
            r = d.rolling
            sched = p_roll.RollingSchedule(st.dims_m[2], r.final_thickness_mm / 1000.0, r.passes, st.dims_m[1], r.roll_radius_mm / 1000.0,
                                           r.roll_speed_m_s, C(r.entry_temperature_C), C(r.roll_temperature_C), r.interpass_s,
                                           r.reduction_per_pass)
            rr = p_roll.roll_plate(ctx, st, sched)
            mill = rolling_mill.check_mill(ctx, rr)
            for w in mill.warnings:
                ctx.warn(w)
            res.stage_results["deformation"] = {"result": rr, "mill": mill}
            h = rr.history
            tpass = np.array([s.time_s for s in h.steps])
            res.signals["rolling_force"] = (tpass, np.array([s.force_n for s in h.steps]), "N")
            res.signals["rolling_speed"] = (tpass, np.full(len(h.steps), r.roll_speed_m_s), "m/s")
            res.signals["strain"] = (tpass, np.cumsum([s.true_strain for s in h.steps]), "-")
            res.signals["strain_rate"] = (tpass, np.array([s.strain_rate_s for s in h.steps]), "1/s")
            res.signals["rolling_temperature"] = (rr.realised["t_s"], rr.realised["T_K"], "K")
            summ = {"passes": r.passes, "max_force_n": rr.max_force_n, "reduction_ratio": rr.thickness_m[0] / rr.thickness_m[-1],
                    "X_final": rr.X_final}
        elif d.type == "forging":
            f = d.forging
            fr_ = p_forge.forge(ctx, st, p_forge.ForgingSchedule(C(f.forging_temperature_C), f.true_strain_per_step, f.n_steps,
                                                                 f.strain_rate_s, die_temperature_K=C(f.die_temperature_C)))
            res.stage_results["deformation"] = {"result": fr_}
            h = fr_.history
            tpass = np.array([s.time_s for s in h.steps])
            res.signals["rolling_force"] = (tpass, np.array([s.force_n for s in h.steps]), "N")
            res.signals["strain"] = (tpass, np.cumsum([s.true_strain for s in h.steps]), "-")
            res.signals["strain_rate"] = (tpass, np.array([s.strain_rate_s for s in h.steps]), "1/s")
            summ = {"steps": f.n_steps, "max_pressure_pa": fr_.max_pressure_pa}
        else:
            e = d.extrusion
            er = p_ext.extrude(ctx, st, p_ext.ExtrusionSchedule(C(e.billet_temperature_C), e.reduction_ratio, e.ram_speed_m_s))
            res.stage_results["deformation"] = {"result": er}
            h = er.history
            res.signals["strain"] = (np.array([s.time_s for s in h.steps]), np.array([s.true_strain for s in h.steps]), "-")
            summ = {"reduction_ratio": e.reduction_ratio, "ram_pressure_pa": er.ram_pressure_pa}
        gen.add("DEFORMATION", {"type": d.type, **d.model_dump()[d.type]}, summ)
        if keep_snapshots:
            res.snapshots["deformed"] = st.copy()
        res.reached = "deformed"
    # ---- solution treatment --------------------------------------------------------------------------------------------
    if last >= 3:
        s = route.solution
        cond = ht_sol.SolutionTreatment(C(s.temperature_C), s.hold_min * 60.0, s.heating_rate_K_min / 60.0)
        fr = furnace.realise(ctx, cond.cycle(), st.dims_m[2], "solution")
        sres = ht_sol.solution_treat(ctx, st, cond, fr.part)
        for n in sres.notes:
            ctx.warn(n)
        res.stage_results["solution"] = {"result": sres, "furnace": fr}
        res.signals["solution_furnace_T"] = (fr.furnace.t_s, fr.furnace.T_K, "K")
        res.signals["solution_part_T"] = (fr.part.t_s, fr.part.T_K, "K")
        gen.add("SOLUTION", {"T_K": cond.solution_temperature_K, "hold_s": cond.hold_time_s},
                {"X_rex": sres.recrystallised_fraction, "burning_margin_K": sres.burning_margin_K,
                 "cu_in_solution_wt": sres.cu_in_solution_wt, "li_in_solution_wt": sres.li_in_solution_wt})
        if keep_snapshots:
            res.snapshots["solution_treated"] = st.copy()
        res.reached = "solution_treated"
    # ---- quench + stretch ------------------------------------------------------------------------------------------------
    if last >= 4:
        q = route.quench
        tank = quench_system.QuenchTank(q.medium, C(q.tank_temperature_C), q.flow_m_s, q.asymmetry, q.transfer_delay_s)
        T_in = float(res.stage_results["solution"]["furnace"].part.T_K[-1]) if "solution" in res.stage_results else C(route.solution.temperature_C)
        qin = tank.inputs(ctx, T_in, st.dims_m[2], q.stretch_percent / 100.0)
        qr = ht_quench.quench_plate(ctx, st, qin)
        res.stage_results["quench"] = {"result": qr, "inputs": qin}
        tq = qr.history.t_s
        res.signals["quench_surface_T"] = (tq, qr.history.T_surface_K, "K")
        res.signals["quench_centre_T"] = (tq, qr.history.T_centre_K, "K")
        mass = st.dims_m[0] * st.dims_m[1] * st.dims_m[2] * density.density_kg_m3(ctx, comp).value
        Tm = (qr.T_xt_K.mean(axis=1))
        res.signals["quench_tank_T"] = (tq, quench_system.tank_trace(ctx, tq, Tm, mass, qin.medium_temperature_K), "K")
        res.signals["quench_flow"] = (np.array([0.0, float(tq[-1])]), np.full(2, q.flow_m_s), "m/s")
        gen.add("QUENCH", {"medium": q.medium, "flow_m_s": q.flow_m_s, "delay_s": q.transfer_delay_s},
                {"quench_factor": qr.quench_factor_mean, "cooling_rate_window_centre": qr.cooling_rate_window_centre_K_s,
                 "residual_stress_max_MPa": qr.residual.max_abs_pa / 1e6, "distortion_risk": qr.residual.distortion_risk})
        if q.stretch_percent > 0:
            gen.add("STRETCH", {"strain": q.stretch_percent / 100.0}, {"dislocation_density": st.dislocation_density,
                                                                        "stress_relief": qr.residual.stress_relief_fraction})
        if keep_snapshots:
            res.snapshots["quenched"] = st.copy()
        res.reached = "quenched"
    # ---- ageing ------------------------------------------------------------------------------------------------------------
    if last >= 5:
        a = route.ageing
        if a.natural_h > 0:
            nat = ht_age.AgeingTreatment(295.0, a.natural_h * 3600.0, kind="natural")
            nres = ht_age.age(ctx, st, nat)
            res.stage_results["natural_ageing"] = nres
            gen.add("NATURAL_AGEING", {"hours": a.natural_h}, {"peak_mpa": nres.peak_mpa, "regime": nres.regime})
        art = ht_age.AgeingTreatment(C(a.temperature_C), a.time_h * 3600.0)
        fr = furnace.realise(ctx, art.cycle(), st.dims_m[2], "ageing")
        ares = ht_age.age(ctx, st, art)
        res.stage_results["ageing"] = {"result": ares, "furnace": fr}
        res.signals["ageing_furnace_T"] = (fr.furnace.t_s, fr.furnace.T_K, "K")
        res.signals["ageing_part_T"] = (fr.part.t_s, fr.part.T_K, "K")
        res.signals["ageing_time"] = (np.array([0.0, art.time_s]), np.array([0.0, a.time_h]), "h")
        gen.add("AGEING", {"T_K": art.temperature_K, "hours": a.time_h}, {"regime": ares.regime, "strengthening_mpa": ares.final_mpa,
                                                                             "t_peak_h": ares.t_peak_s / 3600.0})
        if keep_snapshots:
            res.snapshots["aged"] = st.copy()
        res.reached = "aged"
        if evaluate:
            res.properties = evaluate_properties(ctx, st, route.surface_condition)
            hold_h = sum(sh.hold_h for sh in route.homogenisation.steps) + route.solution.hold_min / 60.0 + a.time_h
            temps = [C(sh.temperature_C) for sh in route.homogenisation.steps] + [C(route.solution.temperature_C), C(a.temperature_C)]
            npass = route.deformation.rolling.passes if route.deformation.type == "rolling" else route.deformation.forging.n_steps if route.deformation.type == "forging" else 1
            res.cost = route_cost(ctx, comp, hold_h, temps, q.stretch_percent / 100.0 if last >= 4 else 0.0, npass, mass_kg)
    res.state = st
    res.warnings = list(ctx.warnings)
    return res


_ = math
