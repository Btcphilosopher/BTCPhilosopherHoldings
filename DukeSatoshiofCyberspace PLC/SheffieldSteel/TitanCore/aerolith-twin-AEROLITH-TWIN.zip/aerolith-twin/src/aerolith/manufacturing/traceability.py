"""Batch genealogy: hash-chained process history (tamper-evident)."""

from __future__ import annotations

import hashlib
import json
from dataclasses import asdict, dataclass, field
from datetime import UTC, datetime
from typing import Any

KIND_PREFIX = {"MELT": "", "CAST": "", "HOMOGENISATION": "H-", "DEFORMATION": "R-", "SOLUTION": "ST-", "QUENCH": "Q-",
               "STRETCH": "SK-", "NATURAL_AGEING": "NA-", "AGEING": "AG-", "INSPECTION": "NDT-", "QUALIFICATION": "QUAL-"}


def _num(batch_id: str, kind: str, salt: str = "") -> int:
    return int(hashlib.sha256(f"{batch_id}|{kind}|{salt}".encode()).hexdigest()[:8], 16) % 900 + 100


@dataclass
class GenealogyNode:
    kind: str
    node_id: str
    parents: list[str]
    parameters: dict[str, Any]
    summary: dict[str, Any]
    timestamp: str
    input_hash: str
    node_hash: str = ""


@dataclass
class BatchGenealogy:
    batch_id: str
    nodes: list[GenealogyNode] = field(default_factory=list)
    chemistry: dict[str, float] = field(default_factory=dict)
    frozen_time: str | None = None

    def _make_id(self, kind: str) -> str:
        suffix = batch_id_number(self.batch_id)
        if kind == "MELT":
            return f"MELT {suffix}"
        if kind == "CAST":
            return f"CAST {suffix}-A"
        return f"{KIND_PREFIX.get(kind, kind + '-')}{_num(self.batch_id, kind)}"

    def add(self, kind: str, parameters: dict[str, Any], summary: dict[str, Any]) -> GenealogyNode:
        parent = self.nodes[-1].node_hash if self.nodes else hashlib.sha256(json.dumps(self.chemistry, sort_keys=True).encode()).hexdigest()
        ts = self.frozen_time or datetime.now(UTC).isoformat(timespec="seconds")
        body = json.dumps({"kind": kind, "params": parameters, "parent": parent}, sort_keys=True, default=str)
        ih = hashlib.sha256(body.encode()).hexdigest()
        node = GenealogyNode(kind, self._make_id(kind), [self.nodes[-1].node_id] if self.nodes else ["CHEMISTRY"],
                             parameters, summary, ts, ih)
        node.node_hash = hashlib.sha256((ih + json.dumps(summary, sort_keys=True, default=str)).encode()).hexdigest()
        self.nodes.append(node)
        return node

    def verify(self) -> bool:
        parent = hashlib.sha256(json.dumps(self.chemistry, sort_keys=True).encode()).hexdigest()
        for n in self.nodes:
            body = json.dumps({"kind": n.kind, "params": n.parameters, "parent": parent}, sort_keys=True, default=str)
            ih = hashlib.sha256(body.encode()).hexdigest()
            nh = hashlib.sha256((ih + json.dumps(n.summary, sort_keys=True, default=str)).encode()).hexdigest()
            if ih != n.input_hash or nh != n.node_hash:
                return False
            parent = n.node_hash
        return True

    def to_text(self) -> str:
        lines = [f"BATCH {self.batch_id}", "", "CHEMISTRY"]
        for n in self.nodes:
            lines += ["  ↓", n.node_id if n.kind not in ("DEFORMATION",) else f"{n.node_id}  ({n.parameters.get('type', 'deformation')})"]
        return "\n".join(lines)

    def to_dict(self) -> dict[str, Any]:
        return {"batch_id": self.batch_id, "chemistry": self.chemistry, "verified": self.verify(),
                "nodes": [asdict(n) for n in self.nodes]}


def batch_id_number(batch_id: str) -> str:
    digits = "".join(c for c in batch_id if c.isdigit())
    return digits[-6:].rjust(6, "0") if digits else "000000"
