"""Cost and manufacturing-complexity indices (screening level, ILLUSTRATIVE prices)."""

from __future__ import annotations

from dataclasses import dataclass

from ..chemistry.composition import Composition
from ..chemistry.elements import ELEMENTS
from ..governance import ModelMeta, register
from ..params import P, Status, declare

_PRICE = {"Al": 3.0, "Li": 90.0, "Cu": 9.0, "Mg": 3.5, "Zn": 3.0, "Ag": 900.0, "Zr": 45.0, "Sc": 3500.0, "Mn": 2.5,
          "Fe": 0.2, "Si": 2.5, "Ti": 14.0}
declare(*[P(f"cost.element.{e}", _PRICE[e], "USD/kg", Status.ILLUSTRATIVE, "market-dependent placeholder; replace with contract prices", 0.3, 0.0, 1e5) for e in ELEMENTS])
declare(
    P("cost.melt_yield", 0.88, "-", Status.ILLUSTRATIVE, "casting/scalping/trim yield from melt to plate", 0.03, 0.5, 1.0),
    P("cost.energy", 0.12, "USD/kWh", Status.ILLUSTRATIVE, "energy price", 0.3, 0.0, 2.0),
    P("cost.conversion_base", 2.5, "USD/kg", Status.ILLUSTRATIVE, "casting + rolling conversion cost excluding furnace energy", 0.3, 0.0, 100.0),
    P("cost.stretch", 0.25, "USD/kg", Status.ILLUSTRATIVE, "stretching operation", 0.3, 0.0, 10.0),
    P("cost.furnace_loss_kw", 25.0, "kW", Status.ILLUSTRATIVE, "furnace holding loss (average)", 0.3, 1.0, 5000.0),
)
META = register(ModelMeta(
    model_name="route_cost_and_complexity",
    equation="cost = sum w_i c_i / yield + conversion + energy ; complexity = weighted count of operations, tight windows, scarce elements",
    parameter_source="registry cost.* (ILLUSTRATIVE)",
    validity_range="screening / ranking of routes, not a quotation",
    fidelity="EMPIRICAL",
))


@dataclass
class CostResult:
    usd_per_kg: float
    material: float
    energy: float
    conversion: float
    complexity: float


def route_cost(ctx, comp: Composition, hold_hours_total: float, peak_temps_K: list[float], stretch: float,  # type: ignore[no-untyped-def]
               n_passes: int, mass_kg: float = 1000.0) -> CostResult:
    ctx.use(META.model_name)
    mat = sum(comp.wt()[e] / 100.0 * ctx.p(f"cost.element.{e}") for e in ELEMENTS) / ctx.p("cost.melt_yield")
    heat_kwh = sum(mass_kg * ctx.p("def.cp") * (T - 293.0) for T in peak_temps_K) / 3.6e6
    hold_kwh = hold_hours_total * ctx.p("cost.furnace_loss_kw")
    energy = (heat_kwh + hold_kwh) * ctx.p("cost.energy") / mass_kg
    conv = ctx.p("cost.conversion_base") * (1.0 + 0.02 * n_passes) + (ctx.p("cost.stretch") if stretch > 0 else 0.0)
    cx = complexity_index(comp, hold_hours_total, len(peak_temps_K), stretch, n_passes)
    return CostResult(mat + energy + conv, mat, energy, conv, cx)


def complexity_index(comp: Composition, hold_hours_total: float, n_thermal_ops: int, stretch: float, n_passes: int) -> float:
    """Dimensionless manufacturing-complexity index: operations + scarce-element handling + long thermal holds."""
    wt = comp.wt()
    scarce = (1.0 if wt["Sc"] > 0 else 0.0) * 1.5 + (1.0 if wt["Ag"] > 0 else 0.0) * 0.7 + 0.8 * min(wt["Li"], 3.0) / 3.0
    return float(0.4 * n_thermal_ops + 0.05 * n_passes + (0.5 if stretch > 0 else 0.0) + scarce + 0.02 * hold_hours_total)
