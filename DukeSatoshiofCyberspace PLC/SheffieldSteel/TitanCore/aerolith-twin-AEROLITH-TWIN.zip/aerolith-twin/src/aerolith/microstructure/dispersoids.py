"""Dispersoids (Al3Zr, Al3Sc) and Zener pinning."""

from __future__ import annotations

import math
from dataclasses import dataclass

from ..governance import ModelMeta, register
from ..params import P, Status, declare
from .state import MaterialState

declare(
    P("disp.gamma_gb", 0.32, "J/m2", Status.LITERATURE_APPROX, "high-angle grain boundary energy of Al (order 0.3 J/m2)", 0.06, 0.1, 0.6),
    P("disp.zener_coeff", 1.5, "-", Status.LITERATURE_APPROX, "Zener pinning pressure P = c gamma f / r (c = 3/2 classical)", 0.3, 0.3, 4.0),
)

META = register(ModelMeta(
    model_name="zener_pinning",
    equation="P_Z = 1.5 gamma_gb f / r ; d_Z = 4 r / (3 f)",
    parameter_source="registry disp.*",
    validity_range="spherical, incoherent-to-coherent hard particles; f < 0.05; random distribution",
    fidelity="ANALYTICAL",
))


@dataclass
class DispersoidState:
    volume_fraction: float
    mean_radius_m: float
    number_density_m3: float


def dispersoids(state: MaterialState) -> DispersoidState:
    f = state.precip.volume_fraction("Al3Zr") + state.precip.volume_fraction("Al3Sc")
    n = state.precip.number_density("Al3Zr") + state.precip.number_density("Al3Sc")
    if f <= 0 or n <= 0:
        return DispersoidState(0.0, 0.0, 0.0)
    rz = state.precip.mean_radius("Al3Zr") * state.precip.number_density("Al3Zr")
    rs = state.precip.mean_radius("Al3Sc") * state.precip.number_density("Al3Sc")
    return DispersoidState(f, (rz + rs) / n, n)


def zener_pressure(ctx, state: MaterialState) -> float:  # type: ignore[no-untyped-def]
    """Pinning pressure (Pa) acting on the dispersoid-bearing fraction of boundaries."""
    ctx.use(META.model_name)
    d = dispersoids(state)
    if d.volume_fraction <= 0 or d.mean_radius_m <= 0:
        return 0.0
    return ctx.p("disp.zener_coeff") * ctx.p("disp.gamma_gb") * d.volume_fraction / d.mean_radius_m


def zener_limit_grain_size(state: MaterialState) -> float:
    d = dispersoids(state)
    if d.volume_fraction <= 0:
        return math.inf
    return 4.0 * d.mean_radius_m / (3.0 * d.volume_fraction)
