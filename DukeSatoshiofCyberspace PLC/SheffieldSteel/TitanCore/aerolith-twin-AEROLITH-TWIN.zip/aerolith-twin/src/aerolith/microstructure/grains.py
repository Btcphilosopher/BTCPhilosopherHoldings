"""Statistical grain-structure state."""

from __future__ import annotations

import math
from dataclasses import dataclass

import numpy as np


@dataclass
class GrainState:
    """Grains as lognormal-distributed ellipsoids with mean dimensions along L, T, N.

    ``mean_size_m`` is the geometric-mean (equivalent) diameter; the distribution of
    equivalent diameters is lognormal with log-standard-deviation ``sigma_ln``.
    """

    d_L: float
    d_T: float
    d_N: float
    sigma_ln: float = 0.5
    recrystallised_fraction: float = 0.0
    subgrain_size_m: float = 3.0e-6
    columnar_fraction: float = 0.0

    @property
    def mean_size_m(self) -> float:
        return (self.d_L * self.d_T * self.d_N) ** (1.0 / 3.0)

    @property
    def aspect_ratio(self) -> float:
        return self.d_L / self.d_N

    @property
    def boundary_density_m2_m3(self) -> float:
        """Grain-boundary area per unit volume S_v = 2 * <P_L> averaged over three axes."""
        return 2.0 * (1.0 / self.d_L + 1.0 / self.d_T + 1.0 / self.d_N) / 3.0

    def size_distribution(self, n: int = 200) -> tuple[np.ndarray, np.ndarray]:
        """(diameter grid, pdf) of the lognormal distribution of equivalent diameters."""
        mu = math.log(self.mean_size_m) - 0.5 * self.sigma_ln**2
        d = np.logspace(math.log10(self.mean_size_m) - 1.5, math.log10(self.mean_size_m) + 1.5, n)
        pdf = np.exp(-((np.log(d) - mu) ** 2) / (2 * self.sigma_ln**2)) / (d * self.sigma_ln * math.sqrt(2 * math.pi))
        return d, pdf

    def sample_diameters(self, rng: np.random.Generator, n: int) -> np.ndarray:
        mu = math.log(self.mean_size_m) - 0.5 * self.sigma_ln**2
        return rng.lognormal(mu, self.sigma_ln, n)

    def summary(self) -> dict[str, float]:
        return {
            "mean_grain_size_m": self.mean_size_m, "d_L_m": self.d_L, "d_T_m": self.d_T, "d_N_m": self.d_N,
            "aspect_ratio": self.aspect_ratio, "sigma_ln": self.sigma_ln,
            "recrystallised_fraction": self.recrystallised_fraction,
            "boundary_density_1_m": self.boundary_density_m2_m3, "subgrain_size_m": self.subgrain_size_m,
        }
