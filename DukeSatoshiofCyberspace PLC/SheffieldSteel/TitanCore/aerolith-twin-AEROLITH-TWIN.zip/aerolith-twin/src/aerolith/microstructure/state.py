"""MaterialState: the central object of the digital twin.

The state is what evolves through the process chain; every stage takes a state and returns a
new one, and a snapshot (deep copy + summary) is stored in the genealogy.
"""

from __future__ import annotations

import copy
import math
from dataclasses import dataclass, field
from typing import Any

import numpy as np

from ..chemistry.composition import Composition
from ..chemistry.elements import ATOMIC_MASS_G_MOL
from .defects import DefectPopulation
from .grains import GrainState
from .precipitates import PrecipitateField
from .texture import TextureState


@dataclass
class ResidualStressState:
    x_m: np.ndarray  # through-thickness position (from surface)
    sigma_pa: np.ndarray  # in-plane residual stress profile
    surface_pa: float
    core_pa: float
    max_abs_pa: float
    plastic_strain_max: float
    distortion_risk: float
    stress_relief_fraction: float = 0.0


def solute_atomic_fractions(comp: Composition) -> dict[str, float]:
    x = comp.at_fraction()
    return {k: x[k] for k in ("Li", "Cu", "Zr", "Sc")}


def wt_to_atom_fraction_scale(comp: Composition) -> float:
    """moles of all atoms per 100 g: converts wt% of an element to atomic fraction via (w/M)/total."""
    return sum(w / ATOMIC_MASS_G_MOL[e] for e, w in comp.wt().items())


@dataclass
class MaterialState:
    composition: Composition
    dims_m: tuple[float, float, float]  # (L, W, H): rolling, transverse, normal
    stage: str = "melt"
    temper: str = "as-cast"
    # chemistry / segregation
    profiles_wt: dict[str, np.ndarray] = field(default_factory=dict)  # core -> boundary, solid-phase composition
    lambda2_m: float = 5.0e-5
    eutectic_fraction: float = 0.0  # volume fraction of soluble non-equilibrium eutectic constituents
    eutectic_fraction_initial: float = 0.0
    eutectic_solute_wt: dict[str, float] = field(default_factory=dict)  # wt% of alloy locked in soluble eutectic
    constituent_radius_m: float = 3.0e-6
    insoluble_constituent_fraction: float = 0.0  # Fe/Si-bearing intermetallics
    solute_pool_at: dict[str, float] = field(default_factory=dict)  # atom fractions available for nano-precipitation
    dispersoid_free_fraction: float = 0.0
    # microstructure
    precip: PrecipitateField = field(default_factory=PrecipitateField)
    vacancy_cv: float = 0.0
    grains: GrainState | None = None
    dislocation_density: float = 1.0e11  # m-2
    texture: TextureState = field(default_factory=TextureState)
    defects: DefectPopulation = field(default_factory=DefectPopulation)
    residual_stress: ResidualStressState | None = None
    # process memory
    total_true_strain: float = 0.0
    cumulative_reduction_ratio: float = 1.0
    stretch_strain: float = 0.0
    quench_factor_mean: float = 0.0
    quench_factor_centre: float = 0.0
    quench_loss_fraction: float = 0.0  # fraction of solute lost to quench-induced (grain boundary / coarse) precipitation
    gb_precipitate_coverage: float = 0.0
    time_since_quench_s: float = 0.0
    peak_temperature_K: float = 293.0
    process_log: list[dict[str, Any]] = field(default_factory=list)
    flags: list[str] = field(default_factory=list)

    def copy(self) -> MaterialState:
        return copy.deepcopy(self)

    def log(self, name: str, **info: Any) -> None:
        self.process_log.append({"stage": name, **info})

    def matrix_wt(self) -> dict[str, float]:
        """Approximate free-solute concentration in the matrix, wt% (precipitating solutes from the pool, others nominal)."""
        out = dict(self.composition.wt())
        from ..thermodynamics.equilibrium import PHASES, SOLUTE_INDEX

        scale = wt_to_atom_fraction_scale(self.composition)
        pool = self.solute_pool_at
        f_tot = 0.0
        locked = dict.fromkeys(SOLUTE_INDEX, 0.0)
        for p in PHASES:
            f = self.precip.volume_fraction(p.key)
            f_tot += f
            for el, i in SOLUTE_INDEX.items():
                locked[el] += f * p.s[i]
        for el in SOLUTE_INDEX:
            x_free = max((pool.get(el, 0.0) - locked[el]) / max(1.0 - f_tot, 1e-6), 0.0)
            out[el] = x_free * scale * ATOMIC_MASS_G_MOL[el]
        # solutes tied up in insoluble constituents / soluble eutectic are not in solution
        for el, w in self.eutectic_solute_wt.items():
            if el not in SOLUTE_INDEX:
                out[el] = max(0.0, out[el] - w * (self.eutectic_fraction / max(self.eutectic_fraction_initial, 1e-12)))
        return out

    def summary(self) -> dict[str, Any]:
        g = self.grains.summary() if self.grains else {}
        return {
            "stage": self.stage, "temper": self.temper, "dims_m": list(self.dims_m),
            "eutectic_fraction": self.eutectic_fraction,
            "insoluble_constituent_fraction": self.insoluble_constituent_fraction,
            "dislocation_density_m2": self.dislocation_density,
            "total_true_strain": self.total_true_strain, "stretch_strain": self.stretch_strain,
            "quench_factor": self.quench_factor_mean, "quench_loss_fraction": self.quench_loss_fraction,
            "texture_index": self.texture.index(), "grains": g, "precipitates": self.precip.summary(),
            "defect_summary": self.defects.summary(),
            "peak_temperature_K": self.peak_temperature_K, "flags": list(self.flags),
        }


def volume_scale_check(state: MaterialState) -> float:
    L, W, H = state.dims_m
    return L * W * H


_ = (math, np)
