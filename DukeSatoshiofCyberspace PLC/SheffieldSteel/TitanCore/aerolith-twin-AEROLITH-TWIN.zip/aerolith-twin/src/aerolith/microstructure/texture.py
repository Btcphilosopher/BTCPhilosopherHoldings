"""Texture representation and texture-dependent anisotropy (Taylor factor, elastic moduli).

Texture is represented as a weighted set of standard orientation components (each a
Gaussian-spread cloud of sampled orientations) plus a random fraction.  This is a
simplified ODF, adequate for trend-level anisotropy; it is not a measured ODF.

Conventions: sample axes x = RD, y = TD, z = ND; Bunge Euler angles (phi1, Phi, phi2) give
the rotation g taking sample vectors to crystal vectors: v_c = g v_s.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from functools import lru_cache

import numpy as np
from scipy.optimize import linprog

COMPONENTS = ("Cube", "Goss", "Brass", "S", "Copper", "Fibre111", "Fibre100", "Random")

_EULER_DEG = {
    "Cube": (0.0, 0.0, 0.0),
    "Goss": (0.0, 45.0, 0.0),
    "Brass": (35.0, 45.0, 0.0),
    "S": (59.0, 37.0, 63.0),
    "Copper": (90.0, 35.0, 45.0),
}
N_PER_COMPONENT = 36
N_RANDOM = 240
SPREAD_DEG = 10.0

# single-crystal elastic constants of pure Al, GPa (tabulated handbook values; verify)
C11, C12, C44 = 108.2, 61.3, 28.5


def bunge_matrix(phi1: float, Phi: float, phi2: float) -> np.ndarray:
    c1, s1, c, s, c2, s2 = math.cos(phi1), math.sin(phi1), math.cos(Phi), math.sin(Phi), math.cos(phi2), math.sin(phi2)
    return np.array([
        [c1 * c2 - s1 * s2 * c, s1 * c2 + c1 * s2 * c, s2 * s],
        [-c1 * s2 - s1 * c2 * c, -s1 * s2 + c1 * c2 * c, c2 * s],
        [s1 * s, -c1 * s, c],
    ])


def _random_rotations(rng: np.random.Generator, n: int) -> np.ndarray:
    q = rng.normal(size=(n, 4))
    q /= np.linalg.norm(q, axis=1, keepdims=True)
    w, x, y, z = q.T
    R = np.empty((n, 3, 3))
    R[:, 0, 0] = 1 - 2 * (y * y + z * z)
    R[:, 0, 1] = 2 * (x * y - z * w)
    R[:, 0, 2] = 2 * (x * z + y * w)
    R[:, 1, 0] = 2 * (x * y + z * w)
    R[:, 1, 1] = 1 - 2 * (x * x + z * z)
    R[:, 1, 2] = 2 * (y * z - x * w)
    R[:, 2, 0] = 2 * (x * z - y * w)
    R[:, 2, 1] = 2 * (y * z + x * w)
    R[:, 2, 2] = 1 - 2 * (x * x + y * y)
    return R


def _small_rotations(rng: np.random.Generator, n: int, sigma_deg: float) -> np.ndarray:
    axes = rng.normal(size=(n, 3))
    axes /= np.linalg.norm(axes, axis=1, keepdims=True)
    ang = np.deg2rad(rng.normal(0.0, sigma_deg, n))
    K = np.zeros((n, 3, 3))
    K[:, 0, 1], K[:, 0, 2] = -axes[:, 2], axes[:, 1]
    K[:, 1, 0], K[:, 1, 2] = axes[:, 2], -axes[:, 0]
    K[:, 2, 0], K[:, 2, 1] = -axes[:, 1], axes[:, 0]
    s, c = np.sin(ang)[:, None, None], np.cos(ang)[:, None, None]
    return np.eye(3) + s * K + (1 - c) * (K @ K)


def _fibre(rng: np.random.Generator, n: int, crystal_dir: np.ndarray) -> np.ndarray:
    """Orientations with a given crystal direction parallel to RD (sample x), random rotation about it."""
    d = crystal_dir / np.linalg.norm(crystal_dir)
    out = np.empty((n, 3, 3))
    for i in range(n):
        a = rng.uniform(0, 2 * math.pi)
        # g maps sample->crystal; column 0 of g^T is the crystal direction of sample x
        e1 = d
        t = np.array([1.0, 0.0, 0.0]) if abs(d[0]) < 0.9 else np.array([0.0, 1.0, 0.0])
        e2 = np.cross(d, t)
        e2 /= np.linalg.norm(e2)
        e3 = np.cross(e1, e2)
        y = math.cos(a) * e2 + math.sin(a) * e3
        z = np.cross(e1, y)
        out[i] = np.vstack([e1, y, z])  # rows: crystal coords of sample x,y,z -> this is g^T
    return np.transpose(out, (0, 2, 1))  # g such that v_c = g v_s  (g = [x_c y_c z_c] columns)


@lru_cache(maxsize=1)
def component_orientations() -> dict[str, np.ndarray]:
    rng = np.random.default_rng(20260101)
    out: dict[str, np.ndarray] = {}
    for name, eul in _EULER_DEG.items():
        g0 = bunge_matrix(*np.deg2rad(eul))
        out[name] = np.einsum("nij,jk->nik", _small_rotations(rng, N_PER_COMPONENT, SPREAD_DEG), g0)
    out["Fibre111"] = _fibre(rng, N_PER_COMPONENT, np.array([1.0, 1.0, 1.0]))
    out["Fibre100"] = _fibre(rng, N_PER_COMPONENT, np.array([1.0, 0.0, 0.0]))
    out["Random"] = _random_rotations(rng, N_RANDOM)
    return out


# ---------------------------------------------------------------------------- slip systems / Taylor factor
def _slip_systems() -> list[tuple[np.ndarray, np.ndarray]]:
    normals = [np.array(v, float) for v in ([1, 1, 1], [-1, 1, 1], [1, -1, 1], [1, 1, -1])]
    dirs = {
        0: [[0, 1, -1], [1, 0, -1], [1, -1, 0]],
        1: [[0, 1, -1], [1, 0, 1], [1, 1, 0]],
        2: [[0, 1, 1], [1, 0, -1], [1, 1, 0]],
        3: [[0, 1, 1], [1, 0, 1], [1, -1, 0]],
    }
    out = []
    for i, n in enumerate(normals):
        for d_idx in dirs[i]:
            d = np.array(d_idx, float)
            assert abs(np.dot(n, d)) < 1e-9
            out.append((d / np.linalg.norm(d), n / np.linalg.norm(n)))
    return out


_SYS = _slip_systems()
_SCHMID = np.array([0.5 * (np.outer(b, n) + np.outer(n, b)) for b, n in _SYS])  # (12,3,3)


def taylor_factor(g: np.ndarray, d_sample: np.ndarray) -> float:
    """Full-constraints Taylor factor for uniaxial tension along d (unit, sample frame), Sigma|gamma|/eps_axial."""
    d = d_sample / np.linalg.norm(d_sample)
    eps_s = 1.5 * np.outer(d, d) - 0.5 * np.eye(3)  # axial strain 1, isochoric lateral
    eps_c = g @ eps_s @ g.T
    idx = [(0, 0), (1, 1), (0, 1), (0, 2), (1, 2)]
    A = np.array([[m[i, j] for m in _SCHMID] for i, j in idx])
    b = np.array([eps_c[i, j] for i, j in idx])
    A2 = np.hstack([A, -A])
    res = linprog(np.ones(24), A_eq=A2, b_eq=b, bounds=(0, None), method="highs")
    return float(res.fun) if res.success else float("nan")


DIRECTIONS = {"L": np.array([1.0, 0.0, 0.0]), "T": np.array([0.0, 1.0, 0.0]),
              "D": np.array([1.0, 1.0, 0.0]) / math.sqrt(2.0)}


@lru_cache(maxsize=1)
def component_taylor_factors() -> dict[str, dict[str, float]]:
    """Mean Taylor factor of each texture component for L, T and 45-degree loading (cached)."""
    from pathlib import Path

    cache = Path(__file__).resolve().parents[3] / "models" / "taylor_cache.npz"
    comps = component_orientations()
    if cache.exists():
        z = np.load(cache)
        if all(k in z.files for k in comps):
            return {c: dict(zip(DIRECTIONS, z[c], strict=True)) for c in comps}
    out: dict[str, dict[str, float]] = {}
    for name, gs in comps.items():
        out[name] = {dn: float(np.nanmean([taylor_factor(g, d) for g in gs])) for dn, d in DIRECTIONS.items()}
    try:
        cache.parent.mkdir(exist_ok=True)
        np.savez(cache, **{c: np.array([out[c][d] for d in DIRECTIONS]) for c in out})  # type: ignore[arg-type]
    except OSError:
        pass
    return out


# ---------------------------------------------------------------------------- elasticity
def _cubic_stiffness_tensor(c11: float, c12: float, c44: float) -> np.ndarray:
    """4th-order stiffness tensor of a cubic crystal: C1111=c11, C1122=c12, C1212=c44."""
    d = np.eye(3)
    T = c12 * np.einsum("ij,kl->ijkl", d, d)
    T = T + c44 * (np.einsum("ik,jl->ijkl", d, d) + np.einsum("il,jk->ijkl", d, d))
    T = T + (c11 - c12 - 2.0 * c44) * np.einsum("ia,ja,ka,la->ijkl", d, d, d, d)
    return T


def _mandel(T: np.ndarray) -> np.ndarray:
    idx = [(0, 0), (1, 1), (2, 2), (1, 2), (0, 2), (0, 1)]
    w = [1, 1, 1, math.sqrt(2), math.sqrt(2), math.sqrt(2)]
    M = np.empty((6, 6))
    for a, (i, j) in enumerate(idx):
        for b, (k, l) in enumerate(idx):
            M[a, b] = w[a] * w[b] * T[i, j, k, l]
    return M


def single_crystal_constants(scale: float = 1.0) -> tuple[float, float, float]:
    return C11 * scale, C12 * scale, C44 * scale


def _rotate(T: np.ndarray, g: np.ndarray) -> np.ndarray:
    # v_c = g v_s  =>  T_sample_ijkl = g_pi g_qj g_rk g_sl T_crystal_pqrs
    return np.einsum("pi,qj,rk,sl,pqrs->ijkl", g, g, g, g, T, optimize=True)


@dataclass
class ElasticResult:
    E_L: float
    E_T: float
    E_N: float
    G_LT: float
    nu_LT: float
    E_iso: float
    G_iso: float
    nu_iso: float


def _untensor(M: np.ndarray) -> np.ndarray:
    idx = [(0, 0), (1, 1), (2, 2), (1, 2), (0, 2), (0, 1)]
    w = [1, 1, 1, math.sqrt(2), math.sqrt(2), math.sqrt(2)]
    T = np.zeros((3, 3, 3, 3))
    for a, (i, j) in enumerate(idx):
        for b, (k, l) in enumerate(idx):
            v = M[a, b] / (w[a] * w[b])
            for p, q in {(i, j), (j, i)}:
                for r, s in {(k, l), (l, k)}:
                    T[p, q, r, s] = v
    return T


def textured_elastic(weights: dict[str, float], scale: float = 1.0) -> ElasticResult:
    """Voigt-Reuss-Hill orientation-averaged elastic constants of a textured aggregate (Pa).

    Voigt = uniform strain (orientation-averaged stiffness), Reuss = uniform stress
    (orientation-averaged compliance); the Hill estimate is their mean compliance.
    """
    c11, c12, c44 = single_crystal_constants(scale)
    C_t = _cubic_stiffness_tensor(c11, c12, c44)
    S_t = _untensor(np.linalg.inv(_mandel(C_t)))
    comps = component_orientations()
    tot = sum(max(w, 0.0) for w in weights.values()) or 1.0
    Cv = np.zeros((3, 3, 3, 3))
    Sr = np.zeros((3, 3, 3, 3))
    for name, w in weights.items():
        if w <= 0:
            continue
        gs = comps[name]
        for g in gs:
            Cv += (w / tot / len(gs)) * _rotate(C_t, g)
            Sr += (w / tot / len(gs)) * _rotate(S_t, g)
    Sv = _untensor(np.linalg.inv(_mandel(Cv)))
    S = 0.5 * (Sv + Sr)
    E_L, E_T, E_N = 1 / S[0, 0, 0, 0], 1 / S[1, 1, 1, 1], 1 / S[2, 2, 2, 2]
    G_LT = 1 / (4 * S[0, 1, 0, 1])
    nu_LT = -S[0, 0, 1, 1] / S[0, 0, 0, 0]
    s11 = S[0, 0, 0, 0] + S[1, 1, 1, 1] + S[2, 2, 2, 2]
    s12 = S[0, 0, 1, 1] + S[0, 0, 2, 2] + S[1, 1, 2, 2]
    s44t = S[0, 1, 0, 1] + S[0, 2, 0, 2] + S[1, 2, 1, 2]
    K = 1.0 / (s11 + 2.0 * s12)
    G = 15.0 / (4.0 * s11 - 4.0 * s12 + 12.0 * s44t)
    E = 9 * K * G / (3 * K + G)
    nu = (3 * K - 2 * G) / (2 * (3 * K + G))
    return ElasticResult(float(E_L * 1e9), float(E_T * 1e9), float(E_N * 1e9), float(G_LT * 1e9), float(nu_LT),
                         float(E * 1e9), float(G * 1e9), float(nu))


@dataclass
class TextureState:
    """Weights of orientation components (sum = 1) + a scalar texture index (0 = random, 1 = single component)."""

    weights: dict[str, float] = field(default_factory=lambda: {**dict.fromkeys(COMPONENTS, 0.0), "Random": 1.0})

    def normalised(self) -> dict[str, float]:
        tot = sum(self.weights.values()) or 1.0
        return {k: v / tot for k, v in self.weights.items()}

    def copy(self) -> TextureState:
        return TextureState(dict(self.weights))

    def index(self) -> float:
        w = self.normalised()
        return float(1.0 - w.get("Random", 0.0))

    def taylor_factor(self, direction: str) -> float:
        tf = component_taylor_factors()
        w = self.normalised()
        return float(sum(w[c] * tf[c][direction] for c in w if w[c] > 0))

    def taylor_factors(self) -> dict[str, float]:
        return {d: self.taylor_factor(d) for d in DIRECTIONS}
