"""Precipitate size-distribution field (number density per radius bin, per phase)."""

from __future__ import annotations

import math
from dataclasses import dataclass, field

import numpy as np

from ..thermodynamics.equilibrium import PHASE_KEYS

DR = 0.1e-9  # bin width (m)
NB = 600  # bins -> radii 0.05 nm .. 60 nm
R_GRID = (np.arange(NB) + 0.5) * DR


@dataclass
class PrecipitateField:
    r: np.ndarray = field(default_factory=lambda: R_GRID.copy())
    n: dict[str, np.ndarray] = field(default_factory=lambda: {k: np.zeros(NB) for k in PHASE_KEYS})

    def copy(self) -> PrecipitateField:
        return PrecipitateField(self.r.copy(), {k: v.copy() for k, v in self.n.items()})

    def volume_fraction(self, phase: str) -> float:
        return float(4.0 / 3.0 * math.pi * np.sum(self.n[phase] * self.r**3))

    def number_density(self, phase: str) -> float:
        return float(np.sum(self.n[phase]))

    def mean_radius(self, phase: str) -> float:
        N = self.number_density(phase)
        return float(np.sum(self.n[phase] * self.r) / N) if N > 0 else 0.0

    def volume_weighted_radius(self, phase: str) -> float:
        w = self.n[phase] * self.r**3
        s = float(np.sum(w))
        return float(np.sum(w * self.r) / s) if s > 0 else 0.0

    def distribution(self, phase: str) -> tuple[np.ndarray, np.ndarray]:
        """(radius [m], number-weighted pdf [1/m])."""
        N = self.number_density(phase)
        return self.r, (self.n[phase] / N / DR if N > 0 else np.zeros_like(self.r))

    def total_volume_fraction(self) -> float:
        return sum(self.volume_fraction(k) for k in PHASE_KEYS)

    def summary(self) -> dict[str, dict[str, float]]:
        return {
            k: {
                "volume_fraction": self.volume_fraction(k),
                "mean_radius_m": self.mean_radius(k),
                "number_density_m3": self.number_density(k),
            }
            for k in PHASE_KEYS
        }
