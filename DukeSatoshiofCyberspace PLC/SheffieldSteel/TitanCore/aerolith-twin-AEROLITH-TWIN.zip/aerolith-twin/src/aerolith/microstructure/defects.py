"""Manufacturing defect population.

Each defect carries: type, size, location, orientation, confidence, severity.
Positions are normalised part coordinates (u along RD, v along TD, w through ND, each in [0,1]).
"""

from __future__ import annotations

from dataclasses import asdict, dataclass, field
from enum import StrEnum

import numpy as np
import pandas as pd


class DefectType(StrEnum):
    POROSITY = "porosity"
    INCLUSION = "inclusion"
    SEGREGATION = "segregation"
    CRACK = "crack"
    SURFACE = "surface_defect"
    VOID = "void"
    GRAIN_ABNORMALITY = "grain_abnormality"


@dataclass
class Defect:
    id: int
    type: DefectType
    size_m: float  # equivalent diameter / characteristic length of the largest dimension in the plane of interest
    position: tuple[float, float, float]
    orientation: tuple[float, float, float]  # unit vector of the major axis in sample frame (RD, TD, ND)
    aspect_ratio: float = 1.0
    confidence: float = 0.5  # confidence in existence/size of this model-generated defect (0..1)
    severity: float | None = None  # a_eq / a_critical, filled by assess_severity
    origin: str = ""
    surface: bool = False
    detected_by: list[str] = field(default_factory=list)


class DefectPopulation:
    def __init__(self, volume_m3: float = 0.0, dims_m: tuple[float, float, float] = (1.0, 1.0, 0.01)):
        self.defects: list[Defect] = []
        self.volume_m3 = volume_m3
        self.dims_m = dims_m
        self._next = 1
        # statistics of the sub-reporting-threshold bulk (too many to enumerate)
        self.bulk: dict[str, float] = {}

    def add(self, type: DefectType, size_m: float, position, orientation, **kw) -> Defect:  # type: ignore[no-untyped-def]
        o = np.asarray(orientation, float)
        o = o / np.linalg.norm(o)
        d = Defect(self._next, type, float(size_m), (float(position[0]), float(position[1]), float(position[2])),
                   (float(o[0]), float(o[1]), float(o[2])), **kw)
        self._next += 1
        self.defects.append(d)
        return d

    def __len__(self) -> int:
        return len(self.defects)

    def of_type(self, t: DefectType) -> list[Defect]:
        return [d for d in self.defects if d.type is t]

    def porosity_volume_fraction(self) -> float:
        if self.volume_m3 <= 0:
            return 0.0
        v = 0.0
        for d in self.defects:
            if d.type in (DefectType.POROSITY, DefectType.VOID):
                # ellipsoid with major axis size_m and minor axes size_m/aspect_ratio
                v += np.pi / 6.0 * d.size_m**3 / max(d.aspect_ratio, 1.0) ** 2
        return float(min(v / self.volume_m3, 0.5))

    def largest(self) -> Defect | None:
        return max(self.defects, key=lambda d: d.size_m, default=None)

    def to_dataframe(self) -> pd.DataFrame:
        rows = []
        for d in self.defects:
            r = asdict(d)
            r["type"] = d.type.value
            r["u"], r["v"], r["w"] = d.position
            r["ox"], r["oy"], r["oz"] = d.orientation
            r.pop("position")
            r.pop("orientation")
            r["detected_by"] = ",".join(d.detected_by)
            rows.append(r)
        cols = ["id", "type", "size_m", "u", "v", "w", "ox", "oy", "oz", "aspect_ratio", "confidence",
                "severity", "origin", "surface", "detected_by"]
        return pd.DataFrame(rows, columns=cols)

    def copy(self) -> DefectPopulation:
        import copy

        return copy.deepcopy(self)

    def summary(self) -> dict[str, float]:
        out: dict[str, float] = {"count": float(len(self.defects))}
        for t in DefectType:
            out[f"n_{t.value}"] = float(len(self.of_type(t)))
        big = self.largest()
        out["largest_size_m"] = float(big.size_m) if big else 0.0
        out["porosity_volume_fraction"] = self.porosity_volume_fraction()
        return out


def assess_severity(pop: DefectPopulation, applied_stress_pa: float, K_ic: float, geometry_factor: float = 1.12) -> None:
    """Severity = a_eq / a_c with a_c = (K_ic / (Y sigma))^2 / pi  (critical flaw size)."""
    a_c = (K_ic / (geometry_factor * max(applied_stress_pa, 1.0))) ** 2 / np.pi
    for d in pop.defects:
        # equivalent crack half-length: sharper (cracks, surface) count fully; rounded pores are blunted
        blunt = {DefectType.POROSITY: 0.5, DefectType.VOID: 0.5, DefectType.INCLUSION: 0.6}.get(d.type, 1.0)
        a_eq = 0.5 * d.size_m * blunt * (1.0 + 0.1 * min(d.aspect_ratio, 20.0))
        d.severity = float(min(a_eq / a_c, 10.0))
