"""Pulse-echo ultrasonic inspection: grain-scatter attenuation, DGS-type defect response, structural noise, POD."""

from __future__ import annotations

import math
from dataclasses import dataclass

import numpy as np
from scipy.stats import norm

from ..governance import ModelMeta, register
from ..microstructure.defects import Defect, DefectType
from ..microstructure.state import MaterialState
from ..numerics import smooth_min
from ..params import P, Status, declare

declare(
    P("us.v_L", 6320.0, "m/s", Status.LITERATURE_APPROX, "longitudinal wave speed in Al alloys", 40.0, 6000, 6600),
    P("us.alpha_abs", 0.4, "Np/m at 5 MHz", Status.ILLUSTRATIVE, "intrinsic absorption", 0.4, 0.0, 20.0, True),
    P("us.aR", 6.4e-14, "-", Status.ILLUSTRATIVE, "Rayleigh scatter coefficient: alpha = aR f^4 d^3 (SI); regimes cross near d ~ lambda/(2 pi)", 0.5, 0.0, 1e3, True),
    P("us.aS", 4.0e-9, "-", Status.ILLUSTRATIVE, "stochastic scatter coefficient: alpha = aS f^2 d (SI)", 0.5, 0.0, 1e3, True),
    P("us.aG", 4.0e-3, "-", Status.ILLUSTRATIVE, "geometric scatter coefficient: alpha = aG / d (SI)", 0.5, 0.0, 1e3, True),
    P("us.noise_el", 0.01, "-", Status.ILLUSTRATIVE, "electronic noise relative to back-wall echo", 0.3, 0.0, 1.0, True),
    P("us.noise_gr", 0.02, "-", Status.ILLUSTRATIVE, "structural-noise coefficient: n = c (d/lambda)^1.5", 0.4, 0.0, 1.0, True),
    P("us.thr_dB", 6.0, "dB", Status.ILLUSTRATIVE, "detection threshold above noise; to be set by NDT procedure qualification", 0.0),
    P("us.sigma_dB", 3.0, "dB", Status.ILLUSTRATIVE, "scatter of the signal response (POD curve width)", 0.5, 0.5, 12.0),
    P("us.dead_zone", 2.0e-3, "m", Status.ILLUSTRATIVE, "near-surface dead zone", 0.0),
)
META = register(ModelMeta(
    model_name="ultrasonic_pulse_echo",
    equation="alpha = smooth_min(aR f^4 d^3, aS f^2 d, aG/d) + alpha_abs ; S = (pi a_eq^2/(lambda z)) exp(-2 alpha z) cos^2(theta) ; POD = Phi((20log10(S/N) - thr)/sigma)",
    parameter_source="registry us.* (ILLUSTRATIVE; requires NDT procedure qualification)",
    validity_range="normal-incidence longitudinal waves, 1-15 MHz, far-field disc-reflector response; no focused beams or phased arrays",
))


@dataclass
class UTSettings:
    frequency_hz: float = 5.0e6
    scan_surface: str = "top"  # top | both


def wavelength(ctx, f: float) -> float:  # type: ignore[no-untyped-def]
    return ctx.p("us.v_L") / f


def attenuation_np_m(ctx, state: MaterialState, f: float) -> float:  # type: ignore[no-untyped-def]
    ctx.use(META.model_name)
    g = state.grains
    d = g.d_N if g else 1e-4  # beam along ND: intercept along the through-thickness grain dimension
    aR, aS, aG = ctx.p("us.aR") * f**4 * d**3, ctx.p("us.aS") * f**2 * d, ctx.p("us.aG") / d
    scat = smooth_min(max(aR, 1e-12), max(aS, 1e-12), 3.0)
    scat = smooth_min(scat, max(aG, 1e-12), 3.0)
    return float(scat + ctx.p("us.alpha_abs") * (f / 5.0e6) ** 2)


def structural_noise(ctx, state: MaterialState, f: float) -> float:  # type: ignore[no-untyped-def]
    g = state.grains
    d = g.d_N if g else 1e-4
    return ctx.p("us.noise_el") + ctx.p("us.noise_gr") * (d / wavelength(ctx, f)) ** 1.5


_SHAPE = {DefectType.POROSITY: 0.45, DefectType.VOID: 0.45, DefectType.INCLUSION: 0.35, DefectType.SEGREGATION: 0.08,
          DefectType.CRACK: 1.0, DefectType.SURFACE: 0.9, DefectType.GRAIN_ABNORMALITY: 0.05}


def defect_signal(ctx, state: MaterialState, d: Defect, s: UTSettings) -> tuple[float, float]:  # type: ignore[no-untyped-def]
    """(signal relative to the back-wall echo, depth z in m)."""
    f = s.frequency_hz
    H = state.dims_m[2]
    w = d.position[2]
    z = w * H if s.scan_surface == "top" else min(w, 1.0 - w) * H
    lam = wavelength(ctx, f)
    # disc-equivalent radius: flat reflectors (orientation normal to the beam, i.e. along ND) respond fully
    cos2 = d.orientation[2] ** 2
    aspect_gain = 1.0 + 0.5 * math.log(max(d.aspect_ratio, 1.0))
    a_eq = 0.5 * d.size_m * _SHAPE.get(d.type, 0.3) * aspect_gain * (0.35 + 0.65 * cos2)
    z_eff = max(z, 0.5 * lam)
    sig = math.pi * a_eq**2 / (lam * z_eff) * math.exp(-2.0 * attenuation_np_m(ctx, state, f) * z_eff)
    return sig, z


def pod(ctx, state: MaterialState, d: Defect, s: UTSettings) -> float:  # type: ignore[no-untyped-def]
    sig, z = defect_signal(ctx, state, d, s)
    if z < ctx.p("us.dead_zone"):
        return 0.0
    noise = structural_noise(ctx, state, s.frequency_hz)
    snr_db = 20.0 * math.log10(max(sig, 1e-12) / max(noise, 1e-12))
    return float(norm.cdf((snr_db - ctx.p("us.thr_dB")) / ctx.p("us.sigma_dB")))


def pod_curve(ctx, state: MaterialState, s: UTSettings, sizes_m: np.ndarray, dtype: DefectType = DefectType.CRACK) -> np.ndarray:  # type: ignore[no-untyped-def]
    out = []
    for a in sizes_m:
        d = Defect(0, dtype, float(a), (0.5, 0.5, 0.5), (0.0, 0.0, 1.0), 1.0)
        out.append(pod(ctx, state, d, s))
    return np.array(out)
