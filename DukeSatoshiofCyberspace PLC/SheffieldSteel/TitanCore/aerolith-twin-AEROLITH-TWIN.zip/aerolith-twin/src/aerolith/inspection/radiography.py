"""Radiography: Beer-Lambert contrast, photon-limited noise, Rose-criterion POD (probabilistic visibility)."""

from __future__ import annotations

import math
from dataclasses import dataclass

from scipy.stats import norm

from ..governance import ModelMeta, register
from ..microstructure.defects import Defect, DefectType
from ..microstructure.state import MaterialState
from ..params import P, Status, declare

declare(
    P("rt.mu_rho", 1.704e-3, "m2/kg", Status.REFERENCE, "mass attenuation coefficient of Al at 100 keV (0.1704 cm2/g)", 1e-5),
    P("rt.photons", 2.0e4, "photons/pixel", Status.ILLUSTRATIVE, "detected photons per pixel behind the unattenuated plate", 0.4, 1e2, 1e8, True),
    P("rt.pixel", 1.0e-4, "m", Status.ILLUSTRATIVE, "effective pixel / unsharpness size", 0.2, 1e-5, 1e-3, True),
    P("rt.cnr_thr", 3.0, "-", Status.REFERENCE, "Rose-criterion contrast-to-noise ratio for visibility", 0.5, 2.0, 6.0),
    P("rt.sigma_ln", 0.3, "-", Status.ILLUSTRATIVE, "log-scatter of visibility", 0.1, 0.05, 1.5),
)
META = register(ModelMeta(
    model_name="radiography_rose_criterion",
    equation="C = (mu_m - mu_d) t_d ; CNR = C sqrt(N_ph) ; POD = Phi((ln CNR - ln CNR_thr)/sigma)",
    parameter_source="registry rt.* (Rose criterion REFERENCE; others ILLUSTRATIVE)",
    validity_range="monoenergetic projection radiography through plate thickness; no scatter, no geometric unsharpness model beyond pixel size",
    fidelity="ANALYTICAL",
))


@dataclass
class RTSettings:
    energy_label: str = "100 keV (monoenergetic)"


def pod(ctx, state: MaterialState, d: Defect, s: RTSettings, rho_kg_m3: float = 2700.0) -> float:  # type: ignore[no-untyped-def]
    ctx.use(META.model_name)
    mu = ctx.p("rt.mu_rho") * rho_kg_m3
    # extent along the beam (ND): flattened defects have thickness size/aspect when lying in the plate plane
    in_plane = 1.0 - d.orientation[2] ** 2
    t_beam = d.size_m / max(d.aspect_ratio, 1.0) ** (0.8 * in_plane + 0.0)
    contrast_factor = {DefectType.POROSITY: 1.0, DefectType.VOID: 1.0, DefectType.CRACK: 1.0, DefectType.INCLUSION: 0.25,
                       DefectType.SEGREGATION: 0.03, DefectType.SURFACE: 0.5, DefectType.GRAIN_ABNORMALITY: 0.0}.get(d.type, 0.2)
    C = mu * t_beam * contrast_factor
    lateral = d.size_m if in_plane > 0.5 else d.size_m / max(d.aspect_ratio, 1.0)
    # blur: contrast diluted when the feature is smaller than the pixel
    C *= min(1.0, (lateral / ctx.p("rt.pixel")) ** 2)
    cnr = C * math.sqrt(ctx.p("rt.photons"))
    if cnr <= 0:
        return 0.0
    return float(norm.cdf((math.log(cnr) - math.log(ctx.p("rt.cnr_thr"))) / ctx.p("rt.sigma_ln")))
