"""Virtual metallography: connects the true statistical microstructure to measured quantities with counting statistics.

These are instrument simulations inside the twin: their values are SIMULATED (synthetic measurements),
never MEASURED.  Real laboratory data enters through the experiments database.
"""

from __future__ import annotations

import math
from dataclasses import dataclass

import numpy as np

from ..governance import ModelMeta, register
from ..microstructure.state import MaterialState
from ..params import P, Status, declare
from ..provenance import Provenance, Quantity

declare(
    P("mic.intercept_cv", 0.9, "-", Status.ILLUSTRATIVE, "coefficient of variation of a single lineal intercept", 0.2, 0.2, 3.0),
    P("mic.grain_bias", 0.0, "-", Status.ILLUSTRATIVE, "systematic relative bias of the grain-size estimate (etching/threshold)", 0.03, -0.3, 0.3),
    P("mic.particle_cv", 0.35, "-", Status.ILLUSTRATIVE, "coefficient of variation of measured particle radius", 0.1, 0.05, 1.5),
    P("mic.particle_bias", -0.05, "-", Status.ILLUSTRATIVE, "systematic bias of TEM radius (projection / truncation)", 0.03, -0.3, 0.3),
)
META = register(ModelMeta(
    model_name="virtual_metallography",
    equation="L_meas = L (1+b)(1 + cv/sqrt(N) xi) ; r_meas = r (1+b)(1 + cv/sqrt(N) xi)",
    parameter_source="registry mic.* (ILLUSTRATIVE)",
    validity_range="mean-lineal-intercept and TEM particle sizing; Gaussian counting error; independent fields",
    fidelity="ANALYTICAL",
))
_NOTE = "virtual instrument (synthetic measurement)"


@dataclass
class GrainMeasurement:
    intercept_L_m: Quantity
    intercept_T_m: Quantity
    intercept_N_m: Quantity
    equivalent_size_m: Quantity


def measure_grain_size(ctx, state: MaterialState, n_intercepts: int = 400) -> GrainMeasurement:  # type: ignore[no-untyped-def]
    ctx.use(META.model_name)
    g = state.grains
    assert g is not None
    rng = ctx.rng
    cv, bias = ctx.p("mic.intercept_cv"), ctx.p("mic.grain_bias")
    out = []
    for name, d in (("L", g.d_L), ("T", g.d_T), ("N", g.d_N)):
        rel = cv / math.sqrt(n_intercepts)
        m = d * (1.0 + bias) * (1.0 + rng.normal(0.0, rel))
        out.append(Quantity(f"mean_intercept_{name}", m, "m", d * rel, Provenance.SIMULATED, META.model_name, _NOTE))
    eq = (out[0].value * out[1].value * out[2].value) ** (1 / 3)
    sig = eq * math.sqrt(sum((q.sigma / q.value) ** 2 for q in out if q.sigma)) / 3.0
    return GrainMeasurement(out[0], out[1], out[2], Quantity("grain_size_equivalent", eq, "m", sig, Provenance.SIMULATED, META.model_name, _NOTE))


def measure_precipitate_radius(ctx, state: MaterialState, phase: str, n_particles: int = 300) -> Quantity:  # type: ignore[no-untyped-def]
    ctx.use(META.model_name)
    r = state.precip.mean_radius(phase)
    if r <= 0:
        return Quantity(f"{phase}_radius", 0.0, "m", None, Provenance.SIMULATED, META.model_name, "phase not present")
    rel = ctx.p("mic.particle_cv") / math.sqrt(n_particles)
    m = r * (1.0 + ctx.p("mic.particle_bias")) * (1.0 + ctx.rng.normal(0.0, rel))
    return Quantity(f"{phase}_radius", m, "m", r * rel, Provenance.SIMULATED, META.model_name, _NOTE)


def measure_recrystallised_fraction(ctx, state: MaterialState, n_fields: int = 40) -> Quantity:  # type: ignore[no-untyped-def]
    ctx.use(META.model_name)
    X = state.grains.recrystallised_fraction if state.grains else 0.0
    sd = math.sqrt(max(X * (1 - X), 1e-4) / n_fields)
    return Quantity("recrystallised_fraction", float(np.clip(X + ctx.rng.normal(0.0, sd), 0, 1)), "-", sd, Provenance.SIMULATED,
                    META.model_name, _NOTE)
