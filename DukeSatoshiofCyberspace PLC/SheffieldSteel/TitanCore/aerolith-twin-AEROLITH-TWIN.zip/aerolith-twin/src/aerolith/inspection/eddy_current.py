"""Eddy-current testing: skin depth from the electrical conductivity (itself a function of ageing state),
surface-crack response, and conductivity (temper) measurement."""

from __future__ import annotations

import math
from dataclasses import dataclass

import numpy as np
from scipy.stats import norm

from ..governance import ModelMeta, register
from ..microstructure.defects import Defect, DefectType
from ..microstructure.state import MaterialState
from ..params import P, Status, declare
from ..properties.thermal import thermal_properties

MU0 = 4.0e-7 * math.pi
declare(
    P("ect.noise", 0.05, "-", Status.ILLUSTRATIVE, "lift-off / conductivity-variation noise relative to a unit crack signal", 0.3, 0.0, 1.0, True),
    P("ect.thr", 2.5, "-", Status.ILLUSTRATIVE, "detection threshold in noise units; to be set by procedure qualification", 0.0),
    P("ect.sigma_ln", 0.35, "-", Status.ILLUSTRATIVE, "log-scatter of the crack signal", 0.1, 0.05, 1.5),
    P("ect.l0", 1.0e-3, "m", Status.ILLUSTRATIVE, "crack length at which the length factor is 0.5", 0.3, 1e-4, 1e-2, True),
    P("ect.cond_noise_rel", 0.005, "-", Status.ILLUSTRATIVE, "relative repeatability (1 sigma) of a conductivity reading", 0.3, 0.0, 0.1, True),
)
META = register(ModelMeta(
    model_name="eddy_current_surface",
    equation="delta = 1/sqrt(pi f mu0 sigma_e) ; S = (1-exp(-a/delta)) exp(-z/delta) l/(l+l0) ; POD = Phi((ln(S/N) - ln thr)/sigma_ln)",
    parameter_source="registry ect.* (ILLUSTRATIVE)",
    validity_range="surface and near-surface flaws in non-magnetic plate; single-frequency absolute coil; no edge effects",
))


@dataclass
class ECTSettings:
    frequency_hz: float = 100.0e3


def skin_depth(sigma_s_m: float, f: float) -> float:
    return 1.0 / math.sqrt(math.pi * f * MU0 * sigma_s_m)


def pod(ctx, state: MaterialState, d: Defect, s: ECTSettings) -> float:  # type: ignore[no-untyped-def]
    ctx.use(META.model_name)
    sigma = thermal_properties(ctx, state).conductivity_ms_m * 1e6
    delta = skin_depth(sigma, s.frequency_hz)
    H = state.dims_m[2]
    z = min(d.position[2], 1.0 - d.position[2]) * H  # depth below the nearer surface
    if d.type in (DefectType.SURFACE, DefectType.CRACK) or d.surface:
        depth = 0.5 * d.size_m if d.surface else 0.35 * d.size_m
    else:
        depth = 0.5 * d.size_m
    length = d.size_m * max(d.aspect_ratio, 1.0) ** 0.5
    sig = (1.0 - math.exp(-depth / delta)) * math.exp(-max(z - 0.0, 0.0) / delta) * length / (length + ctx.p("ect.l0"))
    if d.type in (DefectType.SEGREGATION, DefectType.GRAIN_ABNORMALITY):
        sig *= 0.05
    snr = max(sig, 1e-12) / ctx.p("ect.noise")
    return float(norm.cdf((math.log(snr) - math.log(ctx.p("ect.thr"))) / ctx.p("ect.sigma_ln")))


def measure_conductivity_iacs(ctx, state: MaterialState, rng: np.random.Generator) -> float:  # type: ignore[no-untyped-def]
    t = thermal_properties(ctx, state).iacs_percent
    return float(t * (1.0 + rng.normal(0.0, ctx.p("ect.cond_noise_rel"))))
