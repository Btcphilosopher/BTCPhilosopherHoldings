"""Combined NDT of a batch: per-defect probability of detection, detection draws, and missed-defect bookkeeping.

The twin knows the ground truth (the defect population); this module shows what inspection would see.
Acceptance criteria are supplied by the user: none are invented.
"""

from __future__ import annotations

from dataclasses import dataclass, field

from ..microstructure.defects import Defect, DefectType, assess_severity
from ..microstructure.state import MaterialState
from . import eddy_current as ect
from . import radiography as rt
from . import ultrasonic as us


@dataclass
class AcceptanceCriteria:
    """User-supplied rejection limits.  max_size_m maps defect type -> largest accepted indication size."""

    name: str = "UNSPECIFIED"
    max_size_m: dict[str, float] = field(default_factory=dict)
    source: str = "none supplied"

    @property
    def defined(self) -> bool:
        return bool(self.max_size_m)


@dataclass
class DetectionSummary:
    methods: list[str]
    n_true: int
    n_detected: int
    detected_ids: list[int]
    missed_ids: list[int]
    expected_detections: float
    largest_missed_size_m: float
    largest_missed_severity: float
    rejected: bool | None
    reject_reasons: list[str]
    pod_by_id: dict[int, float]
    criteria: AcceptanceCriteria


def combined_pod(ctx, state: MaterialState, d: Defect, methods: list[str], rho: float) -> float:  # type: ignore[no-untyped-def]
    miss = 1.0
    if "UT" in methods:
        miss *= 1.0 - us.pod(ctx, state, d, us.UTSettings())
    if "ECT" in methods:
        miss *= 1.0 - ect.pod(ctx, state, d, ect.ECTSettings())
    if "RT" in methods:
        miss *= 1.0 - rt.pod(ctx, state, d, rt.RTSettings(), rho)
    return 1.0 - miss


def inspect_batch(ctx, state: MaterialState, methods: list[str] | None = None, criteria: AcceptanceCriteria | None = None,  # type: ignore[no-untyped-def]
                  rho_kg_m3: float = 2700.0, applied_stress_mpa: float | None = None, K_mpa_sqrt_m: float | None = None) -> DetectionSummary:
    methods = methods or ["UT", "ECT", "RT"]
    criteria = criteria or AcceptanceCriteria()
    if applied_stress_mpa and K_mpa_sqrt_m:
        assess_severity(state.defects, applied_stress_mpa * 1e6, K_mpa_sqrt_m * 1e6)
    pods: dict[int, float] = {}
    det: list[int] = []
    miss: list[int] = []
    exp = 0.0
    for d in state.defects.defects:
        p = combined_pod(ctx, state, d, methods, rho_kg_m3)
        pods[d.id] = p
        exp += p
        if ctx.rng.random() < p:
            d.detected_by = list(methods)
            det.append(d.id)
        else:
            d.detected_by = []
            miss.append(d.id)
    by_id = {d.id: d for d in state.defects.defects}
    lm = max((by_id[i].size_m for i in miss), default=0.0)
    lsev = max((by_id[i].severity or 0.0 for i in miss), default=0.0)
    rejected: bool | None = None
    reasons: list[str] = []
    if criteria.defined:
        rejected = False
        for i in det:
            d = by_id[i]
            lim = criteria.max_size_m.get(d.type.value)
            if lim is not None and d.size_m > lim:
                rejected = True
                reasons.append(f"defect {i} ({d.type.value}) {d.size_m * 1e3:.2f} mm > {lim * 1e3:.2f} mm")
    return DetectionSummary(methods, len(by_id), len(det), det, miss, exp, lm, lsev, rejected, reasons[:20], pods, criteria)


_ = DefectType
