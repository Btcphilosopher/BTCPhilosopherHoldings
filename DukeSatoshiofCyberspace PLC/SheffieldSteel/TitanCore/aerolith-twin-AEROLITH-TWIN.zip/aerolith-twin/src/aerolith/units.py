"""Units and constants.  SI internally: K, Pa, m, s, kg, J, mol.

Conversions are explicit and named; nothing in the code base should add a bare
273.15 or a bare 1e6.  Quantities that carry a non-SI unit in their *name*
(e.g. ``yield_strength_MPa``) are for human-facing reporting only.
"""

from __future__ import annotations

import math

R_GAS = 8.314462618  # J mol-1 K-1
K_B = 1.380649e-23  # J K-1
N_A = 6.02214076e23  # mol-1
EV_J = 1.602176634e-19
KELVIN_OFFSET = 273.15
SECONDS_PER_MINUTE = 60.0
SECONDS_PER_HOUR = 3600.0
MPA = 1.0e6
GPA = 1.0e9
MM = 1.0e-3
UM = 1.0e-6
NM = 1.0e-9
AL_BURGERS_M = 2.86e-10  # |b| for FCC Al (a/sqrt2), a = 0.40495 nm
AL_LATTICE_M = 4.0495e-10
AL_MOLAR_VOLUME_M3 = 9.99e-6


def c_to_k(t_c: float) -> float:
    return t_c + KELVIN_OFFSET


def k_to_c(t_k: float) -> float:
    return t_k - KELVIN_OFFSET


def mpa_to_pa(x: float) -> float:
    return x * MPA


def pa_to_mpa(x: float) -> float:
    return x / MPA


def mm_to_m(x: float) -> float:
    return x * MM


def m_to_mm(x: float) -> float:
    return x / MM


def minutes_to_s(x: float) -> float:
    return x * SECONDS_PER_MINUTE


def hours_to_s(x: float) -> float:
    return x * SECONDS_PER_HOUR


def s_to_hours(x: float) -> float:
    return x / SECONDS_PER_HOUR


def arrhenius(prefactor: float, activation_j_mol: float, temperature_k: float) -> float:
    """prefactor * exp(-Q / (R T)).  Temperature must be in kelvin."""
    if temperature_k <= 0.0:
        raise ValueError("temperature must be in kelvin and > 0")
    return prefactor * math.exp(-activation_j_mol / (R_GAS * temperature_k))
