"""YAML specification loading for the CLI."""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import yaml

from .chemistry.composition import Composition
from .digital_twin.qualification import QualificationSpec, Requirement
from .inspection.defect_detection import AcceptanceCriteria
from .manufacturing.spec import RouteSpec


@dataclass
class Options:
    n_ensemble: int = 0
    n_posterior: int = 0
    seed: int = 0
    strict: bool = False
    outdir: str = "results"
    inspect_methods: list[str] = field(default_factory=lambda: ["UT", "ECT", "RT"])
    frozen_time: str | None = None


@dataclass
class Spec:
    batch_id: str
    composition: Composition
    route: RouteSpec
    options: Options
    criteria: AcceptanceCriteria | None
    qualification: QualificationSpec | None
    raw: dict[str, Any]


def load_spec(path: str | Path) -> Spec:
    raw = yaml.safe_load(Path(path).read_text()) or {}
    cw = dict(raw.get("composition_wt") or raw.get("composition") or {})
    if not cw:
        raise ValueError(f"{path}: 'composition_wt' is required")
    unc = raw.get("composition_uncertainty_wt") or {}
    comp = Composition(**cw, uncertainty_wt=unc, label=raw.get("label", ""), sum_tolerance_wt=float(raw.get("sum_tolerance_wt", 0.05)))
    route = RouteSpec(**(raw.get("route") or {}))
    opt = Options(**(raw.get("options") or {}))
    crit = None
    if raw.get("acceptance_criteria"):
        a = raw["acceptance_criteria"]
        crit = AcceptanceCriteria(a.get("name", "user"), {k: float(v) * 1e-3 for k, v in (a.get("max_size_mm") or {}).items()}, a.get("source", "user supplied"))
    qual = None
    if raw.get("qualification"):
        q = raw["qualification"]
        qual = QualificationSpec(q.get("name", "user"), [Requirement(**r) for r in q.get("requirements", [])],
                                 float(q.get("min_pass_probability", 0.9)), q.get("source", "user supplied"))
    return Spec(str(raw.get("batch_id", "AL-LI-000421")), comp, route, opt, crit, qual, raw)
