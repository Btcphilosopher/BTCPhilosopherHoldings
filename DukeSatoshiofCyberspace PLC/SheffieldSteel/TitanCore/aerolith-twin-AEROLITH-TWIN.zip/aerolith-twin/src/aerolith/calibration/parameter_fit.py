"""Calibration against experimental data: least squares with bounded, log-transformed parameters.

An experiment record carries: sample_id, composition, processing history, heat treatment, microstructure,
mechanical properties, inspection results and measurement uncertainty.  Training and validation sets are kept
separate (explicit `split` column, otherwise a deterministic hash split)."""

from __future__ import annotations

import hashlib
import math
from collections.abc import Callable
from dataclasses import dataclass, field
from typing import Any

import numpy as np
import pandas as pd
from scipy.optimize import least_squares

from ..context import RunContext
from ..params import ParameterRegistry, Status

ModelFn = Callable[[RunContext, dict[str, Any]], dict[str, float]]


def split_dataset(df: pd.DataFrame, validation_fraction: float = 0.3, id_col: str = "sample_id") -> tuple[pd.DataFrame, pd.DataFrame]:
    if "split" in df.columns:
        return df[df.split == "train"].copy(), df[df.split == "validation"].copy()
    h = df[id_col].map(lambda s: int(hashlib.sha256(str(s).encode()).hexdigest()[:8], 16) / 0xFFFFFFFF)
    return df[h >= validation_fraction].copy(), df[h < validation_fraction].copy()


@dataclass
class FitResult:
    parameters: dict[str, float]
    initial: dict[str, float]
    sigma_estimate: dict[str, float]
    cost: float
    n_train: int
    n_validation: int
    train_rmse: dict[str, float]
    validation_rmse: dict[str, float]
    train_r2: dict[str, float]
    validation_r2: dict[str, float]
    success: bool
    calibrated_registry: ParameterRegistry
    dataset_id: str
    predictions_validation: pd.DataFrame = field(default_factory=pd.DataFrame)


def _theta_to_values(reg: ParameterRegistry, names: list[str], theta: np.ndarray) -> dict[str, float]:
    out = {}
    for n, t in zip(names, theta, strict=True):
        p = reg.get(n)
        out[n] = float(math.exp(t)) if p.log_scale else float(t)
    return out


def _values_to_theta(reg: ParameterRegistry, names: list[str]) -> np.ndarray:
    return np.array([math.log(reg.value(n)) if reg.get(n).log_scale else reg.value(n) for n in names])


def _bounds(reg: ParameterRegistry, names: list[str]) -> tuple[np.ndarray, np.ndarray]:
    lo, hi = [], []
    for n in names:
        p = reg.get(n)
        a = p.valid_min if p.valid_min is not None else -np.inf
        b = p.valid_max if p.valid_max is not None else np.inf
        if p.log_scale:
            a, b = (math.log(a) if a > 0 else -np.inf), (math.log(b) if b > 0 else np.inf)
        lo.append(a)
        hi.append(b)
    return np.array(lo), np.array(hi)


def _predict(reg: ParameterRegistry, df: pd.DataFrame, model: ModelFn, targets: list[str], seed: int = 0) -> pd.DataFrame:
    rows = []
    for _, rec in df.iterrows():
        ctx = RunContext(reg, np.random.default_rng(seed))
        out = model(ctx, rec.to_dict())
        rows.append({t: out[t] for t in targets})
    return pd.DataFrame(rows, index=df.index)


def _metrics(pred: pd.DataFrame, obs: pd.DataFrame, targets: list[str]) -> tuple[dict[str, float], dict[str, float]]:
    rmse, r2 = {}, {}
    for t in targets:
        e = pred[t].to_numpy(float) - obs[t].to_numpy(float)
        rmse[t] = float(np.sqrt(np.mean(e**2))) if e.size else float("nan")
        var = float(np.var(obs[t].to_numpy(float)))
        r2[t] = float(1.0 - np.mean(e**2) / var) if var > 0 and e.size else float("nan")
    return rmse, r2


def calibrate(registry: ParameterRegistry, df: pd.DataFrame, model: ModelFn, param_names: list[str], targets: list[str],
              sigma_cols: dict[str, str] | None = None, dataset_id: str = "dataset", validation_fraction: float = 0.3,
              max_nfev: int = 60, prior_weight: float = 0.0) -> FitResult:
    """Fit ``param_names`` to the training rows; report error on the held-out rows.

    Residuals are (prediction - observation)/sigma, sigma from ``sigma_cols[target]`` (column) or 5 % of the value.
    ``prior_weight`` adds a Gaussian prior pull toward the initial value using the parameter's registered uncertainty.
    """
    train, val = split_dataset(df, validation_fraction)
    reg0 = registry.copy()
    names = list(param_names)
    theta0 = _values_to_theta(reg0, names)
    lo, hi = _bounds(reg0, names)
    scale = np.maximum(np.abs(theta0), 1e-12)

    def sig(frame: pd.DataFrame, t: str) -> np.ndarray:
        if sigma_cols and t in sigma_cols and sigma_cols[t] in frame:
            return np.maximum(frame[sigma_cols[t]].to_numpy(float), 1e-12)
        return np.maximum(0.05 * np.abs(frame[t].to_numpy(float)), 1e-12)

    def resid(th: np.ndarray) -> np.ndarray:
        reg = reg0.copy()
        for n, v in _theta_to_values(reg0, names, th).items():
            reg.override(n, v, Status.CALIBRATED, source=f"calibrated on {dataset_id}")
        pred = _predict(reg, train, model, targets)
        r = np.concatenate([(pred[t].to_numpy(float) - train[t].to_numpy(float)) / sig(train, t) for t in targets])
        if prior_weight > 0:
            pr = [(th[i] - theta0[i]) / max(reg0.get(n).uncertainty, 1e-9 * scale[i]) * prior_weight for i, n in enumerate(names)]
            r = np.concatenate([r, pr])
        return r

    sol = least_squares(resid, theta0, bounds=(lo, hi), x_scale=np.maximum(scale * 0.1, 1e-6), max_nfev=max_nfev)
    vals = _theta_to_values(reg0, names, sol.x)
    cal = reg0.copy(label=f"calibrated:{dataset_id}")
    J = sol.jac
    try:
        cov = np.linalg.inv(J.T @ J)
        s = np.sqrt(np.diag(cov))
    except np.linalg.LinAlgError:
        s = np.full(len(names), np.nan)
    sig_est = {}
    for i, n in enumerate(names):
        p = reg0.get(n)
        sig_est[n] = float(s[i]) if p.log_scale else float(s[i])
        cal.override(n, vals[n], Status.CALIBRATED, uncertainty=float(s[i]) if np.isfinite(s[i]) else p.uncertainty,
                     source=f"calibrated on {dataset_id}")
    ptr = _predict(cal, train, model, targets)
    pva = _predict(cal, val, model, targets) if len(val) else pd.DataFrame(columns=targets)
    tr_rmse, tr_r2 = _metrics(ptr, train, targets)
    va_rmse, va_r2 = _metrics(pva, val, targets) if len(val) else ({}, {})
    return FitResult(vals, {n: reg0.value(n) for n in names}, sig_est, float(sol.cost), len(train), len(val), tr_rmse, va_rmse, tr_r2, va_r2,
                     bool(sol.success), cal, dataset_id, pd.concat([pva.add_suffix("_pred"), val[targets].add_suffix("_obs")], axis=1) if len(val) else pd.DataFrame())
