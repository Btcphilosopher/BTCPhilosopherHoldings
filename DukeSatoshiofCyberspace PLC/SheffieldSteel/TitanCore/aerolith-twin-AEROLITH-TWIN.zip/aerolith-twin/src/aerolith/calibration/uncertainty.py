"""Monte Carlo utilities: Latin-hypercube sampling, distribution summaries, variance by source."""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np
from scipy.stats import norm, qmc


def latin_hypercube_normal(n: int, sigmas: np.ndarray, seed: int = 0) -> np.ndarray:
    """(n, d) stratified standard-normal draws scaled by sigmas."""
    d = len(sigmas)
    u = qmc.LatinHypercube(d=d, seed=seed).random(n)
    return norm.ppf(np.clip(u, 1e-9, 1 - 1e-9)) * np.asarray(sigmas)


@dataclass
class Summary:
    mean: float
    sigma: float
    ci95: tuple[float, float]
    p05: float
    p50: float
    p95: float
    n: int

    def to_dict(self) -> dict[str, float | int | list[float]]:
        return {"mean": self.mean, "sigma": self.sigma, "ci95": list(self.ci95), "p05": self.p05, "p50": self.p50, "p95": self.p95, "n": self.n}


def summarise(x: np.ndarray) -> Summary:
    x = np.asarray(x, float)
    x = x[np.isfinite(x)]
    if x.size == 0:
        return Summary(float("nan"), float("nan"), (float("nan"), float("nan")), float("nan"), float("nan"), float("nan"), 0)
    lo, med, hi, l95, h95 = np.percentile(x, [5, 50, 95, 2.5, 97.5])
    return Summary(float(x.mean()), float(x.std(ddof=1)) if x.size > 1 else 0.0, (float(l95), float(h95)), float(lo), float(med), float(hi), int(x.size))


def combine_sigma(*sigmas: float) -> float:
    return float(np.sqrt(sum(s**2 for s in sigmas)))


def variance_fractions(source_sigmas: dict[str, float]) -> dict[str, float]:
    """Fractional contribution of each source to the (summed) variance (sources treated as independent)."""
    tot = sum(s**2 for s in source_sigmas.values())
    return {k: (s**2 / tot if tot > 0 else 0.0) for k, s in source_sigmas.items()}


def mc_standard_error(x: np.ndarray) -> float:
    x = np.asarray(x, float)
    return float(x.std(ddof=1) / np.sqrt(x.size))


def running_mean(x: np.ndarray) -> np.ndarray:
    return np.cumsum(x) / np.arange(1, x.size + 1)
