"""Model functions for calibration: record -> predicted properties."""

from __future__ import annotations

import math
from typing import Any

import numpy as np

from ..chemistry.composition import Composition
from ..chemistry.elements import ATOMIC_MASS_G_MOL
from ..context import RunContext
from ..manufacturing.process_chain import run_route
from ..manufacturing.spec import RouteSpec
from ..microstructure.grains import GrainState
from ..microstructure.precipitates import DR, NB, R_GRID
from ..microstructure.state import MaterialState, wt_to_atom_fraction_scale
from ..properties.evaluate import evaluate_properties
from ..properties.strength import evaluate_strength

_ELEMS = ("Li", "Cu", "Mg", "Zn", "Ag", "Zr", "Sc", "Mn", "Fe", "Si", "Ti")


def state_from_record(rec: dict[str, Any]) -> MaterialState:
    """Build a MaterialState from *measured microstructure* columns of an experiment record.

    Columns (all optional unless noted): <El> (wt%, composition), grain_size_um, grain_aspect_ratio, recrystallised_fraction,
    subgrain_size_um, dislocation_density_m2, <phase>_fraction, <phase>_radius_nm for phase in delta_prime, T1, theta_prime, Al3Zr,
    Al3Sc, matrix_<El>_wt (free solute, wt%), insoluble_constituent_fraction, porosity_fraction.
    """
    comp = Composition(**{e: float(rec.get(e, 0.0) or 0.0) for e in _ELEMS})  # type: ignore[arg-type]
    d = float(rec.get("grain_size_um", 50.0)) * 1e-6
    ar = float(rec.get("grain_aspect_ratio", 1.0))
    st = MaterialState(comp, (1.0, 1.0, 0.025), "experiment", "measured")
    st.grains = GrainState(d * ar ** (2 / 3), d, d / ar ** (1 / 3) if False else d * ar ** (-1 / 3) * ar ** (0.0), 0.5,
                           float(rec.get("recrystallised_fraction", 0.0)), float(rec.get("subgrain_size_um", 3.0)) * 1e-6)
    # keep the geometric mean size equal to grain_size_um for any aspect ratio
    L = d * ar ** (2.0 / 3.0)
    N = d * ar ** (-1.0 / 3.0)
    st.grains = GrainState(L, N, N, 0.5, float(rec.get("recrystallised_fraction", 0.0)), float(rec.get("subgrain_size_um", 3.0)) * 1e-6)
    st.dislocation_density = float(rec.get("dislocation_density_m2", 1e13))
    st.insoluble_constituent_fraction = float(rec.get("insoluble_constituent_fraction", 0.002))
    for ph in ("delta_prime", "T1", "theta_prime", "Al3Zr", "Al3Sc"):
        f, r = float(rec.get(f"{ph}_fraction", 0.0) or 0.0), float(rec.get(f"{ph}_radius_nm", 0.0) or 0.0) * 1e-9
        if f > 0 and r > 0:
            n = np.zeros(NB)
            b = int(np.clip(round((r - R_GRID[0]) / DR), 0, NB - 1))
            n[b] = f / (4.0 / 3.0 * math.pi * R_GRID[b] ** 3)
            st.precip.n[ph] = n
    # free solute: if provided use it, else assume the nominal solute less what the measured precipitates hold
    scale = wt_to_atom_fraction_scale(comp)
    st.solute_pool_at = {el: comp.wt()[el] / ATOMIC_MASS_G_MOL[el] / scale for el in ("Li", "Cu", "Zr", "Sc")}
    p = float(rec.get("porosity_fraction", 0.0) or 0.0)
    st.defects.bulk["cast_porosity_fraction"] = p
    return st


def strength_from_microstructure(ctx: RunContext, rec: dict[str, Any]) -> dict[str, float]:
    st = state_from_record(rec)
    ps = evaluate_properties(ctx, st)
    v = ps.values()
    return {"yield_strength": v["yield_strength"], "uts": v["uts"], "elongation": v["elongation"],
            "fracture_toughness": v["fracture_toughness"], "density": v["density"], "E_L": v["E_L"]}


def properties_from_route(ctx: RunContext, rec: dict[str, Any]) -> dict[str, float]:
    """Full-chain model: record carries composition columns and a JSON route (column 'route_json')."""
    import json

    comp = Composition(**{e: float(rec.get(e, 0.0) or 0.0) for e in _ELEMS})  # type: ignore[arg-type]
    route = RouteSpec(**json.loads(rec["route_json"])) if rec.get("route_json") else RouteSpec()
    ch = run_route(ctx, comp, route, str(rec.get("sample_id", "SAMPLE")), keep_snapshots=False)
    assert ch.properties is not None
    return ch.properties.values()


_ = evaluate_strength
