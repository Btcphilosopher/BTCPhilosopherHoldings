"""Bayesian calibration: adaptive Metropolis sampling of parameter posteriors (Gaussian likelihood, bounded priors)."""

from __future__ import annotations

import math
from dataclasses import dataclass

import numpy as np
import pandas as pd

from ..params import ParameterRegistry
from .parameter_fit import ModelFn, _bounds, _predict, _theta_to_values, _values_to_theta, split_dataset


@dataclass
class PosteriorResult:
    names: list[str]
    samples: np.ndarray  # (n, d) in parameter space (natural units)
    log_post: np.ndarray
    acceptance: float
    summary: pd.DataFrame
    rhat: dict[str, float]


def _gelman_rubin(chains: np.ndarray) -> np.ndarray:
    m, n, d = chains.shape
    means = chains.mean(axis=1)
    W = chains.var(axis=1, ddof=1).mean(axis=0)
    B = n * means.var(axis=0, ddof=1)
    var = (n - 1) / n * W + B / n
    return np.sqrt(var / np.maximum(W, 1e-300))


def metropolis(registry: ParameterRegistry, df: pd.DataFrame, model: ModelFn, param_names: list[str], targets: list[str],
               sigma_cols: dict[str, str] | None = None, n_steps: int = 600, burn: int = 200, seed: int = 0, n_chains: int = 2,
               discrepancy_rel: float = 0.02, use_training_only: bool = True, prior_from_registry: bool = True) -> PosteriorResult:
    """Adaptive Metropolis (Haario) on the training rows.  Priors: N(value, sigma_registered) in the sampling coordinate
    (log for log-scale parameters) truncated to the validity range; flat if the registered uncertainty is zero."""
    train, _ = split_dataset(df) if use_training_only else (df, df)
    names = list(param_names)
    theta0 = _values_to_theta(registry, names)
    lo, hi = _bounds(registry, names)
    prior_sd = np.array([max(registry.get(n).uncertainty, 0.0) if prior_from_registry else 0.0 for n in names])
    d = len(names)

    def sig(t: str) -> np.ndarray:
        s = np.maximum(0.0, train[sigma_cols[t]].to_numpy(float)) if sigma_cols and t in sigma_cols and sigma_cols[t] in train else 0.0
        return np.sqrt(s**2 + (discrepancy_rel * np.abs(train[t].to_numpy(float))) ** 2) + 1e-12

    def logpost(th: np.ndarray) -> float:
        if np.any(th < lo) or np.any(th > hi):
            return -np.inf
        reg = registry.copy()
        for n, v in _theta_to_values(registry, names, th).items():
            reg.override(n, v)
        pred = _predict(reg, train, model, targets)
        ll = 0.0
        for t in targets:
            r = (pred[t].to_numpy(float) - train[t].to_numpy(float)) / sig(t)
            ll += -0.5 * float(np.sum(r**2))
        lp = 0.0
        for i in range(d):
            if prior_sd[i] > 0:
                lp += -0.5 * ((th[i] - theta0[i]) / prior_sd[i]) ** 2
        return ll + lp

    chains, lps, acc = [], [], 0
    rng0 = np.random.default_rng(seed)
    for c in range(n_chains):
        rng = np.random.default_rng(rng0.integers(1 << 31))
        th = theta0 + rng.normal(0, 0.05 * np.maximum(np.abs(theta0), 1e-6)) if c else theta0.copy()
        th = np.clip(th, lo + 1e-12, hi - 1e-12)
        cur = logpost(th)
        cov = np.diag((0.1 * np.maximum(np.abs(theta0), 1e-3)) ** 2)
        hist: list[np.ndarray] = []
        lph: list[float] = []
        for k in range(n_steps):
            if k > 50 and k % 25 == 0:
                H = np.array(hist)
                cov = np.cov(H.T) * (2.38**2 / d) + 1e-12 * np.eye(d) if d > 1 else np.array([[np.var(H) * 2.38**2 + 1e-12]])
            prop = rng.multivariate_normal(th, np.atleast_2d(cov))
            lp = logpost(prop)
            if math.log(rng.random() + 1e-300) < lp - cur:
                th, cur = prop, lp
                acc += 1
            hist.append(th.copy())
            lph.append(cur)
        chains.append(np.array(hist))
        lps.append(np.array(lph))
    arr = np.array(chains)[:, burn:, :]
    flat = arr.reshape(-1, d)
    nat = np.array([[(_theta_to_values(registry, names, row))[n] for n in names] for row in flat])
    rows = []
    for i, n in enumerate(names):
        x = nat[:, i]
        rows.append({"parameter": n, "mean": x.mean(), "sd": x.std(ddof=1), "ci95_lo": np.percentile(x, 2.5), "ci95_hi": np.percentile(x, 97.5)})
    rhat = dict(zip(names, _gelman_rubin(arr).tolist(), strict=True)) if n_chains > 1 else {}
    return PosteriorResult(names, nat, np.concatenate([l[burn:] for l in lps]), acc / (n_chains * n_steps), pd.DataFrame(rows).set_index("parameter"), rhat)
