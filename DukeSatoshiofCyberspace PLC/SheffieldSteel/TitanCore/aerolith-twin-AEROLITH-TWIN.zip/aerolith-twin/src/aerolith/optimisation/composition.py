"""Candidate alloy library and comparison.  No composition is called 'best': candidates are placed on a Pareto front."""

from __future__ import annotations

import numpy as np
import pandas as pd

from ..chemistry.composition import Composition
from ..context import RunContext
from ..manufacturing.process_chain import run_route
from ..manufacturing.spec import RouteSpec
from ..params import ParameterRegistry
from .multiobjective import OBJECTIVES, dominated_by, objective_vector, pareto_mask

# Representative chemistries inspired by published Al-Li-Cu alloy families.  They are NOT registered
# compositions or specifications; consult the registering body's limits before any real use.
CANDIDATES: dict[str, Composition] = {
    "Candidate A": Composition(Li=1.0, Cu=4.0, Mg=0.4, Ag=0.4, Zr=0.12, label="Candidate A: Cu-rich / Li-lean, Ag+Mg"),
    "Candidate B": Composition(Li=2.4, Cu=1.2, Mg=0.8, Zr=0.12, label="Candidate B: Li-rich / low-Cu, Mg"),
    "Candidate C": Composition(Li=1.8, Cu=2.7, Mg=0.3, Zn=0.7, Mn=0.3, Zr=0.09, label="Candidate C: mid-Li, Cu+Zn+Mn"),
    "Candidate D": Composition(Li=1.3, Cu=3.5, Mg=0.4, Ag=0.3, Zr=0.10, Sc=0.08, label="Candidate D: Sc-modified Cu-Li-Ag"),
}


def custom_candidate(**wt: float) -> Composition:
    return Composition(**wt, label="Custom")  # type: ignore[arg-type]


def compare_candidates(registry: ParameterRegistry, route: RouteSpec, candidates: dict[str, Composition] | None = None,
                       objectives: list[str] | None = None, seed: int = 0) -> pd.DataFrame:
    """Deterministic run of every candidate through the same route, then Pareto classification (no ranking)."""
    candidates = candidates or CANDIDATES
    objectives = objectives or ["specific_strength", "specific_modulus", "fracture_toughness", "fatigue_strength_1e7", "density",
                                "corrosion_index", "complexity", "cost_usd_kg"]
    rows = []
    for name, comp in candidates.items():
        ctx = RunContext(registry, np.random.default_rng(seed))
        ch = run_route(ctx, comp, route, name, keep_snapshots=False)
        assert ch.properties is not None and ch.cost is not None
        v = dict(ch.properties.values())
        v["complexity"], v["cost_usd_kg"] = ch.cost.complexity, ch.cost.usd_per_kg
        v["yield_strength"] = v["yield_strength_L"]
        rows.append({"candidate": name, **{k: v[k] for k in set(objectives) | {"yield_strength", "uts", "elongation", "grain_size"}}})
    df = pd.DataFrame(rows).set_index("candidate")
    F = np.array([objective_vector(df.loc[i], objectives) for i in df.index])
    mask = pareto_mask(F)
    df["pareto_status"] = np.where(mask, "NON-DOMINATED", "DOMINATED")
    df["dominated_by"] = ["" if mask[i] else ", ".join(df.index[j] for j in dominated_by(F, i)) for i in range(len(df))]
    return df


_ = OBJECTIVES
