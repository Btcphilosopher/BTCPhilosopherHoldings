"""Whole-route optimisation: composition + homogenisation + solution + quench + stretch + ageing as one decision vector."""

from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np
import pandas as pd

from ..chemistry.composition import Composition
from ..context import RunContext
from ..manufacturing.process_chain import run_route
from ..manufacturing.spec import HomogStep, RouteSpec
from ..params import ParameterRegistry
from .multiobjective import NSGAResult, nsga2, objective_vector

DEFAULT_BOUNDS: dict[str, tuple[float, float]] = {
    "Li": (0.8, 2.4), "Cu": (1.0, 4.5), "Mg": (0.0, 0.9), "Ag": (0.0, 0.45), "Zn": (0.0, 0.8), "Zr": (0.08, 0.14), "Mn": (0.0, 0.4),
    "homog_T2_C": (480.0, 505.0), "solution_C": (495.0, 525.0), "solution_hold_min": (30.0, 120.0), "quench_flow_m_s": (0.5, 2.0),
    "stretch_percent": (0.0, 5.0), "ageing_T_C": (140.0, 190.0), "ageing_time_h": (8.0, 100.0),
}


@dataclass
class DesignSpace:
    bounds: dict[str, tuple[float, float]] = field(default_factory=lambda: dict(DEFAULT_BOUNDS))
    base_route: RouteSpec = field(default_factory=RouteSpec)

    @property
    def names(self) -> list[str]:
        return list(self.bounds)

    @property
    def lo(self) -> np.ndarray:
        return np.array([b[0] for b in self.bounds.values()])

    @property
    def hi(self) -> np.ndarray:
        return np.array([b[1] for b in self.bounds.values()])

    def decode(self, x: np.ndarray) -> tuple[Composition, RouteSpec]:
        v = dict(zip(self.names, map(float, x), strict=True))
        comp = Composition(**{e: v[e] for e in ("Li", "Cu", "Mg", "Ag", "Zn", "Zr", "Mn") if e in v})  # type: ignore[arg-type]
        r = self.base_route.model_copy(deep=True)
        if "homog_T2_C" in v:
            r.homogenisation.steps = [r.homogenisation.steps[0], HomogStep(temperature_C=v["homog_T2_C"], hold_h=r.homogenisation.steps[-1].hold_h)]
        if "solution_C" in v:
            r.solution.temperature_C = v["solution_C"]
        if "solution_hold_min" in v:
            r.solution.hold_min = v["solution_hold_min"]
        if "quench_flow_m_s" in v:
            r.quench.flow_m_s = v["quench_flow_m_s"]
        if "stretch_percent" in v:
            r.quench.stretch_percent = v["stretch_percent"]
        if "ageing_T_C" in v:
            r.ageing.temperature_C = v["ageing_T_C"]
        if "ageing_time_h" in v:
            r.ageing.time_h = v["ageing_time_h"]
        return comp, r


@dataclass
class Constraint:
    output: str
    minimum: float | None = None
    maximum: float | None = None


def evaluate_design(registry: ParameterRegistry, space: DesignSpace, x: np.ndarray, seed: int = 0) -> dict[str, float]:
    comp, route = space.decode(x)
    ctx = RunContext(registry, np.random.default_rng(seed))
    ch = run_route(ctx, comp, route, "OPT", keep_snapshots=False)
    assert ch.properties is not None and ch.cost is not None
    v = dict(ch.properties.values())
    v["complexity"], v["cost_usd_kg"] = ch.cost.complexity, ch.cost.usd_per_kg
    v["yield_strength"] = v["yield_strength_L"]
    return v


def optimise_route(registry: ParameterRegistry, objectives: list[str], constraints: list[Constraint] | None = None,
                   space: DesignSpace | None = None, pop: int = 24, gens: int = 8, seed: int = 0) -> tuple[NSGAResult, pd.DataFrame, DesignSpace]:
    """Answers: which material/process combinations produce the desired property envelope?  Output = a Pareto set, not one winner."""
    space = space or DesignSpace()
    constraints = constraints or []

    def ev(x: np.ndarray) -> tuple[np.ndarray, float]:
        try:
            v = evaluate_design(registry, space, x)
        except Exception:  # an infeasible route (e.g. numerical failure) is simply infeasible
            return np.full(len(objectives), 1e9), 1e9
        viol = 0.0
        for c in constraints:
            if c.minimum is not None:
                viol += max(0.0, (c.minimum - v[c.output]) / max(abs(c.minimum), 1e-9))
            if c.maximum is not None:
                viol += max(0.0, (v[c.output] - c.maximum) / max(abs(c.maximum), 1e-9))
        return objective_vector(v, objectives), viol

    res = nsga2(ev, space.lo, space.hi, pop, gens, seed)
    rows = []
    for i in res.fronts[0]:
        v = evaluate_design(registry, space, res.X[i])
        rows.append({**dict(zip(space.names, res.X[i], strict=True)), **{k: v[k] for k in set(objectives) | {"yield_strength", "uts", "elongation"}},
                     "constraint_violation": res.violation[i], "pareto_status": "NON-DOMINATED"})
    return res, pd.DataFrame(rows), space
