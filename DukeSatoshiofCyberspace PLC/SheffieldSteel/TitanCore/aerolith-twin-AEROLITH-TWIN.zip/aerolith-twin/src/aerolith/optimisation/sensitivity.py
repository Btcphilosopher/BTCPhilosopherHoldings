"""Global and local sensitivity: Sobol indices (scipy) and normalised finite-difference sensitivities."""

from __future__ import annotations

from collections.abc import Callable

import numpy as np
import pandas as pd
from scipy.stats import qmc, sobol_indices, uniform


def sobol(func: Callable[[np.ndarray], np.ndarray], lo: np.ndarray, hi: np.ndarray, names: list[str], n: int = 256, seed: int = 0) -> pd.DataFrame:
    """First-order and total Sobol indices for a vectorised function f(X (d, N)) -> (N,) over a uniform box."""
    dists = [uniform(loc=l, scale=h - l) for l, h in zip(lo, hi, strict=True)]
    rng = np.random.default_rng(seed)
    res = sobol_indices(func=func, n=n, dists=dists, random_state=rng)
    return pd.DataFrame({"first_order": res.first_order, "total": res.total_order}, index=names)


def local_sensitivity(func: Callable[[np.ndarray], float], x0: np.ndarray, names: list[str], rel_step: float = 0.02) -> pd.DataFrame:
    """Normalised sensitivities d ln f / d ln x (central differences)."""
    f0 = func(x0)
    rows = []
    for i, n in enumerate(names):
        h = rel_step * max(abs(x0[i]), 1e-6)
        xp, xm = x0.copy(), x0.copy()
        xp[i] += h
        xm[i] -= h
        rows.append({"parameter": n, "dlnf_dlnx": (func(xp) - func(xm)) / (2 * h) * x0[i] / f0 if f0 else float("nan")})
    return pd.DataFrame(rows).set_index("parameter")


def sample_box(lo: np.ndarray, hi: np.ndarray, n: int, seed: int = 0) -> np.ndarray:
    return qmc.scale(qmc.Sobol(d=len(lo), seed=seed).random(n), lo, hi)
