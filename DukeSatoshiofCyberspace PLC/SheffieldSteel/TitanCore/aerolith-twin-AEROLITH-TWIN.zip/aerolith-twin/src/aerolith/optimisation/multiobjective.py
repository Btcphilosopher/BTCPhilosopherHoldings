"""Multi-objective machinery: objective table, Pareto dominance, NSGA-II."""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass

import numpy as np

# objective name -> (output key, +1 maximise / -1 minimise, label)
OBJECTIVES: dict[str, tuple[int, str]] = {
    "specific_strength": (+1, "kN m/kg"), "specific_modulus": (+1, "MN m/kg"), "fracture_toughness": (+1, "MPa m^0.5"),
    "fatigue_strength_1e7": (+1, "MPa"), "density": (-1, "kg/m3"), "corrosion_index": (-1, "-"), "complexity": (-1, "-"),
    "cost_usd_kg": (-1, "USD/kg"), "robustness": (+1, "yield probability"),
}


def objective_vector(row, objectives: list[str]) -> np.ndarray:  # type: ignore[no-untyped-def]
    """Vector to MINIMISE (maximised objectives are negated)."""
    return np.array([(-float(row[o]) if OBJECTIVES[o][0] > 0 else float(row[o]))
                     for o in objectives])


def dominates(a: np.ndarray, b: np.ndarray) -> bool:
    return bool(np.all(a <= b) and np.any(a < b))


def pareto_mask(F: np.ndarray) -> np.ndarray:
    n = len(F)
    m = np.ones(n, bool)
    for i in range(n):
        for j in range(n):
            if i != j and dominates(F[j], F[i]):
                m[i] = False
                break
    return m


def dominated_by(F: np.ndarray, i: int) -> list[int]:
    return [j for j in range(len(F)) if j != i and dominates(F[j], F[i])]


def non_dominated_sort(F: np.ndarray, viol: np.ndarray | None = None) -> list[list[int]]:
    n = len(F)
    viol = np.zeros(n) if viol is None else viol

    def dom(i: int, j: int) -> bool:
        if viol[i] == 0 and viol[j] > 0:
            return True
        if viol[i] > 0 and viol[j] == 0:
            return False
        if viol[i] > 0 and viol[j] > 0:
            return viol[i] < viol[j]
        return dominates(F[i], F[j])

    S: list[list[int]] = [[] for _ in range(n)]
    cnt = np.zeros(n, int)
    fronts: list[list[int]] = [[]]
    for i in range(n):
        for j in range(n):
            if i == j:
                continue
            if dom(i, j):
                S[i].append(j)
            elif dom(j, i):
                cnt[i] += 1
        if cnt[i] == 0:
            fronts[0].append(i)
    k = 0
    while fronts[k]:
        nxt = []
        for i in fronts[k]:
            for j in S[i]:
                cnt[j] -= 1
                if cnt[j] == 0:
                    nxt.append(j)
        k += 1
        fronts.append(nxt)
    return fronts[:-1]


def crowding_distance(F: np.ndarray) -> np.ndarray:
    n, m = F.shape
    d = np.zeros(n)
    for k in range(m):
        idx = np.argsort(F[:, k])
        d[idx[0]] = d[idx[-1]] = np.inf
        rng = F[idx[-1], k] - F[idx[0], k]
        if rng <= 0:
            continue
        d[idx[1:-1]] += (F[idx[2:], k] - F[idx[:-2], k]) / rng
    return d


def hypervolume_2d(F: np.ndarray, ref: np.ndarray) -> float:
    """Dominated hypervolume of a 2-objective minimisation front relative to ``ref``."""
    P = F[pareto_mask(F)]
    P = P[np.all(P <= ref, axis=1)]
    if len(P) == 0:
        return 0.0
    P = P[np.argsort(P[:, 0])]
    hv, prev = 0.0, ref[1]
    for x, y in P:
        hv += (ref[0] - x) * (prev - y)
        prev = y
    return float(hv)


@dataclass
class NSGAResult:
    X: np.ndarray
    F: np.ndarray
    violation: np.ndarray
    fronts: list[list[int]]
    history: list[np.ndarray]
    n_evaluations: int


def nsga2(evaluate: Callable[[np.ndarray], tuple[np.ndarray, float]], lo: np.ndarray, hi: np.ndarray, pop: int = 24, gens: int = 10,
          seed: int = 0, eta_c: float = 15.0, eta_m: float = 20.0, p_mut: float | None = None, X0: np.ndarray | None = None) -> NSGAResult:
    """NSGA-II (SBX crossover, polynomial mutation, constraint-dominance).  ``evaluate`` -> (objective vector to minimise, violation >= 0)."""
    rng = np.random.default_rng(seed)
    d = len(lo)
    p_mut = 1.0 / d if p_mut is None else p_mut
    cache: dict[bytes, tuple[np.ndarray, float]] = {}
    nev = 0

    def ev(x: np.ndarray) -> tuple[np.ndarray, float]:
        nonlocal nev
        key = np.round(x, 6).tobytes()
        if key not in cache:
            cache[key] = evaluate(x)
            nev += 1
        return cache[key]

    X = lo + rng.random((pop, d)) * (hi - lo)
    if X0 is not None:
        X[: len(X0)] = X0
    FV = [ev(x) for x in X]
    F = np.array([f for f, _ in FV])
    V = np.array([v for _, v in FV])
    hist = [F.copy()]

    def tournament(rank: np.ndarray, crowd: np.ndarray) -> int:
        a, b = rng.integers(len(rank), size=2)
        if rank[a] != rank[b]:
            return a if rank[a] < rank[b] else b
        return a if crowd[a] >= crowd[b] else b

    def ranks(F_: np.ndarray, V_: np.ndarray) -> tuple[np.ndarray, np.ndarray, list[list[int]]]:
        fronts = non_dominated_sort(F_, V_)
        rk = np.zeros(len(F_), int)
        cd = np.zeros(len(F_))
        for r, fr in enumerate(fronts):
            rk[fr] = r
            cd[fr] = crowding_distance(F_[fr]) if len(fr) > 2 else np.inf
        return rk, cd, fronts

    for _ in range(gens):
        rk, cd, _f = ranks(F, V)
        kids: list[np.ndarray] = []
        while len(kids) < pop:
            p1, p2 = X[tournament(rk, cd)], X[tournament(rk, cd)]
            c1, c2 = p1.copy(), p2.copy()
            if rng.random() < 0.9:
                for k in range(d):
                    if rng.random() < 0.5 and abs(p1[k] - p2[k]) > 1e-12:
                        u = rng.random()
                        beta = (2 * u) ** (1 / (eta_c + 1)) if u <= 0.5 else (1 / (2 * (1 - u))) ** (1 / (eta_c + 1))
                        c1[k] = 0.5 * ((1 + beta) * p1[k] + (1 - beta) * p2[k])
                        c2[k] = 0.5 * ((1 - beta) * p1[k] + (1 + beta) * p2[k])
            for c in (c1, c2):
                for k in range(d):
                    if rng.random() < p_mut:
                        u = rng.random()
                        delta = (2 * u) ** (1 / (eta_m + 1)) - 1 if u < 0.5 else 1 - (2 * (1 - u)) ** (1 / (eta_m + 1))
                        c[k] += delta * (hi[k] - lo[k])
                kids.append(np.clip(c, lo, hi))
        kids_a = np.array(kids[:pop])
        kv = [ev(x) for x in kids_a]
        Fk, Vk = np.array([f for f, _ in kv]), np.array([v for _, v in kv])
        Xa, Fa, Va = np.vstack([X, kids_a]), np.vstack([F, Fk]), np.concatenate([V, Vk])
        fronts = non_dominated_sort(Fa, Va)
        sel: list[int] = []
        for fr in fronts:
            if len(sel) + len(fr) <= pop:
                sel += fr
            else:
                cdv = crowding_distance(Fa[fr])
                order = np.argsort(-cdv)
                sel += [fr[i] for i in order[: pop - len(sel)]]
                break
        X, F, V = Xa[sel], Fa[sel], Va[sel]
        hist.append(F.copy())
    return NSGAResult(X, F, V, non_dominated_sort(F, V), hist, nev)
