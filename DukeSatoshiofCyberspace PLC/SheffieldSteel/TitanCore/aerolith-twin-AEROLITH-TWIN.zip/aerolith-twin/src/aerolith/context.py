"""RunContext: carries parameters, RNG, provenance ledger and warnings through a run."""

from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np

from .errors import StrictModeError
from .governance import MODEL_REGISTRY, ModelMeta
from .params import ParameterRegistry, Status, default_registry

_BAD_FOR_STRICT = {Status.ILLUSTRATIVE, Status.UNKNOWN}


@dataclass
class RunContext:
    registry: ParameterRegistry = field(default_factory=default_registry)
    rng: np.random.Generator = field(default_factory=lambda: np.random.default_rng(12345))
    strict: bool = False
    ledger: dict[str, str] = field(default_factory=dict)
    models_used: dict[str, ModelMeta] = field(default_factory=dict)
    warnings: list[str] = field(default_factory=list)

    def p(self, name: str) -> float:
        par = self.registry.get(name)
        if self.strict and par.status in _BAD_FOR_STRICT:
            raise StrictModeError(f"strict mode: parameter '{name}' is {par.status.value}")
        v = self.registry.value(name)
        self.ledger[name] = par.status.value
        return v

    def use(self, model_name: str) -> None:
        self.models_used[model_name] = MODEL_REGISTRY[model_name]

    def warn(self, msg: str) -> None:
        if msg not in self.warnings:
            self.warnings.append(msg)

    def check_range(self, label: str, x: float, lo: float, hi: float, unit: str = "") -> None:
        if x < lo or x > hi:
            self.warn(f"EXTRAPOLATION: {label}={x:.4g}{unit} outside documented validity [{lo:g}, {hi:g}]{unit}")

    def spawn(self, registry: ParameterRegistry | None = None, seed: int | None = None) -> RunContext:
        """Child context sharing nothing mutable (used for Monte Carlo members)."""
        rng = np.random.default_rng(seed) if seed is not None else self.rng
        return RunContext(registry or self.registry, rng, self.strict)

    def ledger_summary(self) -> dict[str, int]:
        out: dict[str, int] = {}
        for s in self.ledger.values():
            out[s] = out.get(s, 0) + 1
        return out
