"""JSON serialisation of numpy / pandas / dataclass / pydantic objects."""

from __future__ import annotations

import dataclasses
import json
from enum import Enum
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd


def to_jsonable(o: Any) -> Any:
    if isinstance(o, np.generic):
        return o.item()
    if isinstance(o, np.ndarray):
        return [to_jsonable(x) for x in o.tolist()] if o.size <= 20000 else {"__ndarray__": True, "shape": list(o.shape), "dtype": str(o.dtype), "note": "omitted (large)"}
    if isinstance(o, pd.DataFrame):
        return json.loads(o.to_json(orient="records", double_precision=10))
    if isinstance(o, pd.Series):
        return json.loads(o.to_json(double_precision=10))
    if isinstance(o, Enum):
        return o.value
    if hasattr(o, "model_dump"):
        return to_jsonable(o.model_dump())
    if dataclasses.is_dataclass(o) and not isinstance(o, type):
        return {f.name: to_jsonable(getattr(o, f.name)) for f in dataclasses.fields(o)}
    if isinstance(o, dict):
        return {str(k): to_jsonable(v) for k, v in o.items()}
    if isinstance(o, (list, tuple, set)):
        return [to_jsonable(x) for x in o]
    if isinstance(o, float) and (o != o or o in (float("inf"), float("-inf"))):
        return None
    return o


def write_json(obj: Any, path: str | Path) -> None:
    Path(path).write_text(json.dumps(to_jsonable(obj), indent=2, sort_keys=False, allow_nan=False))


def read_json(path: str | Path) -> Any:
    return json.loads(Path(path).read_text())
