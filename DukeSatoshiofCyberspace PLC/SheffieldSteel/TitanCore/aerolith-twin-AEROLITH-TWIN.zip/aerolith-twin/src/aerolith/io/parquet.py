"""Parquet tables with embedded reproducibility metadata."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import pandas as pd
import pyarrow as pa
import pyarrow.parquet as pq


def write_table(df: pd.DataFrame, path: str | Path, metadata: dict[str, Any]) -> None:
    table = pa.Table.from_pandas(df.reset_index(drop=df.index.name is None) if df.index.name else df, preserve_index=bool(df.index.name))
    md = {**(table.schema.metadata or {}), b"aerolith": json.dumps(metadata, default=str).encode()}
    pq.write_table(table.replace_schema_metadata(md), path)


def read_table(path: str | Path) -> tuple[pd.DataFrame, dict[str, Any]]:
    t = pq.read_table(path)
    md = json.loads((t.schema.metadata or {}).get(b"aerolith", b"{}").decode() or "{}")
    return t.to_pandas(), md
