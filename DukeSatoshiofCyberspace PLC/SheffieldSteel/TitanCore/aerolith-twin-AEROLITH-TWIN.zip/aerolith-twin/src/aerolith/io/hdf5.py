"""HDF5 result files: groups of arrays + attributes (metadata is mandatory)."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import h5py
import numpy as np
import pandas as pd

REQUIRED_META = ("model_version", "parameter_version", "simulation_timestamp", "input_hash", "dataset_version", "units", "uncertainty")


def write_hdf5(path: str | Path, metadata: dict[str, Any], tables: dict[str, pd.DataFrame], arrays: dict[str, dict[str, np.ndarray]],
               documents: dict[str, Any] | None = None) -> None:
    missing = [k for k in REQUIRED_META if k not in metadata]
    if missing:
        raise ValueError(f"result metadata incomplete: missing {missing}")
    with h5py.File(path, "w") as f:
        for k, v in metadata.items():
            f.attrs[k] = v if isinstance(v, (str, int, float)) else json.dumps(v, default=str)
        g = f.create_group("tables")
        for name, df in tables.items():
            sg = g.create_group(name)
            for col in df.columns:
                s = df[col]
                if s.dtype == object or str(s.dtype).startswith("string"):
                    sg.create_dataset(col, data=s.astype(str).to_numpy().astype("S"))
                else:
                    sg.create_dataset(col, data=s.to_numpy())
            if df.index.name:
                sg.attrs["index"] = df.index.name
        a = f.create_group("arrays")
        for gname, d in arrays.items():
            ag = a.create_group(gname)
            for n, arr in d.items():
                ag.create_dataset(n, data=np.asarray(arr), compression="gzip")
        if documents:
            dg = f.create_group("documents")
            for n, doc in documents.items():
                dg.create_dataset(n, data=json.dumps(doc, default=str))


def read_hdf5_meta(path: str | Path) -> dict[str, Any]:
    with h5py.File(path, "r") as f:
        return {k: (v.decode() if isinstance(v, bytes) else v) for k, v in f.attrs.items()}
