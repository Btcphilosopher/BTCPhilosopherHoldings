"""Provenance-tagged quantities.

Every reported value is MEASURED, SIMULATED, ESTIMATED or ASSUMED.  The report
generator refuses to promote a non-MEASURED value into a MEASURED slot.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import StrEnum
from typing import Any

from .errors import ProvenanceError


class Provenance(StrEnum):
    MEASURED = "MEASURED"
    SIMULATED = "SIMULATED"
    ESTIMATED = "ESTIMATED"
    ASSUMED = "ASSUMED"


@dataclass
class Quantity:
    name: str
    value: float
    unit: str
    sigma: float | None = None  # 1-sigma
    provenance: Provenance = Provenance.SIMULATED
    model: str = ""
    note: str = ""
    ci95: tuple[float, float] | None = None  # empirical credible interval, if available

    def interval95(self) -> tuple[float, float] | None:
        if self.ci95 is not None:
            return self.ci95
        if self.sigma is None:
            return None
        return (self.value - 1.96 * self.sigma, self.value + 1.96 * self.sigma)

    def as_measured(self) -> Quantity:
        if self.provenance is not Provenance.MEASURED:
            raise ProvenanceError(
                f"{self.name} is {self.provenance.value}; it cannot be presented as MEASURED"
            )
        return self

    def to_dict(self) -> dict[str, Any]:
        iv = self.interval95()
        return {
            "name": self.name,
            "value": float(self.value),
            "unit": self.unit,
            "sigma": None if self.sigma is None else float(self.sigma),
            "ci95": None if iv is None else [float(iv[0]), float(iv[1])],
            "provenance": self.provenance.value,
            "model": self.model,
            "note": self.note,
        }

    def __str__(self) -> str:
        s = f"{self.value:.4g} {self.unit}"
        if self.sigma is not None:
            s += f" ± {1.96 * self.sigma:.2g} (95%)"
        return f"{s} [{self.provenance.value}]"


@dataclass
class QuantitySet:
    items: dict[str, Quantity] = field(default_factory=dict)

    def add(self, q: Quantity) -> Quantity:
        self.items[q.name] = q
        return q

    def __getitem__(self, k: str) -> Quantity:
        return self.items[k]

    def __contains__(self, k: str) -> bool:
        return k in self.items

    def values(self) -> dict[str, float]:
        return {k: v.value for k, v in self.items.items()}

    def to_dict(self) -> dict[str, Any]:
        return {k: v.to_dict() for k, v in self.items.items()}
