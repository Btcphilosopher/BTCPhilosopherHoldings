# AEROLITH-TWIN
**Aerospace aluminium–lithium alloy manufacturing digital twin** — research / engineering-development software.

> Not a substitute for certified materials qualification, laboratory testing, standards compliance, destructive testing, NDT qualification,
> production process qualification, finite-element certification or airworthiness approval. The qualification module screens against a
> user-supplied envelope and always reports **NOT QUALIFIED**.

The central object is not the composition but the **material state**, evolved through
`chemistry → melt → casting/solidification → homogenisation → thermomechanical processing → solution treatment → quench (+stretch) → ageing → microstructure → defects → properties → inspection → screening`.
Each stage passes explicit state variables forward and writes a hash-chained genealogy node (`MELT 000421 → CAST 000421-A → H-… → R-… → ST-… → Q-… → AG-… → NDT-…`).

## What is real, what is placeholder — read this first
The *physics structure* is implemented (enthalpy solidification, Clyne–Kurz segregation, exact diffusion homogenisation, multi-phase KWN
precipitation with mass balance and vacancy-enhanced diffusion, Zener-limited recrystallisation, Taylor-factor/VRH texture anisotropy, quench
conduction + quench-factor loss + elastoplastic residual stress, mechanism-separated strengthening, UT/ECT/RT inspection, Kalman/Bayesian
estimation, NSGA-II). **No validated Al-Li material dataset ships with it.** Of 356 parameters, 273 are `ILLUSTRATIVE` placeholders,
58 `LITERATURE_APPROX` (verify), 19 `REFERENCE`, 6 `UNKNOWN` (never invented: models that need them refuse to run). Reports list every
parameter used and label placeholders `ASSUMED`; `--strict` refuses to run with them. Calibrate (`aerolith calibrate`) before drawing
material conclusions. Details: `docs/LIMITATIONS.md`, `docs/PARAMETERS.md`, `docs/MODELS.md`.

## Quick start
```bash
pip install -e .[dev]
pytest && python validation/run_validation.py
python examples/aerospace_panel/run.py            # complete example -> examples/aerospace_panel/output/report.html
aerolith report examples/aerospace_panel/sample.yaml
```
```python
from aerolith.chemistry.composition import Composition
from aerolith.manufacturing.spec import RouteSpec
from aerolith.digital_twin.twin import AerolithTwin
run = AerolithTwin().run(Composition(Li=1.0, Cu=4.0, Mg=0.4, Ag=0.4, Zr=0.12), RouteSpec(), n_ensemble=24)
```

## Design commitments (from the brief) and where they live
* **Process history, not composition** — `microstructure/state.py`, `manufacturing/process_chain.py`.
* **No "best alloy"** — `optimisation/composition.py` returns `NON-DOMINATED` / `DOMINATED` per candidate (A–D, custom) over stated objectives; `optimisation/process.py` optimises composition + homogenisation + solution + quench + stretch + ageing as one vector.
* **Manufacturing robustness** — `digital_twin/twin.py::robustness`: Monte Carlo process variation, yield probability against an envelope, local sensitivities, process-window widths.
* **Units** — SI internally; the YAML layer uses explicit-unit field names converted once (`manufacturing/spec.py`); kelvin-vs-°C slips raise errors.
* **Never silently invent data** — parameter registry with status/source/validity/uncertainty; UNKNOWN has no value; `RunContext.ledger`.
* **MEASURED vs SIMULATED vs ESTIMATED vs ASSUMED** — `provenance.py`; virtual instruments are SIMULATED, never MEASURED.
* **TRUE vs MEASURED vs ESTIMATED state** — `digital_twin/state.py`, sensors with bias/noise/drift/resolution/rate/dropout, Kalman + importance-weighted posterior.
* **Reproducibility** — `model_version`, `parameter_version`, timestamp, `input_hash`, `dataset_version`, units, uncertainty in HDF5/Parquet/JSON/CSV.
* **Governance** — every model registered with equation, source, validity, calibration dataset, uncertainty, revision (`docs/MODELS.md`).

## Layout
`src/aerolith/` (package) · `models/` (default parameter YAML, Taylor-factor cache) · `datasets/` (SYNTHETIC calibration-verification data) ·
`experiments/` (schema + synthetic samples) · `validation/` (analytical/convergence report, model-vs-experiment) · `tests/` ·
`notebooks/` · `docs/` · `examples/aerospace_panel/`.

## Visual language
White, graphite, aluminium, deep navy, steel, restrained blue, restrained amber/red. Figures are static engineering plots; the optional 3-D view is labelled
**STATISTICAL MICROSTRUCTURE REPRESENTATION** (lognormal ellipsoids; not atomistic, not a reconstruction).
