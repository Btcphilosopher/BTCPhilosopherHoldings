import {
  ChangeDetectionStrategy,
  Component,
  OnDestroy,
  OnInit,
  PLATFORM_ID,
  inject,
  signal,
} from '@angular/core';
import { isPlatformBrowser } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { SimulationEngine, PREDEFINED_SCENARIOS } from './core/simulation-engine';
import { TelemetryPoint, GuidanceMode, ModelFidelity } from './core/spacecraft-types';

import { ControlRoomHeaderComponent } from './components/control-room-header';
import { TelemetryStripComponent } from './components/telemetry-strip';
import { DigitalTwinComponent } from './components/digital-twin';
import { AttitudePanelComponent } from './components/attitude-panel';
import { SensorsEstimationPanelComponent } from './components/sensors-estimation-panel';
import { ControlAllocationPanelComponent } from './components/control-allocation-panel';
import { ActuatorMomentumPanelComponent } from './components/actuator-momentum-panel';
import { OrbitPanelComponent } from './components/orbit-panel';
import { FaultLabPanelComponent } from './components/fault-lab-panel';
import { StabilityPanelComponent } from './components/stability-panel';
import { MonteCarloPanelComponent } from './components/monte-carlo-panel';
import { RepoBrowserPanelComponent } from './components/repo-browser-panel';
import { EngineeringReportDialogComponent } from './components/engineering-report-dialog';

@Component({
  selector: 'app-root',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [
    MatIconModule,
    ControlRoomHeaderComponent,
    TelemetryStripComponent,
    DigitalTwinComponent,
    AttitudePanelComponent,
    SensorsEstimationPanelComponent,
    ControlAllocationPanelComponent,
    ActuatorMomentumPanelComponent,
    OrbitPanelComponent,
    FaultLabPanelComponent,
    StabilityPanelComponent,
    MonteCarloPanelComponent,
    RepoBrowserPanelComponent,
    EngineeringReportDialogComponent,
  ],
  templateUrl: './app.html',
  styleUrl: './app.css',
})
export class App implements OnInit, OnDestroy {
  engine = new SimulationEngine();

  // Signals
  telemetry = signal<TelemetryPoint | null>(null);
  activeTab = signal<string>('overview');
  isRunning = signal<boolean>(true);
  selectedScenarioId = signal<string>('nominal-pointing');
  modelFidelity = signal<ModelFidelity>('j2-perturbed');
  reportOpen = signal<boolean>(false);

  private platformId = inject(PLATFORM_ID);
  private simTimer: ReturnType<typeof setInterval> | null = null;

  ngOnInit() {
    // Initial step to produce initial telemetry
    const initialTelem = this.engine.step();
    this.telemetry.set(initialTelem);

    if (isPlatformBrowser(this.platformId)) {
      this.startSimLoop();
    }
  }

  ngOnDestroy() {
    this.stopSimLoop();
  }

  startSimLoop() {
    if (this.simTimer) clearInterval(this.simTimer);
    // 20 Hz simulation loop (50 ms per step)
    this.simTimer = setInterval(() => {
      if (this.isRunning()) {
        const point = this.engine.step();
        this.telemetry.set(point);
      }
    }, 50);
  }

  stopSimLoop() {
    if (this.simTimer) {
      clearInterval(this.simTimer);
      this.simTimer = null;
    }
  }

  onSelectTab(tabId: string) {
    this.activeTab.set(tabId);
  }

  onToggleSimulation() {
    this.isRunning.update((running) => !running);
  }

  onStepSimulation() {
    const point = this.engine.step();
    this.telemetry.set(point);
  }

  onResetSimulation() {
    this.engine.loadScenario(this.engine.activeScenario);
    const point = this.engine.step();
    this.telemetry.set(point);
  }

  onChangeScenario(scenId: string) {
    this.selectedScenarioId.set(scenId);
    const scen = PREDEFINED_SCENARIOS.find((s) => s.id === scenId);
    if (scen) {
      this.engine.loadScenario(scen);
      const point = this.engine.step();
      this.telemetry.set(point);
    }
  }

  onChangeGuidance(mode: GuidanceMode) {
    this.engine.guidanceMode = mode;
  }

  onChangeFidelity(fid: ModelFidelity) {
    this.modelFidelity.set(fid);
    this.engine.modelFidelity = fid;
  }

  onToggleDisturbance(key: string) {
    type DistKey = keyof typeof this.engine.disturbancesActive;
    if (key in this.engine.disturbancesActive) {
      const k = key as DistKey;
      this.engine.disturbancesActive[k] = !this.engine.disturbancesActive[k];
    }
  }

  onToggleFault(key: string) {
    if (key === 'wheelFailed3') {
      this.engine.faults.wheelFailed = this.engine.faults.wheelFailed === 3 ? 0 : 3;
      this.engine.wheels[2].failed = this.engine.faults.wheelFailed === 3;
    } else if (key === 'wheelSaturated1') {
      this.engine.faults.wheelSaturated = this.engine.faults.wheelSaturated === 1 ? 0 : 1;
      this.engine.wheels[0].saturated = this.engine.faults.wheelSaturated === 1;
    } else if (key === 'starTrackerBlinded') {
      this.engine.faults.starTrackerBlinded = !this.engine.faults.starTrackerBlinded;
    } else if (key === 'gyroBiasJump') {
      this.engine.faults.gyroBiasJump = !this.engine.faults.gyroBiasJump;
    } else if (key === 'magnetometerCorrupt') {
      this.engine.faults.magnetometerCorrupt = !this.engine.faults.magnetometerCorrupt;
    }
  }

  onClearAllFaults() {
    this.engine.faults = {
      wheelFailed: 0,
      wheelSaturated: 0,
      starTrackerBlinded: false,
      gyroBiasJump: false,
      magnetometerCorrupt: false,
    };
    this.engine.wheels.forEach((w) => {
      w.failed = false;
      w.saturated = false;
    });
  }

  onToggleThruster() {
    this.engine.thruster.firing = !this.engine.thruster.firing;
  }

  onInjectDeltaV(dv: number) {
    // Apply immediate impulsive burn
    const vMag = Math.sqrt(
      this.engine.orbitState.v[0] ** 2 +
      this.engine.orbitState.v[1] ** 2 +
      this.engine.orbitState.v[2] ** 2
    );
    this.engine.orbitState.v[0] += (dv / 1000) * (this.engine.orbitState.v[0] / vMag);
    this.engine.orbitState.v[1] += (dv / 1000) * (this.engine.orbitState.v[1] / vMag);
    this.engine.orbitState.v[2] += (dv / 1000) * (this.engine.orbitState.v[2] / vMag);
    this.engine.thruster.totalDeltaVMs += Math.abs(dv);
    this.engine.thruster.propellantMassKg = Math.max(
      0,
      this.engine.thruster.propellantMassKg - 0.25
    );
  }

  onUpdateGains(gains: { kp: number; kd: number; ki: number }) {
    this.engine.guidance.kp = gains.kp;
    this.engine.guidance.kd = gains.kd;
    this.engine.guidance.ki = gains.ki;
  }

  onOpenReport() {
    this.reportOpen.set(true);
  }

  onCloseReport() {
    this.reportOpen.set(false);
  }
}
