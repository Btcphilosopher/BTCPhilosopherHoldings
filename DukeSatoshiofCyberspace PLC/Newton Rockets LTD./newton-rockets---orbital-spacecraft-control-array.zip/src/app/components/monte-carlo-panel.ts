import { ChangeDetectionStrategy, Component, OnInit } from '@angular/core';
import { MatIconModule } from '@angular/material/icon';
import { MonteCarloEngine, MonteCarloSummary } from '../core/monte-carlo';

@Component({
  selector: 'app-monte-carlo-panel',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [MatIconModule],
  template: `
    <div class="space-y-4 font-mono">
      <!-- Header Banner & Execution Trigger -->
      <div class="bg-slate-900/90 border border-slate-800 rounded-xl p-4 flex flex-wrap items-center justify-between gap-3">
        <div>
          <span class="text-xs text-slate-200 font-semibold uppercase tracking-wider flex items-center gap-1.5">
            <mat-icon class="!text-sm !w-4 !h-4 leading-none">query_stats</mat-icon>
            MONTE CARLO UNCERTAINTY & DISPERSION STUDY
          </span>
          <p class="text-[11px] text-slate-400 mt-1">
            Parametric variation over mass (±10%), inertia (±15%), sensor noise (0.5×–2×), and detumble initial rates.
          </p>
        </div>

        <div class="flex items-center gap-2">
          <div class="flex items-center gap-1 bg-slate-950 p-1 rounded-lg border border-slate-800 text-xs">
            <button
              (click)="setRunsCount(50)"
              [class]="selectedRuns === 50 ? 'bg-slate-800 text-cyan-300 font-bold' : 'text-slate-400 hover:text-slate-200'"
              class="px-2 py-1 rounded transition-colors"
            >
              50 RUNS
            </button>
            <button
              (click)="setRunsCount(100)"
              [class]="selectedRuns === 100 ? 'bg-slate-800 text-cyan-300 font-bold' : 'text-slate-400 hover:text-slate-200'"
              class="px-2 py-1 rounded transition-colors"
            >
              100 RUNS
            </button>
            <button
              (click)="setRunsCount(250)"
              [class]="selectedRuns === 250 ? 'bg-slate-800 text-cyan-300 font-bold' : 'text-slate-400 hover:text-slate-200'"
              class="px-2 py-1 rounded transition-colors"
            >
              250 RUNS
            </button>
          </div>

          <button
            (click)="runStudy()"
            class="px-3.5 py-1.5 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-slate-950 font-bold text-xs transition-colors flex items-center gap-1.5"
          >
            <mat-icon class="!text-sm !w-3.5 !h-3.5 leading-none">play_arrow</mat-icon>
            <span>DISPERSE & EVALUATE</span>
          </button>
        </div>
      </div>

      <!-- Summary KPI Metric Cards -->
      <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <!-- Metric 1: 95th Percentile Pointing Error -->
        <div class="bg-slate-900/90 border border-slate-800 rounded-xl p-4 flex flex-col justify-between">
          <div>
            <div class="text-[10px] text-slate-500 uppercase tracking-wider mb-1">P95 RMS POINTING ERROR</div>
            <div class="text-2xl font-bold text-cyan-300 tabular-nums">
              {{ summary.p95PointingErrorDeg }}°
            </div>
          </div>
          <div class="text-[11px] text-slate-400 mt-2">
            Mean: <span class="text-slate-200 font-semibold tabular-nums">{{ summary.meanPointingErrorDeg }}°</span>
            <div class="text-[10px] text-slate-500 mt-0.5">Worst-case: {{ summary.maxPointingErrorDeg }}°</div>
          </div>
        </div>

        <!-- Metric 2: Settling Time Distribution -->
        <div class="bg-slate-900/90 border border-slate-800 rounded-xl p-4 flex flex-col justify-between">
          <div>
            <div class="text-[10px] text-slate-500 uppercase tracking-wider mb-1">P95 SETTLING TIME</div>
            <div class="text-2xl font-bold text-slate-100 tabular-nums">
              {{ summary.p95SettlingTimeSec }} s
            </div>
          </div>
          <div class="text-[11px] text-slate-400 mt-2">
            Mean: <span class="text-slate-200 font-semibold tabular-nums">{{ summary.meanSettlingTimeSec }} s</span>
            <div class="text-[10px] text-slate-500 mt-0.5">Nominal: ~22s target</div>
          </div>
        </div>

        <!-- Metric 3: Success Compliance Rate -->
        <div class="bg-slate-900/90 border border-slate-800 rounded-xl p-4 flex flex-col justify-between">
          <div>
            <div class="text-[10px] text-slate-500 uppercase tracking-wider mb-1">MISSION COMPLIANCE RATE</div>
            <div class="text-2xl font-bold text-emerald-400 tabular-nums">
              {{ summary.successRatePercent }}%
            </div>
          </div>
          <div class="text-[11px] text-slate-400 mt-2">
            Pointing Spec: &lt; 0.050°
            <div class="text-[10px] text-slate-500 mt-0.5">{{ summary.totalRuns }} total trials analyzed</div>
          </div>
        </div>

        <!-- Metric 4: Mean Control Effort -->
        <div class="bg-slate-900/90 border border-slate-800 rounded-xl p-4 flex flex-col justify-between">
          <div>
            <div class="text-[10px] text-slate-500 uppercase tracking-wider mb-1">MEAN CONTROL EFFORT</div>
            <div class="text-2xl font-bold text-slate-200 tabular-nums">
              {{ summary.meanControlEffort }} N²m²s
            </div>
          </div>
          <div class="text-[11px] text-slate-400 mt-2">
            Integral ∫ τ² dt
            <div class="text-[10px] text-slate-500 mt-0.5">Energy expenditure index</div>
          </div>
        </div>
      </div>

      <!-- Distribution Histograms -->
      <div class="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <!-- Histogram 1: RMS Pointing Error Distribution -->
        <div class="bg-slate-900/90 border border-slate-800 rounded-xl p-4">
          <div class="flex items-center justify-between mb-3 pb-2 border-b border-slate-800">
            <span class="text-xs text-slate-200 font-semibold tracking-wider uppercase">
              RMS POINTING ERROR DISTRIBUTION
            </span>
            <span class="text-[10px] text-slate-500">HISTOGRAM BINS</span>
          </div>

          <div class="space-y-2.5 pt-1">
            @for (bin of summary.errorHistogram; track bin.binLabel) {
              <div class="space-y-1">
                <div class="flex justify-between text-xs">
                  <span class="text-slate-400">{{ bin.binLabel }}</span>
                  <span class="text-slate-200 tabular-nums">{{ bin.count }} runs ({{ bin.percentage }}%)</span>
                </div>
                <div class="h-3 w-full bg-slate-950 rounded overflow-hidden border border-slate-800">
                  <div
                    [style.width.%]="bin.percentage"
                    class="h-full bg-cyan-500 transition-all duration-300"
                  ></div>
                </div>
              </div>
            }
          </div>
        </div>

        <!-- Histogram 2: Settling Time Distribution -->
        <div class="bg-slate-900/90 border border-slate-800 rounded-xl p-4">
          <div class="flex items-center justify-between mb-3 pb-2 border-b border-slate-800">
            <span class="text-xs text-slate-200 font-semibold tracking-wider uppercase">
              SETTLING TIME DISTRIBUTION (CDF)
            </span>
            <span class="text-[10px] text-slate-500">SETTLING TIME (SECONDS)</span>
          </div>

          <div class="space-y-2.5 pt-1">
            @for (bin of summary.settlingHistogram; track bin.binLabel) {
              <div class="space-y-1">
                <div class="flex justify-between text-xs">
                  <span class="text-slate-400">{{ bin.binLabel }}</span>
                  <span class="text-slate-200 tabular-nums">{{ bin.count }} runs ({{ bin.percentage }}%)</span>
                </div>
                <div class="h-3 w-full bg-slate-950 rounded overflow-hidden border border-slate-800">
                  <div
                    [style.width.%]="bin.percentage"
                    class="h-full bg-emerald-500 transition-all duration-300"
                  ></div>
                </div>
              </div>
            }
          </div>
        </div>
      </div>
    </div>
  `,
})
export class MonteCarloPanelComponent implements OnInit {
  selectedRuns = 100;
  summary!: MonteCarloSummary;

  ngOnInit() {
    this.runStudy();
  }

  setRunsCount(count: number) {
    this.selectedRuns = count;
    this.runStudy();
  }

  runStudy() {
    this.summary = MonteCarloEngine.runStudy(this.selectedRuns, 350, 48.5, 2.5, 4.2);
  }
}
