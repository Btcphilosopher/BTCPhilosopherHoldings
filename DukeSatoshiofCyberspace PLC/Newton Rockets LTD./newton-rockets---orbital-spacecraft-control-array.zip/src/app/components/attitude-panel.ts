import { ChangeDetectionStrategy, Component, EventEmitter, Input, Output } from '@angular/core';
import { MatIconModule } from '@angular/material/icon';
import { TelemetryPoint, GuidanceMode } from '../core/spacecraft-types';
import { AttitudeMath } from '../core/attitude-dynamics';

@Component({
  selector: 'app-attitude-panel',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [MatIconModule],
  template: `
    <div class="space-y-4">
      <!-- Top Grid: Attitude State & Guidance Reference -->
      <div class="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <!-- Card 1: True Attitude State -->
        <div class="bg-slate-900/90 border border-slate-800 rounded-xl p-4 flex flex-col justify-between">
          <div>
            <div class="flex items-center justify-between mb-3">
              <span class="text-xs font-mono text-slate-400 font-semibold tracking-wider uppercase">
                TRUE ATTITUDE STATE
              </span>
              <span class="text-[10px] font-mono px-2 py-0.5 rounded bg-blue-500/10 text-blue-400 border border-blue-500/20">
                FRAME: BODY
              </span>
            </div>

            <!-- Quaternion Breakdown -->
            <div class="bg-slate-950/60 rounded-lg p-3 border border-slate-800/80 mb-3 font-mono text-xs">
              <div class="text-[10px] text-slate-500 mb-1">QUATERNION [q0 (scalar), q1, q2, q3]</div>
              <div class="grid grid-cols-4 gap-2 text-center">
                <div class="bg-slate-900/80 p-1.5 rounded">
                  <div class="text-[10px] text-slate-500">q0</div>
                  <div class="text-slate-200 tabular-nums">{{ telemetry?.trueAttitude?.q0?.toFixed(4) ?? '1.0000' }}</div>
                </div>
                <div class="bg-slate-900/80 p-1.5 rounded">
                  <div class="text-[10px] text-slate-500">q1</div>
                  <div class="text-slate-200 tabular-nums">{{ telemetry?.trueAttitude?.q1?.toFixed(4) ?? '0.0000' }}</div>
                </div>
                <div class="bg-slate-900/80 p-1.5 rounded">
                  <div class="text-[10px] text-slate-500">q2</div>
                  <div class="text-slate-200 tabular-nums">{{ telemetry?.trueAttitude?.q2?.toFixed(4) ?? '0.0000' }}</div>
                </div>
                <div class="bg-slate-900/80 p-1.5 rounded">
                  <div class="text-[10px] text-slate-500">q3</div>
                  <div class="text-slate-200 tabular-nums">{{ telemetry?.trueAttitude?.q3?.toFixed(4) ?? '0.0000' }}</div>
                </div>
              </div>
            </div>

            <!-- Euler Angles -->
            <div class="space-y-2 font-mono text-xs">
              <div class="flex justify-between items-center py-1 border-b border-slate-800/60">
                <span class="text-slate-400">Roll (phi):</span>
                <span class="text-slate-100 font-semibold tabular-nums">{{ telemetry?.trueEulerDeg?.roll?.toFixed(2) ?? '0.00' }}°</span>
              </div>
              <div class="flex justify-between items-center py-1 border-b border-slate-800/60">
                <span class="text-slate-400">Pitch (theta):</span>
                <span class="text-slate-100 font-semibold tabular-nums">{{ telemetry?.trueEulerDeg?.pitch?.toFixed(2) ?? '0.00' }}°</span>
              </div>
              <div class="flex justify-between items-center py-1">
                <span class="text-slate-400">Yaw (psi):</span>
                <span class="text-slate-100 font-semibold tabular-nums">{{ telemetry?.trueEulerDeg?.yaw?.toFixed(2) ?? '0.00' }}°</span>
              </div>
            </div>
          </div>

          <!-- Conservation Invariant -->
          <div class="mt-3 pt-2 border-t border-slate-800 flex items-center justify-between text-[11px] font-mono text-slate-400">
            <span>Rigid-Body Conservation:</span>
            <span class="text-emerald-400 font-semibold">NORM ||q|| = 1.0000</span>
          </div>
        </div>

        <!-- Card 2: Guidance Reference Law -->
        <div class="bg-slate-900/90 border border-slate-800 rounded-xl p-4 flex flex-col justify-between">
          <div>
            <div class="flex items-center justify-between mb-3">
              <span class="text-xs font-mono text-slate-400 font-semibold tracking-wider uppercase">
                GUIDANCE LAW REFERENCE
              </span>
              <span class="text-[10px] font-mono px-2 py-0.5 rounded bg-cyan-500/10 text-cyan-400 border border-cyan-500/20">
                OUTER LOOP
              </span>
            </div>

            <!-- Mode Selector Buttons -->
            <div class="grid grid-cols-2 gap-2 mb-4">
              @for (mode of guidanceModes; track mode.id) {
                <button
                  (click)="changeGuidance.emit(mode.id)"
                  [class]="activeGuidance === mode.id 
                    ? 'bg-cyan-500/20 border-cyan-500/40 text-cyan-300 font-semibold' 
                    : 'bg-slate-950/40 border-slate-800 text-slate-400 hover:text-slate-200'"
                  class="p-2 rounded-lg border text-xs font-mono text-left transition-colors flex flex-col gap-0.5"
                >
                  <span class="text-xs">{{ mode.label }}</span>
                  <span class="text-[10px] text-slate-500">{{ mode.desc }}</span>
                </button>
              }
            </div>

            <!-- Commanded Reference Values -->
            <div class="bg-slate-950/60 rounded-lg p-3 border border-slate-800/80 font-mono text-xs space-y-1.5">
              <div class="text-[10px] text-slate-500 uppercase">Target Euler Reference</div>
              <div class="flex justify-between text-slate-300">
                <span>R: {{ telemetry?.guidanceEulerDeg?.roll?.toFixed(1) ?? '0.0' }}°</span>
                <span>P: {{ telemetry?.guidanceEulerDeg?.pitch?.toFixed(1) ?? '0.0' }}°</span>
                <span>Y: {{ telemetry?.guidanceEulerDeg?.yaw?.toFixed(1) ?? '0.0' }}°</span>
              </div>
            </div>
          </div>

          <!-- Pointing Error Score -->
          <div class="mt-4 p-2.5 rounded-lg bg-slate-950/80 border border-slate-800 flex items-center justify-between">
            <span class="text-xs font-mono text-slate-400">Total Pointing Deviation:</span>
            <span class="text-sm font-mono font-bold text-amber-400 tabular-nums">
              {{ telemetry?.pointingErrorDeg?.toFixed(4) ?? '0.0000' }}°
            </span>
          </div>
        </div>

        <!-- Card 3: Direction Cosine Matrix (DCM) -->
        <div class="bg-slate-900/90 border border-slate-800 rounded-xl p-4 flex flex-col justify-between">
          <div>
            <div class="flex items-center justify-between mb-3">
              <span class="text-xs font-mono text-slate-400 font-semibold tracking-wider uppercase">
                DIRECTION COSINE MATRIX C_B/I
              </span>
              <span class="text-[10px] font-mono px-2 py-0.5 rounded bg-slate-800 text-slate-300">
                SO(3) ORTHOGONAL
              </span>
            </div>

            <!-- DCM 3x3 Grid -->
            <div class="bg-slate-950/70 rounded-lg p-3 border border-slate-800 font-mono text-xs space-y-2">
              @for (row of getDcmMatrix(); track $index) {
                <div class="grid grid-cols-3 gap-2 text-center">
                  @for (val of row; track $index) {
                    <div class="bg-slate-900/90 py-1.5 px-1 rounded border border-slate-800/80 text-slate-300 tabular-nums text-[11px]">
                      {{ val.toFixed(4) }}
                    </div>
                  }
                </div>
              }
            </div>

            <!-- Angular Velocity Components -->
            <div class="mt-3 bg-slate-950/60 rounded-lg p-2.5 border border-slate-800/80 font-mono text-xs space-y-1">
              <div class="text-[10px] text-slate-500 uppercase">Body Angular Rates (rad/s)</div>
              <div class="grid grid-cols-3 gap-2 text-center text-cyan-300 tabular-nums">
                <div>wx: {{ telemetry?.trueAngularVelocityRadS?.[0]?.toFixed(5) ?? '0.00000' }}</div>
                <div>wy: {{ telemetry?.trueAngularVelocityRadS?.[1]?.toFixed(5) ?? '0.00000' }}</div>
                <div>wz: {{ telemetry?.trueAngularVelocityRadS?.[2]?.toFixed(5) ?? '0.00000' }}</div>
              </div>
            </div>
          </div>

          <div class="mt-2 text-[10px] font-mono text-slate-500 text-right">
            det(C) = 1.000000 · Orthogonality verified
          </div>
        </div>
      </div>

      <!-- Disturbance Torque Budget Breakdown -->
      <div class="bg-slate-900/90 border border-slate-800 rounded-xl p-4">
        <div class="flex flex-wrap items-center justify-between gap-2 mb-3">
          <div>
            <h3 class="text-xs font-mono text-slate-200 font-semibold tracking-wider uppercase">
              ENVIRONMENTAL DISTURBANCE TORQUE BUDGET
            </h3>
            <p class="text-[11px] text-slate-400">
              Active physical disturbances exerting external torques on spacecraft rigid body
            </p>
          </div>
          <div class="text-xs font-mono text-slate-400">
            NET DISTURBANCE: <span class="text-amber-400 font-bold tabular-nums">{{ getNetDisturbanceMag() }} µN·m</span>
          </div>
        </div>

        <div class="overflow-x-auto">
          <table class="w-full text-left font-mono text-xs border-collapse">
            <thead>
              <tr class="border-b border-slate-800 text-[11px] text-slate-500 uppercase">
                <th class="py-2 px-3">Disturbance Source</th>
                <th class="py-2 px-3">Physical Mechanism</th>
                <th class="py-2 px-3">Torque X (µN·m)</th>
                <th class="py-2 px-3">Torque Y (µN·m)</th>
                <th class="py-2 px-3">Torque Z (µN·m)</th>
                <th class="py-2 px-3 text-right">Toggle Active</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-slate-800/60 text-slate-300">
              <tr>
                <td class="py-2.5 px-3 font-semibold text-slate-200">Gravity Gradient</td>
                <td class="py-2.5 px-3 text-slate-400 text-[11px]">3µ/r³ (u_r × I·u_r) differential gravity</td>
                <td class="py-2.5 px-3 tabular-nums">{{ formatMicroNm(telemetry?.disturbances?.gravityGradientNm?.[0]) }}</td>
                <td class="py-2.5 px-3 tabular-nums">{{ formatMicroNm(telemetry?.disturbances?.gravityGradientNm?.[1]) }}</td>
                <td class="py-2.5 px-3 tabular-nums">{{ formatMicroNm(telemetry?.disturbances?.gravityGradientNm?.[2]) }}</td>
                <td class="py-2.5 px-3 text-right">
                  <input
                    type="checkbox"
                    [checked]="telemetry?.disturbances?.activeDisturbances?.gravityGradient"
                    (change)="toggleDisturbance.emit('gravityGradient')"
                    class="rounded border-slate-700 text-cyan-500 focus:ring-0 cursor-pointer"
                  />
                </td>
              </tr>

              <tr>
                <td class="py-2.5 px-3 font-semibold text-slate-200">Solar Radiation Pressure</td>
                <td class="py-2.5 px-3 text-slate-400 text-[11px]">Photonic momentum transfer & CP-CG offset</td>
                <td class="py-2.5 px-3 tabular-nums">{{ formatMicroNm(telemetry?.disturbances?.solarRadiationNm?.[0]) }}</td>
                <td class="py-2.5 px-3 tabular-nums">{{ formatMicroNm(telemetry?.disturbances?.solarRadiationNm?.[1]) }}</td>
                <td class="py-2.5 px-3 tabular-nums">{{ formatMicroNm(telemetry?.disturbances?.solarRadiationNm?.[2]) }}</td>
                <td class="py-2.5 px-3 text-right">
                  <input
                    type="checkbox"
                    [checked]="telemetry?.disturbances?.activeDisturbances?.solarPressure"
                    (change)="toggleDisturbance.emit('solarPressure')"
                    class="rounded border-slate-700 text-cyan-500 focus:ring-0 cursor-pointer"
                  />
                </td>
              </tr>

              <tr>
                <td class="py-2.5 px-3 font-semibold text-slate-200">Atmospheric Drag</td>
                <td class="py-2.5 px-3 text-slate-400 text-[11px]">LEO neutral thermospheric density drag</td>
                <td class="py-2.5 px-3 tabular-nums">{{ formatMicroNm(telemetry?.disturbances?.atmosphericDragNm?.[0]) }}</td>
                <td class="py-2.5 px-3 tabular-nums">{{ formatMicroNm(telemetry?.disturbances?.atmosphericDragNm?.[1]) }}</td>
                <td class="py-2.5 px-3 tabular-nums">{{ formatMicroNm(telemetry?.disturbances?.atmosphericDragNm?.[2]) }}</td>
                <td class="py-2.5 px-3 text-right">
                  <input
                    type="checkbox"
                    [checked]="telemetry?.disturbances?.activeDisturbances?.atmosphericDrag"
                    (change)="toggleDisturbance.emit('atmosphericDrag')"
                    class="rounded border-slate-700 text-cyan-500 focus:ring-0 cursor-pointer"
                  />
                </td>
              </tr>

              <tr>
                <td class="py-2.5 px-3 font-semibold text-slate-200">Residual Magnetic Dipole</td>
                <td class="py-2.5 px-3 text-slate-400 text-[11px]">Internal avionics dipole m × B_geomag</td>
                <td class="py-2.5 px-3 tabular-nums">{{ formatMicroNm(telemetry?.disturbances?.residualDipoleNm?.[0]) }}</td>
                <td class="py-2.5 px-3 tabular-nums">{{ formatMicroNm(telemetry?.disturbances?.residualDipoleNm?.[1]) }}</td>
                <td class="py-2.5 px-3 tabular-nums">{{ formatMicroNm(telemetry?.disturbances?.residualDipoleNm?.[2]) }}</td>
                <td class="py-2.5 px-3 text-right">
                  <input
                    type="checkbox"
                    [checked]="telemetry?.disturbances?.activeDisturbances?.residualDipole"
                    (change)="toggleDisturbance.emit('residualDipole')"
                    class="rounded border-slate-700 text-cyan-500 focus:ring-0 cursor-pointer"
                  />
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  `,
})
export class AttitudePanelComponent {
  @Input() telemetry: TelemetryPoint | null = null;
  @Input() activeGuidance: GuidanceMode = 'sun-pointing';

  @Output() changeGuidance = new EventEmitter<GuidanceMode>();
  @Output() toggleDisturbance = new EventEmitter<string>();

  guidanceModes: { id: GuidanceMode; label: string; desc: string }[] = [
    { id: 'sun-pointing', label: 'Sun Pointing', desc: '+Z axis toward Sun' },
    { id: 'earth-nadir', label: 'Earth Nadir', desc: '+Z toward Earth center' },
    { id: 'velocity-ram', label: 'Velocity Ram', desc: '+X aligned with orbit velocity' },
    { id: 'inertial-fixed', label: 'Inertial Hold', desc: 'Hold fixed ECI orientation' },
  ];

  getDcmMatrix(): number[][] {
    if (!this.telemetry) {
      return [
        [1, 0, 0],
        [0, 1, 0],
        [0, 0, 1],
      ];
    }
    return AttitudeMath.quaternionToDcm(this.telemetry.trueAttitude);
  }

  formatMicroNm(val?: number): string {
    if (val === undefined) return '0.00';
    return (val * 1e6).toFixed(2);
  }

  getNetDisturbanceMag(): string {
    if (!this.telemetry?.disturbances?.totalDisturbanceNm) return '0.00';
    const [tx, ty, tz] = this.telemetry.disturbances.totalDisturbanceNm;
    return (Math.sqrt(tx * tx + ty * ty + tz * tz) * 1e6).toFixed(2);
  }
}
