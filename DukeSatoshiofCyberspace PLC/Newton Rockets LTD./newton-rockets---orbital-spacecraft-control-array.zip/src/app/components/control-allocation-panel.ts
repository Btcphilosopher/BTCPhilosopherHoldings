import { ChangeDetectionStrategy, Component, EventEmitter, Input, Output } from '@angular/core';
import { MatIconModule } from '@angular/material/icon';
import { TelemetryPoint, ReactionWheelState } from '../core/spacecraft-types';
import { ControlAllocator } from '../core/control-allocation';

@Component({
  selector: 'app-control-allocation-panel',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [MatIconModule],
  template: `
    <div class="space-y-4 font-mono">
      <!-- Top Grid: Control Law & Commanded Torque -->
      <div class="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <!-- Card 1: Inner-Loop Attitude Controller Law -->
        <div class="bg-slate-900/90 border border-slate-800 rounded-xl p-4 flex flex-col justify-between">
          <div>
            <div class="flex items-center justify-between mb-3 pb-2 border-b border-slate-800">
              <span class="text-xs text-slate-200 font-semibold tracking-wider uppercase">
                ATTITUDE CONTROL LAW (INNER LOOP)
              </span>
              <span class="text-[10px] px-2 py-0.5 rounded bg-blue-500/10 text-blue-400 border border-blue-500/20">
                QUATERNION FEEDBACK
              </span>
            </div>

            <!-- Mathematical Equation -->
            <div class="bg-slate-950/70 p-3 rounded-lg border border-slate-800/80 mb-3 text-slate-300 text-[11px] leading-relaxed">
              <div class="text-[10px] text-slate-500 mb-1">CONTROL LAW FORMULATION:</div>
              <div class="text-cyan-300 font-bold">
                τ_req = -2·Kp·sgn(qe0)·qev - Kd·ω_err - Ki·∫qev dt
              </div>
              <div class="text-slate-400 text-[10px] mt-1">
                Where qe = q_des⁻¹ ⊗ q_est is the error quaternion and ω_err is angular rate error.
              </div>
            </div>

            <!-- Gain Tuning Steppers -->
            <div class="space-y-2 text-xs">
              <div class="flex items-center justify-between">
                <span class="text-slate-400">Proportional Gain (Kp):</span>
                <div class="flex items-center gap-1.5">
                  <button (click)="adjustGain('kp', -0.2)" class="w-6 h-6 bg-slate-800 hover:bg-slate-700 rounded text-slate-200">-</button>
                  <span class="w-12 text-center text-slate-100 font-semibold tabular-nums">{{ telemetry?.controller?.kp?.toFixed(1) ?? '2.5' }}</span>
                  <button (click)="adjustGain('kp', 0.2)" class="w-6 h-6 bg-slate-800 hover:bg-slate-700 rounded text-slate-200">+</button>
                </div>
              </div>

              <div class="flex items-center justify-between">
                <span class="text-slate-400">Derivative Gain (Kd):</span>
                <div class="flex items-center gap-1.5">
                  <button (click)="adjustGain('kd', -0.2)" class="w-6 h-6 bg-slate-800 hover:bg-slate-700 rounded text-slate-200">-</button>
                  <span class="w-12 text-center text-slate-100 font-semibold tabular-nums">{{ telemetry?.controller?.kd?.toFixed(1) ?? '4.2' }}</span>
                  <button (click)="adjustGain('kd', 0.2)" class="w-6 h-6 bg-slate-800 hover:bg-slate-700 rounded text-slate-200">+</button>
                </div>
              </div>

              <div class="flex items-center justify-between">
                <span class="text-slate-400">Integral Gain (Ki):</span>
                <div class="flex items-center gap-1.5">
                  <button (click)="adjustGain('ki', -0.02)" class="w-6 h-6 bg-slate-800 hover:bg-slate-700 rounded text-slate-200">-</button>
                  <span class="w-12 text-center text-slate-100 font-semibold tabular-nums">{{ telemetry?.controller?.ki?.toFixed(2) ?? '0.08' }}</span>
                  <button (click)="adjustGain('ki', 0.02)" class="w-6 h-6 bg-slate-800 hover:bg-slate-700 rounded text-slate-200">+</button>
                </div>
              </div>
            </div>
          </div>

          <div class="mt-3 text-[10px] text-slate-500 pt-2 border-t border-slate-800">
            Anti-windup clamping: ±0.50 rad·s
          </div>
        </div>

        <!-- Card 2: Commanded vs Realized Torque Breakdown -->
        <div class="bg-slate-900/90 border border-slate-800 rounded-xl p-4 flex flex-col justify-between">
          <div>
            <div class="flex items-center justify-between mb-3 pb-2 border-b border-slate-800">
              <span class="text-xs text-slate-200 font-semibold tracking-wider uppercase">
                TORQUE REQUEST & REALIZATION
              </span>
              <span class="text-[10px] px-2 py-0.5 rounded bg-cyan-500/10 text-cyan-400 border border-cyan-500/20">
                BODY FRAME
              </span>
            </div>

            <!-- Requested Torque -->
            <div class="bg-slate-950/70 p-3 rounded-lg border border-slate-800/80 mb-3 text-xs space-y-1">
              <div class="text-[10px] text-slate-500 uppercase">1. REQUESTED TORQUE τ_req (N·m)</div>
              <div class="grid grid-cols-3 gap-2 text-center font-bold text-slate-200 tabular-nums">
                <div class="bg-slate-900 p-1.5 rounded">
                  <span class="text-slate-500 text-[10px]">Tx:</span> {{ formatNm(telemetry?.controller?.commandedTorqueNm?.[0]) }}
                </div>
                <div class="bg-slate-900 p-1.5 rounded">
                  <span class="text-slate-500 text-[10px]">Ty:</span> {{ formatNm(telemetry?.controller?.commandedTorqueNm?.[1]) }}
                </div>
                <div class="bg-slate-900 p-1.5 rounded">
                  <span class="text-slate-500 text-[10px]">Tz:</span> {{ formatNm(telemetry?.controller?.commandedTorqueNm?.[2]) }}
                </div>
              </div>
            </div>

            <!-- Realized Torque -->
            <div class="bg-slate-950/70 p-3 rounded-lg border border-slate-800/80 mb-3 text-xs space-y-1">
              <div class="text-[10px] text-slate-500 uppercase">2. DELIVERED TORQUE τ_act = -A·u (N·m)</div>
              <div class="grid grid-cols-3 gap-2 text-center font-bold text-emerald-400 tabular-nums">
                <div class="bg-slate-900 p-1.5 rounded">
                  <span class="text-slate-500 text-[10px]">Tx:</span> {{ formatNm(telemetry?.controller?.realizedTorqueNm?.[0]) }}
                </div>
                <div class="bg-slate-900 p-1.5 rounded">
                  <span class="text-slate-500 text-[10px]">Ty:</span> {{ formatNm(telemetry?.controller?.realizedTorqueNm?.[1]) }}
                </div>
                <div class="bg-slate-900 p-1.5 rounded">
                  <span class="text-slate-500 text-[10px]">Tz:</span> {{ formatNm(telemetry?.controller?.realizedTorqueNm?.[2]) }}
                </div>
              </div>
            </div>
          </div>

          <!-- Allocation Residual -->
          <div class="p-2.5 rounded-lg bg-slate-950/80 border border-slate-800 flex items-center justify-between text-xs">
            <span class="text-slate-400">Allocation Residual ||Δτ||:</span>
            <span 
              [class]="getAllocationResidualNorm() < 0.001 ? 'text-emerald-400' : 'text-amber-400 font-bold'"
              class="tabular-nums"
            >
              {{ getAllocationResidualNorm().toFixed(5) }} N·m
            </span>
          </div>
        </div>

        <!-- Card 3: Actuator Matrix Geometry & Health -->
        <div class="bg-slate-900/90 border border-slate-800 rounded-xl p-4 flex flex-col justify-between">
          <div>
            <div class="flex items-center justify-between mb-3 pb-2 border-b border-slate-800">
              <span class="text-xs text-slate-200 font-semibold tracking-wider uppercase">
                PYRAMID ACTUATOR GEOMETRY
              </span>
              <span class="text-[10px] px-2 py-0.5 rounded bg-slate-800 text-slate-300">
                β = 54.74° TETRAHEDRAL
              </span>
            </div>

            <!-- Actuator Matrix A (3x4) -->
            <div class="bg-slate-950/70 p-3 rounded-lg border border-slate-800 mb-3 text-[11px] space-y-1.5">
              <div class="text-[10px] text-slate-500">ACTUATOR MATRIX A (3×4):</div>
              @for (row of getMatrixA(); track $index) {
                <div class="grid grid-cols-4 gap-1 text-center">
                  @for (val of row; track $index) {
                    <div class="bg-slate-900/80 py-1 rounded text-slate-300 tabular-nums text-[10px]">
                      {{ val.toFixed(3) }}
                    </div>
                  }
                </div>
              }
            </div>

            <!-- Wheel Authority Weights -->
            <div class="space-y-1 text-xs">
              <div class="text-[10px] text-slate-500 uppercase">Actuator Weighting (W):</div>
              <div class="grid grid-cols-4 gap-1 text-center text-[10px]">
                @for (w of telemetry?.actuators?.wheels; track w.id) {
                  <div 
                    [class]="w.failed ? 'bg-rose-500/10 text-rose-400 border-rose-500/30' : 'bg-emerald-500/10 text-emerald-300 border-emerald-500/30'"
                    class="py-1 px-1 rounded border font-semibold"
                  >
                    RW{{ w.id }}: {{ w.failed ? '0.00' : '1.00' }}
                  </div>
                }
              </div>
            </div>
          </div>

          <div class="mt-3 text-[10px] text-slate-500 text-right">
            Moore-Penrose Pseudoinverse A⁺: Reconfigurable under fault
          </div>
        </div>
      </div>

      <!-- Core Allocation Mathematical Breakdown (Section 12 Explicit Requirement) -->
      <div class="bg-slate-900/90 border border-slate-800 rounded-xl p-4">
        <div class="flex items-center justify-between mb-3 pb-2 border-b border-slate-800">
          <div>
            <h3 class="text-xs text-slate-200 font-semibold tracking-wider uppercase">
              EXPOSED ALLOCATION MATHEMATICS: TORQUE REQUEST → ALLOCATION MATRIX → ACTUATOR COMMANDS
            </h3>
            <p class="text-[11px] text-slate-400">
              Step-by-step transformation: requested torque mapped via weighted pseudoinverse + nullspace momentum redistribution
            </p>
          </div>
          <span class="text-xs text-cyan-400 font-bold">u_cmd = -A⁺·τ_req + (I - A⁺A)·k_null·Δh</span>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-4 gap-3 text-xs">
          @for (wheel of telemetry?.actuators?.wheels; track wheel.id) {
            <div 
              [class]="wheel.failed ? 'border-rose-800/80 bg-rose-950/20' : wheel.saturated ? 'border-amber-800/80 bg-amber-950/20' : 'border-slate-800 bg-slate-950/70'"
              class="p-3 rounded-lg border space-y-2"
            >
              <div class="flex items-center justify-between text-[11px]">
                <span class="font-bold text-slate-200">REACTION WHEEL {{ wheel.id }}</span>
                @if (wheel.failed) {
                  <span class="text-rose-400 text-[10px] font-bold">LOCKED / 0 AUTHORITY</span>
                } @else if (wheel.saturated) {
                  <span class="text-amber-400 text-[10px] font-bold">SATURATED</span>
                } @else {
                  <span class="text-emerald-400 text-[10px]">ACTIVE</span>
                }
              </div>

              <!-- Commanded vs Actual Torque -->
              <div class="space-y-1 text-[11px]">
                <div class="flex justify-between">
                  <span class="text-slate-400">Allocated Cmd:</span>
                  <span class="text-cyan-300 font-bold tabular-nums">
                    {{ wheel.commandedTorqueNm.toFixed(4) }} N·m
                  </span>
                </div>
                <div class="flex justify-between">
                  <span class="text-slate-400">Physical Actual:</span>
                  <span 
                    [class]="wheel.actualTorqueNm !== wheel.commandedTorqueNm ? 'text-amber-400' : 'text-emerald-400'"
                    class="font-bold tabular-nums"
                  >
                    {{ wheel.actualTorqueNm.toFixed(4) }} N·m
                  </span>
                </div>
                <div class="flex justify-between">
                  <span class="text-slate-400">Speed / RPM:</span>
                  <span class="text-slate-200 tabular-nums">
                    {{ wheel.speedRpm.toFixed(0) }} / 6000 RPM
                  </span>
                </div>
              </div>

              <!-- Utilization Progress Bar -->
              <div class="pt-1">
                <div class="h-1.5 w-full bg-slate-800 rounded-full overflow-hidden">
                  <div
                    [class]="wheel.failed ? 'bg-rose-500' : (getWheelTorquePct(wheel) > 80 ? 'bg-amber-500' : 'bg-cyan-500')"
                    [style.width.%]="getWheelTorquePct(wheel)"
                    class="h-full transition-all duration-150"
                  ></div>
                </div>
                <div class="text-[10px] text-slate-500 text-right mt-0.5">
                  Torque load: {{ getWheelTorquePct(wheel).toFixed(0) }}%
                </div>
              </div>
            </div>
          }
        </div>
      </div>
    </div>
  `,
})
export class ControlAllocationPanelComponent {
  @Input() telemetry: TelemetryPoint | null = null;
  @Output() updateGains = new EventEmitter<{ kp: number; kd: number; ki: number }>();

  adjustGain(param: 'kp' | 'kd' | 'ki', delta: number) {
    if (!this.telemetry) return;
    const current = this.telemetry.controller;
    const newKp = param === 'kp' ? Math.max(0.1, current.kp + delta) : current.kp;
    const newKd = param === 'kd' ? Math.max(0.1, current.kd + delta) : current.kd;
    const newKi = param === 'ki' ? Math.max(0.0, current.ki + delta) : current.ki;

    this.updateGains.emit({
      kp: Number(newKp.toFixed(2)),
      kd: Number(newKd.toFixed(2)),
      ki: Number(newKi.toFixed(3)),
    });
  }

  getMatrixA(): number[][] {
    return ControlAllocator.getPyramidAllocationMatrix();
  }

  formatNm(val?: number): string {
    if (val === undefined) return '0.000';
    return val.toFixed(4);
  }

  getAllocationResidualNorm(): number {
    if (!this.telemetry?.controller?.torqueResidualNm) return 0;
    const [rx, ry, rz] = this.telemetry.controller.torqueResidualNm;
    return Math.sqrt(rx * rx + ry * ry + rz * rz);
  }

  getWheelTorquePct(w: ReactionWheelState): number {
    return Math.min(100, (Math.abs(w.actualTorqueNm) / w.maxTorqueNm) * 100);
  }
}
