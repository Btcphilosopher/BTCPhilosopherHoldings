import { ChangeDetectionStrategy, Component, Input } from '@angular/core';
import { TelemetryPoint } from '../core/spacecraft-types';

@Component({
  selector: 'app-telemetry-strip',
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="w-full bg-[#07090e] border-b border-slate-800/80 px-4 py-2 flex flex-wrap items-center justify-between gap-3 text-xs font-mono">
      <!-- Group 1: MET & Orbit Altitude -->
      <div class="flex items-center gap-4">
        <div class="flex items-center gap-1.5">
          <span class="text-slate-500">MET:</span>
          <span class="text-cyan-300 font-bold tabular-nums">
            T+{{ formatTime(telemetry?.timeSec ?? 0) }}
          </span>
        </div>

        <div class="hidden sm:flex items-center gap-1.5">
          <span class="text-slate-500">ALTITUDE:</span>
          <span class="text-slate-200 tabular-nums">
            {{ telemetry?.trueOrbit?.altitudeKm?.toFixed(1) ?? '550.0' }} km
          </span>
        </div>

        <div class="hidden md:flex items-center gap-1.5">
          <span class="text-slate-500">VELOCITY:</span>
          <span class="text-slate-200 tabular-nums">
            {{ getVelocityMag() }} km/s
          </span>
        </div>
      </div>

      <!-- Group 2: Pointing Error & Angular Rate -->
      <div class="flex items-center gap-4">
        <div class="flex items-center gap-1.5">
          <span class="text-slate-500">POINTING ERR:</span>
          <span 
            [class]="(telemetry?.pointingErrorDeg ?? 0) < 0.05 ? 'text-emerald-400 font-bold' : 'text-amber-400 font-bold'"
            class="tabular-nums"
          >
            {{ telemetry?.pointingErrorDeg?.toFixed(4) ?? '0.0000' }}°
          </span>
        </div>

        <div class="hidden sm:flex items-center gap-1.5">
          <span class="text-slate-500">RATE |w|:</span>
          <span class="text-cyan-400 tabular-nums">
            {{ getRateDegS() }} °/s
          </span>
        </div>
      </div>

      <!-- Group 3: Actuator Momentum & Propellant -->
      <div class="flex items-center gap-4">
        <div class="flex items-center gap-1.5">
          <span class="text-slate-500">WHEEL MOMENTUM:</span>
          <span 
            [class]="(telemetry?.actuators?.totalWheelMomentumNms ?? 0) > 6.0 ? 'text-amber-400 font-bold' : 'text-emerald-400'"
            class="tabular-nums"
          >
            {{ telemetry?.actuators?.totalWheelMomentumNms?.toFixed(2) ?? '0.00' }} N·m·s
          </span>
        </div>

        <div class="hidden lg:flex items-center gap-1.5">
          <span class="text-slate-500">DESAT COILS:</span>
          <span 
            [class]="telemetry?.actuators?.magnetorquer?.active ? 'text-cyan-400 font-bold animate-pulse' : 'text-slate-500'"
          >
            {{ telemetry?.actuators?.magnetorquer?.active ? 'ACTIVE' : 'STANDBY' }}
          </span>
        </div>

        <div class="hidden xl:flex items-center gap-1.5">
          <span class="text-slate-500">PROPELLANT:</span>
          <span class="text-slate-200 tabular-nums">
            {{ telemetry?.actuators?.thruster?.propellantMassKg?.toFixed(2) ?? '45.00' }} kg
          </span>
        </div>

        <!-- Conservation & Consistency Check -->
        <div class="hidden 2xl:flex items-center gap-1.5 border-l border-slate-800 pl-3">
          <span class="text-slate-500">QUAT NORM:</span>
          <span class="text-emerald-400 tabular-nums">
            {{ getQuaternionNorm() }}
          </span>
          <span class="text-[10px] text-slate-500">[CONSISTENT]</span>
        </div>
      </div>
    </div>
  `,
})
export class TelemetryStripComponent {
  @Input() telemetry: TelemetryPoint | null = null;

  formatTime(totalSec: number): string {
    const mins = Math.floor(totalSec / 60);
    const secs = (totalSec % 60).toFixed(2);
    const mStr = mins < 10 ? `0${mins}` : `${mins}`;
    const sStr = Number(secs) < 10 ? `0${secs}` : `${secs}`;
    return `${mStr}:${sStr}`;
  }

  getVelocityMag(): string {
    if (!this.telemetry) return '7.58';
    const v = this.telemetry.trueVelocityEci;
    return Math.sqrt(v.x * v.x + v.y * v.y + v.z * v.z).toFixed(2);
  }

  getRateDegS(): string {
    if (!this.telemetry) return '0.000';
    const w = this.telemetry.trueAngularVelocityRadS;
    const mag = Math.sqrt(w[0] * w[0] + w[1] * w[1] + w[2] * w[2]);
    return ((mag * 180) / Math.PI).toFixed(3);
  }

  getQuaternionNorm(): string {
    if (!this.telemetry) return '1.000000';
    const q = this.telemetry.trueAttitude;
    const norm = Math.sqrt(q.q0 * q.q0 + q.q1 * q.q1 + q.q2 * q.q2 + q.q3 * q.q3);
    return norm.toFixed(6);
  }
}
