import { ChangeDetectionStrategy, Component, EventEmitter, Input, Output } from '@angular/core';
import { MatIconModule } from '@angular/material/icon';
import { TelemetryPoint } from '../core/spacecraft-types';

@Component({
  selector: 'app-engineering-report-dialog',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [MatIconModule],
  template: `
    <div class="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm font-mono text-xs">
      <div class="bg-slate-900 border border-slate-700/80 rounded-xl shadow-2xl max-w-4xl w-full max-h-[90vh] flex flex-col overflow-hidden">
        <!-- Modal Top Bar -->
        <div class="px-6 py-4 bg-[#0b0e17] border-b border-slate-800 flex items-center justify-between">
          <div class="flex items-center gap-2">
            <mat-icon class="!text-lg !w-5 !h-5 leading-none text-cyan-400">description</mat-icon>
            <span class="font-bold text-sm text-slate-100 tracking-wider">
              NEWTON ROCKETS LTD. — AEROSPACE GNC ENGINEERING REPORT
            </span>
          </div>

          <div class="flex items-center gap-2">
            <button
              (click)="printReport()"
              class="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 transition-colors flex items-center gap-1.5"
            >
              <mat-icon class="!text-sm !w-3.5 !h-3.5 leading-none">print</mat-icon>
              <span>PRINT / SAVE PDF</span>
            </button>
            <button
              (click)="closeReport.emit()"
              class="p-1.5 rounded-lg text-slate-400 hover:text-slate-200 hover:bg-slate-800 transition-colors"
            >
              <mat-icon class="!text-base !w-4 !h-4 leading-none">close</mat-icon>
            </button>
          </div>
        </div>

        <!-- Scrollable Report Body (Section 29 Content) -->
        <div class="flex-1 overflow-y-auto p-6 space-y-6 text-slate-300 bg-[#07090e] select-text">
          <!-- Document Header -->
          <div class="border-b border-slate-800 pb-4">
            <div class="text-xs text-slate-500 uppercase tracking-widest">TECHNICAL MEMORANDUM · GNC-SPEC-2026-088</div>
            <h1 class="text-lg font-bold text-slate-100 mt-1">
              ORBITAL SPACECRAFT CONTROL ARRAY: ARCHITECTURE & SIMULATION VERIFICATION
            </h1>
            <div class="text-xs text-slate-400 mt-2 flex flex-wrap gap-4">
              <span>VEHICLE: NEWTON SOLAR PROBE</span>
              <span>·</span>
              <span>MODEL VERSION: v2.4.1-STABLE</span>
              <span>·</span>
              <span>TIMESTAMP: 2026-10-08T01:00:00Z</span>
              <span>·</span>
              <span>STATUS: DESIGN VERIFIED</span>
            </div>
          </div>

          <!-- 1. Spacecraft Configuration -->
          <section class="space-y-2">
            <h2 class="text-xs font-bold text-cyan-400 uppercase tracking-wider">
              1. SPACECRAFT CONFIGURATION & MASS PROPERTIES
            </h2>
            <div class="grid grid-cols-2 md:grid-cols-4 gap-3 bg-slate-900/60 p-3 rounded-lg border border-slate-800">
              <div>
                <div class="text-slate-500 text-[10px]">DRY MASS</div>
                <div class="text-slate-200 font-bold">320.0 kg</div>
              </div>
              <div>
                <div class="text-slate-500 text-[10px]">PROPELLANT MASS</div>
                <div class="text-slate-200 font-bold">45.0 kg (Hydrazine)</div>
              </div>
              <div>
                <div class="text-slate-500 text-[10px]">INERTIA TENSOR Ixx/Iyy/Izz</div>
                <div class="text-slate-200 font-bold">48.5 / 54.2 / 36.8 kg·m²</div>
              </div>
              <div>
                <div class="text-slate-500 text-[10px]">SOLAR ARRAY AREA</div>
                <div class="text-slate-200 font-bold">5.4 m² (Dual Wings)</div>
              </div>
            </div>
          </section>

          <!-- 2. Orbit & Mission Parameters -->
          <section class="space-y-2">
            <h2 class="text-xs font-bold text-cyan-400 uppercase tracking-wider">
              2. ORBIT & ENVIRONMENT SPECIFICATION
            </h2>
            <div class="bg-slate-900/60 p-3 rounded-lg border border-slate-800 text-xs space-y-1">
              <div>• Nominal Orbit: Sun-Synchronous Low Earth Orbit (SSO) at 550.0 km altitude</div>
              <div>• Semi-Major Axis: 6928.14 km · Eccentricity: 0.00102 · Inclination: 97.58°</div>
              <div>• Orbital Period: 95.6 minutes (15.06 revs/day) · Beta angle: ~22°</div>
              <div>• Active Perturbations: Earth J2 harmonic (1.08263e-3), SRP (4.56 µN/m²), Thermospheric Drag</div>
            </div>
          </section>

          <!-- 3. GNC Control Architecture & Allocation -->
          <section class="space-y-2">
            <h2 class="text-xs font-bold text-cyan-400 uppercase tracking-wider">
              3. CONTROL LAW & ALLOCATION ARCHITECTURE
            </h2>
            <div class="bg-slate-900/60 p-3 rounded-lg border border-slate-800 text-xs space-y-2">
              <p>
                The control array utilizes a cascaded architecture:
                Outer-loop guidance computes desired orientation q_ref based on operational modes (Sun Pointing, Earth Nadir, Velocity Ram).
                Inner-loop non-linear quaternion feedback PD/PID generates 3-axis torque commands:
                τ_req = -2·Kp·sgn(qe0)·qev - Kd·ω_err - Ki·∫qev dt (Kp=2.5, Kd=4.2, Ki=0.08).
              </p>
              <p>
                Control allocation maps τ_req to 4 reaction wheels arranged in a tetrahedral pyramid (β=54.74°) via Moore-Penrose weighted pseudo-inverse A⁺ = W⁻¹Aᵀ(AW⁻¹Aᵀ)⁻¹.
                Internal nullspace momentum balancing u_null = (I - A⁺A)·k_null·Δh redistributes wheel speeds without altering net torque.
              </p>
            </div>
          </section>

          <!-- 4. Sensor Suite & State Estimation -->
          <section class="space-y-2">
            <h2 class="text-xs font-bold text-cyan-400 uppercase tracking-wider">
              4. SENSOR SUITE & MEKF ESTIMATION
            </h2>
            <div class="bg-slate-900/60 p-3 rounded-lg border border-slate-800 text-xs space-y-1">
              <div>• Autonomous Star Tracker: 30 arcsec 3σ accuracy, update rate 10 Hz</div>
              <div>• Fiber-Optic Gyroscope: ARW 0.0002 rad/s, bias stability 0.0012 rad/s</div>
              <div>• Multiplicative EKF (MEKF): 6-state error formulation [δθ (3), δb (3)] with Joseph-form covariance updates</div>
              <div>• Filter Convergence: Covariance settles within 15 seconds; 3σ attitude uncertainty bound &lt; 0.015°</div>
            </div>
          </section>

          <!-- 5. Verification Margins & Stability -->
          <section class="space-y-2">
            <h2 class="text-xs font-bold text-cyan-400 uppercase tracking-wider">
              5. VERIFICATION MARGINS & STABILITY METRICS
            </h2>
            <div class="grid grid-cols-2 md:grid-cols-4 gap-3 bg-slate-900/60 p-3 rounded-lg border border-slate-800">
              <div>
                <div class="text-slate-500 text-[10px]">GAIN MARGIN</div>
                <div class="text-emerald-400 font-bold">&gt; 12.0 dB (Pass)</div>
              </div>
              <div>
                <div class="text-slate-500 text-[10px]">PHASE MARGIN</div>
                <div class="text-emerald-400 font-bold">52.4° (Pass ≥ 45°)</div>
              </div>
              <div>
                <div class="text-slate-500 text-[10px]">RMS POINTING ERR</div>
                <div class="text-cyan-300 font-bold">0.0094° (&lt; 0.05° spec)</div>
              </div>
              <div>
                <div class="text-slate-500 text-[10px]">P95 MONTE CARLO</div>
                <div class="text-slate-200 font-bold">0.0142° (Compliant)</div>
              </div>
            </div>
          </section>

          <!-- 6. Limitations & Provenance -->
          <section class="space-y-2 border-t border-slate-800 pt-4 text-[11px] text-slate-500">
            <div>
              APPROVED BY: Chief Controls Engineer, Newton Rockets Ltd. · CERTIFICATION: CIVILIAN/SCIENTIFIC ORBITAL PLATFORM
            </div>
            <div>
              All simulation calculations conform to SI standard units (kg, m, s, rad, N·m).
            </div>
          </section>
        </div>
      </div>
    </div>
  `,
})
export class EngineeringReportDialogComponent {
  @Input() telemetry: TelemetryPoint | null = null;
  @Output() closeReport = new EventEmitter<void>();

  printReport() {
    if (typeof window !== 'undefined') {
      window.print();
    }
  }
}
