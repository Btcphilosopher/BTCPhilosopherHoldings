import { ChangeDetectionStrategy, Component, EventEmitter, Input, Output } from '@angular/core';
import { MatIconModule } from '@angular/material/icon';
import { TelemetryPoint, ReactionWheelState } from '../core/spacecraft-types';

@Component({
  selector: 'app-actuator-momentum-panel',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [MatIconModule],
  template: `
    <div class="space-y-4 font-mono">
      <!-- Section 17: Real Simulated Momentum State Dashboard -->
      <div class="bg-slate-900/90 border border-slate-800 rounded-xl p-4">
        <div class="flex flex-wrap items-center justify-between gap-2 mb-3 pb-2 border-b border-slate-800">
          <div>
            <span class="text-xs text-slate-200 font-semibold tracking-wider uppercase">
              MOMENTUM STATE & ACCUMULATION DASHBOARD
            </span>
            <p class="text-[11px] text-slate-400">
              Live reaction-wheel stored angular momentum and automatic magnetorquer desaturation status
            </p>
          </div>
          <div class="flex items-center gap-3 text-xs">
            <span class="text-slate-400">NET STORED MOMENTUM:</span>
            <span 
              [class]="(telemetry?.actuators?.totalWheelMomentumNms ?? 0) > 6.0 ? 'text-amber-400 font-bold' : 'text-emerald-400 font-bold'"
              class="tabular-nums"
            >
              {{ telemetry?.actuators?.totalWheelMomentumNms?.toFixed(2) ?? '0.00' }} / 10.00 N·m·s
            </span>
          </div>
        </div>

        <!-- ASCII / Graphical Momentum Bars as explicitly requested in Section 17 -->
        <div class="space-y-3">
          @for (wheel of telemetry?.actuators?.wheels; track wheel.id) {
            <div class="bg-slate-950/70 p-3 rounded-lg border border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
              <div class="w-32 shrink-0">
                <span class="font-bold text-slate-200">WHEEL {{ wheel.id }}</span>
                <span class="text-[10px] text-slate-500 ml-1.5">({{ wheel.speedRpm.toFixed(0) }} RPM)</span>
              </div>

              <!-- Bar representation -->
              <div class="flex-1 flex items-center gap-2">
                <div class="flex-1 h-4 bg-slate-900 rounded border border-slate-800 overflow-hidden relative">
                  <div
                    [class]="wheel.failed ? 'bg-rose-500' : (wheel.saturated ? 'bg-amber-500' : 'bg-cyan-500')"
                    [style.width.%]="getMomentumPct(wheel)"
                    class="h-full transition-all duration-100 flex items-center justify-end pr-1 text-[9px] font-bold text-slate-950"
                  ></div>
                </div>
                <div class="w-20 text-right tabular-nums text-slate-300">
                  {{ wheel.momentumNms.toFixed(2) }} N·m·s
                </div>
              </div>

              <!-- Wheel Health / Fault Badge -->
              <div class="w-24 text-right">
                @if (wheel.failed) {
                  <span class="text-[10px] text-rose-400 font-bold px-1.5 py-0.5 rounded bg-rose-500/10 border border-rose-500/20">
                    LOCKED
                  </span>
                } @else if (wheel.saturated) {
                  <span class="text-[10px] text-amber-400 font-bold px-1.5 py-0.5 rounded bg-amber-500/10 border border-amber-500/20">
                    SATURATED
                  </span>
                } @else {
                  <span class="text-[10px] text-emerald-400 px-1.5 py-0.5 rounded bg-emerald-500/10 border border-emerald-500/20">
                    NOMINAL
                  </span>
                }
              </div>
            </div>
          }
        </div>
      </div>

      <!-- Secondary Actuators: Magnetorquers & RCS Thruster -->
      <div class="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <!-- 3-Axis Magnetorquer Momentum Management (Section 13) -->
        <div class="bg-slate-900/90 border border-slate-800 rounded-xl p-4 flex flex-col justify-between">
          <div>
            <div class="flex items-center justify-between mb-3 pb-2 border-b border-slate-800">
              <span class="text-xs text-slate-200 font-semibold tracking-wider uppercase">
                MAGNETORQUER MOMENTUM DESATURATION (MTQ)
              </span>
              <span 
                [class]="telemetry?.actuators?.magnetorquer?.active ? 'bg-cyan-500/20 text-cyan-300 border-cyan-500/40 animate-pulse' : 'bg-slate-800 text-slate-400'"
                class="text-[10px] px-2 py-0.5 rounded border"
              >
                {{ telemetry?.actuators?.magnetorquer?.active ? 'CROSS-PRODUCT DUMPING' : 'IDLE' }}
              </span>
            </div>

            <div class="bg-slate-950/70 p-3 rounded-lg border border-slate-800/80 mb-3 text-[11px] space-y-1.5">
              <div class="text-[10px] text-slate-500">MAGNETORQUER CONTROL LAW:</div>
              <div class="text-cyan-300 font-bold">
                m_cmd = (k_dump / ||B||²) · (H_wheel × B_local)
              </div>
              <div class="text-slate-400 text-[10px]">
                Low-authority geomagnetic interaction for continuous wheel momentum unloading without consuming propellant.
              </div>
            </div>

            <!-- Dipole Moment & Generated Torque Readouts -->
            <div class="space-y-2 text-xs">
              <div class="flex justify-between items-center py-1 border-b border-slate-800/60">
                <span class="text-slate-400">Commanded Dipole [mx, my, mz]:</span>
                <span class="text-slate-200 tabular-nums">
                  [{{ formatAm2(telemetry?.actuators?.magnetorquer?.dipoleMomentAm2?.[0]) }},
                   {{ formatAm2(telemetry?.actuators?.magnetorquer?.dipoleMomentAm2?.[1]) }},
                   {{ formatAm2(telemetry?.actuators?.magnetorquer?.dipoleMomentAm2?.[2]) }}] A·m²
                </span>
              </div>

              <div class="flex justify-between items-center py-1 border-b border-slate-800/60">
                <span class="text-slate-400">Generated Magnetic Torque:</span>
                <span class="text-emerald-400 tabular-nums">
                  [{{ formatMicroNm(telemetry?.actuators?.magnetorquer?.generatedTorqueNm?.[0]) }},
                   {{ formatMicroNm(telemetry?.actuators?.magnetorquer?.generatedTorqueNm?.[1]) }},
                   {{ formatMicroNm(telemetry?.actuators?.magnetorquer?.generatedTorqueNm?.[2]) }}] µN·m
                </span>
              </div>

              <div class="flex justify-between items-center py-1">
                <span class="text-slate-400">Max Magnetic Authority:</span>
                <span class="text-slate-300">±30.0 A·m² / Axis</span>
              </div>
            </div>
          </div>

          <div class="mt-3 text-[10px] text-slate-500 pt-2 border-t border-slate-800">
            Field reference: IGRF geomagnetic dipole approximation
          </div>
        </div>

        <!-- System-Level RCS Thruster Model (Section 14) -->
        <div class="bg-slate-900/90 border border-slate-800 rounded-xl p-4 flex flex-col justify-between">
          <div>
            <div class="flex items-center justify-between mb-3 pb-2 border-b border-slate-800">
              <span class="text-xs text-slate-200 font-semibold tracking-wider uppercase">
                REACTION CONTROL SYSTEM (RCS THRUSTERS)
              </span>
              <span 
                [class]="telemetry?.actuators?.thruster?.firing ? 'bg-amber-500/20 text-amber-300 border-amber-500/40 animate-pulse' : 'bg-slate-800 text-slate-400'"
                class="text-[10px] px-2 py-0.5 rounded border"
              >
                {{ telemetry?.actuators?.thruster?.firing ? 'VALVE OPEN / FIRING' : 'READY' }}
              </span>
            </div>

            <!-- Thruster Specs -->
            <div class="bg-slate-950/70 p-3 rounded-lg border border-slate-800/80 mb-3 text-xs space-y-2">
              <div class="flex justify-between">
                <span class="text-slate-400">Nominal Thrust:</span>
                <span class="text-slate-100 font-bold tabular-nums">
                  {{ telemetry?.actuators?.thruster?.thrustN?.toFixed(1) ?? '4.0' }} N
                </span>
              </div>
              <div class="flex justify-between">
                <span class="text-slate-400">Specific Impulse (Isp):</span>
                <span class="text-slate-100 tabular-nums">
                  {{ telemetry?.actuators?.thruster?.ispSec ?? 220 }} sec
                </span>
              </div>
              <div class="flex justify-between">
                <span class="text-slate-400">Total Delta-V Executed:</span>
                <span class="text-cyan-300 font-bold tabular-nums">
                  {{ telemetry?.actuators?.thruster?.totalDeltaVMs?.toFixed(2) ?? '0.00' }} m/s
                </span>
              </div>
            </div>

            <!-- Propellant Mass Bar -->
            <div class="space-y-1">
              <div class="flex justify-between text-xs">
                <span class="text-slate-400">Propellant Remaining:</span>
                <span class="text-slate-200 font-bold tabular-nums">
                  {{ telemetry?.actuators?.thruster?.propellantMassKg?.toFixed(2) ?? '45.00' }} / 45.00 kg
                </span>
              </div>
              <div class="h-2 w-full bg-slate-950 rounded-full overflow-hidden border border-slate-800">
                <div
                  [style.width.%]="getPropellantPct()"
                  class="h-full bg-cyan-500 transition-all duration-100"
                ></div>
              </div>
            </div>
          </div>

          <!-- Thruster Fire Trigger Button -->
          <div class="mt-4 pt-3 border-t border-slate-800 flex items-center justify-between">
            <span class="text-slate-400 text-xs">Manual Pulse Burn:</span>
            <button
              (click)="toggleThruster.emit()"
              [class]="telemetry?.actuators?.thruster?.firing 
                ? 'bg-rose-500/20 text-rose-300 border-rose-500/40 hover:bg-rose-500/30' 
                : 'bg-cyan-500/10 text-cyan-300 border-cyan-500/30 hover:bg-cyan-500/20'"
              class="px-3 py-1.5 text-xs font-bold rounded-lg border transition-colors flex items-center gap-1.5"
            >
              <mat-icon class="!text-sm !w-3.5 !h-3.5 leading-none">local_fire_department</mat-icon>
              <span>{{ telemetry?.actuators?.thruster?.firing ? 'CUT THRUST' : 'FIRE RCS THRUSTERS' }}</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  `,
})
export class ActuatorMomentumPanelComponent {
  @Input() telemetry: TelemetryPoint | null = null;
  @Output() toggleThruster = new EventEmitter<void>();

  getMomentumPct(wheel: ReactionWheelState): number {
    return Math.min(100, (Math.abs(wheel.momentumNms) / wheel.maxMomentumNms) * 100);
  }

  getPropellantPct(): number {
    if (!this.telemetry?.actuators?.thruster) return 100;
    const t = this.telemetry.actuators.thruster;
    return Math.max(0, Math.min(100, (t.propellantMassKg / t.initialPropellantKg) * 100));
  }

  formatAm2(val?: number): string {
    if (val === undefined) return '0.00';
    return val.toFixed(2);
  }

  formatMicroNm(val?: number): string {
    if (val === undefined) return '0.0';
    return (val * 1e6).toFixed(1);
  }
}
