import { ChangeDetectionStrategy, Component, OnInit } from '@angular/core';
import { MatIconModule } from '@angular/material/icon';
import { REPOSITORY_FILES, RepoFile } from '../core/repository-blueprint';

@Component({
  selector: 'app-repo-browser-panel',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [MatIconModule],
  template: `
    <div class="h-[680px] bg-slate-900/90 border border-slate-800 rounded-xl overflow-hidden flex flex-col font-mono text-xs">
      <!-- Top Bar: Repository Header & Actions -->
      <div class="px-4 py-2.5 bg-[#0b0e17] border-b border-slate-800 flex flex-wrap items-center justify-between gap-3 select-none">
        <div class="flex items-center gap-2">
          <mat-icon class="!text-sm !w-4 !h-4 leading-none text-cyan-400">folder_special</mat-icon>
          <span class="font-bold text-slate-100">orbital-control-array/</span>
          <span class="text-slate-500">·</span>
          <span class="text-[11px] text-slate-400">Python 3.12+ · Rust · Kotlin/Compose · R</span>
        </div>

        <div class="flex items-center gap-2">
          <button
            (click)="copyCurrentCode()"
            class="px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 transition-colors flex items-center gap-1"
          >
            <mat-icon class="!text-sm !w-3.5 !h-3.5 leading-none">{{ copied ? 'done' : 'content_copy' }}</mat-icon>
            <span>{{ copied ? 'COPIED!' : 'COPY FILE' }}</span>
          </button>

          <button
            (click)="downloadBundle()"
            class="px-2.5 py-1 rounded bg-cyan-600 hover:bg-cyan-500 text-slate-950 font-bold transition-colors flex items-center gap-1"
          >
            <mat-icon class="!text-sm !w-3.5 !h-3.5 leading-none">download</mat-icon>
            <span>EXPORT REPO BUNDLE</span>
          </button>
        </div>
      </div>

      <!-- Main Workspace: Split Pane (File Explorer on Left, Code Viewer on Right) -->
      <div class="flex-1 flex overflow-hidden">
        <!-- Left: File Explorer Sidebar (260px) -->
        <div class="w-64 bg-slate-950/80 border-r border-slate-800 p-2 overflow-y-auto select-none space-y-1">
          <div class="text-[10px] text-slate-500 uppercase px-2 py-1 font-semibold tracking-wider">
            PROJECT SOURCE TREE
          </div>

          @for (file of files; track file.path) {
            <button
              (click)="selectFile(file)"
              [class]="selectedFile.path === file.path 
                ? 'bg-slate-800 text-cyan-300 font-semibold' 
                : 'text-slate-400 hover:bg-slate-900 hover:text-slate-200'"
              class="w-full text-left px-2 py-1.5 rounded transition-colors flex items-center gap-2 group truncate"
            >
              <mat-icon class="!text-sm !w-3.5 !h-3.5 leading-none text-slate-500 group-hover:text-cyan-400">
                {{ getFileIcon(file.language) }}
              </mat-icon>
              <span class="truncate text-[11px]">{{ file.path }}</span>
            </button>
          }
        </div>

        <!-- Right: Code Viewer & File Details -->
        <div class="flex-1 flex flex-col bg-[#07090e] overflow-hidden">
          <!-- File Subtitle Bar -->
          <div class="px-4 py-2 bg-slate-900/60 border-b border-slate-800/80 flex items-center justify-between text-[11px]">
            <div class="flex items-center gap-2">
              <span class="text-slate-200 font-bold">{{ selectedFile.path }}</span>
              <span class="text-slate-600">·</span>
              <span class="text-slate-400">{{ selectedFile.description }}</span>
            </div>
            <span class="text-[10px] uppercase px-1.5 py-0.5 rounded bg-slate-800 text-slate-300">
              {{ selectedFile.language }}
            </span>
          </div>

          <!-- Code Content with Line Numbers -->
          <div class="flex-1 overflow-auto p-4 font-mono text-[11px] leading-relaxed select-text text-slate-300 bg-[#07090e]">
            <pre class="overflow-x-auto whitespace-pre font-mono"><code>{{ selectedFile.content }}</code></pre>
          </div>
        </div>
      </div>
    </div>
  `,
})
export class RepoBrowserPanelComponent implements OnInit {
  files = REPOSITORY_FILES;
  selectedFile!: RepoFile;
  copied = false;

  ngOnInit() {
    this.selectedFile = this.files[0];
  }

  selectFile(file: RepoFile) {
    this.selectedFile = file;
    this.copied = false;
  }

  getFileIcon(lang: string): string {
    switch (lang) {
      case 'python':
        return 'code';
      case 'rust':
        return 'memory';
      case 'kotlin':
        return 'android';
      case 'r':
        return 'insights';
      case 'yaml':
      case 'toml':
        return 'settings';
      default:
        return 'description';
    }
  }

  copyCurrentCode() {
    if (typeof navigator !== 'undefined' && navigator.clipboard) {
      navigator.clipboard.writeText(this.selectedFile.content);
      this.copied = true;
      setTimeout(() => (this.copied = false), 2000);
    }
  }

  downloadBundle() {
    // Generate text export blob of selected file or full bundle manifest
    const manifest = this.files.map((f) => `=== ${f.path} ===\n${f.content}\n\n`).join('\n');
    const blob = new Blob([manifest], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'newton-orbital-control-array-repo.txt';
    a.click();
    URL.revokeObjectURL(url);
  }
}
