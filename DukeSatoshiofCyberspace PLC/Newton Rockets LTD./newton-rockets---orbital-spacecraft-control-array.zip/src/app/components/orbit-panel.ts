import { ChangeDetectionStrategy, Component, EventEmitter, Input, Output } from '@angular/core';
import { MatIconModule } from '@angular/material/icon';
import { TelemetryPoint, ModelFidelity } from '../core/spacecraft-types';

@Component({
  selector: 'app-orbit-panel',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [MatIconModule],
  template: `
    <div class="space-y-4 font-mono">
      <!-- Section 5 Mandate: MODEL FIDELITY BANNER -->
      <div class="bg-slate-900/90 border border-slate-800 rounded-xl p-4 flex flex-wrap items-center justify-between gap-3">
        <div>
          <div class="flex items-center gap-2">
            <span class="text-xs text-slate-400 font-semibold uppercase tracking-wider">MODEL FIDELITY:</span>
            <span 
              [class]="fidelity === 'high-fidelity' 
                ? 'bg-cyan-500/10 text-cyan-300 border-cyan-500/30' 
                : fidelity === 'j2-perturbed' 
                ? 'bg-blue-500/10 text-blue-300 border-blue-500/30' 
                : 'bg-slate-800 text-slate-300 border-slate-700'"
              class="text-xs font-bold px-2.5 py-0.5 rounded border tracking-wider uppercase"
            >
              {{ fidelity.replace('-', ' ') }}
            </span>
          </div>
          <p class="text-[11px] text-slate-400 mt-1">
            Active numerical propagator physics: 
            @if (fidelity === 'two-body') {
              Point-mass Keplerian central gravity (µ = 398600.44 km³/s²)
            } @else if (fidelity === 'j2-perturbed') {
              Two-Body + Earth J2 Oblateness harmonic perturbation (J2 = 1.08263e-3)
            } @else {
              J2 Oblateness + Solar Radiation Pressure (4.56 µN/m²) + Thermospheric Drag
            }
          </p>
        </div>

        <!-- Fidelity Selector Buttons -->
        <div class="flex items-center gap-1.5 bg-slate-950 p-1 rounded-lg border border-slate-800 text-xs">
          <button
            (click)="changeFidelity.emit('two-body')"
            [class]="fidelity === 'two-body' ? 'bg-slate-800 text-cyan-300 font-bold' : 'text-slate-400 hover:text-slate-200'"
            class="px-2.5 py-1 rounded transition-colors"
          >
            TWO-BODY
          </button>
          <button
            (click)="changeFidelity.emit('j2-perturbed')"
            [class]="fidelity === 'j2-perturbed' ? 'bg-slate-800 text-cyan-300 font-bold' : 'text-slate-400 hover:text-slate-200'"
            class="px-2.5 py-1 rounded transition-colors"
          >
            J2 PERTURBED
          </button>
          <button
            (click)="changeFidelity.emit('high-fidelity')"
            [class]="fidelity === 'high-fidelity' ? 'bg-slate-800 text-cyan-300 font-bold' : 'text-slate-400 hover:text-slate-200'"
            class="px-2.5 py-1 rounded transition-colors"
          >
            HIGH FIDELITY
          </button>
        </div>
      </div>

      <!-- Orbital Elements & Cartesian Coordinates -->
      <div class="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <!-- Keplerian Classical Orbital Elements -->
        <div class="bg-slate-900/90 border border-slate-800 rounded-xl p-4 flex flex-col justify-between">
          <div>
            <div class="flex items-center justify-between mb-3 pb-2 border-b border-slate-800">
              <span class="text-xs text-slate-200 font-semibold tracking-wider uppercase">
                CLASSICAL KEPLERIAN ORBITAL ELEMENTS
              </span>
              <span class="text-[10px] px-2 py-0.5 rounded bg-slate-800 text-slate-400">
                SUN-SYNCHRONOUS LEO
              </span>
            </div>

            <div class="space-y-2 text-xs">
              <div class="flex justify-between py-1 border-b border-slate-800/60">
                <span class="text-slate-400">Semi-Major Axis (a):</span>
                <span class="text-slate-100 font-semibold tabular-nums">
                  {{ telemetry?.trueOrbit?.semiMajorAxis?.toFixed(2) ?? '6928.14' }} km
                </span>
              </div>

              <div class="flex justify-between py-1 border-b border-slate-800/60">
                <span class="text-slate-400">Eccentricity (e):</span>
                <span class="text-slate-100 font-semibold tabular-nums">
                  {{ telemetry?.trueOrbit?.eccentricity?.toFixed(6) ?? '0.001020' }}
                </span>
              </div>

              <div class="flex justify-between py-1 border-b border-slate-800/60">
                <span class="text-slate-400">Inclination (i):</span>
                <span class="text-slate-100 font-semibold tabular-nums">
                  {{ telemetry?.trueOrbit?.inclination?.toFixed(3) ?? '97.580' }}°
                </span>
              </div>

              <div class="flex justify-between py-1 border-b border-slate-800/60">
                <span class="text-slate-400">RAAN (Ω):</span>
                <span class="text-slate-100 font-semibold tabular-nums">
                  {{ telemetry?.trueOrbit?.raan?.toFixed(3) ?? '142.100' }}°
                </span>
              </div>

              <div class="flex justify-between py-1 border-b border-slate-800/60">
                <span class="text-slate-400">Argument of Periapsis (ω):</span>
                <span class="text-slate-100 font-semibold tabular-nums">
                  {{ telemetry?.trueOrbit?.argOfPeriapsis?.toFixed(3) ?? '78.450' }}°
                </span>
              </div>

              <div class="flex justify-between py-1 border-b border-slate-800/60">
                <span class="text-slate-400">True Anomaly (ν):</span>
                <span class="text-cyan-300 font-bold tabular-nums">
                  {{ telemetry?.trueOrbit?.trueAnomaly?.toFixed(3) ?? '0.000' }}°
                </span>
              </div>

              <div class="flex justify-between py-1">
                <span class="text-slate-400">Orbital Period (T):</span>
                <span class="text-slate-200 tabular-nums">
                  {{ telemetry?.trueOrbit?.periodMinutes?.toFixed(2) ?? '95.60' }} min
                </span>
              </div>
            </div>
          </div>

          <div class="mt-3 text-[10px] text-slate-500 pt-2 border-t border-slate-800 flex justify-between">
            <span>Perigee: {{ getPerigeeKm() }} km</span>
            <span>Apogee: {{ getApogeeKm() }} km</span>
          </div>
        </div>

        <!-- Cartesian State Vector & Manoeuvre Planner (Section 18) -->
        <div class="bg-slate-900/90 border border-slate-800 rounded-xl p-4 flex flex-col justify-between">
          <div>
            <div class="flex items-center justify-between mb-3 pb-2 border-b border-slate-800">
              <span class="text-xs text-slate-200 font-semibold tracking-wider uppercase">
                CARTESIAN STATE & MISSION MANOEUVRES
              </span>
              <span class="text-[10px] px-2 py-0.5 rounded bg-blue-500/10 text-blue-400 border border-blue-500/20">
                ECI J2000
              </span>
            </div>

            <!-- Position & Velocity ECI -->
            <div class="grid grid-cols-2 gap-2 text-xs mb-3">
              <div class="bg-slate-950/70 p-2.5 rounded-lg border border-slate-800">
                <div class="text-[10px] text-slate-500 uppercase mb-1">Position ECI (km)</div>
                <div class="text-slate-200 tabular-nums text-[11px] space-y-0.5">
                  <div>X: {{ telemetry?.truePositionEci?.x?.toFixed(1) ?? '6928.1' }}</div>
                  <div>Y: {{ telemetry?.truePositionEci?.y?.toFixed(1) ?? '0.0' }}</div>
                  <div>Z: {{ telemetry?.truePositionEci?.z?.toFixed(1) ?? '0.0' }}</div>
                </div>
              </div>

              <div class="bg-slate-950/70 p-2.5 rounded-lg border border-slate-800">
                <div class="text-[10px] text-slate-500 uppercase mb-1">Velocity ECI (km/s)</div>
                <div class="text-slate-200 tabular-nums text-[11px] space-y-0.5">
                  <div>Vx: {{ telemetry?.trueVelocityEci?.x?.toFixed(3) ?? '0.000' }}</div>
                  <div>Vy: {{ telemetry?.trueVelocityEci?.y?.toFixed(3) ?? '7.580' }}</div>
                  <div>Vz: {{ telemetry?.trueVelocityEci?.z?.toFixed(3) ?? '0.000' }}</div>
                </div>
              </div>
            </div>

            <!-- Abstract Manoeuvre Model Triggers -->
            <div class="bg-slate-950/70 p-3 rounded-lg border border-slate-800 text-xs space-y-2">
              <div class="text-[10px] text-slate-400 uppercase font-semibold">Mission Manoeuvre Execution</div>
              <p class="text-[11px] text-slate-400">
                Inject instantaneous impulsional Delta-V burns to evaluate orbit change, station-keeping requirements, and mass consumption:
              </p>
              
              <div class="grid grid-cols-2 gap-2 pt-1">
                <button
                  (click)="executeDeltaV(5.0)"
                  class="px-2.5 py-1.5 rounded bg-slate-900 hover:bg-slate-800 border border-slate-700 text-cyan-300 font-bold transition-colors text-left flex flex-col"
                >
                  <span>+5.0 m/s PROGRADE</span>
                  <span class="text-[9px] text-slate-500">Orbit Raising (~18 km)</span>
                </button>

                <button
                  (click)="executeDeltaV(-5.0)"
                  class="px-2.5 py-1.5 rounded bg-slate-900 hover:bg-slate-800 border border-slate-700 text-amber-300 font-bold transition-colors text-left flex flex-col"
                >
                  <span>-5.0 m/s RETROGRADE</span>
                  <span class="text-[9px] text-slate-500">Orbit Lowering (~18 km)</span>
                </button>
              </div>
            </div>
          </div>

          <div class="mt-3 text-[10px] text-slate-500 pt-2 border-t border-slate-800 flex justify-between">
            <span>Tsiolkovsky mass tracking: Isp = 220s</span>
            <span>Δv executed: {{ telemetry?.actuators?.thruster?.totalDeltaVMs?.toFixed(2) ?? '0.00' }} m/s</span>
          </div>
        </div>
      </div>
    </div>
  `,
})
export class OrbitPanelComponent {
  @Input() telemetry: TelemetryPoint | null = null;
  @Input() fidelity: ModelFidelity = 'j2-perturbed';

  @Output() changeFidelity = new EventEmitter<ModelFidelity>();
  @Output() injectBurn = new EventEmitter<number>();

  executeDeltaV(dv: number) {
    this.injectBurn.emit(dv);
  }

  getPerigeeKm(): string {
    if (!this.telemetry?.trueOrbit) return '540.0';
    const { semiMajorAxis, eccentricity } = this.telemetry.trueOrbit;
    return (semiMajorAxis * (1 - eccentricity) - 6378.137).toFixed(1);
  }

  getApogeeKm(): string {
    if (!this.telemetry?.trueOrbit) return '560.0';
    const { semiMajorAxis, eccentricity } = this.telemetry.trueOrbit;
    return (semiMajorAxis * (1 + eccentricity) - 6378.137).toFixed(1);
  }
}
