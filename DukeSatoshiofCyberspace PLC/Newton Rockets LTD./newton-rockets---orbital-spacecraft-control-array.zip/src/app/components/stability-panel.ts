import { ChangeDetectionStrategy, Component, Input, OnInit, OnChanges } from '@angular/core';
import { MatIconModule } from '@angular/material/icon';
import { StabilityAnalysis, StabilityMetrics, BodePoint } from '../core/stability-analysis';

@Component({
  selector: 'app-stability-panel',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [MatIconModule],
  template: `
    <div class="space-y-4 font-mono">
      <!-- Top Grid: Stability Margins & Poles -->
      <div class="grid grid-cols-1 lg:grid-cols-4 gap-4">
        <!-- Metric 1: Gain Margin -->
        <div class="bg-slate-900/90 border border-slate-800 rounded-xl p-4 flex flex-col justify-between">
          <div>
            <div class="text-[10px] text-slate-500 uppercase tracking-wider mb-1">GAIN MARGIN (GM)</div>
            <div class="text-2xl font-bold text-slate-100 tabular-nums">
              {{ metrics.gainMarginDb }} dB
            </div>
          </div>
          <div class="text-[11px] text-slate-400 mt-2">
            @if (metrics.gainMarginDb > 6.0) {
              <span class="text-emerald-400 font-semibold">● ROBUST (> 6 dB)</span>
            } @else if (metrics.gainMarginDb > 0) {
              <span class="text-amber-400 font-semibold">▲ MARGINAL</span>
            } @else {
              <span class="text-rose-400 font-semibold">✖ UNSTABLE</span>
            }
            <div class="text-[10px] text-slate-500 mt-0.5">At ω = {{ metrics.phaseCrossoverFreqRadS }} rad/s</div>
          </div>
        </div>

        <!-- Metric 2: Phase Margin -->
        <div class="bg-slate-900/90 border border-slate-800 rounded-xl p-4 flex flex-col justify-between">
          <div>
            <div class="text-[10px] text-slate-500 uppercase tracking-wider mb-1">PHASE MARGIN (PM)</div>
            <div class="text-2xl font-bold text-cyan-300 tabular-nums">
              {{ metrics.phaseMarginDeg }}°
            </div>
          </div>
          <div class="text-[11px] text-slate-400 mt-2">
            @if (metrics.phaseMarginDeg >= 45.0) {
              <span class="text-emerald-400 font-semibold">● OPTIMAL (≥ 45°)</span>
            } @else if (metrics.phaseMarginDeg > 0) {
              <span class="text-amber-400 font-semibold">▲ UNDERDAMPED</span>
            } @else {
              <span class="text-rose-400 font-semibold">✖ UNSTABLE</span>
            }
            <div class="text-[10px] text-slate-500 mt-0.5">At ω_gc = {{ metrics.gainCrossoverFreqRadS }} rad/s</div>
          </div>
        </div>

        <!-- Metric 3: Damping & Bandwidth -->
        <div class="bg-slate-900/90 border border-slate-800 rounded-xl p-4 flex flex-col justify-between">
          <div>
            <div class="text-[10px] text-slate-500 uppercase tracking-wider mb-1">DAMPING RATIO & NATURAL FREQ</div>
            <div class="text-xl font-bold text-slate-200 tabular-nums">
              ζ = {{ metrics.dampingRatio }}
            </div>
          </div>
          <div class="text-[11px] text-slate-400 mt-2">
            <div>ωn: <span class="text-slate-200 font-semibold tabular-nums">{{ metrics.naturalFreqRadS }} rad/s</span></div>
            <div class="text-[10px] text-slate-500 mt-0.5">Bandwidth: {{ (metrics.naturalFreqRadS / (2 * 3.14159)).toFixed(3) }} Hz</div>
          </div>
        </div>

        <!-- Metric 4: Settling Time Estimate -->
        <div class="bg-slate-900/90 border border-slate-800 rounded-xl p-4 flex flex-col justify-between">
          <div>
            <div class="text-[10px] text-slate-500 uppercase tracking-wider mb-1">ESTIMATED SETTLING TIME (Ts 2%)</div>
            <div class="text-2xl font-bold text-emerald-400 tabular-nums">
              {{ metrics.estimatedSettlingTimeSec }} s
            </div>
          </div>
          <div class="text-[11px] text-slate-400 mt-2">
            <div>Ts ≈ 4 / (ζ · ωn)</div>
            <div class="text-[10px] text-slate-500 mt-0.5">Dominant conjugate pair decay</div>
          </div>
        </div>
      </div>

      <!-- Closed-Loop Poles in the Complex S-Plane & Bode Diagram -->
      <div class="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <!-- SVG 1: Closed-Loop Poles in the Complex S-Plane -->
        <div class="bg-slate-900/90 border border-slate-800 rounded-xl p-4 flex flex-col justify-between">
          <div>
            <div class="flex items-center justify-between mb-3 pb-2 border-b border-slate-800">
              <span class="text-xs text-slate-200 font-semibold tracking-wider uppercase">
                CLOSED-LOOP POLES (COMPLEX S-PLANE)
              </span>
              <span 
                [class]="metrics.isStable ? 'text-emerald-400 bg-emerald-500/10 border-emerald-500/20' : 'text-rose-400 bg-rose-500/10 border-rose-500/20'"
                class="text-[10px] px-2 py-0.5 rounded border font-bold"
              >
                {{ metrics.isStable ? 'LHP STABLE' : 'UNSTABLE POLES' }}
              </span>
            </div>

            <!-- SVG S-Plane -->
            <div class="bg-slate-950 rounded-lg p-2 border border-slate-800 relative flex justify-center">
              <svg viewBox="-120 -80 240 160" class="w-full h-52">
                <!-- Stable Left Half Plane Background -->
                <rect x="-120" y="-80" width="120" height="160" fill="rgba(16, 185, 129, 0.05)" />
                <rect x="0" y="-80" width="120" height="160" fill="rgba(239, 68, 68, 0.05)" />

                <!-- Grid lines -->
                <line x1="-120" y1="0" x2="120" y2="0" stroke="#334155" stroke-width="1" />
                <line x1="0" y1="-80" x2="0" y2="80" stroke="#475569" stroke-width="1.5" />
                
                <!-- Axis labels -->
                <text x="95" y="12" fill="#64748b" font-size="8" font-family="monospace">σ (Real)</text>
                <text x="4" y="-68" fill="#64748b" font-size="8" font-family="monospace">jω (Imag)</text>

                <!-- Damping angle lines -->
                <line x1="0" y1="0" x2="-80" y2="-60" stroke="#1e293b" stroke-dasharray="2,2" stroke-width="1" />
                <line x1="0" y1="0" x2="-80" y2="60" stroke="#1e293b" stroke-dasharray="2,2" stroke-width="1" />

                <!-- Poles marked as 'X' -->
                @for (p of metrics.poles; track $index) {
                  <g [attr.transform]="'translate(' + (p.real * 70) + ',' + (-p.imag * 70) + ')'">
                    <line x1="-5" y1="-5" x2="5" y2="5" stroke="#38bdf8" stroke-width="2.5" />
                    <line x1="-5" y1="5" x2="5" y2="-5" stroke="#38bdf8" stroke-width="2.5" />
                    <circle cx="0" cy="0" r="7" fill="none" stroke="rgba(56, 189, 248, 0.4)" stroke-width="1" />
                  </g>
                }
              </svg>
            </div>

            <!-- Pole Values Table -->
            <div class="mt-3 space-y-1 text-xs">
              @for (p of metrics.poles; track $index) {
                <div class="flex justify-between py-1 border-b border-slate-800/60">
                  <span class="text-slate-400">Pole p{{ $index + 1 }}:</span>
                  <span class="text-slate-200 tabular-nums">
                    {{ p.real }} {{ p.imag !== 0 ? (p.imag > 0 ? '+ ' : '- ') + Math.abs(p.imag) + 'j' : '' }}
                  </span>
                </div>
              }
            </div>
          </div>

          <div class="mt-3 text-[10px] text-slate-500 pt-2 border-t border-slate-800">
            Characteristic Equation: I·s³ + Kd·s² + Kp·s + Ki = 0
          </div>
        </div>

        <!-- SVG 2: Bode Frequency Response Plot -->
        <div class="bg-slate-900/90 border border-slate-800 rounded-xl p-4 flex flex-col justify-between">
          <div>
            <div class="flex items-center justify-between mb-3 pb-2 border-b border-slate-800">
              <span class="text-xs text-slate-200 font-semibold tracking-wider uppercase">
                BODE FREQUENCY RESPONSE L(jω)
              </span>
              <span class="text-[10px] px-2 py-0.5 rounded bg-slate-800 text-slate-300">
                OPEN-LOOP TRANSFER FUNCTION
              </span>
            </div>

            <!-- SVG Bode Plot -->
            <div class="bg-slate-950 rounded-lg p-2 border border-slate-800 relative">
              <svg viewBox="0 0 300 170" class="w-full h-52">
                <!-- 0 dB Line -->
                <line x1="30" y1="50" x2="290" y2="50" stroke="#475569" stroke-width="1" stroke-dasharray="3,3" />
                <text x="8" y="53" fill="#64748b" font-size="8" font-family="monospace">0 dB</text>

                <!-- -180 deg Line -->
                <line x1="30" y1="135" x2="290" y2="135" stroke="#ef4444" stroke-width="1" stroke-dasharray="3,3" />
                <text x="2" y="138" fill="#ef4444" font-size="8" font-family="monospace">-180°</text>

                <!-- Magnitude Curve (Blue) -->
                <path [attr.d]="bodeMagPath" fill="none" stroke="#38bdf8" stroke-width="2" />

                <!-- Phase Curve (Orange) -->
                <path [attr.d]="bodePhasePath" fill="none" stroke="#f59e0b" stroke-width="1.8" />

                <!-- Axes and Labels -->
                <line x1="30" y1="10" x2="30" y2="160" stroke="#334155" stroke-width="1" />
                <line x1="30" y1="160" x2="290" y2="160" stroke="#334155" stroke-width="1" />

                <text x="40" y="20" fill="#38bdf8" font-size="8" font-family="monospace">■ Magnitude (dB)</text>
                <text x="130" y="20" fill="#f59e0b" font-size="8" font-family="monospace">■ Phase (deg)</text>
                <text x="230" y="155" fill="#64748b" font-size="8" font-family="monospace">ω (rad/s)</text>
              </svg>
            </div>

            <div class="mt-3 flex justify-between text-xs text-slate-400">
              <div>Phase Margin: <span class="text-cyan-300 font-bold">{{ metrics.phaseMarginDeg }}°</span></div>
              <div>Gain Margin: <span class="text-slate-200 font-bold">{{ metrics.gainMarginDb }} dB</span></div>
            </div>
          </div>

          <div class="mt-3 text-[10px] text-slate-500 pt-2 border-t border-slate-800">
            Gain crossover: {{ metrics.gainCrossoverFreqRadS }} rad/s · Phase crossover: {{ metrics.phaseCrossoverFreqRadS }} rad/s
          </div>
        </div>
      </div>
    </div>
  `,
})
export class StabilityPanelComponent implements OnInit, OnChanges {
  @Input() kp = 2.5;
  @Input() kd = 4.2;
  @Input() ki = 0.08;
  @Input() inertia = 48.5;

  Math = Math;
  metrics!: StabilityMetrics;
  bodePoints: BodePoint[] = [];
  bodeMagPath = '';
  bodePhasePath = '';

  ngOnInit() {
    this.recompute();
  }

  ngOnChanges() {
    this.recompute();
  }

  recompute() {
    this.metrics = StabilityAnalysis.analyze(this.kp, this.kd, this.ki, this.inertia);
    this.bodePoints = StabilityAnalysis.generateBodeData(this.kp, this.kd, this.ki, this.inertia, 50);

    // Build SVG paths for Bode plot
    // Width: 30 to 290 (260 px range for 4 decades: 10^-2 to 10^2)
    // Mag height: 10 to 90 (0 dB at y=50)
    // Phase height: 95 to 160 (-180 deg at y=135)
    let magD = '';
    let phaseD = '';

    this.bodePoints.forEach((pt, idx) => {
      const dec = Math.log10(pt.freqRadS); // -2 to 2
      const x = 30 + ((dec + 2) / 4) * 260;

      // Mag: +60 dB -> y=15, 0 dB -> y=50, -60 dB -> y=85
      const yMag = 50 - (pt.magDb / 60) * 35;
      // Phase: 0 deg -> y=100, -180 deg -> y=135, -270 deg -> y=155
      const yPhase = 100 + (Math.abs(pt.phaseDeg) / 180) * 35;

      if (idx === 0) {
        magD += `M ${x.toFixed(1)} ${yMag.toFixed(1)}`;
        phaseD += `M ${x.toFixed(1)} ${yPhase.toFixed(1)}`;
      } else {
        magD += ` L ${x.toFixed(1)} ${yMag.toFixed(1)}`;
        phaseD += ` L ${x.toFixed(1)} ${yPhase.toFixed(1)}`;
      }
    });

    this.bodeMagPath = magD;
    this.bodePhasePath = phaseD;
  }
}
