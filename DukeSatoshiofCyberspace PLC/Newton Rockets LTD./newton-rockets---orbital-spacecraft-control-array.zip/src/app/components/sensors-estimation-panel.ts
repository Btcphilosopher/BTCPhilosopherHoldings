import { ChangeDetectionStrategy, Component, Input } from '@angular/core';
import { MatIconModule } from '@angular/material/icon';
import { TelemetryPoint } from '../core/spacecraft-types';

@Component({
  selector: 'app-sensors-estimation-panel',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [MatIconModule],
  template: `
    <div class="space-y-4 font-mono">
      <!-- Top Section: TRUE STATE vs ESTIMATED STATE vs COVARIANCE (Section 8 Requirement) -->
      <div class="bg-slate-900/90 border border-slate-800 rounded-xl p-4">
        <div class="flex flex-wrap items-center justify-between gap-2 mb-3 pb-2 border-b border-slate-800">
          <div>
            <span class="text-xs text-slate-200 font-semibold tracking-wider uppercase">
              STATE ESTIMATION: MULTIPLICATIVE EXTENDED KALMAN FILTER (MEKF)
            </span>
            <p class="text-[11px] text-slate-400">
              Consumes simulated noisy sensor measurements to estimate attitude quaternion and gyro bias
            </p>
          </div>
          <div class="flex items-center gap-3 text-xs">
            <span class="flex items-center gap-1.5">
              <span 
                [class]="telemetry?.estimator?.converged ? 'bg-emerald-400' : 'bg-amber-400'"
                class="w-2 h-2 rounded-full"
              ></span>
              <span class="text-slate-300">
                {{ telemetry?.estimator?.converged ? 'FILTER CONVERGED' : 'ACQUIRING' }}
              </span>
            </span>
            <span class="text-slate-600">|</span>
            <span class="text-slate-400">
              INNOVATION: <span class="text-cyan-400 font-bold tabular-nums">{{ formatNum(telemetry?.estimator?.innovationResidual, 5) }}</span>
            </span>
          </div>
        </div>

        <!-- 4-Column Core State Comparison Grid -->
        <div class="grid grid-cols-1 md:grid-cols-4 gap-3 text-xs">
          <!-- Column 1: True State -->
          <div class="bg-slate-950/70 p-3 rounded-lg border border-slate-800">
            <div class="text-[10px] text-slate-500 uppercase tracking-wider mb-2 flex items-center justify-between">
              <span>1. TRUE STATE (PHYSICAL)</span>
              <span class="text-slate-400">GROUND TRUTH</span>
            </div>
            <div class="space-y-1 text-[11px]">
              <div class="text-slate-400">Euler (deg):</div>
              <div class="text-slate-200 font-semibold tabular-nums">
                R: {{ formatNum(telemetry?.trueEulerDeg?.roll, 2) }}°
              </div>
              <div class="text-slate-200 font-semibold tabular-nums">
                P: {{ formatNum(telemetry?.trueEulerDeg?.pitch, 2) }}°
              </div>
              <div class="text-slate-200 font-semibold tabular-nums">
                Y: {{ formatNum(telemetry?.trueEulerDeg?.yaw, 2) }}°
              </div>

              <div class="pt-2 text-slate-400">Rates (deg/s):</div>
              <div class="text-slate-300 tabular-nums">
                [{{ formatDegS(telemetry?.trueAngularVelocityRadS?.[0]) }}, 
                 {{ formatDegS(telemetry?.trueAngularVelocityRadS?.[1]) }}, 
                 {{ formatDegS(telemetry?.trueAngularVelocityRadS?.[2]) }}]
              </div>
            </div>
          </div>

          <!-- Column 2: Estimated State -->
          <div class="bg-slate-950/70 p-3 rounded-lg border border-slate-800">
            <div class="text-[10px] text-cyan-400 uppercase tracking-wider mb-2 flex items-center justify-between">
              <span>2. ESTIMATED STATE (FILTER)</span>
              <span class="text-cyan-500 font-bold">EKF q_hat</span>
            </div>
            <div class="space-y-1 text-[11px]">
              <div class="text-slate-400">Euler Est (deg):</div>
              <div class="text-cyan-300 font-semibold tabular-nums">
                R: {{ formatNum(getEstimatedEuler()?.roll, 2) }}°
              </div>
              <div class="text-cyan-300 font-semibold tabular-nums">
                P: {{ formatNum(getEstimatedEuler()?.pitch, 2) }}°
              </div>
              <div class="text-cyan-300 font-semibold tabular-nums">
                Y: {{ formatNum(getEstimatedEuler()?.yaw, 2) }}°
              </div>

              <div class="pt-2 text-slate-400">Rates Est (deg/s):</div>
              <div class="text-cyan-400 tabular-nums">
                [{{ formatDegS(telemetry?.estimator?.estimatedAngularVelocity?.[0]) }}, 
                 {{ formatDegS(telemetry?.estimator?.estimatedAngularVelocity?.[1]) }}, 
                 {{ formatDegS(telemetry?.estimator?.estimatedAngularVelocity?.[2]) }}]
              </div>
            </div>
          </div>

          <!-- Column 3: Estimation Error -->
          <div class="bg-slate-950/70 p-3 rounded-lg border border-slate-800">
            <div class="text-[10px] text-amber-400 uppercase tracking-wider mb-2 flex items-center justify-between">
              <span>3. ERROR (TRUE - EST)</span>
              <span class="text-amber-500">RESIDUAL</span>
            </div>
            <div class="space-y-1 text-[11px]">
              <div class="text-slate-400">Attitude Error (arcsec):</div>
              <div class="text-amber-300 font-semibold tabular-nums">
                dX: {{ formatArcsec(telemetry?.estimator?.attitudeErrorDeg?.[0]) }}"
              </div>
              <div class="text-amber-300 font-semibold tabular-nums">
                dY: {{ formatArcsec(telemetry?.estimator?.attitudeErrorDeg?.[1]) }}"
              </div>
              <div class="text-amber-300 font-semibold tabular-nums">
                dZ: {{ formatArcsec(telemetry?.estimator?.attitudeErrorDeg?.[2]) }}"
              </div>

              <div class="pt-2 text-slate-400">Gyro Bias Est (rad/s):</div>
              <div class="text-slate-300 tabular-nums">
                bx: {{ formatSci(telemetry?.estimator?.gyroBiasEstimate?.[0]) }}
              </div>
              <div class="text-slate-300 tabular-nums">
                by: {{ formatSci(telemetry?.estimator?.gyroBiasEstimate?.[1]) }}
              </div>
              <div class="text-slate-300 tabular-nums">
                bz: {{ formatSci(telemetry?.estimator?.gyroBiasEstimate?.[2]) }}
              </div>
            </div>
          </div>

          <!-- Column 4: 3-Sigma Covariance Bounds -->
          <div class="bg-slate-950/70 p-3 rounded-lg border border-slate-800">
            <div class="text-[10px] text-emerald-400 uppercase tracking-wider mb-2 flex items-center justify-between">
              <span>4. 3-SIGMA UNCERTAINTY</span>
              <span class="text-emerald-500 font-bold">COVARIANCE P</span>
            </div>
            <div class="space-y-1 text-[11px]">
              <div class="text-slate-400">3-Sigma Bounds (deg):</div>
              <div class="text-emerald-300 font-semibold tabular-nums">
                ±3σ_x: {{ formatNum(telemetry?.estimator?.sigma3Bounds?.[0], 4) }}°
              </div>
              <div class="text-emerald-300 font-semibold tabular-nums">
                ±3σ_y: {{ formatNum(telemetry?.estimator?.sigma3Bounds?.[1], 4) }}°
              </div>
              <div class="text-emerald-300 font-semibold tabular-nums">
                ±3σ_z: {{ formatNum(telemetry?.estimator?.sigma3Bounds?.[2], 4) }}°
              </div>

              <div class="pt-2 text-slate-400">Covariance Diag:</div>
              <div class="text-slate-400 text-[10px] tabular-nums">
                P_theta: {{ formatSci(telemetry?.estimator?.covarianceDiagonal?.[0]) }}
              </div>
              <div class="text-slate-400 text-[10px] tabular-nums">
                P_bias:  {{ formatSci(telemetry?.estimator?.covarianceDiagonal?.[3]) }}
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- Sensor Suite Detailed Table: Truth vs Measured vs Error vs Uncertainty -->
      <div class="bg-slate-900/90 border border-slate-800 rounded-xl p-4">
        <div class="flex items-center justify-between mb-3">
          <div>
            <h3 class="text-xs text-slate-200 font-semibold tracking-wider uppercase">
              SENSOR ARRAY TELEMETRY & MEASUREMENT ACCURACY
            </h3>
            <p class="text-[11px] text-slate-400">
              Direct telemetry from on-board sensors, comparing truth, noisy measurement, and calibrated error
            </p>
          </div>
          <span class="text-[11px] text-slate-500">SAMPLING: 20 Hz SYNCHRONIZED</span>
        </div>

        <div class="overflow-x-auto">
          <table class="w-full text-left text-xs border-collapse">
            <thead>
              <tr class="border-b border-slate-800 text-[11px] text-slate-500 uppercase">
                <th class="py-2.5 px-3">Instrument</th>
                <th class="py-2.5 px-3">Truth Value</th>
                <th class="py-2.5 px-3">Measured Telemetry</th>
                <th class="py-2.5 px-3">Measurement Error</th>
                <th class="py-2.5 px-3">3-Sigma Spec</th>
                <th class="py-2.5 px-3 text-right">Status</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-slate-800/60 text-slate-300">
              <!-- Gyroscope -->
              <tr>
                <td class="py-3 px-3">
                  <div class="font-semibold text-slate-200">Fiber-Optic Gyroscope</div>
                  <div class="text-[10px] text-slate-500">3-Axis Angular Rate [wx, wy, wz] rad/s</div>
                </td>
                <td class="py-3 px-3 tabular-nums">
                  {{ formatVector(telemetry?.sensors?.gyro?.truth) }}
                </td>
                <td class="py-3 px-3 tabular-nums text-cyan-300">
                  {{ formatVector(telemetry?.sensors?.gyro?.measured) }}
                </td>
                <td class="py-3 px-3 tabular-nums text-amber-300">
                  {{ formatVector(telemetry?.sensors?.gyro?.error) }}
                </td>
                <td class="py-3 px-3 tabular-nums text-emerald-400">
                  ±{{ (telemetry?.sensors?.gyro?.uncertainty3Sigma ?? 0.0006).toFixed(5) }} rad/s
                </td>
                <td class="py-3 px-3 text-right">
                  <span class="text-[11px] font-semibold text-emerald-400">● NOMINAL</span>
                </td>
              </tr>

              <!-- Star Tracker -->
              <tr>
                <td class="py-3 px-3">
                  <div class="font-semibold text-slate-200">Autonomous Star Tracker</div>
                  <div class="text-[10px] text-slate-500">Inertial Quaternion [q0, q1, q2, q3]</div>
                </td>
                <td class="py-3 px-3 tabular-nums text-[11px]">
                  q: [{{ (telemetry?.sensors?.starTracker?.truth?.[0] ?? 1).toFixed(4) }}, {{ (telemetry?.sensors?.starTracker?.truth?.[1] ?? 0).toFixed(4) }}...]
                </td>
                <td class="py-3 px-3 tabular-nums text-cyan-300 text-[11px]">
                  q: [{{ (telemetry?.sensors?.starTracker?.measured?.[0] ?? 1).toFixed(4) }}, {{ (telemetry?.sensors?.starTracker?.measured?.[1] ?? 0).toFixed(4) }}...]
                </td>
                <td class="py-3 px-3 tabular-nums text-amber-300">
                  {{ getStarTrackerErrorDeg() }}°
                </td>
                <td class="py-3 px-3 tabular-nums text-emerald-400">
                  ±30 arcsec (1.5e-4 rad)
                </td>
                <td class="py-3 px-3 text-right">
                  @if (telemetry?.sensors?.starTracker?.healthy) {
                    <span class="text-[11px] font-semibold text-emerald-400">● TRACKING</span>
                  } @else {
                    <span class="text-[11px] font-semibold text-rose-400 animate-pulse">✖ BLINDED / OCCLUDED</span>
                  }
                </td>
              </tr>

              <!-- Fine Sun Sensor -->
              <tr>
                <td class="py-3 px-3">
                  <div class="font-semibold text-slate-200">Fine Sun Sensor</div>
                  <div class="text-[10px] text-slate-500">Unit Vector in Body Frame</div>
                </td>
                <td class="py-3 px-3 tabular-nums">
                  {{ formatVector(telemetry?.sensors?.sunSensor?.truth) }}
                </td>
                <td class="py-3 px-3 tabular-nums text-cyan-300">
                  {{ formatVector(telemetry?.sensors?.sunSensor?.measured) }}
                </td>
                <td class="py-3 px-3 tabular-nums text-amber-300">
                  {{ formatVector(telemetry?.sensors?.sunSensor?.error) }}
                </td>
                <td class="py-3 px-3 tabular-nums text-emerald-400">
                  ±0.006 rad (0.35°)
                </td>
                <td class="py-3 px-3 text-right">
                  @if (telemetry?.sensors?.sunSensor?.healthy) {
                    <span class="text-[11px] font-semibold text-emerald-400">● SUN ACQUIRED</span>
                  } @else {
                    <span class="text-[11px] font-semibold text-slate-500">ECLIPSE / OFF-AXIS</span>
                  }
                </td>
              </tr>

              <!-- 3-Axis Magnetometer -->
              <tr>
                <td class="py-3 px-3">
                  <div class="font-semibold text-slate-200">Fluxgate Magnetometer</div>
                  <div class="text-[10px] text-slate-500">Geomagnetic Induction [Bx, By, Bz] µT</div>
                </td>
                <td class="py-3 px-3 tabular-nums">
                  {{ formatVector(telemetry?.sensors?.magnetometer?.truth, 1) }}
                </td>
                <td class="py-3 px-3 tabular-nums text-cyan-300">
                  {{ formatVector(telemetry?.sensors?.magnetometer?.measured, 1) }}
                </td>
                <td class="py-3 px-3 tabular-nums text-amber-300">
                  {{ formatVector(telemetry?.sensors?.magnetometer?.error, 1) }}
                </td>
                <td class="py-3 px-3 tabular-nums text-emerald-400">
                  ±1.50 µT
                </td>
                <td class="py-3 px-3 text-right">
                  <span class="text-[11px] font-semibold text-emerald-400">● NOMINAL</span>
                </td>
              </tr>

              <!-- 3-Axis Accelerometer -->
              <tr>
                <td class="py-3 px-3">
                  <div class="font-semibold text-slate-200">Specific Force Accelerometer</div>
                  <div class="text-[10px] text-slate-500">Body Specific Force [ax, ay, az] m/s²</div>
                </td>
                <td class="py-3 px-3 tabular-nums">
                  {{ formatVector(telemetry?.sensors?.accelerometer?.truth, 4) }}
                </td>
                <td class="py-3 px-3 tabular-nums text-cyan-300">
                  {{ formatVector(telemetry?.sensors?.accelerometer?.measured, 4) }}
                </td>
                <td class="py-3 px-3 tabular-nums text-amber-300">
                  {{ formatVector(telemetry?.sensors?.accelerometer?.error, 4) }}
                </td>
                <td class="py-3 px-3 tabular-nums text-emerald-400">
                  ±0.015 m/s²
                </td>
                <td class="py-3 px-3 text-right">
                  <span class="text-[11px] font-semibold text-emerald-400">● NOMINAL</span>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  `,
})
export class SensorsEstimationPanelComponent {
  @Input() telemetry: TelemetryPoint | null = null;

  formatNum(val?: number, decimals = 3): string {
    if (val === undefined || isNaN(val)) return '0.000';
    return val.toFixed(decimals);
  }

  formatDegS(val?: number): string {
    if (val === undefined) return '0.000';
    return ((val * 180) / Math.PI).toFixed(3);
  }

  formatArcsec(deg?: number): string {
    if (deg === undefined) return '0.0';
    return (deg * 3600).toFixed(1);
  }

  formatSci(val?: number): string {
    if (val === undefined) return '0.0e0';
    return val.toExponential(2);
  }

  formatVector(vec?: [number, number, number] | null, decimals = 3): string {
    if (!vec) return '[0.000, 0.000, 0.000]';
    return `[${vec[0].toFixed(decimals)}, ${vec[1].toFixed(decimals)}, ${vec[2].toFixed(decimals)}]`;
  }

  getEstimatedEuler() {
    if (!this.telemetry?.estimator?.estimatedAttitude) return null;
    const q = this.telemetry.estimator.estimatedAttitude;
    const sinr_cosp = 2 * (q.q0 * q.q1 + q.q2 * q.q3);
    const cosr_cosp = 1 - 2 * (q.q1 * q.q1 + q.q2 * q.q2);
    const roll = (Math.atan2(sinr_cosp, cosr_cosp) * 180) / Math.PI;

    const sinp = 2 * (q.q0 * q.q2 - q.q3 * q.q1);
    const pitch = (Math.asin(Math.max(-1, Math.min(1, sinp))) * 180) / Math.PI;

    const siny_cosp = 2 * (q.q0 * q.q3 + q.q1 * q.q2);
    const cosy_cosp = 1 - 2 * (q.q2 * q.q2 + q.q3 * q.q3);
    const yaw = (Math.atan2(siny_cosp, cosy_cosp) * 180) / Math.PI;

    return { roll, pitch, yaw };
  }

  getStarTrackerErrorDeg(): string {
    if (!this.telemetry?.sensors?.starTracker?.error) return '0.000';
    const err = this.telemetry.sensors.starTracker.error;
    const mag = Math.sqrt(err[1] * err[1] + err[2] * err[2] + err[3] * err[3]);
    return ((mag * 2 * 180) / Math.PI).toFixed(4);
  }
}
