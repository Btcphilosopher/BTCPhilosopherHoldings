import {
  ChangeDetectionStrategy,
  Component,
  ElementRef,
  Input,
  OnDestroy,
  PLATFORM_ID,
  ViewChild,
  afterNextRender,
  inject,
} from '@angular/core';
import { isPlatformBrowser } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import * as THREE from 'three';
import { TelemetryPoint } from '../core/spacecraft-types';

@Component({
  selector: 'app-digital-twin',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [MatIconModule],
  template: `
    <div class="relative w-full h-full min-h-[460px] bg-[#07090e] rounded-xl overflow-hidden border border-slate-800/80 flex flex-col">
      <!-- 3D Canvas Container -->
      <div #canvasContainer class="relative flex-1 w-full h-full cursor-grab active:cursor-grabbing"></div>

      <!-- Top Overlay Telemetry HUD -->
      <div class="absolute top-3 left-3 right-3 flex items-start justify-between pointer-events-none gap-2">
        <!-- Spacecraft Designation & Attitude Mode -->
        <div class="bg-slate-900/90 backdrop-blur-md border border-slate-700/60 rounded-lg p-2.5 shadow-lg pointer-events-auto flex flex-col gap-1">
          <div class="flex items-center gap-2">
            <span class="inline-block w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
            <span class="text-xs font-semibold tracking-wider text-slate-200">NEWTON SOLAR PROBE</span>
            <span class="text-[10px] font-mono text-slate-400">· DIGITAL TWIN</span>
          </div>
          <div class="flex items-center gap-2 text-[11px] font-mono text-slate-300">
            <span class="text-slate-400">GUIDANCE:</span>
            <span class="text-cyan-400 uppercase font-semibold">
              {{ telemetry?.modelFidelity ? telemetry?.modelFidelity : 'ACTIVE' }}
            </span>
            <span class="text-slate-600">/</span>
            <span class="text-amber-400 font-mono">ERR: {{ telemetry?.pointingErrorDeg?.toFixed(3) ?? '0.000' }}°</span>
          </div>
        </div>

        <!-- 3D Viewport Controls -->
        <div class="bg-slate-900/90 backdrop-blur-md border border-slate-700/60 rounded-lg p-1.5 shadow-lg pointer-events-auto flex items-center gap-1 text-slate-300">
          <button
            (click)="toggleAxes()"
            [class]="showAxes ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40' : 'text-slate-400 hover:text-slate-200'"
            class="px-2 py-1 text-xs font-mono rounded transition-colors flex items-center gap-1"
            title="Toggle Body & LVLH Coordinate Frames"
          >
            <mat-icon class="!text-sm !w-3.5 !h-3.5 leading-none">open_with</mat-icon>
            <span>AXES</span>
          </button>

          <button
            (click)="toggleFov()"
            [class]="showFov ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40' : 'text-slate-400 hover:text-slate-200'"
            class="px-2 py-1 text-xs font-mono rounded transition-colors flex items-center gap-1"
            title="Toggle Star Tracker FOV Cone"
          >
            <mat-icon class="!text-sm !w-3.5 !h-3.5 leading-none">visibility</mat-icon>
            <span>FOV</span>
          </button>

          <button
            (click)="resetCamera()"
            class="px-2 py-1 text-xs font-mono rounded text-slate-400 hover:text-slate-200 transition-colors flex items-center gap-1"
            title="Reset 3D Camera"
          >
            <mat-icon class="!text-sm !w-3.5 !h-3.5 leading-none">center_focus_strong</mat-icon>
            <span>RESET</span>
          </button>
        </div>
      </div>

      <!-- Bottom Telemetry HUD Overlay -->
      <div class="absolute bottom-3 left-3 right-3 flex items-end justify-between pointer-events-none gap-2">
        <!-- Live Attitude & Rates -->
        <div class="bg-slate-900/90 backdrop-blur-md border border-slate-700/60 rounded-lg p-2.5 shadow-lg pointer-events-auto flex gap-4 text-xs font-mono">
          <div>
            <div class="text-[10px] text-slate-400 uppercase tracking-wider mb-0.5">True Euler (R/P/Y)</div>
            <div class="text-slate-100 tabular-nums">
              {{ telemetry?.trueEulerDeg?.roll?.toFixed(1) ?? '0.0' }}° /
              {{ telemetry?.trueEulerDeg?.pitch?.toFixed(1) ?? '0.0' }}° /
              {{ telemetry?.trueEulerDeg?.yaw?.toFixed(1) ?? '0.0' }}°
            </div>
          </div>
          <div class="border-l border-slate-800 pl-4">
            <div class="text-[10px] text-slate-400 uppercase tracking-wider mb-0.5">Angular Rate |w|</div>
            <div class="text-cyan-300 tabular-nums">
              {{ getAngularRateMagnitude() }} deg/s
            </div>
          </div>
          <div class="border-l border-slate-800 pl-4">
            <div class="text-[10px] text-slate-400 uppercase tracking-wider mb-0.5">Reaction Wheels</div>
            <div class="text-emerald-400 tabular-nums">
              {{ telemetry?.actuators?.totalWheelMomentumNms?.toFixed(2) ?? '0.00' }} N·m·s
            </div>
          </div>
        </div>

        <!-- Reference Orientation Badge -->
        <div class="bg-slate-900/90 backdrop-blur-md border border-slate-700/60 rounded-lg px-3 py-2 shadow-lg pointer-events-auto flex items-center gap-2 text-xs font-mono text-slate-400">
          <span class="w-2 h-2 rounded-full bg-blue-500"></span>
          <span>+Z: NADIR/SUN</span>
          <span class="text-slate-600">·</span>
          <span class="w-2 h-2 rounded-full bg-red-500"></span>
          <span>+X: RAM/VEL</span>
        </div>
      </div>
    </div>
  `,
})
export class DigitalTwinComponent implements OnDestroy {
  @ViewChild('canvasContainer', { static: false }) canvasContainerRef!: ElementRef<HTMLDivElement>;

  private platformId = inject(PLATFORM_ID);
  private _telemetry: TelemetryPoint | null = null;
  @Input()
  set telemetry(val: TelemetryPoint | null) {
    this._telemetry = val;
    if (val) {
      this.updateSpacecraftPose(val);
    }
  }
  get telemetry(): TelemetryPoint | null {
    return this._telemetry;
  }

  showAxes = true;
  showFov = true;

  private scene!: THREE.Scene;
  private camera!: THREE.PerspectiveCamera;
  private renderer!: THREE.WebGLRenderer;
  private animationFrameId = 0;

  private spacecraftRoot!: THREE.Group;
  private wheelMeshes: THREE.Mesh[] = [];
  private axesHelper!: THREE.Group;
  private starTrackerCone!: THREE.Mesh;
  private thrusterPlume!: THREE.Mesh;
  private earthMesh!: THREE.Mesh;

  // Interaction controls
  private isDragging = false;
  private prevMouseX = 0;
  private prevMouseY = 0;
  private sphericalCoords = { radius: 7.5, theta: Math.PI / 4, phi: Math.PI / 3 };

  constructor() {
    afterNextRender(() => {
      this.initThree();
    });
  }

  ngOnDestroy() {
    if (isPlatformBrowser(this.platformId)) {
      if (this.animationFrameId) {
        cancelAnimationFrame(this.animationFrameId);
      }
      if (this.renderer) {
        this.renderer.dispose();
      }
    }
  }

  getAngularRateMagnitude(): string {
    if (!this.telemetry) return '0.00';
    const w = this.telemetry.trueAngularVelocityRadS;
    const magRad = Math.sqrt(w[0] * w[0] + w[1] * w[1] + w[2] * w[2]);
    return ((magRad * 180) / Math.PI).toFixed(3);
  }

  toggleAxes() {
    this.showAxes = !this.showAxes;
    if (this.axesHelper) {
      this.axesHelper.visible = this.showAxes;
    }
  }

  toggleFov() {
    this.showFov = !this.showFov;
    if (this.starTrackerCone) {
      this.starTrackerCone.visible = this.showFov;
    }
  }

  resetCamera() {
    this.sphericalCoords = { radius: 7.5, theta: Math.PI / 4, phi: Math.PI / 3 };
    this.updateCameraPosition();
  }

  private initThree() {
    if (!this.canvasContainerRef) return;
    const container = this.canvasContainerRef.nativeElement;
    const width = container.clientWidth || 800;
    const height = container.clientHeight || 500;

    // 1. Scene
    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(0x07090e);

    // Starfield points
    const starGeometry = new THREE.BufferGeometry();
    const starCount = 800;
    const starPositions = new Float32Array(starCount * 3);
    for (let i = 0; i < starCount * 3; i += 3) {
      starPositions[i] = (Math.random() - 0.5) * 200;
      starPositions[i + 1] = (Math.random() - 0.5) * 200;
      starPositions[i + 2] = (Math.random() - 0.5) * 200;
    }
    starGeometry.setAttribute('position', new THREE.BufferAttribute(starPositions, 3));
    const starMaterial = new THREE.PointsMaterial({ color: 0x94a3b8, size: 0.8, sizeAttenuation: true });
    const starField = new THREE.Points(starGeometry, starMaterial);
    this.scene.add(starField);

    // 2. Camera
    this.camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 1000);
    this.updateCameraPosition();

    // 3. Renderer
    this.renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    this.renderer.setSize(width, height);
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    container.appendChild(this.renderer.domElement);

    // 4. Lighting
    const ambientLight = new THREE.AmbientLight(0x334155, 1.2);
    this.scene.add(ambientLight);

    // Directional Sun Light
    const sunLight = new THREE.DirectionalLight(0xfffbeb, 2.5);
    sunLight.position.set(30, 15, 20);
    this.scene.add(sunLight);

    // Earth fill light
    const earthGlowLight = new THREE.DirectionalLight(0x38bdf8, 0.8);
    earthGlowLight.position.set(-15, -20, -10);
    this.scene.add(earthGlowLight);

    // 5. Spacecraft Model Hierarchy
    this.buildSpacecraft();

    // 6. Earth Sphere in background
    const earthGeo = new THREE.SphereGeometry(18, 32, 32);
    const earthMat = new THREE.MeshStandardMaterial({
      color: 0x0f3460,
      roughness: 0.8,
      metalness: 0.1,
      wireframe: false,
    });
    this.earthMesh = new THREE.Mesh(earthGeo, earthMat);
    this.earthMesh.position.set(-25, -28, -20);
    this.scene.add(this.earthMesh);

    // Orbit ellipse ring representation
    const orbitCurve = new THREE.EllipseCurve(0, 0, 8, 8, 0, 2 * Math.PI, false, 0);
    const orbitPoints = orbitCurve.getPoints(64);
    const orbitGeometry = new THREE.BufferGeometry().setFromPoints(
      orbitPoints.map((p) => new THREE.Vector3(p.x, 0, p.y))
    );
    const orbitMat = new THREE.LineBasicMaterial({ color: 0x1e293b, linewidth: 1 });
    const orbitLine = new THREE.Line(orbitGeometry, orbitMat);
    orbitLine.position.copy(this.earthMesh.position);
    this.scene.add(orbitLine);

    // Event Listeners for Orbit Rotation
    container.addEventListener('mousedown', this.onMouseDown.bind(this));
    window.addEventListener('mousemove', this.onMouseMove.bind(this));
    window.addEventListener('mouseup', this.onMouseUp.bind(this));
    container.addEventListener('wheel', this.onWheel.bind(this));
    window.addEventListener('resize', this.onResize.bind(this));

    // Animation Loop
    this.animate();
  }

  private buildSpacecraft() {
    this.spacecraftRoot = new THREE.Group();

    // Central Bus: Carbon/Gold faceted chassis
    const busGeo = new THREE.BoxGeometry(1.6, 1.4, 2.2);
    const busMat = new THREE.MeshStandardMaterial({
      color: 0xd97706, // Gold thermal Kapton blanket
      metalness: 0.85,
      roughness: 0.25,
    });
    const busMesh = new THREE.Mesh(busGeo, busMat);
    this.spacecraftRoot.add(busMesh);

    // Upper Electronics & Sensor Deck (Graphite panel)
    const topDeckGeo = new THREE.BoxGeometry(1.5, 0.1, 2.1);
    const topDeckMat = new THREE.MeshStandardMaterial({
      color: 0x1e293b,
      metalness: 0.6,
      roughness: 0.4,
    });
    const topDeck = new THREE.Mesh(topDeckGeo, topDeckMat);
    topDeck.position.set(0, 0.75, 0);
    this.spacecraftRoot.add(topDeck);

    // Dual Solar Array Panels
    const wingGeo = new THREE.BoxGeometry(3.2, 0.04, 1.2);
    const wingMat = new THREE.MeshStandardMaterial({
      color: 0x1d4ed8, // Deep silicon blue
      metalness: 0.7,
      roughness: 0.2,
    });

    // Left solar panel (+X side)
    const leftWing = new THREE.Mesh(wingGeo, wingMat);
    leftWing.position.set(2.5, 0, 0);
    this.spacecraftRoot.add(leftWing);

    // Right solar panel (-X side)
    const rightWing = new THREE.Mesh(wingGeo, wingMat);
    rightWing.position.set(-2.5, 0, 0);
    this.spacecraftRoot.add(rightWing);

    // Solar panel yokes
    const yokeGeo = new THREE.CylinderGeometry(0.06, 0.06, 0.9, 12);
    const yokeMat = new THREE.MeshStandardMaterial({ color: 0x64748b, metalness: 0.8 });
    const leftYoke = new THREE.Mesh(yokeGeo, yokeMat);
    leftYoke.rotation.z = Math.PI / 2;
    leftYoke.position.set(1.1, 0, 0);
    this.spacecraftRoot.add(leftYoke);

    const rightYoke = new THREE.Mesh(yokeGeo, yokeMat);
    rightYoke.rotation.z = Math.PI / 2;
    rightYoke.position.set(-1.1, 0, 0);
    this.spacecraftRoot.add(rightYoke);

    // High-Gain Antenna Dish (+Z pointing)
    const dishGeo = new THREE.CylinderGeometry(0.65, 0.1, 0.25, 24, 1, true);
    const dishMat = new THREE.MeshStandardMaterial({
      color: 0xf8fafc,
      side: THREE.DoubleSide,
      roughness: 0.3,
      metalness: 0.2,
    });
    const dish = new THREE.Mesh(dishGeo, dishMat);
    dish.position.set(0, 0.85, 0.8);
    dish.rotation.x = -Math.PI / 4;
    this.spacecraftRoot.add(dish);

    // Star Tracker Optical Hood & FOV Cone (+Z / +Y slant)
    const stHoodGeo = new THREE.CylinderGeometry(0.12, 0.14, 0.35, 16);
    const stHoodMat = new THREE.MeshStandardMaterial({ color: 0x0f172a, roughness: 0.9 });
    const stHood = new THREE.Mesh(stHoodGeo, stHoodMat);
    stHood.position.set(0.5, 0.85, -0.6);
    this.spacecraftRoot.add(stHood);

    // Transparent Cyan FOV Cone
    const fovConeGeo = new THREE.ConeGeometry(0.7, 2.5, 24, 1, true);
    const fovConeMat = new THREE.MeshBasicMaterial({
      color: 0x06b6d4,
      transparent: true,
      opacity: 0.2,
      side: THREE.DoubleSide,
    });
    this.starTrackerCone = new THREE.Mesh(fovConeGeo, fovConeMat);
    this.starTrackerCone.position.set(0.5, 2.1, -0.6);
    this.starTrackerCone.rotation.x = Math.PI;
    this.spacecraftRoot.add(this.starTrackerCone);

    // 4 Reaction Wheels in Tetrahedral Mounting
    const wheelGeo = new THREE.CylinderGeometry(0.22, 0.22, 0.08, 16);
    const wheelMat = new THREE.MeshStandardMaterial({
      color: 0x94a3b8,
      metalness: 0.9,
      roughness: 0.2,
    });

    const beta = (54.74 * Math.PI) / 180;
    const phi = [Math.PI / 4, (3 * Math.PI) / 4, (5 * Math.PI) / 4, (7 * Math.PI) / 4];
    this.wheelMeshes = [];

    for (let i = 0; i < 4; i++) {
      const wheel = new THREE.Mesh(wheelGeo, wheelMat);
      const dist = 0.55;
      wheel.position.set(
        dist * Math.cos(phi[i]),
        -0.45,
        dist * Math.sin(phi[i])
      );
      // Tilted axis orientation
      wheel.rotation.x = Math.sin(phi[i]) * beta;
      wheel.rotation.z = -Math.cos(phi[i]) * beta;
      this.wheelMeshes.push(wheel);
      this.spacecraftRoot.add(wheel);
    }

    // Thruster Plume Effect at base (-Z or -Y)
    const plumeGeo = new THREE.ConeGeometry(0.3, 1.2, 16);
    const plumeMat = new THREE.MeshBasicMaterial({
      color: 0x38bdf8,
      transparent: true,
      opacity: 0.7,
    });
    this.thrusterPlume = new THREE.Mesh(plumeGeo, plumeMat);
    this.thrusterPlume.position.set(0, 0, -1.7);
    this.thrusterPlume.rotation.x = -Math.PI / 2;
    this.thrusterPlume.visible = false;
    this.spacecraftRoot.add(this.thrusterPlume);

    // Coordinate Axes Helper
    this.axesHelper = new THREE.Group();
    const axisLen = 2.4;
    // Body +X (Red)
    const xLine = new THREE.ArrowHelper(
      new THREE.Vector3(1, 0, 0),
      new THREE.Vector3(0, 0, 0),
      axisLen,
      0xef4444,
      0.3,
      0.15
    );
    // Body +Y (Green)
    const yLine = new THREE.ArrowHelper(
      new THREE.Vector3(0, 1, 0),
      new THREE.Vector3(0, 0, 0),
      axisLen,
      0x10b981,
      0.3,
      0.15
    );
    // Body +Z (Blue)
    const zLine = new THREE.ArrowHelper(
      new THREE.Vector3(0, 0, 1),
      new THREE.Vector3(0, 0, 0),
      axisLen,
      0x3b82f6,
      0.3,
      0.15
    );
    this.axesHelper.add(xLine, yLine, zLine);
    this.spacecraftRoot.add(this.axesHelper);

    this.scene.add(this.spacecraftRoot);
  }

  private updateSpacecraftPose(telem: TelemetryPoint) {
    if (!this.spacecraftRoot) return;

    // Quaternion attitude: [q0, q1, q2, q3] -> Three.js Quaternion(x, y, z, w)
    const q = telem.trueAttitude;
    this.spacecraftRoot.quaternion.set(q.q1, q.q2, q.q3, q.q0);

    // Spin reaction wheels proportional to their actual simulated RPM
    if (this.wheelMeshes.length === 4) {
      telem.actuators.wheels.forEach((w, idx) => {
        const mesh = this.wheelMeshes[idx];
        if (mesh && !w.failed) {
          mesh.rotation.y += (w.speedRpm / 60) * 0.1;
        }
      });
    }

    // Toggle thruster plume
    if (this.thrusterPlume) {
      this.thrusterPlume.visible = telem.actuators.thruster.firing;
    }
  }

  private updateCameraPosition() {
    const { radius, theta, phi } = this.sphericalCoords;
    this.camera.position.x = radius * Math.sin(phi) * Math.sin(theta);
    this.camera.position.y = radius * Math.cos(phi);
    this.camera.position.z = radius * Math.sin(phi) * Math.cos(theta);
    this.camera.lookAt(0, 0, 0);
  }

  private onMouseDown(e: MouseEvent) {
    this.isDragging = true;
    this.prevMouseX = e.clientX;
    this.prevMouseY = e.clientY;
  }

  private onMouseMove(e: MouseEvent) {
    if (!this.isDragging) return;
    const dx = e.clientX - this.prevMouseX;
    const dy = e.clientY - this.prevMouseY;

    this.sphericalCoords.theta -= dx * 0.008;
    this.sphericalCoords.phi = Math.max(0.1, Math.min(Math.PI - 0.1, this.sphericalCoords.phi - dy * 0.008));

    this.updateCameraPosition();
    this.prevMouseX = e.clientX;
    this.prevMouseY = e.clientY;
  }

  private onMouseUp() {
    this.isDragging = false;
  }

  private onWheel(e: WheelEvent) {
    e.preventDefault();
    this.sphericalCoords.radius = Math.max(3.0, Math.min(20.0, this.sphericalCoords.radius + e.deltaY * 0.008));
    this.updateCameraPosition();
  }

  private onResize() {
    if (!this.canvasContainerRef || !this.renderer || !this.camera) return;
    const container = this.canvasContainerRef.nativeElement;
    const width = container.clientWidth;
    const height = container.clientHeight;
    this.camera.aspect = width / height;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(width, height);
  }

  private animate() {
    this.animationFrameId = requestAnimationFrame(() => this.animate());

    // Slow ambient rotation of Earth mesh
    if (this.earthMesh) {
      this.earthMesh.rotation.y += 0.0005;
    }

    if (this.renderer && this.scene && this.camera) {
      this.renderer.render(this.scene, this.camera);
    }
  }
}
