import { ChangeDetectionStrategy, Component, EventEmitter, Input, Output } from '@angular/core';
import { MatIconModule } from '@angular/material/icon';
import { TelemetryPoint } from '../core/spacecraft-types';

@Component({
  selector: 'app-fault-lab-panel',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [MatIconModule],
  template: `
    <div class="space-y-4 font-mono">
      <!-- Header Banner -->
      <div class="bg-slate-900/90 border border-slate-800 rounded-xl p-4 flex flex-wrap items-center justify-between gap-3">
        <div>
          <span class="text-xs text-rose-400 font-semibold uppercase tracking-wider flex items-center gap-1.5">
            <mat-icon class="!text-sm !w-4 !h-4 leading-none">biotech</mat-icon>
            CONTROL SYSTEM FAULT INJECTION LABORATORY
          </span>
          <p class="text-[11px] text-slate-400 mt-1">
            Inject controlled sensor and actuator failures into real-time simulation and inspect the closed-loop causal chain response.
          </p>
        </div>

        <button
          (click)="clearAllFaults.emit()"
          class="px-3 py-1.5 text-xs font-semibold rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 transition-colors flex items-center gap-1"
        >
          <mat-icon class="!text-sm !w-3.5 !h-3.5 leading-none">clear_all</mat-icon>
          <span>CLEAR ALL FAULTS</span>
        </button>
      </div>

      <!-- Fault Injection Switches Grid -->
      <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
        <!-- Fault 1: Reaction Wheel 3 Locked -->
        <button
          (click)="toggleFault.emit('wheelFailed3')"
          [class]="isFaultActive('wheelFailed3') 
            ? 'bg-rose-950/40 border-rose-500/60 text-rose-300' 
            : 'bg-slate-900/80 border-slate-800 text-slate-400 hover:text-slate-200'"
          class="p-3 rounded-xl border text-xs text-left transition-colors flex flex-col justify-between gap-2"
        >
          <div>
            <div class="flex items-center justify-between mb-1">
              <span class="font-bold">RW 3 LOCKED</span>
              <span class="text-[9px] px-1 rounded bg-slate-800">{{ isFaultActive('wheelFailed3') ? 'ACTIVE' : 'OFF' }}</span>
            </div>
            <p class="text-[10px] text-slate-500">
              Bearing freeze; loss of authority on Wheel 3.
            </p>
          </div>
          <div class="text-[10px] font-semibold text-rose-400">
            Tests 3-wheel re-allocation
          </div>
        </button>

        <!-- Fault 2: Reaction Wheel 1 Saturated -->
        <button
          (click)="toggleFault.emit('wheelSaturated1')"
          [class]="isFaultActive('wheelSaturated1') 
            ? 'bg-amber-950/40 border-amber-500/60 text-amber-300' 
            : 'bg-slate-900/80 border-slate-800 text-slate-400 hover:text-slate-200'"
          class="p-3 rounded-xl border text-xs text-left transition-colors flex flex-col justify-between gap-2"
        >
          <div>
            <div class="flex items-center justify-between mb-1">
              <span class="font-bold">RW 1 SATURATION</span>
              <span class="text-[9px] px-1 rounded bg-slate-800">{{ isFaultActive('wheelSaturated1') ? 'ACTIVE' : 'OFF' }}</span>
            </div>
            <p class="text-[10px] text-slate-500">
              Wheel 1 hits 6000 RPM speed limit.
            </p>
          </div>
          <div class="text-[10px] font-semibold text-amber-400">
            Triggers torque clipping
          </div>
        </button>

        <!-- Fault 3: Star Tracker Blinded / Dropout -->
        <button
          (click)="toggleFault.emit('starTrackerBlinded')"
          [class]="isFaultActive('starTrackerBlinded') 
            ? 'bg-cyan-950/40 border-cyan-500/60 text-cyan-300' 
            : 'bg-slate-900/80 border-slate-800 text-slate-400 hover:text-slate-200'"
          class="p-3 rounded-xl border text-xs text-left transition-colors flex flex-col justify-between gap-2"
        >
          <div>
            <div class="flex items-center justify-between mb-1">
              <span class="font-bold">STAR TRACKER LOSS</span>
              <span class="text-[9px] px-1 rounded bg-slate-800">{{ isFaultActive('starTrackerBlinded') ? 'ACTIVE' : 'OFF' }}</span>
            </div>
            <p class="text-[10px] text-slate-500">
              Sun/Moon glint blinds camera optics.
            </p>
          </div>
          <div class="text-[10px] font-semibold text-cyan-400">
            Forces EKF gyro dead-reckon
          </div>
        </button>

        <!-- Fault 4: Gyro Bias Jump -->
        <button
          (click)="toggleFault.emit('gyroBiasJump')"
          [class]="isFaultActive('gyroBiasJump') 
            ? 'bg-purple-950/40 border-purple-500/60 text-purple-300' 
            : 'bg-slate-900/80 border-slate-800 text-slate-400 hover:text-slate-200'"
          class="p-3 rounded-xl border text-xs text-left transition-colors flex flex-col justify-between gap-2"
        >
          <div>
            <div class="flex items-center justify-between mb-1">
              <span class="font-bold">GYRO BIAS JUMP</span>
              <span class="text-[9px] px-1 rounded bg-slate-800">{{ isFaultActive('gyroBiasJump') ? 'ACTIVE' : 'OFF' }}</span>
            </div>
            <p class="text-[10px] text-slate-500">
              Sudden +0.02 rad/s thermal drift step.
            </p>
          </div>
          <div class="text-[10px] font-semibold text-purple-400">
            Tests EKF bias estimator
          </div>
        </button>

        <!-- Fault 5: Magnetometer Noise Corruption -->
        <button
          (click)="toggleFault.emit('magnetometerCorrupt')"
          [class]="isFaultActive('magnetometerCorrupt') 
            ? 'bg-amber-950/40 border-amber-500/60 text-amber-300' 
            : 'bg-slate-900/80 border-slate-800 text-slate-400 hover:text-slate-200'"
          class="p-3 rounded-xl border text-xs text-left transition-colors flex flex-col justify-between gap-2"
        >
          <div>
            <div class="flex items-center justify-between mb-1">
              <span class="font-bold">MAG CORRUPTION</span>
              <span class="text-[9px] px-1 rounded bg-slate-800">{{ isFaultActive('magnetometerCorrupt') ? 'ACTIVE' : 'OFF' }}</span>
            </div>
            <p class="text-[10px] text-slate-500">
              Avionics stray electromagnetic flux.
            </p>
          </div>
          <div class="text-[10px] font-semibold text-amber-400">
            Spurious desaturation dump
          </div>
        </button>
      </div>

      <!-- Section 28 Mandate: CAUSAL CHAIN INSPECTOR -->
      <div class="bg-slate-900/90 border border-slate-800 rounded-xl p-4">
        <div class="flex items-center justify-between mb-3 pb-2 border-b border-slate-800">
          <div>
            <h3 class="text-xs text-slate-200 font-semibold tracking-wider uppercase">
              CLOSED-LOOP CAUSAL CHAIN PROPAGATION
            </h3>
            <p class="text-[11px] text-slate-400">
              Live causal path: Fault Injected → Sensor/Actuator Dynamics → Estimator Innovation → Controller Commands → Spacecraft Motion
            </p>
          </div>
          <span class="text-[11px] text-cyan-400 font-bold">REAL-TIME INVARIANT TRACKER</span>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-5 gap-3 text-xs">
          <!-- Step 1: Fault State -->
          <div class="bg-slate-950/70 p-3 rounded-lg border border-slate-800 flex flex-col justify-between">
            <div>
              <div class="text-[10px] text-rose-400 uppercase font-bold mb-1">1. FAULT INJECTED</div>
              <div class="text-slate-200 font-semibold">
                {{ getActiveFaultName() }}
              </div>
              <p class="text-[10px] text-slate-400 mt-1">
                {{ getFaultDescription() }}
              </p>
            </div>
            <div class="mt-3 pt-2 border-t border-slate-800 text-[10px] text-rose-400">
              TRIGGER SOURCE
            </div>
          </div>

          <!-- Step 2: Sensor / Actuator Response -->
          <div class="bg-slate-950/70 p-3 rounded-lg border border-slate-800 flex flex-col justify-between">
            <div>
              <div class="text-[10px] text-cyan-400 uppercase font-bold mb-1">2. SENSOR / ACTUATOR</div>
              <div class="text-slate-200 text-[11px]">
                @if (telemetry?.sensors?.starTracker?.healthy === false) {
                  Star tracker: <span class="text-rose-400 font-bold">DROPOUT</span>
                } @else if (telemetry?.actuators?.wheels?.[2]?.failed) {
                  RW 3: <span class="text-rose-400 font-bold">0.00 Nm (LOCKED)</span>
                } @else if (telemetry?.actuators?.wheels?.[0]?.saturated) {
                  RW 1: <span class="text-amber-400 font-bold">SATURATED (6000 RPM)</span>
                } @else {
                  Hardware state: <span class="text-emerald-400 font-semibold">NOMINAL</span>
                }
              </div>
              <p class="text-[10px] text-slate-400 mt-1">
                Actuator limits or sensor measurement corruption detected.
              </p>
            </div>
            <div class="mt-3 pt-2 border-t border-slate-800 text-[10px] text-cyan-400">
              PHYSICAL PERTURBATION
            </div>
          </div>

          <!-- Step 3: Estimator Response -->
          <div class="bg-slate-950/70 p-3 rounded-lg border border-slate-800 flex flex-col justify-between">
            <div>
              <div class="text-[10px] text-purple-400 uppercase font-bold mb-1">3. ESTIMATOR (EKF)</div>
              <div class="text-slate-200 text-[11px]">
                Innovation: <span class="text-cyan-300 font-bold">{{ telemetry?.estimator?.innovationResidual?.toFixed(4) ?? '0.0000' }}</span>
              </div>
              <div class="text-slate-400 text-[10px] mt-0.5">
                Covariance ±3σ: {{ telemetry?.estimator?.sigma3Bounds?.[0]?.toFixed(3) ?? '0.000' }}°
              </div>
              <p class="text-[10px] text-slate-400 mt-1">
                @if (telemetry?.sensors?.starTracker?.healthy === false) {
                  Optical loss: P covariance bounds expand; dead-reckoning on gyros.
                } @else {
                  Kalman filter re-estimates state and gyro bias.
                }
              </p>
            </div>
            <div class="mt-3 pt-2 border-t border-slate-800 text-[10px] text-purple-400">
              BELIEF RE-ESTIMATION
            </div>
          </div>

          <!-- Step 4: Controller & Allocation -->
          <div class="bg-slate-950/70 p-3 rounded-lg border border-slate-800 flex flex-col justify-between">
            <div>
              <div class="text-[10px] text-amber-400 uppercase font-bold mb-1">4. CONTROL LAW & ALLOCATION</div>
              <div class="text-slate-200 text-[11px]">
                Residual: <span class="text-amber-300 font-bold">{{ getAllocationResidual() }} N·m</span>
              </div>
              <p class="text-[10px] text-slate-400 mt-1">
                @if (telemetry?.actuators?.wheels?.[2]?.failed) {
                  Weighted pseudoinverse redistributes missing torque to RW 1, 2, 4.
                } @else {
                  Controller commands reaction wheels to compensate pointing error.
                }
              </p>
            </div>
            <div class="mt-3 pt-2 border-t border-slate-800 text-[10px] text-amber-400">
              RESTORING TORQUE
            </div>
          </div>

          <!-- Step 5: Spacecraft Physical Motion -->
          <div class="bg-slate-950/70 p-3 rounded-lg border border-slate-800 flex flex-col justify-between">
            <div>
              <div class="text-[10px] text-emerald-400 uppercase font-bold mb-1">5. SPACECRAFT MOTION</div>
              <div class="text-slate-200 text-[11px]">
                Pointing Err: <span class="text-amber-400 font-bold">{{ telemetry?.pointingErrorDeg?.toFixed(4) ?? '0.0000' }}°</span>
              </div>
              <div class="text-slate-400 text-[10px] mt-0.5">
                Rate |w|: {{ getRateDegS() }} °/s
              </div>
              <p class="text-[10px] text-slate-400 mt-1">
                Spacecraft rigid-body dynamics stabilize back to reference.
              </p>
            </div>
            <div class="mt-3 pt-2 border-t border-slate-800 text-[10px] text-emerald-400">
              CLOSED-LOOP STABILITY
            </div>
          </div>
        </div>
      </div>
    </div>
  `,
})
export class FaultLabPanelComponent {
  @Input() telemetry: TelemetryPoint | null = null;
  @Input() activeFaults: Record<string, boolean | number> = {};

  @Output() toggleFault = new EventEmitter<string>();
  @Output() clearAllFaults = new EventEmitter<void>();

  isFaultActive(key: string): boolean {
    if (key === 'wheelFailed3') return this.activeFaults['wheelFailed'] === 3;
    if (key === 'wheelSaturated1') return this.activeFaults['wheelSaturated'] === 1;
    return !!this.activeFaults[key];
  }

  getActiveFaultName(): string {
    if (this.activeFaults['wheelFailed'] === 3) return 'REACTION WHEEL 3 LOCKED';
    if (this.activeFaults['wheelSaturated'] === 1) return 'REACTION WHEEL 1 SATURATED';
    if (this.activeFaults['starTrackerBlinded']) return 'STAR TRACKER OPTICAL LOSS';
    if (this.activeFaults['gyroBiasJump']) return 'GYRO BIAS JUMP (+0.02 rad/s)';
    if (this.activeFaults['magnetometerCorrupt']) return 'MAGNETOMETER SENSOR CORRUPTION';
    return 'NO ACTIVE FAULTS (NOMINAL)';
  }

  getFaultDescription(): string {
    if (this.activeFaults['wheelFailed'] === 3) {
      return 'Wheel 3 is inoperable; control allocator recalculates Moore-Penrose pseudo-inverse with zero weight for wheel 3.';
    }
    if (this.activeFaults['wheelSaturated'] === 1) {
      return 'Wheel 1 has reached maximum speed/momentum capacity and cannot generate acceleration in saturated direction.';
    }
    if (this.activeFaults['starTrackerBlinded']) {
      return 'Optical occlusion prevents attitude quaternion fixes; MEKF continues on rate gyro propagation with expanding covariance.';
    }
    if (this.activeFaults['gyroBiasJump']) {
      return 'Step jump injected into gyro rate output; MEKF innovation detects discrepancy and estimates new bias.';
    }
    if (this.activeFaults['magnetometerCorrupt']) {
      return 'Stray spacecraft electronics field corrupts B-field telemetry; desaturation filter isolates anomaly.';
    }
    return 'Spacecraft GNC running with all 4 reaction wheels and all 5 sensors healthy.';
  }

  getAllocationResidual(): string {
    if (!this.telemetry?.controller?.torqueResidualNm) return '0.000';
    const [x, y, z] = this.telemetry.controller.torqueResidualNm;
    return Math.sqrt(x * x + y * y + z * z).toFixed(4);
  }

  getRateDegS(): string {
    if (!this.telemetry) return '0.000';
    const w = this.telemetry.trueAngularVelocityRadS;
    return ((Math.sqrt(w[0] * w[0] + w[1] * w[1] + w[2] * w[2]) * 180) / Math.PI).toFixed(3);
  }
}
