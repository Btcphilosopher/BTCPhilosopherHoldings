import { ChangeDetectionStrategy, Component, EventEmitter, Input, Output } from '@angular/core';
import { MatIconModule } from '@angular/material/icon';
import { ModelFidelity } from '../core/spacecraft-types';
import { PREDEFINED_SCENARIOS } from '../core/simulation-engine';

@Component({
  selector: 'app-control-room-header',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [MatIconModule],
  template: `
    <header class="w-full bg-[#0b0e17] border-b border-slate-800 px-4 py-2.5 flex items-center justify-between gap-4 select-none">
      <!-- Zone 1: Brand Wordmark & Mission Status -->
      <div class="flex items-center gap-3">
        <div class="flex items-center gap-2">
          <div class="w-2.5 h-2.5 rounded-sm bg-cyan-500 shadow-sm shadow-cyan-500/50"></div>
          <span class="text-sm font-bold tracking-wider text-slate-100 font-mono whitespace-nowrap">
            NEWTON ROCKETS LTD.
          </span>
          <span class="text-xs text-slate-500 font-mono">/</span>
          <span class="text-xs font-semibold text-slate-300 font-mono tracking-wide hidden sm:inline">
            ORBITAL CONTROL ARRAY
          </span>
        </div>
      </div>

      <!-- Zone 2: Navigation Tabs -->
      <nav class="hidden md:flex items-center gap-1 bg-slate-900/80 p-1 rounded-lg border border-slate-800">
        @for (tab of tabs; track tab.id) {
          <button
            (click)="selectTab.emit(tab.id)"
            [class]="activeTab === tab.id 
              ? 'bg-slate-800 text-cyan-300 font-semibold shadow-sm border border-slate-700/60' 
              : 'text-slate-400 hover:text-slate-200'"
            class="px-2.5 py-1 text-xs font-mono rounded-md transition-colors whitespace-nowrap flex items-center gap-1.5"
          >
            <mat-icon class="!text-sm !w-3.5 !h-3.5 leading-none">{{ tab.icon }}</mat-icon>
            <span>{{ tab.label }}</span>
          </button>
        }
      </nav>

      <!-- Zone 3: Actions & Mission Controls -->
      <div class="flex items-center gap-2">
        <!-- Scenario Preset Selector -->
        <div class="relative hidden lg:block">
          <select
            [value]="selectedScenarioId"
            (change)="onScenarioChange($event)"
            class="bg-slate-900 border border-slate-800 text-xs font-mono text-slate-200 rounded-lg px-2.5 py-1.5 focus:outline-none focus:border-cyan-500 cursor-pointer"
          >
            @for (scen of scenarios; track scen.id) {
              <option [value]="scen.id">{{ scen.code }}: {{ scen.name }}</option>
            }
          </select>
        </div>

        <!-- Simulation Run / Pause Button -->
        <button
          (click)="toggleSimulation.emit()"
          [class]="isRunning 
            ? 'bg-amber-500/10 text-amber-300 border-amber-500/30 hover:bg-amber-500/20' 
            : 'bg-emerald-500/10 text-emerald-300 border-emerald-500/30 hover:bg-emerald-500/20'"
          class="px-3 py-1.5 text-xs font-mono font-medium rounded-lg border transition-colors flex items-center gap-1.5 whitespace-nowrap"
        >
          <mat-icon class="!text-base !w-4 !h-4 leading-none">
            {{ isRunning ? 'pause' : 'play_arrow' }}
          </mat-icon>
          <span>{{ isRunning ? 'PAUSE' : 'RUN (20Hz)' }}</span>
        </button>

        <!-- Single Step -->
        <button
          (click)="stepSimulation.emit()"
          [disabled]="isRunning"
          class="p-1.5 text-slate-400 hover:text-slate-200 bg-slate-900 border border-slate-800 rounded-lg disabled:opacity-40 transition-colors"
          title="Single Simulation Step (50ms)"
        >
          <mat-icon class="!text-base !w-4 !h-4 leading-none">skip_next</mat-icon>
        </button>

        <!-- Reset -->
        <button
          (click)="resetSimulation.emit()"
          class="p-1.5 text-slate-400 hover:text-rose-300 bg-slate-900 border border-slate-800 rounded-lg transition-colors"
          title="Reset Scenario State"
        >
          <mat-icon class="!text-base !w-4 !h-4 leading-none">replay</mat-icon>
        </button>

        <!-- Engineering Report Trigger -->
        <button
          (click)="openReport.emit()"
          class="hidden sm:flex px-2.5 py-1.5 text-xs font-mono text-slate-300 hover:text-cyan-300 bg-slate-900 border border-slate-800 rounded-lg items-center gap-1.5 transition-colors whitespace-nowrap"
        >
          <mat-icon class="!text-sm !w-3.5 !h-3.5 leading-none">description</mat-icon>
          <span>REPORT</span>
        </button>
      </div>
    </header>
  `,
})
export class ControlRoomHeaderComponent {
  @Input() activeTab = 'overview';
  @Input() isRunning = false;
  @Input() selectedScenarioId = 'nominal-pointing';
  @Input() modelFidelity: ModelFidelity = 'j2-perturbed';

  @Output() selectTab = new EventEmitter<string>();
  @Output() toggleSimulation = new EventEmitter<void>();
  @Output() stepSimulation = new EventEmitter<void>();
  @Output() resetSimulation = new EventEmitter<void>();
  @Output() changeScenario = new EventEmitter<string>();
  @Output() openReport = new EventEmitter<void>();

  scenarios = PREDEFINED_SCENARIOS;

  tabs = [
    { id: 'overview', label: 'DIGITAL TWIN', icon: 'view_in_ar' },
    { id: 'attitude', label: 'ATTITUDE & GUIDANCE', icon: 'explore' },
    { id: 'sensors', label: 'SENSORS & EKF', icon: 'sensors' },
    { id: 'control', label: 'CONTROL & ALLOCATION', icon: 'tune' },
    { id: 'actuators', label: 'WHEELS & MOMENTUM', icon: 'motion_photos_on' },
    { id: 'orbit', label: 'ORBIT & MANOEUVRE', icon: 'public' },
    { id: 'faults', label: 'FAULT LAB', icon: 'biotech' },
    { id: 'stability', label: 'STABILITY & BODE', icon: 'show_chart' },
    { id: 'monte-carlo', label: 'MONTE CARLO', icon: 'query_stats' },
    { id: 'repo', label: 'REPO & CODE', icon: 'code' },
  ];

  onScenarioChange(e: Event) {
    const val = (e.target as HTMLSelectElement).value;
    this.changeScenario.emit(val);
  }
}
