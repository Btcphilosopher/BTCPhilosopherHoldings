export type ReferenceFrame = 'ECI' | 'ECEF' | 'LVLH' | 'Body' | 'Inertial' | 'Orbital';

export interface Vector3D {
  x: number;
  y: number;
  z: number;
  frame: ReferenceFrame;
}

export interface Quaternion {
  q0: number; // Scalar part
  q1: number; // Vector x
  q2: number; // Vector y
  q3: number; // Vector z
  frame: ReferenceFrame;
}

export interface EulerAngles {
  roll: number;  // deg (phi around X)
  pitch: number; // deg (theta around Y)
  yaw: number;   // deg (psi around Z)
}

export interface InertiaTensor {
  ixx: number; // kg*m^2
  iyy: number;
  izz: number;
  ixy: number;
  ixz: number;
  iyz: number;
}

export interface OrbitalElements {
  semiMajorAxis: number;     // km
  eccentricity: number;      // dimensionless
  inclination: number;       // deg
  raan: number;              // Right Ascension of Ascending Node (deg)
  argOfPeriapsis: number;    // deg
  trueAnomaly: number;       // deg
  periodMinutes: number;     // min
  altitudeKm: number;        // km
}

export type ModelFidelity = 'two-body' | 'j2-perturbed' | 'high-fidelity';

export type GuidanceMode = 
  | 'sun-pointing' 
  | 'earth-nadir' 
  | 'inertial-fixed' 
  | 'velocity-ram' 
  | 'target-track';

export interface ReactionWheelState {
  id: number;
  axis: [number, number, number]; // Unit vector in Body frame
  speedRpm: number;
  maxSpeedRpm: number;
  maxTorqueNm: number;
  inertiaKgM2: number;
  momentumNms: number;
  maxMomentumNms: number;
  commandedTorqueNm: number;
  actualTorqueNm: number;
  saturated: boolean;
  failed: boolean;
  temperatureC: number;
}

export interface MagnetorquerState {
  dipoleMomentAm2: [number, number, number]; // Body frame
  maxDipoleAm2: number;
  localFieldTesla: [number, number, number];
  generatedTorqueNm: [number, number, number];
  active: boolean;
}

export interface ThrusterState {
  totalDeltaVMs: number;
  thrustN: number;
  propellantMassKg: number;
  initialPropellantKg: number;
  ispSec: number;
  firing: boolean;
}

export interface SensorReading<T> {
  truth: T;
  measured: T;
  error: T;
  uncertainty3Sigma: number;
  healthy: boolean;
}

export interface SensorSuiteState {
  gyro: SensorReading<[number, number, number]>; // rad/s
  starTracker: SensorReading<[number, number, number, number]>; // quaternion
  sunSensor: SensorReading<[number, number, number]>; // unit vector
  magnetometer: SensorReading<[number, number, number]>; // microTesla
  accelerometer: SensorReading<[number, number, number]>; // m/s^2
  sunVisible: boolean;
  starTrackerOccluded: boolean;
}

export interface EstimatorState {
  estimatedAttitude: Quaternion;
  estimatedAngularVelocity: [number, number, number];
  gyroBiasEstimate: [number, number, number];
  attitudeErrorDeg: [number, number, number];
  rateErrorDegPerSec: [number, number, number];
  covarianceDiagonal: number[]; // 6 states: [d_theta (3), d_bias (3)]
  sigma3Bounds: [number, number, number];
  innovationResidual: number;
  converged: boolean;
}

export interface ControllerState {
  errorQuaternion: Quaternion;
  rateErrorRadPerSec: [number, number, number];
  commandedTorqueNm: [number, number, number];
  realizedTorqueNm: [number, number, number];
  torqueResidualNm: [number, number, number];
  kp: number;
  kd: number;
  ki: number;
}

export interface DisturbanceState {
  gravityGradientNm: [number, number, number];
  solarRadiationNm: [number, number, number];
  atmosphericDragNm: [number, number, number];
  residualDipoleNm: [number, number, number];
  totalDisturbanceNm: [number, number, number];
  activeDisturbances: {
    gravityGradient: boolean;
    solarPressure: boolean;
    atmosphericDrag: boolean;
    residualDipole: boolean;
  };
}

export interface TelemetryPoint {
  timeSec: number;
  trueOrbit: OrbitalElements;
  truePositionEci: Vector3D;
  trueVelocityEci: Vector3D;
  trueAttitude: Quaternion;
  trueEulerDeg: EulerAngles;
  trueAngularVelocityRadS: [number, number, number];
  guidanceAttitude: Quaternion;
  guidanceEulerDeg: EulerAngles;
  pointingErrorDeg: number;
  estimator: EstimatorState;
  controller: ControllerState;
  actuators: {
    wheels: ReactionWheelState[];
    totalWheelMomentumNms: number;
    magnetorquer: MagnetorquerState;
    thruster: ThrusterState;
  };
  disturbances: DisturbanceState;
  sensors: SensorSuiteState;
  modelFidelity: ModelFidelity;
}

export interface SpacecraftConfig {
  name: string;
  busDimensionsMeters: [number, number, number]; // [x, y, z]
  dryMassKg: number;
  propellantMassKg: number;
  inertia: InertiaTensor;
  centerOfMassOffsetMeters: [number, number, number];
  solarArrayAreaM2: number;
  dragCoefficientCd: number;
  reflectivityCr: number;
  residualDipoleAm2: [number, number, number];
  reactionWheelCount: 3 | 4;
}

export interface ScenarioDefinition {
  id: string;
  name: string;
  code: string;
  description: string;
  initialAttitude: EulerAngles;
  initialRatesDegS: [number, number, number];
  guidanceMode: GuidanceMode;
  initialAltitudeKm: number;
  wheelSpeedsRpm: number[];
  injectedFaults?: {
    wheelFailed?: number;
    wheelSaturated?: number;
    starTrackerBlinded?: boolean;
    gyroBiasJump?: boolean;
    highDisturbance?: boolean;
  };
}
