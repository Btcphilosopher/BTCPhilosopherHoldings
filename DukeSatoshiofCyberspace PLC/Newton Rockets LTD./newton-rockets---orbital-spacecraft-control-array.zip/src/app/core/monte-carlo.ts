export interface MonteCarloRunResult {
  runId: number;
  massKg: number;
  inertiaScale: number;
  initialErrorDeg: number;
  rmsPointingErrorDeg: number;
  maxPointingErrorDeg: number;
  settlingTimeSec: number;
  controlEffortNm2S: number;
  peakWheelMomentumNms: number;
  success: boolean;
}

export interface MonteCarloSummary {
  totalRuns: number;
  successRatePercent: number;
  meanPointingErrorDeg: number;
  p95PointingErrorDeg: number;
  maxPointingErrorDeg: number;
  meanSettlingTimeSec: number;
  p95SettlingTimeSec: number;
  meanControlEffort: number;
  errorHistogram: { binLabel: string; count: number; percentage: number }[];
  settlingHistogram: { binLabel: string; count: number; percentage: number }[];
  runs: MonteCarloRunResult[];
}

export class MonteCarloEngine {
  /**
   * Runs a fast batch Monte Carlo simulation dispersion study
   */
  static runStudy(
    numRuns = 100,
    nominalMass = 350,
    nominalInertia = 45,
    nominalKp = 2.5,
    nominalKd = 4.2
  ): MonteCarloSummary {
    const results: MonteCarloRunResult[] = [];

    for (let i = 0; i < numRuns; i++) {
      // Dispersions:
      // Mass: +/- 10%
      const massDisp = nominalMass * (1 + (Math.random() - 0.5) * 0.2);
      // Inertia: +/- 15%
      const inertiaScale = 1 + (Math.random() - 0.5) * 0.3;
      const effectiveInertia = nominalInertia * inertiaScale;

      // Initial attitude disturbance angle: 2 to 25 deg
      const initialErrorDeg = 2.0 + Math.random() * 20.0;
      // Sensor noise scale: 0.5x to 2.0x
      const noiseScale = 0.5 + Math.random() * 1.5;

      // Dynamics physics evaluation:
      const wn = Math.sqrt(nominalKp / effectiveInertia);
      const zeta = nominalKd / (2 * Math.sqrt(effectiveInertia * nominalKp));

      // Settling time roughly 4 / (zeta * wn) with random overshoot dispersion
      const settlingNominal = zeta > 0 ? 4.0 / (zeta * wn) : 120;
      const settlingTimeSec = Number(
        Math.max(5, settlingNominal * (1 + (Math.random() - 0.5) * 0.4)).toFixed(1)
      );

      // RMS pointing error in steady state governed by sensor noise and disturbance rejection
      const steadyStateNoiseFloor = 0.008 * noiseScale;
      const rmsPointingError = Number(
        (steadyStateNoiseFloor + 0.002 * (Math.random() * 0.5)).toFixed(4)
      );
      const maxPointingError = Number(
        (initialErrorDeg * Math.exp(-zeta * wn * 0.5) + rmsPointingError * 3).toFixed(3)
      );

      // Control effort: integral of tau^2 dt approx prop to initial angle & settling
      const controlEffort = Number(
        (0.5 * nominalKp * Math.pow((initialErrorDeg * Math.PI) / 180, 2) * settlingTimeSec * 1.2).toFixed(2)
      );

      // Peak wheel momentum accumulation (Nms)
      const peakWheelMomentum = Number(
        Math.min(9.8, 1.8 + initialErrorDeg * 0.15 + Math.random() * 0.8).toFixed(2)
      );

      const success = rmsPointingError < 0.05 && settlingTimeSec < 60;

      results.push({
        runId: i + 1,
        massKg: Number(massDisp.toFixed(1)),
        inertiaScale: Number(inertiaScale.toFixed(3)),
        initialErrorDeg: Number(initialErrorDeg.toFixed(2)),
        rmsPointingErrorDeg: rmsPointingError,
        maxPointingErrorDeg: maxPointingError,
        settlingTimeSec,
        controlEffortNm2S: controlEffort,
        peakWheelMomentumNms: peakWheelMomentum,
        success,
      });
    }

    // Compute statistics
    const sortedErrors = [...results].map((r) => r.rmsPointingErrorDeg).sort((a, b) => a - b);
    const sortedSettling = [...results].map((r) => r.settlingTimeSec).sort((a, b) => a - b);

    const meanError = sortedErrors.reduce((a, b) => a + b, 0) / numRuns;
    const p95Error = sortedErrors[Math.floor(numRuns * 0.95)];
    const maxError = sortedErrors[numRuns - 1];

    const meanSettling = sortedSettling.reduce((a, b) => a + b, 0) / numRuns;
    const p95Settling = sortedSettling[Math.floor(numRuns * 0.95)];

    const meanEffort = results.reduce((a, b) => a + b.controlEffortNm2S, 0) / numRuns;
    const successCount = results.filter((r) => r.success).length;

    // Build Error Histogram (5 bins)
    const errBins = [
      { max: 0.01, label: '< 0.010°' },
      { max: 0.015, label: '0.010 - 0.015°' },
      { max: 0.020, label: '0.015 - 0.020°' },
      { max: 0.030, label: '0.020 - 0.030°' },
      { max: 999, label: '> 0.030°' },
    ];
    const errorHistogram = errBins.map((bin, idx) => {
      const prevMax = idx === 0 ? 0 : errBins[idx - 1].max;
      const count = results.filter((r) => r.rmsPointingErrorDeg > prevMax && r.rmsPointingErrorDeg <= bin.max).length;
      return {
        binLabel: bin.label,
        count,
        percentage: Number(((count / numRuns) * 100).toFixed(1)),
      };
    });

    // Build Settling Histogram (5 bins)
    const setBins = [
      { max: 15, label: '< 15s' },
      { max: 25, label: '15 - 25s' },
      { max: 35, label: '25 - 35s' },
      { max: 45, label: '35 - 45s' },
      { max: 999, label: '> 45s' },
    ];
    const settlingHistogram = setBins.map((bin, idx) => {
      const prevMax = idx === 0 ? 0 : setBins[idx - 1].max;
      const count = results.filter((r) => r.settlingTimeSec > prevMax && r.settlingTimeSec <= bin.max).length;
      return {
        binLabel: bin.label,
        count,
        percentage: Number(((count / numRuns) * 100).toFixed(1)),
      };
    });

    return {
      totalRuns: numRuns,
      successRatePercent: Number(((successCount / numRuns) * 100).toFixed(1)),
      meanPointingErrorDeg: Number(meanError.toFixed(4)),
      p95PointingErrorDeg: Number(p95Error.toFixed(4)),
      maxPointingErrorDeg: Number(maxError.toFixed(4)),
      meanSettlingTimeSec: Number(meanSettling.toFixed(1)),
      p95SettlingTimeSec: Number(p95Settling.toFixed(1)),
      meanControlEffort: Number(meanEffort.toFixed(2)),
      errorHistogram,
      settlingHistogram,
      runs: results,
    };
  }
}
