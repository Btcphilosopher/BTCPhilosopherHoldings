import {
  SpacecraftConfig,
  TelemetryPoint,
  ScenarioDefinition,
  GuidanceMode,
  ModelFidelity,
  ReactionWheelState,
  MagnetorquerState,
  ThrusterState,
  Quaternion,
} from './spacecraft-types';
import { OrbitalMechanics, OrbitStateVector } from './orbital-mechanics';
import { AttitudeMath, AttitudeDynamics } from './attitude-dynamics';
import { SensorModels, MultiplicativeEKF } from './sensors-estimation';
import { ControlAllocator, GuidanceController } from './control-allocation';

export const DEFAULT_SPACECRAFT: SpacecraftConfig = {
  name: 'NEWTON SOLAR PROBE',
  busDimensionsMeters: [1.6, 1.4, 2.2],
  dryMassKg: 320.0,
  propellantMassKg: 45.0,
  inertia: {
    ixx: 48.5,
    iyy: 54.2,
    izz: 36.8,
    ixy: 0.8,
    ixz: -0.4,
    iyz: 0.6,
  },
  centerOfMassOffsetMeters: [0.02, -0.01, 0.04],
  solarArrayAreaM2: 5.4,
  dragCoefficientCd: 2.2,
  reflectivityCr: 1.3,
  residualDipoleAm2: [0.2, -0.15, 0.3],
  reactionWheelCount: 4,
};

export const PREDEFINED_SCENARIOS: ScenarioDefinition[] = [
  {
    id: 'nominal-pointing',
    code: 'SCEN-01',
    name: 'Nominal Sun Pointing',
    description: 'Spacecraft in 550 km Sun-synchronous orbit holding high-precision Sun alignment with fine Star Tracker tracking.',
    initialAttitude: { roll: 2, pitch: -88, yaw: 1 },
    initialRatesDegS: [0.02, -0.01, 0.01],
    guidanceMode: 'sun-pointing',
    initialAltitudeKm: 550,
    wheelSpeedsRpm: [800, -650, 720, -500],
  },
  {
    id: 'sun-acquisition',
    code: 'SCEN-02',
    name: 'Sun Acquisition & Detumble',
    description: 'Post-separation rate damping and acquisition maneuver from 4.5 deg/s initial tumble.',
    initialAttitude: { roll: 45, pitch: -30, yaw: 70 },
    initialRatesDegS: [3.5, -2.8, 1.9],
    guidanceMode: 'sun-pointing',
    initialAltitudeKm: 550,
    wheelSpeedsRpm: [0, 0, 0, 0],
  },
  {
    id: 'earth-nadir',
    code: 'SCEN-03',
    name: 'Earth Nadir Observation',
    description: 'Payload Earth-pointing mode with orbital pitch rate tracking at 0.001 rad/s.',
    initialAttitude: { roll: 0, pitch: 0, yaw: 0 },
    initialRatesDegS: [0, -0.06, 0],
    guidanceMode: 'earth-nadir',
    initialAltitudeKm: 500,
    wheelSpeedsRpm: [1200, 1100, -900, -800],
  },
  {
    id: 'wheel-failure',
    code: 'SCEN-04',
    name: 'Single-Wheel Failure (RW 3 Locked)',
    description: 'Reaction Wheel 3 experiences a mechanical lock. The Control Allocator dynamically re-allocates torque to the remaining 3 wheels.',
    initialAttitude: { roll: 5, pitch: -85, yaw: 4 },
    initialRatesDegS: [0.1, 0.05, -0.08],
    guidanceMode: 'sun-pointing',
    initialAltitudeKm: 550,
    wheelSpeedsRpm: [1200, -1400, 0, 800],
    injectedFaults: { wheelFailed: 3 },
  },
  {
    id: 'star-tracker-loss',
    code: 'SCEN-05',
    name: 'Star-Tracker Loss / Optical Dropout',
    description: 'Bright Earth limb or Sun blinding blinds the optical star tracker. MEKF coasts on gyros; covariance 3-sigma bounds expand.',
    initialAttitude: { roll: 0, pitch: -90, yaw: 0 },
    initialRatesDegS: [0, 0, 0],
    guidanceMode: 'sun-pointing',
    initialAltitudeKm: 550,
    wheelSpeedsRpm: [900, -900, 700, -700],
    injectedFaults: { starTrackerBlinded: true },
  },
  {
    id: 'wheel-saturation',
    code: 'SCEN-06',
    name: 'Reaction-Wheel Saturation & Desat',
    description: 'Reaction wheels near 5800 RPM saturation limit. Momentum management triggers magnetorquer cross-product dumping.',
    initialAttitude: { roll: 1, pitch: -89, yaw: 0 },
    initialRatesDegS: [0, 0, 0],
    guidanceMode: 'sun-pointing',
    initialAltitudeKm: 480,
    wheelSpeedsRpm: [5200, 5400, 5100, 5300],
    injectedFaults: { wheelSaturated: 1 },
  },
  {
    id: 'high-disturbance',
    code: 'SCEN-07',
    name: 'High Disturbance Environment',
    description: 'Low 320 km orbit with aggressive atmospheric drag and severe gravity-gradient torque.',
    initialAttitude: { roll: 12, pitch: -60, yaw: 20 },
    initialRatesDegS: [0.3, -0.4, 0.2],
    guidanceMode: 'earth-nadir',
    initialAltitudeKm: 320,
    wheelSpeedsRpm: [1500, -1200, 1800, -1100],
    injectedFaults: { highDisturbance: true },
  },
  {
    id: 'orbital-manoeuvre',
    code: 'SCEN-08',
    name: 'Orbital Manoeuvre (RCS Burn)',
    description: 'Translational Delta-V orbit raising maneuver with thruster firing and attitude hold under thruster disturbance torques.',
    initialAttitude: { roll: 0, pitch: 0, yaw: 0 },
    initialRatesDegS: [0, 0, 0],
    guidanceMode: 'velocity-ram',
    initialAltitudeKm: 450,
    wheelSpeedsRpm: [1000, -1000, 800, -800],
  },
];

export class SimulationEngine {
  spacecraft: SpacecraftConfig = { ...DEFAULT_SPACECRAFT };
  activeScenario: ScenarioDefinition = PREDEFINED_SCENARIOS[0];
  modelFidelity: ModelFidelity = 'j2-perturbed';

  timeSec = 0;
  dt = 0.05; // 20 Hz simulation step
  isRunning = false;

  // True States
  orbitState: OrbitStateVector = { r: [6928, 0, 0], v: [0, 7.58, 0] };
  trueAttitude: Quaternion = { q0: 1, q1: 0, q2: 0, q3: 0, frame: 'Body' };
  trueOmegaRadS: [number, number, number] = [0, 0, 0];

  // Guidance & Control
  guidanceMode: GuidanceMode = 'sun-pointing';
  guidance = new GuidanceController();
  allocatorA = ControlAllocator.getPyramidAllocationMatrix();

  // Actuator States
  wheels: ReactionWheelState[] = [];
  magnetorquer: MagnetorquerState = {
    dipoleMomentAm2: [0, 0, 0],
    maxDipoleAm2: 30,
    localFieldTesla: [0, 0, 0],
    generatedTorqueNm: [0, 0, 0],
    active: false,
  };
  thruster: ThrusterState = {
    totalDeltaVMs: 0,
    thrustN: 4.0,
    propellantMassKg: 45.0,
    initialPropellantKg: 45.0,
    ispSec: 220,
    firing: false,
  };

  // Estimator
  mekf = new MultiplicativeEKF();

  // Disturbance Toggles
  disturbancesActive = {
    gravityGradient: true,
    solarPressure: true,
    atmosphericDrag: true,
    residualDipole: true,
  };

  // Fault Injections
  faults = {
    wheelFailed: 0, // 1..4 (0 means none)
    wheelSaturated: 0,
    starTrackerBlinded: false,
    gyroBiasJump: false,
    magnetometerCorrupt: false,
  };

  // Telemetry History (Ring buffer)
  telemetryHistory: TelemetryPoint[] = [];
  maxHistoryPoints = 1200;

  constructor() {
    this.initWheels();
    this.loadScenario(this.activeScenario);
  }

  initWheels() {
    const beta = (54.7356 * Math.PI) / 180;
    const cosB = Math.cos(beta);
    const sinB = Math.sin(beta);
    const phi = [Math.PI / 4, (3 * Math.PI) / 4, (5 * Math.PI) / 4, (7 * Math.PI) / 4];

    this.wheels = [1, 2, 3, 4].map((id, idx) => ({
      id,
      axis: [cosB * Math.cos(phi[idx]), cosB * Math.sin(phi[idx]), sinB],
      speedRpm: 500,
      maxSpeedRpm: 6000,
      maxTorqueNm: 0.2,
      inertiaKgM2: 0.018,
      momentumNms: (500 * (2 * Math.PI / 60)) * 0.018,
      maxMomentumNms: (6000 * (2 * Math.PI / 60)) * 0.018,
      commandedTorqueNm: 0,
      actualTorqueNm: 0,
      saturated: false,
      failed: false,
      temperatureC: 21.5,
    }));
  }

  loadScenario(scenario: ScenarioDefinition) {
    this.activeScenario = scenario;
    this.timeSec = 0;
    this.telemetryHistory = [];

    // Set initial attitude & rates
    this.trueAttitude = AttitudeMath.eulerToQuaternion(scenario.initialAttitude);
    this.trueOmegaRadS = [
      (scenario.initialRatesDegS[0] * Math.PI) / 180,
      (scenario.initialRatesDegS[1] * Math.PI) / 180,
      (scenario.initialRatesDegS[2] * Math.PI) / 180,
    ];
    this.guidanceMode = scenario.guidanceMode;

    // Set initial orbit state
    const rOrbitKm = 6378.137 + scenario.initialAltitudeKm;
    const vOrbitKmS = Math.sqrt(398600.4418 / rOrbitKm);
    this.orbitState = {
      r: [rOrbitKm, 0, 0],
      v: [0, vOrbitKmS, 0],
    };

    // Initialize wheel speeds
    this.wheels.forEach((w, idx) => {
      const rpm = scenario.wheelSpeedsRpm[idx] || 0;
      w.speedRpm = rpm;
      w.momentumNms = (rpm * (2 * Math.PI / 60)) * w.inertiaKgM2;
      w.failed = false;
      w.saturated = false;
    });

    // Reset injected faults
    this.faults = {
      wheelFailed: scenario.injectedFaults?.wheelFailed || 0,
      wheelSaturated: scenario.injectedFaults?.wheelSaturated || 0,
      starTrackerBlinded: scenario.injectedFaults?.starTrackerBlinded || false,
      gyroBiasJump: scenario.injectedFaults?.gyroBiasJump || false,
      magnetometerCorrupt: false,
    };

    if (this.faults.wheelFailed > 0) {
      this.wheels[this.faults.wheelFailed - 1].failed = true;
    }
    if (this.faults.wheelSaturated > 0) {
      const w = this.wheels[this.faults.wheelSaturated - 1];
      w.speedRpm = w.maxSpeedRpm;
      w.momentumNms = w.maxMomentumNms;
      w.saturated = true;
    }

    // Reset EKF
    this.mekf.reset(this.trueAttitude);
    this.guidance.resetIntegral();
  }

  /**
   * Performs one simulation iteration step
   */
  step(): TelemetryPoint {
    const dt = this.dt;
    this.timeSec += dt;

    // 1. ORBIT PROPAGATION (RK4)
    const massTotalKg = this.spacecraft.dryMassKg + this.thruster.propellantMassKg;
    this.orbitState = OrbitalMechanics.stepRk4(
      this.orbitState,
      dt,
      this.modelFidelity,
      massTotalKg,
      this.spacecraft.solarArrayAreaM2,
      this.spacecraft.dragCoefficientCd
    );

    // Apply thruster delta-v if active
    let thrusterForceBody: [number, number, number] = [0, 0, 0];
    if (this.thruster.firing && this.thruster.propellantMassKg > 0.05) {
      const dm = (this.thruster.thrustN / (this.thruster.ispSec * 9.80665)) * dt;
      this.thruster.propellantMassKg = Math.max(0, this.thruster.propellantMassKg - dm);
      const dv = (this.thruster.thrustN / massTotalKg) * dt;
      this.thruster.totalDeltaVMs += dv;
      thrusterForceBody = [this.thruster.thrustN, 0, 0];

      // Add velocity along track
      const vMag = Math.sqrt(
        this.orbitState.v[0] * this.orbitState.v[0] +
        this.orbitState.v[1] * this.orbitState.v[1] +
        this.orbitState.v[2] * this.orbitState.v[2]
      );
      this.orbitState.v[0] += (dv / 1000) * (this.orbitState.v[0] / vMag);
      this.orbitState.v[1] += (dv / 1000) * (this.orbitState.v[1] / vMag);
      this.orbitState.v[2] += (dv / 1000) * (this.orbitState.v[2] / vMag);
    }

    // 2. GUIDANCE & REFERENCE
    const ref = this.guidance.generateReference(this.guidanceMode, this.orbitState);
    const guidanceAttitude = ref.qDes;
    const guidanceOmega = ref.omegaDes;
    const guidanceEuler = AttitudeMath.quaternionToEuler(guidanceAttitude);

    // 3. SENSORS SAMPLING (Truth -> Noisy Measurements)
    const dcmEciToBody = AttitudeMath.quaternionToDcm(this.trueAttitude);
    const sunUnitEci: [number, number, number] = [1, 0, 0];
    const sunUnitBody = AttitudeMath.rotateVector(dcmEciToBody, sunUnitEci);

    const bFieldTesla: [number, number, number] = [
      30e-6 * Math.cos(this.timeSec * 0.001),
      -20e-6 * Math.sin(this.timeSec * 0.001),
      40e-6,
    ];
    const bFieldBodyMicroTesla = AttitudeMath.rotateVector(dcmEciToBody, bFieldTesla).map(
      (v) => v * 1e6
    ) as [number, number, number];

    const specificForceBody: [number, number, number] = [
      thrusterForceBody[0] / massTotalKg,
      thrusterForceBody[1] / massTotalKg,
      thrusterForceBody[2] / massTotalKg,
    ];

    const sensorState = SensorModels.sampleSensors(
      this.trueAttitude,
      this.trueOmegaRadS,
      sunUnitBody,
      bFieldBodyMicroTesla,
      specificForceBody,
      {
        starTrackerBlinded: this.faults.starTrackerBlinded,
        gyroBiasJump: this.faults.gyroBiasJump,
        magnetometerCorrupt: this.faults.magnetometerCorrupt,
      }
    );

    // 4. STATE ESTIMATION (MEKF)
    const estimatorState = this.mekf.step(
      dt,
      sensorState.gyro.measured,
      sensorState.starTracker.healthy ? sensorState.starTracker.measured : null,
      sensorState.starTracker.healthy,
      this.trueAttitude,
      this.trueOmegaRadS
    );

    // 5. CONTROL LAW (Consumes ESTIMATED State)
    const ctrl = this.guidance.computeControlTorque(
      dt,
      estimatorState.estimatedAttitude,
      estimatorState.estimatedAngularVelocity,
      guidanceAttitude,
      guidanceOmega
    );

    // 6. CONTROL ALLOCATION (Wheel matrix & Pseudo-inverse)
    const wheelHealth: [boolean, boolean, boolean, boolean] = [
      !this.wheels[0].failed,
      !this.wheels[1].failed,
      !this.wheels[2].failed,
      !this.wheels[3].failed,
    ];
    const A_pinv = ControlAllocator.computeWeightedPseudoInverse(this.allocatorA, wheelHealth);
    const alloc = ControlAllocator.allocateWheelTorques(
      ctrl.tauReqNm,
      this.wheels,
      this.allocatorA,
      A_pinv
    );

    // 7. ACTUATORS DYNAMICS & UPDATE
    for (let i = 0; i < 4; i++) {
      const w = this.wheels[i];
      w.commandedTorqueNm = alloc.commandedWheelTorques[i];
      w.actualTorqueNm = alloc.actualWheelTorques[i];

      // Update wheel momentum: dH = u_wheel * dt
      w.momentumNms += w.actualTorqueNm * dt;
      // Wheel speed in RPM
      const omegaWheelRadS = w.momentumNms / w.inertiaKgM2;
      w.speedRpm = (omegaWheelRadS * 60) / (2 * Math.PI);
      w.saturated = Math.abs(w.momentumNms) >= w.maxMomentumNms;
    }

    // Total wheel momentum vector in body frame: H_w = A * [h1, h2, h3, h4]^T
    const hWheelBody: [number, number, number] = [0, 0, 0];
    for (let r = 0; r < 3; r++) {
      let sum = 0;
      for (let c = 0; c < 4; c++) {
        sum += this.allocatorA[r][c] * this.wheels[c].momentumNms;
      }
      hWheelBody[r] = sum;
    }

    // Magnetorquer momentum management
    const bTeslaBody: [number, number, number] = [
      bFieldBodyMicroTesla[0] * 1e-6,
      bFieldBodyMicroTesla[1] * 1e-6,
      bFieldBodyMicroTesla[2] * 1e-6,
    ];
    this.magnetorquer = this.guidance.computeMagnetorquerDump(
      hWheelBody,
      bTeslaBody,
      this.magnetorquer.maxDipoleAm2
    );

    // 8. DISTURBANCES CALCULATION
    const disturbances = AttitudeDynamics.calculateDisturbances(
      this.orbitState.r,
      dcmEciToBody,
      this.spacecraft.inertia,
      this.disturbancesActive,
      this.spacecraft.residualDipoleAm2
    );

    // 9. RIGID-BODY ATTITUDE DYNAMICS (RK4 update of true attitude & rate)
    // Net torque on spacecraft body = tau_realized (from wheels) + tau_mag + tau_disturbances
    const tauTotalBody: [number, number, number] = [
      alloc.realizedTorqueNm[0] + this.magnetorquer.generatedTorqueNm[0] + disturbances.total[0],
      alloc.realizedTorqueNm[1] + this.magnetorquer.generatedTorqueNm[1] + disturbances.total[1],
      alloc.realizedTorqueNm[2] + this.magnetorquer.generatedTorqueNm[2] + disturbances.total[2],
    ];

    // Propagate angular velocity
    const alpha = AttitudeDynamics.getAngularAcceleration(
      this.trueOmegaRadS,
      hWheelBody,
      tauTotalBody,
      this.spacecraft.inertia
    );
    this.trueOmegaRadS = [
      this.trueOmegaRadS[0] + alpha[0] * dt,
      this.trueOmegaRadS[1] + alpha[1] * dt,
      this.trueOmegaRadS[2] + alpha[2] * dt,
    ];

    // Propagate true quaternion
    const qDot = AttitudeDynamics.getQuaternionDerivative(this.trueAttitude, this.trueOmegaRadS);
    this.trueAttitude = AttitudeMath.normalizeQuaternion({
      q0: this.trueAttitude.q0 + qDot[0] * dt,
      q1: this.trueAttitude.q1 + qDot[1] * dt,
      q2: this.trueAttitude.q2 + qDot[2] * dt,
      q3: this.trueAttitude.q3 + qDot[3] * dt,
      frame: 'Body',
    });

    // Pointing error angle with respect to guidance
    const qErrGuidance = AttitudeMath.errorQuaternion(this.trueAttitude, guidanceAttitude);
    const pointingErrorDeg = (2 * Math.acos(Math.min(1, Math.abs(qErrGuidance.q0))) * 180) / Math.PI;

    // Compile Telemetry Point
    const trueEuler = AttitudeMath.quaternionToEuler(this.trueAttitude);
    const trueOrbit = OrbitalMechanics.stateToKeplerian(this.orbitState);

    const point: TelemetryPoint = {
      timeSec: Number(this.timeSec.toFixed(2)),
      trueOrbit,
      truePositionEci: {
        x: this.orbitState.r[0],
        y: this.orbitState.r[1],
        z: this.orbitState.r[2],
        frame: 'ECI',
      },
      trueVelocityEci: {
        x: this.orbitState.v[0],
        y: this.orbitState.v[1],
        z: this.orbitState.v[2],
        frame: 'ECI',
      },
      trueAttitude: { ...this.trueAttitude },
      trueEulerDeg: trueEuler,
      trueAngularVelocityRadS: [...this.trueOmegaRadS],
      guidanceAttitude: { ...guidanceAttitude },
      guidanceEulerDeg: guidanceEuler,
      pointingErrorDeg: Number(pointingErrorDeg.toFixed(4)),
      estimator: estimatorState,
      controller: {
        errorQuaternion: ctrl.errorQuaternion,
        rateErrorRadPerSec: ctrl.rateError,
        commandedTorqueNm: ctrl.tauReqNm,
        realizedTorqueNm: alloc.realizedTorqueNm,
        torqueResidualNm: alloc.residualTorqueNm,
        kp: this.guidance.kp,
        kd: this.guidance.kd,
        ki: this.guidance.ki,
      },
      actuators: {
        wheels: this.wheels.map((w) => ({ ...w })),
        totalWheelMomentumNms: Number(AttitudeMath.norm(hWheelBody).toFixed(3)),
        magnetorquer: { ...this.magnetorquer },
        thruster: { ...this.thruster },
      },
      disturbances: {
        gravityGradientNm: disturbances.gravityGradient,
        solarRadiationNm: disturbances.solarPressure,
        atmosphericDragNm: disturbances.atmosphericDrag,
        residualDipoleNm: disturbances.residualDipole,
        totalDisturbanceNm: disturbances.total,
        activeDisturbances: { ...this.disturbancesActive },
      },
      sensors: sensorState,
      modelFidelity: this.modelFidelity,
    };

    this.telemetryHistory.push(point);
    if (this.telemetryHistory.length > this.maxHistoryPoints) {
      this.telemetryHistory.shift();
    }

    return point;
  }
}
