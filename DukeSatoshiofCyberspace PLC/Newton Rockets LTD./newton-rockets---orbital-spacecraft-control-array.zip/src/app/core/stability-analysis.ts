export interface StabilityMetrics {
  gainMarginDb: number;
  phaseMarginDeg: number;
  gainCrossoverFreqRadS: number;
  phaseCrossoverFreqRadS: number;
  dampingRatio: number;
  naturalFreqRadS: number;
  estimatedSettlingTimeSec: number;
  poles: { real: number; imag: number }[];
  isStable: boolean;
}

export interface BodePoint {
  freqRadS: number;
  freqHz: number;
  magDb: number;
  phaseDeg: number;
}

export class StabilityAnalysis {
  /**
   * Computes stability metrics for rigid-body satellite with PID attitude control
   * Single-axis model: I * s^2 * theta = (Kp + Kd*s + Ki/s) * theta_err
   * Open loop: L(s) = (Kd*s^2 + Kp*s + Ki) / (I*s^3)
   */
  static analyze(kp: number, kd: number, ki: number, inertia: number): StabilityMetrics {
    // Characteristic equation: I*s^3 + Kd*s^2 + Kp*s + Ki = 0
    // Roots using Cardano's cubic formula for a*s^3 + b*s^2 + c*s + d = 0
    const a = inertia;
    const b = kd;
    const c = kp;
    const d = Math.max(1e-6, ki);

    const poles = this.solveCubic(a, b, c, d);

    // Natural frequency and damping estimate from dominant quadratic pair
    const wn = Math.sqrt(kp / inertia);
    const zeta = kd / (2 * Math.sqrt(inertia * kp));
    const settlingTime = zeta > 0 ? 4.0 / (zeta * wn) : 999;

    // Gain crossover frequency: |L(j*wc)| = 1
    // For s = j*w: |L(jw)| = sqrt((Kp - Kd*w^2)^2 + (Ki/w)^2) / (I*w^2)
    let gainCrossoverW = wn;
    let minErr = 999;
    for (let w = 0.01; w <= 50; w += 0.02) {
      const mag = this.computeOpenLoopMagnitude(w, kp, kd, ki, inertia);
      const err = Math.abs(mag - 1.0);
      if (err < minErr) {
        minErr = err;
        gainCrossoverW = w;
      }
    }

    // Phase at gain crossover frequency: PM = 180 + Phase(L(j*wc))
    const phaseAtWc = this.computeOpenLoopPhaseDeg(gainCrossoverW, kp, kd, ki);
    let pm = 180 + phaseAtWc;
    while (pm < -180) pm += 360;
    while (pm > 180) pm -= 360;

    // Phase crossover: Phase = -180 deg
    // For PID + 1/s^2, phase crossover occurs when Ki / w = Kd * w, i.e. w = sqrt(Ki / Kd)
    const phaseCrossoverW = Math.sqrt(d / Math.max(1e-4, b));
    const magAtPhaseCross = this.computeOpenLoopMagnitude(phaseCrossoverW, kp, kd, ki, inertia);
    const gmDb = magAtPhaseCross > 0 ? -20 * Math.log10(magAtPhaseCross) : 99;

    const allPolesStable = poles.every((p) => p.real < 0);
    const isStable = allPolesStable && pm > 0;

    return {
      gainMarginDb: Number(gmDb.toFixed(2)),
      phaseMarginDeg: Number(pm.toFixed(2)),
      gainCrossoverFreqRadS: Number(gainCrossoverW.toFixed(3)),
      phaseCrossoverFreqRadS: Number(phaseCrossoverW.toFixed(3)),
      dampingRatio: Number(zeta.toFixed(3)),
      naturalFreqRadS: Number(wn.toFixed(3)),
      estimatedSettlingTimeSec: Number(settlingTime.toFixed(1)),
      poles,
      isStable,
    };
  }

  static generateBodeData(
    kp: number,
    kd: number,
    ki: number,
    inertia: number,
    points = 60
  ): BodePoint[] {
    const data: BodePoint[] = [];
    const minDecade = -2; // 0.01 rad/s
    const maxDecade = 2; // 100 rad/s
    const step = (maxDecade - minDecade) / points;

    for (let dec = minDecade; dec <= maxDecade; dec += step) {
      const w = Math.pow(10, dec);
      const magLinear = this.computeOpenLoopMagnitude(w, kp, kd, ki, inertia);
      const magDb = 20 * Math.log10(Math.max(1e-6, magLinear));
      const phaseDeg = this.computeOpenLoopPhaseDeg(w, kp, kd, ki);

      data.push({
        freqRadS: w,
        freqHz: w / (2 * Math.PI),
        magDb: Math.max(-60, Math.min(80, magDb)),
        phaseDeg: Math.max(-270, Math.min(0, phaseDeg)),
      });
    }

    return data;
  }

  private static computeOpenLoopMagnitude(
    w: number,
    kp: number,
    kd: number,
    ki: number,
    inertia: number
  ): number {
    // Numerator: C(jw) = Kp + j(Kd*w - Ki/w)
    const realNum = kp;
    const imagNum = kd * w - ki / w;
    const numMag = Math.sqrt(realNum * realNum + imagNum * imagNum);

    // Denominator: G(jw)^-1 = I * w^2
    const denMag = inertia * w * w;
    return numMag / Math.max(1e-8, denMag);
  }

  private static computeOpenLoopPhaseDeg(w: number, kp: number, kd: number, ki: number): number {
    // C(jw) angle: atan2(Kd*w - Ki/w, Kp)
    const angleC = Math.atan2(kd * w - ki / w, kp);
    // G(jw) angle is -180 deg (due to 1 / (j*w)^2)
    const totalPhaseRad = angleC - Math.PI;
    let deg = (totalPhaseRad * 180) / Math.PI;
    if (deg > 0) deg -= 360;
    return deg;
  }

  private static solveCubic(
    a: number,
    b: number,
    c: number,
    d: number
  ): { real: number; imag: number }[] {
    // Normalize to x^3 + a1*x^2 + a2*x + a3 = 0
    const a1 = b / a;
    const a2 = c / a;
    const a3 = d / a;

    // Substitution x = y - a1/3
    const q = (3 * a2 - a1 * a1) / 9;
    const r = (9 * a1 * a2 - 27 * a3 - 2 * a1 * a1 * a1) / 54;
    const disc = q * q * q + r * r;

    const shift = -a1 / 3;

    if (disc > 0) {
      // 1 real root, 2 complex conjugates
      const s = Math.cbrt(r + Math.sqrt(disc));
      const t = Math.cbrt(r - Math.sqrt(disc));
      const r1 = shift + (s + t);
      const realPart = shift - (s + t) / 2;
      const imagPart = (Math.sqrt(3) / 2) * (s - t);

      return [
        { real: Number(r1.toFixed(3)), imag: 0 },
        { real: Number(realPart.toFixed(3)), imag: Number(imagPart.toFixed(3)) },
        { real: Number(realPart.toFixed(3)), imag: Number((-imagPart).toFixed(3)) },
      ];
    } else {
      // 3 real roots
      const theta = Math.acos(r / Math.sqrt(-q * q * q));
      const sqrtQ = 2 * Math.sqrt(-q);
      const r1 = shift + sqrtQ * Math.cos(theta / 3);
      const r2 = shift + sqrtQ * Math.cos((theta + 2 * Math.PI) / 3);
      const r3 = shift + sqrtQ * Math.cos((theta + 4 * Math.PI) / 3);

      return [
        { real: Number(r1.toFixed(3)), imag: 0 },
        { real: Number(r2.toFixed(3)), imag: 0 },
        { real: Number(r3.toFixed(3)), imag: 0 },
      ];
    }
  }
}
