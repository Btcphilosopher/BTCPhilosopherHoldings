import { OrbitalElements, ModelFidelity } from './spacecraft-types';

export const EARTH_MU = 398600.4418; // km^3/s^2
export const EARTH_RADIUS_KM = 6378.137; // km
export const EARTH_J2 = 1.08262668e-3;
export const SOLAR_PRESSURE_N_M2 = 4.56e-6; // N/m^2 at 1 AU
export const SPEED_OF_LIGHT = 299792458; // m/s

export interface OrbitStateVector {
  r: [number, number, number]; // km (ECI)
  v: [number, number, number]; // km/s (ECI)
}

export class OrbitalMechanics {
  /**
   * Converts Keplerian elements to Cartesian state vector (ECI)
   */
  static keplerianToState(elements: OrbitalElements): OrbitStateVector {
    const a = elements.semiMajorAxis;
    const e = elements.eccentricity;
    const i = (elements.inclination * Math.PI) / 180;
    const raan = (elements.raan * Math.PI) / 180;
    const argp = (elements.argOfPeriapsis * Math.PI) / 180;
    const nu = (elements.trueAnomaly * Math.PI) / 180;

    const p = a * (1 - e * e);
    const rMag = p / (1 + e * Math.cos(nu));

    // Perifocal coordinates
    const rPQW = [rMag * Math.cos(nu), rMag * Math.sin(nu), 0];
    const sqrtMuP = Math.sqrt(EARTH_MU / Math.max(1e-6, p));
    const vPQW = [-sqrtMuP * Math.sin(nu), sqrtMuP * (e + Math.cos(nu)), 0];

    // Rotation from PQW to ECI
    const cosO = Math.cos(raan);
    const sinO = Math.sin(raan);
    const cosi = Math.cos(i);
    const sini = Math.sin(i);
    const cosw = Math.cos(argp);
    const sinw = Math.sin(argp);

    const Px = cosO * cosw - sinO * sinw * cosi;
    const Py = sinO * cosw + cosO * sinw * cosi;
    const Pz = sinw * sini;

    const Qx = -cosO * sinw - sinO * cosw * cosi;
    const Qy = -sinO * sinw + cosO * cosw * cosi;
    const Qz = cosw * sini;

    const rEci: [number, number, number] = [
      rPQW[0] * Px + rPQW[1] * Qx,
      rPQW[0] * Py + rPQW[1] * Qy,
      rPQW[0] * Pz + rPQW[1] * Qz,
    ];

    const vEci: [number, number, number] = [
      vPQW[0] * Px + vPQW[1] * Qx,
      vPQW[0] * Py + vPQW[1] * Qy,
      vPQW[0] * Pz + vPQW[1] * Qz,
    ];

    return { r: rEci, v: vEci };
  }

  /**
   * Converts Cartesian state vector (ECI) to Keplerian elements
   */
  static stateToKeplerian(state: OrbitStateVector): OrbitalElements {
    const [rx, ry, rz] = state.r;
    const [vx, vy, vz] = state.v;
    const r = Math.sqrt(rx * rx + ry * ry + rz * rz);
    const v = Math.sqrt(vx * vx + vy * vy + vz * vz);

    // Specific angular momentum h = r x v
    const hx = ry * vz - rz * vy;
    const hy = rz * vx - rx * vz;
    const hz = rx * vy - ry * vx;
    const h = Math.sqrt(hx * hx + hy * hy + hz * hz);

    // Node vector n = k x h = [-hy, hx, 0]
    const n = Math.sqrt(hx * hx + hy * hy);

    // Eccentricity vector e = (1/mu) * ((v^2 - mu/r)r - (r.v)v)
    const rDotV = rx * vx + ry * vy + rz * vz;
    const v2MinusMuOverR = v * v - EARTH_MU / r;
    const ex = (v2MinusMuOverR * rx - rDotV * vx) / EARTH_MU;
    const ey = (v2MinusMuOverR * ry - rDotV * vy) / EARTH_MU;
    const ez = (v2MinusMuOverR * rz - rDotV * vz) / EARTH_MU;
    const e = Math.sqrt(ex * ex + ey * ey + ez * ez);

    // Specific mechanical energy epsilon = v^2/2 - mu/r
    const energy = (v * v) / 2 - EARTH_MU / r;
    const a = -EARTH_MU / (2 * energy);

    // Inclination
    const inc = Math.acos(Math.max(-1, Math.min(1, hz / h)));

    // RAAN
    let raan = 0;
    if (n > 1e-6) {
      raan = Math.acos(Math.max(-1, Math.min(1, -hy / n)));
      if (hx < 0) raan = 2 * Math.PI - raan;
    }

    // Argument of periapsis
    let argp = 0;
    if (n > 1e-6 && e > 1e-6) {
      const nDotE = -hy * ex + hx * ey;
      argp = Math.acos(Math.max(-1, Math.min(1, nDotE / (n * e))));
      if (ez < 0) argp = 2 * Math.PI - argp;
    }

    // True anomaly
    let nu = 0;
    if (e > 1e-6) {
      const eDotR = ex * rx + ey * ry + ez * rz;
      nu = Math.acos(Math.max(-1, Math.min(1, eDotR / (e * r))));
      if (rDotV < 0) nu = 2 * Math.PI - nu;
    }

    const periodSec = 2 * Math.PI * Math.sqrt(Math.pow(Math.abs(a), 3) / EARTH_MU);

    return {
      semiMajorAxis: a,
      eccentricity: e,
      inclination: (inc * 180) / Math.PI,
      raan: (raan * 180) / Math.PI,
      argOfPeriapsis: (argp * 180) / Math.PI,
      trueAnomaly: (nu * 180) / Math.PI,
      periodMinutes: periodSec / 60,
      altitudeKm: r - EARTH_RADIUS_KM,
    };
  }

  /**
   * Evaluates gravitational and perturbation acceleration in km/s^2
   */
  static getAcceleration(
    rEci: [number, number, number],
    vEci: [number, number, number],
    fidelity: ModelFidelity,
    massKg: number,
    dragAreaM2: number,
    cd: number
  ): [number, number, number] {
    const [x, y, z] = rEci;
    const r2 = x * x + y * y + z * z;
    const r = Math.sqrt(r2);
    const r3 = r2 * r;

    // Two-body central gravity
    const muOverR3 = EARTH_MU / r3;
    let ax = -muOverR3 * x;
    let ay = -muOverR3 * y;
    let az = -muOverR3 * z;

    if (fidelity === 'two-body') {
      return [ax, ay, az];
    }

    // J2 Oblateness Perturbation
    const reOverR2 = Math.pow(EARTH_RADIUS_KM / r, 2);
    const factorJ2 = (1.5 * EARTH_J2 * EARTH_MU * reOverR2) / r3;
    const z2OverR2 = (z * z) / r2;

    const axJ2 = factorJ2 * x * (5 * z2OverR2 - 1);
    const ayJ2 = factorJ2 * y * (5 * z2OverR2 - 1);
    const azJ2 = factorJ2 * z * (5 * z2OverR2 - 3);

    ax += axJ2;
    ay += ayJ2;
    az += azJ2;

    if (fidelity === 'j2-perturbed') {
      return [ax, ay, az];
    }

    // High fidelity: Atmospheric Drag + Solar Radiation Pressure
    const altitude = r - EARTH_RADIUS_KM;
    if (altitude > 100 && altitude < 800) {
      // Exponential atmospheric density model (kg/m^3)
      const h0 = 400; // km
      const rho0 = 3.72e-12; // kg/m^3
      const scaleHeight = 58.0; // km
      const rho = rho0 * Math.exp(-(altitude - h0) / scaleHeight);

      const vMagKmS = Math.sqrt(vEci[0] * vEci[0] + vEci[1] * vEci[1] + vEci[2] * vEci[2]);
      const vMagMS = vMagKmS * 1000;
      // Drag force: 0.5 * rho * v^2 * Cd * A in Newtons
      const fDragN = 0.5 * rho * vMagMS * vMagMS * cd * dragAreaM2;
      const aDragKmS2 = (fDragN / (massKg * 1000)); // convert m/s^2 to km/s^2

      ax -= aDragKmS2 * (vEci[0] / vMagKmS);
      ay -= aDragKmS2 * (vEci[1] / vMagKmS);
      az -= aDragKmS2 * (vEci[2] / vMagKmS);
    }

    // Solar Radiation Pressure acceleration (assuming Sun in direction [1, 0, 0] roughly)
    const sunUnit: [number, number, number] = [1, 0, 0];
    const srpForceN = SOLAR_PRESSURE_N_M2 * dragAreaM2 * 1.5; // with reflectivity
    const aSrpKmS2 = (srpForceN / (massKg * 1000));
    ax += aSrpKmS2 * sunUnit[0];
    ay += aSrpKmS2 * sunUnit[1];
    az += aSrpKmS2 * sunUnit[2];

    return [ax, ay, az];
  }

  /**
   * Runge-Kutta 4th Order Propagator Step
   */
  static stepRk4(
    state: OrbitStateVector,
    dt: number,
    fidelity: ModelFidelity,
    massKg: number,
    dragAreaM2: number,
    cd: number
  ): OrbitStateVector {
    const r0 = state.r;
    const v0 = state.v;

    // k1
    const a1 = this.getAcceleration(r0, v0, fidelity, massKg, dragAreaM2, cd);
    const dr1 = v0;
    const dv1 = a1;

    // k2
    const r_k2: [number, number, number] = [
      r0[0] + 0.5 * dt * dr1[0],
      r0[1] + 0.5 * dt * dr1[1],
      r0[2] + 0.5 * dt * dr1[2],
    ];
    const v_k2: [number, number, number] = [
      v0[0] + 0.5 * dt * dv1[0],
      v0[1] + 0.5 * dt * dv1[1],
      v0[2] + 0.5 * dt * dv1[2],
    ];
    const a2 = this.getAcceleration(r_k2, v_k2, fidelity, massKg, dragAreaM2, cd);
    const dr2 = v_k2;
    const dv2 = a2;

    // k3
    const r_k3: [number, number, number] = [
      r0[0] + 0.5 * dt * dr2[0],
      r0[1] + 0.5 * dt * dr2[1],
      r0[2] + 0.5 * dt * dr2[2],
    ];
    const v_k3: [number, number, number] = [
      v0[0] + 0.5 * dt * dv2[0],
      v0[1] + 0.5 * dt * dv2[1],
      v0[2] + 0.5 * dt * dv2[2],
    ];
    const a3 = this.getAcceleration(r_k3, v_k3, fidelity, massKg, dragAreaM2, cd);
    const dr3 = v_k3;
    const dv3 = a3;

    // k4
    const r_k4: [number, number, number] = [
      r0[0] + dt * dr3[0],
      r0[1] + dt * dr3[1],
      r0[2] + dt * dr3[2],
    ];
    const v_k4: [number, number, number] = [
      v0[0] + dt * dv3[0],
      v0[1] + dt * dv3[1],
      v0[2] + dt * dv3[2],
    ];
    const a4 = this.getAcceleration(r_k4, v_k4, fidelity, massKg, dragAreaM2, cd);
    const dr4 = v_k4;
    const dv4 = a4;

    const rNew: [number, number, number] = [
      r0[0] + (dt / 6) * (dr1[0] + 2 * dr2[0] + 2 * dr3[0] + dr4[0]),
      r0[1] + (dt / 6) * (dr1[1] + 2 * dr2[1] + 2 * dr3[1] + dr4[1]),
      r0[2] + (dt / 6) * (dr1[2] + 2 * dr2[2] + 2 * dr3[2] + dr4[2]),
    ];

    const vNew: [number, number, number] = [
      v0[0] + (dt / 6) * (dv1[0] + 2 * dv2[0] + 2 * dv3[0] + dv4[0]),
      v0[1] + (dt / 6) * (dv1[1] + 2 * dv2[1] + 2 * dv3[1] + dv4[1]),
      v0[2] + (dt / 6) * (dv1[2] + 2 * dv2[2] + 2 * dv3[2] + dv4[2]),
    ];

    return { r: rNew, v: vNew };
  }

  /**
   * Computes LVLH unit axes in ECI frame:
   * Z_LVLH = -r / ||r|| (Nadir)
   * Y_LVLH = -(r x v) / ||r x v|| (Opposite orbit angular momentum)
   * X_LVLH = Y_LVLH x Z_LVLH (Along-track in circular orbit)
   */
  static getLvlhFrame(state: OrbitStateVector): {
    xLvlh: [number, number, number];
    yLvlh: [number, number, number];
    zLvlh: [number, number, number];
  } {
    const [rx, ry, rz] = state.r;
    const [vx, vy, vz] = state.v;
    const rMag = Math.sqrt(rx * rx + ry * ry + rz * rz);

    // Z points to center of Earth (Nadir)
    const zLvlh: [number, number, number] = [-rx / rMag, -ry / rMag, -rz / rMag];

    // Angular momentum h = r x v
    const hx = ry * vz - rz * vy;
    const hy = rz * vx - rx * vz;
    const hz = rx * vy - ry * vx;
    const hMag = Math.sqrt(hx * hx + hy * hy + hz * hz);

    // Y points opposite orbit normal
    const yLvlh: [number, number, number] = [-hx / hMag, -hy / hMag, -hz / hMag];

    // X = Y x Z
    const xLvlh: [number, number, number] = [
      yLvlh[1] * zLvlh[2] - yLvlh[2] * zLvlh[1],
      yLvlh[2] * zLvlh[0] - yLvlh[0] * zLvlh[2],
      yLvlh[0] * zLvlh[1] - yLvlh[1] * zLvlh[0],
    ];

    return { xLvlh, yLvlh, zLvlh };
  }
}
