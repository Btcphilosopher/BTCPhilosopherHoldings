import {
  Quaternion,
  GuidanceMode,
  ReactionWheelState,
  MagnetorquerState,
} from './spacecraft-types';
import { AttitudeMath } from './attitude-dynamics';
import { OrbitalMechanics, OrbitStateVector, EARTH_MU } from './orbital-mechanics';

export class ControlAllocator {
  // 4-Wheel pyramid mounting configuration matrix A (3 rows, 4 columns)
  // Wheel axes unit vectors in Body frame
  static getPyramidAllocationMatrix(): number[][] {
    const beta = (54.7356 * Math.PI) / 180; // Pyramid elevation angle ~54.74 deg
    const cosB = Math.cos(beta);
    const sinB = Math.sin(beta);
    const phi = [Math.PI / 4, (3 * Math.PI) / 4, (5 * Math.PI) / 4, (7 * Math.PI) / 4];

    // A = [a1 a2 a3 a4]
    return [
      [cosB * Math.cos(phi[0]), cosB * Math.cos(phi[1]), cosB * Math.cos(phi[2]), cosB * Math.cos(phi[3])],
      [cosB * Math.sin(phi[0]), cosB * Math.sin(phi[1]), cosB * Math.sin(phi[2]), cosB * Math.sin(phi[3])],
      [sinB, sinB, sinB, sinB],
    ];
  }

  /**
   * Computes Moore-Penrose weighted pseudo-inverse:
   * A_pinv = W^-1 * A^T * (A * W^-1 * A^T)^-1
   * Where W is a 4x4 diagonal weighting matrix reflecting wheel health
   */
  static computeWeightedPseudoInverse(
    A: number[][],
    wheelHealth: [boolean, boolean, boolean, boolean]
  ): number[][] {
    // 3 rows, 4 columns
    const m = 3;
    const n = 4;

    // Weights: healthy = 1.0, failed = 1e-6 (near zero authority)
    const w = wheelHealth.map((h) => (h ? 1.0 : 1e-6));

    // A_W_inv = A * W^-1 (col j divided by w[j])
    // A_W_inv_AT = A * W^-1 * A^T (3x3 matrix)
    const M: number[][] = [
      [0, 0, 0],
      [0, 0, 0],
      [0, 0, 0],
    ];

    for (let i = 0; i < m; i++) {
      for (let j = 0; j < m; j++) {
        let sum = 0;
        for (let k = 0; k < n; k++) {
          sum += (A[i][k] * A[j][k]) * w[k];
        }
        M[i][j] = sum;
      }
    }

    // Invert 3x3 matrix M
    const Minv = this.invert3x3(M);

    // Pseudo-inverse: A_pinv = W * A^T * Minv  (4x3 matrix)
    const A_pinv: number[][] = [
      [0, 0, 0],
      [0, 0, 0],
      [0, 0, 0],
      [0, 0, 0],
    ];

    for (let i = 0; i < n; i++) {
      for (let j = 0; j < m; j++) {
        let sum = 0;
        for (let k = 0; k < m; k++) {
          sum += (A[k][i] * w[i]) * Minv[k][j];
        }
        A_pinv[i][j] = sum;
      }
    }

    return A_pinv;
  }

  private static invert3x3(A: number[][]): number[][] {
    const a = A[0][0], b = A[0][1], c = A[0][2];
    const d = A[1][0], e = A[1][1], f = A[1][2];
    const g = A[2][0], h = A[2][1], k = A[2][2];

    const det = a * (e * k - f * h) - b * (d * k - f * g) + c * (d * h - e * g);
    if (Math.abs(det) < 1e-12) {
      return [
        [1, 0, 0],
        [0, 1, 0],
        [0, 0, 1],
      ];
    }

    const invDet = 1.0 / det;
    return [
      [(e * k - f * h) * invDet, (c * h - b * k) * invDet, (b * f - c * e) * invDet],
      [(f * g - d * k) * invDet, (a * k - c * g) * invDet, (c * d - a * f) * invDet],
      [(d * h - e * g) * invDet, (g * b - a * h) * invDet, (a * e - b * d) * invDet],
    ];
  }

  /**
   * Allocates desired 3-axis torque to 4 reaction wheels
   * Includes nullspace projection for momentum management and actuator saturation
   */
  static allocateWheelTorques(
    tauReqNm: [number, number, number],
    wheels: ReactionWheelState[],
    A: number[][],
    A_pinv: number[][]
  ): {
    commandedWheelTorques: number[];
    actualWheelTorques: number[];
    realizedTorqueNm: [number, number, number];
    residualTorqueNm: [number, number, number];
  } {
    // Note: Spacecraft reaction torque = -A * u_wheels
    // So wheel torque desired is: u_w = -A_pinv * tauReq
    const targetWheelTorque: number[] = [0, 0, 0, 0];
    for (let i = 0; i < 4; i++) {
      targetWheelTorque[i] = -(
        A_pinv[i][0] * tauReqNm[0] +
        A_pinv[i][1] * tauReqNm[1] +
        A_pinv[i][2] * tauReqNm[2]
      );
    }

    // Nullspace projection: N = I - A_pinv * A
    // Momentum balance nullspace vector
    const meanMomentum =
      wheels.reduce((acc, w) => acc + w.momentumNms, 0) / 4;
    const kNull = 0.05; // Nullspace equalization gain

    const hDiff = wheels.map((w) => w.momentumNms - meanMomentum);
    const nullTorque = [0, 0, 0, 0];
    for (let i = 0; i < 4; i++) {
      let pinvA_h = 0;
      for (let j = 0; j < 4; j++) {
        const pinvA_ij =
          A_pinv[i][0] * A[0][j] +
          A_pinv[i][1] * A[1][j] +
          A_pinv[i][2] * A[2][j];
        pinvA_h += pinvA_ij * hDiff[j];
      }
      nullTorque[i] = -kNull * (hDiff[i] - pinvA_h);
    }

    const commanded: number[] = [0, 0, 0, 0];
    const actual: number[] = [0, 0, 0, 0];

    for (let i = 0; i < 4; i++) {
      const wheel = wheels[i];
      if (wheel.failed) {
        commanded[i] = 0;
        actual[i] = 0;
        continue;
      }

      commanded[i] = targetWheelTorque[i] + nullTorque[i];

      // Physical torque limits
      let uAct = Math.max(-wheel.maxTorqueNm, Math.min(wheel.maxTorqueNm, commanded[i]));

      // Momentum / speed saturation check
      if (
        (wheel.momentumNms >= wheel.maxMomentumNms && uAct > 0) ||
        (wheel.momentumNms <= -wheel.maxMomentumNms && uAct < 0)
      ) {
        uAct = 0; // Saturated wheel cannot accelerate further in that direction
      }

      actual[i] = uAct;
    }

    // Realized torque on spacecraft: tau_realized = -A * actual
    const realizedTorque: [number, number, number] = [0, 0, 0];
    for (let r = 0; r < 3; r++) {
      let sum = 0;
      for (let c = 0; c < 4; c++) {
        sum += A[r][c] * actual[c];
      }
      realizedTorque[r] = -sum;
    }

    const residual: [number, number, number] = [
      tauReqNm[0] - realizedTorque[0],
      tauReqNm[1] - realizedTorque[1],
      tauReqNm[2] - realizedTorque[2],
    ];

    return {
      commandedWheelTorques: commanded,
      actualWheelTorques: actual,
      realizedTorqueNm: realizedTorque,
      residualTorqueNm: residual,
    };
  }
}

export class GuidanceController {
  // PID Controller gains
  kp = 2.5; // Proportional gain (N*m / rad)
  kd = 4.2; // Derivative gain (N*m / (rad/s))
  ki = 0.08; // Integral gain (N*m / (rad*s))

  private integralError: [number, number, number] = [0, 0, 0];

  resetIntegral() {
    this.integralError = [0, 0, 0];
  }

  /**
   * Generates desired reference attitude quaternion and angular velocity
   */
  generateReference(
    mode: GuidanceMode,
    orbitState: OrbitStateVector
  ): { qDes: Quaternion; omegaDes: [number, number, number] } {
    switch (mode) {
      case 'sun-pointing': {
        // Point spacecraft +Z axis towards the Sun (assumed roughly +X in ECI for prototype)
        const qDes = AttitudeMath.eulerToQuaternion({ roll: 0, pitch: -90, yaw: 0 });
        return { qDes, omegaDes: [0, 0, 0] };
      }

      case 'earth-nadir': {
        // Body +Z points towards Earth center (-r/|r|), Body +X along velocity
        const lvlh = OrbitalMechanics.getLvlhFrame(orbitState);
        // Transform LVLH frame DCM to quaternion
        const R_lvlh_eci = [
          [lvlh.xLvlh[0], lvlh.yLvlh[0], lvlh.zLvlh[0]],
          [lvlh.xLvlh[1], lvlh.yLvlh[1], lvlh.zLvlh[1]],
          [lvlh.xLvlh[2], lvlh.yLvlh[2], lvlh.zLvlh[2]],
        ];
        const qDes = AttitudeMath.dcmToQuaternion(R_lvlh_eci);
        // Orbital mean motion rate approx 0.001 rad/s around orbit normal
        const rMag = Math.sqrt(
          orbitState.r[0] * orbitState.r[0] +
          orbitState.r[1] * orbitState.r[1] +
          orbitState.r[2] * orbitState.r[2]
        );
        const meanMotion = Math.sqrt(EARTH_MU / Math.pow(rMag, 3));
        return { qDes, omegaDes: [0, -meanMotion, 0] };
      }

      case 'velocity-ram': {
        // Body +X points in velocity vector
        const v = orbitState.v;
        const vMag = Math.sqrt(v[0] * v[0] + v[1] * v[1] + v[2] * v[2]);
        const yaw = (Math.atan2(v[1], v[0]) * 180) / Math.PI;
        const pitch = (-Math.asin(v[2] / vMag) * 180) / Math.PI;
        const qDes = AttitudeMath.eulerToQuaternion({ roll: 0, pitch, yaw });
        return { qDes, omegaDes: [0, 0, 0] };
      }

      case 'inertial-fixed':
      default: {
        const qDes = AttitudeMath.eulerToQuaternion({ roll: 0, pitch: 0, yaw: 0 });
        return { qDes, omegaDes: [0, 0, 0] };
      }
    }
  }

  /**
   * Computes commanded control torque using Quaternion Feedback PD / PID
   */
  computeControlTorque(
    dt: number,
    qEstimated: Quaternion,
    omegaEstimated: [number, number, number],
    qDes: Quaternion,
    omegaDes: [number, number, number]
  ): {
    tauReqNm: [number, number, number];
    errorQuaternion: Quaternion;
    rateError: [number, number, number];
  } {
    // Error quaternion: q_err = q_des^-1 * q_est
    const qErr = AttitudeMath.errorQuaternion(qEstimated, qDes);
    const signQ0 = qErr.q0 >= 0 ? 1.0 : -1.0;
    const qErrVec: [number, number, number] = [
      signQ0 * qErr.q1,
      signQ0 * qErr.q2,
      signQ0 * qErr.q3,
    ];

    // Rate error: omega_err = omega_est - omega_des
    const omegaErr: [number, number, number] = [
      omegaEstimated[0] - omegaDes[0],
      omegaEstimated[1] - omegaDes[1],
      omegaEstimated[2] - omegaDes[2],
    ];

    // Integral update with anti-windup clamp
    const maxInt = 0.5;
    this.integralError[0] = Math.max(-maxInt, Math.min(maxInt, this.integralError[0] + qErrVec[0] * dt));
    this.integralError[1] = Math.max(-maxInt, Math.min(maxInt, this.integralError[1] + qErrVec[1] * dt));
    this.integralError[2] = Math.max(-maxInt, Math.min(maxInt, this.integralError[2] + qErrVec[2] * dt));

    // Commanded torque: tau_req = -2*Kp*q_err - Kd*omega_err - Ki*int_err
    const tauReq: [number, number, number] = [
      -2 * this.kp * qErrVec[0] - this.kd * omegaErr[0] - this.ki * this.integralError[0],
      -2 * this.kp * qErrVec[1] - this.kd * omegaErr[1] - this.ki * this.integralError[1],
      -2 * this.kp * qErrVec[2] - this.kd * omegaErr[2] - this.ki * this.integralError[2],
    ];

    return {
      tauReqNm: tauReq,
      errorQuaternion: qErr,
      rateError: omegaErr,
    };
  }

  /**
   * Momentum desaturation via Magnetorquer cross-product law:
   * m_cmd = (k_dump / |B|^2) * (h_wheel x B)
   */
  computeMagnetorquerDump(
    wheelMomentumBody: [number, number, number],
    bFieldTesla: [number, number, number],
    maxDipoleAm2: number
  ): MagnetorquerState {
    const bMag = AttitudeMath.norm(bFieldTesla);
    if (bMag < 1e-9) {
      return {
        dipoleMomentAm2: [0, 0, 0],
        maxDipoleAm2,
        localFieldTesla: bFieldTesla,
        generatedTorqueNm: [0, 0, 0],
        active: false,
      };
    }

    const hMag = AttitudeMath.norm(wheelMomentumBody);
    const thresholdNms = 3.5; // Dump momentum if exceeds threshold

    if (hMag < thresholdNms) {
      return {
        dipoleMomentAm2: [0, 0, 0],
        maxDipoleAm2,
        localFieldTesla: bFieldTesla,
        generatedTorqueNm: [0, 0, 0],
        active: false,
      };
    }

    const kDump = 5.0e-3;
    // Cross product: h_wheel x B
    const hCrossB = AttitudeMath.crossProduct(wheelMomentumBody, bFieldTesla);
    const factor = kDump / (bMag * bMag);

    let mCmd: [number, number, number] = [
      hCrossB[0] * factor,
      hCrossB[1] * factor,
      hCrossB[2] * factor,
    ];

    // Saturate at max dipole moment
    mCmd = [
      Math.max(-maxDipoleAm2, Math.min(maxDipoleAm2, mCmd[0])),
      Math.max(-maxDipoleAm2, Math.min(maxDipoleAm2, mCmd[1])),
      Math.max(-maxDipoleAm2, Math.min(maxDipoleAm2, mCmd[2])),
    ];

    // Generated torque on spacecraft: tau_m = m x B
    const tauMag = AttitudeMath.crossProduct(mCmd, bFieldTesla);

    return {
      dipoleMomentAm2: mCmd,
      maxDipoleAm2,
      localFieldTesla: bFieldTesla,
      generatedTorqueNm: tauMag,
      active: true,
    };
  }
}
