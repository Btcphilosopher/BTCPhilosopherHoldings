import { Quaternion, EulerAngles, InertiaTensor } from './spacecraft-types';
import { EARTH_MU } from './orbital-mechanics';

export class AttitudeMath {
  /**
   * Normalizes a quaternion to unit length
   */
  static normalizeQuaternion(q: Quaternion): Quaternion {
    const norm = Math.sqrt(q.q0 * q.q0 + q.q1 * q.q1 + q.q2 * q.q2 + q.q3 * q.q3);
    if (norm < 1e-12) {
      return { q0: 1, q1: 0, q2: 0, q3: 0, frame: q.frame };
    }
    return {
      q0: q.q0 / norm,
      q1: q.q1 / norm,
      q2: q.q2 / norm,
      q3: q.q3 / norm,
      frame: q.frame,
    };
  }

  /**
   * Quaternion multiplication (Hamilton convention): q = p * q
   */
  static multiplyQuaternions(p: Quaternion, q: Quaternion): Quaternion {
    return {
      q0: p.q0 * q.q0 - p.q1 * q.q1 - p.q2 * q.q2 - p.q3 * q.q3,
      q1: p.q0 * q.q1 + p.q1 * q.q0 + p.q2 * q.q3 - p.q3 * q.q2,
      q2: p.q0 * q.q2 - p.q1 * q.q3 + p.q2 * q.q0 + p.q3 * q.q1,
      q3: p.q0 * q.q3 + p.q1 * q.q2 - p.q2 * q.q1 + p.q3 * q.q0,
      frame: q.frame,
    };
  }

  /**
   * Quaternion conjugate (inverse for unit quaternion)
   */
  static conjugate(q: Quaternion): Quaternion {
    return {
      q0: q.q0,
      q1: -q.q1,
      q2: -q.q2,
      q3: -q.q3,
      frame: q.frame,
    };
  }

  /**
   * Computes error quaternion between current q and desired q_des:
   * q_err = q_des^-1 * q
   */
  static errorQuaternion(qCurrent: Quaternion, qDes: Quaternion): Quaternion {
    const qDesInv = this.conjugate(qDes);
    const qErr = this.multiplyQuaternions(qDesInv, qCurrent);
    return this.normalizeQuaternion(qErr);
  }

  /**
   * Converts Quaternion to Direction Cosine Matrix (3x3 array)
   * Transforms vector from Inertial/Reference frame to Body frame: v_b = DCM * v_i
   */
  static quaternionToDcm(q: Quaternion): number[][] {
    const { q0, q1, q2, q3 } = q;
    return [
      [
        1 - 2 * (q2 * q2 + q3 * q3),
        2 * (q1 * q2 + q0 * q3),
        2 * (q1 * q3 - q0 * q2),
      ],
      [
        2 * (q1 * q2 - q0 * q3),
        1 - 2 * (q1 * q1 + q3 * q3),
        2 * (q2 * q3 + q0 * q1),
      ],
      [
        2 * (q1 * q3 + q0 * q2),
        2 * (q2 * q3 - q0 * q1),
        1 - 2 * (q1 * q1 + q2 * q2),
      ],
    ];
  }

  /**
   * Converts DCM to Quaternion (Shepperd's method)
   */
  static dcmToQuaternion(R: number[][]): Quaternion {
    const tr = R[0][0] + R[1][1] + R[2][2];
    let q0: number, q1: number, q2: number, q3: number;

    if (tr > 0) {
      const s = 0.5 / Math.sqrt(tr + 1.0);
      q0 = 0.25 / s;
      q1 = (R[1][2] - R[2][1]) * s;
      q2 = (R[2][0] - R[0][2]) * s;
      q3 = (R[0][1] - R[1][0]) * s;
    } else if (R[0][0] > R[1][1] && R[0][0] > R[2][2]) {
      const s = 2.0 * Math.sqrt(1.0 + R[0][0] - R[1][1] - R[2][2]);
      q0 = (R[1][2] - R[2][1]) / s;
      q1 = 0.25 * s;
      q2 = (R[0][1] + R[1][0]) / s;
      q3 = (R[0][2] + R[2][0]) / s;
    } else if (R[1][1] > R[2][2]) {
      const s = 2.0 * Math.sqrt(1.0 + R[1][1] - R[0][0] - R[2][2]);
      q0 = (R[2][0] - R[0][2]) / s;
      q1 = (R[0][1] + R[1][0]) / s;
      q2 = 0.25 * s;
      q3 = (R[1][2] + R[2][1]) / s;
    } else {
      const s = 2.0 * Math.sqrt(1.0 + R[2][2] - R[0][0] - R[1][1]);
      q0 = (R[0][1] - R[1][0]) / s;
      q1 = (R[0][2] + R[2][0]) / s;
      q2 = (R[1][2] + R[2][1]) / s;
      q3 = 0.25 * s;
    }

    return this.normalizeQuaternion({ q0, q1, q2, q3, frame: 'Body' });
  }

  /**
   * Converts Quaternion to Euler angles (Roll, Pitch, Yaw in degrees)
   */
  static quaternionToEuler(q: Quaternion): EulerAngles {
    const { q0, q1, q2, q3 } = q;

    // Roll (x-axis rotation)
    const sinr_cosp = 2 * (q0 * q1 + q2 * q3);
    const cosr_cosp = 1 - 2 * (q1 * q1 + q2 * q2);
    const roll = Math.atan2(sinr_cosp, cosr_cosp);

    // Pitch (y-axis rotation)
    const sinp = 2 * (q0 * q2 - q3 * q1);
    let pitch: number;
    if (Math.abs(sinp) >= 1) {
      pitch = (Math.sign(sinp) * Math.PI) / 2; // use 90 degrees if out of range
    } else {
      pitch = Math.asin(sinp);
    }

    // Yaw (z-axis rotation)
    const siny_cosp = 2 * (q0 * q3 + q1 * q2);
    const cosy_cosp = 1 - 2 * (q2 * q2 + q3 * q3);
    const yaw = Math.atan2(siny_cosp, cosy_cosp);

    return {
      roll: (roll * 180) / Math.PI,
      pitch: (pitch * 180) / Math.PI,
      yaw: (yaw * 180) / Math.PI,
    };
  }

  /**
   * Converts Euler angles (deg) to Quaternion
   */
  static eulerToQuaternion(euler: EulerAngles): Quaternion {
    const roll = (euler.roll * Math.PI) / 180;
    const pitch = (euler.pitch * Math.PI) / 180;
    const yaw = (euler.yaw * Math.PI) / 180;

    const cr = Math.cos(roll * 0.5);
    const sr = Math.sin(roll * 0.5);
    const cp = Math.cos(pitch * 0.5);
    const sp = Math.sin(pitch * 0.5);
    const cy = Math.cos(yaw * 0.5);
    const sy = Math.sin(yaw * 0.5);

    const q0 = cr * cp * cy + sr * sp * sy;
    const q1 = sr * cp * cy - cr * sp * sy;
    const q2 = cr * sp * cy + sr * cp * sy;
    const q3 = cr * cp * sy - sr * sp * cy;

    return this.normalizeQuaternion({ q0, q1, q2, q3, frame: 'Body' });
  }

  /**
   * Rotate a 3D vector by DCM: v_out = DCM * v_in
   */
  static rotateVector(dcm: number[][], v: [number, number, number]): [number, number, number] {
    return [
      dcm[0][0] * v[0] + dcm[0][1] * v[1] + dcm[0][2] * v[2],
      dcm[1][0] * v[0] + dcm[1][1] * v[1] + dcm[1][2] * v[2],
      dcm[2][0] * v[0] + dcm[2][1] * v[1] + dcm[2][2] * v[2],
    ];
  }

  /**
   * Cross product of two 3D vectors
   */
  static crossProduct(a: [number, number, number], b: [number, number, number]): [number, number, number] {
    return [
      a[1] * b[2] - a[2] * b[1],
      a[2] * b[0] - a[0] * b[2],
      a[0] * b[1] - a[1] * b[0],
    ];
  }

  /**
   * Dot product
   */
  static dotProduct(a: [number, number, number], b: [number, number, number]): number {
    return a[0] * b[0] + a[1] * b[1] + a[2] * b[2];
  }

  /**
   * Vector norm
   */
  static norm(v: [number, number, number]): number {
    return Math.sqrt(v[0] * v[0] + v[1] * v[1] + v[2] * v[2]);
  }
}

export class AttitudeDynamics {
  /**
   * Computes angular acceleration:
   * I * omega_dot + omega x (I * omega + h_wheel) = tau_total
   * omega_dot = I^-1 * (tau_total - omega x (I * omega + h_wheel))
   */
  static getAngularAcceleration(
    omega: [number, number, number],
    hWheelBody: [number, number, number],
    tauTotalBody: [number, number, number],
    inertia: InertiaTensor
  ): [number, number, number] {
    // Spacecraft body angular momentum: H_sc = I * omega
    const H_sc: [number, number, number] = [
      inertia.ixx * omega[0] + inertia.ixy * omega[1] + inertia.ixz * omega[2],
      inertia.ixy * omega[0] + inertia.iyy * omega[1] + inertia.iyz * omega[2],
      inertia.ixz * omega[0] + inertia.iyz * omega[1] + inertia.izz * omega[2],
    ];

    // Total angular momentum in body frame: H_tot = H_sc + h_wheel
    const H_tot: [number, number, number] = [
      H_sc[0] + hWheelBody[0],
      H_sc[1] + hWheelBody[1],
      H_sc[2] + hWheelBody[2],
    ];

    // Gyroscopic coupling: omega x H_tot
    const gyroTorque = AttitudeMath.crossProduct(omega, H_tot);

    // Net torque applied to spacecraft rigid body
    const netTorque: [number, number, number] = [
      tauTotalBody[0] - gyroTorque[0],
      tauTotalBody[1] - gyroTorque[1],
      tauTotalBody[2] - gyroTorque[2],
    ];

    // For principal axes (or near-principal with small cross terms)
    // Invert inertia tensor 3x3
    const Iinv = this.invertInertia(inertia);

    return [
      Iinv[0][0] * netTorque[0] + Iinv[0][1] * netTorque[1] + Iinv[0][2] * netTorque[2],
      Iinv[1][0] * netTorque[0] + Iinv[1][1] * netTorque[1] + Iinv[1][2] * netTorque[2],
      Iinv[2][0] * netTorque[0] + Iinv[2][1] * netTorque[1] + Iinv[2][2] * netTorque[2],
    ];
  }

  private static invertInertia(I: InertiaTensor): number[][] {
    const a = I.ixx, b = I.ixy, c = I.ixz;
    const d = I.ixy, e = I.iyy, f = I.iyz;
    const g = I.ixz, h = I.iyz, k = I.izz;

    const det = a * (e * k - f * h) - b * (d * k - f * g) + c * (d * h - e * g);
    if (Math.abs(det) < 1e-9) {
      return [
        [1 / Math.max(1e-3, a), 0, 0],
        [0, 1 / Math.max(1e-3, e), 0],
        [0, 0, 1 / Math.max(1e-3, k)],
      ];
    }

    const invDet = 1 / det;
    return [
      [(e * k - f * h) * invDet, (c * h - b * k) * invDet, (b * f - c * e) * invDet],
      [(f * g - d * k) * invDet, (a * k - c * g) * invDet, (c * d - a * f) * invDet],
      [(d * h - e * g) * invDet, (g * b - a * h) * invDet, (a * e - b * d) * invDet],
    ];
  }

  /**
   * Quaternion derivative:
   * q_dot = 0.5 * q * [0, omega]
   */
  static getQuaternionDerivative(q: Quaternion, omega: [number, number, number]): [number, number, number, number] {
    const q0 = q.q0, q1 = q.q1, q2 = q.q2, q3 = q.q3;
    const [wx, wy, wz] = omega;

    return [
      0.5 * (-q1 * wx - q2 * wy - q3 * wz),
      0.5 * (q0 * wx + q2 * wz - q3 * wy),
      0.5 * (q0 * wy - q1 * wz + q3 * wx),
      0.5 * (q0 * wz + q1 * wy - q2 * wx),
    ];
  }

  /**
   * Computes environmental disturbance torques:
   * 1. Gravity Gradient: tau_gg = (3*mu/R^3) * u_r x (I * u_r)
   * 2. Solar Radiation Pressure
   * 3. Atmospheric Drag
   * 4. Residual Dipole: tau_dip = m_res x B_local
   */
  static calculateDisturbances(
    rEciKm: [number, number, number],
    dcmEciToBody: number[][],
    inertia: InertiaTensor,
    options: {
      gravityGradient: boolean;
      solarPressure: boolean;
      atmosphericDrag: boolean;
      residualDipole: boolean;
    },
    residualDipoleAm2: [number, number, number]
  ): {
    gravityGradient: [number, number, number];
    solarPressure: [number, number, number];
    atmosphericDrag: [number, number, number];
    residualDipole: [number, number, number];
    total: [number, number, number];
  } {
    const rMagKm = AttitudeMath.norm(rEciKm);
    const rUnitEci: [number, number, number] = [
      rEciKm[0] / rMagKm,
      rEciKm[1] / rMagKm,
      rEciKm[2] / rMagKm,
    ];

    // r unit vector in body frame: u_rb = DCM * u_reci
    const u_rb = AttitudeMath.rotateVector(dcmEciToBody, rUnitEci);

    // 1. Gravity Gradient
    let tau_gg: [number, number, number] = [0, 0, 0];
    if (options.gravityGradient) {
      // mu in km^3/s^2, r in km: 3 * mu / r^3 has unit s^-2
      const rMeters = rMagKm * 1000;
      const muM3S2 = EARTH_MU * 1e9;
      const factorGg = (3 * muM3S2) / Math.pow(rMeters, 3);

      const I_urb: [number, number, number] = [
        inertia.ixx * u_rb[0] + inertia.ixy * u_rb[1] + inertia.ixz * u_rb[2],
        inertia.ixy * u_rb[0] + inertia.iyy * u_rb[1] + inertia.iyz * u_rb[2],
        inertia.ixz * u_rb[0] + inertia.iyz * u_rb[1] + inertia.izz * u_rb[2],
      ];

      tau_gg = AttitudeMath.crossProduct(u_rb, I_urb).map((val) => val * factorGg) as [number, number, number];
    }

    // 2. Solar Radiation Pressure torque (subtle cyclic disturbance, ~1e-5 Nm)
    let tau_srp: [number, number, number] = [0, 0, 0];
    if (options.solarPressure) {
      const sunUnitEci: [number, number, number] = [1, 0, 0];
      const sunUnitBody = AttitudeMath.rotateVector(dcmEciToBody, sunUnitEci);
      // Center of pressure offset approx [0.05, 0.02, -0.01] m, force approx 1.2e-4 N
      const cpOffset: [number, number, number] = [0.04, 0.02, -0.01];
      const fSrpBody: [number, number, number] = [
        -sunUnitBody[0] * 1.5e-4,
        -sunUnitBody[1] * 1.5e-4,
        -sunUnitBody[2] * 1.5e-4,
      ];
      tau_srp = AttitudeMath.crossProduct(cpOffset, fSrpBody);
    }

    // 3. Atmospheric drag torque (predominant at low orbits)
    let tau_drag: [number, number, number] = [0, 0, 0];
    if (options.atmosphericDrag) {
      const altitude = rMagKm - 6378.137;
      if (altitude < 600) {
        const dragScale = Math.exp(-(altitude - 300) / 60) * 1e-4;
        tau_drag = [
          -dragScale * 0.3 * Math.sin(rMagKm),
          dragScale * 0.5 * Math.cos(rMagKm),
          -dragScale * 0.2,
        ];
      }
    }

    // 4. Residual Magnetic Dipole torque: tau = m x B
    // Earth magnetic dipole approx 30 microTesla at LEO
    let tau_dipole: [number, number, number] = [0, 0, 0];
    if (options.residualDipole) {
      const bFieldTesla: [number, number, number] = [
        30e-6 * Math.cos(rEciKm[0] / 1000),
        -15e-6 * Math.sin(rEciKm[1] / 1000),
        40e-6,
      ];
      const bFieldBody = AttitudeMath.rotateVector(dcmEciToBody, bFieldTesla);
      tau_dipole = AttitudeMath.crossProduct(residualDipoleAm2, bFieldBody);
    }

    const total: [number, number, number] = [
      tau_gg[0] + tau_srp[0] + tau_drag[0] + tau_dipole[0],
      tau_gg[1] + tau_srp[1] + tau_drag[1] + tau_dipole[1],
      tau_gg[2] + tau_srp[2] + tau_drag[2] + tau_dipole[2],
    ];

    return {
      gravityGradient: tau_gg,
      solarPressure: tau_srp,
      atmosphericDrag: tau_drag,
      residualDipole: tau_dipole,
      total,
    };
  }
}
