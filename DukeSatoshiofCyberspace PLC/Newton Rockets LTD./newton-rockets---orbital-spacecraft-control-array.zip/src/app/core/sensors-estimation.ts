import { Quaternion, SensorSuiteState, EstimatorState } from './spacecraft-types';
import { AttitudeMath, AttitudeDynamics } from './attitude-dynamics';

export class SensorModels {
  // Sensor intrinsic noise and bias parameters
  static gyroBiasTrue: [number, number, number] = [0.0012, -0.0008, 0.0005]; // rad/s
  static gyroNoiseSigma = 0.0002; // rad/s
  static starTrackerNoiseSigma = 0.00015; // rad (approx 30 arcsec)
  static sunSensorNoiseSigma = 0.002; // rad
  static magnetometerNoiseSigma = 0.5; // microTesla
  static magnetometerBias: [number, number, number] = [0.8, -0.4, 0.6]; // microTesla
  static accelNoiseSigma = 0.005; // m/s^2

  /**
   * Generates Gaussian white noise
   */
  static gaussianNoise(mean = 0, stdDev = 1): number {
    const u1 = Math.max(1e-12, Math.random());
    const u2 = Math.random();
    return mean + stdDev * Math.sqrt(-2.0 * Math.log(u1)) * Math.cos(2.0 * Math.PI * u2);
  }

  /**
   * Simulates full sensor suite readings
   */
  static sampleSensors(
    trueAttitude: Quaternion,
    trueOmega: [number, number, number],
    sunVectorBody: [number, number, number],
    bFieldBodyMicroTesla: [number, number, number],
    specificForceBody: [number, number, number],
    faults: {
      starTrackerBlinded?: boolean;
      gyroBiasJump?: boolean;
      magnetometerCorrupt?: boolean;
    }
  ): SensorSuiteState {
    // 1. Gyroscope
    const currentBias: [number, number, number] = faults.gyroBiasJump
      ? [this.gyroBiasTrue[0] + 0.02, this.gyroBiasTrue[1] - 0.015, this.gyroBiasTrue[2] + 0.01]
      : this.gyroBiasTrue;

    const gyroMeas: [number, number, number] = [
      trueOmega[0] + currentBias[0] + this.gaussianNoise(0, this.gyroNoiseSigma),
      trueOmega[1] + currentBias[1] + this.gaussianNoise(0, this.gyroNoiseSigma),
      trueOmega[2] + currentBias[2] + this.gaussianNoise(0, this.gyroNoiseSigma),
    ];

    const gyroError: [number, number, number] = [
      gyroMeas[0] - trueOmega[0],
      gyroMeas[1] - trueOmega[1],
      gyroMeas[2] - trueOmega[2],
    ];

    // 2. Star Tracker
    const starTrackerOccluded = faults.starTrackerBlinded ?? false;
    let starTrackerMeas: [number, number, number, number] = [
      trueAttitude.q0,
      trueAttitude.q1,
      trueAttitude.q2,
      trueAttitude.q3,
    ];

    if (!starTrackerOccluded) {
      // Perturb true quaternion with small random angle rotation
      const dTheta = [
        this.gaussianNoise(0, this.starTrackerNoiseSigma),
        this.gaussianNoise(0, this.starTrackerNoiseSigma),
        this.gaussianNoise(0, this.starTrackerNoiseSigma),
      ];
      const dq: Quaternion = {
        q0: 1,
        q1: 0.5 * dTheta[0],
        q2: 0.5 * dTheta[1],
        q3: 0.5 * dTheta[2],
        frame: 'Body',
      };
      const noisyQ = AttitudeMath.normalizeQuaternion(
        AttitudeMath.multiplyQuaternions(trueAttitude, dq)
      );
      starTrackerMeas = [noisyQ.q0, noisyQ.q1, noisyQ.q2, noisyQ.q3];
    }

    const starTrackerError: [number, number, number, number] = [
      starTrackerMeas[0] - trueAttitude.q0,
      starTrackerMeas[1] - trueAttitude.q1,
      starTrackerMeas[2] - trueAttitude.q2,
      starTrackerMeas[3] - trueAttitude.q3,
    ];

    // 3. Sun Sensor (sun visible if z-component or sun angle favorable)
    const sunVisible = sunVectorBody[0] > -0.2; // FOV check
    const sunMeas: [number, number, number] = sunVisible
      ? [
          sunVectorBody[0] + this.gaussianNoise(0, this.sunSensorNoiseSigma),
          sunVectorBody[1] + this.gaussianNoise(0, this.sunSensorNoiseSigma),
          sunVectorBody[2] + this.gaussianNoise(0, this.sunSensorNoiseSigma),
        ]
      : [0, 0, 0];

    const sunError: [number, number, number] = [
      sunMeas[0] - sunVectorBody[0],
      sunMeas[1] - sunVectorBody[1],
      sunMeas[2] - sunVectorBody[2],
    ];

    // 4. Magnetometer
    const magScale = faults.magnetometerCorrupt ? 3.0 : 1.0;
    const magMeas: [number, number, number] = [
      (bFieldBodyMicroTesla[0] + this.magnetometerBias[0] + this.gaussianNoise(0, this.magnetometerNoiseSigma)) * magScale,
      (bFieldBodyMicroTesla[1] + this.magnetometerBias[1] + this.gaussianNoise(0, this.magnetometerNoiseSigma)) * magScale,
      (bFieldBodyMicroTesla[2] + this.magnetometerBias[2] + this.gaussianNoise(0, this.magnetometerNoiseSigma)) * magScale,
    ];

    const magError: [number, number, number] = [
      magMeas[0] - bFieldBodyMicroTesla[0],
      magMeas[1] - bFieldBodyMicroTesla[1],
      magMeas[2] - bFieldBodyMicroTesla[2],
    ];

    // 5. Accelerometer
    const accelMeas: [number, number, number] = [
      specificForceBody[0] + this.gaussianNoise(0, this.accelNoiseSigma),
      specificForceBody[1] + this.gaussianNoise(0, this.accelNoiseSigma),
      specificForceBody[2] + this.gaussianNoise(0, this.accelNoiseSigma),
    ];

    return {
      gyro: {
        truth: trueOmega,
        measured: gyroMeas,
        error: gyroError,
        uncertainty3Sigma: this.gyroNoiseSigma * 3,
        healthy: true,
      },
      starTracker: {
        truth: [trueAttitude.q0, trueAttitude.q1, trueAttitude.q2, trueAttitude.q3],
        measured: starTrackerMeas,
        error: starTrackerError,
        uncertainty3Sigma: this.starTrackerNoiseSigma * 3,
        healthy: !starTrackerOccluded,
      },
      sunSensor: {
        truth: sunVectorBody,
        measured: sunMeas,
        error: sunError,
        uncertainty3Sigma: this.sunSensorNoiseSigma * 3,
        healthy: sunVisible,
      },
      magnetometer: {
        truth: bFieldBodyMicroTesla,
        measured: magMeas,
        error: magError,
        uncertainty3Sigma: this.magnetometerNoiseSigma * 3,
        healthy: !faults.magnetometerCorrupt,
      },
      accelerometer: {
        truth: specificForceBody,
        measured: accelMeas,
        error: [
          accelMeas[0] - specificForceBody[0],
          accelMeas[1] - specificForceBody[1],
          accelMeas[2] - specificForceBody[2],
        ],
        uncertainty3Sigma: this.accelNoiseSigma * 3,
        healthy: true,
      },
      sunVisible,
      starTrackerOccluded,
    };
  }
}

export class MultiplicativeEKF {
  // Estimated reference attitude
  qHat: Quaternion = { q0: 1, q1: 0, q2: 0, q3: 0, frame: 'Body' };
  // Estimated gyro bias (rad/s)
  biasHat: [number, number, number] = [0, 0, 0];
  // 6x6 Covariance matrix (diagonal elements)
  // [dtheta_x, dtheta_y, dtheta_z, dbias_x, dbias_y, dbias_z]
  P: number[] = [1e-4, 1e-4, 1e-4, 1e-6, 1e-6, 1e-6];

  // Process noise Q
  Q_theta = 1e-6;
  Q_bias = 1e-9;
  // Measurement noise R
  R_st = 1e-6;

  reset(qInitial: Quaternion) {
    this.qHat = { ...qInitial };
    this.biasHat = [0, 0, 0];
    this.P = [1e-3, 1e-3, 1e-3, 1e-5, 1e-5, 1e-5];
  }

  /**
   * MEKF Step: Time propagation using gyro + measurement update using Star Tracker
   */
  step(
    dt: number,
    gyroMeas: [number, number, number],
    starTrackerMeas: [number, number, number, number] | null,
    starTrackerHealthy: boolean,
    trueAttitude: Quaternion,
    trueOmega: [number, number, number]
  ): EstimatorState {
    // 1. Unbiased rate estimate
    const omegaHat: [number, number, number] = [
      gyroMeas[0] - this.biasHat[0],
      gyroMeas[1] - this.biasHat[1],
      gyroMeas[2] - this.biasHat[2],
    ];

    // 2. Propagate attitude quaternion
    const qDot = AttitudeDynamics.getQuaternionDerivative(this.qHat, omegaHat);
    this.qHat = AttitudeMath.normalizeQuaternion({
      q0: this.qHat.q0 + qDot[0] * dt,
      q1: this.qHat.q1 + qDot[1] * dt,
      q2: this.qHat.q2 + qDot[2] * dt,
      q3: this.qHat.q3 + qDot[3] * dt,
      frame: 'Body',
    });

    // 3. Propagate Covariance (simple diagonal discrete approximation)
    for (let i = 0; i < 3; i++) {
      this.P[i] += this.Q_theta * dt + this.P[i + 3] * dt * dt;
      this.P[i + 3] += this.Q_bias * dt;
    }

    let innovation = 0;

    // 4. Measurement Update if Star Tracker available and healthy
    if (starTrackerHealthy && starTrackerMeas) {
      const qMeas: Quaternion = {
        q0: starTrackerMeas[0],
        q1: starTrackerMeas[1],
        q2: starTrackerMeas[2],
        q3: starTrackerMeas[3],
        frame: 'Body',
      };

      // Error quaternion between measurement and estimate: q_err = qHat^-1 * qMeas
      const qErr = AttitudeMath.errorQuaternion(qMeas, this.qHat);
      // Small angle residual: dtheta = 2 * [q1, q2, q3] / q0
      const signQ0 = qErr.q0 >= 0 ? 1 : -1;
      const res: [number, number, number] = [
        2 * signQ0 * qErr.q1,
        2 * signQ0 * qErr.q2,
        2 * signQ0 * qErr.q3,
      ];

      innovation = Math.sqrt(res[0] * res[0] + res[1] * res[1] + res[2] * res[2]);

      // Kalman Gain for angle states: K_theta = P_theta / (P_theta + R)
      for (let i = 0; i < 3; i++) {
        const S = this.P[i] + this.R_st;
        const K_theta = this.P[i] / S;
        const K_bias = (0.05 * this.P[i + 3]) / S;

        // Angle correction
        const dAngle = K_theta * res[i];
        // Bias correction
        this.biasHat[i] -= K_bias * res[i];

        // Update attitude estimate with small angle rotation
        const dq: Quaternion = {
          q0: 1,
          q1: 0.5 * (i === 0 ? dAngle : 0),
          q2: 0.5 * (i === 1 ? dAngle : 0),
          q3: 0.5 * (i === 2 ? dAngle : 0),
          frame: 'Body',
        };
        this.qHat = AttitudeMath.normalizeQuaternion(
          AttitudeMath.multiplyQuaternions(this.qHat, dq)
        );

        // Update covariance
        this.P[i] = Math.max(1e-8, (1 - K_theta) * this.P[i]);
        this.P[i + 3] = Math.max(1e-10, (1 - K_bias) * this.P[i + 3]);
      }
    } else {
      // Coasting without star tracker: covariance grows linearly
      for (let i = 0; i < 3; i++) {
        this.P[i] = Math.min(0.05, this.P[i] + 1e-5 * dt);
      }
    }

    // 5. Calculate error with respect to TRUE state for verification
    const qErrTrue = AttitudeMath.errorQuaternion(trueAttitude, this.qHat);
    const signTrue = qErrTrue.q0 >= 0 ? 1 : -1;
    const attErrDeg: [number, number, number] = [
      ((2 * signTrue * qErrTrue.q1) * 180) / Math.PI,
      ((2 * signTrue * qErrTrue.q2) * 180) / Math.PI,
      ((2 * signTrue * qErrTrue.q3) * 180) / Math.PI,
    ];

    const rateErrDegS: [number, number, number] = [
      ((omegaHat[0] - trueOmega[0]) * 180) / Math.PI,
      ((omegaHat[1] - trueOmega[1]) * 180) / Math.PI,
      ((omegaHat[2] - trueOmega[2]) * 180) / Math.PI,
    ];

    // 3-Sigma bounds in degrees
    const sigma3Bounds: [number, number, number] = [
      (3 * Math.sqrt(this.P[0]) * 180) / Math.PI,
      (3 * Math.sqrt(this.P[1]) * 180) / Math.PI,
      (3 * Math.sqrt(this.P[2]) * 180) / Math.PI,
    ];

    return {
      estimatedAttitude: { ...this.qHat },
      estimatedAngularVelocity: omegaHat,
      gyroBiasEstimate: [...this.biasHat],
      attitudeErrorDeg: attErrDeg,
      rateErrorDegPerSec: rateErrDegS,
      covarianceDiagonal: [...this.P],
      sigma3Bounds,
      innovationResidual: innovation,
      converged: this.P[0] < 5e-4,
    };
  }
}
