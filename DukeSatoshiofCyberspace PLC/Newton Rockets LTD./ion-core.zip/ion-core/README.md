# ION-CORE

**An engineering-system-level physics simulator of a gridded electrostatic ion engine.**

ION-CORE simulates the ion engine itself — propellant flow, ionisation, plasma, extraction, electrostatic
acceleration, beam, neutralisation, thrust — together with the electrical chain that feeds it (DC bus → PPU →
discharge / grids / neutraliser) and the heat it generates. It is not a spacecraft, orbit or mission simulator.

> **The physics is the product.** There is no hard-coded thrust and no fake telemetry. Every displayed value
> is produced by the numerical model, and the console shows the model path next to each number.

> **All engineering parameters shipped here are DEMONSTRATION values** (loosely of the 30 cm gridded-ion-thruster
> class so magnitudes are plausible). They are not data from any real engine, and the model has **not** been
> validated against thruster test data. See [docs/PHYSICS.md](docs/PHYSICS.md) for what is and is not modelled.

## Install and run

```bash
pip install -e ".[dev]"          # Python 3.12+

ion-core steady-state scenarios/xenon_ion_engine.yaml --report
ion-core transient    scenarios/startup_shutdown.yaml  -f h5 --report
ion-core sweep        scenarios/parametric_sweeps.yaml -f json,csv,h5
ion-core validate                                     # exit status 1 on any failure
ion-core report results/<run>.h5                      # HTML engineering report from an exported result
ion-core console                                      # Plotly engineering console -> http://127.0.0.1:8050
```

Also: `ion-core run <config>` (scenario type read from the file), `ion-core montecarlo`, `ion-core lifetime`,
`ion-core fault --fault grid_interception_increase --magnitude 8`.

```python
from ion_core.configuration import EngineConfig, OperatingPoint
from ion_core.simulation.solver import solve_steady_state

st = solve_steady_state(EngineConfig(), OperatingPoint(mass_flow_kg_s=3.0e-6, beam_voltage_v=1100, beam_current_a=1.76))
print(st.performance_state.thrust_n, st.performance_state.isp_s, st.limits.status)
print(st.energy_balance.message)        # ENERGY BALANCE: PASS (residual ...)
```

Values may carry units (`"1.1 kV"`, `"3 mg/s"`, `"0.58 mm"`); they are parsed with Pint, dimensionally checked and
stored in SI. A value with the wrong dimension is rejected.

## The chain that is simulated

```
PROPELLANT → FLOW → neutral density → IONISATION → PLASMA → EXTRACTION → ACCELERATION → BEAM → NEUTRALISATION → THRUST
DC INPUT → PPU (every stage has a loss) → DISCHARGE | GRID SUPPLIES | NEUTRALISER | AUX → heat → THERMAL NODES → LIMITS
```

Changing a parameter propagates physically: e.g. grid interception ↑ → grid power ↑ → grid temperature ↑ → thermal margin ↓ → limit status.

| topic | model (reduced-order; details in docs/PHYSICS.md) |
|---|---|
| species | `PropellantSpecies` (mass, ion mass, charge state, ionisation energy, Lotz shells); xenon/krypton/argon + runtime registration; no species is hard-coded in the physics |
| ionisation | Lotz cross-section → Maxwellian rate coefficient ⟨σv⟩(Tₑ) (Numba, Simpson) → ionisation frequency, rate density, probability; `Tₑ` from the ion particle balance |
| plasma | 0-D global discharge model; Bohm loss; floating-wall sheath; neutral balance (neutral density from flow minus extracted ions); quasi-neutrality noted as an approximation |
| discharge energy | `P_d = P_ionisation + P_excitation + P_ion_potential + P_wall + P_radiation + P_electron_loss + P_other`, residual always shown |
| extraction | potential ladder (plasma / screen / accelerator / plume), planar Child–Langmuir with Kaufman effective gap (labelled reduced-order), perveance-dependent interception and divergence |
| beam | ideal / modelled-effective / calibrated velocity kept separate; Rayleigh divergence distribution → ⟨cos θ⟩ |
| thrust | momentum flow `ṁ v ⟨cos θ⟩` + cold-gas momentum; ideal, gross, axial, divergence loss reported separately |
| Isp | on total, main-line and beam-ion flow — never silently substituted |
| neutraliser | emission command / capability / delivered; beam must be neutralised or the point is INVALID |
| power | PPU stage chain with visible losses; independent energy ledger with a tolerance and a visible `FAIL` |
| thermal | 5-node lumped network (chamber, grids, neutraliser, PPU, structure); `Q = εσA(T⁴−Tenv⁴)`; Newton steady state, RK4 transient |
| limits | `VALID / WARNING / LIMIT / INVALID` with margins; **nothing is clamped silently** |
| transient | explicit state machine OFF → … → COOLDOWN; first-order lags (flow, discharge, grid voltage, plasma, neutraliser); thermal ODEs |
| faults, degradation | 8 fault types with causal reports; degradation coefficients with source/uncertainty/validity range, calibratable |
| digital twin | `SIMULATION` vs `DIGITAL_TWIN`; synthetic telemetry (noise, bias, latency, dropout, quantisation); estimator + bounded least-squares calibration |
| output | `SimulationResult`; JSON / CSV / Parquet / HDF5 with simulation id, timestamp, versions, configuration, units, scenario, seed, validation status; HTML report |

## Nominal demonstration case

[docs/NOMINAL_CASE.md](docs/NOMINAL_CASE.md) (generated from the model): 3.0 mg/s, 1100 V, 1.76 A → 94.7 mN, Isp 3220 s,
2.50 kW input, 37.8 mN/kW, overall efficiency 0.60. These magnitudes are *plausible for the class* — that is not validation.

## Repository

```
src/ion_core/   propellant/ plasma/ extraction/ acceleration/ neutraliser/ thrust/ power/ thermal/
                simulation/ (engine, solver, transient, scenarios, faults, degradation, sweeps, telemetry, digital_twin)
                diagnostics/ reporting/ console/ configuration.py units.py validation.py results.py cli.py
tests/          132 tests (pytest + Hypothesis); validation/ runner + latest report; scenarios/ configs/ examples/ notebooks/ docs/
```

See [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md), [docs/PHYSICS.md](docs/PHYSICS.md), [docs/VALIDATION.md](docs/VALIDATION.md).

## Quality gates

```bash
pytest            # 132 tests, ~96 % line coverage
ruff check src tests
mypy src
ion-core validate # 32 validation checks against independent analytic / numerical references
```

## Acceptance criteria → where each is verified

| # | criterion | verified by |
|---|---|---|
| 1 | species selectable | `test_species_swap_changes_physics_not_code`, console select |
| 2 | mass flow varied | `test_every_listed_sweep_variable_runs` (`mass_flow`) |
| 3 | plasma state calculated | `test_ionisation_is_connected_to_density_and_temperature` |
| 4 | ionisation modelled | `test_rate_coefficient_vs_quadrature`, validation "ionisation rate coefficient" |
| 5 | extraction voltage varied | sweeps of `beam_voltage`; accelerator bias in `OperatingPoint` |
| 6 | ion velocity from q, V, m | `test_ion_energy_and_velocity`, validation suite |
| 7 | beam current calculated | `test_beam_current_and_mass_flow`; plasma-limited mode `test_more_discharge_power_gives_more_plasma_and_beam` |
| 8 | space-charge limit | `test_space_charge_extraction.py`, validation "Child-Langmuir solves Poisson" |
| 9 | beam power | `test_beam_power_and_thrust` |
| 10 | neutralisation | `test_neutraliser_must_neutralise_beam` |
| 11 | thrust from momentum flow | `test_beam_power_and_thrust`, validation "thrust (no divergence)" |
| 12 | specific impulse | `test_isp_uses_total_flow_and_distinguishes_flows` |
| 13 | electrical power conserved | `test_energy_balance_closes_and_residual_is_displayed`, property test over operating points, every transient step |
| 14 | mass flow conserved | `test_mass_balance_*`, every transient step |
| 15 | thermal losses | `test_grid_interception_feeds_grid_thermal_node`, `test_network_steady_state_conserves_heat` |
| 16 | operating limits explicit | `test_nominal_is_valid_and_limit_taxonomy`, `test_thermal_limit_breach_reported_not_clamped` |
| 17 | transient start-up/shutdown | `tests/test_transient.py` |
| 18 | parameters swept | `tests/test_sweeps_validation.py` |
| 19 | results exported | `tests/test_io_cli_console.py` (JSON, CSV, Parquet, HDF5 round trips) |
| 20 | validation tests pass | `ion-core validate`, `test_validation_suite_passes_and_covers_required_topics` |
| 21 | every displayed value traces to the model | console renders only `/api/*` responses (`test_console_values_come_from_the_python_model`); each row shows its state path |

## Known limitations (read before using results)

* Singly charged ions only. Species with `charge_state > 1` are **refused** (`NotImplementedError`), not approximated. No doubly-charged ions, charge-exchange ions, or grid erosion physics.
* 0-D, Maxwellian-electron discharge model. Primary electrons enter only through the `primary_confinement` coefficient.
* Interception, divergence and the excitation cross-section use parametric forms with DEMONSTRATION coefficients.
* The energy ledger closes by construction when all formulas are mutually consistent; it detects inconsistency (see its negative-control test and the INVALID points where it fails) but is not an independent physical measurement.
* The neutraliser emission readiness is a configured first-order lag, not thermionic emission physics. Electron backstreaming is a voltage-margin check only.
* The plasma time constant is an effective energy-reservoir lag (stored energy is accounted in the energy balance), not the microsecond plasma energy-confinement time.
* The digital-twin estimator is steady-state; temperature channels are only compared when the telemetry is declared thermally settled.
