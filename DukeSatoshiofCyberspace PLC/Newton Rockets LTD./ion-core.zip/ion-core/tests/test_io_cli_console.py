import json
import threading
import urllib.error
import urllib.request
from pathlib import Path

import h5py
import pandas as pd
import pyarrow.parquet as pq
import pytest
from pydantic import ValidationError

from ion_core.cli import main
from ion_core.configuration import EngineConfig
from ion_core.console.server import make_server
from ion_core.reporting.export import export_result, load_hdf5, result_to_dict
from ion_core.reporting.report import build_report, build_report_from_hdf5
from ion_core.results import result_from_state, result_from_transient
from ion_core.simulation.scenarios import Event, Scenario
from ion_core.simulation.solver import solve_steady_state
from ion_core.simulation.sweeps import sweep
from ion_core.simulation.transient import run_transient
from ion_core.units import to_si, unit_of

ROOT = Path(__file__).resolve().parents[1]
CFG = EngineConfig()
REQUIRED = {"simulation_id", "timestamp", "software_version", "model_version", "configuration", "parameters", "units", "scenario",
            "random_seed", "results", "validation_status"}


@pytest.fixture(scope="module")
def result():
    st = solve_steady_state(CFG)
    return result_from_state(CFG, st, seed=11, tables={"sweep_beam_voltage": sweep(CFG, None, "beam_voltage", [800, 1100, 1400])})


# ------------------------------------------------------------------------ units & configuration
def test_units_are_parsed_and_wrong_dimensions_rejected():
    assert to_si("1.1 kV", "V") == pytest.approx(1100.0)
    assert to_si("2.5 mg/s", "kg/s") == pytest.approx(2.5e-6)
    assert to_si("0.58 mm", "m") == pytest.approx(0.58e-3)
    with pytest.raises(ValueError):
        to_si("3 m", "V")
    c = EngineConfig.model_validate({"operating_point": {"mass_flow_kg_s": "3 mg/s", "beam_voltage_v": "1.1 kV", "beam_current_a": "1760 mA"}})
    assert c.operating_point.mass_flow_kg_s == pytest.approx(3e-6) and c.operating_point.beam_current_a == pytest.approx(1.76)
    assert unit_of("beam_voltage_v") == "V" and unit_of("mass_flow_kg_s") == "kg/s" and unit_of("thrust_to_power_mn_kw") == "mN/kW"


def test_unknown_config_keys_and_paths_are_errors():
    with pytest.raises(ValidationError):
        EngineConfig.model_validate({"grids": {"bogus": 1}})
    with pytest.raises(KeyError):
        CFG.with_updates({"grids.nope": 1})


def test_example_files_load_and_solve():
    for f in sorted((ROOT / "scenarios").glob("*.yaml")) + sorted((ROOT / "configs").glob("*.yaml")):
        cfg = EngineConfig.from_yaml(f)
        assert cfg.engine.parameter_provenance.startswith("DEMONSTRATION")
        assert isinstance(solve_steady_state(cfg).limits.status, str)


def test_demo_defaults_are_marked_as_demonstration():
    assert "DEMONSTRATION" in CFG.engine.parameter_provenance
    assert all("DEMONSTRATION" in c.source for c in CFG.degradation.coefficients)
    assert "DEMONSTRATION" in EngineConfig().species.notes or "DEMONSTRATION" in CFG.species.notes


# ------------------------------------------------------------------------ export
def test_json_export_has_required_metadata(tmp_path, result):
    p = export_result(result, tmp_path / "r.json")[0]
    d = json.loads(p.read_text())
    assert REQUIRED <= set(d)
    assert d["validation_status"] == "PASS" and d["random_seed"] == 11 and d["configuration"]["propellant"]["species"] == "xenon"
    assert d["results"]["performance"]["thrust_n"] == pytest.approx(result.state.performance_state.thrust_n)
    assert d["results"]["power_balance"]["status"] == "PASS" and d["results"]["mass_balance"]["status"] == "PASS"
    assert "state" in d["results"] and len(d["results"]["tables"]["sweep_beam_voltage"]) == 3
    assert d["units"]["beam_voltage_v"] == "V"
    json.dumps(d, allow_nan=False)


def test_csv_export_has_header_and_units(tmp_path, result):
    files = export_result(result, tmp_path / "r.csv")
    assert {f.name for f in files} == {"r_operating_points.csv", "r_sweep_beam_voltage.csv"}
    txt = (tmp_path / "r_sweep_beam_voltage.csv").read_text().splitlines()
    assert txt[0].startswith("# simulation_id=") and "model_version=" in txt[0] and "random_seed=11" in txt[0]
    assert txt[1].startswith("# units:")
    df = pd.read_csv(tmp_path / "r_sweep_beam_voltage.csv", comment="#")
    assert len(df) == 3 and df["thrust_n"].is_monotonic_increasing


def test_parquet_export_embeds_metadata(tmp_path, result):
    files = export_result(result, tmp_path / "r.parquet")
    t = pq.read_table(files[0])
    md = t.schema.metadata
    assert b"simulation_id" in md and b"model_version" in md and b"configuration" in md
    assert len(pq.read_table(tmp_path / "r_sweep_beam_voltage.parquet")) == 3


def test_hdf5_roundtrip(tmp_path, result):
    p = export_result(result, tmp_path / "r.h5")[0]
    with h5py.File(p) as f:
        assert {"simulation_id", "timestamp", "software_version", "model_version", "random_seed", "validation_status"} <= set(f.attrs)
        assert f["sweep_beam_voltage"]["beam_voltage_v"].attrs["unit"] == "V"
    back = load_hdf5(p)
    assert back["attrs"]["simulation_id"] == result.metadata["simulation_id"]
    assert back["tables"]["sweep_beam_voltage"]["thrust_n"].tolist() == pytest.approx(result.tables["sweep_beam_voltage"]["thrust_n"].tolist())
    assert EngineConfig.model_validate(back["configuration"]).to_dict() == CFG.to_dict()


def test_unknown_export_format(tmp_path, result):
    with pytest.raises(ValueError):
        export_result(result, tmp_path / "r.xyz")


def test_transient_result_structure(tmp_path):
    tr = run_transient(CFG, Scenario("e", 300.0, [Event(0, "start")], stop_when_off=False))
    r = result_from_transient(CFG, tr)
    d = result_to_dict(r)
    assert REQUIRED <= set(d) and d["scenario"]["transitions"] and "time_history" in d["results"]["tables"]
    assert r.validation["run_checks"][0].startswith("energy balance")
    p = export_result(r, tmp_path / "t.h5")[0]
    assert "time_history" in load_hdf5(p)["tables"]


# ------------------------------------------------------------------------ report
def test_report_contains_every_required_section_and_figures(tmp_path, result):
    p = build_report(result, tmp_path / "rep.html")
    html = p.read_text()
    for sec in ("ENGINE CONFIGURATION", "PROPELLANT", "PLASMA STATE", "EXTRACTION", "ION BEAM", "NEUTRALISER", "POWER", "THERMAL", "THRUST",
                "SPECIFIC IMPULSE", "EFFICIENCY", "LIMITS", "BALANCE RESIDUALS", "VALIDATION STATUS"):
        assert f"<h2>{sec}</h2>" in html, sec
    assert html.count("data:image/png;base64") >= 9 and "plotly" in html.lower() and "ENERGY BALANCE PASS" in html
    assert "DEMONSTRATION" in html
    assert "performance_state.thrust_n" in html  # every value shows its model path


def test_report_from_hdf5(tmp_path, result):
    h5 = export_result(result, tmp_path / "r.h5")[0]
    out = build_report_from_hdf5(h5, tmp_path / "r.html")
    assert out.exists() and "THRUST" in out.read_text()


# ------------------------------------------------------------------------ CLI
def test_cli_steady_state_writes_results(tmp_path, capsys):
    rc = main(["steady-state", str(ROOT / "scenarios/xenon_ion_engine.yaml"), "-o", str(tmp_path), "-f", "json,h5", "--report"])
    out = capsys.readouterr().out
    assert rc == 0 and "ENERGY BALANCE: PASS" in out and "MASS BALANCE: PASS" in out
    assert len(list(tmp_path.glob("*.json"))) == 1 and len(list(tmp_path.glob("*.h5"))) == 1 and len(list(tmp_path.glob("*.report.html"))) == 1


def test_cli_run_uses_scenario_type(tmp_path, capsys):
    assert main(["run", str(ROOT / "scenarios/xenon_ion_engine.yaml"), "-o", str(tmp_path), "-f", "json"]) == 0
    assert "thrust 9" in capsys.readouterr().out


def test_cli_sweep_and_validate(tmp_path, capsys):
    assert main(["sweep", str(ROOT / "scenarios/parametric_sweeps.yaml"), "-o", str(tmp_path), "-f", "json,csv"]) == 0
    out = capsys.readouterr().out
    for t in ("sweep_beam_voltage", "sweep_mass_flow", "sweep_discharge_power", "sweep_grid_spacing", "sweep_grid_aperture", "throttle_curve", "performance_map"):
        assert f"table {t}" in out
    assert main(["validate", "--json", str(tmp_path / "v.json")]) == 0
    assert "VALIDATION: PASS" in capsys.readouterr().out
    assert json.loads((tmp_path / "v.json").read_text())["status"] == "PASS"


def test_cli_transient_and_report(tmp_path, capsys):
    spec = tmp_path / "t.yaml"
    spec.write_text("operating_point: {mass_flow_kg_s: 3.0e-6, beam_voltage_v: 1100, beam_current_a: 1.76}\n"
                    "scenario: {type: transient, name: quick, duration_s: 400, events: [{t: 0, action: start}], stop_when_off: false}\n")
    assert main(["transient", str(spec), "-o", str(tmp_path), "-f", "h5"]) == 0
    out = capsys.readouterr().out
    assert "BEAM_ESTABLISHED" in out and "energy balance FAIL steps 0" in out
    h5 = next(tmp_path.glob("*.h5"))
    assert main(["report", str(h5), "-o", str(tmp_path / "x.html")]) == 0 and (tmp_path / "x.html").exists()


def test_cli_invalid_point_returns_nonzero(tmp_path, capsys):
    spec = tmp_path / "bad.yaml"
    spec.write_text("operating_point: {mass_flow_kg_s: 2.0e-6, beam_voltage_v: 1100, beam_current_a: 1.76}\nscenario: {type: steady}\n")
    assert main(["steady-state", str(spec), "-o", str(tmp_path), "-f", "json"]) == 1
    assert "INVALID" in capsys.readouterr().out


def test_cli_fault_prints_causal_chain(capsys):
    assert main(["fault", "--fault", "grid_interception_increase", "--magnitude", "8"]) == 0
    out = capsys.readouterr().out
    assert "grid power loss" in out and "grid thermal margin" in out


# ------------------------------------------------------------------------ console server
@pytest.fixture(scope="module")
def server():
    srv = make_server(CFG, port=0)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    yield f"http://127.0.0.1:{srv.server_address[1]}"
    srv.shutdown()
    srv.server_close()


def _post(base, path, body):
    req = urllib.request.Request(base + path, data=json.dumps(body).encode(), headers={"Content-Type": "application/json"})
    return json.loads(urllib.request.urlopen(req).read())


def test_console_values_come_from_the_python_model(server):
    e = _post(server, "/api/evaluate", {"inputs": {}})
    ref = solve_steady_state(CFG)
    assert e["state"]["performance_state"]["thrust_n"] == pytest.approx(ref.performance_state.thrust_n, rel=1e-12)
    e2 = _post(server, "/api/evaluate", {"inputs": {"beam_voltage_v": 1300.0}})
    assert e2["state"]["beam_state"]["beam_voltage_v"] == 1300.0
    assert e2["state"]["performance_state"]["isp_s"] > e["state"]["performance_state"]["isp_s"]
    chain = {c["step"]: c for c in e["state"]["calculation_chain"]}
    assert {"BEAM VOLTAGE", "ION ENERGY", "ION VELOCITY", "ION MASS FLOW", "THRUST", "SPECIFIC IMPULSE"} <= set(chain)


def test_console_endpoints(server):
    page = urllib.request.urlopen(server + "/").read().decode()
    for sec in ("ENGINE", "PLASMA", "EXTRACTION", "BEAM", "NEUTRALISER", "POWER", "THERMAL", "PERFORMANCE", "TRANSIENT", "LIMITS", "VALIDATION"):
        assert f'"{sec}"' in page
    assert len(urllib.request.urlopen(server + "/static/plotly.min.js").read()) > 1_000_000
    sch = json.loads(urllib.request.urlopen(server + "/api/schema").read())
    assert sch["defaults"]["species"] == "xenon" and "krypton" in sch["fields"][0]["options"]
    c = _post(server, "/api/curves", {"inputs": {}})
    assert len(c["throttle"]["thrust_n"]) == 21 and len(c["map"]["thrust_n"]) == 12
    v = json.loads(urllib.request.urlopen(server + "/api/validate").read())
    assert v["status"] == "PASS"


def test_console_rejects_bad_input_with_message(server):
    with pytest.raises(urllib.error.HTTPError) as ei:
        _post(server, "/api/evaluate", {"inputs": {"beam_voltage_v": -5.0}})
    assert ei.value.code == 400 and "error" in json.loads(ei.value.read())
    with pytest.raises(urllib.error.HTTPError) as ei2:
        urllib.request.urlopen(server + "/api/nope")
    assert ei2.value.code == 404
