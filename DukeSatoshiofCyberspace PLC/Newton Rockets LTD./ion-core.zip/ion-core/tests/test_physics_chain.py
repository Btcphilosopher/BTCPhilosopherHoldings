"""Fundamental relations: E = qV, v = sqrt(2E/m), F = m_dot v, Isp, beam current/power."""
import math

import pytest
from hypothesis import given, settings
from hypothesis import strategies as st

from ion_core import constants as k
from ion_core.acceleration.velocity import ion_speed
from ion_core.configuration import EngineConfig, OperatingPoint
from ion_core.propellant.species import ARGON, KRYPTON, XENON
from ion_core.simulation.solver import solve_steady_state

CFG = EngineConfig()


def test_ion_energy_and_velocity(nominal):
    b = nominal.beam_state
    assert b.ion_energy_ideal_j == pytest.approx(k.E_CHARGE * b.beam_voltage_v, rel=1e-14)
    e = b.ion_energy_ideal_j
    assert b.ion_velocity_ideal_m_s == pytest.approx(math.sqrt(2 * e / CFG.species.ion_mass), rel=1e-12)


def test_beam_current_and_mass_flow(nominal):
    b, pf = nominal.beam_state, nominal.propellant_flow
    assert b.beam_current_a == pytest.approx(1.76)
    assert pf.ion_flow_beam_kg_s == pytest.approx(b.beam_current_a / k.E_CHARGE * CFG.species.ion_mass, rel=1e-12)


def test_beam_power_and_thrust(nominal):
    b, p = nominal.beam_state, nominal.performance_state
    assert b.beam_power_w == pytest.approx(b.beam_voltage_v * b.beam_current_a, rel=1e-14)
    f_axial = nominal.propellant_flow.ion_flow_beam_kg_s * b.ion_velocity_effective_m_s * b.thrust_factor_gamma
    assert p.thrust_axial_ion_n == pytest.approx(f_axial, rel=1e-12)
    assert p.thrust_n == pytest.approx(p.thrust_axial_ion_n + p.thrust_neutral_chamber_n + p.thrust_neutraliser_gas_n, rel=1e-12)
    assert p.thrust_ideal_n > p.thrust_gross_n > p.thrust_axial_ion_n  # losses are visible and ordered


def test_divergence_loss_is_the_difference(nominal):
    p = nominal.performance_state
    assert p.divergence_loss_n == pytest.approx(p.thrust_gross_n - p.thrust_axial_ion_n, rel=1e-12)
    assert p.divergence_loss_n > 0


def test_isp_uses_total_flow_and_distinguishes_flows(nominal):
    p, pf = nominal.performance_state, nominal.propellant_flow
    assert p.isp_s == pytest.approx(p.thrust_n / (pf.mass_flow_total_kg_s * k.G0), rel=1e-12)
    assert p.isp_main_s > p.isp_s  # main line carries less flow than the total
    assert p.isp_ion_s != p.isp_s


def test_thrust_to_power_units(nominal):
    p, pw = nominal.performance_state, nominal.power_state
    assert p.thrust_to_power_n_kw == pytest.approx(p.thrust_n / (pw.p_input_w / 1000), rel=1e-12)
    assert p.thrust_to_power_mn_kw == pytest.approx(1000 * p.thrust_to_power_n_kw, rel=1e-12)


def test_efficiency_decomposition_is_exact(nominal):
    e = nominal.performance_state.efficiencies
    assert e["ion_thrust_overall"] == pytest.approx(
        e["propellant_utilisation"] * e["divergence"] * e["acceleration"] * e["electrical"], rel=1e-12)
    assert 0 < e["overall"] < 1 and e["thruster"] > e["overall"]  # PPU loss separates them


def test_effective_velocity_distinct_from_ideal(nominal):
    b = nominal.beam_state
    assert b.ion_velocity_effective_m_s != b.ion_velocity_ideal_m_s
    assert b.ion_velocity_calibrated_m_s is None  # not provided -> not invented
    cal = solve_steady_state(CFG.with_updates({"beam.velocity_calibration_factor": 0.98}))
    assert cal.beam_state.ion_velocity_calibrated_m_s == pytest.approx(0.98 * cal.beam_state.ion_velocity_effective_m_s)


@pytest.mark.parametrize("sp", [XENON, KRYPTON, ARGON])
def test_species_swap_changes_physics_not_code(sp):
    s = solve_steady_state(CFG.with_updates({"propellant.species": sp.species_name,
                                              "operating_point": {"mass_flow_kg_s": 3.0e-6 * sp.atomic_mass_u / 131.293 * 0.9,
                                                                  "beam_voltage_v": 1100.0, "beam_current_a": 1.5,
                                                                  **{k_: None for k_ in ("discharge_voltage_v", "discharge_current_a", "discharge_power_w",
                                                                                         "neutraliser_current_a", "accelerator_voltage_v")}}}))
    assert s.beam_state.ion_velocity_ideal_m_s == pytest.approx(ion_speed(k.E_CHARGE, 1100.0, sp.ion_mass), rel=1e-12)
    assert s.propellant_flow.species_name == sp.species_name


def test_lighter_species_gives_higher_isp_at_same_voltage():
    out = {}
    for sp in (XENON, KRYPTON):
        out[sp.species_name] = solve_steady_state(CFG.with_updates({"propellant.species": sp.species_name}),
                                                  OperatingPoint(mass_flow_kg_s=2.2e-6 if sp is KRYPTON else 3.0e-6,
                                                                 beam_voltage_v=1100.0, beam_current_a=1.5)).performance_state.isp_s
    assert out["krypton"] > out["xenon"]


@settings(max_examples=40, deadline=None)
@given(v=st.floats(500, 1500), i=st.floats(0.6, 2.0))
def test_property_velocity_and_power_laws(v, i):
    op = OperatingPoint(mass_flow_kg_s=3.0e-6 * i / 1.76 * 1.05, beam_voltage_v=v, beam_current_a=i)
    s = solve_steady_state(CFG, op)
    assert s.beam_state.ion_velocity_ideal_m_s == pytest.approx(math.sqrt(2 * k.E_CHARGE * v / CFG.species.ion_mass), rel=1e-12)
    assert s.beam_state.beam_power_w == pytest.approx(v * i, rel=1e-12)
    assert s.performance_state.thrust_n > 0
    if s.limits.status != "INVALID":  # a failed balance only ever occurs on a point flagged INVALID
        assert s.energy_balance.status == "PASS" and s.mass_balance.status == "PASS"
    elif s.energy_balance.status == "FAIL" or s.mass_balance.status == "FAIL":
        assert any(c.status == "INVALID" for c in s.limits.checks)


@settings(max_examples=25, deadline=None)
@given(v=st.floats(600, 1500))
def test_property_thrust_increases_with_voltage_at_fixed_current_and_flow(v):
    base = OperatingPoint(mass_flow_kg_s=3.0e-6, beam_voltage_v=v, beam_current_a=1.5)
    hi = OperatingPoint(mass_flow_kg_s=3.0e-6, beam_voltage_v=v * 1.1, beam_current_a=1.5)
    assert solve_steady_state(CFG, hi).performance_state.thrust_n > solve_steady_state(CFG, base).performance_state.thrust_n
