import math

import pytest
from hypothesis import given, settings
from hypothesis import strategies as st

from ion_core import constants as k
from ion_core.configuration import EngineConfig, OperatingPoint
from ion_core.extraction.grids import build_geometry, effective_gap
from ion_core.extraction.space_charge import child_langmuir_current_density, space_charge_state
from ion_core.simulation.solver import solve_steady_state

M_I = EngineConfig().species.ion_mass


def test_child_langmuir_matches_formula():
    v, d = 1280.0, 1.354e-3
    j = (4 / 9) * k.EPS0 * math.sqrt(2 * k.E_CHARGE / M_I) * v**1.5 / d**2
    assert child_langmuir_current_density(v, d, M_I, k.E_CHARGE) == pytest.approx(j, rel=1e-14)


@settings(max_examples=50, deadline=None)
@given(v=st.floats(50, 3000), d=st.floats(2e-4, 3e-3), f=st.floats(1.1, 5))
def test_property_scaling_laws(v, d, f):
    j = child_langmuir_current_density(v, d, M_I, k.E_CHARGE)
    assert child_langmuir_current_density(f * v, d, M_I, k.E_CHARGE) == pytest.approx(j * f**1.5, rel=1e-12)
    assert child_langmuir_current_density(v, f * d, M_I, k.E_CHARGE) == pytest.approx(j / f**2, rel=1e-12)


def test_zero_voltage_gives_zero_limit():
    assert child_langmuir_current_density(0.0, 1e-3, M_I, k.E_CHARGE) == 0.0


def test_space_charge_state_margin():
    r = space_charge_state(extraction_voltage_v=1280, effective_gap_m=1.35e-3, ion_mass_kg=M_I, ion_charge_c=k.E_CHARGE,
                           n_apertures=15000, aperture_area_m2=2.865e-6, actual_current_a=1.76)
    assert r.margin_a == pytest.approx(r.limit_a - 1.76) and r.ratio == pytest.approx(1.76 / r.limit_a)
    assert 0 < r.ratio < 1


def test_kaufman_effective_gap_geometry():
    assert effective_gap(0.58e-3, 0.38e-3, 1.91e-3) == pytest.approx(math.sqrt((0.96e-3) ** 2 + (0.955e-3) ** 2))


def test_potentials_are_distinct(nominal):
    g = nominal.grid_state
    assert g.plasma_potential_v > g.screen_grid_potential_v > 0 > g.accelerator_grid_potential_v
    assert g.extraction_voltage_v == pytest.approx(g.screen_grid_potential_v - g.accelerator_grid_potential_v)
    assert g.electric_field_v_m == pytest.approx(g.extraction_voltage_v / 0.58e-3)


def test_commanded_current_above_space_charge_limit_is_invalid_not_clamped():
    cfg = EngineConfig()
    op = OperatingPoint(mass_flow_kg_s=6e-6, beam_voltage_v=300.0, beam_current_a=2.0)
    s = solve_steady_state(cfg, op)
    assert s.limits.status == "INVALID"
    assert any(c.name == "space_charge" and c.status == "INVALID" for c in s.limits.checks)
    assert s.grid_state.extracted_current_a > s.grid_state.space_charge_limit_a  # value is reported, not clamped


def test_interception_rises_with_perveance_and_heats_the_grid():
    cfg = EngineConfig()
    lo = solve_steady_state(cfg, OperatingPoint(mass_flow_kg_s=2.0e-6, beam_voltage_v=1100.0, beam_current_a=1.0))
    hi = solve_steady_state(cfg, OperatingPoint(mass_flow_kg_s=4.2e-6, beam_voltage_v=1100.0, beam_current_a=2.4))
    assert hi.grid_state.interception_fraction > lo.grid_state.interception_fraction
    assert hi.grid_state.p_grid_loss_w > lo.grid_state.p_grid_loss_w
    assert hi.thermal_state.nodes["grids"].temperature_k > lo.thermal_state.nodes["grids"].temperature_k


def test_wider_gap_lowers_space_charge_limit():
    base = build_geometry(EngineConfig().grids)
    wide = build_geometry(EngineConfig().with_updates({"grids.extraction_gap_m": 1.0e-3}).grids)
    assert wide.effective_gap_m > base.effective_gap_m
    assert child_langmuir_current_density(1280, wide.effective_gap_m, M_I, k.E_CHARGE) < \
        child_langmuir_current_density(1280, base.effective_gap_m, M_I, k.E_CHARGE)


def test_plasma_limited_beam_is_space_charge_limited_at_low_voltage():
    cfg = EngineConfig()
    s = solve_steady_state(cfg, OperatingPoint(mass_flow_kg_s=3.0e-6, beam_voltage_v=250.0, discharge_power_w=330.0))
    assert s.grid_state.space_charge_limited
    assert s.grid_state.extracted_current_a == pytest.approx(s.grid_state.space_charge_limit_a, rel=1e-9)
    assert any(c.name == "space_charge" and c.status == "LIMIT" for c in s.limits.checks)
