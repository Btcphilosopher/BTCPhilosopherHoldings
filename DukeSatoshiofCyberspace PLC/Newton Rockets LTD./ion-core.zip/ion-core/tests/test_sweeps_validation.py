import numpy as np
import pytest

from ion_core.configuration import EngineConfig, OperatingPoint
from ion_core.simulation.solver import solve_steady_state
from ion_core.simulation.sweeps import (
    SWEEPABLE,
    engineering_curves,
    monte_carlo,
    performance_map,
    sweep,
    sweep_2d,
    throttle_curve,
)
from ion_core.validation import run_validation

CFG = EngineConfig()


def test_validation_suite_passes_and_covers_required_topics():
    rep = run_validation()
    assert rep.status == "PASS", [c.name for c in rep.checks if not c.passed]
    names = " | ".join(c.name for c in rep.checks).lower()
    for topic in ("ion velocity", "ion kinetic energy", "ion mass flow", "beam current", "beam power", "child-langmuir", "thrust",
                  "specific impulse", "radiative", "power balance", "mass balance", "dimensional consistency"):
        assert topic in names, topic
    assert all(c.rel_error <= c.tolerance for c in rep.checks)


def test_every_listed_sweep_variable_runs():
    ref = {"beam_voltage": (800, 1300), "beam_current": (1.2, 1.9), "mass_flow": (3.0e-6, 3.8e-6), "discharge_power": (280, 330),
           "neutraliser_current": (2.0, 2.6), "grid_spacing": (0.5e-3, 0.8e-3), "grid_aperture": (1.8e-3, 2.0e-3)}
    assert set(ref) == set(SWEEPABLE)
    for var, (lo, hi) in ref.items():
        df = sweep(CFG, None, var, np.linspace(lo, hi, 4))
        assert len(df) == 4 and df["thrust_n"].gt(0).all(), var
        assert df[f"sweep_{var}"].tolist() == pytest.approx(np.linspace(lo, hi, 4).tolist())


def test_sweep_keeps_invalid_points_labelled():
    df = sweep(CFG, None, "mass_flow", [1.8e-6, 3.0e-6])
    assert df["limit_status"].tolist() == ["INVALID", "VALID"]


def test_sweep_responses_are_physically_ordered():
    v = sweep(CFG, None, "beam_voltage", np.linspace(700, 1400, 6))
    assert v["thrust_n"].is_monotonic_increasing and v["isp_s"].is_monotonic_increasing and v["p_input_w"].is_monotonic_increasing
    g = sweep(CFG, None, "grid_spacing", np.linspace(0.4e-3, 1.0e-3, 5))
    assert g["space_charge_limit_a"].is_monotonic_decreasing and g["perveance_ratio"].is_monotonic_increasing
    d = sweep(CFG, None, "discharge_power", np.linspace(220, 340, 5))
    assert d["beam_current_a"].is_monotonic_increasing and d["thrust_n"].is_monotonic_increasing
    n = sweep(CFG, None, "neutraliser_current", [2.0, 2.4])
    assert n["p_input_w"].iloc[0] == pytest.approx(n["p_input_w"].iloc[1])  # emission command does not change input power in this model


def test_throttle_curve_curves_are_generated_by_the_model():
    t = throttle_curve(CFG, n=9, scale_min=0.4, scale_max=1.1)
    assert t["thrust_n"].is_monotonic_increasing and t["p_input_w"].is_monotonic_increasing
    ref = solve_steady_state(CFG, CFG.operating_point.model_copy(update={"beam_current_a": 0.4 * 1.76, "mass_flow_kg_s": 0.4 * 3.0e-6}))
    assert t["thrust_n"].iloc[0] == pytest.approx(ref.performance_state.thrust_n, rel=1e-12)  # first point == a direct solve
    assert t["thrust_to_power_mn_kw"].iloc[-1] > t["thrust_to_power_mn_kw"].iloc[0]


def test_performance_map_values_equal_direct_solves():
    m = performance_map(CFG, None, beam_voltages=[800.0, 1100.0], beam_currents=[1.0, 1.76])
    assert m["thrust_n"].shape == (2, 2)
    op = OperatingPoint(mass_flow_kg_s=3.0e-6 * 1.0 / 1.76, beam_voltage_v=800.0, beam_current_a=1.0)
    assert float(m["thrust_n"].sel(beam_voltage_v_axis=800.0, beam_current_a_axis=1.0)) == pytest.approx(solve_steady_state(CFG, op).performance_state.thrust_n, rel=1e-12)
    for q in ("thrust_n", "eta_overall", "thrust_to_power_mn_kw", "p_beam_w"):
        assert q in m and np.isfinite(m[q].values.astype(float)).all()


def test_sweep_2d_shape_and_axes():
    ds = sweep_2d(CFG, None, "beam_voltage", [900, 1100, 1300], "mass_flow", [3.0e-6, 3.5e-6])
    assert ds["thrust_n"].shape == (2, 3) and list(ds["x"].values) == [900, 1100, 1300]


def test_engineering_curves_bundle():
    c = engineering_curves(CFG, n=7)
    assert set(c) == {"throttle", "beam_voltage", "envelope"} and len(c["throttle"]) == 7


def test_monte_carlo_is_reproducible_and_reports_invalid_fraction():
    params = {"grids.interception_fraction_base": {"dist": "lognormal", "median": 0.005, "sigma_log": 0.3},
              "chamber.primary_confinement": {"dist": "normal", "mean": 0.8, "sigma": 0.03},
              "ppu.efficiency_beam": {"dist": "uniform", "low": 0.93, "high": 0.97}}
    a, sa = monte_carlo(CFG, None, params, n=25, seed=4)
    b, sb = monte_carlo(CFG, None, params, n=25, seed=4)
    c, _ = monte_carlo(CFG, None, params, n=25, seed=5)
    assert a["thrust_n"].tolist() == b["thrust_n"].tolist() and a["thrust_n"].tolist() != c["thrust_n"].tolist()
    assert "invalid_fraction" in sa.columns and sa.loc["p_input_w", "std"] > 0
    assert a["param:chamber.primary_confinement"].std() == pytest.approx(0.03, rel=0.5)
    with pytest.raises(ValueError):
        monte_carlo(CFG, None, {"chamber.primary_confinement": {"dist": "weird"}}, n=2)


def test_monte_carlo_keeps_configuration_rejections_as_invalid_samples():
    df, summ = monte_carlo(CFG, None, {"chamber.primary_confinement": {"dist": "uniform", "low": 0.0, "high": 1.5}}, n=30, seed=1)
    assert (df["limit_status"] == "INVALID").any() and summ["invalid_fraction"].iloc[0] > 0
