import numpy as np
import pandas as pd
import pytest

from ion_core.configuration import DegradationCoefficient, EngineConfig
from ion_core.simulation.degradation import calibrate_coefficient, degradation_report, degraded_health
from ion_core.simulation.digital_twin import DigitalTwin, OperationMode
from ion_core.simulation.faults import FAULT_NAMES, Fault, apply_fault, fault_causal_report
from ion_core.simulation.lifetime import simulate_lifetime
from ion_core.simulation.scenarios import Event, Scenario
from ion_core.simulation.solver import solve_steady_state
from ion_core.simulation.state import HealthState
from ion_core.simulation.telemetry import CHANNELS, synthetic_telemetry
from ion_core.simulation.transient import run_transient

CFG = EngineConfig()
OP = CFG.operating_point


def _v(report, label):
    row = next(c for c in report["chain"] if c["quantity"] == label)
    return row["baseline"], row["faulted"]


def test_grid_interception_fault_chain_is_causal():
    r = fault_causal_report(CFG, OP, Fault("grid_interception_increase", 8.0))
    for label in ("grid interception fraction", "intercepted ion current", "grid power loss", "grid temperature"):
        b, f = _v(r, label)
        assert f > b, label
    b, f = _v(r, "grid thermal margin")
    assert f < b  # margin shrinks
    labels = [c["quantity"] for c in r["chain"]]
    assert labels.index("grid interception fraction") < labels.index("grid power loss") < labels.index("grid temperature") < labels.index("grid thermal margin")


def test_grid_fault_can_push_the_engine_to_its_limit():
    r = fault_causal_report(CFG.with_updates({"limits.max_grid_temperature_k": 420.0}), OP, Fault("grid_interception_increase", 12.0))
    assert r["baseline_limit_status"] != "LIMIT" and r["faulted_limit_status"] == "LIMIT"
    assert any("grids_temperature" in m for m in r["faulted_limit_messages"])


def test_flow_reduction_fault_propagates():
    r = fault_causal_report(CFG, OP, Fault("propellant_flow_reduction", 0.12))
    assert _v(r, "total propellant flow")[1] == pytest.approx(0.88 * _v(r, "total propellant flow")[0])
    assert _v(r, "neutral density")[1] < _v(r, "neutral density")[0]
    assert _v(r, "electron temperature")[1] > _v(r, "electron temperature")[0]
    assert r["faulted_limit_status"] in ("WARNING", "LIMIT", "INVALID")  # utilisation rises toward / past the limit


def test_ppu_degradation_raises_power_and_ppu_temperature():
    r = fault_causal_report(CFG, OP, Fault("ppu_efficiency_degradation", 0.06))
    assert _v(r, "input power")[1] > _v(r, "input power")[0]
    assert _v(r, "PPU temperature")[1] > _v(r, "PPU temperature")[0]
    assert _v(r, "thrust-to-power")[1] < _v(r, "thrust-to-power")[0]


def test_neutraliser_degradation_ends_in_non_neutral_beam():
    r = fault_causal_report(CFG, OP, Fault("neutraliser_degradation", 0.5))
    assert _v(r, "neutralisation ratio")[1] < 1.0
    assert _v(r, "charge imbalance")[1] > 0
    assert r["faulted_limit_status"] == "INVALID"


def test_plasma_density_reduction_lowers_density_and_beam_at_fixed_discharge():
    r = fault_causal_report(CFG, OP, Fault("plasma_density_reduction", 0.1))
    assert _v(r, "electron density")[1] < _v(r, "electron density")[0]
    assert _v(r, "beam current")[1] < _v(r, "beam current")[0]
    assert _v(r, "thrust")[1] < _v(r, "thrust")[0]


def test_thermal_rejection_degradation_heats_everything():
    r = fault_causal_report(CFG, OP, Fault("thermal_rejection_degradation", 0.4))
    for label in ("structure temperature", "chamber temperature", "grid temperature", "PPU temperature"):
        assert _v(r, label)[1] > _v(r, label)[0], label


def test_regulated_discharge_compensates_plasma_coupling_loss_with_more_power():
    base = solve_steady_state(CFG)
    h = apply_fault(HealthState(), Fault("plasma_density_reduction", 0.1))
    f = solve_steady_state(CFG, OP, h)
    assert f.beam_state.beam_current_a == pytest.approx(base.beam_state.beam_current_a)
    assert f.power_state.p_discharge_w > base.power_state.p_discharge_w


def test_all_faults_are_known_and_unknown_is_rejected():
    assert len(FAULT_NAMES) == 8
    with pytest.raises(KeyError):
        apply_fault(HealthState(), Fault("made_up", 1.0))
    with pytest.raises(ValueError):
        apply_fault(HealthState(), Fault("sensor_bias", 1.0))


def test_beam_instability_fault_oscillates_in_time_domain():
    sc = Scenario("i", 420.0, [Event(0, "start"), Event(250, "fault", {"name": "beam_current_instability", "magnitude": 0.15, "frequency_hz": 0.05})],
                  stop_when_off=False)
    h = run_transient(CFG, sc).history
    late = h[h["time_s"] > 300]
    early = h[(h["time_s"] > 220) & (h["time_s"] < 250)]
    assert late["beam_current_a"].std() > 20 * max(early["beam_current_a"].std(), 1e-9)
    assert late["energy_status"].eq("PASS").all()  # supply power oscillates; energy still balances


# ------------------------------------------------------------------ degradation ---------------------------------------------------
def test_coefficients_carry_source_uncertainty_and_validity():
    for c in CFG.degradation.coefficients:
        assert c.source and "DEMONSTRATION" in c.source and c.units and c.validity_range[0] < c.validity_range[1]
    rep = degradation_report(CFG, HealthState())
    assert {"name", "value", "units", "source", "uncertainty", "validity_range"} <= set(rep[0])


def test_degradation_grows_with_exposure_and_hours():
    h = degraded_health(CFG, HealthState(grid_exposure_ah=100, neutraliser_hours=5000, operating_hours=8000, thermal_cycles=300))
    assert h.interception_multiplier == pytest.approx(1 + 2.0e-3 * 100)
    assert h.neutraliser_emission_factor == pytest.approx(1 - 1.0e-5 * 5000)
    assert h.ppu_efficiency_delta == pytest.approx(-1.0e-6 * 8000)
    assert h.radiator_emissivity_factor == pytest.approx(1 - 1.0e-4 * 300)


def test_validity_range_violation_is_reported_not_extrapolated_silently():
    h = degraded_health(CFG, HealthState(grid_exposure_ah=900))
    assert any("grid_exposure_ah" in w for w in h.degradation_warnings)


def test_lifetime_trends():
    df = simulate_lifetime(CFG, hours=3000, steps=3, thermal_cycles_per_100h=1.0)
    assert df["interception_fraction"].is_monotonic_increasing and df["grid_temperature_k"].is_monotonic_increasing
    # commanded beam current is held, so thrust is essentially unchanged (recombined intercepted ions add a few ppm of cold-gas
    # momentum); what degrades is the cost of that thrust
    assert df["thrust_n"].iloc[-1] == pytest.approx(df["thrust_n"].iloc[0], rel=1e-4)
    assert df["p_input_w"].is_monotonic_increasing and df["ppu_efficiency"].is_monotonic_decreasing
    assert (df["thrust_n"] / df["p_input_w"]).is_monotonic_decreasing
    assert df["propellant_throughput_kg"].iloc[-1] > 0 and df["operating_hours"].iloc[-1] == pytest.approx(3000 * 3 / 3)


def test_coefficient_calibration_recovers_slope_and_uncertainty():
    x = np.linspace(10, 200, 12)
    rng = np.random.default_rng(3)
    y = 3.1e-3 * x + rng.normal(0, 2e-3, x.size)
    c = calibrate_coefficient(CFG.degradation.coefficients[0], x, y, "bench test BT-17")
    assert c.value == pytest.approx(3.1e-3, rel=0.05) and c.uncertainty and c.uncertainty > 0
    assert c.source == "bench test BT-17" and c.validity_range == (10.0, 200.0)
    with pytest.raises(ValueError):
        calibrate_coefficient(CFG.degradation.coefficients[0], np.array([1.0]), np.array([1.0]), "x")
    assert isinstance(c, DegradationCoefficient)


# ------------------------------------------------------------------ telemetry & digital twin ----------------------------------------
@pytest.fixture(scope="module")
def truth():
    h = run_transient(CFG, Scenario("tw", 600.0, [Event(0, "start")], stop_when_off=False)).history
    return h


def test_telemetry_has_all_channels_and_is_deterministic(truth):
    a = synthetic_telemetry(truth, CFG)
    b = synthetic_telemetry(truth, CFG)
    assert set(CHANNELS) <= set(a.columns)
    pd.testing.assert_frame_equal(a, b)
    c = synthetic_telemetry(truth, CFG, seed=999)
    assert not np.allclose(a["beam_current_a"], c["beam_current_a"])


def test_noise_bias_quantisation_dropout_latency(truth):
    clean = CFG.with_updates({"telemetry.noise_rel": 0.0})
    base = synthetic_telemetry(truth, clean)
    assert base["thrust_estimate_n"].to_numpy() == pytest.approx(truth["thrust_n"].to_numpy())  # no noise = truth
    noisy = synthetic_telemetry(truth, CFG.with_updates({"telemetry.noise_rel": 0.02}))
    steady = truth["mode"] == "STEADY_OPERATION"
    rel = (noisy.loc[steady, "beam_current_a"] / truth.loc[steady, "beam_current_a"] - 1).std()
    assert rel == pytest.approx(0.02, rel=0.3)
    biased = synthetic_telemetry(truth, clean, extra_bias={"grid_temperature_k": 7.5})
    assert (biased["grid_temperature_k"] - base["grid_temperature_k"]).to_numpy() == pytest.approx(7.5)
    q = synthetic_telemetry(truth, CFG.with_updates({"telemetry.noise_rel": 0.0, "telemetry.quantisation": {"beam_voltage_v": 25.0}}))
    assert np.allclose(q["beam_voltage_v"] % 25.0, 0.0, atol=1e-9)
    d = synthetic_telemetry(truth, CFG.with_updates({"telemetry.dropout_probability": 0.2}))
    assert 0.1 < d["beam_current_a"].isna().mean() < 0.3
    lagged = synthetic_telemetry(truth, CFG.with_updates({"telemetry.noise_rel": 0.0, "telemetry.latency_s": 20.0}))
    i = truth.index[truth["time_s"] > 200][0]
    j = (truth["time_s"] - (truth["time_s"].iloc[i] - 20.0)).abs().idxmin()
    assert lagged["beam_voltage_v"].iloc[i] == pytest.approx(truth["beam_voltage_v"].iloc[j], rel=0.05, abs=1.0)


def test_sensor_bias_does_not_change_the_physics():
    r = fault_causal_report(CFG, OP, Fault("sensor_bias", 5.0, channel="grid_temperature_k"))
    assert r["baseline_limit_status"] == r["faulted_limit_status"] and r["chain"] == []
    assert r["faulted_state"].performance_state.thrust_n == r["baseline_state"].performance_state.thrust_n


def test_digital_twin_estimates_unmeasured_state(truth):
    tel = synthetic_telemetry(truth, CFG)
    twin = DigitalTwin(CFG)
    assert twin.mode == OperationMode.DIGITAL_TWIN
    est = twin.run(tel[tel["time_s"] > 400].iloc[::40])
    assert len(est) > 0
    assert est["thrust_estimate_n"].iloc[-1] == pytest.approx(solve_steady_state(CFG).performance_state.thrust_n, rel=0.03)
    assert abs(est["input_power_w_innovation"].median()) < 0.05 * est["input_power_w_predicted"].median()


def test_calibration_recovers_degraded_parameters_from_settled_telemetry():
    true_cfg = CFG.with_updates({"grids.interception_fraction_base": 0.016, "chamber.primary_confinement": 0.74})
    h = run_transient(true_cfg, Scenario("cal", 3600.0, [Event(0, "start")], stop_when_off=False)).history
    tel = synthetic_telemetry(h, true_cfg.with_updates({"telemetry.noise_rel": 0.002}))
    settled = tel[tel["time_s"] > 3200]
    res = DigitalTwin(CFG).calibrate(settled, parameters={"grids.interception_fraction_base": (5e-4, 0.05), "chamber.primary_confinement": (0.5, 0.95)},
                                     channels=["input_power_w", "discharge_current_a", "grid_temperature_k"], thermal_settled=True)
    assert res.cost_after < 0.05 * res.cost_before
    assert res.parameters["chamber.primary_confinement"] == pytest.approx(0.74, abs=0.02)
    assert res.parameters["grids.interception_fraction_base"] == pytest.approx(0.016, rel=0.2)
    assert res.config.chamber.primary_confinement == pytest.approx(res.parameters["chamber.primary_confinement"])
    assert CFG.chamber.primary_confinement == 0.80  # original configuration untouched


def test_calibration_without_settled_thermal_state_uses_only_quasi_static_channels():
    true_cfg = CFG.with_updates({"chamber.primary_confinement": 0.74})
    h = run_transient(true_cfg, Scenario("cal", 400.0, [Event(0, "start")], stop_when_off=False)).history
    tel = synthetic_telemetry(h, true_cfg.with_updates({"telemetry.noise_rel": 0.002}))
    with pytest.raises(ValueError, match="thermal_settled"):
        DigitalTwin(CFG).calibrate(tel, channels=["input_power_w", "grid_temperature_k"])
    res = DigitalTwin(CFG).calibrate(tel, parameters={"chamber.primary_confinement": (0.5, 0.95)})
    assert res.channels == ["input_power_w", "discharge_current_a"]
    assert res.parameters["chamber.primary_confinement"] == pytest.approx(0.74, abs=0.02)
