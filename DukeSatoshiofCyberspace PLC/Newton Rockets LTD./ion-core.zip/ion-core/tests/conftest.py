import pytest

from ion_core.configuration import EngineConfig
from ion_core.simulation.solver import solve_steady_state


@pytest.fixture(scope="session")
def cfg() -> EngineConfig:
    return EngineConfig()


@pytest.fixture(scope="session")
def nominal(cfg):
    return solve_steady_state(cfg)
