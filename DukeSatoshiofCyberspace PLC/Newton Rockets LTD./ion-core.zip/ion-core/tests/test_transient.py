import math

import numpy as np
import pytest

from ion_core.configuration import EngineConfig
from ion_core.simulation.scenarios import TRANSITIONS, Event, Scenario, full_cycle_scenario
from ion_core.simulation.state import EngineMode
from ion_core.simulation.timestep import lag
from ion_core.simulation.transient import TransientSimulator, run_transient

CFG = EngineConfig()


@pytest.fixture(scope="module")
def cycle():
    return run_transient(CFG, full_cycle_scenario(700.0))


def test_lag_is_exact_exponential():
    assert lag(0.0, 1.0, 2.0, 2.0) == pytest.approx(1 - math.exp(-1))
    assert lag(5.0, 1.0, 0.0, 1.0) == 1.0
    x = 0.0
    for _ in range(10):
        x = lag(x, 1.0, 3.0, 0.5)
    assert x == pytest.approx(lag(0.0, 1.0, 3.0, 5.0), rel=1e-12)  # step-size independent


def test_state_machine_visits_every_state_in_order(cycle):
    seq = [t["to"] for t in cycle.transitions]
    expected = ["INITIALISING", "PROPELLANT_FLOW", "PLASMA_START", "IONISATION", "EXTRACTION", "BEAM_ESTABLISHED",
                "STEADY_OPERATION", "SHUTDOWN", "COOLDOWN", "OFF"]
    assert seq == expected
    for a, b in zip(cycle.transitions, cycle.transitions[1:], strict=False):
        assert EngineMode(b["to"]) in TRANSITIONS[EngineMode(a["to"])]
    assert all(t2["t_s"] >= t1["t_s"] for t1, t2 in zip(cycle.transitions, cycle.transitions[1:], strict=False))


def test_nothing_changes_instantaneously(cycle):
    h = cycle.history
    assert h["thrust_n"].iloc[0] == 0.0
    steps = h["thrust_n"].diff().abs().iloc[1:]
    assert steps.max() < 0.35 * h["thrust_n"].max()  # no jump to nominal in a single step
    assert (h["mass_flow_kg_s"].diff().abs().iloc[1:] < 0.5 * h["mass_flow_kg_s"].max()).all()


def test_startup_order_flow_plasma_grid_beam_neutraliser_thrust(cycle):
    h = cycle.history

    def first(col, level):
        return h.loc[h[col] > level, "time_s"].iloc[0]

    t_ready = first("neutraliser_readiness", 0.5)
    t_flow = first("mass_flow_kg_s", 0.5 * 3.0e-6)
    t_plasma = first("plasma_power_w", 10.0)
    t_grid = first("beam_voltage_v", 5.5)  # screen grid must exceed the plume potential hill before any ion leaves
    t_beam = first("beam_current_a", 0.1)
    t_thrust = first("thrust_n", 1e-3)
    assert t_ready < t_flow < t_plasma < t_grid <= t_beam <= t_thrust
    assert h["neutraliser_current_a"].iloc[h.index[h["beam_current_a"] > 0.1][0]] >= 0.1  # electrons available when beam appears


def test_reaches_nominal_thrust_and_matches_steady_solver(cycle):
    hold = cycle.hold_state
    tgt = cycle.target_state
    assert hold.performance_state.thrust_n == pytest.approx(tgt.performance_state.thrust_n, rel=0.01)
    assert hold.beam_state.beam_current_a == pytest.approx(tgt.beam_state.beam_current_a, rel=0.01)
    assert cycle.history["thrust_n"].max() == pytest.approx(tgt.performance_state.thrust_n, rel=0.02)


def test_balances_hold_at_every_time_step(cycle):
    assert cycle.energy_balance_failures == 0 and cycle.mass_balance_failures == 0
    assert cycle.max_energy_residual_rel < 1e-9 and cycle.max_mass_residual_rel < 1e-9
    assert (cycle.history["energy_status"] == "PASS").all() and (cycle.history["mass_status"] == "PASS").all()


def test_stored_discharge_energy_is_accounted(cycle):
    h = cycle.history
    assert h["p_stored_w"].abs().max() > 1.0  # the plasma lag stores energy during ramps ...
    assert h.loc[h["mode"] == "STEADY_OPERATION", "p_stored_w"].abs().max() < 1e-3  # ... and none at steady state
    # energy put into the reservoir over the whole cycle is returned: integral of P_stored = tau * (P_end - P_start) = 0
    tau = CFG.timing.plasma_s
    u_peak = tau * h["plasma_power_w"].max()
    assert abs(np.trapezoid(h["p_stored_w"], h["time_s"])) < 1e-3 * u_peak


def test_thermal_state_evolves_slowly_and_cools(cycle):
    h = cycle.history
    assert h["temp_grids_k"].iloc[0] == pytest.approx(300.0)
    assert h["temp_grids_k"].max() > 340.0
    assert h["temp_grids_k"].iloc[-1] < h["temp_grids_k"].max() - 10.0
    peak_i = h["temp_neutraliser_k"].idxmax()
    assert h["time_s"].iloc[peak_i] > 100.0  # thermal lag: not instantaneous


def test_shutdown_order_beam_grids_neutraliser_plasma_flow(cycle):
    h = cycle.history
    t_sd = [t["t_s"] for t in cycle.transitions if t["to"] == "SHUTDOWN"][0]
    after = h[h["time_s"] >= t_sd]

    def last_above(col, level):
        return after.loc[after[col] > level, "time_s"].iloc[-1]

    t_beam = last_above("beam_current_a", 0.01)
    t_grid = last_above("beam_voltage_v", 5.0)
    t_plasma = last_above("plasma_power_w", 1.0)
    t_flow = last_above("mass_flow_kg_s", 1e-8)
    assert t_beam <= t_grid + 1.0 and t_grid < t_plasma < t_flow
    assert after["thrust_n"].iloc[-1] == pytest.approx(0.0, abs=1e-6)


def test_ion_beam_never_exists_without_neutralisation(cycle):
    h = cycle.history
    beam = h[h["beam_current_a"] > 0.2]
    assert beam["neutralised"].all()


def test_throttle_event_moves_to_new_setpoint():
    sc = Scenario("t", 900.0, [Event(0, "start"), Event(450, "throttle", {"operating_point": {"mass_flow_kg_s": 2.0e-6, "beam_current_a": 1.17}})],
                  stop_when_off=False)
    r = run_transient(CFG, sc)
    modes = [t["to"] for t in r.transitions]
    assert "THROTTLING" in modes
    late = r.history.iloc[-1]
    assert late["beam_current_a"] == pytest.approx(1.17, rel=0.03)
    assert late["thrust_n"] < r.history["thrust_n"].max() * 0.8


def test_fault_event_during_operation_heats_the_grid():
    base = run_transient(CFG, Scenario("a", 700.0, [Event(0, "start")], stop_when_off=False))
    f = run_transient(CFG, Scenario("b", 700.0, [Event(0, "start"), Event(300, "fault", {"name": "grid_interception_increase", "magnitude": 8.0})],
                                    stop_when_off=False))
    assert f.history["temp_grids_k"].iloc[-1] > base.history["temp_grids_k"].iloc[-1] + 1.0
    assert f.history["intercepted_current_a"].iloc[-1] > 5 * base.history["intercepted_current_a"].iloc[-1]


def test_illegal_transition_is_refused():
    sim = TransientSimulator(CFG, Scenario("x", 10.0, []))
    assert EngineMode.STEADY_OPERATION not in TRANSITIONS[EngineMode.OFF]
    assert sim.mode == EngineMode.OFF


def test_neutraliser_time_constant_is_the_configured_one():
    h = run_transient(CFG, Scenario("n", 100.0, [Event(0, "start")], stop_when_off=False)).history
    tau = CFG.timing.neutraliser_s
    for t_probe in (tau, 2 * tau):
        row = h.iloc[(h["time_s"] - t_probe).abs().argmin()]
        assert row["neutraliser_readiness"] == pytest.approx(1 - math.exp(-row["time_s"] / tau), rel=1e-6)


def test_history_is_finite(cycle):
    num = cycle.history.select_dtypes("number")
    assert np.isfinite(num.to_numpy()).all()
