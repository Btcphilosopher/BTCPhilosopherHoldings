import numpy as np
import pytest
from hypothesis import given, settings
from hypothesis import strategies as st

from ion_core import constants as k
from ion_core.configuration import EngineConfig, OperatingPoint
from ion_core.diagnostics.energy_balance import energy_balance
from ion_core.diagnostics.mass_balance import mass_balance
from ion_core.power.electrical import ppu_chain
from ion_core.simulation.solver import solve_steady_state
from ion_core.thermal.model import ThermalNetwork
from ion_core.thermal.radiation import radiated_power

CFG = EngineConfig()


def test_radiation_formula_and_zero_at_equilibrium():
    assert radiated_power(0.7, 0.8, 350.0, 300.0) == pytest.approx(0.7 * k.SIGMA_SB * 0.8 * (350.0**4 - 300.0**4), rel=1e-14)
    assert radiated_power(0.7, 0.8, 300.0, 300.0) == 0.0
    assert radiated_power(0.7, 0.8, 250.0, 300.0) < 0  # net absorption below environment


def test_isolated_nodes_reach_analytic_radiative_equilibrium():
    net = ThermalNetwork(CFG.thermal.model_copy(update={"conductances_w_k": {}}))
    q = np.array([80.0, 40.0, 5.0, 20.0, 10.0])
    t, ok = net.steady_state(q)
    assert ok
    assert t == pytest.approx((q / (net.eps * k.SIGMA_SB * net.area) + 300.0**4) ** 0.25, rel=1e-10)


def test_network_steady_state_conserves_heat(nominal):
    th = nominal.thermal_state
    assert th.steady_state_solved
    assert th.total_generated_w == pytest.approx(th.total_radiated_w, rel=1e-7)
    assert all(abs(n.stored_rate_w) < 1e-4 for n in th.nodes.values())
    assert sum(n.conducted_heat_w for n in th.nodes.values()) == pytest.approx(0.0, abs=1e-8)  # conduction only moves heat


def test_thermal_rk4_relaxes_to_steady_state():
    net = ThermalNetwork(CFG.thermal)
    q = np.array([120.0, 25.0, 42.0, 270.0, 0.0])
    t_ss, _ = net.steady_state(q)
    t = net.initial()
    for _ in range(3000):
        t = net.step_rk4(t, q, 5.0, 1.0)
    assert t == pytest.approx(t_ss, rel=2e-3)


def test_hotter_environment_gives_hotter_engine():
    cold = solve_steady_state(CFG.with_updates({"thermal.environment_temperature_k": 4.0}))
    warm = solve_steady_state(CFG.with_updates({"thermal.environment_temperature_k": 330.0}))
    assert warm.thermal_state.nodes["structure"].temperature_k > cold.thermal_state.nodes["structure"].temperature_k


def test_ppu_every_stage_has_visible_loss():
    r = ppu_chain(CFG.ppu, p_discharge_w=300, p_beam_w=1900, p_accel_w=10, p_neutraliser_w=42, p_aux_w=25)
    assert r.p_input_w == pytest.approx(r.p_output_total_w + r.p_ppu_loss_w, rel=1e-14)
    assert sum(s.p_loss_w for s in r.stages) + r.input_stage_loss_w == pytest.approx(r.p_ppu_loss_w, rel=1e-12)
    for s in r.stages:
        assert s.p_loss_w == pytest.approx(s.p_in_w - s.p_out_w, rel=1e-14) and s.p_loss_w > 0
    assert r.bus_current_a * r.bus_voltage_v == pytest.approx(r.p_input_w, rel=1e-14)


def test_ppu_efficiency_degradation_raises_input_power():
    a = ppu_chain(CFG.ppu, p_discharge_w=300, p_beam_w=1900, p_accel_w=10, p_neutraliser_w=42, p_aux_w=25)
    b = ppu_chain(CFG.ppu, p_discharge_w=300, p_beam_w=1900, p_accel_w=10, p_neutraliser_w=42, p_aux_w=25, efficiency_delta=-0.05)
    assert b.p_input_w > a.p_input_w


def test_energy_balance_closes_and_residual_is_displayed(nominal):
    eb = nominal.energy_balance
    assert eb.status == "PASS" and abs(eb.relative_residual) < 1e-12
    assert eb.residual_w == pytest.approx(eb.p_input_w - eb.p_accounted_w)
    assert "ENERGY BALANCE: PASS" in eb.message
    assert nominal.power_state.p_input_w == pytest.approx(
        nominal.power_state.p_ppu_loss_w + nominal.power_state.p_discharge_w + nominal.power_state.p_grid_w
        + nominal.power_state.p_neutraliser_w + nominal.power_state.p_auxiliary_w, rel=1e-12)


def test_energy_balance_fails_loudly_when_unbalanced():
    eb = energy_balance(p_input_w=1000, p_beam_w=500, p_ionisation_w=10, p_grid_loss_w=5, p_neutraliser_w=40, p_thermal_w=400,
                        p_other_w=10, p_stored_w=0, tolerance=1e-3)
    assert eb.status == "FAIL" and eb.residual_w == pytest.approx(35.0)
    assert "ENERGY BALANCE: FAIL" in eb.message


def test_mass_balance_fail_and_pass():
    ok = mass_balance(m_in=1e-6, m_ion_beam=6e-7, m_electrons=0, m_ion_intercepted=0, m_neutral_chamber=3e-7, m_neutraliser=1e-7,
                      m_leak=0, m_stored=0, tolerance=1e-6)
    bad = mass_balance(m_in=1e-6, m_ion_beam=6e-7, m_electrons=0, m_ion_intercepted=0, m_neutral_chamber=2e-7, m_neutraliser=1e-7,
                       m_leak=0, m_stored=0, tolerance=1e-6)
    assert ok.status == "PASS" and bad.status == "FAIL" and bad.residual_kg_s == pytest.approx(1e-7)


def test_mass_balance_terms_distinguish_ion_and_neutral_flows(nominal):
    m = nominal.mass_balance
    assert m.status == "PASS" and abs(m.relative_residual) < 1e-12
    assert m.m_dot_ion_kg_s > m.m_dot_neutral_kg_s * 0  # separate named terms
    assert m.m_dot_in_kg_s == pytest.approx(m.m_dot_ion_kg_s + m.m_dot_neutral_kg_s + m.m_dot_loss_kg_s, rel=1e-12)


def test_leak_channel_appears_in_loss_term_and_balance_still_closes():
    s = solve_steady_state(CFG.with_updates({"flow.leak_fraction": 0.02}))
    assert s.mass_balance.m_dot_loss_kg_s == pytest.approx(0.02 * 3.0e-6)
    assert s.mass_balance.status == "PASS"


def test_grid_interception_feeds_grid_thermal_node(nominal):
    g, q = nominal.grid_state, nominal.power_state.heat_generated_w
    assert q["grids"] > g.intercepted_current_a * nominal.beam_state.beam_voltage_v  # + accel bias, recombination, screen web
    hot = solve_steady_state(CFG.with_updates({"grids.interception_fraction_base": 0.03}))
    assert hot.power_state.heat_generated_w["grids"] > q["grids"]
    assert hot.thermal_state.nodes["grids"].temperature_k > nominal.thermal_state.nodes["grids"].temperature_k
    assert hot.thermal_state.nodes["grids"].margin_k < nominal.thermal_state.nodes["grids"].margin_k


def test_thermal_limit_breach_reported_not_clamped():
    s = solve_steady_state(CFG.with_updates({"grids.interception_fraction_base": 0.06, "limits.max_grid_temperature_k": 410.0}))
    assert s.limits.status in ("LIMIT", "INVALID")
    c = next(c for c in s.limits.checks if c.name == "grids_temperature")
    assert c.status == "LIMIT" and c.value > 410.0  # the true value is shown


def test_nominal_is_valid_and_limit_taxonomy(nominal):
    assert nominal.limits.status == "VALID"
    assert {c.status for c in nominal.limits.checks} == {"VALID"}
    warn = solve_steady_state(CFG.with_updates({"limits.max_beam_current_a": 1.85}))
    assert warn.limits.status == "WARNING"
    lim = solve_steady_state(CFG.with_updates({"limits.max_beam_current_a": 1.5}))
    assert lim.limits.status == "LIMIT"
    inv = solve_steady_state(CFG, OperatingPoint(mass_flow_kg_s=2.0e-6, beam_voltage_v=1100, beam_current_a=1.76))
    assert inv.limits.status == "INVALID" and inv.grid_state.extracted_current_a > 0
    assert any(c.name == "propellant_available" for c in inv.limits.checks if c.status == "INVALID")


def test_neutraliser_must_neutralise_beam():
    ok = solve_steady_state(CFG)
    assert ok.neutraliser_state.neutralised and ok.neutraliser_state.charge_imbalance_a < 0
    assert ok.neutraliser_state.delivered_emission_a == pytest.approx(0.98 * 1.1 * 1.76)
    bad = solve_steady_state(CFG, OperatingPoint(mass_flow_kg_s=3.0e-6, beam_voltage_v=1100, beam_current_a=1.76, neutraliser_current_a=1.5))
    assert not bad.neutraliser_state.neutralised and bad.limits.status == "INVALID"
    assert bad.neutraliser_state.neutralisation_efficiency < 1
    assert bad.neutraliser_state.charge_imbalance_a == pytest.approx(1.76 - 0.98 * 1.5)


def test_neutraliser_power_is_heat_on_its_node(nominal):
    n = nominal.neutraliser_state
    assert n.power_w == pytest.approx(n.heater_power_w + n.keeper_power_w) and n.heat_w == n.power_w
    assert nominal.power_state.heat_generated_w["neutraliser"] == pytest.approx(n.heat_w)


@settings(max_examples=60, deadline=None)
@given(v=st.floats(500, 1500), i=st.floats(0.6, 2.2), util=st.floats(0.75, 0.93))
def test_property_balances_close_or_the_point_is_flagged_invalid(v, i, util):
    flow = i / k.E_CHARGE * CFG.species.ion_mass / util / (1 - CFG.flow.neutraliser_flow_fraction)
    s = solve_steady_state(CFG, OperatingPoint(mass_flow_kg_s=flow, beam_voltage_v=v, beam_current_a=i))
    failed = s.energy_balance.status == "FAIL" or s.mass_balance.status == "FAIL"
    if failed:  # a failed balance is never silent
        assert s.limits.status == "INVALID"
        assert any(c.name in ("energy_balance", "mass_balance") and c.status == "INVALID" for c in s.limits.checks)
    if s.limits.status != "INVALID":
        assert s.energy_balance.status == "PASS" and s.mass_balance.status == "PASS"
        assert abs(s.energy_balance.relative_residual) < 1e-9
        assert s.thermal_state.total_generated_w == pytest.approx(s.thermal_state.total_radiated_w, rel=1e-6)
    assert s.power_state.p_input_w > s.beam_state.beam_power_w


def test_propellant_starved_point_shows_mass_residual_and_invalid():
    s = solve_steady_state(CFG, OperatingPoint(mass_flow_kg_s=2.0e-6, beam_voltage_v=1100, beam_current_a=1.76))
    assert s.mass_balance.status == "FAIL" and s.mass_balance.residual_kg_s != 0.0
    assert "MASS BALANCE: FAIL" in s.mass_balance.message
    assert s.limits.status == "INVALID"


def test_input_power_exceeds_every_downstream_power(nominal):
    p = nominal.power_state
    assert p.p_input_w > p.p_output_total_w > p.p_discharge_w
    assert p.p_input_w > nominal.performance_state.jet_power_w
    e = nominal.performance_state.efficiencies
    assert e["overall"] == pytest.approx(e["thruster"] * e["ppu"], rel=1e-12)
