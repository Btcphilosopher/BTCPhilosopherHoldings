import math

import pytest
from scipy.integrate import quad

from ion_core import constants as k
from ion_core.configuration import EngineConfig, OperatingPoint
from ion_core.plasma.chamber import solve_electron_temperature, solve_plasma
from ion_core.plasma.density import ion_density, neutral_effusion_rate, neutral_mean_speed
from ion_core.plasma.ionisation import (
    excitation_rate_coefficient,
    ionisation_cross_section,
    ionisation_rate_coefficient,
)
from ion_core.plasma.ions import bohm_velocity, floating_potential_v
from ion_core.propellant.species import XENON, PropellantSpecies, register_species
from ion_core.simulation.solver import solve_steady_state

CFG = EngineConfig()


def test_cross_section_threshold_and_peak():
    assert ionisation_cross_section(XENON.ionisation_energy_ev * 0.99, XENON)[0] == 0.0
    e = [20, 40, 80, 160, 600]
    s = [ionisation_cross_section(x, XENON)[0] for x in e]
    assert max(s) == s[1] or max(s) == s[2]  # peak at a few times threshold
    assert 1e-20 < max(s) < 1e-19


@pytest.mark.parametrize("te", [1.0, 2.5, 4.0, 8.0, 20.0])
def test_rate_coefficient_vs_quadrature(te):
    f = lambda en: ionisation_cross_section(en, XENON)[0] * math.sqrt(2 * en * k.E_CHARGE / k.M_ELECTRON) \
        * 2 * math.sqrt(en / math.pi) * te**-1.5 * math.exp(-en / te)  # noqa: E731
    p = XENON.ionisation_energy_ev
    ref = quad(f, p, p + 80 * te, limit=800, epsabs=0, epsrel=1e-12)[0]
    assert ionisation_rate_coefficient(te, XENON) == pytest.approx(ref, rel=2e-5)


def test_rate_coefficient_monotonic_in_te():
    vals = [ionisation_rate_coefficient(t, XENON) for t in (1, 2, 3, 5, 8, 13, 21)]
    assert all(b > a for a, b in zip(vals, vals[1:], strict=False))
    assert excitation_rate_coefficient(3.0, XENON) > 0


def test_electron_temperature_falls_with_neutral_density():
    ch, a_loss = CFG.chamber, 0.16
    t_lo, ok1 = solve_electron_temperature(XENON, ch, 5e17, a_loss)
    t_hi, ok2 = solve_electron_temperature(XENON, ch, 5e18, a_loss)
    assert ok1 and ok2 and t_hi < t_lo


def test_plasma_not_sustained_without_neutrals():
    _, ok = solve_electron_temperature(XENON, CFG.chamber, 1e10, 0.16)
    assert not ok


def test_ionisation_is_connected_to_density_and_temperature(nominal):
    p = nominal.plasma_state
    v = CFG.chamber.volume_m3
    assert p.ionisation_rate_density_m3_s == pytest.approx(p.electron_density_m3 * p.neutral_density_m3 * p.ionisation_rate_coefficient_m3_s, rel=1e-12)
    assert p.ion_production_rate_s == pytest.approx(p.ionisation_rate_density_m3_s * v, rel=1e-9)
    assert p.ionisation_rate_coefficient_m3_s > 0 and 0 < p.ionisation_probability <= 1


def test_quasi_neutrality_and_bohm(nominal):
    p = nominal.plasma_state
    assert p.ion_density_m3 == pytest.approx(ion_density(p.electron_density_m3))
    assert p.quasi_neutrality_error == 0.0
    assert p.bohm_velocity_m_s == pytest.approx(bohm_velocity(p.electron_temperature_ev, XENON.ion_mass))
    assert p.floating_potential_v == pytest.approx(floating_potential_v(p.electron_temperature_ev, XENON.ion_mass)) if hasattr(p, "floating_potential_v") else True


def test_ionisation_efficiency_is_computed_not_assumed(nominal):
    e = nominal.performance_state.efficiencies
    bud = nominal.plasma_state.discharge_budget
    i_ext = nominal.grid_state.extracted_current_a
    assert e["ionisation"] == pytest.approx(i_ext * XENON.ionisation_energy_ev / bud["p_discharge_w"], rel=1e-12)
    assert e["ion_production_cost_ev_per_ion"] == pytest.approx(bud["p_discharge_w"] / nominal.beam_state.beam_current_a, rel=1e-12)
    assert 0.01 < e["ionisation"] < 0.3  # thermodynamic cost >> ionisation potential


def test_discharge_budget_closes_and_residual_visible(nominal):
    b = nominal.plasma_state.discharge_budget
    ch = ("p_ionisation_w", "p_excitation_w", "p_ion_potential_w", "p_wall_w", "p_radiation_w", "p_electron_loss_w", "p_other_w")
    assert sum(b[c] for c in ch) == pytest.approx(b["p_discharge_w"], rel=1e-12)
    assert b["residual_w"] == pytest.approx(0.0, abs=1e-9)
    assert nominal.plasma_state.discharge_residual_w == b["residual_w"]


def test_more_discharge_power_gives_more_plasma_and_beam():
    lo = solve_steady_state(CFG, OperatingPoint(mass_flow_kg_s=3.0e-6, beam_voltage_v=1100.0, discharge_power_w=250.0))
    hi = solve_steady_state(CFG, OperatingPoint(mass_flow_kg_s=3.0e-6, beam_voltage_v=1100.0, discharge_power_w=340.0))
    assert hi.plasma_state.electron_density_m3 > lo.plasma_state.electron_density_m3
    assert hi.beam_state.beam_current_a > lo.beam_state.beam_current_a
    assert hi.performance_state.thrust_n > lo.performance_state.thrust_n


def test_infeasible_discharge_power_for_commanded_beam_is_invalid():
    s = solve_steady_state(CFG, OperatingPoint(mass_flow_kg_s=3.0e-6, beam_voltage_v=1100.0, beam_current_a=1.76, discharge_power_w=150.0))
    assert s.limits.status == "INVALID"
    assert any(c.name == "extraction_supply" and c.status == "INVALID" for c in s.limits.checks)


def test_custom_species_registered_at_runtime():
    sp = PropellantSpecies(species_name="demo_gas", atomic_mass_u=100.0, ionisation_energy_ev=13.0, lotz_shells=((6, 13.0),),
                           excitation_threshold_ev=9.0, excitation_cross_section_m2=1e-20)
    register_species(sp)
    s = solve_steady_state(CFG.with_updates({"propellant.species": "demo_gas"}),
                           OperatingPoint(mass_flow_kg_s=2.4e-6, beam_voltage_v=1000.0, beam_current_a=1.5))
    assert s.propellant_flow.species_name == "demo_gas"
    assert s.beam_state.ion_velocity_ideal_m_s == pytest.approx(math.sqrt(2 * k.E_CHARGE * 1000.0 / sp.ion_mass), rel=1e-12)


def test_higher_charge_state_is_refused_not_silently_approximated():
    sp = XENON.model_copy(update={"charge_state": 2, "species_name": "xe2"})
    register_species(sp)
    with pytest.raises(NotImplementedError):
        solve_steady_state(CFG.with_updates({"propellant.species": "xe2"}))


def test_neutral_helpers():
    v = neutral_mean_speed(400.0, XENON.atomic_mass)
    assert v == pytest.approx(math.sqrt(8 * k.K_B * 400 / (math.pi * XENON.atomic_mass)))
    assert neutral_effusion_rate(1e18, v, 1e-2) == pytest.approx(0.25 * 1e18 * v * 1e-2)


def test_solve_plasma_regulated_vs_fixed_consistent():
    reg = solve_plasma(XENON, CFG.chamber, n_neutral=3e18, screen_area_m2=0.0616, ion_open_area_m2=0.0473, n_ext_rate=1.1e19, p_discharge_w=None)
    p_d = reg.p_absorbed_w / reg.absorb_fraction
    fix = solve_plasma(XENON, CFG.chamber, n_neutral=3e18, screen_area_m2=0.0616, ion_open_area_m2=0.0473, n_ext_rate=1.1e19, p_discharge_w=p_d)
    assert fix.ion_generation_rate == pytest.approx(reg.ion_generation_rate, rel=1e-12)
    assert fix.extraction_capacity_rate == pytest.approx(1.1e19, rel=1e-9)


def test_electron_helpers():
    from ion_core.plasma.electrons import mean_energy_ev, mean_speed, wall_loss_energy_ev
    assert mean_speed(4.0) == pytest.approx(math.sqrt(8 * 4.0 * k.E_CHARGE / (math.pi * k.M_ELECTRON)))
    assert mean_speed(0.0) == 0.0
    assert mean_energy_ev(4.0) == 6.0 and wall_loss_energy_ev(4.0) == 8.0


def test_lotz_rate_zero_at_zero_temperature_and_cross_section_array():
    assert ionisation_rate_coefficient(0.0, XENON) == 0.0
    s = ionisation_cross_section([5.0, 15.0, 50.0], XENON)
    assert s[0] == 0.0 and s[1] > 0 and s[2] > s[1]
