"""ION-CORE — engineering-system-level simulator of a gridded electrostatic ion engine."""

__version__ = "0.1.0"
MODEL_VERSION = "ion-core-ro-1.0 (reduced-order global discharge + planar Child-Langmuir extraction)"
