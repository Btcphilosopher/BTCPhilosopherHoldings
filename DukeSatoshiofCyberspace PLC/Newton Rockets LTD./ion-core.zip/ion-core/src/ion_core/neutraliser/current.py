"""Neutraliser emission current logic."""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class EmissionResult:
    commanded_a: float
    capability_a: float
    delivered_a: float
    neutralisation_current_a: float  # electrons actually neutralising the beam
    neutralisation_ratio: float  # delivered / I_beam
    neutralisation_efficiency: float  # min(delivered, I_beam) / I_beam
    charge_imbalance_a: float  # I_beam - delivered (>0: plume net positive)
    neutralised: bool


def emission(*, beam_current_a: float, commanded_a: float, efficiency: float, capability_a: float,
             tolerance: float = 1e-3) -> EmissionResult:
    delivered = max(min(efficiency * commanded_a, capability_a), 0.0)
    neutralising = min(delivered, beam_current_a)
    ratio = delivered / beam_current_a if beam_current_a > 0 else float("inf")
    eff = neutralising / beam_current_a if beam_current_a > 0 else 1.0
    imbalance = beam_current_a - delivered
    return EmissionResult(commanded_a, capability_a, delivered, neutralising, ratio, eff,
                          imbalance, imbalance <= tolerance * max(beam_current_a, 1e-12))
