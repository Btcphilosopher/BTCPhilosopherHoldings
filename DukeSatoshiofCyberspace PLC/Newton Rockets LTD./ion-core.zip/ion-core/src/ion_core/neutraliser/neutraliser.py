"""Neutraliser (hollow-cathode style) as a part of the propulsion system.

Electrical power = heater + keeper (V_k I_k); all of it ends up as heat on the neutraliser
node. Emission capability = I_max * readiness * health factor, with readiness a first-order
lag (thermal/ignition state of the cathode) handled in the transient solver.
"""

from __future__ import annotations

from dataclasses import dataclass

from ..configuration import NeutraliserConfig
from .current import EmissionResult, emission


@dataclass(frozen=True)
class NeutraliserResult:
    emission: EmissionResult
    heater_power_w: float
    keeper_power_w: float
    power_w: float  # neutraliser electrical power
    heat_w: float  # neutraliser heat
    required_current_a: float  # = beam current


def neutraliser_state(cfg: NeutraliserConfig, *, beam_current_a: float, commanded_a: float | None,
                      readiness: float, health_factor: float, on: bool,
                      tolerance: float = 1e-3) -> NeutraliserResult:
    cmd = cfg.emission_margin * beam_current_a if commanded_a is None else commanded_a
    capability = cfg.max_emission_current_a * readiness * health_factor if on else 0.0
    em = emission(beam_current_a=beam_current_a, commanded_a=cmd if on else 0.0,
                  efficiency=cfg.efficiency, capability_a=capability, tolerance=tolerance)
    heater = cfg.heater_power_w if on else 0.0
    keeper = cfg.keeper_voltage_v * cfg.keeper_current_a if on else 0.0
    return NeutraliserResult(em, heater, keeper, heater + keeper, heater + keeper, beam_current_a)
