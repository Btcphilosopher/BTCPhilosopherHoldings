"""Beam model: Rayleigh-distributed polar-angle divergence (Gaussian transverse velocity).

p(theta) = (theta / sigma^2) exp(-theta^2 / 2 sigma^2) on [0, pi/2] (renormalised).
Axial momentum factor gamma = <cos theta>; axial energy factor <cos^2 theta>.
"""

from __future__ import annotations

import math
from dataclasses import dataclass

import numpy as np

_XG, _WG = np.polynomial.legendre.leggauss(96)


def divergence_factors(sigma_rad: float) -> tuple[float, float]:
    """(<cos theta>, <cos^2 theta>) for the Rayleigh divergence distribution."""
    if sigma_rad <= 1e-9:
        return 1.0, 1.0
    top = min(math.pi / 2.0, 9.0 * sigma_rad)
    th = 0.5 * top * (_XG + 1.0)
    w = 0.5 * top * _WG
    p = (th / sigma_rad**2) * np.exp(-th * th / (2.0 * sigma_rad**2))
    norm = float(np.sum(w * p))
    return float(np.sum(w * p * np.cos(th)) / norm), float(np.sum(w * p * np.cos(th) ** 2) / norm)


def beam_half_angle_95(sigma_rad: float) -> float:
    """Half-angle containing 95% of the current: sqrt(-2 ln 0.05) sigma."""
    return min(math.sqrt(-2.0 * math.log(0.05)) * sigma_rad, math.pi / 2.0 - 1e-6)


def beam_diameter(active_diameter_m: float, distance_m: float, half_angle_rad: float) -> float:
    return active_diameter_m + 2.0 * distance_m * math.tan(half_angle_rad)


@dataclass(frozen=True)
class BeamGeometry:
    sigma_rad: float
    half_angle_95_rad: float
    gamma: float  # <cos theta>
    cos2_mean: float
    diameter_m: float
    cross_section_m2: float


def beam_geometry(sigma_rad: float, active_diameter_m: float, distance_m: float) -> BeamGeometry:
    g, c2 = divergence_factors(sigma_rad)
    ha = beam_half_angle_95(sigma_rad)
    d = beam_diameter(active_diameter_m, distance_m, ha)
    return BeamGeometry(sigma_rad, ha, g, c2, d, math.pi * 0.25 * d * d)
