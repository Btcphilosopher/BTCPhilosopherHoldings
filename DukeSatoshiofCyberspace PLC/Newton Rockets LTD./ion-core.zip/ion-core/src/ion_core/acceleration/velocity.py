"""Ion exhaust speed. Three distinct quantities are kept apart:

* ideal      v = sqrt(2 q V_acc / m_i)              with V_acc = commanded beam voltage
* effective  same expression with the modelled effective voltage (plasma offset, plume coupling)
* calibrated effective speed x a measured/modelled calibration factor (None if not provided)
"""

from __future__ import annotations

import math
from dataclasses import dataclass


def ion_speed(charge_c: float, voltage_v: float, ion_mass_kg: float) -> float:
    """v = sqrt(2 q V / m); zero for V <= 0."""
    return math.sqrt(2.0 * charge_c * voltage_v / ion_mass_kg) if voltage_v > 0.0 else 0.0


@dataclass(frozen=True)
class IonVelocities:
    ideal_m_s: float
    effective_m_s: float
    calibrated_m_s: float | None
    calibration_factor: float | None


def ion_velocities(charge_c: float, ion_mass_kg: float, beam_voltage_v: float,
                   effective_voltage_v: float, calibration_factor: float | None) -> IonVelocities:
    v_eff = ion_speed(charge_c, effective_voltage_v, ion_mass_kg)
    return IonVelocities(ion_speed(charge_c, beam_voltage_v, ion_mass_kg), v_eff,
                         None if calibration_factor is None else v_eff * calibration_factor,
                         calibration_factor)
