"""Ideal electrostatic acceleration energy: E_ion = q V_acc."""

from __future__ import annotations


def ion_energy_j(charge_c: float, voltage_v: float) -> float:
    return charge_c * voltage_v


def effective_acceleration_voltage(beam_voltage_v: float, plasma_offset_v: float,
                                   plume_potential_v: float) -> float:
    """V_eff = V_screen + (V_plasma - V_screen) - V_plume.

    Ions are born at the plasma potential (offset dV_p above the screen grid) and finish
    at the plume plasma potential V_c above the neutraliser common.
    """
    return beam_voltage_v + plasma_offset_v - plume_potential_v
