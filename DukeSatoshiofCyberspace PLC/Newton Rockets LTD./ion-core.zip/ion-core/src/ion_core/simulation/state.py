"""Serialisable engine state. Every quantity is SI; the name suffix carries the unit."""

from __future__ import annotations

import dataclasses
import math
from dataclasses import dataclass, field
from enum import Enum, StrEnum
from typing import Any

from ..diagnostics.convergence import ConvergenceRecord
from ..diagnostics.energy_balance import EnergyBalance
from ..diagnostics.mass_balance import MassBalance


class EngineMode(StrEnum):
    OFF = "OFF"
    INITIALISING = "INITIALISING"
    PROPELLANT_FLOW = "PROPELLANT_FLOW"
    PLASMA_START = "PLASMA_START"
    IONISATION = "IONISATION"
    EXTRACTION = "EXTRACTION"
    BEAM_ESTABLISHED = "BEAM_ESTABLISHED"
    STEADY_OPERATION = "STEADY_OPERATION"
    THROTTLING = "THROTTLING"
    SHUTDOWN = "SHUTDOWN"
    COOLDOWN = "COOLDOWN"


class Status(StrEnum):
    VALID = "VALID"
    WARNING = "WARNING"
    LIMIT = "LIMIT"
    INVALID = "INVALID"


STATUS_ORDER = {Status.VALID: 0, Status.WARNING: 1, Status.LIMIT: 2, Status.INVALID: 3}


@dataclass
class PropellantFlowState:
    species_name: str = ""
    mass_flow_total_kg_s: float = 0.0
    mass_flow_main_kg_s: float = 0.0
    mass_flow_neutraliser_kg_s: float = 0.0
    mass_flow_leak_kg_s: float = 0.0
    atoms_per_s_main: float = 0.0
    neutral_flow_exit_kg_s: float = 0.0  # chamber neutrals through the grids
    ionised_flow_extracted_kg_s: float = 0.0  # all ions through the screen grid
    ion_flow_beam_kg_s: float = 0.0
    ion_flow_intercepted_kg_s: float = 0.0
    neutral_density_m3: float = 0.0
    neutral_temperature_k: float = 0.0
    neutral_mean_speed_m_s: float = 0.0
    propellant_utilisation: float = 0.0  # beam ion / total engine propellant
    chamber_utilisation: float = 0.0  # extracted ion / main-line propellant


@dataclass
class PlasmaState:
    sustained: bool = False
    electron_temperature_ev: float = 0.0
    ion_temperature_ev: float = 0.0
    electron_density_m3: float = 0.0
    ion_density_m3: float = 0.0
    sheath_edge_density_m3: float = 0.0
    neutral_density_m3: float = 0.0
    plasma_potential_v: float = 0.0
    quasi_neutrality_error: float = 0.0  # |n_e - sum Z n_i| / n_e (approximation, see density.py)
    bohm_velocity_m_s: float = 0.0
    floating_potential_v: float = 0.0
    ionisation_rate_coefficient_m3_s: float = 0.0
    excitation_rate_coefficient_m3_s: float = 0.0
    ionisation_frequency_per_electron_s: float = 0.0
    ionisation_frequency_per_neutral_s: float = 0.0
    ionisation_rate_density_m3_s: float = 0.0
    ion_production_rate_s: float = 0.0  # N_g, ions/s
    ion_extracted_rate_s: float = 0.0
    ion_wall_loss_rate_s: float = 0.0
    ionisation_probability: float = 0.0
    ion_balance_residual: float = 0.0
    extraction_capacity_rate_s: float = 0.0
    extraction_supply_margin_s: float = 0.0
    energy_per_ion_ionisation_ev: float = 0.0
    discharge_budget: dict[str, float] = field(default_factory=dict)
    discharge_residual_w: float = 0.0
    approximations: tuple[str, ...] = (
        "0-D global model; Maxwellian electrons; n_e = n_i/Z quasi-neutrality; "
        "uniform density with edge/bulk ratio h",)


@dataclass
class GridState:
    screen_grid_potential_v: float = 0.0
    accelerator_grid_potential_v: float = 0.0
    plasma_potential_v: float = 0.0
    plume_potential_v: float = 0.0
    extraction_voltage_v: float = 0.0
    electric_field_v_m: float = 0.0
    effective_gap_m: float = 0.0
    geometric_transparency: float = 0.0
    ion_transparency: float = 0.0
    extracted_current_a: float = 0.0
    intercepted_current_a: float = 0.0
    interception_fraction: float = 0.0
    perveance_ratio: float = 0.0
    space_charge_limit_a: float = 0.0
    actual_current_density_a_m2: float = 0.0
    space_charge_limit_density_a_m2: float = 0.0
    current_margin_a: float = 0.0
    space_charge_limited: bool = False
    extraction_efficiency: float = 0.0
    p_grid_loss_w: float = 0.0
    space_charge_model: str = ""


@dataclass
class BeamState:
    beam_current_a: float = 0.0
    beam_voltage_v: float = 0.0
    effective_voltage_v: float = 0.0
    beam_power_w: float = 0.0  # ideal V_acc * I_beam
    beam_kinetic_power_w: float = 0.0  # I_beam * V_eff
    ion_energy_ideal_j: float = 0.0
    ion_velocity_ideal_m_s: float = 0.0
    ion_velocity_effective_m_s: float = 0.0
    ion_velocity_calibrated_m_s: float | None = None
    ion_mass_flow_kg_s: float = 0.0
    ion_rate_s: float = 0.0
    divergence_sigma_rad: float = 0.0
    divergence_half_angle_rad: float = 0.0
    thrust_factor_gamma: float = 1.0
    beam_diameter_m: float = 0.0
    beam_density_m3: float = 0.0
    beam_current_density_a_m2: float = 0.0


@dataclass
class NeutraliserState:
    on: bool = False
    commanded_emission_a: float = 0.0
    emission_capability_a: float = 0.0
    delivered_emission_a: float = 0.0
    neutralisation_current_a: float = 0.0
    neutralisation_ratio: float = 0.0
    neutralisation_efficiency: float = 0.0
    charge_imbalance_a: float = 0.0
    neutralised: bool = True
    power_w: float = 0.0
    heater_power_w: float = 0.0
    keeper_power_w: float = 0.0
    heat_w: float = 0.0
    readiness: float = 0.0


@dataclass
class PowerState:
    p_input_w: float = 0.0
    bus_voltage_v: float = 0.0
    bus_current_a: float = 0.0
    p_ppu_loss_w: float = 0.0
    p_discharge_w: float = 0.0
    discharge_voltage_v: float = 0.0
    discharge_current_a: float = 0.0
    p_grid_w: float = 0.0  # beam + accelerator supplies
    p_beam_supply_w: float = 0.0
    p_accel_supply_w: float = 0.0
    p_beam_w: float = 0.0  # V_acc I_beam
    p_neutraliser_w: float = 0.0
    p_auxiliary_w: float = 0.0
    p_output_total_w: float = 0.0
    p_stored_w: float = 0.0
    ppu_stages: dict[str, dict[str, float]] = field(default_factory=dict)
    ledger: dict[str, float] = field(default_factory=dict)
    heat_generated_w: dict[str, float] = field(default_factory=dict)
    p_radiated_escape_w: float = 0.0


@dataclass
class ThermalNodeState:
    temperature_k: float = 0.0
    generated_heat_w: float = 0.0
    conducted_heat_w: float = 0.0
    radiated_heat_w: float = 0.0
    stored_rate_w: float = 0.0
    limit_k: float | None = None
    margin_k: float | None = None


@dataclass
class ThermalState:
    environment_k: float = 300.0
    nodes: dict[str, ThermalNodeState] = field(default_factory=dict)
    total_generated_w: float = 0.0
    total_radiated_w: float = 0.0
    time_constants_s: dict[str, float] = field(default_factory=dict)
    steady_state_solved: bool = True


@dataclass
class PerformanceState:
    thrust_n: float = 0.0
    thrust_ideal_n: float = 0.0
    thrust_gross_n: float = 0.0
    thrust_axial_ion_n: float = 0.0
    divergence_loss_n: float = 0.0
    thrust_neutral_chamber_n: float = 0.0
    thrust_neutraliser_gas_n: float = 0.0
    thrust_calibrated_n: float | None = None
    isp_s: float = 0.0
    isp_main_s: float = 0.0
    isp_ion_s: float = 0.0
    effective_exhaust_velocity_m_s: float = 0.0
    jet_power_w: float = 0.0
    thrust_to_power_n_kw: float = 0.0
    thrust_to_power_mn_kw: float = 0.0
    efficiencies: dict[str, float] = field(default_factory=dict)


@dataclass
class HealthState:
    """Effective health/fault multipliers (degradation x injected faults) + usage counters."""

    flow_factor: float = 1.0
    ppu_efficiency_delta: float = 0.0
    interception_multiplier: float = 1.0
    neutraliser_emission_factor: float = 1.0
    plasma_coupling_factor: float = 1.0
    radiator_emissivity_factor: float = 1.0
    beam_instability_amplitude: float = 0.0
    beam_instability_frequency_hz: float = 5.0
    sensor_bias: dict[str, float] = field(default_factory=dict)
    active_faults: list[str] = field(default_factory=list)
    operating_hours: float = 0.0
    propellant_throughput_kg: float = 0.0
    grid_exposure_ah: float = 0.0
    thermal_cycles: float = 0.0
    neutraliser_hours: float = 0.0
    degradation_warnings: list[str] = field(default_factory=list)


@dataclass
class LimitCheck:
    name: str
    status: str
    value: float
    limit: float | None
    margin: float | None  # fractional margin to the limit (negative = beyond)
    unit: str
    message: str = ""


@dataclass
class LimitReport:
    status: str = "VALID"
    checks: list[LimitCheck] = field(default_factory=list)

    @property
    def messages(self) -> list[str]:
        return [f"{c.status}: {c.name} — {c.message}" for c in self.checks if c.status != "VALID"]


@dataclass
class IonEngineState:
    time_s: float = 0.0
    mode: str = EngineMode.STEADY_OPERATION.value
    propellant_flow: PropellantFlowState = field(default_factory=PropellantFlowState)
    plasma_state: PlasmaState = field(default_factory=PlasmaState)
    grid_state: GridState = field(default_factory=GridState)
    beam_state: BeamState = field(default_factory=BeamState)
    neutraliser_state: NeutraliserState = field(default_factory=NeutraliserState)
    power_state: PowerState = field(default_factory=PowerState)
    thermal_state: ThermalState = field(default_factory=ThermalState)
    performance_state: PerformanceState = field(default_factory=PerformanceState)
    health_state: HealthState = field(default_factory=HealthState)
    energy_balance: EnergyBalance | None = None
    mass_balance: MassBalance | None = None
    limits: LimitReport = field(default_factory=LimitReport)
    convergence: ConvergenceRecord = field(default_factory=ConvergenceRecord)
    calculation_chain: list[dict[str, Any]] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return to_jsonable(self)


def to_jsonable(obj: Any) -> Any:
    """Recursively convert dataclasses/enums/numpy to JSON-safe python (NaN/inf -> None)."""
    import numpy as np

    if dataclasses.is_dataclass(obj) and not isinstance(obj, type):
        return {f.name: to_jsonable(getattr(obj, f.name)) for f in dataclasses.fields(obj)}
    if isinstance(obj, Enum):
        return obj.value
    if isinstance(obj, dict):
        return {str(k): to_jsonable(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [to_jsonable(v) for v in obj]
    if isinstance(obj, np.ndarray):
        return to_jsonable(obj.tolist())
    if isinstance(obj, np.generic):
        return to_jsonable(obj.item())
    if isinstance(obj, float):
        return obj if math.isfinite(obj) else None
    return obj
