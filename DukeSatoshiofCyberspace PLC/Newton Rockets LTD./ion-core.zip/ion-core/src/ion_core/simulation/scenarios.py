"""Scenario definitions (events) and the explicit start-up / throttle / shutdown state machine.

OFF -> INITIALISING -> PROPELLANT_FLOW -> PLASMA_START -> IONISATION -> EXTRACTION
    -> BEAM_ESTABLISHED -> STEADY_OPERATION <-> THROTTLING -> SHUTDOWN -> COOLDOWN -> OFF

Transition conditions are evaluated on the *physical* state (neutraliser readiness, flow,
plasma density, grid voltage, beam current), never on elapsed time alone.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from ..configuration import EngineConfig, OperatingPoint
from .state import EngineMode

# allowed transitions (documentation + runtime guard)
TRANSITIONS: dict[EngineMode, tuple[EngineMode, ...]] = {
    EngineMode.OFF: (EngineMode.INITIALISING,),
    EngineMode.INITIALISING: (EngineMode.PROPELLANT_FLOW, EngineMode.SHUTDOWN),
    EngineMode.PROPELLANT_FLOW: (EngineMode.PLASMA_START, EngineMode.SHUTDOWN),
    EngineMode.PLASMA_START: (EngineMode.IONISATION, EngineMode.SHUTDOWN),
    EngineMode.IONISATION: (EngineMode.EXTRACTION, EngineMode.SHUTDOWN),
    EngineMode.EXTRACTION: (EngineMode.BEAM_ESTABLISHED, EngineMode.SHUTDOWN),
    EngineMode.BEAM_ESTABLISHED: (EngineMode.STEADY_OPERATION, EngineMode.SHUTDOWN),
    EngineMode.STEADY_OPERATION: (EngineMode.THROTTLING, EngineMode.SHUTDOWN),
    EngineMode.THROTTLING: (EngineMode.STEADY_OPERATION, EngineMode.SHUTDOWN),
    EngineMode.SHUTDOWN: (EngineMode.COOLDOWN,),
    EngineMode.COOLDOWN: (EngineMode.OFF, EngineMode.INITIALISING),
}


@dataclass
class SequenceSettings:
    ignition_delay_s: float = 3.0
    flow_ready_fraction: float = 0.95
    plasma_ready_fraction: float = 0.95
    beam_voltage_ready_fraction: float = 0.98
    beam_current_ready_fraction: float = 0.97
    steady_tolerance: float = 0.01
    steady_dwell_s: float = 10.0
    cooldown_residual_fraction: float = 0.10  # COOLDOWN ends when every node has shed 90 % of its peak excursion
    shutdown_off_fraction: float = 0.01
    steady_time_step_s: float = 2.0
    ignition_power_fraction: float = 0.15  # discharge power until the grids are energised
    shutdown_power_fraction: float = 0.02  # discharge power held while the grids ramp down
    beam_reduced_fraction: float = 0.05  # beam current (of target) at which the grids may ramp down


@dataclass
class Event:
    t_s: float
    action: str  # start | shutdown | throttle | fault | clear_faults
    params: dict[str, Any] = field(default_factory=dict)


@dataclass
class Scenario:
    name: str
    duration_s: float
    events: list[Event]
    sequence: SequenceSettings = field(default_factory=SequenceSettings)
    operating_point: OperatingPoint | None = None
    stop_when_off: bool = True
    random_seed: int = 0

    @classmethod
    def from_dict(cls, d: dict[str, Any], cfg: EngineConfig | None = None) -> Scenario:
        events = [Event(float(e["t"]), e["action"], {k: v for k, v in e.items() if k not in ("t", "action")})
                  for e in d.get("events", [])]
        op = OperatingPoint.model_validate(d["operating_point"]) if "operating_point" in d else None
        seq = SequenceSettings(**d.get("sequence", {}))
        return cls(name=d.get("name", "scenario"), duration_s=float(d["duration_s"]), events=sorted(events, key=lambda e: e.t_s),
                   sequence=seq, operating_point=op, stop_when_off=bool(d.get("stop_when_off", True)),
                   random_seed=int(d.get("random_seed", 0)))


def startup_scenario(duration_s: float = 1500.0) -> Scenario:
    """0 -> nominal thrust, hold."""
    return Scenario("startup_to_nominal", duration_s, [Event(0.0, "start")])


def full_cycle_scenario(hold_s: float = 900.0) -> Scenario:
    """start-up, hold, throttle down, shutdown and cool-down."""
    return Scenario("full_cycle", 7000.0, [Event(0.0, "start"), Event(hold_s, "shutdown")])
