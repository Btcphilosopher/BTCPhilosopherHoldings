"""Parametric sweeps, 2-D performance maps, throttle curves and Monte Carlo.

Every point is a full steady-state solve of the physics model (no interpolation, no curve
drawn by hand)."""

from __future__ import annotations

from collections.abc import Callable, Iterable, Sequence
from typing import Any

import numpy as np
import pandas as pd
import xarray as xr

from ..configuration import EngineConfig, OperatingPoint
from .solver import solve_steady_state
from .state import HealthState, IonEngineState

# name -> (target, path): target "op" edits the OperatingPoint, "cfg" edits the EngineConfig
SWEEPABLE: dict[str, tuple[str, str]] = {
    "beam_voltage": ("op", "beam_voltage_v"),
    "beam_current": ("op", "beam_current_a"),
    "mass_flow": ("op", "mass_flow_kg_s"),
    "discharge_power": ("op", "discharge_power_w"),
    "neutraliser_current": ("op", "neutraliser_current_a"),
    "grid_spacing": ("cfg", "grids.extraction_gap_m"),
    "grid_aperture": ("cfg", "grids.aperture_diameter_m"),
}


def state_row(st: IonEngineState) -> dict[str, Any]:
    """Flat record of the quantities used in curves, maps and tables."""
    pe, pw, b, g, th, n, pf, pl = (st.performance_state, st.power_state, st.beam_state, st.grid_state,
                                   st.thermal_state, st.neutraliser_state, st.propellant_flow, st.plasma_state)
    row: dict[str, Any] = {
        "mass_flow_kg_s": pf.mass_flow_total_kg_s, "beam_voltage_v": b.beam_voltage_v, "beam_current_a": b.beam_current_a,
        "discharge_power_w": pw.p_discharge_w, "neutraliser_current_a": n.delivered_emission_a,
        "thrust_n": pe.thrust_n, "isp_s": pe.isp_s, "p_input_w": pw.p_input_w, "p_beam_w": pw.p_beam_w,
        "p_ppu_loss_w": pw.p_ppu_loss_w, "thrust_to_power_mn_kw": pe.thrust_to_power_mn_kw,
        "thrust_to_power_n_kw": pe.thrust_to_power_n_kw, "jet_power_w": pe.jet_power_w,
        "perveance_ratio": g.perveance_ratio, "space_charge_limit_a": g.space_charge_limit_a,
        "interception_fraction": g.interception_fraction, "p_grid_loss_w": g.p_grid_loss_w,
        "electron_temperature_ev": pl.electron_temperature_ev, "electron_density_m3": pl.electron_density_m3,
        "neutral_density_m3": pf.neutral_density_m3, "propellant_utilisation": pf.propellant_utilisation,
        "grid_temperature_k": th.nodes["grids"].temperature_k, "chamber_temperature_k": th.nodes["chamber"].temperature_k,
        "neutraliser_temperature_k": th.nodes["neutraliser"].temperature_k, "ppu_temperature_k": th.nodes["ppu"].temperature_k,
        "structure_temperature_k": th.nodes["structure"].temperature_k, "beam_diameter_m": b.beam_diameter_m,
        "limit_status": st.limits.status, "energy_balance": st.energy_balance.status if st.energy_balance else "",
        "mass_balance": st.mass_balance.status if st.mass_balance else "",
        "energy_residual_w": st.energy_balance.residual_w if st.energy_balance else float("nan"),
        "mass_residual_kg_s": st.mass_balance.residual_kg_s if st.mass_balance else float("nan"),
    }
    for k, v in pe.efficiencies.items():
        row[f"eta_{k}"] = v
    return row


def _apply(cfg: EngineConfig, op: OperatingPoint, variable: str, value: float) -> tuple[EngineConfig, OperatingPoint]:
    if variable not in SWEEPABLE:
        raise KeyError(f"cannot sweep '{variable}'; sweepable: {sorted(SWEEPABLE)}")
    target, path = SWEEPABLE[variable]
    if target == "op":
        data = op.model_dump()
        data[path] = float(value)
        if variable == "discharge_power":  # the discharge then sets the beam: plasma-limited extraction
            data["beam_current_a"] = None
            data["discharge_current_a"] = None
        return cfg, OperatingPoint.model_validate(data)
    return cfg.with_updates({path: float(value)}), op


def sweep(cfg: EngineConfig, op: OperatingPoint | None, variable: str, values: Iterable[float],
          health: HealthState | None = None) -> pd.DataFrame:
    """One steady-state solve per value; invalid points are kept and labelled, never dropped."""
    op = op or cfg.operating_point
    rows = []
    for v in values:
        c, o = _apply(cfg, op, variable, float(v))
        row = {f"sweep_{variable}": float(v)}
        row.update(state_row(solve_steady_state(c, o, health)))
        rows.append(row)
    return pd.DataFrame(rows)


def sweep_2d(cfg: EngineConfig, op: OperatingPoint | None, var_x: str, xs: Sequence[float] | np.ndarray, var_y: str,
             ys: Sequence[float] | np.ndarray, health: HealthState | None = None) -> xr.Dataset:
    """Dataset indexed [y, x] holding every quantity of :func:`state_row` (strings kept as object)."""
    op = op or cfg.operating_point
    recs = []
    for y in ys:
        for x in xs:
            c, o = _apply(cfg, op, var_x, float(x))
            c, o = _apply(c, o, var_y, float(y))
            recs.append(state_row(solve_steady_state(c, o, health)))
    keys = list(recs[0])
    shape = (len(ys), len(xs))
    data = {k: (("y", "x"), np.array([r[k] for r in recs], dtype=object if isinstance(recs[0][k], str) else float).reshape(shape))
            for k in keys}
    return xr.Dataset(data, coords={"x": np.asarray(xs, float), "y": np.asarray(ys, float)},
                      attrs={"x": var_x, "y": var_y})


def performance_map(cfg: EngineConfig, op: OperatingPoint | None = None, *, beam_voltages: Sequence[float] | np.ndarray,
                    beam_currents: Sequence[float] | np.ndarray, flow_per_amp_kg_s_a: float | None = None,
                    health: HealthState | None = None) -> xr.Dataset:
    """Beam-voltage x beam-current operating map. The propellant flow follows the beam current at
    the nominal utilisation (``flow_per_amp``) so every point is a feasible operating condition;
    pass ``flow_per_amp_kg_s_a=0`` to hold the mass flow at the operating-point value instead."""
    op = op or cfg.operating_point
    ref_i = op.beam_current_a or 1.0
    fpa = op.mass_flow_kg_s / ref_i if flow_per_amp_kg_s_a is None else flow_per_amp_kg_s_a
    recs = []
    for i_b in beam_currents:
        for v_b in beam_voltages:
            o = op.model_copy(update={"beam_voltage_v": float(v_b), "beam_current_a": float(i_b),
                                      "mass_flow_kg_s": (fpa * float(i_b)) if fpa > 0 else op.mass_flow_kg_s})
            recs.append(state_row(solve_steady_state(cfg, o, health)))
    keys = list(recs[0])
    shape = (len(beam_currents), len(beam_voltages))
    data = {k: (("beam_current_a_axis", "beam_voltage_v_axis"),
                np.array([r[k] for r in recs], dtype=object if isinstance(recs[0][k], str) else float).reshape(shape))
            for k in keys}
    return xr.Dataset(data, coords={"beam_current_a_axis": np.asarray(beam_currents, float),
                                    "beam_voltage_v_axis": np.asarray(beam_voltages, float)})


def throttle_curve(cfg: EngineConfig, op: OperatingPoint | None = None, *, n: int = 25, scale_min: float = 0.4,
                   scale_max: float = 1.1, health: HealthState | None = None) -> pd.DataFrame:
    """Beam current and propellant flow scaled together (constant utilisation, constant voltage)."""
    op = op or cfg.operating_point
    rows = []
    for s in np.linspace(scale_min, scale_max, n):
        o = op.model_copy(update={"beam_current_a": float(s * (op.beam_current_a or 1.0)),
                                  "mass_flow_kg_s": float(s * op.mass_flow_kg_s)})
        r = state_row(solve_steady_state(cfg, o, health))
        r["throttle_scale"] = float(s)
        rows.append(r)
    return pd.DataFrame(rows)


# ---------------------------------------------------------------------------------------------
def _draw(rng: np.random.Generator, spec: dict[str, Any], n: int) -> np.ndarray:
    kind = spec["dist"]
    if kind == "normal":
        return rng.normal(spec["mean"], spec["sigma"], n)
    if kind == "uniform":
        return rng.uniform(spec["low"], spec["high"], n)
    if kind == "lognormal":
        return rng.lognormal(np.log(spec["median"]), spec["sigma_log"], n)
    raise ValueError(f"unknown distribution '{kind}'")


def monte_carlo(cfg: EngineConfig, op: OperatingPoint | None, parameters: dict[str, dict[str, Any]], *,
                n: int = 200, seed: int = 0, health: HealthState | None = None,
                progress: Callable[[int], None] | None = None) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Sample configuration parameters (dotted paths) and solve each draw.

    Returns (samples, summary). Invalid draws (configuration rejected by validation or
    state INVALID) are kept and counted, not discarded."""
    op = op or cfg.operating_point
    rng = np.random.default_rng(seed)
    draws = {p: _draw(rng, s, n) for p, s in parameters.items()}
    rows = []
    for k in range(n):
        upd = {p: float(draws[p][k]) for p in parameters}
        row: dict[str, Any] = {f"param:{p}": v for p, v in upd.items()}
        try:
            st = solve_steady_state(cfg.with_updates(upd), op, health)
            row.update(state_row(st))
        except Exception as exc:  # configuration rejected by validation
            row.update({"limit_status": "INVALID", "error": str(exc)[:120]})
        rows.append(row)
        if progress:
            progress(k)
    df = pd.DataFrame(rows)
    num = df.select_dtypes("number").drop(columns=[c for c in df if c.startswith("param:")], errors="ignore")
    summ = num.describe(percentiles=[0.05, 0.5, 0.95]).T
    summ["invalid_fraction"] = float((df["limit_status"] == "INVALID").mean())
    return df, summ


def engineering_curves(cfg: EngineConfig, op: OperatingPoint | None = None, *, n: int = 21,
                       health: HealthState | None = None) -> dict[str, Any]:
    """The standard curve set (all generated by solving the model):

    throttle      beam current and flow scaled together at constant voltage -> vs power / current
    beam_voltage  voltage sweep at constant current and flow
    envelope      beam voltage x beam current map (flow follows current)
    """
    op = op or cfg.operating_point
    ib = op.beam_current_a or 1.0
    vb = op.beam_voltage_v
    return {
        "throttle": throttle_curve(cfg, op, n=n, scale_min=0.35, scale_max=1.2, health=health),
        "beam_voltage": sweep(cfg, op, "beam_voltage", np.linspace(0.45 * vb, 1.35 * vb, n), health),
        "envelope": performance_map(cfg, op, beam_voltages=np.linspace(0.55 * vb, 1.35 * vb, 12),
                                    beam_currents=np.linspace(0.35 * ib, 1.35 * ib, 12), health=health),
    }
