"""Steady-state solver: engine physics <-> thermal network, solved to a self-consistent
fixed point (chamber temperature sets neutral gas speed; heat generation sets temperature)."""

from __future__ import annotations

import numpy as np

from ..configuration import NODE_NAMES, EngineConfig, OperatingPoint
from ..diagnostics.convergence import ConvergenceRecord
from ..extraction.grids import build_geometry
from ..thermal.model import ThermalNetwork
from .engine import Drivers, attach_thermal, evaluate
from .state import HealthState, IonEngineState


def solve_steady_state(cfg: EngineConfig, op: OperatingPoint | None = None, health: HealthState | None = None,
                       drivers: Drivers | None = None) -> IonEngineState:
    """Steady-state engine state for an operating point (or explicit drivers)."""
    op = op or cfg.operating_point
    health = health or HealthState()
    drv = drivers or Drivers.from_operating_point(cfg, op)
    net = ThermalNetwork(cfg.thermal, health.radiator_emissivity_factor)
    geo = build_geometry(cfg.grids)
    s = cfg.solver
    t = net.initial() + 100.0
    rec = ConvergenceRecord(absolute_tolerance=s.absolute_tolerance, relative_tolerance=s.relative_tolerance)
    ev = None
    thermal_ok = True
    for it in range(1, s.maximum_iterations + 1):
        ev = evaluate(cfg, drv, dict(zip(NODE_NAMES, t, strict=True)), health, geometry=geo)
        t_new, thermal_ok = net.steady_state(ev.q_gen, t)
        err = float(np.max(np.abs(t_new - t)))
        rec.history.append(err)
        rec.iterations = it
        done = err <= s.absolute_tolerance + s.relative_tolerance * float(np.max(t_new))
        t = t_new
        if done:
            rec.converged = True
            break
    ev = evaluate(cfg, drv, dict(zip(NODE_NAMES, t, strict=True)), health, geometry=geo)
    rec.final_residual = rec.history[-1]
    if not rec.converged:
        rec.note = "maximum_iterations reached without meeting the temperature tolerance"
    st = attach_thermal(cfg, ev.state, net, t, ev.q_gen, space_limited=ev.space_limited, steady=thermal_ok)
    st.convergence = rec
    return st
