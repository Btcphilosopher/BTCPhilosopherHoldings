"""SIMULATION vs DIGITAL_TWIN modes.

SIMULATION   : model -> state -> outputs.
DIGITAL_TWIN : model + telemetry + estimated state + parameter calibration.

The estimator runs the steady-state physics at the *measured* inputs (mass flow, beam
voltage, beam current), predicts every channel, reports the innovation (measured - predicted)
and the unmeasured states (plasma temperature, divergence, thrust, margins). Calibration
fits configurable model coefficients to telemetry by bounded least squares.
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import StrEnum
from typing import Any

import numpy as np
import pandas as pd
from scipy.optimize import least_squares

from ..configuration import EngineConfig, OperatingPoint
from .solver import solve_steady_state
from .state import HealthState


class OperationMode(StrEnum):
    SIMULATION = "SIMULATION"
    DIGITAL_TWIN = "DIGITAL_TWIN"


# dotted config path -> (lower, upper)
DEFAULT_CALIBRATION_PARAMETERS: dict[str, tuple[float, float]] = {
    "grids.interception_fraction_base": (5e-4, 0.05),
    "chamber.primary_confinement": (0.4, 0.97),
    "ppu.efficiency_beam": (0.8, 0.995),
    "chamber.edge_density_ratio": (0.2, 1.0),
}

# telemetry channel -> (state accessor, relative sigma used for residual weighting)
_PREDICT: dict[str, tuple[str, float]] = {
    "input_power_w": ("power_state.p_input_w", 0.01),
    "discharge_current_a": ("power_state.discharge_current_a", 0.02),
    "grid_temperature_k": ("thermal_state.nodes.grids.temperature_k", 0.01),
    "engine_temperature_k": ("thermal_state.nodes.chamber.temperature_k", 0.01),
    "plasma_density_m3": ("plasma_state.electron_density_m3", 0.05),
    "thrust_estimate_n": ("performance_state.thrust_n", 0.02),
}


def _get(st: Any, path: str) -> float:
    obj = st
    for part in path.split("."):
        obj = obj[part] if isinstance(obj, dict) else getattr(obj, part)
    return float(obj)


@dataclass
class CalibrationResult:
    config: EngineConfig
    parameters: dict[str, float]
    initial_parameters: dict[str, float]
    cost_before: float
    cost_after: float
    channels: list[str]
    success: bool


class DigitalTwin:
    def __init__(self, cfg: EngineConfig, health: HealthState | None = None) -> None:
        self.cfg, self.health = cfg, health or HealthState()
        self.mode = OperationMode.DIGITAL_TWIN

    @staticmethod
    def operating_point_from_telemetry(row: pd.Series | dict[str, float], cfg: EngineConfig) -> OperatingPoint:
        return OperatingPoint(mass_flow_kg_s=float(row["mass_flow_kg_s"]), beam_voltage_v=float(row["beam_voltage_v"]),
                              beam_current_a=float(row["beam_current_a"]),
                              neutraliser_current_a=(float(row["neutraliser_current_a"]) if row.get("neutraliser_current_a", 0) else None))

    def estimate(self, row: pd.Series | dict[str, float]) -> dict[str, float]:
        """Predicted channels, innovations and unmeasured states for one telemetry sample."""
        op = self.operating_point_from_telemetry(row, self.cfg)
        st = solve_steady_state(self.cfg, op, self.health)
        out: dict[str, float] = {}
        for ch, (path, _) in _PREDICT.items():
            pred = _get(st, path)
            out[f"{ch}_predicted"] = pred
            if ch in row and np.isfinite(row[ch]):
                out[f"{ch}_innovation"] = float(row[ch]) - pred
        out["electron_temperature_ev"] = st.plasma_state.electron_temperature_ev
        out["thrust_estimate_n"] = st.performance_state.thrust_n
        out["isp_estimate_s"] = st.performance_state.isp_s
        out["divergence_sigma_rad"] = st.beam_state.divergence_sigma_rad
        out["grid_margin_k"] = st.thermal_state.nodes["grids"].margin_k or float("nan")
        out["limit_status"] = st.limits.status  # type: ignore[assignment]
        return out

    def run(self, telemetry: pd.DataFrame, stride: int = 1) -> pd.DataFrame:
        rows = []
        for i in range(0, len(telemetry), stride):
            r = telemetry.iloc[i]
            if r["beam_current_a"] <= 0.05 or not np.isfinite(r["beam_current_a"]):
                continue  # estimator is steady-state: skip ramps with no beam
            rows.append({"time_s": r["time_s"], **self.estimate(r)})
        return pd.DataFrame(rows)

    def calibrate(self, telemetry: pd.DataFrame, parameters: dict[str, tuple[float, float]] | None = None,
                  channels: list[str] | None = None, max_samples: int = 8, thermal_settled: bool = False) -> CalibrationResult:
        """Fit configuration coefficients so the steady-state model reproduces the telemetry means.

        The estimator is steady-state, so temperature channels are only compared when the
        caller states the telemetry is thermally settled (``thermal_settled=True``); otherwise
        only the quasi-static electrical / plasma channels are used.
        """
        parameters = parameters or DEFAULT_CALIBRATION_PARAMETERS
        if channels is None:
            channels = ["input_power_w", "discharge_current_a"]
            if thermal_settled:
                channels += ["grid_temperature_k", "engine_temperature_k"]
        if not thermal_settled and any("temperature" in c for c in channels):
            raise ValueError("temperature channels need thermal_settled=True (the model is steady-state)")
        steady = telemetry[(telemetry["beam_current_a"] > 0.5 * telemetry["beam_current_a"].max())].dropna(subset=channels)
        if len(steady) == 0:
            raise ValueError("telemetry contains no steady beam samples to calibrate against")
        sample = steady.iloc[np.linspace(0, len(steady) - 1, min(max_samples, len(steady))).astype(int)]
        names = list(parameters)
        lo = np.array([parameters[n][0] for n in names])
        hi = np.array([parameters[n][1] for n in names])
        x0 = np.clip(np.array([float(self.cfg.get_path(n)) for n in names]), lo, hi)

        def resid(x: np.ndarray) -> np.ndarray:
            cfg = self.cfg.with_updates(dict(zip(names, x, strict=True)))
            res = []
            for _, r in sample.iterrows():
                st = solve_steady_state(cfg, self.operating_point_from_telemetry(r, cfg), self.health)
                for ch in channels:
                    path, sig = _PREDICT[ch]
                    res.append((_get(st, path) - float(r[ch])) / (sig * max(abs(float(r[ch])), 1e-12)))
            return np.array(res)

        r0 = resid(x0)
        sol = least_squares(resid, x0, bounds=(lo, hi), x_scale=np.abs(x0) + 1e-9, diff_step=1e-3)
        fitted = dict(zip(names, (float(v) for v in sol.x), strict=True))
        return CalibrationResult(self.cfg.with_updates(fitted), fitted, dict(zip(names, (float(v) for v in x0), strict=True)),
                                 float(r0 @ r0), float(sol.fun @ sol.fun), channels, bool(sol.success))
