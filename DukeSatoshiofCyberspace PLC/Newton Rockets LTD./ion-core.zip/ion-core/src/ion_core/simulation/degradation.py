"""Long-duration degradation.

Every coefficient is a :class:`DegradationCoefficient` with value, units, source,
uncertainty and validity range. The shipped values are DEMONSTRATION placeholders — no
lifetime figures are invented — and can be calibrated against experimental data with
:func:`calibrate_coefficient`.

Linear-in-exposure forms (the driving variable is the accumulated counter):
    interception multiplier   1 + k_grid * grid_exposure[A*h]
    neutraliser emission      1 - k_neut * neutraliser_hours
    PPU efficiency            - k_ppu * operating_hours             (absolute)
    radiator emissivity       1 - k_cyc * thermal_cycles
"""

from __future__ import annotations

import dataclasses

import numpy as np

from ..configuration import DegradationCoefficient, EngineConfig
from .state import HealthState

_DRIVER = {
    "grid_interception_growth": "grid_exposure_ah",
    "neutraliser_emission_loss": "neutraliser_hours",
    "ppu_efficiency_loss": "operating_hours",
    "thermal_cycle_emissivity_loss": "thermal_cycles",
}


def degraded_health(cfg: EngineConfig, counters: HealthState, coefficient_offset_sigma: float = 0.0) -> HealthState:
    """Health multipliers implied by the usage counters. ``coefficient_offset_sigma`` shifts every
    coefficient that has an uncertainty by that many sigma (for bounding studies)."""
    h = dataclasses.replace(counters, sensor_bias=dict(counters.sensor_bias),
                            active_faults=list(counters.active_faults), degradation_warnings=[])

    def k(name: str) -> float:
        c = next(c for c in cfg.degradation.coefficients if c.name == name)
        v = c.value + (coefficient_offset_sigma * c.uncertainty if c.uncertainty is not None else 0.0)
        driver = getattr(counters, _DRIVER[name])
        lo, hi = c.validity_range
        if not lo <= driver <= hi:
            h.degradation_warnings.append(
                f"{name}: driving variable {_DRIVER[name]}={driver:.4g} outside validity range [{lo:g}, {hi:g}]")
        return max(v, 0.0)

    h.interception_multiplier = counters.interception_multiplier * (1.0 + k("grid_interception_growth") * counters.grid_exposure_ah)
    h.neutraliser_emission_factor = counters.neutraliser_emission_factor * max(1.0 - k("neutraliser_emission_loss") * counters.neutraliser_hours, 0.0)
    h.ppu_efficiency_delta = counters.ppu_efficiency_delta - k("ppu_efficiency_loss") * counters.operating_hours
    h.radiator_emissivity_factor = counters.radiator_emissivity_factor * max(1.0 - k("thermal_cycle_emissivity_loss") * counters.thermal_cycles, 0.0)
    return h


def degradation_report(cfg: EngineConfig, counters: HealthState) -> list[dict]:
    rows = []
    for c in cfg.degradation.coefficients:
        drv = getattr(counters, _DRIVER[c.name])
        rows.append({"name": c.name, "value": c.value, "units": c.units, "source": c.source,
                     "uncertainty": c.uncertainty, "validity_range": list(c.validity_range),
                     "driver": _DRIVER[c.name], "driver_value": drv,
                     "within_validity": c.validity_range[0] <= drv <= c.validity_range[1]})
    return rows


def calibrate_coefficient(coefficient: DegradationCoefficient, driver_values: np.ndarray,
                          observed_effects: np.ndarray, source: str) -> DegradationCoefficient:
    """Least-squares slope through the origin of observed effect vs driver; the 1-sigma
    uncertainty is the standard error of the slope; the validity range is the data range."""
    x, y = np.asarray(driver_values, float), np.asarray(observed_effects, float)
    if x.size < 2 or float(x @ x) == 0.0:
        raise ValueError("need at least two non-zero driver values to calibrate")
    k = float(x @ y / (x @ x))
    resid = y - k * x
    se = float(np.sqrt((resid @ resid) / max(x.size - 1, 1) / (x @ x)))
    return coefficient.model_copy(update={"value": k, "uncertainty": se, "source": source,
                                          "validity_range": (float(x.min()), float(x.max()))})
