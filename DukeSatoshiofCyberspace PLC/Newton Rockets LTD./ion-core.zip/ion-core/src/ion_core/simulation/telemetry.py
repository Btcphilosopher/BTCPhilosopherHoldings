"""Synthetic telemetry generated from the simulated truth, with configurable noise, bias,
latency, dropouts and quantisation."""

from __future__ import annotations

import numpy as np
import pandas as pd

from ..configuration import EngineConfig, TelemetryConfig

# telemetry channel -> history column
CHANNELS: dict[str, str] = {
    "beam_voltage_v": "beam_voltage_v", "beam_current_a": "beam_current_a",
    "discharge_voltage_v": "discharge_voltage_v", "discharge_current_a": "discharge_current_a",
    "mass_flow_kg_s": "mass_flow_kg_s", "plasma_density_m3": "electron_density_m3",
    "neutraliser_current_a": "neutraliser_current_a", "grid_temperature_k": "temp_grids_k",
    "engine_temperature_k": "temp_chamber_k", "input_power_w": "p_input_w", "thrust_estimate_n": "thrust_n",
}


def synthetic_telemetry(history: pd.DataFrame, cfg: EngineConfig, extra_bias: dict[str, float] | None = None,
                        seed: int | None = None) -> pd.DataFrame:
    """Telemetry channels from a transient history (or a steady-state table with the same columns)."""
    tc: TelemetryConfig = cfg.telemetry
    rng = np.random.default_rng(tc.seed if seed is None else seed)
    h = history.copy()
    if "discharge_voltage_v" not in h:
        h["discharge_voltage_v"] = np.where(h["discharge_power_w"] > 0, cfg.chamber.default_discharge_voltage_v, 0.0)
    if "discharge_current_a" not in h:
        h["discharge_current_a"] = h["discharge_power_w"] / cfg.chamber.default_discharge_voltage_v
    t = h["time_s"].to_numpy(float)
    out = pd.DataFrame({"time_s": t})
    bias = dict(tc.bias)
    for k, v in (extra_bias or {}).items():
        bias[k] = bias.get(k, 0.0) + v
    for ch, col in CHANNELS.items():
        truth = h[col].to_numpy(float)
        if tc.latency_s > 0:
            truth = np.interp(t - tc.latency_s, t, truth, left=truth[0])
        rel = tc.noise_rel_by_channel.get(ch, tc.noise_rel)
        val = truth * (1.0 + rel * rng.standard_normal(truth.shape)) + bias.get(ch, 0.0)
        q = tc.quantisation.get(ch)
        if q:
            val = np.round(val / q) * q
        if tc.dropout_probability > 0:
            val = np.where(rng.random(val.shape) < tc.dropout_probability, np.nan, val)
        out[ch] = val
    return out
