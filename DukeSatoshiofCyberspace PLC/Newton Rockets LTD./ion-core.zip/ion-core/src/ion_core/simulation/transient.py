"""Time-domain engine simulation.

State variables (each with its own time constant from ``cfg.timing``):
  propellant flow (tau_flow) · screen/accelerator voltages (tau_grid, then PPU output tau_pe)
  discharge supply power (tau_discharge, then tau_pe) · power coupled to the plasma
  (tau_plasma; the lag is an energy reservoir U = tau_plasma * P_plasma, accounted as
  P_stored in the energy balance) · neutraliser emission readiness (tau_neutraliser) ·
  thermal node temperatures (RK4 on the lumped network).

The beam current is NOT commanded: it is whatever the plasma can supply through the
instantaneous extraction voltage, limited by the space-charge limit.
"""

from __future__ import annotations

import dataclasses
import math
from dataclasses import dataclass, field
from typing import Any

import numpy as np
import pandas as pd

from ..configuration import NODE_NAMES, EngineConfig, OperatingPoint
from ..diagnostics.convergence import ConvergenceRecord
from ..extraction.grids import build_geometry
from ..thermal.model import ThermalNetwork
from .degradation import degraded_health
from .engine import Drivers, attach_thermal, evaluate
from .faults import Fault, apply_fault
from .scenarios import TRANSITIONS, Scenario
from .solver import solve_steady_state
from .state import EngineMode, HealthState, IonEngineState
from .timestep import choose_dt, lag

OPERATING = (EngineMode.EXTRACTION, EngineMode.BEAM_ESTABLISHED, EngineMode.STEADY_OPERATION, EngineMode.THROTTLING)


@dataclass
class TransientResult:
    history: pd.DataFrame
    final_state: IonEngineState
    transitions: list[dict]
    event_log: list[dict]
    warnings: list[str]
    target_state: IonEngineState
    health: HealthState
    max_energy_residual_rel: float = 0.0
    max_mass_residual_rel: float = 0.0
    energy_balance_failures: int = 0
    mass_balance_failures: int = 0
    scenario: Scenario | None = None
    hold_state: IonEngineState | None = None  # last state recorded while the beam was on
    extra: dict = field(default_factory=dict)


class TransientSimulator:
    def __init__(self, cfg: EngineConfig, scenario: Scenario, base_health: HealthState | None = None) -> None:
        self.cfg, self.sc = cfg, scenario
        self.counters = base_health or HealthState()
        self.faults: list[Fault] = []
        self.op = scenario.operating_point or cfg.operating_point
        self.geo = build_geometry(cfg.grids)
        self.net = ThermalNetwork(cfg.thermal)
        self.mode = EngineMode.OFF

    # ---- health = degradation(counters) then injected faults -----------------------------------
    def _health(self) -> HealthState:
        h = degraded_health(self.cfg, self.counters)
        for f in self.faults:
            h = apply_fault(h, f)
        return h

    def _retarget(self, op: OperatingPoint) -> None:
        self.op = op
        tgt = solve_steady_state(self.cfg, op, self._health())
        self.target = tgt
        self.t_flow = op.mass_flow_kg_s
        self.t_vb = op.beam_voltage_v
        self.t_va = op.accelerator_voltage_v or self.cfg.grids.accelerator_voltage_v
        self.t_pd = tgt.power_state.p_discharge_w
        self.t_ib = tgt.beam_state.beam_current_a
        self.t_ne = tgt.plasma_state.electron_density_m3
        self.v_d = op.discharge_voltage_v or self.cfg.chamber.default_discharge_voltage_v

    def run(self) -> TransientResult:
        cfg, sc, seq, tm = self.cfg, self.sc, self.sc.sequence, self.cfg.timing
        warnings: list[str] = []
        self._retarget(self.op)
        env = cfg.thermal.environment_temperature_k
        T = np.full(len(NODE_NAMES), env)
        # states
        flow = 0.0
        vb1 = vb2 = va1 = va2 = 0.0
        pd1 = pd2 = pplasma = 0.0
        ready = 0.0
        want: dict[str, Any] = {"flow": 0.0, "vb": 0.0, "va": 0.0, "pd": 0.0, "neut": False, "aux": False}
        sub = ""  # shutdown sub-phase
        inv_prev: float | None = None
        dt_prev = 1.0
        peak_exc = np.zeros(len(NODE_NAMES))
        t, k_ev = 0.0, 0
        t_enter = 0.0
        rows: list[dict] = []
        transitions: list[dict] = []
        events_log: list[dict] = []
        e_fail = m_fail = 0
        max_e = max_m = 0.0
        steady_since: float | None = None
        last_st: IonEngineState | None = None
        hold_st: IonEngineState | None = None
        events = list(sc.events)
        cum_t = 0.0

        def goto(new: EngineMode) -> None:
            nonlocal t_enter
            if new not in TRANSITIONS[self.mode]:
                raise RuntimeError(f"illegal transition {self.mode.value} -> {new.value}")
            transitions.append({"t_s": t, "from": self.mode.value, "to": new.value})
            self.mode, t_enter = new, t

        while t <= sc.duration_s:
            # ---- scheduled events ------------------------------------------------------------
            while k_ev < len(events) and events[k_ev].t_s <= t + 1e-9:
                ev = events[k_ev]
                k_ev += 1
                events_log.append({"t_s": t, "action": ev.action, **ev.params})
                if ev.action == "start" and self.mode in (EngineMode.OFF, EngineMode.COOLDOWN):
                    goto(EngineMode.INITIALISING)
                elif ev.action == "shutdown" and self.mode not in (EngineMode.OFF, EngineMode.SHUTDOWN, EngineMode.COOLDOWN):
                    goto(EngineMode.SHUTDOWN)
                    sub = "beam_reduction"
                elif ev.action == "throttle":
                    new_op = self.op.model_copy(update=ev.params["operating_point"])
                    self._retarget(new_op)
                    if self.mode == EngineMode.STEADY_OPERATION:
                        goto(EngineMode.THROTTLING)
                elif ev.action == "fault":
                    self.faults.append(Fault(**{k: v for k, v in ev.params.items()}))
                elif ev.action == "clear_faults":
                    self.faults.clear()
                else:
                    warnings.append(f"event '{ev.action}' ignored in mode {self.mode.value} at t={t:.1f}s")

            health = self._health()
            m = self.mode
            # ---- command targets by mode --------------------------------------------------------
            if m == EngineMode.OFF or m == EngineMode.COOLDOWN:
                want = {"flow": 0.0, "vb": 0.0, "va": 0.0, "pd": 0.0, "neut": False, "aux": False}
            elif m == EngineMode.INITIALISING:
                want = {"flow": 0.0, "vb": 0.0, "va": 0.0, "pd": 0.0, "neut": True, "aux": True}
            elif m == EngineMode.PROPELLANT_FLOW:
                want = {"flow": self.t_flow, "vb": 0.0, "va": 0.0, "pd": 0.0, "neut": True, "aux": True}
            elif m == EngineMode.PLASMA_START:
                want = {"flow": self.t_flow, "vb": 0.0, "va": 0.0, "pd": seq.ignition_power_fraction * self.t_pd,
                        "neut": True, "aux": True}
            elif m == EngineMode.IONISATION:  # accelerator grid biased before the screen grid
                want = {"flow": self.t_flow, "vb": 0.0, "va": self.t_va, "pd": seq.ignition_power_fraction * self.t_pd,
                        "neut": True, "aux": True}
            elif m == EngineMode.EXTRACTION:  # raise the discharge only once the grids are up
                grids_up = vb2 >= seq.beam_voltage_ready_fraction * self.t_vb
                want = {"flow": self.t_flow, "vb": self.t_vb, "va": self.t_va,
                        "pd": self.t_pd if grids_up else seq.ignition_power_fraction * self.t_pd, "neut": True, "aux": True}
            elif m in (EngineMode.BEAM_ESTABLISHED, EngineMode.STEADY_OPERATION, EngineMode.THROTTLING):
                want = {"flow": self.t_flow, "vb": self.t_vb, "va": self.t_va, "pd": self.t_pd, "neut": True, "aux": True}
            elif m == EngineMode.SHUTDOWN:
                ib_now = last_st.beam_state.beam_current_a if last_st else 0.0
                if sub == "beam_reduction":  # reduce the discharge first: beam current follows the plasma
                    want.update(vb=self.t_vb if vb2 > 1.0 else 0.0, va=self.t_va if va2 > 1.0 else 0.0,
                                pd=seq.shutdown_power_fraction * self.t_pd, flow=self.t_flow)
                    if ib_now <= seq.beam_reduced_fraction * self.t_ib:
                        sub = "grid_shutdown"
                elif sub == "grid_shutdown":
                    want.update(vb=0.0, va=0.0)
                    if vb2 <= 1.0 and va2 <= 1.0 and ib_now <= 1e-4:
                        sub = "neutraliser_shutdown"
                elif sub == "neutraliser_shutdown":
                    want.update(neut=False)
                    sub = "plasma_decay"
                elif sub == "plasma_decay":
                    want.update(pd=0.0)
                    if pplasma <= seq.shutdown_off_fraction * self.t_pd:
                        sub = "propellant_cutoff"
                elif sub == "propellant_cutoff":
                    want.update(flow=0.0)
                    if flow <= seq.shutdown_off_fraction * self.t_flow:
                        goto(EngineMode.COOLDOWN)
                        sub = ""
                        want = {"flow": 0.0, "vb": 0.0, "va": 0.0, "pd": 0.0, "neut": False, "aux": False}
                        self.counters.thermal_cycles += 1.0

            # ---- step size & lags ------------------------------------------------------------------
            dt = choose_dt(self.mode.value, cfg.solver.time_step_s, seq.steady_time_step_s, cfg.solver.cooldown_time_step_s)
            if k_ev < len(events):
                dt = min(dt, max(events[k_ev].t_s - t, 1e-3)) if events[k_ev].t_s > t else dt
            # every row is a consistent snapshot at time t: evaluate with the CURRENT states, record,
            # then advance all states (lags, thermal) to t + dt at the end of the step
            osc = 1.0
            if health.beam_instability_amplitude > 0 and vb2 > 0:
                osc += health.beam_instability_amplitude * math.sin(2 * math.pi * health.beam_instability_frequency_hz * t)
            pd_sup = pd2 * osc

            drv = Drivers(mass_flow_kg_s=flow, beam_voltage_v=vb2, accelerator_voltage_v=va2, beam_current_a=None,
                          discharge_voltage_v=self.v_d, p_discharge_w=pplasma, p_discharge_supply_w=pd_sup,
                          neutraliser_readiness=ready, neutraliser_on=want["neut"], aux_on=want["aux"])
            ev_ = evaluate(cfg, drv, dict(zip(NODE_NAMES, T, strict=True)), health, time_s=t, mode=self.mode.value,
                           geometry=self.geo, prev_inventory_kg=inv_prev, dt_s=dt_prev if inv_prev is not None else None)
            inv_prev = ev_.n_neutral_inventory_kg
            st = attach_thermal(cfg, ev_.state, self.net, T, ev_.q_gen, space_limited=ev_.space_limited, steady=True)
            st.convergence = ConvergenceRecord(converged=True, iterations=0, note="time-domain state (no iteration)")
            last_st = st
            if self.mode in OPERATING and st.beam_state.beam_current_a > 0:
                hold_st = st
            eb, mb = st.energy_balance, st.mass_balance
            assert eb is not None and mb is not None
            max_e, max_m = max(max_e, abs(eb.relative_residual)), max(max_m, abs(mb.relative_residual))
            e_fail += eb.status == "FAIL"
            m_fail += mb.status == "FAIL"

            # ---- record -------------------------------------------------------------------------------
            b, pe, pw, pl, g, n, pf = (st.beam_state, st.performance_state, st.power_state, st.plasma_state,
                                       st.grid_state, st.neutraliser_state, st.propellant_flow)
            row = {"time_s": t, "mode": self.mode.value, "mass_flow_kg_s": pf.mass_flow_total_kg_s,
                   "neutral_density_m3": pf.neutral_density_m3, "discharge_power_w": pw.p_discharge_w,
                   "plasma_power_w": pplasma, "electron_density_m3": pl.electron_density_m3,
                   "electron_temperature_ev": pl.electron_temperature_ev, "plasma_sustained": pl.sustained,
                   "beam_voltage_v": b.beam_voltage_v, "accelerator_voltage_v": va2, "extraction_voltage_v": g.extraction_voltage_v,
                   "beam_current_a": b.beam_current_a, "extracted_current_a": g.extracted_current_a,
                   "intercepted_current_a": g.intercepted_current_a, "space_charge_limit_a": g.space_charge_limit_a,
                   "space_charge_limited": g.space_charge_limited, "neutraliser_readiness": ready,
                   "neutraliser_current_a": n.delivered_emission_a, "neutralised": n.neutralised, "thrust_n": pe.thrust_n,
                   "isp_s": pe.isp_s, "p_input_w": pw.p_input_w, "p_beam_w": pw.p_beam_w, "p_grid_loss_w": g.p_grid_loss_w,
                   "p_stored_w": pw.p_stored_w, "thrust_to_power_mn_kw": pe.thrust_to_power_mn_kw,
                   "overall_efficiency": pe.efficiencies["overall"], "energy_residual_w": eb.residual_w,
                   "energy_residual_rel": eb.relative_residual, "energy_status": eb.status,
                   "mass_residual_kg_s": mb.residual_kg_s, "mass_residual_rel": mb.relative_residual,
                   "mass_status": mb.status, "limit_status": st.limits.status}
            for i, nme in enumerate(NODE_NAMES):
                row[f"temp_{nme}_k"] = float(T[i])
            rows.append(row)

            # ---- bookkeeping (usage counters) ------------------------------------------------------------
            dh = dt / 3600.0
            if b.beam_current_a > 0:
                self.counters.operating_hours += dh
                self.counters.grid_exposure_ah += g.intercepted_current_a * dh
            if want["neut"]:
                self.counters.neutraliser_hours += dh
            self.counters.propellant_throughput_kg += pf.mass_flow_total_kg_s * dt

            # ---- transitions (physical conditions) -----------------------------------------------------------
            m = self.mode
            if m == EngineMode.INITIALISING and ready >= cfg.neutraliser.readiness_threshold:
                goto(EngineMode.PROPELLANT_FLOW)
            elif m == EngineMode.PROPELLANT_FLOW and flow >= seq.flow_ready_fraction * self.t_flow:
                goto(EngineMode.PLASMA_START)
            elif m == EngineMode.PLASMA_START and (t - t_enter) >= seq.ignition_delay_s and pl.sustained:
                goto(EngineMode.IONISATION)
            elif m == EngineMode.IONISATION and pl.sustained and va2 >= seq.beam_voltage_ready_fraction * self.t_va \
                    and pplasma >= seq.plasma_ready_fraction * seq.ignition_power_fraction * self.t_pd:
                goto(EngineMode.EXTRACTION)
            elif m == EngineMode.EXTRACTION and vb2 >= seq.beam_voltage_ready_fraction * self.t_vb \
                    and b.beam_current_a >= seq.beam_current_ready_fraction * self.t_ib:
                goto(EngineMode.BEAM_ESTABLISHED)
                steady_since = t
            elif m in (EngineMode.BEAM_ESTABLISHED, EngineMode.THROTTLING):
                near = (abs(b.beam_current_a - self.t_ib) <= seq.steady_tolerance * self.t_ib
                        and abs(vb2 - self.t_vb) <= seq.steady_tolerance * self.t_vb
                        and abs(pf.mass_flow_total_kg_s - self.t_flow * health.flow_factor) <= seq.steady_tolerance * self.t_flow)
                steady_since = (steady_since if steady_since is not None else t) if near else None
                if near and steady_since is not None and t - steady_since >= seq.steady_dwell_s:
                    goto(EngineMode.STEADY_OPERATION)
            elif m == EngineMode.COOLDOWN and bool(np.all(T - env <= seq.cooldown_residual_fraction * peak_exc + 1.0)):
                goto(EngineMode.OFF)
                if sc.stop_when_off:
                    break

            peak_exc = np.maximum(peak_exc, T - env)
            # ---- advance all states to t + dt ---------------------------------------------------------------
            flow = lag(flow, want["flow"], tm.flow_s, dt)
            vb1 = lag(vb1, want["vb"], tm.grid_voltage_s, dt)
            vb2 = lag(vb2, vb1, tm.power_electronics_s, dt)
            va1 = lag(va1, want["va"], tm.grid_voltage_s, dt)
            va2 = lag(va2, va1, tm.power_electronics_s, dt)
            pd1 = lag(pd1, want["pd"], tm.discharge_s, dt)
            pd2 = lag(pd2, pd1, tm.power_electronics_s, dt)
            pplasma = lag(pplasma, pd_sup, tm.plasma_s, dt)
            ready = lag(ready, 1.0 if want["neut"] else 0.0, tm.neutraliser_s, dt)
            dt_prev = dt

            # ---- advance thermal state ----------------------------------------------------------------------------
            self.net.eps = np.array([cfg.thermal.nodes[n_].emissivity for n_ in NODE_NAMES]) * health.radiator_emissivity_factor
            T = self.net.step_rk4(T, ev_.q_gen, dt, 1.0)
            t += dt
            cum_t = t
        _ = cum_t
        hist = pd.DataFrame(rows)
        final = last_st if last_st is not None else IonEngineState()
        return TransientResult(hist, final, transitions, events_log, warnings, self.target, self._health(),
                               max_e, max_m, int(e_fail), int(m_fail), sc, hold_st)


def run_transient(cfg: EngineConfig, scenario: Scenario, health: HealthState | None = None) -> TransientResult:
    return TransientSimulator(cfg, scenario, health).run()


__all__ = ["TransientResult", "TransientSimulator", "run_transient", "dataclasses"]
