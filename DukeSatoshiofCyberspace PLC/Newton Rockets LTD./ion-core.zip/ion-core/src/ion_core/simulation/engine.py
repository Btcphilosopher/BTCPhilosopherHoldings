"""Core engine evaluation: drivers + temperatures + health -> complete physical state.

This is the single place where the physics chain is assembled:

 PROPELLANT -> FLOW -> neutral density -> IONISATION/PLASMA -> EXTRACTION (space charge,
 interception) -> ACCELERATION -> BEAM -> NEUTRALISATION -> THRUST
 and in parallel ELECTRICAL INPUT -> PPU -> DISCHARGE / GRIDS / NEUTRALISER -> heat.

Everything the console or the reports show is read from the :class:`IonEngineState`
returned here; there is no other source of numbers.
"""

from __future__ import annotations

import math
from dataclasses import dataclass

import numpy as np
from scipy.optimize import brentq

from ..acceleration.beam import beam_geometry
from ..acceleration.electrostatic import effective_acceleration_voltage, ion_energy_j
from ..acceleration.velocity import ion_velocities
from ..configuration import NODE_NAMES, EngineConfig, OperatingPoint
from ..constants import E_CHARGE, M_ELECTRON
from ..diagnostics.energy_balance import energy_balance
from ..diagnostics.mass_balance import mass_balance
from ..extraction.current import beam_from_extracted, divergence_sigma, interception_fraction
from ..extraction.grids import GridGeometry, build_geometry
from ..extraction.sheath import electric_field, potential_ladder
from ..extraction.space_charge import space_charge_state
from ..neutraliser.neutraliser import neutraliser_state
from ..plasma.chamber import solve_plasma
from ..plasma.density import neutral_mean_speed
from ..plasma.losses import discharge_budget
from ..power.discharge import discharge_supply
from ..power.electrical import ppu_chain
from ..power.grid_power import grid_power
from ..propellant.feed import split_flow
from ..propellant.flow import ion_mass_flow
from ..thermal.model import NodeThermal, ThermalNetwork
from ..thrust.efficiency import jet_power_w, thrust_to_power
from ..thrust.specific_impulse import specific_impulse
from ..thrust.thrust import neutral_exit_thrust, thrust_breakdown
from .limits import evaluate_limits
from .state import (
    BeamState,
    GridState,
    HealthState,
    IonEngineState,
    NeutraliserState,
    PerformanceState,
    PlasmaState,
    PowerState,
    PropellantFlowState,
    ThermalNodeState,
    ThermalState,
)


@dataclass
class Drivers:
    """Instantaneous inputs to the engine physics (SI)."""

    mass_flow_kg_s: float
    beam_voltage_v: float
    accelerator_voltage_v: float | None = None
    beam_current_a: float | None = None  # None -> plasma-limited extraction
    discharge_voltage_v: float | None = None
    p_discharge_w: float | None = None  # None -> regulated to deliver beam_current_a
    p_discharge_supply_w: float | None = None  # supply output when it differs (transients)
    neutraliser_current_a: float | None = None
    neutraliser_readiness: float = 1.0
    neutraliser_on: bool = True
    aux_on: bool = True

    @classmethod
    def from_operating_point(cls, cfg: EngineConfig, op: OperatingPoint) -> Drivers:
        vd = op.discharge_voltage_v or cfg.chamber.default_discharge_voltage_v
        p_d = op.discharge_power_w
        if p_d is None and op.discharge_current_a is not None:
            p_d = vd * op.discharge_current_a
        return cls(mass_flow_kg_s=op.mass_flow_kg_s, beam_voltage_v=op.beam_voltage_v,
                   accelerator_voltage_v=op.accelerator_voltage_v, beam_current_a=op.beam_current_a,
                   discharge_voltage_v=vd, p_discharge_w=p_d, neutraliser_current_a=op.neutraliser_current_a)


@dataclass
class Evaluation:
    state: IonEngineState
    q_gen: np.ndarray  # heat generated per thermal node (NODE_NAMES order)
    space_limited: bool
    n_neutral_inventory_kg: float  # neutral gas mass stored in the chamber


def _plasma_limited_nx(cfg: EngineConfig, geo: GridGeometry, n_main: float, v_bar: float,
                       p_plasma_w: float, coupling: float) -> tuple[float, bool]:
    """Largest extracted ion rate (ions/s) the plasma can supply for a fixed discharge power,
    with neutral depletion by extraction. Returns (N_x, propellant_limited)."""
    sp, ch = cfg.species, cfg.chamber
    if p_plasma_w <= 0.0 or n_main <= 0.0:
        return 0.0, False

    def cap_minus(nx: float) -> float:
        n_n = 4.0 * max(n_main - nx, 0.0) / (v_bar * geo.neutral_exit_area_m2)
        s = solve_plasma(sp, ch, n_neutral=n_n, screen_area_m2=geo.active_area_m2,
                         ion_open_area_m2=geo.ion_open_area_m2, n_ext_rate=nx, p_discharge_w=p_plasma_w,
                         coupling_factor=coupling)
        return s.extraction_capacity_rate - nx

    upper = cfg.flow.max_propellant_utilisation * n_main
    if cap_minus(0.0) <= 0.0:
        return 0.0, False
    if cap_minus(upper) >= 0.0:
        return upper, True
    return float(brentq(cap_minus, 0.0, upper, xtol=1e-6 * n_main, rtol=1e-12, maxiter=200)), False


def evaluate(cfg: EngineConfig, drv: Drivers, temps: dict[str, float], health: HealthState | None = None,
             *, time_s: float = 0.0, mode: str = "STEADY_OPERATION", geometry: GridGeometry | None = None,
             prev_inventory_kg: float | None = None, dt_s: float | None = None) -> Evaluation:
    health = health or HealthState()
    sp = cfg.species
    if drv.mass_flow_kg_s < 0 or drv.beam_voltage_v < 0 or (drv.beam_current_a is not None and drv.beam_current_a < 0) \
            or (drv.p_discharge_w is not None and drv.p_discharge_w < 0):
        raise ValueError("negative flow / voltage / current / power is not a valid engine input")
    if sp.charge_state != 1:
        raise NotImplementedError("ION-CORE v0.1 models singly charged ions only (charge_state=1)")
    e, z = E_CHARGE, 1
    m_a, m_i = sp.atomic_mass, sp.ion_mass
    ch, gcfg = cfg.chamber, cfg.grids
    geo = geometry or build_geometry(gcfg)

    # ---- propellant flow -----------------------------------------------------------------
    m_tot = drv.mass_flow_kg_s * health.flow_factor
    split = split_flow(m_tot, cfg.flow.neutraliser_flow_fraction, cfg.flow.leak_fraction)
    n_main = split.main_kg_s / m_a
    t_ch = temps["chamber"]
    v_bar = neutral_mean_speed(t_ch, m_a)

    # ---- potentials, space-charge limit ----------------------------------------------------
    v_b = drv.beam_voltage_v
    v_acc_bias = cfg.grids.accelerator_voltage_v if drv.accelerator_voltage_v is None else drv.accelerator_voltage_v
    ladder = potential_ladder(v_b, v_acc_bias, ch.plasma_potential_offset_v, cfg.neutraliser.coupling_voltage_v)
    v_eff_volt = effective_acceleration_voltage(v_b, ch.plasma_potential_offset_v,
                                                cfg.neutraliser.coupling_voltage_v) if v_b > 0 else 0.0
    extraction_on = v_eff_volt > 0.0  # ions cannot leave if V_eff <= 0 (plume potential hill)
    v_ext = ladder.extraction_voltage_v if extraction_on else 0.0
    sc0 = space_charge_state(extraction_voltage_v=v_ext, effective_gap_m=geo.effective_gap_m, ion_mass_kg=m_i,
                             ion_charge_c=e, n_apertures=geo.n_apertures,
                             aperture_area_m2=geo.screen_aperture_area_m2, actual_current_a=0.0)
    i_cl = sc0.limit_a

    # ---- extracted / beam current ----------------------------------------------------------
    space_limited = False
    maxit = cfg.solver.maximum_iterations
    if drv.beam_current_a is not None:
        i_b_cmd = drv.beam_current_a
        i_ext = i_b_cmd
        for _ in range(maxit):
            p = min(i_ext / i_cl, 10.0) if i_cl > 0 else 10.0
            f = interception_fraction(gcfg, p, health.interception_multiplier)
            new = i_b_cmd / (1.0 - f)
            done = abs(new - i_ext) <= 1e-15 + 1e-14 * new  # contraction mapping: converge fully so I_beam == command
            i_ext = new
            if done:
                break
    else:
        nx_cap, _prop_limited = _plasma_limited_nx(cfg, geo, n_main, v_bar,
                                                   (drv.p_discharge_w or 0.0), health.plasma_coupling_factor)
        i_plasma = e * nx_cap
        space_limited = extraction_on and i_plasma > i_cl
        i_ext = min(i_plasma, i_cl) if i_cl > 0 else 0.0
    p_ratio = min(i_ext / i_cl, 10.0) if i_cl > 0 else (10.0 if i_ext > 0 else 0.0)
    f_int = interception_fraction(gcfg, p_ratio, health.interception_multiplier)
    i_beam, i_acc = beam_from_extracted(i_ext, f_int)
    n_x = i_ext / e

    # ---- neutral density (neutral balance), plasma -----------------------------------------
    n_exit_atoms = n_main - n_x
    n_n = 4.0 * n_exit_atoms / (v_bar * geo.neutral_exit_area_m2) if n_exit_atoms > 0 else 0.0
    plasma = solve_plasma(sp, ch, n_neutral=n_n, screen_area_m2=geo.active_area_m2,
                          ion_open_area_m2=geo.ion_open_area_m2, n_ext_rate=n_x,
                          p_discharge_w=drv.p_discharge_w, coupling_factor=health.plasma_coupling_factor)
    absorb = plasma.absorb_fraction
    p_d = (plasma.p_absorbed_w / max(absorb, 1e-3)) if drv.p_discharge_w is None else drv.p_discharge_w
    p_d_sup = p_d if drv.p_discharge_supply_w is None else drv.p_discharge_supply_w
    p_stored = p_d_sup - p_d
    v_d = drv.discharge_voltage_v or ch.default_discharge_voltage_v
    dsup = discharge_supply(p_d_sup, v_d)
    e_iz = sp.ionisation_energy_ev
    bud = discharge_budget(
        p_discharge_w=p_d, n_gen=plasma.ion_generation_rate, n_ext=n_x, e_ion_ev=e_iz,
        e_exc_ev=plasma.exc_ratio * sp.excitation_threshold_ev, v_float_v=plasma.v_float_v, te_ev=plasma.te_ev,
        confinement=ch.primary_confinement * health.plasma_coupling_factor,
        radiative_fraction=ch.radiative_loss_fraction, other_fraction=ch.other_loss_fraction,
        plasma_offset_v=ch.plasma_potential_offset_v, sustained=plasma.sustained)

    # ---- acceleration, beam, thrust -----------------------------------------------------------
    vel = ion_velocities(e, m_i, v_b, v_eff_volt, cfg.beam.velocity_calibration_factor)
    sigma = divergence_sigma(gcfg, p_ratio) if i_beam > 0 else 0.0
    bg = beam_geometry(sigma, gcfg.active_diameter_m, cfg.beam.measurement_distance_m)
    m_ion_beam = ion_mass_flow(i_beam, m_i)
    m_ion_ext = ion_mass_flow(i_ext, m_i)
    m_ion_acc = ion_mass_flow(i_acc, m_a)  # intercepted: returns as neutral atoms
    m_n_exit = 0.25 * n_n * v_bar * geo.neutral_exit_area_m2 * m_a
    t_grid, t_neut = temps["grids"], temps["neutraliser"]
    f_n_chamber = neutral_exit_thrust(m_n_exit, t_ch, m_a) + neutral_exit_thrust(m_ion_acc, t_grid, m_a)
    f_n_neut = neutral_exit_thrust(split.neutraliser_kg_s, t_neut, m_a)
    thr = thrust_breakdown(ion_mass_flow_kg_s=m_ion_beam, v_ideal=vel.ideal_m_s, v_effective=vel.effective_m_s,
                           gamma=bg.gamma, neutral_chamber_n=f_n_chamber, neutraliser_gas_n=f_n_neut,
                           calibration_factor=cfg.beam.velocity_calibration_factor)
    isp = specific_impulse(thrust_n=thr.total_n, axial_ion_thrust_n=thr.axial_ion_n, m_dot_total=m_tot,
                           m_dot_main=split.main_kg_s, m_dot_ion=m_ion_beam)

    # ---- neutraliser ------------------------------------------------------------------------
    nres = neutraliser_state(cfg.neutraliser, beam_current_a=i_beam, commanded_a=drv.neutraliser_current_a,
                             readiness=drv.neutraliser_readiness,
                             health_factor=health.neutraliser_emission_factor, on=drv.neutraliser_on)

    # ---- power chain -------------------------------------------------------------------------
    gp = grid_power(v_beam=v_b, v_accel=v_acc_bias, plasma_offset_v=ch.plasma_potential_offset_v,
                    i_beam=i_beam, i_intercepted=i_acc, ionisation_energy_ev=e_iz)
    p_aux = cfg.ppu.auxiliary_power_w if drv.aux_on else 0.0
    ppu = ppu_chain(cfg.ppu, p_discharge_w=p_d_sup, p_beam_w=gp.beam_supply_w, p_accel_w=gp.accel_supply_w,
                    p_neutraliser_w=nres.power_w, p_aux_w=p_aux, efficiency_delta=health.ppu_efficiency_delta)

    # ---- heat generation by node ---------------------------------------------------------------
    a_loss = plasma.ion_loss_area_m2
    denom = a_loss - geo.ion_open_area_m2
    web_share = (geo.active_area_m2 - geo.ion_open_area_m2) / denom if denom > 0 else 0.0
    wall_heat = bud.p_wall_w + plasma.ion_wall_rate * e_iz * e
    esc = cfg.thermal.radiation_escape_fraction
    p_rad_escape = esc * (bud.p_excitation_w + bud.p_radiation_w)
    q = {n: 0.0 for n in NODE_NAMES}
    q["grids"] = gp.intercepted_ion_power_w + web_share * wall_heat
    q["chamber"] = ((1.0 - web_share) * wall_heat + bud.p_electron_loss_w + bud.p_other_w
                    + (1.0 - esc) * (bud.p_excitation_w + bud.p_radiation_w))
    q["neutraliser"] = nres.heat_w
    q["ppu"] = ppu.p_ppu_loss_w + p_aux
    q_gen = np.array([q[n] for n in NODE_NAMES])

    # ---- energy balance (independent terms vs PPU input) ------------------------------------------
    p_beam_kin = i_beam * v_eff_volt
    eb = energy_balance(
        p_input_w=ppu.p_input_w, p_beam_w=p_beam_kin, p_ionisation_w=i_beam * e_iz, p_grid_loss_w=q["grids"],
        p_neutraliser_w=q["neutraliser"], p_thermal_w=q["chamber"] + q["ppu"] + q["structure"] + p_rad_escape,
        p_other_w=i_beam * cfg.neutraliser.coupling_voltage_v, p_stored_w=p_stored,
        tolerance=cfg.solver.energy_balance_tolerance)

    # ---- mass balance ----------------------------------------------------------------------------------
    inventory = n_n * ch.volume_m3 * m_a
    stored_rate = 0.0 if (prev_inventory_kg is None or not dt_s) else (inventory - prev_inventory_kg) / dt_s
    mb = mass_balance(
        m_in=m_tot, m_ion_beam=m_ion_beam, m_electrons=i_beam * M_ELECTRON / e,
        m_ion_intercepted=m_ion_acc, m_neutral_chamber=m_n_exit, m_neutraliser=split.neutraliser_kg_s,
        m_leak=split.leak_kg_s, m_stored=0.0, tolerance=cfg.solver.mass_balance_tolerance,
        storage_neglected=stored_rate)

    # ---- efficiencies & performance ------------------------------------------------------------------------
    p_beam_ideal = v_b * i_beam
    p_jet = jet_power_w(thr.total_n, m_tot)
    tp_n, tp_mn = thrust_to_power(thr.total_n, ppu.p_input_w)
    eta_m = m_ion_beam / m_tot if m_tot > 0 else 0.0
    eta_acc = v_eff_volt / v_b if v_b > 0 else 0.0
    eta_div = bg.gamma**2
    eta_elec = p_beam_ideal / ppu.p_input_w if ppu.p_input_w > 0 else 0.0
    eta_ion_thrust = jet_power_w(thr.axial_ion_n, m_tot) / ppu.p_input_w if ppu.p_input_w > 0 else 0.0
    nu_iz_n = plasma.n_e * plasma.k_iz
    nu_exit = 0.25 * v_bar * geo.neutral_exit_area_m2 / ch.volume_m3
    p_iz = nu_iz_n / (nu_iz_n + nu_exit) if (nu_iz_n + nu_exit) > 0 else 0.0
    eff = {
        "propellant_utilisation": eta_m,
        "chamber_utilisation": m_ion_ext / split.main_kg_s if split.main_kg_s > 0 else 0.0,
        "ionisation": (i_ext * e_iz / p_d) if p_d > 0 else 0.0,
        "ion_production_cost_ev_per_ion": (p_d / i_beam) if i_beam > 0 else 0.0,
        "ionisation_probability": p_iz,
        "extraction": (i_beam / (e * plasma.ion_generation_rate)) if plasma.ion_generation_rate > 0 else 0.0,
        "ion_transparency": geo.ion_transparency,
        "grid_transmission": 1.0 - f_int,
        "acceleration": eta_acc, "divergence": eta_div, "neutralisation": nres.emission.neutralisation_efficiency,
        "ppu": ppu.p_output_total_w / ppu.p_input_w if ppu.p_input_w > 0 else 0.0,
        "electrical": eta_elec,
        "thruster": p_jet / ppu.p_output_total_w if ppu.p_output_total_w > 0 else 0.0,
        "overall": p_jet / ppu.p_input_w if ppu.p_input_w > 0 else 0.0,
        "ion_thrust_overall": eta_ion_thrust,
        "decomposition_residual": eta_ion_thrust - eta_m * eta_div * eta_acc * eta_elec,
    }

    # ---- assemble state ---------------------------------------------------------------------------------------
    st = IonEngineState(time_s=time_s, mode=mode)
    st.propellant_flow = PropellantFlowState(
        species_name=sp.species_name, mass_flow_total_kg_s=m_tot, mass_flow_main_kg_s=split.main_kg_s,
        mass_flow_neutraliser_kg_s=split.neutraliser_kg_s, mass_flow_leak_kg_s=split.leak_kg_s,
        atoms_per_s_main=n_main, neutral_flow_exit_kg_s=m_n_exit, ionised_flow_extracted_kg_s=m_ion_ext,
        ion_flow_beam_kg_s=m_ion_beam, ion_flow_intercepted_kg_s=m_ion_acc, neutral_density_m3=n_n,
        neutral_temperature_k=t_ch, neutral_mean_speed_m_s=v_bar, propellant_utilisation=eta_m,
        chamber_utilisation=eff["chamber_utilisation"])
    st.plasma_state = PlasmaState(
        sustained=plasma.sustained, electron_temperature_ev=plasma.te_ev, ion_temperature_ev=plasma.ti_ev,
        electron_density_m3=plasma.n_e, ion_density_m3=plasma.n_i, sheath_edge_density_m3=plasma.n_edge,
        neutral_density_m3=n_n, plasma_potential_v=ladder.plasma_potential_v,
        quasi_neutrality_error=abs(plasma.n_e - z * plasma.n_i) / plasma.n_e if plasma.n_e > 0 else 0.0,
        bohm_velocity_m_s=plasma.u_bohm, floating_potential_v=plasma.v_float_v,
        ionisation_rate_coefficient_m3_s=plasma.k_iz, excitation_rate_coefficient_m3_s=plasma.k_exc,
        ionisation_frequency_per_electron_s=plasma.nu_iz, ionisation_frequency_per_neutral_s=nu_iz_n,
        ionisation_rate_density_m3_s=plasma.ionisation_rate_density, ion_production_rate_s=plasma.ion_generation_rate,
        ion_extracted_rate_s=n_x, ion_wall_loss_rate_s=plasma.ion_wall_rate, ionisation_probability=p_iz,
        ion_balance_residual=plasma.ion_balance_residual,
        extraction_capacity_rate_s=plasma.extraction_capacity_rate, extraction_supply_margin_s=plasma.extraction_supply_margin,
        energy_per_ion_ionisation_ev=plasma.e_generation_ev,
        discharge_budget={k: getattr(bud, k) for k in (
            "p_discharge_w", "p_ionisation_w", "p_excitation_w", "p_ion_potential_w", "p_wall_w", "p_radiation_w",
            "p_electron_loss_w", "p_other_w", "p_ion_wall_w", "p_electron_wall_w", "p_primary_loss_w",
            "p_anode_collection_w")} | {"accounted_w": bud.accounted_w, "residual_w": bud.residual_w},
        discharge_residual_w=bud.residual_w)
    sc = space_charge_state(extraction_voltage_v=v_ext, effective_gap_m=geo.effective_gap_m, ion_mass_kg=m_i,
                            ion_charge_c=e, n_apertures=geo.n_apertures, aperture_area_m2=geo.screen_aperture_area_m2,
                            actual_current_a=i_ext)
    st.grid_state = GridState(
        screen_grid_potential_v=ladder.screen_grid_potential_v, accelerator_grid_potential_v=ladder.accelerator_grid_potential_v,
        plasma_potential_v=ladder.plasma_potential_v, plume_potential_v=ladder.plume_potential_v,
        extraction_voltage_v=v_ext, electric_field_v_m=electric_field(v_ext, geo.gap_m),
        effective_gap_m=geo.effective_gap_m, geometric_transparency=geo.geometric_transparency,
        ion_transparency=geo.ion_transparency, extracted_current_a=i_ext, intercepted_current_a=i_acc,
        interception_fraction=f_int, perveance_ratio=p_ratio, space_charge_limit_a=sc.limit_a,
        actual_current_density_a_m2=sc.j_actual_a_m2, space_charge_limit_density_a_m2=sc.j_limit_a_m2,
        current_margin_a=sc.margin_a, space_charge_limited=space_limited,
        extraction_efficiency=eff["extraction"], p_grid_loss_w=q["grids"], space_charge_model=sc.model)
    st.beam_state = BeamState(
        beam_current_a=i_beam, beam_voltage_v=v_b, effective_voltage_v=v_eff_volt, beam_power_w=p_beam_ideal,
        beam_kinetic_power_w=p_beam_kin, ion_energy_ideal_j=ion_energy_j(e, v_b),
        ion_velocity_ideal_m_s=vel.ideal_m_s, ion_velocity_effective_m_s=vel.effective_m_s,
        ion_velocity_calibrated_m_s=vel.calibrated_m_s, ion_mass_flow_kg_s=m_ion_beam, ion_rate_s=i_beam / e,
        divergence_sigma_rad=sigma, divergence_half_angle_rad=bg.half_angle_95_rad, thrust_factor_gamma=bg.gamma,
        beam_diameter_m=bg.diameter_m,
        beam_density_m3=(i_beam / (e * vel.effective_m_s * bg.cross_section_m2)) if vel.effective_m_s > 0 else 0.0,
        beam_current_density_a_m2=i_beam / geo.active_area_m2)
    st.neutraliser_state = NeutraliserState(
        on=drv.neutraliser_on, commanded_emission_a=nres.emission.commanded_a, emission_capability_a=nres.emission.capability_a,
        delivered_emission_a=nres.emission.delivered_a, neutralisation_current_a=nres.emission.neutralisation_current_a,
        neutralisation_ratio=nres.emission.neutralisation_ratio if math.isfinite(nres.emission.neutralisation_ratio) else 0.0,
        neutralisation_efficiency=nres.emission.neutralisation_efficiency, charge_imbalance_a=nres.emission.charge_imbalance_a,
        neutralised=nres.emission.neutralised, power_w=nres.power_w, heater_power_w=nres.heater_power_w,
        keeper_power_w=nres.keeper_power_w, heat_w=nres.heat_w, readiness=drv.neutraliser_readiness)
    st.power_state = PowerState(
        p_input_w=ppu.p_input_w, bus_voltage_v=ppu.bus_voltage_v, bus_current_a=ppu.bus_current_a,
        p_ppu_loss_w=ppu.p_ppu_loss_w, p_discharge_w=p_d_sup, discharge_voltage_v=dsup.voltage_v,
        discharge_current_a=dsup.current_a, p_grid_w=gp.beam_supply_w + gp.accel_supply_w,
        p_beam_supply_w=gp.beam_supply_w, p_accel_supply_w=gp.accel_supply_w, p_beam_w=p_beam_ideal,
        p_neutraliser_w=nres.power_w, p_auxiliary_w=p_aux, p_output_total_w=ppu.p_output_total_w, p_stored_w=p_stored,
        ppu_stages={s.name: {"p_out_w": s.p_out_w, "efficiency": s.efficiency, "p_in_w": s.p_in_w, "p_loss_w": s.p_loss_w}
                    for s in ppu.stages} | {"input_stage": {"efficiency": ppu.input_stage_efficiency,
                                                           "p_loss_w": ppu.input_stage_loss_w}},
        ledger={"p_input_w": eb.p_input_w, "p_beam_w": eb.p_beam_w, "p_ionisation_w": eb.p_ionisation_w,
                "p_grid_loss_w": eb.p_grid_loss_w, "p_neutraliser_w": eb.p_neutraliser_w,
                "p_thermal_w": eb.p_thermal_w, "p_other_w": eb.p_other_w, "p_stored_w": eb.p_stored_w,
                "p_grid_loss_over_p_beam": gp.interception_fraction_of_beam_power},
        heat_generated_w=dict(q), p_radiated_escape_w=p_rad_escape)
    st.performance_state = PerformanceState(
        thrust_n=thr.total_n, thrust_ideal_n=thr.ideal_n, thrust_gross_n=thr.gross_n, thrust_axial_ion_n=thr.axial_ion_n,
        divergence_loss_n=thr.divergence_loss_n, thrust_neutral_chamber_n=thr.neutral_chamber_n,
        thrust_neutraliser_gas_n=thr.neutraliser_gas_n, thrust_calibrated_n=thr.calibrated_n, isp_s=isp.isp_total_s,
        isp_main_s=isp.isp_main_s, isp_ion_s=isp.isp_ion_s, effective_exhaust_velocity_m_s=isp.effective_exhaust_velocity_m_s,
        jet_power_w=p_jet, thrust_to_power_n_kw=tp_n, thrust_to_power_mn_kw=tp_mn, efficiencies=eff)
    st.health_state = health
    st.energy_balance, st.mass_balance = eb, mb
    st.calculation_chain = calculation_chain(st, cfg)
    return Evaluation(st, q_gen, space_limited, inventory)


def attach_thermal(cfg: EngineConfig, st: IonEngineState, net: ThermalNetwork, t: np.ndarray,
                   q_gen: np.ndarray, *, space_limited: bool, steady: bool = True) -> IonEngineState:
    rep: dict[str, NodeThermal] = net.node_report(t, q_gen)
    nodes = {n: ThermalNodeState(r.temperature_k, r.generated_heat_w, r.conducted_heat_w, r.radiated_heat_w,
                                 r.stored_rate_w) for n, r in rep.items()}
    tc = net.time_constants(t)
    st.thermal_state = ThermalState(
        environment_k=cfg.thermal.environment_temperature_k, nodes=nodes, total_generated_w=float(q_gen.sum()),
        total_radiated_w=float(sum(r.radiated_heat_w for r in rep.values())),
        time_constants_s={n: float(tc[i]) for i, n in enumerate(NODE_NAMES)}, steady_state_solved=steady)
    st.limits = evaluate_limits(cfg, st, space_limited=space_limited)
    return st


def calculation_chain(st: IonEngineState, cfg: EngineConfig) -> list[dict]:
    """The explicit chain BEAM VOLTAGE -> ... -> SPECIFIC IMPULSE with every intermediate value."""
    b, pf, pe, pw = st.beam_state, st.propellant_flow, st.performance_state, st.power_state
    sp = cfg.species
    return [
        {"step": "BEAM VOLTAGE", "symbol": "V_b", "value": b.beam_voltage_v, "unit": "V", "formula": "commanded screen-grid potential"},
        {"step": "EFFECTIVE VOLTAGE", "symbol": "V_eff", "value": b.effective_voltage_v, "unit": "V",
         "formula": "V_b + dV_p - V_plume"},
        {"step": "ION ENERGY", "symbol": "E_ion", "value": b.ion_energy_ideal_j, "unit": "J", "formula": "q V_b"},
        {"step": "ION VELOCITY", "symbol": "v_ion", "value": b.ion_velocity_effective_m_s, "unit": "m/s",
         "formula": "sqrt(2 q V_eff / m_i)"},
        {"step": "ION RATE", "symbol": "N_dot", "value": b.ion_rate_s, "unit": "1/s", "formula": "I_b / (Z e)"},
        {"step": "ION MASS FLOW", "symbol": "m_dot_ion", "value": pf.ion_flow_beam_kg_s, "unit": "kg/s", "formula": "N_dot m_i"},
        {"step": "MOMENTUM FLOW (AXIAL)", "symbol": "F_axial", "value": pe.thrust_axial_ion_n, "unit": "N",
         "formula": "m_dot_ion v_eff <cos theta>"},
        {"step": "THRUST", "symbol": "F", "value": pe.thrust_n, "unit": "N", "formula": "F_axial + cold-gas momentum"},
        {"step": "SPECIFIC IMPULSE", "symbol": "Isp", "value": pe.isp_s, "unit": "s", "formula": "F / (m_dot_total g0)"},
        {"step": "THRUST-TO-POWER", "symbol": "T/P", "value": pe.thrust_to_power_mn_kw, "unit": "mN/kW", "formula": "F / P_input"},
        {"step": "INPUT POWER", "symbol": "P_in", "value": pw.p_input_w, "unit": "W", "formula": "sum PPU stage inputs / eta_input"},
        {"step": "SPECIES", "symbol": "m_i", "value": sp.ion_mass, "unit": "kg", "formula": sp.species_name},
    ]
