"""Long-duration (lifetime) integration: usage counters -> degradation -> steady state."""

from __future__ import annotations

import pandas as pd

from ..configuration import EngineConfig, OperatingPoint
from .degradation import degraded_health
from .solver import solve_steady_state
from .state import HealthState


def simulate_lifetime(cfg: EngineConfig, op: OperatingPoint | None = None, *, hours: float, steps: int = 50,
                      thermal_cycles_per_100h: float = 0.0, coefficient_offset_sigma: float = 0.0) -> pd.DataFrame:
    """Step operating hours through the degradation models, solving the steady state at each step."""
    op = op or cfg.operating_point
    counters = HealthState()
    rows = []
    dt_h = hours / steps
    for _ in range(steps + 1):
        h = degraded_health(cfg, counters, coefficient_offset_sigma)
        st = solve_steady_state(cfg, op, h)
        rows.append({
            "operating_hours": counters.operating_hours, "propellant_throughput_kg": counters.propellant_throughput_kg,
            "grid_exposure_ah": counters.grid_exposure_ah, "thermal_cycles": counters.thermal_cycles,
            "neutraliser_hours": counters.neutraliser_hours, "interception_fraction": st.grid_state.interception_fraction,
            "thrust_n": st.performance_state.thrust_n, "isp_s": st.performance_state.isp_s,
            "p_input_w": st.power_state.p_input_w, "grid_temperature_k": st.thermal_state.nodes["grids"].temperature_k,
            "grid_margin_k": st.thermal_state.nodes["grids"].margin_k, "neutralisation_ratio": st.neutraliser_state.neutralisation_ratio,
            "ppu_efficiency": st.performance_state.efficiencies["ppu"], "limit_status": st.limits.status,
            "warnings": "; ".join(h.degradation_warnings)})
        counters.operating_hours += dt_h
        counters.neutraliser_hours += dt_h
        counters.propellant_throughput_kg += st.propellant_flow.mass_flow_total_kg_s * dt_h * 3600.0
        counters.grid_exposure_ah += st.grid_state.intercepted_current_a * dt_h
        counters.thermal_cycles += thermal_cycles_per_100h * dt_h / 100.0
    return pd.DataFrame(rows)
