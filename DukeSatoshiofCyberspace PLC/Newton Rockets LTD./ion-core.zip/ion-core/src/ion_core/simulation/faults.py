"""Simulation-only fault injection, with the causal chain through the physics."""

from __future__ import annotations

import dataclasses
from dataclasses import dataclass
from typing import Any

from ..configuration import EngineConfig, OperatingPoint
from .solver import solve_steady_state
from .state import HealthState, IonEngineState

FAULT_NAMES = (
    "propellant_flow_reduction", "ppu_efficiency_degradation", "beam_current_instability",
    "grid_interception_increase", "neutraliser_degradation", "plasma_density_reduction",
    "thermal_rejection_degradation", "sensor_bias",
)


@dataclass
class Fault:
    """magnitude meaning: flow_reduction/neutraliser/plasma/thermal -> fractional loss (0..1);
    ppu -> absolute efficiency loss; interception -> multiplier (>1); instability -> relative
    amplitude; sensor_bias -> additive bias on ``channel``."""

    name: str
    magnitude: float
    onset_s: float = 0.0
    channel: str | None = None
    frequency_hz: float = 5.0


def apply_fault(h: HealthState, f: Fault) -> HealthState:
    if f.name not in FAULT_NAMES:
        raise KeyError(f"unknown fault '{f.name}'; known: {FAULT_NAMES}")
    n = dataclasses.replace(h, sensor_bias=dict(h.sensor_bias), active_faults=[*h.active_faults, f.name],
                            degradation_warnings=list(h.degradation_warnings))
    m = f.magnitude
    if f.name == "propellant_flow_reduction":
        n.flow_factor *= 1.0 - m
    elif f.name == "ppu_efficiency_degradation":
        n.ppu_efficiency_delta -= m
    elif f.name == "beam_current_instability":
        n.beam_instability_amplitude = m
        n.beam_instability_frequency_hz = f.frequency_hz
    elif f.name == "grid_interception_increase":
        n.interception_multiplier *= m
    elif f.name == "neutraliser_degradation":
        n.neutraliser_emission_factor *= 1.0 - m
    elif f.name == "plasma_density_reduction":
        n.plasma_coupling_factor *= 1.0 - m
    elif f.name == "thermal_rejection_degradation":
        n.radiator_emissivity_factor *= 1.0 - m
    elif f.name == "sensor_bias":
        if not f.channel:
            raise ValueError("sensor_bias fault needs a telemetry channel")
        n.sensor_bias[f.channel] = n.sensor_bias.get(f.channel, 0.0) + m
    return n


def _g(path: str):
    def get(st: IonEngineState) -> float:
        obj: Any = st
        for part in path.split("."):
            obj = obj[part] if isinstance(obj, dict) else getattr(obj, part)
        return float(obj) if obj is not None else float("nan")
    return get


# (label, accessor, unit) in causal order
CHAINS: dict[str, list[tuple[str, str, str]]] = {
    "grid_interception_increase": [
        ("grid interception fraction", "grid_state.interception_fraction", "-"),
        ("intercepted ion current", "grid_state.intercepted_current_a", "A"),
        ("grid power loss", "grid_state.p_grid_loss_w", "W"),
        ("grid temperature", "thermal_state.nodes.grids.temperature_k", "K"),
        ("grid thermal margin", "thermal_state.nodes.grids.margin_k", "K"),
        ("beam current", "beam_state.beam_current_a", "A"),
        ("thrust", "performance_state.thrust_n", "N"),
    ],
    "propellant_flow_reduction": [
        ("total propellant flow", "propellant_flow.mass_flow_total_kg_s", "kg/s"),
        ("neutral density", "propellant_flow.neutral_density_m3", "m^-3"),
        ("electron temperature", "plasma_state.electron_temperature_ev", "eV"),
        ("ion production rate", "plasma_state.ion_production_rate_s", "1/s"),
        ("chamber utilisation", "propellant_flow.chamber_utilisation", "-"),
        ("discharge power", "power_state.p_discharge_w", "W"),
        ("thrust", "performance_state.thrust_n", "N"),
        ("specific impulse", "performance_state.isp_s", "s"),
    ],
    "ppu_efficiency_degradation": [
        ("PPU efficiency", "performance_state.efficiencies.ppu", "-"),
        ("PPU loss", "power_state.p_ppu_loss_w", "W"),
        ("input power", "power_state.p_input_w", "W"),
        ("PPU temperature", "thermal_state.nodes.ppu.temperature_k", "K"),
        ("PPU thermal margin", "thermal_state.nodes.ppu.margin_k", "K"),
        ("thrust-to-power", "performance_state.thrust_to_power_mn_kw", "mN/kW"),
    ],
    "neutraliser_degradation": [
        ("emission capability", "neutraliser_state.emission_capability_a", "A"),
        ("delivered emission", "neutraliser_state.delivered_emission_a", "A"),
        ("neutralisation ratio", "neutraliser_state.neutralisation_ratio", "-"),
        ("charge imbalance", "neutraliser_state.charge_imbalance_a", "A"),
    ],
    "plasma_density_reduction": [
        ("ionisation efficiency", "performance_state.efficiencies.ionisation", "-"),
        ("electron density", "plasma_state.electron_density_m3", "m^-3"),
        ("ion production rate", "plasma_state.ion_production_rate_s", "1/s"),
        ("beam current", "beam_state.beam_current_a", "A"),
        ("thrust", "performance_state.thrust_n", "N"),
        ("input power", "power_state.p_input_w", "W"),
    ],
    "thermal_rejection_degradation": [
        ("structure radiated heat", "thermal_state.nodes.structure.radiated_heat_w", "W"),
        ("structure temperature", "thermal_state.nodes.structure.temperature_k", "K"),
        ("chamber temperature", "thermal_state.nodes.chamber.temperature_k", "K"),
        ("grid temperature", "thermal_state.nodes.grids.temperature_k", "K"),
        ("grid thermal margin", "thermal_state.nodes.grids.margin_k", "K"),
        ("PPU temperature", "thermal_state.nodes.ppu.temperature_k", "K"),
    ],
}


def fault_causal_report(cfg: EngineConfig, op: OperatingPoint, fault: Fault,
                        base_health: HealthState | None = None) -> dict[str, Any]:
    """Baseline vs faulted steady state, listing the changes in causal order.

    * plasma_density_reduction is evaluated with the discharge power held fixed (so the
      reduced plasma coupling shows up in density and beam current instead of being
      silently compensated by the regulator).
    * beam_current_instability is evaluated at the peak of the oscillation.
    * sensor_bias has no physical effect on the engine (telemetry only).
    """
    base_health = base_health or HealthState()
    base = solve_steady_state(cfg, op, base_health)
    op_eval = op
    if fault.name == "plasma_density_reduction":
        op_eval = OperatingPoint(mass_flow_kg_s=op.mass_flow_kg_s, beam_voltage_v=op.beam_voltage_v,
                                 discharge_power_w=base.power_state.p_discharge_w,
                                 accelerator_voltage_v=op.accelerator_voltage_v)
        base = solve_steady_state(cfg, op_eval, base_health)
    if fault.name == "beam_current_instability":
        peak = (op.beam_current_a or base.beam_state.beam_current_a) * (1.0 + fault.magnitude)
        op_eval = op.model_copy(update={"beam_current_a": peak})
        faulted = solve_steady_state(cfg, op_eval, base_health)
        chain_key = "grid_interception_increase"
    else:
        faulted = solve_steady_state(cfg, op_eval, apply_fault(base_health, fault))
        chain_key = fault.name
    chain = []
    for label, path, unit in CHAINS.get(chain_key, []):
        b0, b1 = _g(path)(base), _g(path)(faulted)
        chain.append({"quantity": label, "path": path, "unit": unit, "baseline": b0, "faulted": b1,
                      "delta_pct": (b1 - b0) / abs(b0) * 100.0 if b0 not in (0.0,) else None})
    return {"fault": dataclasses.asdict(fault), "chain": chain, "baseline_limit_status": base.limits.status,
            "faulted_limit_status": faulted.limits.status, "faulted_limit_messages": faulted.limits.messages,
            "baseline_state": base, "faulted_state": faulted,
            "note": "sensor_bias affects telemetry only" if fault.name == "sensor_bias" else ""}
