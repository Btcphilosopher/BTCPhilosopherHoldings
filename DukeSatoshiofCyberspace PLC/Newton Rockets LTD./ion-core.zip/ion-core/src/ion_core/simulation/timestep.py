"""Time-stepping primitives: exact first-order lags and adaptive step selection."""

from __future__ import annotations

import math


def lag(x: float, target: float, tau_s: float, dt_s: float) -> float:
    """Exact solution of dx/dt = (target - x)/tau over dt (unconditionally stable)."""
    if tau_s <= 0.0:
        return target
    return target + (x - target) * math.exp(-dt_s / tau_s)


def choose_dt(mode: str, fast_s: float, steady_s: float, cooldown_s: float) -> float:
    if mode == "COOLDOWN":
        return cooldown_s
    if mode in ("STEADY_OPERATION", "OFF"):
        return steady_s
    return fast_s
