"""Explicit engine operating constraints. The solver never clamps an invalid value:
it reports VALID / WARNING / LIMIT / INVALID with the margin to every limit.

INVALID : physically impossible or outside the model's validity (e.g. commanded beam
          current above the space-charge limit, un-neutralised beam, plasma not sustained,
          failed balance).
LIMIT   : a configured operating limit is exceeded.
WARNING : within ``warn_fraction`` of a limit.
"""

from __future__ import annotations

from ..configuration import EngineConfig
from .state import STATUS_ORDER, IonEngineState, LimitCheck, LimitReport, Status


def _max_check(name: str, value: float, limit: float, unit: str, warn: float, msg: str = "") -> LimitCheck:
    margin = (limit - value) / limit if limit else None
    if value > limit:
        st = Status.LIMIT
    elif value > warn * limit:
        st = Status.WARNING
    else:
        st = Status.VALID
    return LimitCheck(name, st.value, value, limit, margin, unit,
                      msg or (f"{value:.4g} {unit} vs maximum {limit:.4g}" if st != Status.VALID else ""))


def _min_check(name: str, value: float, limit: float, unit: str, warn: float, msg: str = "") -> LimitCheck:
    margin = (value - limit) / limit if limit else None
    if value < limit:
        st = Status.LIMIT
    elif value < limit / warn:
        st = Status.WARNING
    else:
        st = Status.VALID
    return LimitCheck(name, st.value, value, limit, margin, unit,
                      msg or (f"{value:.4g} {unit} vs minimum {limit:.4g}" if st != Status.VALID else ""))


def _flag(name: str, bad: bool, status: Status, msg: str, value: float = 0.0) -> LimitCheck:
    return LimitCheck(name, status.value if bad else Status.VALID.value, value, None, None, "",
                      msg if bad else "")


def evaluate_limits(cfg: EngineConfig, st: IonEngineState, *, space_limited: bool = False,
                    beam_on: bool | None = None) -> LimitReport:
    lim, w = cfg.limits, cfg.limits.warn_fraction
    g, b, pl, n, pw, th = (st.grid_state, st.beam_state, st.plasma_state, st.neutraliser_state,
                           st.power_state, st.thermal_state)
    on = (b.beam_current_a > lim.beam_active_threshold_a) if beam_on is None else beam_on
    present = b.beam_current_a > 1e-6
    ch = [
        _max_check("beam_voltage", b.beam_voltage_v, lim.max_beam_voltage_v, "V", w),
        _max_check("beam_current", b.beam_current_a, lim.max_beam_current_a, "A", w),
        _max_check("discharge_power", pw.p_discharge_w, lim.max_discharge_power_w, "W", w),
        _max_check("neutraliser_commanded_current", n.commanded_emission_a, lim.max_neutraliser_current_a, "A", w),
        _max_check("thermal_load", th.total_generated_w, lim.max_thermal_load_w, "W", w),
        _max_check("grid_electric_field", g.electric_field_v_m, lim.max_electric_field_v_m, "V/m", w),
    ]
    if g.extracted_current_a > lim.beam_active_threshold_a:
        ch.append(_max_check("interception_fraction", g.interception_fraction, lim.max_interception_fraction, "-", w))
    tmax = {"grids": lim.max_grid_temperature_k, "chamber": lim.max_chamber_temperature_k,
            "neutraliser": lim.max_neutraliser_temperature_k, "ppu": lim.max_ppu_temperature_k}
    for node, limit in tmax.items():
        if node in th.nodes:
            ns = th.nodes[node]
            ns.limit_k, ns.margin_k = limit, limit - ns.temperature_k
            ch.append(_max_check(f"{node}_temperature", ns.temperature_k, limit, "K", w))
    if on:
        ch.append(_min_check("plasma_density", pl.electron_density_m3, lim.min_plasma_density_m3, "m^-3", w))
        ch.append(_min_check("accelerator_voltage_backstreaming", abs(g.accelerator_grid_potential_v),
                             lim.min_accel_voltage_v, "V", w,
                             "accelerator bias too low: electron backstreaming margin lost"))
    ratio = g.perveance_ratio
    if g.space_charge_limited and g.extracted_current_a <= lim.beam_active_threshold_a:
        pass  # negligible extracted current (ramp end-points): not a meaningful limit
    elif ratio > lim.max_space_charge_ratio and not g.space_charge_limited:
        ch.append(LimitCheck("space_charge", Status.INVALID.value, ratio, lim.max_space_charge_ratio,
                             lim.max_space_charge_ratio - ratio, "-",
                             f"beam current {g.extracted_current_a:.4g} A exceeds space-charge limit "
                             f"{g.space_charge_limit_a:.4g} A"))
    elif g.space_charge_limited:
        ch.append(LimitCheck("space_charge", Status.LIMIT.value, ratio, lim.max_space_charge_ratio, 0.0, "-",
                             "extraction is space-charge limited (plasma could supply more current)"))
    else:
        ch.append(_max_check("space_charge", ratio, lim.max_space_charge_ratio, "-", w))
    if present:
        ch.append(_flag("plasma_sustained", not pl.sustained, Status.INVALID,
                        "discharge plasma not sustained at this neutral density / power"))
        ch.append(_flag("beam_neutralised", not n.neutralised, Status.INVALID,
                        f"beam not neutralised: charge imbalance {n.charge_imbalance_a:.4g} A", n.charge_imbalance_a))
        ch.append(_flag("extraction_supply", pl.extraction_supply_margin_s < -1e-4 * max(pl.ion_extracted_rate_s, 1.0), Status.INVALID,
                        "plasma cannot supply the commanded beam current at this discharge power"))
    pf = st.propellant_flow
    ch.append(_flag("propellant_available", pf.neutral_density_m3 <= 0 and on, Status.INVALID,
                    "commanded ion flow exceeds the main-line propellant flow (utilisation >= 1)"))
    ch.append(_max_check("propellant_utilisation", pf.chamber_utilisation, cfg.flow.max_propellant_utilisation,
                         "-", w))
    if st.energy_balance is not None:
        ch.append(_flag("energy_balance", st.energy_balance.status == "FAIL", Status.INVALID,
                        st.energy_balance.message, st.energy_balance.residual_w))
    if st.mass_balance is not None:
        ch.append(_flag("mass_balance", st.mass_balance.status == "FAIL", Status.INVALID,
                        st.mass_balance.message, st.mass_balance.residual_kg_s))
    if st.mass_balance is not None and st.mass_balance.m_dot_in_kg_s > 0.05 * cfg.operating_point.mass_flow_kg_s:
        rel = abs(st.mass_balance.m_dot_storage_neglected_kg_s) / st.mass_balance.m_dot_in_kg_s
        ch.append(_flag("quasi_static_neutral_gas", rel > 0.02, Status.WARNING,
                        f"neutral inventory changing at {rel:.1%} of inflow: quasi-static assumption strained", rel))
    ch.append(_flag("discharge_budget", abs(pl.discharge_residual_w) > 1e-6 * max(pw.p_discharge_w, 1.0),
                    Status.INVALID, f"discharge power budget residual {pl.discharge_residual_w:+.3e} W"))
    worst = max((Status(c.status) for c in ch), key=lambda s: STATUS_ORDER[s], default=Status.VALID)
    return LimitReport(worst.value, ch)
