"""Discharge supply: voltage / current / power bookkeeping."""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class DischargeSupply:
    voltage_v: float
    current_a: float
    power_w: float


def discharge_supply(power_w: float, voltage_v: float) -> DischargeSupply:
    """I_d = P_d / V_d for a regulated-voltage discharge supply."""
    return DischargeSupply(voltage_v, power_w / voltage_v if voltage_v > 0 else 0.0, power_w)
