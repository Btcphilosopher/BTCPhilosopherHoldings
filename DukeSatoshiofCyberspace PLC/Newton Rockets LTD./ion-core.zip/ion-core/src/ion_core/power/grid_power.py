"""Grid power: supply outputs and the heat deposited on the grids by intercepted ions."""

from __future__ import annotations

from dataclasses import dataclass

from ..constants import E_CHARGE


@dataclass(frozen=True)
class GridPower:
    beam_supply_w: float  # V_b * (I_beam + I_accel_intercepted)
    accel_supply_w: float  # |V_a| * I_accel_intercepted
    beam_supply_current_a: float
    accel_supply_current_a: float
    intercepted_ion_power_w: float  # kinetic + recombination energy deposited by intercepted ions
    interception_fraction_of_beam_power: float  # spec shorthand: P_grid_loss / P_beam


def grid_power(*, v_beam: float, v_accel: float, plasma_offset_v: float, i_beam: float,
               i_intercepted: float, ionisation_energy_ev: float) -> GridPower:
    """Intercepted ions fall through the full gap potential and recombine on the grid:
    P = I_acc * (V_b + |V_a| + dV_p + E_iz/e)."""
    i_ext = i_beam + i_intercepted
    p_int = i_intercepted * (v_beam + abs(v_accel) + plasma_offset_v + ionisation_energy_ev)
    p_beam = i_beam * v_beam
    _ = E_CHARGE
    return GridPower(v_beam * i_ext, abs(v_accel) * i_intercepted, i_ext, i_intercepted, p_int,
                     p_int / p_beam if p_beam > 0 else 0.0)
