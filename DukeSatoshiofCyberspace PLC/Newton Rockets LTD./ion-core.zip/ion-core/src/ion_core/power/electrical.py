"""Reduced-order PPU: DC bus -> converter stages -> thruster loads.

Each conversion stage has an efficiency; P_loss = P_in - P_out for every stage and the
common input stage. Nothing is hidden: ``PPUResult.stages`` lists every stage.
"""

from __future__ import annotations

from dataclasses import dataclass

from ..configuration import PPUConfig


@dataclass(frozen=True)
class StageResult:
    name: str
    p_out_w: float
    efficiency: float
    p_in_w: float  # before the common input stage
    p_loss_w: float  # P_in - P_out


@dataclass(frozen=True)
class PPUResult:
    bus_voltage_v: float
    bus_current_a: float
    p_input_w: float
    p_output_total_w: float
    p_ppu_loss_w: float
    input_stage_efficiency: float
    input_stage_loss_w: float
    stages: tuple[StageResult, ...]

    def stage(self, name: str) -> StageResult:
        return next(s for s in self.stages if s.name == name)


def ppu_chain(cfg: PPUConfig, *, p_discharge_w: float, p_beam_w: float, p_accel_w: float,
              p_neutraliser_w: float, p_aux_w: float, efficiency_delta: float = 0.0) -> PPUResult:
    """Compute input power from the stage output powers (efficiency_delta: absolute change)."""
    def eff(x: float) -> float:
        return min(max(x + efficiency_delta, 0.05), 1.0)

    spec = (("discharge", p_discharge_w, cfg.efficiency_discharge),
            ("beam", p_beam_w, cfg.efficiency_beam),
            ("accelerator", p_accel_w, cfg.efficiency_accel),
            ("neutraliser", p_neutraliser_w, cfg.efficiency_neutraliser),
            ("auxiliary", p_aux_w, cfg.efficiency_auxiliary))
    stages = []
    for name, p_out, e0 in spec:
        e = eff(e0)
        p_in = p_out / e
        stages.append(StageResult(name, p_out, e, p_in, p_in - p_out))
    p_mid = sum(s.p_in_w for s in stages)
    e_in = eff(cfg.efficiency_input_stage)
    p_input = p_mid / e_in
    p_out_tot = sum(s.p_out_w for s in stages)
    return PPUResult(cfg.bus_voltage_v, p_input / cfg.bus_voltage_v, p_input, p_out_tot,
                     p_input - p_out_tot, e_in, p_input - p_mid, tuple(stages))
