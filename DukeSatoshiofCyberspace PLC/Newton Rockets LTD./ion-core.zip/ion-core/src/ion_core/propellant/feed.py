"""Propellant feed: split of the total engine flow between main (discharge) line,
neutraliser line and an explicit leak/loss channel."""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class FlowSplit:
    total_kg_s: float
    main_kg_s: float
    neutraliser_kg_s: float
    leak_kg_s: float


def split_flow(total_kg_s: float, neutraliser_fraction: float, leak_fraction: float) -> FlowSplit:
    """total = main + neutraliser + leak (exact)."""
    neut = neutraliser_fraction * total_kg_s
    leak = leak_fraction * total_kg_s
    return FlowSplit(total_kg_s, total_kg_s - neut - leak, neut, leak)
