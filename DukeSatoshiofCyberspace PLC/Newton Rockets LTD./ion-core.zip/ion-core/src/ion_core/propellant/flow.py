"""Particle / mass flow bookkeeping. Distinguishes propellant (total engine), main-line,
ion and neutral flows; never substitutes one for another silently."""

from __future__ import annotations

from ..constants import E_CHARGE


def atoms_per_second(mass_flow_kg_s: float, atomic_mass_kg: float) -> float:
    return mass_flow_kg_s / atomic_mass_kg


def ion_rate_from_current(current_a: float, charge_state: int = 1) -> float:
    """N_dot_ions = I / (Z e), ions/s."""
    return current_a / (charge_state * E_CHARGE)


def ion_mass_flow(current_a: float, ion_mass_kg: float, charge_state: int = 1) -> float:
    """m_dot_ion = N_dot_ions * m_i, kg/s."""
    return ion_rate_from_current(current_a, charge_state) * ion_mass_kg


def propellant_utilisation(ion_mass_flow_kg_s: float, propellant_mass_flow_kg_s: float) -> float:
    """eta_m = m_dot_ion / m_dot_propellant — the caller states which propellant flow."""
    return ion_mass_flow_kg_s / propellant_mass_flow_kg_s if propellant_mass_flow_kg_s > 0 else 0.0
