"""Propellant species model. Nothing in the physics engine hard-codes xenon.

Neutral atoms, singly charged ions, higher charge states and electrons are distinct
quantities: ``atomic_mass`` is the neutral atom, ``ion_mass`` removes ``charge_state``
electrons, ``ion_charge`` is ``charge_state * e``.

Ionisation cross-sections use the Lotz formula (single outer p-shell). It is a
semi-quantitative reduced-order model, adequate for trends, not for calibration.
The lumped excitation cross-sections below are DEMONSTRATION values.
"""

from __future__ import annotations

from pydantic import BaseModel, ConfigDict, Field

from ..constants import AMU, E_CHARGE, M_ELECTRON


class PropellantSpecies(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")

    species_name: str
    atomic_mass_u: float = Field(gt=0)
    ionisation_energy_ev: float = Field(gt=0)  # first ionisation energy
    charge_state: int = Field(default=1, ge=1)
    lotz_shells: tuple[tuple[int, float], ...]  # (electrons in shell, binding energy eV)
    lotz_a_cm2_ev2: float = 4.5e-14
    excitation_threshold_ev: float = Field(gt=0)
    excitation_cross_section_m2: float = Field(gt=0)  # lumped effective, DEMONSTRATION
    notes: str = ""

    @property
    def atomic_mass(self) -> float:
        """Neutral atom mass, kg."""
        return self.atomic_mass_u * AMU

    @property
    def ion_mass(self) -> float:
        """Ion mass, kg (neutral minus ``charge_state`` electrons)."""
        return self.atomic_mass - self.charge_state * M_ELECTRON

    @property
    def ion_charge(self) -> float:
        """Ion charge, C."""
        return self.charge_state * E_CHARGE

    @property
    def ionisation_energy(self) -> float:
        """First ionisation energy, J."""
        return self.ionisation_energy_ev * E_CHARGE


XENON = PropellantSpecies(
    species_name="xenon", atomic_mass_u=131.293, ionisation_energy_ev=12.1298,
    lotz_shells=((6, 12.1298),), excitation_threshold_ev=8.32,
    excitation_cross_section_m2=1.0e-20,
    notes="Xe; excitation cross-section is a DEMONSTRATION lumped value.",
)
KRYPTON = PropellantSpecies(
    species_name="krypton", atomic_mass_u=83.798, ionisation_energy_ev=13.9996,
    lotz_shells=((6, 13.9996),), excitation_threshold_ev=9.92,
    excitation_cross_section_m2=1.0e-20,
    notes="Kr; excitation cross-section is a DEMONSTRATION lumped value.",
)
ARGON = PropellantSpecies(
    species_name="argon", atomic_mass_u=39.948, ionisation_energy_ev=15.7596,
    lotz_shells=((6, 15.7596),), excitation_threshold_ev=11.55,
    excitation_cross_section_m2=1.0e-20,
    notes="Ar; excitation cross-section is a DEMONSTRATION lumped value.",
)

SPECIES_REGISTRY: dict[str, PropellantSpecies] = {
    s.species_name: s for s in (XENON, KRYPTON, ARGON)
}


def get_species(name: str) -> PropellantSpecies:
    try:
        return SPECIES_REGISTRY[name.lower()]
    except KeyError as exc:
        raise KeyError(f"unknown species '{name}'; known: {sorted(SPECIES_REGISTRY)}") from exc


def register_species(species: PropellantSpecies) -> None:
    """Add a species at runtime — no engine code changes needed."""
    SPECIES_REGISTRY[species.species_name.lower()] = species
