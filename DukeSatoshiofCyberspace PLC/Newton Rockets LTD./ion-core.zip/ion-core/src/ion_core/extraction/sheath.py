"""Potential ladder and Bohm-flux supply at the sheath edge.

Potentials are referenced to the neutraliser / engine common (0 V):

    plasma potential   V_p = V_screen + dV_p          (dV_p: configured plasma-to-screen offset)
    screen grid        V_s = V_beam                   (positive)
    accelerator grid   V_a = -|V_accel|               (negative)
    plume plasma       V_c                            (neutraliser coupling potential)

The extraction voltage across the gap is V_ext = V_s - V_a = V_beam + |V_accel|.
"""

from __future__ import annotations

from dataclasses import dataclass

from ..constants import E_CHARGE


@dataclass(frozen=True)
class PotentialLadder:
    plasma_potential_v: float
    screen_grid_potential_v: float
    accelerator_grid_potential_v: float
    plume_potential_v: float
    extraction_voltage_v: float
    plasma_to_screen_offset_v: float
    net_ion_energy_voltage_v: float  # V_p - V_plume: potential drop seen by a born-at-plasma ion


def potential_ladder(beam_voltage_v: float, accel_bias_v: float, plasma_offset_v: float,
                     plume_potential_v: float) -> PotentialLadder:
    v_s = beam_voltage_v
    v_a = -abs(accel_bias_v)
    v_p = v_s + plasma_offset_v
    return PotentialLadder(v_p, v_s, v_a, plume_potential_v, v_s - v_a, plasma_offset_v,
                           v_p - plume_potential_v)


def electric_field(extraction_voltage_v: float, gap_m: float) -> float:
    """Mean field across the screen-accelerator gap, V/m."""
    return extraction_voltage_v / gap_m if gap_m > 0 else float("inf")


def bohm_current_density(n_edge: float, u_bohm: float, charge_state: int = 1) -> float:
    """Ion current density available at the sheath edge, A/m^2."""
    return charge_state * E_CHARGE * n_edge * u_bohm
