"""Extraction currents, grid interception and beam-divergence optics model.

perveance ratio p = I_extracted / I_space_charge_limit.
    interception:   f_int = f0 * mult * (1 + g x^2),  x = max(0, p - p_opt)/(1 - p_opt)
                    (over-perveance drives ions into the accelerator grid)
    divergence:     sigma = sigma0 * (1 + k ((p - p_opt)/p_opt)^2)
                    (under-perveance over-focuses, over-perveance under-focuses)
Both are reduced-order parametric forms with DEMONSTRATION coefficients (see GridConfig).
"""

from __future__ import annotations

from ..configuration import GridConfig


def perveance_excess(ratio: float, p_opt: float) -> float:
    return max(0.0, ratio - p_opt) / (1.0 - p_opt)


def interception_fraction(g: GridConfig, perveance_ratio: float, multiplier: float = 1.0) -> float:
    x = perveance_excess(perveance_ratio, g.perveance_ratio_optimum)
    return min(g.interception_fraction_base * multiplier * (1.0 + g.interception_overperveance_gain * x * x), 0.95)


def divergence_sigma(g: GridConfig, perveance_ratio: float) -> float:
    d = (perveance_ratio - g.perveance_ratio_optimum) / g.perveance_ratio_optimum
    return g.divergence_sigma_base_rad * (1.0 + g.divergence_perveance_gain * d * d)


def beam_from_extracted(i_extracted_a: float, f_int: float) -> tuple[float, float]:
    """(I_beam, I_accel_interception) from the extracted ion current."""
    i_acc = f_int * i_extracted_a
    return i_extracted_a - i_acc, i_acc
