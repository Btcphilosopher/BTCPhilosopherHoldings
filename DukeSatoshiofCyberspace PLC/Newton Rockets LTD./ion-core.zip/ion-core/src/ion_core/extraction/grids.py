"""Two-grid optics geometry (screen + accelerator)."""

from __future__ import annotations

import math
from dataclasses import dataclass

from ..configuration import GridConfig


@dataclass(frozen=True)
class GridGeometry:
    active_area_m2: float
    n_apertures: int
    screen_aperture_area_m2: float  # one aperture
    screen_open_area_m2: float  # all apertures (or transparency * active area)
    geometric_transparency: float
    ion_open_area_m2: float  # effective area through which plasma ions are focused
    ion_transparency: float
    neutral_exit_area_m2: float
    accel_open_area_m2: float
    gap_m: float
    screen_thickness_m: float
    screen_aperture_diameter_m: float
    accel_aperture_diameter_m: float
    effective_gap_m: float  # Kaufman effective acceleration length


def effective_gap(gap_m: float, screen_thickness_m: float, screen_aperture_diameter_m: float) -> float:
    """l_e = sqrt((l_g + t_s)^2 + d_s^2 / 4) — Kaufman effective extraction length.

    Reduced-order: assumes a planar-diode-equivalent length for a round-hole two-grid system;
    it is not valid for strongly distorted grids or very thick screen grids.
    """
    return math.sqrt((gap_m + screen_thickness_m) ** 2 + 0.25 * screen_aperture_diameter_m**2)


def build_geometry(g: GridConfig, gap_scale: float = 1.0) -> GridGeometry:
    """``gap_scale`` allows thermal/degradation change of the cold gap."""
    a_act = math.pi * 0.25 * g.active_diameter_m**2
    a_ap = math.pi * 0.25 * g.aperture_diameter_m**2
    open_area = (g.transparency * a_act) if g.transparency is not None else g.number_of_apertures * a_ap
    ion_open = min(0.95 * a_act, g.ion_focusing_factor * open_area)
    a_acc_ap = math.pi * 0.25 * g.accel_aperture_diameter_m**2
    d_min = min(g.aperture_diameter_m, g.accel_aperture_diameter_m)
    a_neutral = g.number_of_apertures * math.pi * 0.25 * d_min**2 * g.neutral_clausing_factor
    gap = g.extraction_gap_m * gap_scale
    return GridGeometry(
        active_area_m2=a_act, n_apertures=g.number_of_apertures, screen_aperture_area_m2=a_ap,
        screen_open_area_m2=open_area, geometric_transparency=open_area / a_act,
        ion_open_area_m2=ion_open, ion_transparency=ion_open / a_act,
        neutral_exit_area_m2=a_neutral, accel_open_area_m2=g.number_of_apertures * a_acc_ap,
        gap_m=gap, screen_thickness_m=g.grid_thickness_m,
        screen_aperture_diameter_m=g.aperture_diameter_m,
        accel_aperture_diameter_m=g.accel_aperture_diameter_m,
        effective_gap_m=effective_gap(gap, g.grid_thickness_m, g.aperture_diameter_m))
