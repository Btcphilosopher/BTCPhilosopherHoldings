"""Space-charge-limited extraction: planar Child–Langmuir (reduced-order).

    J = (4/9) eps0 sqrt(2 q / m) V^(3/2) / d^2

REDUCED-ORDER PLANAR APPROXIMATION. It is applied per aperture with the Kaufman effective
length and the screen-aperture area as the emitting area. It does not capture meniscus
shape, aperture-to-gap ratio effects, grid misalignment or thermal distortion, and must
not be extrapolated to arbitrary grid geometries.
"""

from __future__ import annotations

import math
from dataclasses import dataclass

from ..constants import EPS0


def child_langmuir_current_density(voltage_v: float, gap_m: float, ion_mass_kg: float,
                                   ion_charge_c: float) -> float:
    """Planar space-charge-limited current density, A/m^2."""
    if voltage_v <= 0.0 or gap_m <= 0.0:
        return 0.0
    return (4.0 / 9.0) * EPS0 * math.sqrt(2.0 * ion_charge_c / ion_mass_kg) * voltage_v**1.5 / gap_m**2


@dataclass(frozen=True)
class SpaceChargeResult:
    limit_a: float  # space_charge_limit (total)
    actual_a: float
    j_limit_a_m2: float  # at the aperture
    j_actual_a_m2: float
    margin_a: float  # current_margin = limit - actual
    ratio: float  # actual / limit (perveance ratio)
    model: str = "planar Child-Langmuir, reduced-order (Kaufman effective gap)"


def space_charge_state(*, extraction_voltage_v: float, effective_gap_m: float, ion_mass_kg: float,
                       ion_charge_c: float, n_apertures: int, aperture_area_m2: float,
                       actual_current_a: float) -> SpaceChargeResult:
    j_lim = child_langmuir_current_density(extraction_voltage_v, effective_gap_m, ion_mass_kg, ion_charge_c)
    i_lim = j_lim * aperture_area_m2 * n_apertures
    j_act = actual_current_a / (aperture_area_m2 * n_apertures)
    return SpaceChargeResult(i_lim, actual_current_a, j_lim, j_act, i_lim - actual_current_a,
                             actual_current_a / i_lim if i_lim > 0 else math.inf)
