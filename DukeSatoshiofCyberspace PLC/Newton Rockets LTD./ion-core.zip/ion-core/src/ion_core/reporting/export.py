"""Result export: JSON, CSV, Parquet, HDF5 — each carrying simulation_id, timestamp,
software/model version, configuration, parameters, units, scenario, random seed, results
and validation status."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import h5py
import numpy as np
import pandas as pd

from ..results import SimulationResult
from ..simulation.state import to_jsonable
from ..units import unit_of


def _tables(res: SimulationResult) -> dict[str, pd.DataFrame]:
    out: dict[str, pd.DataFrame] = {"operating_points": res.operating_points}
    if res.time_history is not None:
        out["time_history"] = res.time_history
    out.update(res.tables)
    return out


def _df_records(df: pd.DataFrame) -> list[dict[str, Any]]:
    return to_jsonable(df.replace({np.nan: None}).to_dict(orient="records"))


def result_to_dict(res: SimulationResult, include_tables: bool = True) -> dict[str, Any]:
    d: dict[str, Any] = {
        **{k: res.metadata[k] for k in ("simulation_id", "timestamp", "software_version", "model_version", "random_seed")},
        "mode": res.metadata["mode"], "scenario": res.metadata["scenario"], "parameters": res.metadata["parameters"],
        "units": res.metadata["units"], "unit_system": res.metadata["unit_system"],
        "parameter_provenance": res.metadata["parameter_provenance"],
        "validation_status": res.validation_status, "configuration": res.engine_configuration,
        "results": {"performance": res.performance, "thermal_state": res.thermal_state, "power_balance": res.power_balance,
                    "mass_balance": res.mass_balance, "warnings": res.warnings, "validation": res.validation},
    }
    if include_tables:
        d["results"]["tables"] = {k: _df_records(v) for k, v in _tables(res).items()}
    if res.state is not None:
        d["results"]["state"] = res.state.to_dict()
    return d


def write_json(res: SimulationResult, path: str | Path) -> Path:
    p = Path(path)
    p.write_text(json.dumps(result_to_dict(res), indent=1, allow_nan=False), encoding="utf-8")
    return p


def write_csv(res: SimulationResult, path: str | Path) -> list[Path]:
    """One CSV per table: <stem>_<table>.csv, with a ``# `` metadata header (units row included)."""
    base = Path(path)
    stem = base.with_suffix("")
    written = []
    for name, df in _tables(res).items():
        p = Path(f"{stem}_{name}.csv")
        with open(p, "w", encoding="utf-8", newline="") as fh:
            fh.write(f"# simulation_id={res.metadata['simulation_id']} timestamp={res.metadata['timestamp']} "
                     f"software_version={res.metadata['software_version']} model_version={res.metadata['model_version']} "
                     f"random_seed={res.metadata['random_seed']} validation_status={res.validation_status}\n")
            fh.write("# units: " + ",".join(unit_of(c) or "-" for c in df.columns) + "\n")
            df.to_csv(fh, index=False)
        written.append(p)
    return written


def write_parquet(res: SimulationResult, path: str | Path) -> list[Path]:
    import pyarrow as pa
    import pyarrow.parquet as pq

    stem = Path(path).with_suffix("")
    written = []
    meta = {k: json.dumps(to_jsonable(v)) for k, v in res.metadata.items()}
    meta["configuration"] = json.dumps(res.engine_configuration)
    for name, df in _tables(res).items():
        table = pa.Table.from_pandas(df.reset_index(drop=True), preserve_index=False)
        table = table.replace_schema_metadata({**(table.schema.metadata or {}),
                                               **{k.encode(): v.encode() for k, v in meta.items()}})
        p = Path(f"{stem}_{name}.parquet")
        pq.write_table(table, p)
        written.append(p)
    return written


def write_hdf5(res: SimulationResult, path: str | Path) -> Path:
    p = Path(path)
    with h5py.File(p, "w") as f:
        for k, v in res.metadata.items():
            f.attrs[k] = json.dumps(to_jsonable(v)) if isinstance(v, (dict, list)) else str(v)
        f.attrs["configuration_json"] = json.dumps(res.engine_configuration)
        f.attrs["result_json"] = json.dumps(result_to_dict(res, include_tables=False), allow_nan=False)
        f.attrs["validation_status"] = res.validation_status
        for name, df in _tables(res).items():
            g = f.create_group(name)
            for col in df.columns:
                s = df[col]
                if s.dtype == object or str(s.dtype).startswith("str") or s.dtype == bool and False:
                    ds = g.create_dataset(col, data=np.array(s.astype(str).tolist(), dtype=h5py.string_dtype()))
                else:
                    ds = g.create_dataset(col, data=s.to_numpy(dtype=float if s.dtype != bool else bool))
                ds.attrs["unit"] = unit_of(col) or "-"
    return p


def export_result(res: SimulationResult, path: str | Path, fmt: str | None = None) -> list[Path]:
    p = Path(path)
    fmt = (fmt or p.suffix.lstrip(".")).lower()
    p.parent.mkdir(parents=True, exist_ok=True)
    if fmt == "json":
        return [write_json(res, p)]
    if fmt == "csv":
        return write_csv(res, p)
    if fmt in ("parquet", "pq"):
        return write_parquet(res, p)
    if fmt in ("h5", "hdf5"):
        return [write_hdf5(res, p)]
    raise ValueError(f"unknown export format '{fmt}' (json, csv, parquet, h5)")


def load_hdf5(path: str | Path) -> dict[str, Any]:
    """Read back an HDF5 result: metadata, configuration, result dict and tables."""
    with h5py.File(path, "r") as f:
        attrs = {k: (v.decode() if isinstance(v, bytes) else v) for k, v in f.attrs.items()}
        tables: dict[str, pd.DataFrame] = {}
        for name, g in f.items():
            cols = {}
            for col, ds in g.items():
                arr = ds[()]
                cols[col] = [x.decode() if isinstance(x, bytes) else x for x in arr] if arr.dtype.kind in "OS" else arr
            tables[name] = pd.DataFrame(cols)
    return {"attrs": attrs, "configuration": json.loads(attrs["configuration_json"]),
            "result": json.loads(attrs["result_json"]), "tables": tables}
