"""ion-core command line.

    ion-core run config.yaml            run the scenario named in the configuration
    ion-core steady-state config.yaml   steady-state solve
    ion-core transient config.yaml      time-domain simulation (start-up / throttle / shutdown)
    ion-core sweep config.yaml          parametric sweeps, throttle curve, performance map
    ion-core validate                   engineering validation suite (exit status 1 on failure)
    ion-core report results.h5          engineering report from an exported result
    ion-core console                    Plotly engineering console (local server)
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd

from . import MODEL_VERSION, __version__
from .configuration import EngineConfig, OperatingPoint
from .reporting.export import export_result
from .reporting.report import build_report, build_report_from_hdf5
from .results import SimulationResult, result_from_state, result_from_transient
from .simulation.faults import FAULT_NAMES, Fault, fault_causal_report
from .simulation.lifetime import simulate_lifetime
from .simulation.scenarios import Scenario, full_cycle_scenario
from .simulation.solver import solve_steady_state
from .simulation.sweeps import (
    SWEEPABLE,
    engineering_curves,
    monte_carlo,
    performance_map,
    sweep,
    throttle_curve,
)
from .simulation.transient import run_transient
from .validation import run_validation

DEFAULT_SWEEPS = (
    {"variable": "beam_voltage", "rel_start": 0.55, "rel_stop": 1.35, "n": 25},
    {"variable": "mass_flow", "rel_start": 0.85, "rel_stop": 1.6, "n": 25},
    {"variable": "discharge_power", "rel_start": 0.6, "rel_stop": 1.15, "n": 25},
    {"variable": "grid_spacing", "rel_start": 0.7, "rel_stop": 1.6, "n": 25},
)


def _load(path: str | None) -> tuple[EngineConfig, dict[str, Any]]:
    if not path:
        return EngineConfig(), {}
    cfg = EngineConfig.from_yaml(path)
    return cfg, dict(cfg.scenario)


def _stem(res: SimulationResult, name: str) -> str:
    return f"{name}_{res.metadata['simulation_id'][:8]}"


def _emit(res: SimulationResult, outdir: Path, name: str, formats: list[str], report: bool) -> list[Path]:
    outdir.mkdir(parents=True, exist_ok=True)
    written: list[Path] = []
    stem = _stem(res, name)
    for fmt in formats:
        written += export_result(res, outdir / f"{stem}.{'h5' if fmt in ('h5', 'hdf5') else fmt}", fmt)
    if report:
        written.append(build_report(res, outdir / f"{stem}.report.html"))
    return written


def _print_state(res: SimulationResult) -> None:
    print(res.summary())
    st = res.state
    if st is not None:
        print(f"  limits: {st.limits.status}")
        for c in st.limits.checks:
            if c.status != "VALID":
                print(f"    {c.status:<8} {c.name}: {c.message}")


def _sweep_tables(cfg: EngineConfig, op: OperatingPoint, spec: dict[str, Any]) -> dict[str, pd.DataFrame]:
    tables: dict[str, pd.DataFrame] = {}
    sweeps = spec.get("sweeps") or list(DEFAULT_SWEEPS)
    nominal = {"beam_voltage": op.beam_voltage_v, "beam_current": op.beam_current_a, "mass_flow": op.mass_flow_kg_s,
               "discharge_power": None, "neutraliser_current": op.neutraliser_current_a,
               "grid_spacing": cfg.grids.extraction_gap_m, "grid_aperture": cfg.grids.aperture_diameter_m}
    for sw in sweeps:
        var = sw["variable"]
        if var not in SWEEPABLE:
            raise SystemExit(f"cannot sweep '{var}'; sweepable: {', '.join(sorted(SWEEPABLE))}")
        if "start" in sw:
            lo, hi = float(sw["start"]), float(sw["stop"])
        else:
            ref = nominal[var]
            if ref is None:
                ref = solve_steady_state(cfg, op).power_state.p_discharge_w
            ref = ref or 1.0
            lo, hi = sw["rel_start"] * ref, sw["rel_stop"] * ref
        tables[f"sweep_{var}"] = sweep(cfg, op, var, np.linspace(lo, hi, int(sw.get("n", 21))))
    return tables


def _map_table(cfg: EngineConfig, op: OperatingPoint, spec: dict[str, Any]) -> dict[str, pd.DataFrame]:
    m = spec.get("map", {})
    vb, ib = op.beam_voltage_v, op.beam_current_a or 1.0

    def axis(key: str, default: tuple[float, float, int]) -> np.ndarray:
        lo, hi, n = m.get(key) or default
        return np.linspace(float(lo), float(hi), int(n))

    ds = performance_map(cfg, op, beam_voltages=axis("beam_voltage", (0.55 * vb, 1.35 * vb, 12)),
                         beam_currents=axis("beam_current", (0.35 * ib, 1.35 * ib, 12)))
    return {"performance_map": ds.to_dataframe().reset_index()}


def cmd_steady(cfg: EngineConfig, spec: dict[str, Any], args: argparse.Namespace) -> SimulationResult:
    st = solve_steady_state(cfg)
    res = result_from_state(cfg, st, scenario={"type": "steady-state", **spec})
    _print_state(res)
    return res


def cmd_transient(cfg: EngineConfig, spec: dict[str, Any], args: argparse.Namespace) -> SimulationResult:
    sc = Scenario.from_dict(spec, cfg) if spec.get("events") else full_cycle_scenario(float(spec.get("hold_s", 900.0)))
    if spec.get("duration_s") and not spec.get("events"):
        sc.duration_s = float(spec["duration_s"])
    tr = run_transient(cfg, sc)
    res = result_from_transient(cfg, tr)
    print(res.summary())
    print("  state transitions:")
    for t in tr.transitions:
        print(f"    {t['t_s']:8.1f} s  {t['from']:<17} -> {t['to']}")
    print(f"  steps {len(tr.history)}; energy balance FAIL steps {tr.energy_balance_failures}; mass balance FAIL steps {tr.mass_balance_failures}")
    return res


def cmd_sweep(cfg: EngineConfig, spec: dict[str, Any], args: argparse.Namespace) -> SimulationResult:
    op = cfg.operating_point
    st = solve_steady_state(cfg, op)
    tables = _sweep_tables(cfg, op, spec)
    tables["throttle_curve"] = throttle_curve(cfg, op, n=int(spec.get("throttle_points", 25)))
    tables.update(_map_table(cfg, op, spec))
    res = result_from_state(cfg, st, scenario={"type": "sweep", **spec}, tables=tables)
    _print_state(res)
    for name, df in tables.items():
        n_bad = int((df["limit_status"] == "INVALID").sum()) if "limit_status" in df else 0
        print(f"  table {name}: {len(df)} points" + (f", {n_bad} INVALID (kept)" if n_bad else ""))
    return res


def cmd_montecarlo(cfg: EngineConfig, spec: dict[str, Any], args: argparse.Namespace) -> SimulationResult:
    mc = spec.get("monte_carlo", {})
    params = mc.get("parameters") or {"grids.interception_fraction_base": {"dist": "lognormal", "median": cfg.grids.interception_fraction_base, "sigma_log": 0.3},
                                      "chamber.primary_confinement": {"dist": "normal", "mean": cfg.chamber.primary_confinement, "sigma": 0.03}}
    seed = int(mc.get("seed", spec.get("random_seed", 0)))
    df, summ = monte_carlo(cfg, cfg.operating_point, params, n=int(mc.get("n", 200)), seed=seed)
    st = solve_steady_state(cfg)
    res = result_from_state(cfg, st, scenario={"type": "monte_carlo", **spec}, seed=seed, parameters=params,
                            tables={"monte_carlo_samples": df, "monte_carlo_summary": summ.reset_index(names="quantity")})
    _print_state(res)
    print(summ.loc[[q for q in ("thrust_n", "isp_s", "p_input_w", "grid_temperature_k") if q in summ.index],
                   ["mean", "std", "5%", "95%"]].to_string())
    print(f"  invalid fraction: {summ['invalid_fraction'].iloc[0]:.1%}")
    return res


def cmd_lifetime(cfg: EngineConfig, spec: dict[str, Any], args: argparse.Namespace) -> SimulationResult:
    lt = spec.get("lifetime", {})
    df = simulate_lifetime(cfg, hours=float(lt.get("hours", 5000.0)), steps=int(lt.get("steps", 25)),
                           thermal_cycles_per_100h=float(lt.get("thermal_cycles_per_100h", 0.5)))
    st = solve_steady_state(cfg)
    res = result_from_state(cfg, st, scenario={"type": "lifetime", **spec}, tables={"lifetime": df})
    _print_state(res)
    print(df[["operating_hours", "interception_fraction", "thrust_n", "grid_temperature_k", "limit_status"]].iloc[::max(len(df) // 6, 1)].to_string(index=False))
    for c in cfg.degradation.coefficients:
        print(f"  coefficient {c.name} = {c.value:g} {c.units}  [{c.source}]")
    return res


RUNNERS = {"steady": cmd_steady, "steady-state": cmd_steady, "transient": cmd_transient, "sweep": cmd_sweep,
           "monte_carlo": cmd_montecarlo, "lifetime": cmd_lifetime}


def _run(kind: str | None, args: argparse.Namespace) -> int:
    cfg, spec = _load(args.config)
    kind = kind or spec.get("type", "steady")
    if kind not in RUNNERS:
        raise SystemExit(f"unknown scenario type '{kind}' (use one of {', '.join(RUNNERS)})")
    res = RUNNERS[kind](cfg, spec, args)
    name = spec.get("name", kind.replace("-", "_"))
    formats = [f.strip() for f in (args.format or ",".join(spec.get("export", ["json", "h5"]))).split(",") if f.strip()]
    out = Path(args.out or spec.get("output_dir", "results"))
    files = _emit(res, out, name, formats, args.report or bool(spec.get("report", False)))
    for f in files:
        print(f"  wrote {f}")
    bad = res.validation_status != "PASS" or (res.state is not None and res.state.limits.status == "INVALID")
    return 1 if bad else 0


def cmd_validate(args: argparse.Namespace) -> int:
    rep = run_validation()
    w = max(len(c.name) for c in rep.checks)
    for c in rep.checks:
        print(f"  {'PASS' if c.passed else 'FAIL'}  {c.name:<{w}}  expected {c.expected:<13.6g} model {c.actual:<13.6g} rel.err {c.rel_error:.1e}  (tol {c.tolerance:.0e})")
    print(f"VALIDATION: {rep.status}  ({len(rep.checks) - rep.n_failed}/{len(rep.checks)} checks passed)")
    if args.json:
        Path(args.json).write_text(json.dumps(rep.to_dict(), indent=1))
    return 0 if rep.status == "PASS" else 1


def cmd_report(args: argparse.Namespace) -> int:
    p = build_report_from_hdf5(args.results, args.out)
    print(f"wrote {p}")
    return 0


def cmd_fault(args: argparse.Namespace) -> int:
    cfg, _ = _load(args.config)
    r = fault_causal_report(cfg, cfg.operating_point, Fault(args.fault, args.magnitude, channel=args.channel))
    print(f"FAULT {args.fault} (magnitude {args.magnitude})   {r['baseline_limit_status']} -> {r['faulted_limit_status']}")
    for c in r["chain"]:
        d = "" if c["delta_pct"] is None else f"{c['delta_pct']:+8.2f} %"
        print(f"  {c['quantity']:<30} {c['baseline']:>12.5g} -> {c['faulted']:<12.5g} {c['unit']:<8} {d}")
    for m in r["faulted_limit_messages"]:
        print(f"  {m}")
    return 0


def cmd_console(args: argparse.Namespace) -> int:
    from .console.server import serve
    cfg, _ = _load(args.config)
    serve(cfg, host=args.host, port=args.port, open_browser=not args.no_browser)
    return 0


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(prog="ion-core", description="ION-CORE gridded electrostatic ion engine simulator")
    ap.add_argument("--version", action="version", version=f"ion-core {__version__} ({MODEL_VERSION})")
    sub = ap.add_subparsers(dest="cmd", required=True)

    def runner(name: str, helptext: str) -> argparse.ArgumentParser:
        p = sub.add_parser(name, help=helptext)
        p.add_argument("config", nargs="?", help="YAML configuration (defaults to the built-in demonstration engine)")
        p.add_argument("-o", "--out", help="output directory (default: results/)")
        p.add_argument("-f", "--format", help="comma list of json,h5,csv,parquet")
        p.add_argument("--report", action="store_true", help="also write the HTML engineering report")
        return p

    runner("run", "run the scenario named in the configuration").set_defaults(func=lambda a: _run(None, a))
    runner("steady-state", "steady-state solve").set_defaults(func=lambda a: _run("steady", a))
    runner("transient", "time-domain simulation").set_defaults(func=lambda a: _run("transient", a))
    runner("sweep", "parametric sweeps and performance map").set_defaults(func=lambda a: _run("sweep", a))
    runner("montecarlo", "Monte Carlo over configuration parameters").set_defaults(func=lambda a: _run("monte_carlo", a))
    runner("lifetime", "long-duration degradation").set_defaults(func=lambda a: _run("lifetime", a))
    v = sub.add_parser("validate", help="run the engineering validation suite")
    v.add_argument("--json", help="write the validation report as JSON")
    v.set_defaults(func=cmd_validate)
    r = sub.add_parser("report", help="engineering report from an HDF5 result")
    r.add_argument("results")
    r.add_argument("-o", "--out")
    r.set_defaults(func=cmd_report)
    f = sub.add_parser("fault", help="inject a fault and print the causal chain")
    f.add_argument("config", nargs="?")
    f.add_argument("--fault", required=True, choices=FAULT_NAMES)
    f.add_argument("--magnitude", type=float, required=True)
    f.add_argument("--channel")
    f.set_defaults(func=cmd_fault)
    c = sub.add_parser("console", help="start the Plotly engineering console")
    c.add_argument("config", nargs="?")
    c.add_argument("--host", default="127.0.0.1")
    c.add_argument("--port", type=int, default=8050)
    c.add_argument("--no-browser", action="store_true")
    c.set_defaults(func=cmd_console)

    args = ap.parse_args(argv)
    return int(args.func(args))


if __name__ == "__main__":
    sys.exit(main())

__all__ = ["main", "engineering_curves"]
