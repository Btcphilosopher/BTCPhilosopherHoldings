"""Separate efficiencies (never collapsed into one number).

Exact decomposition of the ion-beam thrust efficiency (neutral cold gas excluded):

    F_ion^2 / (2 m_dot_total P_in) = eta_m * eta_div * eta_acc * eta_elec
      eta_m    = m_dot_ion / m_dot_total                  propellant utilisation
      eta_div  = <cos theta>^2                            divergence (thrust direction)
      eta_acc  = V_eff / V_beam                           acceleration (voltage delivery)
      eta_elec = I_beam V_beam / P_in                     electrical (beam share of input)
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class Efficiencies:
    propellant_utilisation: float  # beam ions / total engine propellant
    chamber_utilisation: float  # extracted ions / main-line propellant
    ionisation: float  # minimum ionisation power / discharge power
    ion_production_cost_ev_per_ion: float  # discharge loss: P_d / (I_beam / e)
    ionisation_probability: float  # per-neutral ionisation probability in the chamber
    extraction: float  # beam ions / generated ions
    ion_transparency: float
    grid_transmission: float  # 1 - interception
    acceleration: float
    divergence: float
    neutralisation: float
    ppu: float
    electrical: float
    thruster: float  # P_jet / P_ppu_output
    overall: float  # P_jet / P_input
    ion_thrust_overall: float  # ion-beam-only decomposition target
    decomposition_residual: float


def jet_power_w(thrust_n: float, m_dot_total_kg_s: float) -> float:
    """P_jet = F^2 / (2 m_dot) — kinetic power of the equivalent exhaust."""
    return 0.5 * thrust_n**2 / m_dot_total_kg_s if m_dot_total_kg_s > 0 else 0.0


def thrust_to_power(thrust_n: float, p_input_w: float) -> tuple[float, float]:
    """(N/kW, mN/kW)."""
    if p_input_w <= 0:
        return 0.0, 0.0
    n_kw = thrust_n / (p_input_w / 1000.0)
    return n_kw, n_kw * 1000.0
