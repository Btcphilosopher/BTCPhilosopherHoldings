"""Thrust from momentum flow.

    F_ideal = m_dot_ion * v_ion(ideal)            (axial, undiverged, nominal voltage)
    F_gross = m_dot_ion * v_ion(effective)         (undiverged, modelled voltage)
    F_axial = m_dot_ion * v_eff * <cos theta>      (beam divergence)
    divergence_loss = F_gross - F_axial
plus the small cold-gas momentum of neutral atoms leaving through the grids / neutraliser.
"""

from __future__ import annotations

import math
from dataclasses import dataclass

from ..constants import K_B


@dataclass(frozen=True)
class ThrustBreakdown:
    ideal_n: float
    gross_n: float
    axial_ion_n: float
    divergence_loss_n: float
    neutral_chamber_n: float
    neutraliser_gas_n: float
    total_n: float  # axial_ion + neutral contributions
    calibrated_n: float | None


def neutral_exit_thrust(mass_flow_kg_s: float, temperature_k: float, atomic_mass_kg: float) -> float:
    """Momentum flux of an effusing gas: m_dot * sqrt(pi k T / (2 m))."""
    if mass_flow_kg_s <= 0 or temperature_k <= 0:
        return 0.0
    return mass_flow_kg_s * math.sqrt(math.pi * K_B * temperature_k / (2.0 * atomic_mass_kg))


def thrust_breakdown(*, ion_mass_flow_kg_s: float, v_ideal: float, v_effective: float, gamma: float,
                     neutral_chamber_n: float, neutraliser_gas_n: float,
                     calibration_factor: float | None) -> ThrustBreakdown:
    ideal = ion_mass_flow_kg_s * v_ideal
    gross = ion_mass_flow_kg_s * v_effective
    axial = gross * gamma
    total = axial + neutral_chamber_n + neutraliser_gas_n
    return ThrustBreakdown(ideal, gross, axial, gross - axial, neutral_chamber_n, neutraliser_gas_n,
                           total, None if calibration_factor is None else total * calibration_factor)
