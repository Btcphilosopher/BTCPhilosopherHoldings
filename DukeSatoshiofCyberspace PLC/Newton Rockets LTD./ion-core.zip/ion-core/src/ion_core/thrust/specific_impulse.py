"""Specific impulse. The mass flow used is always named."""

from __future__ import annotations

from dataclasses import dataclass

from ..constants import G0


def isp_s(thrust_n: float, mass_flow_kg_s: float) -> float:
    """Isp = F / (m_dot g0)."""
    return thrust_n / (mass_flow_kg_s * G0) if mass_flow_kg_s > 0 else 0.0


@dataclass(frozen=True)
class SpecificImpulse:
    isp_total_s: float  # F / (m_dot_total_engine g0)   <- the headline Isp
    isp_main_s: float  # F / (m_dot_main_line g0)
    isp_ion_s: float  # F_ion_axial / (m_dot_ion_beam g0)
    effective_exhaust_velocity_m_s: float  # F / m_dot_total


def specific_impulse(*, thrust_n: float, axial_ion_thrust_n: float, m_dot_total: float,
                     m_dot_main: float, m_dot_ion: float) -> SpecificImpulse:
    return SpecificImpulse(isp_s(thrust_n, m_dot_total), isp_s(thrust_n, m_dot_main),
                           isp_s(axial_ion_thrust_n, m_dot_ion),
                           thrust_n / m_dot_total if m_dot_total > 0 else 0.0)
