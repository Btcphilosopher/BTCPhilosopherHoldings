"""Unit handling.

Internally ION-CORE is SI only. Pint is used at the boundaries (configuration input,
reporting, dimensional-consistency validation) so units are never mixed silently:
a configuration value may be written as ``"1.1 kV"`` and is converted to volts, while
a value with the wrong dimensionality (``"3 m"`` for a voltage) is rejected.
"""

from __future__ import annotations

from typing import Annotated, Any

import pint
from pydantic import BeforeValidator

ureg = pint.UnitRegistry()
Q_ = ureg.Quantity


def to_si(value: Any, unit: str) -> float:
    """Convert ``value`` (number = already in ``unit``; str = parsed with Pint) to ``unit``."""
    if isinstance(value, bool):
        raise TypeError("boolean is not a physical quantity")
    if isinstance(value, str):
        q = Q_(value)
        expected = Q_(1.0, unit)
        if q.dimensionless and not expected.dimensionless:
            return float(q.magnitude)  # bare number: interpreted in the field's SI unit
        if q.dimensionality != expected.dimensionality:
            raise ValueError(f"'{value}' has dimensionality {q.dimensionality}, expected {unit}")
        return float(q.to(unit).magnitude)
    return float(value)


def _bv(unit: str) -> BeforeValidator:
    return BeforeValidator(lambda v: to_si(v, unit))


Volt = Annotated[float, _bv("V")]
Amp = Annotated[float, _bv("A")]
Metre = Annotated[float, _bv("m")]
SqMetre = Annotated[float, _bv("m**2")]
CuMetre = Annotated[float, _bv("m**3")]
Kelvin = Annotated[float, _bv("K")]
Watt = Annotated[float, _bv("W")]
KgPerS = Annotated[float, _bv("kg/s")]
Second = Annotated[float, _bv("s")]
Kilogram = Annotated[float, _bv("kg")]
JPerK = Annotated[float, _bv("J/K")]
WPerK = Annotated[float, _bv("W/K")]
Radian = Annotated[float, _bv("rad")]

# Unit labels used by exporters / reports, keyed by column-name suffix.
SUFFIX_UNITS: dict[str, str] = {
    "_kg_s": "kg/s", "_m3": "1/m^3", "_m2": "m^2", "_w_k": "W/K", "_j_k": "J/K",
    "_v_m": "V/m", "_a_m2": "A/m^2", "_m_s": "m/s", "_ev": "eV", "_mn_kw": "mN/kW",
    "_n_kw": "N/kW", "_a_h": "A*h", "_kg": "kg", "_rad": "rad", "_v": "V", "_a": "A",
    "_w": "W", "_k": "K", "_n": "N", "_m": "m", "_s": "s", "_j": "J", "_h": "h",
}


def unit_of(name: str) -> str:
    """Best-effort unit label from a column name's suffix ('' = dimensionless / unknown)."""
    for suffix, unit in SUFFIX_UNITS.items():
        if name.endswith(suffix):
            return unit
    return ""
