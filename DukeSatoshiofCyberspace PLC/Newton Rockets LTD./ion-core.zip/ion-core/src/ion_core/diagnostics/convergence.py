"""Convergence records for iterative solves."""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass
class ConvergenceRecord:
    converged: bool = False
    iterations: int = 0
    final_residual: float = float("nan")
    history: list[float] = field(default_factory=list)
    absolute_tolerance: float = 0.0
    relative_tolerance: float = 0.0
    note: str = ""

    def to_dict(self) -> dict:
        return {"converged": self.converged, "iterations": self.iterations,
                "final_residual": self.final_residual, "history": self.history,
                "absolute_tolerance": self.absolute_tolerance,
                "relative_tolerance": self.relative_tolerance, "note": self.note}
