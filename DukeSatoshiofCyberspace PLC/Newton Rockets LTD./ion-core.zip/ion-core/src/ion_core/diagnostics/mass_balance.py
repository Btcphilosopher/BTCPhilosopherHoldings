"""Propellant mass balance.

    m_dot_in = m_dot_ion + m_dot_neutral + m_dot_loss (+ d M_stored / dt in transients)

Terms: beam ions (m_i), electrons restored on neutralisation, intercepted ions returned as
neutral atoms, neutral atoms effusing from the chamber, neutraliser gas, explicit leak.
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class MassBalance:
    m_dot_in_kg_s: float
    m_dot_ion_beam_kg_s: float
    m_dot_neutralising_electrons_kg_s: float
    m_dot_ion_intercepted_kg_s: float
    m_dot_neutral_chamber_kg_s: float
    m_dot_neutraliser_kg_s: float
    m_dot_leak_kg_s: float
    m_dot_ion_kg_s: float  # beam ions incl. restored electron mass + intercepted
    m_dot_neutral_kg_s: float
    m_dot_loss_kg_s: float
    m_dot_stored_kg_s: float  # modelled storage (0: neutral gas is quasi-static)
    m_dot_storage_neglected_kg_s: float  # d(neutral inventory)/dt NOT in the balance (information)
    m_dot_accounted_kg_s: float
    residual_kg_s: float
    relative_residual: float
    tolerance: float
    status: str

    @property
    def message(self) -> str:
        return f"MASS BALANCE: {self.status} (residual {self.residual_kg_s:+.3e} kg/s, " \
               f"{self.relative_residual:+.2e} of inflow, tol {self.tolerance:.1e})"


def mass_balance(*, m_in: float, m_ion_beam: float, m_electrons: float, m_ion_intercepted: float,
                 m_neutral_chamber: float, m_neutraliser: float, m_leak: float, m_stored: float,
                 tolerance: float, storage_neglected: float = 0.0) -> MassBalance:
    acc = m_ion_beam + m_electrons + m_ion_intercepted + m_neutral_chamber + m_neutraliser + m_leak + m_stored
    res = m_in - acc
    rel = res / m_in if m_in > 0 else (0.0 if abs(res) < 1e-30 else float("inf"))
    return MassBalance(m_in, m_ion_beam, m_electrons, m_ion_intercepted, m_neutral_chamber, m_neutraliser,
                       m_leak, m_ion_beam + m_electrons, m_neutral_chamber + m_neutraliser + m_ion_intercepted,
                       m_leak, m_stored, storage_neglected, acc, res, rel, tolerance, "PASS" if abs(rel) <= tolerance else "FAIL")
