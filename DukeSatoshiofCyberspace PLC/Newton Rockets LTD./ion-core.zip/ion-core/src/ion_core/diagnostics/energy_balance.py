"""Engine energy balance, evaluated at every step.

    P_input = P_beam + P_ionisation + P_grid_loss + P_neutraliser + P_thermal + P_other
              (+ P_stored in transients)

Definitions (all independent of P_input, which comes from the PPU chain):
  P_beam        far-field ion kinetic power I_b V_eff
  P_ionisation  ionisation energy carried off by beam ions (N_b E_iz), recombines in the plume
  P_grid_loss   heat generated on the grid node (interception, screen web, recombination)
  P_neutraliser neutraliser electrical power (all dissipated as heat on its node)
  P_thermal     heat generated on chamber + PPU + structure nodes, plus escaped plasma radiation
  P_other       plume coupling power I_b V_c (ions climbing the plume potential)
  P_stored      discharge energy-inventory change (transient only; zero in steady state)
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class EnergyBalance:
    p_input_w: float
    p_beam_w: float
    p_ionisation_w: float
    p_grid_loss_w: float
    p_neutraliser_w: float
    p_thermal_w: float
    p_other_w: float
    p_stored_w: float
    p_accounted_w: float
    residual_w: float
    relative_residual: float
    tolerance: float
    status: str  # "PASS" | "FAIL"

    @property
    def message(self) -> str:
        return f"ENERGY BALANCE: {self.status} (residual {self.residual_w:+.3e} W, " \
               f"{self.relative_residual:+.2e} of input, tol {self.tolerance:.1e})"


def energy_balance(*, p_input_w: float, p_beam_w: float, p_ionisation_w: float, p_grid_loss_w: float,
                   p_neutraliser_w: float, p_thermal_w: float, p_other_w: float, p_stored_w: float,
                   tolerance: float) -> EnergyBalance:
    acc = p_beam_w + p_ionisation_w + p_grid_loss_w + p_neutraliser_w + p_thermal_w + p_other_w + p_stored_w
    res = p_input_w - acc
    rel = res / p_input_w if p_input_w > 0 else (0.0 if abs(res) < 1e-12 else float("inf"))
    status = "PASS" if abs(rel) <= tolerance else "FAIL"
    return EnergyBalance(p_input_w, p_beam_w, p_ionisation_w, p_grid_loss_w, p_neutraliser_w,
                         p_thermal_w, p_other_w, p_stored_w, acc, res, rel, tolerance, status)
