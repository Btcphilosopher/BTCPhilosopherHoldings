"""Engineering validation: model outputs vs independent analytic / numerical references.

Each check compares a value produced by the simulator with a value computed by a separate
route (closed form with Pint units, numerical quadrature, finite-difference residual of
the governing ODE, ...). ``run_validation`` is used by ``ion-core validate``, the
console and the test-suite.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from functools import lru_cache
from typing import Any

import numpy as np
import pint
from scipy.integrate import quad

from . import constants as k
from .configuration import EngineConfig, OperatingPoint
from .diagnostics.energy_balance import energy_balance
from .plasma.ionisation import ionisation_cross_section, ionisation_rate_coefficient
from .propellant.species import ARGON, KRYPTON, XENON
from .simulation.solver import solve_steady_state
from .thermal.model import ThermalNetwork
from .units import Q_, ureg

REL = 1e-9


@dataclass
class ValidationCheck:
    name: str
    quantity: str
    expected: float
    actual: float
    unit: str
    rel_error: float
    tolerance: float
    passed: bool
    method: str


@dataclass
class ValidationReport:
    checks: list[ValidationCheck] = field(default_factory=list)

    @property
    def status(self) -> str:
        return "PASS" if self.checks and all(c.passed for c in self.checks) else "FAIL"

    @property
    def n_failed(self) -> int:
        return sum(not c.passed for c in self.checks)

    def to_dict(self) -> dict:
        return {"status": self.status, "n_checks": len(self.checks), "n_failed": self.n_failed,
                "checks": [c.__dict__ for c in self.checks]}


def _chk(rep: ValidationReport, name: str, quantity: str, expected: float, actual: float, unit: str,
         tol: float, method: str) -> None:
    denom = abs(expected) if expected != 0 else 1.0
    err = abs(actual - expected) / denom
    rep.checks.append(ValidationCheck(name, quantity, float(expected), float(actual), unit, float(err), tol,
                                      bool(err <= tol), method))


def _dimension(rep: ValidationReport, name: str, expr: pint.Quantity, target: str, actual_si: float,
               tol: float = 1e-9) -> None:
    """Pint raises DimensionalityError if the expression is not of the target dimension."""
    try:
        val = expr.to(target).magnitude
        _chk(rep, f"dimensional consistency: {name}", target, float(val), actual_si, target, tol,
             "Pint dimensional analysis")
    except pint.DimensionalityError:
        rep.checks.append(ValidationCheck(f"dimensional consistency: {name}", target, float("nan"), actual_si,
                                          target, float("inf"), tol, False, "Pint dimensional analysis"))


@lru_cache(maxsize=1)
def _reference_state():
    cfg = EngineConfig()
    return cfg, solve_steady_state(cfg)


def run_validation() -> ValidationReport:  # noqa: C901 - one flat list of checks
    rep = ValidationReport()
    cfg, st = _reference_state()
    sp = cfg.species
    b, pe, pf, pw = st.beam_state, st.performance_state, st.propellant_flow, st.power_state
    v_b, i_b = b.beam_voltage_v, b.beam_current_a

    # --- ion kinetic energy and velocity: E = qV, v = sqrt(2E/m) ---------------------------------------
    e_ion: Any = Q_(k.E_CHARGE, "C") * Q_(v_b, "V")
    _chk(rep, "ion kinetic energy", "E = qV", e_ion.to("J").magnitude, b.ion_energy_ideal_j, "J", REL, "closed form (Pint)")
    v_ref: Any = (2 * e_ion / Q_(sp.ion_mass, "kg")) ** 0.5
    _dimension(rep, "ion velocity sqrt(2E/m)", v_ref, "m/s", b.ion_velocity_ideal_m_s)
    _chk(rep, "ion velocity (ideal)", "v = sqrt(2qV/m)", v_ref.to("m/s").magnitude, b.ion_velocity_ideal_m_s, "m/s", REL, "closed form (Pint)")
    veff = math.sqrt(2 * k.E_CHARGE * b.effective_voltage_v / sp.ion_mass)
    _chk(rep, "ion velocity (modelled effective)", "v_eff", veff, b.ion_velocity_effective_m_s, "m/s", REL, "closed form")
    # independent constants path: astropy units/constants, atomic mass minus one electron
    from astropy import constants as ac
    from astropy import units as au
    m_xe = (131.293 * au.u).to(au.kg) - ac.m_e
    v_astropy = ((2 * ac.e.si * (1000.0 * au.V) / m_xe) ** 0.5).to(au.m / au.s).value
    _chk(rep, "xenon ion speed at 1 kV", "v(Xe+, 1 kV)", float(v_astropy),
         math.sqrt(2 * k.E_CHARGE * 1000.0 / XENON.ion_mass), "m/s", 1e-12, "astropy.units independent route")

    # --- mass flow, beam current, beam power ------------------------------------------------------------
    n_dot = i_b / k.E_CHARGE
    _chk(rep, "beam current", "I = q N_dot", i_b, k.E_CHARGE * b.ion_rate_s, "A", REL, "closed form")
    _chk(rep, "ion mass flow", "m_dot_ion = N_dot m_i", n_dot * sp.ion_mass, pf.ion_flow_beam_kg_s, "kg/s", REL, "closed form")
    _chk(rep, "beam power", "P = V I", v_b * i_b, b.beam_power_w, "W", REL, "closed form")
    _chk(rep, "kinetic power", "P_kin = (1/2) m_dot v_eff^2",
         0.5 * pf.ion_flow_beam_kg_s * b.ion_velocity_effective_m_s**2, b.beam_kinetic_power_w, "W", 1e-9, "closed form")

    # --- space-charge limit: closed form AND Poisson residual of phi = V (x/d)^(4/3) -----------------------
    vv, d = 1280.0, 1.354e-3
    j_cl = (4 / 9) * k.EPS0 * math.sqrt(2 * k.E_CHARGE / sp.ion_mass) * vv**1.5 / d**2
    from .extraction.space_charge import child_langmuir_current_density as cl
    _chk(rep, "Child-Langmuir current density", "J_CL", j_cl, cl(vv, d, sp.ion_mass, k.E_CHARGE), "A/m^2", REL, "closed form")
    cl_q: Any = (Q_(4, "") / 9) * Q_(k.EPS0, "F/m") * (2 * Q_(k.E_CHARGE, "C") / Q_(sp.ion_mass, "kg")) ** 0.5 \
        * Q_(vv, "V") ** 1.5 / Q_(d, "m") ** 2
    _dimension(rep, "Child-Langmuir J", cl_q, "A/m^2", cl(vv, d, sp.ion_mass, k.E_CHARGE))
    x = np.linspace(0.2, 0.95, 7) * d
    h = 1e-3 * d  # large enough that second-difference roundoff is negligible
    phi = lambda s: vv * (s / d) ** (4 / 3)  # noqa: E731
    lap = (phi(x + h) - 2 * phi(x) + phi(x - h)) / h**2
    rho_over_eps = (cl(vv, d, sp.ion_mass, k.E_CHARGE) / k.EPS0) / np.sqrt(2 * k.E_CHARGE * phi(x) / sp.ion_mass)
    _chk(rep, "Child-Langmuir solves Poisson", "d2phi/dx2 = rho/eps0", float(np.mean(rho_over_eps)),
         float(np.mean(lap)), "V/m^2", 1e-4, "finite-difference residual of the governing ODE")
    i1, i2 = (cl(v, d, sp.ion_mass, k.E_CHARGE) for v in (500.0, 2000.0))
    _chk(rep, "space-charge V^(3/2) scaling", "J(4V)/J(V)", 8.0, i2 / i1, "-", 1e-12, "scaling law")

    # --- thrust from momentum flow; divergence integral -------------------------------------------------------------
    flat = cfg.with_updates({"grids.divergence_sigma_base_rad": 1e-12, "grids.divergence_perveance_gain": 0.0,
                             "propellant.species": "xenon"})
    s0 = solve_steady_state(flat)
    _chk(rep, "thrust (no divergence)", "F = m_dot v", s0.propellant_flow.ion_flow_beam_kg_s * s0.beam_state.ion_velocity_effective_m_s,
         s0.performance_state.thrust_axial_ion_n, "N", 1e-9, "momentum flow")
    _chk(rep, "axial thrust", "F = m_dot v <cos theta>", pf.ion_flow_beam_kg_s * b.ion_velocity_effective_m_s * b.thrust_factor_gamma,
         pe.thrust_axial_ion_n, "N", REL, "momentum flow")
    sig = b.divergence_sigma_rad
    pdf = lambda t: (t / sig**2) * math.exp(-t * t / (2 * sig**2))  # noqa: E731
    top = min(math.pi / 2, 9 * sig)
    norm = quad(pdf, 0, top)[0]
    gam = quad(lambda t: math.cos(t) * pdf(t), 0, top)[0] / norm
    _chk(rep, "divergence thrust factor", "<cos theta> (Rayleigh)", gam, b.thrust_factor_gamma, "-", 1e-9, "scipy.integrate.quad")
    F_q: Any = Q_(pf.ion_flow_beam_kg_s, "kg/s") * Q_(b.ion_velocity_effective_m_s, "m/s")
    _dimension(rep, "thrust m_dot v", F_q, "N", pf.ion_flow_beam_kg_s * b.ion_velocity_effective_m_s)

    # --- specific impulse -----------------------------------------------------------------------------------------------
    _chk(rep, "specific impulse", "Isp = F/(m_dot g0)", pe.thrust_n / (pf.mass_flow_total_kg_s * k.G0), pe.isp_s, "s", REL, "closed form")
    isp_q: Any = Q_(pe.thrust_n, "N") / (Q_(pf.mass_flow_total_kg_s, "kg/s") * Q_(k.G0, "m/s**2"))
    _dimension(rep, "Isp F/(m_dot g0)", isp_q, "s", pe.isp_s)
    _chk(rep, "thrust-to-power", "T/P in mN/kW", pe.thrust_n / pw.p_input_w * 1e6, pe.thrust_to_power_mn_kw, "mN/kW", REL, "closed form")

    # --- thermal radiation and node balance -----------------------------------------------------------------------------
    eps, area, t, tenv = 0.7, 0.8, 350.0, 300.0
    q_ref: Any = (Q_(eps, "") * ureg.stefan_boltzmann_constant * Q_(area, "m**2") * (Q_(t, "K") ** 4 - Q_(tenv, "K") ** 4)).to("W")
    from .thermal.radiation import radiated_power
    _chk(rep, "radiative heat rejection", "eps sigma A (T^4 - Tenv^4)", q_ref.magnitude, radiated_power(eps, area, t, tenv), "W", 1e-6,
         "Pint (CODATA sigma from the registry)")
    iso = cfg.thermal.model_copy(update={"conductances_w_k": {}})
    net = ThermalNetwork(iso)
    q_in = np.array([100.0, 50.0, 10.0, 30.0, 5.0])
    t_ss, ok = net.steady_state(q_in)
    expect_t = (q_in / (net.eps * k.SIGMA_SB * net.area) + tenv**4) ** 0.25
    _chk(rep, "isolated-node radiative equilibrium", "T = (Q/(eps sigma A) + Tenv^4)^(1/4)", float(np.max(expect_t)), float(np.max(t_ss)),
         "K", 1e-9, "analytic single-node solution")
    th = st.thermal_state
    _chk(rep, "thermal energy balance", "sum Q_gen = sum Q_rad", th.total_generated_w, th.total_radiated_w, "W", 1e-6, "steady-state network")

    # --- mass and power balances over a grid of operating points --------------------------------------------------------------
    worst_e = worst_m = 0.0
    for v in (700.0, 1100.0, 1500.0):
        for i in (0.8, 1.76, 2.1):
            op = OperatingPoint(mass_flow_kg_s=3.0e-6 * i / 1.76, beam_voltage_v=v, beam_current_a=i)
            s = solve_steady_state(cfg, op)
            worst_e = max(worst_e, abs(s.energy_balance.relative_residual))  # type: ignore[union-attr]
            worst_m = max(worst_m, abs(s.mass_balance.relative_residual))  # type: ignore[union-attr]
    _chk(rep, "power balance (9 operating points)", "max |P_in - P_accounted| / P_in", 0.0, worst_e, "-", cfg.solver.energy_balance_tolerance,
         "independent ledger vs PPU input")
    _chk(rep, "mass balance (9 operating points)", "max |m_in - m_accounted| / m_in", 0.0, worst_m, "-", cfg.solver.mass_balance_tolerance,
         "independent ledger vs flow input")
    # the balance check must actually be able to fail
    probe = energy_balance(p_input_w=1000.0, p_beam_w=500.0, p_ionisation_w=0.0, p_grid_loss_w=0.0, p_neutraliser_w=0.0,
                           p_thermal_w=480.0, p_other_w=0.0, p_stored_w=0.0, tolerance=1e-3)
    _chk(rep, "balance check can fail (negative control)", "2 % missing power flagged", 1.0, 1.0 if probe.status == "FAIL" else 0.0, "-", 0.0,
         "deliberately unbalanced ledger")

    # --- ionisation kinetics ----------------------------------------------------------------------------------------------------------
    te = 4.0
    f = lambda en: ionisation_cross_section(en, XENON)[0] * math.sqrt(2 * en * k.E_CHARGE / k.M_ELECTRON) \
        * 2 * math.sqrt(en / math.pi) * te**-1.5 * math.exp(-en / te)  # noqa: E731
    ref = quad(f, XENON.ionisation_energy_ev, XENON.ionisation_energy_ev + 60 * te, limit=500, epsabs=0, epsrel=1e-12)[0]
    _chk(rep, "ionisation rate coefficient", "<sigma v> Maxwellian average", ref, ionisation_rate_coefficient(te, XENON), "m^3/s", 1e-5,
         "scipy.integrate.quad of the Lotz cross-section")
    pl = st.plasma_state
    _chk(rep, "ion particle balance", "production = Bohm loss", pl.ion_production_rate_s,
         pl.ionisation_rate_density_m3_s * cfg.chamber.volume_m3, "1/s", 1e-9, "independent ionisation-rate evaluation")
    _chk(rep, "discharge power budget closes", "sum of channels = P_d", pl.discharge_budget["p_discharge_w"],
         pl.discharge_budget["accounted_w"], "W", 1e-9, "channel sum")
    ef = pe.efficiencies
    _chk(rep, "efficiency decomposition", "eta = eta_m eta_div eta_acc eta_elec", ef["ion_thrust_overall"],
         ef["propellant_utilisation"] * ef["divergence"] * ef["acceleration"] * ef["electrical"], "-", 1e-9, "exact identity")

    # --- species independence: same physics, different propellant ----------------------------------------------------------------------------
    for spc in (KRYPTON, ARGON):
        s2 = solve_steady_state(cfg.with_updates({"propellant.species": spc.species_name}))
        v_expected = math.sqrt(2 * k.E_CHARGE * s2.beam_state.beam_voltage_v / spc.ion_mass)
        _chk(rep, f"species swap ({spc.species_name}) ion speed", "sqrt(2qV/m_i)", v_expected, s2.beam_state.ion_velocity_ideal_m_s, "m/s", REL,
             "closed form with the selected species mass")
    return rep


__all__ = ["REL", "ValidationCheck", "ValidationReport", "run_validation"]
