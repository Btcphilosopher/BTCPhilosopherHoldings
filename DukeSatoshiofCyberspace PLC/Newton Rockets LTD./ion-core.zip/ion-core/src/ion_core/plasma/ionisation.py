"""Ionisation and excitation kinetics from first principles (reduced-order).

Ionisation cross-section: Lotz formula, sigma(E) = a * xi * ln(E/P) / (E * P) for E >= P
(a = 4.5e-14 cm^2 eV^2, xi electrons in the shell, P its binding energy in eV).
Rate coefficient: Maxwellian average <sigma v>(T_e) by composite Simpson quadrature (Numba).
Excitation: constant lumped cross-section above threshold, which has the closed-form
Maxwellian average sigma0 * v_bar * (1 + E_th/T_e) * exp(-E_th/T_e).
"""

from __future__ import annotations

from functools import lru_cache

import numpy as np
from numba import njit

from ..constants import E_CHARGE, M_ELECTRON
from ..propellant.species import PropellantSpecies

_NPTS = 801  # odd: composite Simpson


@njit(cache=True)
def _lotz_rate_nb(te: float, xi: np.ndarray, pe: np.ndarray, a_cm2: float, e: float, me: float) -> float:
    """<sigma v> = int sigma(E) v(E) f(E) dE over [P, P + 60 T_e] by composite Simpson's rule."""
    total = 0.0
    span = 60.0 * te
    dx = span / (_NPTS - 1)
    for k in range(xi.shape[0]):
        p = pe[k]
        s = 0.0
        for i in range(_NPTS):
            en = p + i * dx
            if i == 0:
                sigma = 0.0  # ln(E/P) = 0 at threshold
            else:
                sigma = a_cm2 * 1.0e-4 * xi[k] * np.log(en / p) / (en * p)  # m^2
            v = np.sqrt(2.0 * en * e / me)
            f = 2.0 * np.sqrt(en / np.pi) * te ** -1.5 * np.exp(-en / te)  # 1/eV
            w = 1.0 if (i == 0 or i == _NPTS - 1) else (4.0 if i % 2 == 1 else 2.0)
            s += w * sigma * v * f
        total += s * dx / 3.0
    return total


@lru_cache(maxsize=32)
def _shell_arrays(species: PropellantSpecies) -> tuple[np.ndarray, np.ndarray]:
    xi = np.array([n for n, _ in species.lotz_shells], dtype=np.float64)
    pe = np.array([p for _, p in species.lotz_shells], dtype=np.float64)
    return xi, pe


def ionisation_cross_section(energy_ev: float | np.ndarray, species: PropellantSpecies) -> np.ndarray:
    """Lotz electron-impact ionisation cross-section, m^2."""
    en = np.atleast_1d(np.asarray(energy_ev, dtype=float))
    out = np.zeros_like(en)
    for xi, p in species.lotz_shells:
        m = en > p
        out[m] += species.lotz_a_cm2_ev2 * 1e-4 * xi * np.log(en[m] / p) / (en[m] * p)
    return out


def ionisation_rate_coefficient(te_ev: float, species: PropellantSpecies) -> float:
    """Maxwellian-averaged ionisation rate coefficient <sigma_iz v>, m^3/s."""
    if te_ev <= 0.0:
        return 0.0
    xi, pe = _shell_arrays(species)
    return float(_lotz_rate_nb(float(te_ev), xi, pe, species.lotz_a_cm2_ev2, E_CHARGE, M_ELECTRON))


def excitation_rate_coefficient(te_ev: float, species: PropellantSpecies) -> float:
    """Maxwellian-averaged lumped excitation rate coefficient, m^3/s."""
    if te_ev <= 0.0:
        return 0.0
    eth = species.excitation_threshold_ev
    vbar = np.sqrt(8.0 * te_ev * E_CHARGE / (np.pi * M_ELECTRON))
    return float(species.excitation_cross_section_m2 * vbar * (1.0 + eth / te_ev) * np.exp(-eth / te_ev))


def ionisation_frequency(n_neutral: float, te_ev: float, species: PropellantSpecies) -> float:
    """Ionisation events per electron per second, nu_iz = n_n <sigma v>."""
    return n_neutral * ionisation_rate_coefficient(te_ev, species)


def ionisation_rate_density(n_e: float, n_neutral: float, te_ev: float,
                            species: PropellantSpecies) -> float:
    """Ion production rate per unit volume, m^-3 s^-1 = n_e n_n <sigma v>."""
    return n_e * ionisation_frequency(n_neutral, te_ev, species)


def ionisation_probability(nu_iz: float, nu_exit: float) -> float:
    """Probability that a neutral in the chamber is ionised before it effuses out."""
    tot = nu_iz + nu_exit
    return nu_iz / tot if tot > 0 else 0.0
