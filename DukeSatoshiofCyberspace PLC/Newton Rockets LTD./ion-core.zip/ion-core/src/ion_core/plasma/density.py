"""Densities, quasi-neutrality and neutral-gas effusion."""

from __future__ import annotations

import math

from ..constants import K_B


def ion_density(n_e: float, charge_state: int = 1) -> float:
    """Quasi-neutrality n_e = sum(Z_i n_i); for a single species n_i = n_e / Z.

    APPROXIMATION: ignores negative ions and the (tiny) sheath/presheath charge separation.
    """
    return n_e / charge_state


def neutral_mean_speed(temperature_k: float, atomic_mass: float) -> float:
    """Mean thermal speed sqrt(8 k T / (pi m)), m/s."""
    return math.sqrt(8.0 * K_B * temperature_k / (math.pi * atomic_mass))


def neutral_axial_exit_speed(temperature_k: float, atomic_mass: float) -> float:
    """Mean axial speed of a flux-weighted effusing gas, sqrt(pi k T / (2 m)), m/s."""
    return math.sqrt(math.pi * K_B * temperature_k / (2.0 * atomic_mass))


def neutral_effusion_rate(n_n: float, v_mean: float, area_eff: float) -> float:
    """Neutral atoms leaving through an effective area, (1/4) n v_bar A, atoms/s."""
    return 0.25 * n_n * v_mean * area_eff


def neutral_density_from_exit_rate(rate: float, v_mean: float, area_eff: float) -> float:
    """Invert :func:`neutral_effusion_rate` for the chamber neutral density."""
    return 4.0 * rate / (v_mean * area_eff) if area_eff * v_mean > 0 else 0.0


def sheath_edge_density(n_bulk: float, edge_ratio: float) -> float:
    return edge_ratio * n_bulk
