"""Electron population helpers (Maxwellian bulk, temperature in eV)."""

from __future__ import annotations

import math

from ..constants import E_CHARGE, M_ELECTRON


def mean_speed(te_ev: float) -> float:
    """Mean electron speed sqrt(8 e T_e / (pi m_e)), m/s."""
    return math.sqrt(8.0 * te_ev * E_CHARGE / (math.pi * M_ELECTRON)) if te_ev > 0 else 0.0


def mean_energy_ev(te_ev: float) -> float:
    """Mean kinetic energy of a Maxwellian, 3/2 T_e."""
    return 1.5 * te_ev


def wall_loss_energy_ev(te_ev: float) -> float:
    """Mean kinetic energy carried off per electron lost across a sheath: 2 T_e."""
    return 2.0 * te_ev
