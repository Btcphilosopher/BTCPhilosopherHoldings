"""Ion transport helpers: Bohm speed and floating-wall sheath potential."""

from __future__ import annotations

import math

from ..constants import E_CHARGE, M_ELECTRON


def bohm_velocity(te_ev: float, ion_mass: float, charge_state: int = 1) -> float:
    """Bohm speed u_B = sqrt(Z e T_e / m_i), m/s."""
    return math.sqrt(charge_state * te_ev * E_CHARGE / ion_mass) if te_ev > 0 else 0.0


def floating_potential_v(te_ev: float, ion_mass: float) -> float:
    """Floating-wall sheath drop (T_e/2) ln(m_i / (2 pi m_e)), volts (Te in eV)."""
    return 0.5 * te_ev * math.log(ion_mass / (2.0 * math.pi * M_ELECTRON))


def ion_wall_energy_ev(te_ev: float, ion_mass: float) -> float:
    """Energy per ion arriving at a floating wall: presheath T_e/2 plus sheath drop."""
    return 0.5 * te_ev + floating_potential_v(te_ev, ion_mass)
