"""Reduced-order global (0-D) discharge-chamber model.

Ion particle balance (volume ionisation = Bohm-flux loss to all surfaces):

    n_e n_n K_iz(T_e) V = h n_e u_B(T_e) (A_wall + A_screen)

which fixes T_e from the neutral density and geometry alone (Goebel & Katz, ch. 5 global
model). Energy balance (see :mod:`ion_core.plasma.losses`) then fixes the ion generation
rate N_g from the absorbed discharge power and hence n_e. APPROXIMATIONS: Maxwellian bulk
electrons only (primary electrons enter through the ``primary_confinement`` coefficient),
uniform plasma with edge/bulk ratio h, T_e held at the geometric ion-balance value even
when extraction is below the Bohm supply (surplus ions are assumed lost to walls/web).
"""

from __future__ import annotations

from dataclasses import dataclass

from scipy.optimize import brentq

from ..configuration import ChamberConfig
from ..propellant.species import PropellantSpecies
from .ionisation import excitation_rate_coefficient, ionisation_rate_coefficient
from .ions import bohm_velocity, floating_potential_v


@dataclass(frozen=True)
class PlasmaSolution:
    sustained: bool
    te_ev: float
    ti_ev: float
    n_e: float  # bulk electron density, m^-3
    n_i: float  # bulk ion density, m^-3 (= n_e / Z)
    n_edge: float  # sheath-edge density, m^-3
    n_neutral: float
    u_bohm: float
    k_iz: float
    k_exc: float
    exc_ratio: float  # K_exc / K_iz
    nu_iz: float  # ionisation frequency per electron, 1/s
    ionisation_rate_density: float  # m^-3 s^-1
    ion_generation_rate: float  # ions/s (N_g)
    ion_extracted_rate: float  # ions/s through screen apertures (N_x)
    ion_wall_rate: float  # ions/s lost to walls + screen web
    ion_loss_area_m2: float
    extraction_fraction_geometric: float
    extraction_capacity_rate: float  # max N_x the plasma can supply at the given power (nan if n/a)
    e_generation_ev: float  # energy per generated ion (ionisation + excitation)
    e_wall_ev: float  # energy per wall-lost ion/electron pair
    e_extraction_ev: float  # energy per extracted ion's balancing electron + presheath
    v_float_v: float
    p_absorbed_w: float  # power absorbed by the electron-energy budget (excl. confinement losses)
    ion_balance_residual: float  # (N_g(ionisation model) - N_g(energy budget)) / N_g
    extraction_supply_margin: float  # f_geo N_g - N_x, ions/s
    absorb_fraction: float  # P_absorbed / P_discharge


def solve_electron_temperature(species: PropellantSpecies, ch: ChamberConfig, n_neutral: float,
                               loss_area_m2: float) -> tuple[float, bool]:
    """Solve the ion particle balance for T_e. Returns (T_e [eV], plasma_sustained)."""
    target = ch.edge_density_ratio * loss_area_m2 / ch.volume_m3  # 1/m
    m_i, z = species.ion_mass, species.charge_state

    def g(te: float) -> float:
        return n_neutral * ionisation_rate_coefficient(te, species) / bohm_velocity(te, m_i, z) - target

    lo, hi = ch.te_min_ev, ch.te_max_ev
    if n_neutral <= 0.0 or g(hi) < 0.0:
        return hi, False
    if g(lo) > 0.0:
        return lo, True
    return float(brentq(g, lo, hi, xtol=1e-10, rtol=1e-12)), True


def solve_plasma(species: PropellantSpecies, ch: ChamberConfig, *, n_neutral: float,
                 screen_area_m2: float, ion_open_area_m2: float, n_ext_rate: float,
                 p_discharge_w: float | None, coupling_factor: float = 1.0) -> PlasmaSolution:
    """Plasma state for a given extracted ion rate.

    ``p_discharge_w=None`` -> *regulated*: generation follows from extraction (N_g = N_x/f_geo)
    and the discharge power needed is implied (see ``p_absorbed_w``).
    ``p_discharge_w`` given -> *fixed*: N_g follows from the absorbed power for the imposed
    extraction ``n_ext_rate``; ``extraction_capacity_rate`` is the largest rate the plasma
    could supply (Bohm flux through the open area) and ``extraction_supply_margin`` is
    f_geo N_g - N_x (negative = the plasma cannot supply the imposed extraction).
    """
    z = species.charge_state
    a_loss = ch.wall_loss_area_m2 + screen_area_m2
    f_geo = ion_open_area_m2 / a_loss
    te, sustained = solve_electron_temperature(species, ch, n_neutral, a_loss)
    k_iz = ionisation_rate_coefficient(te, species)
    k_exc = excitation_rate_coefficient(te, species)
    r = k_exc / k_iz if k_iz > 0 else 0.0
    u_b = bohm_velocity(te, species.ion_mass, z)
    v_f = floating_potential_v(te, species.ion_mass)
    e_g = species.ionisation_energy_ev + r * species.excitation_threshold_ev
    e_w = v_f + 2.5 * te
    e_x = 2.5 * te + z * ch.plasma_potential_offset_v
    absorb = (ch.primary_confinement * coupling_factor - ch.radiative_loss_fraction
              - ch.other_loss_fraction)
    ev = species.ion_charge / z  # J per eV

    if p_discharge_w is None:
        n_gen = n_ext_rate / f_geo if f_geo > 0 else 0.0
        n_wall = max(n_gen - n_ext_rate, 0.0)
        p_abs = (n_gen * e_g + n_wall * e_w + n_ext_rate * e_x) * ev
        cap = float("nan")
    else:
        p_abs = max(p_discharge_w, 0.0) * absorb
        pw = p_abs / ev  # eV/s
        cap = f_geo * pw / (e_g + (1.0 - f_geo) * e_w + f_geo * e_x) if sustained else 0.0
        n_gen = max((pw + n_ext_rate * (e_w - e_x)) / (e_g + e_w), 0.0) if sustained else 0.0
    n_wall = max(n_gen - n_ext_rate, 0.0)
    n_e = n_gen / (ch.edge_density_ratio * u_b * a_loss) if u_b > 0 else 0.0
    nu_iz = n_neutral * k_iz
    prod = n_e * nu_iz * ch.volume_m3
    resid = (prod - n_gen) / n_gen if n_gen > 0 else 0.0
    return PlasmaSolution(
        sustained=sustained and n_gen > 0, te_ev=te, ti_ev=ch.ion_temperature_ev, n_e=n_e,
        n_i=n_e / z, n_edge=ch.edge_density_ratio * n_e, n_neutral=n_neutral, u_bohm=u_b,
        k_iz=k_iz, k_exc=k_exc, exc_ratio=r, nu_iz=nu_iz, ionisation_rate_density=prod / ch.volume_m3,
        ion_generation_rate=n_gen, ion_extracted_rate=n_ext_rate, ion_wall_rate=n_wall,
        ion_loss_area_m2=a_loss, extraction_fraction_geometric=f_geo,
        extraction_capacity_rate=cap, e_generation_ev=e_g, e_wall_ev=e_w, e_extraction_ev=e_x,
        v_float_v=v_f, p_absorbed_w=p_abs, ion_balance_residual=resid,
        extraction_supply_margin=f_geo * n_gen - n_ext_rate, absorb_fraction=absorb)
