"""Discharge (electron-energy) budget:

P_discharge = P_ionisation + P_excitation + P_ion_potential + P_wall + P_radiation
              + P_electron_loss + P_other

``P_ion_potential`` (potential energy given to extracted ions by the plasma-to-screen
potential offset, N_x e dV_p) is the one explicit extension of the six-channel identity; it
is zero when the plasma potential offset is zero. The residual is computed from the
independently derived channels and is never hidden.
"""

from __future__ import annotations

from dataclasses import dataclass

from ..constants import E_CHARGE


@dataclass(frozen=True)
class DischargeBudget:
    p_discharge_w: float
    p_ionisation_w: float
    p_excitation_w: float
    p_ion_potential_w: float
    p_wall_w: float
    p_radiation_w: float
    p_electron_loss_w: float
    p_other_w: float
    p_ion_wall_w: float  # sub-channel of p_wall: ion energy to walls
    p_electron_wall_w: float  # sub-channel of p_wall: electron energy to walls
    p_primary_loss_w: float  # sub-channel of p_electron_loss: unconfined primaries to anode
    p_anode_collection_w: float  # sub-channel of p_electron_loss: balancing electrons + presheath

    @property
    def accounted_w(self) -> float:
        return (self.p_ionisation_w + self.p_excitation_w + self.p_ion_potential_w + self.p_wall_w
                + self.p_radiation_w + self.p_electron_loss_w + self.p_other_w)

    @property
    def residual_w(self) -> float:
        return self.p_discharge_w - self.accounted_w


def discharge_budget(*, p_discharge_w: float, n_gen: float, n_ext: float, e_ion_ev: float,
                     e_exc_ev: float, v_float_v: float, te_ev: float, confinement: float,
                     radiative_fraction: float, other_fraction: float,
                     plasma_offset_v: float = 0.0, sustained: bool = True) -> DischargeBudget:
    """Distribute discharge power over the modelled channels.

    Per generated ion: ionisation e_ion plus excitation (K_exc/K_iz) E_exc.
    Per ion lost to a wall: ion (T_e/2 + sheath drop) and electron (2 T_e) energy.
    Per extracted ion: the balancing electron collected by the anode (2 T_e), the ion's
    presheath energy (T_e/2) and the potential energy dV_p. Primary electrons that are not
    confined reach the anode: (1 - confinement) * P_d.
    """
    if not sustained and n_gen <= 0.0:
        # no plasma: the supply power is dissipated as electrode (anode/cathode) heating
        return DischargeBudget(p_discharge_w, 0.0, 0.0, 0.0, 0.0, 0.0, p_discharge_w, 0.0, 0.0, 0.0,
                               p_discharge_w, 0.0)
    n_wall = max(n_gen - n_ext, 0.0)
    ev = E_CHARGE
    p_ion_wall = n_wall * (v_float_v + 0.5 * te_ev) * ev
    p_el_wall = n_wall * 2.0 * te_ev * ev
    p_anode = n_ext * 2.5 * te_ev * ev
    p_primary = (1.0 - confinement) * p_discharge_w
    return DischargeBudget(
        p_discharge_w=p_discharge_w, p_ionisation_w=n_gen * e_ion_ev * ev,
        p_excitation_w=n_gen * e_exc_ev * ev, p_ion_potential_w=n_ext * plasma_offset_v * ev,
        p_wall_w=p_ion_wall + p_el_wall, p_radiation_w=radiative_fraction * p_discharge_w,
        p_electron_loss_w=p_primary + p_anode, p_other_w=other_fraction * p_discharge_w,
        p_ion_wall_w=p_ion_wall, p_electron_wall_w=p_el_wall, p_primary_loss_w=p_primary,
        p_anode_collection_w=p_anode)
