"""Physical constants (SI). Sourced from astropy.constants (CODATA)."""

from __future__ import annotations

from astropy import constants as _c

E_CHARGE: float = float(_c.e.si.value)  # C
M_ELECTRON: float = float(_c.m_e.si.value)  # kg
EPS0: float = float(_c.eps0.si.value)  # F/m
K_B: float = float(_c.k_B.si.value)  # J/K
SIGMA_SB: float = float(_c.sigma_sb.si.value)  # W m^-2 K^-4
AMU: float = float(_c.u.si.value)  # kg
EV: float = E_CHARGE  # J per eV (numerically equal to e)
G0: float = 9.80665  # m/s^2, standard gravity (exact by definition)

__all__ = ["AMU", "EPS0", "EV", "E_CHARGE", "G0", "K_B", "M_ELECTRON", "SIGMA_SB"]
