"""Structured simulation results."""

from __future__ import annotations

import datetime as _dt
import uuid
from dataclasses import dataclass, field
from typing import Any

import pandas as pd

from . import MODEL_VERSION, __version__
from .configuration import EngineConfig
from .simulation.state import IonEngineState, to_jsonable
from .simulation.sweeps import state_row
from .simulation.transient import TransientResult
from .validation import ValidationReport, run_validation


@dataclass
class SimulationResult:
    engine_configuration: dict[str, Any]
    operating_points: pd.DataFrame
    time_history: pd.DataFrame | None
    performance: dict[str, Any]
    thermal_state: dict[str, Any]
    power_balance: dict[str, Any]
    mass_balance: dict[str, Any]
    warnings: list[str]
    validation: dict[str, Any]
    metadata: dict[str, Any]
    state: IonEngineState | None = None
    tables: dict[str, pd.DataFrame] = field(default_factory=dict)

    @property
    def validation_status(self) -> str:
        return str(self.validation.get("status", "UNKNOWN"))

    def summary(self) -> str:
        p = self.performance
        lines = [f"ION-CORE result {self.metadata['simulation_id']}  [{self.metadata['mode']}]  validation: {self.validation_status}"]
        if p:
            lines.append(f"  thrust {p.get('thrust_n', 0) * 1e3:.2f} mN   Isp {p.get('isp_s', 0):.0f} s   "
                         f"T/P {p.get('thrust_to_power_mn_kw', 0):.1f} mN/kW   P_in {self.power_balance.get('p_input_w', 0):.0f} W")
        lines.append("  " + self.power_balance.get("message", ""))
        lines.append("  " + self.mass_balance.get("message", ""))
        lines += [f"  ! {w}" for w in self.warnings]
        return "\n".join(lines)


def _meta(cfg: EngineConfig, mode: str, scenario: dict[str, Any], seed: int, validation_status: str,
          parameters: dict[str, Any] | None = None) -> dict[str, Any]:
    from .units import unit_of
    cols = ["time_s", "beam_voltage_v", "beam_current_a", "thrust_n", "isp_s", "p_input_w", "mass_flow_kg_s",
            "temp_grids_k", "thrust_to_power_mn_kw", "neutral_density_m3", "electron_density_m3"]
    return {
        "simulation_id": str(uuid.uuid4()), "timestamp": _dt.datetime.now(_dt.UTC).isoformat(timespec="seconds"),
        "software_version": __version__, "model_version": MODEL_VERSION, "mode": mode, "scenario": scenario,
        "random_seed": seed, "parameters": parameters or {}, "units": {c: unit_of(c) for c in cols},
        "validation_status": validation_status, "parameter_provenance": cfg.engine.parameter_provenance,
        "unit_system": "SI (column-name suffix gives the unit: _v V, _a A, _w W, _k K, _n N, _s s, _m3 1/m^3, _kg_s kg/s)",
    }


def _validation(state_ok: list[str], report: ValidationReport | None = None) -> dict[str, Any]:
    rep = report or run_validation()
    d = rep.to_dict()
    d["suite_status"] = d["status"]
    d["run_checks"] = state_ok
    if any(s.endswith("FAIL") for s in state_ok):
        d["status"] = "FAIL"
    return d


def _state_blocks(st: IonEngineState) -> tuple[dict, dict, dict, dict, list[str]]:
    eb, mb = st.energy_balance, st.mass_balance
    assert eb is not None and mb is not None
    perf = to_jsonable(st.performance_state)
    perf |= {"efficiencies": to_jsonable(st.performance_state.efficiencies)}
    power = to_jsonable(st.power_state) | to_jsonable(eb) | {"message": eb.message}
    mass = to_jsonable(mb) | {"message": mb.message}
    thermal = to_jsonable(st.thermal_state)
    warn = st.limits.messages + (["thermal network did not converge"] if not st.thermal_state.steady_state_solved else []) \
        + ([] if st.convergence.converged else ["steady-state iteration did not converge: " + st.convergence.note])
    return perf, thermal, power, mass, warn


def result_from_state(cfg: EngineConfig, st: IonEngineState, *, mode: str = "SIMULATION", scenario: dict | None = None,
                      seed: int = 0, tables: dict[str, pd.DataFrame] | None = None,
                      time_history: pd.DataFrame | None = None, parameters: dict | None = None) -> SimulationResult:
    perf, thermal, power, mass, warn = _state_blocks(st)
    val = _validation([f"energy balance: {st.energy_balance.status}", f"mass balance: {st.mass_balance.status}",  # type: ignore[union-attr]
                       f"limits: {st.limits.status}"])
    meta = _meta(cfg, mode, scenario or {"type": "steady-state"}, seed, val["status"], parameters)
    return SimulationResult(cfg.to_dict(), pd.DataFrame([state_row(st)]), time_history, perf, thermal, power, mass, warn, val, meta,
                            st, tables or {})


def result_from_transient(cfg: EngineConfig, tr: TransientResult, *, mode: str = "SIMULATION",
                          tables: dict[str, pd.DataFrame] | None = None) -> SimulationResult:
    st = tr.hold_state or tr.final_state  # state reported = last state with the beam on
    perf, thermal, power, mass, warn = _state_blocks(st)
    warn = list(tr.warnings) + warn
    checks = [f"energy balance (all {len(tr.history)} steps): {'FAIL' if tr.energy_balance_failures else 'PASS'} "
              f"(worst {tr.max_energy_residual_rel:.2e})",
              f"mass balance (all {len(tr.history)} steps): {'FAIL' if tr.mass_balance_failures else 'PASS'} "
              f"(worst {tr.max_mass_residual_rel:.2e})"]
    val = _validation(checks)
    sc = tr.scenario
    scenario = {"type": "transient", "name": sc.name if sc else "", "duration_s": sc.duration_s if sc else None,
                "events": [{"t_s": e.t_s, "action": e.action, **e.params} for e in (sc.events if sc else [])],
                "transitions": tr.transitions}
    meta = _meta(cfg, mode, scenario, sc.random_seed if sc else 0, val["status"])
    steady = tr.target_state
    ops = pd.DataFrame([state_row(steady)])
    return SimulationResult(cfg.to_dict(), ops, tr.history, perf, thermal, power, mass, warn, val, meta, st, tables or {})
