"""Lightweight engineering console server (stdlib only).

Every number shown in the console is returned by the Python model through these endpoints:

    GET  /api/schema        input definitions + defaults + species
    POST /api/evaluate      steady-state state, calculation chain, limits, balances
    POST /api/curves        thrust/Isp/efficiency/T-P curves + operating map (model sweeps)
    POST /api/transient     start-up / hold / shutdown time history
    GET  /api/validate      the validation suite
"""

from __future__ import annotations

import json
import os
import threading
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any

import numpy as np

from ..configuration import EngineConfig, OperatingPoint
from ..propellant.species import SPECIES_REGISTRY
from ..simulation.scenarios import Event, Scenario
from ..simulation.solver import solve_steady_state
from ..simulation.sweeps import engineering_curves
from ..simulation.transient import run_transient
from ..validation import run_validation

INDEX = Path(__file__).with_name("index.html")

# input id -> (label, unit, default getter, min, max, step, display scale)
FIELDS: list[dict[str, Any]] = [
    {"id": "species", "label": "Propellant", "type": "select", "options": sorted(SPECIES_REGISTRY)},
    {"id": "mass_flow_mg_s", "label": "Total mass flow", "unit": "mg/s", "min": 1.0, "max": 6.0, "step": 0.01},
    {"id": "beam_voltage_v", "label": "Beam voltage", "unit": "V", "min": 300.0, "max": 1800.0, "step": 5.0},
    {"id": "beam_current_a", "label": "Beam current", "unit": "A", "min": 0.2, "max": 3.0, "step": 0.01},
    {"id": "accelerator_voltage_v", "label": "Accelerator bias", "unit": "V", "min": 20.0, "max": 400.0, "step": 1.0},
    {"id": "neutraliser_current_a", "label": "Neutraliser emission (blank = auto)", "unit": "A", "min": 0.0, "max": 4.0, "step": 0.01, "optional": True},
    {"id": "gap_mm", "label": "Grid gap", "unit": "mm", "min": 0.3, "max": 1.2, "step": 0.01},
    {"id": "aperture_mm", "label": "Screen aperture diameter", "unit": "mm", "min": 1.4, "max": 2.1, "step": 0.01},
    {"id": "env_k", "label": "Environment temperature", "unit": "K", "min": 3.0, "max": 400.0, "step": 1.0},
]


def defaults(cfg: EngineConfig) -> dict[str, Any]:
    op = cfg.operating_point
    return {"species": cfg.propellant.species, "mass_flow_mg_s": op.mass_flow_kg_s * 1e6, "beam_voltage_v": op.beam_voltage_v,
            "beam_current_a": op.beam_current_a or 1.76, "accelerator_voltage_v": op.accelerator_voltage_v or cfg.grids.accelerator_voltage_v,
            "neutraliser_current_a": op.neutraliser_current_a, "gap_mm": cfg.grids.extraction_gap_m * 1e3,
            "aperture_mm": cfg.grids.aperture_diameter_m * 1e3, "env_k": cfg.thermal.environment_temperature_k}


def build(base: EngineConfig, v: dict[str, Any]) -> tuple[EngineConfig, OperatingPoint]:
    """Console inputs -> (configuration, operating point). Raises ValueError on invalid input."""
    nc = v.get("neutraliser_current_a")
    cfg = base.with_updates({"propellant.species": str(v["species"]), "grids.extraction_gap_m": float(v["gap_mm"]) * 1e-3,
                             "grids.aperture_diameter_m": float(v["aperture_mm"]) * 1e-3,
                             "thermal.environment_temperature_k": float(v["env_k"])})
    op = OperatingPoint(mass_flow_kg_s=float(v["mass_flow_mg_s"]) * 1e-6, beam_voltage_v=float(v["beam_voltage_v"]),
                        beam_current_a=float(v["beam_current_a"]), accelerator_voltage_v=float(v["accelerator_voltage_v"]),
                        neutraliser_current_a=None if nc in (None, "") else float(nc))
    cfg = cfg.with_updates({"operating_point": op.model_dump()})
    return cfg, op


def _df(df: Any) -> dict[str, list]:
    d = df.replace({np.nan: None}).to_dict(orient="list")
    return {k: [None if (isinstance(x, float) and not np.isfinite(x)) else x for x in col] for k, col in d.items()}


class Handler(BaseHTTPRequestHandler):
    base_cfg: EngineConfig
    transient_cache: dict[str, Any] = {}

    def log_message(self, fmt: str, *args: Any) -> None:  # quiet
        pass

    def _send(self, code: int, body: bytes, ctype: str = "application/json") -> None:
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def _json(self, obj: Any, code: int = 200) -> None:
        self._send(code, json.dumps(obj, allow_nan=False).encode())

    def do_GET(self) -> None:
        path = self.path.split("?")[0]
        if path in ("/", "/index.html"):
            self._send(200, INDEX.read_bytes(), "text/html; charset=utf-8")
        elif path == "/static/plotly.min.js":
            import plotly
            js = Path(plotly.__file__).parent / "package_data" / "plotly.min.js"
            self._send(200, js.read_bytes(), "application/javascript")
        elif path == "/api/schema":
            from .. import MODEL_VERSION, __version__
            self._json({"fields": FIELDS, "defaults": defaults(self.base_cfg), "version": __version__, "model_version": MODEL_VERSION,
                        "engine": self.base_cfg.engine.name, "provenance": self.base_cfg.engine.parameter_provenance})
        elif path == "/api/validate":
            self._json(run_validation().to_dict())
        else:
            self._send(404, b'{"error":"not found"}')

    def do_POST(self) -> None:
        length = int(self.headers.get("Content-Length", 0))
        try:
            body = json.loads(self.rfile.read(length) or b"{}")
            cfg, op = build(self.base_cfg, {**defaults(self.base_cfg), **body.get("inputs", {})})
            path = self.path.split("?")[0]
            if path == "/api/evaluate":
                st = solve_steady_state(cfg, op)
                self._json({"state": st.to_dict(), "config": cfg.to_dict()})
            elif path == "/api/curves":
                c = engineering_curves(cfg, op, n=21)
                env = c["envelope"]
                grid = {k: env[k].values.tolist() for k in ("thrust_n", "eta_overall", "thrust_to_power_mn_kw", "p_beam_w", "p_input_w",
                                                            "isp_s", "perveance_ratio", "limit_status")}
                grid = {k: [[(None if isinstance(x, float) and not np.isfinite(x) else x) for x in row] for row in v] for k, v in grid.items()}
                self._json({"throttle": _df(c["throttle"]), "beam_voltage": _df(c["beam_voltage"]),
                            "map": {"x": env["beam_voltage_v_axis"].values.tolist(), "y": env["beam_current_a_axis"].values.tolist(), **grid}})
            elif path == "/api/transient":
                key = json.dumps([cfg.to_dict()], sort_keys=True, default=str)
                if key not in self.transient_cache:
                    sc = Scenario("console_cycle", float(body.get("duration_s", 2400.0)),
                                  [Event(0.0, "start"), Event(float(body.get("hold_until_s", 900.0)), "shutdown")])
                    tr = run_transient(cfg, sc)
                    h = tr.history.iloc[::max(len(tr.history) // 700, 1)]
                    self.transient_cache.clear()
                    self.transient_cache[key] = {"history": _df(h), "transitions": tr.transitions,
                                                 "energy_fail_steps": tr.energy_balance_failures, "mass_fail_steps": tr.mass_balance_failures,
                                                 "max_energy_residual_rel": tr.max_energy_residual_rel,
                                                 "max_mass_residual_rel": tr.max_mass_residual_rel, "steps": len(tr.history)}
                self._json(self.transient_cache[key])
            else:
                self._send(404, b'{"error":"not found"}')
        except (ValueError, KeyError, TypeError) as exc:
            self._json({"error": str(exc)[:400]}, 400)


def serve(cfg: EngineConfig, host: str = "127.0.0.1", port: int = 8050, open_browser: bool = True) -> None:
    Handler.base_cfg = cfg
    srv = ThreadingHTTPServer((host, port), Handler)
    url = f"http://{host}:{port}/"
    print(f"ION-CORE engineering console: {url}   (Ctrl-C to stop)")
    if open_browser and not os.environ.get("ION_CORE_NO_BROWSER"):
        threading.Timer(0.6, lambda: webbrowser.open(url)).start()
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        srv.server_close()


def make_server(cfg: EngineConfig, host: str = "127.0.0.1", port: int = 0) -> ThreadingHTTPServer:
    """Server object for tests (port 0 = free port)."""
    Handler.base_cfg = cfg
    return ThreadingHTTPServer((host, port), Handler)
