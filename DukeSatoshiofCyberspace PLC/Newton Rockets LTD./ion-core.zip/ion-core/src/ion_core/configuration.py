"""Engine configuration (Pydantic). All numeric defaults are DEMONSTRATION parameters.

They are loosely of the 30 cm gridded-ion-thruster class so that the model produces
plausible magnitudes, but they are NOT data from any real engine and carry no authority.
Values may be written with units (e.g. ``"1.1 kV"``); everything is stored in SI.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any, Literal

import yaml
from pydantic import BaseModel, ConfigDict, Field, model_validator

from .propellant.species import PropellantSpecies, get_species
from .units import (
    Amp,
    CuMetre,
    JPerK,
    Kelvin,
    KgPerS,
    Metre,
    Radian,
    Second,
    SqMetre,
    Volt,
    Watt,
    WPerK,
)

PROVENANCE = "DEMONSTRATION parameters: unvalidated, not data from any real engine"


class _Cfg(BaseModel):
    model_config = ConfigDict(extra="forbid", validate_assignment=True)


class EngineMeta(_Cfg):
    architecture: Literal["gridded_ion_thruster"] = "gridded_ion_thruster"
    name: str = "ION-CORE demonstration engine"
    parameter_provenance: str = PROVENANCE


class PropellantConfig(_Cfg):
    species: str = "xenon"
    custom: PropellantSpecies | None = None

    def resolve(self) -> PropellantSpecies:
        return self.custom if self.custom is not None else get_species(self.species)


class FlowConfig(_Cfg):
    neutraliser_flow_fraction: float = Field(0.07, ge=0, le=1)  # of main flow, DEMONSTRATION
    leak_fraction: float = Field(0.0, ge=0, le=0.5)  # explicit propellant-loss channel
    max_propellant_utilisation: float = Field(0.98, gt=0, le=1)


class ChamberConfig(_Cfg):
    default_discharge_voltage_v: Volt = 25.0
    volume_m3: CuMetre = 8.0e-3
    wall_loss_area_m2: SqMetre = 0.10  # effective anode/wall ion-loss area (cusp-confined)
    edge_density_ratio: float = Field(0.6, gt=0, le=1)  # n_sheath-edge / n_bulk (h factor)
    ion_temperature_ev: float = Field(0.2, gt=0)
    primary_confinement: float = Field(0.80, gt=0, le=1)  # fraction of P_d coupled to plasma
    radiative_loss_fraction: float = Field(0.01, ge=0, lt=1)
    other_loss_fraction: float = Field(0.03, ge=0, lt=1)  # unmodelled losses
    plasma_potential_offset_v: Volt = 3.0  # plasma potential above screen-grid potential
    te_min_ev: float = 0.3
    te_max_ev: float = 40.0

    @model_validator(mode="after")
    def _check(self) -> ChamberConfig:
        if self.primary_confinement - self.radiative_loss_fraction - self.other_loss_fraction <= 0.05:
            raise ValueError("primary_confinement minus radiative/other fractions must exceed 0.05")
        return self


class GridConfig(_Cfg):
    active_diameter_m: Metre = 0.28
    number_of_apertures: int = Field(15000, gt=0)
    aperture_diameter_m: Metre = 1.91e-3  # screen-grid aperture
    accel_aperture_diameter_m: Metre = 1.14e-3
    grid_thickness_m: Metre = 0.38e-3  # screen grid
    accel_thickness_m: Metre = 0.51e-3
    extraction_gap_m: Metre = 0.58e-3  # grid_spacing: screen-to-accelerator
    transparency: float | None = Field(None, gt=0, lt=1)  # optional override of open fraction
    accelerator_voltage_v: Volt = 180.0  # magnitude of the (negative) accel-grid bias
    ion_focusing_factor: float = Field(1.1, ge=1.0)
    interception_fraction_base: float = Field(0.005, ge=0, lt=0.5)
    interception_overperveance_gain: float = Field(20.0, ge=0)  # f_int = f0 (1 + gain x^2)
    neutral_clausing_factor: float = Field(0.5, gt=0, le=1)  # neutral transmission of grid holes
    divergence_sigma_base_rad: Radian = 0.12
    divergence_perveance_gain: float = Field(0.8, ge=0)
    perveance_ratio_optimum: float = Field(0.45, gt=0, lt=1)

    @model_validator(mode="after")
    def _geometry(self) -> GridConfig:
        if self.transparency is None and self.number_of_apertures * self.aperture_diameter_m**2 \
                >= self.active_diameter_m**2:
            raise ValueError("apertures overfill the active grid area; reduce count or diameter")
        return self


class BeamConfig(_Cfg):
    measurement_distance_m: Metre = 0.30  # plane at which beam diameter is reported
    velocity_calibration_factor: float | None = Field(None, gt=0)  # measured/modelled velocity


class NeutraliserConfig(_Cfg):
    efficiency: float = Field(0.98, gt=0, le=1)  # emission delivered / emission commanded
    emission_margin: float = Field(1.10, ge=1.0)  # auto-commanded I_n = margin * I_beam
    readiness_threshold: float = Field(0.95, gt=0, le=1)  # emission readiness needed for beam
    max_emission_current_a: Amp = 3.0
    heater_power_w: Watt = 30.0
    keeper_voltage_v: Volt = 12.0
    keeper_current_a: Amp = 1.0
    coupling_voltage_v: Volt = 8.0  # plume coupling potential (beam plasma above neutraliser)


class PPUConfig(_Cfg):
    bus_voltage_v: Volt = 100.0
    efficiency_input_stage: float = Field(0.985, gt=0, le=1)
    efficiency_discharge: float = Field(0.93, gt=0, le=1)
    efficiency_beam: float = Field(0.95, gt=0, le=1)
    efficiency_accel: float = Field(0.90, gt=0, le=1)
    efficiency_neutraliser: float = Field(0.90, gt=0, le=1)
    efficiency_auxiliary: float = Field(0.92, gt=0, le=1)
    auxiliary_power_w: Watt = 25.0


class ThermalNodeConfig(_Cfg):
    heat_capacity_j_k: JPerK
    radiating_area_m2: SqMetre
    emissivity: float = Field(gt=0, le=1)


NODE_NAMES = ("chamber", "grids", "neutraliser", "ppu", "structure")


def _default_nodes() -> dict[str, ThermalNodeConfig]:
    return {
        "chamber": ThermalNodeConfig(heat_capacity_j_k=2000.0, radiating_area_m2=0.30, emissivity=0.60),
        "grids": ThermalNodeConfig(heat_capacity_j_k=150.0, radiating_area_m2=0.12, emissivity=0.25),
        "neutraliser": ThermalNodeConfig(heat_capacity_j_k=40.0, radiating_area_m2=0.0004, emissivity=0.60),
        "ppu": ThermalNodeConfig(heat_capacity_j_k=3000.0, radiating_area_m2=0.40, emissivity=0.80),
        "structure": ThermalNodeConfig(heat_capacity_j_k=3000.0, radiating_area_m2=0.80, emissivity=0.70),
    }


class ThermalConfig(_Cfg):
    environment_temperature_k: Kelvin = 300.0
    nodes: dict[str, ThermalNodeConfig] = Field(default_factory=_default_nodes)
    conductances_w_k: dict[str, WPerK] = Field(default_factory=lambda: {
        "chamber-grids": 1.0, "chamber-structure": 2.0, "chamber-neutraliser": 0.01,
        "neutraliser-structure": 0.02, "ppu-structure": 3.0,
    })
    radiation_escape_fraction: float = Field(0.3, ge=0, le=1)  # of excitation/radiative power

    @model_validator(mode="after")
    def _nodes(self) -> ThermalConfig:
        if set(self.nodes) != set(NODE_NAMES):
            raise ValueError(f"thermal.nodes must define exactly {NODE_NAMES}")
        for key in self.conductances_w_k:
            a, _, b = key.partition("-")
            if a not in NODE_NAMES or b not in NODE_NAMES or a == b:
                raise ValueError(f"bad conductance key '{key}'")
        return self


class LimitsConfig(_Cfg):
    max_beam_voltage_v: Volt = 1500.0
    max_beam_current_a: Amp = 2.2
    max_discharge_power_w: Watt = 450.0
    max_neutraliser_current_a: Amp = 3.0
    max_grid_temperature_k: Kelvin = 650.0
    max_chamber_temperature_k: Kelvin = 700.0
    max_neutraliser_temperature_k: Kelvin = 1300.0
    max_ppu_temperature_k: Kelvin = 400.0
    max_thermal_load_w: Watt = 800.0
    min_plasma_density_m3: float = 1.0e16
    min_accel_voltage_v: Volt = 100.0  # electron-backstreaming margin
    max_electric_field_v_m: float = 6.0e6
    max_space_charge_ratio: float = 1.0
    max_interception_fraction: float = 0.05
    beam_active_threshold_a: float = 0.05  # density / backstreaming checks apply above this beam current
    warn_fraction: float = Field(0.9, gt=0, lt=1)


class SolverConfig(_Cfg):
    time_step_s: Second = 0.25
    cooldown_time_step_s: Second = 5.0
    absolute_tolerance: float = 1e-9
    relative_tolerance: float = 1e-6
    maximum_iterations: int = 100
    energy_balance_tolerance: float = 1e-3  # |residual| / P_input
    mass_balance_tolerance: float = 1e-6  # |residual| / m_dot_in


class TimeConstantsConfig(_Cfg):
    flow_s: Second = 2.0
    discharge_s: Second = 0.4
    plasma_s: Second = 0.05
    grid_voltage_s: Second = 4.0
    beam_current_s: Second = 1.0
    neutraliser_s: Second = 40.0
    power_electronics_s: Second = 0.2


class DegradationCoefficient(_Cfg):
    name: str
    value: float
    units: str
    source: str = "DEMONSTRATION — uncalibrated; replace with experimental fit"
    uncertainty: float | None = None  # 1-sigma, same units as value (None = unknown)
    validity_range: tuple[float, float] = (0.0, 1.0e5)  # range of the driving variable
    description: str = ""


def _default_degradation() -> list[DegradationCoefficient]:
    return [
        DegradationCoefficient(
            name="grid_interception_growth", value=2.0e-3, units="1/(A*h)",
            validity_range=(0.0, 500.0), uncertainty=None,
            description="relative growth of accel-grid interception per A*h of intercepted ions"),
        DegradationCoefficient(
            name="neutraliser_emission_loss", value=1.0e-5, units="1/h",
            validity_range=(0.0, 3.0e4),
            description="fractional loss of neutraliser emission capability per operating hour"),
        DegradationCoefficient(
            name="ppu_efficiency_loss", value=1.0e-6, units="1/h",
            validity_range=(0.0, 5.0e4),
            description="absolute PPU efficiency loss per operating hour"),
        DegradationCoefficient(
            name="thermal_cycle_emissivity_loss", value=1.0e-4, units="1/cycle",
            validity_range=(0.0, 1000.0),
            description="fractional radiator-emissivity loss per thermal cycle"),
    ]


class DegradationConfig(_Cfg):
    coefficients: list[DegradationCoefficient] = Field(default_factory=_default_degradation)

    def value(self, name: str) -> float:
        for c in self.coefficients:
            if c.name == name:
                return c.value
        raise KeyError(name)


class TelemetryConfig(_Cfg):
    seed: int = 12345
    noise_rel: float = Field(0.005, ge=0)
    noise_rel_by_channel: dict[str, float] = Field(default_factory=dict)
    bias: dict[str, float] = Field(default_factory=dict)  # additive, channel units
    latency_s: Second = 0.0
    dropout_probability: float = Field(0.0, ge=0, lt=1)
    quantisation: dict[str, float] = Field(default_factory=dict)  # step size per channel


class OperatingPoint(_Cfg):
    """Commanded operating point. ``None`` fields are resolved from the configuration.

    * ``discharge_current_a`` given (or ``discharge_power_w`` / discharge voltage): fixed discharge.
    * both ``None``: discharge current is regulated to deliver the commanded beam current.
    """

    mass_flow_kg_s: KgPerS = Field(gt=0)
    beam_voltage_v: Volt = Field(gt=0)
    beam_current_a: Amp | None = Field(None, ge=0)
    discharge_voltage_v: Volt | None = Field(None, gt=0)
    discharge_current_a: Amp | None = Field(None, ge=0)
    discharge_power_w: Watt | None = Field(None, ge=0)
    neutraliser_current_a: Amp | None = Field(None, ge=0)
    accelerator_voltage_v: Volt | None = Field(None, ge=0)

    @model_validator(mode="after")
    def _discharge(self) -> OperatingPoint:
        if self.beam_current_a is None and self.discharge_power_w is None \
                and self.discharge_current_a is None:
            raise ValueError("give beam_current_a (discharge regulated) and/or a discharge setting")
        if None not in (self.discharge_voltage_v, self.discharge_current_a, self.discharge_power_w):
            p = self.discharge_voltage_v * self.discharge_current_a  # type: ignore[operator]
            if abs(p - self.discharge_power_w) > 0.01 * abs(p):  # type: ignore[operator]
                raise ValueError("discharge_power_w inconsistent with discharge V*I")
        return self


class EngineConfig(_Cfg):
    engine: EngineMeta = Field(default_factory=EngineMeta)
    propellant: PropellantConfig = Field(default_factory=PropellantConfig)
    flow: FlowConfig = Field(default_factory=FlowConfig)
    chamber: ChamberConfig = Field(default_factory=ChamberConfig)
    grids: GridConfig = Field(default_factory=GridConfig)
    beam: BeamConfig = Field(default_factory=BeamConfig)
    neutraliser: NeutraliserConfig = Field(default_factory=NeutraliserConfig)
    ppu: PPUConfig = Field(default_factory=PPUConfig)
    thermal: ThermalConfig = Field(default_factory=ThermalConfig)
    limits: LimitsConfig = Field(default_factory=LimitsConfig)
    solver: SolverConfig = Field(default_factory=SolverConfig)
    timing: TimeConstantsConfig = Field(default_factory=TimeConstantsConfig)
    degradation: DegradationConfig = Field(default_factory=DegradationConfig)
    telemetry: TelemetryConfig = Field(default_factory=TelemetryConfig)
    operating_point: OperatingPoint = Field(
        default_factory=lambda: OperatingPoint(
            mass_flow_kg_s=3.0e-6, beam_voltage_v=1100.0, beam_current_a=1.76))
    scenario: dict[str, Any] = Field(default_factory=dict)  # free-form run settings

    @property
    def species(self) -> PropellantSpecies:
        return self.propellant.resolve()

    # ---- (de)serialisation -------------------------------------------------------------
    @classmethod
    def from_yaml(cls, path: str | Path) -> EngineConfig:
        with open(path, encoding="utf-8") as fh:
            data = yaml.safe_load(fh) or {}
        return cls.model_validate(data)

    def to_dict(self) -> dict[str, Any]:
        return self.model_dump(mode="json")

    # ---- dotted-path access used by sweeps / Monte Carlo / calibration ---------------------
    def get_path(self, path: str) -> Any:
        obj: Any = self
        for part in path.split("."):
            obj = obj[part] if isinstance(obj, dict) else getattr(obj, part)
        return obj

    def with_updates(self, updates: dict[str, Any]) -> EngineConfig:
        data = self.model_dump()
        for path, value in updates.items():
            node: Any = data
            parts = path.split(".")
            for part in parts[:-1]:
                node = node[part]
            if parts[-1] not in node:
                raise KeyError(f"unknown configuration path '{path}'")
            node[parts[-1]] = value
        return EngineConfig.model_validate(data)
