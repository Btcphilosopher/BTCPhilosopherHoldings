"""Radiative heat rejection: Q_rad = eps sigma A (T^4 - T_env^4)."""

from __future__ import annotations

from ..constants import SIGMA_SB


def radiated_power(emissivity: float, area_m2: float, temperature_k: float, env_k: float) -> float:
    return emissivity * SIGMA_SB * area_m2 * (temperature_k**4 - env_k**4)


def radiative_conductance(emissivity: float, area_m2: float, temperature_k: float) -> float:
    """dQ_rad/dT = 4 eps sigma A T^3, W/K (used for time constants and Jacobians)."""
    return 4.0 * emissivity * SIGMA_SB * area_m2 * temperature_k**3
