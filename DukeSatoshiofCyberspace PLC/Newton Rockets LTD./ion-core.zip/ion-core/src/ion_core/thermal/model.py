"""Lumped thermal network: chamber, grids, neutraliser, PPU, structure.

C_i dT_i/dt = Q_gen,i - sum_j G_ij (T_i - T_j) - eps_i sigma A_i (T_i^4 - T_env^4)
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from ..configuration import NODE_NAMES, ThermalConfig
from ..constants import SIGMA_SB
from .radiation import radiative_conductance


@dataclass(frozen=True)
class NodeThermal:
    temperature_k: float
    generated_heat_w: float
    conducted_heat_w: float  # net heat conducted OUT to other nodes (negative = received)
    radiated_heat_w: float
    stored_rate_w: float  # C dT/dt = Q_gen - conducted - radiated


class ThermalNetwork:
    def __init__(self, cfg: ThermalConfig, emissivity_factor: float = 1.0) -> None:
        self.cfg = cfg
        self.names = NODE_NAMES
        self.idx = {n: i for i, n in enumerate(self.names)}
        self.c = np.array([cfg.nodes[n].heat_capacity_j_k for n in self.names])
        self.area = np.array([cfg.nodes[n].radiating_area_m2 for n in self.names])
        self.eps = np.array([cfg.nodes[n].emissivity for n in self.names]) * emissivity_factor
        self.t_env = cfg.environment_temperature_k
        n = len(self.names)
        self.g = np.zeros((n, n))
        for key, val in cfg.conductances_w_k.items():
            a, _, b = key.partition("-")
            self.g[self.idx[a], self.idx[b]] += val
            self.g[self.idx[b], self.idx[a]] += val

    def initial(self) -> np.ndarray:
        return np.full(len(self.names), self.t_env)

    def q_rad(self, t: np.ndarray) -> np.ndarray:
        """eps sigma A (T^4 - T_env^4), vectorised form of :func:`radiated_power`."""
        return self.eps * SIGMA_SB * self.area * (t**4 - self.t_env**4)

    def q_cond(self, t: np.ndarray) -> np.ndarray:
        """Net conduction out of each node."""
        return (self.g * (t[:, None] - t[None, :])).sum(axis=1)

    def residual(self, t: np.ndarray, q_gen: np.ndarray) -> np.ndarray:
        return q_gen - self.q_cond(t) - self.q_rad(t)

    def derivative(self, t: np.ndarray, q_gen: np.ndarray) -> np.ndarray:
        return self.residual(t, q_gen) / self.c

    def step_rk4(self, t: np.ndarray, q_gen: np.ndarray, dt: float, max_sub_dt: float = 1.0) -> np.ndarray:
        n_sub = max(1, int(np.ceil(dt / max_sub_dt)))
        h = dt / n_sub
        for _ in range(n_sub):
            k1 = self.derivative(t, q_gen)
            k2 = self.derivative(t + 0.5 * h * k1, q_gen)
            k3 = self.derivative(t + 0.5 * h * k2, q_gen)
            k4 = self.derivative(t + h * k3, q_gen)
            t = t + h * (k1 + 2 * k2 + 2 * k3 + k4) / 6.0
        return t

    def jacobian(self, t: np.ndarray) -> np.ndarray:
        """-dR/dT = (diag(sum G) - G) + diag(4 eps sigma A T^3); symmetric positive definite."""
        return np.diag(self.g.sum(axis=1)) - self.g + np.diag(4.0 * self.eps * SIGMA_SB * self.area * t**3)

    def steady_state(self, q_gen: np.ndarray, t0: np.ndarray | None = None,
                     tol_k: float = 1e-10, max_iter: int = 80) -> tuple[np.ndarray, bool]:
        """Newton solve of R(T) = Q_gen - conduction - radiation = 0 with an analytic Jacobian.

        R is monotone in every T_i, so damped Newton from a positive start converges
        quadratically. Returns (T, converged). Falls back to time relaxation only if Newton
        fails, and then reports converged=False.
        """
        t = (self.initial() + 50.0) if t0 is None else np.array(t0, dtype=float)
        scale = max(float(np.max(np.abs(q_gen))), 1.0)
        for _ in range(max_iter):
            r = self.residual(t, q_gen)
            dt = np.linalg.solve(self.jacobian(t), r)
            step = 1.0
            while np.any(t + step * dt <= 1.0) and step > 1e-6:
                step *= 0.5
            t = t + step * dt
            if float(np.max(np.abs(step * dt))) <= tol_k and float(np.max(np.abs(self.residual(t, q_gen)))) <= 1e-9 * scale:
                return t, True
        t = np.maximum(t, 1.0)
        for _ in range(400):
            t = self.step_rk4(t, q_gen, 50.0, 2.0)
        return t, False

    def node_report(self, t: np.ndarray, q_gen: np.ndarray) -> dict[str, NodeThermal]:
        qc, qr = self.q_cond(t), self.q_rad(t)
        out = {}
        for n, i in self.idx.items():
            out[n] = NodeThermal(float(t[i]), float(q_gen[i]), float(qc[i]), float(qr[i]),
                                 float(q_gen[i] - qc[i] - qr[i]))
        return out

    def time_constants(self, t: np.ndarray) -> np.ndarray:
        """Per-node characteristic time C / (sum G + dQ_rad/dT), s."""
        gsum = self.g.sum(axis=1)
        gr = np.array([radiative_conductance(self.eps[i], self.area[i], t[i]) for i in range(len(t))])
        return self.c / (gsum + gr)
