# ION-CORE physics model

Reduced-order, SI throughout. **All numeric engineering parameters are DEMONSTRATION values** (see
`configuration.py`; the provenance string travels with every result). Equation numbers refer to this file only.

## 1. Species (`propellant/species.py`)
`atomic_mass`, `ion_mass = atomic_mass − Z m_e`, `ion_charge = Z e`, first `ionisation_energy`, Lotz shells,
excitation threshold and a lumped excitation cross-section (DEMONSTRATION). Neutral atoms, ions and electrons are
separate quantities everywhere. The engine raises `NotImplementedError` for `Z > 1`.

## 2. Propellant flow and neutral balance (`propellant/`, `simulation/engine.py`)
Total engine flow `ṁ = ṁ_main + ṁ_neutraliser + ṁ_leak` (fractions in `FlowConfig`). With `Ṅ_main = ṁ_main/m_a`
and extracted-ion rate `N_x = I_ext/(Z e)`:

    Ṅ_main = N_x + ¼ n_n v̄ A_n          (1)   neutral balance — wall-lost ions recombine and return as neutrals
    n_n    = 4 (Ṅ_main − N_x) / (v̄ A_n)  (2)   v̄ at the chamber temperature, A_n = N_ap π d_min²/4 · clausing

`n_n ≤ 0` (extracted ions ≥ main flow) is a physically impossible point: it is flagged `INVALID`, not clamped.

## 3. Ionisation (`plasma/ionisation.py`)
Lotz cross-section `σ(E) = a ξ ln(E/P)/(E P)` for `E ≥ P`; Maxwellian average
`⟨σv⟩(Tₑ) = ∫σ v f dE` by composite Simpson (801 points on `[P, P+60Tₑ]`, Numba). Excitation uses a closed form for a
constant cross-section above threshold. Exposed: `ionisation_frequency`, `ionisation_rate_density = nₑ n_n ⟨σv⟩`,
`ionisation_probability = ν_iz/(ν_iz+ν_exit)` per neutral, `ion_production_rate`.
**There is no assumed ionisation efficiency**: the reported efficiency is `I_ext E_iz / P_d` (minimum ionisation power ÷
discharge power), and the discharge loss `P_d/I_beam` in eV/ion.

## 4. Plasma chamber (`plasma/chamber.py`)
Ion particle balance fixes `Tₑ` from geometry and neutral density:

    n_n ⟨σ_iz v⟩(Tₑ) V = h u_B(Tₑ) (A_wall + A_screen)        (3)   u_B = √(Z e Tₑ/m_i)

The ion generation rate `N_g` follows from the absorbed discharge power:

    P_abs = P_d (c_conf − f_rad − f_other) = e [ N_g E_g + (N_g−N_x) E_w + N_x E_x ]      (4)
    E_g = E_iz + (K_exc/K_iz) E_exc,  E_w = V_float + 2.5 Tₑ,  E_x = 2.5 Tₑ + dV_p

and `nₑ = N_g / (h u_B A_loss)`. `n_i = nₑ/Z` (quasi-neutrality; an approximation, documented). **Regulated mode** (beam
current commanded): `N_g = N_x / f_geo` and (4) gives the required `P_d`. **Fixed mode** (`discharge_power_w` given): (4)
gives `N_g` for the imposed extraction; if `f_geo N_g < N_x` the plasma cannot supply the beam → `INVALID`. With no
beam current given, extraction is plasma-limited and solved self-consistently with neutral depletion (eqs. 1–4).

Discharge budget (`plasma/losses.py`) — residual always reported:
`P_d = P_ion + P_exc + P_ion_potential + P_wall + P_rad + P_electron_loss + P_other`
(`P_ion_potential = N_x e dV_p` is the one explicit extension of the six-channel identity).

## 5. Extraction (`extraction/`)
Potentials relative to the neutraliser common: plasma `V_s + dV_p`, screen `V_b`, accelerator `−|V_a|`, plume `V_c`.
Extraction voltage `V_ext = V_b + |V_a|`, mean field `V_ext/gap`.

Space-charge limit — **planar Child–Langmuir, reduced-order**:

    J = (4/9) ε₀ √(2q/m_i) V_ext^{3/2} / l_e²,   l_e = √((l_g + t_s)² + d_s²/4)  (Kaufman),   I_CL = J N_ap π d_s²/4      (5)

Not valid for arbitrary geometry (meniscus shape, aperture/gap ratio, misalignment, thermal distortion are not modelled).
Perveance ratio `p = I_ext/I_CL`. Interception and divergence are parametric (DEMONSTRATION coefficients):

    f_int = f₀ m (1 + g x²),  x = max(0, p−p_opt)/(1−p_opt)         σ_div = σ₀ [1 + k ((p−p_opt)/p_opt)²]      (6)

`I_beam = I_ext (1 − f_int)`, `I_acc = f_int I_ext`. Commanded `I_beam > I_CL` is reported (`INVALID`, margin negative),
never clamped. In plasma-limited mode, extraction is physically limited to `I_CL` and flagged `LIMIT (space_charge_limited)`.

## 6. Acceleration, beam, thrust (`acceleration/`, `thrust/`)
`E = qV`, `v = √(2qV/m_i)`. Three velocities: **ideal** (`V_b`), **modelled effective** (`V_eff = V_b + dV_p − V_c`),
**calibrated** (`× beam.velocity_calibration_factor`; `None` if not provided).
Beam divergence: Rayleigh polar angle `p(θ) = (θ/σ²) exp(−θ²/2σ²)`, `γ = ⟨cos θ⟩` by Gauss–Legendre.

    ṁ_ion = (I_b/Ze) m_i,   F_ideal = ṁ_ion v(V_b),   F_gross = ṁ_ion v_eff,   F_axial = ṁ_ion v_eff γ,   divergence loss = F_gross − F_axial

Cold-gas momentum `ṁ √(πkT/2m_a)` of chamber neutrals, re-emitted intercepted atoms and neutraliser flow is added.
`Isp = F/(ṁ g₀)` is reported on total, main-line and beam-ion flow.

## 7. Efficiencies (`thrust/efficiency.py`)
Exact identity for the ion-beam thrust efficiency:
`F_ion²/(2 ṁ_tot P_in) = η_m · γ² · (V_eff/V_b) · (I_b V_b/P_in)` (checked to 1e-9 in the validation suite).
Also reported: chamber utilisation, ionisation, extraction, grid transmission, neutralisation, PPU,
`η_thruster = P_jet/P_out`, `η_overall = P_jet/P_in`, with `P_jet = F²/(2ṁ_tot)`. `T/P` in N/kW and mN/kW.

## 8. Neutraliser (`neutraliser/`)
Commanded emission (default `1.10 I_b`), capability `I_max × readiness × health`, delivered
`min(η_n I_cmd, capability)`. `charge_imbalance = I_b − delivered`; positive ⇒ un-neutralised beam ⇒ `INVALID`.
Heater + keeper power is neutraliser heat. Readiness is a first-order lag (not thermionic physics).

## 9. Power and energy balance (`power/`, `diagnostics/`)
PPU: every stage `P_in = P_out/η`, common input stage, `P_loss = P_in − P_out`. Supplies: beam `V_b I_ext`, accelerator
`|V_a| I_acc`, discharge `P_d`, neutraliser, auxiliary. Energy ledger, evaluated at every step with a tolerance:

    P_input = P_beam + P_ionisation + P_grid_loss + P_neutraliser + P_thermal + P_other (+ P_stored)

`P_beam = I_b V_eff`; `P_ionisation = I_b E_iz` (carried in the beam); `P_grid_loss` = heat on the grid node
(`I_acc (V_b+|V_a|+dV_p+E_iz)` + screen-web share of wall heat); `P_thermal` = chamber + PPU + structure heat + escaped
radiation; `P_other = I_b V_c` (plume coupling); `P_stored` = discharge energy-reservoir change (transients only).
`P_input` comes from the PPU chain and the right-hand side from independent physical terms; a residual beyond tolerance
prints `ENERGY BALANCE: FAIL` and makes the point `INVALID`. Mass balance
`ṁ_in = ṁ_ion + ṁ_neutral + ṁ_loss` is handled the same way (electron mass restored on neutralisation is an explicit term).

## 10. Thermal (`thermal/`)
`C_i dT_i/dt = Q_gen,i − Σ G_ij (T_i − T_j) − ε_i σ A_i (T_i⁴ − T_env⁴)` on nodes chamber, grids, neutraliser, PPU, structure.
Steady state by Newton with the analytic (symmetric, positive-definite) Jacobian; transients by RK4. The chamber temperature
sets the neutral speed, so the steady-state solver iterates physics ↔ thermal to the configured tolerances.

## 11. Time domain (`simulation/transient.py`)
Each row of the history is a consistent snapshot at time `t` (evaluate → record → advance). Exact exponential lags
`x ← target + (x − target) e^{−dt/τ}` for flow, grid voltages, discharge supply, PPU outputs, plasma coupling and neutraliser
readiness. Beam current is *not* commanded: it is what the plasma supplies through the instantaneous extraction voltage,
limited by space charge. Shutdown reverses the sequence (beam → grids → neutraliser → plasma → propellant → cool-down;
cool-down ends when every node has shed 90 % of its peak excursion). The plasma lag is an energy reservoir `U = τ_plasma P_plasma`;
its change is `P_stored` in the ledger and integrates to zero over a complete cycle.

## 12. Degradation (`simulation/degradation.py`)
Each coefficient carries `value, units, source, uncertainty, validity_range`; the shipped values are placeholders marked
DEMONSTRATION — **no lifetime figures are invented**. Using a driver outside its validity range produces a warning.
`calibrate_coefficient` fits a slope-through-origin with standard error and sets the validity range to the data range.
