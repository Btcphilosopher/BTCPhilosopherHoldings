# Architecture

```
configuration.py   Pydantic models (units via Pint at the boundary, SI inside). EngineConfig, OperatingPoint
constants.py       CODATA via astropy.constants           units.py   Pint registry, to_si, unit_of
propellant/        species (registry), feed (flow split), flow (particle/mass flow helpers)
plasma/            ionisation (Numba Lotz), electrons, ions, density, losses (discharge budget), chamber (global model)
extraction/        grids (geometry), sheath (potential ladder), space_charge (Child-Langmuir), current (interception, divergence)
acceleration/      electrostatic, velocity (ideal / effective / calibrated), beam (divergence distribution)
neutraliser/       current (emission logic), neutraliser (power, heat)
thrust/            thrust (momentum flow), specific_impulse, efficiency (separate efficiencies, T/P)
power/             electrical (PPU), discharge, grid_power, (losses ledger lives in diagnostics/)
thermal/           radiation, model (lumped network)
diagnostics/       energy_balance, mass_balance, convergence
simulation/        state (IonEngineState and sub-states) · engine (the whole physics chain) · solver (steady state)
                   transient + timestep + scenarios (state machine) · limits · faults · degradation · lifetime
                   sweeps (sweeps, maps, Monte Carlo) · telemetry · digital_twin
reporting/         plots · report (HTML) · export (JSON / CSV / Parquet / HDF5)
console/           server (stdlib HTTP, model-backed API) · index.html (vanilla JS + Plotly)
results.py         SimulationResult        validation.py   independent checks        cli.py
```

**Single source of numbers.** `simulation/engine.py::evaluate` is the one function that assembles the physics chain
(`Drivers + temperatures + HealthState → IonEngineState`). The steady solver, transient simulator, sweeps, Monte Carlo,
fault reports, digital twin, exporters, report and console all call it (directly or via `solve_steady_state`). There is no other
path from input to displayed value. `IonEngineState` is a tree of dataclasses and serialises with `to_dict()`.

**Console traceability.** The browser holds no physics. It POSTs inputs to `/api/evaluate`, `/api/curves`, `/api/transient`
and renders the JSON that the Python model returns; each table row prints its state path (e.g. `beam_state.ion_velocity_effective_m_s`).
The calculation chain panel is `IonEngineState.calculation_chain`.

**Failure policy.** Invalid *inputs* (negative flow, wrong dimension, unknown keys) raise at construction. Invalid *operating
points* (over the space-charge limit, propellant-starved, un-neutralised beam, failed balance) are computed, reported with their
true values, and labelled `INVALID` — sweeps and Monte Carlo keep them and mark them rather than dropping them.

**Extending.** New species: `register_species(PropellantSpecies(...))` or `propellant.custom` in YAML. New fault: add to `faults.py`
(`FAULT_NAMES`, `apply_fault`, optionally `CHAINS`). New limit: add a check in `limits.py`. New sweep variable: add to `SWEEPABLE`.
