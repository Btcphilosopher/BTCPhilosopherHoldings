# Validation

`ion-core validate` (and `validation/run_validation.py`, which also writes `validation/latest_report.json`) runs 32 checks.
Each compares a model output with a value obtained by a **different route**; tolerances are tight and stated per check.

| topic | reference route | tolerance |
|---|---|---|
| ion kinetic energy `E = qV` | Pint closed form | 1e-9 |
| ion velocity `v = √(2E/m)` (ideal, effective) | Pint closed form; astropy.units/constants route for Xe⁺ at 1 kV | 1e-9 / 1e-12 |
| beam current `I = qṄ`, ion mass flow `ṁ = Ṅ m_i`, beam power `P = VI`, kinetic power `½ṁv²` | closed form | 1e-9 |
| Child–Langmuir current density | closed form and Pint dimensional check | 1e-9 |
| Child–Langmuir validity | finite-difference residual of Poisson's equation for `φ = V (x/d)^{4/3}` | 1e-4 |
| `V^{3/2}` scaling | `J(4V)/J(V) = 8` | 1e-12 |
| thrust `F = ṁ v` (no divergence), axial thrust with `⟨cos θ⟩` | momentum flow; `scipy.integrate.quad` of the Rayleigh integral | 1e-9 |
| specific impulse, thrust-to-power | closed form; Pint dimension `s` | 1e-9 |
| radiative rejection `εσA(T⁴−Tenv⁴)` | Pint with the registry's σ | 1e-6 |
| isolated-node equilibrium | analytic `T = (Q/εσA + Tenv⁴)^{1/4}` | 1e-9 |
| thermal energy balance | `ΣQ_gen = ΣQ_rad` at steady state | 1e-6 |
| power balance (9 operating points) | independent ledger vs PPU input | 1e-3 (tolerance configured) |
| mass balance (9 operating points) | independent ledger vs flow input | 1e-6 |
| balance check can fail | deliberately unbalanced ledger must report `FAIL` | exact |
| ionisation rate coefficient | `scipy.integrate.quad` of the Lotz cross-section × Maxwellian | 1e-5 |
| ion particle balance, discharge budget closure | independent evaluation | 1e-9 |
| efficiency decomposition | `η_m γ² (V_eff/V_b)(I_bV_b/P_in)` | 1e-9 |
| species swap (krypton, argon) | closed form with the selected species mass | 1e-9 |

Honest scope: this validates **internal correctness** (the code implements the stated equations, units are consistent,
conservation laws close, limiting cases and scalings hold). It does **not** validate the model against thruster test data;
no such data was used, and the DEMONSTRATION parameters would have to be replaced and calibrated first
(`DigitalTwin.calibrate` and `calibrate_coefficient` are provided for that).

Two defects were found and fixed while building the suite, kept here because they show what the checks are for:
a hard-coded "literature" xenon speed that was wrong (the model was right; the reference is now an independent astropy
computation) and a trapezoid rule in the ionisation integral that was 0.05 % low (now Simpson).
