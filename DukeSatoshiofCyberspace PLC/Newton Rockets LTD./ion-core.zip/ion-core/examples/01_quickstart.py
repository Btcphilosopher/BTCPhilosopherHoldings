"""Steady-state solve: every link of the electrical power -> thrust chain."""
from ion_core.configuration import EngineConfig, OperatingPoint
from ion_core.simulation.solver import solve_steady_state

cfg = EngineConfig()  # DEMONSTRATION parameters, xenon
op = OperatingPoint(mass_flow_kg_s=3.0e-6, beam_voltage_v=1100.0, beam_current_a=1.76)
st = solve_steady_state(cfg, op)

print("CALCULATION CHAIN")
for c in st.calculation_chain:
    print(f"  {c['step']:<24} {c['value']:>14.6g} {c['unit']:<8} {c['symbol']} = {c['formula']}")
print()
print(st.energy_balance.message)
print(st.mass_balance.message)
print("limits:", st.limits.status)
e = st.performance_state.efficiencies
print(f"eta: utilisation {e['propellant_utilisation']:.3f}  ionisation {e['ionisation']:.3f}  extraction {e['extraction']:.3f}  "
      f"acceleration {e['acceleration']:.3f}  PPU {e['ppu']:.3f}  thruster {e['thruster']:.3f}  overall {e['overall']:.3f}")

# a different propellant: only the species name changes
kr = solve_steady_state(cfg.with_updates({"propellant.species": "krypton"}),
                        OperatingPoint(mass_flow_kg_s=2.0e-6, beam_voltage_v=1100.0, beam_current_a=1.76))
print(f"krypton: thrust {kr.performance_state.thrust_n * 1e3:.1f} mN, Isp {kr.performance_state.isp_s:.0f} s")
