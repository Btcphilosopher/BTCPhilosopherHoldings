"""0 -> nominal thrust -> hold -> shutdown -> cool-down, with balances checked at every step."""
from pathlib import Path

from ion_core.configuration import EngineConfig
from ion_core.reporting import plots
from ion_core.simulation.scenarios import full_cycle_scenario
from ion_core.simulation.transient import run_transient

cfg = EngineConfig()
tr = run_transient(cfg, full_cycle_scenario(hold_s=700.0))
for t in tr.transitions:
    print(f"{t['t_s']:8.1f} s  {t['from']:<17} -> {t['to']}")
print(f"energy-balance failures: {tr.energy_balance_failures}   mass-balance failures: {tr.mass_balance_failures}")
print(f"peak thrust {tr.history['thrust_n'].max() * 1e3:.2f} mN   peak grid temperature {tr.history['temp_grids_k'].max():.1f} K")
out = Path("example_output")
out.mkdir(exist_ok=True)
plots.startup_plot(tr.history).savefig(out / "startup.png", dpi=120, bbox_inches="tight")
plots.transient_plot(tr.history).savefig(out / "full_cycle.png", dpi=120, bbox_inches="tight")
