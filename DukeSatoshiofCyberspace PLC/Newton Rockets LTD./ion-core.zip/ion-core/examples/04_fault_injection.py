"""Fault -> physics chain -> operating limit."""
from ion_core.configuration import EngineConfig
from ion_core.simulation.faults import Fault, fault_causal_report

cfg = EngineConfig().with_updates({"limits.max_grid_temperature_k": 420.0})  # tighter limit for the demonstration
r = fault_causal_report(cfg, cfg.operating_point, Fault("grid_interception_increase", magnitude=12.0))
print(f"{r['baseline_limit_status']} -> {r['faulted_limit_status']}")
for c in r["chain"]:
    print(f"  {c['quantity']:<28} {c['baseline']:>12.5g} -> {c['faulted']:<12.5g} {c['unit']}")
print(*r["faulted_limit_messages"], sep="\n")
