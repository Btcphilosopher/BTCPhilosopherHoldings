"""Synthetic telemetry from a 'degraded' engine, then calibrate the nominal model against it."""
from ion_core.configuration import EngineConfig
from ion_core.simulation.digital_twin import DigitalTwin
from ion_core.simulation.scenarios import Event, Scenario
from ion_core.simulation.telemetry import synthetic_telemetry
from ion_core.simulation.transient import run_transient

nominal = EngineConfig()
truth_cfg = nominal.with_updates({"chamber.primary_confinement": 0.74, "grids.interception_fraction_base": 0.016})
history = run_transient(truth_cfg, Scenario("truth", 3600.0, [Event(0, "start")], stop_when_off=False)).history
tel = synthetic_telemetry(history, truth_cfg.with_updates({"telemetry.noise_rel": 0.003}))

twin = DigitalTwin(nominal)
fit = twin.calibrate(tel[tel["time_s"] > 3200], parameters={"chamber.primary_confinement": (0.5, 0.95),
                                                           "grids.interception_fraction_base": (5e-4, 0.05)},
                     channels=["input_power_w", "discharge_current_a", "grid_temperature_k"], thermal_settled=True)
print("calibrated:", {k: round(v, 4) for k, v in fit.parameters.items()}, " (truth 0.74, 0.016)")
print(f"cost {fit.cost_before:.1f} -> {fit.cost_after:.2f}")
est = DigitalTwin(fit.config).run(tel[tel["time_s"] > 3300].iloc[::50])
print(est[["time_s", "thrust_estimate_n", "electron_temperature_ev", "grid_margin_k"]].tail(3).to_string(index=False))
