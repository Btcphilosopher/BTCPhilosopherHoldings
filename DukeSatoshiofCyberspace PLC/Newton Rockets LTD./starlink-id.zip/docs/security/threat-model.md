# STARLINK ID — SECURITY THREAT MODEL & ARCHITECTURE

## 1. Executive Summary
Starlink ID fundamentally separates phone identity from mobile carrier telephone numbers and SIM cards. Identity is rooted in hardware-backed asymmetric key pairs generated inside Android KeyStore / StrongBox TEE, authorized exclusively via Android BiometricPrompt.

---

## 2. Threat Vector Analysis & Countermeasures

| Threat Vector | Attack Scenario | Countermeasure & Protection |
| :--- | :--- | :--- |
| **Lost or Stolen Device** | Adversary physically gains access to phone. | Private key resides inside KeyStore/StrongBox TEE with non-exportable flag. Key usage requires biometric unlock via BiometricPrompt. Plaintext key material cannot be read from memory or flash. |
| **SIM Swap Attack** | Adversary attempts port-out or SIM hijack. | **Immune.** Application uses zero telephone numbers, SMS verification codes, or SIM identities. Identity is bound to hardware public key signatures (`nid:sha256:...`). |
| **Rooted Device / OS Compromise** | Malware executes with elevated root privileges. | Keys generated in StrongBox/TEE secure element. Even root users cannot export hardware private keys. Signed messages require TEE execution. |
| **Public Key Spoofing / MitM** | Adversary impersonates contact during key exchange. | Contacts display verified NID fingerprints and QR code signatures. Key changes trigger `KEY_CHANGED_WARNING` alerts. |
| **Message Tampering & Replay** | Adversary intercepts and re-transmits encrypted packets. | Every payload is signed via ECDSA secp256r1 with incremental timestamps and unique message UUIDs verified before decryption. |
| **Metadata Leakage** | Transport-level traffic analysis. | Payloads wrapped in AES-256-GCM authenticated encryption. Network transport layer operates transparently over Wi-Fi, Cellular, or Satellite. |

---

## 3. Cryptographic Specification
- **Algorithm**: Elliptic Curve (EC) `secp256r1` (P-256)
- **Signature Digest**: SHA-256 (`SHA256withECDSA`)
- **Symmetric Cipher**: AES-256-GCM (`AES/GCM/NoPadding`)
- **Key Storage**: Android KeyStore / StrongBox TEE
- **Biometric Authorization**: Android `BiometricPrompt`
