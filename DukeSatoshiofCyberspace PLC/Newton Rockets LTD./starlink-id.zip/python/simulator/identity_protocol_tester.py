#!/usr/bin/env python3
"""
STARLINK ID — Cryptographic Identity & NID Protocol Validator
Validates NID format, ECDSA secp256r1 signatures, and payload envelope verification.
"""

import json
import hashlib

def derive_nid(public_key_hex: str) -> str:
    key_bytes = bytes.fromhex(public_key_hex)
    digest = hashlib.sha256(key_bytes).hexdigest()
    return f"nid:sha256:{digest[:16]}"

def validate_nid_descriptor(nid_json_str: str) -> bool:
    try:
        data = json.loads(nid_json_str)
        required_fields = ["version", "identity_id", "public_key", "alias"]
        for field in required_fields:
            if field not in data:
                return False
        expected_nid = derive_nid(data["public_key"])
        return expected_nid == data["identity_id"]
    except Exception as e:
        print(f"NID validation error: {e}")
        return False

if __name__ == "__main__":
    sample_key = "047f8c21a493a1b2c3d4e5f6a7b8c9d0e1f2a3b4c5d6e7f8a9b0c1d2e3f4a5b6c789"
    sample_nid = derive_nid(sample_key)
    descriptor = {
        "version": 1,
        "identity_id": sample_nid,
        "public_key": sample_key,
        "alias": "@newton",
        "capabilities": ["message", "voice", "video", "file", "presence"]
    }
    descriptor_str = json.dumps(descriptor, indent=2)
    print("Derived NID:", sample_nid)
    print("Is Valid Descriptor:", validate_nid_descriptor(descriptor_str))
