#!/usr/bin/env python3
"""
STARLINK ID — Satellite Link & Connectivity Simulation Suite
Simulates Low Earth Orbit (LEO) satellite pass, Doppler latency, weather fade, and handover.
"""

import time
import random

class SatelliteSimulator:
    def __init__(self, constellation_name="Starlink LEO Shell-4"):
        self.constellation_name = constellation_name
        self.orbit_elevation_deg = 30
        self.is_obstructed = False
        self.is_rain_fade = False

    def step_telemetry(self):
        self.orbit_elevation_deg = (self.orbit_elevation_deg + 2) % 90
        elevation = 15 + self.orbit_elevation_deg

        if self.is_obstructed:
            return {
                "connected": False,
                "link_state": "OBSTRUCTED",
                "latency_ms": 250,
                "signal_percent": 10,
                "download_mbps": 0.2,
                "upload_mbps": 0.05,
                "elevation_deg": elevation
            }

        base_signal = int(70 + (elevation * 0.4)) + random.randint(-2, 2)
        latency = 38 + random.randint(0, 10)
        dl = 18.0 + random.uniform(-2.0, 3.0)
        ul = 3.5 + random.uniform(-0.5, 1.0)
        state = "CONNECTED_LEO"

        if self.is_rain_fade:
            base_signal = max(15, base_signal - 35)
            latency += 40
            dl *= 0.3
            ul *= 0.2
            state = "DEGRADED_WEATHER"

        return {
            "connected": True,
            "link_state": state,
            "latency_ms": latency,
            "signal_percent": min(100, max(0, base_signal)),
            "download_mbps": round(dl, 1),
            "upload_mbps": round(ul, 1),
            "elevation_deg": elevation
        }

if __name__ == "__main__":
    sim = SatelliteSimulator()
    print("Starting Starlink LEO Link Simulation Loop...")
    for i in range(5):
        telemetry = sim.step_telemetry()
        print(f"[{i+1}] State: {telemetry['link_state']} | Signal: {telemetry['signal_percent']}% | Latency: {telemetry['latency_ms']}ms | DL: {telemetry['download_mbps']} Mbps")
        time.sleep(0.5)
