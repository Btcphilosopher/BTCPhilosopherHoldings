package com.example.networking

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlin.random.Random

/**
 * Satellite Connectivity Adapter.
 * Bridges Android platform ConnectivityManager for active IP checks with a high-fidelity
 * Satellite Simulation Engine that models LEO orbit passes, Doppler latency, weather fade, and obstructions.
 */
class SatelliteConnectivityAdapter(
    private val context: Context,
    private val scope: CoroutineScope
) {
    private val connectivityManager =
        context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager

    private val _telemetry = MutableStateFlow(
        NetworkTelemetry(
            transportType = TransportType.SATELLITE,
            isConnected = true,
            signalQualityPercent = 88,
            latencyMs = 42,
            downloadSpeedMbps = 18.4f,
            uploadSpeedMbps = 3.8f,
            satelliteElevationDegrees = 62,
            satelliteConstellation = "Starlink LEO Shell-4",
            linkState = SatelliteLinkState.CONNECTED_LEO
        )
    )
    val telemetry: StateFlow<NetworkTelemetry> = _telemetry.asStateFlow()

    private val _userPolicy = MutableStateFlow(ConnectivityPolicy.AUTO_SATELLITE_BACKUP)
    val userPolicy: StateFlow<ConnectivityPolicy> = _userPolicy.asStateFlow()

    // Simulation Override Toggles
    var isSimulatedObstructed: Boolean = false
        private set
    var isSimulatedRainFade: Boolean = false
        private set
    var isSimulatedOffline: Boolean = false
        private set

    init {
        startTelemetrySimulationLoop()
    }

    fun setPolicy(policy: ConnectivityPolicy) {
        _userPolicy.value = policy
    }

    fun toggleSimulatedObstruction() {
        isSimulatedObstructed = !isSimulatedObstructed
    }

    fun toggleSimulatedRainFade() {
        isSimulatedRainFade = !isSimulatedRainFade
    }

    fun toggleSimulatedOffline() {
        isSimulatedOffline = !isSimulatedOffline
    }

    fun forceTransportType(transportType: TransportType) {
        val current = _telemetry.value
        _telemetry.value = when (transportType) {
            TransportType.SATELLITE -> current.copy(
                transportType = TransportType.SATELLITE,
                isConnected = true,
                signalQualityPercent = 85,
                latencyMs = 44,
                downloadSpeedMbps = 19.2f,
                uploadSpeedMbps = 4.1f,
                linkState = SatelliteLinkState.CONNECTED_LEO
            )
            TransportType.WIFI -> current.copy(
                transportType = TransportType.WIFI,
                isConnected = true,
                signalQualityPercent = 95,
                latencyMs = 12,
                downloadSpeedMbps = 120.0f,
                uploadSpeedMbps = 25.0f,
                linkState = SatelliteLinkState.DISCONNECTED
            )
            TransportType.CELLULAR -> current.copy(
                transportType = TransportType.CELLULAR,
                isConnected = true,
                signalQualityPercent = 78,
                latencyMs = 28,
                downloadSpeedMbps = 45.0f,
                uploadSpeedMbps = 8.5f,
                linkState = SatelliteLinkState.DISCONNECTED
            )
            TransportType.OFFLINE -> current.copy(
                transportType = TransportType.OFFLINE,
                isConnected = false,
                signalQualityPercent = 0,
                latencyMs = 0,
                downloadSpeedMbps = 0.0f,
                uploadSpeedMbps = 0.0f,
                linkState = SatelliteLinkState.DISCONNECTED
            )
        }
    }

    private fun startTelemetrySimulationLoop() {
        scope.launch(Dispatchers.Default) {
            var orbitAngle = 30
            while (true) {
                delay(2000)

                if (_telemetry.value.transportType != TransportType.SATELLITE) continue

                if (isSimulatedOffline) {
                    _telemetry.value = _telemetry.value.copy(
                        isConnected = false,
                        signalQualityPercent = 0,
                        latencyMs = 0,
                        downloadSpeedMbps = 0f,
                        uploadSpeedMbps = 0f,
                        linkState = SatelliteLinkState.DISCONNECTED
                    )
                    continue
                }

                orbitAngle = (orbitAngle + 2) % 90
                val elevation = 15 + orbitAngle

                if (isSimulatedObstructed) {
                    _telemetry.value = _telemetry.value.copy(
                        isConnected = false,
                        signalQualityPercent = 12,
                        latencyMs = 240,
                        downloadSpeedMbps = 0.5f,
                        uploadSpeedMbps = 0.1f,
                        satelliteElevationDegrees = elevation,
                        linkState = SatelliteLinkState.OBSTRUCTED
                    )
                    continue
                }

                val noise = Random.nextInt(-3, 4)
                var signal = (70 + (elevation * 0.4)).toInt() + noise
                var latency = (38 + Random.nextInt(0, 12))
                var dl = 16.0f + Random.nextFloat() * 4.0f
                var ul = 3.2f + Random.nextFloat() * 1.5f
                var state = SatelliteLinkState.CONNECTED_LEO

                if (isSimulatedRainFade) {
                    signal = (signal - 35).coerceAtLeast(15)
                    latency += 45
                    dl *= 0.3f
                    ul *= 0.2f
                    state = SatelliteLinkState.DEGRADED_WEATHER
                }

                _telemetry.value = _telemetry.value.copy(
                    isConnected = true,
                    signalQualityPercent = signal.coerceIn(0, 100),
                    latencyMs = latency,
                    downloadSpeedMbps = (dl * 10).toInt() / 10f,
                    uploadSpeedMbps = (ul * 10).toInt() / 10f,
                    satelliteElevationDegrees = elevation,
                    linkState = state
                )
            }
        }
    }

    /**
     * Inspects actual Android system internet status.
     */
    fun checkRealSystemConnectivity(): Boolean {
        val activeNetwork = connectivityManager.activeNetwork ?: return false
        val capabilities = connectivityManager.getNetworkCapabilities(activeNetwork) ?: return false
        return capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }
}
