package com.example.identity

import org.json.JSONArray
import org.json.JSONObject

enum class TrustLevel {
    VERIFIED,
    UNVERIFIED,
    KEY_CHANGED_WARNING,
    REVOKED
}

data class Identity(
    val identityId: String,
    val alias: String,
    val publicKey: String,
    val keyAlgorithm: String = "EC secp256r1",
    val keyVersion: Int = 1,
    val createdAt: Long = System.currentTimeMillis(),
    val isHardwareBacked: Boolean = true,
    val isStrongBoxBacked: Boolean = false,
    val isBiometricProtected: Boolean = true,
    val isRecoveryConfigured: Boolean = true
)

data class NID(
    val version: Int = 1,
    val identityId: String,
    val publicKey: String,
    val alias: String,
    val capabilities: List<String> = listOf("message", "voice", "video", "file", "presence")
) {
    fun toJson(): String {
        val json = JSONObject()
        json.put("version", version)
        json.put("identity_id", identityId)
        json.put("public_key", publicKey)
        json.put("alias", alias)
        val capsArray = JSONArray()
        capabilities.forEach { capsArray.put(it) }
        json.put("capabilities", capsArray)
        return json.toString(2)
    }

    companion object {
        fun parseJson(jsonStr: String): NID {
            val json = JSONObject(jsonStr)
            val version = json.optInt("version", 1)
            val identityId = json.getString("identity_id")
            val publicKey = json.getString("public_key")
            val alias = json.optString("alias", "@anonymous")
            val caps = mutableListOf<String>()
            val capsArray = json.optJSONArray("capabilities")
            if (capsArray != null) {
                for (i in 0 until capsArray.length()) {
                    caps.add(capsArray.getString(i))
                }
            } else {
                caps.addAll(listOf("message", "voice", "video", "file", "presence"))
            }
            return NID(version, identityId, publicKey, alias, caps)
        }
    }
}

data class DeviceIdentity(
    val deviceId: String,
    val deviceName: String,
    val isCurrentDevice: Boolean,
    val isAuthorized: Boolean,
    val authorizedAt: Long
)
