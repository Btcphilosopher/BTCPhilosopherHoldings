package com.example.storage

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.example.identity.TrustLevel

@Entity(tableName = "contacts")
data class ContactEntity(
    @PrimaryKey val identityId: String,
    val publicKey: String,
    val alias: String,
    val displayName: String,
    val trustLevel: String, // VERIFIED, UNVERIFIED, KEY_CHANGED_WARNING, REVOKED
    val lastSeen: Long = System.currentTimeMillis(),
    val avatarUrl: String? = null,
    val previousPublicKey: String? = null,
    val keyChangeWarningAck: Boolean = false
)

@Entity(tableName = "messages")
data class MessageEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val messageId: String,
    val conversationIdentityId: String,
    val senderIdentityId: String,
    val receiverIdentityId: String,
    val content: String, // Plaintext for UI after decryption or local display
    val encryptedPayloadBase64: String,
    val signatureBase64: String,
    val isVerifiedSignature: Boolean,
    val transportUsed: String, // SATELLITE, WIFI, CELLULAR, OFFLINE_QUEUED
    val isOutgoing: Boolean,
    val timestamp: Long = System.currentTimeMillis(),
    val status: String // QUEUED, SENT, DELIVERED, READ
)

@Entity(tableName = "calls")
data class CallEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val callId: String,
    val peerIdentityId: String,
    val peerAlias: String,
    val callType: String, // VOICE, VIDEO
    val isIncoming: Boolean,
    val durationSeconds: Int,
    val transportUsed: String,
    val timestamp: Long = System.currentTimeMillis(),
    val status: String // COMPLETED, MISSED, DECLINED
)

@Entity(tableName = "audit_logs")
data class AuditLogEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val timestamp: Long = System.currentTimeMillis(),
    val category: String, // BIOMETRIC, KEYSTORE, SESSION, NETWORK, MESSAGING
    val eventDescription: String,
    val severity: String // INFO, WARNING, CRITICAL
)
