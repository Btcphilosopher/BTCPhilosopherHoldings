package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Nfc
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.storage.ContactEntity
import com.example.ui.theme.AerospaceCard
import com.example.ui.theme.AerospaceCardBorder
import com.example.ui.theme.AerospaceNavy
import com.example.ui.theme.AerospaceTextMuted
import com.example.ui.theme.AerospaceTextPrimary
import com.example.ui.theme.AerospaceTextSecondary
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.SatelliteAmber
import com.example.ui.theme.SecurityAlertRed
import com.example.ui.theme.VerifiedGreen

@Composable
fun ContactsScreen(
    contacts: List<ContactEntity>,
    onAddContactByNid: (nidStr: String) -> Unit
) {
    var showAddDialog by remember { mutableStateOf(false) }
    var selectedContactDetail by remember { mutableStateOf<ContactEntity?>(null) }

    if (showAddDialog) {
        AddContactModal(
            onDismiss = { showAddDialog = false },
            onAdd = { nid ->
                onAddContactByNid(nid)
                showAddDialog = false
            }
        )
    }

    if (selectedContactDetail != null) {
        ContactTrustDetailModal(
            contact = selectedContactDetail!!,
            onDismiss = { selectedContactDetail = null }
        )
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(AerospaceNavy)
            .padding(16.dp)
            .testTag("contacts_screen")
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "CONTACT DIRECTORY",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    color = AerospaceTextPrimary,
                    letterSpacing = 2.sp
                )
                Text(
                    text = "Authenticated Public Key Directory",
                    fontSize = 11.sp,
                    color = AerospaceTextMuted
                )
            }

            Button(
                onClick = { showAddDialog = true },
                colors = ButtonDefaults.buttonColors(containerColor = CyberCyan),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.testTag("add_contact_button")
            ) {
                Icon(imageVector = Icons.Default.Add, contentDescription = "Add Contact", tint = Color.Black)
                Spacer(modifier = Modifier.width(4.dp))
                Text(text = "Add", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 12.sp)
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(contacts, key = { it.identityId }) { contact ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { selectedContactDetail = contact }
                        .border(
                            1.dp,
                            if (contact.trustLevel == "KEY_CHANGED_WARNING") SecurityAlertRed else AerospaceCardBorder,
                            RoundedCornerShape(12.dp)
                        ),
                    colors = CardDefaults.cardColors(containerColor = AerospaceCard),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(38.dp)
                                        .clip(CircleShape)
                                        .background(
                                            if (contact.trustLevel == "KEY_CHANGED_WARNING") SecurityAlertRed.copy(alpha = 0.2f)
                                            else CyberCyan.copy(alpha = 0.2f)
                                        ),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = contact.alias.take(2).uppercase(),
                                        fontWeight = FontWeight.Bold,
                                        color = if (contact.trustLevel == "KEY_CHANGED_WARNING") SecurityAlertRed else CyberCyan
                                    )
                                }

                                Spacer(modifier = Modifier.width(12.dp))

                                Column {
                                    Text(
                                        text = contact.alias,
                                        fontSize = 15.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = AerospaceTextPrimary
                                    )
                                    Text(
                                        text = contact.displayName,
                                        fontSize = 12.sp,
                                        color = AerospaceTextSecondary
                                    )
                                }
                            }

                            // Trust Badge
                            if (contact.trustLevel == "KEY_CHANGED_WARNING") {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(SecurityAlertRed.copy(alpha = 0.2f))
                                        .padding(horizontal = 8.dp, vertical = 4.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Warning,
                                        contentDescription = "Alert",
                                        tint = SecurityAlertRed,
                                        modifier = Modifier.size(14.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = "KEY CHANGED",
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = SecurityAlertRed
                                    )
                                }
                            } else {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(VerifiedGreen.copy(alpha = 0.15f))
                                        .padding(horizontal = 8.dp, vertical = 4.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Verified,
                                        contentDescription = "Verified",
                                        tint = VerifiedGreen,
                                        modifier = Modifier.size(14.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = "VERIFIED",
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = VerifiedGreen
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Text(
                            text = contact.identityId,
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace,
                            color = AerospaceTextMuted
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun AddContactModal(
    onDismiss: () -> Unit,
    onAdd: (String) -> Unit
) {
    var input by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = AerospaceCard,
        title = {
            Text(
                text = "ADD CRYPTOGRAPHIC CONTACT",
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace,
                color = CyberCyan
            )
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(
                    text = "Scan identity QR, paste NID JSON, or type identity handle.",
                    fontSize = 12.sp,
                    color = AerospaceTextSecondary
                )

                OutlinedTextField(
                    value = input,
                    onValueChange = { input = it },
                    placeholder = { Text("Paste NID or @alias...", color = AerospaceTextMuted) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("add_contact_input"),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = CyberCyan,
                        unfocusedBorderColor = AerospaceCardBorder,
                        focusedTextColor = AerospaceTextPrimary
                    )
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = { input = "@david" },
                        colors = ButtonDefaults.buttonColors(containerColor = AerospaceCardBorder),
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(imageVector = Icons.Default.QrCodeScanner, contentDescription = "Scan QR", tint = CyberCyan)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(text = "Scan QR", fontSize = 11.sp, color = CyberCyan)
                    }

                    Button(
                        onClick = { input = "@elena" },
                        colors = ButtonDefaults.buttonColors(containerColor = AerospaceCardBorder),
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(imageVector = Icons.Default.Nfc, contentDescription = "NFC", tint = SatelliteAmber)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(text = "NFC Tap", fontSize = 11.sp, color = SatelliteAmber)
                    }
                }
            }
        },
        confirmButton = {
            TextButton(
                onClick = {
                    if (input.isNotBlank()) onAdd(input.trim())
                }
            ) {
                Text(text = "Add Contact", color = CyberCyan, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(text = "Cancel", color = AerospaceTextMuted)
            }
        }
    )
}

@Composable
private fun ContactTrustDetailModal(
    contact: ContactEntity,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = AerospaceCard,
        title = {
            Text(
                text = "IDENTITY TRUST AUDIT",
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace,
                color = CyberCyan
            )
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                if (contact.trustLevel == "KEY_CHANGED_WARNING") {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = SecurityAlertRed.copy(alpha = 0.2f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Text(
                                text = "SECURITY ALERT: PUBLIC KEY CHANGED",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = SecurityAlertRed
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "The cryptographic identity key for ${contact.alias} has changed. This may indicate key rotation or device replacement.",
                                fontSize = 11.sp,
                                color = AerospaceTextPrimary
                            )
                        }
                    }
                }

                TrustField(label = "Alias", value = contact.alias)
                TrustField(label = "Identity NID", value = contact.identityId)
                TrustField(label = "Public Key", value = contact.publicKey)
                if (contact.previousPublicKey != null) {
                    TrustField(label = "Previous Public Key", value = contact.previousPublicKey)
                }
                TrustField(
                    label = "Verification Status",
                    value = if (contact.trustLevel == "VERIFIED") "✓ ECDSA Signature Validated" else "⚠️ Key Rotation Flagged",
                    highlightColor = if (contact.trustLevel == "VERIFIED") VerifiedGreen else SatelliteAmber
                )
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text(text = "Acknowledge", color = CyberCyan)
            }
        }
    )
}

@Composable
private fun TrustField(label: String, value: String, highlightColor: Color = AerospaceTextPrimary) {
    Column {
        Text(text = label, fontSize = 9.sp, fontWeight = FontWeight.Bold, color = AerospaceTextMuted)
        Text(text = value, fontSize = 11.sp, fontFamily = FontFamily.Monospace, color = highlightColor)
    }
}
