package com.example.security

import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyInfo
import android.security.keystore.KeyProperties
import android.util.Base64
import android.util.Log
import java.security.KeyFactory
import java.security.KeyPair
import java.security.KeyPairGenerator
import java.security.KeyStore
import java.security.PrivateKey
import java.security.PublicKey
import java.security.Signature
import java.security.spec.ECGenParameterSpec
import java.security.spec.X509EncodedKeySpec
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import java.security.MessageDigest

data class KeyAttestationInfo(
    val isHardwareBacked: Boolean,
    val isStrongBoxBacked: Boolean,
    val keyAlgorithm: String,
    val keySize: Int,
    val userAuthenticationRequired: Boolean,
    val keystoreAlias: String
)

class CryptoManager(private val context: Context) {

    private val keyStore: KeyStore = KeyStore.getInstance(ANDROID_KEYSTORE).apply {
        load(null)
    }

    companion object {
        private const val TAG = "StarlinkCrypto"
        private const val ANDROID_KEYSTORE = "AndroidKeyStore"
        private const val KEY_ALIAS_PREFIX = "starlink_id_key_"
        private const val AES_KEY_ALIAS = "starlink_id_aes_key"
        private const val SIGNATURE_ALGORITHM = "SHA256withECDSA"
        private const val AES_TRANSFORMATION = "AES/GCM/NoPadding"
        private const val GCM_TAG_LENGTH = 128
    }

    fun hasKey(identityAlias: String): Boolean {
        return keyStore.containsAlias(KEY_ALIAS_PREFIX + identityAlias)
    }

    /**
     * Generates a hardware-backed EC P-256 key pair inside Android KeyStore / StrongBox.
     * The private key never leaves secure hardware.
     */
    fun generateHardwareKeyPair(identityAlias: String, requireBiometricAuth: Boolean = false): KeyPair {
        val alias = KEY_ALIAS_PREFIX + identityAlias
        
        if (keyStore.containsAlias(alias)) {
            keyStore.deleteEntry(alias)
        }

        val kpg = KeyPairGenerator.getInstance(
            KeyProperties.KEY_ALGORITHM_EC,
            ANDROID_KEYSTORE
        )

        val builder = KeyGenParameterSpec.Builder(
            alias,
            KeyProperties.PURPOSE_SIGN or KeyProperties.PURPOSE_VERIFY
        )
            .setAlgorithmParameterSpec(ECGenParameterSpec("secp256r1"))
            .setDigests(KeyProperties.DIGEST_SHA256)

        // Check StrongBox availability
        val isStrongBoxSupported = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            context.packageManager.hasSystemFeature(PackageManager.FEATURE_STRONGBOX_KEYSTORE)
        } else false

        if (isStrongBoxSupported && Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            try {
                builder.setIsStrongBoxBacked(true)
            } catch (e: Exception) {
                Log.w(TAG, "StrongBox requested but failed, falling back to standard TEE: ${e.message}")
            }
        }

        if (requireBiometricAuth) {
            builder.setUserAuthenticationRequired(true)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                builder.setUserAuthenticationParameters(
                    0, // 0 means authentication is required for every key usage
                    KeyProperties.AUTH_BIOMETRIC_STRONG
                )
            }
        }

        kpg.initialize(builder.build())
        return kpg.generateKeyPair().also {
            Log.i(TAG, "Hardware KeyPair successfully generated for $alias. StrongBox=$isStrongBoxSupported")
        }
    }

    fun getPublicKey(identityAlias: String): PublicKey? {
        val alias = KEY_ALIAS_PREFIX + identityAlias
        val entry = keyStore.getEntry(alias, null) as? KeyStore.PrivateKeyEntry
        return entry?.certificate?.publicKey
    }

    fun getKeyAttestationInfo(identityAlias: String): KeyAttestationInfo {
        val alias = KEY_ALIAS_PREFIX + identityAlias
        val entry = keyStore.getEntry(alias, null) as? KeyStore.PrivateKeyEntry
        
        var isHardware = true
        var isStrongBox = false
        
        if (entry != null) {
            try {
                val factory = KeyFactory.getInstance(entry.privateKey.algorithm, ANDROID_KEYSTORE)
                val keyInfo = factory.getKeySpec(entry.privateKey, KeyInfo::class.java)
                isHardware = keyInfo.isInsideSecureHardware
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    isStrongBox = keyInfo.securityLevel == KeyProperties.SECURITY_LEVEL_STRONGBOX
                }
            } catch (e: Exception) {
                Log.w(TAG, "Could not inspect KeyInfo: ${e.message}")
            }
        }

        return KeyAttestationInfo(
            isHardwareBacked = isHardware,
            isStrongBoxBacked = isStrongBox,
            keyAlgorithm = "EC secp256r1",
            keySize = 256,
            userAuthenticationRequired = false,
            keystoreAlias = alias
        )
    }

    /**
     * Signs data using the hardware private key.
     */
    fun signData(identityAlias: String, data: ByteArray): ByteArray {
        val alias = KEY_ALIAS_PREFIX + identityAlias
        val entry = keyStore.getEntry(alias, null) as? KeyStore.PrivateKeyEntry
            ?: throw IllegalStateException("Key $alias not found in KeyStore")

        val signature = Signature.getInstance(SIGNATURE_ALGORITHM).apply {
            initSign(entry.privateKey)
            update(data)
        }
        return signature.sign()
    }

    /**
     * Verifies signature using a raw encoded public key or PublicKey object.
     */
    fun verifySignature(publicKeyHexOrBase64: String, data: ByteArray, signatureBytes: ByteArray): Boolean {
        return try {
            val keyBytes = decodeKeyString(publicKeyHexOrBase64)
            val keySpec = X509EncodedKeySpec(keyBytes)
            val keyFactory = KeyFactory.getInstance(KeyProperties.KEY_ALGORITHM_EC)
            val pubKey = keyFactory.generatePublic(keySpec)

            val signature = Signature.getInstance(SIGNATURE_ALGORITHM).apply {
                initVerify(pubKey)
                update(data)
            }
            signature.verify(signatureBytes)
        } catch (e: Exception) {
            Log.e(TAG, "Signature verification failed: ${e.message}")
            false
        }
    }

    /**
     * Derives canonical NID string from public key (e.g. nid:sha256:7f8c...)
     */
    fun deriveNidFromPublicKey(publicKey: PublicKey): String {
        val encoded = publicKey.encoded
        val digest = MessageDigest.getInstance("SHA-256").digest(encoded)
        val hex = digest.joinToString("") { "%02x".format(it) }
        return "nid:sha256:${hex.take(16)}"
    }

    fun deriveFullNidFromPublicKey(publicKeyHexOrBase64: String): String {
        val keyBytes = decodeKeyString(publicKeyHexOrBase64)
        val digest = MessageDigest.getInstance("SHA-256").digest(keyBytes)
        val hex = digest.joinToString("") { "%02x".format(it) }
        return "nid:sha256:${hex.take(16)}"
    }

    /**
     * Encrypts payload with AES-GCM-256.
     */
    fun encryptSymmetric(plaintext: String): String {
        val secretKey = getOrCreateSecretKey()
        val cipher = Cipher.getInstance(AES_TRANSFORMATION)
        cipher.init(Cipher.ENCRYPT_MODE, secretKey)
        
        val iv = cipher.iv
        val ciphertext = cipher.doFinal(plaintext.toByteArray(Charsets.UTF_8))
        
        val combined = ByteArray(iv.size + ciphertext.size)
        System.arraycopy(iv, 0, combined, 0, iv.size)
        System.arraycopy(ciphertext, 0, combined, iv.size, ciphertext.size)
        
        return Base64.encodeToString(combined, Base64.NO_WRAP)
    }

    /**
     * Decrypts payload with AES-GCM-256.
     */
    fun decryptSymmetric(encryptedBase64: String): String {
        val secretKey = getOrCreateSecretKey()
        val combined = Base64.decode(encryptedBase64, Base64.NO_WRAP)
        
        val ivSize = 12 // Standard GCM IV length
        if (combined.size < ivSize) throw IllegalArgumentException("Invalid ciphertext length")

        val iv = ByteArray(ivSize)
        val ciphertext = ByteArray(combined.size - ivSize)
        System.arraycopy(combined, 0, iv, 0, ivSize)
        System.arraycopy(combined, ivSize, ciphertext, 0, ciphertext.size)

        val cipher = Cipher.getInstance(AES_TRANSFORMATION)
        val spec = GCMParameterSpec(GCM_TAG_LENGTH, iv)
        cipher.init(Cipher.DECRYPT_MODE, secretKey, spec)

        val decrypted = cipher.doFinal(ciphertext)
        return String(decrypted, Charsets.UTF_8)
    }

    private fun getOrCreateSecretKey(): SecretKey {
        if (!keyStore.containsAlias(AES_KEY_ALIAS)) {
            val keyGenerator = KeyGenerator.getInstance(
                KeyProperties.KEY_ALGORITHM_AES,
                ANDROID_KEYSTORE
            )
            keyGenerator.init(
                KeyGenParameterSpec.Builder(
                    AES_KEY_ALIAS,
                    KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
                )
                    .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                    .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                    .setKeySize(256)
                    .build()
            )
            keyGenerator.generateKey()
        }
        val entry = keyStore.getEntry(AES_KEY_ALIAS, null) as KeyStore.SecretKeyEntry
        return entry.secretKey
    }

    private fun decodeKeyString(keyStr: String): ByteArray {
        return try {
            Base64.decode(keyStr, Base64.NO_WRAP)
        } catch (e: Exception) {
            // Fallback hex decode
            keyStr.chunked(2).map { it.toInt(16).toByte() }.toByteArray()
        }
    }
}
