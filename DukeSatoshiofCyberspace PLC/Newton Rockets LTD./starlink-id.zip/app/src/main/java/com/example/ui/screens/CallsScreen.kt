package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.CallEnd
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.SatelliteAlt
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material.icons.filled.VideocamOff
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.calling.ActiveCallSession
import com.example.calling.CallState
import com.example.storage.CallEntity
import com.example.storage.ContactEntity
import com.example.ui.theme.AerospaceCard
import com.example.ui.theme.AerospaceCardBorder
import com.example.ui.theme.AerospaceNavy
import com.example.ui.theme.AerospaceTextMuted
import com.example.ui.theme.AerospaceTextPrimary
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.SatelliteAmber
import com.example.ui.theme.SecurityAlertRed
import com.example.ui.theme.VerifiedGreen

@Composable
fun CallsScreen(
    calls: List<CallEntity>,
    contacts: List<ContactEntity>,
    activeSession: ActiveCallSession?,
    onStartCall: (peerId: String, peerAlias: String, callType: String) -> Unit,
    onEndCall: () -> Unit,
    onToggleMute: () -> Unit,
    onToggleCamera: () -> Unit
) {
    Box(modifier = Modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(AerospaceNavy)
                .padding(16.dp)
                .testTag("calls_screen")
        ) {
            Text(
                text = "INTERNET CALLS",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace,
                color = AerospaceTextPrimary,
                letterSpacing = 2.sp
            )
            Text(
                text = "Direct Authenticated IP Audio/Video • No Telephone Carrier",
                fontSize = 11.sp,
                color = AerospaceTextMuted,
                modifier = Modifier.padding(bottom = 16.dp)
            )

            // Start New Call Quick Launcher Row
            Text(
                text = "CALL A VERIFIED NID CONTACT",
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                color = AerospaceTextMuted,
                modifier = Modifier.padding(bottom = 8.dp)
            )

            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(contacts, key = { it.identityId }) { contact ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, AerospaceCardBorder, RoundedCornerShape(12.dp)),
                        colors = CardDefaults.cardColors(containerColor = AerospaceCard),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text(
                                    text = contact.alias,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = AerospaceTextPrimary
                                )
                                Text(
                                    text = "Verified NID Key",
                                    fontSize = 10.sp,
                                    color = VerifiedGreen
                                )
                            }

                            Row {
                                IconButton(
                                    onClick = { onStartCall(contact.identityId, contact.alias, "VOICE") }
                                ) {
                                    Icon(imageVector = Icons.Default.Call, contentDescription = "Voice Call", tint = CyberCyan)
                                }
                                IconButton(
                                    onClick = { onStartCall(contact.identityId, contact.alias, "VIDEO") }
                                ) {
                                    Icon(imageVector = Icons.Default.Videocam, contentDescription = "Video Call", tint = CyberCyan)
                                }
                            }
                        }
                    }
                }

                item {
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = "CALL HISTORY",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = AerospaceTextMuted,
                        modifier = Modifier.padding(bottom = 8.dp)
                    )
                }

                items(calls, key = { it.id }) { call ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, AerospaceCardBorder, RoundedCornerShape(10.dp)),
                        colors = CardDefaults.cardColors(containerColor = AerospaceCard),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = if (call.callType == "VIDEO") Icons.Default.Videocam else Icons.Default.Call,
                                    contentDescription = null,
                                    tint = CyberCyan,
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(modifier = Modifier.width(12.dp))
                                Column {
                                    Text(
                                        text = call.peerAlias,
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = AerospaceTextPrimary
                                    )
                                    Text(
                                        text = "${call.transportUsed} • ${call.durationSeconds}s",
                                        fontSize = 10.sp,
                                        fontFamily = FontFamily.Monospace,
                                        color = AerospaceTextMuted
                                    )
                                }
                            }

                            Text(
                                text = "COMPLETED",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = VerifiedGreen
                            )
                        }
                    }
                }
            }
        }

        // Active Call Fullscreen Overlay
        if (activeSession != null) {
            ActiveCallOverlay(
                session = activeSession,
                onEndCall = onEndCall,
                onToggleMute = onToggleMute,
                onToggleCamera = onToggleCamera
            )
        }
    }
}

@Composable
private fun ActiveCallOverlay(
    session: ActiveCallSession,
    onEndCall: () -> Unit,
    onToggleMute: () -> Unit,
    onToggleCamera: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(AerospaceNavy)
            .padding(24.dp)
            .testTag("active_call_overlay"),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(
                imageVector = Icons.Default.SatelliteAlt,
                contentDescription = null,
                tint = SatelliteAmber,
                modifier = Modifier.size(48.dp)
            )

            Spacer(modifier = Modifier.height(16.dp))

            Text(
                text = "INTERNET NID CALL",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace,
                color = CyberCyan,
                letterSpacing = 2.sp
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Avatar circle
            Box(
                modifier = Modifier
                    .size(90.dp)
                    .clip(CircleShape)
                    .background(CyberCyan.copy(alpha = 0.2f))
                    .border(2.dp, CyberCyan, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = session.peerAlias.take(2).uppercase(),
                    fontSize = 28.sp,
                    fontWeight = FontWeight.Bold,
                    color = CyberCyan
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            Text(
                text = session.peerAlias,
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                color = AerospaceTextPrimary
            )

            Spacer(modifier = Modifier.height(6.dp))

            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(imageVector = Icons.Default.Verified, contentDescription = null, tint = VerifiedGreen, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "Cryptographically Authenticated Handshake",
                    fontSize = 11.sp,
                    color = VerifiedGreen
                )
            }

            Spacer(modifier = Modifier.height(20.dp))

            Text(
                text = when (session.callState) {
                    CallState.INITIATING -> "Initiating Satellite ICE Handshake..."
                    CallState.RINGING -> "Ringing @${session.peerAlias}..."
                    CallState.CONNECTED -> "CONNECTED • ${session.durationSeconds}s"
                    CallState.ENDED -> "Call Ended"
                    else -> ""
                },
                fontSize = 16.sp,
                fontFamily = FontFamily.Monospace,
                color = AerospaceTextPrimary
            )

            Spacer(modifier = Modifier.height(24.dp))

            // Audio Waveform Visualizer simulation bars
            if (session.callState == CallState.CONNECTED) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    repeat(7) { index ->
                        val barHeight = (12 + ((session.audioLevel * 40) * ((index % 3) + 1))).dp
                        Box(
                            modifier = Modifier
                                .width(6.dp)
                                .height(barHeight)
                                .clip(RoundedCornerShape(3.dp))
                                .background(CyberCyan)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(48.dp))

            // Call Controls
            Row(
                horizontalArrangement = Arrangement.spacedBy(24.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = onToggleMute,
                    modifier = Modifier
                        .size(56.dp)
                        .clip(CircleShape)
                        .background(if (session.isMuted) SecurityAlertRed else AerospaceCard)
                ) {
                    Icon(
                        imageVector = if (session.isMuted) Icons.Default.MicOff else Icons.Default.Mic,
                        contentDescription = "Mute",
                        tint = AerospaceTextPrimary
                    )
                }

                IconButton(
                    onClick = onEndCall,
                    modifier = Modifier
                        .size(68.dp)
                        .clip(CircleShape)
                        .background(SecurityAlertRed)
                ) {
                    Icon(
                        imageVector = Icons.Default.CallEnd,
                        contentDescription = "End Call",
                        tint = Color.White,
                        modifier = Modifier.size(32.dp)
                    )
                }

                if (session.callType == "VIDEO") {
                    IconButton(
                        onClick = onToggleCamera,
                        modifier = Modifier
                            .size(56.dp)
                            .clip(CircleShape)
                            .background(if (!session.isCameraOn) SecurityAlertRed else AerospaceCard)
                    ) {
                        Icon(
                            imageVector = if (session.isCameraOn) Icons.Default.Videocam else Icons.Default.VideocamOff,
                            contentDescription = "Camera",
                            tint = AerospaceTextPrimary
                        )
                    }
                }
            }
        }
    }
}
