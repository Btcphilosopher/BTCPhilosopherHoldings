package com.example.ui.navigation

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Message
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.QrCode
import androidx.compose.material.icons.outlined.Call
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Message
import androidx.compose.material.icons.outlined.People
import androidx.compose.material.icons.outlined.QrCode
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.fragment.app.FragmentActivity
import com.example.ui.MainViewModel
import com.example.ui.components.TopNetworkBar
import com.example.ui.screens.CallsScreen
import com.example.ui.screens.ContactsScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.IdentityScreen
import com.example.ui.screens.MessagesScreen
import com.example.ui.screens.NetworkScreen
import com.example.ui.screens.RecoveryScreen
import com.example.ui.screens.SecurityLogScreen
import com.example.ui.theme.AerospaceCard
import com.example.ui.theme.AerospaceCardBorder
import com.example.ui.theme.AerospaceNavy
import com.example.ui.theme.AerospaceTextMuted
import com.example.ui.theme.AerospaceTextPrimary
import com.example.ui.theme.CyberCyan

import androidx.compose.runtime.rememberCoroutineScope
import kotlinx.coroutines.launch

enum class Screen {
    HOME,
    MESSAGES,
    CALLS,
    CONTACTS,
    IDENTITY,
    NETWORK,
    RECOVERY,
    SECURITY_LOGS
}

data class NavItem(
    val screen: Screen,
    val title: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector
)

@Composable
fun AppNavigation(viewModel: MainViewModel) {
    var currentScreen by remember { mutableStateOf(Screen.HOME) }
    var previousScreen by remember { mutableStateOf(Screen.HOME) }

    val identity by viewModel.identity.collectAsState()
    val telemetry by viewModel.telemetry.collectAsState()
    val contacts by viewModel.contacts.collectAsState()
    val messages by viewModel.messageDao.getAllRecentMessages().collectAsState(initial = emptyList())
    val calls by viewModel.calls.collectAsState()
    val activeCallSession by viewModel.callEngine.currentCallSession.collectAsState()
    val auditLogs by viewModel.auditLogs.collectAsState()

    val context = LocalContext.current
    val activity = context as? FragmentActivity
    val coroutineScope = rememberCoroutineScope()

    // Handle System Back Button
    if (currentScreen != Screen.HOME) {
        BackHandler {
            currentScreen = if (currentScreen == Screen.RECOVERY || currentScreen == Screen.SECURITY_LOGS || currentScreen == Screen.NETWORK) {
                previousScreen
            } else {
                Screen.HOME
            }
        }
    }

    val navItems = listOf(
        NavItem(Screen.HOME, "Home", Icons.Filled.Home, Icons.Outlined.Home),
        NavItem(Screen.MESSAGES, "Messages", Icons.Filled.Message, Icons.Outlined.Message),
        NavItem(Screen.CALLS, "Calls", Icons.Filled.Call, Icons.Outlined.Call),
        NavItem(Screen.CONTACTS, "Contacts", Icons.Filled.People, Icons.Outlined.People),
        NavItem(Screen.IDENTITY, "Identity", Icons.Filled.QrCode, Icons.Outlined.QrCode)
    )

    Scaffold(
        topBar = {
            TopNetworkBar(
                telemetry = telemetry,
                onBarClick = {
                    previousScreen = currentScreen
                    currentScreen = Screen.NETWORK
                }
            )
        },
        bottomBar = {
            if (currentScreen in listOf(Screen.HOME, Screen.MESSAGES, Screen.CALLS, Screen.CONTACTS, Screen.IDENTITY)) {
                NavigationBar(
                    containerColor = AerospaceCard,
                    contentColor = AerospaceTextPrimary,
                    modifier = Modifier.testTag("bottom_nav_bar")
                ) {
                    navItems.forEach { item ->
                        val isSelected = currentScreen == item.screen
                        NavigationBarItem(
                            selected = isSelected,
                            onClick = { currentScreen = item.screen },
                            icon = {
                                Icon(
                                    imageVector = if (isSelected) item.selectedIcon else item.unselectedIcon,
                                    contentDescription = item.title,
                                    tint = if (isSelected) CyberCyan else AerospaceTextMuted
                                )
                            },
                            label = {
                                Text(
                                    text = item.title,
                                    fontSize = 10.sp,
                                    color = if (isSelected) CyberCyan else AerospaceTextMuted
                                )
                            },
                            colors = NavigationBarItemDefaults.colors(
                                indicatorColor = CyberCyan.copy(alpha = 0.15f)
                            ),
                            modifier = Modifier.testTag("nav_${item.screen.name.lowercase()}")
                        )
                    }
                }
            }
        },
        containerColor = AerospaceNavy
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (currentScreen) {
                Screen.HOME -> HomeScreen(
                    identity = identity,
                    telemetry = telemetry,
                    contactCount = contacts.size,
                    messageCount = messages.size,
                    callCount = calls.size,
                    onNavigateToMessages = { currentScreen = Screen.MESSAGES },
                    onNavigateToCalls = { currentScreen = Screen.CALLS },
                    onNavigateToContacts = { currentScreen = Screen.CONTACTS },
                    onNavigateToIdentity = { currentScreen = Screen.IDENTITY },
                    onNavigateToNetwork = {
                        previousScreen = Screen.HOME
                        currentScreen = Screen.NETWORK
                    },
                    onTriggerBiometricUnlock = {
                        if (activity != null) {
                            viewModel.triggerBiometricUnlock(activity) { _, _ -> }
                        }
                    }
                )

                Screen.MESSAGES -> MessagesScreen(
                    contacts = contacts,
                    messageDao = viewModel.messageDao,
                    onSendMessage = { recipientNid, text ->
                        viewModel.sendMessage(recipientNid, text)
                    }
                )

                Screen.CALLS -> CallsScreen(
                    calls = calls,
                    contacts = contacts,
                    activeSession = activeCallSession,
                    onStartCall = { peerId, peerAlias, callType ->
                        viewModel.callEngine.startCall(peerId, peerAlias, callType)
                    },
                    onEndCall = { viewModel.callEngine.endCall() },
                    onToggleMute = { viewModel.callEngine.toggleMute() },
                    onToggleCamera = { viewModel.callEngine.toggleCamera() }
                )

                Screen.CONTACTS -> ContactsScreen(
                    contacts = contacts,
                    onAddContactByNid = { nidStr -> viewModel.addContactByNid(nidStr) }
                )

                Screen.IDENTITY -> IdentityScreen(
                    identity = identity,
                    onRotateKey = { viewModel.rotateKey() },
                    onNavigateToRecovery = {
                        previousScreen = Screen.IDENTITY
                        currentScreen = Screen.RECOVERY
                    },
                    onNavigateToAuditLogs = {
                        previousScreen = Screen.IDENTITY
                        currentScreen = Screen.SECURITY_LOGS
                    }
                )

                Screen.NETWORK -> NetworkScreen(
                    telemetry = telemetry,
                    policy = viewModel.satelliteAdapter.userPolicy.collectAsState().value,
                    onSetPolicy = { viewModel.setConnectivityPolicy(it) },
                    onForceTransport = { viewModel.forceTransportType(it) },
                    onToggleObstruction = { viewModel.toggleSimulatedObstruction() },
                    onToggleRainFade = { viewModel.toggleSimulatedRainFade() },
                    onToggleOffline = { viewModel.toggleSimulatedOffline() }
                )

                Screen.RECOVERY -> RecoveryScreen(
                    recoveryManager = viewModel.recoveryManager,
                    onBack = { currentScreen = previousScreen },
                    onRevokeDevice = { deviceId ->
                        coroutineScope.launch {
                            viewModel.recoveryManager.revokeDevice(deviceId)
                        }
                    },
                    onAuthorizeDevice = { deviceId ->
                        coroutineScope.launch {
                            viewModel.recoveryManager.authorizeDevice(deviceId)
                        }
                    }
                )

                Screen.SECURITY_LOGS -> SecurityLogScreen(
                    logs = auditLogs,
                    onBack = { currentScreen = previousScreen }
                )
            }
        }
    }
}
