package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Devices
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.QrCode
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Restore
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.identity.Identity
import com.example.identity.NID
import com.example.ui.theme.AerospaceCard
import com.example.ui.theme.AerospaceCardBorder
import com.example.ui.theme.AerospaceNavy
import com.example.ui.theme.AerospaceTextMuted
import com.example.ui.theme.AerospaceTextPrimary
import com.example.ui.theme.AerospaceTextSecondary
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.SatelliteAmber
import com.example.ui.theme.SecurityAlertRed
import com.example.ui.theme.VerifiedGreen

@Composable
fun IdentityScreen(
    identity: Identity?,
    onRotateKey: () -> Unit,
    onNavigateToRecovery: () -> Unit,
    onNavigateToAuditLogs: () -> Unit
) {
    var showQrModal by remember { mutableStateOf(false) }
    var showRotateConfirmDialog by remember { mutableStateOf(false) }

    if (showQrModal && identity != null) {
        NidQrCodeModal(
            identity = identity,
            onDismiss = { showQrModal = false }
        )
    }

    if (showRotateConfirmDialog) {
        KeyRotationConfirmDialog(
            onConfirm = {
                onRotateKey()
                showRotateConfirmDialog = false
            },
            onDismiss = { showRotateConfirmDialog = false }
        )
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(AerospaceNavy)
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
            .testTag("identity_screen"),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = "YOUR CRYPTOGRAPHIC IDENTITY",
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace,
            color = AerospaceTextPrimary,
            letterSpacing = 2.sp
        )
        Text(
            text = "Hardware-backed Android KeyStore / StrongBox TEE",
            fontSize = 11.sp,
            color = AerospaceTextMuted,
            modifier = Modifier.padding(bottom = 16.dp)
        )

        // Main Identity Card
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, AerospaceCardBorder, RoundedCornerShape(16.dp)),
            colors = CardDefaults.cardColors(containerColor = AerospaceCard),
            shape = RoundedCornerShape(16.dp)
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(48.dp)
                                .clip(CircleShape)
                                .background(CyberCyan.copy(alpha = 0.2f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(imageVector = Icons.Default.Shield, contentDescription = null, tint = CyberCyan, modifier = Modifier.size(28.dp))
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = identity?.alias ?: "@newton",
                                fontSize = 22.sp,
                                fontWeight = FontWeight.Bold,
                                color = AerospaceTextPrimary
                            )
                            Text(
                                text = "Verified Internet Identity",
                                fontSize = 11.sp,
                                color = VerifiedGreen
                            )
                        }
                    }

                    Button(
                        onClick = { showQrModal = true },
                        colors = ButtonDefaults.buttonColors(containerColor = CyberCyan),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.testTag("share_nid_qr_btn")
                    ) {
                        Icon(imageVector = Icons.Default.QrCode, contentDescription = "QR", tint = Color.Black)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(text = "QR NID", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))
                HorizontalDivider(color = AerospaceCardBorder)
                Spacer(modifier = Modifier.height(16.dp))

                // Identity Details Grid
                IdentityDetailRow(label = "NID IDENTIFIER", value = identity?.identityId ?: "nid:sha256:7f8c21a493a1002")
                Spacer(modifier = Modifier.height(10.dp))
                IdentityDetailRow(label = "ALGORITHM", value = "${identity?.keyAlgorithm ?: "EC secp256r1"} (P-256)")
                Spacer(modifier = Modifier.height(10.dp))
                IdentityDetailRow(label = "HARDWARE BACKING", value = if (identity?.isStrongBoxBacked == true) "StrongBox TEE" else "Android KeyStore TEE")

                Spacer(modifier = Modifier.height(16.dp))

                // Formatted Public Key Display
                Text(
                    text = "PUBLIC KEY FINGERPRINT",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    color = AerospaceTextMuted,
                    letterSpacing = 1.sp
                )
                Spacer(modifier = Modifier.height(6.dp))
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(AerospaceNavy)
                        .padding(10.dp)
                ) {
                    val rawPub = identity?.publicKey ?: "7F8C21A493A1B2C3D4E5F6A7B8C9D0E1F2A3B4C5"
                    val formattedHex = rawPub.chunked(4).take(8).joinToString(" ")
                    Text(
                        text = formattedHex,
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace,
                        color = CyberCyan
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Actions & Management
        Text(
            text = "SECURITY & RECOVERY MANAGEMENT",
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace,
            color = AerospaceTextMuted,
            letterSpacing = 1.sp,
            modifier = Modifier.align(Alignment.Start)
        )

        Spacer(modifier = Modifier.height(10.dp))

        Card(
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, AerospaceCardBorder, RoundedCornerShape(12.dp)),
            colors = CardDefaults.cardColors(containerColor = AerospaceCard),
            shape = RoundedCornerShape(12.dp)
        ) {
            Column {
                ManagementActionItem(
                    icon = Icons.Default.Restore,
                    title = "Recovery Center & Seed Phrase",
                    subtitle = "24-word cryptographic backup & device replacement",
                    onClick = onNavigateToRecovery
                )
                HorizontalDivider(color = AerospaceCardBorder)
                ManagementActionItem(
                    icon = Icons.Default.Refresh,
                    title = "Key Rotation",
                    subtitle = "Generate new hardware key pair & revoke old key",
                    onClick = { showRotateConfirmDialog = true }
                )
                HorizontalDivider(color = AerospaceCardBorder)
                ManagementActionItem(
                    icon = Icons.Default.Security,
                    title = "Security Audit Log",
                    subtitle = "View hardware key, biometric, and network events",
                    onClick = onNavigateToAuditLogs
                )
            }
        }
    }
}

@Composable
private fun IdentityDetailRow(label: String, value: String) {
    Column {
        Text(text = label, fontSize = 9.sp, fontWeight = FontWeight.Bold, color = AerospaceTextMuted)
        Text(text = value, fontSize = 12.sp, fontFamily = FontFamily.Monospace, color = AerospaceTextPrimary)
    }
}

@Composable
private fun ManagementActionItem(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    subtitle: String,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .padding(14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(imageVector = icon, contentDescription = null, tint = CyberCyan, modifier = Modifier.size(20.dp))
        Spacer(modifier = Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(text = title, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = AerospaceTextPrimary)
            Text(text = subtitle, fontSize = 10.sp, color = AerospaceTextMuted)
        }
    }
}

@Composable
private fun NidQrCodeModal(
    identity: Identity,
    onDismiss: () -> Unit
) {
    val nidJson = NID(
        version = 1,
        identityId = identity.identityId,
        publicKey = identity.publicKey,
        alias = identity.alias
    ).toJson()

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = AerospaceCard,
        title = {
            Text(
                text = "NETWORK IDENTITY DESCRIPTOR (NID)",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace,
                color = CyberCyan
            )
        },
        text = {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Simulated QR Code Visual Box
                Box(
                    modifier = Modifier
                        .size(180.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color.White)
                        .border(2.dp, CyberCyan, RoundedCornerShape(12.dp))
                        .padding(16.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            imageVector = Icons.Default.QrCode,
                            contentDescription = "QR Code",
                            tint = Color.Black,
                            modifier = Modifier.size(100.dp)
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = identity.alias,
                            fontWeight = FontWeight.Bold,
                            color = Color.Black,
                            fontSize = 14.sp
                        )
                    }
                }

                Text(
                    text = "Scan this QR code from another device to exchange verified cryptographic identities.",
                    fontSize = 11.sp,
                    color = AerospaceTextSecondary
                )

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(AerospaceNavy)
                        .padding(8.dp)
                ) {
                    Text(
                        text = nidJson,
                        fontSize = 9.sp,
                        fontFamily = FontFamily.Monospace,
                        color = AerospaceTextMuted
                    )
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text(text = "Close", color = CyberCyan)
            }
        }
    )
}

@Composable
private fun KeyRotationConfirmDialog(
    onConfirm: () -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = AerospaceCard,
        title = {
            Text(
                text = "EXECUTE KEY ROTATION?",
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace,
                color = SatelliteAmber
            )
        },
        text = {
            Text(
                text = "This will generate a new hardware EC key pair inside StrongBox/KeyStore and revoke the current key. Your contacts will receive a verified key rotation notice.",
                fontSize = 12.sp,
                color = AerospaceTextPrimary
            )
        },
        confirmButton = {
            TextButton(onClick = onConfirm) {
                Text(text = "Rotate Key Pair", color = SatelliteAmber, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(text = "Cancel", color = AerospaceTextMuted)
            }
        }
    )
}
