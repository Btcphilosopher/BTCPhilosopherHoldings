package com.example.recovery

import com.example.identity.DeviceIdentity
import com.example.security.CryptoManager
import com.example.storage.AuditLogDao
import com.example.storage.AuditLogEntity
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class RecoveryManager(
    private val cryptoManager: CryptoManager,
    private val auditLogDao: AuditLogDao
) {

    private val _devices = MutableStateFlow<List<DeviceIdentity>>(
        listOf(
            DeviceIdentity(
                deviceId = "dev_this_phone",
                deviceName = "Starlink Phone (This Device)",
                isCurrentDevice = true,
                isAuthorized = true,
                authorizedAt = System.currentTimeMillis() - 864000000
            ),
            DeviceIdentity(
                deviceId = "dev_laptop_m2",
                deviceName = "Aerospace Laptop",
                isCurrentDevice = false,
                isAuthorized = true,
                authorizedAt = System.currentTimeMillis() - 432000000
            ),
            DeviceIdentity(
                deviceId = "dev_tablet_pro",
                deviceName = "Flight Deck Tablet",
                isCurrentDevice = false,
                isAuthorized = false,
                authorizedAt = System.currentTimeMillis() - 172800000
            )
        )
    )
    val devices: StateFlow<List<DeviceIdentity>> = _devices.asStateFlow()

    fun generateRecoverySeedPhrase(): List<String> {
        return listOf(
            "orbit", "shield", "satellite", "quantum", "beacon", "vector",
            "zenith", "cipher", "matrix", "hardware", "keystore", "horizon",
            "signal", "canopy", "apogee", "telemetry", "starlink", "azimuth",
            "cadence", "entropy", "spectrum", "gateway", "parabolic", "vertex"
        )
    }

    suspend fun rotateIdentityKey(identityAlias: String) {
        val newKeyPair = cryptoManager.generateHardwareKeyPair(identityAlias, requireBiometricAuth = false)
        val newPubKey = newKeyPair.public
        val newNid = cryptoManager.deriveNidFromPublicKey(newPubKey)

        auditLogDao.insertLog(
            AuditLogEntity(
                category = "KEYSTORE",
                eventDescription = "Key Rotation executed for @$identityAlias. New Hardware NID: $newNid",
                severity = "WARNING"
            )
        )
    }

    suspend fun revokeDevice(deviceId: String) {
        _devices.value = _devices.value.map {
            if (it.deviceId == deviceId) it.copy(isAuthorized = false) else it
        }

        auditLogDao.insertLog(
            AuditLogEntity(
                category = "SECURITY",
                eventDescription = "Revoked device authorization for device $deviceId",
                severity = "CRITICAL"
            )
        )
    }

    suspend fun authorizeDevice(deviceId: String) {
        _devices.value = _devices.value.map {
            if (it.deviceId == deviceId) it.copy(isAuthorized = true) else it
        }

        auditLogDao.insertLog(
            AuditLogEntity(
                category = "SECURITY",
                eventDescription = "Authorized new device certificate for device $deviceId",
                severity = "INFO"
            )
        )
    }
}
