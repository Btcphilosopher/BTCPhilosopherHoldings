package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = CyberCyan,
    onPrimary = Color.Black,
    primaryContainer = CyberCyanContainer,
    onPrimaryContainer = CyberCyanLight,
    secondary = SatelliteAmber,
    onSecondary = Color.Black,
    secondaryContainer = SatelliteAmberContainer,
    onSecondaryContainer = SatelliteAmber,
    tertiary = VerifiedGreen,
    onTertiary = Color.Black,
    tertiaryContainer = VerifiedGreenContainer,
    onTertiaryContainer = VerifiedGreen,
    background = AerospaceNavy,
    onBackground = AerospaceTextPrimary,
    surface = AerospaceCard,
    onSurface = AerospaceTextPrimary,
    surfaceVariant = AerospaceSurfaceVariant,
    onSurfaceVariant = AerospaceTextSecondary,
    outline = AerospaceCardBorder,
    error = SecurityAlertRed,
    errorContainer = SecurityAlertContainer,
    onError = Color.White
)

private val LightColorScheme = darkColorScheme( // Force Aerospace dark theme as canonical look
    primary = CyberCyan,
    onPrimary = Color.Black,
    primaryContainer = CyberCyanContainer,
    onPrimaryContainer = CyberCyanLight,
    secondary = SatelliteAmber,
    onSecondary = Color.Black,
    secondaryContainer = SatelliteAmberContainer,
    onSecondaryContainer = SatelliteAmber,
    tertiary = VerifiedGreen,
    onTertiary = Color.Black,
    tertiaryContainer = VerifiedGreenContainer,
    onTertiaryContainer = VerifiedGreen,
    background = AerospaceNavy,
    onBackground = AerospaceTextPrimary,
    surface = AerospaceCard,
    onSurface = AerospaceTextPrimary,
    surfaceVariant = AerospaceSurfaceVariant,
    onSurfaceVariant = AerospaceTextSecondary,
    outline = AerospaceCardBorder,
    error = SecurityAlertRed,
    errorContainer = SecurityAlertContainer,
    onError = Color.White
)

@Composable
fun StarlinkTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = DarkColorScheme,
        typography = Typography,
        content = content
    )
}
