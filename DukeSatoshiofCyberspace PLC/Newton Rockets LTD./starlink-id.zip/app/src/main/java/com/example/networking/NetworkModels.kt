package com.example.networking

enum class TransportType {
    SATELLITE,
    WIFI,
    CELLULAR,
    OFFLINE
}

enum class SatelliteLinkState {
    SEARCHING,
    ACQUIRING_ORBIT,
    CONNECTED_LEO,
    DEGRADED_WEATHER,
    OBSTRUCTED,
    DISCONNECTED
}

enum class ConnectivityPolicy {
    PREFER_WIFI,
    PREFER_CELLULAR,
    PREFER_SATELLITE,
    AUTO_SATELLITE_BACKUP
}

data class NetworkTelemetry(
    val transportType: TransportType,
    val isConnected: Boolean,
    val signalQualityPercent: Int,
    val latencyMs: Int,
    val downloadSpeedMbps: Float,
    val uploadSpeedMbps: Float,
    val satelliteElevationDegrees: Int = 45,
    val satelliteConstellation: String = "Starlink Gen2 LEO",
    val linkState: SatelliteLinkState = SatelliteLinkState.CONNECTED_LEO
)
