package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Devices
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.identity.DeviceIdentity
import com.example.recovery.RecoveryManager
import com.example.ui.theme.AerospaceCard
import com.example.ui.theme.AerospaceCardBorder
import com.example.ui.theme.AerospaceNavy
import com.example.ui.theme.AerospaceTextMuted
import com.example.ui.theme.AerospaceTextPrimary
import com.example.ui.theme.AerospaceTextSecondary
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.SatelliteAmber
import com.example.ui.theme.SecurityAlertRed
import com.example.ui.theme.VerifiedGreen

@Composable
fun RecoveryScreen(
    recoveryManager: RecoveryManager,
    onBack: () -> Unit,
    onRevokeDevice: (String) -> Unit,
    onAuthorizeDevice: (String) -> Unit
) {
    val seedWords = recoveryManager.generateRecoverySeedPhrase()
    val devices by recoveryManager.devices.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(AerospaceNavy)
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
            .testTag("recovery_screen")
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) {
                Icon(imageVector = Icons.Default.ArrowBack, contentDescription = "Back", tint = AerospaceTextPrimary)
            }
            Spacer(modifier = Modifier.width(8.dp))
            Column {
                Text(
                    text = "RECOVERY & DEVICE CENTER",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    color = AerospaceTextPrimary
                )
                Text(
                    text = "24-Word Master Seed & Multi-Device Certificates",
                    fontSize = 11.sp,
                    color = AerospaceTextMuted
                )
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // 24-Word Seed Phrase Card
        Text(
            text = "24-WORD RECOVERY SEED PHRASE",
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace,
            color = SatelliteAmber,
            letterSpacing = 1.sp
        )

        Spacer(modifier = Modifier.height(8.dp))

        Card(
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, AerospaceCardBorder, RoundedCornerShape(12.dp)),
            colors = CardDefaults.cardColors(containerColor = AerospaceCard),
            shape = RoundedCornerShape(12.dp)
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text(
                    text = "Keep this phrase offline in physical security. It restores your root cryptographic identity on a new phone.",
                    fontSize = 11.sp,
                    color = AerospaceTextSecondary
                )

                Spacer(modifier = Modifier.height(12.dp))

                // 24 Word Grid
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    seedWords.chunked(3).forEachIndexed { rowIndex, chunk ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            chunk.forEachIndexed { colIndex, word ->
                                val wordNumber = (rowIndex * 3) + colIndex + 1
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(AerospaceNavy)
                                        .padding(8.dp)
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(
                                            text = "$wordNumber.",
                                            fontSize = 9.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = AerospaceTextMuted
                                        )
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(
                                            text = word,
                                            fontSize = 11.sp,
                                            fontFamily = FontFamily.Monospace,
                                            color = CyberCyan
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Multi-Device Certificates Section
        Text(
            text = "AUTHORIZED MULTI-DEVICE CERTIFICATES",
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace,
            color = CyberCyan,
            letterSpacing = 1.sp
        )

        Spacer(modifier = Modifier.height(8.dp))

        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            devices.forEach { device ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, AerospaceCardBorder, RoundedCornerShape(12.dp)),
                    colors = CardDefaults.cardColors(containerColor = AerospaceCard),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Devices,
                                contentDescription = null,
                                tint = if (device.isAuthorized) VerifiedGreen else SecurityAlertRed,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = device.deviceName,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = AerospaceTextPrimary
                                )
                                Text(
                                    text = if (device.isCurrentDevice) "This Phone • Active Key" else if (device.isAuthorized) "Authorized Secondary Device" else "Device Certificate Revoked",
                                    fontSize = 10.sp,
                                    color = if (device.isAuthorized) VerifiedGreen else SecurityAlertRed
                                )
                            }
                        }

                        if (!device.isCurrentDevice) {
                            if (device.isAuthorized) {
                                Button(
                                    onClick = { onRevokeDevice(device.deviceId) },
                                    colors = ButtonDefaults.buttonColors(containerColor = SecurityAlertRed.copy(alpha = 0.2f)),
                                    shape = RoundedCornerShape(6.dp)
                                ) {
                                    Text(text = "Revoke", color = SecurityAlertRed, fontSize = 11.sp)
                                }
                            } else {
                                Button(
                                    onClick = { onAuthorizeDevice(device.deviceId) },
                                    colors = ButtonDefaults.buttonColors(containerColor = VerifiedGreen.copy(alpha = 0.2f)),
                                    shape = RoundedCornerShape(6.dp)
                                ) {
                                    Text(text = "Authorize", color = VerifiedGreen, fontSize = 11.sp)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
