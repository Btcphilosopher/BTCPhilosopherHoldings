package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.Message
import androidx.compose.material.icons.filled.SatelliteAlt
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.storage.ContactEntity
import com.example.storage.MessageDao
import com.example.storage.MessageEntity
import com.example.ui.theme.AerospaceCard
import com.example.ui.theme.AerospaceCardBorder
import com.example.ui.theme.AerospaceNavy
import com.example.ui.theme.AerospaceTextMuted
import com.example.ui.theme.AerospaceTextPrimary
import com.example.ui.theme.AerospaceTextSecondary
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.SatelliteAmber
import com.example.ui.theme.SecurityAlertRed
import com.example.ui.theme.VerifiedGreen

@Composable
fun MessagesScreen(
    contacts: List<ContactEntity>,
    messageDao: MessageDao,
    onSendMessage: (recipientNid: String, text: String) -> Unit
) {
    var selectedContact by remember { mutableStateOf<ContactEntity?>(null) }

    if (selectedContact != null) {
        ChatDetailView(
            contact = selectedContact!!,
            messageDao = messageDao,
            onBack = { selectedContact = null },
            onSendMessage = { text -> onSendMessage(selectedContact!!.identityId, text) }
        )
    } else {
        ConversationListView(
            contacts = contacts,
            onSelectContact = { selectedContact = it }
        )
    }
}

@Composable
private fun ConversationListView(
    contacts: List<ContactEntity>,
    onSelectContact: (ContactEntity) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(AerospaceNavy)
            .padding(16.dp)
            .testTag("conversation_list_view")
    ) {
        Text(
            text = "E2E ENCRYPTED CHATS",
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace,
            color = AerospaceTextPrimary,
            letterSpacing = 2.sp
        )
        Text(
            text = "Direct Internet NID Messaging • Zero Telephone Numbers",
            fontSize = 11.sp,
            color = AerospaceTextMuted,
            modifier = Modifier.padding(bottom = 16.dp)
        )

        if (contacts.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(32.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "No NID contacts available. Scan a QR code or paste an identity in Contacts.",
                    color = AerospaceTextMuted,
                    fontSize = 13.sp
                )
            }
        } else {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(contacts, key = { it.identityId }) { contact ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onSelectContact(contact) }
                            .border(1.dp, AerospaceCardBorder, RoundedCornerShape(12.dp))
                            .testTag("chat_item_${contact.alias}"),
                        colors = CardDefaults.cardColors(containerColor = AerospaceCard),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(42.dp)
                                    .clip(CircleShape)
                                    .background(CyberCyan.copy(alpha = 0.2f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = contact.alias.take(2).uppercase(),
                                    fontWeight = FontWeight.Bold,
                                    color = CyberCyan
                                )
                            }

                            Spacer(modifier = Modifier.width(12.dp))

                            Column(modifier = Modifier.weight(1f)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = contact.alias,
                                        fontSize = 15.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = AerospaceTextPrimary
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Icon(
                                        imageVector = Icons.Default.Verified,
                                        contentDescription = "Verified",
                                        tint = if (contact.trustLevel == "VERIFIED") VerifiedGreen else SatelliteAmber,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                                Text(
                                    text = contact.identityId,
                                    fontSize = 10.sp,
                                    fontFamily = FontFamily.Monospace,
                                    color = AerospaceTextMuted
                                )
                            }

                            Icon(
                                imageVector = Icons.Default.Lock,
                                contentDescription = "E2EE",
                                tint = VerifiedGreen,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ChatDetailView(
    contact: ContactEntity,
    messageDao: MessageDao,
    onBack: () -> Unit,
    onSendMessage: (String) -> Unit
) {
    val messagesState by messageDao.getMessagesForConversation(contact.identityId)
        .collectAsState(initial = emptyList())

    var messageInput by remember { mutableStateOf("") }
    var inspectMessage by remember { mutableStateOf<MessageEntity?>(null) }

    if (inspectMessage != null) {
        MessageEnvelopeInspectorModal(
            message = inspectMessage!!,
            contact = contact,
            onDismiss = { inspectMessage = null }
        )
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(AerospaceNavy)
            .testTag("chat_detail_view")
    ) {
        // Chat Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(AerospaceCard)
                .padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(imageVector = Icons.Default.ArrowBack, contentDescription = "Back", tint = AerospaceTextPrimary)
            }

            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = contact.alias,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = AerospaceTextPrimary
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Icon(
                        imageVector = Icons.Default.Verified,
                        contentDescription = null,
                        tint = VerifiedGreen,
                        modifier = Modifier.size(14.dp)
                    )
                }
                Text(
                    text = contact.identityId,
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace,
                    color = AerospaceTextMuted
                )
            }
        }

        // Messages List
        LazyColumn(
            modifier = Modifier
                .weight(1f)
                .padding(horizontal = 12.dp, vertical = 8.dp),
            reverseLayout = false,
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(messagesState, key = { it.messageId }) { msg ->
                val isOutgoing = msg.isOutgoing
                Box(
                    modifier = Modifier.fillMaxWidth(),
                    contentAlignment = if (isOutgoing) Alignment.CenterEnd else Alignment.CenterStart
                ) {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth(0.82f)
                            .clickable { inspectMessage = msg }
                            .border(
                                1.dp,
                                if (isOutgoing) CyberCyan.copy(alpha = 0.4f) else AerospaceCardBorder,
                                RoundedCornerShape(12.dp)
                            ),
                        colors = CardDefaults.cardColors(
                            containerColor = if (isOutgoing) AerospaceCardBorder else AerospaceCard
                        ),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Text(
                                text = msg.content,
                                fontSize = 14.sp,
                                color = AerospaceTextPrimary
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = if (msg.isVerifiedSignature) Icons.Default.Lock else Icons.Default.LockOpen,
                                        contentDescription = "Signature",
                                        tint = if (msg.isVerifiedSignature) VerifiedGreen else SecurityAlertRed,
                                        modifier = Modifier.size(11.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = "${msg.transportUsed} • ${msg.status}",
                                        fontSize = 9.sp,
                                        fontFamily = FontFamily.Monospace,
                                        color = if (msg.status == "QUEUED") SatelliteAmber else CyberCyan
                                    )
                                }
                                Icon(
                                    imageVector = Icons.Default.Info,
                                    contentDescription = "Inspect Envelope",
                                    tint = AerospaceTextMuted,
                                    modifier = Modifier.size(12.dp)
                                )
                            }
                        }
                    }
                }
            }
        }

        // Input Box
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(AerospaceCard)
                .padding(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = messageInput,
                onValueChange = { messageInput = it },
                placeholder = { Text("E2EE Message...", color = AerospaceTextMuted, fontSize = 13.sp) },
                modifier = Modifier
                    .weight(1f)
                    .testTag("chat_input_text_field"),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = CyberCyan,
                    unfocusedBorderColor = AerospaceCardBorder,
                    focusedTextColor = AerospaceTextPrimary,
                    unfocusedTextColor = AerospaceTextPrimary
                ),
                maxLines = 3
            )

            Spacer(modifier = Modifier.width(8.dp))

            IconButton(
                onClick = {
                    if (messageInput.isNotBlank()) {
                        onSendMessage(messageInput.trim())
                        messageInput = ""
                    }
                },
                modifier = Modifier.testTag("chat_send_button")
            ) {
                Icon(imageVector = Icons.Default.Send, contentDescription = "Send", tint = CyberCyan)
            }
        }
    }
}

@Composable
private fun MessageEnvelopeInspectorModal(
    message: MessageEntity,
    contact: ContactEntity,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = AerospaceCard,
        title = {
            Text(
                text = "ENVELOPE CRYPTO AUDIT",
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace,
                color = CyberCyan
            )
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                AuditField(label = "Message ID", value = message.messageId)
                AuditField(label = "Sender NID", value = message.senderIdentityId)
                AuditField(label = "Recipient NID", value = message.receiverIdentityId)
                AuditField(label = "Transport Used", value = message.transportUsed)
                AuditField(label = "Payload Cipher", value = "AES-256-GCM")
                AuditField(label = "Ciphertext", value = message.encryptedPayloadBase64)
                AuditField(
                    label = "Digital Signature",
                    value = message.signatureBase64,
                    highlightColor = if (message.isVerifiedSignature) VerifiedGreen else SecurityAlertRed
                )
                AuditField(
                    label = "Signature Status",
                    value = if (message.isVerifiedSignature) "✓ VALID (ECDSA secp256r1)" else "❌ INVALID SIGNATURE",
                    highlightColor = if (message.isVerifiedSignature) VerifiedGreen else SecurityAlertRed
                )
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text(text = "Close", color = CyberCyan)
            }
        }
    )
}

@Composable
private fun AuditField(label: String, value: String, highlightColor: Color = AerospaceTextPrimary) {
    Column {
        Text(text = label, fontSize = 9.sp, fontWeight = FontWeight.Bold, color = AerospaceTextMuted)
        Text(text = value, fontSize = 11.sp, fontFamily = FontFamily.Monospace, color = highlightColor)
    }
}
