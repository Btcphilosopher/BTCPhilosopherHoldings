package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.CellTower
import androidx.compose.material.icons.filled.SatelliteAlt
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material.icons.filled.WifiOff
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.networking.NetworkTelemetry
import com.example.networking.SatelliteLinkState
import com.example.networking.TransportType
import com.example.ui.theme.AerospaceCard
import com.example.ui.theme.AerospaceCardBorder
import com.example.ui.theme.AerospaceTextMuted
import com.example.ui.theme.AerospaceTextPrimary
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.SatelliteAmber
import com.example.ui.theme.SecurityAlertRed
import com.example.ui.theme.VerifiedGreen

@Composable
fun TopNetworkBar(
    telemetry: NetworkTelemetry,
    onBarClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val statusColor = when {
        !telemetry.isConnected -> SecurityAlertRed
        telemetry.transportType == TransportType.SATELLITE && telemetry.linkState == SatelliteLinkState.DEGRADED_WEATHER -> SatelliteAmber
        telemetry.transportType == TransportType.SATELLITE && telemetry.linkState == SatelliteLinkState.OBSTRUCTED -> SecurityAlertRed
        else -> VerifiedGreen
    }

    val transportIcon = when (telemetry.transportType) {
        TransportType.SATELLITE -> Icons.Default.SatelliteAlt
        TransportType.WIFI -> Icons.Default.Wifi
        TransportType.CELLULAR -> Icons.Default.CellTower
        TransportType.OFFLINE -> Icons.Default.WifiOff
    }

    Box(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(bottomStart = 16.dp, bottomEnd = 16.dp))
            .background(AerospaceCard)
            .clickable { onBarClick() }
            .padding(horizontal = 16.dp, vertical = 10.dp)
            .testTag("top_network_bar")
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                // Pulse dot indicator
                Box(
                    modifier = Modifier
                        .size(10.dp)
                        .clip(CircleShape)
                        .background(statusColor)
                )

                Spacer(modifier = Modifier.width(10.dp))

                Icon(
                    imageVector = transportIcon,
                    contentDescription = "Transport Icon",
                    tint = CyberCyan,
                    modifier = Modifier.size(18.dp)
                )

                Spacer(modifier = Modifier.width(8.dp))

                Column {
                    Text(
                        text = if (telemetry.isConnected) "${telemetry.transportType.name} CONNECTED" else "NETWORK DISCONNECTED",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        color = AerospaceTextPrimary,
                        letterSpacing = 1.sp
                    )
                    Text(
                        text = when (telemetry.transportType) {
                            TransportType.SATELLITE -> "Starlink LEO • ${telemetry.satelliteElevationDegrees}° Elev • ${telemetry.linkState}"
                            TransportType.WIFI -> "Wi-Fi Direct IP • Low Latency"
                            TransportType.CELLULAR -> "Cellular Data • IP Gateway"
                            TransportType.OFFLINE -> "Offline Mode • Queuing Local Messages"
                        },
                        fontSize = 10.sp,
                        color = AerospaceTextMuted
                    )
                }
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                if (telemetry.isConnected) {
                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            text = "${telemetry.latencyMs} ms",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace,
                            color = CyberCyan
                        )
                        Text(
                            text = "↓${telemetry.downloadSpeedMbps} M",
                            fontSize = 10.sp,
                            color = AerospaceTextMuted
                        )
                    }
                }

                Spacer(modifier = Modifier.width(6.dp))

                Icon(
                    imageVector = Icons.Default.ChevronRight,
                    contentDescription = "View Network",
                    tint = AerospaceTextMuted,
                    modifier = Modifier.size(18.dp)
                )
            }
        }
    }
}
