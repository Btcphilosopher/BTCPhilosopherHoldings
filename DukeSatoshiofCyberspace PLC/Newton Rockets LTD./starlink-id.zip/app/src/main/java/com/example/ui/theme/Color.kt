package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Aerospace Theme Palette
val AerospaceNavy = Color(0xFF070D1E)
val AerospaceCard = Color(0xFF0F1B36)
val AerospaceCardBorder = Color(0xFF1E325C)
val AerospaceSurfaceVariant = Color(0xFF152242)

val CyberCyan = Color(0xFF00A8E8)
val CyberCyanLight = Color(0xFF48CAE4)
val CyberCyanContainer = Color(0xFF0B3A5A)

val SatelliteAmber = Color(0xFFFFB703)
val SatelliteAmberContainer = Color(0xFF4A3400)

val VerifiedGreen = Color(0xFF06D6A0)
val VerifiedGreenContainer = Color(0xFF033E2F)

val SecurityAlertRed = Color(0xFFEF476F)
val SecurityAlertContainer = Color(0xFF4A101C)

val AerospaceTextPrimary = Color(0xFFF8F9FA)
val AerospaceTextSecondary = Color(0xFF90A4AE)
val AerospaceTextMuted = Color(0xFF546E7A)
