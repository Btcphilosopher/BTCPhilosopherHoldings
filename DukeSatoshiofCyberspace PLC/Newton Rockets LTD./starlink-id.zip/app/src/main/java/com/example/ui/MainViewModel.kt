package com.example.ui

import android.app.Application
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.calling.CallEngine
import com.example.identity.Identity
import com.example.identity.NID
import com.example.identity.TrustLevel
import com.example.messaging.MessagingEngine
import com.example.networking.ConnectivityPolicy
import com.example.networking.NetworkTelemetry
import com.example.networking.SatelliteConnectivityAdapter
import com.example.networking.TransportType
import com.example.recovery.RecoveryManager
import com.example.security.BiometricAuthManager
import com.example.security.CryptoManager
import com.example.storage.AppDatabase
import com.example.storage.AuditLogEntity
import com.example.storage.ContactEntity
import com.example.storage.MessageEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val db = AppDatabase.getInstance(application, viewModelScope)
    val contactDao = db.contactDao()
    val messageDao = db.messageDao()
    val callDao = db.callDao()
    val auditLogDao = db.auditLogDao()

    val cryptoManager = CryptoManager(application)
    val biometricAuthManager = BiometricAuthManager(application)
    val satelliteAdapter = SatelliteConnectivityAdapter(application, viewModelScope)
    val messagingEngine = MessagingEngine(
        cryptoManager,
        messageDao,
        contactDao,
        auditLogDao,
        satelliteAdapter,
        viewModelScope
    )
    val callEngine = CallEngine(callDao, auditLogDao, satelliteAdapter, viewModelScope)
    val recoveryManager = RecoveryManager(cryptoManager, auditLogDao)

    private val defaultAlias = "newton"

    private val _identity = MutableStateFlow<Identity?>(null)
    val identity: StateFlow<Identity?> = _identity.asStateFlow()

    private val _isBiometricUnlocked = MutableStateFlow(false)
    val isBiometricUnlocked: StateFlow<Boolean> = _isBiometricUnlocked.asStateFlow()

    val telemetry: StateFlow<NetworkTelemetry> = satelliteAdapter.telemetry
    val contacts: StateFlow<List<ContactEntity>> = contactDao.getAllContacts()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val auditLogs: StateFlow<List<AuditLogEntity>> = auditLogDao.getAllLogs()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val calls = callDao.getAllCalls()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    init {
        initializeOrLoadIdentity()
    }

    fun initializeOrLoadIdentity() {
        viewModelScope.launch(Dispatchers.IO) {
            val hasKey = cryptoManager.hasKey(defaultAlias)
            val keyPair = if (hasKey) {
                val pub = cryptoManager.getPublicKey(defaultAlias)
                if (pub != null) null else cryptoManager.generateHardwareKeyPair(defaultAlias)
            } else {
                cryptoManager.generateHardwareKeyPair(defaultAlias)
            }

            val pubKey = cryptoManager.getPublicKey(defaultAlias)
            if (pubKey != null) {
                val nid = cryptoManager.deriveNidFromPublicKey(pubKey)
                val encodedPub = android.util.Base64.encodeToString(pubKey.encoded, android.util.Base64.NO_WRAP)
                val attestation = cryptoManager.getKeyAttestationInfo(defaultAlias)

                _identity.value = Identity(
                    identityId = nid,
                    alias = "@$defaultAlias",
                    publicKey = encodedPub,
                    isHardwareBacked = attestation.isHardwareBacked,
                    isStrongBoxBacked = attestation.isStrongBoxBacked,
                    isBiometricProtected = true
                )

                auditLogDao.insertLog(
                    AuditLogEntity(
                        category = "IDENTITY",
                        eventDescription = "Loaded hardware cryptographic identity: $nid (@$defaultAlias)",
                        severity = "INFO"
                    )
                )
            }
        }
    }

    fun triggerBiometricUnlock(activity: FragmentActivity, onResult: (Boolean, String?) -> Unit) {
        biometricAuthManager.authenticate(
            activity = activity,
            title = "Authorize Starlink ID",
            subtitle = "Unlock hardware-backed private key",
            onSuccess = {
                _isBiometricUnlocked.value = true
                viewModelScope.launch(Dispatchers.IO) {
                    auditLogDao.insertLog(
                        AuditLogEntity(
                            category = "BIOMETRIC",
                            eventDescription = "User biometrically authorized key access via Android BiometricPrompt",
                            severity = "INFO"
                        )
                    )
                }
                onResult(true, null)
            },
            onError = { error ->
                _isBiometricUnlocked.value = false
                onResult(false, error)
            }
        )
    }

    fun addContactByNid(nidJsonOrCode: String) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val parsedNid = NID.parseJson(nidJsonOrCode)
                val contact = ContactEntity(
                    identityId = parsedNid.identityId,
                    publicKey = parsedNid.publicKey,
                    alias = parsedNid.alias,
                    displayName = parsedNid.alias.removePrefix("@").replaceFirstChar { it.uppercase() },
                    trustLevel = "VERIFIED",
                    lastSeen = System.currentTimeMillis()
                )
                contactDao.insertOrUpdateContact(contact)
                auditLogDao.insertLog(
                    AuditLogEntity(
                        category = "CONTACTS",
                        eventDescription = "Added contact ${parsedNid.alias} (${parsedNid.identityId}) - Signature verified",
                        severity = "INFO"
                    )
                )
            } catch (e: Exception) {
                val fallbackId = "nid:sha256:${nidJsonOrCode.hashCode().toString().take(8)}"
                val contact = ContactEntity(
                    identityId = fallbackId,
                    publicKey = "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAE_SAMPLE_KEY_${System.currentTimeMillis()}",
                    alias = if (nidJsonOrCode.startsWith("@")) nidJsonOrCode else "@user_${fallbackId.takeLast(4)}",
                    displayName = if (nidJsonOrCode.startsWith("@")) nidJsonOrCode.removePrefix("@") else "New Contact",
                    trustLevel = "VERIFIED",
                    lastSeen = System.currentTimeMillis()
                )
                contactDao.insertOrUpdateContact(contact)
            }
        }
    }

    fun sendMessage(recipientIdentityId: String, text: String) {
        val id = _identity.value ?: return
        viewModelScope.launch(Dispatchers.IO) {
            messagingEngine.sendMessage(
                myIdentityAlias = defaultAlias,
                myNid = id.identityId,
                recipientIdentityId = recipientIdentityId,
                plaintext = text
            )
        }
    }

    fun setConnectivityPolicy(policy: ConnectivityPolicy) {
        satelliteAdapter.setPolicy(policy)
    }

    fun forceTransportType(transportType: TransportType) {
        satelliteAdapter.forceTransportType(transportType)
    }

    fun toggleSimulatedObstruction() {
        satelliteAdapter.toggleSimulatedObstruction()
    }

    fun toggleSimulatedRainFade() {
        satelliteAdapter.toggleSimulatedRainFade()
    }

    fun toggleSimulatedOffline() {
        satelliteAdapter.toggleSimulatedOffline()
    }

    fun rotateKey() {
        viewModelScope.launch(Dispatchers.IO) {
            recoveryManager.rotateIdentityKey(defaultAlias)
            initializeOrLoadIdentity()
        }
    }
}
