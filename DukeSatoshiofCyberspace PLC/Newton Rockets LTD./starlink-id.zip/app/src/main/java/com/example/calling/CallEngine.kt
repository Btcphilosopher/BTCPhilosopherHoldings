package com.example.calling

import com.example.networking.SatelliteConnectivityAdapter
import com.example.storage.AuditLogDao
import com.example.storage.AuditLogEntity
import com.example.storage.CallDao
import com.example.storage.CallEntity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.util.UUID

enum class CallState {
    IDLE,
    INITIATING,
    RINGING,
    CONNECTED,
    ENDED
}

data class ActiveCallSession(
    val callId: String,
    val peerIdentityId: String,
    val peerAlias: String,
    val callType: String, // VOICE, VIDEO
    val callState: CallState,
    val durationSeconds: Int = 0,
    val isMuted: Boolean = false,
    val isCameraOn: Boolean = true,
    val audioLevel: Float = 0.4f,
    val transportUsed: String = "SATELLITE",
    val encryptionHandshakeVerified: Boolean = true
)

class CallEngine(
    private val callDao: CallDao,
    private val auditLogDao: AuditLogDao,
    private val satelliteAdapter: SatelliteConnectivityAdapter,
    private val scope: CoroutineScope
) {

    private val _currentCallSession = MutableStateFlow<ActiveCallSession?>(null)
    val currentCallSession: StateFlow<ActiveCallSession?> = _currentCallSession.asStateFlow()

    private var callTimerJob: Job? = null

    fun startCall(peerIdentityId: String, peerAlias: String, callType: String) {
        val callId = "call_${UUID.randomUUID().toString().take(8)}"
        val transport = satelliteAdapter.telemetry.value.transportType.name

        val session = ActiveCallSession(
            callId = callId,
            peerIdentityId = peerIdentityId,
            peerAlias = peerAlias,
            callType = callType,
            callState = CallState.INITIATING,
            transportUsed = transport,
            encryptionHandshakeVerified = true
        )

        _currentCallSession.value = session

        scope.launch(Dispatchers.Main) {
            auditLogDao.insertLog(
                AuditLogEntity(
                    category = "CALL",
                    eventDescription = "Initiating encrypted NID $callType call to $peerAlias via $transport",
                    severity = "INFO"
                )
            )

            delay(1500) // Simulate ICE candidates & NID cryptographic handshake
            _currentCallSession.value = _currentCallSession.value?.copy(callState = CallState.RINGING)

            delay(2000) // Peer accepts call
            _currentCallSession.value = _currentCallSession.value?.copy(callState = CallState.CONNECTED)

            startCallTimer()
        }
    }

    fun toggleMute() {
        val session = _currentCallSession.value ?: return
        _currentCallSession.value = session.copy(isMuted = !session.isMuted)
    }

    fun toggleCamera() {
        val session = _currentCallSession.value ?: return
        _currentCallSession.value = session.copy(isCameraOn = !session.isCameraOn)
    }

    fun endCall() {
        callTimerJob?.cancel()
        val session = _currentCallSession.value ?: return
        
        _currentCallSession.value = session.copy(callState = CallState.ENDED)

        scope.launch(Dispatchers.IO) {
            callDao.insertCall(
                CallEntity(
                    callId = session.callId,
                    peerIdentityId = session.peerIdentityId,
                    peerAlias = session.peerAlias,
                    callType = session.callType,
                    isIncoming = false,
                    durationSeconds = session.durationSeconds,
                    transportUsed = session.transportUsed,
                    status = "COMPLETED"
                )
            )

            auditLogDao.insertLog(
                AuditLogEntity(
                    category = "CALL",
                    eventDescription = "Ended ${session.callType} call with ${session.peerAlias}. Duration: ${session.durationSeconds}s",
                    severity = "INFO"
                )
            )

            delay(1000)
            _currentCallSession.value = null
        }
    }

    private fun startCallTimer() {
        callTimerJob?.cancel()
        callTimerJob = scope.launch(Dispatchers.Default) {
            while (_currentCallSession.value?.callState == CallState.CONNECTED) {
                delay(1000)
                val active = _currentCallSession.value ?: break
                val audioLvl = if (active.isMuted) 0f else (0.2f + (Math.random().toFloat() * 0.6f))
                _currentCallSession.value = active.copy(
                    durationSeconds = active.durationSeconds + 1,
                    audioLevel = audioLvl
                )
            }
        }
    }
}
