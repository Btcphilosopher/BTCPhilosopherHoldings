package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CellTower
import androidx.compose.material.icons.filled.CloudOff
import androidx.compose.material.icons.filled.Grain
import androidx.compose.material.icons.filled.SatelliteAlt
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material.icons.filled.WifiOff
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.networking.ConnectivityPolicy
import com.example.networking.NetworkTelemetry
import com.example.networking.TransportType
import com.example.ui.theme.AerospaceCard
import com.example.ui.theme.AerospaceCardBorder
import com.example.ui.theme.AerospaceNavy
import com.example.ui.theme.AerospaceTextMuted
import com.example.ui.theme.AerospaceTextPrimary
import com.example.ui.theme.AerospaceTextSecondary
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.SatelliteAmber
import com.example.ui.theme.SecurityAlertRed
import com.example.ui.theme.VerifiedGreen

@Composable
fun NetworkScreen(
    telemetry: NetworkTelemetry,
    policy: ConnectivityPolicy,
    onSetPolicy: (ConnectivityPolicy) -> Unit,
    onForceTransport: (TransportType) -> Unit,
    onToggleObstruction: () -> Unit,
    onToggleRainFade: () -> Unit,
    onToggleOffline: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(AerospaceNavy)
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
            .testTag("network_screen")
    ) {
        Text(
            text = "CONNECTIVITY & SATELLITE TELEMETRY",
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace,
            color = AerospaceTextPrimary,
            letterSpacing = 2.sp
        )
        Text(
            text = "Network Abstraction Layer • NID Persists Across Transports",
            fontSize = 11.sp,
            color = AerospaceTextMuted,
            modifier = Modifier.padding(bottom = 16.dp)
        )

        // Live Telemetry Card
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, AerospaceCardBorder, RoundedCornerShape(16.dp)),
            colors = CardDefaults.cardColors(containerColor = AerospaceCard),
            shape = RoundedCornerShape(16.dp)
        ) {
            Column(modifier = Modifier.padding(18.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.SatelliteAlt,
                            contentDescription = "Satellite",
                            tint = SatelliteAmber,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = "${telemetry.transportType.name} LINK",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            color = AerospaceTextPrimary
                        )
                    }

                    Text(
                        text = telemetry.linkState.name,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        color = if (telemetry.isConnected) VerifiedGreen else SecurityAlertRed
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    TelemetryMetric(label = "LATENCY", value = "${telemetry.latencyMs} ms", color = CyberCyan)
                    TelemetryMetric(label = "DOWNLOAD", value = "${telemetry.downloadSpeedMbps} Mbps", color = CyberCyan)
                    TelemetryMetric(label = "UPLOAD", value = "${telemetry.uploadSpeedMbps} Mbps", color = CyberCyan)
                    TelemetryMetric(label = "SIGNAL", value = "${telemetry.signalQualityPercent}%", color = VerifiedGreen)
                }

                Spacer(modifier = Modifier.height(16.dp))
                HorizontalDivider(color = AerospaceCardBorder)
                Spacer(modifier = Modifier.height(12.dp))

                // Orbital Status Info
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(text = "CONSTELLATION", fontSize = 10.sp, color = AerospaceTextMuted)
                    Text(text = telemetry.satelliteConstellation, fontSize = 11.sp, fontFamily = FontFamily.Monospace, color = AerospaceTextPrimary)
                }
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(text = "ELEVATION ANGLE", fontSize = 10.sp, color = AerospaceTextMuted)
                    Text(text = "${telemetry.satelliteElevationDegrees}° Above Horizon", fontSize = 11.sp, fontFamily = FontFamily.Monospace, color = AerospaceTextPrimary)
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Transport Selector Buttons
        Text(
            text = "SELECT ACTIVE TRANSPORT",
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace,
            color = AerospaceTextMuted,
            letterSpacing = 1.sp
        )

        Spacer(modifier = Modifier.height(8.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            TransportChip(
                label = "Satellite",
                icon = Icons.Default.SatelliteAlt,
                isSelected = telemetry.transportType == TransportType.SATELLITE,
                modifier = Modifier.weight(1f),
                onClick = { onForceTransport(TransportType.SATELLITE) }
            )
            TransportChip(
                label = "Wi-Fi",
                icon = Icons.Default.Wifi,
                isSelected = telemetry.transportType == TransportType.WIFI,
                modifier = Modifier.weight(1f),
                onClick = { onForceTransport(TransportType.WIFI) }
            )
            TransportChip(
                label = "Cellular",
                icon = Icons.Default.CellTower,
                isSelected = telemetry.transportType == TransportType.CELLULAR,
                modifier = Modifier.weight(1f),
                onClick = { onForceTransport(TransportType.CELLULAR) }
            )
            TransportChip(
                label = "Offline",
                icon = Icons.Default.WifiOff,
                isSelected = telemetry.transportType == TransportType.OFFLINE,
                modifier = Modifier.weight(1f),
                onClick = { onForceTransport(TransportType.OFFLINE) }
            )
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Satellite Simulation Engine Controls (Section 23)
        Text(
            text = "SATELLITE LINK SIMULATION SUITE",
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace,
            color = SatelliteAmber,
            letterSpacing = 1.sp
        )

        Spacer(modifier = Modifier.height(8.dp))

        Card(
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, AerospaceCardBorder, RoundedCornerShape(12.dp)),
            colors = CardDefaults.cardColors(containerColor = AerospaceCard),
            shape = RoundedCornerShape(12.dp)
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text(
                    text = "Test network resilience, message queueing, and satellite handover in real time.",
                    fontSize = 11.sp,
                    color = AerospaceTextSecondary
                )

                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = onToggleObstruction,
                        colors = ButtonDefaults.buttonColors(containerColor = AerospaceCardBorder),
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(imageVector = Icons.Default.CloudOff, contentDescription = null, tint = SatelliteAmber, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(text = "Obstruction", fontSize = 11.sp, color = SatelliteAmber)
                    }

                    Button(
                        onClick = onToggleRainFade,
                        colors = ButtonDefaults.buttonColors(containerColor = AerospaceCardBorder),
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(imageVector = Icons.Default.Grain, contentDescription = null, tint = CyberCyan, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(text = "Rain Fade", fontSize = 11.sp, color = CyberCyan)
                    }
                }
            }
        }
    }
}

@Composable
private fun TelemetryMetric(label: String, value: String, color: Color) {
    Column {
        Text(text = label, fontSize = 9.sp, fontWeight = FontWeight.Bold, color = AerospaceTextMuted)
        Text(text = value, fontSize = 13.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, color = color)
    }
}

@Composable
private fun TransportChip(
    label: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    isSelected: Boolean,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(10.dp))
            .background(if (isSelected) CyberCyan else AerospaceCard)
            .border(1.dp, if (isSelected) CyberCyan else AerospaceCardBorder, RoundedCornerShape(10.dp))
            .clickable { onClick() }
            .padding(vertical = 10.dp, horizontal = 6.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = if (isSelected) Color.Black else CyberCyan,
                modifier = Modifier.size(18.dp)
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = label,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = if (isSelected) Color.Black else AerospaceTextPrimary
            )
        }
    }
}
