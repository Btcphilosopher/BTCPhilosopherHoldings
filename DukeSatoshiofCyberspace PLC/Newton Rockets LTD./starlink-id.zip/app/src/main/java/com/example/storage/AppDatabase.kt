package com.example.storage

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [
        ContactEntity::class,
        MessageEntity::class,
        CallEntity::class,
        AuditLogEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun contactDao(): ContactDao
    abstract fun messageDao(): MessageDao
    abstract fun callDao(): CallDao
    abstract fun auditLogDao(): AuditLogDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context, scope: CoroutineScope): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "starlink_id_db"
                )
                    .addCallback(DatabaseCallback(scope))
                    .fallbackToDestructiveMigration()
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }

    private class DatabaseCallback(
        private val scope: CoroutineScope
    ) : RoomDatabase.Callback() {
        override fun onCreate(db: SupportSQLiteDatabase) {
            super.onCreate(db)
            INSTANCE?.let { database ->
                scope.launch(Dispatchers.IO) {
                    populateInitialData(database)
                }
            }
        }

        private suspend fun populateInitialData(db: AppDatabase) {
            val now = System.currentTimeMillis()

            // Seed Contacts
            val aliceNid = "nid:sha256:a1ice884f93a1002"
            val bobNid = "nid:sha256:b0b92d8471e49191"
            val carolNid = "nid:sha256:c0a18374f38e2022"

            val alice = ContactEntity(
                identityId = aliceNid,
                publicKey = "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAE7F8C21A493A1B2C3D4E5F6A7B8C9D0E1F2A3B4C5D6E7F8A9B0C1D2E3F4A5B6C7",
                alias = "@alice",
                displayName = "Alice Vance",
                trustLevel = "VERIFIED",
                lastSeen = now - 120000
            )

            val bob = ContactEntity(
                identityId = bobNid,
                publicKey = "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAE11223344556677889900AABBCCDDEEFF11223344556677889900AABBCCDD",
                alias = "@bob",
                displayName = "Bob Miller",
                trustLevel = "VERIFIED",
                lastSeen = now - 3600000
            )

            val carol = ContactEntity(
                identityId = carolNid,
                publicKey = "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAE99887766554433221100FFEEDDCCBBAA99887766554433221100FFEEDD",
                alias = "@carol",
                displayName = "Dr. Carol Zhang",
                trustLevel = "KEY_CHANGED_WARNING",
                lastSeen = now - 86400000,
                previousPublicKey = "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAE0000111122223333444455556666777788889999AAAABBBBCCCCDDDDEEEE"
            )

            db.contactDao().insertOrUpdateContact(alice)
            db.contactDao().insertOrUpdateContact(bob)
            db.contactDao().insertOrUpdateContact(carol)

            // Seed Initial Messages
            val msg1 = MessageEntity(
                messageId = "msg_001",
                conversationIdentityId = aliceNid,
                senderIdentityId = aliceNid,
                receiverIdentityId = "my_identity",
                content = "Greetings! Connecting directly over Starlink LEO satellite link.",
                encryptedPayloadBase64 = "g3F8A2m0K1p2====",
                signatureBase64 = "SIG_ALICE_VALID_7F8C",
                isVerifiedSignature = true,
                transportUsed = "SATELLITE",
                isOutgoing = false,
                timestamp = now - 1800000,
                status = "READ"
            )

            val msg2 = MessageEntity(
                messageId = "msg_002",
                conversationIdentityId = aliceNid,
                senderIdentityId = "my_identity",
                receiverIdentityId = aliceNid,
                content = "Signature verified. Zero telephone numbers needed.",
                encryptedPayloadBase64 = "x8A9K1p2M3n4====",
                signatureBase64 = "SIG_MY_DEVICE_VALID",
                isVerifiedSignature = true,
                transportUsed = "SATELLITE",
                isOutgoing = true,
                timestamp = now - 900000,
                status = "DELIVERED"
            )

            val msg3 = MessageEntity(
                messageId = "msg_003",
                conversationIdentityId = bobNid,
                senderIdentityId = bobNid,
                receiverIdentityId = "my_identity",
                content = "Did you complete the hardware key attestation test?",
                encryptedPayloadBase64 = "p2M3n4x8A9K1====",
                signatureBase64 = "SIG_BOB_VALID",
                isVerifiedSignature = true,
                transportUsed = "WIFI",
                isOutgoing = false,
                timestamp = now - 7200000,
                status = "READ"
            )

            db.messageDao().insertMessage(msg1)
            db.messageDao().insertMessage(msg2)
            db.messageDao().insertMessage(msg3)

            // Seed Calls
            val call1 = CallEntity(
                callId = "call_001",
                peerIdentityId = aliceNid,
                peerAlias = "@alice",
                callType = "VOICE",
                isIncoming = true,
                durationSeconds = 245,
                transportUsed = "SATELLITE",
                timestamp = now - 3600000,
                status = "COMPLETED"
            )

            db.callDao().insertCall(call1)

            // Seed Audit Logs
            db.auditLogDao().insertLog(
                AuditLogEntity(
                    timestamp = now - 10000,
                    category = "BIOMETRIC",
                    eventDescription = "Identity key unlocked via Android BiometricPrompt",
                    severity = "INFO"
                )
            )
            db.auditLogDao().insertLog(
                AuditLogEntity(
                    timestamp = now - 8000,
                    category = "KEYSTORE",
                    eventDescription = "EC secp256r1 hardware key pair validated inside StrongBox TEE",
                    severity = "INFO"
                )
            )
            db.auditLogDao().insertLog(
                AuditLogEntity(
                    timestamp = now - 5000,
                    category = "NETWORK",
                    eventDescription = "Handover: Wi-Fi lost -> Starlink LEO Satellite transport active",
                    severity = "INFO"
                )
            )
        }
    }
}
