package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Message
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material.icons.filled.QrCode
import androidx.compose.material.icons.filled.SatelliteAlt
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.identity.Identity
import com.example.networking.NetworkTelemetry
import com.example.ui.theme.AerospaceCard
import com.example.ui.theme.AerospaceCardBorder
import com.example.ui.theme.AerospaceNavy
import com.example.ui.theme.AerospaceTextMuted
import com.example.ui.theme.AerospaceTextPrimary
import com.example.ui.theme.AerospaceTextSecondary
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.SatelliteAmber
import com.example.ui.theme.VerifiedGreen

@Composable
fun HomeScreen(
    identity: Identity?,
    telemetry: NetworkTelemetry,
    contactCount: Int,
    messageCount: Int,
    callCount: Int,
    onNavigateToMessages: () -> Unit,
    onNavigateToCalls: () -> Unit,
    onNavigateToContacts: () -> Unit,
    onNavigateToIdentity: () -> Unit,
    onNavigateToNetwork: () -> Unit,
    onTriggerBiometricUnlock: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(AerospaceNavy)
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
            .testTag("home_screen"),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(modifier = Modifier.height(8.dp))

        // Title Header
        Text(
            text = "STARLINK ID",
            fontSize = 22.sp,
            fontWeight = FontWeight.Black,
            fontFamily = FontFamily.Monospace,
            letterSpacing = 4.sp,
            color = AerospaceTextPrimary
        )
        Text(
            text = "Your phone number is your key.",
            fontSize = 12.sp,
            color = CyberCyan,
            letterSpacing = 1.sp,
            modifier = Modifier.padding(top = 2.dp)
        )

        Spacer(modifier = Modifier.height(20.dp))

        // Primary Cryptographic Identity Banner Card
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, AerospaceCardBorder, RoundedCornerShape(16.dp)),
            colors = CardDefaults.cardColors(containerColor = AerospaceCard),
            shape = RoundedCornerShape(16.dp)
        ) {
            Column(
                modifier = Modifier.padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Shield,
                        contentDescription = "Shield",
                        tint = VerifiedGreen,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = identity?.alias ?: "@newton",
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        color = AerospaceTextPrimary
                    )
                }

                Spacer(modifier = Modifier.height(6.dp))

                Text(
                    text = identity?.identityId ?: "nid:sha256:7f8c21a493a1002",
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    color = AerospaceTextMuted,
                    letterSpacing = 1.sp
                )

                Spacer(modifier = Modifier.height(16.dp))

                HorizontalDivider(color = AerospaceCardBorder)

                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    IdentityBadgeItem(icon = Icons.Default.Lock, text = "Hardware Key")
                    IdentityBadgeItem(icon = Icons.Default.Fingerprint, text = "Biometric Auth")
                    IdentityBadgeItem(icon = Icons.Default.CheckCircle, text = "No SIM/Number")
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Quick Stats Instrument Row
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            StatCard(
                title = "Messages",
                value = messageCount.toString(),
                subtitle = "E2E Encrypted",
                icon = Icons.Default.Message,
                modifier = Modifier.weight(1f),
                onClick = onNavigateToMessages
            )
            StatCard(
                title = "Calls",
                value = callCount.toString(),
                subtitle = "Direct NID",
                icon = Icons.Default.Call,
                modifier = Modifier.weight(1f),
                onClick = onNavigateToCalls
            )
            StatCard(
                title = "Contacts",
                value = contactCount.toString(),
                subtitle = "Verified Keys",
                icon = Icons.Default.PersonAdd,
                modifier = Modifier.weight(1f),
                onClick = onNavigateToContacts
            )
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Active Transport Telemetry Card
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .clickable { onNavigateToNetwork() }
                .border(1.dp, AerospaceCardBorder, RoundedCornerShape(16.dp)),
            colors = CardDefaults.cardColors(containerColor = AerospaceCard),
            shape = RoundedCornerShape(16.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.SatelliteAlt,
                        contentDescription = "Satellite",
                        tint = SatelliteAmber,
                        modifier = Modifier.size(28.dp)
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = "NETWORK TRANSPORT",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace,
                            color = AerospaceTextMuted,
                            letterSpacing = 1.sp
                        )
                        Text(
                            text = "${telemetry.transportType.name} LINK ACTIVE",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = AerospaceTextPrimary
                        )
                        Text(
                            text = "Latency: ${telemetry.latencyMs} ms • Signal: ${telemetry.signalQualityPercent}%",
                            fontSize = 11.sp,
                            color = CyberCyan
                        )
                    }
                }

                Button(
                    onClick = onNavigateToNetwork,
                    colors = ButtonDefaults.buttonColors(containerColor = CyberCyan.copy(alpha = 0.15f)),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text(text = "Manage", color = CyberCyan, fontSize = 11.sp)
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Primary Launch Buttons
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Button(
                onClick = onNavigateToMessages,
                modifier = Modifier
                    .weight(1f)
                    .height(48.dp)
                    .testTag("home_new_message_btn"),
                colors = ButtonDefaults.buttonColors(containerColor = CyberCyan),
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(imageVector = Icons.Default.Message, contentDescription = null, tint = Color.Black)
                Spacer(modifier = Modifier.width(8.dp))
                Text(text = "Secure Chat", color = Color.Black, fontWeight = FontWeight.Bold)
            }

            Button(
                onClick = onNavigateToIdentity,
                modifier = Modifier
                    .weight(1f)
                    .height(48.dp)
                    .testTag("home_identity_btn"),
                colors = ButtonDefaults.buttonColors(containerColor = AerospaceCardBorder),
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(imageVector = Icons.Default.QrCode, contentDescription = null, tint = AerospaceTextPrimary)
                Spacer(modifier = Modifier.width(8.dp))
                Text(text = "Share NID", color = AerospaceTextPrimary, fontWeight = FontWeight.Bold)
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        OutlinedButton(
            onClick = onTriggerBiometricUnlock,
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp)
                .testTag("home_biometric_auth_btn"),
            shape = RoundedCornerShape(12.dp)
        ) {
            Icon(imageVector = Icons.Default.Fingerprint, contentDescription = null, tint = VerifiedGreen)
            Spacer(modifier = Modifier.width(8.dp))
            Text(text = "Test Hardware BiometricPrompt", color = VerifiedGreen, fontWeight = FontWeight.Bold)
        }

        Spacer(modifier = Modifier.height(16.dp))
    }
}

@Composable
private fun IdentityBadgeItem(icon: androidx.compose.ui.graphics.vector.ImageVector, text: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(imageVector = icon, contentDescription = null, tint = CyberCyan, modifier = Modifier.size(14.dp))
        Spacer(modifier = Modifier.width(4.dp))
        Text(text = text, fontSize = 11.sp, color = AerospaceTextSecondary, fontWeight = FontWeight.Medium)
    }
}

@Composable
private fun StatCard(
    title: String,
    value: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Card(
        modifier = modifier
            .clickable { onClick() }
            .border(1.dp, AerospaceCardBorder, RoundedCornerShape(12.dp)),
        colors = CardDefaults.cardColors(containerColor = AerospaceCard),
        shape = RoundedCornerShape(12.dp)
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            horizontalAlignment = Alignment.Start
        ) {
            Icon(imageVector = icon, contentDescription = title, tint = CyberCyan, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.height(8.dp))
            Text(text = value, fontSize = 20.sp, fontWeight = FontWeight.Bold, color = AerospaceTextPrimary)
            Text(text = title, fontSize = 11.sp, fontWeight = FontWeight.Medium, color = AerospaceTextSecondary)
            Text(text = subtitle, fontSize = 9.sp, color = AerospaceTextMuted)
        }
    }
}
