/**
 * Newton Rockets Ltd. - Core Astrodynamics & Orbital Mechanics Engine
 * Mathematical implementation matching IAU 2015, NASA JPL Standish Ephemerides, and Bate-Mueller-White (BMW)
 */

export interface Vector3D {
  x: number;
  y: number;
  z: number;
}

export interface StateVector {
  r: Vector3D; // km
  v: Vector3D; // km/s
  epoch: Date;
  frame: string;
}

export interface OrbitalElements {
  a: number;    // Semi-major axis in AU
  a_km: number; // Semi-major axis in km
  e: number;    // Eccentricity
  inc: number;  // Inclination in radians
  inc_deg: number;
  raan: number; // Longitude of ascending node in radians
  raan_deg: number;
  argp: number; // Argument of periapsis in radians
  argp_deg: number;
  nu: number;   // True anomaly in radians
  nu_deg: number;
  M: number;    // Mean anomaly in radians
  M_deg: number;
  period_days: number;
  energy: number; // Specific mechanical energy km^2/s^2
  angular_momentum: number; // Specific angular momentum km^2/s
}

export interface CelestialBodyData {
  name: string;
  type: 'star' | 'planet' | 'moon' | 'spacecraft';
  mass_kg: number;
  radius_km: number;
  rotation_period_days: number;
  axial_tilt_deg: number;
  albedo: number;
  atmosphere: boolean;
  mu: number; // km^3 / s^2
  soi_radius_km: number;
  color: string;
  elements?: OrbitalElements;
  state?: StateVector;
  solar_flux?: number; // W / m^2
  illuminated_fraction?: number;
  phase_angle_deg?: number;
}

export interface MissionMilestone {
  id: string;
  epoch: string;
  name: string;
  type: 'BURN' | 'FLYBY' | 'SCIENCE' | 'ORBIT_INSERTION';
  body?: string;
  delta_v_m_s?: number;
  description: string;
  status: 'COMPLETED' | 'SCHEDULED' | 'PLANNED';
}

export const CONSTANTS = {
  G_KM: 6.67430e-20, // km^3 kg^-1 s^-2
  SPEED_OF_LIGHT_KM_S: 299792.458,
  AU_KM: 149597870.7,
  MU_SUN: 1.32712440018e11, // km^3 s^-2
  RADIUS_SUN_KM: 696342.0,
  SOLAR_CONSTANT_1AU: 1361.0, // W / m^2
  JD_J2000: 2451545.0,
  EPSILON_J2000_RAD: (23.4392911 * Math.PI) / 180.0,
  MU: {
    Sun: 1.32712440018e11,
    Mercury: 22031.86,
    Venus: 324858.592,
    Earth: 398600.4418,
    Moon: 4902.800066,
    Mars: 42828.375214,
    Jupiter: 126686534.9,
    Saturn: 37931207.7,
    Uranus: 5793939.3,
    Neptune: 6836527.1,
  }
};

// Math helpers
export function wrap2Pi(angleRad: number): number {
  return ((angleRad % (2 * Math.PI)) + 2 * Math.PI) % (2 * Math.PI);
}

export function wrapPi(angleRad: number): number {
  const wrapped = wrap2Pi(angleRad);
  return wrapped > Math.PI ? wrapped - 2 * Math.PI : wrapped;
}

export function degToRad(deg: number): number {
  return (deg * Math.PI) / 180.0;
}

export function radToDeg(rad: number): number {
  return (rad * 180.0) / Math.PI;
}

export function auToKm(au: number): number {
  return au * CONSTANTS.AU_KM;
}

export function kmToAu(km: number): number {
  return km / CONSTANTS.AU_KM;
}

// Convert Date to Julian Date (UTC)
export function dateToJD(date: Date): number {
  return 2440587.5 + date.getTime() / 86400000.0;
}

export function jdToDate(jd: number): Date {
  return new Date((jd - 2440587.5) * 86400000.0);
}

export function dateToCenturiesJ2000(date: Date): number {
  const jd = dateToJD(date);
  return (jd - CONSTANTS.JD_J2000) / 36525.0;
}

// High-precision Kepler solver (Halley third-order step converging to 1e-14)
export function solveKeplerEccentricAnomaly(M: number, e: number, tol = 1e-14, maxIter = 40): number {
  const M_wrapped = wrapPi(M);

  let E: number;
  if (Math.abs(M_wrapped) < 0.2) {
    E = M_wrapped / (1 - e);
  } else {
    E = M_wrapped + e * Math.sin(M_wrapped) + 0.5 * e * e * Math.sin(2 * M_wrapped);
  }

  for (let i = 0; i < maxIter; i++) {
    const sE = Math.sin(E);
    const cE = Math.cos(E);
    const f = E - e * sE - M_wrapped;
    const fp = 1.0 - e * cE;
    const fpp = e * sE;

    // Halley's third-order correction
    const delta = -f / (fp - (0.5 * f * fpp) / fp);
    E += delta;

    if (Math.abs(delta) < tol) {
      return wrap2Pi(E);
    }
  }
  return wrap2Pi(E);
}

export function solveKeplerTrueAnomaly(M: number, e: number): number {
  const E = solveKeplerEccentricAnomaly(M, e);
  const sinNu = (Math.sqrt(1.0 - e * e) * Math.sin(E)) / (1.0 - e * Math.cos(E));
  const cosNu = (Math.cos(E) - e) / (1.0 - e * Math.cos(E));
  return wrap2Pi(Math.atan2(sinNu, cosNu));
}

// Standish JPL Planetary Ephemeris coefficients (J2000 + secular rates per century)
interface JplPlanetCoeffs {
  a0: number; a_dot: number;
  e0: number; e_dot: number;
  I0: number; I_dot: number;
  L0: number; L_dot: number;
  varpi0: number; varpi_dot: number;
  node0: number; node_dot: number;
}

const JPL_COEFFS: Record<string, JplPlanetCoeffs> = {
  Mercury: { a0: 0.38709927, a_dot: 0.00000037, e0: 0.20563593, e_dot: 0.00001906, I0: 7.00497902, I_dot: -0.00594749, L0: 252.25032350, L_dot: 149472.67411175, varpi0: 77.45779628, varpi_dot: 0.16047689, node0: 48.33076593, node_dot: -0.12534081 },
  Venus:   { a0: 0.72333566, a_dot: 0.00000390, e0: 0.00677672, e_dot: -0.00004107, I0: 3.39467605, I_dot: -0.00078890, L0: 181.97909950, L_dot: 58517.81538729, varpi0: 131.60246718, varpi_dot: 0.00268329, node0: 76.67984255, node_dot: -0.27769418 },
  Earth:   { a0: 1.00000261, a_dot: 0.00000562, e0: 0.01671123, e_dot: -0.00004392, I0: -0.00001531, I_dot: -0.01294668, L0: 100.46457166, L_dot: 35999.37244981, varpi0: 102.93768193, varpi_dot: 0.32327364, node0: 0.0, node_dot: 0.0 },
  Mars:    { a0: 1.52371034, a_dot: 0.00001847, e0: 0.09339410, e_dot: 0.00007882, I0: 1.84969142, I_dot: -0.00813131, L0: -4.55343205, L_dot: 19140.30268499, varpi0: -23.94362959, varpi_dot: 0.44441088, node0: 49.55953891, node_dot: -0.29257343 },
  Jupiter: { a0: 5.20288700, a_dot: -0.00011607, e0: 0.04838624, e_dot: -0.00013253, I0: 1.30439695, I_dot: -0.00183714, L0: 34.39644051, L_dot: 3034.74612775, varpi0: 14.72847983, varpi_dot: 0.21252668, node0: 100.47390909, node_dot: 0.20469106 },
  Saturn:  { a0: 9.53667594, a_dot: -0.00125060, e0: 0.05386179, e_dot: -0.00050991, I0: 2.48599187, I_dot: 0.00193609, L0: 49.95424423, L_dot: 1222.49362201, varpi0: 92.59887831, varpi_dot: -0.41897216, node0: 113.66242448, node_dot: -0.28867794 },
  Uranus:  { a0: 19.18916464, a_dot: -0.00196176, e0: 0.04725744, e_dot: -0.00004397, I0: 0.77263783, I_dot: -0.00242939, L0: 313.23810451, L_dot: 428.48202785, varpi0: 170.95427630, varpi_dot: 0.40805281, node0: 74.01692503, node_dot: 0.04240589 },
  Neptune: { a0: 30.06992276, a_dot: 0.00026291, e0: 0.00859048, e_dot: 0.00005105, I0: 1.77004347, I_dot: 0.00035372, L0: -55.12002969, L_dot: 218.45945325, varpi0: 44.96476227, varpi_dot: -0.32241464, node0: 131.78422574, node_dot: -0.00508664 }
};

export function getPlanetOrbitalElements(planetName: string, date: Date): OrbitalElements {
  const c = JPL_COEFFS[planetName];
  if (!c) {
    throw new Error(`Unknown planetary body: ${planetName}`);
  }
  const T = dateToCenturiesJ2000(date);
  const a_au = c.a0 + c.a_dot * T;
  const e = c.e0 + c.e_dot * T;
  const I_deg = c.I0 + c.I_dot * T;
  const L_deg = c.L0 + c.L_dot * T;
  const varpi_deg = c.varpi0 + c.varpi_dot * T;
  const node_deg = c.node0 + c.node_dot * T;

  const omega_deg = ((varpi_deg - node_deg) % 360 + 360) % 360;
  const M_deg = ((L_deg - varpi_deg) % 360 + 360) % 360;

  const inc = degToRad(I_deg);
  const raan = degToRad(node_deg);
  const argp = degToRad(omega_deg);
  const M = degToRad(M_deg);
  const nu = solveKeplerTrueAnomaly(M, e);
  const nu_deg = radToDeg(nu);

  const a_km = auToKm(a_au);
  const mu = CONSTANTS.MU_SUN;
  const period_seconds = 2 * Math.PI * Math.sqrt(Math.pow(a_km, 3) / mu);
  const energy = -mu / (2 * a_km);
  const h = Math.sqrt(mu * a_km * (1 - e * e));

  return {
    a: a_au,
    a_km,
    e,
    inc,
    inc_deg: I_deg,
    raan,
    raan_deg: node_deg,
    argp,
    argp_deg: omega_deg,
    nu,
    nu_deg,
    M,
    M_deg,
    period_days: period_seconds / 86400,
    energy,
    angular_momentum: h
  };
}

// Convert Keplerian Elements to Cartesian State Vector [r, v] in Heliocentric Ecliptic J2000
export function elementsToStateVector(
  elements: OrbitalElements,
  epoch: Date,
  mu = CONSTANTS.MU_SUN,
  frame = "Heliocentric Ecliptic J2000"
): StateVector {
  const { a_km, e, inc, raan, argp, nu } = elements;
  const p = a_km * (1.0 - e * e);
  const r_mag = p / (1.0 + e * Math.cos(nu));

  // Perifocal PQW coordinates
  const r_pqw_x = r_mag * Math.cos(nu);
  const r_pqw_y = r_mag * Math.sin(nu);

  const sqrt_mu_p = Math.sqrt(mu / p);
  const v_pqw_x = -sqrt_mu_p * Math.sin(nu);
  const v_pqw_y = sqrt_mu_p * (e + Math.cos(nu));

  // Rotation matrix from PQW to Inertial
  const cos_O = Math.cos(raan); const sin_O = Math.sin(raan);
  const cos_i = Math.cos(inc);  const sin_i = Math.sin(inc);
  const cos_w = Math.cos(argp); const sin_w = Math.sin(argp);

  const P_x = cos_O * cos_w - sin_O * sin_w * cos_i;
  const P_y = sin_O * cos_w + cos_O * sin_w * cos_i;
  const P_z = sin_w * sin_i;

  const Q_x = -cos_O * sin_w - sin_O * cos_w * cos_i;
  const Q_y = -sin_O * sin_w + cos_O * cos_w * cos_i;
  const Q_z = cos_w * sin_i;

  const rx = r_pqw_x * P_x + r_pqw_y * Q_x;
  const ry = r_pqw_x * P_y + r_pqw_y * Q_y;
  const rz = r_pqw_x * P_z + r_pqw_y * Q_z;

  const vx = v_pqw_x * P_x + v_pqw_y * Q_x;
  const vy = v_pqw_x * P_y + v_pqw_y * Q_y;
  const vz = v_pqw_x * P_z + v_pqw_y * Q_z;

  return {
    r: { x: rx, y: ry, z: rz },
    v: { x: vx, y: vy, z: vz },
    epoch,
    frame
  };
}

// Convert Cartesian State Vector to Keplerian Orbital Elements
export function stateVectorToElements(
  r: Vector3D,
  v: Vector3D,
  epoch: Date,
  mu = CONSTANTS.MU_SUN,
  frame = "Heliocentric Ecliptic J2000"
): OrbitalElements {
  const r_mag = Math.sqrt(r.x * r.x + r.y * r.y + r.z * r.z);
  const v_mag = Math.sqrt(v.x * v.x + v.y * v.y + v.z * v.z);

  const hx = r.y * v.z - r.z * v.y;
  const hy = r.z * v.x - r.x * v.z;
  const hz = r.x * v.y - r.y * v.x;
  const h_mag = Math.sqrt(hx * hx + hy * hy + hz * hz);

  const nx = -hy;
  const ny = hx;
  const n_mag = Math.sqrt(nx * nx + ny * ny);

  const r_dot_v = r.x * v.x + r.y * v.y + r.z * v.z;
  const ex = (1 / mu) * ((v_mag * v_mag - mu / r_mag) * r.x - r_dot_v * v.x);
  const ey = (1 / mu) * ((v_mag * v_mag - mu / r_mag) * r.y - r_dot_v * v.y);
  const ez = (1 / mu) * ((v_mag * v_mag - mu / r_mag) * r.z - r_dot_v * v.z);
  const e_mag = Math.sqrt(ex * ex + ey * ey + ez * ez);

  const energy = 0.5 * v_mag * v_mag - mu / r_mag;
  const a_km = -mu / (2 * energy);
  const a_au = kmToAu(a_km);

  const inc = Math.acos(Math.max(-1.0, Math.min(1.0, hz / h_mag)));

  let raan = 0;
  if (n_mag > 1e-10) {
    raan = Math.acos(Math.max(-1.0, Math.min(1.0, nx / n_mag)));
    if (ny < 0) raan = 2 * Math.PI - raan;
  }

  let argp = 0;
  if (n_mag > 1e-10 && e_mag > 1e-10) {
    const n_dot_e = nx * ex + ny * ey;
    argp = Math.acos(Math.max(-1.0, Math.min(1.0, n_dot_e / (n_mag * e_mag))));
    if (ez < 0) argp = 2 * Math.PI - argp;
  }

  let nu = 0;
  if (e_mag > 1e-10) {
    const e_dot_r = ex * r.x + ey * r.y + ez * r.z;
    nu = Math.acos(Math.max(-1.0, Math.min(1.0, e_dot_r / (e_mag * r_mag))));
    if (r_dot_v < 0) nu = 2 * Math.PI - nu;
  } else {
    nu = Math.atan2(r.y, r.x);
  }

  // Mean anomaly M from nu
  const sin_nu = Math.sin(nu);
  const cos_nu = Math.cos(nu);
  const sin_E = (Math.sqrt(1 - e_mag * e_mag) * sin_nu) / (1 + e_mag * cos_nu);
  const cos_E = (e_mag + cos_nu) / (1 + e_mag * cos_nu);
  const E = wrap2Pi(Math.atan2(sin_E, cos_E));
  const M = wrap2Pi(E - e_mag * Math.sin(E));

  const period_seconds = 2 * Math.PI * Math.sqrt(Math.pow(Math.abs(a_km), 3) / mu);

  return {
    a: a_au,
    a_km,
    e: e_mag,
    inc,
    inc_deg: radToDeg(inc),
    raan,
    raan_deg: radToDeg(raan),
    argp,
    argp_deg: radToDeg(argp),
    nu,
    nu_deg: radToDeg(nu),
    M,
    M_deg: radToDeg(M),
    period_days: period_seconds / 86400,
    energy,
    angular_momentum: h_mag
  };
}

// Propagate Keplerian orbit forward/backward by delta_t seconds
export function propagateKeplerian(
  initialElements: OrbitalElements,
  delta_t_seconds: number,
  mu = CONSTANTS.MU_SUN
): OrbitalElements {
  const { a_km, e, inc, raan, argp } = initialElements;
  const n = Math.sqrt(mu / Math.pow(a_km, 3)); // Mean motion [rad/s]

  const M_t = wrap2Pi(initialElements.M + n * delta_t_seconds);
  const nu_t = solveKeplerTrueAnomaly(M_t, e);

  return {
    ...initialElements,
    M: M_t,
    M_deg: radToDeg(M_t),
    nu: nu_t,
    nu_deg: radToDeg(nu_t)
  };
}

// Relative motion calculation between two objects
export function computeRelativeGeometry(stateA: StateVector, stateB: StateVector) {
  const dx = stateB.r.x - stateA.r.x;
  const dy = stateB.r.y - stateA.r.y;
  const dz = stateB.r.z - stateA.r.z;
  const range_km = Math.sqrt(dx * dx + dy * dy + dz * dz);
  const range_au = kmToAu(range_km);

  const dvx = stateB.v.x - stateA.v.x;
  const dvy = stateB.v.y - stateA.v.y;
  const dvz = stateB.v.z - stateA.v.z;
  const rel_speed_km_s = Math.sqrt(dvx * dvx + dvy * dvy + dvz * dvz);

  // Range rate (closing velocity) dr/dt = (dr . dv) / r
  const r_dot_v = dx * dvx + dy * dvy + dz * dvz;
  const range_rate = range_km > 0 ? r_dot_v / range_km : 0;
  const closing_velocity = -range_rate; // Positive if approaching

  const light_time_s = range_km / CONSTANTS.SPEED_OF_LIGHT_KM_S;

  return {
    range_km,
    range_au,
    rel_speed_km_s,
    closing_velocity_km_s: closing_velocity,
    light_time_s
  };
}

// Hyperbolic Gravity Assist Flyby Geometry
export function computeFlybyGeometry(v_inf_in_km_s: number, r_p_km: number, mu_planet: number, r_planet_km: number) {
  const a_hyp = -mu_planet / (v_inf_in_km_s * v_inf_in_km_s);
  const e_hyp = 1.0 + (r_p_km * v_inf_in_km_s * v_inf_in_km_s) / mu_planet;
  const delta_turn_rad = 2.0 * Math.asin(1.0 / e_hyp);
  const delta_v_flyby = 2.0 * v_inf_in_km_s * Math.sin(delta_turn_rad / 2.0);
  const alt_periapsis_km = r_p_km - r_planet_km;
  const b_parameter_km = Math.abs(a_hyp) * Math.sqrt(e_hyp * e_hyp - 1.0);

  return {
    v_inf_km_s: v_inf_in_km_s,
    r_periapsis_km: r_p_km,
    alt_periapsis_km,
    eccentricity: e_hyp,
    turning_angle_rad: delta_turn_rad,
    turning_angle_deg: radToDeg(delta_turn_rad),
    delta_v_flyby_km_s: delta_v_flyby,
    b_parameter_km
  };
}

// Solar Flux & Photometry
export function computeSolarFlux(r_sun_km: number): number {
  const r_au = kmToAu(r_sun_km);
  return CONSTANTS.SOLAR_CONSTANT_1AU / (r_au * r_au);
}

export function computePhaseAngle(r_body_sun: Vector3D, r_body_obs: Vector3D): number {
  const dot = r_body_sun.x * r_body_obs.x + r_body_sun.y * r_body_obs.y + r_body_sun.z * r_body_obs.z;
  const s_mag = Math.sqrt(r_body_sun.x ** 2 + r_body_sun.y ** 2 + r_body_sun.z ** 2);
  const o_mag = Math.sqrt(r_body_obs.x ** 2 + r_body_obs.y ** 2 + r_body_obs.z ** 2);
  if (s_mag === 0 || o_mag === 0) return 0;
  return Math.acos(Math.max(-1.0, Math.min(1.0, dot / (s_mag * o_mag))));
}

export function computeIlluminatedFraction(phaseAngleRad: number): number {
  return 0.5 * (1.0 + Math.cos(phaseAngleRad));
}
