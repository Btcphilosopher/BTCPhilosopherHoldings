'use client';

import React from 'react';
import Link from 'next/link';
import { Maximize2, Minimize2, Moon, Sun, Download, Radio, Orbit, Activity, Table, Calendar, Compass, Code, ShieldCheck } from 'lucide-react';

interface TopBarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  utcTimeStr: string;
  missionDayStr: string;
  isArrayMode: boolean;
  setIsArrayMode: (val: boolean | ((prev: boolean) => boolean)) => void;
  isNightMode: boolean;
  setIsNightMode: (val: boolean | ((prev: boolean) => boolean)) => void;
  onOpenReport: () => void;
  activeFrame: string;
  scaleMode: 'TRUE' | 'ENHANCED';
  setScaleMode: (mode: 'TRUE' | 'ENHANCED') => void;
}

export const TopBar: React.FC<TopBarProps> = ({
  activeTab,
  setActiveTab,
  utcTimeStr,
  missionDayStr,
  isArrayMode,
  setIsArrayMode,
  isNightMode,
  setIsNightMode,
  onOpenReport,
  activeFrame,
  scaleMode,
  setScaleMode,
}) => {
  const navItems = [
    { id: 'array', label: 'Orbital Array', icon: Orbit },
    { id: 'grid', label: 'Planetary Grid', icon: Table },
    { id: 'timeline', label: 'Mission Timeline', icon: Calendar },
    { id: 'relative', label: 'Relative Motion', icon: Compass },
    { id: 'flyby', label: 'Flyby Analyzer', icon: Activity },
    { id: 'montecarlo', label: 'Monte Carlo', icon: Radio },
    { id: 'provenance', label: 'Provenance', icon: ShieldCheck },
    { id: 'rplatform', label: 'R Platform', icon: Code },
  ];

  return (
    <header className="flex items-center justify-between px-4 py-2.5 border-b border-slate-800 bg-[#07090E]/95 backdrop-blur-md shrink-0 select-none z-30">
      {/* Zone 1: Single Brand Lockup */}
      <div className="flex items-center gap-3">
        <Link href="/" className="text-sm font-semibold tracking-wider text-slate-100 uppercase flex items-center gap-2 whitespace-nowrap">
          <span className="w-2.5 h-2.5 rounded-full bg-sky-400 ring-2 ring-sky-400/30"></span>
          NEWTON ROCKETS LTD.
          <span className="text-slate-400 font-normal">/</span>
          <span className="text-sky-400 font-normal">PLANETARY ARRAY</span>
        </Link>
        <div className="hidden xl:flex items-center gap-2 text-[11px] text-slate-400 font-mono pl-3 border-l border-slate-800">
          <span className="text-slate-500">FRAME:</span>
          <span className="text-slate-300 font-medium">{activeFrame}</span>
          <span className="text-slate-600">·</span>
          <button
            onClick={() => setScaleMode(scaleMode === 'TRUE' ? 'ENHANCED' : 'TRUE')}
            className="hover:text-sky-400 transition-colors text-slate-400 flex items-center gap-1 cursor-pointer"
            title="Click to toggle scale representation"
          >
            <span>SCALE:</span>
            <span className={scaleMode === 'TRUE' ? 'text-amber-400 font-medium' : 'text-emerald-400 font-medium'}>
              {scaleMode === 'TRUE' ? '1:1 PHYSICAL' : 'ENHANCED 1500×'}
            </span>
          </button>
        </div>
      </div>

      {/* Zone 2: Navigation Links */}
      <nav className="hidden lg:flex items-center gap-1">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`flex items-center gap-1.5 px-2.5 py-1 text-xs font-medium rounded transition-colors cursor-pointer whitespace-nowrap ${
                isActive
                  ? 'text-sky-400 bg-sky-950/40 border border-sky-800/60'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/60 border border-transparent'
              }`}
            >
              <Icon className="w-3.5 h-3.5" />
              <span>{item.label}</span>
            </button>
          );
        })}
      </nav>

      {/* Zone 3: Mission Clock & Actions */}
      <div className="flex items-center gap-3">
        {/* Orbital Mission Clock */}
        <div className="flex flex-col text-right font-mono tabular-nums leading-tight border-r border-slate-800 pr-3">
          <div className="text-xs font-semibold text-slate-200 tracking-wider">
            {utcTimeStr}
          </div>
          <div className="text-[10px] text-sky-400 font-medium">
            {missionDayStr}
          </div>
        </div>

        {/* Array Mode Toggle */}
        <button
          onClick={() => setIsArrayMode(prev => !prev)}
          className={`px-2.5 py-1.5 text-xs font-medium rounded border transition-colors flex items-center gap-1.5 cursor-pointer whitespace-nowrap ${
            isArrayMode
              ? 'bg-amber-500/20 border-amber-500/50 text-amber-300 hover:bg-amber-500/30'
              : 'bg-slate-900 border-slate-800 text-slate-300 hover:bg-slate-800 hover:text-slate-100'
          }`}
          title="Toggle Large-Format Array Mode for Wall Monitors"
        >
          {isArrayMode ? <Minimize2 className="w-3.5 h-3.5" /> : <Maximize2 className="w-3.5 h-3.5" />}
          <span className="hidden sm:inline">{isArrayMode ? 'EXIT ARRAY' : 'ARRAY MODE'}</span>
        </button>

        {/* Night / Control Room Mode */}
        <button
          onClick={() => setIsNightMode(prev => !prev)}
          className="p-1.5 text-slate-400 hover:text-slate-100 bg-slate-900 hover:bg-slate-800 border border-slate-800 rounded transition-colors cursor-pointer"
          title={isNightMode ? 'Switch to Standard Lab Mode' : 'Switch to Night Control Room Mode'}
        >
          {isNightMode ? <Sun className="w-3.5 h-3.5 text-amber-400" /> : <Moon className="w-3.5 h-3.5" />}
        </button>

        {/* Export Dossier */}
        <button
          onClick={onOpenReport}
          className="px-2.5 py-1.5 text-xs font-medium bg-sky-600 hover:bg-sky-500 text-white rounded transition-colors flex items-center gap-1.5 cursor-pointer whitespace-nowrap"
        >
          <Download className="w-3.5 h-3.5" />
          <span className="hidden sm:inline">REPORT</span>
        </button>
      </div>
    </header>
  );
};
