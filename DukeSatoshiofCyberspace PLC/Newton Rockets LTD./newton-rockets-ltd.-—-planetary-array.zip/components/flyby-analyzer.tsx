'use client';

import React, { useState, useEffect, useRef } from 'react';
import { computeFlybyGeometry, CONSTANTS, radToDeg } from '@/lib/orbital-mechanics';
import { Activity, Compass, ArrowRight, Sliders, Shield } from 'lucide-react';

interface FlybyAnalyzerProps {
  currentDate: Date;
}

export const FlybyAnalyzer: React.FC<FlybyAnalyzerProps> = ({ currentDate }) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  const [selectedPlanet, setSelectedPlanet] = useState<string>('Venus');
  const [approachSpeedKmS, setApproachSpeedKmS] = useState<number>(6.84);
  const [periapsisAltKm, setPeriapsisAltKm] = useState<number>(340.0);

  const planetData: Record<string, { mu: number; radius_km: number; color: string }> = {
    Venus:   { mu: CONSTANTS.MU.Venus, radius_km: 6051.8, color: '#FBBF24' },
    Mars:    { mu: CONSTANTS.MU.Mars, radius_km: 3396.2, color: '#FB7185' },
    Earth:   { mu: CONSTANTS.MU.Earth, radius_km: 6378.1, color: '#38BDF8' },
    Jupiter: { mu: CONSTANTS.MU.Jupiter, radius_km: 71492, color: '#F97316' },
    Mercury: { mu: CONSTANTS.MU.Mercury, radius_km: 2439.7, color: '#94A3B8' },
  };

  const currentPlanet = planetData[selectedPlanet] || planetData.Venus;
  const r_p = currentPlanet.radius_km + periapsisAltKm;
  const flyby = computeFlybyGeometry(approachSpeedKmS, r_p, currentPlanet.mu, currentPlanet.radius_km);

  // Draw 2D Hyperbolic Flyby Trajectory
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const dpr = window.devicePixelRatio || 1;
    const rect = canvas.getBoundingClientRect();
    canvas.width = rect.width * dpr;
    canvas.height = rect.height * dpr;
    ctx.scale(dpr, dpr);

    const width = rect.width;
    const height = rect.height;

    ctx.fillStyle = '#07090E';
    ctx.fillRect(0, 0, width, height);

    const cx = width / 2;
    const cy = height / 2;

    // Scale so planet and periapsis fit well
    const maxDim = currentPlanet.radius_km * 4;
    const scale = (Math.min(width, height) * 0.38) / maxDim;

    // Grid lines
    ctx.strokeStyle = 'rgba(51, 65, 85, 0.3)';
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(0, cy); ctx.lineTo(width, cy);
    ctx.moveTo(cx, 0); ctx.lineTo(cx, height);
    ctx.stroke();

    // Planet Body
    const pRadiusPx = currentPlanet.radius_km * scale;
    ctx.fillStyle = currentPlanet.color;
    ctx.beginPath();
    ctx.arc(cx, cy, pRadiusPx, 0, 2 * Math.PI);
    ctx.fill();

    // Planet label
    ctx.fillStyle = '#CBD5E1';
    ctx.font = '10px JetBrains Mono, monospace';
    ctx.textAlign = 'center';
    ctx.fillText(`${selectedPlanet.toUpperCase()}`, cx, cy + pRadiusPx + 14);

    // Hyperbolic Trajectory
    // Equation in polar coords: r(theta) = p / (1 + e * cos(theta))
    // Asymptote angle theta_inf = acos(-1/e)
    const e_hyp = flyby.eccentricity;
    const p_hyp = r_p * (1 + e_hyp);
    const theta_inf = Math.acos(-1.0 / e_hyp);

    ctx.strokeStyle = '#38BDF8';
    ctx.lineWidth = 2;
    ctx.beginPath();

    const steps = 100;
    const maxTheta = theta_inf - 0.08;

    for (let i = 0; i <= steps; i++) {
      const theta = -maxTheta + (i / steps) * (2 * maxTheta);
      const r = p_hyp / (1 + e_hyp * Math.cos(theta));
      const px = cx + r * Math.cos(theta) * scale;
      const py = cy - r * Math.sin(theta) * scale; // Invert y

      if (i === 0) ctx.moveTo(px, py);
      else ctx.lineTo(px, py);
    }
    ctx.stroke();

    // Periapsis marker
    const periapsisPx = cx + r_p * scale;
    ctx.fillStyle = '#F59E0B';
    ctx.beginPath();
    ctx.arc(periapsisPx, cy, 4, 0, 2 * Math.PI);
    ctx.fill();

    // Periapsis radius line
    ctx.strokeStyle = 'rgba(245, 158, 11, 0.6)';
    ctx.setLineDash([3, 3]);
    ctx.beginPath();
    ctx.moveTo(cx, cy);
    ctx.lineTo(periapsisPx, cy);
    ctx.stroke();
    ctx.setLineDash([]);

    ctx.fillStyle = '#F59E0B';
    ctx.font = '9px JetBrains Mono, monospace';
    ctx.textAlign = 'left';
    ctx.fillText(`Periapsis: +${periapsisAltKm.toFixed(0)} km`, periapsisPx + 6, cy - 6);

    // Turning Angle Arc
    ctx.strokeStyle = 'rgba(16, 185, 129, 0.8)';
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.arc(cx, cy, pRadiusPx * 1.8, -theta_inf, theta_inf);
    ctx.stroke();

    ctx.fillStyle = '#10B981';
    ctx.font = '10px JetBrains Mono, monospace';
    ctx.fillText(`Deflection: ${flyby.turning_angle_deg.toFixed(1)}°`, cx - 80, cy - pRadiusPx * 1.8 - 4);
  }, [selectedPlanet, approachSpeedKmS, periapsisAltKm, flyby, currentPlanet, r_p]);

  return (
    <div className="flex flex-col h-full bg-[#07090E] p-4 text-xs font-mono select-none overflow-y-auto">
      {/* Header */}
      <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-4">
        <div>
          <h2 className="text-sm font-semibold text-slate-100 uppercase tracking-wide flex items-center gap-2">
            <Activity className="w-4 h-4 text-emerald-400" />
            GRAVITY ASSIST FLYBY & ENCOUNTER GEOMETRY
          </h2>
          <p className="text-[11px] text-slate-400">
            Hyperbolic Orbital Mechanics • Two-Body Patched Conics Formulation
          </p>
        </div>
        <div className="text-right text-[11px] text-slate-500">
          RIGOROUS HYPERBOLIC EQUATIONS OF MOTION
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Left: Interactive Controls */}
        <div className="border border-slate-800 rounded-lg p-4 bg-[#090C14] space-y-4">
          <div className="text-xs font-semibold text-slate-200 uppercase tracking-wider">
            FLIGHT ENCOUNTER PARAMETERS
          </div>

          <div>
            <label className="text-[10px] text-slate-400 uppercase">TARGET PLANETARY BODY</label>
            <select
              value={selectedPlanet}
              onChange={(e) => setSelectedPlanet(e.target.value)}
              className="w-full mt-1 bg-slate-900 border border-slate-800 text-sky-400 text-xs px-2.5 py-1.5 rounded focus:outline-none cursor-pointer"
            >
              <option value="Venus">VENUS (NEWTON-01 EGA-1)</option>
              <option value="Mars">MARS (NRL-MEX-02)</option>
              <option value="Earth">EARTH (RESONANT FLYBY)</option>
              <option value="Mercury">MERCURY</option>
              <option value="Jupiter">JUPITER (OUTER SYSTEM)</option>
            </select>
          </div>

          <div>
            <div className="flex justify-between text-[10px] text-slate-400 uppercase mb-1">
              <span>HYPERBOLIC EXCESS VELOCITY (V_INF)</span>
              <span className="text-slate-200 font-semibold tabular-nums">{approachSpeedKmS.toFixed(2)} km/s</span>
            </div>
            <input
              type="range"
              min="2.0"
              max="15.0"
              step="0.05"
              value={approachSpeedKmS}
              onChange={(e) => setApproachSpeedKmS(parseFloat(e.target.value))}
              className="w-full accent-sky-500 cursor-pointer"
            />
          </div>

          <div>
            <div className="flex justify-between text-[10px] text-slate-400 uppercase mb-1">
              <span>PERIAPSIS ALTITUDE (h_p)</span>
              <span className="text-slate-200 font-semibold tabular-nums">{periapsisAltKm.toFixed(0)} km</span>
            </div>
            <input
              type="range"
              min="150"
              max="5000"
              step="10"
              value={periapsisAltKm}
              onChange={(e) => setPeriapsisAltKm(parseFloat(e.target.value))}
              className="w-full accent-sky-500 cursor-pointer"
            />
          </div>

          {/* Computed Metrics Matrix */}
          <div className="pt-3 border-t border-slate-800 space-y-2">
            <div className="text-[10px] text-slate-500 uppercase tracking-wider font-semibold">
              CALCULATED ASYMPTOTIC VALUES
            </div>

            <div className="flex justify-between py-1 border-b border-slate-800/60">
              <span className="text-slate-400">Hyperbolic Eccentricity (e):</span>
              <span className="text-slate-200 font-medium tabular-nums">{flyby.eccentricity.toFixed(4)}</span>
            </div>
            <div className="flex justify-between py-1 border-b border-slate-800/60">
              <span className="text-slate-400">Turning Angle (δ):</span>
              <span className="text-emerald-400 font-medium tabular-nums">{flyby.turning_angle_deg.toFixed(2)}°</span>
            </div>
            <div className="flex justify-between py-1 border-b border-slate-800/60">
              <span className="text-slate-400">Impulse Δv Gained:</span>
              <span className="text-sky-300 font-medium tabular-nums">{flyby.delta_v_flyby_km_s.toFixed(3)} km/s</span>
            </div>
            <div className="flex justify-between py-1 border-b border-slate-800/60">
              <span className="text-slate-400">Periapsis Radius (r_p):</span>
              <span className="text-slate-200 font-medium tabular-nums">{flyby.r_periapsis_km.toLocaleString()} km</span>
            </div>
            <div className="flex justify-between py-1">
              <span className="text-slate-400">Impact Parameter (b):</span>
              <span className="text-slate-200 font-medium tabular-nums">{flyby.b_parameter_km.toFixed(1)} km</span>
            </div>
          </div>
        </div>

        {/* Right: 2D Hyperbolic Canvas */}
        <div className="lg:col-span-2 border border-slate-800 rounded-lg p-3 bg-[#090C14] flex flex-col">
          <div className="flex items-center justify-between pb-2 border-b border-slate-800 mb-2">
            <span className="text-xs font-semibold text-slate-300">
              AREOCENTRIC / PLANETOCENTRIC HYPERBOLIC TRAJECTORY
            </span>
            <span className="text-[10px] text-slate-500">2D PERIFOCAL PROJECTION</span>
          </div>

          <div className="flex-1 min-h-[360px] relative">
            <canvas ref={canvasRef} className="w-full h-full rounded" />
          </div>
        </div>
      </div>
    </div>
  );
};
