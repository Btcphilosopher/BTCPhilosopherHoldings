'use client';

import React, { useState, useEffect, useRef } from 'react';
import { 
  getPlanetOrbitalElements, 
  elementsToStateVector, 
  computeRelativeGeometry, 
  CONSTANTS, 
  OrbitalElements, 
  StateVector, 
  kmToAu 
} from '@/lib/orbital-mechanics';
import { Compass, ArrowRightLeft, Radio, Clock, Gauge } from 'lucide-react';

interface RelativeMotionProps {
  currentDate: Date;
  spacecraftElements: OrbitalElements;
}

const SELECTABLE_OBJECTS = [
  'NEWTON-01',
  'Sun',
  'Mercury',
  'Venus',
  'Earth',
  'Mars',
  'Jupiter',
  'Saturn',
  'Uranus',
  'Neptune'
];

export const RelativeMotion: React.FC<RelativeMotionProps> = ({
  currentDate,
  spacecraftElements,
}) => {
  const [objectA, setObjectA] = useState<string>('Earth');
  const [objectB, setObjectB] = useState<string>('NEWTON-01');

  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  // Helper to obtain StateVector of an object at epoch
  const getObjectState = (name: string): StateVector | null => {
    if (name === 'NEWTON-01') {
      return elementsToStateVector(spacecraftElements, currentDate);
    }
    if (name === 'Sun') {
      return {
        r: { x: 0, y: 0, z: 0 },
        v: { x: 0, y: 0, z: 0 },
        epoch: currentDate,
        frame: 'Heliocentric Ecliptic J2000'
      };
    }
    try {
      const elems = getPlanetOrbitalElements(name, currentDate);
      return elementsToStateVector(elems, currentDate);
    } catch {
      return null;
    }
  };

  const stateA = getObjectState(objectA);
  const stateB = getObjectState(objectB);

  const rel = (stateA && stateB) ? computeRelativeGeometry(stateA, stateB) : null;

  // Render Relative Motion Vector Diagram
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas || !stateA || !stateB || !rel) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const dpr = window.devicePixelRatio || 1;
    const rect = canvas.getBoundingClientRect();
    canvas.width = rect.width * dpr;
    canvas.height = rect.height * dpr;
    ctx.scale(dpr, dpr);

    const width = rect.width;
    const height = rect.height;

    ctx.fillStyle = '#07090E';
    ctx.fillRect(0, 0, width, height);

    const cx = width / 2;
    const cy = height / 2;

    // Grid circles
    ctx.strokeStyle = 'rgba(51, 65, 85, 0.3)';
    ctx.lineWidth = 1;
    [0.2, 0.4, 0.6, 0.8].forEach(rPct => {
      ctx.beginPath();
      ctx.arc(cx, cy, (Math.min(width, height) / 2) * rPct, 0, 2 * Math.PI);
      ctx.stroke();
    });

    // Object A at Origin (Center of reference frame)
    ctx.fillStyle = '#38BDF8';
    ctx.beginPath();
    ctx.arc(cx, cy, 6, 0, 2 * Math.PI);
    ctx.fill();

    ctx.fillStyle = '#CBD5E1';
    ctx.font = '10px JetBrains Mono, monospace';
    ctx.textAlign = 'center';
    ctx.fillText(`${objectA.toUpperCase()} (ORIGIN)`, cx, cy + 18);

    // Vector from A to B in Ecliptic plane
    const dx_km = stateB.r.x - stateA.r.x;
    const dy_km = stateB.r.y - stateA.r.y;
    const range_km = Math.sqrt(dx_km * dx_km + dy_km * dy_km);

    if (range_km > 0) {
      const scale = (Math.min(width, height) * 0.35) / range_km;
      const bx = cx + dx_km * scale;
      const by = cy - dy_km * scale; // Invert Y

      // Line of Sight
      ctx.strokeStyle = 'rgba(56, 189, 248, 0.5)';
      ctx.setLineDash([3, 3]);
      ctx.beginPath();
      ctx.moveTo(cx, cy);
      ctx.lineTo(bx, by);
      ctx.stroke();
      ctx.setLineDash([]);

      // Object B Marker
      ctx.fillStyle = '#F59E0B';
      ctx.beginPath();
      ctx.arc(bx, by, 6, 0, 2 * Math.PI);
      ctx.fill();

      ctx.fillStyle = '#FBBF24';
      ctx.font = '10px JetBrains Mono, monospace';
      ctx.fillText(`${objectB.toUpperCase()}`, bx, by - 10);

      // Relative Velocity Vector
      const dvx = stateB.v.x - stateA.v.x;
      const dvy = stateB.v.y - stateA.v.y;
      const vScale = 3.0; // Visual scale for km/s
      ctx.strokeStyle = '#10B981';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(bx, by);
      ctx.lineTo(bx + dvx * vScale, by - dvy * vScale);
      ctx.stroke();

      ctx.fillStyle = '#10B981';
      ctx.font = '9px JetBrains Mono, monospace';
      ctx.fillText(`Δv: ${rel.rel_speed_km_s.toFixed(2)} km/s`, bx + dvx * vScale + 4, by - dvy * vScale);
    }
  }, [objectA, objectB, stateA, stateB, rel]);

  return (
    <div className="flex flex-col h-full bg-[#07090E] p-4 text-xs font-mono select-none overflow-y-auto">
      {/* Header */}
      <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-4">
        <div>
          <h2 className="text-sm font-semibold text-slate-100 uppercase tracking-wide flex items-center gap-2">
            <Compass className="w-4 h-4 text-sky-400" />
            RELATIVE MOTION & CLOSING VELOCITY ANALYZER
          </h2>
          <p className="text-[11px] text-slate-400">
            Body-to-Body Range, Rate, and Vector Kinematics • Heliocentric Ecliptic Frame
          </p>
        </div>
        <div className="text-right text-[11px] text-slate-500">
          SELECT DUAL TARGETS TO INSPECT CLOSING VELOCITY
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Left Column: Selectors and Stat Cards */}
        <div className="border border-slate-800 rounded-lg p-4 bg-[#090C14] space-y-4">
          <div className="text-xs font-semibold text-slate-200 uppercase tracking-wider">
            KINEMATIC PAIR SELECTION
          </div>

          <div className="grid grid-cols-2 gap-2">
            <div>
              <label className="text-[10px] text-slate-400 uppercase">OBJECT A (BASE)</label>
              <select
                value={objectA}
                onChange={(e) => setObjectA(e.target.value)}
                className="w-full mt-1 bg-slate-900 border border-slate-800 text-sky-400 text-xs px-2 py-1.5 rounded focus:outline-none cursor-pointer"
              >
                {SELECTABLE_OBJECTS.map(obj => (
                  <option key={obj} value={obj}>{obj}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="text-[10px] text-slate-400 uppercase">OBJECT B (TARGET)</label>
              <select
                value={objectB}
                onChange={(e) => setObjectB(e.target.value)}
                className="w-full mt-1 bg-slate-900 border border-slate-800 text-amber-400 text-xs px-2 py-1.5 rounded focus:outline-none cursor-pointer"
              >
                {SELECTABLE_OBJECTS.map(obj => (
                  <option key={obj} value={obj}>{obj}</option>
                ))}
              </select>
            </div>
          </div>

          {rel && (
            <div className="pt-2 border-t border-slate-800 space-y-3">
              <div className="bg-slate-950 p-2.5 rounded border border-slate-800">
                <div className="text-[10px] text-slate-500 uppercase">RANGE (DISTANCE)</div>
                <div className="text-base font-semibold text-slate-100 tabular-nums">
                  {rel.range_au.toFixed(6)} <span className="text-xs text-slate-400 font-normal">AU</span>
                </div>
                <div className="text-[10px] text-slate-400 tabular-nums">
                  {(rel.range_km / 1e6).toFixed(3)} Million km ({rel.range_km.toLocaleString()} km)
                </div>
              </div>

              <div className="bg-slate-950 p-2.5 rounded border border-slate-800">
                <div className="text-[10px] text-slate-500 uppercase">CLOSING VELOCITY (RANGE RATE)</div>
                <div className={`text-base font-semibold tabular-nums ${rel.closing_velocity_km_s > 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                  {rel.closing_velocity_km_s > 0 ? `+${rel.closing_velocity_km_s.toFixed(3)}` : rel.closing_velocity_km_s.toFixed(3)}{' '}
                  <span className="text-xs text-slate-400 font-normal">km/s</span>
                </div>
                <div className="text-[10px] text-slate-400">
                  {rel.closing_velocity_km_s > 0 ? 'APPROACHING / CLOSING' : 'RECEDING / OPENING'}
                </div>
              </div>

              <div className="bg-slate-950 p-2.5 rounded border border-slate-800">
                <div className="text-[10px] text-slate-500 uppercase">RELATIVE SPEED (|Δv|)</div>
                <div className="text-base font-semibold text-slate-100 tabular-nums">
                  {rel.rel_speed_km_s.toFixed(3)} <span className="text-xs text-slate-400 font-normal">km/s</span>
                </div>
                <div className="text-[10px] text-slate-400 tabular-nums">
                  {(rel.rel_speed_km_s * 3600).toLocaleString(undefined, { maximumFractionDigits: 0 })} km/h
                </div>
              </div>

              <div className="bg-slate-950 p-2.5 rounded border border-slate-800">
                <div className="text-[10px] text-slate-500 uppercase">ONE-WAY LIGHT TIME (τ)</div>
                <div className="text-base font-semibold text-sky-400 tabular-nums">
                  {rel.light_time_s.toFixed(2)} <span className="text-xs text-slate-400 font-normal">SECONDS</span>
                </div>
                <div className="text-[10px] text-slate-400 tabular-nums">
                  {(rel.light_time_s / 60).toFixed(2)} minutes (Round-trip: {((rel.light_time_s * 2) / 60).toFixed(2)} min)
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Right Column: 2D Relative Motion Vector Diagram */}
        <div className="lg:col-span-2 border border-slate-800 rounded-lg p-3 bg-[#090C14] flex flex-col">
          <div className="flex items-center justify-between pb-2 border-b border-slate-800 mb-2">
            <span className="text-xs font-semibold text-slate-300">
              RELATIVE MOTION VECTOR & LINE-OF-SIGHT GEOMETRY
            </span>
            <span className="text-[10px] text-slate-500">ORIGIN FIXED AT {objectA.toUpperCase()}</span>
          </div>

          <div className="flex-1 min-h-[380px] relative">
            <canvas ref={canvasRef} className="w-full h-full rounded" />
          </div>
        </div>
      </div>
    </div>
  );
};
