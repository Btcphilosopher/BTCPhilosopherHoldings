'use client';

import React from 'react';
import { 
  getPlanetOrbitalElements, 
  elementsToStateVector, 
  computeSolarFlux, 
  computeIlluminatedFraction,
  computePhaseAngle,
  CONSTANTS, 
  kmToAu 
} from '@/lib/orbital-mechanics';
import { Table, Eye, Compass, ArrowUpRight } from 'lucide-react';

interface PlanetaryGridProps {
  currentDate: Date;
  selectedObjectName: string;
  onSelectObject: (name: string) => void;
  spacecraftPositionKm: { x: number; y: number; z: number };
}

const PLANETS = [
  { name: 'Mercury', color: '#94A3B8' },
  { name: 'Venus',   color: '#FBBF24' },
  { name: 'Earth',   color: '#38BDF8' },
  { name: 'Mars',    color: '#FB7185' },
  { name: 'Jupiter', color: '#F97316' },
  { name: 'Saturn',  color: '#EAB308' },
  { name: 'Uranus',  color: '#2DD4BF' },
  { name: 'Neptune', color: '#60A5FA' },
];

export const PlanetaryGrid: React.FC<PlanetaryGridProps> = ({
  currentDate,
  selectedObjectName,
  onSelectObject,
  spacecraftPositionKm,
}) => {
  // Compute Earth's state for relative distances
  let earthPos = { x: 0, y: 0, z: 0 };
  try {
    const earthElems = getPlanetOrbitalElements('Earth', currentDate);
    const earthState = elementsToStateVector(earthElems, currentDate);
    earthPos = earthState.r;
  } catch {}

  const rows = PLANETS.map(p => {
    try {
      const elems = getPlanetOrbitalElements(p.name, currentDate);
      const state = elementsToStateVector(elems, currentDate);

      const r_km = Math.sqrt(state.r.x ** 2 + state.r.y ** 2 + state.r.z ** 2);
      const r_au = kmToAu(r_km);
      const v_km_s = Math.sqrt(state.v.x ** 2 + state.v.y ** 2 + state.v.z ** 2);

      // Distance to Earth
      const dEarthKm = Math.sqrt(
        (state.r.x - earthPos.x) ** 2 + (state.r.y - earthPos.y) ** 2 + (state.r.z - earthPos.z) ** 2
      );
      const dEarthAu = kmToAu(dEarthKm);

      // Distance to Spacecraft
      const dScKm = Math.sqrt(
        (state.r.x - spacecraftPositionKm.x) ** 2 +
        (state.r.y - spacecraftPositionKm.y) ** 2 +
        (state.r.z - spacecraftPositionKm.z) ** 2
      );
      const dScAu = kmToAu(dScKm);

      const solarFlux = computeSolarFlux(r_km);
      const lightTimeToEarthS = dEarthKm / CONSTANTS.SPEED_OF_LIGHT_KM_S;

      // Phase angle from Earth
      const rBodySun = { x: -state.r.x, y: -state.r.y, z: -state.r.z };
      const rBodyEarth = { x: earthPos.x - state.r.x, y: earthPos.y - state.r.y, z: earthPos.z - state.r.z };
      const phaseAngleRad = computePhaseAngle(rBodySun, rBodyEarth);
      const illumFraction = computeIlluminatedFraction(phaseAngleRad);

      return {
        name: p.name,
        color: p.color,
        r_au,
        r_km,
        v_km_s,
        dEarthAu,
        dScAu,
        trueAnomalyDeg: elems.nu_deg,
        illuminatedFraction: illumFraction * 100,
        solarFlux,
        lightTimeToEarthS,
      };
    } catch {
      return null;
    }
  }).filter(Boolean);

  return (
    <div className="flex flex-col h-full bg-[#07090E] p-4 text-xs font-mono select-none overflow-auto">
      <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-3">
        <div>
          <h2 className="text-sm font-semibold text-slate-100 uppercase tracking-wide flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-sky-400"></span>
            PLANETARY ARRAY INFORMATION MATRIX
          </h2>
          <p className="text-[11px] text-slate-400">
            Real-time Ephemeris States • Heliocentric Mean Ecliptic J2000.0 Frame
          </p>
        </div>
        <div className="text-right text-[11px] text-slate-500">
          ALL QUANTITIES CALCULATED FROM ORBITAL MODEL
        </div>
      </div>

      <div className="border border-slate-800 rounded-lg overflow-hidden bg-[#090C14]">
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="bg-slate-900/80 border-b border-slate-800 text-[10px] text-slate-400 uppercase tracking-wider">
              <th className="py-2.5 px-3">BODY</th>
              <th className="py-2.5 px-3">HELIOCENTRIC R</th>
              <th className="py-2.5 px-3">ORBITAL VEL.</th>
              <th className="py-2.5 px-3">DIST. TO EARTH</th>
              <th className="py-2.5 px-3">DIST. TO NEWTON-01</th>
              <th className="py-2.5 px-3">TRUE ANOMALY</th>
              <th className="py-2.5 px-3">ILLUMINATED</th>
              <th className="py-2.5 px-3">SOLAR FLUX</th>
              <th className="py-2.5 px-3">LIGHT TIME (1-WAY)</th>
              <th className="py-2.5 px-3 text-right">ACTION</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800/60">
            {rows.map((row) => {
              if (!row) return null;
              const isSelected = selectedObjectName === row.name;
              return (
                <tr
                  key={row.name}
                  onClick={() => onSelectObject(row.name)}
                  className={`hover:bg-slate-800/40 transition-colors cursor-pointer ${
                    isSelected ? 'bg-sky-950/30' : ''
                  }`}
                >
                  <td className="py-2.5 px-3 font-semibold text-slate-200 flex items-center gap-2">
                    <span className="w-2 h-2 rounded-full" style={{ backgroundColor: row.color }}></span>
                    <span className={isSelected ? 'text-sky-400' : ''}>{row.name}</span>
                  </td>
                  <td className="py-2.5 px-3 tabular-nums text-slate-200">
                    {row.r_au.toFixed(4)} <span className="text-[10px] text-slate-500">AU</span>
                  </td>
                  <td className="py-2.5 px-3 tabular-nums text-emerald-400 font-medium">
                    {row.v_km_s.toFixed(2)} <span className="text-[10px] text-slate-500 font-normal">km/s</span>
                  </td>
                  <td className="py-2.5 px-3 tabular-nums text-slate-300">
                    {row.dEarthAu.toFixed(4)} <span className="text-[10px] text-slate-500">AU</span>
                  </td>
                  <td className="py-2.5 px-3 tabular-nums text-sky-300">
                    {row.dScAu.toFixed(4)} <span className="text-[10px] text-slate-500">AU</span>
                  </td>
                  <td className="py-2.5 px-3 tabular-nums text-slate-300">
                    {row.trueAnomalyDeg.toFixed(2)}°
                  </td>
                  <td className="py-2.5 px-3 tabular-nums text-amber-300">
                    {row.illuminatedFraction.toFixed(1)}%
                  </td>
                  <td className="py-2.5 px-3 tabular-nums text-slate-300">
                    {row.solarFlux.toFixed(0)} <span className="text-[10px] text-slate-500">W/m²</span>
                  </td>
                  <td className="py-2.5 px-3 tabular-nums text-slate-300">
                    {(row.lightTimeToEarthS / 60).toFixed(2)} <span className="text-[10px] text-slate-500">min</span>
                  </td>
                  <td className="py-2.5 px-3 text-right">
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        onSelectObject(row.name);
                      }}
                      className="text-[11px] text-sky-400 hover:text-sky-300 hover:underline flex items-center justify-end gap-1 w-full"
                    >
                      <span>INSPECT</span>
                      <ArrowUpRight className="w-3 h-3" />
                    </button>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
};
