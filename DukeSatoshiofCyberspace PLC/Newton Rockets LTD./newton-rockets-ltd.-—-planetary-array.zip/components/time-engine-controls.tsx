'use client';

import React from 'react';
import { Play, Pause, Rewind, FastForward, RotateCcw, Calendar, ChevronLeft, ChevronRight } from 'lucide-react';

interface TimeEngineControlsProps {
  isPlaying: boolean;
  setIsPlaying: (val: boolean | ((prev: boolean) => boolean)) => void;
  timeWarp: number;
  setTimeWarp: (warp: number) => void;
  onStepTime: (deltaSeconds: number) => void;
  onResetTime: () => void;
  currentDate: Date;
  onSetDate: (d: Date) => void;
  isCompact?: boolean;
}

export const TimeEngineControls: React.FC<TimeEngineControlsProps> = ({
  isPlaying,
  setIsPlaying,
  timeWarp,
  setTimeWarp,
  onStepTime,
  onResetTime,
  currentDate,
  onSetDate,
  isCompact = false,
}) => {
  const warpLevels = [-1000, -100, -10, -1, 1, 10, 100, 1000];

  const handleDateChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = e.target.value;
    if (val) {
      const parsed = new Date(val);
      if (!isNaN(parsed.getTime())) {
        onSetDate(parsed);
      }
    }
  };

  const isoDateTime = currentDate.toISOString().slice(0, 16);

  return (
    <div className={`flex flex-wrap items-center justify-between gap-3 px-3 py-2 bg-[#090C14]/90 border border-slate-800/80 rounded-lg text-xs font-mono select-none ${isCompact ? 'p-2' : ''}`}>
      {/* Playback Controls */}
      <div className="flex items-center gap-1.5">
        <button
          onClick={onResetTime}
          className="p-1.5 text-slate-400 hover:text-slate-200 hover:bg-slate-800 rounded transition-colors"
          title="Reset to Mission Epoch"
        >
          <RotateCcw className="w-3.5 h-3.5" />
        </button>

        <button
          onClick={() => onStepTime(-86400)}
          className="px-2 py-1 text-[11px] text-slate-400 hover:text-slate-200 hover:bg-slate-800 rounded transition-colors flex items-center gap-0.5"
          title="Step Backward 1 Day"
        >
          <ChevronLeft className="w-3 h-3" />
          <span>-1D</span>
        </button>

        <button
          onClick={() => onStepTime(-3600)}
          className="px-2 py-1 text-[11px] text-slate-400 hover:text-slate-200 hover:bg-slate-800 rounded transition-colors flex items-center gap-0.5"
          title="Step Backward 1 Hour"
        >
          <span>-1H</span>
        </button>

        <button
          onClick={() => setIsPlaying(prev => !prev)}
          className={`px-3 py-1.5 rounded font-semibold flex items-center gap-1.5 transition-colors cursor-pointer ${
            isPlaying
              ? 'bg-amber-500/20 text-amber-300 border border-amber-500/50 hover:bg-amber-500/30'
              : 'bg-sky-600 text-white hover:bg-sky-500'
          }`}
        >
          {isPlaying ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
          <span>{isPlaying ? 'PAUSE' : 'RUN'}</span>
        </button>

        <button
          onClick={() => onStepTime(3600)}
          className="px-2 py-1 text-[11px] text-slate-400 hover:text-slate-200 hover:bg-slate-800 rounded transition-colors flex items-center gap-0.5"
          title="Step Forward 1 Hour"
        >
          <span>+1H</span>
        </button>

        <button
          onClick={() => onStepTime(86400)}
          className="px-2 py-1 text-[11px] text-slate-400 hover:text-slate-200 hover:bg-slate-800 rounded transition-colors flex items-center gap-0.5"
          title="Step Forward 1 Day"
        >
          <span>+1D</span>
          <ChevronRight className="w-3 h-3" />
        </button>
      </div>

      {/* Warp Speeds */}
      <div className="flex items-center gap-1 bg-slate-900/80 p-0.5 rounded border border-slate-800">
        <span className="text-[10px] text-slate-500 px-1.5 uppercase font-medium">WARP</span>
        {warpLevels.map((warp) => (
          <button
            key={warp}
            onClick={() => {
              setTimeWarp(warp);
              if (!isPlaying) setIsPlaying(true);
            }}
            className={`px-1.5 py-0.5 text-[11px] rounded transition-colors cursor-pointer ${
              timeWarp === warp && isPlaying
                ? 'bg-sky-500 text-white font-semibold'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800'
            }`}
          >
            {warp > 0 ? `+${warp}×` : `${warp}×`}
          </button>
        ))}
      </div>

      {/* Date-Time Picker */}
      <div className="flex items-center gap-2">
        <span className="text-slate-500 text-[10px]">EPOCH:</span>
        <input
          type="datetime-local"
          value={isoDateTime}
          onChange={handleDateChange}
          className="bg-slate-900 border border-slate-800 text-slate-200 text-xs px-2 py-1 rounded font-mono focus:outline-none focus:border-sky-500 cursor-pointer"
        />
      </div>
    </div>
  );
};
