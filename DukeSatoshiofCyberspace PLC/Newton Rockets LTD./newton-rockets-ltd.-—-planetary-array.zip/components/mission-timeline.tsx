'use client';

import React from 'react';
import { Calendar, ChevronRight, CheckCircle2, Clock, Flame, Radio, Compass } from 'lucide-react';
import { MissionMilestone } from '@/lib/orbital-mechanics';

interface MissionTimelineProps {
  currentDate: Date;
  onJumpToEpoch: (dateStr: string) => void;
  milestones: MissionMilestone[];
  selectedMilestoneId: string | null;
  onSelectMilestone: (id: string) => void;
}

export const MissionTimeline: React.FC<MissionTimelineProps> = ({
  currentDate,
  onJumpToEpoch,
  milestones,
  selectedMilestoneId,
  onSelectMilestone,
}) => {
  const currentEpochTime = currentDate.getTime();

  return (
    <div className="flex flex-col h-full bg-[#07090E] p-4 text-xs font-mono select-none overflow-y-auto">
      {/* Header */}
      <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-4">
        <div>
          <h2 className="text-sm font-semibold text-slate-100 uppercase tracking-wide flex items-center gap-2">
            <Calendar className="w-4 h-4 text-sky-400" />
            MISSION FLIGHT TIMELINE & TRAJECTORY EVENTS
          </h2>
          <p className="text-[11px] text-slate-400">
            Calculated Milestones • NEWTON-01 Solar Science Mission Architecture
          </p>
        </div>
        <div className="text-right text-[11px] text-slate-500">
          CLICK MILESTONE TO JUMP SIMULATION CLOCK
        </div>
      </div>

      {/* Horizontal / Stepper Timeline */}
      <div className="relative border border-slate-800 rounded-lg p-4 bg-[#090C14] mb-4">
        <div className="text-[10px] text-slate-500 uppercase tracking-wider mb-3">
          MISSION SEQUENCE OVERVIEW
        </div>

        <div className="grid grid-cols-1 md:grid-cols-5 gap-3">
          {milestones.map((m, idx) => {
            const milestoneTime = new Date(m.epoch).getTime();
            const isPast = currentEpochTime >= milestoneTime;
            const isSelected = selectedMilestoneId === m.id;

            return (
              <div
                key={m.id}
                onClick={() => {
                  onSelectMilestone(m.id);
                  onJumpToEpoch(m.epoch);
                }}
                className={`relative p-3 rounded-lg border transition-all cursor-pointer ${
                  isSelected
                    ? 'border-sky-500 bg-sky-950/40 shadow-lg'
                    : isPast
                    ? 'border-slate-700 bg-slate-900/60 hover:border-slate-600'
                    : 'border-slate-800 bg-slate-950 hover:border-slate-700'
                }`}
              >
                <div className="flex items-center justify-between mb-1.5">
                  <span className="text-[10px] text-slate-400 font-semibold">{m.id}</span>
                  <span
                    className={`text-[9px] px-1.5 py-0.5 rounded font-medium ${
                      isPast
                        ? 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                        : 'bg-amber-950 text-amber-300 border border-amber-800'
                    }`}
                  >
                    {isPast ? 'COMPLETED' : 'UPCOMING'}
                  </span>
                </div>

                <div className="text-xs font-semibold text-slate-200 line-clamp-2 mb-1">
                  {m.name}
                </div>

                <div className="text-[10px] text-sky-400 font-medium tabular-nums mb-1">
                  {m.epoch.slice(0, 10)}
                </div>

                {m.delta_v_m_s && (
                  <div className="text-[10px] text-slate-400 tabular-nums">
                    Δv: <span className="text-slate-200 font-semibold">{m.delta_v_m_s.toFixed(1)} m/s</span>
                  </div>
                )}
                {m.body && (
                  <div className="text-[10px] text-slate-400">
                    Target: <span className="text-amber-300 font-semibold">{m.body}</span>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>

      {/* Detailed Selected Milestone Dossier */}
      {selectedMilestoneId && (() => {
        const sel = milestones.find(m => m.id === selectedMilestoneId);
        if (!sel) return null;
        return (
          <div className="border border-slate-800 rounded-lg p-4 bg-[#090C14]">
            <div className="flex items-center justify-between pb-2 border-b border-slate-800 mb-3">
              <div className="text-xs font-semibold text-sky-400 uppercase tracking-wider">
                EVENT SPECIFICATION DOSSIER: {sel.id} — {sel.name}
              </div>
              <button
                onClick={() => onJumpToEpoch(sel.epoch)}
                className="px-2.5 py-1 text-xs bg-sky-600 hover:bg-sky-500 text-white rounded transition-colors"
              >
                JUMP TO EPOCH
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-slate-300">
              <div className="space-y-1">
                <div className="text-[10px] text-slate-500 uppercase">EXECUTION EPOCH</div>
                <div className="text-xs font-semibold text-slate-100 tabular-nums">{sel.epoch}</div>
              </div>
              <div className="space-y-1">
                <div className="text-[10px] text-slate-500 uppercase">EVENT TYPE</div>
                <div className="text-xs font-semibold text-slate-100">{sel.type}</div>
              </div>
              {sel.delta_v_m_s && (
                <div className="space-y-1">
                  <div className="text-[10px] text-slate-500 uppercase">IMPULSE EXPENDITURE</div>
                  <div className="text-xs font-semibold text-emerald-400 tabular-nums">{sel.delta_v_m_s} m/s</div>
                </div>
              )}
            </div>

            <div className="mt-3 pt-3 border-t border-slate-800 text-[11px] text-slate-300">
              <span className="text-slate-500 font-semibold uppercase">TACTICAL BRIEFING: </span>
              {sel.description}
            </div>
          </div>
        );
      })()}
    </div>
  );
};
