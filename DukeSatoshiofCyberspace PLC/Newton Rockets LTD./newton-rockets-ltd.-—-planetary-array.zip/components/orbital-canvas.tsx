'use client';

import React, { useRef, useEffect, useState, useCallback } from 'react';
import { 
  getPlanetOrbitalElements, 
  elementsToStateVector, 
  propagateKeplerian, 
  CONSTANTS, 
  kmToAu, 
  OrbitalElements, 
  StateVector 
} from '@/lib/orbital-mechanics';
import { ZoomIn, ZoomOut, RotateCcw, Crosshair, Layers, Eye, Compass, Shield } from 'lucide-react';

interface OrbitalCanvasProps {
  currentDate: Date;
  selectedObjectName: string;
  onSelectObject: (name: string) => void;
  displayMode: string;
  setDisplayMode: (mode: string) => void;
  scaleMode: 'TRUE' | 'ENHANCED';
  layers: {
    orbits: boolean;
    trajectory: boolean;
    velocity: boolean;
    labels: boolean;
    terminators: boolean;
    soi: boolean;
    grid: boolean;
  };
  setLayers: React.Dispatch<React.SetStateAction<{
    orbits: boolean;
    trajectory: boolean;
    velocity: boolean;
    labels: boolean;
    terminators: boolean;
    soi: boolean;
    grid: boolean;
  }>>;
  isArrayMode: boolean;
  isNightMode: boolean;
  activeFrame: string;
  spacecraftElements: OrbitalElements;
}

const PLANET_NAMES = ['Mercury', 'Venus', 'Earth', 'Mars', 'Jupiter', 'Saturn', 'Uranus', 'Neptune'];

const PLANET_PALETTE: Record<string, { color: string; radius_km: number; name: string }> = {
  Sun:     { color: '#F59E0B', radius_km: 696342, name: 'Sun' },
  Mercury: { color: '#94A3B8', radius_km: 2439.7, name: 'Mercury' },
  Venus:   { color: '#FBBF24', radius_km: 6051.8, name: 'Venus' },
  Earth:   { color: '#38BDF8', radius_km: 6378.1, name: 'Earth' },
  Mars:    { color: '#FB7185', radius_km: 3396.2, name: 'Mars' },
  Jupiter: { color: '#F97316', radius_km: 71492,  name: 'Jupiter' },
  Saturn:  { color: '#EAB308', radius_km: 60268,  name: 'Saturn' },
  Uranus:  { color: '#2DD4BF', radius_km: 25559,  name: 'Uranus' },
  Neptune: { color: '#60A5FA', radius_km: 24764,  name: 'Neptune' },
};

export const OrbitalCanvas: React.FC<OrbitalCanvasProps> = ({
  currentDate,
  selectedObjectName,
  onSelectObject,
  displayMode,
  setDisplayMode,
  scaleMode,
  layers,
  setLayers,
  isArrayMode,
  isNightMode,
  activeFrame,
  spacecraftElements,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  // Camera state
  const [zoom, setZoom] = useState<number>(140); // Pixels per AU
  const [pan, setPan] = useState<{ x: number; y: number }>({ x: 0, y: 0 });
  const [rotation, setRotation] = useState<{ azimuth: number; pitch: number }>({
    azimuth: -0.2,
    pitch: 0.85, // Near top-down oblique view
  });

  const [isDragging, setIsDragging] = useState<boolean>(false);
  const [dragMode, setDragMode] = useState<'orbit' | 'pan'>('orbit');
  const [lastMouse, setLastMouse] = useState<{ x: number; y: number }>({ x: 0, y: 0 });

  const applyViewPreset = useCallback((mode: string) => {
    if (mode === 'SOLAR_SYSTEM') {
      setZoom(16); // Fit outer planets (Neptune ~30 AU)
      setPan({ x: 0, y: 0 });
      setRotation({ azimuth: -0.2, pitch: 0.85 });
    } else if (mode === 'INNER_SYSTEM') {
      setZoom(180); // Fit inner planets (Mars ~1.5 AU)
      setPan({ x: 0, y: 0 });
      setRotation({ azimuth: -0.2, pitch: 0.85 });
    } else if (mode === 'POLAR_VIEW') {
      setRotation({ azimuth: 0, pitch: Math.PI / 2 }); // Direct top-down
    } else if (mode === 'ORBITAL_PLANE_VIEW') {
      setRotation({ azimuth: 0, pitch: 0.05 }); // Edge-on to see inclination
    } else if (mode === 'HELIOCENTRIC') {
      setPan({ x: 0, y: 0 });
    }
  }, []);

  // World to Screen 3D projection
  // Coordinates (x, y, z) in AU where X-Y is Ecliptic plane, Z is North Ecliptic Pole
  const project3D = useCallback((x: number, y: number, z: number, width: number, height: number) => {
    const { azimuth, pitch } = rotation;

    // Yaw rotation around Z axis
    const cosAz = Math.cos(azimuth);
    const sinAz = Math.sin(azimuth);
    const x1 = x * cosAz - y * sinAz;
    const y1 = x * sinAz + y * cosAz;
    const z1 = z;

    // Pitch rotation around X axis
    const cosPitch = Math.cos(pitch);
    const sinPitch = Math.sin(pitch);
    const x2 = x1;
    const y2 = y1 * sinPitch - z1 * cosPitch;
    const z2 = y1 * cosPitch + z1 * sinPitch;

    // Screen coordinates with zoom and pan
    const screenX = width / 2 + pan.x + x2 * zoom;
    const screenY = height / 2 + pan.y - y2 * zoom; // Invert Y for screen canvas

    return { x: screenX, y: screenY, depth: z2 };
  }, [rotation, pan, zoom]);

  // Render Loop
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Handle high-DPI retina display
    const dpr = window.devicePixelRatio || 1;
    const rect = canvas.getBoundingClientRect();
    canvas.width = rect.width * dpr;
    canvas.height = rect.height * dpr;
    ctx.scale(dpr, dpr);

    const width = rect.width;
    const height = rect.height;

    // Clear background (Obsidian / Space)
    ctx.fillStyle = isNightMode ? '#040609' : '#07090E';
    ctx.fillRect(0, 0, width, height);

    // Subtle Ecliptic Reference Grid
    if (layers.grid) {
      ctx.strokeStyle = isNightMode ? 'rgba(30, 41, 59, 0.4)' : 'rgba(51, 65, 85, 0.35)';
      ctx.lineWidth = 1;

      // Draw concentric distance rings (1 AU, 2 AU, 5 AU, 10 AU, 20 AU, 30 AU)
      const ringDistances = [0.5, 1.0, 1.52, 2.0, 5.2, 9.5, 19.2, 30.1];
      ringDistances.forEach((au) => {
        ctx.beginPath();
        const steps = 96;
        for (let i = 0; i <= steps; i++) {
          const theta = (i / steps) * 2 * Math.PI;
          const gx = au * Math.cos(theta);
          const gy = au * Math.sin(theta);
          const pt = project3D(gx, gy, 0, width, height);
          if (i === 0) ctx.moveTo(pt.x, pt.y);
          else ctx.lineTo(pt.x, pt.y);
        }
        ctx.stroke();

        // Distance label
        if (zoom > 40 && au <= 5.2) {
          const lblPt = project3D(au, 0, 0, width, height);
          ctx.fillStyle = 'rgba(148, 163, 184, 0.4)';
          ctx.font = '10px JetBrains Mono, monospace';
          ctx.fillText(`${au.toFixed(1)} AU`, lblPt.x + 4, lblPt.y - 2);
        }
      });

      // Axis crosshairs
      ctx.beginPath();
      const pNegX = project3D(-35, 0, 0, width, height);
      const pPosX = project3D(35, 0, 0, width, height);
      ctx.moveTo(pNegX.x, pNegX.y);
      ctx.lineTo(pPosX.x, pPosX.y);

      const pNegY = project3D(0, -35, 0, width, height);
      const pPosY = project3D(0, 35, 0, width, height);
      ctx.moveTo(pNegY.x, pNegY.y);
      ctx.lineTo(pPosY.x, pPosY.y);
      ctx.stroke();
    }

    // 1. Draw Sun at origin
    const sunPt = project3D(0, 0, 0, width, height);
    const sunRadiusPx = scaleMode === 'TRUE' ? Math.max(3, (CONSTANTS.RADIUS_SUN_KM / CONSTANTS.AU_KM) * zoom) : 10;

    // Radiant Corona
    const coronaGrad = ctx.createRadialGradient(sunPt.x, sunPt.y, sunRadiusPx * 0.2, sunPt.x, sunPt.y, sunRadiusPx * 2.5);
    coronaGrad.addColorStop(0, 'rgba(251, 191, 36, 0.9)');
    coronaGrad.addColorStop(0.4, 'rgba(245, 158, 11, 0.35)');
    coronaGrad.addColorStop(1, 'rgba(245, 158, 11, 0)');
    ctx.fillStyle = coronaGrad;
    ctx.beginPath();
    ctx.arc(sunPt.x, sunPt.y, sunRadiusPx * 2.5, 0, 2 * Math.PI);
    ctx.fill();

    // Sun core
    ctx.fillStyle = '#FEF08A';
    ctx.beginPath();
    ctx.arc(sunPt.x, sunPt.y, sunRadiusPx, 0, 2 * Math.PI);
    ctx.fill();

    if (layers.labels) {
      ctx.fillStyle = '#FDE68A';
      ctx.font = '11px JetBrains Mono, monospace';
      ctx.fillText('SUN', sunPt.x + sunRadiusPx + 4, sunPt.y + 4);
    }

    // 2. Compute and Draw Planetary Orbits & Positions
    PLANET_NAMES.forEach((name) => {
      try {
        const elems = getPlanetOrbitalElements(name, currentDate);
        const state = elementsToStateVector(elems, currentDate);

        // Position in AU
        const curX_au = kmToAu(state.r.x);
        const curY_au = kmToAu(state.r.y);
        const curZ_au = kmToAu(state.r.z);

        const planetPt = project3D(curX_au, curY_au, curZ_au, width, height);
        const pMeta = PLANET_PALETTE[name];

        // Draw Keplerian Orbital Ellipse
        if (layers.orbits) {
          ctx.beginPath();
          const orbitSteps = 120;
          ctx.strokeStyle = name === selectedObjectName 
            ? 'rgba(56, 189, 248, 0.8)' 
            : isNightMode ? 'rgba(71, 85, 105, 0.45)' : 'rgba(100, 116, 139, 0.4)';
          ctx.lineWidth = name === selectedObjectName ? 1.5 : 1;

          for (let step = 0; step <= orbitSteps; step++) {
            const trueAnom = (step / orbitSteps) * 2 * Math.PI;
            const evalElems: OrbitalElements = { ...elems, nu: trueAnom };
            const evalState = elementsToStateVector(evalElems, currentDate);
            const ox = kmToAu(evalState.r.x);
            const oy = kmToAu(evalState.r.y);
            const oz = kmToAu(evalState.r.z);
            const opt = project3D(ox, oy, oz, width, height);

            if (step === 0) ctx.moveTo(opt.x, opt.y);
            else ctx.lineTo(opt.x, opt.y);
          }
          ctx.stroke();
        }

        // Draw Day / Night Terminator
        if (layers.terminators) {
          const rSunX = -curX_au;
          const rSunY = -curY_au;
          const rSunLen = Math.sqrt(rSunX * rSunX + rSunY * rSunY);
          if (rSunLen > 0) {
            const normX = -rSunY / rSunLen;
            const normY = rSunX / rSunLen;
            const termLen = 0.05 * (zoom / 40);
            const p1 = project3D(curX_au - normX * termLen, curY_au - normY * termLen, curZ_au, width, height);
            const p2 = project3D(curX_au + normX * termLen, curY_au + normY * termLen, curZ_au, width, height);

            ctx.strokeStyle = 'rgba(255, 255, 255, 0.35)';
            ctx.lineWidth = 1;
            ctx.beginPath();
            ctx.moveTo(p1.x, p1.y);
            ctx.lineTo(p2.x, p2.y);
            ctx.stroke();
          }
        }

        // Draw Velocity Vector
        if (layers.velocity) {
          const vScale = 0.02; // Visual scaling factor
          const vPt = project3D(
            curX_au + state.v.x * vScale,
            curY_au + state.v.y * vScale,
            curZ_au + state.v.z * vScale,
            width,
            height
          );
          ctx.strokeStyle = 'rgba(34, 197, 94, 0.7)';
          ctx.lineWidth = 1;
          ctx.beginPath();
          ctx.moveTo(planetPt.x, planetPt.y);
          ctx.lineTo(vPt.x, vPt.y);
          ctx.stroke();
        }

        // Draw Planet Body
        const isSelected = selectedObjectName === name;
        const planetRadiusPx = scaleMode === 'TRUE' 
          ? Math.max(2, (pMeta.radius_km / CONSTANTS.AU_KM) * zoom)
          : Math.max(3.5, Math.log10(pMeta.radius_km) * 1.5);

        // Selection Reticle
        if (isSelected) {
          ctx.strokeStyle = '#38BDF8';
          ctx.lineWidth = 1.5;
          ctx.beginPath();
          ctx.arc(planetPt.x, planetPt.y, planetRadiusPx + 5, 0, 2 * Math.PI);
          ctx.stroke();

          // Reticle corners
          const rSize = planetRadiusPx + 8;
          ctx.beginPath();
          ctx.moveTo(planetPt.x - rSize, planetPt.y);
          ctx.lineTo(planetPt.x - rSize + 4, planetPt.y);
          ctx.moveTo(planetPt.x + rSize, planetPt.y);
          ctx.lineTo(planetPt.x + rSize - 4, planetPt.y);
          ctx.moveTo(planetPt.x, planetPt.y - rSize);
          ctx.lineTo(planetPt.x, planetPt.y - rSize + 4);
          ctx.moveTo(planetPt.x, planetPt.y + rSize);
          ctx.lineTo(planetPt.x, planetPt.y + rSize - 4);
          ctx.stroke();
        }

        // Planet Sphere
        ctx.fillStyle = pMeta.color;
        ctx.beginPath();
        ctx.arc(planetPt.x, planetPt.y, planetRadiusPx, 0, 2 * Math.PI);
        ctx.fill();

        // Saturn Rings representation
        if (name === 'Saturn' && (scaleMode === 'ENHANCED' || zoom > 60)) {
          ctx.strokeStyle = 'rgba(253, 230, 138, 0.6)';
          ctx.lineWidth = 1.5;
          ctx.beginPath();
          ctx.ellipse(planetPt.x, planetPt.y, planetRadiusPx * 2.2, planetRadiusPx * 0.7, 0.3, 0, 2 * Math.PI);
          ctx.stroke();
        }

        // Body Label
        if (layers.labels) {
          ctx.fillStyle = isSelected ? '#38BDF8' : '#CBD5E1';
          ctx.font = isSelected ? 'bold 11px JetBrains Mono, monospace' : '10px JetBrains Mono, monospace';
          const distStr = `${Math.sqrt(curX_au * curX_au + curY_au * curY_au).toFixed(2)} AU`;
          ctx.fillText(name.toUpperCase(), planetPt.x + planetRadiusPx + 4, planetPt.y - 2);
          ctx.fillStyle = 'rgba(148, 163, 184, 0.6)';
          ctx.font = '9px JetBrains Mono, monospace';
          ctx.fillText(distStr, planetPt.x + planetRadiusPx + 4, planetPt.y + 9);
        }
      } catch {
        // Continue
      }
    });

    // 3. Draw Spacecraft: NEWTON-01
    try {
      const scState = elementsToStateVector(spacecraftElements, currentDate);
      const scX_au = kmToAu(scState.r.x);
      const scY_au = kmToAu(scState.r.y);
      const scZ_au = kmToAu(scState.r.z);

      const scPt = project3D(scX_au, scY_au, scZ_au, width, height);

      // Trajectory Arcs
      if (layers.trajectory) {
        // Past Arc (-60 days to 0)
        ctx.beginPath();
        ctx.strokeStyle = 'rgba(6, 182, 212, 0.7)'; // Solid muted cyan
        ctx.lineWidth = 1.5;
        const pastSteps = 40;
        for (let s = -pastSteps; s <= 0; s++) {
          const dtSec = (s / pastSteps) * (60 * 86400);
          const pElems = propagateKeplerian(spacecraftElements, dtSec);
          const pSt = elementsToStateVector(pElems, currentDate);
          const pt = project3D(kmToAu(pSt.r.x), kmToAu(pSt.r.y), kmToAu(pSt.r.z), width, height);
          if (s === -pastSteps) ctx.moveTo(pt.x, pt.y);
          else ctx.lineTo(pt.x, pt.y);
        }
        ctx.stroke();

        // Predicted Future Arc (0 to +120 days)
        ctx.beginPath();
        ctx.strokeStyle = 'rgba(56, 189, 248, 0.55)'; // Dashed sky blue
        ctx.setLineDash([4, 4]);
        ctx.lineWidth = 1.5;
        const futSteps = 80;
        for (let s = 0; s <= futSteps; s++) {
          const dtSec = (s / futSteps) * (120 * 86400);
          const pElems = propagateKeplerian(spacecraftElements, dtSec);
          const pSt = elementsToStateVector(pElems, currentDate);
          const pt = project3D(kmToAu(pSt.r.x), kmToAu(pSt.r.y), kmToAu(pSt.r.z), width, height);
          if (s === 0) ctx.moveTo(pt.x, pt.y);
          else ctx.lineTo(pt.x, pt.y);
        }
        ctx.stroke();
        ctx.setLineDash([]); // Reset dash
      }

      // Spacecraft Engineering Marker
      const isScSelected = selectedObjectName === 'NEWTON-01';
      ctx.fillStyle = '#38BDF8';
      ctx.beginPath();
      ctx.arc(scPt.x, scPt.y, 4, 0, 2 * Math.PI);
      ctx.fill();

      // Spacecraft Reticle
      ctx.strokeStyle = isScSelected ? '#F59E0B' : '#06B6D4';
      ctx.lineWidth = 1.5;
      const sBox = 8;
      ctx.strokeRect(scPt.x - sBox, scPt.y - sBox, sBox * 2, sBox * 2);

      // Label
      if (layers.labels) {
        ctx.fillStyle = '#38BDF8';
        ctx.font = 'bold 11px JetBrains Mono, monospace';
        ctx.fillText('NEWTON-01', scPt.x + 12, scPt.y - 2);
        ctx.fillStyle = '#94A3B8';
        ctx.font = '9px JetBrains Mono, monospace';
        const scDist = Math.sqrt(scX_au * scX_au + scY_au * scY_au).toFixed(3);
        ctx.fillText(`r: ${scDist} AU`, scPt.x + 12, scPt.y + 10);
      }
    } catch {
      // Continue
    }

  }, [
    currentDate,
    selectedObjectName,
    zoom,
    pan,
    rotation,
    layers,
    scaleMode,
    isNightMode,
    project3D,
    spacecraftElements,
  ]);

  // Mouse Interaction Handlers
  const handleMouseDown = (e: React.MouseEvent<HTMLCanvasElement>) => {
    setIsDragging(true);
    setLastMouse({ x: e.clientX, y: e.clientY });
    if (e.button === 2 || e.shiftKey) {
      setDragMode('pan');
    } else {
      setDragMode('orbit');
    }
  };

  const handleMouseMove = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (!isDragging) {
      // Check object hover for cursor
      return;
    }

    const dx = e.clientX - lastMouse.x;
    const dy = e.clientY - lastMouse.y;
    setLastMouse({ x: e.clientX, y: e.clientY });

    if (dragMode === 'pan') {
      setPan(prev => ({ x: prev.x + dx, y: prev.y + dy }));
    } else {
      setRotation(prev => ({
        azimuth: prev.azimuth + dx * 0.008,
        pitch: Math.max(0.05, Math.min(Math.PI / 2, prev.pitch + dy * 0.008)),
      }));
    }
  };

  const handleMouseUp = () => {
    setIsDragging(false);
  };

  const handleWheel = (e: React.WheelEvent<HTMLCanvasElement>) => {
    e.preventDefault();
    const factor = e.deltaY < 0 ? 1.15 : 0.87;
    setZoom(prev => Math.max(4, Math.min(2000, prev * factor)));
  };

  // Click on Canvas to Select Object
  const handleCanvasClick = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const clickX = e.clientX - rect.left;
    const clickY = e.clientY - rect.top;

    const width = rect.width;
    const height = rect.height;

    // Check Sun
    const sunPt = project3D(0, 0, 0, width, height);
    if (Math.hypot(clickX - sunPt.x, clickY - sunPt.y) < 18) {
      onSelectObject('Sun');
      return;
    }

    // Check Spacecraft
    try {
      const scState = elementsToStateVector(spacecraftElements, currentDate);
      const scPt = project3D(kmToAu(scState.r.x), kmToAu(scState.r.y), kmToAu(scState.r.z), width, height);
      if (Math.hypot(clickX - scPt.x, clickY - scPt.y) < 16) {
        onSelectObject('NEWTON-01');
        return;
      }
    } catch {}

    // Check Planets
    for (const name of PLANET_NAMES) {
      try {
        const elems = getPlanetOrbitalElements(name, currentDate);
        const state = elementsToStateVector(elems, currentDate);
        const pt = project3D(kmToAu(state.r.x), kmToAu(state.r.y), kmToAu(state.r.z), width, height);
        if (Math.hypot(clickX - pt.x, clickY - pt.y) < 16) {
          onSelectObject(name);
          return;
        }
      } catch {}
    }
  };

  return (
    <div className="relative w-full h-full min-h-[500px] flex flex-col bg-[#07090E] select-none overflow-hidden">
      {/* HUD Overlay Bar */}
      <div className="absolute top-3 left-3 z-10 flex flex-wrap items-center gap-2 pointer-events-auto">
        {/* Display Mode Dropdown */}
        <div className="bg-[#0B0E14]/90 border border-slate-800 rounded px-2 py-1 text-xs font-mono text-slate-300 flex items-center gap-1.5 shadow-sm">
          <span className="text-slate-500 text-[10px]">VIEW:</span>
          <select
            value={displayMode}
            onChange={(e) => {
              const m = e.target.value;
              setDisplayMode(m);
              applyViewPreset(m);
            }}
            className="bg-transparent text-sky-400 font-semibold focus:outline-none cursor-pointer"
          >
            <option value="SOLAR_SYSTEM">SOLAR SYSTEM (FULL)</option>
            <option value="INNER_SYSTEM">INNER SYSTEM</option>
            <option value="HELIOCENTRIC">HELIOCENTRIC</option>
            <option value="POLAR_VIEW">POLAR (TOP-DOWN)</option>
            <option value="ORBITAL_PLANE_VIEW">ORBITAL PLANE (EDGE-ON)</option>
            <option value="MISSION_VIEW">MISSION VIEW</option>
          </select>
        </div>

        {/* Layer Toggles */}
        <div className="hidden md:flex items-center gap-1 bg-[#0B0E14]/90 border border-slate-800 rounded p-1 text-[11px] font-mono shadow-sm">
          <button
            onClick={() => setLayers(prev => ({ ...prev, orbits: !prev.orbits }))}
            className={`px-2 py-0.5 rounded cursor-pointer ${layers.orbits ? 'bg-sky-950 text-sky-300 border border-sky-800' : 'text-slate-400 hover:text-slate-200'}`}
          >
            Orbits
          </button>
          <button
            onClick={() => setLayers(prev => ({ ...prev, trajectory: !prev.trajectory }))}
            className={`px-2 py-0.5 rounded cursor-pointer ${layers.trajectory ? 'bg-sky-950 text-sky-300 border border-sky-800' : 'text-slate-400 hover:text-slate-200'}`}
          >
            Trajectory
          </button>
          <button
            onClick={() => setLayers(prev => ({ ...prev, terminators: !prev.terminators }))}
            className={`px-2 py-0.5 rounded cursor-pointer ${layers.terminators ? 'bg-sky-950 text-sky-300 border border-sky-800' : 'text-slate-400 hover:text-slate-200'}`}
          >
            Terminators
          </button>
          <button
            onClick={() => setLayers(prev => ({ ...prev, velocity: !prev.velocity }))}
            className={`px-2 py-0.5 rounded cursor-pointer ${layers.velocity ? 'bg-sky-950 text-sky-300 border border-sky-800' : 'text-slate-400 hover:text-slate-200'}`}
          >
            Velocity
          </button>
          <button
            onClick={() => setLayers(prev => ({ ...prev, grid: !prev.grid }))}
            className={`px-2 py-0.5 rounded cursor-pointer ${layers.grid ? 'bg-sky-950 text-sky-300 border border-sky-800' : 'text-slate-400 hover:text-slate-200'}`}
          >
            Grid
          </button>
        </div>
      </div>

      {/* Floating Camera Controls */}
      <div className="absolute top-3 right-3 z-10 flex flex-col gap-1.5 pointer-events-auto">
        <button
          onClick={() => setZoom(prev => Math.min(2000, prev * 1.3))}
          className="p-1.5 bg-[#0B0E14]/90 hover:bg-slate-800 border border-slate-800 text-slate-300 rounded shadow transition-colors"
          title="Zoom In"
        >
          <ZoomIn className="w-4 h-4" />
        </button>
        <button
          onClick={() => setZoom(prev => Math.max(4, prev * 0.77))}
          className="p-1.5 bg-[#0B0E14]/90 hover:bg-slate-800 border border-slate-800 text-slate-300 rounded shadow transition-colors"
          title="Zoom Out"
        >
          <ZoomOut className="w-4 h-4" />
        </button>
        <button
          onClick={() => {
            setPan({ x: 0, y: 0 });
            setRotation({ azimuth: -0.2, pitch: 0.85 });
            setZoom(140);
          }}
          className="p-1.5 bg-[#0B0E14]/90 hover:bg-slate-800 border border-slate-800 text-slate-300 rounded shadow transition-colors"
          title="Reset Camera"
        >
          <RotateCcw className="w-4 h-4" />
        </button>
      </div>

      {/* Array Mode Prominent Telemetry Banner (when in Array Mode) */}
      {isArrayMode && (
        <div className="absolute bottom-4 left-4 z-10 bg-[#0B0E14]/95 border border-amber-500/40 rounded-lg p-3 text-xs font-mono backdrop-blur-md shadow-2xl max-w-md">
          <div className="text-[10px] text-amber-400 font-semibold tracking-wider uppercase mb-1">
            NEWTON ROCKETS MISSION ARRAY MONITOR
          </div>
          <div className="grid grid-cols-2 gap-x-4 gap-y-1 text-slate-300">
            <div><span className="text-slate-500">TARGET:</span> NEWTON-01</div>
            <div><span className="text-slate-500">PHASE:</span> HELIOCENTRIC CRUISE</div>
            <div><span className="text-slate-500">HELIOCENTRIC R:</span> 0.784 AU</div>
            <div><span className="text-slate-500">VELOCITY:</span> 33.42 km/s</div>
            <div><span className="text-slate-500">NEXT EVENT:</span> VENUS FLYBY (EGA-1)</div>
            <div><span className="text-slate-500">DISTANCE TO VENUS:</span> 4.12M km</div>
          </div>
        </div>
      )}

      {/* Canvas */}
      <canvas
        ref={canvasRef}
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        onWheel={handleWheel}
        onClick={handleCanvasClick}
        onContextMenu={(e) => e.preventDefault()}
        className="w-full h-full cursor-crosshair"
      />
    </div>
  );
};
