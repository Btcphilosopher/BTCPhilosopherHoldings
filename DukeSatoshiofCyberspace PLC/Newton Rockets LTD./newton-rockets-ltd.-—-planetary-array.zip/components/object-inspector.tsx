'use client';

import React, { useState } from 'react';
import { 
  getPlanetOrbitalElements, 
  elementsToStateVector, 
  computeSolarFlux, 
  computeIlluminatedFraction,
  CONSTANTS, 
  OrbitalElements, 
  StateVector, 
  kmToAu 
} from '@/lib/orbital-mechanics';
import { Crosshair, Orbit, Compass, Activity, Shield, Sun } from 'lucide-react';

interface ObjectInspectorProps {
  selectedObjectName: string;
  onSelectObject: (name: string) => void;
  currentDate: Date;
  spacecraftElements: OrbitalElements;
}

const BODIES_METADATA: Record<string, {
  name: string;
  type: string;
  mass_kg: number;
  radius_km: number;
  rotation_period_days: number;
  axial_tilt_deg: number;
  atmosphere: boolean;
  mu: number;
  soi_km: number;
  albedo: number;
  color: string;
}> = {
  Sun: {
    name: 'Sun', type: 'Yellow Dwarf (G2V)', mass_kg: 1.98847e30, radius_km: 696342,
    rotation_period_days: 25.38, axial_tilt_deg: 7.25, atmosphere: true,
    mu: CONSTANTS.MU_SUN, soi_km: Infinity, albedo: 0.0, color: '#F59E0B'
  },
  Mercury: {
    name: 'Mercury', type: 'Terrestrial Planet', mass_kg: 3.3011e23, radius_km: 2439.7,
    rotation_period_days: 58.646, axial_tilt_deg: 0.034, atmosphere: false,
    mu: CONSTANTS.MU.Mercury, soi_km: 112000, albedo: 0.142, color: '#94A3B8'
  },
  Venus: {
    name: 'Venus', type: 'Terrestrial Planet', mass_kg: 4.8675e24, radius_km: 6051.8,
    rotation_period_days: -243.02, axial_tilt_deg: 177.36, atmosphere: true,
    mu: CONSTANTS.MU.Venus, soi_km: 616000, albedo: 0.689, color: '#FBBF24'
  },
  Earth: {
    name: 'Earth', type: 'Terrestrial Planet', mass_kg: 5.9722e24, radius_km: 6378.137,
    rotation_period_days: 0.99727, axial_tilt_deg: 23.44, atmosphere: true,
    mu: CONSTANTS.MU.Earth, soi_km: 925000, albedo: 0.367, color: '#38BDF8'
  },
  Mars: {
    name: 'Mars', type: 'Terrestrial Planet', mass_kg: 6.4171e23, radius_km: 3396.2,
    rotation_period_days: 1.02596, axial_tilt_deg: 25.19, atmosphere: true,
    mu: CONSTANTS.MU.Mars, soi_km: 577000, albedo: 0.150, color: '#FB7185'
  },
  Jupiter: {
    name: 'Jupiter', type: 'Gas Giant', mass_kg: 1.8982e27, radius_km: 71492,
    rotation_period_days: 0.4135, axial_tilt_deg: 3.13, atmosphere: true,
    mu: CONSTANTS.MU.Jupiter, soi_km: 48200000, albedo: 0.538, color: '#F97316'
  },
  Saturn: {
    name: 'Saturn', type: 'Gas Giant', mass_kg: 5.6834e26, radius_km: 60268,
    rotation_period_days: 0.444, axial_tilt_deg: 26.73, atmosphere: true,
    mu: CONSTANTS.MU.Saturn, soi_km: 54800000, albedo: 0.499, color: '#EAB308'
  },
  Uranus: {
    name: 'Uranus', type: 'Ice Giant', mass_kg: 8.6810e25, radius_km: 25559,
    rotation_period_days: -0.7183, axial_tilt_deg: 97.77, atmosphere: true,
    mu: CONSTANTS.MU.Uranus, soi_km: 51800000, albedo: 0.488, color: '#2DD4BF'
  },
  Neptune: {
    name: 'Neptune', type: 'Ice Giant', mass_kg: 1.02413e26, radius_km: 24764,
    rotation_period_days: 0.6713, axial_tilt_deg: 28.32, atmosphere: true,
    mu: CONSTANTS.MU.Neptune, soi_km: 86800000, albedo: 0.442, color: '#60A5FA'
  },
  'NEWTON-01': {
    name: 'NEWTON-01', type: 'Solar Science Probe', mass_kg: 1450.0, radius_km: 0.003,
    rotation_period_days: 0.01, axial_tilt_deg: 0.0, atmosphere: false,
    mu: 0.0, soi_km: 0.0, albedo: 0.25, color: '#38BDF8'
  }
};

export const ObjectInspector: React.FC<ObjectInspectorProps> = ({
  selectedObjectName,
  onSelectObject,
  currentDate,
  spacecraftElements,
}) => {
  const [viewTab, setViewTab] = useState<'elements' | 'vectors' | 'physical'>('elements');

  const meta = BODIES_METADATA[selectedObjectName] || BODIES_METADATA['Earth'];

  // Calculate live state and elements
  let elements: OrbitalElements | null = null;
  let state: StateVector | null = null;

  if (selectedObjectName === 'NEWTON-01') {
    elements = spacecraftElements;
    state = elementsToStateVector(spacecraftElements, currentDate);
  } else if (selectedObjectName !== 'Sun') {
    try {
      elements = getPlanetOrbitalElements(selectedObjectName, currentDate);
      state = elementsToStateVector(elements, currentDate);
    } catch {
      // Continue
    }
  }

  const heliocentricDistKm = state ? Math.sqrt(state.r.x ** 2 + state.r.y ** 2 + state.r.z ** 2) : 0;
  const heliocentricDistAu = kmToAu(heliocentricDistKm);
  const velocityMag = state ? Math.sqrt(state.v.x ** 2 + state.v.y ** 2 + state.v.z ** 2) : 0;
  const solarFlux = heliocentricDistKm > 0 ? computeSolarFlux(heliocentricDistKm) : CONSTANTS.SOLAR_CONSTANT_1AU;
  const lightTimeToEarthS = heliocentricDistKm / CONSTANTS.SPEED_OF_LIGHT_KM_S;

  return (
    <div className="flex flex-col h-full bg-[#090C14] border-l border-slate-800 text-xs font-mono select-none overflow-y-auto">
      {/* Header Badge */}
      <div className="p-3 border-b border-slate-800 bg-[#0B0E14] flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: meta.color }}></div>
          <div>
            <div className="text-sm font-semibold text-slate-100 uppercase tracking-wide">
              {meta.name}
            </div>
            <div className="text-[10px] text-slate-400">
              {meta.type}
            </div>
          </div>
        </div>

        <select
          value={selectedObjectName}
          onChange={(e) => onSelectObject(e.target.value)}
          className="bg-slate-900 border border-slate-800 text-sky-400 text-xs px-2 py-1 rounded focus:outline-none cursor-pointer"
        >
          <option value="NEWTON-01">NEWTON-01 (PROBE)</option>
          <option value="Sun">SUN</option>
          <option value="Mercury">MERCURY</option>
          <option value="Venus">VENUS</option>
          <option value="Earth">EARTH</option>
          <option value="Mars">MARS</option>
          <option value="Jupiter">JUPITER</option>
          <option value="Saturn">SATURN</option>
          <option value="Uranus">URANUS</option>
          <option value="Neptune">NEPTUNE</option>
        </select>
      </div>

      {/* Primary Telemetry Stat Cards */}
      <div className="grid grid-cols-2 gap-2 p-3 border-b border-slate-800 bg-slate-950/40">
        <div className="bg-slate-900/60 border border-slate-800/80 rounded p-2">
          <div className="text-[10px] text-slate-500 uppercase">HELIOCENTRIC DIST.</div>
          <div className="text-sm font-semibold text-slate-100 tabular-nums">
            {selectedObjectName === 'Sun' ? '0.000' : heliocentricDistAu.toFixed(4)} <span className="text-[10px] text-slate-400 font-normal">AU</span>
          </div>
          <div className="text-[9px] text-slate-500 tabular-nums">
            {(heliocentricDistKm / 1e6).toFixed(3)} M km
          </div>
        </div>

        <div className="bg-slate-900/60 border border-slate-800/80 rounded p-2">
          <div className="text-[10px] text-slate-500 uppercase">ORBITAL VELOCITY</div>
          <div className="text-sm font-semibold text-emerald-400 tabular-nums">
            {velocityMag.toFixed(3)} <span className="text-[10px] text-slate-400 font-normal">km/s</span>
          </div>
          <div className="text-[9px] text-slate-500 tabular-nums">
            {(velocityMag * 3600).toFixed(0)} km/h
          </div>
        </div>

        <div className="bg-slate-900/60 border border-slate-800/80 rounded p-2">
          <div className="text-[10px] text-slate-500 uppercase">SOLAR FLUX</div>
          <div className="text-sm font-semibold text-amber-400 tabular-nums">
            {solarFlux.toFixed(1)} <span className="text-[10px] text-slate-400 font-normal">W/m²</span>
          </div>
          <div className="text-[9px] text-slate-500 tabular-nums">
            {(solarFlux / CONSTANTS.SOLAR_CONSTANT_1AU).toFixed(2)}× Earth Solar
          </div>
        </div>

        <div className="bg-slate-900/60 border border-slate-800/80 rounded p-2">
          <div className="text-[10px] text-slate-500 uppercase">LIGHT TIME TO EARTH</div>
          <div className="text-sm font-semibold text-sky-400 tabular-nums">
            {lightTimeToEarthS.toFixed(1)} <span className="text-[10px] text-slate-400 font-normal">SEC</span>
          </div>
          <div className="text-[9px] text-slate-500 tabular-nums">
            {(lightTimeToEarthS / 60).toFixed(2)} min
          </div>
        </div>
      </div>

      {/* Mode Tabs */}
      <div className="flex border-b border-slate-800 p-1 bg-[#07090E]">
        <button
          onClick={() => setViewTab('elements')}
          className={`flex-1 py-1 text-[11px] rounded transition-colors cursor-pointer ${
            viewTab === 'elements' ? 'bg-sky-950 text-sky-300 font-semibold border border-sky-800' : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          Elements
        </button>
        <button
          onClick={() => setViewTab('vectors')}
          className={`flex-1 py-1 text-[11px] rounded transition-colors cursor-pointer ${
            viewTab === 'vectors' ? 'bg-sky-950 text-sky-300 font-semibold border border-sky-800' : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          State Vectors
        </button>
        <button
          onClick={() => setViewTab('physical')}
          className={`flex-1 py-1 text-[11px] rounded transition-colors cursor-pointer ${
            viewTab === 'physical' ? 'bg-sky-950 text-sky-300 font-semibold border border-sky-800' : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          Physical Specs
        </button>
      </div>

      {/* Tab 1: Orbital Elements */}
      {viewTab === 'elements' && elements && (
        <div className="p-3 space-y-2">
          <div className="text-[10px] text-slate-500 uppercase tracking-wider font-semibold">
            KEPLERIAN ORBITAL PARAMETERS (J2000)
          </div>

          <div className="space-y-1.5 divide-y divide-slate-800/60">
            <div className="flex justify-between py-1">
              <span className="text-slate-400">Semi-Major Axis (a):</span>
              <span className="text-slate-200 font-medium tabular-nums">{elements.a.toFixed(6)} AU ({elements.a_km.toExponential(4)} km)</span>
            </div>
            <div className="flex justify-between py-1">
              <span className="text-slate-400">Eccentricity (e):</span>
              <span className="text-slate-200 font-medium tabular-nums">{elements.e.toFixed(6)}</span>
            </div>
            <div className="flex justify-between py-1">
              <span className="text-slate-400">Inclination (i):</span>
              <span className="text-slate-200 font-medium tabular-nums">{elements.inc_deg.toFixed(4)}° ({elements.inc.toFixed(4)} rad)</span>
            </div>
            <div className="flex justify-between py-1">
              <span className="text-slate-400">Ascending Node (Ω):</span>
              <span className="text-slate-200 font-medium tabular-nums">{elements.raan_deg.toFixed(4)}°</span>
            </div>
            <div className="flex justify-between py-1">
              <span className="text-slate-400">Arg. of Periapsis (ω):</span>
              <span className="text-slate-200 font-medium tabular-nums">{elements.argp_deg.toFixed(4)}°</span>
            </div>
            <div className="flex justify-between py-1">
              <span className="text-slate-400">True Anomaly (ν):</span>
              <span className="text-emerald-400 font-medium tabular-nums">{elements.nu_deg.toFixed(4)}°</span>
            </div>
            <div className="flex justify-between py-1">
              <span className="text-slate-400">Mean Anomaly (M):</span>
              <span className="text-slate-200 font-medium tabular-nums">{elements.M_deg.toFixed(4)}°</span>
            </div>
            <div className="flex justify-between py-1">
              <span className="text-slate-400">Orbital Period (T):</span>
              <span className="text-slate-200 font-medium tabular-nums">{elements.period_days.toFixed(2)} days ({(elements.period_days / 365.25).toFixed(3)} yr)</span>
            </div>
            <div className="flex justify-between py-1">
              <span className="text-slate-400">Specific Energy (ε):</span>
              <span className="text-slate-200 font-medium tabular-nums">{elements.energy.toFixed(3)} km²/s²</span>
            </div>
            <div className="flex justify-between py-1">
              <span className="text-slate-400">Angular Momentum (h):</span>
              <span className="text-slate-200 font-medium tabular-nums">{elements.angular_momentum.toExponential(4)} km²/s</span>
            </div>
          </div>
        </div>
      )}

      {/* Tab 2: State Vectors */}
      {viewTab === 'vectors' && state && (
        <div className="p-3 space-y-3">
          <div>
            <div className="text-[10px] text-slate-500 uppercase tracking-wider font-semibold mb-1">
              CARTESIAN POSITION VECTOR [KM]
            </div>
            <div className="bg-slate-950 p-2 rounded border border-slate-800 space-y-1">
              <div className="flex justify-between"><span className="text-slate-500">X:</span> <span className="text-slate-200 tabular-nums">{state.r.x.toFixed(2)} km</span></div>
              <div className="flex justify-between"><span className="text-slate-500">Y:</span> <span className="text-slate-200 tabular-nums">{state.r.y.toFixed(2)} km</span></div>
              <div className="flex justify-between"><span className="text-slate-500">Z:</span> <span className="text-slate-200 tabular-nums">{state.r.z.toFixed(2)} km</span></div>
              <div className="flex justify-between pt-1 border-t border-slate-800"><span className="text-sky-400">|r|:</span> <span className="text-sky-400 tabular-nums">{heliocentricDistKm.toFixed(2)} km</span></div>
            </div>
          </div>

          <div>
            <div className="text-[10px] text-slate-500 uppercase tracking-wider font-semibold mb-1">
              CARTESIAN VELOCITY VECTOR [KM/S]
            </div>
            <div className="bg-slate-950 p-2 rounded border border-slate-800 space-y-1">
              <div className="flex justify-between"><span className="text-slate-500">Vx:</span> <span className="text-slate-200 tabular-nums">{state.v.x.toFixed(4)} km/s</span></div>
              <div className="flex justify-between"><span className="text-slate-500">Vy:</span> <span className="text-slate-200 tabular-nums">{state.v.y.toFixed(4)} km/s</span></div>
              <div className="flex justify-between"><span className="text-slate-500">Vz:</span> <span className="text-slate-200 tabular-nums">{state.v.z.toFixed(4)} km/s</span></div>
              <div className="flex justify-between pt-1 border-t border-slate-800"><span className="text-emerald-400">|v|:</span> <span className="text-emerald-400 tabular-nums">{velocityMag.toFixed(4)} km/s</span></div>
            </div>
          </div>
        </div>
      )}

      {/* Tab 3: Physical Specifications */}
      {viewTab === 'physical' && (
        <div className="p-3 space-y-2">
          <div className="text-[10px] text-slate-500 uppercase tracking-wider font-semibold">
            PHYSICAL CHARACTERISTICS
          </div>
          <div className="space-y-1.5 divide-y divide-slate-800/60">
            <div className="flex justify-between py-1">
              <span className="text-slate-400">Mass:</span>
              <span className="text-slate-200 tabular-nums">{meta.mass_kg.toExponential(4)} kg</span>
            </div>
            <div className="flex justify-between py-1">
              <span className="text-slate-400">Equatorial Radius:</span>
              <span className="text-slate-200 tabular-nums">{meta.radius_km.toLocaleString()} km</span>
            </div>
            <div className="flex justify-between py-1">
              <span className="text-slate-400">Gravitational Parameter (μ):</span>
              <span className="text-slate-200 tabular-nums">{meta.mu.toExponential(4)} km³/s²</span>
            </div>
            <div className="flex justify-between py-1">
              <span className="text-slate-400">Rotation Period:</span>
              <span className="text-slate-200 tabular-nums">{meta.rotation_period_days} days</span>
            </div>
            <div className="flex justify-between py-1">
              <span className="text-slate-400">Axial Tilt:</span>
              <span className="text-slate-200 tabular-nums">{meta.axial_tilt_deg}°</span>
            </div>
            <div className="flex justify-between py-1">
              <span className="text-slate-400">Geometric Albedo:</span>
              <span className="text-slate-200 tabular-nums">{meta.albedo}</span>
            </div>
            <div className="flex justify-between py-1">
              <span className="text-slate-400">Atmosphere Present:</span>
              <span className={meta.atmosphere ? 'text-emerald-400' : 'text-slate-500'}>{meta.atmosphere ? 'YES' : 'NO'}</span>
            </div>
            <div className="flex justify-between py-1">
              <span className="text-slate-400">Sphere of Influence (SOI):</span>
              <span className="text-slate-200 tabular-nums">{meta.soi_km === Infinity ? 'INF' : `${(meta.soi_km / 1e3).toLocaleString()} k km`}</span>
            </div>
          </div>
        </div>
      )}

      {/* Special Spacecraft Mission State Card */}
      {selectedObjectName === 'NEWTON-01' && (
        <div className="mt-auto p-3 border-t border-slate-800 bg-[#0B0E14]">
          <div className="text-[10px] text-sky-400 uppercase tracking-wider font-semibold mb-1">
            SPACECRAFT MISSION STATUS
          </div>
          <div className="space-y-1 text-slate-300">
            <div className="flex justify-between"><span className="text-slate-500">PHASE:</span> <span className="text-sky-300 font-medium">HELIOCENTRIC CRUISE</span></div>
            <div className="flex justify-between"><span className="text-slate-500">PROPELLANT:</span> <span className="tabular-nums">724.2 / 730 kg</span></div>
            <div className="flex justify-between"><span className="text-slate-500">NEXT ENCOUNTER:</span> <span className="text-amber-300">VENUS EGA-1</span></div>
            <div className="flex justify-between"><span className="text-slate-500">DELTA-V BUDGET:</span> <span className="text-emerald-400 tabular-nums">1,840 m/s REMAINING</span></div>
          </div>
        </div>
      )}
    </div>
  );
};
