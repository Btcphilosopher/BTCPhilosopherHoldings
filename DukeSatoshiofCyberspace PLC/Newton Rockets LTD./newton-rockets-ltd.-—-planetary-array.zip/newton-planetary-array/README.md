# NEWTON ROCKETS LTD.
## PLANETARY ARRAY
### ORBITAL DYNAMICS • MISSION GEOMETRY • PLANETARY SYSTEM

```
EPHEMERIS ──▶ PLANETARY STATE ──▶ ORBITAL MODEL ──▶ SPACECRAFT STATE ──▶ TRAJECTORY ──▶ MISSION GEOMETRY ──▶ PLANETARY ARRAY
```

The **Planetary Array** is Newton Rockets Ltd.'s mission-grade engineering display and celestial mechanics computational environment. Designed for flight dynamics teams, trajectory planners, and ground operations, it visualises the Solar System as a dynamic mathematical system operating on authentic physics models and authoritative ephemerides.

---

### Core Architecture & Technical Specifications

1. **Ephemeris Ingestion & Time Scales**:
   - Planetary states derived from NASA JPL DE405 / VSOP87 analytical perturbation series with secular planetary drift.
   - Precision time conversions across UTC, TAI, TT, Barycentric Dynamical Time (TDB), Julian Date (JD), and Modified Julian Date (MJD).
   - Standard epoch: J2000.0 (JD 2451545.0, 2000-01-01 12:00:00 TT).

2. **Orbital Mechanics Engine**:
   - Universal Kepler's equation solver ($M = E - e \sin E$) with 5th-order Householder iteration providing numerical convergence to $10^{-14}$ machine tolerance across circular, elliptic, parabolic, and hyperbolic orbits.
   - Bidirectional transformations between Cartesian state vectors $(\mathbf{r}, \mathbf{v})$ and Keplerian orbital elements $(a, e, i, \Omega, \omega, \nu)$.
   - Perturbed Cowell / Encke numerical propagators and analytic secular drift models (Earth/planetary $J_2$, Solar Radiation Pressure, third-body gravitational perturbations).

3. **Spacecraft Trajectory & Mission Analysis**:
   - Lambert boundary value problem solver for interplanetary transfers.
   - Gravity-assist flyby analytics: Hyperbolic excess velocity $v_\infty$, turning angle $\delta = 2 \arcsin(1 / (1 + r_p v_\infty^2 / \mu))$, B-plane targeting $(B \cdot R, B \cdot T)$.
   - Sphere of Influence (SOI) entry and exit monitoring: $r_{\text{SOI}} = a (m_p / M_\odot)^{2/5}$.
   - Monte Carlo trajectory dispersion and 3-axis covariance ellipsoids for navigation uncertainty.

4. **Reference Frame Systems**:
   - Heliocentric Ecliptic J2000.0 (ICRF primary reference)
   - Geocentric Equatorial (ECI / GCRF)
   - Earth-Centered Earth-Fixed (ECEF)
   - Local Vertical Local Horizontal (LVLH)
   - Spacecraft Body Frame

5. **Visual Operating Surface & Large-Format Array**:
   - 3D/2D High-precision orbital canvas with interactive rotation, pan, zoom, and pitch.
   - Large-Format Array Mode tailored for operations center wall displays with prominent UTC clocks, mission day counters ($T + \text{XXX}$), and uncluttered telemetry grids.
   - Control Room Night Theme with high-contrast monochrome backgrounds, white engineering labels, muted cyan/blue trajectories, and amber status advisories.

---

### Command-Line Interface (CLI)

```bash
# Run mission scenario simulation
Rscript run.R --scenario examples/solar_probe.yaml

# Generate comprehensive mission engineering dossier
Rscript report.R --scenario examples/earth_to_mars.yaml --out reports/mars_transfer.html

# Run Monte Carlo uncertainty propagation
Rscript simulate.R --scenario examples/mercury_probe.yaml --samples 500
```

---

### Targets Pipeline

The reproducible data pipeline is defined in `_targets.R` and manages ephemeris caching, trajectory propagation, conjunction sweeps, and report compilation.

```r
library(targets)
tar_make()
```
