# Newton Rockets Ltd. - State Vector to Orbital Elements Transformation
# Exact analytical conversion per Bate, Mueller, White (BMW) "Fundamentals of Astrodynamics"

state_vector_to_elements <- function(r_vec, v_vec, epoch, mu = NEWTON_CONSTANTS$MU_SUN, frame = "Heliocentric Ecliptic J2000") {
  r_mag <- sqrt(sum(r_vec^2))
  v_mag <- sqrt(sum(v_vec^2))
  
  if (r_mag == 0) stop("Position magnitude cannot be zero.")
  
  # Specific angular momentum vector h = r x v
  h_vec <- c(
    r_vec[2] * v_vec[3] - r_vec[3] * v_vec[2],
    r_vec[3] * v_vec[1] - r_vec[1] * v_vec[3],
    r_vec[1] * v_vec[2] - r_vec[2] * v_vec[1]
  )
  h_mag <- sqrt(sum(h_vec^2))
  
  # Node vector n = k_hat x h = (-h_y, h_x, 0)
  n_vec <- c(-h_vec[2], h_vec[1], 0)
  n_mag <- sqrt(sum(n_vec^2))
  
  # Eccentricity vector e = (1/mu) * [(v^2 - mu/r)*r - (r . v)*v]
  r_dot_v <- sum(r_vec * v_vec)
  e_vec <- (1 / mu) * ((v_mag^2 - mu / r_mag) * r_vec - r_dot_v * v_vec)
  e_mag <- sqrt(sum(e_vec^2))
  
  # Specific mechanical energy epsilon = v^2/2 - mu/r
  energy <- (v_mag^2 / 2) - (mu / r_mag)
  
  # Semi-major axis a = -mu / (2 * epsilon)
  if (abs(e_mag - 1.0) > 1e-12) {
    a <- -mu / (2 * energy)
  } else {
    a <- Inf # Parabolic
  }
  
  # Inclination i = acos(h_z / h)
  inc <- acos(pmin(pmax(h_vec[3] / h_mag, -1.0), 1.0))
  
  # Longitude of Ascending Node Omega
  if (n_mag > 1e-10) {
    raan <- acos(pmin(pmax(n_vec[1] / n_mag, -1.0), 1.0))
    if (n_vec[2] < 0) raan <- 2 * pi - raan
  } else {
    raan <- 0 # Equatorial orbit
  }
  
  # Argument of Periapsis omega
  if (n_mag > 1e-10 && e_mag > 1e-10) {
    argp <- acos(pmin(pmax(sum(n_vec * e_vec) / (n_mag * e_mag), -1.0), 1.0))
    if (e_vec[3] < 0) argp <- 2 * pi - argp
  } else {
    argp <- 0
  }
  
  # True Anomaly nu
  if (e_mag > 1e-10) {
    nu <- acos(pmin(pmax(sum(e_vec * r_vec) / (e_mag * r_mag), -1.0), 1.0))
    if (r_dot_v < 0) nu <- 2 * pi - nu
  } else {
    # Circular orbit: argument of latitude u
    nu <- acos(pmin(pmax(r_vec[1] / r_mag, -1.0), 1.0))
    if (r_vec[2] < 0) nu <- 2 * pi - nu
  }
  
  # Orbital period T = 2*pi*sqrt(a^3 / mu)
  period_seconds <- ifelse(a > 0, 2 * pi * sqrt(a^3 / mu), Inf)
  
  list(
    a = a,
    e = e_mag,
    inc = inc,
    raan = raan,
    argp = argp,
    nu = nu,
    period_days = period_seconds / 86400.0,
    energy = energy,
    angular_momentum = h_mag,
    h_vector = h_vec,
    e_vector = e_vec,
    epoch = epoch,
    frame = frame
  )
}
