# Newton Rockets Ltd. - Orbital Propagation Engines (Analytical Keplerian & Numerical Runge-Kutta 4)

propagate_keplerian <- function(initial_elements, delta_t_seconds, mu = NEWTON_CONSTANTS$MU_SUN) {
  a <- initial_elements$a
  e <- initial_elements$e
  
  if (a <= 0) stop("Elliptical Keplerian propagator requires positive semi-major axis.")
  
  # Mean motion n = sqrt(mu / a^3) [rad/s]
  n <- sqrt(mu / (a^3))
  
  # Convert initial true anomaly nu0 to initial mean anomaly M0
  cos_nu0 <- cos(initial_elements$nu)
  sin_nu0 <- sin(initial_elements$nu)
  
  # Eccentric anomaly E0
  sin_E0 <- (sqrt(1.0 - e^2) * sin_nu0) / (1.0 + e * cos_nu0)
  cos_E0 <- (e + cos_nu0) / (1.0 + e * cos_nu0)
  E0 <- wrap_2pi(atan2(sin_E0, cos_E0))
  
  M0 <- E0 - e * sin(E0)
  
  # Propagate mean anomaly M(t) = M0 + n * dt
  M_t <- wrap_2pi(M0 + n * delta_t_seconds)
  
  # Solve for new true anomaly nu(t)
  nu_t <- solve_kepler_true_anomaly(M_t, e)
  
  # New epoch
  new_epoch <- as.POSIXct(initial_elements$epoch, tz = "UTC") + delta_t_seconds
  
  new_orbital_elements(
    a = a,
    e = e,
    inc = initial_elements$inc,
    raan = initial_elements$raan,
    argp = initial_elements$argp,
    nu = nu_t,
    epoch = new_epoch,
    mu = mu,
    frame = initial_elements$frame
  )
}

# Numerical Cowell RK4 Integrator with optional J2 and 3rd body perturbations
rk4_step <- function(r_vec, v_vec, dt, accel_func, params) {
  k1_v <- accel_func(r_vec, v_vec, params)
  k1_r <- v_vec
  
  r2 <- r_vec + 0.5 * dt * k1_r
  v2 <- v_vec + 0.5 * dt * k1_v
  k2_v <- accel_func(r2, v2, params)
  k2_r <- v2
  
  r3 <- r_vec + 0.5 * dt * k2_r
  v3 <- v_vec + 0.5 * dt * k2_v
  k3_v <- accel_func(r3, v3, params)
  k3_r <- v3
  
  r4 <- r_vec + dt * k3_r
  v4 <- v_vec + dt * k3_v
  k4_v <- accel_func(r4, v4, params)
  k4_r <- v4
  
  r_next <- r_vec + (dt / 6.0) * (k1_r + 2.0 * k2_r + 2.0 * k3_r + k4_r)
  v_next <- v_vec + (dt / 6.0) * (k1_v + 2.0 * k2_v + 2.0 * k3_v + k4_v)
  
  list(r = r_next, v = v_next)
}
