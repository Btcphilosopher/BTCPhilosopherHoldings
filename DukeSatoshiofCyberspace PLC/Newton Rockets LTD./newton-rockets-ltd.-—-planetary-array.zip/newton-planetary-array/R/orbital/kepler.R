# Newton Rockets Ltd. - Universal Kepler Solver
# High-precision Householder / Halley iteration converging to machine precision (< 1e-14)

solve_kepler_eccentric_anomaly <- function(M, e, tol = 1e-14, max_iter = 50) {
  # Wrap M into [-pi, pi]
  M <- wrap_pi(M)
  
  if (e < 1.0) {
    # Elliptic Kepler Equation: M = E - e * sin(E)
    # Initial guess with high-accuracy cubic series (Danby)
    if (abs(M) < 0.2) {
      E <- M / (1 - e)
    } else {
      E <- M + e * sin(M) + 0.5 * e^2 * sin(2 * M)
    }
    
    for (i in 1:max_iter) {
      sin_E <- sin(E)
      cos_E <- cos(E)
      
      f   <- E - e * sin_E - M
      f_p <- 1.0 - e * cos_E
      f_pp <- e * sin_E
      
      # Halley's third-order correction step
      delta <- - f / (f_p - 0.5 * f * f_pp / f_p)
      E <- E + delta
      
      if (abs(delta) < tol) {
        return(wrap_2pi(E))
      }
    }
    return(wrap_2pi(E))
  } else {
    # Hyperbolic Kepler Equation: M = e * sinh(F) - F
    # Initial guess
    F <- log(2.0 * abs(M) / e + 1.8)
    if (M < 0) F <- -F
    
    for (i in 1:max_iter) {
      sinh_F <- sinh(F)
      cosh_F <- cosh(F)
      
      f   <- e * sinh_F - F - M
      f_p <- e * cosh_F - 1.0
      f_pp <- e * sinh_F
      
      delta <- - f / (f_p - 0.5 * f * f_pp / f_p)
      F <- F + delta
      
      if (abs(delta) < tol) {
        return(F)
      }
    }
    return(F)
  }
}

solve_kepler_true_anomaly <- function(M, e) {
  if (e < 1.0) {
    E <- solve_kepler_eccentric_anomaly(M, e)
    # True anomaly nu from E
    sin_nu <- (sqrt(1.0 - e^2) * sin(E)) / (1.0 - e * cos(E))
    cos_nu <- (cos(E) - e) / (1.0 - e * cos(E))
    wrap_2pi(atan2(sin_nu, cos_nu))
  } else {
    F <- solve_kepler_eccentric_anomaly(M, e)
    # Hyperbolic true anomaly
    tanh_half_F <- tanh(F / 2.0)
    tan_half_nu <- sqrt((e + 1.0) / (e - 1.0)) * tanh_half_F
    2.0 * atan(tan_half_nu)
  }
}
