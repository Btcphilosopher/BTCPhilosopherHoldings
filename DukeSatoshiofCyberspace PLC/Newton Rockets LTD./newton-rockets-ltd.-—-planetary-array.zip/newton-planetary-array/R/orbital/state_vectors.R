# Newton Rockets Ltd. - Orbital Elements to Cartesian State Vector Conversion

elements_to_state_vector <- function(a, e, inc, raan, argp, nu, mu = NEWTON_CONSTANTS$MU_SUN, epoch = Sys.time(), frame = "Heliocentric Ecliptic J2000", body = "Spacecraft") {
  # Semi-latus rectum p = a * (1 - e^2)
  p <- a * (1.0 - e^2)
  
  # Radial distance r = p / (1 + e * cos(nu))
  r <- p / (1.0 + e * cos(nu))
  
  # State in orbital perifocal plane (PQW frame)
  r_pqw <- c(
    r * cos(nu),
    r * sin(nu),
    0.0
  )
  
  sqrt_mu_p <- sqrt(mu / p)
  v_pqw <- c(
    -sqrt_mu_p * sin(nu),
    sqrt_mu_p * (e + cos(nu)),
    0.0
  )
  
  # Direction Cosine Matrix from PQW to Inertial frame
  # Rotations: R_z(-raan) * R_x(-inc) * R_z(-argp)
  cos_O <- cos(raan); sin_O <- sin(raan)
  cos_i <- cos(inc);  sin_i <- sin(inc)
  cos_w <- cos(argp); sin_w <- sin(argp)
  
  P_x <- cos_O * cos_w - sin_O * sin_w * cos_i
  P_y <- sin_O * cos_w + cos_O * sin_w * cos_i
  P_z <- sin_w * sin_i
  
  Q_x <- -cos_O * sin_w - sin_O * cos_w * cos_i
  Q_y <- -sin_O * sin_w + cos_O * cos_w * cos_i
  Q_z <- cos_w * sin_i
  
  W_x <- sin_O * sin_i
  W_y <- -cos_O * sin_i
  W_z <- cos_i
  
  # Inertial coordinates
  r_inertial <- c(
    r_pqw[1] * P_x + r_pqw[2] * Q_x,
    r_pqw[1] * P_y + r_pqw[2] * Q_y,
    r_pqw[1] * P_z + r_pqw[2] * Q_z
  )
  
  v_inertial <- c(
    v_pqw[1] * P_x + v_pqw[2] * Q_x,
    v_pqw[1] * P_y + v_pqw[2] * Q_y,
    v_pqw[1] * P_z + v_pqw[2] * Q_z
  )
  
  new_state_vector(
    x = r_inertial[1],
    y = r_inertial[2],
    z = r_inertial[3],
    vx = v_inertial[1],
    vy = v_inertial[2],
    vz = v_inertial[3],
    epoch = epoch,
    frame = frame,
    body = body
  )
}
