# Newton Rockets Ltd. - Time Scales Conversion Library
# Reference: Explanatory Supplement to the Astronomical Almanac

utc_to_tai <- function(utc_posix) {
  # Standard leap seconds offset (approx 37 seconds post-2017)
  as.POSIXct(utc_posix, tz = "UTC") + 37.0
}

tai_to_tt <- function(tai_posix) {
  # TT = TAI + 32.184s
  tai_posix + 32.184
}

utc_to_tt <- function(utc_posix) {
  # TT = UTC + 37 + 32.184 = UTC + 69.184s
  as.POSIXct(utc_posix, tz = "UTC") + 69.184
}

tt_to_tdb <- function(tt_posix) {
  # TDB approximately equals TT within 1.7 ms
  # TDB = TT + 0.001657 * sin(g + 0.01671 * sin(g))
  jd <- posix_to_jd(tt_posix)
  t <- (jd - 2451545.0) / 36525.0
  g <- deg_to_rad(357.53 + 35999.05 * t)
  tt_posix + 0.001657 * sin(g + 0.01671 * sin(g))
}

epoch_to_jd <- function(epoch_str) {
  posix_to_jd(as.POSIXct(epoch_str, tz = "UTC"))
}
