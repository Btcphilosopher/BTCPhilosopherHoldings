# Newton Rockets Ltd. - Authoritative Planetary Ephemeris (NASA JPL Standish / VSOP87 Analytical Series)
# Reference: Standish, E.M. (JPL IOM 312.F-92-102) "Keplerian Elements for Approximate Positions of the Major Planets"

# Coefficients table: [a0, a_rate, e0, e_rate, I0, I_rate, L0, L_rate, varpi0, varpi_rate, node0, node_rate]
# Rates are per Julian Century (36525 days)
JPL_PLANETARY_ELEMENTS_COEFFS <- list(
  Mercury = list(
    a0 = 0.38709927,   a_dot = 0.00000037,
    e0 = 0.20563593,   e_dot = 0.00001906,
    I0 = 7.00497902,   I_dot = -0.00594749,
    L0 = 252.25032350, L_dot = 149472.67411175,
    varpi0 = 77.45779628, varpi_dot = 0.16047689,
    node0 = 48.33076593,  node_dot = -0.12534081
  ),
  Venus = list(
    a0 = 0.72333566,   a_dot = 0.00000390,
    e0 = 0.00677672,   e_dot = -0.00004107,
    I0 = 3.39467605,   I_dot = -0.00078890,
    L0 = 181.97909950, L_dot = 58517.81538729,
    varpi0 = 131.60246718, varpi_dot = 0.00268329,
    node0 = 76.67984255,   node_dot = -0.27769418
  ),
  Earth = list(
    a0 = 1.00000261,   a_dot = 0.00000562,
    e0 = 0.01671123,   e_dot = -0.00004392,
    I0 = -0.00001531,  I_dot = -0.01294668,
    L0 = 100.46457166, L_dot = 35999.37244981,
    varpi0 = 102.93768193, varpi_dot = 0.32327364,
    node0 = 0.0,           node_dot = 0.0
  ),
  Mars = list(
    a0 = 1.52371034,   a_dot = 0.00001847,
    e0 = 0.09339410,   e_dot = 0.00007882,
    I0 = 1.84969142,   I_dot = -0.00813131,
    L0 = -4.55343205,  L_dot = 19140.30268499,
    varpi0 = -23.94362959, varpi_dot = 0.44441088,
    node0 = 49.55953891,   node_dot = -0.29257343
  ),
  Jupiter = list(
    a0 = 5.20288700,   a_dot = -0.00011607,
    e0 = 0.04838624,   e_dot = -0.00013253,
    I0 = 1.30439695,   I_dot = -0.00183714,
    L0 = 34.39644051,  L_dot = 3034.74612775,
    varpi0 = 14.72847983, varpi_dot = 0.21252668,
    node0 = 100.47390909, node_dot = 0.20469106
  ),
  Saturn = list(
    a0 = 9.53667594,   a_dot = -0.00125060,
    e0 = 0.05386179,   e_dot = -0.00050991,
    I0 = 2.48599187,   I_dot = 0.00193609,
    L0 = 49.95424423,  L_dot = 1222.49362201,
    varpi0 = 92.59887831, varpi_dot = -0.41897216,
    node0 = 113.66242448, node_dot = -0.28867794
  ),
  Uranus = list(
    a0 = 19.18916464,  a_dot = -0.00196176,
    e0 = 0.04725744,   e_dot = -0.00004397,
    I0 = 0.77263783,   I_dot = -0.00242939,
    L0 = 313.23810451, L_dot = 428.48202785,
    varpi0 = 170.95427630, varpi_dot = 0.40805281,
    node0 = 74.01692503,   node_dot = 0.04240589
  ),
  Neptune = list(
    a0 = 30.06992276,  a_dot = 0.00026291,
    e0 = 0.00859048,   e_dot = 0.00005105,
    I0 = 1.77004347,   I_dot = 0.00035372,
    L0 = -55.12002969, L_dot = 218.45945325,
    varpi0 = 44.96476227, varpi_dot = -0.32241464,
    node0 = 131.78422574, node_dot = -0.00508664
  )
)

get_planet_orbital_elements <- function(planet_name, epoch_posix) {
  if (!planet_name %in% names(JPL_PLANETARY_ELEMENTS_COEFFS)) {
    stop(paste("Unknown planetary body:", planet_name))
  }
  
  jd <- posix_to_jd(epoch_posix)
  T_centuries <- jd_to_centuries_j2000(jd)
  c <- JPL_PLANETARY_ELEMENTS_COEFFS[[planet_name]]
  
  a_au <- c$a0 + c$a_dot * T_centuries
  e <- c$e0 + c$e_dot * T_centuries
  I_deg <- c$I0 + c$I_dot * T_centuries
  L_deg <- c$L0 + c$L_dot * T_centuries
  varpi_deg <- c$varpi0 + c$varpi_dot * T_centuries
  node_deg <- c$node0 + c$node_dot * T_centuries
  
  # Argument of periapsis omega = varpi - Omega
  omega_deg <- (varpi_deg - node_deg) %% 360.0
  # Mean anomaly M = L - varpi
  M_deg <- (L_deg - varpi_deg) %% 360.0
  
  # Wrap angles
  I_rad <- deg_to_rad(I_deg)
  node_rad <- deg_to_rad(node_deg)
  omega_rad <- deg_to_rad(omega_deg)
  M_rad <- deg_to_rad(M_deg)
  
  # Solve Kepler's equation to obtain true anomaly nu
  nu_rad <- solve_kepler_true_anomaly(M_rad, e)
  
  new_orbital_elements(
    a = au_to_km(a_au),
    e = e,
    inc = I_rad,
    raan = node_rad,
    argp = omega_rad,
    nu = nu_rad,
    epoch = epoch_posix,
    mu = NEWTON_CONSTANTS$MU_SUN,
    frame = "Heliocentric Ecliptic J2000"
  )
}
