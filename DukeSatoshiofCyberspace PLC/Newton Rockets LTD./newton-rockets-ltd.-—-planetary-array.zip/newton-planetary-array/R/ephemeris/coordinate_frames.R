# Newton Rockets Ltd. - Coordinate Frames & Direction Cosine Matrices

# Transform vector from Ecliptic to Equatorial frame (rotation by obliquity epsilon)
ecliptic_to_equatorial <- function(vec_ecliptic, eps = NEWTON_CONSTANTS$EPSILON_J2000_RAD) {
  cos_eps <- cos(eps)
  sin_eps <- sin(eps)
  
  R_x <- matrix(c(
    1,       0,        0,
    0, cos_eps, -sin_eps,
    0, sin_eps,  cos_eps
  ), nrow = 3, byrow = TRUE)
  
  as.vector(R_x %*% vec_ecliptic)
}

# Transform vector from Equatorial to Ecliptic frame
equatorial_to_ecliptic <- function(vec_equatorial, eps = NEWTON_CONSTANTS$EPSILON_J2000_RAD) {
  cos_eps <- cos(eps)
  sin_eps <- sin(eps)
  
  R_x_inv <- matrix(c(
    1,        0,       0,
    0,  cos_eps, sin_eps,
    0, -sin_eps, cos_eps
  ), nrow = 3, byrow = TRUE)
  
  as.vector(R_x_inv %*% vec_equatorial)
}

# Construct Local-Vertical-Local-Horizontal (LVLH) rotation matrix from state vector
# r_vec: position vector [km], v_vec: velocity vector [km/s]
state_to_lvlh_dcm <- function(r_vec, v_vec) {
  r_norm <- sqrt(sum(r_vec^2))
  v_norm <- sqrt(sum(v_vec^2))
  
  # Radial unit vector (outward)
  e_r <- r_vec / r_norm
  
  # Cross-track / Angular momentum unit vector
  h_vec <- c(
    r_vec[2]*v_vec[3] - r_vec[3]*v_vec[2],
    r_vec[3]*v_vec[1] - r_vec[1]*v_vec[3],
    r_vec[1]*v_vec[2] - r_vec[2]*v_vec[1]
  )
  e_h <- h_vec / sqrt(sum(h_vec^2))
  
  # In-track unit vector (completes right-handed orthogonal triad)
  e_theta <- c(
    e_h[2]*e_r[3] - e_h[3]*e_r[2],
    e_h[3]*e_r[1] - e_h[1]*e_r[3],
    e_h[1]*e_r[2] - e_h[2]*e_r[1]
  )
  
  # Matrix mapping Inertial -> LVLH
  rbind(e_r, e_theta, e_h)
}
