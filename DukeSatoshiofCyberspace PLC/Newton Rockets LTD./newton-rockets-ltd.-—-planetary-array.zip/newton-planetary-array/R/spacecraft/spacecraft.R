# Newton Rockets Ltd. - Spacecraft Object Model & Mission Phases

new_spacecraft <- function(
  name = "NEWTON-01",
  dry_mass_kg = 720.0,
  propellant_kg = 730.0,
  solar_array_area_m2 = 18.5,
  mission_phase = "HELIOCENTRIC_CRUISE",
  epoch = "2026-09-28 16:00:00 UTC",
  orbital_elements = NULL
) {
  total_mass <- dry_mass_kg + propellant_kg
  structure(
    list(
      name = name,
      dry_mass_kg = dry_mass_kg,
      propellant_kg = propellant_kg,
      total_mass_kg = total_mass,
      solar_array_area_m2 = solar_array_area_m2,
      mission_phase = mission_phase,
      epoch = as.POSIXct(epoch, tz = "UTC"),
      orbital_elements = orbital_elements,
      trajectory_history = list(),
      events = list()
    ),
    class = "newton_spacecraft"
  )
}

MISSION_PHASES <- c(
  "PRE_LAUNCH",
  "LAUNCH_AND_EARLY_ORBIT",
  "TRANS_PLANETARY_INJECTION",
  "HELIOCENTRIC_CRUISE",
  "PLANETARY_ENCOUNTER",
  "GRAVITY_ASSIST_FLYBY",
  "ORBITAL_INSERTION",
  "SCIENCE_OPERATIONS",
  "EXTENDED_MISSION",
  "DECOMMISSIONED"
)
