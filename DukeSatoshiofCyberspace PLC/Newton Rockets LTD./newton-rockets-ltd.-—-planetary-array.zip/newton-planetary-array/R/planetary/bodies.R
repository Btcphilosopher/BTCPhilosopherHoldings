# Newton Rockets Ltd. - Structured Planetary Database

get_planetary_database <- function() {
  list(
    Sun = list(
      name = "Sun",
      mass_kg = 1.98847e30,
      radius_km = 696342.0,
      rotation_period_days = 25.38,
      axial_tilt_deg = 7.25,
      albedo = 0.0,
      atmosphere = TRUE,
      mu = NEWTON_CONSTANTS$MU_SUN,
      color = "#F59E0B"
    ),
    Mercury = list(
      name = "Mercury",
      mass_kg = 3.3011e23,
      radius_km = 2439.7,
      rotation_period_days = 58.646,
      axial_tilt_deg = 0.034,
      albedo = 0.142,
      atmosphere = FALSE,
      mu = NEWTON_CONSTANTS$MU$Mercury,
      soi_radius_km = 112000.0,
      color = "#9CA3AF"
    ),
    Venus = list(
      name = "Venus",
      mass_kg = 4.8675e24,
      radius_km = 6051.8,
      rotation_period_days = -243.02, # Retrograde
      axial_tilt_deg = 177.36,
      albedo = 0.689,
      atmosphere = TRUE,
      mu = NEWTON_CONSTANTS$MU$Venus,
      soi_radius_km = 616000.0,
      color = "#FBBF24"
    ),
    Earth = list(
      name = "Earth",
      mass_kg = 5.9722e24,
      radius_km = 6378.137,
      rotation_period_days = 0.99727,
      axial_tilt_deg = 23.44,
      albedo = 0.367,
      atmosphere = TRUE,
      mu = NEWTON_CONSTANTS$MU$Earth,
      soi_radius_km = 925000.0,
      color = "#38BDF8"
    ),
    Moon = list(
      name = "Moon",
      mass_kg = 7.342e22,
      radius_km = 1737.4,
      rotation_period_days = 27.322,
      axial_tilt_deg = 6.68,
      albedo = 0.12,
      atmosphere = FALSE,
      mu = NEWTON_CONSTANTS$MU$Moon,
      soi_radius_km = 66100.0,
      color = "#E2E8F0"
    ),
    Mars = list(
      name = "Mars",
      mass_kg = 6.4171e23,
      radius_km = 3396.2,
      rotation_period_days = 1.02596,
      axial_tilt_deg = 25.19,
      albedo = 0.150,
      atmosphere = TRUE,
      mu = NEWTON_CONSTANTS$MU$Mars,
      soi_radius_km = 577000.0,
      color = "#FB7185"
    ),
    Jupiter = list(
      name = "Jupiter",
      mass_kg = 1.8982e27,
      radius_km = 71492.0,
      rotation_period_days = 0.4135,
      axial_tilt_deg = 3.13,
      albedo = 0.538,
      atmosphere = TRUE,
      mu = NEWTON_CONSTANTS$MU$Jupiter,
      soi_radius_km = 48200000.0,
      color = "#E0A96D"
    ),
    Saturn = list(
      name = "Saturn",
      mass_kg = 5.6834e26,
      radius_km = 60268.0,
      rotation_period_days = 0.444,
      axial_tilt_deg = 26.73,
      albedo = 0.499,
      atmosphere = TRUE,
      mu = NEWTON_CONSTANTS$MU$Saturn,
      soi_radius_km = 54800000.0,
      color = "#FDE68A"
    ),
    Uranus = list(
      name = "Uranus",
      mass_kg = 8.6810e25,
      radius_km = 25559.0,
      rotation_period_days = -0.7183,
      axial_tilt_deg = 97.77,
      albedo = 0.488,
      atmosphere = TRUE,
      mu = NEWTON_CONSTANTS$MU$Uranus,
      soi_radius_km = 51800000.0,
      color = "#67E8F9"
    ),
    Neptune = list(
      name = "Neptune",
      mass_kg = 1.02413e26,
      radius_km = 24764.0,
      rotation_period_days = 0.6713,
      axial_tilt_deg = 28.32,
      albedo = 0.442,
      atmosphere = TRUE,
      mu = NEWTON_CONSTANTS$MU$Neptune,
      soi_radius_km = 86800000.0,
      color = "#60A5FA"
    )
  )
}
