# Newton Rockets Ltd. - Solar Illumination & Planetary Photometry Engine

compute_solar_flux <- function(r_sun_km) {
  # Solar flux S = S0 * (1 AU / r)^2
  r_au <- km_to_au(r_sun_km)
  NEWTON_CONSTANTS$SOLAR_CONSTANT_1AU_W_M2 / (r_au^2)
}

compute_phase_angle <- function(r_body_sun, r_body_observer) {
  # Angle Sun-Body-Observer
  dot_prod <- sum(r_body_sun * r_body_observer)
  norm_s <- sqrt(sum(r_body_sun^2))
  norm_o <- sqrt(sum(r_body_observer^2))
  
  if (norm_s == 0 || norm_o == 0) return(0.0)
  cos_phi <- pmin(pmax(dot_prod / (norm_s * norm_o), -1.0), 1.0)
  acos(cos_phi)
}

compute_illuminated_fraction <- function(phase_angle_rad) {
  # k = (1 + cos(phi)) / 2
  0.5 * (1.0 + cos(phase_angle_rad))
}
