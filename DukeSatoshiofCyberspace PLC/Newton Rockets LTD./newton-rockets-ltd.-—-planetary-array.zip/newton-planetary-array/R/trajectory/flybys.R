# Newton Rockets Ltd. - Gravity Assist Flyby & Encounter Mechanics
# Analytical formulation per BMW Astrodynamics & Battin

compute_flyby_geometry <- function(v_inf_in, r_periapsis_km, mu_planet, r_planet_km) {
  # Hyperbolic excess velocity magnitude
  v_inf_mag <- sqrt(sum(v_inf_in^2))
  
  # Semi-major axis of hyperbola a = -mu / v_inf^2
  a_hyp <- -mu_planet / (v_inf_mag^2)
  
  # Eccentricity e = 1 + r_p * v_inf^2 / mu = 1 - r_p / a_hyp
  e_hyp <- 1.0 + (r_periapsis_km * v_inf_mag^2) / mu_planet
  
  # Deflection / turning angle delta = 2 * asin(1 / e_hyp)
  delta_turn_rad <- 2.0 * asin(1.0 / e_hyp)
  
  # Max theoretical delta V imparted to spacecraft in planet-centric frame
  delta_v_mag <- 2.0 * v_inf_mag * sin(delta_turn_rad / 2.0)
  
  # Periapsis altitude
  alt_periapsis_km <- r_periapsis_km - r_planet_km
  
  # Asymptote impact parameter b = a_hyp * sqrt(e_hyp^2 - 1)
  b_parameter_km <- abs(a_hyp) * sqrt(e_hyp^2 - 1.0)
  
  list(
    v_inf_km_s = v_inf_mag,
    r_periapsis_km = r_periapsis_km,
    alt_periapsis_km = alt_periapsis_km,
    eccentricity = e_hyp,
    turning_angle_rad = delta_turn_rad,
    turning_angle_deg = rad_to_deg(delta_turn_rad),
    delta_v_flyby_km_s = delta_v_mag,
    b_parameter_km = b_parameter_km
  )
}

compute_relative_motion <- function(state_a, state_b) {
  # Relative position vector delta_r = r_b - r_a
  delta_r <- state_b$r - state_a$r
  range_km <- sqrt(sum(delta_r^2))
  
  # Relative velocity vector delta_v = v_b - v_a
  delta_v <- state_b$v - state_a$v
  rel_speed_km_s <- sqrt(sum(delta_v^2))
  
  # Range rate (closing velocity): dr/dt = (delta_r . delta_v) / range
  if (range_km > 0) {
    range_rate_km_s <- sum(delta_r * delta_v) / range_km
  } else {
    range_rate_km_s <- 0.0
  }
  
  # One-way light time tau = d / c
  light_time_seconds <- range_km / NEWTON_CONSTANTS$SPEED_OF_LIGHT_KM_S
  
  list(
    delta_r_km = delta_r,
    range_km = range_km,
    range_au = km_to_au(range_km),
    delta_v_km_s = delta_v,
    rel_speed_km_s = rel_speed_km_s,
    closing_velocity_km_s = -range_rate_km_s, # Positive when approaching
    light_time_seconds = light_time_seconds
  )
}
