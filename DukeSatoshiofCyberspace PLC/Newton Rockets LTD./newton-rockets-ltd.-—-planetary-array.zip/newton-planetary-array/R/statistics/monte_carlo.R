# Newton Rockets Ltd. - Monte Carlo Uncertainty & Dispersion Engine

generate_monte_carlo_trajectories <- function(
  nominal_elements,
  num_samples = 100,
  sigma_pos_km = 150.0,
  sigma_vel_m_s = 0.5,
  duration_days = 90.0,
  dt_days = 1.0,
  mu = NEWTON_CONSTANTS$MU_SUN
) {
  sigma_vel_km_s <- sigma_vel_m_s / 1000.0
  nominal_state <- elements_to_state_vector(
    a = nominal_elements$a,
    e = nominal_elements$e,
    inc = nominal_elements$inc,
    raan = nominal_elements$raan,
    argp = nominal_elements$argp,
    nu = nominal_elements$nu,
    mu = mu,
    epoch = nominal_elements$epoch
  )
  
  timesteps <- seq(0, duration_days * 86400, by = dt_days * 86400)
  num_steps <- length(timesteps)
  
  # Matrix of trajectories [sample, step, coordinate]
  trajectories <- array(0, dim = c(num_samples, num_steps, 3))
  
  for (s in 1:num_samples) {
    # Gaussian 3-axis perturbation
    delta_r <- rnorm(3, mean = 0, sd = sigma_pos_km)
    delta_v <- rnorm(3, mean = 0, sd = sigma_vel_km_s)
    
    pert_r <- nominal_state$r + delta_r
    pert_v <- nominal_state$v + delta_v
    
    pert_elems <- state_vector_to_elements(pert_r, pert_v, epoch = nominal_elements$epoch, mu = mu)
    
    for (t_idx in 1:num_steps) {
      dt <- timesteps[t_idx]
      prop_elems <- propagate_keplerian(pert_elems, dt, mu = mu)
      st <- elements_to_state_vector(
        a = prop_elems$a, e = prop_elems$e, inc = prop_elems$inc,
        raan = prop_elems$raan, argp = prop_elems$argp, nu = prop_elems$nu,
        mu = mu, epoch = prop_elems$epoch
      )
      trajectories[s, t_idx, ] <- st$r
    }
  }
  
  # Calculate 1-sigma, 2-sigma, 3-sigma envelopes per timestep
  mean_pos <- apply(trajectories, c(2, 3), mean)
  sd_pos   <- apply(trajectories, c(2, 3), sd)
  
  list(
    num_samples = num_samples,
    timesteps_days = timesteps / 86400,
    nominal_path = mean_pos,
    dispersion_1sigma = sd_pos,
    dispersion_3sigma = 3.0 * sd_pos
  )
}
