# Newton Rockets Ltd. - Configuration Loader & Scenario Parsing

load_mission_scenario <- function(file_path) {
  if (!file.exists(file_path)) {
    stop(paste("Scenario file not found:", file_path))
  }
  cfg <- yaml::read_yaml(file_path)
  
  # Validate required keys
  req_keys <- c("id", "name", "epoch", "spacecraft")
  missing <- setdiff(req_keys, names(cfg))
  if (length(missing) > 0) {
    stop(paste("Invalid scenario configuration. Missing keys:", paste(missing, collapse = ", ")))
  }
  
  cfg
}

get_default_scenario <- function() {
  list(
    id = "NEWTON-01-SOLAR",
    name = "NEWTON-01 Solar Science Mission",
    subtitle = "Inner Solar System Perihelion Insertion & Heliospheric Baseline",
    epoch = list(
      start = "2026-09-28 16:00:00 UTC",
      current = "2026-11-10 16:00:00 UTC",
      end = "2027-09-28 16:00:00 UTC"
    ),
    reference_frame = "Heliocentric Ecliptic J2000",
    spacecraft = list(
      name = "NEWTON-01",
      mass_kg = 1450.0,
      dry_mass_kg = 720.0,
      propellant_kg = 730.0,
      solar_array_area_m2 = 18.5,
      mission_phase = "HELIOCENTRIC_CRUISE",
      initial_elements = list(
        a_au = 0.824,
        e = 0.382,
        inc_deg = 3.45,
        raan_deg = 76.2,
        argp_deg = 124.8,
        nu_deg = 45.0
      )
    )
  )
}
