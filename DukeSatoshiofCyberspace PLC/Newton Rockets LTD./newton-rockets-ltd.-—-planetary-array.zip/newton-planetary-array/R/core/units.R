# Newton Rockets Ltd. - Unit Conversion Library
# Enforces strict unit conversion rules; no silent unit assumptions

au_to_km <- function(au) {
  au * NEWTON_CONSTANTS$AU_KM
}

km_to_au <- function(km) {
  km / NEWTON_CONSTANTS$AU_KM
}

deg_to_rad <- function(deg) {
  deg * pi / 180.0
}

rad_to_deg <- function(rad) {
  rad * 180.0 / pi
}

# Wrap angle into [0, 2*pi)
wrap_2pi <- function(angle_rad) {
  (angle_rad %% (2 * pi) + 2 * pi) %% (2 * pi)
}

# Wrap angle into [-pi, pi)
wrap_pi <- function(angle_rad) {
  wrapped <- wrap_2pi(angle_rad)
  ifelse(wrapped > pi, wrapped - 2 * pi, wrapped)
}

# Convert POSIXct to Julian Date (UTC)
posix_to_jd <- function(time_posix) {
  if (is.character(time_posix)) {
    time_posix <- as.POSIXct(time_posix, tz = "UTC")
  }
  unix_secs <- as.numeric(time_posix)
  # Unix epoch 1970-01-01 00:00:00 UTC = JD 2440587.5
  2440587.5 + (unix_secs / 86400.0)
}

# Convert Julian Date to POSIXct (UTC)
jd_to_posix <- function(jd) {
  unix_secs <- (jd - 2440587.5) * 86400.0
  as.POSIXct(unix_secs, origin = "1970-01-01", tz = "UTC")
}

# Julian Centuries since J2000.0
jd_to_centuries_j2000 <- function(jd) {
  (jd - NEWTON_CONSTANTS$JD_J2000) / 36525.0
}

# Days since J2000.0
jd_to_days_j2000 <- function(jd) {
  jd - NEWTON_CONSTANTS$JD_J2000
}
