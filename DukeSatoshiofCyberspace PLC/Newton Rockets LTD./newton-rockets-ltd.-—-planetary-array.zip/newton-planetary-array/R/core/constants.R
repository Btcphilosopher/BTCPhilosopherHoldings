# Newton Rockets Ltd. - Core Astronomical and Physical Constants
# Reference: IAU 2015 Resolution B3, CODATA 2018, JPL Planetary Physical Parameters

NEWTON_CONSTANTS <- list(
  # Universal Gravitational Constant [m^3 kg^-1 s^-2] and [km^3 kg^-1 s^-2]
  G_SI = 6.67430e-11,
  G_KM = 6.67430e-20,

  # Speed of Light in Vacuum [km s^-1]
  SPEED_OF_LIGHT_KM_S = 299792.458,

  # Astronomical Unit [km] (IAU 2012 exact definition)
  AU_KM = 149597870.7,

  # Solar Gravitational Parameter GM_sun [km^3 s^-2]
  MU_SUN = 1.32712440018e11,

  # Solar Radius [km]
  RADIUS_SUN_KM = 696342.0,

  # Solar Luminosity [W] and Solar Constant at 1 AU [W m^-2]
  SOLAR_LUMINOSITY_W = 3.828e26,
  SOLAR_CONSTANT_1AU_W_M2 = 1361.0,

  # Standard Epoch J2000.0 (2000-01-01 12:00:00 TT)
  JD_J2000 = 2451545.0,
  MJD_J2000 = 51544.5,

  # Planetary Gravitational Parameters GM [km^3 s^-2]
  MU = list(
    Sun     = 1.32712440018e11,
    Mercury = 22031.86,
    Venus   = 324858.592,
    Earth   = 398600.4418,
    Moon    = 4902.800066,
    Mars    = 42828.375214,
    Jupiter = 126686534.9,
    Saturn  = 37931207.7,
    Uranus  = 5793939.3,
    Neptune = 6836527.1
  ),

  # Planetary Equator Radii [km]
  RADIUS_KM = list(
    Sun     = 696342.0,
    Mercury = 2439.7,
    Venus   = 6051.8,
    Earth   = 6378.137,
    Moon    = 1737.4,
    Mars    = 3396.2,
    Jupiter = 71492.0,
    Saturn  = 60268.0,
    Uranus  = 25559.0,
    Neptune = 24764.0
  ),

  # Obliquity of the Ecliptic at J2000 [radians]
  EPSILON_J2000_RAD = 23.4392911 * pi / 180.0
)
