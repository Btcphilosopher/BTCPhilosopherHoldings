# Newton Rockets Ltd. - Validation & Physical Invariants Engine

validate_orbital_elements <- function(elements) {
  if (elements$a <= 0 && elements$e < 1.0) {
    stop("Semi-major axis must be strictly positive for bound elliptical orbits.")
  }
  if (elements$e < 0) {
    stop("Eccentricity must be non-negative.")
  }
  if (elements$inc < 0 || elements$inc > pi) {
    stop("Inclination must lie strictly within [0, pi] radians.")
  }
  TRUE
}

check_energy_conservation <- function(state1, state2, mu = NEWTON_CONSTANTS$MU_SUN, tol = 1e-8) {
  # Specific orbital energy epsilon = v^2/2 - mu/r
  r1 <- sqrt(sum(state1$r^2))
  v1 <- sqrt(sum(state1$v^2))
  eps1 <- 0.5 * v1^2 - mu / r1
  
  r2 <- sqrt(sum(state2$r^2))
  v2 <- sqrt(sum(state2$v^2))
  eps2 <- 0.5 * v2^2 - mu / r2
  
  delta_eps <- abs((eps2 - eps1) / eps1)
  if (delta_eps > tol) {
    warning(sprintf("Energy conservation warning: relative drift = %.2e exceeds tolerance %.2e", delta_eps, tol))
    return(FALSE)
  }
  TRUE
}
