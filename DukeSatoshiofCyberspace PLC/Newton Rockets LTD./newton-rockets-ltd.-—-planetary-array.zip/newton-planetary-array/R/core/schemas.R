# Newton Rockets Ltd. - Data Schemas & State Vector Definitions

new_state_vector <- function(x, y, z, vx, vy, vz, epoch, frame = "Heliocentric Ecliptic J2000", body = "Spacecraft") {
  structure(
    list(
      r = c(x = as.numeric(x), y = as.numeric(y), z = as.numeric(z)),
      v = c(vx = as.numeric(vx), vy = as.numeric(vy), vz = as.numeric(vz)),
      epoch = epoch,
      frame = frame,
      body = body
    ),
    class = "newton_state_vector"
  )
}

new_orbital_elements <- function(a, e, inc, raan, argp, nu, epoch, mu = NEWTON_CONSTANTS$MU_SUN, frame = "Heliocentric Ecliptic J2000") {
  # a: Semi-major axis [km]
  # e: Eccentricity [dimensionless]
  # inc: Inclination [rad]
  # raan: Longitude of Ascending Node [rad]
  # argp: Argument of Periapsis [rad]
  # nu: True Anomaly [rad]
  structure(
    list(
      a = as.numeric(a),
      e = as.numeric(e),
      inc = as.numeric(inc),
      raan = as.numeric(raan),
      argp = as.numeric(argp),
      nu = as.numeric(nu),
      epoch = epoch,
      mu = as.numeric(mu),
      frame = frame
    ),
    class = "newton_orbital_elements"
  )
}
