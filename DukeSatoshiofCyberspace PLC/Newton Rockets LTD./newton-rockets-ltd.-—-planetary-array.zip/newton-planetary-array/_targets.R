# _targets.R - Newton Rockets Ltd. Targets Pipeline
# Manages reproducible ephemeris caching, trajectory propagation, conjunction sweeps, and reporting

library(targets)
library(tarchetypes)

tar_option_set(
  packages = c(
    "data.table", "dplyr", "tidyr", "purrr", "readr",
    "yaml", "jsonlite", "lubridate"
  ),
  format = "rds"
)

# Source all Newton modules
tar_source("R")

list(
  tar_target(
    config_file,
    "examples/solar_probe.yaml",
    format = "file"
  ),
  tar_target(
    scenario_config,
    load_mission_scenario(config_file)
  ),
  tar_target(
    planetary_catalog,
    get_planetary_database()
  ),
  tar_target(
    ephemeris_states,
    compute_planetary_ephemeris(
      bodies = c("Mercury", "Venus", "Earth", "Mars", "Jupiter", "Saturn", "Uranus", "Neptune"),
      start_epoch = scenario_config$epoch$start,
      end_epoch = scenario_config$epoch$end,
      step_days = 1.0
    )
  ),
  tar_target(
    spacecraft_trajectory,
    propagate_spacecraft_trajectory(
      spacecraft = scenario_config$spacecraft,
      start_epoch = scenario_config$epoch$start,
      end_epoch = scenario_config$epoch$end,
      dt_seconds = 3600
    )
  ),
  tar_target(
    detected_encounters,
    detect_planetary_encounters(
      trajectory = spacecraft_trajectory,
      planets = planetary_catalog,
      threshold_km = 5e6
    )
  ),
  tar_target(
    conjunction_events,
    scan_planetary_conjunctions(
      ephemeris = ephemeris_states,
      bodies = c("Earth", "Venus", "Mars"),
      max_angle_deg = 2.0
    )
  ),
  tar_target(
    provenance_record,
    generate_provenance_record(
      scenario_id = scenario_config$id,
      model = "VSOP87 + Perturbed Cowell RK4",
      frame = "Heliocentric Ecliptic J2000"
    )
  )
)
