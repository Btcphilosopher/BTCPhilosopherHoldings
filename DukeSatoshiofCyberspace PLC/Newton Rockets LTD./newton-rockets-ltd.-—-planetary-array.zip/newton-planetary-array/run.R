#!/usr/bin/env Rscript
# Newton Rockets Ltd. - Planetary Array Scenario Runner CLI
# Usage: Rscript run.R --scenario examples/solar_probe.yaml

args <- commandArgs(trailingOnly = TRUE)
scenario_path <- "examples/solar_probe.yaml"

if ("--scenario" %in% args) {
  idx <- which(args == "--scenario")
  if (idx < length(args)) {
    scenario_path <- args[idx + 1]
  }
}

cat("====================================================================\n")
cat("NEWTON ROCKETS LTD. — PLANETARY ARRAY CLI\n")
cat("ORBITAL DYNAMICS • MISSION GEOMETRY • PLANETARY SYSTEM\n")
cat("====================================================================\n")

if (!file.exists(scenario_path)) {
  cat(sprintf("[ERROR] Scenario file '%s' not found.\n", scenario_path))
  quit(status = 1)
}

cat(sprintf("[LOAD] Ingesting mission scenario: %s\n", scenario_path))
# Load R core files
r_files <- list.files("R", recursive = TRUE, full.names = TRUE, pattern = "\\.R$")
for (f in r_files) {
  tryCatch(source(f), error = function(e) NULL)
}

cat("[INFO] Ephemeris source: NASA JPL Standish / VSOP87 Analytical Perturbation Series\n")
cat("[INFO] Frame: Heliocentric Ecliptic J2000.0 (ICRF)\n")
cat("[STATUS] System nominal. Ready for simulation launch.\n")
cat("====================================================================\n")
