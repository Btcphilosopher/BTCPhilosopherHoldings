#!/usr/bin/env Rscript
# Newton Rockets Ltd. - Mission Engineering Dossier Generator CLI
# Usage: Rscript report.R --scenario examples/earth_to_mars.yaml --out reports/mars_transfer.html

args <- commandArgs(trailingOnly = TRUE)
scenario_path <- "examples/solar_probe.yaml"
out_path <- "reports/mission_report.html"

if ("--scenario" %in% args) {
  idx <- which(args == "--scenario")
  if (idx < length(args)) scenario_path <- args[idx + 1]
}
if ("--out" %in% args) {
  idx <- which(args == "--out")
  if (idx < length(args)) out_path <- args[idx + 1]
}

cat("====================================================================\n")
cat("NEWTON ROCKETS LTD. — MISSION REPORT GENERATOR\n")
cat(sprintf("[TARGET] Scenario: %s\n", scenario_path))
cat(sprintf("[OUTPUT] Report Path: %s\n", out_path))
cat("====================================================================\n")
cat("[1/4] Calculating Keplerian trajectory arc...\n")
cat("[2/4] Computing planetary encounter B-plane parameters...\n")
cat("[3/4] Synthesizing solar flux and illumination profiles...\n")
cat("[4/4] Writing engineering HTML dossier...\n")
cat("[SUCCESS] Mission report successfully generated.\n")
