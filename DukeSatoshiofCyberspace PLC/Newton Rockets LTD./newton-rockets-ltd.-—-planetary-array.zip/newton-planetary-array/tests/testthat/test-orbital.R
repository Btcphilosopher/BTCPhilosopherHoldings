# Newton Rockets Ltd. - Unit Tests for Astrodynamics & Orbital Mechanics
library(testthat)

test_that("Unit conversions are exact and reversible", {
  # 1 AU to km
  expect_equal(au_to_km(1.0), 149597870.7, tolerance = 1e-6)
  expect_equal(km_to_au(149597870.7), 1.0, tolerance = 1e-9)
  
  # Radians to degrees
  expect_equal(rad_to_deg(pi), 180.0, tolerance = 1e-9)
  expect_equal(deg_to_rad(180.0), pi, tolerance = 1e-9)
})

test_that("Julian Date conversions match astronomical benchmarks", {
  # J2000.0 is 2000-01-01 12:00:00 UTC = JD 2451545.0
  j2000_posix <- as.POSIXct("2000-01-01 12:00:00", tz = "UTC")
  expect_equal(posix_to_jd(j2000_posix), 2451545.0, tolerance = 1e-8)
  expect_equal(format(jd_to_posix(2451545.0), "%Y-%m-%d %H:%M:%S"), "2000-01-01 12:00:00")
})

test_that("Universal Kepler solver achieves machine precision for elliptic orbits", {
  # Test with diverse eccentricities
  for (e in c(0.0, 0.0167, 0.2056, 0.5, 0.8, 0.95)) {
    for (M in c(0.0, pi/6, pi/2, pi, 4*pi/3, 11*pi/6)) {
      E <- solve_kepler_eccentric_anomaly(M, e, tol = 1e-14)
      # Re-evaluate M_calc = E - e*sin(E)
      M_calc <- wrap_2pi(E - e * sin(E))
      M_expected <- wrap_2pi(M)
      diff <- abs(M_calc - M_expected)
      diff <- min(diff, 2*pi - diff)
      expect_lt(diff, 1e-12)
    }
  }
})

test_that("State-vector to orbital-elements conversion is an exact round-trip", {
  mu <- 1.32712440018e11 # Solar GM
  a <- 1.4959787e8       # 1 AU
  e <- 0.05
  inc <- deg_to_rad(15.0)
  raan <- deg_to_rad(45.0)
  argp <- deg_to_rad(30.0)
  nu <- deg_to_rad(60.0)
  
  st <- elements_to_state_vector(a, e, inc, raan, argp, nu, mu = mu)
  elems <- state_vector_to_elements(st$r, st$v, epoch = Sys.time(), mu = mu)
  
  expect_equal(elems$a, a, tolerance = 1e-3)
  expect_equal(elems$e, e, tolerance = 1e-9)
  expect_equal(elems$inc, inc, tolerance = 1e-9)
  expect_equal(elems$raan, raan, tolerance = 1e-9)
  expect_equal(elems$argp, argp, tolerance = 1e-9)
  expect_equal(elems$nu, nu, tolerance = 1e-9)
})

test_that("Specific orbital energy and angular momentum are strictly conserved", {
  mu <- 1.32712440018e11
  elems0 <- new_orbital_elements(
    a = 1.4959787e8, e = 0.2, inc = deg_to_rad(10),
    raan = deg_to_rad(40), argp = deg_to_rad(20), nu = 0.1,
    epoch = as.POSIXct("2026-09-28 16:00:00", tz = "UTC"), mu = mu
  )
  
  st0 <- elements_to_state_vector(elems0$a, elems0$e, elems0$inc, elems0$raan, elems0$argp, elems0$nu, mu = mu)
  
  # Propagate 100 days
  elems100 <- propagate_keplerian(elems0, 100 * 86400, mu = mu)
  st100 <- elements_to_state_vector(elems100$a, elems100$e, elems100$inc, elems100$raan, elems100$argp, elems100$nu, mu = mu)
  
  # Energy conservation check
  expect_true(check_energy_conservation(st0, st100, mu = mu, tol = 1e-12))
})

test_that("Flyby turning angle matches theoretical formula", {
  mu_venus <- 324858.592
  r_venus <- 6051.8
  r_p <- r_venus + 300.0 # 300 km altitude
  v_inf <- 6.5 # km/s
  
  geom <- compute_flyby_geometry(c(v_inf, 0, 0), r_p, mu_venus, r_venus)
  
  expected_e <- 1.0 + (r_p * v_inf^2) / mu_venus
  expected_delta <- 2.0 * asin(1.0 / expected_e)
  
  expect_equal(geom$eccentricity, expected_e, tolerance = 1e-9)
  expect_equal(geom$turning_angle_rad, expected_delta, tolerance = 1e-9)
  expect_gt(geom$delta_v_flyby_km_s, 0.0)
})

test_that("Relative closing velocity is positive when closing range", {
  st_a <- list(r = c(0, 0, 0), v = c(0, 0, 0))
  st_b <- list(r = c(1000, 0, 0), v = c(-5, 0, 0)) # Moving towards A at 5 km/s
  
  rel <- compute_relative_motion(st_a, st_b)
  expect_equal(rel$range_km, 1000.0)
  expect_equal(rel$closing_velocity_km_s, 5.0)
})
