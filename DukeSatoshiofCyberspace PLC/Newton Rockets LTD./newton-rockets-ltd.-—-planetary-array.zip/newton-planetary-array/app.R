# Newton Rockets Ltd. - Planetary Array Standalone Shiny Application
# Interactive Orbital Display, Mission Geometry, and Planetary System Visualisation

library(shiny)
library(bslib)
library(plotly)
library(DT)
library(yaml)

# Source core astrodynamic modules
r_files <- list.files("R", recursive = TRUE, full.names = TRUE, pattern = "\\.R$")
for (f in r_files) {
  tryCatch(source(f), error = function(e) NULL)
}

ui <- page_navbar(
  title = "NEWTON ROCKETS LTD. — PLANETARY ARRAY",
  theme = bs_theme(
    version = 5,
    bg = "#0B0E14",
    fg = "#E2E8F0",
    primary = "#38BDF8",
    secondary = "#64748B",
    base_font = font_google("Inter"),
    code_font = font_google("JetBrains Mono")
  ),
  nav_panel(
    title = "ORBITAL ARRAY",
    layout_sidebar(
      sidebar = sidebar(
        title = "MISSION CONTROL",
        width = 340,
        selectInput(
          "scenario_select", "MISSION SCENARIO",
          choices = c(
            "NEWTON-01 Solar Science Mission" = "solar_probe.yaml",
            "Earth to Mars Transfer" = "earth_to_mars.yaml",
            "Earth to Venus Cruise" = "earth_to_venus.yaml",
            "Mercury Polar Orbiter" = "mercury_probe.yaml"
          )
        ),
        selectInput(
          "display_mode", "DISPLAY MODE",
          choices = c(
            "SOLAR SYSTEM" = "SOLAR_SYSTEM",
            "INNER SYSTEM" = "INNER_SYSTEM",
            "HELIOCENTRIC" = "HELIOCENTRIC",
            "EARTH-CENTRIC" = "EARTH_CENTRIC",
            "MISSION VIEW" = "MISSION_VIEW",
            "SPACECRAFT VIEW" = "SPACECRAFT_VIEW",
            "POLAR VIEW" = "POLAR_VIEW"
          )
        ),
        selectInput(
          "reference_frame", "REFERENCE FRAME",
          choices = c(
            "HELIOCENTRIC ECLIPTIC (J2000)" = "HELIOCENTRIC_ECLIPTIC",
            "GEOCENTRIC EQUATORIAL (ECI)" = "GEOCENTRIC_ECI",
            "LOCAL VERTICAL LOCAL HORIZONTAL (LVLH)" = "LVLH",
            "SPACECRAFT BODY" = "SPACECRAFT_BODY"
          )
        ),
        sliderInput("time_warp", "SIMULATION TIME WARP", min = -1000, max = 1000, value = 1, step = 10),
        actionButton("btn_pause", "PAUSE / RESUME", class = "btn-outline-primary w-100 mb-2"),
        checkboxGroupInput(
          "layers", "ACTIVE LAYERS",
          choices = c(
            "Orbit Tracks" = "orbits",
            "Spacecraft Trajectory" = "trajectory",
            "Velocity Vectors" = "velocity",
            "Day/Night Terminators" = "terminators",
            "Sphere of Influence" = "soi",
            "Coordinate Grid" = "grid"
          ),
          selected = c("orbits", "trajectory", "terminators", "grid")
        ),
        hr(),
        div(
          class = "text-muted small",
          p("EPHEMERIS: NASA JPL DE405 / VSOP87"),
          p("SOLVER: Householder Kepler 5th Order"),
          p("TOLERANCE: 1.0e-14")
        )
      ),
      card(
        card_header(
          class = "d-flex justify-content-between align-items-center",
          span("HELIOCENTRIC ORBITAL FIELD"),
          span(class = "badge bg-primary", "LIVE ORBITAL ENGINE")
        ),
        plotlyOutput("orbital_canvas", height = "650px")
      )
    )
  ),
  nav_panel(
    title = "OBJECT INSPECTOR",
    card(
      card_header("ORBITAL ELEMENTS & STATE VECTORS"),
      DTOutput("inspector_table")
    )
  ),
  nav_panel(
    title = "PLANETARY ARRAY GRID",
    card(
      card_header("REAL-TIME PLANETARY STATES (HELIOCENTRIC J2000)"),
      DTOutput("planetary_grid")
    )
  ),
  nav_panel(
    title = "DATA PROVENANCE",
    card(
      card_header("SCIENTIFIC AUDIT & REPRODUCIBILITY RECORD"),
      verbatimTextOutput("provenance_output")
    )
  )
)

server <- function(input, output, session) {
  # Reactive simulation clock
  current_epoch <- reactiveVal(as.POSIXct("2026-09-28 16:00:00", tz = "UTC"))
  
  output$orbital_canvas <- renderPlotly({
    p <- plot_ly(type = 'scatter3d', mode = 'markers+lines') %>%
      layout(
        scene = list(
          xaxis = list(title = "X [AU]", color = "#94A3B8", gridcolor = "#1E293B"),
          yaxis = list(title = "Y [AU]", color = "#94A3B8", gridcolor = "#1E293B"),
          zaxis = list(title = "Z [AU]", color = "#94A3B8", gridcolor = "#1E293B"),
          bgcolor = "#07090E"
        ),
        paper_bgcolor = "#0B0E14"
      )
    p
  })
  
  output$provenance_output <- renderPrint({
    generate_provenance_record()
  })
}

shinyApp(ui, server)
