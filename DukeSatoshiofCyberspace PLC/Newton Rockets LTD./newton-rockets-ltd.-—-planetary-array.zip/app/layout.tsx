import type {Metadata} from 'next';
import './globals.css'; // Global styles

export const metadata: Metadata = {
  title: 'Newton Rockets Ltd. — Planetary Array',
  description: 'Orbital dynamics, mission geometry, and planetary system visualisation platform for aerospace mission planning.',
  openGraph: {
    title: 'Newton Rockets Ltd. — Planetary Array',
    description: 'Orbital dynamics, mission geometry, and planetary system visualisation platform for aerospace mission planning.',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Newton Rockets Ltd. — Planetary Array',
    description: 'Orbital dynamics, mission geometry, and planetary system visualisation platform for aerospace mission planning.',
  },
};

export default function RootLayout({children}: {children: React.ReactNode}) {
  return (
    <html lang="en">
      <body suppressHydrationWarning>{children}</body>
    </html>
  );
}
