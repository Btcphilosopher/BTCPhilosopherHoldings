'use client';

import React, { useState, useEffect, useRef, useCallback } from 'react';
import { TopBar } from '@/components/top-bar';
import { OrbitalCanvas } from '@/components/orbital-canvas';
import { ObjectInspector } from '@/components/object-inspector';
import { TimeEngineControls } from '@/components/time-engine-controls';
import { PlanetaryGrid } from '@/components/planetary-grid';
import { MissionTimeline } from '@/components/mission-timeline';
import { FlybyAnalyzer } from '@/components/flyby-analyzer';
import { RelativeMotion } from '@/components/relative-motion';
import { MonteCarlo } from '@/components/monte-carlo';
import { ProvenancePanel } from '@/components/provenance-panel';
import { RPlatformExplorer } from '@/components/r-platform-explorer';
import { ReportModal } from '@/components/report-modal';
import { 
  OrbitalElements, 
  StateVector, 
  elementsToStateVector, 
  propagateKeplerian, 
  MissionMilestone,
  CONSTANTS,
  degToRad,
  auToKm
} from '@/lib/orbital-mechanics';

// Default initial spacecraft elements: NEWTON-01 Solar Science Mission
const INITIAL_SPACECRAFT_ELEMENTS: OrbitalElements = {
  a: 0.824,
  a_km: auToKm(0.824),
  e: 0.382,
  inc: degToRad(3.45),
  inc_deg: 3.45,
  raan: degToRad(76.2),
  raan_deg: 76.2,
  argp: degToRad(124.8),
  argp_deg: 124.8,
  nu: degToRad(45.0),
  nu_deg: 45.0,
  M: degToRad(32.0),
  M_deg: 32.0,
  period_days: 273.2,
  energy: -CONSTANTS.MU_SUN / (2 * auToKm(0.824)),
  angular_momentum: Math.sqrt(CONSTANTS.MU_SUN * auToKm(0.824) * (1 - 0.382 * 0.382))
};

const DEFAULT_MILESTONES: MissionMilestone[] = [
  {
    id: 'EVT-01',
    epoch: '2026-09-28 16:00:00',
    name: 'Trans-Planetary Injection (TPI)',
    type: 'BURN',
    delta_v_m_s: 3620.0,
    status: 'COMPLETED',
    description: 'Centaur-derived upper stage injection burn towards Venus resonance transfer orbit.'
  },
  {
    id: 'EVT-02',
    epoch: '2026-10-18 10:00:00',
    name: 'Trajectory Correction Maneuver 1 (TCM-1)',
    type: 'BURN',
    delta_v_m_s: 24.5,
    status: 'COMPLETED',
    description: 'B-plane aimpoint calibration for Venus gravity-assist target vector.'
  },
  {
    id: 'EVT-03',
    epoch: '2026-12-04 03:22:15',
    name: 'Venus Gravity Assist 1 (EGA-1)',
    type: 'FLYBY',
    body: 'Venus',
    delta_v_m_s: 0.0,
    status: 'SCHEDULED',
    description: 'Hyperbolic flyby to reduce perihelion distance to 0.285 AU for coronal science passes.'
  },
  {
    id: 'EVT-04',
    epoch: '2027-01-15 14:00:00',
    name: 'Trajectory Correction Maneuver 2 (TCM-2)',
    type: 'BURN',
    delta_v_m_s: 12.0,
    status: 'PLANNED',
    description: 'Post-flyby orbit trim and attitude stabilization maneuver.'
  },
  {
    id: 'EVT-05',
    epoch: '2027-03-29 08:45:00',
    name: 'Solar Perihelion Science Pass 1 (P1)',
    type: 'SCIENCE',
    delta_v_m_s: 0.0,
    status: 'PLANNED',
    description: 'First perihelion pass at 0.285 AU. Solar array tilt compensation for 16.7 kW/m² flux.'
  }
];

export default function PlanetaryArrayApp() {
  const [activeTab, setActiveTab] = useState<string>('array');
  const [isArrayMode, setIsArrayMode] = useState<boolean>(false);
  const [isNightMode, setIsNightMode] = useState<boolean>(false);
  const [isReportOpen, setIsReportOpen] = useState<boolean>(false);

  // Simulation Clock state (Starts at mission epoch: 2026-09-28 16:00:00 UTC)
  const [currentDate, setCurrentDate] = useState<Date>(new Date('2026-09-28T16:00:00Z'));
  const [isPlaying, setIsPlaying] = useState<boolean>(true);
  const [timeWarp, setTimeWarp] = useState<number>(10); // 10x by default for visible planetary dynamics

  // Selected Object
  const [selectedObjectName, setSelectedObjectName] = useState<string>('NEWTON-01');

  // Display Mode & Scale
  const [displayMode, setDisplayMode] = useState<string>('INNER_SYSTEM');
  const [scaleMode, setScaleMode] = useState<'TRUE' | 'ENHANCED'>('ENHANCED');
  const activeFrame = 'Heliocentric Ecliptic J2000';

  // Canvas Layers
  const [layers, setLayers] = useState({
    orbits: true,
    trajectory: true,
    velocity: true,
    labels: true,
    terminators: true,
    soi: true,
    grid: true,
  });

  // Spacecraft state
  const [spacecraftElements, setSpacecraftElements] = useState<OrbitalElements>(INITIAL_SPACECRAFT_ELEMENTS);
  const [selectedMilestoneId, setSelectedMilestoneId] = useState<string | null>('EVT-03');

  // Animation Loop: Advance Simulation Clock based on Time Warp
  useEffect(() => {
    let lastTick = performance.now();
    let animId: number;

    const tick = (now: number) => {
      const dtRealSeconds = (now - lastTick) / 1000.0;
      lastTick = now;

      if (isPlaying && dtRealSeconds > 0 && dtRealSeconds < 1.0) {
        // Compute delta simulation seconds
        // At warp 1x: 1 real second = 1 sim hour (astronomical scale)
        // At warp 10x: 1 real sec = 10 sim hours
        const deltaSimSeconds = dtRealSeconds * timeWarp * 3600;

        setCurrentDate(prev => {
          const nextTime = new Date(prev.getTime() + deltaSimSeconds * 1000);
          return nextTime;
        });

        // Propagate Spacecraft Keplerian elements
        setSpacecraftElements(prev => propagateKeplerian(prev, deltaSimSeconds));
      }

      animId = requestAnimationFrame(tick);
    };

    animId = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(animId);
  }, [isPlaying, timeWarp]);

  // Manual Step
  const handleStepTime = (deltaSeconds: number) => {
    setCurrentDate(prev => new Date(prev.getTime() + deltaSeconds * 1000));
    setSpacecraftElements(prev => propagateKeplerian(prev, deltaSeconds));
  };

  const handleResetTime = () => {
    setCurrentDate(new Date('2026-09-28T16:00:00Z'));
    setSpacecraftElements(INITIAL_SPACECRAFT_ELEMENTS);
  };

  const handleJumpToEpoch = (epochStr: string) => {
    const d = new Date(epochStr.replace(' ', 'T') + 'Z');
    if (!isNaN(d.getTime())) {
      const diffSec = (d.getTime() - currentDate.getTime()) / 1000;
      setCurrentDate(d);
      setSpacecraftElements(prev => propagateKeplerian(prev, diffSec));
    }
  };

  // Clock Formatting
  const utcTimeStr = currentDate.toISOString().replace('T', ' ').slice(0, 19) + ' UTC';
  const missionStart = new Date('2026-09-28T16:00:00Z').getTime();
  const elapsedDays = Math.floor((currentDate.getTime() - missionStart) / 86400000);
  const missionDayStr = elapsedDays >= 0 
    ? `MISSION DAY ${String(elapsedDays).padStart(3, '0')} (T + ${String(elapsedDays).padStart(3, '0')}D)`
    : `T - ${String(Math.abs(elapsedDays)).padStart(3, '0')}D`;

  // Current Spacecraft Position for relative computations
  const scState = elementsToStateVector(spacecraftElements, currentDate);

  return (
    <div className={`flex flex-col h-screen w-screen overflow-hidden ${isNightMode ? 'bg-[#040609] text-slate-200' : 'bg-[#07090E] text-slate-100'}`}>
      {/* Top Bar Header Contract */}
      <TopBar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        utcTimeStr={utcTimeStr}
        missionDayStr={missionDayStr}
        isArrayMode={isArrayMode}
        setIsArrayMode={setIsArrayMode}
        isNightMode={isNightMode}
        setIsNightMode={setIsNightMode}
        onOpenReport={() => setIsReportOpen(true)}
        activeFrame={activeFrame}
        scaleMode={scaleMode}
        setScaleMode={setScaleMode}
      />

      {/* Main View Area */}
      <main className="flex-1 flex flex-col min-h-0 relative">
        {/* Tab 1: Orbital Array (Primary Visual Operating Surface) */}
        {activeTab === 'array' && (
          <div className="flex-1 flex flex-col min-h-0">
            {/* Center Split: Canvas + Object Inspector */}
            <div className="flex-1 flex min-h-0">
              {/* Large Orbital Canvas Field */}
              <div className="flex-1 h-full min-h-0 relative">
                <OrbitalCanvas
                  currentDate={currentDate}
                  selectedObjectName={selectedObjectName}
                  onSelectObject={setSelectedObjectName}
                  displayMode={displayMode}
                  setDisplayMode={setDisplayMode}
                  scaleMode={scaleMode}
                  layers={layers}
                  setLayers={setLayers}
                  isArrayMode={isArrayMode}
                  isNightMode={isNightMode}
                  activeFrame={activeFrame}
                  spacecraftElements={spacecraftElements}
                />
              </div>

              {/* Right Side: Object Inspector Panel (Hidden in Large-Format Array Mode) */}
              {!isArrayMode && (
                <div className="w-80 md:w-96 h-full shrink-0 flex flex-col">
                  <ObjectInspector
                    selectedObjectName={selectedObjectName}
                    onSelectObject={setSelectedObjectName}
                    currentDate={currentDate}
                    spacecraftElements={spacecraftElements}
                  />
                </div>
              )}
            </div>

            {/* Bottom Section: Time Engine Controls + Horizontal Mission Timeline */}
            {!isArrayMode && (
              <div className="shrink-0 flex flex-col border-t border-slate-800 bg-[#090C14] p-2 gap-2">
                <TimeEngineControls
                  isPlaying={isPlaying}
                  setIsPlaying={setIsPlaying}
                  timeWarp={timeWarp}
                  setTimeWarp={setTimeWarp}
                  onStepTime={handleStepTime}
                  onResetTime={handleResetTime}
                  currentDate={currentDate}
                  onSetDate={(d) => {
                    const diffSec = (d.getTime() - currentDate.getTime()) / 1000;
                    setCurrentDate(d);
                    setSpacecraftElements(prev => propagateKeplerian(prev, diffSec));
                  }}
                  isCompact={true}
                />

                {/* Compact Mission Timeline Strip */}
                <div className="flex items-center gap-2 overflow-x-auto pb-1 text-[11px] font-mono">
                  <span className="text-[10px] text-slate-500 uppercase font-semibold shrink-0 pl-1">
                    TIMELINE:
                  </span>
                  {DEFAULT_MILESTONES.map(m => {
                    const mTime = new Date(m.epoch).getTime();
                    const isPast = currentDate.getTime() >= mTime;
                    return (
                      <button
                        key={m.id}
                        onClick={() => handleJumpToEpoch(m.epoch)}
                        className={`flex items-center gap-1.5 px-2.5 py-1 rounded border transition-colors shrink-0 cursor-pointer ${
                          isPast
                            ? 'bg-slate-900 border-slate-700 text-slate-300 hover:border-slate-500'
                            : 'bg-slate-950 border-slate-800 text-slate-400 hover:border-sky-500 hover:text-slate-200'
                        }`}
                      >
                        <span className={`w-1.5 h-1.5 rounded-full ${isPast ? 'bg-emerald-400' : 'bg-amber-400'}`}></span>
                        <span className="font-semibold text-slate-200">{m.id}</span>
                        <span className="text-slate-400">·</span>
                        <span className="text-sky-300">{m.name}</span>
                        <span className="text-[10px] text-slate-500 tabular-nums">({m.epoch.slice(0, 10)})</span>
                      </button>
                    );
                  })}
                </div>
              </div>
            )}
          </div>
        )}

        {/* Tab 2: Planetary Grid Information Matrix */}
        {activeTab === 'grid' && (
          <PlanetaryGrid
            currentDate={currentDate}
            selectedObjectName={selectedObjectName}
            onSelectObject={(name) => {
              setSelectedObjectName(name);
              setActiveTab('array');
            }}
            spacecraftPositionKm={scState.r}
          />
        )}

        {/* Tab 3: Detailed Mission Timeline */}
        {activeTab === 'timeline' && (
          <MissionTimeline
            currentDate={currentDate}
            onJumpToEpoch={handleJumpToEpoch}
            milestones={DEFAULT_MILESTONES}
            selectedMilestoneId={selectedMilestoneId}
            onSelectMilestone={setSelectedMilestoneId}
          />
        )}

        {/* Tab 4: Relative Motion Analyzer */}
        {activeTab === 'relative' && (
          <RelativeMotion
            currentDate={currentDate}
            spacecraftElements={spacecraftElements}
          />
        )}

        {/* Tab 5: Gravity Assist Flyby Geometry */}
        {activeTab === 'flyby' && (
          <FlybyAnalyzer
            currentDate={currentDate}
          />
        )}

        {/* Tab 6: Monte Carlo Trajectory Uncertainty */}
        {activeTab === 'montecarlo' && (
          <MonteCarlo
            nominalElements={spacecraftElements}
            currentDate={currentDate}
          />
        )}

        {/* Tab 7: Scientific Data Provenance */}
        {activeTab === 'provenance' && (
          <ProvenancePanel
            currentDate={currentDate}
            activeFrame={activeFrame}
            scenarioId="NEWTON-01-SOLAR"
          />
        )}

        {/* Tab 8: R Engineering Platform Explorer */}
        {activeTab === 'rplatform' && (
          <RPlatformExplorer
            currentDate={currentDate}
          />
        )}
      </main>

      {/* Engineering Report Export Modal */}
      <ReportModal
        isOpen={isReportOpen}
        onClose={() => setIsReportOpen(false)}
        currentDate={currentDate}
        selectedObjectName={selectedObjectName}
        spacecraftElements={spacecraftElements}
      />
    </div>
  );
}
