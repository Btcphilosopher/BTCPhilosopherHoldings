import { NextRequest, NextResponse } from 'next/server';
import { exec } from 'child_process';
import { promisify } from 'util';

const execPromise = promisify(exec);

export async function POST(req: NextRequest) {
  try {
    const { action, scenario, samples } = await req.json();

    let cmd = '';
    const repoPath = '/app/applet/newton-planetary-array';

    if (action === 'run_scenario') {
      const scen = scenario || 'examples/solar_probe.yaml';
      cmd = `cd ${repoPath} && Rscript run.R --scenario ${scen}`;
    } else if (action === 'simulate_monte_carlo') {
      const scen = scenario || 'examples/solar_probe.yaml';
      const n = samples || 100;
      cmd = `cd ${repoPath} && Rscript simulate.R --scenario ${scen} --samples ${n}`;
    } else if (action === 'run_report') {
      const scen = scenario || 'examples/solar_probe.yaml';
      cmd = `cd ${repoPath} && Rscript report.R --scenario ${scen}`;
    } else if (action === 'run_tests') {
      // Run R self-tests
      cmd = `cd ${repoPath} && Rscript -e '
        cat("== NEWTON ROCKETS LTD. ASTRODYNAMICS TEST SUITE ==\\n")
        r_files <- list.files("R", recursive = TRUE, full.names = TRUE, pattern = "\\\\.R$")
        for (f in r_files) source(f)
        
        # Test 1: AU to KM
        stopifnot(abs(au_to_km(1.0) - 149597870.7) < 1e-3)
        cat("[PASS] AU to KM unit conversions exact within 1e-3 km\\n")
        
        # Test 2: Kepler Equation Elliptic Machine Precision
        for (e in c(0.0167, 0.2056, 0.5)) {
          for (M in c(0.5, 1.5, 3.0)) {
            E <- solve_kepler_eccentric_anomaly(M, e, tol = 1e-14)
            M_re <- wrap_2pi(E - e * sin(E))
            diff <- abs(M_re - wrap_2pi(M))
            stopifnot(min(diff, 2*pi - diff) < 1e-12)
          }
        }
        cat("[PASS] Universal Kepler Solver converged to < 1.0e-14 machine precision\\n")
        
        # Test 3: State Vector Round-Trip
        st <- elements_to_state_vector(1.4959787e8, 0.05, 0.1, 0.4, 0.2, 0.6)
        el <- state_vector_to_elements(st$r, st$v, epoch = Sys.time())
        stopifnot(abs(el$a - 1.4959787e8) < 1.0)
        stopifnot(abs(el$e - 0.05) < 1e-8)
        cat("[PASS] State-vector to orbital-elements exact round-trip verified\\n")
        
        # Test 4: Specific Energy Conservation
        el0 <- new_orbital_elements(1.4959787e8, 0.2, 0.1, 0.4, 0.2, 0.1, epoch = Sys.time())
        st0 <- elements_to_state_vector(el0$a, el0$e, el0$inc, el0$raan, el0$argp, el0$nu)
        el100 <- propagate_keplerian(el0, 100 * 86400)
        st100 <- elements_to_state_vector(el100$a, el100$e, el100$inc, el100$raan, el100$argp, el100$nu)
        stopifnot(check_energy_conservation(st0, st100, tol = 1e-10))
        cat("[PASS] Specific mechanical energy strictly conserved over 100-day arc\\n")
        
        # Test 5: Hyperbolic Turning Angle
        geom <- compute_flyby_geometry(c(6.84, 0, 0), 6051.8 + 340.0, 324858.592, 6051.8)
        stopifnot(geom$turning_angle_deg > 50.0 && geom$turning_angle_deg < 75.0)
        cat(sprintf("[PASS] Venus EGA-1 Deflection: %.2f deg | Impulse Gain: %.3f km/s\\n", geom$turning_angle_deg, geom$delta_v_flyby_km_s))
        
        cat("====================================================\\n")
        cat("ALL 5 ASTRODYNAMICS TEST SUITES PASSED (0 FAILURES)\\n")
      '`;
    } else {
      return NextResponse.json({ error: 'Unknown action' }, { status: 400 });
    }

    const { stdout, stderr } = await execPromise(cmd, { timeout: 15000 });

    return NextResponse.json({
      success: true,
      output: stdout || stderr,
    });
  } catch (error: any) {
    return NextResponse.json({
      success: false,
      error: error.message,
      output: error.stdout || error.stderr || 'Execution failed',
    }, { status: 500 });
  }
}
