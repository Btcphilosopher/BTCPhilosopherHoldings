# NewtonEnergy: Rocket Ascent Energy Loss Accounting and Thermodynamic Analysis

`NewtonEnergy` is a serious, production-grade R package built for aerospace, thermodynamics, and propulsion engineers at **Newton Rockets Ltd.** It is designed for strict energy accounting and loss path analysis of launch vehicle trajectories, rather than simple flight simulation or animation.

## Key Features

- **Strict Energy Accounting**: Systematically partitions initial chemical energy into kinetic energy, gravitational potential energy, kinetic/thermal exhaust, gravity loss, drag loss, thermal losses, radiation, steering losses, propulsion-system internal consumption, and residual propellants.
- **Isentropic Nozzle Expansion**: Solves standard thermodynamic relations for rocket engines with finite pressure ratios, expansion ratios, and combustion efficiencies.
- **Robust Numerical Integration**: Incorporates trapezoidal, Simpson, and adaptive ODE solver methods to integrate force, power, and work from high-frequency telemetry or simulated trajectories.
- **Monte Carlo Uncertainty Propagation**: Accounts for parametric uncertainties in propellant mass, $C_d$, specific energy, and nozzle efficiency, delivering statistical confidence intervals ($95\%$ CI).
- **Global & Local Sensitivity Analysis**: Computes sensitivity indices (such as standardized regression coefficients and partial derivatives) of overall energy efficiency relative to vehicle design inputs.
- **Physical Validation Cases**: Validates calculations against analytical benchmarks (zero-drag, zero-gravity, constant thrust, isentropic nozzle, and closed energy balance).

## Installation

```r
# Install development version
devtools::install_local("./newton-energy")
```

## Quick Start

```r
library(NewtonEnergy)

# Load synthetic or measured trajectory
traj <- read.csv("scenarios/example_trajectory.csv")

# Compute exhaustive energy balance
analysis <- calculate_energy_balance(
  vehicle_mass_dry = 12000,          # kg
  propellant_mass = 100000,         # kg
  propellant_type = "methane_lox",   # or "rp1_lox", "lh2_lox"
  combustion_efficiency = 0.98,
  nozzle_efficiency = 0.96,
  trajectory = traj,
  system_boundary = "full_ascent"
)

# Print tabular energy accountancy
print(analysis$summary_table)

# Generate plots
plot_energy_balance(analysis)
plot_power_curves(analysis)
```

## System Boundaries

The package allows evaluation over several control-volume boundaries:
1. **PROPULSION CONTROL VOLUME**: Energy conversion from chemical reactants to high-velocity mechanical gas.
2. **VEHICLE CONTROL VOLUME**: Energy transfer from hot gas thrust to kinetic and potential vehicle states.
3. **FULL ASCENT CONTROL VOLUME**: Integrated system analysis including external aerodynamics and environmental losses.
