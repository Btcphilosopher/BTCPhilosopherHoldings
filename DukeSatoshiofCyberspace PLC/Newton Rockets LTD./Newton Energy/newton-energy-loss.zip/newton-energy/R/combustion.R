#' Calculate Combustion Energy and Loss
#'
#' Evaluates the conversion of chemical reactants into high-temperature hot gas enthalpy.
#'
#' @param propellant_energy Stored chemical energy in Joules.
#' @param combustion_efficiency Combustion efficiency parameter (0-1).
#' @return A list containing ideal energy, actual combustion energy, and combustion thermal loss in Joules.
#' @export
calculate_combustion <- function(propellant_energy, combustion_efficiency = 0.98) {
  ideal_energy <- propellant_energy
  actual_energy <- propellant_energy * combustion_efficiency
  loss_energy <- propellant_energy * (1 - combustion_efficiency)
  
  return(list(
    ideal_combustion_energy = ideal_energy,
    actual_combustion_energy = actual_energy,
    combustion_loss = loss_energy
  ))
}
