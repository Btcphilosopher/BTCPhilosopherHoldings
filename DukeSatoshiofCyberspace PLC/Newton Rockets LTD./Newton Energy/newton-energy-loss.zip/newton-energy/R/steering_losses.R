#' Calculate Steering Losses
#'
#' Computes kinetic energy losses from off-axis thrusting (thrust-vectoring angles or angle of attack).
#'
#' @param times Time vector in seconds.
#' @param thrusts Instantaneous thrust vector magnitudes in Newtons.
#' @param velocities Velocity magnitude in m/s.
#' @param flight_path_angles Flight path angles in radians.
#' @param attitude_angles Pitch/gimbal attitude angles in radians.
#' @return A list of steering loss power (W) and total steering loss energy (J).
#' @export
calculate_steering_loss <- function(times, thrusts, velocities, flight_path_angles, attitude_angles) {
  # Steering angle difference (alpha)
  alpha <- abs(attitude_angles - flight_path_angles)
  
  # Power lost to non-axial thrust
  powers <- thrusts * velocities * (1 - cos(alpha))
  
  energy <- 0
  n <- length(times)
  if (n > 1) {
    for (i in 1:(n-1)) {
      dt <- times[i+1] - times[i]
      avg_p <- (powers[i+1] + powers[i]) / 2
      energy <- energy + avg_p * dt
    }
  }
  
  return(list(
    steering_powers = powers,
    steering_energy = energy
  ))
}
