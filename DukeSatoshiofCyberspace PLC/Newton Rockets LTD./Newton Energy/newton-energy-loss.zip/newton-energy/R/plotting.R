#' Plot Energy Balance Distribution
#'
#' Generates a structured ggplot2 bar chart representing energy allocation and losses.
#'
#' @param analysis Completed EnergyAnalysis object.
#' @return A ggplot object.
#' @export
plot_energy_balance <- function(analysis) {
  if (!requireNamespace("ggplot2", quietly = TRUE)) {
    stop("ggplot2 package is required.")
  }
  
  df <- analysis$summary_table
  # Remove initial chemical input from balance bar chart
  df_losses <- df[df$term != "Initial Chemical Input", ]
  
  ggplot2::ggplot(df_losses, ggplot2::aes(x = reorder(term, MJ), y = MJ, fill = MJ > 0)) +
    ggplot2::geom_col(width = 0.7, color = "#1E293B", fill = "#2563EB") +
    ggplot2::coord_flip() +
    ggplot2::labs(
      title = "Rocket Ascent Energy Partitioning & Loss Pathways",
      subtitle = paste("Propellant Architecture:", toupper(analysis$propellant_type)),
      x = "Energy Flow Category",
      y = "Energy (MJ)"
    ) +
    ggplot2::theme_minimal()
}

#' Plot Instantaneous Power Curves
#'
#' Renders power allocation changes (W) relative to launch timeline.
#'
#' @param analysis Completed EnergyAnalysis object.
#' @return A ggplot object.
#' @export
plot_power_curves <- function(analysis) {
  if (!requireNamespace("ggplot2", quietly = TRUE)) {
    stop("ggplot2 package is required.")
  }
  
  traj <- analysis$trajectory_data
  # Calculate simple derivative curves
  g0 <- 9.80665
  traj$kinetic_power <- traj$mass * traj$velocity * 1.5 # proxy
  traj$gravity_power <- traj$mass * g0 * traj$velocity_vertical
  
  # Melt/Pivot for plotting
  df_long <- data.frame(
    time = rep(traj$time, 2),
    Power_MW = c(traj$kinetic_power, traj$gravity_power) / 1e6,
    Type = rep(c("Useful Kinetic Power", "Gravity Dissipation Power"), each = nrow(traj))
  )
  
  ggplot2::ggplot(df_long, ggplot2::aes(x = time, y = Power_MW, color = Type)) +
    ggplot2::geom_line(linewidth = 1.2) +
    ggplot2::scale_color_manual(values = c("#EA580C", "#2563EB")) +
    ggplot2::labs(
      title = "Instantaneous Ascent Power Profile",
      x = "Mission Elapsed Time (s)",
      y = "Power (MW)",
      color = "Channel"
    ) +
    ggplot2::theme_minimal()
}

#' Plot Altitude Energy Correlation
#'
#' Renders energy states over height profiles.
#'
#' @param analysis Completed EnergyAnalysis object.
#' @return A ggplot object.
#' @export
plot_altitude_energy <- function(analysis) {
  if (!requireNamespace("ggplot2", quietly = TRUE)) {
    stop("ggplot2 package is required.")
  }
  
  traj <- analysis$trajectory_data
  g0 <- 9.80665
  traj$PE_MJ <- (traj$mass * g0 * traj$altitude) / 1e6
  traj$KE_MJ <- (0.5 * traj$mass * traj$velocity^2) / 1e6
  
  df_long <- data.frame(
    altitude_km = rep(traj$altitude / 1000, 2),
    Energy_MJ = c(traj$PE_MJ, traj$KE_MJ),
    State = rep(c("Potential Energy", "Kinetic Energy"), each = nrow(traj))
  )
  
  ggplot2::ggplot(df_long, ggplot2::aes(x = altitude_km, y = Energy_MJ, color = State)) +
    ggplot2::geom_line(linewidth = 1.1) +
    ggplot2::labs(
      title = "Vehicle Mechanical Energy vs Altitude Profile",
      x = "Altitude (km)",
      y = "Mechanical Energy (MJ)",
      color = "Energy Type"
    ) +
    ggplot2::theme_minimal()
}
