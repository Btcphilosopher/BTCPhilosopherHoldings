#' Calculate Aerodynamic Drag Losses
#'
#' Evaluates the kinetic energy dissipated as atmospheric turbulence and wave drag.
#'
#' @param times Time vector in seconds.
#' @param velocities Velocity vector in m/s.
#' @param altitudes Altitude vector in meters.
#' @param Cd Drag coefficient (0.1 - 0.6).
#' @param area Reference cross-sectional area in m^2.
#' @return A list with drag force (N), drag power (W), and integrated drag energy loss (J).
#' @export
calculate_drag_loss <- function(times, velocities, altitudes, Cd = 0.25, area = 8.0) {
  n <- length(times)
  forces <- numeric(n)
  powers <- numeric(n)
  
  for (i in 1:n) {
    atmos <- get_us_standard_atmosphere(altitudes[i])
    rho <- atmos$density
    
    # Drag equation
    f_drag <- 0.5 * rho * (velocities[i]^2) * Cd * area
    p_drag <- f_drag * velocities[i]
    
    forces[i] <- f_drag
    powers[i] <- p_drag
  }
  
  # Integration
  energy <- 0
  if (n > 1) {
    for (i in 1:(n-1)) {
      dt <- times[i+1] - times[i]
      avg_p <- (powers[i+1] + powers[i]) / 2
      energy <- energy + avg_p * dt
    }
  }
  
  return(list(
    drag_forces = forces,
    drag_powers = powers,
    drag_energy = energy
  ))
}
