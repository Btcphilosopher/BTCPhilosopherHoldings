#' Calculate Radiative Energy Losses
#'
#' Computes blackbody radiative cooling from the nozzle and vehicle surface to the cold background environment.
#'
#' @param times Time vector in seconds.
#' @param surface_temps Surface temperatures in Kelvin.
#' @param radiating_area Area of high-temperature radiating surfaces in m^2 (e.g. nozzle skirt).
#' @param emissivity Emissivity parameter (0-1).
#' @return Total integrated radiative energy loss in Joules.
#' @export
calculate_radiation <- function(times, surface_temps, radiating_area = 2.5, emissivity = 0.85) {
  sigma <- 5.670374e-8 # Stefan-Boltzmann constant (W/m^2 K^4)
  T_env <- 250.0       # Atmospheric ambient sky background temp
  
  n <- length(times)
  powers <- numeric(n)
  
  for (i in 1:n) {
    t_surf <- surface_temps[i]
    if (t_surf < T_env) t_surf <- T_env
    powers[i] <- emissivity * sigma * radiating_area * (t_surf^4 - T_env^4)
  }
  
  # Integrate
  energy <- 0
  if (n > 1) {
    for (i in 1:(n-1)) {
      dt <- times[i+1] - times[i]
      avg_p <- (powers[i+1] + powers[i]) / 2
      energy <- energy + avg_p * dt
    }
  }
  
  return(list(
    radiative_powers = powers,
    radiative_energy = energy
  ))
}
