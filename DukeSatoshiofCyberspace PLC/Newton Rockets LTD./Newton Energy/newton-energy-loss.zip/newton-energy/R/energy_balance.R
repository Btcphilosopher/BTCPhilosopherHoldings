#' Core Energy Loss Balance Analysis Engine
#'
#' Orchestrates physical loss modules to construct a closed, high-fidelity energy accounting ledger for a rocket flight.
#'
#' @param vehicle_mass_dry Dry mass of the vehicle structure (kg).
#' @param propellant_mass Combined mass of initial propellant loaded (kg).
#' @param propellant_type Name of chemical propellant mixture.
#' @param combustion_efficiency Thermal conversion efficiency (0-1).
#' @param nozzle_efficiency Expansion velocity efficiency (0-1).
#' @param Cd Aerodynamic drag coefficient.
#' @param area Cross-sectional reference drag area (m^2).
#' @param trajectory Dataframe of ascent telemetry with time, altitude, velocity, and thrust.
#' @param system_boundary Specified boundary: "propulsion", "vehicle", or "full_ascent".
#' @return A list representing the completed \code{EnergyAnalysis} object.
#' @export
calculate_energy_balance <- function(vehicle_mass_dry, propellant_mass, propellant_type = "methane_lox",
                                     combustion_efficiency = 0.98, nozzle_efficiency = 0.96,
                                     Cd = 0.25, area = 8.0, trajectory = NULL,
                                     system_boundary = "full_ascent") {
  
  if (is.null(trajectory)) {
    # Generate default synthetic trajectory if none provided
    trajectory <- generate_synthetic_trajectory(
      Cd = Cd, area = area, vehicle_mass_dry = vehicle_mass_dry, propellant_mass = propellant_mass
    )
  }
  
  # 1. Chemical Input Energy
  E_chemical_total <- calculate_propellant_energy(propellant_mass, propellant_type)
  
  # Determine mass of propellant burned
  n_points <- nrow(trajectory)
  mass_start <- trajectory$mass[1]
  mass_end <- trajectory$mass[n_points]
  total_mass_loss <- mass_start - mass_end
  
  # Restrict burned propellant within physical constraints
  prop_burned <- min(propellant_mass, max(0, total_mass_loss))
  E_chemical_burned <- calculate_propellant_energy(prop_burned, propellant_type)
  E_residual_chemical <- E_chemical_total - E_chemical_burned
  
  # 2. Hot-gas Combustion Enthalpy & Losses
  combustion_step <- calculate_combustion(E_chemical_burned, combustion_efficiency)
  E_combustion_actual <- combustion_step$actual_combustion_energy
  E_combustion_loss <- combustion_step$combustion_loss
  
  # 3. Nozzle Kinetic Expansion Conversion
  nozzle_step <- calculate_nozzle_expansion(E_combustion_actual, nozzle_efficiency)
  E_exhaust_ke_actual <- nozzle_step$exhaust_kinetic_energy
  E_nozzle_loss <- nozzle_step$nozzle_loss
  
  # 4. Exhaust Plume Residual vs Momentum Transfer Work
  # Momentum thrust kinetic energy: W_thrust = F_thrust * v_exhaust / 2 etc.
  # For system accounting, exhaust losses are defined as energy carried away in the plume
  exhaust_step <- calculate_exhaust_energy(E_exhaust_ke_actual, pressure_thrust_fraction = 0.04)
  E_plume_residual <- exhaust_step$plume_residual_kinetic
  E_pressure_work_loss <- exhaust_step$pressure_work_loss
  
  # 5. Internal Turbopump and Auxiliary Systems
  E_propulsion_internal <- calculate_propulsion_losses(prop_burned, turbopump_efficiency = 0.75)
  
  # 6. Integrated Flight Trajectory Loss Paths
  times <- trajectory$time
  velocities <- trajectory$velocity
  altitudes <- trajectory$altitude
  masses <- trajectory$mass
  vels_vert <- if (!is.null(trajectory$velocity_vertical)) trajectory$velocity_vertical else (velocities * 0.8) # vertical component proxy
  thrusts <- trajectory$thrust
  
  # Gravity Loss
  grav_step <- calculate_gravity_loss(times, masses, vels_vert)
  E_gravity_loss <- grav_step$gravity_loss_energy
  
  # Aerodynamic Drag Loss
  drag_step <- calculate_drag_loss(times, velocities, altitudes, Cd = Cd, area = area)
  E_drag_loss <- drag_step$drag_energy
  
  # Convective Aerodynamic Thermal Loss
  surf_area_est <- pi * sqrt(area / pi) * 20.0 # simple cylindrical surface area estimate
  thermal_step <- calculate_thermal_loss(times, velocities, altitudes, surface_area = surf_area_est)
  E_thermal_loss <- thermal_step$thermal_energy
  
  # Radiative Loss
  surface_temps <- if (!is.null(trajectory$surface_temp)) trajectory$surface_temp else (300.0 + (velocities / 100.0)^2 * 10.0)
  rad_step <- calculate_radiation(times, surface_temps, radiating_area = 3.0, emissivity = 0.85)
  E_radiative_loss <- rad_step$radiative_energy
  
  # Steering/Off-axis Loss
  attitude_ang <- if (!is.null(trajectory$attitude_angle)) trajectory$attitude_angle else rep(pi/2, n_points)
  flight_path_ang <- if (!is.null(trajectory$flight_path_angle)) trajectory$flight_path_angle else rep(pi/2, n_points)
  steer_step <- calculate_steering_loss(times, thrusts, velocities, flight_path_ang, attitude_ang)
  E_steering_loss <- steer_step$steering_energy
  
  # 7. Final Vehicle State Energies
  vehicle_start <- calculate_vehicle_energy(masses[1], velocities[1], altitudes[1])
  vehicle_end <- calculate_vehicle_energy(masses[n_points], velocities[n_points], altitudes[n_points])
  
  E_kinetic_gain <- vehicle_end$kinetic_energy - vehicle_start$kinetic_energy
  E_potential_gain <- vehicle_end$potential_energy - vehicle_start$potential_energy
  
  # 8. Compile Accounting Balance & Residual Analysis
  # Sum accounted terms depending on boundary
  if (system_boundary == "propulsion") {
    # System boundary around engine only
    accounted <- E_exhaust_ke_actual + E_combustion_loss + E_nozzle_loss + E_propulsion_internal
    E_residual_balance <- E_chemical_burned - accounted
    overall_eff <- E_exhaust_ke_actual / E_chemical_burned
  } else if (system_boundary == "vehicle") {
    # System boundary around the structure excluding external environment
    accounted <- E_kinetic_gain + E_potential_gain + E_propulsion_internal + E_steering_loss
    E_residual_balance <- E_exhaust_ke_actual - accounted
    overall_eff <- (E_kinetic_gain + E_potential_gain) / E_exhaust_ke_actual
  } else {
    # FULL ASCENT SYSTEM BOUNDARY (Default)
    accounted <- E_kinetic_gain + E_potential_gain + E_plume_residual +
      E_combustion_loss + E_nozzle_loss + E_pressure_work_loss +
      E_gravity_loss + E_drag_loss + E_steering_loss + E_thermal_loss +
      E_radiative_loss + E_propulsion_internal
    
    E_residual_balance <- E_chemical_burned - accounted
    overall_eff <- (E_kinetic_gain + E_potential_gain) / E_chemical_burned
  }
  
  # Convert energy values to data frames representing flow pathways
  summary_data <- data.frame(
    term = c("Initial Chemical Input", "Vehicle Kinetic Energy Gain", "Vehicle Potential Energy Gain",
             "Exhaust Plume Kinetic Loss", "Combustion Chemical Loss", "Nozzle Expansion Loss",
             "Exit Expansion Overpressure", "Gravity Potential Loss", "Aerodynamic Drag Loss",
             "Lateral Steering Vector Loss", "Structural Aerodynamic Heating", "Atmospheric Radiative Loss",
             "Internal Auxiliary Turbopump Loss", "Residual Unburned Propellant", "Unbalanced Residual (Closure Error)"),
    MJ = c(E_chemical_total, E_kinetic_gain, E_potential_gain, E_plume_residual, E_combustion_loss,
           E_nozzle_loss, E_pressure_work_loss, E_gravity_loss, E_drag_loss, E_steering_loss,
           E_thermal_loss, E_radiative_loss, E_propulsion_internal, E_residual_chemical, E_residual_balance) / 1e6,
    stringsAsFactors = FALSE
  )
  
  summary_data$fraction_percent <- (summary_data$MJ * 1e6 / E_chemical_total) * 100
  
  return(list(
    analysis_id = paste0("NEWTON-EA-", round(runif(1, 1000, 9999))),
    system_boundary = system_boundary,
    propellant_type = propellant_type,
    chemical_input_total_J = E_chemical_total,
    kinetic_gain_J = E_kinetic_gain,
    potential_gain_J = E_potential_gain,
    exhaust_plume_J = E_plume_residual,
    combustion_loss_J = E_combustion_loss,
    nozzle_loss_J = E_nozzle_loss,
    pressure_loss_J = E_pressure_work_loss,
    gravity_loss_J = E_gravity_loss,
    drag_loss_J = E_drag_loss,
    steering_loss_J = E_steering_loss,
    thermal_loss_J = E_thermal_loss,
    radiative_loss_J = E_radiative_loss,
    propulsion_internal_loss_J = E_propulsion_internal,
    residual_chemical_J = E_residual_chemical,
    closure_residual_J = E_residual_balance,
    overall_efficiency = overall_eff,
    summary_table = summary_data,
    trajectory_data = trajectory
  ))
}
