#' Calculate Gravity Losses
#'
#' Computes the energy expended when thrusting directly against gravity to generate vertical speed.
#'
#' @param times Time vector in seconds.
#' @param masses Vehicle masses in kg.
#' @param velocities_vertical Vertical velocities in m/s.
#' @return A list with gravity loss power (W) and integrated gravity loss energy (J).
#' @export
calculate_gravity_loss <- function(times, masses, velocities_vertical) {
  g0 <- 9.80665
  
  # Instantaneous power
  powers <- masses * g0 * velocities_vertical
  
  # Trapezoidal integration
  energy <- 0
  n <- length(times)
  if (n > 1) {
    for (i in 1:(n-1)) {
      dt <- times[i+1] - times[i]
      avg_p <- (powers[i+1] + powers[i]) / 2
      energy <- energy + avg_p * dt
    }
  }
  
  return(list(
    gravity_loss_power = powers,
    gravity_loss_energy = energy
  ))
}
