#' NewtonEnergy Utility and Unit Conversion Functions
#'
#' Helper functions to handle standard conversions, validate SI units, and format scientific telemetry.
#'
#' @export
validate_units <- function(val, expected_unit) {
  if (inherits(val, "units")) {
    return(units::set_units(val, expected_unit, mode = "standard"))
  }
  return(val)
}

#' Convert LHV of common propellant mixtures
#'
#' Returns specific energy of mixture in Joules per kg of total propellant.
#'
#' @param propellant Name of the propellant mixture.
#' @return Mixture specific energy in J/kg.
#' @export
get_propellant_specific_energy <- function(propellant) {
  # Specific chemical energy in J/kg of stoichiometric/nominal mixture
  energies <- list(
    "rp1_lox" = 10.2e6,       # ~10.2 MJ/kg
    "lh2_lox" = 13.4e6,       # ~13.4 MJ/kg
    "methane_lox" = 11.0e6,   # ~11.0 MJ/kg
    "ethanol_lox" = 6.0e6,    # ~6.0 MJ/kg
    "peroxide_90" = 2.7e6     # ~2.7 MJ/kg
  )
  
  prop_lower <- tolower(propellant)
  if (prop_lower %in% names(energies)) {
    return(energies[[prop_lower]])
  } else {
    warning("Unknown propellant. Returning generic 10.0 MJ/kg.")
    return(10.0e6)
  }
}
