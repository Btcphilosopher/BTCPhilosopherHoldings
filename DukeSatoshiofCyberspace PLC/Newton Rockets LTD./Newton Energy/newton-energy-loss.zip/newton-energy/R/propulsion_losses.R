#' Calculate Internal Propulsion and Auxiliary Losses
#'
#' Estimates internal energy overhead including turbopump shaft hydraulic work, pressurization losses, and avionics.
#'
#' @param propellant_mass_burned Mass of propellant burned in kg.
#' @param turbopump_efficiency Pump shaft mechanical efficiency (0-1).
#' @return Total internal propulsion auxiliary energy loss in Joules.
#' @export
calculate_propulsion_losses <- function(propellant_mass_burned, turbopump_efficiency = 0.72) {
  # Estimate 40 kJ of pump mechanical work needed per kg of propellant pumped
  base_pumping_work_per_kg <- 40000 
  ideal_pumping_work <- propellant_mass_burned * base_pumping_work_per_kg
  actual_pump_loss <- ideal_pumping_work / turbopump_efficiency
  
  # Avionics and guidance overhead (constant power estimate ~5 kW integrated)
  auxiliary_loss <- propellant_mass_burned * 2000 # 2 kJ/kg approximation
  
  total_loss <- actual_pump_loss + auxiliary_loss
  return(total_loss)
}
