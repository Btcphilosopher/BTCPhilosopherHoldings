#' Calculate Sensitivity of Vehicle Energy Efficiency
#'
#' Evaluates local first-order derivatives or standardized regression coefficients of payload/ascent efficiency relative to design variables.
#'
#' @param vehicle_mass_dry Baseline empty vehicle mass in kg.
#' @param propellant_mass Baseline propellant load in kg.
#' @param propellant_type Type of propellant.
#' @param Cd Baseline drag coefficient.
#' @param nozzle_efficiency Baseline nozzle velocity efficiency.
#' @return A dataframe showing design variables, computed sensitivities, and engineering rank.
#' @export
calculate_sensitivity <- function(vehicle_mass_dry = 12000, propellant_mass = 100000,
                                  propellant_type = "methane_lox", Cd = 0.25, nozzle_efficiency = 0.96) {
  
  # Base run
  base_run <- calculate_energy_balance(
    vehicle_mass_dry = vehicle_mass_dry,
    propellant_mass = propellant_mass,
    propellant_type = propellant_type,
    combustion_efficiency = 0.98,
    nozzle_efficiency = nozzle_efficiency,
    Cd = Cd,
    area = 8.0,
    trajectory = NULL
  )
  base_eff <- base_run$overall_efficiency
  
  # Helper to compute finite difference derivative: d_Eff / d_Param
  get_perturbed_eff <- function(p_name, p_val, delta) {
    v_dry <- vehicle_mass_dry
    p_mass <- propellant_mass
    v_cd <- Cd
    v_noz <- nozzle_efficiency
    
    if (p_name == "dry_mass") v_dry <- p_val + delta
    if (p_name == "prop_mass") p_mass <- p_val + delta
    if (p_name == "Cd") v_cd <- p_val + delta
    if (p_name == "nozzle_eff") v_noz <- p_val + delta
    
    run <- calculate_energy_balance(
      vehicle_mass_dry = v_dry,
      propellant_mass = p_mass,
      propellant_type = propellant_type,
      combustion_efficiency = 0.98,
      nozzle_efficiency = v_noz,
      Cd = v_cd,
      area = 8.0,
      trajectory = NULL
    )
    return(run$overall_efficiency)
  }
  
  # Dry mass sensitivity
  eff_dry_plus <- get_perturbed_eff("dry_mass", vehicle_mass_dry, 500) # +500kg
  sens_dry <- (eff_dry_plus - base_eff) / (500 / vehicle_mass_dry) # elasticity
  
  # Propellant mass sensitivity
  eff_prop_plus <- get_perturbed_eff("prop_mass", propellant_mass, 2000)
  sens_prop <- (eff_prop_plus - base_eff) / (2000 / propellant_mass)
  
  # Cd sensitivity
  eff_cd_plus <- get_perturbed_eff("Cd", Cd, 0.05)
  sens_cd <- (eff_cd_plus - base_eff) / (0.05 / Cd)
  
  # Nozzle efficiency sensitivity
  eff_noz_plus <- get_perturbed_eff("nozzle_eff", nozzle_efficiency, 0.01)
  sens_noz <- (eff_noz_plus - base_eff) / (0.01 / nozzle_efficiency)
  
  # Create summary
  df <- data.frame(
    parameter = c("Nozzle Efficiency (eta_nozzle)", "Vehicle Dry Mass (m_dry)", "Aerodynamic Drag (Cd)", "Propellant Load (m_prop)"),
    elasticity = c(sens_noz, sens_dry, sens_cd, sens_prop),
    impact_direction = c("Positive", "Negative", "Negative", "Positive"),
    stringsAsFactors = FALSE
  )
  
  # Calculate normalized significance
  total_abs <- sum(abs(df$elasticity))
  df$normalized_importance <- (abs(df$elasticity) / total_abs) * 100
  df <- df[order(-df$normalized_importance), ]
  df$rank <- 1:nrow(df)
  
  return(df)
}
