#' US Standard Atmosphere 1976 Approximation
#'
#' Estimates air density, temperature, and pressure at a given altitude.
#'
#' @param altitude_m Altitude in meters (SI).
#' @return A list containing temperature (K), density (kg/m^3), and pressure (Pa).
#' @export
get_us_standard_atmosphere <- function(altitude_m) {
  # Constants
  g0 <- 9.80665
  R <- 287.05
  T0 <- 288.15
  p0 <- 101325.0
  rho0 <- 1.225
  
  if (altitude_m < 0) altitude_m <- 0
  
  # Lapse rates and layers
  if (altitude_m <= 11000) {
    # Troposphere
    L <- -0.0065
    T_alt <- T0 + L * altitude_m
    p_alt <- p0 * (T_alt / T0) ^ (-g0 / (R * L))
    rho_alt <- p_alt / (R * T_alt)
  } else if (altitude_m <= 20000) {
    # Tropopause (isothermal)
    T11 <- T0 - 0.0065 * 11000
    p11 <- p0 * (T11 / T0) ^ (-g0 / (R * -0.0065))
    h_diff <- altitude_m - 11000
    p_alt <- p11 * exp(-g0 * h_diff / (R * T11))
    T_alt <- T11
    rho_alt <- p_alt / (R * T_alt)
  } else {
    # Stratosphere (up to 47km)
    T11 <- T0 - 0.0065 * 11000
    p11 <- p0 * (T11 / T0) ^ (-g0 / (R * -0.0065))
    p20 <- p11 * exp(-g0 * 9000 / (R * T11))
    
    L2 <- 0.0010
    h_diff <- altitude_m - 20000
    T_alt <- T11 + L2 * h_diff
    p_alt <- p20 * (T_alt / T11) ^ (-g0 / (R * L2))
    rho_alt <- p_alt / (R * T_alt)
    
    # Vacuum cut-off
    if (altitude_m > 80000) {
      T_alt <- 180.0
      p_alt <- 0.01
      rho_alt <- 0.0
    }
  }
  
  return(list(
    temperature = T_alt,
    density = rho_alt,
    pressure = p_alt
  ))
}
