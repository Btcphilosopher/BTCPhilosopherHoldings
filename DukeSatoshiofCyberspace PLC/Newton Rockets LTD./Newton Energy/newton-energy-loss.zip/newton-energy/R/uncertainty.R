#' Set Parametric Uncertainty Distributions
#'
#' Helper constructor to build probability distribution specs for Monte Carlo parameters.
#'
#' @param type Distribution type ("normal", "uniform", "triangular").
#' @param params Numeric vector of distribution parameters (e.g. c(mean, sd) or c(min, max)).
#' @return A list detailing the distribution spec.
#' @export
create_uncertainty_spec <- function(type = "normal", params) {
  return(list(
    type = type,
    params = params
  ))
}

#' Sample from Uncertainty Spec
#'
#' Draws random variables from defined probability density functions.
#'
#' @param spec An uncertainty specification list.
#' @param n Number of samples.
#' @return A numeric vector of random draws.
#' @export
sample_uncertainty <- function(spec, n = 1) {
  type <- spec$type
  p <- spec$params
  
  if (type == "normal") {
    return(rnorm(n, mean = p[1], sd = p[2]))
  } else if (type == "uniform") {
    return(runif(n, min = p[1], max = p[2]))
  } else if (type == "triangular") {
    # Triangular sampling using inverse transform
    # params: min=p[1], mode=p[2], max=p[3]
    a <- p[1]
    c <- p[2]
    b <- p[3]
    u <- runif(n)
    fc <- (c - a) / (b - a)
    samples <- ifelse(u < fc,
                      a + sqrt(u * (b - a) * (c - a)),
                      b - sqrt((1 - u) * (b - a) * (b - c)))
    return(samples)
  } else {
    stop("Unsupported uncertainty distribution type.")
  }
}
