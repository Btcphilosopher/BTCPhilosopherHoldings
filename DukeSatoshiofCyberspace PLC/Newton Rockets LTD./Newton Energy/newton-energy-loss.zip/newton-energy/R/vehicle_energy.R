#' Calculate Vehicle Mechanical Energy
#'
#' Computes the kinetic and potential energy states of the vehicle throughout ascent.
#'
#' @param mass_kg Vehicle mass at each point in kg.
#' @param velocity_mps Velocity magnitude in m/s.
#' @param altitude_m Altitude in meters.
#' @param model_type Gravity model type: "constant_g" or "central_gravity".
#' @return A list with kinetic energy (J) and potential energy (J) over the trajectory.
#' @export
calculate_vehicle_energy <- function(mass_kg, velocity_mps, altitude_m, model_type = "central_gravity") {
  g0 <- 9.80665
  GM <- 3.986004418e14  # Earth gravitational constant (m^3/s^2)
  R_earth <- 6378137.0  # Earth equatorial radius in meters
  
  # Kinetic Energy: Ek = 0.5 * m * v^2
  kinetic_energy <- 0.5 * mass_kg * (velocity_mps ^ 2)
  
  # Potential Energy
  if (model_type == "constant_g") {
    potential_energy <- mass_kg * g0 * altitude_m
  } else {
    # Central Gravity relative to Earth surface
    # Ep = -G M m / r - (-G M m / R_earth)
    r <- R_earth + altitude_m
    potential_energy <- -GM * mass_kg / r - (-GM * mass_kg / R_earth)
  }
  
  return(list(
    kinetic_energy = kinetic_energy,
    potential_energy = potential_energy
  ))
}
