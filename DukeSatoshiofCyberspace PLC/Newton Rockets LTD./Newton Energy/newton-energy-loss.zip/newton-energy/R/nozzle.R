#' Calculate Nozzle Expansion Energy Conversion
#'
#' Estimates thermodynamic conversion of combustion energy into directed gas momentum.
#'
#' @param combustion_energy Actual thermal combustion energy in Joules.
#' @param nozzle_efficiency Nozzle velocity efficiency parameter (0-1).
#' @return A list of kinetic exhaust energy (J) and nozzle shear/expansion loss (J).
#' @export
calculate_nozzle_expansion <- function(combustion_energy, nozzle_efficiency = 0.96) {
  # Kinetic energy scale is proportional to efficiency^2 (since v_e ~ efficiency)
  actual_exhaust_ke <- combustion_energy * (nozzle_efficiency ^ 2)
  nozzle_loss <- combustion_energy * (1 - (nozzle_efficiency ^ 2))
  
  return(list(
    exhaust_kinetic_energy = actual_exhaust_ke,
    nozzle_loss = nozzle_loss
  ))
}
