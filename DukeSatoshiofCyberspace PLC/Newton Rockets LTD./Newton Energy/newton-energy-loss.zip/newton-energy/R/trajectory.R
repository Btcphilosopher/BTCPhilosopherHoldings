#' Generate or Ingest Trajectory Dataset
#'
#' Simulates a high-fidelity synthetic ascent trajectory representing nominal launch operations for verification.
#'
#' @param duration Simulation duration in seconds (nominal: 120s).
#' @param dt Time step in seconds.
#' @param thrust Engine nominal thrust in Newtons.
#' @param mdot Propellant mass flow rate in kg/s.
#' @param vehicle_mass_dry Empty dry vehicle mass in kg.
#' @param propellant_mass Propellant loading in kg.
#' @param Cd Aerodynamic drag coefficient.
#' @param area Aerodynamic cross-sectional area in m^2.
#' @return A data frame containing simulated launch telemetry.
#' @export
generate_synthetic_trajectory <- function(duration = 120, dt = 1.0, thrust = 1.2e6, mdot = 400.0,
                                          vehicle_mass_dry = 12000, propellant_mass = 100000,
                                          Cd = 0.25, area = 8.0) {
  times <- seq(0, duration, by = dt)
  n <- length(times)
  
  altitudes <- numeric(n)
  velocities <- numeric(n)
  velocities_vertical <- numeric(n)
  masses <- numeric(n)
  thrusts <- numeric(n)
  flight_path_angles <- numeric(n)
  attitude_angles <- numeric(n)
  temperatures <- numeric(n)
  
  curr_propellant <- propellant_mass
  curr_altitude <- 0
  curr_velocity <- 0
  
  g0 <- 9.80665
  
  for (i in 1:n) {
    t <- times[i]
    masses[i] <- vehicle_mass_dry + curr_propellant
    
    # Simple flight pitch program: starts vertical, gradually tilts over
    # pitch angle theta relative to horizontal. T=0 => 90 deg (pi/2).
    # After 10s, pitch over towards 30 deg at T=120s
    if (t < 10) {
      theta <- pi / 2
    } else {
      fraction <- (t - 10) / (duration - 10)
      theta <- (pi / 2) - fraction * (pi / 3) # ends at 30 degrees (pi/6)
    }
    attitude_angles[i] <- theta
    
    # Engine status: thrusts while propellant remains
    if (curr_propellant > 0) {
      thrusts[i] <- thrust
      curr_propellant <- max(0, curr_propellant - mdot * dt)
    } else {
      thrusts[i] <- 0
    }
    
    # Atmospheric properties
    atmos <- get_us_standard_atmosphere(curr_altitude)
    rho <- atmos$density
    temperatures[i] <- 400.0 + 3.0 * (curr_velocity / 100.0)^2 # surface thermal proxy
    
    # Aero forces
    f_drag <- 0.5 * rho * (curr_velocity^2) * Cd * area
    
    # Accelerations (vertical & horizontal)
    # F_net = Thrust - Drag - Gravity
    # Assuming flight aligned velocity vector roughly for simplicity
    f_net_thrust_drag <- thrusts[i] - f_drag
    
    # Resolve 2D dynamics
    f_x <- f_net_thrust_drag * cos(theta)
    f_y <- f_net_thrust_drag * sin(theta) - masses[i] * g0
    
    ax <- f_x / masses[i]
    ay <- f_y / masses[i]
    
    # Update states
    if (i < n) {
      vx <- curr_velocity * cos(theta) + ax * dt
      vy <- curr_velocity * sin(theta) + ay * dt
      
      curr_velocity <- sqrt(vx^2 + vy^2)
      curr_altitude <- max(0, curr_altitude + vy * dt)
      
      velocities_vertical[i] <- vy
      flight_path_angles[i] <- atan2(vy, vx)
    } else {
      velocities_vertical[i] <- curr_velocity * sin(theta)
      flight_path_angles[i] <- theta
    }
    
    altitudes[i] <- curr_altitude
    velocities[i] <- curr_velocity
  }
  
  df <- data.frame(
    time = times,
    mass = masses,
    altitude = altitudes,
    velocity = velocities,
    velocity_vertical = velocities_vertical,
    thrust = thrusts,
    flight_path_angle = flight_path_angles,
    attitude_angle = attitude_angles,
    surface_temp = temperatures
  )
  
  return(df)
}
