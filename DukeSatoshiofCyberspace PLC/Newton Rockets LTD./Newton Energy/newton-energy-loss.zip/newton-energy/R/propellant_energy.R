#' Calculate Propellant Chemical Energy
#'
#' Computes total potential chemical energy stored inside the rocket's propellant tanks.
#'
#' @param propellant_mass Mass of propellant in kg.
#' @param propellant_type Type of propellant (e.g. "rp1_lox", "lh2_lox", "methane_lox").
#' @return Total stored chemical energy in Joules.
#' @export
calculate_propellant_energy <- function(propellant_mass, propellant_type = "methane_lox") {
  spec_energy <- get_propellant_specific_energy(propellant_type)
  E_chemical <- propellant_mass * spec_energy
  return(E_chemical)
}
