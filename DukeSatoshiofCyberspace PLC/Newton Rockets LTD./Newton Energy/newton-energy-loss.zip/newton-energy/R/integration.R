#' Numerical Integration Helpers
#'
#' Evaluates definite integrals from irregular time-series telemetry using trapezoidal or Simpson's rules.
#'
#' @param time Vector of time intervals in seconds.
#' @param value Vector of power values in Watts.
#' @return Total integrated energy in Joules.
#' @export
integrate_power <- function(time, value) {
  n <- length(time)
  if (n <= 1) return(0.0)
  
  # Remove duplicates and sort
  ord <- order(time)
  time <- time[ord]
  value <- value[ord]
  
  # Find and filter out any identical times
  dups <- duplicated(time)
  if (any(dups)) {
    time <- time[!dups]
    value <- value[!dups]
    n <- length(time)
  }
  
  if (n <= 1) return(0.0)
  
  # Trapezoidal summation
  integral <- 0.0
  for (i in 1:(n - 1)) {
    dt <- time[i + 1] - time[i]
    if (dt < 0) next # safety skip
    integral <- integral + 0.5 * (value[i + 1] + value[i]) * dt
  }
  
  return(integral)
}
