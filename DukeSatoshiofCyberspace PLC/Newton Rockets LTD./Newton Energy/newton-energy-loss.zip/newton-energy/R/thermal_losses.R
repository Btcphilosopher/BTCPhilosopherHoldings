#' Calculate Aerodynamic Surface Heating
#'
#' Estimates the convective heat energy transferred to the rocket skin using engineering correlations (Sutton-Graves or flat-plate boundary layer approximations).
#'
#' @param times Time vector in seconds.
#' @param velocities Velocity vector in m/s.
#' @param altitudes Altitude vector in meters.
#' @param surface_area Effective vehicle thermal surface area in m^2.
#' @return Total integrated aerodynamic convective heat energy in Joules.
#' @export
calculate_thermal_loss <- function(times, velocities, altitudes, surface_area = 24.0) {
  n <- length(times)
  heat_fluxes <- numeric(n)
  
  for (i in 1:n) {
    atmos <- get_us_standard_atmosphere(altitudes[i])
    rho <- atmos$density
    
    # Flat plate convective heat flux approximation: q = C * rho^0.5 * v^3
    # C is an empirical aerodynamic factor
    if (rho > 0) {
      q_conv <- 0.00015 * sqrt(rho) * (velocities[i] ^ 3)
    } else {
      q_conv <- 0.0
    }
    
    heat_fluxes[i] <- q_conv * surface_area
  }
  
  # Integrate over time
  energy <- 0
  if (n > 1) {
    for (i in 1:(n-1)) {
      dt <- times[i+1] - times[i]
      avg_q <- (heat_fluxes[i+1] + heat_fluxes[i]) / 2
      energy <- energy + avg_q * dt
    }
  }
  
  return(list(
    heat_powers = heat_fluxes,
    thermal_energy = energy
  ))
}
