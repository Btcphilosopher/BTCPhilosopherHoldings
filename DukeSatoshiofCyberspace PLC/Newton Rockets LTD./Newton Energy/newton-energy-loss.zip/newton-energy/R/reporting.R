#' Generate Quarto Energy Loss Report Preview
#'
#' Builds a text-formatted R Markdown / Quarto engineering report summarising vehicle energy budget parameters, statistical intervals, and closure checks.
#'
#' @param analysis Completed EnergyAnalysis object.
#' @param mc_results Optional Monte Carlo summary.
#' @return A character string of the formatted report.
#' @export
generate_energy_report <- function(analysis, mc_results = NULL) {
  # Header
  rpt <- c(
    "=========================================================================",
    "                    NEWTON ROCKETS LTD. - ENGINEERING REPORT              ",
    "                    VEHICLE ASCENT THERMODYNAMIC LOSS ANALYSIS             ",
    "=========================================================================",
    paste("Report ID:       ", analysis$analysis_id),
    paste("Date Generated:  ", Sys.time()),
    paste("Propellant Class:", toupper(analysis$propellant_type)),
    paste("Control Boundary:", toupper(analysis$system_boundary)),
    "-------------------------------------------------------------------------",
    "",
    "1. SYSTEM INPUT PROFILE",
    "-----------------------",
    paste("Initial Chemical Energy (input):", round(analysis$chemical_input_total_J / 1e6, 2), "MJ"),
    paste("Residual Stored Tank Energy:    ", round(analysis$residual_chemical_J / 1e6, 2), "MJ"),
    "",
    "2. VEHICLE MECHANICAL WORK ACCOMPLISHED",
    "--------------------------------------",
    paste("Useful Kinetic Energy Gain:     ", round(analysis$kinetic_gain_J / 1e6, 2), "MJ"),
    paste("Gravitational Potential Gain:   ", round(analysis$potential_gain_J / 1e6, 2), "MJ"),
    paste("Overall Energy Efficiency:      ", round(analysis$overall_efficiency * 100, 3), "%"),
    "",
    "3. SYSTEM LOSS ACCOUNTANCY",
    "-------------------------",
    paste("Exhaust Plume Heat & KE Loss:   ", round(analysis$exhaust_plume_J / 1e6, 2), "MJ"),
    paste("Combustion Loss:                ", round(analysis$combustion_loss_J / 1e6, 2), "MJ"),
    paste("Nozzle Velocity Expansion Loss: ", round(analysis$nozzle_loss_J / 1e6, 2), "MJ"),
    paste("Gravity Dissipation Loss:       ", round(analysis$gravity_loss_J / 1e6, 2), "MJ"),
    paste("Aerodynamic Drag Loss:          ", round(analysis$drag_loss_J / 1e6, 2), "MJ"),
    paste("Convective Kinetic Heat Loss:   ", round(analysis$thermal_loss_J / 1e6, 2), "MJ"),
    paste("Auxiliary Turbopump Power Loss: ", round(analysis$propulsion_internal_loss_J / 1e6, 2), "MJ"),
    "",
    "4. ENERGY BALANCE CLOSURE & RESIDUALS",
    "------------------------------------",
    paste("Unbalanced Closure Error:       ", round(analysis$closure_residual_J / 1e6, 4), "MJ"),
    paste("Normalized Closure Error (%):   ", round((analysis$closure_residual_J / analysis$chemical_input_total_J) * 100, 5), "%"),
    ""
  )
  
  if (!is.null(mc_results)) {
    rpt <- c(rpt,
      "5. STATISTICAL UNCERTAINTY BOUNDS (MONTE CARLO)",
      "----------------------------------------------",
      paste("Mean Drag Loss (95% CI):        ", round(mc_results$drag_stats["mean"], 2), "MJ [", round(mc_results$drag_stats["p2.5"], 2), "-", round(mc_results$drag_stats["p97.5"], 2), "MJ ]"),
      paste("Mean Flight Efficiency (95% CI):", round(mc_results$efficiency_stats["mean"] * 100, 3), "% [", round(mc_results$efficiency_stats["p2.5"] * 100, 3), "-", round(mc_results$efficiency_stats["p97.5"] * 100, 3), "% ]"),
      ""
    )
  }
  
  rpt <- c(rpt,
    "6. MODEL LIMITATIONS & DISCLAIMER",
    "----------------------------------",
    "- Standard U.S. 1976 atmosphere represents mid-latitude average conditions.",
    "- Nozzle calculations assume static gamma; finite rate chemistry is not modeled.",
    "- Local convective heat flux uses 1D flat-plate approximations.",
    "-------------------------------------------------------------------------",
    "                      REPRODUCIBILITY CRYPTO SIGNATURE                    ",
    paste("SHA-256 MANIFEST HASH: ", digest::digest(analysis, algo="sha256")),
    "========================================================================="
  )
  
  return(paste(rpt, collapse = "\n"))
}
