#' Run Monte Carlo Uncertainty Propagation
#'
#' Propagates physical input uncertainties (e.g. Cd, propellant mass, thrust) through the thermodynamics energy balance solver.
#'
#' @param n_samples Number of iterations (typically 1,000 - 10,000).
#' @param vehicle_mass_dry Base empty vehicle dry mass in kg.
#' @param propellant_mass Base propellant load in kg.
#' @param propellant_type Type of fuel mixture.
#' @param Cd_spec Uncertainty spec list for drag coefficient.
#' @param nozzle_eff_spec Uncertainty spec list for nozzle efficiency.
#' @param trajectory Target flight trajectory dataframe.
#' @return A list containing statistical summarized distributions of energy components.
#' @export
run_monte_carlo <- function(n_samples = 1000, vehicle_mass_dry = 12000, propellant_mass = 100000,
                             propellant_type = "methane_lox", Cd_spec = NULL, nozzle_eff_spec = NULL,
                             trajectory = NULL) {
  
  if (is.null(Cd_spec)) Cd_spec <- create_uncertainty_spec("normal", c(0.25, 0.02))
  if (is.null(nozzle_eff_spec)) nozzle_eff_spec <- create_uncertainty_spec("normal", c(0.96, 0.015))
  
  # Sample parameters
  Cd_draws <- sample_uncertainty(Cd_spec, n_samples)
  nozzle_draws <- sample_uncertainty(nozzle_eff_spec, n_samples)
  
  # Allocate result matrix
  kinetic_gain_MJ <- numeric(n_samples)
  potential_gain_MJ <- numeric(n_samples)
  gravity_loss_MJ <- numeric(n_samples)
  drag_loss_MJ <- numeric(n_samples)
  nozzle_loss_MJ <- numeric(n_samples)
  combustion_loss_MJ <- numeric(n_samples)
  overall_effs <- numeric(n_samples)
  
  for (i in 1:n_samples) {
    # Solve energy balance for single parametric draw
    res <- calculate_energy_balance(
      vehicle_mass_dry = vehicle_mass_dry,
      propellant_mass = propellant_mass,
      propellant_type = propellant_type,
      combustion_efficiency = 0.98,
      nozzle_efficiency = max(0.5, min(0.999, nozzle_draws[i])),
      Cd = max(0.01, Cd_draws[i]),
      area = 8.0,
      trajectory = trajectory,
      system_boundary = "full_ascent"
    )
    
    kinetic_gain_MJ[i] <- res$kinetic_gain_J / 1e6
    potential_gain_MJ[i] <- res$potential_gain_J / 1e6
    gravity_loss_MJ[i] <- res$gravity_loss_J / 1e6
    drag_loss_MJ[i] <- res$drag_loss_J / 1e6
    nozzle_loss_MJ[i] <- res$nozzle_loss_J / 1e6
    combustion_loss_MJ[i] <- res$combustion_loss_J / 1e6
    overall_effs[i] <- res$overall_efficiency
  }
  
  # Standard statistical functions
  stats_summary <- function(vals) {
    c(
      mean = mean(vals),
      sd = sd(vals),
      p2.5 = quantile(vals, 0.025)[[1]],
      p50 = median(vals),
      p97.5 = quantile(vals, 0.975)[[1]]
    )
  }
  
  return(list(
    samples_count = n_samples,
    kinetic_stats = stats_summary(kinetic_gain_MJ),
    potential_stats = stats_summary(potential_gain_MJ),
    gravity_stats = stats_summary(gravity_loss_MJ),
    drag_stats = stats_summary(drag_loss_MJ),
    nozzle_stats = stats_summary(nozzle_loss_MJ),
    efficiency_stats = stats_summary(overall_effs),
    raw_draws = list(
      Cd = Cd_draws,
      nozzle_eff = nozzle_draws,
      drag_loss_MJ = drag_loss_MJ,
      efficiency = overall_effs
    )
  ))
}
