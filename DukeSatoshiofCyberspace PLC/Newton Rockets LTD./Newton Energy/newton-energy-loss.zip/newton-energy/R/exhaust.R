#' Account for Energy Leaving in Exhaust
#'
#' Classifies energy remaining in the exit plume, distinguishing between directed plume velocity, ambient backpressure work, and residual thermal gas.
#'
#' @param exhaust_kinetic_energy Plume kinetic energy in Joules.
#' @param pressure_thrust_fraction Fraction of energy lost as ambient pressure expansion.
#' @return A list detailing residual kinetic plume energy, ambient expansion losses, and useful directed momentum energy.
#' @export
calculate_exhaust_energy <- function(exhaust_kinetic_energy, pressure_thrust_fraction = 0.05) {
  residual_kinetic <- exhaust_kinetic_energy * (1 - pressure_thrust_fraction)
  pressure_loss <- exhaust_kinetic_energy * pressure_thrust_fraction
  
  return(list(
    plume_residual_kinetic = residual_kinetic,
    pressure_work_loss = pressure_loss
  ))
}
