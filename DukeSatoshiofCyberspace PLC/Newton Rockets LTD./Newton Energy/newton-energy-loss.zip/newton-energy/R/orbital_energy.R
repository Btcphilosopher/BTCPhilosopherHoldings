#' Specific Orbital Energy Analysis
#'
#' Computes total orbital energy per unit mass (Joules/kg) to determine orbit type and circular velocity matching.
#'
#' @param velocity_mps Velocity magnitude in m/s.
#' @param altitude_m Altitude in meters.
#' @return Specific orbital energy in Joules/kg.
#' @export
calculate_specific_orbital_energy <- function(velocity_mps, altitude_m) {
  GM <- 3.986004418e14  # Earth standard gravitational parameter
  R_earth <- 6378137.0
  
  r <- R_earth + altitude_m
  spec_ke <- 0.5 * (velocity_mps ^ 2)
  spec_pe <- -GM / r
  
  spec_total <- spec_ke + spec_pe
  return(spec_total)
}
