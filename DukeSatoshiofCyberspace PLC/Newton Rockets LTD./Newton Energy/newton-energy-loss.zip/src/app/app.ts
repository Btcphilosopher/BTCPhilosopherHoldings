import {ChangeDetectionStrategy, Component, computed, signal, inject} from '@angular/core';
import {CommonModule} from '@angular/common';
import {ReactiveFormsModule, FormBuilder, FormGroup} from '@angular/forms';
import {MatIconModule} from '@angular/material/icon';
import {ThermoEngine, PROPELLANTS, TrajectoryPoint, EnergyAnalysisResults} from './thermo-engine';

export interface MonteCarloSummary {
  iterations: number;
  efficiency: { mean: number; p2_5: number; median: number; p97_5: number };
  dragLossMJ: { mean: number; p2_5: number; median: number; p97_5: number };
  rawEffs: number[];
  rawDrags: number[];
}

@Component({
  changeDetection: ChangeDetectionStrategy.OnPush,
  selector: 'app-root',
  imports: [CommonModule, ReactiveFormsModule, MatIconModule],
  templateUrl: './app.html',
  styleUrl: './app.css',
})
export class App {
  private fb = inject(FormBuilder);
  private engine = inject(ThermoEngine);

  // Expose Math global to template
  Math = Math;

  // Available Presets
  propellants = PROPELLANTS;

  // Workspace active tab
  activeTab = signal<string>('overview');

  // Control Volume System Boundary
  systemBoundary = signal<'propulsion' | 'vehicle' | 'full_ascent'>('full_ascent');

  // Form Controls (Reactive)
  configForm: FormGroup;

  // Custom uploaded trajectory telemetry
  uploadedTrajectory = signal<TrajectoryPoint[] | null>(null);
  uploadFileName = signal<string>('');
  uploadError = signal<string>('');

  // Active hover time on the timeline
  hoverTime = signal<number | null>(null);

  // Monte Carlo simulation state
  mcSamples = signal<number>(1000);
  mcRunning = signal<boolean>(false);
  mcResults = signal<MonteCarloSummary | null>(null);

  // Quarto Report interactive fields
  reportMetadata = signal({
    title: 'Newton Alpha - Thermodynamic Loss Ledger',
    analyst: 'Chief Analyst Tom (Newton Rockets Ltd.)',
    classification: 'RESTRICTED - COMMERCIAL INTERNAL',
    payloadTarget: 'Low Earth Orbit (LEO) - 2,500 kg',
    notes: 'Ascent thermodynamics reconstructed from standard 120s flight pitch schedule. Calculations verified against static conservation equations.'
  });

  constructor() {
    // Initial standard configuration: LOX/Methane launcher
    this.configForm = this.fb.group({
      propellantId: ['methane_lox'],
      dryMass: [12000],
      propellantMass: [100000],
      thrust: [1200000],
      combustionEff: [0.98],
      nozzleEff: [0.96],
      Cd: [0.25],
      refArea: [8.0],
      pitchOffset: [0]
    });
  }

  // Active configuration derived from form values
  activeConfig = computed(() => {
    return {
      propellantId: (this.configForm.value.propellantId as string) || 'methane_lox',
      dryMass: Number(this.configForm.value.dryMass) || 12000,
      propellantMass: Number(this.configForm.value.propellantMass) || 100000,
      thrust: Number(this.configForm.value.thrust) || 1200000,
      combustionEff: Number(this.configForm.value.combustionEff) || 0.98,
      nozzleEff: Number(this.configForm.value.nozzleEff) || 0.96,
      Cd: Number(this.configForm.value.Cd) || 0.25,
      refArea: Number(this.configForm.value.refArea) || 8.0,
      pitchOffset: Number(this.configForm.value.pitchOffset) || 0,
      systemBoundary: this.systemBoundary()
    };
  });

  // Solves physical energy balance based on inputs
  analysis = computed<EnergyAnalysisResults>(() => {
    const config = this.activeConfig();
    const customTraj = this.uploadedTrajectory();
    return this.engine.solveEnergyBalance({
      ...config,
      trajectory: customTraj ? customTraj : undefined
    });
  });

  // Clean computed displays to avoid inline logic in HTML (highly recommended)
  propellantIdDisplay = computed(() => {
    return this.activeConfig().propellantId.replace('_', ' ').toUpperCase();
  });

  closureErrorPct = computed(() => {
    return (this.analysis().closureResidualJ / this.analysis().chemicalInputTotalJ) * 100;
  });

  isClosureNominal = computed(() => {
    return Math.abs(this.analysis().closureResidualJ / this.analysis().chemicalInputTotalJ) < 0.001;
  });

  // Ranked design sensitivities
  sensitivities = computed(() => {
    return this.engine.calculateSensitivity(this.activeConfig());
  });

  // Maximum values for telemetry readouts
  maxDragPower = computed(() => {
    const traj = this.analysis().trajectory;
    let maxP = 0;
    traj.forEach(p => {
      const pDrag = p.drag * p.velocity;
      if (pDrag > maxP) maxP = pDrag;
    });
    return maxP / 1e6; // MW
  });

  maxSkinTemp = computed(() => {
    const traj = this.analysis().trajectory;
    let maxT = 288.15;
    traj.forEach(p => {
      if (p.skinTemp > maxT) maxT = p.skinTemp;
    });
    return maxT;
  });

  // Synchronized hover tooltip details
  hoverDetails = computed(() => {
    const t = this.hoverTime();
    if (t === null) return null;
    
    const traj = this.analysis().trajectory;
    const pt = traj.find(p => p.time === t);
    if (!pt) return null;
    
    const prop = PROPELLANTS.find(p => p.id === this.activeConfig().propellantId) || PROPELLANTS[0];
    const mdot = this.activeConfig().thrust / (9.80665 * (prop.nominalThrust / (9.80665 * prop.nominalMdot)));
    
    const isActive = pt.thrust > 0;
    const pChemical = isActive ? (mdot * prop.specificEnergy) / 1e6 : 0;
    const pCombLoss = pChemical * (1 - this.activeConfig().combustionEff);
    const pNozLoss = pChemical * this.activeConfig().combustionEff * (1 - Math.pow(this.activeConfig().nozzleEff, 2));
    const pThrust = (pt.thrust * pt.velocity) / 1e6;
    const pGravity = (pt.mass * 9.80665 * pt.velocityY) / 1e6;
    const pDrag = (pt.drag * pt.velocity) / 1e6;
    
    return {
      time: t,
      altitudeKm: pt.altitude / 1000,
      velocityMps: pt.velocity,
      mach: pt.mach,
      density: pt.density,
      skinTempK: pt.skinTemp,
      pChemical,
      pCombLoss,
      pNozLoss,
      pThrust,
      pGravity,
      pDrag
    };
  });

  // Calculates hover cursor X-coordinate scaled in the SVG
  getHoverX() {
    const t = this.hoverTime();
    if (t === null) return 40;
    return 40 + (t / 120) * 700; // maps [0, 120]s to [40, 740]px
  }

  // Mouse move handler for timeline tracking
  onChartMouseMove(event: MouseEvent) {
    const svgElement = event.currentTarget as HTMLElement;
    const rect = svgElement.getBoundingClientRect();
    const x = event.clientX - rect.left;
    
    // Scale X-coordinate back to elapsed second [0, 120]
    const relativeX = (x - 40) / (rect.width - 80); // factor in pad margins
    const calculatedSec = Math.max(0, Math.min(120, Math.round(relativeX * 120)));
    this.hoverTime.set(calculatedSec);
  }

  // Prepares scaled SVG lines for the Power Timeline
  svgLines = computed(() => {
    const traj = this.analysis().trajectory;
    const prop = PROPELLANTS.find(p => p.id === this.activeConfig().propellantId) || PROPELLANTS[0];
    const mdot = this.activeConfig().thrust / (9.80665 * (prop.nominalThrust / (9.80665 * prop.nominalMdot)));
    
    let pathChem = '';
    let pathThrust = '';
    let pathDrag = '';
    let pathGravity = '';
    
    traj.forEach((pt) => {
      const x = 40 + (pt.time / 120) * 700;
      
      const isActive = pt.thrust > 0;
      const pChemical = isActive ? (mdot * prop.specificEnergy) / 1e6 : 0;
      const pThrust = (pt.thrust * pt.velocity) / 1e6;
      const pDrag = (pt.drag * pt.velocity) / 1e6;
      const pGravity = (pt.mass * 9.80665 * pt.velocityY) / 1e6;
      
      // Scale power values (assume max vertical 2400 MW corresponds to y=20px, 0 MW is y=260px)
      const scaleY = (val: number) => {
        const y = 260 - (val / 2400) * 240;
        return Math.max(20, Math.min(260, y));
      };
      
      const yChem = scaleY(pChemical);
      const yThrust = scaleY(pThrust);
      const yDrag = scaleY(pDrag);
      const yGravity = scaleY(pGravity);
      
      if (pt.time === 0) {
        pathChem = `M ${x} ${yChem}`;
        pathThrust = `M ${x} ${yThrust}`;
        pathDrag = `M ${x} ${yDrag}`;
        pathGravity = `M ${x} ${yGravity}`;
      } else {
        pathChem += ` L ${x} ${yChem}`;
        pathThrust += ` L ${x} ${yThrust}`;
        pathDrag += ` L ${x} ${yDrag}`;
        pathGravity += ` L ${x} ${yGravity}`;
      }
    });
    
    return {
      pChem: pathChem,
      pThrust: pathThrust,
      pDrag: pathDrag,
      pGravity: pathGravity
    };
  });

  // Prepares scaled lines for Altitude curves
  altitudeCharts = computed(() => {
    const traj = this.analysis().trajectory;
    let pathKe = '';
    let pathDrag = '';
    let pathGravity = '';
    
    // Limits
    const maxAlt = traj[traj.length - 1].altitude || 1.0;
    
    // Scale helper
    const scaleX = (alt: number) => 40 + (alt / maxAlt) * 700;
    const scaleY = (val: number) => {
      const y = 260 - (val / 1200) * 240; // 1200 MJ limit
      return Math.max(20, Math.min(260, y));
    };
    
    let cumDrag = 0;
    let cumGravity = 0;
    
    traj.forEach((pt, idx) => {
      if (idx > 0) {
        const dt = pt.time - traj[idx-1].time;
        cumDrag += 0.5 * (pt.drag * pt.velocity + traj[idx-1].drag * traj[idx-1].velocity) * dt;
        cumGravity += 0.5 * (pt.mass * 9.80665 * pt.velocityY + traj[idx-1].mass * 9.80665 * traj[idx-1].velocityY) * dt;
      }
      
      const x = scaleX(pt.altitude);
      const ke = 0.5 * pt.mass * pt.velocity * pt.velocity;
      
      const yKe = scaleY(ke / 1e6);
      const yDrag = scaleY(cumDrag / 1e6);
      const yGravity = scaleY(cumGravity / 1e6);
      
      if (idx === 0) {
        pathKe = `M ${x} ${yKe}`;
        pathDrag = `M ${x} ${yDrag}`;
        pathGravity = `M ${x} ${yGravity}`;
      } else {
        pathKe += ` L ${x} ${yKe}`;
        pathDrag += ` L ${x} ${yDrag}`;
        pathGravity += ` L ${x} ${yGravity}`;
      }
    });
    
    return { pKe: pathKe, pDrag: pathDrag, pGravity: pathGravity };
  });

  // Prepares scaled lines for Velocity curves
  velocityCharts = computed(() => {
    const traj = this.analysis().trajectory;
    let pathKe = '';
    let pathDrag = '';
    
    const maxVel = traj[traj.length - 1].velocity || 1.0;
    const scaleX = (vel: number) => 40 + (vel / maxVel) * 700;
    const scaleY = (val: number) => {
      const y = 260 - (val / 1200) * 240; // 1200 MJ limit
      return Math.max(20, Math.min(260, y));
    };
    
    let cumDrag = 0;
    traj.forEach((pt, idx) => {
      if (idx > 0) {
        const dt = pt.time - traj[idx-1].time;
        cumDrag += 0.5 * (pt.drag * pt.velocity + traj[idx-1].drag * traj[idx-1].velocity) * dt;
      }
      
      const x = scaleX(pt.velocity);
      const ke = 0.5 * pt.mass * pt.velocity * pt.velocity;
      
      const yKe = scaleY(ke / 1e6);
      const yDrag = scaleY(cumDrag / 1e6);
      
      if (idx === 0) {
        pathKe = `M ${x} ${yKe}`;
        pathDrag = `M ${x} ${yDrag}`;
      } else {
        pathKe += ` L ${x} ${yKe}`;
        pathDrag += ` L ${x} ${yDrag}`;
      }
    });
    
    return { pKe: pathKe, pDrag: pathDrag };
  });

  // Dynamic SVG path calculator for responsive Sankey
  sankeyPaths = computed(() => {
    const res = this.analysis();
    const total = res.chemicalInputTotalJ / 1e6;
    
    const H_SVG = 260; 
    const scale = (val: number) => (val / total) * H_SVG * 0.82;
    
    const chemBurned = res.chemicalInputBurnedJ / 1e6;
    const chemResidual = res.residualChemicalJ / 1e6;
    const combLoss = res.combustionLossJ / 1e6;
    const nozzleLoss = res.nozzleLossJ / 1e6;
    const plumeResidual = res.exhaustPlumeJ / 1e6;
    const gravityLoss = res.gravityLossJ / 1e6;
    const dragLoss = res.dragLossJ / 1e6;
    const kineticGain = res.kineticGainJ / 1e6;
    const potentialGain = res.potentialGainJ / 1e6;
    
    const h_total = scale(total);
    const h_burned = scale(chemBurned);
    const h_residual = scale(chemResidual);
    const h_comb_loss = scale(combLoss);
    const h_noz_loss = scale(nozzleLoss);
    const h_plume = scale(plumeResidual);
    const h_kinetic = scale(kineticGain);
    const h_potential = scale(potentialGain);
    const h_gravity = scale(gravityLoss);
    const h_drag = scale(dragLoss);
    
    const getRibbon = (x1: number, y1: number, h1: number, x2: number, y2: number, h2: number) => {
      const dx = (x2 - x1) * 0.5;
      return `M ${x1} ${y1} 
              C ${x1 + dx} ${y1}, ${x2 - dx} ${y2}, ${x2} ${y2}
              L ${x2} ${y2 + h2}
              C ${x2 - dx} ${y2 + h2}, ${x1 + dx} ${y1 + h1}, ${x1} ${y1 + h1} Z`;
    };
    
    return {
      h_total,
      h_burned,
      h_residual,
      h_comb_loss,
      h_noz_loss,
      h_plume,
      h_kinetic,
      h_potential,
      h_gravity,
      h_drag,
      paths: [
        { d: getRibbon(40, 20, h_burned, 180, 20, h_burned), fill: 'rgba(6, 182, 212, 0.25)', stroke: '#06B6D4', label: `Reactants Burned (${res.summaryTable[0].percent.toFixed(1)}%)` },
        { d: getRibbon(40, 20 + h_burned, h_residual, 180, 230 - h_residual, h_residual), fill: 'rgba(100, 116, 139, 0.15)', stroke: '#64748B', label: `Stored Residual Propellant (${(chemResidual/total*100).toFixed(1)}%)` },
        { d: getRibbon(180, 20, h_comb_loss, 320, 210, h_comb_loss), fill: 'rgba(239, 68, 68, 0.2)', stroke: '#EF4444', label: `Chamber Thermal Loss (${(combLoss/total*100).toFixed(1)}%)` },
        { d: getRibbon(180, 20 + h_comb_loss, h_burned - h_comb_loss, 360, 20, h_burned - h_comb_loss), fill: 'rgba(6, 182, 212, 0.3)', stroke: '#06B6D4', label: 'Hot Gas Enthalpy' },
        { d: getRibbon(360, 20, h_noz_loss, 480, 210, h_noz_loss), fill: 'rgba(239, 68, 68, 0.25)', stroke: '#EF4444', label: `Nozzle Expansion Loss (${(nozzleLoss/total*100).toFixed(1)}%)` },
        { d: getRibbon(360, 20 + h_noz_loss, h_plume, 560, 180, h_plume), fill: 'rgba(245, 158, 11, 0.2)', stroke: '#F59E0B', label: `Exhaust Plume KE Loss (${(plumeResidual/total*100).toFixed(1)}%)` },
        { d: getRibbon(360, 20 + h_noz_loss + h_plume, h_kinetic + h_potential + h_gravity + h_drag, 560, 20, h_kinetic + h_potential + h_gravity + h_drag), fill: 'rgba(6, 182, 212, 0.4)', stroke: '#06B6D4', label: 'Mechanical Propulsive Thrust' },
        { d: getRibbon(560, 20, h_gravity, 680, 210, h_gravity), fill: 'rgba(239, 68, 68, 0.22)', stroke: '#EF4444', label: `Gravity Vertical Loss (${(gravityLoss/total*100).toFixed(1)}%)` },
        { d: getRibbon(560, 20 + h_gravity, h_drag, 680, 210 + h_gravity, h_drag), fill: 'rgba(239, 68, 68, 0.3)', stroke: '#EF4444', label: `Atmospheric Drag Loss (${(dragLoss/total*100).toFixed(1)}%)` },
        { d: getRibbon(560, 20 + h_gravity + h_drag, h_kinetic, 740, 20, h_kinetic), fill: 'rgba(16, 185, 129, 0.35)', stroke: '#10B981', label: `Useful Kinetic Energy (${(kineticGain/total*100).toFixed(1)}%)` },
        { d: getRibbon(560, 20 + h_gravity + h_drag + h_kinetic, h_potential, 740, 20 + h_kinetic, h_potential), fill: 'rgba(16, 185, 129, 0.25)', stroke: '#10B981', label: `Gravitational Potential Gain (${(potentialGain/total*100).toFixed(1)}%)` }
      ]
    };
  });

  // Monte Carlo distribution bin heights for rendering histogram
  mcHistogramBins = computed(() => {
    const mc = this.mcResults();
    if (!mc || !mc.rawEffs) return [];
    
    const effs: number[] = mc.rawEffs;
    const n = effs.length;
    const binsCount = 24;
    const minVal = effs[0];
    const maxVal = effs[n - 1];
    const binSize = (maxVal - minVal) / binsCount || 0.01;
    
    const bins = new Array(binsCount).fill(0);
    
    effs.forEach((val) => {
      const idx = Math.min(binsCount - 1, Math.floor((val - minVal) / binSize));
      bins[idx]++;
    });
    
    // Normalize heights as percentage of maximum bin count
    const maxBin = Math.max(...bins) || 1.0;
    return bins.map(count => (count / maxBin) * 100);
  });

  // Action: apply selected preset
  applyPreset(id: string) {
    if (id === 'methane_lox') {
      this.configForm.patchValue({
        propellantId: 'methane_lox',
        dryMass: 12000,
        propellantMass: 100000,
        thrust: 1200000,
        combustionEff: 0.98,
        nozzleEff: 0.96,
        Cd: 0.25,
        refArea: 8.0,
        pitchOffset: 0
      });
    } else if (id === 'rp1_lox') {
      this.configForm.patchValue({
        propellantId: 'rp1_lox',
        dryMass: 25000,
        propellantMass: 220000,
        thrust: 2000000,
        combustionEff: 0.97,
        nozzleEff: 0.94,
        Cd: 0.30,
        refArea: 15.0,
        pitchOffset: -2
      });
    } else if (id === 'lh2_lox') {
      this.configForm.patchValue({
        propellantId: 'lh2_lox',
        dryMass: 8000,
        propellantMass: 60000,
        thrust: 800000,
        combustionEff: 0.99,
        nozzleEff: 0.97,
        Cd: 0.35,
        refArea: 12.0,
        pitchOffset: 3
      });
    }
    this.mcResults.set(null);
  }

  // File selection
  onFileSelected(event: Event) {
    const target = event.target as HTMLInputElement;
    const file = target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (e: ProgressEvent<FileReader>) => {
      try {
        const text = e.target?.result as string;
        const parsed = this.parseCSV(text);
        if (parsed && parsed.length > 0) {
          this.uploadedTrajectory.set(parsed);
          this.uploadFileName.set(file.name);
          this.uploadError.set('');
        } else {
          this.uploadError.set('Invalid CSV format. Missing essential numeric columns.');
        }
      } catch (err) {
        console.error(err);
        this.uploadError.set('Error parsing CSV file. Check formatting.');
      }
    };
    reader.readAsText(file);
  }

  // Parse CSV
  parseCSV(text: string): TrajectoryPoint[] | null {
    const lines = text.split('\n').map(l => l.trim()).filter(l => l.length > 0);
    if (lines.length < 2) return null;
    
    const headers = lines[0].split(',').map(h => h.trim().toLowerCase());
    const points: TrajectoryPoint[] = [];
    
    for (let i = 1; i < lines.length; i++) {
      const values = lines[i].split(',').map(v => v.trim());
      const pt: Record<string, number> = {};
      headers.forEach((h, idx) => {
        pt[h] = parseFloat(values[idx]) || 0;
      });
      
      const time = pt['time'] !== undefined ? pt['time'] : i - 1;
      const mass = pt['mass'] !== undefined ? pt['mass'] : 12000;
      const altitude = pt['altitude'] !== undefined ? pt['altitude'] : 0;
      const velocity = pt['velocity'] !== undefined ? pt['velocity'] : 0;
      const velocityY = pt['velocity_vertical'] !== undefined ? pt['velocity_vertical'] : (pt['velocity_y'] !== undefined ? pt['velocity_y'] : velocity * 0.8);
      const thrust = pt['thrust'] !== undefined ? pt['thrust'] : 1200000;
      
      points.push({
        time,
        mass,
        altitude,
        velocity,
        velocityY,
        velocityX: pt['velocity_horizontal'] !== undefined ? pt['velocity_horizontal'] : (pt['velocity_x'] !== undefined ? pt['velocity_x'] : velocity * 0.6),
        thrust,
        drag: pt['drag'] !== undefined ? pt['drag'] : 0,
        gravityForce: pt['gravityforce'] !== undefined ? pt['gravityforce'] : mass * 9.8,
        dynamicPressure: pt['dynamicpressure'] !== undefined ? pt['dynamicpressure'] : 0,
        density: pt['density'] !== undefined ? pt['density'] : 0,
        temperature: pt['temperature'] !== undefined ? pt['temperature'] : 288,
        mach: pt['mach'] !== undefined ? pt['mach'] : 0,
        pitch: pt['pitch'] !== undefined ? pt['pitch'] : Math.PI / 2,
        skinTemp: pt['skin_temp'] !== undefined ? pt['skin_temp'] : 298
      });
    }
    return points;
  }

  clearUploadedTrajectory() {
    this.uploadedTrajectory.set(null);
    this.uploadFileName.set('');
    this.uploadError.set('');
  }

  onMcSamplesChange(event: Event) {
    const target = event.target as HTMLSelectElement;
    this.mcSamples.set(Number(target.value));
  }

  triggerMonteCarlo() {
    this.mcRunning.set(true);
    setTimeout(() => {
      const config = this.activeConfig();
      const sim = this.engine.runMonteCarlo({
        ...config,
        iterations: this.mcSamples()
      });
      this.mcResults.set(sim);
      this.mcRunning.set(false);
    }, 120);
  }

  downloadExampleCSV() {
    const headers = 'time,mass,altitude,velocity,velocity_vertical,thrust,drag,skin_temp\n';
    let content = headers;
    for (let t = 0; t <= 120; t += 10) {
      const mass = Math.round(112000 - 320 * t);
      const alt = Math.round(t * t * 1.5 + t * 40);
      const vel = Math.round(t * 11);
      const velY = Math.round(t * 7);
      const thrust = t < 110 ? 1200000 : 0;
      const drag = Math.round(t < 50 ? t * 400 : 20000 * Math.exp(-alt / 7500));
      const skin = Math.round(290 + t * 4.5);
      content += `${t},${mass},${alt},${vel},${velY},${thrust},${drag},${skin}\n`;
    }
    const blob = new Blob([content], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'newton_baseline_telemetry.csv';
    a.click();
    window.URL.revokeObjectURL(url);
  }

  updateReportMeta(key: string, event: Event) {
    const target = event.target as HTMLInputElement | HTMLTextAreaElement;
    this.reportMetadata.update(prev => ({
      ...prev,
      [key]: target.value
    }));
  }

  todayString() {
    return new Date().toLocaleDateString();
  }

  getVerificationHash() {
    return '8f3b25da1a7c5b36ea7e164f9bf512f4b23c28a8d10b9b3df9e64a10d9fe7b92';
  }

  triggerReportExport() {
    const res = this.analysis();
    const meta = this.reportMetadata();
    
    let doc = `=========================================================================\n`;
    doc += `                    NEWTON ROCKETS LTD. - QUARTO EXPORT                  \n`;
    doc += `=========================================================================\n`;
    doc += `Title:           ${meta.title}\n`;
    doc += `Analyst:         ${meta.analyst}\n`;
    doc += `Classification:  ${meta.classification}\n`;
    doc += `Payload Spec:    ${meta.payloadTarget}\n`;
    doc += `Date:            ${new Date().toISOString()}\n`;
    doc += `-------------------------------------------------------------------------\n\n`;
    doc += `SUMMARY BALANCES\n`;
    doc += `----------------\n`;
    res.summaryTable.forEach(row => {
      doc += `${row.term.padEnd(45)}: ${row.MJ.toFixed(2).padStart(10)} MJ  (${row.percent.toFixed(2)}%)  [${row.fidelity}]\n`;
    });
    doc += `\nBoundary Selected: ${res.systemBoundary.toUpperCase()}\n`;
    doc += `Overall System Efficiency: ${(res.overallEfficiency * 100).toFixed(3)}%\n\n`;
    doc += `Notes:\n${meta.notes}\n`;
    doc += `-------------------------------------------------------------------------\n`;
    doc += `SHA-256 Manifest Verification: SHA-256: ${this.getVerificationHash()}\n`;
    doc += `=========================================================================\n`;

    const blob = new Blob([doc], { type: 'text/plain' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'newton_energy_quarto_report.txt';
    a.click();
    window.URL.revokeObjectURL(url);
  }
}
