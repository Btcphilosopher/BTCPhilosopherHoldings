import React, { useState, useMemo } from 'react';
import { BoosterVehicleConfig, EvaluatedDesign } from './engine/types';
import { BASELINE_BOOSTER_CONFIG, PRESET_CONFIGURATIONS } from './engine/default_config';
import { runCoupledConvergence } from './engine/convergence';
import { generateDesignSpace, extractParetoFront } from './engine/optimizer';

import { TopHeader } from './components/TopHeader';
import { ClassificationBanner } from './components/ClassificationBanner';
import { ActiveDesignOverview } from './components/ActiveDesignOverview';
import { DesignSpaceExplorer } from './components/DesignSpaceExplorer';
import { DigitalTwinSchematic } from './components/DigitalTwinSchematic';
import { TrajectoryCharts } from './components/TrajectoryCharts';
import { SubsystemDeepDive } from './components/SubsystemDeepDive';
import { SensitivityAndUQ } from './components/SensitivityAndUQ';
import { TradeStudiesView } from './components/TradeStudiesView';
import { DesignComparisonMatrix } from './components/DesignComparisonMatrix';
import { AnalyticalValidationView } from './components/AnalyticalValidationView';
import { CliConsole } from './components/CliConsole';
import { EngineeringReportModal } from './components/EngineeringReportModal';
import { ParameterEditorDrawer } from './components/ParameterEditorDrawer';

export function App() {
  const [activeTab, setActiveTab] = useState<string>('cockpit');
  const [currentConfig, setCurrentConfig] = useState<BoosterVehicleConfig>(BASELINE_BOOSTER_CONFIG);
  const [isDrawerOpen, setIsDrawerOpen] = useState<boolean>(false);
  const [isReportOpen, setIsReportOpen] = useState<boolean>(false);
  const [isConverging, setIsConverging] = useState<boolean>(false);

  // Active Evaluated Design
  const activeDesign: EvaluatedDesign = useMemo(() => {
    return runCoupledConvergence(currentConfig);
  }, [currentConfig]);

  // Design space evaluated configurations
  const designSpace: EvaluatedDesign[] = useMemo(() => {
    return generateDesignSpace(currentConfig, 180);
  }, [currentConfig.material, currentConfig.fuelType]);

  // Pareto optimal frontier
  const paretoDesigns: EvaluatedDesign[] = useMemo(() => {
    return extractParetoFront(designSpace);
  }, [designSpace]);

  const handleSelectPreset = (preset: BoosterVehicleConfig) => {
    setIsConverging(true);
    setCurrentConfig(preset);
    setTimeout(() => setIsConverging(false), 80);
  };

  const handleApplyConfig = (newConfig: BoosterVehicleConfig) => {
    setIsConverging(true);
    setCurrentConfig(newConfig);
    setTimeout(() => setIsConverging(false), 80);
  };

  const handleSelectDesignFromSpace = (design: EvaluatedDesign) => {
    setCurrentConfig(design.config);
  };

  return (
    <div className="min-h-screen bg-[#080b11] text-slate-100 flex flex-col selection:bg-cyan-500/30 selection:text-cyan-200">
      {/* Top Bar Contract Navigation */}
      <TopHeader
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        currentConfig={currentConfig}
        onSelectPreset={handleSelectPreset}
        onToggleDrawer={() => setIsDrawerOpen(true)}
        onOpenReport={() => setIsReportOpen(true)}
        isConverging={isConverging}
      />

      {/* Engineering Disclaimer & Provenance Classification Ribbon */}
      <ClassificationBanner
        classification={activeDesign.provenance.classification}
        validationLevel={activeDesign.provenance.validationLevel}
        provenanceHash={activeDesign.provenance.hash}
        isConverged={activeDesign.convergence.isConverged}
        residualKg={activeDesign.convergence.massResidualKg}
      />

      {/* Main Workspace Stage */}
      <main className="flex-1 max-w-[1520px] w-full mx-auto p-4 lg:p-6">
        {activeTab === 'cockpit' && (
          <ActiveDesignOverview
            design={activeDesign}
            totalDesignsEvaluated={designSpace.length}
            paretoCount={paretoDesigns.length}
            onNavigateTab={setActiveTab}
          />
        )}

        {activeTab === 'design-space' && (
          <DesignSpaceExplorer
            designs={designSpace}
            paretoDesigns={paretoDesigns}
            activeDesign={activeDesign}
            onSelectDesign={handleSelectDesignFromSpace}
          />
        )}

        {activeTab === 'digital-twin' && (
          <DigitalTwinSchematic design={activeDesign} />
        )}

        {activeTab === 'trajectory' && (
          <TrajectoryCharts trajectory={activeDesign.trajectory} />
        )}

        {activeTab === 'subsystems' && (
          <SubsystemDeepDive design={activeDesign} />
        )}

        {activeTab === 'sensitivity-uq' && (
          <SensitivityAndUQ design={activeDesign} />
        )}

        {activeTab === 'trade-studies' && (
          <TradeStudiesView design={activeDesign} />
        )}

        {activeTab === 'compare' && (
          <DesignComparisonMatrix
            activeDesign={activeDesign}
            onSelectDesign={handleSelectDesignFromSpace}
          />
        )}

        {activeTab === 'validation' && (
          <AnalyticalValidationView />
        )}

        {activeTab === 'cli' && (
          <CliConsole
            activeDesign={activeDesign}
            onOpenReport={() => setIsReportOpen(true)}
          />
        )}
      </main>

      {/* Engineering Report Modal */}
      <EngineeringReportModal
        isOpen={isReportOpen}
        onClose={() => setIsReportOpen(false)}
        design={activeDesign}
      />

      {/* Parameter Editor Drawer */}
      <ParameterEditorDrawer
        isOpen={isDrawerOpen}
        onClose={() => setIsDrawerOpen(false)}
        config={currentConfig}
        onApplyConfig={handleApplyConfig}
      />

      {/* Quiet Aerospace Footer */}
      <footer className="border-t border-slate-900 bg-[#06080e] px-6 py-3 text-xs text-slate-400 flex flex-wrap items-center justify-between gap-2 font-mono">
        <div className="flex items-center gap-3">
          <span className="text-slate-400 font-bold uppercase font-technical">Newton Rockets Ltd.</span>
          <span>·</span>
          <span>Booster Optimisation Engine Module v3.7.0</span>
          <span>·</span>
          <span>Digital Engineering Platform</span>
        </div>
        <div className="flex items-center gap-4 text-slate-400">
          <span>COUPLED MODELS: CRYOTANK · PROPULSION · STRUCTURES · THERMAL · TRAJECTORY</span>
          <span>·</span>
          <span>NOT FLIGHT CERTIFIED</span>
        </div>
      </footer>
    </div>
  );
}

export default App;
