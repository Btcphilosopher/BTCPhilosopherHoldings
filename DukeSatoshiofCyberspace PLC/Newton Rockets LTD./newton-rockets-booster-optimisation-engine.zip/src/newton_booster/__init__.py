"""
NEWTON ROCKETS LTD.
BOOSTER OPTIMISATION ENGINE
MODULE OF THE NEWTON ROCKETS DIGITAL ENGINEERING PLATFORM
RESEARCH / ENGINEERING SIMULATION — NOT CERTIFICATION
"""

__version__ = "3.7.0"
__author__ = "Newton Rockets Ltd. Propulsion & Flight Sciences Division"

from .configuration.vehicle import BoosterConfiguration
from .mass.budget import MassBudgetEngine
from .propulsion.interface import PropulsionModel
from .aerodynamics.atmosphere import AtmosphericModel
from .aerodynamics.drag import AerodynamicModel
from .trajectory.integrator import TrajectoryIntegrator
from .structures.interface import StructuralModel
from .thermal.interface import ThermalModel
from .recovery.propellant_reserve import RecoveryModel
from .digital_twin.state import BoosterDigitalTwin
from .optimisation.optimizer import BoosterOptimizer

__all__ = [
    "BoosterConfiguration",
    "MassBudgetEngine",
    "PropulsionModel",
    "AtmosphericModel",
    "AerodynamicModel",
    "TrajectoryIntegrator",
    "StructuralModel",
    "ThermalModel",
    "RecoveryModel",
    "BoosterDigitalTwin",
    "BoosterOptimizer",
]
