"""
NEWTON ROCKETS LTD.
BOOSTER OPTIMISATION ENGINE - VEHICLE CONFIGURATION
RESEARCH / ENGINEERING SIMULATION — NOT CERTIFICATION
"""
from dataclasses import dataclass, field
from typing import Dict, Any, Optional

@dataclass
class BoosterConfiguration:
    name: str = "Newton-Heavy-Booster-Block-III"
    vehicle_length: float = 70.0  # meters
    vehicle_diameter: float = 5.2  # meters
    propellant_capacity: float = 480_000.0  # kg
    dry_mass: float = 34_500.0  # kg
    structural_mass: float = 18_200.0  # kg
    tank_mass: float = 12_400.0  # kg
    engine_mass: float = 9_800.0  # kg
    avionics_mass: float = 850.0  # kg
    thermal_protection_mass: float = 1_850.0  # kg
    recovery_mass: float = 3_900.0  # kg
    landing_system_mass: float = 2_200.0  # kg
    reserve_mass: float = 24_000.0  # kg
    engine_count: int = 9
    fuel_type: str = "LCH4"  # LCH4, RP-1, LH2
    oxidizer_type: str = "LOX"
    mixture_ratio: float = 3.45
    chamber_pressure_bar: float = 250.0
    material: str = "Al-Li-2195"  # Al-Li-2195, 304L-Stainless, Carbon-Composite
    provenance_classification: str = "CALIBRATED"
    validation_level: str = "LEVEL 3"

    def to_dict(self) -> Dict[str, Any]:
        return {k: v for k, v in self.__dict__.items()}
