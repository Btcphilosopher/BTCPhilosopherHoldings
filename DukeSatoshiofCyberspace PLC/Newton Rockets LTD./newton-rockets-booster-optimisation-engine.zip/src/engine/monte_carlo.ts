/**
 * NEWTON ROCKETS LTD.
 * MONTE CARLO UNCERTAINTY PROPAGATION ENGINE
 * RESEARCH / ENGINEERING SIMULATION — NOT CERTIFICATION
 */

import { BoosterVehicleConfig, MonteCarloResult } from './types';
import { runCoupledConvergence } from './convergence';

// Standard normal distribution generator via Box-Muller transform
function sampleGaussian(mean: number, stdDev: number): number {
  const u1 = Math.max(1e-8, Math.random());
  const u2 = Math.random();
  const z0 = Math.sqrt(-2.0 * Math.log(u1)) * Math.cos(2.0 * Math.PI * u2);
  return mean + z0 * stdDev;
}

export function runMonteCarloAnalysis(
  baseConfig: BoosterVehicleConfig,
  sampleCount: number = 300
): MonteCarloResult {
  const runs: MonteCarloResult['runs'] = [];

  const dryMassSamples: number[] = [];
  const deltaVSamples: number[] = [];
  const maxQSamples: number[] = [];
  const structMarginSamples: number[] = [];
  const thermalMarginSamples: number[] = [];
  let violationsCount = 0;

  for (let i = 0; i < sampleCount; i++) {
    // Parameter variances based on aerospace manufacturing and test cell tolerances:
    // 1. Structural factor: +/- 3.5% normal variation
    const perturbedStructFactor = Math.max(0.8, sampleGaussian(baseConfig.structuralFactor, 0.035));
    // 2. Engine Isp: +/- 1.2% normal variation
    const perturbedIspVac = sampleGaussian(baseConfig.vacuumIspSec, 3.8);
    const perturbedIspSL = sampleGaussian(baseConfig.seaLevelIspSec, 3.5);
    // 3. Tank pressure: +/- 4%
    const perturbedTankPressure = sampleGaussian(baseConfig.tankPressureBar, 0.12);
    // 4. SOFI thickness: +/- 2.5 mm
    const perturbedSofi = Math.max(10.0, sampleGaussian(baseConfig.sofiInsulationThicknessMm, 2.5));

    const perturbedConfig: BoosterVehicleConfig = {
      ...baseConfig,
      structuralFactor: perturbedStructFactor,
      vacuumIspSec: perturbedIspVac,
      seaLevelIspSec: perturbedIspSL,
      tankPressureBar: perturbedTankPressure,
      sofiInsulationThicknessMm: perturbedSofi,
    };

    const evalResult = runCoupledConvergence(perturbedConfig);

    dryMassSamples.push(evalResult.objectives.dryMassKg);
    deltaVSamples.push(evalResult.objectives.stagingDeltaVMS);
    maxQSamples.push(evalResult.objectives.maxDynamicPressureKPa);
    structMarginSamples.push(evalResult.objectives.structuralMargin);
    thermalMarginSamples.push(evalResult.objectives.thermalMargin);

    if (!evalResult.allConstraintsMet) {
      violationsCount++;
    }

    if (i < 120) {
      runs.push({
        runId: i + 1,
        dryMassKg: evalResult.objectives.dryMassKg,
        stagingDeltaVMS: evalResult.objectives.stagingDeltaVMS,
        maxDynamicPressureKPa: evalResult.objectives.maxDynamicPressureKPa,
        structuralMargin: evalResult.objectives.structuralMargin,
        thermalMargin: evalResult.objectives.thermalMargin,
        allConstraintsMet: evalResult.allConstraintsMet,
      });
    }
  }

  function computeStats(arr: number[]) {
    const sorted = [...arr].sort((a, b) => a - b);
    const mean = sorted.reduce((sum, v) => sum + v, 0) / sorted.length;
    const variance = sorted.reduce((sum, v) => sum + Math.pow(v - mean, 2), 0) / sorted.length;
    const stdDev = Math.sqrt(variance);
    const p10 = sorted[Math.floor(sorted.length * 0.1)];
    const p50 = sorted[Math.floor(sorted.length * 0.5)];
    const p90 = sorted[Math.floor(sorted.length * 0.9)];
    return {
      mean: parseFloat(mean.toFixed(2)),
      stdDev: parseFloat(stdDev.toFixed(2)),
      p10: parseFloat(p10.toFixed(2)),
      p50: parseFloat(p50.toFixed(2)),
      p90: parseFloat(p90.toFixed(2)),
    };
  }

  return {
    sampleCount,
    runs,
    statistics: {
      dryMass: computeStats(dryMassSamples),
      deltaV: computeStats(deltaVSamples),
      maxQ: computeStats(maxQSamples),
      structuralMargin: computeStats(structMarginSamples),
      thermalMargin: computeStats(thermalMarginSamples),
      constraintViolationProbability: parseFloat((violationsCount / sampleCount).toFixed(4)),
    },
  };
}
