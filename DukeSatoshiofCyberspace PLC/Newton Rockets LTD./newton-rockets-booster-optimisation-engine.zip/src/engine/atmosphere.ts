/**
 * NEWTON ROCKETS LTD.
 * 1976 US STANDARD ATMOSPHERIC MODEL & HIGH-FIDELITY THERMODYNAMICS
 * RESEARCH / ENGINEERING SIMULATION — NOT CERTIFICATION
 */

import { AtmosphericState } from './types';

// Physical Constants (CODATA / Standard Atmosphere)
export const R_AIR = 287.05287; // J/(kg*K) Specific gas constant for air
export const G0 = 9.80665; // m/s^2 Standard gravity
export const GAMMA_AIR = 1.40; // Ratio of specific heats
export const SUTHERLAND_C = 120.0; // Sutherland constant (K)
export const SUTHERLAND_MU0 = 1.716e-5; // Reference viscosity (Pa*s)
export const SUTHERLAND_T0 = 273.15; // Reference temperature (K)
export const R_EARTH = 6371000.0; // Earth mean radius (m)

interface Layer {
  hBase: number; // Geopotential base altitude (m)
  tBase: number; // Base temperature (K)
  pBase: number; // Base pressure (Pa)
  lapseRate: number; // K/m
}

const ATMOSPHERE_LAYERS: Layer[] = [
  { hBase: 0, tBase: 288.15, pBase: 101325.0, lapseRate: -0.0065 }, // Troposphere
  { hBase: 11000, tBase: 216.65, pBase: 22632.06, lapseRate: 0.0 }, // Tropopause
  { hBase: 20000, tBase: 216.65, pBase: 5474.889, lapseRate: 0.0010 }, // Stratosphere 1
  { hBase: 32000, tBase: 228.65, pBase: 868.0187, lapseRate: 0.0028 }, // Stratosphere 2
  { hBase: 47000, tBase: 270.65, pBase: 110.9063, lapseRate: 0.0 }, // Stratopause
  { hBase: 51000, tBase: 270.65, pBase: 66.93887, lapseRate: -0.0028 }, // Mesosphere 1
  { hBase: 71000, tBase: 214.65, pBase: 3.956420, lapseRate: -0.0020 }, // Mesosphere 2
  { hBase: 84852, tBase: 186.87, pBase: 0.373400, lapseRate: 0.0 }, // Mesopause / Exosphere cutoff
];

export function getGeopotentialAltitude(geometricAltM: number): number {
  return (R_EARTH * geometricAltM) / (R_EARTH + geometricAltM);
}

export function evaluateAtmosphere(geometricAltitudeM: number): AtmosphericState {
  const alt = Math.max(0, geometricAltitudeM);
  
  if (alt > 120000) {
    // High-altitude vacuum approximation
    const T = 186.87;
    const p = Math.max(1e-7, 0.3734 * Math.exp(-(alt - 84852) / 6000));
    const rho = p / (R_AIR * T);
    return {
      altitudeM: alt,
      temperatureK: T,
      pressurePa: p,
      densityKgM3: rho,
      speedOfSoundMS: Math.sqrt(GAMMA_AIR * R_AIR * T),
      dynamicViscosityPaS: 1e-6,
    };
  }

  const h = getGeopotentialAltitude(alt);
  
  // Find atmospheric layer
  let layerIndex = 0;
  for (let i = ATMOSPHERE_LAYERS.length - 1; i >= 0; i--) {
    if (h >= ATMOSPHERE_LAYERS[i].hBase) {
      layerIndex = i;
      break;
    }
  }

  const layer = ATMOSPHERE_LAYERS[layerIndex];
  const deltaH = h - layer.hBase;
  let temperatureK: number;
  let pressurePa: number;

  if (Math.abs(layer.lapseRate) < 1e-9) {
    // Isothermal layer
    temperatureK = layer.tBase;
    pressurePa = layer.pBase * Math.exp((-G0 * deltaH) / (R_AIR * temperatureK));
  } else {
    // Gradient layer
    temperatureK = layer.tBase + layer.lapseRate * deltaH;
    const exponent = -G0 / (layer.lapseRate * R_AIR);
    pressurePa = layer.pBase * Math.pow(temperatureK / layer.tBase, exponent);
  }

  const densityKgM3 = pressurePa / (R_AIR * temperatureK);
  const speedOfSoundMS = Math.sqrt(GAMMA_AIR * R_AIR * temperatureK);
  
  // Sutherland's formula for dynamic viscosity
  const dynamicViscosityPaS =
    (SUTHERLAND_MU0 * Math.pow(temperatureK / SUTHERLAND_T0, 1.5) * (SUTHERLAND_T0 + SUTHERLAND_C)) /
    (temperatureK + SUTHERLAND_C);

  return {
    altitudeM: alt,
    temperatureK,
    pressurePa,
    densityKgM3,
    speedOfSoundMS,
    dynamicViscosityPaS,
  };
}
