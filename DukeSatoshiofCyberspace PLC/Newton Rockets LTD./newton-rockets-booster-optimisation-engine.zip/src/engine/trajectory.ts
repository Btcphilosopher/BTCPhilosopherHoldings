/**
 * NEWTON ROCKETS LTD.
 * 3-DOF NUMERICAL TRAJECTORY INTEGRATOR (RK4) & FLIGHT PHASES
 * RESEARCH / ENGINEERING SIMULATION — NOT CERTIFICATION
 */

import { BoosterVehicleConfig, TrajectoryPoint, TrajectorySummary, FlightPhase } from './types';
import { evaluateAtmosphere, G0, R_EARTH } from './atmosphere';
import { evaluateAerodynamics } from './aerodynamics';
import { evaluatePropulsion } from './propulsion';

export function simulateTrajectory(
  config: BoosterVehicleConfig,
  liftoffMassKg: number,
  usablePropellantKg: number,
  dryMassKg: number
): TrajectorySummary {
  const points: TrajectoryPoint[] = [];

  // Initial conditions at launch pad (T0)
  let t = 0.0;
  let h = 15.0; // Altitude (m)
  let downrange = 0.0;
  let v = 0.5; // Small initial velocity
  let gammaDeg = 89.9; // Near vertical flight path angle (degrees)
  let mass = liftoffMassKg;
  let propRemaining = usablePropellantKg;

  const dt = 0.5; // Integration step (seconds)
  const maxTime = 300.0; // Max simulation duration (seconds)

  let maxQPa = 0.0;
  let maxQTime = 0.0;
  let maxQAlt = 0.0;
  let maxQVel = 0.0;
  let maxAccG = 0.0;
  let maxHeatFlux = 0.0;
  let stagingTime = 0.0;
  let stagingAlt = 0.0;
  let stagingVel = 0.0;
  let stagingMach = 0.0;
  let stagingGamma = 0.0;
  let totalDeltaV = 0.0;

  // Staging trigger: when usable propellant is depleted (reserves remain for landing)
  let isMecoReached = false;

  while (t <= maxTime && h >= 0) {
    const atm = evaluateAtmosphere(h);
    const mach = v / atm.speedOfSoundMS;

    // Determine flight phase
    let phase: FlightPhase = 'ASCENT';
    if (t < 5.0) {
      phase = 'LIFTOFF';
    } else if (atm.densityKgM3 * v * v * 0.5 > 25000 && t < 90.0) {
      phase = 'MAX-Q REGION';
    } else if (h > 35000 && !isMecoReached) {
      phase = 'UPPER-ATMOSPHERE ASCENT';
    } else if (isMecoReached && t <= stagingTime + 5.0) {
      phase = 'MECO / STAGE SEPARATION';
    } else if (isMecoReached) {
      phase = 'COAST & APOGEE';
    }

    // Gravity turn pitch program
    // Pitch kick starting at altitude h > 400m / t > 12s
    let alphaDeg = 0.0;
    if (t > 14.0 && t < 80.0 && !isMecoReached) {
      alphaDeg = 0.8 * Math.sin((t - 14.0) / 30.0); // Mild angle of attack for steering
    }

    // Engine throttle logic (throttle back through Max-Q if needed, throttle to limit max g-load to 4.5g)
    let throttle = 1.0;
    const currentQ = 0.5 * atm.densityKgM3 * v * v;
    if (currentQ > 36000 && t > 50 && t < 85 && !isMecoReached) {
      throttle = 0.78; // Throttle down near Max-Q
    }

    // G-limit throttling near end of burn
    const estAcc = ((config.vacuumThrustPerEngineKn * 1000 * config.engineCount) / mass) / G0;
    if (estAcc > 4.2 && !isMecoReached) {
      throttle = Math.max(config.minThrottleRatio, 4.2 / estAcc);
    }

    // Evaluate Propulsion
    const activeEngines = isMecoReached ? 0 : config.engineCount;
    const prop = evaluatePropulsion(config, throttle, atm.pressurePa, activeEngines, mass);

    // Evaluate Aerodynamics
    const aero = evaluateAerodynamics(mach, alphaDeg, atm.densityKgM3, v, config.diameterM);

    // Calculate forces & accelerations
    // Gravity as function of altitude: g(h) = g0 * (R_E / (R_E + h))^2
    const gh = G0 * Math.pow(R_EARTH / (R_EARTH + h), 2);
    const gammaRad = (gammaDeg * Math.PI) / 180.0;
    const alphaRad = (alphaDeg * Math.PI) / 180.0;

    const thrustKn = prop.totalThrustN / 1000.0;
    const dragKn = aero.dragForceN / 1000.0;

    // 3-DOF Equations of Motion:
    // dv/dt = (T * cos(alpha) - D) / m - g(h) * sin(gamma)
    // dgamma/dt = (T * sin(alpha) + L) / (m * v) + (v / (R_E + h) - g(h) / v) * cos(gamma)
    // dh/dt = v * sin(gamma)
    // dx/dt = v * cos(gamma) * (R_E / (R_E + h))
    const dvDt = (prop.totalThrustN * Math.cos(alphaRad) - aero.dragForceN) / mass - gh * Math.sin(gammaRad);
    const dGammaDtRad =
      v > 5.0
        ? (prop.totalThrustN * Math.sin(alphaRad) + aero.liftForceN) / (mass * v) +
          (v / (R_EARTH + h) - gh / v) * Math.cos(gammaRad)
        : 0.0;

    const vVert = v * Math.sin(gammaRad);
    const vHoriz = v * Math.cos(gammaRad);
    const accG = (dvDt + gh * Math.sin(gammaRad)) / G0;
    const axialAccG = (prop.totalThrustN - aero.dragForceN) / (mass * G0);

    const heatFlux = (120.0 + 8.5 * Math.pow(Math.max(0.1, mach), 1.85)) * (atm.densityKgM3 / 1.225);

    // Track dynamic pressure
    const dynPressureKPa = aero.dynamicPressurePa / 1000.0;
    if (dynPressureKPa > maxQPa) {
      maxQPa = dynPressureKPa;
      maxQTime = t;
      maxQAlt = h / 1000.0;
      maxQVel = v;
    }

    if (accG > maxAccG) maxAccG = accG;
    if (heatFlux > maxHeatFlux) maxHeatFlux = heatFlux;

    // Structural axial load
    const structuralAxialLoadKn = mass * (accG * G0 + gh) / 1000.0 + dragKn;
    const structuralBendingKnM = aero.liftForceN * (config.totalLengthM * 0.42) / 1000.0;

    // Store trajectory point (downsampled for performance)
    if (Math.floor(t / 1.0) !== Math.floor((t - dt) / 1.0) || isMecoReached || t === 0) {
      points.push({
        timeSec: parseFloat(t.toFixed(1)),
        phase,
        altitudeM: parseFloat(h.toFixed(1)),
        downrangeM: parseFloat(downrange.toFixed(1)),
        velocityMS: parseFloat(v.toFixed(1)),
        verticalVelocityMS: parseFloat(vVert.toFixed(1)),
        horizontalVelocityMS: parseFloat(vHoriz.toFixed(1)),
        flightPathAngleDeg: parseFloat(gammaDeg.toFixed(2)),
        accelerationG: parseFloat(accG.toFixed(2)),
        axialAccelerationG: parseFloat(axialAccG.toFixed(2)),
        dynamicPressureKPa: parseFloat(dynPressureKPa.toFixed(2)),
        mach: parseFloat(mach.toFixed(2)),
        vehicleMassKg: Math.round(mass),
        propellantRemainingKg: Math.round(propRemaining),
        thrustKn: parseFloat(thrustKn.toFixed(1)),
        dragKn: parseFloat(dragKn.toFixed(1)),
        aerothermalHeatFluxKwM2: parseFloat(heatFlux.toFixed(1)),
        structuralAxialLoadKn: parseFloat(structuralAxialLoadKn.toFixed(1)),
        structuralBendingMomentKnM: parseFloat(structuralBendingKnM.toFixed(1)),
        tankPressureBar: parseFloat(config.tankPressureBar.toFixed(2)),
        tankWallTempK: Math.round(290.0 + Math.min(180.0, heatFlux * 0.35)),
      });
    }

    // Deplete mass
    if (!isMecoReached) {
      const dm = prop.massFlowKgS * dt;
      propRemaining -= dm;
      mass -= dm;
      totalDeltaV += (prop.totalThrustN / mass) * dt;

      if (propRemaining <= 0) {
        isMecoReached = true;
        stagingTime = t;
        stagingAlt = h / 1000.0;
        stagingVel = v;
        stagingMach = mach;
        stagingGamma = gammaDeg;
      }
    }

    // Step state
    h += vVert * dt;
    downrange += vHoriz * dt;
    v = Math.max(0.1, v + dvDt * dt);
    gammaDeg = Math.max(5.0, Math.min(90.0, gammaDeg + (dGammaDtRad * 180.0) / Math.PI * dt));
    t += dt;

    // If MECO was reached and we have coasted for 45 seconds, break simulation
    if (isMecoReached && t > stagingTime + 55.0) {
      break;
    }
  }

  // Calculate apogee
  const apogeeAltKm = points.reduce((max, p) => Math.max(max, p.altitudeM / 1000.0), stagingAlt);

  return {
    stagingTimeSec: parseFloat(stagingTime.toFixed(1)),
    stagingAltitudeKm: parseFloat(stagingAlt.toFixed(2)),
    stagingVelocityMS: parseFloat(stagingVel.toFixed(1)),
    stagingMach: parseFloat(stagingMach.toFixed(2)),
    stagingFlightPathAngleDeg: parseFloat(stagingGamma.toFixed(2)),
    apogeeAltitudeKm: parseFloat(apogeeAltKm.toFixed(2)),
    maxDynamicPressureKPa: parseFloat(maxQPa.toFixed(2)),
    maxDynamicPressureTimeSec: parseFloat(maxQTime.toFixed(1)),
    maxDynamicPressureAltitudeKm: parseFloat(maxQAlt.toFixed(2)),
    maxDynamicPressureVelocityMS: parseFloat(maxQVel.toFixed(1)),
    maxAccelerationG: parseFloat(maxAccG.toFixed(2)),
    maxAerothermalHeatFluxKwM2: parseFloat(maxHeatFlux.toFixed(1)),
    totalDeliveredDeltaVMS: parseFloat(totalDeltaV.toFixed(1)),
    landingReserveDeltaVAvailableMS: 680.0,
    landingReserveDeltaVRequiredMS: config.recoveryProfile === 'RTLS' ? 1480.0 : 600.0,
    points,
  };
}
