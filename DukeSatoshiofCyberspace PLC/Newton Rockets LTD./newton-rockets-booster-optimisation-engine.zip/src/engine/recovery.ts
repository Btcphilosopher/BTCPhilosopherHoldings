/**
 * NEWTON ROCKETS LTD.
 * RECOVERY SYSTEM, PROPELLANT RESERVES & FLEET TURNAROUND MODEL
 * RESEARCH / ENGINEERING SIMULATION — NOT CERTIFICATION
 */

import { BoosterVehicleConfig, RecoveryAnalysis } from './types';
import { G0 } from './atmosphere';

export function analyzeRecovery(
  config: BoosterVehicleConfig,
  dryMassKg: number,
  stagingVelocityMS: number,
  stagingAltitudeKm: number
): RecoveryAnalysis {
  if (config.recoveryProfile === 'EXPENDABLE') {
    return {
      profile: 'EXPENDABLE',
      recoveryHardwareMassKg: 0,
      gridFinsMassKg: 0,
      landingLegsMassKg: 0,
      rcsMassKg: 0,
      reservePropellantKg: 0,
      boostbackDeltaVMS: 0,
      reentryDeltaVMS: 0,
      landingDeltaVMS: 0,
      recoveryMarginFraction: 1.0,
      isRecoveryFeasible: true,
      refurbishmentDurationDays: 0,
      estimatedRefurbishmentCostKgbp: 0,
      fatigueCycleDamageAccumulated: 0,
    };
  }

  // Recovery Hardware Sizing:
  // 1. Titanium / Inconel Cast Grid Fins (4 units + hydraulic HPU)
  // Fin area proportional to vehicle cross-section
  const gridFinsMassKg = config.gridFinsCount * (120.0 + config.diameterM * 45.0) * config.structuralFactor;

  // 2. Telescoping Carbon/Aramid Landing Legs with crushable aluminium honeycomb core
  // Typically ~2.8% to 3.5% of booster dry mass
  const landingLegsMassKg = dryMassKg * 0.032 * (config.landingLegsCount / 4.0) * config.structuralFactor;

  // 3. High-pressure Nitrogen / Hot Gas RCS Thruster System
  const rcsMassKg = 180.0 + config.diameterM * 35.0;

  const recoveryHardwareMassKg = gridFinsMassKg + landingLegsMassKg + rcsMassKg;

  // Recovery Delta-V Requirements:
  // RTLS (Return to Launch Site): Needs Boostback burn (~550-750 m/s), Entry burn (~300-450 m/s), Landing burn (~280-340 m/s)
  // ASDS (Autonomous Spaceport Drone Ship / Downrange Barges): No boostback, Entry burn (~220-350 m/s), Landing burn (~280-340 m/s)
  let boostbackDeltaVMS = 0;
  let reentryDeltaVMS = 0;
  let landingDeltaVMS = 310.0;

  if (config.recoveryProfile === 'RTLS') {
    boostbackDeltaVMS = Math.min(850.0, 0.42 * stagingVelocityMS + 220.0);
    reentryDeltaVMS = 380.0;
    landingDeltaVMS = 330.0;
  } else {
    // ASDS Downrange recovery
    boostbackDeltaVMS = 0;
    reentryDeltaVMS = 290.0;
    landingDeltaVMS = 310.0;
  }

  const totalRecoveryDeltaVReqMS = boostbackDeltaVMS + reentryDeltaVMS + landingDeltaVMS;

  // Tsiolkovsky backward calculation to find required reserve propellant mass:
  // Delta_V = Isp_avg * g0 * ln(m_final_with_reserve / m_final_dry)
  const effectiveLandingIspSec = config.seaLevelIspSec * 0.96;
  const massRatioRequired = Math.exp(totalRecoveryDeltaVReqMS / (effectiveLandingIspSec * G0));
  
  const recoveryDryMass = dryMassKg + recoveryHardwareMassKg;
  const requiredPropellantReserveKg = recoveryDryMass * (massRatioRequired - 1.0);

  // Compare against configured reserve
  const allocatedReserveKg = config.reserveFractionReq * 480000; // estimated
  const recoveryMarginFraction = allocatedReserveKg / Math.max(100.0, requiredPropellantReserveKg) - 1.0;
  const isRecoveryFeasible = recoveryMarginFraction >= -0.05;

  // Turnaround model & Fleet Reusability:
  // Inspection, nondestructive testing (NDT), engine turbopump borescope, tile replacement
  const baseTurnaroundDays = config.recoveryProfile === 'RTLS' ? 9.5 : 16.0;
  const refurbishmentDurationDays = Math.max(5.0, baseTurnaroundDays * (config.turnaroundTargetDays / 14.0));
  const estimatedRefurbishmentCostKgbp = 450.0 + (config.engineCount * 45.0) + (refurbishmentDurationDays * 8.5);

  // Cumulative fatigue damage index per flight D = sum(n/N) ~ 0.012 to 0.025 per flight cycle
  const fatigueCycleDamageAccumulated = 0.016;

  return {
    profile: config.recoveryProfile,
    recoveryHardwareMassKg,
    gridFinsMassKg,
    landingLegsMassKg,
    rcsMassKg,
    reservePropellantKg: requiredPropellantReserveKg,
    boostbackDeltaVMS,
    reentryDeltaVMS,
    landingDeltaVMS,
    recoveryMarginFraction,
    isRecoveryFeasible,
    refurbishmentDurationDays,
    estimatedRefurbishmentCostKgbp,
    fatigueCycleDamageAccumulated,
  };
}
