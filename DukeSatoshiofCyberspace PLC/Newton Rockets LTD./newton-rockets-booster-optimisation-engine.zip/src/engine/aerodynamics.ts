/**
 * NEWTON ROCKETS LTD.
 * REDUCED-ORDER AERODYNAMIC COEFFICIENT MODEL & DYNAMIC PRESSURE
 * RESEARCH / ENGINEERING SIMULATION — NOT CERTIFICATION
 */

import { AerodynamicState } from './types';

export function evaluateAerodynamics(
  mach: number,
  angleOgAttackDeg: number,
  densityKgM3: number,
  velocityMS: number,
  diameterM: number
): AerodynamicState {
  const referenceAreaM2 = (Math.PI * Math.pow(diameterM, 2)) / 4.0;
  const dynamicPressurePa = 0.5 * densityKgM3 * Math.pow(velocityMS, 2);

  // Compressible / Transonic Drag Rise Model (Wave Drag Peak):
  // Subsonic: Cd0 ~ 0.22 - 0.26 (skin friction + base drag)
  // Transonic (Mach 0.8 to 1.3): Peak wave drag up to ~0.58 at Mach 1.05
  // Supersonic (Mach 1.3 to 5.0): Decays with 1 / sqrt(M^2 - 1)
  // Hypersonic (Mach > 5.0): Approaches modified Newtonian limit ~0.28
  let cd0 = 0.24;
  if (mach < 0.8) {
    cd0 = 0.22 + 0.03 * Math.pow(mach / 0.8, 2);
  } else if (mach >= 0.8 && mach < 1.05) {
    const t = (mach - 0.8) / 0.25;
    cd0 = 0.25 + 0.33 * (3 * t * t - 2 * t * t * t); // Smooth S-curve peak
  } else if (mach >= 1.05 && mach < 1.5) {
    const t = (mach - 1.05) / 0.45;
    cd0 = 0.58 - 0.16 * t;
  } else if (mach >= 1.5 && mach < 5.0) {
    cd0 = 0.28 + 0.20 / Math.sqrt(Math.max(0.1, mach * mach - 1.0));
  } else {
    cd0 = 0.28;
  }

  // Induced drag & angle of attack dependency
  const alphaRad = (angleOgAttackDeg * Math.PI) / 180.0;
  // Slender body lift curve slope dCL/dalpha ~ 2.0 (per radian) + crossflow drag
  const clAlpha = 1.8 + 0.4 / Math.max(1.0, mach);
  const cl = clAlpha * Math.sin(alphaRad) * Math.cos(alphaRad);
  const inducedDragFactor = 0.85;
  const cd = cd0 + inducedDragFactor * Math.pow(cl, 2) + 0.5 * Math.pow(Math.sin(alphaRad), 3);

  const dragForceN = cd * dynamicPressurePa * referenceAreaM2;
  const liftForceN = cl * dynamicPressurePa * referenceAreaM2;

  return {
    mach,
    angleOgAttackDeg,
    dragCoefficientCd: cd,
    liftCoefficientCl: cl,
    dynamicPressurePa,
    dragForceN,
    liftForceN,
  };
}
