/**
 * NEWTON ROCKETS LTD.
 * MULTI-OBJECTIVE OPTIMISATION ENGINE & DESIGN-SPACE GENERATOR
 * RESEARCH / ENGINEERING SIMULATION — NOT CERTIFICATION
 */

import { BoosterVehicleConfig, EvaluatedDesign } from './types';
import { runCoupledConvergence } from './convergence';

export interface OptimizationVariableBounds {
  diameterM: [number, number];
  lengthM: [number, number];
  engineCount: [number, number];
  tankPressureBar: [number, number];
  structuralFactor: [number, number];
  reserveFraction: [number, number];
  sofiThicknessMm: [number, number];
}

export const DEFAULT_BOUNDS: OptimizationVariableBounds = {
  diameterM: [3.6, 6.4],
  lengthM: [58.0, 78.0],
  engineCount: [7, 11],
  tankPressureBar: [2.2, 4.0],
  structuralFactor: [0.88, 1.25],
  reserveFraction: [0.04, 0.12],
  sofiThicknessMm: [15.0, 45.0],
};

// Check Pareto dominance: Design A dominates Design B if A is <= B on all minimization objectives (and >= on maximization) and strictly better on at least one
export function dominates(a: EvaluatedDesign, b: EvaluatedDesign): boolean {
  // Objectives:
  // 1. Dry mass (minimize)
  // 2. Staging Delta-V (maximize)
  // 3. Max Dynamic Pressure (minimize)
  // 4. Structural Margin (maximize)
  // 5. Turnaround Days (minimize)
  const aBetterOrEqual =
    a.objectives.dryMassKg <= b.objectives.dryMassKg &&
    a.objectives.stagingDeltaVMS >= b.objectives.stagingDeltaVMS &&
    a.objectives.maxDynamicPressureKPa <= b.objectives.maxDynamicPressureKPa &&
    a.objectives.structuralMargin >= b.objectives.structuralMargin &&
    a.objectives.turnaroundDays <= b.objectives.turnaroundDays;

  const aStrictlyBetter =
    a.objectives.dryMassKg < b.objectives.dryMassKg ||
    a.objectives.stagingDeltaVMS > b.objectives.stagingDeltaVMS ||
    a.objectives.maxDynamicPressureKPa < b.objectives.maxDynamicPressureKPa ||
    a.objectives.structuralMargin > b.objectives.structuralMargin ||
    a.objectives.turnaroundDays < b.objectives.turnaroundDays;

  return aBetterOrEqual && aStrictlyBetter;
}

export function extractParetoFront(designs: EvaluatedDesign[]): EvaluatedDesign[] {
  // Only consider designs where all constraints are met for the Pareto frontier
  const validDesigns = designs.filter((d) => d.allConstraintsMet);
  const pareto: EvaluatedDesign[] = [];

  for (let i = 0; i < validDesigns.length; i++) {
    let isDominated = false;
    for (let j = 0; j < validDesigns.length; j++) {
      if (i !== j && dominates(validDesigns[j], validDesigns[i])) {
        isDominated = true;
        break;
      }
    }
    if (!isDominated) {
      pareto.push(validDesigns[i]);
    }
  }

  return pareto.sort((a, b) => a.objectives.dryMassKg - b.objectives.dryMassKg);
}

export function generateDesignSpace(
  baseConfig: BoosterVehicleConfig,
  sampleCount: number = 180,
  bounds: OptimizationVariableBounds = DEFAULT_BOUNDS
): EvaluatedDesign[] {
  const designs: EvaluatedDesign[] = [];

  // 1. Evaluate baseline design first
  const baseline = runCoupledConvergence(baseConfig);
  designs.push(baseline);

  // 2. Systematic Latin-Hypercube / Quasi-Random sampling across design space
  for (let i = 1; i < sampleCount; i++) {
    // Stratified random sampling
    const u1 = (i + Math.random() * 0.8) / sampleCount;
    const u2 = ((i * 7) % sampleCount + Math.random() * 0.8) / sampleCount;
    const u3 = ((i * 13) % sampleCount + Math.random() * 0.8) / sampleCount;
    const u4 = ((i * 19) % sampleCount + Math.random() * 0.8) / sampleCount;
    const u5 = ((i * 23) % sampleCount + Math.random() * 0.8) / sampleCount;
    const u6 = ((i * 31) % sampleCount + Math.random() * 0.8) / sampleCount;

    const diameterM = parseFloat((bounds.diameterM[0] + u1 * (bounds.diameterM[1] - bounds.diameterM[0])).toFixed(2));
    const totalLengthM = parseFloat((bounds.lengthM[0] + u2 * (bounds.lengthM[1] - bounds.lengthM[0])).toFixed(1));
    const rawEngine = Math.round(bounds.engineCount[0] + u3 * (bounds.engineCount[1] - bounds.engineCount[0]));
    // Engine count typically odd or cluster symmetric: 7, 9, 11
    const engineCount = rawEngine % 2 === 0 ? rawEngine + 1 : rawEngine;
    const tankPressureBar = parseFloat(
      (bounds.tankPressureBar[0] + u4 * (bounds.tankPressureBar[1] - bounds.tankPressureBar[0])).toFixed(2)
    );
    const structuralFactor = parseFloat(
      (bounds.structuralFactor[0] + u5 * (bounds.structuralFactor[1] - bounds.structuralFactor[0])).toFixed(3)
    );
    const reserveFractionReq = parseFloat(
      (bounds.reserveFraction[0] + u6 * (bounds.reserveFraction[1] - bounds.reserveFraction[0])).toFixed(4)
    );

    const materials = ['Al-Li-2195', '304L-Stainless', 'Carbon-Composite', 'Al-Li-2195'] as const;
    const material = materials[i % materials.length];

    const candidateConfig: BoosterVehicleConfig = {
      ...baseConfig,
      id: `NR-CFG-${(i + 100).toString()}`,
      name: `Newton Booster Candidate #${i + 1}`,
      diameterM,
      totalLengthM,
      engineCount: Math.max(7, Math.min(11, engineCount)),
      tankPressureBar,
      structuralFactor,
      reserveFractionReq,
      material,
      sofiInsulationThicknessMm: Math.round(bounds.sofiThicknessMm[0] + Math.random() * 25),
      timestamp: new Date().toISOString(),
    };

    const evaluated = runCoupledConvergence(candidateConfig);
    designs.push(evaluated);
  }

  return designs;
}
