/**
 * NEWTON ROCKETS LTD.
 * THERMAL DIGITAL TWIN INTERFACE & AEROTHERMAL ENVIRONMENT
 * RESEARCH / ENGINEERING SIMULATION — NOT CERTIFICATION
 */

import { BoosterVehicleConfig, ThermalAnalysis } from './types';
import { MATERIAL_DATABASE } from './cryotank';

export function analyzeThermalEnvironment(
  config: BoosterVehicleConfig,
  maxMach: number,
  maxDynamicPressureKPa: number,
  ascentDurationSec: number,
  totalWettedAreaM2: number
): ThermalAnalysis {
  const mat = MATERIAL_DATABASE[config.material];

  // Sutton-Graves / Fay-Riddell engineering correlation for peak stagnation point heat flux:
  // q_dot = k_sg * sqrt(rho_inf / R_nose) * v_inf^3
  // Approximate empirical launch vehicle peak heat flux during ascent / re-entry
  const estimatedPeakVelocityMS = Math.min(2400.0, maxMach * 310.0);
  const peakStagnationHeatFluxKwM2 = 120.0 + 8.5 * Math.pow(maxMach, 1.85);

  // Integrated total heat load Q = integral(q_dot dt) ~ 0.45 * q_peak * duration
  const totalIntegratedHeatLoadMjM2 = (0.45 * peakStagnationHeatFluxKwM2 * ascentDurationSec) / 1000.0;

  // Peak skin temperature from Stefan-Boltzmann radiation equilibrium:
  // epsilon * sigma * T_skin^4 = q_dot_effective
  const emissivity = 0.82;
  const sigmaSB = 5.670374419e-8; // W/(m^2 K^4)
  const qAbsorbedW = peakStagnationHeatFluxKwM2 * 1000.0 * 0.65; // Conduction and radiation partition
  const radiativeEqTempK = Math.pow(qAbsorbedW / (emissivity * sigmaSB), 0.25);
  const peakSkinTemperatureK = Math.min(1100.0, radiativeEqTempK);

  // Thermal Protection System (TPS) Sizing:
  // Forward nose, chines, raceway covers, base heat shield around engine cluster
  const baseHeatShieldAreaM2 = Math.PI * Math.pow(config.diameterM / 2.0, 2) * 0.85;
  const racewayAreaM2 = config.totalLengthM * 0.45;
  const tpsAreaM2 = baseHeatShieldAreaM2 + racewayAreaM2;

  // PICA-X / SLA-561V / Cork-Phenolic TPS density ~ 270 kg/m3, average thickness ~ 18mm
  const tpsThicknessM = 0.016;
  const tpsDensityKgM3 = 280.0;
  const tpsMassKg = tpsAreaM2 * tpsThicknessM * tpsDensityKgM3 * config.structuralFactor;

  // Thermal margin of safety: MS_thermal = (T_limit / (1.15 * T_skin)) - 1.0
  const materialTemperatureLimitK = mat.maxOperatingTempK;
  // If stainless steel, material limit is 820K; if Al-Li, 395K (requiring external cork/paint)
  const effectiveSkinUnderTpsK = config.material === '304L-Stainless' ? peakSkinTemperatureK * 0.85 : 340.0;
  const thermalMarginOfSafety = (materialTemperatureLimitK / (1.15 * effectiveSkinUnderTpsK)) - 1.0;

  // SOFI cryogenic boil-off
  const sofiMassKg = (totalWettedAreaM2 * (config.sofiInsulationThicknessMm / 1000.0)) * 34.0;
  const boilOffRateKgPerHr = 42.0 * (25.0 / Math.max(5.0, config.sofiInsulationThicknessMm));
  const totalBoilOffMassKg = boilOffRateKgPerHr * (ascentDurationSec / 3600.0 + 0.5);

  return {
    peakStagnationHeatFluxKwM2,
    totalIntegratedHeatLoadMjM2,
    peakSkinTemperatureK: effectiveSkinUnderTpsK,
    materialTemperatureLimitK,
    thermalMarginOfSafety,
    sofiInsulationMassKg: sofiMassKg,
    cryoBoilOffRateKgPerHr: boilOffRateKgPerHr,
    totalBoilOffMassKg,
    tpsMassKg,
  };
}
