/**
 * NEWTON ROCKETS LTD.
 * CRYOTANK DIGITAL TWIN INTERFACE & THERMODYNAMIC SIZING MODEL
 * RESEARCH / ENGINEERING SIMULATION — NOT CERTIFICATION
 */

import { BoosterVehicleConfig, StructuralMaterial, FuelType } from './types';

export interface MaterialProperties {
  densityKgM3: number;
  yieldStrengthMpa: number;
  ultimateStrengthMpa: number;
  elasticModulusGpa: number;
  poissonRatio: number;
  maxOperatingTempK: number;
  weldEfficiency: number;
}

export const MATERIAL_DATABASE: Record<StructuralMaterial, MaterialProperties> = {
  'Al-Li-2195': {
    densityKgM3: 2710.0,
    yieldStrengthMpa: 560.0,
    ultimateStrengthMpa: 590.0,
    elasticModulusGpa: 76.0,
    poissonRatio: 0.33,
    maxOperatingTempK: 395.0, // ~120 C
    weldEfficiency: 0.85,
  },
  '304L-Stainless': {
    densityKgM3: 7900.0,
    yieldStrengthMpa: 310.0,
    ultimateStrengthMpa: 620.0,
    elasticModulusGpa: 193.0,
    poissonRatio: 0.29,
    maxOperatingTempK: 820.0, // ~550 C
    weldEfficiency: 0.90,
  },
  'Carbon-Composite': {
    densityKgM3: 1550.0,
    yieldStrengthMpa: 950.0,
    ultimateStrengthMpa: 1200.0,
    elasticModulusGpa: 130.0,
    poissonRatio: 0.28,
    maxOperatingTempK: 420.0,
    weldEfficiency: 0.80,
  },
  'Ti-6Al-4V': {
    densityKgM3: 4430.0,
    yieldStrengthMpa: 880.0,
    ultimateStrengthMpa: 950.0,
    elasticModulusGpa: 114.0,
    poissonRatio: 0.34,
    maxOperatingTempK: 670.0,
    weldEfficiency: 0.85,
  },
};

export const PROPELLANT_PROPERTIES: Record<FuelType | 'LOX', { densityKgM3: number; boilingTempK: number; latentHeatJouleKg: number }> = {
  'LOX': { densityKgM3: 1141.0, boilingTempK: 90.2, latentHeatJouleKg: 213000 },
  'LCH4': { densityKgM3: 422.6, boilingTempK: 111.6, latentHeatJouleKg: 510000 },
  'RP-1': { densityKgM3: 810.0, boilingTempK: 489.0, latentHeatJouleKg: 300000 },
  'LH2': { densityKgM3: 70.85, boilingTempK: 20.3, latentHeatJouleKg: 446000 },
};

export interface CryotankAnalysisResult {
  loxTankLengthM: number;
  fuelTankLengthM: number;
  intertankLengthM: number;
  loxVolumeM3: number;
  fuelVolumeM3: number;
  loxMassKg: number;
  fuelMassKg: number;
  totalPropellantMassKg: number;
  usablePropellantKg: number;
  reservePropellantKg: number;
  unusablePropellantKg: number;
  loxTankDryMassKg: number;
  fuelTankDryMassKg: number;
  intertankDryMassKg: number;
  bafflesSloshMassKg: number;
  sofiInsulationMassKg: number;
  totalTankSystemMassKg: number;
  boilOffRateKgPerHr: number;
  hoopStressMpa: number;
  tankWallThicknessMm: number;
}

export function analyzeCryotank(config: BoosterVehicleConfig, propellantCapacityKg: number): CryotankAnalysisResult {
  const mat = MATERIAL_DATABASE[config.material];
  const loxProps = PROPELLANT_PROPERTIES.LOX;
  const fuelProps = PROPELLANT_PROPERTIES[config.fuelType];

  const MR = config.mixtureRatio;
  const loxMass = (MR / (MR + 1.0)) * propellantCapacityKg;
  const fuelMass = (1.0 / (MR + 1.0)) * propellantCapacityKg;

  const unusableFraction = 0.012; // 1.2% unusable residuals
  const unusablePropellant = propellantCapacityKg * unusableFraction;
  const reservePropellant = propellantCapacityKg * config.reserveFractionReq;
  const usablePropellant = propellantCapacityKg - unusablePropellant - reservePropellant;

  // Volumes with ullage
  const loxVolumeM3 = (loxMass / loxProps.densityKgM3) * (1.0 + config.ullageFraction);
  const fuelVolumeM3 = (fuelMass / fuelProps.densityKgM3) * (1.0 + config.ullageFraction);

  const radius = config.diameterM / 2.0;
  const crossSectionArea = Math.PI * radius * radius;

  // ASME 2:1 Ellipsoidal Dome Geometry:
  // Dome height h_dome = radius / 2.0
  // Dome volume V_dome = (2/3) * pi * radius^2 * (radius / 2) = (1/3) * pi * radius^3
  // Surface area of 2:1 dome ~ 1.084 * pi * radius^2
  const hDome = radius / 2.0;
  const vDome = (1.0 / 3.0) * Math.PI * Math.pow(radius, 3);
  const areaDome = 1.084 * Math.PI * radius * radius;

  // Calculate cylinder barrel lengths
  const loxCylVolume = Math.max(0, loxVolumeM3 - 2 * vDome);
  const loxBarrelLength = loxCylVolume / crossSectionArea;
  const loxTankLength = loxBarrelLength + 2 * hDome;

  const fuelCylVolume = Math.max(0, fuelVolumeM3 - 2 * vDome);
  const fuelBarrelLength = fuelCylVolume / crossSectionArea;
  const fuelTankLength = fuelBarrelLength + 2 * hDome;

  // Intertank section between fuel and LOX (or common bulkhead transition)
  const intertankLength = Math.max(1.5, config.diameterM * 0.45);

  // Pressure vessel wall sizing:
  // Design burst pressure = 1.4 * Proof = 1.4 * 1.05 * Tank Operating Pressure
  const pOperatingPa = config.tankPressureBar * 100000.0;
  const pDesignPa = 1.4 * pOperatingPa;
  
  // Thin-walled cylinder hoop stress: t = (p * r) / (sigma_allow * e_weld)
  const allowableStressPa = (mat.yieldStrengthMpa * 1e6) / 1.25; // 1.25 safety factor
  const minGageMm = config.material === '304L-Stainless' ? 3.5 : 2.4;
  const reqThicknessCylM = (pDesignPa * radius) / (allowableStressPa * mat.weldEfficiency);
  const tankWallThicknessMm = Math.max(minGageMm, reqThicknessCylM * 1000.0);
  const tM = tankWallThicknessMm / 1000.0;

  // Surface areas
  const loxCylArea = 2.0 * Math.PI * radius * loxBarrelLength;
  const fuelCylArea = 2.0 * Math.PI * radius * fuelBarrelLength;
  const totalLoxArea = loxCylArea + 2 * areaDome;
  const totalFuelArea = fuelCylArea + 2 * areaDome;

  // Component masses (including 1.12 factor for weld lands, flanges, and rings)
  const weldLandFactor = 1.12;
  const loxTankDryMassKg = totalLoxArea * tM * mat.densityKgM3 * weldLandFactor * config.structuralFactor;
  const fuelTankDryMassKg = totalFuelArea * tM * mat.densityKgM3 * weldLandFactor * config.structuralFactor;

  // Intertank is unpressurized cylindrical shell subject to compressive buckling
  const intertankArea = 2.0 * Math.PI * radius * intertankLength;
  const intertankThicknessM = Math.max(tM * 1.15, 0.0035);
  const intertankDryMassKg = intertankArea * intertankThicknessM * mat.densityKgM3 * 1.15 * config.structuralFactor;

  // Anti-slosh baffles and vortex suppressors (approx 1.5% of total tank dry mass)
  const bafflesSloshMassKg = (loxTankDryMassKg + fuelTankDryMassKg) * 0.022;

  // Thermal insulation (SOFI - Spray-On Foam Insulation: density ~32 kg/m3, thickness ~25mm)
  const sofiThicknessM = config.sofiInsulationThicknessMm / 1000.0;
  const sofiDensityKgM3 = 34.0;
  const insulatedArea = totalLoxArea + (config.fuelType === 'LCH4' || config.fuelType === 'LH2' ? totalFuelArea : 0);
  const sofiInsulationMassKg = insulatedArea * sofiThicknessM * sofiDensityKgM3;

  // Boil-off estimation: k_foam ~ 0.022 W/(m*K)
  const kFoam = 0.024;
  const deltaT = 295.0 - loxProps.boilingTempK; // Ambient 22C to LOX
  const heatLeakWatts = (kFoam * insulatedArea * deltaT) / Math.max(0.005, sofiThicknessM);
  const boilOffKgPerSec = heatLeakWatts / loxProps.latentHeatJouleKg;
  const boilOffRateKgPerHr = boilOffKgPerSec * 3600.0;

  const totalTankSystemMassKg =
    loxTankDryMassKg +
    fuelTankDryMassKg +
    intertankDryMassKg +
    bafflesSloshMassKg +
    sofiInsulationMassKg;

  const hoopStressMpa = (pOperatingPa * radius) / (tM * 1e6);

  return {
    loxTankLengthM: loxTankLength,
    fuelTankLengthM: fuelTankLength,
    intertankLengthM: intertankLength,
    loxVolumeM3,
    fuelVolumeM3,
    loxMassKg: loxMass,
    fuelMassKg: fuelMass,
    totalPropellantMassKg: propellantCapacityKg,
    usablePropellantKg: usablePropellant,
    reservePropellantKg: reservePropellant,
    unusablePropellantKg: unusablePropellant,
    loxTankDryMassKg,
    fuelTankDryMassKg,
    intertankDryMassKg,
    bafflesSloshMassKg,
    sofiInsulationMassKg,
    totalTankSystemMassKg,
    boilOffRateKgPerHr,
    hoopStressMpa,
    tankWallThicknessMm,
  };
}
