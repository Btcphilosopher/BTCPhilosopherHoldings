/**
 * NEWTON ROCKETS LTD.
 * BOOSTER OPTIMISATION ENGINE - CORE TYPES & DATA CONTRACTS
 * RESEARCH / ENGINEERING SIMULATION — NOT CERTIFICATION
 */

export type DataClassification =
  | 'THEORETICAL'
  | 'REFERENCE'
  | 'ASSUMED'
  | 'MEASURED'
  | 'CALIBRATED'
  | 'VALIDATED'
  | 'QUALIFIED';

export type ValidationLevel =
  | 'LEVEL 0: Unit Verification'
  | 'LEVEL 1: Analytical Model Verification'
  | 'LEVEL 2: Subsystem Validation'
  | 'LEVEL 3: Integrated Digital-Twin Validation'
  | 'LEVEL 4: Experimental Correlation'
  | 'LEVEL 5: Operational Flight Validation';

export type FuelType = 'LCH4' | 'RP-1' | 'LH2';
export type OxidizerType = 'LOX';
export type StructuralMaterial = 'Al-Li-2195' | '304L-Stainless' | 'Carbon-Composite' | 'Ti-6Al-4V';
export type RecoveryProfile = 'RTLS' | 'ASDS' | 'EXPENDABLE';

export type FlightPhase =
  | 'PRELAUNCH'
  | 'LIFTOFF'
  | 'ASCENT'
  | 'MAX-Q REGION'
  | 'UPPER-ATMOSPHERE ASCENT'
  | 'PROPULSION TRANSITION'
  | 'MECO / STAGE SEPARATION'
  | 'BOOSTBACK BURN'
  | 'COAST & APOGEE'
  | 'RE-ENTRY BURN'
  | 'AERODYNAMIC GUIDANCE'
  | 'TERMINAL LANDING BURN'
  | 'TOUCHDOWN';

export interface MassComponent {
  name: string;
  category: 'propellant' | 'tanks' | 'propulsion' | 'structures' | 'avionics' | 'thermal' | 'recovery' | 'reserves';
  massKg: number;
  uncertaintyKg: number;
  source: string;
  model: string;
  confidence: number; // 0.0 - 1.0
  classification: DataClassification;
  subcomponents?: MassComponent[];
}

export interface MassBudget {
  totalLiftoffMassKg: number;
  totalDryMassKg: number;
  propellantMassKg: number;
  usablePropellantKg: number;
  reservePropellantKg: number;
  unusablePropellantKg: number;
  tankMassKg: number;
  propulsionMassKg: number;
  primaryStructureMassKg: number;
  secondaryStructureMassKg: number;
  avionicsMassKg: number;
  thermalProtectionMassKg: number;
  recoveryHardwareMassKg: number;
  massClosureResidualKg: number;
  fractions: {
    propellantFraction: number;
    dryMassFraction: number;
    structuralFraction: number;
    propulsionFraction: number;
    recoveryFraction: number;
    reserveFraction: number;
  };
  components: MassComponent[];
}

export interface BoosterVehicleConfig {
  id: string;
  name: string;
  version: string;
  diameterM: number;
  totalLengthM: number;
  fuelType: FuelType;
  oxidizerType: OxidizerType;
  mixtureRatio: number; // O/F
  material: StructuralMaterial;
  tankPressureBar: number;
  ullageFraction: number; // e.g. 0.04
  sofiInsulationThicknessMm: number;
  engineCount: number;
  engineName: string;
  seaLevelThrustPerEngineKn: number;
  vacuumThrustPerEngineKn: number;
  seaLevelIspSec: number;
  vacuumIspSec: number;
  engineMassPerUnitKg: number;
  minThrottleRatio: number;
  maxThrottleRatio: number;
  structuralFactor: number; // multiplier on sizing
  recoveryProfile: RecoveryProfile;
  gridFinsCount: number;
  landingLegsCount: number;
  reserveFractionReq: number; // fraction of propellant reserved
  turnaroundTargetDays: number;
  classification: DataClassification;
  validationLevel: ValidationLevel;
  timestamp: string;
}

export interface AtmosphericState {
  altitudeM: number;
  temperatureK: number;
  pressurePa: number;
  densityKgM3: number;
  speedOfSoundMS: number;
  dynamicViscosityPaS: number;
}

export interface AerodynamicState {
  mach: number;
  angleOgAttackDeg: number;
  dragCoefficientCd: number;
  liftCoefficientCl: number;
  dynamicPressurePa: number;
  dragForceN: number;
  liftForceN: number;
}

export interface PropulsionState {
  engineCount: number;
  activeEngines: number;
  throttle: number;
  totalThrustN: number;
  effectiveIspSec: number;
  massFlowKgS: number;
  fuelFlowKgS: number;
  oxFlowKgS: number;
}

export interface TrajectoryPoint {
  timeSec: number;
  phase: FlightPhase;
  altitudeM: number;
  downrangeM: number;
  velocityMS: number;
  verticalVelocityMS: number;
  horizontalVelocityMS: number;
  flightPathAngleDeg: number;
  accelerationG: number;
  axialAccelerationG: number;
  dynamicPressureKPa: number;
  mach: number;
  vehicleMassKg: number;
  propellantRemainingKg: number;
  thrustKn: number;
  dragKn: number;
  aerothermalHeatFluxKwM2: number;
  structuralAxialLoadKn: number;
  structuralBendingMomentKnM: number;
  tankPressureBar: number;
  tankWallTempK: number;
}

export interface TrajectorySummary {
  stagingTimeSec: number;
  stagingAltitudeKm: number;
  stagingVelocityMS: number;
  stagingMach: number;
  stagingFlightPathAngleDeg: number;
  apogeeAltitudeKm: number;
  maxDynamicPressureKPa: number;
  maxDynamicPressureTimeSec: number;
  maxDynamicPressureAltitudeKm: number;
  maxDynamicPressureVelocityMS: number;
  maxAccelerationG: number;
  maxAerothermalHeatFluxKwM2: number;
  totalDeliveredDeltaVMS: number;
  landingReserveDeltaVAvailableMS: number;
  landingReserveDeltaVRequiredMS: number;
  points: TrajectoryPoint[];
}

export interface StructuralAnalysis {
  allowableAxialStressMpa: number;
  appliedAxialStressMpa: number;
  compressiveBucklingCapacityKn: number;
  appliedCompressiveLoadKn: number;
  hoopStressMpa: number;
  yieldStrengthMpa: number;
  structuralMarginOfSafety: number;
  bucklingMarginOfSafety: number;
  tensileMarginOfSafety: number;
  primaryStructureMassKg: number;
  secondaryStructureMassKg: number;
  isogridMassMultiplier: number;
}

export interface ThermalAnalysis {
  peakStagnationHeatFluxKwM2: number;
  totalIntegratedHeatLoadMjM2: number;
  peakSkinTemperatureK: number;
  materialTemperatureLimitK: number;
  thermalMarginOfSafety: number;
  sofiInsulationMassKg: number;
  cryoBoilOffRateKgPerHr: number;
  totalBoilOffMassKg: number;
  tpsMassKg: number;
}

export interface RecoveryAnalysis {
  profile: RecoveryProfile;
  recoveryHardwareMassKg: number;
  gridFinsMassKg: number;
  landingLegsMassKg: number;
  rcsMassKg: number;
  reservePropellantKg: number;
  boostbackDeltaVMS: number;
  reentryDeltaVMS: number;
  landingDeltaVMS: number;
  recoveryMarginFraction: number;
  isRecoveryFeasible: boolean;
  refurbishmentDurationDays: number;
  estimatedRefurbishmentCostKgbp: number;
  fatigueCycleDamageAccumulated: number;
}

export interface DesignConstraint {
  id: string;
  name: string;
  category: 'structure' | 'aero' | 'thermal' | 'propulsion' | 'recovery' | 'mass';
  value: number;
  limit: number;
  isUpperBound: boolean;
  unit: string;
  margin: number;
  isViolated: boolean;
}

export interface ConvergenceState {
  isConverged: boolean;
  iterations: number;
  massResidualKg: number;
  structuralResidualKg: number;
  thermalResidualKg: number;
  trajectoryResidualMS: number;
  history: Array<{
    iteration: number;
    dryMassKg: number;
    structuralMassKg: number;
    maxDynamicPressureKPa: number;
    massDeltaKg: number;
  }>;
}

export interface EvaluatedDesign {
  id: string;
  name: string;
  config: BoosterVehicleConfig;
  massBudget: MassBudget;
  trajectory: TrajectorySummary;
  structures: StructuralAnalysis;
  thermal: ThermalAnalysis;
  recovery: RecoveryAnalysis;
  convergence: ConvergenceState;
  constraints: DesignConstraint[];
  allConstraintsMet: boolean;
  objectives: {
    dryMassKg: number;
    stagingDeltaVMS: number;
    maxDynamicPressureKPa: number;
    structuralMargin: number;
    thermalMargin: number;
    recoveryReserveKg: number;
    turnaroundDays: number;
    estimatedCostKgbp: number;
    robustnessIndex: number; // 0.0 - 1.0
  };
  provenance: {
    hash: string;
    timestamp: string;
    modelVersions: Record<string, string>;
    classification: DataClassification;
    validationLevel: ValidationLevel;
  };
}

export interface SobolSensitivityResult {
  parameterName: string;
  firstOrderIndex: number; // S_i
  totalOrderIndex: number; // S_Ti
  confidenceInterval: [number, number];
}

export interface MonteCarloResult {
  sampleCount: number;
  runs: Array<{
    runId: number;
    dryMassKg: number;
    stagingDeltaVMS: number;
    maxDynamicPressureKPa: number;
    structuralMargin: number;
    thermalMargin: number;
    allConstraintsMet: boolean;
  }>;
  statistics: {
    dryMass: { mean: number; stdDev: number; p10: number; p50: number; p90: number };
    deltaV: { mean: number; stdDev: number; p10: number; p50: number; p90: number };
    maxQ: { mean: number; stdDev: number; p10: number; p50: number; p90: number };
    structuralMargin: { mean: number; stdDev: number; p10: number; p50: number; p90: number };
    thermalMargin: { mean: number; stdDev: number; p10: number; p50: number; p90: number };
    constraintViolationProbability: number;
  };
}

export interface TradeStudyPoint {
  parameterValue: number;
  dryMassKg: number;
  stagingDeltaVMS: number;
  maxDynamicPressureKPa: number;
  structuralMargin: number;
  thermalMargin: number;
  payloadEquivalentKg: number;
  isFeasible: boolean;
}

export interface TradeStudy {
  id: string;
  title: string;
  description: string;
  parameterName: string;
  parameterUnit: string;
  points: TradeStudyPoint[];
  baselineValue: number;
  insights: string[];
}
