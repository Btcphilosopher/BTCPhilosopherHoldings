/**
 * NEWTON ROCKETS LTD.
 * AUTOMATED MULTI-PARAMETRIC ENGINEERING TRADE STUDIES
 * RESEARCH / ENGINEERING SIMULATION — NOT CERTIFICATION
 */

import { BoosterVehicleConfig, TradeStudy, TradeStudyPoint } from './types';
import { runCoupledConvergence } from './convergence';

export function runDiameterTradeStudy(baseConfig: BoosterVehicleConfig): TradeStudy {
  const points: TradeStudyPoint[] = [];
  const diameters = [3.8, 4.2, 4.6, 5.0, 5.2, 5.6, 6.0, 6.5];

  for (const d of diameters) {
    const config: BoosterVehicleConfig = { ...baseConfig, diameterM: d };
    const evalRes = runCoupledConvergence(config);
    points.push({
      parameterValue: d,
      dryMassKg: evalRes.objectives.dryMassKg,
      stagingDeltaVMS: evalRes.objectives.stagingDeltaVMS,
      maxDynamicPressureKPa: evalRes.objectives.maxDynamicPressureKPa,
      structuralMargin: evalRes.objectives.structuralMargin,
      thermalMargin: evalRes.objectives.thermalMargin,
      payloadEquivalentKg: Math.round((evalRes.objectives.stagingDeltaVMS - 2100) * 8.2),
      isFeasible: evalRes.allConstraintsMet,
    });
  }

  return {
    id: 'ts_diameter',
    title: 'Vehicle Diameter Trade Study',
    description: 'Investigates booster diameter scaling on aerodynamic frontal area, transonic wave drag, and compressive shell buckling margins.',
    parameterName: 'Booster Diameter',
    parameterUnit: 'm',
    points,
    baselineValue: baseConfig.diameterM,
    insights: [
      'Slender configurations (D < 4.2m) suffer severe compressive buckling penalties, requiring thicker skins and higher structural mass.',
      'Larger diameters (D > 5.8m) incur higher transonic wave drag during Max-Q but benefit from shorter tank barrels and superior dome-to-cylinder volume ratios.',
      'Optimal system-level trade space sits at 5.0m - 5.4m for 9-engine staged combustion architectures.',
    ],
  };
}

export function runPropellantReserveTradeStudy(baseConfig: BoosterVehicleConfig): TradeStudy {
  const points: TradeStudyPoint[] = [];
  const reserves = [0.03, 0.05, 0.07, 0.09, 0.11, 0.13, 0.15];

  for (const r of reserves) {
    const config: BoosterVehicleConfig = { ...baseConfig, reserveFractionReq: r };
    const evalRes = runCoupledConvergence(config);
    points.push({
      parameterValue: parseFloat((r * 100).toFixed(1)),
      dryMassKg: evalRes.objectives.dryMassKg,
      stagingDeltaVMS: evalRes.objectives.stagingDeltaVMS,
      maxDynamicPressureKPa: evalRes.objectives.maxDynamicPressureKPa,
      structuralMargin: evalRes.objectives.structuralMargin,
      thermalMargin: evalRes.objectives.thermalMargin,
      payloadEquivalentKg: Math.round((evalRes.objectives.stagingDeltaVMS - 2100) * 8.2),
      isFeasible: evalRes.allConstraintsMet,
    });
  }

  return {
    id: 'ts_recovery_reserve',
    title: 'Recovery Reserve vs Staging Performance',
    description: 'Quantifies the direct staging velocity and net payload penalty of allocating landing reserve propellant for reusable profiles (RTLS vs ASDS).',
    parameterName: 'Landing Reserve Fraction',
    parameterUnit: '%',
    points,
    baselineValue: baseConfig.reserveFractionReq * 100,
    insights: [
      'Every 1.0% increase in propellant reserve reduces booster burnout velocity by ~42 m/s (~340 kg equivalent payload to LEO).',
      'Downrange ASDS landings require 4.5% to 6.2% reserve, preserving 85% of expendable capacity.',
      'Return to Launch Site (RTLS) demands 10.5% to 13.0% reserve due to the energetic 3-burn boostback profile.',
    ],
  };
}

export function runStructuralFactorTradeStudy(baseConfig: BoosterVehicleConfig): TradeStudy {
  const points: TradeStudyPoint[] = [];
  const factors = [0.90, 0.95, 1.00, 1.05, 1.10, 1.15, 1.20, 1.25];

  for (const k of factors) {
    const config: BoosterVehicleConfig = { ...baseConfig, structuralFactor: k };
    const evalRes = runCoupledConvergence(config);
    points.push({
      parameterValue: k,
      dryMassKg: evalRes.objectives.dryMassKg,
      stagingDeltaVMS: evalRes.objectives.stagingDeltaVMS,
      maxDynamicPressureKPa: evalRes.objectives.maxDynamicPressureKPa,
      structuralMargin: evalRes.objectives.structuralMargin,
      thermalMargin: evalRes.objectives.thermalMargin,
      payloadEquivalentKg: Math.round((evalRes.objectives.stagingDeltaVMS - 2100) * 8.2),
      isFeasible: evalRes.allConstraintsMet,
    });
  }

  return {
    id: 'ts_structural_factor',
    title: 'Structural Mass Margin vs Load Safety Factor',
    description: 'Evaluates structural mass growth against minimum margin of safety under maximum combined aerodynamic and thrust loads.',
    parameterName: 'Structural Knockdown Factor',
    parameterUnit: '-',
    points,
    baselineValue: baseConfig.structuralFactor,
    insights: [
      'Operating below k_struct = 0.95 violates the mandatory 15% structural safety margin (MS < 0.15) under peak 4.2g axial acceleration.',
      'Structural growth factor exhibits near-linear dry mass sensitivity: +0.05 k_struct adds ~1,750 kg dry mass.',
      'Isogrid rib optimization can maintain 22% structural margin at k_struct = 1.02 without compromising flight fatigue life.',
    ],
  };
}

export function runSofiThicknessTradeStudy(baseConfig: BoosterVehicleConfig): TradeStudy {
  const points: TradeStudyPoint[] = [];
  const thicknesses = [12, 18, 25, 32, 40, 50];

  for (const t of thicknesses) {
    const config: BoosterVehicleConfig = { ...baseConfig, sofiInsulationThicknessMm: t };
    const evalRes = runCoupledConvergence(config);
    points.push({
      parameterValue: t,
      dryMassKg: evalRes.objectives.dryMassKg,
      stagingDeltaVMS: evalRes.objectives.stagingDeltaVMS,
      maxDynamicPressureKPa: evalRes.objectives.maxDynamicPressureKPa,
      structuralMargin: evalRes.objectives.structuralMargin,
      thermalMargin: evalRes.objectives.thermalMargin,
      payloadEquivalentKg: Math.round((evalRes.objectives.stagingDeltaVMS - 2100) * 8.2),
      isFeasible: evalRes.allConstraintsMet,
    });
  }

  return {
    id: 'ts_sofi',
    title: 'SOFI Insulation Thickness vs Cryo Heat Leak',
    description: 'Trades spray-on foam insulation parasitic mass against liquid methane and LOX on-pad and ascent boil-off rates.',
    parameterName: 'SOFI Thickness',
    parameterUnit: 'mm',
    points,
    baselineValue: baseConfig.sofiInsulationThicknessMm,
    insights: [
      'Thin foam (< 18mm) leads to elevated surface condensation and unacceptable boil-off during ground holds > 45 minutes.',
      'Thicknesses beyond 28mm provide diminishing thermal insulation returns while penalizing dry mass by ~400 kg.',
      'Nominal 25mm polyurethane spray foam provides the optimal balance for rapid turnaround cryo loading.',
    ],
  };
}
