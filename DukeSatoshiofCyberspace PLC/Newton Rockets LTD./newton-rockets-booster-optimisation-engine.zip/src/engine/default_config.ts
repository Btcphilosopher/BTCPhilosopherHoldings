/**
 * NEWTON ROCKETS LTD.
 * BASELINE REFERENCE BOOSTER CONFIGURATION
 * RESEARCH / ENGINEERING SIMULATION — NOT CERTIFICATION
 */

import { BoosterVehicleConfig } from './types';

export const BASELINE_BOOSTER_CONFIG: BoosterVehicleConfig = {
  id: 'NRT-BOOST-MK3',
  name: 'Newton Heavy Booster (Block III)',
  version: '3.7.0-RC4',
  diameterM: 5.2,
  totalLengthM: 70.0,
  fuelType: 'LCH4',
  oxidizerType: 'LOX',
  mixtureRatio: 3.45,
  material: 'Al-Li-2195',
  tankPressureBar: 3.0,
  ullageFraction: 0.04,
  sofiInsulationThicknessMm: 25.0,
  engineCount: 9,
  engineName: 'Newton AeroArc-9 Staged-Combustion',
  seaLevelThrustPerEngineKn: 980.0,
  vacuumThrustPerEngineKn: 1080.0,
  seaLevelIspSec: 308.0,
  vacuumIspSec: 338.0,
  engineMassPerUnitKg: 1020.0,
  minThrottleRatio: 0.40,
  maxThrottleRatio: 1.05,
  structuralFactor: 1.02,
  recoveryProfile: 'RTLS',
  gridFinsCount: 4,
  landingLegsCount: 4,
  reserveFractionReq: 0.085, // 8.5% reserve for RTLS
  turnaroundTargetDays: 14.0,
  classification: 'CALIBRATED',
  validationLevel: 'LEVEL 3: Integrated Digital-Twin Validation',
  timestamp: new Date().toISOString(),
};

export const PRESET_CONFIGURATIONS: Record<string, BoosterVehicleConfig> = {
  'Block III (Methane/LOX - RTLS)': BASELINE_BOOSTER_CONFIG,
  'Block III-D (Downrange ASDS Recovery)': {
    ...BASELINE_BOOSTER_CONFIG,
    id: 'NRT-BOOST-ASDS',
    name: 'Newton Booster ASDS Downrange Profile',
    recoveryProfile: 'ASDS',
    reserveFractionReq: 0.052,
  },
  'Expendable High-Energy Staging': {
    ...BASELINE_BOOSTER_CONFIG,
    id: 'NRT-BOOST-EXP',
    name: 'Newton Booster Expendable High-Energy',
    recoveryProfile: 'EXPENDABLE',
    reserveFractionReq: 0.0,
    gridFinsCount: 0,
    landingLegsCount: 0,
  },
  'Stainless Steel Cryo-Variant (304L)': {
    ...BASELINE_BOOSTER_CONFIG,
    id: 'NRT-BOOST-SS',
    name: 'Newton Heavy Booster Stainless 304L',
    material: '304L-Stainless',
    structuralFactor: 1.15,
    sofiInsulationThicknessMm: 30.0,
  },
  'KeroLOX High-Density Booster': {
    ...BASELINE_BOOSTER_CONFIG,
    id: 'NRT-BOOST-KEROLOX',
    name: 'Newton KeroLOX Booster Variant',
    fuelType: 'RP-1',
    mixtureRatio: 2.65,
    seaLevelIspSec: 288.0,
    vacuumIspSec: 318.0,
    seaLevelThrustPerEngineKn: 1120.0,
    vacuumThrustPerEngineKn: 1240.0,
  },
};
