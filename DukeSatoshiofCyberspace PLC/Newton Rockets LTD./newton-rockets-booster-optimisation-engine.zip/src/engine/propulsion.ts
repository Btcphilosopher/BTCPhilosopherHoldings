/**
 * NEWTON ROCKETS LTD.
 * PROPULSION SYSTEM INTERFACE & OPERATING POINT CALCULATOR
 * RESEARCH / ENGINEERING SIMULATION — NOT CERTIFICATION
 */

import { BoosterVehicleConfig, PropulsionState } from './types';
import { G0 } from './atmosphere';

export interface EngineOperatingPoint {
  throttleRatio: number;
  ambientPressurePa: number;
  thrustPerEngineN: number;
  totalThrustN: number;
  specificImpulseSec: number;
  massFlowTotalKgS: number;
  fuelFlowKgS: number;
  oxFlowKgS: number;
  thrustToWeightRatioLiftoff: number;
}

export function evaluatePropulsion(
  config: BoosterVehicleConfig,
  throttleRatio: number,
  ambientPressurePa: number,
  activeEngines: number = config.engineCount,
  currentMassKg: number = 500000
): PropulsionState {
  const clampedThrottle = Math.max(config.minThrottleRatio, Math.min(config.maxThrottleRatio, throttleRatio));
  const pAtmBar = ambientPressurePa / 100000.0;
  
  // Sea level (1.013 bar) vs Vacuum (0 bar) linear Isp interpolation
  const ispSlope = (config.vacuumIspSec - config.seaLevelIspSec) / 1.01325;
  const currentIspSec = Math.max(
    config.seaLevelIspSec * 0.95,
    Math.min(config.vacuumIspSec, config.vacuumIspSec - ispSlope * pAtmBar)
  );

  // Thrust interpolation with ambient pressure back-pressure loss
  const thrustSlope = (config.vacuumThrustPerEngineKn - config.seaLevelThrustPerEngineKn) / 1.01325;
  const thrustPerEngineKn = Math.max(
    config.seaLevelThrustPerEngineKn * 0.8,
    config.vacuumThrustPerEngineKn - thrustSlope * pAtmBar
  ) * clampedThrottle;

  const totalThrustN = thrustPerEngineKn * 1000.0 * activeEngines;
  const massFlowKgS = totalThrustN / (currentIspSec * G0);

  const MR = config.mixtureRatio;
  const fuelFlowKgS = massFlowKgS / (MR + 1.0);
  const oxFlowKgS = (massFlowKgS * MR) / (MR + 1.0);

  return {
    engineCount: config.engineCount,
    activeEngines,
    throttle: clampedThrottle,
    totalThrustN,
    effectiveIspSec: currentIspSec,
    massFlowKgS,
    fuelFlowKgS,
    oxFlowKgS,
  };
}

export function calculatePropulsionMass(config: BoosterVehicleConfig): {
  enginesDryMassKg: number;
  gimbalActuatorsMassKg: number;
  thrustVectorPuckMassKg: number;
  feedLinesMassKg: number;
  totalPropulsionMassKg: number;
} {
  const enginesDryMassKg = config.engineCount * config.engineMassPerUnitKg;
  // Thrust vector control (gimbal hydraulics/electromechanical actuators: ~45 kg per gimballed engine)
  const gimballedEngines = Math.min(config.engineCount, config.engineCount > 7 ? 3 : 1);
  const gimbalActuatorsMassKg = gimballedEngines * 48.0;
  // Thrust structure puck (titanium/high-strength alloy dome load spreader: ~18% of engine cluster mass)
  const thrustVectorPuckMassKg = enginesDryMassKg * 0.19 * config.structuralFactor;
  // High-pressure cryo feedlines, turbopump manifolds, purge valves
  const feedLinesMassKg = (config.diameterM * 180.0 + config.engineCount * 65.0) * config.structuralFactor;

  const totalPropulsionMassKg =
    enginesDryMassKg +
    gimbalActuatorsMassKg +
    thrustVectorPuckMassKg +
    feedLinesMassKg;

  return {
    enginesDryMassKg,
    gimbalActuatorsMassKg,
    thrustVectorPuckMassKg,
    feedLinesMassKg,
    totalPropulsionMassKg,
  };
}
