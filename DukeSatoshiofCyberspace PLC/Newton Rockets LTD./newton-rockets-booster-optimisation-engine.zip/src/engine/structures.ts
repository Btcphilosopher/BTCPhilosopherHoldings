/**
 * NEWTON ROCKETS LTD.
 * STRUCTURAL DIGITAL TWIN INTERFACE & LOAD MARGINS OF SAFETY
 * RESEARCH / ENGINEERING SIMULATION — NOT CERTIFICATION
 */

import { BoosterVehicleConfig, StructuralAnalysis } from './types';
import { MATERIAL_DATABASE } from './cryotank';

export function analyzeStructures(
  config: BoosterVehicleConfig,
  peakAxialLoadKn: number,
  maxDynamicPressureKPa: number,
  totalLiftoffMassKg: number,
  totalLengthM: number
): StructuralAnalysis {
  const mat = MATERIAL_DATABASE[config.material];
  const radius = config.diameterM / 2.0;
  const areaCrossSectionM2 = Math.PI * radius * radius;
  const circumferenceM = 2.0 * Math.PI * radius;

  // Sizing factors:
  // Forward skirt, Interstage barrel, Aft engine skirt, raceways, separation springs
  const forwardSkirtLengthM = Math.max(1.8, config.diameterM * 0.4);
  const interstageLengthM = Math.max(2.8, config.diameterM * 0.65);
  const aftSkirtLengthM = Math.max(2.2, config.diameterM * 0.5);

  const totalUnpressurizedLengthM = forwardSkirtLengthM + interstageLengthM + aftSkirtLengthM;

  // Shanley / NASA SP-8007 Compressive Shell Buckling Capacity:
  // P_crit = 2 * pi * gamma * E * t^2 / sqrt(3 * (1 - nu^2))
  // With isogrid / orthogrid ribs, buckling capacity increases by factor of ~3.8
  const isogridMultiplier = 3.85;
  const nominalSkinThicknessM = (config.material === '304L-Stainless' ? 4.0 : 3.0) / 1000.0;
  const gammaKnockdown = 0.45; // Empirical knockdown for cylindrical shells
  const ePa = mat.elasticModulusGpa * 1e9;
  const nu = mat.poissonRatio;

  const basicBucklingStressPa =
    (gammaKnockdown * ePa * (nominalSkinThicknessM / radius)) / Math.sqrt(3.0 * (1.0 - nu * nu));
  const effectiveBucklingStressPa = basicBucklingStressPa * isogridMultiplier;

  const compressiveBucklingCapacityKn =
    (effectiveBucklingStressPa * circumferenceM * nominalSkinThicknessM) / 1000.0;

  // Maximum design axial load with 1.4 safety factor
  const appliedCompressiveLoadKn = Math.max(1200.0, peakAxialLoadKn * 1.25);

  // Stresses
  const appliedAxialStressMpa = (appliedCompressiveLoadKn * 1000.0) / (circumferenceM * nominalSkinThicknessM * 1e6);
  const allowableAxialStressMpa = (effectiveBucklingStressPa / 1e6);

  // Buckling margin of safety: MS = (Capacity / Applied) - 1.0
  const bucklingMarginOfSafety = compressiveBucklingCapacityKn / appliedCompressiveLoadKn - 1.0;

  // Tensile hoop stress in skirts/interstage
  const hoopStressMpa = (config.tankPressureBar * 0.1 * radius) / nominalSkinThicknessM; // Mpa
  const tensileMarginOfSafety = (mat.yieldStrengthMpa / (1.4 * Math.max(10.0, hoopStressMpa))) - 1.0;

  // Overall structural margin (governed by buckling or tension)
  const structuralMarginOfSafety = Math.min(bucklingMarginOfSafety, tensileMarginOfSafety);

  // Mass calculations
  const totalSkinAreaM2 = circumferenceM * totalUnpressurizedLengthM;
  const isogridMassFactor = 1.35; // Skin + grid ribbing
  const primaryStructureMassKg =
    totalSkinAreaM2 * nominalSkinThicknessM * mat.densityKgM3 * isogridMassFactor * config.structuralFactor;

  // Secondary structure: avionics shelves, wire conduits, purge ducts, staging brackets
  const secondaryStructureMassKg = (primaryStructureMassKg * 0.38 + config.diameterM * 90.0) * config.structuralFactor;

  return {
    allowableAxialStressMpa,
    appliedAxialStressMpa,
    compressiveBucklingCapacityKn,
    appliedCompressiveLoadKn,
    hoopStressMpa,
    yieldStrengthMpa: mat.yieldStrengthMpa,
    structuralMarginOfSafety,
    bucklingMarginOfSafety,
    tensileMarginOfSafety,
    primaryStructureMassKg,
    secondaryStructureMassKg,
    isogridMassMultiplier: isogridMultiplier,
  };
}
