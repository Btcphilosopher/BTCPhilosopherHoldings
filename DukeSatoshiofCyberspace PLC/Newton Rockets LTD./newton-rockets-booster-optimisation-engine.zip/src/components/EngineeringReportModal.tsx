import React from 'react';
import { EvaluatedDesign } from '../engine/types';
import { X, Download, Printer, FileText, CheckCircle2, ShieldAlert } from 'lucide-react';

interface EngineeringReportModalProps {
  isOpen: boolean;
  onClose: () => void;
  design: EvaluatedDesign;
}

export const EngineeringReportModal: React.FC<EngineeringReportModalProps> = ({
  isOpen,
  onClose,
  design,
}) => {
  if (!isOpen) return null;

  const { config, massBudget, trajectory, structures, thermal, recovery, constraints, provenance } = design;

  const handleExportJson = () => {
    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(design, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', dataStr);
    downloadAnchor.setAttribute('download', `newton_booster_report_${design.config.id}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  const handleExportCsv = () => {
    const rows = [
      ['Metric', 'Value', 'Unit', 'Classification'],
      ['Vehicle ID', config.id, '-', provenance.classification],
      ['Name', config.name, '-', provenance.classification],
      ['Diameter', config.diameterM, 'm', 'SPECIFIED'],
      ['Length', config.totalLengthM, 'm', 'SPECIFIED'],
      ['Liftoff Mass', massBudget.totalLiftoffMassKg, 'kg', 'CALCULATED'],
      ['Dry Mass', massBudget.totalDryMassKg, 'kg', 'CALCULATED'],
      ['Propellant Mass', massBudget.propellantMassKg, 'kg', 'CALCULATED'],
      ['Staging Velocity', trajectory.stagingVelocityMS, 'm/s', 'SIMULATED'],
      ['Staging Altitude', trajectory.stagingAltitudeKm, 'km', 'SIMULATED'],
      ['Max-Q Dynamic Pressure', trajectory.maxDynamicPressureKPa, 'kPa', 'SIMULATED'],
      ['Structural Safety Margin', structures.structuralMarginOfSafety, '-', 'CALCULATED'],
      ['Thermal Safety Margin', thermal.thermalMarginOfSafety, '-', 'CALCULATED'],
      ['Turnaround Duration', recovery.refurbishmentDurationDays, 'days', 'ESTIMATED'],
    ];

    const csvContent = 'data:text/csv;charset=utf-8,' + rows.map((e) => e.join(',')).join('\n');
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', encodeURI(csvContent));
    downloadAnchor.setAttribute('download', `newton_booster_data_${design.config.id}.csv`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 lg:p-6 overflow-y-auto">
      <div className="bg-[#0b0e17] border border-slate-700 rounded-xl w-full max-w-4xl max-h-[90vh] flex flex-col shadow-2xl overflow-hidden">
        {/* Modal Top Bar */}
        <div className="bg-[#0f1424] border-b border-slate-800 p-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <FileText className="w-5 h-5 text-cyan-400" />
            <h2 className="text-sm font-bold text-white uppercase font-technical tracking-wide">
              Newton Rockets Formal Engineering Simulation Report
            </h2>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleExportCsv}
              className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-200 bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded transition-colors"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Export CSV</span>
            </button>
            <button
              onClick={handleExportJson}
              className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-200 bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded transition-colors"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Export JSON</span>
            </button>
            <button
              onClick={() => window.print()}
              className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-white bg-blue-700 hover:bg-blue-600 rounded transition-colors"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Print / PDF</span>
            </button>
            <button
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-white rounded hover:bg-slate-800 transition-colors ml-2"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Printable Document Body */}
        <div className="p-6 lg:p-8 overflow-y-auto space-y-8 font-mono text-xs text-slate-300 bg-[#080b12]">
          {/* Document Header */}
          <div className="border-b-2 border-slate-700 pb-6">
            <div className="flex justify-between items-start">
              <div>
                <div className="text-base font-bold text-white font-technical tracking-wider">
                  NEWTON ROCKETS LTD.
                </div>
                <div className="text-sm font-bold text-cyan-400 font-technical">
                  BOOSTER OPTIMISATION ENGINE - TECHNICAL EVALUATION REPORT
                </div>
                <div className="text-[11px] text-amber-400 mt-1 font-semibold">
                  RESEARCH / ENGINEERING SIMULATION — NOT CERTIFICATION
                </div>
              </div>
              <div className="text-right text-[11px] text-slate-400">
                <div>DOC REF: <span className="text-white font-bold">{provenance.hash}</span></div>
                <div>TIMESTAMP: {provenance.timestamp}</div>
                <div>TIER: {provenance.validationLevel}</div>
              </div>
            </div>
          </div>

          {/* Section 1: Vehicle Definition */}
          <div className="space-y-3">
            <h3 className="text-sm font-bold text-white uppercase font-technical border-b border-slate-800 pb-1">
              01. Baseline Vehicle Configuration
            </h3>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 p-4 bg-slate-900/60 rounded border border-slate-800">
              <div>
                <span className="text-slate-500 block text-[10px]">VEHICLE ID</span>
                <span className="text-white font-bold">{config.id}</span>
              </div>
              <div>
                <span className="text-slate-500 block text-[10px]">OUTER DIAMETER</span>
                <span className="text-white font-bold">{config.diameterM} m</span>
              </div>
              <div>
                <span className="text-slate-500 block text-[10px]">TOTAL LENGTH</span>
                <span className="text-white font-bold">{config.totalLengthM} m</span>
              </div>
              <div>
                <span className="text-slate-500 block text-[10px]">STRUCTURAL MATERIAL</span>
                <span className="text-white font-bold">{config.material}</span>
              </div>
              <div>
                <span className="text-slate-500 block text-[10px]">ENGINE CLUSTER</span>
                <span className="text-white font-bold">{config.engineCount}x {config.fuelType}/LOX</span>
              </div>
              <div>
                <span className="text-slate-500 block text-[10px]">TOTAL LIFTOFF MASS</span>
                <span className="text-cyan-300 font-bold">{massBudget.totalLiftoffMassKg.toLocaleString()} kg</span>
              </div>
              <div>
                <span className="text-slate-500 block text-[10px]">TOTAL DRY MASS</span>
                <span className="text-cyan-300 font-bold">{massBudget.totalDryMassKg.toLocaleString()} kg</span>
              </div>
              <div>
                <span className="text-slate-500 block text-[10px]">RECOVERY PROFILE</span>
                <span className="text-white font-bold">{config.recoveryProfile}</span>
              </div>
            </div>
          </div>

          {/* Section 2: Hierarchical Mass Budget */}
          <div className="space-y-3">
            <h3 className="text-sm font-bold text-white uppercase font-technical border-b border-slate-800 pb-1">
              02. Hierarchical Mass Budget & Uncertainty Closure
            </h3>
            <div className="p-4 bg-slate-900/60 rounded border border-slate-800 space-y-2">
              <div className="flex justify-between font-bold text-slate-100 border-b border-slate-800 pb-1">
                <span>SYSTEM COMPONENT</span>
                <span>MASS (KG) · UNCERTAINTY · PROVENANCE</span>
              </div>
              {massBudget.components.map((c) => (
                <div key={c.name} className="flex justify-between py-1 border-b border-slate-900 last:border-0">
                  <span className="text-slate-300">{c.name}</span>
                  <span className="text-slate-200 tabular-nums">
                    {c.massKg.toLocaleString()} kg (±{c.uncertaintyKg} kg) [{c.classification}]
                  </span>
                </div>
              ))}
              <div className="flex justify-between pt-2 border-t border-slate-700 font-bold text-cyan-300">
                <span>TOTAL VEHICLE MASS (CLOSURE RESIDUAL: {massBudget.massClosureResidualKg} kg)</span>
                <span>{massBudget.totalLiftoffMassKg.toLocaleString()} kg</span>
              </div>
            </div>
          </div>

          {/* Section 3: Trajectory & Performance */}
          <div className="space-y-3">
            <h3 className="text-sm font-bold text-white uppercase font-technical border-b border-slate-800 pb-1">
              03. 3-DOF Trajectory Dynamics Summary
            </h3>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-4 p-4 bg-slate-900/60 rounded border border-slate-800">
              <div>
                <span className="text-slate-500 block text-[10px]">STAGING DELIVERED ΔV</span>
                <span className="text-emerald-400 font-bold">{trajectory.totalDeliveredDeltaVMS} m/s</span>
              </div>
              <div>
                <span className="text-slate-500 block text-[10px]">STAGING BURNOUT VELOCITY</span>
                <span className="text-white font-bold">{trajectory.stagingVelocityMS.toFixed(1)} m/s (Mach {trajectory.stagingMach})</span>
              </div>
              <div>
                <span className="text-slate-500 block text-[10px]">STAGING ALTITUDE</span>
                <span className="text-white font-bold">{trajectory.stagingAltitudeKm} km</span>
              </div>
              <div>
                <span className="text-slate-500 block text-[10px]">MAX DYNAMIC PRESSURE (MAX-Q)</span>
                <span className="text-amber-300 font-bold">{trajectory.maxDynamicPressureKPa} kPa</span>
              </div>
              <div>
                <span className="text-slate-500 block text-[10px]">MAX AXIAL ACCELERATION</span>
                <span className="text-white font-bold">{trajectory.maxAccelerationG} g</span>
              </div>
              <div>
                <span className="text-slate-500 block text-[10px]">PEAK AEROTHERMAL FLUX</span>
                <span className="text-rose-400 font-bold">{thermal.peakStagnationHeatFluxKwM2.toFixed(1)} kW/m²</span>
              </div>
            </div>
          </div>

          {/* Section 4: Structural & Thermal Margins */}
          <div className="space-y-3">
            <h3 className="text-sm font-bold text-white uppercase font-technical border-b border-slate-800 pb-1">
              04. Structural & Thermal Constraint Verification
            </h3>
            <div className="space-y-2">
              {constraints.map((c) => (
                <div key={c.id} className="p-3 bg-slate-900/60 rounded border border-slate-800 flex justify-between items-center">
                  <div>
                    <span className="text-slate-200 font-bold">{c.name}</span>
                    <span className="text-slate-500 text-[11px] block">
                      Value: {c.value.toFixed(2)} {c.unit} (Limit: {c.isUpperBound ? '≤' : '≥'} {c.limit} {c.unit})
                    </span>
                  </div>
                  <div className="text-right">
                    <span className={`px-2 py-0.5 rounded text-[11px] font-bold ${
                      c.isViolated ? 'bg-rose-950 text-rose-300' : 'bg-emerald-950 text-emerald-300'
                    }`}>
                      {c.isViolated ? 'VIOLATED' : 'SATISFIED'}
                    </span>
                    <span className="block text-[10px] text-slate-400 mt-0.5">
                      Margin: {c.margin >= 0 ? `+${(c.margin * 100).toFixed(1)}%` : `${(c.margin * 100).toFixed(1)}%`}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Section 5: Model Limitations & Provenance Disclaimer */}
          <div className="space-y-2 border-t border-slate-800 pt-4 text-[11px] text-slate-400 leading-relaxed">
            <div className="font-bold text-slate-300 uppercase font-technical">Model Limitations & Provenance Statement</div>
            <p>
              This report was compiled autonomously by the Newton Rockets Booster Optimisation Engine (v3.7.0). Calculations utilize reduced-order compressible aerodynamics, 3-DOF point-mass numerical integration, NASA SP-8007 compressive shell buckling approximations, and Sutton-Graves stagnation heating relations. This software is intended strictly for design space exploration and systems engineering trade analysis and is NOT a substitute for detailed computational fluid dynamics (CFD), finite element analysis (FEA), or hot-fire qualification hardware testing.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
