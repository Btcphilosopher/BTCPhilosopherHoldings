import React from 'react';
import { DataClassification, ValidationLevel } from '../engine/types';
import { AlertCircle, CheckCircle2, ShieldAlert, Cpu } from 'lucide-react';

interface ClassificationBannerProps {
  classification: DataClassification;
  validationLevel: ValidationLevel;
  provenanceHash: string;
  isConverged: boolean;
  residualKg: number;
}

export const ClassificationBanner: React.FC<ClassificationBannerProps> = ({
  classification,
  validationLevel,
  provenanceHash,
  isConverged,
  residualKg,
}) => {
  const classificationColors: Record<DataClassification, string> = {
    THEORETICAL: 'text-purple-300 bg-purple-950/40 border-purple-800/60',
    REFERENCE: 'text-slate-300 bg-slate-800/60 border-slate-700/60',
    ASSUMED: 'text-amber-300 bg-amber-950/40 border-amber-800/60',
    MEASURED: 'text-blue-300 bg-blue-950/40 border-blue-800/60',
    CALIBRATED: 'text-cyan-300 bg-cyan-950/40 border-cyan-800/60',
    VALIDATED: 'text-emerald-300 bg-emerald-950/40 border-emerald-800/60',
    QUALIFIED: 'text-teal-300 bg-teal-950/40 border-teal-800/60',
  };

  return (
    <div className="bg-[#0b101b] border-b border-slate-800 px-4 lg:px-6 py-2 flex flex-wrap items-center justify-between gap-3 text-xs">
      <div className="flex items-center gap-3">
        <div className="flex items-center gap-1.5 font-mono text-slate-300">
          <span className="text-slate-400 font-semibold uppercase tracking-wider">ENGINEERING DISCLAIMER:</span>
          <span className="text-slate-400">RESEARCH & DESIGN ANALYSIS SIMULATION — NOT FLIGHT-CERTIFIED SOFTWARE</span>
        </div>
      </div>

      <div className="flex items-center gap-4 flex-wrap font-mono">
        {/* Convergence State */}
        <div className="flex items-center gap-1.5">
          {isConverged ? (
            <span className="inline-flex items-center gap-1 text-emerald-400">
              <CheckCircle2 className="w-3.5 h-3.5" />
              <span>CONVERGED (Residual: {residualKg} kg)</span>
            </span>
          ) : (
            <span className="inline-flex items-center gap-1 text-rose-400 animate-pulse">
              <AlertCircle className="w-3.5 h-3.5" />
              <span>NON-CONVERGED (Residual: {residualKg} kg)</span>
            </span>
          )}
        </div>

        {/* Data Provenance Badge */}
        <div className="flex items-center gap-1.5">
          <span className="text-slate-400">DATA PROVENANCE:</span>
          <span className={`px-2 py-0.5 rounded border text-[11px] font-semibold tracking-wide ${classificationColors[classification]}`}>
            {classification}
          </span>
        </div>

        {/* Validation Hierarchy Level */}
        <div className="flex items-center gap-1.5">
          <span className="text-slate-400">STATUS:</span>
          <span className="text-cyan-300 font-medium">{validationLevel}</span>
        </div>

        {/* Traceability Hash */}
        <div className="hidden lg:flex items-center gap-1.5 text-slate-400">
          <span>PROVENANCE ID:</span>
          <span className="text-slate-300 select-all font-mono">{provenanceHash}</span>
        </div>
      </div>
    </div>
  );
};
