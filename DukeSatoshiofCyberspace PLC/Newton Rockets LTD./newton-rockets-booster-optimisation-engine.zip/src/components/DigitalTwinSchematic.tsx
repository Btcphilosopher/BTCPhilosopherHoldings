import React, { useState } from 'react';
import { EvaluatedDesign } from '../engine/types';
import { Layers, Thermometer, ShieldAlert, Weight, Flame, Eye } from 'lucide-react';

interface DigitalTwinSchematicProps {
  design: EvaluatedDesign;
}

type VisualOverlay = 'MASS' | 'TEMPERATURE' | 'STRUCTURAL_LOAD' | 'PROPELLANT' | 'TPS_SHIELDING';

export const DigitalTwinSchematic: React.FC<DigitalTwinSchematicProps> = ({ design }) => {
  const [activeOverlay, setActiveOverlay] = useState<VisualOverlay>('MASS');
  const [selectedSubsystem, setSelectedSubsystem] = useState<string | null>('lox-tank');

  const { config, massBudget, trajectory, structures, thermal, recovery } = design;

  // Geometry dimensions
  const diameterM = config.diameterM;
  const lengthM = config.totalLengthM;

  return (
    <div className="space-y-6">
      {/* Header & Overlay Selector */}
      <div className="bg-[#0f1422] border border-slate-800 rounded-lg p-4 flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <Layers className="w-4 h-4 text-cyan-400" />
            <h1 className="text-base font-bold text-white uppercase font-technical tracking-wide">
              Booster Digital Twin & Cutaway Section
            </h1>
          </div>
          <p className="text-xs text-slate-400">
            Geometric scaling: {diameterM}m outer diameter · {lengthM}m total height · L/D = {(lengthM / diameterM).toFixed(1)}
          </p>
        </div>

        {/* Visual Overlay Mode Selector */}
        <div className="flex flex-wrap items-center gap-1.5 p-1 bg-slate-900 border border-slate-800 rounded text-xs font-mono">
          <button
            onClick={() => setActiveOverlay('MASS')}
            className={`px-3 py-1 rounded transition-colors ${
              activeOverlay === 'MASS' ? 'bg-blue-600 text-white font-bold' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            MASS DISTRIBUTION
          </button>
          <button
            onClick={() => setActiveOverlay('TEMPERATURE')}
            className={`px-3 py-1 rounded transition-colors ${
              activeOverlay === 'TEMPERATURE' ? 'bg-amber-600 text-white font-bold' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            THERMAL / CRYOGENICS
          </button>
          <button
            onClick={() => setActiveOverlay('STRUCTURAL_LOAD')}
            className={`px-3 py-1 rounded transition-colors ${
              activeOverlay === 'STRUCTURAL_LOAD' ? 'bg-purple-600 text-white font-bold' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            STRUCTURAL LOADS
          </button>
          <button
            onClick={() => setActiveOverlay('PROPELLANT')}
            className={`px-3 py-1 rounded transition-colors ${
              activeOverlay === 'PROPELLANT' ? 'bg-cyan-600 text-white font-bold' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            FLUID LEVELS
          </button>
          <button
            onClick={() => setActiveOverlay('TPS_SHIELDING')}
            className={`px-3 py-1 rounded transition-colors ${
              activeOverlay === 'TPS_SHIELDING' ? 'bg-emerald-600 text-white font-bold' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            TPS & RECOVERY
          </button>
        </div>
      </div>

      {/* Main Cutaway Stage & Subsystem Inspector Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Cols: Interactive Cutaway SVG */}
        <div className="lg:col-span-2 bg-[#0c101c] border border-slate-800 rounded-lg p-5 flex flex-col items-center justify-center min-h-[560px]">
          <div className="w-full max-w-[580px] py-4">
            <svg viewBox="0 0 500 720" className="w-full h-auto font-mono select-none">
              {/* Grid Background */}
              <defs>
                <pattern id="twin-grid" width="20" height="20" patternUnits="userSpaceOnUse">
                  <path d="M 20 0 L 0 0 0 20" fill="none" stroke="#131c2e" strokeWidth="0.8" />
                </pattern>
                {/* Gradients */}
                <linearGradient id="lox-gradient" x1="0" y1="0" x2="1" y2="0">
                  <stop offset="0%" stopColor="#1e3a8a" stopOpacity="0.85" />
                  <stop offset="50%" stopColor="#3b82f6" stopOpacity="0.75" />
                  <stop offset="100%" stopColor="#1e3a8a" stopOpacity="0.85" />
                </linearGradient>
                <linearGradient id="fuel-gradient" x1="0" y1="0" x2="1" y2="0">
                  <stop offset="0%" stopColor="#064e3b" stopOpacity="0.85" />
                  <stop offset="50%" stopColor="#10b981" stopOpacity="0.75" />
                  <stop offset="100%" stopColor="#064e3b" stopOpacity="0.85" />
                </linearGradient>
                <linearGradient id="thermal-gradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#f97316" stopOpacity="0.9" />
                  <stop offset="25%" stopColor="#eab308" stopOpacity="0.8" />
                  <stop offset="70%" stopColor="#38bdf8" stopOpacity="0.8" />
                  <stop offset="100%" stopColor="#ef4444" stopOpacity="0.95" />
                </linearGradient>
                <linearGradient id="stress-gradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#6366f1" stopOpacity="0.7" />
                  <stop offset="60%" stopColor="#8b5cf6" stopOpacity="0.8" />
                  <stop offset="100%" stopColor="#ec4899" stopOpacity="0.9" />
                </linearGradient>
              </defs>

              <rect x="0" y="0" width="500" height="720" fill="url(#twin-grid)" />

              {/* Central Rocket Outline */}
              <g transform="translate(160, 20)">
                {/* 1. Forward Skirt / Interstage */}
                <g 
                  className="cursor-pointer group"
                  onClick={() => setSelectedSubsystem('forward-skirt')}
                >
                  <rect
                    x="20"
                    y="40"
                    width="140"
                    height="50"
                    fill={activeOverlay === 'MASS' ? '#334155' : activeOverlay === 'TEMPERATURE' ? '#f59e0b' : '#1e293b'}
                    stroke="#475569"
                    strokeWidth="1.5"
                    className="transition-all hover:stroke-cyan-400"
                  />
                  <text x="90" y="68" fill="#e2e8f0" fontSize="10" textAnchor="middle" fontWeight="bold">
                    FORWARD SKIRT & AVIONICS
                  </text>
                </g>

                {/* Grid Fins (Recovery) */}
                {config.gridFinsCount > 0 && (
                  <g className="cursor-pointer" onClick={() => setSelectedSubsystem('grid-fins')}>
                    {/* Left Grid Fin */}
                    <rect x="-15" y="55" width="35" height="22" fill="#0f172a" stroke="#06b6d4" strokeWidth="1.5" rx="2" />
                    <line x1="-15" y1="62" x2="20" y2="62" stroke="#06b6d4" strokeWidth="0.8" />
                    <line x1="-15" y1="69" x2="20" y2="69" stroke="#06b6d4" strokeWidth="0.8" />
                    {/* Right Grid Fin */}
                    <rect x="160" y="55" width="35" height="22" fill="#0f172a" stroke="#06b6d4" strokeWidth="1.5" rx="2" />
                    <line x1="160" y1="62" x2="195" y2="62" stroke="#06b6d4" strokeWidth="0.8" />
                    <line x1="160" y1="69" x2="195" y2="69" stroke="#06b6d4" strokeWidth="0.8" />
                  </g>
                )}

                {/* 2. LOX Tank (Upper Cryotank) */}
                <g 
                  className="cursor-pointer group"
                  onClick={() => setSelectedSubsystem('lox-tank')}
                >
                  {/* Top Dome */}
                  <path
                    d="M 20 90 Q 90 60 160 90"
                    fill={activeOverlay === 'TEMPERATURE' ? '#38bdf8' : activeOverlay === 'PROPELLANT' ? 'url(#lox-gradient)' : '#1e3a8a'}
                    stroke="#60a5fa"
                    strokeWidth="1.5"
                  />
                  {/* Barrel */}
                  <rect
                    x="20"
                    y="90"
                    width="140"
                    height="190"
                    fill={
                      activeOverlay === 'TEMPERATURE'
                        ? '#0284c7'
                        : activeOverlay === 'STRUCTURAL_LOAD'
                        ? 'url(#stress-gradient)'
                        : activeOverlay === 'PROPELLANT'
                        ? 'url(#lox-gradient)'
                        : '#1e3a8a'
                    }
                    stroke="#60a5fa"
                    strokeWidth="1.5"
                    className="transition-all hover:stroke-cyan-400"
                  />
                  {/* Internal Liquid Level Wave */}
                  <path
                    d="M 20 120 Q 55 115 90 120 T 160 120 L 160 280 L 20 280 Z"
                    fill="#3b82f6"
                    opacity="0.35"
                  />
                  {/* Bottom Dome */}
                  <path
                    d="M 20 280 Q 90 310 160 280"
                    fill={activeOverlay === 'TEMPERATURE' ? '#0284c7' : '#1e3a8a'}
                    stroke="#60a5fa"
                    strokeWidth="1.5"
                  />
                  <text x="90" y="190" fill="#ffffff" fontSize="11" textAnchor="middle" fontWeight="bold">
                    LOX CRYO-TANK
                  </text>
                  <text x="90" y="208" fill="#93c5fd" fontSize="9" textAnchor="middle">
                    T = 90.2 K · {massBudget.components[0].subcomponents?.[0]?.massKg.toLocaleString()} kg
                  </text>
                </g>

                {/* 3. Intertank Structure */}
                <g 
                  className="cursor-pointer group"
                  onClick={() => setSelectedSubsystem('intertank')}
                >
                  <rect
                    x="20"
                    y="295"
                    width="140"
                    height="45"
                    fill="#1e293b"
                    stroke="#475569"
                    strokeWidth="1.5"
                    className="transition-all hover:stroke-cyan-400"
                  />
                  {/* Isogrid Cross-hatching */}
                  <line x1="20" y1="295" x2="60" y2="340" stroke="#334155" strokeWidth="1" />
                  <line x1="60" y1="295" x2="100" y2="340" stroke="#334155" strokeWidth="1" />
                  <line x1="100" y1="295" x2="140" y2="340" stroke="#334155" strokeWidth="1" />
                  <line x1="140" y1="295" x2="160" y2="315" stroke="#334155" strokeWidth="1" />
                  <text x="90" y="322" fill="#cbd5e1" fontSize="9" textAnchor="middle" fontWeight="bold">
                    INTERTANK (ISOGRID)
                  </text>
                </g>

                {/* 4. Fuel Tank (LCH4 / RP-1) */}
                <g 
                  className="cursor-pointer group"
                  onClick={() => setSelectedSubsystem('fuel-tank')}
                >
                  {/* Top Dome */}
                  <path
                    d="M 20 340 Q 90 315 160 340"
                    fill={activeOverlay === 'TEMPERATURE' ? '#0284c7' : '#064e3b'}
                    stroke="#34d399"
                    strokeWidth="1.5"
                  />
                  {/* Barrel */}
                  <rect
                    x="20"
                    y="340"
                    width="140"
                    height="180"
                    fill={
                      activeOverlay === 'TEMPERATURE'
                        ? '#0369a1'
                        : activeOverlay === 'STRUCTURAL_LOAD'
                        ? 'url(#stress-gradient)'
                        : activeOverlay === 'PROPELLANT'
                        ? 'url(#fuel-gradient)'
                        : '#064e3b'
                    }
                    stroke="#34d399"
                    strokeWidth="1.5"
                    className="transition-all hover:stroke-cyan-400"
                  />
                  {/* Fuel Level */}
                  <path
                    d="M 20 365 Q 55 360 90 365 T 160 365 L 160 520 L 20 520 Z"
                    fill="#10b981"
                    opacity="0.35"
                  />
                  {/* Bottom Dome */}
                  <path
                    d="M 20 520 Q 90 550 160 520"
                    fill="#064e3b"
                    stroke="#34d399"
                    strokeWidth="1.5"
                  />
                  <text x="90" y="435" fill="#ffffff" fontSize="11" textAnchor="middle" fontWeight="bold">
                    {config.fuelType} FUEL TANK
                  </text>
                  <text x="90" y="453" fill="#6ee7b7" fontSize="9" textAnchor="middle">
                    {massBudget.components[0].subcomponents?.[1]?.massKg.toLocaleString()} kg
                  </text>
                </g>

                {/* 5. Aft Skirt & Engine Section */}
                <g 
                  className="cursor-pointer group"
                  onClick={() => setSelectedSubsystem('propulsion-bay')}
                >
                  <rect
                    x="20"
                    y="535"
                    width="140"
                    height="60"
                    fill={activeOverlay === 'TEMPERATURE' ? '#ef4444' : '#18181b'}
                    stroke="#71717a"
                    strokeWidth="1.5"
                    className="transition-all hover:stroke-cyan-400"
                  />
                  <text x="90" y="570" fill="#f43f5e" fontSize="10" textAnchor="middle" fontWeight="bold">
                    ENGINE BAY & PUCK
                  </text>
                </g>

                {/* Engine Nozzles Cluster */}
                <g 
                  className="cursor-pointer"
                  onClick={() => setSelectedSubsystem('engine-cluster')}
                >
                  {/* Center Nozzle */}
                  <path d="M 80 595 L 75 640 L 105 640 L 100 595 Z" fill="#27272a" stroke="#f59e0b" strokeWidth="1.5" />
                  {/* Outer Left Nozzle */}
                  <path d="M 40 595 L 30 635 L 55 635 L 50 595 Z" fill="#27272a" stroke="#f59e0b" strokeWidth="1.5" />
                  {/* Outer Right Nozzle */}
                  <path d="M 130 595 L 125 635 L 150 635 L 140 595 Z" fill="#27272a" stroke="#f59e0b" strokeWidth="1.5" />
                  {/* Exhaust Flame Plume (Active) */}
                  <path d="M 30 635 Q 90 710 150 635 Q 90 670 30 635 Z" fill="url(#thermal-gradient)" opacity="0.85" />
                </g>

                {/* Landing Legs */}
                {config.landingLegsCount > 0 && (
                  <g className="cursor-pointer" onClick={() => setSelectedSubsystem('landing-legs')}>
                    {/* Left Leg */}
                    <path d="M 20 480 L -10 610 L 15 610 Z" fill="#0f172a" stroke="#10b981" strokeWidth="1.5" />
                    {/* Right Leg */}
                    <path d="M 160 480 L 190 610 L 165 610 Z" fill="#0f172a" stroke="#10b981" strokeWidth="1.5" />
                  </g>
                )}
              </g>

              {/* Callout Pointer Lines */}
              <line x1="80" y1="75" x2="180" y2="75" stroke="#06b6d4" strokeWidth="1" strokeDasharray="2 2" />
              <text x="20" y="78" fill="#06b6d4" fontSize="10">AVIONICS</text>

              <line x1="80" y1="210" x2="180" y2="210" stroke="#38bdf8" strokeWidth="1" strokeDasharray="2 2" />
              <text x="20" y="213" fill="#38bdf8" fontSize="10">LOX DOME</text>

              <line x1="80" y1="460" x2="180" y2="460" stroke="#34d399" strokeWidth="1" strokeDasharray="2 2" />
              <text x="20" y="463" fill="#34d399" fontSize="10">FUEL TANK</text>

              <line x1="80" y1="620" x2="180" y2="620" stroke="#f59e0b" strokeWidth="1" strokeDasharray="2 2" />
              <text x="20" y="623" fill="#f59e0b" fontSize="10">9x ENGINES</text>
            </svg>
          </div>
        </div>

        {/* Right 1 Col: Subsystem Deep Inspection Details */}
        <div className="bg-[#0c101c] border border-slate-800 rounded-lg p-5 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-3 mb-4 border-b border-slate-800">
              <h2 className="text-sm font-bold text-white uppercase tracking-wider font-technical">
                Subsystem Twin Telemetry
              </h2>
              <span className="text-xs font-mono text-cyan-400">
                ACTIVE CAD STATE
              </span>
            </div>

            {selectedSubsystem === 'lox-tank' && (
              <div className="space-y-3 font-mono text-xs">
                <div className="text-sm font-bold text-blue-400 font-technical">LOX CRYOGENIC TANK SYSTEM</div>
                <div className="text-slate-300">
                  Cylindrical aluminum-lithium (Al-Li 2195) welded barrel with ASME 2:1 ellipsoidal domes.
                </div>
                <div className="p-3 bg-slate-900 rounded border border-slate-800 space-y-2 text-[11px]">
                  <div className="flex justify-between">
                    <span className="text-slate-400">OPERATING PRESSURE:</span>
                    <span className="text-white font-bold">{config.tankPressureBar} bar (300 kPa)</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">MEMBRANE HOOP STRESS:</span>
                    <span className="text-emerald-400 font-bold">{structures.hoopStressMpa.toFixed(1)} MPa</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">LIQUID TEMPERATURE:</span>
                    <span className="text-cyan-300 font-bold">90.2 K (-182.9 °C)</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">ULLAGE VOLUME:</span>
                    <span className="text-slate-200">{(config.ullageFraction * 100).toFixed(1)} %</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">SOFI INSULATION THICKNESS:</span>
                    <span className="text-slate-200">{config.sofiInsulationThicknessMm} mm</span>
                  </div>
                </div>
              </div>
            )}

            {selectedSubsystem === 'fuel-tank' && (
              <div className="space-y-3 font-mono text-xs">
                <div className="text-sm font-bold text-emerald-400 font-technical">{config.fuelType} CRYOGENIC FUEL TANK</div>
                <div className="text-slate-300">
                  Lower main propellant tank featuring internal anti-slosh baffles and integrated sump feedlines.
                </div>
                <div className="p-3 bg-slate-900 rounded border border-slate-800 space-y-2 text-[11px]">
                  <div className="flex justify-between">
                    <span className="text-slate-400">FUEL CAPACITY:</span>
                    <span className="text-white font-bold">{massBudget.components[0].subcomponents?.[1]?.massKg.toLocaleString()} kg</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">MIXTURE RATIO (O/F):</span>
                    <span className="text-white font-bold">{config.mixtureRatio.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">BULK DENSITY:</span>
                    <span className="text-slate-200">422.6 kg/m³</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">RESIDUAL FRACTION:</span>
                    <span className="text-slate-200">1.2 % (unusable)</span>
                  </div>
                </div>
              </div>
            )}

            {selectedSubsystem === 'engine-cluster' && (
              <div className="space-y-3 font-mono text-xs">
                <div className="text-sm font-bold text-amber-400 font-technical">PROPULSION & ENGINE CLUSTER</div>
                <div className="text-slate-300">
                  {config.engineCount}x {config.engineName} staged-combustion rocket engines.
                </div>
                <div className="p-3 bg-slate-900 rounded border border-slate-800 space-y-2 text-[11px]">
                  <div className="flex justify-between">
                    <span className="text-slate-400">TOTAL SEA-LEVEL THRUST:</span>
                    <span className="text-amber-400 font-bold">
                      {((config.seaLevelThrustPerEngineKn * config.engineCount) / 1000).toFixed(2)} MN
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">SEA-LEVEL SPECIFIC IMPULSE:</span>
                    <span className="text-white font-bold">{config.seaLevelIspSec} s</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">VACUUM SPECIFIC IMPULSE:</span>
                    <span className="text-emerald-400 font-bold">{config.vacuumIspSec} s</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">THROTTLE RANGE:</span>
                    <span className="text-slate-200">{(config.minThrottleRatio * 100).toFixed(0)}% - {(config.maxThrottleRatio * 100).toFixed(0)}%</span>
                  </div>
                </div>
              </div>
            )}

            {(!selectedSubsystem || (selectedSubsystem !== 'lox-tank' && selectedSubsystem !== 'fuel-tank' && selectedSubsystem !== 'engine-cluster')) && (
              <div className="space-y-3 font-mono text-xs">
                <div className="text-sm font-bold text-cyan-400 font-technical">STRUCTURES & RECOVERY SUBSYSTEM</div>
                <div className="text-slate-300">
                  Select a vehicle component on the CAD cutaway to inspect real-time digital twin state.
                </div>
                <div className="p-3 bg-slate-900 rounded border border-slate-800 space-y-2 text-[11px]">
                  <div className="flex justify-between">
                    <span className="text-slate-400">BUCKLING CAPACITY:</span>
                    <span className="text-white font-bold">{structures.compressiveBucklingCapacityKn.toFixed(0)} kN</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">APPLIED PEAK LOAD:</span>
                    <span className="text-slate-200">{structures.appliedCompressiveLoadKn.toFixed(0)} kN</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">GRID FINS COUNT:</span>
                    <span className="text-cyan-400 font-bold">{config.gridFinsCount} (Cast Titanium)</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">LANDING LEGS:</span>
                    <span className="text-cyan-400 font-bold">{config.landingLegsCount} (Aramid Telescoping)</span>
                  </div>
                </div>
              </div>
            )}
          </div>

          <div className="mt-6 pt-4 border-t border-slate-800 text-xs text-slate-400 font-mono">
            <span>DIGITAL TWIN SYNCHRONISATION: </span>
            <span className="text-emerald-400 font-bold">100% (COUPLED PHYSICS)</span>
          </div>
        </div>
      </div>
    </div>
  );
};
