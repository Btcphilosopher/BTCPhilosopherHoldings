import React, { useState } from 'react';
import { BoosterVehicleConfig, StructuralMaterial, FuelType, RecoveryProfile } from '../engine/types';
import { X, SlidersHorizontal, RotateCcw, Check, Sparkles } from 'lucide-react';

interface ParameterEditorDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  config: BoosterVehicleConfig;
  onApplyConfig: (newConfig: BoosterVehicleConfig) => void;
}

export const ParameterEditorDrawer: React.FC<ParameterEditorDrawerProps> = ({
  isOpen,
  onClose,
  config,
  onApplyConfig,
}) => {
  const [draft, setDraft] = useState<BoosterVehicleConfig>({ ...config });

  if (!isOpen) return null;

  const handleFieldChange = (key: keyof BoosterVehicleConfig, value: any) => {
    setDraft((prev) => ({ ...prev, [key]: value }));
  };

  const handleApply = () => {
    onApplyConfig(draft);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex justify-end">
      <div className="bg-[#0b0e17] border-l border-slate-800 w-full max-w-md h-full flex flex-col shadow-2xl overflow-hidden font-mono">
        {/* Top bar */}
        <div className="bg-[#0f1422] border-b border-slate-800 p-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <SlidersHorizontal className="w-4 h-4 text-cyan-400" />
            <h2 className="text-sm font-bold text-white uppercase font-technical">
              Vehicle Parameter Controller
            </h2>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white rounded hover:bg-slate-800 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Scrollable Form Body */}
        <div className="p-5 overflow-y-auto space-y-5 text-xs text-slate-300">
          {/* Section: Geometry */}
          <div className="space-y-3">
            <div className="text-[11px] font-bold text-cyan-400 uppercase tracking-wider border-b border-slate-800 pb-1">
              01. Geometry & Dimensions
            </div>
            <div className="space-y-2">
              <div className="flex justify-between items-center">
                <label className="text-slate-400">Outer Diameter (m):</label>
                <span className="text-white font-bold">{draft.diameterM} m</span>
              </div>
              <input
                type="range"
                min="3.6"
                max="6.5"
                step="0.1"
                value={draft.diameterM}
                onChange={(e) => handleFieldChange('diameterM', parseFloat(e.target.value))}
                className="w-full accent-cyan-500 cursor-pointer"
              />
            </div>

            <div className="space-y-2">
              <div className="flex justify-between items-center">
                <label className="text-slate-400">Total Vehicle Length (m):</label>
                <span className="text-white font-bold">{draft.totalLengthM} m</span>
              </div>
              <input
                type="range"
                min="55.0"
                max="85.0"
                step="0.5"
                value={draft.totalLengthM}
                onChange={(e) => handleFieldChange('totalLengthM', parseFloat(e.target.value))}
                className="w-full accent-cyan-500 cursor-pointer"
              />
            </div>
          </div>

          {/* Section: Materials & Cryotank */}
          <div className="space-y-3">
            <div className="text-[11px] font-bold text-blue-400 uppercase tracking-wider border-b border-slate-800 pb-1">
              02. Materials & Cryotank Pressures
            </div>
            <div className="space-y-1.5">
              <label className="text-slate-400 block">Primary Structural Material:</label>
              <select
                value={draft.material}
                onChange={(e) => handleFieldChange('material', e.target.value as StructuralMaterial)}
                className="w-full bg-slate-900 border border-slate-700 rounded px-2.5 py-1.5 text-slate-200 focus:outline-none focus:border-cyan-500"
              >
                <option value="Al-Li-2195">Al-Li-2195 (Aluminum-Lithium Alloy)</option>
                <option value="304L-Stainless">304L-Stainless Steel (High-Temp Resilient)</option>
                <option value="Carbon-Composite">Carbon-Composite (High Specific Modulus)</option>
                <option value="Ti-6Al-4V">Ti-6Al-4V Titanium Alloy</option>
              </select>
            </div>

            <div className="space-y-2">
              <div className="flex justify-between items-center">
                <label className="text-slate-400">Tank Operating Pressure (bar):</label>
                <span className="text-white font-bold">{draft.tankPressureBar} bar</span>
              </div>
              <input
                type="range"
                min="2.0"
                max="4.5"
                step="0.1"
                value={draft.tankPressureBar}
                onChange={(e) => handleFieldChange('tankPressureBar', parseFloat(e.target.value))}
                className="w-full accent-cyan-500 cursor-pointer"
              />
            </div>

            <div className="space-y-2">
              <div className="flex justify-between items-center">
                <label className="text-slate-400">SOFI Insulation Thickness (mm):</label>
                <span className="text-white font-bold">{draft.sofiInsulationThicknessMm} mm</span>
              </div>
              <input
                type="range"
                min="10"
                max="45"
                step="1"
                value={draft.sofiInsulationThicknessMm}
                onChange={(e) => handleFieldChange('sofiInsulationThicknessMm', parseInt(e.target.value))}
                className="w-full accent-cyan-500 cursor-pointer"
              />
            </div>
          </div>

          {/* Section: Propulsion System */}
          <div className="space-y-3">
            <div className="text-[11px] font-bold text-amber-400 uppercase tracking-wider border-b border-slate-800 pb-1">
              03. Propulsion Configuration
            </div>
            <div className="space-y-1.5">
              <label className="text-slate-400 block">Engine Count (Cluster):</label>
              <select
                value={draft.engineCount}
                onChange={(e) => handleFieldChange('engineCount', parseInt(e.target.value))}
                className="w-full bg-slate-900 border border-slate-700 rounded px-2.5 py-1.5 text-slate-200 focus:outline-none focus:border-cyan-500"
              >
                <option value={7}>7 Engines (Hexagonal + Center)</option>
                <option value={9}>9 Engines (Octagonal + Center)</option>
                <option value={11}>11 Engines (Outer Ring + Core)</option>
              </select>
            </div>

            <div className="space-y-1.5">
              <label className="text-slate-400 block">Propellant Chemistry:</label>
              <select
                value={draft.fuelType}
                onChange={(e) => {
                  const fuel = e.target.value as FuelType;
                  handleFieldChange('fuelType', fuel);
                  if (fuel === 'LCH4') handleFieldChange('mixtureRatio', 3.45);
                  if (fuel === 'RP-1') handleFieldChange('mixtureRatio', 2.65);
                  if (fuel === 'LH2') handleFieldChange('mixtureRatio', 5.50);
                }}
                className="w-full bg-slate-900 border border-slate-700 rounded px-2.5 py-1.5 text-slate-200 focus:outline-none focus:border-cyan-500"
              >
                <option value="LCH4">Liquid Methane (LCH4 / LOX - O/F = 3.45)</option>
                <option value="RP-1">Kerosene (RP-1 / LOX - O/F = 2.65)</option>
                <option value="LH2">Liquid Hydrogen (LH2 / LOX - O/F = 5.50)</option>
              </select>
            </div>
          </div>

          {/* Section: Structures & Recovery */}
          <div className="space-y-3">
            <div className="text-[11px] font-bold text-purple-400 uppercase tracking-wider border-b border-slate-800 pb-1">
              04. Structures & Recovery Profile
            </div>
            <div className="space-y-2">
              <div className="flex justify-between items-center">
                <label className="text-slate-400">Structural Factor (k_struct):</label>
                <span className="text-white font-bold">{draft.structuralFactor}</span>
              </div>
              <input
                type="range"
                min="0.85"
                max="1.30"
                step="0.01"
                value={draft.structuralFactor}
                onChange={(e) => handleFieldChange('structuralFactor', parseFloat(e.target.value))}
                className="w-full accent-cyan-500 cursor-pointer"
              />
            </div>

            <div className="space-y-1.5">
              <label className="text-slate-400 block">Recovery Mission Profile:</label>
              <select
                value={draft.recoveryProfile}
                onChange={(e) => {
                  const prof = e.target.value as RecoveryProfile;
                  handleFieldChange('recoveryProfile', prof);
                  if (prof === 'RTLS') handleFieldChange('reserveFractionReq', 0.085);
                  if (prof === 'ASDS') handleFieldChange('reserveFractionReq', 0.052);
                  if (prof === 'EXPENDABLE') handleFieldChange('reserveFractionReq', 0.0);
                }}
                className="w-full bg-slate-900 border border-slate-700 rounded px-2.5 py-1.5 text-slate-200 focus:outline-none focus:border-cyan-500"
              >
                <option value="RTLS">Return to Launch Site (RTLS - 3 Burns)</option>
                <option value="ASDS">Downrange Drone Ship (ASDS - 2 Burns)</option>
                <option value="EXPENDABLE">Expendable Full Energy Staging (0 Reserve)</option>
              </select>
            </div>

            <div className="space-y-2">
              <div className="flex justify-between items-center">
                <label className="text-slate-400">Landing Propellant Reserve (%):</label>
                <span className="text-white font-bold">{(draft.reserveFractionReq * 100).toFixed(1)} %</span>
              </div>
              <input
                type="range"
                min="0.0"
                max="0.16"
                step="0.005"
                value={draft.reserveFractionReq}
                onChange={(e) => handleFieldChange('reserveFractionReq', parseFloat(e.target.value))}
                className="w-full accent-cyan-500 cursor-pointer"
              />
            </div>
          </div>
        </div>

        {/* Bottom Actions */}
        <div className="bg-[#0f1422] border-t border-slate-800 p-4 flex items-center justify-between gap-3">
          <button
            onClick={() => setDraft({ ...config })}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs text-slate-400 hover:text-slate-200 transition-colors"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Reset</span>
          </button>
          <button
            onClick={handleApply}
            className="flex items-center gap-1.5 px-4 py-2 text-xs font-medium text-white bg-cyan-700 hover:bg-cyan-600 rounded transition-colors shadow-sm"
          >
            <Check className="w-4 h-4" />
            <span>Re-converge Digital Twin</span>
          </button>
        </div>
      </div>
    </div>
  );
};
