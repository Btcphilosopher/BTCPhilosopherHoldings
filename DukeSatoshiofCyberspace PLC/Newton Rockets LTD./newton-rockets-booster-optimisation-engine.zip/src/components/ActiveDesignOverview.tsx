import React, { useState } from 'react';
import { EvaluatedDesign } from '../engine/types';
import { 
  Weight, 
  Flame, 
  Activity, 
  Shield, 
  RotateCcw, 
  Layers, 
  ChevronDown, 
  ChevronRight, 
  CheckCircle2, 
  AlertTriangle, 
  XCircle,
  TrendingUp,
  Clock,
  Zap,
  Gauge
} from 'lucide-react';

interface ActiveDesignOverviewProps {
  design: EvaluatedDesign;
  totalDesignsEvaluated: number;
  paretoCount: number;
  onNavigateTab: (tab: string) => void;
}

export const ActiveDesignOverview: React.FC<ActiveDesignOverviewProps> = ({
  design,
  totalDesignsEvaluated,
  paretoCount,
  onNavigateTab,
}) => {
  const [expandedMassCategory, setExpandedMassCategory] = useState<string | null>('tanks');

  const { config, massBudget, trajectory, structures, thermal, recovery, constraints } = design;

  const violatedConstraintsCount = constraints.filter((c) => c.isViolated).length;

  return (
    <div className="space-y-6">
      {/* Active Design Banner & Key Specs */}
      <div className="bg-[#0f1422] border border-slate-800 rounded-lg p-4 lg:p-5 flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="text-xs font-mono uppercase tracking-wider text-cyan-400 mb-1">
            ACTIVE DESIGN SPECIFICATION
          </div>
          <h1 className="text-xl lg:text-2xl font-bold text-white font-technical tracking-wide">
            {config.name}
          </h1>
          <div className="flex items-center gap-3 text-xs text-slate-400 font-mono mt-1">
            <span>DIAMETER: {config.diameterM}m</span>
            <span>·</span>
            <span>LENGTH: {config.totalLengthM}m</span>
            <span>·</span>
            <span>ENGINES: {config.engineCount}x {config.fuelType}/LOX</span>
            <span>·</span>
            <span>PROFILE: {config.recoveryProfile}</span>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={() => onNavigateTab('digital-twin')}
            className="px-3.5 py-1.5 text-xs font-medium text-slate-200 bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded transition-colors"
          >
            Inspect Digital Twin
          </button>
          <button
            onClick={() => onNavigateTab('design-space')}
            className="px-3.5 py-1.5 text-xs font-medium text-white bg-cyan-700 hover:bg-cyan-600 rounded transition-colors"
          >
            Explore Design Space
          </button>
        </div>
      </div>

      {/* Main Four Quadrant Matrix Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Quadrant 1: MASS BUDGET */}
        <div className="bg-[#0d121e] border border-slate-800/90 rounded-lg p-4 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-2 mb-3 border-b border-slate-800">
              <div className="flex items-center gap-2">
                <Weight className="w-4 h-4 text-blue-400" />
                <span className="text-xs font-bold uppercase tracking-wider text-slate-300">TOTAL MASS</span>
              </div>
              <span className="text-xs font-mono text-blue-300">
                {(massBudget.totalLiftoffMassKg / 1000).toFixed(1)} t
              </span>
            </div>

            <div className="space-y-2.5 text-xs font-mono">
              <div className="flex items-center justify-between">
                <span className="text-slate-400">TOTAL LIFTOFF MASS</span>
                <span className="text-slate-100 font-bold tabular-nums">
                  {massBudget.totalLiftoffMassKg.toLocaleString()} kg
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-400">DRY MASS</span>
                <span className="text-cyan-300 font-semibold tabular-nums">
                  {massBudget.totalDryMassKg.toLocaleString()} kg
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-400">PROPELLANT MASS</span>
                <span className="text-slate-200 tabular-nums">
                  {massBudget.propellantMassKg.toLocaleString()} kg
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-400">STRUCTURAL MASS</span>
                <span className="text-slate-300 tabular-nums">
                  {(massBudget.primaryStructureMassKg + massBudget.secondaryStructureMassKg).toLocaleString()} kg
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-400">ENGINE CLUSTER MASS</span>
                <span className="text-slate-300 tabular-nums">
                  {massBudget.propulsionMassKg.toLocaleString()} kg
                </span>
              </div>
            </div>
          </div>

          <div className="mt-4 pt-2 border-t border-slate-800/80 text-[11px] font-mono text-slate-400 flex items-center justify-between">
            <span>PROPELLANT FRACTION</span>
            <span className="text-cyan-400 font-bold">
              {(massBudget.fractions.propellantFraction * 100).toFixed(2)} %
            </span>
          </div>
        </div>

        {/* Quadrant 2: PERFORMANCE */}
        <div className="bg-[#0d121e] border border-slate-800/90 rounded-lg p-4 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-2 mb-3 border-b border-slate-800">
              <div className="flex items-center gap-2">
                <Flame className="w-4 h-4 text-amber-400" />
                <span className="text-xs font-bold uppercase tracking-wider text-slate-300">PERFORMANCE</span>
              </div>
              <span className="text-xs font-mono text-amber-300">
                {trajectory.stagingVelocityMS.toFixed(0)} m/s
              </span>
            </div>

            <div className="space-y-2.5 text-xs font-mono">
              <div className="flex items-center justify-between">
                <span className="text-slate-400">MAXIMUM ACCELERATION</span>
                <span className="text-slate-100 font-bold tabular-nums">
                  {trajectory.maxAccelerationG} g
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-400">MAX DYNAMIC PRESSURE (MAX-Q)</span>
                <span className="text-cyan-300 font-semibold tabular-nums">
                  {trajectory.maxDynamicPressureKPa} kPa
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-400">PROPULSION DURATION</span>
                <span className="text-slate-200 tabular-nums">
                  {trajectory.stagingTimeSec} s
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-400">STAGING ALTITUDE</span>
                <span className="text-slate-300 tabular-nums">
                  {trajectory.stagingAltitudeKm} km
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-400">TOTAL DELIVERED ΔV</span>
                <span className="text-emerald-400 font-semibold tabular-nums">
                  {trajectory.totalDeliveredDeltaVMS} m/s
                </span>
              </div>
            </div>
          </div>

          <div className="mt-4 pt-2 border-t border-slate-800/80 text-[11px] font-mono text-slate-400 flex items-center justify-between">
            <span>STAGING MACH NUMBER</span>
            <span className="text-amber-400 font-bold">
              M {trajectory.stagingMach}
            </span>
          </div>
        </div>

        {/* Quadrant 3: STRUCTURES & THERMAL */}
        <div className="bg-[#0d121e] border border-slate-800/90 rounded-lg p-4 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-2 mb-3 border-b border-slate-800">
              <div className="flex items-center gap-2">
                <Shield className="w-4 h-4 text-emerald-400" />
                <span className="text-xs font-bold uppercase tracking-wider text-slate-300">STRUCTURES</span>
              </div>
              <span className="text-xs font-mono text-emerald-300">
                MS: +{(structures.structuralMarginOfSafety * 100).toFixed(1)}%
              </span>
            </div>

            <div className="space-y-2.5 text-xs font-mono">
              <div className="flex items-center justify-between">
                <span className="text-slate-400">MAXIMUM AXIAL LOAD</span>
                <span className="text-slate-100 font-bold tabular-nums">
                  {structures.appliedCompressiveLoadKn.toFixed(0)} kN
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-400">STRUCTURAL SAFETY MARGIN</span>
                <span className={`font-semibold tabular-nums ${structures.structuralMarginOfSafety >= 0.15 ? 'text-emerald-400' : 'text-rose-400'}`}>
                  +{(structures.structuralMarginOfSafety * 100).toFixed(1)} %
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-400">THERMAL SAFETY MARGIN</span>
                <span className={`font-semibold tabular-nums ${thermal.thermalMarginOfSafety >= 0.15 ? 'text-emerald-400' : 'text-rose-400'}`}>
                  +{(thermal.thermalMarginOfSafety * 100).toFixed(1)} %
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-400">PEAK HEAT FLUX</span>
                <span className="text-slate-300 tabular-nums">
                  {thermal.peakStagnationHeatFluxKwM2.toFixed(1)} kW/m²
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-400">CRYO BOIL-OFF RATE</span>
                <span className="text-slate-300 tabular-nums">
                  {thermal.cryoBoilOffRateKgPerHr.toFixed(1)} kg/hr
                </span>
              </div>
            </div>
          </div>

          <div className="mt-4 pt-2 border-t border-slate-800/80 text-[11px] font-mono text-slate-400 flex items-center justify-between">
            <span>BUCKLING CAPACITY</span>
            <span className="text-slate-200">
              {structures.compressiveBucklingCapacityKn.toFixed(0)} kN
            </span>
          </div>
        </div>

        {/* Quadrant 4: RECOVERY & OPTIMISATION */}
        <div className="bg-[#0d121e] border border-slate-800/90 rounded-lg p-4 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-2 mb-3 border-b border-slate-800">
              <div className="flex items-center gap-2">
                <RotateCcw className="w-4 h-4 text-purple-400" />
                <span className="text-xs font-bold uppercase tracking-wider text-slate-300">RECOVERY & OPT</span>
              </div>
              <span className="text-xs font-mono text-purple-300">
                {recovery.profile}
              </span>
            </div>

            <div className="space-y-2.5 text-xs font-mono">
              <div className="flex items-center justify-between">
                <span className="text-slate-400">RESERVE PROPELLANT</span>
                <span className="text-slate-100 font-bold tabular-nums">
                  {massBudget.reservePropellantKg.toLocaleString()} kg
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-400">RECOVERY HARDWARE MASS</span>
                <span className="text-cyan-300 font-semibold tabular-nums">
                  {massBudget.recoveryHardwareMassKg.toLocaleString()} kg
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-400">TURNAROUND ESTIMATE</span>
                <span className="text-slate-200 tabular-nums">
                  {recovery.refurbishmentDurationDays.toFixed(1)} days
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-400">DESIGNS EVALUATED</span>
                <span className="text-slate-200 tabular-nums">
                  {totalDesignsEvaluated}
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-400">PARETO OPTIMAL DESIGNS</span>
                <span className="text-cyan-400 font-bold tabular-nums">
                  {paretoCount}
                </span>
              </div>
            </div>
          </div>

          <div className="mt-4 pt-2 border-t border-slate-800/80 text-[11px] font-mono text-slate-400 flex items-center justify-between">
            <span>CONSTRAINT VIOLATIONS</span>
            <span className={violatedConstraintsCount === 0 ? 'text-emerald-400 font-bold' : 'text-rose-400 font-bold'}>
              {violatedConstraintsCount === 0 ? '0 (ALL SATISFIED)' : `${violatedConstraintsCount} VIOLATIONS`}
            </span>
          </div>
        </div>
      </div>

      {/* Hierarchical Mass Budget & Constraint Verification Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Cols: Hierarchical Mass Budget Breakdown */}
        <div className="lg:col-span-2 bg-[#0c101c] border border-slate-800 rounded-lg p-5">
          <div className="flex items-center justify-between pb-3 mb-4 border-b border-slate-800">
            <div>
              <h2 className="text-sm font-bold text-white uppercase tracking-wider font-technical">
                Hierarchical Mass Budget & Uncertainty Tree
              </h2>
              <p className="text-xs text-slate-400 mt-0.5">
                Mass closure verification: sum(components) == {massBudget.totalLiftoffMassKg.toLocaleString()} kg (residual: {massBudget.massClosureResidualKg} kg)
              </p>
            </div>
            <span className="text-xs font-mono px-2 py-0.5 rounded bg-slate-800 text-slate-300 border border-slate-700">
              CONFIDENCE: 98.4%
            </span>
          </div>

          {/* Mass Fractions Bar */}
          <div className="mb-5">
            <div className="flex items-center justify-between text-xs font-mono text-slate-400 mb-1.5">
              <span>VEHICLE MASS FRACTIONS</span>
              <span>100.0% LIFTOFF MASS</span>
            </div>
            <div className="h-4 w-full bg-slate-800 rounded overflow-hidden flex border border-slate-700/80">
              <div
                style={{ width: `${massBudget.fractions.propellantFraction * 100}%` }}
                className="bg-blue-600 h-full title-tooltip"
                title={`Propellant: ${(massBudget.fractions.propellantFraction * 100).toFixed(1)}%`}
              />
              <div
                style={{ width: `${massBudget.fractions.structuralFraction * 100}%` }}
                className="bg-amber-600 h-full"
                title={`Structure: ${(massBudget.fractions.structuralFraction * 100).toFixed(1)}%`}
              />
              <div
                style={{ width: `${massBudget.fractions.propulsionFraction * 100}%` }}
                className="bg-purple-600 h-full"
                title={`Propulsion: ${(massBudget.fractions.propulsionFraction * 100).toFixed(1)}%`}
              />
              <div
                style={{ width: `${massBudget.fractions.recoveryFraction * 100}%` }}
                className="bg-teal-600 h-full"
                title={`Recovery: ${(massBudget.fractions.recoveryFraction * 100).toFixed(1)}%`}
              />
            </div>
            <div className="flex flex-wrap items-center gap-4 text-[11px] font-mono mt-2 text-slate-400">
              <div className="flex items-center gap-1.5">
                <div className="w-2.5 h-2.5 bg-blue-600 rounded-sm" />
                <span>Propellant ({(massBudget.fractions.propellantFraction * 100).toFixed(1)}%)</span>
              </div>
              <div className="flex items-center gap-1.5">
                <div className="w-2.5 h-2.5 bg-amber-600 rounded-sm" />
                <span>Structure ({(massBudget.fractions.structuralFraction * 100).toFixed(1)}%)</span>
              </div>
              <div className="flex items-center gap-1.5">
                <div className="w-2.5 h-2.5 bg-purple-600 rounded-sm" />
                <span>Propulsion ({(massBudget.fractions.propulsionFraction * 100).toFixed(1)}%)</span>
              </div>
              <div className="flex items-center gap-1.5">
                <div className="w-2.5 h-2.5 bg-teal-600 rounded-sm" />
                <span>Recovery ({(massBudget.fractions.recoveryFraction * 100).toFixed(1)}%)</span>
              </div>
            </div>
          </div>

          {/* Mass Component Accordion List */}
          <div className="space-y-2 font-mono text-xs">
            {massBudget.components.map((comp) => {
              const hasSubs = comp.subcomponents && comp.subcomponents.length > 0;
              const isExpanded = expandedMassCategory === comp.category;

              return (
                <div key={comp.name} className="border border-slate-800 rounded bg-[#090d16] overflow-hidden">
                  <div
                    onClick={() => hasSubs && setExpandedMassCategory(isExpanded ? null : comp.category)}
                    className={`p-3 flex items-center justify-between cursor-pointer hover:bg-slate-800/40 transition-colors ${
                      isExpanded ? 'bg-slate-800/30' : ''
                    }`}
                  >
                    <div className="flex items-center gap-2.5">
                      {hasSubs ? (
                        isExpanded ? (
                          <ChevronDown className="w-4 h-4 text-cyan-400" />
                        ) : (
                          <ChevronRight className="w-4 h-4 text-slate-400" />
                        )
                      ) : (
                        <div className="w-4" />
                      )}
                      <div>
                        <span className="font-semibold text-slate-200">{comp.name}</span>
                        <div className="text-[11px] text-slate-400 mt-0.5">
                          <span>{comp.source}</span> · <span>{comp.model}</span>
                        </div>
                      </div>
                    </div>

                    <div className="text-right">
                      <div className="font-bold text-slate-100 tabular-nums">
                        {comp.massKg.toLocaleString()} kg
                      </div>
                      <div className="text-[11px] text-slate-400">
                        ±{comp.uncertaintyKg} kg ·{' '}
                        <span className="text-cyan-400">{comp.classification}</span>
                      </div>
                    </div>
                  </div>

                  {/* Subcomponents */}
                  {hasSubs && isExpanded && (
                    <div className="bg-[#070a12] border-t border-slate-800/70 p-3 space-y-2 pl-9">
                      {comp.subcomponents!.map((sub) => (
                        <div key={sub.name} className="flex items-center justify-between py-1 border-b border-slate-900 last:border-0">
                          <div>
                            <div className="text-slate-300">{sub.name}</div>
                            <div className="text-[10px] text-slate-400">{sub.source}</div>
                          </div>
                          <div className="text-right">
                            <div className="text-slate-200 tabular-nums">{sub.massKg.toLocaleString()} kg</div>
                            <div className="text-[10px] text-slate-400">±{sub.uncertaintyKg} kg ({sub.classification})</div>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>

        {/* Right 1 Col: Engineering Constraints Status */}
        <div className="bg-[#0c101c] border border-slate-800 rounded-lg p-5 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-3 mb-4 border-b border-slate-800">
              <h2 className="text-sm font-bold text-white uppercase tracking-wider font-technical">
                Constraint Engine
              </h2>
              <span className={`text-xs font-mono px-2 py-0.5 rounded border ${
                violatedConstraintsCount === 0
                  ? 'bg-emerald-950/40 text-emerald-300 border-emerald-800/60'
                  : 'bg-rose-950/40 text-rose-300 border-rose-800/60'
              }`}>
                {violatedConstraintsCount === 0 ? 'FEASIBLE' : 'VIOLATION'}
              </span>
            </div>

            <div className="space-y-3 font-mono text-xs">
              {constraints.map((c) => (
                <div
                  key={c.id}
                  className={`p-3 rounded border transition-colors ${
                    c.isViolated
                      ? 'bg-rose-950/20 border-rose-800/70 text-rose-200'
                      : 'bg-slate-900/60 border-slate-800 text-slate-300'
                  }`}
                >
                  <div className="flex items-center justify-between mb-1">
                    <div className="flex items-center gap-1.5 font-semibold">
                      {c.isViolated ? (
                        <XCircle className="w-3.5 h-3.5 text-rose-400 shrink-0" />
                      ) : (
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                      )}
                      <span>{c.name}</span>
                    </div>
                    <span className={`text-[11px] font-bold ${c.isViolated ? 'text-rose-400' : 'text-emerald-400'}`}>
                      {c.isViolated ? 'VIOLATED' : 'PASS'}
                    </span>
                  </div>

                  <div className="grid grid-cols-2 gap-2 text-[11px] text-slate-400 mt-2">
                    <div>
                      CURRENT VALUE: <span className="text-slate-200 font-bold">{c.value.toFixed(2)} {c.unit}</span>
                    </div>
                    <div>
                      LIMIT: <span className="text-slate-200 font-bold">{c.isUpperBound ? '≤' : '≥'} {c.limit} {c.unit}</span>
                    </div>
                  </div>

                  <div className="mt-2 text-[11px] text-slate-400 flex items-center justify-between">
                    <span>MARGIN TO LIMIT:</span>
                    <span className={c.margin >= 0 ? 'text-emerald-400 font-bold' : 'text-rose-400 font-bold'}>
                      {c.margin >= 0 ? `+${(c.margin * 100).toFixed(1)}%` : `${(c.margin * 100).toFixed(1)}%`}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="mt-6 pt-4 border-t border-slate-800 text-xs text-slate-400 font-mono">
            <div className="flex items-center justify-between">
              <span>SOLVER CONVERGENCE:</span>
              <span className="text-emerald-400 font-bold">
                {design.convergence.iterations} ITERATIONS ({design.convergence.massResidualKg} kg residual)
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
