import React from 'react';
import { BoosterVehicleConfig } from '../engine/types';
import { PRESET_CONFIGURATIONS } from '../engine/default_config';
import { 
  Rocket, 
  RotateCcw, 
  SlidersHorizontal, 
  FileText, 
  Terminal, 
  Layers, 
  BarChart3, 
  GitCompare, 
  ShieldCheck, 
  Compass,
  Cpu
} from 'lucide-react';

interface TopHeaderProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  currentConfig: BoosterVehicleConfig;
  onSelectPreset: (config: BoosterVehicleConfig) => void;
  onToggleDrawer: () => void;
  onOpenReport: () => void;
  isConverging: boolean;
}

export const TopHeader: React.FC<TopHeaderProps> = ({
  activeTab,
  setActiveTab,
  currentConfig,
  onSelectPreset,
  onToggleDrawer,
  onOpenReport,
  isConverging,
}) => {
  const navTabs = [
    { id: 'cockpit', label: 'Overview', icon: Rocket },
    { id: 'design-space', label: 'Design Space', icon: Compass },
    { id: 'digital-twin', label: 'Digital Twin', icon: Layers },
    { id: 'trajectory', label: 'Trajectory', icon: BarChart3 },
    { id: 'subsystems', label: 'Subsystems', icon: Cpu },
    { id: 'sensitivity-uq', label: 'Sensitivity & UQ', icon: BarChart3 },
    { id: 'trade-studies', label: 'Trade Studies', icon: Layers },
    { id: 'compare', label: 'Compare', icon: GitCompare },
    { id: 'validation', label: 'Validation', icon: ShieldCheck },
    { id: 'cli', label: 'CLI Console', icon: Terminal },
  ];

  return (
    <header className="bg-[#090d16] border-b border-slate-800/80 sticky top-0 z-40 px-4 lg:px-6 py-2.5">
      <div className="flex items-center justify-between gap-4">
        {/* Zone 1: Brand Title */}
        <div className="flex items-center gap-3 shrink-0">
          <div className="w-8 h-8 rounded bg-gradient-to-br from-blue-600 to-slate-900 border border-blue-500/30 flex items-center justify-center text-white shadow-inner">
            <Rocket className="w-4 h-4 text-cyan-400" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-technical text-base font-bold tracking-wider text-slate-100 uppercase">
                Newton Rockets Ltd.
              </span>
              <span className="hidden sm:inline-block text-xs font-mono px-1.5 py-0.5 rounded bg-slate-800 text-cyan-400 border border-cyan-900/40">
                BOOSTER OPTIMISER v3.7
              </span>
            </div>
          </div>
        </div>

        {/* Zone 2: Navigation Links (single-line, clean unboxed text) */}
        <nav className="hidden xl:flex items-center gap-1 overflow-x-auto py-0.5">
          {navTabs.map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded text-xs font-medium transition-all whitespace-nowrap ${
                  isActive
                    ? 'bg-slate-800/90 text-cyan-300 border border-cyan-500/30 shadow-sm'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/40'
                }`}
              >
                <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-cyan-400' : 'text-slate-400'}`} />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </nav>

        {/* Zone 3: Actions & Controls */}
        <div className="flex items-center gap-2.5 shrink-0">
          {/* Preset Selector */}
          <select
            value={currentConfig.name}
            onChange={(e) => {
              const selected = Object.values(PRESET_CONFIGURATIONS).find((p) => p.name === e.target.value);
              if (selected) onSelectPreset(selected);
            }}
            className="bg-slate-900/90 border border-slate-700/80 rounded px-2.5 py-1 text-xs text-slate-200 font-mono focus:outline-none focus:border-cyan-500 max-w-[180px] truncate"
          >
            {Object.entries(PRESET_CONFIGURATIONS).map(([label, preset]) => (
              <option key={preset.id} value={preset.name} className="bg-slate-900 text-slate-200">
                {label}
              </option>
            ))}
          </select>

          {/* Edit Parameters Drawer Trigger */}
          <button
            onClick={onToggleDrawer}
            className="flex items-center gap-1.5 px-2.5 py-1 text-xs font-medium text-slate-300 bg-slate-800/90 hover:bg-slate-750 border border-slate-700 rounded transition-colors whitespace-nowrap"
            title="Adjust Vehicle Variables & Material"
          >
            <SlidersHorizontal className="w-3.5 h-3.5 text-cyan-400" />
            <span className="hidden md:inline">Parameters</span>
          </button>

          {/* Export Engineering Report */}
          <button
            onClick={onOpenReport}
            className="flex items-center gap-1.5 px-3 py-1 text-xs font-medium text-white bg-blue-700 hover:bg-blue-600 rounded transition-colors shadow-sm whitespace-nowrap"
          >
            <FileText className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Report</span>
          </button>
        </div>
      </div>

      {/* Mobile/Tablet Secondary Nav Bar */}
      <div className="flex xl:hidden items-center gap-1 overflow-x-auto pt-2 border-t border-slate-800/50 mt-2">
        {navTabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center gap-1.5 px-2.5 py-1 rounded text-xs font-medium whitespace-nowrap ${
                isActive
                  ? 'bg-slate-800 text-cyan-300 border border-cyan-500/30'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Icon className="w-3 h-3" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>
    </header>
  );
};
