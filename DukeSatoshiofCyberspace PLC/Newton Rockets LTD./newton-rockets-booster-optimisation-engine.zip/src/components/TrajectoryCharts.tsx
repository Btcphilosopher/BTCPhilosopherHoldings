import React, { useState } from 'react';
import { TrajectorySummary, TrajectoryPoint } from '../engine/types';
import { Activity, Gauge, Flame, TrendingUp, BarChart3, Clock, Compass } from 'lucide-react';

interface TrajectoryChartsProps {
  trajectory: TrajectorySummary;
}

type MetricKey = 'altitudeM' | 'velocityMS' | 'dynamicPressureKPa' | 'accelerationG' | 'aerothermalHeatFluxKwM2' | 'vehicleMassKg';

const METRIC_CONFIGS: Array<{
  key: MetricKey;
  label: string;
  unit: string;
  color: string;
  transform?: (v: number) => number;
  formatUnit?: string;
}> = [
  {
    key: 'altitudeM',
    label: 'Altitude vs Time',
    unit: 'km',
    color: '#06b6d4',
    transform: (v) => v / 1000.0,
    formatUnit: 'km',
  },
  {
    key: 'velocityMS',
    label: 'Velocity vs Time',
    unit: 'm/s',
    color: '#3b82f6',
    formatUnit: 'm/s',
  },
  {
    key: 'dynamicPressureKPa',
    label: 'Dynamic Pressure (q) vs Time',
    unit: 'kPa',
    color: '#f59e0b',
    formatUnit: 'kPa',
  },
  {
    key: 'accelerationG',
    label: 'Axial Acceleration vs Time',
    unit: 'g',
    color: '#ec4899',
    formatUnit: 'g',
  },
  {
    key: 'aerothermalHeatFluxKwM2',
    label: 'Stagnation Heat Flux vs Time',
    unit: 'kW/m²',
    color: '#ef4444',
    formatUnit: 'kW/m²',
  },
  {
    key: 'vehicleMassKg',
    label: 'Continuous Mass Depletion vs Time',
    unit: 't',
    color: '#8b5cf6',
    transform: (v) => v / 1000.0,
    formatUnit: 't',
  },
];

export const TrajectoryCharts: React.FC<TrajectoryChartsProps> = ({ trajectory }) => {
  const [scrubIndex, setScrubIndex] = useState<number>(Math.floor(trajectory.points.length / 2));

  const scrubPoint = trajectory.points[scrubIndex] || trajectory.points[0];

  // Helper to render an SVG line chart for a metric
  const renderChart = (metric: (typeof METRIC_CONFIGS)[0]) => {
    const points = trajectory.points;
    if (!points || points.length === 0) return null;

    const values = points.map((p) => {
      const raw = metric.transform ? metric.transform(p[metric.key]) : p[metric.key];
      return isNaN(raw) ? 0 : raw;
    });
    let minVal = Math.min(0, ...values);
    let maxVal = Math.max(...values);
    if (!isFinite(minVal) || !isFinite(maxVal) || minVal === maxVal) {
      minVal = 0;
      maxVal = 100;
    } else {
      maxVal = maxVal * 1.1;
    }

    const maxTime = Math.max(1.0, points[points.length - 1]?.timeSec || 1.0);

    const w = 480;
    const h = 200;
    const margin = { top: 15, right: 15, bottom: 25, left: 45 };
    const pw = w - margin.left - margin.right;
    const ph = h - margin.top - margin.bottom;

    const valRange = maxVal - minVal || 1.0;

    const polyPoints = points
      .map((p, idx) => {
        const x = margin.left + ((p.timeSec || 0) / maxTime) * pw;
        const yVal = values[idx];
        const y = margin.top + ph - ((yVal - minVal) / valRange) * ph;
        return `${isFinite(x) ? x : margin.left},${isFinite(y) ? y : margin.top + ph}`;
      })
      .join(' ');

    const scrubTime = scrubPoint?.timeSec || 0;
    const scrubX = margin.left + (scrubTime / maxTime) * pw;
    const scrubRaw = metric.transform ? metric.transform(scrubPoint?.[metric.key] || 0) : (scrubPoint?.[metric.key] || 0);
    const scrubVal = isNaN(scrubRaw) ? 0 : scrubRaw;
    const scrubY = margin.top + ph - ((scrubVal - minVal) / valRange) * ph;

    const safeScrubX = isFinite(scrubX) ? scrubX : margin.left;
    const safeScrubY = isFinite(scrubY) ? scrubY : margin.top + ph;

    return (
      <div key={metric.key} className="bg-[#0c101c] border border-slate-800 rounded-lg p-4 flex flex-col justify-between">
        <div className="flex items-center justify-between mb-2">
          <span className="text-xs font-bold text-slate-200 font-technical uppercase">
            {metric.label}
          </span>
          <span className="text-xs font-mono font-bold" style={{ color: metric.color }}>
            {scrubVal.toFixed(1)} {metric.formatUnit || metric.unit}
          </span>
        </div>

        <svg viewBox={`0 0 ${w} ${h}`} className="w-full h-auto font-mono text-[9px]">
          {/* Grid lines */}
          <line x1={margin.left} y1={margin.top} x2={margin.left + pw} y2={margin.top} stroke="#1e293b" strokeDasharray="2 2" />
          <line x1={margin.left} y1={margin.top + ph / 2} x2={margin.left + pw} y2={margin.top + ph / 2} stroke="#1e293b" strokeDasharray="2 2" />
          <line x1={margin.left} y1={margin.top + ph} x2={margin.left + pw} y2={margin.top + ph} stroke="#334155" />

          {/* Y Axis Ticks */}
          <text x={margin.left - 6} y={margin.top + 8} fill="#64748b" textAnchor="end">
            {maxVal.toFixed(0)}
          </text>
          <text x={margin.left - 6} y={margin.top + ph} fill="#64748b" textAnchor="end">
            {minVal.toFixed(0)}
          </text>

          {/* X Axis Ticks */}
          <text x={margin.left} y={h - 6} fill="#64748b" textAnchor="start">
            T+0s
          </text>
          <text x={margin.left + pw} y={h - 6} fill="#64748b" textAnchor="end">
            T+{maxTime.toFixed(0)}s
          </text>

          {/* Line Chart */}
          <polyline points={polyPoints} fill="none" stroke={metric.color} strokeWidth="2" strokeLinecap="round" />

          {/* Scrub Needle */}
          <line x1={safeScrubX} y1={margin.top} x2={safeScrubX} y2={margin.top + ph} stroke="#ffffff" strokeWidth="1" strokeDasharray="3 2" />
          <circle cx={safeScrubX} cy={safeScrubY} r="4" fill={metric.color} stroke="#ffffff" strokeWidth="1.5" />
        </svg>
      </div>
    );
  };

  return (
    <div className="space-y-6">
      {/* Trajectory Header & Scrub Controller */}
      <div className="bg-[#0f1422] border border-slate-800 rounded-lg p-4 flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <Activity className="w-4 h-4 text-cyan-400" />
            <h1 className="text-base font-bold text-white uppercase font-technical tracking-wide">
              3-DOF Flight Dynamics & Telemetry Streams
            </h1>
          </div>
          <p className="text-xs text-slate-400">
            RK4 Numerical Integrator · Gravity Turn Program · Staging at T+{trajectory.stagingTimeSec}s
          </p>
        </div>

        {/* Flight Time Scrubber */}
        <div className="flex items-center gap-3 bg-slate-900 border border-slate-800 rounded px-3 py-1.5 font-mono text-xs">
          <Clock className="w-4 h-4 text-cyan-400" />
          <span className="text-slate-300">TIME: T+{scrubPoint.timeSec.toFixed(1)}s</span>
          <input
            type="range"
            min={0}
            max={trajectory.points.length - 1}
            value={scrubIndex}
            onChange={(e) => setScrubIndex(Number(e.target.value))}
            className="w-36 accent-cyan-500 cursor-pointer"
          />
          <span className="text-cyan-400 font-bold px-1.5 py-0.5 rounded bg-slate-800 border border-slate-700">
            {scrubPoint.phase}
          </span>
        </div>
      </div>

      {/* Scrubbed Live Telemetry Bar */}
      <div className="bg-[#0d121e] border border-slate-800 rounded-lg p-4 grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 text-xs font-mono">
        <div>
          <span className="text-slate-400 block text-[10px]">ALTITUDE</span>
          <span className="text-white font-bold text-sm">{(scrubPoint.altitudeM / 1000).toFixed(2)} km</span>
        </div>
        <div>
          <span className="text-slate-400 block text-[10px]">VELOCITY</span>
          <span className="text-cyan-300 font-bold text-sm">{scrubPoint.velocityMS.toFixed(1)} m/s</span>
        </div>
        <div>
          <span className="text-slate-400 block text-[10px]">MACH NUMBER</span>
          <span className="text-amber-300 font-bold text-sm">M {scrubPoint.mach.toFixed(2)}</span>
        </div>
        <div>
          <span className="text-slate-400 block text-[10px]">DYNAMIC PRESSURE</span>
          <span className="text-amber-400 font-bold text-sm">{scrubPoint.dynamicPressureKPa.toFixed(2)} kPa</span>
        </div>
        <div>
          <span className="text-slate-400 block text-[10px]">AXIAL LOAD</span>
          <span className="text-emerald-400 font-bold text-sm">{scrubPoint.structuralAxialLoadKn.toFixed(0)} kN</span>
        </div>
        <div>
          <span className="text-slate-400 block text-[10px]">REMAINING MASS</span>
          <span className="text-purple-300 font-bold text-sm">{scrubPoint.vehicleMassKg.toLocaleString()} kg</span>
        </div>
      </div>

      {/* 2x3 Matrix of Trajectory Plots */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {METRIC_CONFIGS.map((m) => renderChart(m))}
      </div>
    </div>
  );
};
