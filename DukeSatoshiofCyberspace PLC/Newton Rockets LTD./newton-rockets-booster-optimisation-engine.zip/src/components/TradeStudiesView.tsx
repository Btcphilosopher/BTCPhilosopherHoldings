import React, { useState, useMemo } from 'react';
import { EvaluatedDesign, TradeStudy } from '../engine/types';
import { 
  runDiameterTradeStudy, 
  runPropellantReserveTradeStudy, 
  runStructuralFactorTradeStudy, 
  runSofiThicknessTradeStudy 
} from '../engine/trade_studies';
import { Layers, Lightbulb, CheckCircle2, TrendingUp, Sparkles } from 'lucide-react';

interface TradeStudiesViewProps {
  design: EvaluatedDesign;
}

export const TradeStudiesView: React.FC<TradeStudiesViewProps> = ({ design }) => {
  const [activeStudyId, setActiveStudyId] = useState<string>('ts_diameter');

  const studies: TradeStudy[] = useMemo(() => {
    return [
      runDiameterTradeStudy(design.config),
      runPropellantReserveTradeStudy(design.config),
      runStructuralFactorTradeStudy(design.config),
      runSofiThicknessTradeStudy(design.config),
    ];
  }, [design.config]);

  const activeStudy = studies.find((s) => s.id === activeStudyId) || studies[0];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-[#0f1422] border border-slate-800 rounded-lg p-4 flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <Layers className="w-4 h-4 text-cyan-400" />
            <h1 className="text-base font-bold text-white uppercase font-technical tracking-wide">
              Automated Engineering Trade Studies
            </h1>
          </div>
          <p className="text-xs text-slate-400">
            Parametric sweeps across critical architecture levers · Exposing trade-offs without artificial biasing
          </p>
        </div>

        {/* Trade Study Selector */}
        <div className="flex flex-wrap items-center gap-1.5 p-1 bg-slate-900 border border-slate-800 rounded text-xs font-mono">
          {studies.map((s) => (
            <button
              key={s.id}
              onClick={() => setActiveStudyId(s.id)}
              className={`px-3 py-1.5 rounded transition-all whitespace-nowrap ${
                activeStudy.id === s.id
                  ? 'bg-slate-800 text-cyan-300 border border-cyan-500/30 font-semibold'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              {s.title}
            </button>
          ))}
        </div>
      </div>

      {/* Main Trade Study Analysis Content */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Cols: Parametric Curve & Data Table */}
        <div className="lg:col-span-2 bg-[#0c101c] border border-slate-800 rounded-lg p-5 space-y-5">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <div>
              <h2 className="text-sm font-bold text-white uppercase font-technical">{activeStudy.title}</h2>
              <p className="text-xs text-slate-400 mt-0.5">{activeStudy.description}</p>
            </div>
            <span className="text-xs font-mono px-2 py-0.5 rounded bg-slate-800 text-cyan-400 border border-slate-700">
              BASELINE: {activeStudy.baselineValue} {activeStudy.parameterUnit}
            </span>
          </div>

          {/* Trade Curve Visual */}
          <div className="bg-[#07090e] border border-slate-900 rounded p-4">
            {(() => {
              const points = activeStudy.points || [];
              const w = 560;
              const h = 220;
              const margin = { top: 20, right: 30, bottom: 35, left: 55 };
              const pw = w - margin.left - margin.right;
              const ph = h - margin.top - margin.bottom;

              const xVals = points.map((p) => p.parameterValue).filter((v) => !isNaN(v));
              const yVals = points.map((p) => p.stagingDeltaVMS).filter((v) => !isNaN(v));
              let xMin = xVals.length ? Math.min(...xVals) : 0;
              let xMax = xVals.length ? Math.max(...xVals) : 100;
              let yMin = yVals.length ? Math.min(...yVals) * 0.98 : 0;
              let yMax = yVals.length ? Math.max(...yVals) * 1.02 : 100;

              if (!isFinite(xMin) || !isFinite(xMax) || xMin === xMax) {
                xMin = 0;
                xMax = 100;
              }
              if (!isFinite(yMin) || !isFinite(yMax) || yMin === yMax) {
                yMin = 0;
                yMax = 100;
              }

              const xRange = Math.abs(xMax - xMin) || 1.0;
              const yRange = Math.abs(yMax - yMin) || 1.0;

              const polyPoints = points
                .map((p) => {
                  const x = margin.left + ((p.parameterValue - xMin) / xRange) * pw;
                  const y = margin.top + ph - ((p.stagingDeltaVMS - yMin) / yRange) * ph;
                  return `${isFinite(x) ? x : margin.left},${isFinite(y) ? y : margin.top + ph}`;
                })
                .join(' ');

              return (
                <svg viewBox={`0 0 ${w} ${h}`} className="w-full h-auto font-mono text-[9px]">
                  {/* Grid */}
                  <line x1={margin.left} y1={margin.top} x2={margin.left + pw} y2={margin.top} stroke="#1e293b" strokeDasharray="2 2" />
                  <line x1={margin.left} y1={margin.top + ph / 2} x2={margin.left + pw} y2={margin.top + ph / 2} stroke="#1e293b" strokeDasharray="2 2" />
                  <line x1={margin.left} y1={margin.top + ph} x2={margin.left + pw} y2={margin.top + ph} stroke="#334155" />

                  {/* Y Axis */}
                  <text x={margin.left - 8} y={margin.top + 8} fill="#64748b" textAnchor="end">{yMax.toFixed(0)} m/s</text>
                  <text x={margin.left - 8} y={margin.top + ph} fill="#64748b" textAnchor="end">{yMin.toFixed(0)} m/s</text>

                  {/* Polyline */}
                  <polyline points={polyPoints} fill="none" stroke="#06b6d4" strokeWidth="2.5" />

                  {/* Points */}
                  {points.map((p) => {
                    const cx = margin.left + ((p.parameterValue - xMin) / xRange) * pw;
                    const cy = margin.top + ph - ((p.stagingDeltaVMS - yMin) / yRange) * ph;
                    const safeCx = isFinite(cx) ? cx : margin.left;
                    const safeCy = isFinite(cy) ? cy : margin.top + ph;
                    const isBase = Math.abs(p.parameterValue - activeStudy.baselineValue) < 0.01;
                    return (
                      <g key={p.parameterValue}>
                        <circle
                          cx={safeCx}
                          cy={safeCy}
                          r={isBase ? 6 : 4}
                          fill={isBase ? '#10b981' : p.isFeasible ? '#06b6d4' : '#ef4444'}
                          stroke="#ffffff"
                          strokeWidth="1.5"
                        />
                        <text x={safeCx} y={h - 10} fill="#94a3b8" textAnchor="middle">
                          {p.parameterValue}
                        </text>
                      </g>
                    );
                  })}
                </svg>
              );
            })()}
          </div>

          {/* Parametric Data Table */}
          <div className="overflow-x-auto">
            <table className="w-full font-mono text-xs text-left border-collapse">
              <thead>
                <tr className="border-b border-slate-800 text-slate-400 bg-slate-900/60">
                  <th className="py-2 px-3">{activeStudy.parameterName} ({activeStudy.parameterUnit})</th>
                  <th className="py-2 px-3">Dry Mass (kg)</th>
                  <th className="py-2 px-3">Staging ΔV (m/s)</th>
                  <th className="py-2 px-3">Max-Q (kPa)</th>
                  <th className="py-2 px-3">MS Struct</th>
                  <th className="py-2 px-3">Status</th>
                </tr>
              </thead>
              <tbody>
                {activeStudy.points.map((pt) => {
                  const isBase = Math.abs(pt.parameterValue - activeStudy.baselineValue) < 0.01;
                  return (
                    <tr
                      key={pt.parameterValue}
                      className={`border-b border-slate-900/80 hover:bg-slate-800/30 transition-colors ${
                        isBase ? 'bg-cyan-950/20 font-bold text-cyan-200' : 'text-slate-300'
                      }`}
                    >
                      <td className="py-2 px-3">{pt.parameterValue} {activeStudy.parameterUnit} {isBase && '(Baseline)'}</td>
                      <td className="py-2 px-3 tabular-nums">{pt.dryMassKg.toLocaleString()}</td>
                      <td className="py-2 px-3 text-emerald-400 tabular-nums">{pt.stagingDeltaVMS.toFixed(1)}</td>
                      <td className="py-2 px-3 tabular-nums">{pt.maxDynamicPressureKPa.toFixed(2)}</td>
                      <td className="py-2 px-3 tabular-nums">+{(pt.structuralMargin * 100).toFixed(1)}%</td>
                      <td className="py-2 px-3">
                        <span className={`px-1.5 py-0.5 rounded text-[10px] ${
                          pt.isFeasible ? 'bg-emerald-950/50 text-emerald-300' : 'bg-rose-950/50 text-rose-300'
                        }`}>
                          {pt.isFeasible ? 'FEASIBLE' : 'VIOLATION'}
                        </span>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>

        {/* Right 1 Col: Engineering Insights & Trade Implications */}
        <div className="bg-[#0c101c] border border-slate-800 rounded-lg p-5 flex flex-col justify-between">
          <div>
            <div className="flex items-center gap-2 pb-3 mb-4 border-b border-slate-800">
              <Lightbulb className="w-4 h-4 text-amber-400" />
              <h2 className="text-sm font-bold text-white uppercase font-technical">
                Engineering Trade Insights
              </h2>
            </div>

            <div className="space-y-4 font-mono text-xs">
              {activeStudy.insights.map((insight, idx) => (
                <div key={idx} className="p-3 bg-slate-900/80 rounded border border-slate-800 flex gap-2.5">
                  <span className="text-cyan-400 font-bold">0{idx + 1}.</span>
                  <p className="text-slate-300 leading-relaxed text-[11px]">{insight}</p>
                </div>
              ))}
            </div>
          </div>

          <div className="mt-6 pt-4 border-t border-slate-800 text-[11px] font-mono text-slate-400">
            <span>Newton Rockets Multidisciplinary Trade Engine</span>
          </div>
        </div>
      </div>
    </div>
  );
};
