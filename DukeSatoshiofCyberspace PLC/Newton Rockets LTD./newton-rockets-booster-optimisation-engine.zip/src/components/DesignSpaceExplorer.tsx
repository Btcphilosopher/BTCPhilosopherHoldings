import React, { useState, useMemo } from 'react';
import { EvaluatedDesign } from '../engine/types';
import { Compass, Filter, Sparkles, CheckCircle2, AlertCircle, Info, ArrowUpRight } from 'lucide-react';

interface DesignSpaceExplorerProps {
  designs: EvaluatedDesign[];
  paretoDesigns: EvaluatedDesign[];
  activeDesign: EvaluatedDesign;
  onSelectDesign: (design: EvaluatedDesign) => void;
}

type AxisMetric = 
  | 'dryMassKg'
  | 'stagingDeltaVMS'
  | 'maxDynamicPressureKPa'
  | 'structuralMargin'
  | 'thermalMargin'
  | 'recoveryReserveKg'
  | 'turnaroundDays'
  | 'estimatedCostKgbp';

const AXIS_OPTIONS: Array<{ id: AxisMetric; label: string; unit: string }> = [
  { id: 'dryMassKg', label: 'Dry Mass', unit: 'kg' },
  { id: 'stagingDeltaVMS', label: 'Staging Delivered ΔV', unit: 'm/s' },
  { id: 'maxDynamicPressureKPa', label: 'Max-Q Dynamic Pressure', unit: 'kPa' },
  { id: 'structuralMargin', label: 'Structural Safety Margin', unit: '-' },
  { id: 'thermalMargin', label: 'Thermal Safety Margin', unit: '-' },
  { id: 'recoveryReserveKg', label: 'Landing Propellant Reserve', unit: 'kg' },
  { id: 'turnaroundDays', label: 'Turnaround Duration', unit: 'days' },
  { id: 'estimatedCostKgbp', label: 'Refurbishment Cost', unit: 'k£' },
];

export const DesignSpaceExplorer: React.FC<DesignSpaceExplorerProps> = ({
  designs,
  paretoDesigns,
  activeDesign,
  onSelectDesign,
}) => {
  const [xAxis, setXAxis] = useState<AxisMetric>('dryMassKg');
  const [yAxis, setYAxis] = useState<AxisMetric>('stagingDeltaVMS');
  const [filterOnlyFeasible, setFilterOnlyFeasible] = useState(true);
  const [highlightPareto, setHighlightPareto] = useState(true);
  const [hoveredDesign, setHoveredDesign] = useState<EvaluatedDesign | null>(null);

  const paretoIds = useMemo(() => new Set(paretoDesigns.map((d) => d.id)), [paretoDesigns]);

  // Filtered designs
  const filteredDesigns = useMemo(() => {
    return designs.filter((d) => {
      if (filterOnlyFeasible && !d.allConstraintsMet) return false;
      return true;
    });
  }, [designs, filterOnlyFeasible]);

  // Compute min/max for coordinate mapping
  const bounds = useMemo(() => {
    let xMin = Infinity;
    let xMax = -Infinity;
    let yMin = Infinity;
    let yMax = -Infinity;

    if (filteredDesigns.length > 0) {
      filteredDesigns.forEach((d) => {
        const xVal = Number(d.objectives[xAxis]);
        const yVal = Number(d.objectives[yAxis]);
        if (!isNaN(xVal)) {
          if (xVal < xMin) xMin = xVal;
          if (xVal > xMax) xMax = xVal;
        }
        if (!isNaN(yVal)) {
          if (yVal < yMin) yMin = yVal;
          if (yVal > yMax) yMax = yVal;
        }
      });
    }

    if (!isFinite(xMin) || !isFinite(xMax) || xMin === xMax) {
      xMin = 0;
      xMax = 100;
    }
    if (!isFinite(yMin) || !isFinite(yMax) || yMin === yMax) {
      yMin = 0;
      yMax = 100;
    }

    const xSpan = Math.abs(xMax - xMin);
    const ySpan = Math.abs(yMax - yMin);
    const xPad = (xSpan * 0.08) || 1.0;
    const yPad = (ySpan * 0.08) || 1.0;

    return {
      xMin: xMin - xPad,
      xMax: xMax + xPad,
      yMin: yMin - yPad,
      yMax: yMax + yPad,
    };
  }, [filteredDesigns, xAxis, yAxis]);

  const xLabel = AXIS_OPTIONS.find((o) => o.id === xAxis) || AXIS_OPTIONS[0];
  const yLabel = AXIS_OPTIONS.find((o) => o.id === yAxis) || AXIS_OPTIONS[1];

  // SVG dimensions
  const svgWidth = 740;
  const svgHeight = 440;
  const margin = { top: 30, right: 30, bottom: 50, left: 75 };
  const plotWidth = svgWidth - margin.left - margin.right;
  const plotHeight = svgHeight - margin.top - margin.bottom;

  function mapX(val: number): number {
    const denom = bounds.xMax - bounds.xMin;
    if (!isFinite(val) || !isFinite(denom) || denom === 0) return margin.left;
    const res = margin.left + ((val - bounds.xMin) / denom) * plotWidth;
    return isFinite(res) ? res : margin.left;
  }

  function mapY(val: number): number {
    const denom = bounds.yMax - bounds.yMin;
    if (!isFinite(val) || !isFinite(denom) || denom === 0) return margin.top + plotHeight;
    const res = margin.top + plotHeight - ((val - bounds.yMin) / denom) * plotHeight;
    return isFinite(res) ? res : margin.top + plotHeight;
  }

  // Sorted Pareto line points
  const paretoLinePoints = useMemo(() => {
    const sortedPareto = [...paretoDesigns].sort((a, b) => a.objectives[xAxis] - b.objectives[xAxis]);
    return sortedPareto.map((d) => `${mapX(d.objectives[xAxis])},${mapY(d.objectives[yAxis])}`).join(' ');
  }, [paretoDesigns, xAxis, yAxis, bounds]);

  return (
    <div className="space-y-6">
      {/* Header & Axis Selection Toolbar */}
      <div className="bg-[#0f1422] border border-slate-800 rounded-lg p-4 flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <Compass className="w-4 h-4 text-cyan-400" />
            <h1 className="text-base font-bold text-white uppercase font-technical tracking-wide">
              Design Space Explorer & Pareto Frontier
            </h1>
          </div>
          <p className="text-xs text-slate-400">
            Evaluating {designs.length} candidate configurations across multi-dimensional objective bounds
          </p>
        </div>

        {/* Axis & Filter Controls */}
        <div className="flex flex-wrap items-center gap-3 text-xs font-mono">
          <div className="flex items-center gap-1.5">
            <span className="text-slate-400">X-AXIS:</span>
            <select
              value={xAxis}
              onChange={(e) => setXAxis(e.target.value as AxisMetric)}
              className="bg-slate-900 border border-slate-700 rounded px-2.5 py-1 text-slate-200 focus:outline-none focus:border-cyan-500"
            >
              {AXIS_OPTIONS.map((opt) => (
                <option key={opt.id} value={opt.id}>
                  {opt.label} ({opt.unit})
                </option>
              ))}
            </select>
          </div>

          <div className="flex items-center gap-1.5">
            <span className="text-slate-400">Y-AXIS:</span>
            <select
              value={yAxis}
              onChange={(e) => setYAxis(e.target.value as AxisMetric)}
              className="bg-slate-900 border border-slate-700 rounded px-2.5 py-1 text-slate-200 focus:outline-none focus:border-cyan-500"
            >
              {AXIS_OPTIONS.map((opt) => (
                <option key={opt.id} value={opt.id}>
                  {opt.label} ({opt.unit})
                </option>
              ))}
            </select>
          </div>

          <label className="flex items-center gap-1.5 cursor-pointer text-slate-300">
            <input
              type="checkbox"
              checked={filterOnlyFeasible}
              onChange={(e) => setFilterOnlyFeasible(e.target.checked)}
              className="rounded bg-slate-900 border-slate-700 text-cyan-600 focus:ring-0"
            />
            <span>Only Feasible ({filteredDesigns.length})</span>
          </label>

          <label className="flex items-center gap-1.5 cursor-pointer text-slate-300">
            <input
              type="checkbox"
              checked={highlightPareto}
              onChange={(e) => setHighlightPareto(e.target.checked)}
              className="rounded bg-slate-900 border-slate-700 text-cyan-600 focus:ring-0"
            />
            <span>Show Pareto Frontier ({paretoDesigns.length})</span>
          </label>
        </div>
      </div>

      {/* Main Scatter Canvas & Inspector Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Cols: Scatter Plot Canvas */}
        <div className="lg:col-span-2 bg-[#0c101c] border border-slate-800 rounded-lg p-4 flex flex-col justify-between">
          <div className="relative overflow-hidden w-full">
            <svg
              viewBox={`0 0 ${svgWidth} ${svgHeight}`}
              className="w-full h-auto bg-[#07090e] border border-slate-900 rounded font-mono text-[10px]"
            >
              {/* Grid Lines */}
              {[0.2, 0.4, 0.6, 0.8].map((ratio) => {
                const xVal = bounds.xMin + ratio * (bounds.xMax - bounds.xMin);
                const yVal = bounds.yMin + ratio * (bounds.yMax - bounds.yMin);
                const x = mapX(xVal);
                const y = mapY(yVal);
                return (
                  <React.Fragment key={ratio}>
                    <line x1={x} y1={margin.top} x2={x} y2={margin.top + plotHeight} stroke="#1e293b" strokeDasharray="3 3" />
                    <line x1={margin.left} y1={y} x2={margin.left + plotWidth} y2={y} stroke="#1e293b" strokeDasharray="3 3" />
                    {/* Axis Ticks */}
                    <text x={x} y={svgHeight - 20} fill="#64748b" textAnchor="middle">
                      {xVal >= 1000 ? (xVal / 1000).toFixed(1) + 'k' : xVal.toFixed(1)}
                    </text>
                    <text x={margin.left - 10} y={y + 4} fill="#64748b" textAnchor="end">
                      {yVal >= 1000 ? (yVal / 1000).toFixed(1) + 'k' : yVal.toFixed(1)}
                    </text>
                  </React.Fragment>
                );
              })}

              {/* Axis Labels */}
              <text
                x={margin.left + plotWidth / 2}
                y={svgHeight - 5}
                fill="#94a3b8"
                textAnchor="middle"
                className="font-technical uppercase tracking-wider text-xs font-semibold"
              >
                {xLabel.label} [{xLabel.unit}]
              </text>
              <text
                x={-((margin.top + plotHeight / 2))}
                y={20}
                fill="#94a3b8"
                textAnchor="middle"
                transform="rotate(-90)"
                className="font-technical uppercase tracking-wider text-xs font-semibold"
              >
                {yLabel.label} [{yLabel.unit}]
              </text>

              {/* Pareto Frontier Line */}
              {highlightPareto && paretoLinePoints && (
                <polyline
                  points={paretoLinePoints}
                  fill="none"
                  stroke="#06b6d4"
                  strokeWidth="2"
                  strokeDasharray="4 2"
                  className="opacity-80"
                />
              )}

              {/* Candidate Design Points */}
              {filteredDesigns.map((d) => {
                const isPareto = paretoIds.has(d.id);
                const isActive = d.id === activeDesign.id;
                const isHovered = hoveredDesign?.id === d.id;
                const cx = mapX(d.objectives[xAxis]);
                const cy = mapY(d.objectives[yAxis]);

                let fillColor = '#475569';
                let strokeColor = '#334155';
                let radius = 4;

                if (!d.allConstraintsMet) {
                  fillColor = '#ef4444';
                  strokeColor = '#991b1b';
                } else if (isPareto) {
                  fillColor = '#06b6d4';
                  strokeColor = '#22d3ee';
                  radius = 5.5;
                } else {
                  fillColor = '#3b82f6';
                  strokeColor = '#60a5fa';
                }

                if (isActive) {
                  fillColor = '#10b981';
                  strokeColor = '#34d399';
                  radius = 8;
                }

                return (
                  <circle
                    key={d.id}
                    cx={cx}
                    cy={cy}
                    r={isHovered ? radius + 3 : radius}
                    fill={fillColor}
                    stroke={strokeColor}
                    strokeWidth={isActive ? 3 : 1.5}
                    className="cursor-pointer transition-all hover:scale-125"
                    onClick={() => onSelectDesign(d)}
                    onMouseEnter={() => setHoveredDesign(d)}
                    onMouseLeave={() => setHoveredDesign(null)}
                  />
                );
              })}
            </svg>
          </div>

          <div className="mt-3 flex items-center justify-between text-xs font-mono text-slate-400">
            <div className="flex items-center gap-4">
              <span className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-full bg-cyan-400 inline-block" /> Pareto Optimal
              </span>
              <span className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-full bg-blue-500 inline-block" /> Feasible Candidate
              </span>
              <span className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-full bg-rose-500 inline-block" /> Infeasible
              </span>
              <span className="flex items-center gap-1.5">
                <span className="w-3 h-3 rounded-full bg-emerald-500 border-2 border-white inline-block" /> Active
              </span>
            </div>
            <span>Click any design point to load and simulate</span>
          </div>
        </div>

        {/* Right 1 Col: Candidate Inspector Panel */}
        <div className="bg-[#0c101c] border border-slate-800 rounded-lg p-5 flex flex-col justify-between">
          {(() => {
            const insp = hoveredDesign || activeDesign;
            const isPareto = paretoIds.has(insp.id);

            return (
              <div>
                <div className="flex items-center justify-between pb-3 mb-4 border-b border-slate-800">
                  <div>
                    <span className="text-[11px] font-mono text-cyan-400 uppercase">
                      {hoveredDesign ? 'HOVERED CANDIDATE' : 'ACTIVE LOADED DESIGN'}
                    </span>
                    <h2 className="text-sm font-bold text-white font-technical">{insp.name}</h2>
                  </div>
                  <span
                    className={`text-xs font-mono px-2 py-0.5 rounded border ${
                      isPareto
                        ? 'bg-cyan-950/60 text-cyan-300 border-cyan-800/80'
                        : 'bg-slate-800 text-slate-300 border-slate-700'
                    }`}
                  >
                    {isPareto ? 'PARETO FRONTIER' : 'FEASIBLE'}
                  </span>
                </div>

                <div className="space-y-3 font-mono text-xs">
                  <div className="flex items-center justify-between py-1 border-b border-slate-800/60">
                    <span className="text-slate-400">DESIGN ID</span>
                    <span className="text-slate-200 font-bold">{insp.id}</span>
                  </div>
                  <div className="flex items-center justify-between py-1 border-b border-slate-800/60">
                    <span className="text-slate-400">DIAMETER / LENGTH</span>
                    <span className="text-slate-200">{insp.config.diameterM}m / {insp.config.totalLengthM}m</span>
                  </div>
                  <div className="flex items-center justify-between py-1 border-b border-slate-800/60">
                    <span className="text-slate-400">DRY MASS</span>
                    <span className="text-cyan-300 font-bold">{insp.objectives.dryMassKg.toLocaleString()} kg</span>
                  </div>
                  <div className="flex items-center justify-between py-1 border-b border-slate-800/60">
                    <span className="text-slate-400">STAGING DELIVERED ΔV</span>
                    <span className="text-emerald-400 font-bold">{insp.objectives.stagingDeltaVMS.toFixed(1)} m/s</span>
                  </div>
                  <div className="flex items-center justify-between py-1 border-b border-slate-800/60">
                    <span className="text-slate-400">MAX DYNAMIC PRESSURE</span>
                    <span className="text-slate-200">{insp.objectives.maxDynamicPressureKPa.toFixed(2)} kPa</span>
                  </div>
                  <div className="flex items-center justify-between py-1 border-b border-slate-800/60">
                    <span className="text-slate-400">STRUCTURAL SAFETY MARGIN</span>
                    <span className={insp.objectives.structuralMargin >= 0.15 ? 'text-emerald-400' : 'text-rose-400'}>
                      +{(insp.objectives.structuralMargin * 100).toFixed(1)}%
                    </span>
                  </div>
                  <div className="flex items-center justify-between py-1 border-b border-slate-800/60">
                    <span className="text-slate-400">LANDING RESERVE</span>
                    <span className="text-slate-200">{Math.round(insp.objectives.recoveryReserveKg).toLocaleString()} kg</span>
                  </div>
                  <div className="flex items-center justify-between py-1 border-b border-slate-800/60">
                    <span className="text-slate-400">TURNAROUND DAYS</span>
                    <span className="text-slate-200">{insp.objectives.turnaroundDays.toFixed(1)} days</span>
                  </div>
                </div>

                <div className="mt-6">
                  {insp.id !== activeDesign.id ? (
                    <button
                      onClick={() => onSelectDesign(insp)}
                      className="w-full py-2 px-4 text-xs font-medium text-white bg-cyan-700 hover:bg-cyan-600 rounded transition-colors flex items-center justify-center gap-2"
                    >
                      <span>Load Candidate as Active Design</span>
                      <ArrowUpRight className="w-3.5 h-3.5" />
                    </button>
                  ) : (
                    <div className="w-full py-2 px-4 text-xs font-mono text-center text-emerald-400 bg-emerald-950/40 border border-emerald-800/60 rounded">
                      CURRENTLY ACTIVE DESIGN
                    </div>
                  )}
                </div>
              </div>
            );
          })()}
        </div>
      </div>
    </div>
  );
};
