import React, { useState } from 'react';
import { EvaluatedDesign } from '../engine/types';
import { PRESET_CONFIGURATIONS } from '../engine/default_config';
import { runCoupledConvergence } from '../engine/convergence';
import { GitCompare, CheckCircle2, XCircle, ArrowUpRight } from 'lucide-react';

interface DesignComparisonMatrixProps {
  activeDesign: EvaluatedDesign;
  onSelectDesign: (design: EvaluatedDesign) => void;
}

export const DesignComparisonMatrix: React.FC<DesignComparisonMatrixProps> = ({
  activeDesign,
  onSelectDesign,
}) => {
  const comparisonDesigns = React.useMemo(() => {
    return Object.values(PRESET_CONFIGURATIONS).map((cfg) => runCoupledConvergence(cfg));
  }, []);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-[#0f1422] border border-slate-800 rounded-lg p-4 flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <GitCompare className="w-4 h-4 text-cyan-400" />
            <h1 className="text-base font-bold text-white uppercase font-technical tracking-wide">
              Architectural Trade Comparison Matrix (Design A vs B vs C vs D)
            </h1>
          </div>
          <p className="text-xs text-slate-400">
            Side-by-side multi-candidate evaluation · Exposing trade-offs without declaring an artificial single winner
          </p>
        </div>
      </div>

      {/* Comparison Table */}
      <div className="bg-[#0c101c] border border-slate-800 rounded-lg p-5 overflow-x-auto">
        <table className="w-full font-mono text-xs text-left border-collapse min-w-[760px]">
          <thead>
            <tr className="border-b border-slate-800 text-slate-400 bg-slate-900/60">
              <th className="py-3 px-4 w-1/4">ENGINEERING METRIC</th>
              {comparisonDesigns.map((d, i) => (
                <th key={d.id} className="py-3 px-4">
                  <div className="text-cyan-300 font-bold uppercase font-technical text-sm">
                    DESIGN {String.fromCharCode(65 + i)}: {d.config.name}
                  </div>
                  <div className="text-[10px] text-slate-400 font-mono mt-0.5">
                    {d.config.diameterM}m · {d.config.fuelType}/LOX · {d.config.recoveryProfile}
                  </div>
                </th>
              ))}
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800/60">
            {/* Liftoff Mass */}
            <tr className="hover:bg-slate-800/20">
              <td className="py-2.5 px-4 font-semibold text-slate-300">Total Liftoff Mass</td>
              {comparisonDesigns.map((d) => (
                <td key={d.id} className="py-2.5 px-4 tabular-nums text-slate-100 font-bold">
                  {d.massBudget.totalLiftoffMassKg.toLocaleString()} kg
                </td>
              ))}
            </tr>

            {/* Dry Mass */}
            <tr className="hover:bg-slate-800/20">
              <td className="py-2.5 px-4 font-semibold text-slate-300">Dry Mass</td>
              {comparisonDesigns.map((d) => (
                <td key={d.id} className="py-2.5 px-4 tabular-nums text-cyan-300 font-semibold">
                  {d.massBudget.totalDryMassKg.toLocaleString()} kg
                </td>
              ))}
            </tr>

            {/* Propellant Fraction */}
            <tr className="hover:bg-slate-800/20">
              <td className="py-2.5 px-4 font-semibold text-slate-300">Propellant Mass Fraction</td>
              {comparisonDesigns.map((d) => (
                <td key={d.id} className="py-2.5 px-4 tabular-nums text-slate-200">
                  {(d.massBudget.fractions.propellantFraction * 100).toFixed(2)} %
                </td>
              ))}
            </tr>

            {/* Staging Velocity */}
            <tr className="hover:bg-slate-800/20">
              <td className="py-2.5 px-4 font-semibold text-slate-300">Staging Burnout Velocity (ΔV)</td>
              {comparisonDesigns.map((d) => (
                <td key={d.id} className="py-2.5 px-4 tabular-nums text-emerald-400 font-bold">
                  {d.trajectory.stagingVelocityMS.toFixed(1)} m/s ({d.trajectory.totalDeliveredDeltaVMS.toFixed(0)} m/s total)
                </td>
              ))}
            </tr>

            {/* Max Dynamic Pressure */}
            <tr className="hover:bg-slate-800/20">
              <td className="py-2.5 px-4 font-semibold text-slate-300">Max-Q Dynamic Pressure</td>
              {comparisonDesigns.map((d) => (
                <td key={d.id} className="py-2.5 px-4 tabular-nums text-amber-300">
                  {d.trajectory.maxDynamicPressureKPa.toFixed(2)} kPa
                </td>
              ))}
            </tr>

            {/* Structural Safety Margin */}
            <tr className="hover:bg-slate-800/20">
              <td className="py-2.5 px-4 font-semibold text-slate-300">Structural Safety Margin (MS)</td>
              {comparisonDesigns.map((d) => (
                <td key={d.id} className="py-2.5 px-4 tabular-nums font-semibold">
                  <span className={d.structures.structuralMarginOfSafety >= 0.15 ? 'text-emerald-400' : 'text-rose-400'}>
                    +{(d.structures.structuralMarginOfSafety * 100).toFixed(1)} %
                  </span>
                </td>
              ))}
            </tr>

            {/* Thermal Safety Margin */}
            <tr className="hover:bg-slate-800/20">
              <td className="py-2.5 px-4 font-semibold text-slate-300">Thermal Safety Margin</td>
              {comparisonDesigns.map((d) => (
                <td key={d.id} className="py-2.5 px-4 tabular-nums text-slate-200">
                  +{(d.thermal.thermalMarginOfSafety * 100).toFixed(1)} %
                </td>
              ))}
            </tr>

            {/* Recovery Hardware Mass */}
            <tr className="hover:bg-slate-800/20">
              <td className="py-2.5 px-4 font-semibold text-slate-300">Recovery Hardware Mass</td>
              {comparisonDesigns.map((d) => (
                <td key={d.id} className="py-2.5 px-4 tabular-nums text-slate-300">
                  {d.recovery.recoveryHardwareMassKg.toLocaleString()} kg
                </td>
              ))}
            </tr>

            {/* Turnaround Duration */}
            <tr className="hover:bg-slate-800/20">
              <td className="py-2.5 px-4 font-semibold text-slate-300">Turnaround Duration</td>
              {comparisonDesigns.map((d) => (
                <td key={d.id} className="py-2.5 px-4 tabular-nums text-slate-300">
                  {d.recovery.refurbishmentDurationDays.toFixed(1)} days
                </td>
              ))}
            </tr>

            {/* Constraints Feasibility */}
            <tr className="hover:bg-slate-800/20 bg-slate-900/30">
              <td className="py-3 px-4 font-semibold text-slate-200">Feasibility Status</td>
              {comparisonDesigns.map((d) => (
                <td key={d.id} className="py-3 px-4">
                  <div className="flex items-center gap-1.5 font-bold">
                    {d.allConstraintsMet ? (
                      <span className="text-emerald-400 flex items-center gap-1">
                        <CheckCircle2 className="w-3.5 h-3.5" /> ALL CONSTRAINTS MET
                      </span>
                    ) : (
                      <span className="text-rose-400 flex items-center gap-1">
                        <XCircle className="w-3.5 h-3.5" /> VIOLATIONS DETECTED
                      </span>
                    )}
                  </div>
                </td>
              ))}
            </tr>

            {/* Action Row */}
            <tr>
              <td className="py-3 px-4 font-semibold text-slate-400">Load Action</td>
              {comparisonDesigns.map((d) => (
                <td key={d.id} className="py-3 px-4">
                  {d.id !== activeDesign.id ? (
                    <button
                      onClick={() => onSelectDesign(d)}
                      className="px-3 py-1 text-xs font-medium text-white bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded transition-colors flex items-center gap-1.5"
                    >
                      <span>Select Design</span>
                      <ArrowUpRight className="w-3 h-3" />
                    </button>
                  ) : (
                    <span className="text-cyan-400 font-bold text-xs">ACTIVE LOADED</span>
                  )}
                </td>
              ))}
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  );
};
