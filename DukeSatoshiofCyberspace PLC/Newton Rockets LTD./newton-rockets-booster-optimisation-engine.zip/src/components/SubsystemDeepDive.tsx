import React, { useState } from 'react';
import { EvaluatedDesign } from '../engine/types';
import { Cpu, Flame, Shield, Thermometer, RotateCcw, Box, ArrowRight } from 'lucide-react';

interface SubsystemDeepDiveProps {
  design: EvaluatedDesign;
}

export const SubsystemDeepDive: React.FC<SubsystemDeepDiveProps> = ({ design }) => {
  const [selectedTab, setSelectedTab] = useState<'cryotank' | 'propulsion' | 'structures' | 'thermal' | 'recovery'>('cryotank');

  const { config, massBudget, trajectory, structures, thermal, recovery } = design;

  const tabs = [
    { id: 'cryotank', label: '1. Cryotank Digital Twin', icon: Box, color: 'text-blue-400' },
    { id: 'propulsion', label: '2. Propulsion Model', icon: Flame, color: 'text-amber-400' },
    { id: 'structures', label: '3. Structures & Loads', icon: Shield, color: 'text-emerald-400' },
    { id: 'thermal', label: '4. Thermal Environment', icon: Thermometer, color: 'text-rose-400' },
    { id: 'recovery', label: '5. Recovery & Turnaround', icon: RotateCcw, color: 'text-purple-400' },
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-[#0f1422] border border-slate-800 rounded-lg p-4 flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <Cpu className="w-4 h-4 text-cyan-400" />
            <h1 className="text-base font-bold text-white uppercase font-technical tracking-wide">
              Subsystem Digital Twin Deep-Dive
            </h1>
          </div>
          <p className="text-xs text-slate-400">
            Newton Rockets coupled digital twins · Real-time parameter extraction & physics traceability
          </p>
        </div>

        {/* Subsystem Tabs */}
        <div className="flex flex-wrap items-center gap-1.5 p-1 bg-slate-900 border border-slate-800 rounded text-xs font-mono">
          {tabs.map((t) => {
            const Icon = t.icon;
            const isActive = selectedTab === t.id;
            return (
              <button
                key={t.id}
                onClick={() => setSelectedTab(t.id as any)}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded transition-all ${
                  isActive
                    ? 'bg-slate-800 text-cyan-300 border border-cyan-500/30 font-semibold'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-cyan-400' : 'text-slate-400'}`} />
                <span>{t.label}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Subsystem Content View */}
      {selectedTab === 'cryotank' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="bg-[#0c101c] border border-slate-800 rounded-lg p-5 space-y-4">
            <h2 className="text-sm font-bold text-blue-400 uppercase font-technical">
              Newton Cryogenic Tank Digital Twin Interface
            </h2>
            <p className="text-xs text-slate-300 leading-relaxed font-mono">
              Integrates membrane hoop stress sizing for liquid oxygen and liquid methane pressure vessels. Incorporates ASME 2:1 ellipsoidal domes, cylindrical weld lands, anti-slosh suppression baffles, and spray-on foam insulation (SOFI).
            </p>
            <div className="p-4 bg-slate-900/80 rounded border border-slate-800 font-mono text-xs space-y-2.5">
              <div className="flex justify-between">
                <span className="text-slate-400">TANK MATERIAL:</span>
                <span className="text-white font-bold">{config.material}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">OPERATING PRESSURE:</span>
                <span className="text-cyan-300 font-bold">{config.tankPressureBar} bar (300 kPa)</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">DESIGN BURST PRESSURE:</span>
                <span className="text-slate-200">{(config.tankPressureBar * 1.4 * 1.05).toFixed(2)} bar (Proof SF=1.4)</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">MEMBRANE HOOP STRESS:</span>
                <span className="text-emerald-400 font-bold">{structures.hoopStressMpa.toFixed(1)} MPa</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">SOFI FOAM THICKNESS:</span>
                <span className="text-slate-200">{config.sofiInsulationThicknessMm} mm</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">ON-PAD CRYO BOIL-OFF:</span>
                <span className="text-amber-300 font-bold">{thermal.cryoBoilOffRateKgPerHr.toFixed(1)} kg/hr</span>
              </div>
            </div>
          </div>

          <div className="bg-[#0c101c] border border-slate-800 rounded-lg p-5 space-y-4">
            <h2 className="text-sm font-bold text-white uppercase font-technical">
              Cryotank Governing Physical Equations
            </h2>
            <div className="space-y-3 font-mono text-xs text-slate-300">
              <div className="p-3 bg-slate-900 rounded border border-slate-800">
                <div className="text-slate-400 text-[10px] mb-1">MEMBRANE HOOP STRESS SIZING:</div>
                <div className="text-cyan-300 font-bold">t = (p_burst · r) / (σ_allow · e_weld)</div>
              </div>
              <div className="p-3 bg-slate-900 rounded border border-slate-800">
                <div className="text-slate-400 text-[10px] mb-1">ASME 2:1 ELLIPSOIDAL DOME VOLUME:</div>
                <div className="text-cyan-300 font-bold">V_dome = (1/3) · π · r³</div>
              </div>
              <div className="p-3 bg-slate-900 rounded border border-slate-800">
                <div className="text-slate-400 text-[10px] mb-1">CRYO BOIL-OFF MASS FLOW:</div>
                <div className="text-cyan-300 font-bold">ṁ_boil = (k_sofi · A · ΔT) / (δ_sofi · L_v)</div>
              </div>
            </div>
          </div>
        </div>
      )}

      {selectedTab === 'propulsion' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="bg-[#0c101c] border border-slate-800 rounded-lg p-5 space-y-4">
            <h2 className="text-sm font-bold text-amber-400 uppercase font-technical">
              Newton Propulsion Digital Twin Interface
            </h2>
            <p className="text-xs text-slate-300 leading-relaxed font-mono">
              Extracts high-pressure staged-combustion engine cycle operating points, back-pressure ambient expansion losses, and thrust vector control gimbal hydraulics.
            </p>
            <div className="p-4 bg-slate-900/80 rounded border border-slate-800 font-mono text-xs space-y-2.5">
              <div className="flex justify-between">
                <span className="text-slate-400">ENGINE CLUSTER:</span>
                <span className="text-white font-bold">{config.engineCount}x {config.engineName}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">SEA-LEVEL THRUST (TOTAL):</span>
                <span className="text-amber-400 font-bold">
                  {((config.seaLevelThrustPerEngineKn * config.engineCount) / 1000).toFixed(2)} MN
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">VACUUM THRUST (TOTAL):</span>
                <span className="text-amber-300 font-bold">
                  {((config.vacuumThrustPerEngineKn * config.engineCount) / 1000).toFixed(2)} MN
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">SEA-LEVEL ISP / VACUUM ISP:</span>
                <span className="text-cyan-300 font-bold">{config.seaLevelIspSec} s / {config.vacuumIspSec} s</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">ENGINE CLUSTER DRY MASS:</span>
                <span className="text-slate-200">{(config.engineCount * config.engineMassPerUnitKg).toLocaleString()} kg</span>
              </div>
            </div>
          </div>

          <div className="bg-[#0c101c] border border-slate-800 rounded-lg p-5 space-y-4">
            <h2 className="text-sm font-bold text-white uppercase font-technical">
              Propulsion Governing Equations
            </h2>
            <div className="space-y-3 font-mono text-xs text-slate-300">
              <div className="p-3 bg-slate-900 rounded border border-slate-800">
                <div className="text-slate-400 text-[10px] mb-1">PRESSURE-DEPENDENT THRUST:</div>
                <div className="text-amber-300 font-bold">F(p_a) = ṁ · v_e + (p_e - p_a) · A_e</div>
              </div>
              <div className="p-3 bg-slate-900 rounded border border-slate-800">
                <div className="text-slate-400 text-[10px] mb-1">TOTAL MASS FLOW RATE:</div>
                <div className="text-amber-300 font-bold">ṁ = F_total / (I_sp · g_0)</div>
              </div>
            </div>
          </div>
        </div>
      )}

      {selectedTab === 'structures' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="bg-[#0c101c] border border-slate-800 rounded-lg p-5 space-y-4">
            <h2 className="text-sm font-bold text-emerald-400 uppercase font-technical">
              Newton Structures & Loads Digital Twin
            </h2>
            <p className="text-xs text-slate-300 leading-relaxed font-mono">
              Evaluates compressive cylindrical shell buckling according to NASA SP-8007 criteria with isogrid stiffeners. Computes axial thrust loads, aerodynamic drag compression, and combined safety margins.
            </p>
            <div className="p-4 bg-slate-900/80 rounded border border-slate-800 font-mono text-xs space-y-2.5">
              <div className="flex justify-between">
                <span className="text-slate-400">PEAK APPLIED COMPRESSIVE LOAD:</span>
                <span className="text-white font-bold">{structures.appliedCompressiveLoadKn.toFixed(0)} kN</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">BUCKLING CAPACITY (CRITICAL):</span>
                <span className="text-emerald-400 font-bold">{structures.compressiveBucklingCapacityKn.toFixed(0)} kN</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">BUCKLING MARGIN OF SAFETY (MS):</span>
                <span className="text-emerald-300 font-bold">+{(structures.bucklingMarginOfSafety * 100).toFixed(1)} %</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">STRUCTURAL FACTOR (k_struct):</span>
                <span className="text-slate-200">{config.structuralFactor}</span>
              </div>
            </div>
          </div>

          <div className="bg-[#0c101c] border border-slate-800 rounded-lg p-5 space-y-4">
            <h2 className="text-sm font-bold text-white uppercase font-technical">
              Structural Shell Buckling Equations
            </h2>
            <div className="space-y-3 font-mono text-xs text-slate-300">
              <div className="p-3 bg-slate-900 rounded border border-slate-800">
                <div className="text-slate-400 text-[10px] mb-1">NASA SP-8007 COMPRESSIVE SHELL BUCKLING:</div>
                <div className="text-emerald-300 font-bold">P_crit = [2π · γ · E · t² / √(3(1 - ν²))] · k_isogrid</div>
              </div>
              <div className="p-3 bg-slate-900 rounded border border-slate-800">
                <div className="text-slate-400 text-[10px] mb-1">MARGIN OF SAFETY:</div>
                <div className="text-emerald-300 font-bold">MS = (P_crit / (1.4 · P_applied)) - 1.0</div>
              </div>
            </div>
          </div>
        </div>
      )}

      {selectedTab === 'thermal' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="bg-[#0c101c] border border-slate-800 rounded-lg p-5 space-y-4">
            <h2 className="text-sm font-bold text-rose-400 uppercase font-technical">
              Newton Aerothermal Digital Twin Interface
            </h2>
            <p className="text-xs text-slate-300 leading-relaxed font-mono">
              Fay-Riddell / Sutton-Graves stagnation heat flux modeling, radiative equilibrium temperature, and PICA-X silicone tile TPS mass sizing.
            </p>
            <div className="p-4 bg-slate-900/80 rounded border border-slate-800 font-mono text-xs space-y-2.5">
              <div className="flex justify-between">
                <span className="text-slate-400">PEAK STAGNATION HEAT FLUX:</span>
                <span className="text-rose-400 font-bold">{thermal.peakStagnationHeatFluxKwM2.toFixed(1)} kW/m²</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">TOTAL INTEGRATED HEAT LOAD:</span>
                <span className="text-slate-200">{thermal.totalIntegratedHeatLoadMjM2.toFixed(2)} MJ/m²</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">PEAK SKIN EQUILIBRIUM TEMP:</span>
                <span className="text-amber-300 font-bold">{thermal.peakSkinTemperatureK.toFixed(0)} K ({Math.round(thermal.peakSkinTemperatureK - 273.15)} °C)</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">THERMAL MARGIN OF SAFETY:</span>
                <span className="text-emerald-400 font-bold">+{(thermal.thermalMarginOfSafety * 100).toFixed(1)} %</span>
              </div>
            </div>
          </div>

          <div className="bg-[#0c101c] border border-slate-800 rounded-lg p-5 space-y-4">
            <h2 className="text-sm font-bold text-white uppercase font-technical">
              Aerothermal Governing Equations
            </h2>
            <div className="space-y-3 font-mono text-xs text-slate-300">
              <div className="p-3 bg-slate-900 rounded border border-slate-800">
                <div className="text-slate-400 text-[10px] mb-1">SUTTON-GRAVES STAGNATION HEAT FLUX:</div>
                <div className="text-rose-300 font-bold">q̇_conv = k_sg · √(ρ_∞ / R_nose) · v_∞³</div>
              </div>
              <div className="p-3 bg-slate-900 rounded border border-slate-800">
                <div className="text-slate-400 text-[10px] mb-1">STEFAN-BOLTZMANN RADIATION EQUILIBRIUM:</div>
                <div className="text-rose-300 font-bold">T_skin = [q̇_absorbed / (ε · σ)]^(1/4)</div>
              </div>
            </div>
          </div>
        </div>
      )}

      {selectedTab === 'recovery' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="bg-[#0c101c] border border-slate-800 rounded-lg p-5 space-y-4">
            <h2 className="text-sm font-bold text-purple-400 uppercase font-technical">
              Newton Recovery, Reusability & Turnaround Model
            </h2>
            <p className="text-xs text-slate-300 leading-relaxed font-mono">
              Models the trade-offs of reusable hardware (grid fins, landing legs, RCS) and reserve propellant required for boostback, re-entry, and landing burns.
            </p>
            <div className="p-4 bg-slate-900/80 rounded border border-slate-800 font-mono text-xs space-y-2.5">
              <div className="flex justify-between">
                <span className="text-slate-400">RECOVERY PROFILE:</span>
                <span className="text-purple-300 font-bold">{recovery.profile}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">RESERVE PROPELLANT ALLOCATED:</span>
                <span className="text-white font-bold">{massBudget.reservePropellantKg.toLocaleString()} kg</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">RECOVERY HARDWARE MASS:</span>
                <span className="text-cyan-300 font-bold">{recovery.recoveryHardwareMassKg.toLocaleString()} kg</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">BOOSTBACK / RE-ENTRY / LANDING ΔV:</span>
                <span className="text-slate-200">
                  {recovery.boostbackDeltaVMS.toFixed(0)} / {recovery.reentryDeltaVMS.toFixed(0)} / {recovery.landingDeltaVMS.toFixed(0)} m/s
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">ESTIMATED TURNAROUND TIME:</span>
                <span className="text-emerald-400 font-bold">{recovery.refurbishmentDurationDays.toFixed(1)} days</span>
              </div>
            </div>
          </div>

          <div className="bg-[#0c101c] border border-slate-800 rounded-lg p-5 space-y-4">
            <h2 className="text-sm font-bold text-white uppercase font-technical">
              Landing Reserve Propulsion Sizing
            </h2>
            <div className="space-y-3 font-mono text-xs text-slate-300">
              <div className="p-3 bg-slate-900 rounded border border-slate-800">
                <div className="text-slate-400 text-[10px] mb-1">RESERVE PROPELLANT CALCULATION:</div>
                <div className="text-purple-300 font-bold">m_prop_res = m_dry_recov · [exp(ΔV_recovery / (I_sp · g_0)) - 1]</div>
              </div>
              <div className="p-3 bg-slate-900 rounded border border-slate-800">
                <div className="text-slate-400 text-[10px] mb-1">FATIGUE CYCLE DAMAGE ACCUMULATION:</div>
                <div className="text-purple-300 font-bold">D = ∑ (n_i / N_i) (Palmgren-Miner Rule)</div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
