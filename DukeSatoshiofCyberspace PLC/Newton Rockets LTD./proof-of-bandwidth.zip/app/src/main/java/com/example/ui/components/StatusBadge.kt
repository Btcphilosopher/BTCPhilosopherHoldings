package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.VerificationStatus
import com.example.ui.theme.AlertRed
import com.example.ui.theme.LaserCyan
import com.example.ui.theme.SignalAmber
import com.example.ui.theme.VerifiedGreen

@Composable
fun StatusBadge(
    status: String,
    modifier: Modifier = Modifier
) {
    val (badgeColor, textColor) = when (status.uppercase()) {
        "VERIFIED", "OPTIMAL", "ONLINE" -> Pair(VerifiedGreen, VerifiedGreen)
        "TAMPER_DETECTED", "REJECTED", "FAULT", "OUTAGE" -> Pair(AlertRed, AlertRed)
        "DEGRADED", "CONGESTED", "PENDING_VERIFICATION", "IN_PASS" -> Pair(SignalAmber, SignalAmber)
        else -> Pair(LaserCyan, LaserCyan)
    }

    Box(
        modifier = modifier
            .background(badgeColor.copy(alpha = 0.12f), shape = RoundedCornerShape(4.dp))
            .border(1.dp, badgeColor.copy(alpha = 0.4f), shape = RoundedCornerShape(4.dp))
            .padding(horizontal = 8.dp, vertical = 4.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(6.dp)
                    .background(badgeColor, shape = CircleShape)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = status,
                color = textColor,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace,
                letterSpacing = 0.5.sp
            )
        }
    }
}
