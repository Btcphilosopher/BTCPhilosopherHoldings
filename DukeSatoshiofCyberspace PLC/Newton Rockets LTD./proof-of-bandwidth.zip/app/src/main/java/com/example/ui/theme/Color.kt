package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val SpaceBackground = Color(0xFF0A0E17)
val PanelSurface = Color(0xFF121824)
val ConsoleSurfaceVariant = Color(0xFF1C2433)
val BorderSteel = Color(0xFF2A364F)

val LaserCyan = Color(0xFF00E5FF)
val VerifiedGreen = Color(0xFF00E676)
val SignalAmber = Color(0xFFFFB300)
val AlertRed = Color(0xFFFF5252)

val TextPrimary = Color(0xFFECEFF1)
val TextSecondary = Color(0xFF90A4AE)
val TextMuted = Color(0xFF607D8B)

val OrbitLineColor = Color(0x3300E5FF)
val ActiveLinkGlow = Color(0x6600E676)
