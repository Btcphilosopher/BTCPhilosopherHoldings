package com.example.data.model

data class SpaceLink(
    val id: String,
    val sourceAssetId: String,
    val destinationAssetId: String,
    val direction: LinkDirection,
    val linkType: LinkType,
    val nominalCapacityBps: Long,
    val allocatedCapacityBps: Long,
    val frequencyHz: Double = 12.5e9, // 12.5 GHz Ku-band default
    val bandwidthHz: Double = 250e6, // 250 MHz default
    val modulation: String = "QPSK",
    val codingRate: String = "3/4",
    val txPowerW: Double = 40.0,
    val distanceKm: Double = 850.0,
    val status: LinkStatus = LinkStatus.OPTIMAL
)
