package com.example.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.RocketLaunch
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.components.StatusBadge
import com.example.ui.screens.ApiPortalScreen
import com.example.ui.screens.DashboardScreen
import com.example.ui.screens.LedgerScreen
import com.example.ui.screens.LinksScreen
import com.example.ui.screens.ProofEngineScreen
import com.example.ui.screens.RocketScreen
import com.example.ui.theme.BorderSteel
import com.example.ui.theme.ConsoleSurfaceVariant
import com.example.ui.theme.LaserCyan
import com.example.ui.theme.SpaceBackground
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.VerifiedGreen

enum class AppScreen(val title: String, val icon: ImageVector) {
    DASHBOARD("Dashboard", Icons.Default.Dashboard),
    LINKS("Links", Icons.Default.Assessment),
    PROOF_ENGINE("Proofs", Icons.Default.Security),
    ROCKET("Rocket", Icons.Default.RocketLaunch),
    LEDGER("Ledger", Icons.Default.ReceiptLong),
    API_PORTAL("API", Icons.Default.Code)
}

@Composable
fun MainApp(viewModel: MainViewModel) {
    var currentScreen by remember { mutableStateOf(AppScreen.DASHBOARD) }
    var selectedProofIdForDetails by remember { mutableStateOf<String?>(null) }

    val totalBwc by viewModel.totalBwc.collectAsStateWithLifecycle()

    Scaffold(
        topBar = {
            TopNocBar(totalBwc = totalBwc)
        },
        bottomBar = {
            BottomNavigationBar(
                currentScreen = currentScreen,
                onScreenSelected = { screen ->
                    currentScreen = screen
                    selectedProofIdForDetails = null
                }
            )
        },
        containerColor = SpaceBackground,
        contentWindowInsets = WindowInsets(0, 0, 0, 0)
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (currentScreen) {
                AppScreen.DASHBOARD -> DashboardScreen(
                    viewModel = viewModel,
                    onNavigateToProof = { proofId ->
                        selectedProofIdForDetails = proofId
                        currentScreen = AppScreen.PROOF_ENGINE
                    }
                )
                AppScreen.LINKS -> LinksScreen(viewModel = viewModel)
                AppScreen.PROOF_ENGINE -> ProofEngineScreen(
                    viewModel = viewModel,
                    initialProofId = selectedProofIdForDetails
                )
                AppScreen.ROCKET -> RocketScreen(viewModel = viewModel)
                AppScreen.LEDGER -> LedgerScreen(viewModel = viewModel)
                AppScreen.API_PORTAL -> ApiPortalScreen(viewModel = viewModel)
            }
        }
    }
}

@Composable
private fun TopNocBar(totalBwc: Double) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(ConsoleSurfaceVariant)
            .border(1.dp, BorderSteel)
            .statusBarsPadding()
            .padding(horizontal = 16.dp, vertical = 10.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = "PROOF-OF-BANDWIDTH",
                    color = LaserCyan,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Black,
                    fontFamily = FontFamily.Monospace,
                    letterSpacing = 1.sp
                )
                Spacer(modifier = Modifier.width(8.dp))
                StatusBadge(status = "NOC_LIVE")
            }

            Text(
                text = "${"%.1f".format(totalBwc)} BWC",
                color = VerifiedGreen,
                fontSize = 13.sp,
                fontWeight = FontWeight.ExtraBold,
                fontFamily = FontFamily.Monospace
            )
        }
    }
}

@Composable
private fun BottomNavigationBar(
    currentScreen: AppScreen,
    onScreenSelected: (AppScreen) -> Unit
) {
    NavigationBar(
        containerColor = ConsoleSurfaceVariant,
        contentColor = TextPrimary,
        tonalElevation = 8.dp,
        modifier = Modifier.navigationBarsPadding()
    ) {
        AppScreen.values().forEach { screen ->
            val isSelected = currentScreen == screen
            NavigationBarItem(
                selected = isSelected,
                onClick = { onScreenSelected(screen) },
                icon = {
                    Icon(
                        imageVector = screen.icon,
                        contentDescription = screen.title,
                        tint = if (isSelected) LaserCyan else TextMuted
                    )
                },
                label = {
                    Text(
                        text = screen.title,
                        color = if (isSelected) LaserCyan else TextMuted,
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                    )
                },
                colors = NavigationBarItemDefaults.colors(
                    indicatorColor = ConsoleSurfaceVariant
                ),
                modifier = Modifier.testTag("nav_tab_${screen.name.lowercase()}")
            )
        }
    }
}
