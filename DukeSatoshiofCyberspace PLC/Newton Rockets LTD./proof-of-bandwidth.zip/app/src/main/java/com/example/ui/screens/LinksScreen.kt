package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.SpaceLink
import com.example.engine.LinkBudgetEngine
import com.example.ui.MainViewModel
import com.example.ui.components.LinkBudgetGauge
import com.example.ui.components.StatusBadge
import com.example.ui.components.TelemetryChart
import com.example.ui.theme.AlertRed
import com.example.ui.theme.BorderSteel
import com.example.ui.theme.ConsoleSurfaceVariant
import com.example.ui.theme.LaserCyan
import com.example.ui.theme.SignalAmber
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.VerifiedGreen

@Composable
fun LinksScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val links by viewModel.links.collectAsStateWithLifecycle()
    val telemetryMap by viewModel.telemetryMap.collectAsStateWithLifecycle()
    val faultInjected by viewModel.faultInjected.collectAsStateWithLifecycle()

    var selectedLinkId by remember { mutableStateOf(links.firstOrNull()?.id ?: "") }
    val selectedLink = links.find { it.id == selectedLinkId } ?: links.firstOrNull()

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "AEROSPACE LINKS & LINK BUDGET",
                    color = LaserCyan,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    letterSpacing = 1.sp
                )

                Button(
                    onClick = { viewModel.toggleFaultInjection() },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (faultInjected) AlertRed else SignalAmber,
                        contentColor = Color.Black
                    ),
                    shape = RoundedCornerShape(4.dp),
                    modifier = Modifier.testTag("fault_injection_button")
                ) {
                    Text(
                        text = if (faultInjected) "CLEAR FAULT" else "SIMULATE FAULT",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
        }

        // Selected Link Inspector Details
        if (selectedLink != null) {
            val telem = telemetryMap[selectedLink.id]
            val budget = LinkBudgetEngine.calculateLinkBudget(
                linkId = selectedLink.id,
                frequencyHz = selectedLink.frequencyHz,
                bandwidthHz = selectedLink.bandwidthHz,
                txPowerW = selectedLink.txPowerW,
                distanceKm = selectedLink.distanceKm,
                modulation = selectedLink.modulation
            )

            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(ConsoleSurfaceVariant, shape = RoundedCornerShape(8.dp))
                        .border(1.dp, LaserCyan, shape = RoundedCornerShape(8.dp))
                        .padding(14.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = selectedLink.id,
                            color = TextPrimary,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.ExtraBold,
                            fontFamily = FontFamily.Monospace
                        )
                        StatusBadge(status = selectedLink.status.name)
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = "Path: ${selectedLink.sourceAssetId} → ${selectedLink.destinationAssetId} (${selectedLink.linkType.name})",
                        color = TextMuted,
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        LinkMetric("Nominal Cap", "${(selectedLink.nominalCapacityBps / 1e6).toInt()} Mbps")
                        LinkMetric("Allocated", "${(selectedLink.allocatedCapacityBps / 1e6).toInt()} Mbps")
                        LinkMetric("Observed", "${((telem?.rxRateBps ?: 0.0) / 1e6).toInt()} Mbps")
                        LinkMetric("Latency", "${"%.1f".format(telem?.latencyMs ?: 0.0)} ms")
                    }
                }
            }

            item {
                LinkBudgetGauge(linkBudget = budget)
            }

            item {
                val history = listOfNotNull(telem)
                TelemetryChart(telemetryHistory = history, title = "OBSERVED THROUGHPUT STREAM (${selectedLink.id})")
            }
        }

        // All Links Selection List
        item {
            Text(
                text = "COMMUNICATION LINK DIRECTORY",
                color = LaserCyan,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace,
                letterSpacing = 1.sp
            )
        }

        items(links) { link ->
            val isSelected = link.id == selectedLinkId
            val t = telemetryMap[link.id]

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(
                        if (isSelected) ConsoleSurfaceVariant else ConsoleSurfaceVariant.copy(alpha = 0.5f),
                        shape = RoundedCornerShape(8.dp)
                    )
                    .border(
                        1.dp,
                        if (isSelected) LaserCyan else BorderSteel,
                        shape = RoundedCornerShape(8.dp)
                    )
                    .clickable { selectedLinkId = link.id }
                    .padding(12.dp)
                    .testTag("link_item_${link.id}")
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = link.id,
                            color = TextPrimary,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                        Text(
                            text = "${link.linkType.name} | ${link.modulation}",
                            color = TextMuted,
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }

                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            text = "${((t?.rxRateBps ?: 0.0) / 1e6).toInt()} Mbps",
                            color = VerifiedGreen,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                        StatusBadge(status = link.status.name)
                    }
                }
            }
        }
    }
}

@Composable
private fun LinkMetric(label: String, value: String) {
    Column {
        Text(
            text = label.uppercase(),
            color = TextMuted,
            fontSize = 9.sp,
            fontFamily = FontFamily.Monospace
        )
        Text(
            text = value,
            color = TextPrimary,
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace
        )
    }
}
