package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.LinkTelemetry
import com.example.ui.theme.AlertRed
import com.example.ui.theme.BorderSteel
import com.example.ui.theme.ConsoleSurfaceVariant
import com.example.ui.theme.LaserCyan
import com.example.ui.theme.TextMuted
import com.example.ui.theme.VerifiedGreen

@Composable
fun TelemetryChart(
    telemetryHistory: List<LinkTelemetry>,
    title: String = "LIVE THROUGHPUT vs TIME",
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(ConsoleSurfaceVariant, shape = RoundedCornerShape(8.dp))
            .border(1.dp, BorderSteel, shape = RoundedCornerShape(8.dp))
            .padding(12.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = title.uppercase(),
                color = LaserCyan,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace,
                letterSpacing = 1.sp
            )
        }

        Spacer(modifier = Modifier.height(8.dp))

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(100.dp)
        ) {
            Canvas(modifier = Modifier.matchParentSize()) {
                val w = size.width
                val h = size.height

                // Grid lines
                for (i in 1..3) {
                    val y = h * (i / 4f)
                    drawLine(
                        color = BorderSteel.copy(alpha = 0.5f),
                        start = Offset(0f, y),
                        end = Offset(w, y),
                        strokeWidth = 1f
                    )
                }

                if (telemetryHistory.size > 1) {
                    val maxRate = (telemetryHistory.maxOfOrNull { it.txRateBps } ?: 1e9).coerceAtLeast(1e6)
                    val points = telemetryHistory.takeLast(30)

                    val path = Path()
                    val dx = w / (points.size - 1).coerceAtLeast(1)

                    points.forEachIndexed { index, t ->
                        val x = index * dx
                        val normY = (t.rxRateBps / maxRate).toFloat().coerceIn(0.05f, 0.95f)
                        val y = h - (normY * h)

                        if (index == 0) {
                            path.moveTo(x, y)
                        } else {
                            path.lineTo(x, y)
                        }
                    }

                    drawPath(
                        path = path,
                        color = VerifiedGreen,
                        style = Stroke(width = 2.5f)
                    )
                }
            }
        }
    }
}
