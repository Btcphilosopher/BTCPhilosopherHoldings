package com.example.data.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface AssetDao {
    @Query("SELECT * FROM assets")
    fun getAllAssets(): Flow<List<AssetEntity>>

    @Query("SELECT * FROM assets WHERE id = :id")
    suspend fun getAssetById(id: String): AssetEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAssets(assets: List<AssetEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAsset(asset: AssetEntity)
}

@Dao
interface LinkDao {
    @Query("SELECT * FROM links")
    fun getAllLinks(): Flow<List<LinkEntity>>

    @Query("SELECT * FROM links WHERE id = :id")
    suspend fun getLinkById(id: String): LinkEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLinks(links: List<LinkEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLink(link: LinkEntity)
}

@Dao
interface ProofDao {
    @Query("SELECT * FROM proofs ORDER BY verifiedAtTimestamp DESC")
    fun getAllProofs(): Flow<List<ProofEntity>>

    @Query("SELECT * FROM proofs WHERE proofId = :id")
    suspend fun getProofById(id: String): ProofEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProof(proof: ProofEntity)
}

@Dao
interface LedgerDao {
    @Query("SELECT * FROM ledger_entries ORDER BY timestamp DESC")
    fun getAllLedgerEntries(): Flow<List<LedgerEntryEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLedgerEntry(entry: LedgerEntryEntity)
}

@Dao
interface CreditDao {
    @Query("SELECT * FROM bandwidth_credits ORDER BY timestamp DESC")
    fun getAllCredits(): Flow<List<BandwidthCreditEntity>>

    @Query("SELECT SUM(bwcIssued) FROM bandwidth_credits")
    fun getTotalBwcIssued(): Flow<Double?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCredit(credit: BandwidthCreditEntity)
}
