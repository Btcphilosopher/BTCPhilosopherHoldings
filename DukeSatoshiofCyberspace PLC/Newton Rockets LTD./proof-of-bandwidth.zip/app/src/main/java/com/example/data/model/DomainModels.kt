package com.example.data.model

data class LedgerEntry(
    val entryId: String,
    val eventType: LedgerEventType,
    val proofId: String,
    val hash: String,
    val timestamp: Long,
    val details: String
)

data class BandwidthCredit(
    val creditId: String,
    val proofId: String,
    val assetId: String,
    val bytesVerified: Long,
    val bwcIssued: Double,
    val qualityFactor: Double,
    val timestamp: Long = System.currentTimeMillis()
)

data class LinkBudget(
    val linkId: String,
    val frequencyHz: Double,
    val bandwidthHz: Double,
    val txPowerW: Double,
    val distanceKm: Double,
    val fsplDb: Double,
    val rxPowerDbm: Double,
    val snrDb: Double,
    val ebN0Db: Double,
    val linkMarginDb: Double,
    val shannonCapacityBps: Double,
    val spectralEfficiency: Double
)

data class ContactWindow(
    val id: String,
    val sourceAssetId: String,
    val destinationAssetId: String,
    val startTime: Long,
    val endTime: Long,
    val maxElevationDeg: Double,
    val durationSeconds: Int
)

data class CapacityReservation(
    val reservationId: String,
    val linkId: String,
    val requesterId: String,
    val requestedBps: Long,
    val startTime: Long,
    val durationSeconds: Int,
    val status: String,
    val allocatedBps: Long
)
