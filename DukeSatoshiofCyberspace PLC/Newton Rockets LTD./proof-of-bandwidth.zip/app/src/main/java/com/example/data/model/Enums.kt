package com.example.data.model

enum class AssetType {
    SATELLITE,
    ROCKET,
    LAUNCH_VEHICLE,
    GROUND_STATION,
    USER_TERMINAL,
    RELAY_SATELLITE,
    INTERSATELLITE_NODE,
    NETWORK_GATEWAY
}

enum class AssetStatus {
    ONLINE,
    DEGRADED,
    ECLIPSE,
    OUTAGE,
    IN_PASS
}

enum class LinkType {
    UPLINK,
    DOWNLINK,
    CROSSLINK,
    INTERSATELLITE,
    GROUND_NETWORK,
    RELAY
}

enum class LinkDirection {
    SIMPLEX_TX,
    SIMPLEX_RX,
    DUPLEX
}

enum class LinkStatus {
    OPTIMAL,
    DEGRADED,
    CONGESTED,
    FAULT,
    DISCONNECTED
}

enum class VerificationStatus {
    VERIFIED,
    REJECTED,
    PENDING_VERIFICATION,
    TAMPER_DETECTED
}

enum class MissionPhase {
    PRELAUNCH,
    LIFTOFF,
    ASCENT,
    MAX_Q,
    STAGE_SEPARATION,
    UPPER_STAGE,
    ORBIT_INSERTION,
    DEPLOYMENT
}

enum class LedgerEventType {
    BANDWIDTH_MEASURED,
    PROOF_CREATED,
    PROOF_VERIFIED,
    PROOF_REJECTED,
    CREDIT_ISSUED,
    CREDIT_RETIRED
}
