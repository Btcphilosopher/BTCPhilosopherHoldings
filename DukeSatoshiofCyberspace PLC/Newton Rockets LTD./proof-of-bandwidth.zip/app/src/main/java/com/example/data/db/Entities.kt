package com.example.data.db

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.example.data.model.AssetStatus
import com.example.data.model.AssetType
import com.example.data.model.LedgerEventType
import com.example.data.model.LinkDirection
import com.example.data.model.LinkStatus
import com.example.data.model.LinkType
import com.example.data.model.VerificationStatus

@Entity(tableName = "assets")
data class AssetEntity(
    @PrimaryKey val id: String,
    val name: String,
    val type: AssetType,
    val operatorId: String,
    val publicKey: String,
    val status: AssetStatus,
    val latitude: Double,
    val longitude: Double,
    val altitudeKm: Double,
    val payloadDataGeneratedGb: Double,
    val onboardStorageQueueGb: Double
)

@Entity(tableName = "links")
data class LinkEntity(
    @PrimaryKey val id: String,
    val sourceAssetId: String,
    val destinationAssetId: String,
    val direction: LinkDirection,
    val linkType: LinkType,
    val nominalCapacityBps: Long,
    val allocatedCapacityBps: Long,
    val frequencyHz: Double,
    val bandwidthHz: Double,
    val modulation: String,
    val codingRate: String,
    val txPowerW: Double,
    val distanceKm: Double,
    val status: LinkStatus
)

@Entity(tableName = "proofs")
data class ProofEntity(
    @PrimaryKey val proofId: String,
    val assetId: String,
    val linkId: String,
    val serviceType: String,
    val startTime: Long,
    val endTime: Long,
    val bytesTransferred: Long,
    val measuredThroughputBps: Double,
    val verifiedThroughputBps: Double,
    val latencyMs: Double,
    val packetLossPercent: Double,
    val availabilityPercent: Double,
    val telemetryRoot: String,
    val eventHash: String,
    val previousHash: String,
    val protocolVersion: String,
    val signature: String,
    val verificationStatus: VerificationStatus,
    val verifiedAtTimestamp: Long
)

@Entity(tableName = "ledger_entries")
data class LedgerEntryEntity(
    @PrimaryKey val entryId: String,
    val eventType: LedgerEventType,
    val proofId: String,
    val hash: String,
    val timestamp: Long,
    val details: String
)

@Entity(tableName = "bandwidth_credits")
data class BandwidthCreditEntity(
    @PrimaryKey val creditId: String,
    val proofId: String,
    val assetId: String,
    val bytesVerified: Long,
    val bwcIssued: Double,
    val qualityFactor: Double,
    val timestamp: Long
)
