package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.crypto.VerificationResult
import com.example.data.model.BandwidthProof
import com.example.ui.MainViewModel
import com.example.ui.components.StatusBadge
import com.example.ui.theme.AlertRed
import com.example.ui.theme.BorderSteel
import com.example.ui.theme.ConsoleSurfaceVariant
import com.example.ui.theme.LaserCyan
import com.example.ui.theme.SignalAmber
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.VerifiedGreen

@Composable
fun ProofEngineScreen(
    viewModel: MainViewModel,
    initialProofId: String? = null,
    modifier: Modifier = Modifier
) {
    val links by viewModel.links.collectAsStateWithLifecycle()
    val proofs by viewModel.proofs.collectAsStateWithLifecycle()
    val isGeneratingProof by viewModel.isGeneratingProof.collectAsStateWithLifecycle()
    val latestProof by viewModel.latestGeneratedProof.collectAsStateWithLifecycle()
    val lastVerificationResult by viewModel.lastVerificationResult.collectAsStateWithLifecycle()

    val displayProof = proofs.find { it.proofId == initialProofId }
        ?: latestProof
        ?: proofs.firstOrNull()

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                text = "CRYPTOGRAPHIC PROOF ENGINE",
                color = LaserCyan,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace,
                letterSpacing = 1.sp
            )
        }

        // Proof Execution Control
        item {
            Button(
                onClick = {
                    val targetLink = displayProof?.linkId ?: links.firstOrNull()?.id ?: "LINK-AUREOM-GS01"
                    viewModel.executeProveThisLink(targetLink)
                },
                enabled = !isGeneratingProof,
                colors = ButtonDefaults.buttonColors(
                    containerColor = LaserCyan,
                    contentColor = Color.Black
                ),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("generate_proof_button")
            ) {
                if (isGeneratingProof) {
                    CircularProgressIndicator(color = Color.Black, modifier = Modifier.size(20.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(text = "GENERATING MERKLE TREE & SIGNATURE...", fontWeight = FontWeight.Bold)
                } else {
                    Icon(imageVector = Icons.Default.Lock, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "GENERATE CRYPTOGRAPHIC PROOF",
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
        }

        // Active Proof Cryptographic Evidence Chain Inspector
        if (displayProof != null) {
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(ConsoleSurfaceVariant, shape = RoundedCornerShape(8.dp))
                        .border(1.dp, BorderSteel, shape = RoundedCornerShape(8.dp))
                        .padding(14.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "BANDWIDTH PROOF RECORD",
                                color = TextMuted,
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace
                            )
                            Text(
                                text = displayProof.proofId,
                                color = TextPrimary,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.ExtraBold,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                        StatusBadge(status = displayProof.verificationStatus.name)
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    ProofRow("Asset ID", displayProof.assetId)
                    ProofRow("Link ID", displayProof.linkId)
                    ProofRow("Service Type", displayProof.serviceType)
                    ProofRow("Data Transferred", "${"%.2f".format(displayProof.bytesTransferred / 1e9)} GB")
                    ProofRow("Measured Rate", "${(displayProof.measuredThroughputBps / 1e6).toInt()} Mbps")
                    ProofRow("Verified Rate", "${(displayProof.verifiedThroughputBps / 1e6).toInt()} Mbps")
                    ProofRow("Latency / Loss", "${"%.1f".format(displayProof.latencyMs)} ms / ${"%.2f".format(displayProof.packetLossPercent)}%")

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = "CRYPTOGRAPHIC PROOF EVIDENCE",
                        color = LaserCyan,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        letterSpacing = 1.sp
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    CryptoHashRow("Telemetry Merkle Root", displayProof.telemetryRoot)
                    CryptoHashRow("Event SHA-256 Hash", displayProof.eventHash)
                    CryptoHashRow("Previous Chain Hash", displayProof.previousHash)
                    CryptoHashRow("Ed25519 Signature", displayProof.signature)

                    Spacer(modifier = Modifier.height(12.dp))

                    Button(
                        onClick = { viewModel.verifyProof(displayProof.proofId) },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = VerifiedGreen,
                            contentColor = Color.Black
                        ),
                        shape = RoundedCornerShape(4.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("verify_proof_button")
                    ) {
                        Icon(imageVector = Icons.Default.Shield, contentDescription = null)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "VERIFY CRYPTOGRAPHY & ANTI-FRAUD",
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 12.sp
                        )
                    }
                }
            }
        }

        // Verification Audit Report
        if (lastVerificationResult != null) {
            val res = lastVerificationResult!!
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(ConsoleSurfaceVariant, shape = RoundedCornerShape(8.dp))
                        .border(
                            1.dp,
                            if (res.isValid) VerifiedGreen else AlertRed,
                            shape = RoundedCornerShape(8.dp)
                        )
                        .padding(14.dp)
                ) {
                    Text(
                        text = "VERIFICATION AUDIT REPORT",
                        color = if (res.isValid) VerifiedGreen else AlertRed,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    AuditCheckItem("Digital Signature Check", res.signatureValid)
                    AuditCheckItem("SHA-256 Event Hash Check", res.hashValid)
                    AuditCheckItem("Merkle Tree Telemetry Root", res.merkleValid)
                    AuditCheckItem("Hash Chain Continuity", res.chainValid)
                    AuditCheckItem("Anti-Fraud Consistency Analysis", res.measurementsValid)

                    if (res.fraudWarnings.isNotEmpty()) {
                        Spacer(modifier = Modifier.height(8.dp))
                        res.fraudWarnings.forEach { warning ->
                            Text(
                                text = warning,
                                color = AlertRed,
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ProofRow(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 2.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(text = label, color = TextMuted, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
        Text(text = value, color = TextPrimary, fontSize = 11.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
    }
}

@Composable
private fun CryptoHashRow(label: String, hash: String) {
    Column(modifier = Modifier.padding(vertical = 3.dp)) {
        Text(text = label.uppercase(), color = TextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
        Text(
            text = hash,
            color = LaserCyan,
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace,
            maxLines = 1
        )
    }
}

@Composable
private fun AuditCheckItem(label: String, isValid: Boolean) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 2.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text = label, color = TextPrimary, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
        Text(
            text = if (isValid) "✓ PASSED" else "✗ FAILED",
            color = if (isValid) VerifiedGreen else AlertRed,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace
        )
    }
}
