package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.LinkBudget
import com.example.ui.theme.AlertRed
import com.example.ui.theme.BorderSteel
import com.example.ui.theme.ConsoleSurfaceVariant
import com.example.ui.theme.LaserCyan
import com.example.ui.theme.SignalAmber
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.VerifiedGreen

@Composable
fun LinkBudgetGauge(
    linkBudget: LinkBudget,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(ConsoleSurfaceVariant, shape = RoundedCornerShape(8.dp))
            .border(1.dp, BorderSteel, shape = RoundedCornerShape(8.dp))
            .padding(14.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "ENGINEERING LINK BUDGET",
                color = LaserCyan,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace,
                letterSpacing = 1.sp
            )
            val marginColor = when {
                linkBudget.linkMarginDb >= 5.0 -> VerifiedGreen
                linkBudget.linkMarginDb >= 2.0 -> SignalAmber
                else -> AlertRed
            }
            Text(
                text = "MARGIN: ${"%.1f".format(linkBudget.linkMarginDb)} dB",
                color = marginColor,
                fontSize = 12.sp,
                fontWeight = FontWeight.ExtraBold,
                fontFamily = FontFamily.Monospace
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Grid of Link Budget Equations
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            BudgetParamItem("FSPL Loss", "${"%.1f".format(linkBudget.fsplDb)} dB")
            BudgetParamItem("Rx Power", "${"%.1f".format(linkBudget.rxPowerDbm)} dBm")
            BudgetParamItem("Signal SNR", "${"%.1f".format(linkBudget.snrDb)} dB")
            BudgetParamItem("Eb/N0", "${"%.1f".format(linkBudget.ebN0Db)} dB")
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Shannon Capacity bar
        Text(
            text = "SHANNON CAPACITY: ${"%.2f".format(linkBudget.shannonCapacityBps / 1e9)} Gbps (Efficiency: ${"%.2f".format(linkBudget.spectralEfficiency)} bit/s/Hz)",
            color = TextMuted,
            fontSize = 10.sp,
            fontFamily = FontFamily.Monospace
        )

        Spacer(modifier = Modifier.height(4.dp))

        val progress = (linkBudget.linkMarginDb / 12.0).coerceIn(0.0, 1.0).toFloat()
        LinearProgressIndicator(
            progress = { progress },
            modifier = Modifier
                .fillMaxWidth()
                .height(6.dp),
            color = if (progress > 0.4f) VerifiedGreen else AlertRed,
            trackColor = BorderSteel
        )
    }
}

@Composable
private fun BudgetParamItem(label: String, value: String) {
    Column {
        Text(
            text = label.uppercase(),
            color = TextMuted,
            fontSize = 9.sp,
            fontFamily = FontFamily.Monospace
        )
        Text(
            text = value,
            color = TextPrimary,
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace
        )
    }
}
