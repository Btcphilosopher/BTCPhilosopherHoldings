package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.crypto.VerificationResult
import com.example.data.db.ProofDatabase
import com.example.data.model.BandwidthCredit
import com.example.data.model.BandwidthProof
import com.example.data.model.CommunicationAsset
import com.example.data.model.LedgerEntry
import com.example.data.model.LinkTelemetry
import com.example.data.model.MissionPhase
import com.example.data.model.SpaceLink
import com.example.data.model.VerificationStatus
import com.example.data.repository.PobRepository
import com.example.engine.SimulationEngine
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val db = ProofDatabase.getDatabase(application)
    val repository = PobRepository(db)

    // Simulation Engine state
    val assets: StateFlow<List<CommunicationAsset>> = SimulationEngine.assetsState
    val links: StateFlow<List<SpaceLink>> = SimulationEngine.linksState
    val telemetryMap: StateFlow<Map<String, LinkTelemetry>> = SimulationEngine.telemetryMap
    val missionPhase: StateFlow<MissionPhase> = SimulationEngine.missionPhase
    val faultInjected: StateFlow<Boolean> = SimulationEngine.faultInjected

    // Repository flows from Room DB
    val proofs: StateFlow<List<BandwidthProof>> = repository.allProofs.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val ledgerEntries: StateFlow<List<LedgerEntry>> = repository.allLedgerEntries.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val credits: StateFlow<List<BandwidthCredit>> = repository.allCredits.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val totalBwc: StateFlow<Double> = repository.totalBwcIssued.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = 0.0
    )

    // UI state for proof execution progress
    private val _isGeneratingProof = MutableStateFlow(false)
    val isGeneratingProof: StateFlow<Boolean> = _isGeneratingProof.asStateFlow()

    private val _latestGeneratedProof = MutableStateFlow<BandwidthProof?>(null)
    val latestGeneratedProof: StateFlow<BandwidthProof?> = _latestGeneratedProof.asStateFlow()

    private val _lastVerificationResult = MutableStateFlow<VerificationResult?>(null)
    val lastVerificationResult: StateFlow<VerificationResult?> = _lastVerificationResult.asStateFlow()

    init {
        // Seed initial proofs if empty on first launch
        viewModelScope.launch {
            SimulationEngine.tickSimulation() // First tick
            startSimulationLoop()
        }
    }

    private fun startSimulationLoop() {
        viewModelScope.launch {
            while (true) {
                delay(1000L)
                SimulationEngine.tickSimulation()
            }
        }
    }

    fun executeProveThisLink(linkId: String) {
        viewModelScope.launch {
            _isGeneratingProof.value = true
            _latestGeneratedProof.value = null
            delay(800) // Brief calculation animation pulse
            val proof = repository.generateBandwidthProof(linkId, durationSec = 300)
            _latestGeneratedProof.value = proof
            _isGeneratingProof.value = false
        }
    }

    fun verifyProof(proofId: String) {
        viewModelScope.launch {
            val result = repository.verifyProof(proofId)
            _lastVerificationResult.value = result
        }
    }

    fun toggleFaultInjection() {
        SimulationEngine.toggleFaultInjection()
    }

    fun setMissionPhase(phase: MissionPhase) {
        SimulationEngine.setMissionPhase(phase)
    }
}
