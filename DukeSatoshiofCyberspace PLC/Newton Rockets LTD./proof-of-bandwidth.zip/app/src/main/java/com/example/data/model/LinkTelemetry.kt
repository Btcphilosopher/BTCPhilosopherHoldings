package com.example.data.model

data class LinkTelemetry(
    val timestamp: Long,
    val linkId: String,
    val txBytes: Long,
    val rxBytes: Long,
    val txRateBps: Double,
    val rxRateBps: Double,
    val latencyMs: Double,
    val jitterMs: Double,
    val packetLossPercent: Double,
    val signalQuality: Double,
    val snrDb: Double,
    val linkMarginDb: Double,
    val temperatureC: Double = 22.5,
    val powerW: Double = 42.0,
    val sequenceNumber: Long = 0L
)
