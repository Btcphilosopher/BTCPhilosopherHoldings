package com.example.crypto

import com.example.data.model.BandwidthProof
import com.example.data.model.LinkTelemetry
import com.example.data.model.VerificationStatus
import java.security.MessageDigest
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec

data class MerkleResult(
    val rootHash: String,
    val leafHashes: List<String>
)

data class VerificationResult(
    val isValid: Boolean,
    val status: VerificationStatus,
    val signatureValid: Boolean,
    val hashValid: Boolean,
    val merkleValid: Boolean,
    val chainValid: Boolean,
    val measurementsValid: Boolean,
    val fraudWarnings: List<String>
)

object CryptoEngine {

    fun sha256(input: String): String {
        val digest = MessageDigest.getInstance("SHA-256")
        val hash = digest.digest(input.toByteArray(Charsets.UTF_8))
        return hash.joinToString("") { "%02x".format(it) }
    }

    fun hmacSha256(data: String, key: String): String {
        val secretKey = SecretKeySpec(key.toByteArray(Charsets.UTF_8), "HmacSHA256")
        val mac = Mac.getInstance("HmacSHA256")
        mac.init(secretKey)
        val hash = mac.doFinal(data.toByteArray(Charsets.UTF_8))
        return hash.joinToString("") { "%02x".format(it) }
    }

    /**
     * Constructs a Merkle Tree from a list of measurement window telemetry hashes
     */
    fun buildMerkleTree(telemetryHashes: List<String>): MerkleResult {
        if (telemetryHashes.isEmpty()) {
            val emptyHash = sha256("EMPTY_TELEMETRY")
            return MerkleResult(emptyHash, listOf(emptyHash))
        }

        var currentLevel = telemetryHashes.map { sha256(it) }
        val leafHashes = currentLevel

        while (currentLevel.size > 1) {
            val nextLevel = mutableListOf<String>()
            for (i in currentLevel.indices step 2) {
                val left = currentLevel[i]
                val right = if (i + 1 < currentLevel.size) currentLevel[i + 1] else left
                nextLevel.add(sha256(left + right))
            }
            currentLevel = nextLevel
        }

        return MerkleResult(
            rootHash = currentLevel.first(),
            leafHashes = leafHashes
        )
    }

    fun computeEventHash(
        previousHash: String,
        assetId: String,
        linkId: String,
        startTime: Long,
        endTime: Long,
        bytesTransferred: Long,
        throughputBps: Double,
        telemetryRoot: String
    ): String {
        val raw = "$previousHash|$assetId|$linkId|$startTime|$endTime|$bytesTransferred|$throughputBps|$telemetryRoot"
        return sha256(raw)
    }

    fun signProof(eventHash: String, privateKeyHex: String): String {
        return hmacSha256(eventHash, privateKeyHex)
    }

    fun verifyProof(
        proof: BandwidthProof,
        publicKeyHex: String,
        telemetryList: List<LinkTelemetry>,
        nominalCapacityBps: Long
    ): VerificationResult {
        val fraudWarnings = mutableListOf<String>()

        // 1. Anti-Fraud & Measurement Consistency Analysis
        var measurementsValid = true
        if (proof.bytesTransferred < 0) {
            measurementsValid = false
            fraudWarnings.add("FRAUD_DETECTED: Negative byte count observed")
        }

        if (proof.startTime >= proof.endTime) {
            measurementsValid = false
            fraudWarnings.add("FRAUD_DETECTED: Invalid timestamp duration (startTime >= endTime)")
        }

        // Check if measured throughput exceeds physical nominal link capacity by unrealistic factor
        if (proof.measuredThroughputBps > nominalCapacityBps * 1.2) {
            measurementsValid = false
            fraudWarnings.add("FRAUD_DETECTED: Measured throughput (${(proof.measuredThroughputBps / 1e6).toInt()} Mbps) exceeds physical link limit (${(nominalCapacityBps / 1e6).toInt()} Mbps)")
        }

        // Check telemetry sequence gaps or counter resets
        var prevTx = -1L
        for (t in telemetryList) {
            if (prevTx != -1L && t.txBytes < prevTx) {
                measurementsValid = false
                fraudWarnings.add("FRAUD_DETECTED: Telemetry counter reset or non-monotonic txBytes sequence detected")
                break
            }
            prevTx = t.txBytes
        }

        // 2. Merkle Root Verification
        val windowHashes = telemetryList.map { "W_${it.timestamp}_${it.txBytes}_${it.rxBytes}" }
        val merkleResult = buildMerkleTree(windowHashes)
        val merkleValid = (merkleResult.rootHash == proof.telemetryRoot)

        if (!merkleValid) {
            fraudWarnings.add("MERKLE_MISMATCH: Computed Merkle root does not match proof record")
        }

        // 3. Event Hash Chain Verification
        val expectedEventHash = computeEventHash(
            previousHash = proof.previousHash,
            assetId = proof.assetId,
            linkId = proof.linkId,
            startTime = proof.startTime,
            endTime = proof.endTime,
            bytesTransferred = proof.bytesTransferred,
            throughputBps = proof.measuredThroughputBps,
            telemetryRoot = proof.telemetryRoot
        )
        val hashValid = (expectedEventHash == proof.eventHash)

        if (!hashValid) {
            fraudWarnings.add("HASH_MISMATCH: Event hash recalculation failed")
        }

        // 4. Signature Verification
        val expectedSignature = signProof(proof.eventHash, publicKeyHex)
        val signatureValid = (expectedSignature == proof.signature)

        if (!signatureValid) {
            fraudWarnings.add("SIGNATURE_INVALID: Key signature check failed")
        }

        val isValid = signatureValid && hashValid && merkleValid && measurementsValid
        val status = if (isValid) VerificationStatus.VERIFIED else VerificationStatus.TAMPER_DETECTED

        return VerificationResult(
            isValid = isValid,
            status = status,
            signatureValid = signatureValid,
            hashValid = hashValid,
            merkleValid = merkleValid,
            chainValid = hashValid,
            measurementsValid = measurementsValid,
            fraudWarnings = fraudWarnings
        )
    }
}
