package com.example.data.repository

import com.example.crypto.CryptoEngine
import com.example.crypto.VerificationResult
import com.example.data.db.BandwidthCreditEntity
import com.example.data.db.LedgerEntryEntity
import com.example.data.db.ProofDao
import com.example.data.db.ProofDatabase
import com.example.data.db.ProofEntity
import com.example.data.model.AssetStatus
import com.example.data.model.BandwidthCredit
import com.example.data.model.BandwidthProof
import com.example.data.model.CommunicationAsset
import com.example.data.model.LedgerEntry
import com.example.data.model.LedgerEventType
import com.example.data.model.LinkTelemetry
import com.example.data.model.SpaceLink
import com.example.data.model.VerificationStatus
import com.example.engine.SimulationEngine
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext

class PobRepository(private val db: ProofDatabase) {

    val allProofs: Flow<List<BandwidthProof>> = db.proofDao().getAllProofs().map { entities ->
        entities.map { it.toDomainModel() }
    }

    val allLedgerEntries: Flow<List<LedgerEntry>> = db.ledgerDao().getAllLedgerEntries().map { entities ->
        entities.map { LedgerEntry(it.entryId, it.eventType, it.proofId, it.hash, it.timestamp, it.details) }
    }

    val allCredits: Flow<List<BandwidthCredit>> = db.creditDao().getAllCredits().map { entities ->
        entities.map { BandwidthCredit(it.creditId, it.proofId, it.assetId, it.bytesVerified, it.bwcIssued, it.qualityFactor, it.timestamp) }
    }

    val totalBwcIssued: Flow<Double> = db.creditDao().getTotalBwcIssued().map { it ?: 0.0 }

    suspend fun generateBandwidthProof(linkId: String, durationSec: Int = 300): BandwidthProof = withContext(Dispatchers.IO) {
        val link = SimulationEngine.linksState.value.find { it.id == linkId }
            ?: SimulationEngine.linksState.value.first()
        val asset = SimulationEngine.assetsState.value.find { it.id == link.sourceAssetId }
            ?: SimulationEngine.assetsState.value.first()

        val currentTelem = SimulationEngine.telemetryMap.value[linkId]
            ?: LinkTelemetry(
                timestamp = System.currentTimeMillis(),
                linkId = linkId,
                txBytes = 100_000_000_000L,
                rxBytes = 99_900_000_000L,
                txRateBps = link.allocatedCapacityBps.toDouble() * 0.98,
                rxRateBps = link.allocatedCapacityBps.toDouble() * 0.97,
                latencyMs = 38.2,
                jitterMs = 0.8,
                packetLossPercent = 0.08,
                signalQuality = 0.98,
                snrDb = 18.5,
                linkMarginDb = 6.8
            )

        val now = System.currentTimeMillis()
        val startTime = now - (durationSec * 1000L)
        val bytesTransferred = (currentTelem.rxRateBps / 8.0 * durationSec).toLong()
        val measuredThroughputBps = currentTelem.rxRateBps
        val verifiedThroughputBps = measuredThroughputBps * (1.0 - (currentTelem.packetLossPercent / 100.0))

        // Create 4 window telemetry hashes for Merkle Tree
        val telemetryWindows = (1..4).map { idx ->
            LinkTelemetry(
                timestamp = startTime + (idx * durationSec * 250L),
                linkId = linkId,
                txBytes = currentTelem.txBytes + (idx * 10_000_000L),
                rxBytes = currentTelem.rxBytes + (idx * 9_990_000L),
                txRateBps = measuredThroughputBps,
                rxRateBps = verifiedThroughputBps,
                latencyMs = currentTelem.latencyMs,
                jitterMs = currentTelem.jitterMs,
                packetLossPercent = currentTelem.packetLossPercent,
                signalQuality = currentTelem.signalQuality,
                snrDb = currentTelem.snrDb,
                linkMarginDb = currentTelem.linkMarginDb
            )
        }

        val windowHashes = telemetryWindows.map { "W_${it.timestamp}_${it.txBytes}_${it.rxBytes}" }
        val merkleResult = CryptoEngine.buildMerkleTree(windowHashes)

        val previousHash = "00000000000000000000000000000000" + System.currentTimeMillis().toString(16).padStart(32, '0')

        val eventHash = CryptoEngine.computeEventHash(
            previousHash = previousHash,
            assetId = asset.id,
            linkId = link.id,
            startTime = startTime,
            endTime = now,
            bytesTransferred = bytesTransferred,
            throughputBps = measuredThroughputBps,
            telemetryRoot = merkleResult.rootHash
        )

        val signature = CryptoEngine.signProof(eventHash, asset.publicKey)

        val proofId = "POB-2026-" + (System.currentTimeMillis() % 1000000).toString().padStart(6, '0')

        val initialProof = BandwidthProof(
            proofId = proofId,
            assetId = asset.id,
            linkId = link.id,
            serviceType = link.linkType.name,
            startTime = startTime,
            endTime = now,
            bytesTransferred = bytesTransferred,
            measuredThroughputBps = measuredThroughputBps,
            verifiedThroughputBps = verifiedThroughputBps,
            latencyMs = currentTelem.latencyMs,
            packetLossPercent = currentTelem.packetLossPercent,
            availabilityPercent = 99.94,
            telemetryRoot = merkleResult.rootHash,
            eventHash = eventHash,
            previousHash = previousHash,
            protocolVersion = "PoB/1.0",
            signature = signature,
            verificationStatus = VerificationStatus.VERIFIED,
            verifiedAtTimestamp = now
        )

        // Run Verification Analysis
        val verifyResult = CryptoEngine.verifyProof(
            proof = initialProof,
            publicKeyHex = asset.publicKey,
            telemetryList = telemetryWindows,
            nominalCapacityBps = link.nominalCapacityBps
        )

        val finalProof = initialProof.copy(verificationStatus = verifyResult.status)

        // Save Proof Entity
        db.proofDao().insertProof(finalProof.toEntity())

        // Record Ledger Entry
        val ledgerHash = CryptoEngine.sha256("${finalProof.proofId}|${finalProof.eventHash}")
        db.ledgerDao().insertLedgerEntry(
            LedgerEntryEntity(
                entryId = "LEDGER-${System.currentTimeMillis() % 100000}",
                eventType = LedgerEventType.PROOF_CREATED,
                proofId = finalProof.proofId,
                hash = ledgerHash,
                timestamp = now,
                details = "Proof ${finalProof.proofId} generated for asset ${asset.name}. Verified ${(verifiedThroughputBps / 1e6).toInt()} Mbps (${(bytesTransferred / 1e9).toString().take(5)} GB)."
            )
        )

        // Issue Bandwidth Credit BWC if verified
        if (finalProof.verificationStatus == VerificationStatus.VERIFIED) {
            val bytesVerified = bytesTransferred
            val qualityFactor = (1.0 - (currentTelem.packetLossPercent / 100.0)) * (currentTelem.signalQuality)
            val bwcIssued = (bytesVerified / 1e9) * qualityFactor // 1 BWC per 1 GB verified adjusted for quality

            db.creditDao().insertCredit(
                BandwidthCreditEntity(
                    creditId = "BWC-${System.currentTimeMillis() % 100000}",
                    proofId = finalProof.proofId,
                    assetId = asset.id,
                    bytesVerified = bytesVerified,
                    bwcIssued = bwcIssued,
                    qualityFactor = qualityFactor,
                    timestamp = now
                )
            )

            db.ledgerDao().insertLedgerEntry(
                LedgerEntryEntity(
                    entryId = "LEDGER-CREDIT-${System.currentTimeMillis() % 100000}",
                    eventType = LedgerEventType.CREDIT_ISSUED,
                    proofId = finalProof.proofId,
                    hash = CryptoEngine.sha256("BWC|$bwcIssued|${finalProof.proofId}"),
                    timestamp = now,
                    details = "Issued ${"%.2f".format(bwcIssued)} BWC credits to ${asset.name} for ${"%.2f".format(bytesVerified / 1e9)} GB verified service."
                )
            )
        }

        finalProof
    }

    suspend fun verifyProof(proofId: String): VerificationResult = withContext(Dispatchers.IO) {
        val entity = db.proofDao().getProofById(proofId)
            ?: return@withContext VerificationResult(false, VerificationStatus.REJECTED, false, false, false, false, false, listOf("Proof ID not found"))
        val proof = entity.toDomainModel()
        val link = SimulationEngine.linksState.value.find { it.id == proof.linkId }
            ?: SimulationEngine.linksState.value.first()
        val asset = SimulationEngine.assetsState.value.find { it.id == proof.assetId }
            ?: SimulationEngine.assetsState.value.first()

        val telem = LinkTelemetry(
            timestamp = proof.startTime,
            linkId = proof.linkId,
            txBytes = proof.bytesTransferred,
            rxBytes = (proof.bytesTransferred * 0.999).toLong(),
            txRateBps = proof.measuredThroughputBps,
            rxRateBps = proof.verifiedThroughputBps,
            latencyMs = proof.latencyMs,
            jitterMs = 0.5,
            packetLossPercent = proof.packetLossPercent,
            signalQuality = 0.98,
            snrDb = 18.5,
            linkMarginDb = 6.8
        )

        CryptoEngine.verifyProof(
            proof = proof,
            publicKeyHex = asset.publicKey,
            telemetryList = listOf(telem),
            nominalCapacityBps = link.nominalCapacityBps
        )
    }

    private fun ProofEntity.toDomainModel(): BandwidthProof {
        return BandwidthProof(
            proofId = proofId,
            assetId = assetId,
            linkId = linkId,
            serviceType = serviceType,
            startTime = startTime,
            endTime = endTime,
            bytesTransferred = bytesTransferred,
            measuredThroughputBps = measuredThroughputBps,
            verifiedThroughputBps = verifiedThroughputBps,
            latencyMs = latencyMs,
            packetLossPercent = packetLossPercent,
            availabilityPercent = availabilityPercent,
            telemetryRoot = telemetryRoot,
            eventHash = eventHash,
            previousHash = previousHash,
            protocolVersion = protocolVersion,
            signature = signature,
            verificationStatus = verificationStatus,
            verifiedAtTimestamp = verifiedAtTimestamp
        )
    }

    private fun BandwidthProof.toEntity(): ProofEntity {
        return ProofEntity(
            proofId = proofId,
            assetId = assetId,
            linkId = linkId,
            serviceType = serviceType,
            startTime = startTime,
            endTime = endTime,
            bytesTransferred = bytesTransferred,
            measuredThroughputBps = measuredThroughputBps,
            verifiedThroughputBps = verifiedThroughputBps,
            latencyMs = latencyMs,
            packetLossPercent = packetLossPercent,
            availabilityPercent = availabilityPercent,
            telemetryRoot = telemetryRoot,
            eventHash = eventHash,
            previousHash = previousHash,
            protocolVersion = protocolVersion,
            signature = signature,
            verificationStatus = verificationStatus,
            verifiedAtTimestamp = verifiedAtTimestamp
        )
    }
}
