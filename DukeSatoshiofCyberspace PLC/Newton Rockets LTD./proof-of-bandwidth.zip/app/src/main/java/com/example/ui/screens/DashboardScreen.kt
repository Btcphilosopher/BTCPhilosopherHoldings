package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CloudDownload
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material.icons.filled.RocketLaunch
import androidx.compose.material.icons.filled.SatelliteAlt
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.R
import com.example.data.model.BandwidthProof
import com.example.ui.MainViewModel
import com.example.ui.components.MetricCard
import com.example.ui.components.OrbitMapView
import com.example.ui.components.StatusBadge
import com.example.ui.theme.BorderSteel
import com.example.ui.theme.ConsoleSurfaceVariant
import com.example.ui.theme.LaserCyan
import com.example.ui.theme.SignalAmber
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.VerifiedGreen

@Composable
fun DashboardScreen(
    viewModel: MainViewModel,
    onNavigateToProof: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val assets by viewModel.assets.collectAsStateWithLifecycle()
    val links by viewModel.links.collectAsStateWithLifecycle()
    val proofs by viewModel.proofs.collectAsStateWithLifecycle()
    val totalBwc by viewModel.totalBwc.collectAsStateWithLifecycle()
    val isGeneratingProof by viewModel.isGeneratingProof.collectAsStateWithLifecycle()
    val latestProof by viewModel.latestGeneratedProof.collectAsStateWithLifecycle()

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Hero Header Banner
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(130.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .border(1.dp, BorderSteel, shape = RoundedCornerShape(8.dp))
            ) {
                Image(
                    painter = painterResource(id = R.drawable.hero_satellite_noc_1790675129372),
                    contentDescription = "Aerospace NOC",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color.Black.copy(alpha = 0.65f))
                        .padding(14.dp)
                ) {
                    Column(modifier = Modifier.align(Alignment.CenterStart)) {
                        Text(
                            text = "PROOF-OF-BANDWIDTH",
                            color = LaserCyan,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Black,
                            fontFamily = FontFamily.Monospace,
                            letterSpacing = 2.sp
                        )
                        Text(
                            text = "PROVE THE LINK. MEASURED DATA. VERIFIED CAPACITY.",
                            color = TextPrimary,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }
        }

        // ONE-CLICK HERO ACTION: PROVE THIS LINK
        item {
            Button(
                onClick = {
                    val activeLink = links.firstOrNull()?.id ?: "LINK-AUREOM-GS01"
                    viewModel.executeProveThisLink(activeLink)
                },
                enabled = !isGeneratingProof,
                colors = ButtonDefaults.buttonColors(
                    containerColor = VerifiedGreen,
                    contentColor = Color.Black
                ),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .testTag("hero_prove_link_button")
            ) {
                if (isGeneratingProof) {
                    CircularProgressIndicator(
                        color = Color.Black,
                        strokeWidth = 2.dp,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = "EXECUTING CRYPTOGRAPHIC PROOF...",
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 13.sp
                    )
                } else {
                    Icon(imageVector = Icons.Default.Security, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "PROVE THIS LINK",
                        fontWeight = FontWeight.Black,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 15.sp,
                        letterSpacing = 1.sp
                    )
                }
            }
        }

        // Key Metrics Grid
        item {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    MetricCard(
                        title = "VERIFIED BANDWIDTH",
                        value = "42.8 Gb/s",
                        subtitle = "Measured Rate",
                        icon = Icons.Default.SatelliteAlt,
                        modifier = Modifier.weight(1f)
                    )
                    MetricCard(
                        title = "VERIFIED CREDITS",
                        value = "${"%.1f".format(totalBwc)} BWC",
                        subtitle = "1 BWC = 1 GB Verified",
                        icon = Icons.Default.CheckCircle,
                        accentColor = VerifiedGreen,
                        modifier = Modifier.weight(1f)
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    MetricCard(
                        title = "ACTIVE LINKS",
                        value = "${links.size}",
                        subtitle = "Space & Ground",
                        icon = Icons.Default.Assessment,
                        modifier = Modifier.weight(1f)
                    )
                    MetricCard(
                        title = "PROOFS ISSUED",
                        value = "${proofs.size}",
                        subtitle = "Ed25519 Signed",
                        icon = Icons.Default.Fingerprint,
                        accentColor = SignalAmber,
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }

        // Global NOC Orbital & Link Map
        item {
            Column {
                Text(
                    text = "GLOBAL ORBITAL NETWORK MAP",
                    color = LaserCyan,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    letterSpacing = 1.sp,
                    modifier = Modifier.padding(bottom = 8.dp)
                )
                OrbitMapView(
                    assets = assets,
                    links = links,
                    onAssetClick = { asset -> }
                )
            }
        }

        // Recent Proofs Section
        item {
            Text(
                text = "RECENT BANDWIDTH PROOFS",
                color = LaserCyan,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace,
                letterSpacing = 1.sp
            )
        }

        if (proofs.isEmpty()) {
            item {
                Text(
                    text = "No proofs generated yet. Tap 'PROVE THIS LINK' above to generate the first cryptographic bandwidth proof.",
                    color = TextMuted,
                    fontSize = 12.sp,
                    fontFamily = FontFamily.Monospace,
                    modifier = Modifier.padding(vertical = 12.dp)
                )
            }
        } else {
            items(proofs.take(5)) { proof ->
                ProofSummaryCard(
                    proof = proof,
                    onClick = { onNavigateToProof(proof.proofId) }
                )
            }
        }
    }
}

@Composable
fun ProofSummaryCard(
    proof: BandwidthProof,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .background(ConsoleSurfaceVariant, shape = RoundedCornerShape(8.dp))
            .border(1.dp, BorderSteel, shape = RoundedCornerShape(8.dp))
            .clickable { onClick() }
            .padding(12.dp)
            .testTag("proof_item_${proof.proofId}")
    ) {
        Column {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = proof.proofId,
                    color = TextPrimary,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
                StatusBadge(status = proof.verificationStatus.name)
            }

            Spacer(modifier = Modifier.height(6.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "Link: ${proof.linkId}",
                    color = TextMuted,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace
                )
                Text(
                    text = "Rate: ${(proof.verifiedThroughputBps / 1e6).toInt()} Mbps",
                    color = VerifiedGreen,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
            }
        }
    }
}
