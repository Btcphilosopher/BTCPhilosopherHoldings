package com.example.engine

import com.example.data.model.LinkBudget
import kotlin.math.log10
import kotlin.math.log2
import kotlin.math.pow

object LinkBudgetEngine {

    const val C_SPEED_OF_LIGHT = 299792458.0 // m/s
    const val BOLTZMANN_K = 1.380649e-23
    const val NOISE_TEMP_K = 290.0 // Kelvin

    /**
     * Calculates engineering link budget parameters according to space comms physics
     */
    fun calculateLinkBudget(
        linkId: String,
        frequencyHz: Double,
        bandwidthHz: Double,
        txPowerW: Double,
        distanceKm: Double,
        modulation: String = "QPSK",
        atmosLossDb: Double = 1.5,
        pointingLossDb: Double = 0.5,
        txGainDbi: Double = 34.0, // Satellite high-gain dish
        rxGainDbi: Double = 42.0  // Ground station dish
    ): LinkBudget {
        val distMeters = (distanceKm * 1000.0).coerceAtLeast(1000.0)
        val freqGHz = frequencyHz / 1e9

        // FSPL = 20*log10(d_km) + 20*log10(f_GHz) + 92.45
        val fsplDb = 20 * log10(distanceKm.coerceAtLeast(1.0)) + 20 * log10(freqGHz.coerceAtLeast(0.1)) + 92.45

        // Tx power in dBm
        val txPowerDbm = 10 * log10(txPowerW.coerceAtLeast(0.001) * 1000.0)

        // Total Losses
        val totalLossesDb = fsplDb + atmosLossDb + pointingLossDb

        // Received Power (dBm)
        val rxPowerDbm = txPowerDbm + txGainDbi + rxGainDbi - totalLossesDb

        // Noise Power N = k * T * B (in Watts)
        val noisePowerWatts = BOLTZMANN_K * NOISE_TEMP_K * bandwidthHz.coerceAtLeast(1e5)
        val noisePowerDbm = 10 * log10(noisePowerWatts * 1000.0)

        // SNR in dB
        val snrDb = rxPowerDbm - noisePowerDbm
        val snrLinear = 10.0.pow(snrDb / 10.0)

        // Shannon Capacity C = B * log2(1 + SNR_linear)
        val shannonCapacityBps = bandwidthHz * log2(1.0 + snrLinear)

        // Modulation bits per symbol & required Eb/N0
        val (bitsPerSymbol, requiredEbN0Db) = when (modulation.uppercase()) {
            "BPSK" -> Pair(1.0, 4.3)
            "QPSK" -> Pair(2.0, 6.8)
            "8PSK" -> Pair(3.0, 10.0)
            "16QAM" -> Pair(4.0, 11.5)
            "64QAM" -> Pair(6.0, 16.5)
            "256QAM" -> Pair(8.0, 21.0)
            else -> Pair(2.0, 6.8)
        }

        // Bitrate estimate
        val netBitrateBps = (bandwidthHz * bitsPerSymbol * 0.75).coerceAtMost(shannonCapacityBps)

        // Eb/N0 = SNR + 10*log10(Bandwidth / Bitrate)
        val bwToRateRatio = bandwidthHz / netBitrateBps.coerceAtLeast(1.0)
        val ebN0Db = snrDb + 10 * log10(bwToRateRatio)

        val linkMarginDb = ebN0Db - requiredEbN0Db
        val spectralEfficiency = netBitrateBps / bandwidthHz

        return LinkBudget(
            linkId = linkId,
            frequencyHz = frequencyHz,
            bandwidthHz = bandwidthHz,
            txPowerW = txPowerW,
            distanceKm = distanceKm,
            fsplDb = fsplDb,
            rxPowerDbm = rxPowerDbm,
            snrDb = snrDb,
            ebN0Db = ebN0Db,
            linkMarginDb = linkMarginDb,
            shannonCapacityBps = shannonCapacityBps,
            spectralEfficiency = spectralEfficiency
        )
    }
}
