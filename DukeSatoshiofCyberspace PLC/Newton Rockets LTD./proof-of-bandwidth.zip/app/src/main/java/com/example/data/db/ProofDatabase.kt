package com.example.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        AssetEntity::class,
        LinkEntity::class,
        ProofEntity::class,
        LedgerEntryEntity::class,
        BandwidthCreditEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class ProofDatabase : RoomDatabase() {
    abstract fun assetDao(): AssetDao
    abstract fun linkDao(): LinkDao
    abstract fun proofDao(): ProofDao
    abstract fun ledgerDao(): LedgerDao
    abstract fun creditDao(): CreditDao

    companion object {
        @Volatile
        private var INSTANCE: ProofDatabase? = null

        fun getDatabase(context: Context): ProofDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    ProofDatabase::class.java,
                    "proof_of_bandwidth.db"
                ).fallbackToDestructiveMigration().build()
                INSTANCE = instance
                instance
            }
        }
    }
}
