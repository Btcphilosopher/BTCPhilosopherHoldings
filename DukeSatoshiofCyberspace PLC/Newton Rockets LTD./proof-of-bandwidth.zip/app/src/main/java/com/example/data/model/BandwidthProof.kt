package com.example.data.model

data class BandwidthProof(
    val proofId: String,
    val assetId: String,
    val linkId: String,
    val serviceType: String,
    val startTime: Long,
    val endTime: Long,
    val bytesTransferred: Long,
    val measuredThroughputBps: Double,
    val verifiedThroughputBps: Double,
    val latencyMs: Double,
    val packetLossPercent: Double,
    val availabilityPercent: Double,
    val telemetryRoot: String,
    val eventHash: String,
    val previousHash: String = "0000000000000000000000000000000000000000000000000000000000000000",
    val protocolVersion: String = "PoB/1.0",
    val signature: String,
    val verificationStatus: VerificationStatus,
    val verifiedAtTimestamp: Long = System.currentTimeMillis()
)
