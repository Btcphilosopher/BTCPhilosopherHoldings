package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val AerospaceDarkColorScheme = darkColorScheme(
    primary = LaserCyan,
    onPrimary = SpaceBackground,
    secondary = VerifiedGreen,
    onSecondary = SpaceBackground,
    tertiary = SignalAmber,
    onTertiary = SpaceBackground,
    background = SpaceBackground,
    onBackground = TextPrimary,
    surface = PanelSurface,
    onSurface = TextPrimary,
    surfaceVariant = ConsoleSurfaceVariant,
    onSurfaceVariant = TextSecondary,
    outline = BorderSteel,
    error = AlertRed,
    onError = TextPrimary
)

@Composable
fun ProofOfBandwidthTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = AerospaceDarkColorScheme,
        typography = Typography,
        content = content
    )
}
