package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.RocketLaunch
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.MissionPhase
import com.example.ui.MainViewModel
import com.example.ui.components.MetricCard
import com.example.ui.components.StatusBadge
import com.example.ui.theme.AlertRed
import com.example.ui.theme.BorderSteel
import com.example.ui.theme.ConsoleSurfaceVariant
import com.example.ui.theme.LaserCyan
import com.example.ui.theme.SignalAmber
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.VerifiedGreen

@Composable
fun RocketScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val assets by viewModel.assets.collectAsStateWithLifecycle()
    val missionPhase by viewModel.missionPhase.collectAsStateWithLifecycle()
    val rocket = assets.find { it.id == "ROCKET-007" } ?: assets.first()

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "ROCKET & LAUNCH VEHICLE NOC",
                        color = LaserCyan,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        letterSpacing = 1.sp
                    )
                    Text(
                        text = "MISSION: NEWTON-07 ASCENT",
                        color = TextMuted,
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
                StatusBadge(status = "ACTIVE_MISSION")
            }
        }

        // Flight Phase Selector Tabs
        item {
            Column {
                Text(
                    text = "SELECT FLIGHT PHASE",
                    color = TextMuted,
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace,
                    modifier = Modifier.padding(bottom = 6.dp)
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    listOf(MissionPhase.LIFTOFF, MissionPhase.ASCENT, MissionPhase.MAX_Q, MissionPhase.STAGE_SEPARATION, MissionPhase.ORBIT_INSERTION).forEach { phase ->
                        val isSelected = phase == missionPhase
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .background(if (isSelected) LaserCyan else ConsoleSurfaceVariant, shape = RoundedCornerShape(4.dp))
                                .border(1.dp, if (isSelected) LaserCyan else BorderSteel, shape = RoundedCornerShape(4.dp))
                                .clickable { viewModel.setMissionPhase(phase) }
                                .padding(vertical = 8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = phase.name.take(6),
                                color = if (isSelected) Color.Black else TextPrimary,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                }
            }
        }

        // Rocket Telemetry Breakdown Grid
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(ConsoleSurfaceVariant, shape = RoundedCornerShape(8.dp))
                    .border(1.dp, BorderSteel, shape = RoundedCornerShape(8.dp))
                    .padding(14.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "LAUNCH TELEMETRY STREAM",
                        color = LaserCyan,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                    Text(
                        text = "ALT: ${"%.1f".format(rocket.altitudeKm)} KM",
                        color = VerifiedGreen,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.ExtraBold,
                        fontFamily = FontFamily.Monospace
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                TelemetryChannelRow("S-Band Telemetry", "184 Mbps", VerifiedGreen)
                TelemetryChannelRow("Uplink Command", "2.4 Mbps", LaserCyan)
                TelemetryChannelRow("High-Res Video Feed", "82 Mbps", SignalAmber)
                TelemetryChannelRow("Total S-Band Output", "268.4 Mbps", VerifiedGreen)

                Spacer(modifier = Modifier.height(14.dp))

                Button(
                    onClick = { viewModel.executeProveThisLink("LINK-ROCKET-GS01") },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = VerifiedGreen,
                        contentColor = Color.Black
                    ),
                    shape = RoundedCornerShape(6.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("prove_rocket_link_button")
                ) {
                    Icon(imageVector = Icons.Default.RocketLaunch, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "PROVE MISSION BANDWIDTH",
                        fontWeight = FontWeight.Black,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 13.sp
                    )
                }
            }
        }
    }
}

@Composable
private fun TelemetryChannelRow(channelName: String, rate: String, rateColor: Color) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text = channelName, color = TextPrimary, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
        Text(text = rate, color = rateColor, fontSize = 12.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
    }
}
