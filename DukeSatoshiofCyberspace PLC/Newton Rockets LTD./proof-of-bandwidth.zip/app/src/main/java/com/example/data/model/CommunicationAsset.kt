package com.example.data.model

data class CommunicationAsset(
    val id: String,
    val name: String,
    val type: AssetType,
    val operatorId: String,
    val publicKey: String,
    val status: AssetStatus,
    val latitude: Double = 0.0,
    val longitude: Double = 0.0,
    val altitudeKm: Double = 0.0,
    val payloadDataGeneratedGb: Double = 0.0,
    val onboardStorageQueueGb: Double = 0.0
)
