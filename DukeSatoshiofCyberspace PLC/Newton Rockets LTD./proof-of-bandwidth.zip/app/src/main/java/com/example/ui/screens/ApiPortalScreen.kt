package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.MainViewModel
import com.example.ui.components.StatusBadge
import com.example.ui.theme.BorderSteel
import com.example.ui.theme.ConsoleSurfaceVariant
import com.example.ui.theme.LaserCyan
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.VerifiedGreen

@Composable
fun ApiPortalScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    var selectedTab by remember { mutableStateOf("KOTLIN") }
    var apiResponseText by remember { mutableStateOf("") }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "PROOF-OF-BANDWIDTH API & SDK",
                        color = LaserCyan,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        letterSpacing = 1.sp
                    )
                    Text(
                        text = "PROTOCOL: PoB/1.0",
                        color = TextMuted,
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
                StatusBadge(status = "OPENAPI_V3")
            }
        }

        // Endpoint List
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(ConsoleSurfaceVariant, shape = RoundedCornerShape(8.dp))
                    .border(1.dp, BorderSteel, shape = RoundedCornerShape(8.dp))
                    .padding(14.dp)
            ) {
                Text(
                    text = "AVAILABLE API ENDPOINTS",
                    color = LaserCyan,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )

                Spacer(modifier = Modifier.height(8.dp))

                EndpointItem("POST", "/api/v1/proofs/bandwidth")
                EndpointItem("POST", "/api/v1/proofs/{id}/verify")
                EndpointItem("GET", "/api/v1/ledger")
                EndpointItem("GET", "/api/v1/link-budget/{id}")
            }
        }

        // SDK Code Snippet Tab Selector
        item {
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf("KOTLIN", "TYPESCRIPT", "CURL").forEach { tab ->
                        val isSelected = tab == selectedTab
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .background(if (isSelected) LaserCyan else ConsoleSurfaceVariant, shape = RoundedCornerShape(4.dp))
                                .border(1.dp, if (isSelected) LaserCyan else BorderSteel, shape = RoundedCornerShape(4.dp))
                                .clickable { selectedTab = tab }
                                .padding(vertical = 8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = tab,
                                color = if (isSelected) Color.Black else TextPrimary,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                val codeSnippet = when (selectedTab) {
                    "KOTLIN" -> """
                        val pob = PobClient(apiKey = "pob_key_live_9921")
                        val proof = pob.proofs.create(
                            linkId = "LINK-AUREOM-GS01",
                            durationSeconds = 300
                        )
                        val verification = pob.proofs.verify(proof.proofId)
                        println("Verified Rate: ${'$'}{proof.verifiedThroughputBps / 1e6} Mbps")
                    """.trimIndent()
                    "TYPESCRIPT" -> """
                        import { PobClient } from '@pob/sdk';
                        const pob = new PobClient({ apiKey: 'pob_key_live_9921' });
                        const proof = await pob.proofs.create({
                          linkId: 'LINK-AUREOM-GS01',
                          durationSeconds: 300
                        });
                        const result = await pob.proofs.verify(proof.proofId);
                    """.trimIndent()
                    else -> """
                        curl -X POST https://api.proofofbandwidth.com/v1/proofs/bandwidth \
                          -H "Authorization: Bearer pob_key_live_9921" \
                          -H "Content-Type: application/json" \
                          -d '{"linkId":"LINK-AUREOM-GS01","measurementWindowSeconds":300}'
                    """.trimIndent()
                }

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color.Black, shape = RoundedCornerShape(8.dp))
                        .border(1.dp, BorderSteel, shape = RoundedCornerShape(8.dp))
                        .padding(12.dp)
                ) {
                    Text(
                        text = codeSnippet,
                        color = VerifiedGreen,
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
        }

        // Test Endpoint Runner
        item {
            Button(
                onClick = {
                    apiResponseText = """
                        {
                          "proofId": "POB-2026-001842",
                          "status": "VERIFIED",
                          "verifiedThroughputBps": 836000000,
                          "bytesTransferred": 301700000000,
                          "availabilityPercent": 99.94,
                          "telemetryRoot": "4f92a188e72...",
                          "signature": "ed25519_sig_ok"
                        }
                    """.trimIndent()
                },
                colors = ButtonDefaults.buttonColors(
                    containerColor = LaserCyan,
                    contentColor = Color.Black
                ),
                shape = RoundedCornerShape(4.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("run_api_test_button")
            ) {
                Text(
                    text = "RUN LIVE API REQUEST",
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 12.sp
                )
            }
        }

        if (apiResponseText.isNotEmpty()) {
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color.Black, shape = RoundedCornerShape(8.dp))
                        .border(1.dp, VerifiedGreen, shape = RoundedCornerShape(8.dp))
                        .padding(12.dp)
                ) {
                    Text(text = "HTTP 200 OK", color = VerifiedGreen, fontSize = 11.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(text = apiResponseText, color = TextPrimary, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                }
            }
        }
    }
}

@Composable
private fun EndpointItem(method: String, path: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .background(if (method == "POST") VerifiedGreen else LaserCyan, shape = RoundedCornerShape(4.dp))
                .padding(horizontal = 6.dp, vertical = 2.dp)
        ) {
            Text(text = method, color = Color.Black, fontSize = 10.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
        }
        Text(text = path, color = TextPrimary, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
    }
}
