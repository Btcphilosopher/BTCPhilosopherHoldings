package com.example.engine

import com.example.data.model.AssetStatus
import com.example.data.model.AssetType
import com.example.data.model.CommunicationAsset
import com.example.data.model.ContactWindow
import com.example.data.model.LinkDirection
import com.example.data.model.LinkStatus
import com.example.data.model.LinkTelemetry
import com.example.data.model.LinkType
import com.example.data.model.MissionPhase
import com.example.data.model.SpaceLink
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

object SimulationEngine {

    // Initial Assets
    val defaultAssets = listOf(
        CommunicationAsset(
            id = "SAT-014",
            name = "AUREOM-14 (Payload LEO)",
            type = AssetType.SATELLITE,
            operatorId = "UK-SPACE-LAB",
            publicKey = "ed25519_pk_aureom14_8842",
            status = AssetStatus.ONLINE,
            latitude = 51.5,
            longitude = -0.1,
            altitudeKm = 550.0,
            payloadDataGeneratedGb = 4.8,
            onboardStorageQueueGb = 1.2
        ),
        CommunicationAsset(
            id = "SAT-022",
            name = "CELESTIA-02 (Polar LEO)",
            type = AssetType.SATELLITE,
            operatorId = "UK-SPACE-LAB",
            publicKey = "ed25519_pk_celestia02_9913",
            status = AssetStatus.ONLINE,
            latitude = 78.2,
            longitude = 15.6,
            altitudeKm = 620.0,
            payloadDataGeneratedGb = 8.2,
            onboardStorageQueueGb = 2.4
        ),
        CommunicationAsset(
            id = "RELAY-001",
            name = "ARTEMIS-R1 (GEO Relay)",
            type = AssetType.RELAY_SATELLITE,
            operatorId = "ESA-RELAY-NET",
            publicKey = "ed25519_pk_artemis_r1_1042",
            status = AssetStatus.ONLINE,
            latitude = 0.0,
            longitude = 25.0,
            altitudeKm = 35786.0,
            payloadDataGeneratedGb = 12.0,
            onboardStorageQueueGb = 0.4
        ),
        CommunicationAsset(
            id = "GS-001",
            name = "GS-001 (Cornwall Gateway)",
            type = AssetType.GROUND_STATION,
            operatorId = "UK-GATEWAY-NET",
            publicKey = "ed25519_pk_gs001_5510",
            status = AssetStatus.ONLINE,
            latitude = 50.0,
            longitude = -5.0,
            altitudeKm = 0.1,
            payloadDataGeneratedGb = 0.0,
            onboardStorageQueueGb = 0.0
        ),
        CommunicationAsset(
            id = "GS-002",
            name = "GS-002 (Svalbard Ground Station)",
            type = AssetType.GROUND_STATION,
            operatorId = "NORWAY-SAT-NET",
            publicKey = "ed25519_pk_gs002_7712",
            status = AssetStatus.ONLINE,
            latitude = 78.2,
            longitude = 15.6,
            altitudeKm = 0.4,
            payloadDataGeneratedGb = 0.0,
            onboardStorageQueueGb = 0.0
        ),
        CommunicationAsset(
            id = "ROCKET-007",
            name = "NEWTON-07 Launch Vehicle",
            type = AssetType.ROCKET,
            operatorId = "AEROSPACE-LAUNCH-CORP",
            publicKey = "ed25519_pk_newton07_3391",
            status = AssetStatus.ONLINE,
            latitude = 28.5,
            longitude = -80.5,
            altitudeKm = 142.0,
            payloadDataGeneratedGb = 0.5,
            onboardStorageQueueGb = 0.1
        )
    )

    // Initial Links
    val defaultLinks = listOf(
        SpaceLink(
            id = "LINK-AUREOM-GS01",
            sourceAssetId = "SAT-014",
            destinationAssetId = "GS-001",
            direction = LinkDirection.DUPLEX,
            linkType = LinkType.DOWNLINK,
            nominalCapacityBps = 1000000000L, // 1.0 Gbps
            allocatedCapacityBps = 850000000L,  // 850 Mbps
            frequencyHz = 12.5e9, // 12.5 GHz Ku Band
            bandwidthHz = 250e6,  // 250 MHz
            modulation = "64QAM",
            txPowerW = 50.0,
            distanceKm = 850.0,
            status = LinkStatus.OPTIMAL
        ),
        SpaceLink(
            id = "LINK-CELESTIA-GS02",
            sourceAssetId = "SAT-022",
            destinationAssetId = "GS-002",
            direction = LinkDirection.DUPLEX,
            linkType = LinkType.DOWNLINK,
            nominalCapacityBps = 1200000000L, // 1.2 Gbps
            allocatedCapacityBps = 950000000L,  // 950 Mbps
            frequencyHz = 14.2e9,
            bandwidthHz = 300e6,
            modulation = "64QAM",
            txPowerW = 60.0,
            distanceKm = 920.0,
            status = LinkStatus.OPTIMAL
        ),
        SpaceLink(
            id = "LINK-CROSS-SAT14-RELAY",
            sourceAssetId = "SAT-014",
            destinationAssetId = "RELAY-001",
            direction = LinkDirection.DUPLEX,
            linkType = LinkType.CROSSLINK,
            nominalCapacityBps = 2500000000L, // 2.5 Gbps Optical
            allocatedCapacityBps = 1800000000L,
            frequencyHz = 193.1e12, // Optical 1550nm
            bandwidthHz = 1e9,
            modulation = "QPSK",
            txPowerW = 5.0,
            distanceKm = 38000.0,
            status = LinkStatus.OPTIMAL
        ),
        SpaceLink(
            id = "LINK-ROCKET-GS01",
            sourceAssetId = "ROCKET-007",
            destinationAssetId = "GS-001",
            direction = LinkDirection.SIMPLEX_TX,
            linkType = LinkType.UPLINK,
            nominalCapacityBps = 300000000L, // 300 Mbps
            allocatedCapacityBps = 268000000L, // 268 Mbps
            frequencyHz = 2.2e9, // S-Band Telemetry
            bandwidthHz = 50e6,
            modulation = "QPSK",
            txPowerW = 20.0,
            distanceKm = 420.0,
            status = LinkStatus.OPTIMAL
        )
    )

    private val _assetsState = MutableStateFlow(defaultAssets)
    val assetsState: StateFlow<List<CommunicationAsset>> = _assetsState.asStateFlow()

    private val _linksState = MutableStateFlow(defaultLinks)
    val linksState: StateFlow<List<SpaceLink>> = _linksState.asStateFlow()

    private val _telemetryMap = MutableStateFlow<Map<String, LinkTelemetry>>(emptyMap())
    val telemetryMap: StateFlow<Map<String, LinkTelemetry>> = _telemetryMap.asStateFlow()

    private val _missionPhase = MutableStateFlow(MissionPhase.ASCENT)
    val missionPhase: StateFlow<MissionPhase> = _missionPhase.asStateFlow()

    private val _faultInjected = MutableStateFlow(false)
    val faultInjected: StateFlow<Boolean> = _faultInjected.asStateFlow()

    private var tickCount = 0L

    fun toggleFaultInjection() {
        _faultInjected.value = !_faultInjected.value
    }

    fun setMissionPhase(phase: MissionPhase) {
        _missionPhase.value = phase
    }

    /**
     * Executes one tick of orbital movement, physics calculations, and telemetry update
     */
    fun tickSimulation() {
        tickCount++
        val isFault = _faultInjected.value

        // 1. Orbital position updates for LEO satellites
        val updatedAssets = _assetsState.value.map { asset ->
            if (asset.type == AssetType.SATELLITE) {
                val angle = (tickCount * 0.05) % (2 * Math.PI)
                val newLat = (asset.latitude + sin(angle) * 0.2).coerceIn(-85.0, 85.0)
                val newLon = ((asset.longitude + cos(angle) * 0.3 + 180) % 360) - 180
                val newGenerated = asset.payloadDataGeneratedGb + 0.005
                val newQueue = (asset.onboardStorageQueueGb - 0.003).coerceAtLeast(0.1)
                asset.copy(latitude = newLat, longitude = newLon, payloadDataGeneratedGb = newGenerated, onboardStorageQueueGb = newQueue)
            } else if (asset.type == AssetType.ROCKET) {
                val newAlt = (100.0 + (tickCount % 200) * 1.5).coerceAtMost(550.0)
                asset.copy(altitudeKm = newAlt)
            } else asset
        }
        _assetsState.value = updatedAssets

        // 2. Generate causally connected telemetry for every link
        val newTelemetryMap = mutableMapOf<String, LinkTelemetry>()
        val updatedLinks = _linksState.value.map { link ->
            val isRocket = link.sourceAssetId == "ROCKET-007"
            val baseCapacity = link.allocatedCapacityBps.toDouble()
            
            // Apply fault or noise
            val noiseFactor = if (isFault) 0.65 else (0.95 + Random.nextDouble(-0.04, 0.04))
            val observedRateBps = (baseCapacity * noiseFactor).coerceAtLeast(1e6)

            val latency = if (link.linkType == LinkType.CROSSLINK) 120.0 + Random.nextDouble(0.0, 5.0) else 32.0 + Random.nextDouble(0.0, 4.0)
            val packetLoss = if (isFault) 3.8 + Random.nextDouble(0.0, 1.2) else 0.05 + Random.nextDouble(0.0, 0.05)
            val snrDb = if (isFault) 8.2 else 18.5 + Random.nextDouble(-0.5, 0.5)
            val marginDb = if (isFault) 1.2 else 6.8 + Random.nextDouble(-0.2, 0.2)

            val prevTelem = _telemetryMap.value[link.id]
            val prevTx = prevTelem?.txBytes ?: 100_000_000_000L
            val prevRx = prevTelem?.rxBytes ?: 99_900_000_000L
            val deltaBytes = (observedRateBps / 8.0).toLong()

            val telemetry = LinkTelemetry(
                timestamp = System.currentTimeMillis(),
                linkId = link.id,
                txBytes = prevTx + deltaBytes,
                rxBytes = prevRx + (deltaBytes * (1.0 - packetLoss / 100.0)).toLong(),
                txRateBps = observedRateBps,
                rxRateBps = observedRateBps * (1.0 - packetLoss / 100.0),
                latencyMs = latency,
                jitterMs = Random.nextDouble(0.2, 1.5),
                packetLossPercent = packetLoss,
                signalQuality = if (isFault) 0.62 else 0.98,
                snrDb = snrDb,
                linkMarginDb = marginDb,
                sequenceNumber = tickCount
            )

            newTelemetryMap[link.id] = telemetry

            val status = when {
                isFault -> LinkStatus.DEGRADED
                packetLoss > 1.0 -> LinkStatus.CONGESTED
                else -> LinkStatus.OPTIMAL
            }
            link.copy(status = status)
        }

        _linksState.value = updatedLinks
        _telemetryMap.value = newTelemetryMap
    }
}
