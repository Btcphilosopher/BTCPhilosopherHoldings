package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.TextMeasurer
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AssetType
import com.example.data.model.CommunicationAsset
import com.example.data.model.SpaceLink
import com.example.ui.theme.AlertRed
import com.example.ui.theme.BorderSteel
import com.example.ui.theme.ConsoleSurfaceVariant
import com.example.ui.theme.LaserCyan
import com.example.ui.theme.OrbitLineColor
import com.example.ui.theme.SignalAmber
import com.example.ui.theme.SpaceBackground
import com.example.ui.theme.TextMuted
import com.example.ui.theme.VerifiedGreen
import kotlinx.coroutines.delay
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun OrbitMapView(
    assets: List<CommunicationAsset>,
    links: List<SpaceLink>,
    onAssetClick: (CommunicationAsset) -> Unit,
    modifier: Modifier = Modifier
) {
    var animPhase by remember { mutableFloatStateOf(0f) }
    val textMeasurer = rememberTextMeasurer()

    LaunchedEffect(Unit) {
        while (true) {
            delay(30)
            animPhase = (animPhase + 0.02f) % 1f
        }
    }

    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(260.dp)
            .background(ConsoleSurfaceVariant, shape = RoundedCornerShape(8.dp))
            .border(1.dp, BorderSteel, shape = RoundedCornerShape(8.dp))
            .padding(2.dp)
    ) {
        Canvas(
            modifier = Modifier
                .fillMaxWidth()
                .height(256.dp)
                .pointerInput(assets) {
                    detectTapGestures { tapOffset ->
                        val w = size.width.toFloat()
                        val h = size.height.toFloat()
                        val center = Offset(w / 2f, h / 2f)

                        // Map click to nearest asset
                        val clickedAsset = assets.minByOrNull { asset ->
                            val pos = calculateAssetCanvasPos(asset, center, w, h)
                            (pos - tapOffset).getDistance()
                        }
                        if (clickedAsset != null) {
                            onAssetClick(clickedAsset)
                        }
                    }
                }
        ) {
            val w = size.width
            val h = size.height
            val center = Offset(w / 2f, h / 2f)

            // Draw Space Grid / Radar rings
            drawCircle(
                color = OrbitLineColor,
                radius = h * 0.22f,
                center = center,
                style = Stroke(width = 1f)
            )
            drawCircle(
                color = OrbitLineColor,
                radius = h * 0.42f,
                center = center,
                style = Stroke(width = 1f, pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 10f), 0f))
            )

            // Earth globe center sphere
            drawCircle(
                color = SpaceBackground,
                radius = h * 0.16f,
                center = center
            )
            drawCircle(
                color = LaserCyan.copy(alpha = 0.25f),
                radius = h * 0.16f,
                center = center,
                style = Stroke(width = 2f)
            )

            drawText(
                textMeasurer = textMeasurer,
                text = "EARTH (NOC)",
                style = TextStyle(
                    color = TextMuted,
                    fontSize = 9.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                ),
                topLeft = Offset(center.x - 28f, center.y - 6f)
            )

            // Map assets to screen coordinates
            val assetPosMap = mutableMapOf<String, Offset>()
            assets.forEach { asset ->
                val pos = calculateAssetCanvasPos(asset, center, w, h)
                assetPosMap[asset.id] = pos
            }

            // Draw Links with animated laser data flow
            links.forEach { link ->
                val src = assetPosMap[link.sourceAssetId]
                val dst = assetPosMap[link.destinationAssetId]

                if (src != null && dst != null) {
                    val isFault = link.status == com.example.data.model.LinkStatus.DEGRADED || link.status == com.example.data.model.LinkStatus.FAULT
                    val lineColor = if (isFault) AlertRed.copy(alpha = 0.7f) else VerifiedGreen.copy(alpha = 0.8f)

                    // Draw main beam line
                    drawLine(
                        color = lineColor,
                        start = src,
                        end = dst,
                        strokeWidth = if (link.nominalCapacityBps >= 2_000_000_000L) 3f else 1.8f
                    )

                    // Draw moving pulse packet
                    val pulsePos = Offset(
                        src.x + (dst.x - src.x) * animPhase,
                        src.y + (dst.y - src.y) * animPhase
                    )
                    drawCircle(
                        color = LaserCyan,
                        radius = 4f,
                        center = pulsePos
                    )
                }
            }

            // Draw Asset Node Icons & Labels
            assets.forEach { asset ->
                val pos = assetPosMap[asset.id] ?: center
                val nodeColor = when (asset.type) {
                    AssetType.SATELLITE -> LaserCyan
                    AssetType.RELAY_SATELLITE -> SignalAmber
                    AssetType.GROUND_STATION -> VerifiedGreen
                    AssetType.ROCKET -> AlertRed
                    else -> LaserCyan
                }

                // Outer halo
                drawCircle(
                    color = nodeColor.copy(alpha = 0.2f),
                    radius = 10f,
                    center = pos
                )
                // Core dot
                drawCircle(
                    color = nodeColor,
                    radius = 5f,
                    center = pos
                )

                // Label
                val shortName = asset.name.split(" ").firstOrNull() ?: asset.id
                drawText(
                    textMeasurer = textMeasurer,
                    text = shortName,
                    style = TextStyle(
                        color = Color.White,
                        fontSize = 9.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold
                    ),
                    topLeft = Offset(pos.x + 8f, pos.y - 6f)
                )
            }
        }
    }
}

private fun calculateAssetCanvasPos(
    asset: CommunicationAsset,
    center: Offset,
    width: Float,
    height: Float
): Offset {
    return when (asset.type) {
        AssetType.GROUND_STATION -> {
            // Positioned around Earth perimeter
            val angle = Math.toRadians(asset.longitude + 90.0)
            val r = height * 0.16f
            Offset(center.x + (r * cos(angle)).toFloat(), center.y + (r * sin(angle)).toFloat())
        }
        AssetType.SATELLITE -> {
            // LEO orbit ring
            val angle = Math.toRadians(asset.longitude * 2.5 + asset.latitude)
            val r = height * 0.32f
            Offset(center.x + (r * cos(angle)).toFloat(), center.y + (r * sin(angle)).toFloat())
        }
        AssetType.RELAY_SATELLITE -> {
            // GEO orbit outer ring
            val angle = Math.toRadians(asset.longitude + 45.0)
            val r = height * 0.44f
            Offset(center.x + (r * cos(angle)).toFloat(), center.y + (r * sin(angle)).toFloat())
        }
        AssetType.ROCKET -> {
            // Ascent vector trajectory
            Offset(width * 0.22f, height * 0.32f)
        }
        else -> Offset(width * 0.8f, height * 0.8f)
    }
}
