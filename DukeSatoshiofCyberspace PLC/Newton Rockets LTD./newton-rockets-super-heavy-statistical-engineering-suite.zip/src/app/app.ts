import { ChangeDetectionStrategy, Component, signal, computed, inject, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, FormGroup } from '@angular/forms';
import { MatIconModule } from '@angular/material/icon';
import { DataGenerator } from './services/data-generator';
import { StatsEngine } from './services/stats-engine';
import { VehicleRecord, EngineRecord, TelemetryRecord, LandingRecord, TurnaroundRecord, AnomalyRecord as RawAnomaly, ManufacturingSPCRecord } from './models/rocket-data';

@Component({
  changeDetection: ChangeDetectionStrategy.OnPush,
  selector: 'app-root',
  imports: [CommonModule, ReactiveFormsModule, MatIconModule],
  templateUrl: './app.html',
  styleUrl: './app.css',
})
export class App implements OnInit {
  private generator = inject(DataGenerator);
  private statsEngine = inject(StatsEngine);
  private fb = inject(FormBuilder);

  // --- STATE SIGNALS ---
  activeTab = signal<string>('Overview');
  reproducibilitySeed = signal<number>(20260929);
  
  // Datasets
  vehicles = signal<VehicleRecord[]>([]);
  flights = signal<VehicleRecord[]>([]);
  engines = signal<EngineRecord[]>([]);
  landings = signal<LandingRecord[]>([]);
  turnarounds = signal<TurnaroundRecord[]>([]);
  rawAnomalies = signal<RawAnomaly[]>([]);
  manufacturing = signal<ManufacturingSPCRecord[]>([]);

  // Selected telemetry variables
  selectedTelemetryFlight = signal<string>('N-FL-001');
  selectedTelemetryVar = signal<string>('velocity');
  telemetryStream = signal<TelemetryRecord[]>([]);

  // Active user selections / parameters
  selectedGeneration = signal<string>('ALL'); // 'ALL' | 'V1_Block1' | 'V2_Block2' | 'V3_Starship'
  selectedEnginePosition = signal<string>('ALL'); // 'ALL' | 'Center' | 'Inner_Ring' | 'Outer_Ring'
  selectedEngineBatch = signal<string>('ALL'); // 'ALL' | 'Batch_Alpha' | 'Batch_Beta' | 'Batch_Gamma' | 'Batch_Delta'
  activeVariable = signal<string>('thrust'); // 'thrust' | 'chamber_pressure' | 'specific_impulse' | 'vibration'

  // Form Controls
  bayesianForm!: FormGroup;
  monteCarloForm!: FormGroup;
  spcForm!: FormGroup;

  // Analysis / Report State
  generatedReport = signal<string>('');
  generatingReport = signal<boolean>(false);
  reportSection = signal<string>('Overview');

  // --- LIFE CYCLE ---
  ngOnInit() {
    this.loadDataset();
    this.initForms();
    this.loadTelemetry();
  }

  loadDataset() {
    const data = this.generator.generateDataset();
    this.vehicles.set(data.vehicles);
    this.flights.set(data.flights);
    this.engines.set(data.engines);
    this.landings.set(data.landings);
    this.turnarounds.set(data.turnarounds);
    this.rawAnomalies.set(data.anomalies);
    this.manufacturing.set(data.manufacturing);
  }

  initForms() {
    this.bayesianForm = this.fb.group({
      alphaPrior: [10],
      betaPrior: [2]
    });

    this.monteCarloForm = this.fb.group({
      thrustMean: [2200],
      thrustSd: [35],
      propellantMean: [3600000],
      propellantSd: [15000],
      dryMassMean: [190000],
      dryMassSd: [1200],
      dragMin: [0.15],
      dragMax: [0.35],
      samples: [10000]
    });

    this.spcForm = this.fb.group({
      componentType: ['LOX_Tank_Weld'],
      usl: [0.25],
      lsl: [-0.25]
    });
  }

  // Reload telemetry when flight selection shifts
  loadTelemetry() {
    const flightId = this.selectedTelemetryFlight();
    const fl = this.flights().find(f => f.flight_id === flightId);
    const ver = fl ? fl.vehicle_version : 'V2_Block2';
    const stream = this.generator.generateTelemetry(flightId, ver);
    this.telemetryStream.set(stream);
  }

  // --- DATA QUALITY & INTEGRITY COMPUTATIONS ---
  dataQualityReport = computed(() => {
    const rawLen = this.flights().length * 9; // Summary observations recorded
    const actLen = this.engines().length;
    const missingPercent = ((rawLen - actLen) / rawLen) * 100;

    const sensorSaturationEvents = this.engines().filter(e => e.chamber_pressure > 345 || e.vibration > 28).length;
    const rangeViolations = this.engines().filter(e => e.thrust < 1500 || e.specific_impulse < 300).length;

    return {
      receivedRecords: rawLen,
      retainedRecords: actLen,
      removedRecords: Math.max(0, rawLen - actLen),
      missingTelemetry: Math.round(missingPercent * 100) / 100,
      timestampAnomalies: this.rawAnomalies().filter(a => a.timestamp < 0).length,
      sensorSaturationEvents,
      duplicateRecords: 0,
      rangeViolations
    };
  });

  // --- FILTERED SELECTIONS ---
  filteredEngines = computed(() => {
    let list = this.engines();
    const gen = this.selectedGeneration();
    const pos = this.selectedEnginePosition();
    const batch = this.selectedEngineBatch();

    if (gen !== 'ALL') {
      const flsInGen = this.flights().filter(f => f.vehicle_version === gen).map(f => f.flight_id);
      list = list.filter(e => flsInGen.includes(e.flight_id));
    }
    if (pos !== 'ALL') {
      list = list.filter(e => e.engine_position === pos);
    }
    if (batch !== 'ALL') {
      list = list.filter(e => e.manufacturing_batch === batch);
    }
    return list;
  });

  filteredLandings = computed(() => {
    const gen = this.selectedGeneration();
    if (gen === 'ALL') return this.landings();
    
    // Link landing flight_id to vehicle generation
    const flsInGen = this.flights().filter(f => f.vehicle_version === gen).map(f => f.flight_id);
    return this.landings().filter(l => flsInGen.includes(l.flight_id));
  });

  filteredTurnarounds = computed(() => {
    const gen = this.selectedGeneration();
    if (gen === 'ALL') return this.turnarounds();

    // Link turnaround vehicle to version
    const vehsInGen = this.vehicles().filter(v => v.vehicle_version === gen).map(v => v.vehicle_id);
    return this.turnarounds().filter(t => vehsInGen.includes(t.vehicle_id));
  });

  // Numeric array of active variable values under current filters
  activeDataArray = computed(() => {
    const list = this.filteredEngines();
    const v = this.activeVariable();
    return list.map(e => {
      if (v === 'thrust') return e.thrust;
      if (v === 'chamber_pressure') return e.chamber_pressure;
      if (v === 'specific_impulse') return e.specific_impulse;
      if (v === 'vibration') return e.vibration;
      return e.thrust;
    });
  });

  // --- DESCRIPTIVE STATS ---
  statsSummary = computed(() => {
    return this.statsEngine.calculateSummary(this.activeDataArray());
  });

  // --- DISTRIBUTION FITTING ---
  distributionNormal = computed(() => {
    return this.statsEngine.fitDistribution(this.activeDataArray(), 'Normal');
  });
  distributionWeibull = computed(() => {
    return this.statsEngine.fitDistribution(this.activeDataArray(), 'Weibull');
  });
  distributionLognormal = computed(() => {
    return this.statsEngine.fitDistribution(this.activeDataArray(), 'Lognormal');
  });

  bestFittingDistribution = computed(() => {
    const norm = this.distributionNormal();
    const weib = this.distributionWeibull();
    const logn = this.distributionLognormal();

    const candidates = [norm, weib, logn].filter(c => c.aic !== 0);
    if (candidates.length === 0) return 'Undetermined';
    
    candidates.sort((a, b) => a.aic - b.aic);
    return candidates[0].name;
  });

  // --- RELIABILITY & SURVIVAL ANALYSIS ---
  reliabilityStats = computed(() => {
    const lands = this.filteredLandings();
    // Use landing burn durations or sequence number as survival time scale
    const times = lands.map(l => l.landing_burn_duration + (l.success ? 10 : 0));
    const events = lands.map(l => !l.success); // Failure event = unsuccessful landing

    const kmCurve = this.statsEngine.calculateKaplanMeier(times, events);
    const weibSurvival = this.statsEngine.calculateWeibullSurvival(times, events);

    return {
      kmCurve,
      weibSurvival
    };
  });

  // --- HYPOTHESIS TESTING (Welch Two-sample & ANOVA) ---
  hypothesisTesting = computed(() => {
    // 1. Welch t-test comparing V1 vs V3 Engine Thrusts
    const engs = this.engines();
    const fls = this.flights();

    const v1Flights = fls.filter(f => f.vehicle_version === 'V1_Block1').map(f => f.flight_id);
    const v3Flights = fls.filter(f => f.vehicle_version === 'V3_Starship').map(f => f.flight_id);

    const thrustV1 = engs.filter(e => v1Flights.includes(e.flight_id)).map(e => e.thrust);
    const thrustV3 = engs.filter(e => v3Flights.includes(e.flight_id)).map(e => e.thrust);

    const tTest = this.statsEngine.performWelchTTest(thrustV3, thrustV1);

    // 2. ANOVA comparing thrusts across Manufacturing Batches
    const groups: { [key: string]: number[] } = {
      'Batch_Alpha': engs.filter(e => e.manufacturing_batch === 'Batch_Alpha').map(e => e.thrust),
      'Batch_Beta': engs.filter(e => e.manufacturing_batch === 'Batch_Beta').map(e => e.thrust),
      'Batch_Gamma': engs.filter(e => e.manufacturing_batch === 'Batch_Gamma').map(e => e.thrust),
      'Batch_Delta': engs.filter(e => e.manufacturing_batch === 'Batch_Delta').map(e => e.thrust)
    };
    const anova = this.statsEngine.performANOVA(groups);

    return {
      tTest,
      anova
    };
  });

  // --- TIME-SERIES AND ANOMALIES ---
  telemetryAnomalies = computed(() => {
    const stream = this.telemetryStream();
    const times = stream.map(s => s.timestamp);
    const vals = stream.map(s => {
      const v = this.selectedTelemetryVar();
      if (v === 'altitude') return s.altitude;
      if (v === 'velocity') return s.velocity;
      if (v === 'acceleration') return s.acceleration;
      if (v === 'dynamic_pressure') return s.dynamic_pressure;
      if (v === 'vibration') return s.vibration;
      if (v === 'guidance_error') return s.guidance_error;
      return s.velocity;
    });

    return {
      zAnomalies: this.statsEngine.detectAnomalies(times, vals, 'ZScore'),
      ewmaAnomalies: this.statsEngine.detectAnomalies(times, vals, 'EWMA'),
      cusumAnomalies: this.statsEngine.detectAnomalies(times, vals, 'CUSUM')
    };
  });

  // --- STATISTICAL PROCESS CONTROL (SPC) ---
  manufacturingSPC = computed(() => {
    const list = this.manufacturing();
    const type = this.spcForm?.value?.componentType || 'LOX_Tank_Weld';
    const usl = this.spcForm?.value?.usl ?? 0.25;
    const lsl = this.spcForm?.value?.lsl ?? -0.25;

    const data = list.filter(m => m.component_type === type).map(m => m.dimension_error);
    const spcResult = this.statsEngine.calculateSPC(data, 5, usl, lsl);

    return {
      spcResult,
      type,
      usl,
      lsl
    };
  });

  // --- HIERARCHICAL MIXED EFFECTS WORKSPACE ---
  mixedEffectsResult = computed(() => {
    const list = this.engines();
    const y = list.map(e => e.thrust);
    const x = list.map(e => e.chamber_pressure);
    const groups = list.map(e => e.engine_id);

    return this.statsEngine.calculateMixedEffects(x, y, groups);
  });

  // --- BAYESIAN BELIEF GRAPH ---
  bayesianBeliefResult = computed(() => {
    const formVal = this.bayesianForm?.value || { alphaPrior: 10, betaPrior: 2 };
    
    // Attempt statistics from filtered landings
    const lands = this.filteredLandings();
    const totalTrials = lands.length;
    const totalSuccess = lands.filter(l => l.success).length;

    return this.statsEngine.calculateBayesianBetaBinomial(
      formVal.alphaPrior,
      formVal.betaPrior,
      totalTrials,
      totalSuccess
    );
  });

  // --- MONTE CARLO INSTANCE ---
  monteCarloSummary = computed(() => {
    const val = this.monteCarloForm?.value || {
      thrustMean: 2200, thrustSd: 35,
      propellantMean: 3600000, propellantSd: 15000,
      dryMassMean: 190000, dryMassSd: 1200,
      dragMin: 0.15, dragMax: 0.35, samples: 10000
    };

    const raw = this.statsEngine.runMonteCarlo(
      { mean: val.thrustMean, sd: val.thrustSd },
      { mean: val.propellantMean, sd: val.propellantSd },
      { mean: val.dryMassMean, sd: val.dryMassSd },
      { min: val.dragMin, max: val.dragMax },
      val.samples
    );

    // Pre-map sensitivities with absolute width percentages for template performance
    const sensitivityList = Object.entries(raw.sensitivities).map(([key, value]) => {
      return {
        name: key,
        value,
        widthPercent: Math.round(Math.abs(value) * 100)
      };
    });

    return {
      ...raw,
      sensitivityList
    };
  });

  // --- TURNAROUND AND CADENCE REGRESSION ---
  turnaroundRegression = computed(() => {
    const list = this.filteredTurnarounds();
    const x = list.map(t => t.flight_sequence_number);
    const y = list.map(t => t.total_turnaround_time);

    return {
      linear: this.statsEngine.calculateLinearRegression(x, y),
      poly: this.statsEngine.calculatePolynomialRegression(x, y),
      rawX: x,
      rawY: y
    };
  });

  // --- EXPORT METADATA REPORT VIA EXPRESS BACKEND ---
  async generateTechnicalReport() {
    this.generatingReport.set(true);
    this.generatedReport.set('');

    const activeSec = this.reportSection();
    
    // Build context dictionary
    let statsSummary: any = {};
    if (activeSec === 'Overview') {
      statsSummary = {
        summary: this.statsSummary(),
        quality: this.dataQualityReport(),
        overall_flights: this.flights().length,
        overall_vehicles: this.vehicles().length
      };
    } else if (activeSec === 'Engine Analytics') {
      statsSummary = {
        summary: this.statsSummary(),
        normalFit: this.distributionNormal(),
        weibullFit: this.distributionWeibull(),
        bestDist: this.bestFittingDistribution(),
        t_test: this.hypothesisTesting().tTest
      };
    } else if (activeSec === 'Reliability Analysis') {
      statsSummary = {
        kmCurveSnippet: this.reliabilityStats().kmCurve.slice(0, 8),
        weibullSurvival: {
          scale: this.reliabilityStats().weibSurvival.scale,
          shape: this.reliabilityStats().weibSurvival.shape
        }
      };
    } else if (activeSec === 'Manufacturing SPC') {
      statsSummary = {
        spc: this.manufacturingSPC().spcResult,
        usl: this.manufacturingSPC().usl,
        lsl: this.manufacturingSPC().lsl,
        type: this.manufacturingSPC().type
      };
    }

    const filters = {
      vehicle_generation: this.selectedGeneration(),
      engine_position: this.selectedEnginePosition(),
      active_variable: this.activeVariable(),
      seed: this.reproducibilitySeed()
    };

    try {
      const response = await fetch('/api/generate-report', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          section: activeSec,
          statsSummary,
          filters
        })
      });

      const data = await response.json();
      if (data.report) {
        this.generatedReport.set(data.report);
      } else {
        this.generatedReport.set(`Error compile: ${data.error || 'Server connection issue'}`);
      }
    } catch (e: any) {
      this.generatedReport.set(`Failed connection to analytical compiler: ${e?.message || e}`);
    } finally {
      this.generatingReport.set(false);
    }
  }

  // --- ACTIONS ---
  changeTab(tab: string) {
    this.activeTab.set(tab);
    this.reportSection.set(tab);
    this.generatedReport.set('');
  }

  changeTelemetryFlight(ev: any) {
    this.selectedTelemetryFlight.set(ev.target.value);
    this.loadTelemetry();
  }

  changeTelemetryVar(ev: any) {
    this.selectedTelemetryVar.set(ev.target.value);
  }

  // --- SVG PLOTTING PATH COMPUTATIONS (PURE TS MATHEMATICAL COORDINATE MAPPINGS) ---
  
  // 1. Engine performance variable histogram and CDF comparison curves
  engineChartData = computed(() => {
    const vals = this.activeDataArray();
    if (vals.length === 0) return { bars: [], normalCdfPath: '', ecdfPath: '', xMin: 0, xMax: 1, yMax: 1 };

    const min = Math.min(...vals);
    const max = Math.max(...vals);
    const span = max - min || 1;

    // Determine bins (15 bins)
    const nBins = 15;
    const binWidth = span / nBins;
    const bins = Array(nBins).fill(0);
    vals.forEach(v => {
      const idx = Math.min(nBins - 1, Math.floor((v - min) / binWidth));
      bins[idx]++;
    });

    const maxCount = Math.max(...bins, 1);
    const w = 500;
    const h = 200;

    // Map histogram bars
    const bars = bins.map((cnt, idx) => {
      const xPos = (idx / nBins) * w;
      const barH = (cnt / maxCount) * h;
      const barW = (w / nBins) - 4;
      return {
        x: xPos,
        y: h - barH,
        width: Math.max(2, barW),
        height: barH,
        count: cnt,
        label: `${Math.round((min + idx * binWidth) * 10) / 10}`
      };
    });

    // Map Empirical CDF Curve
    // Sort and map
    const sorted = [...vals].sort((a, b) => a - b);
    const n = sorted.length;
    let ecdfPoints = 'M 0 200 ';
    for (let i = 0; i < n; i += Math.max(1, Math.floor(n / 60))) {
      const xPos = ((sorted[i] - min) / span) * w;
      const yPos = 200 - ((i + 1) / n) * h;
      ecdfPoints += `L ${xPos} ${yPos} `;
    }
    // Add end point
    ecdfPoints += `L ${w} 0`;

    // Map Normal fitted CDF Curve
    const norm = this.distributionNormal();
    const mu = norm.parameters['mean'] || min;
    const sigma = norm.parameters['stdDev'] || 1;
    let normalPoints = '';
    
    const cdfNormalVal = (x: number, m: number, s: number) => {
      const z = (x - m) / s;
      const t = 1 / (1 + 0.2316419 * Math.abs(z));
      const d = 0.39894228 * Math.exp(-z * z / 2);
      const p = d * t * (0.31938153 + t * (-0.356563782 + t * (1.781477937 + t * (-1.821255978 + t * 1.330274429))));
      return z >= 0 ? 1 - p : p;
    };

    for (let i = 0; i <= 50; i++) {
      const xVal = min + (i / 50) * span;
      const xPos = (i / 50) * w;
      const cdfVal = cdfNormalVal(xVal, mu, sigma);
      const yPos = 200 - cdfVal * h;
      normalPoints += (i === 0 ? 'M' : 'L') + ` ${xPos} ${yPos} `;
    }

    return {
      bars,
      ecdfPath: ecdfPoints,
      normalCdfPath: normalPoints,
      xMin: this.roundTo(min, 2),
      xMax: this.roundTo(max, 2),
      yMax: maxCount
    };
  });

  // 2. Reliability Kaplan-Meier & Weibull parametric curves
  reliabilityChartData = computed(() => {
    const stats = this.reliabilityStats();
    const km = stats.kmCurve;
    const weib = stats.weibSurvival;

    const w = 500;
    const h = 200;

    if (km.length === 0) return { kmPath: '', kmCiPath: '', weibPath: '', timePoints: [] };

    const maxT = Math.max(...km.map(k => k.time), 1);

    // Map KM step-path and confidence interval area
    let kmPath = `M 0 0 `;
    let kmCiUpper = 'M 0 0 ';
    let kmCiLower = '';

    km.forEach((pt, idx) => {
      const xPos = (pt.time / maxT) * w;
      const yPos = 200 - pt.survival * h;
      const yCiL = 200 - pt.ciLower * h;
      const yCiU = 200 - pt.ciUpper * h;

      if (idx === 0) {
        kmPath += `M 0 ${yPos} L ${xPos} ${yPos} `;
        kmCiUpper += `M 0 ${yCiU} L ${xPos} ${yCiU} `;
        kmCiLower = `L ${xPos} ${yCiL} L 0 ${yCiL} Z`;
      } else {
        const prevX = (km[idx - 1].time / maxT) * w;

        kmPath += `L ${prevX} ${yPos} L ${xPos} ${yPos} `;
        kmCiUpper += `L ${prevX} ${yCiU} L ${xPos} ${yCiU} `;
        kmCiLower = `L ${xPos} ${yCiL} L ${prevX} ${yCiL} ` + kmCiLower;
      }
    });

    // Add trailing point to KM
    kmPath += `L ${w} ${200 - km[km.length - 1].survival * h}`;

    // Map Weibull parametric curve
    let weibPath = '';
    if (weib.timePoints.length > 0) {
      weib.timePoints.forEach((t, idx) => {
        const xPos = (t / maxT) * w;
        const yPos = 200 - weib.survivalCurve[idx] * h;
        weibPath += (idx === 0 ? 'M' : 'L') + ` ${xPos} ${yPos} `;
      });
    }

    return {
      kmPath,
      kmCiPath: kmCiUpper + kmCiLower,
      weibPath,
      maxT: Math.round(maxT)
    };
  });

  // 3. Cadence and Turnaround Scatter & Regression Curves
  turnaroundChartData = computed(() => {
    const data = this.turnaroundRegression();
    const x = data.rawX;
    const y = data.rawY;

    const w = 500;
    const h = 200;

    if (x.length === 0) return { points: [], linRegPath: '', polyRegPath: '', xMin: 0, xMax: 1, yMin: 0, yMax: 100 };

    const xMin = 1;
    const xMax = Math.max(...x, 5);
    const yMin = 0;
    const yMax = Math.max(...y, 60);

    const mapX = (val: number) => ((val - xMin) / (xMax - xMin)) * w;
    const mapY = (val: number) => h - ((val - yMin) / (yMax - yMin)) * h;

    // Map coordinates for points
    const points = x.map((valX, idx) => ({
      cx: mapX(valX),
      cy: mapY(y[idx]),
      rawX: valX,
      rawY: y[idx]
    }));

    // Linear regression line
    const b0 = data.linear.intercept;
    const b1 = data.linear.slope;
    const linRegPath = `M ${mapX(xMin)} ${mapY(b1 * xMin + b0)} L ${mapX(xMax)} ${mapY(b1 * xMax + b0)}`;

    // Polynomial regression curve
    const c = data.poly.coefficients; // [b0, b1, b2]
    let polyRegPath = '';
    const stepSize = (xMax - xMin) / 30;
    for (let i = 0; i <= 30; i++) {
      const curX = xMin + i * stepSize;
      const curY = c[0] + c[1] * curX + c[2] * curX * curX;
      polyRegPath += (i === 0 ? 'M' : 'L') + ` ${mapX(curX)} ${mapY(curY)} `;
    }

    return {
      points,
      linRegPath,
      polyRegPath,
      xMin,
      xMax,
      yMin,
      yMax: Math.round(yMax)
    };
  });

  // 4. Telemetry Curve Plot mapping
  telemetryChartData = computed(() => {
    const stream = this.telemetryStream();
    const activeVar = this.selectedTelemetryVar();

    const w = 500;
    const h = 200;

    if (stream.length === 0) return { path: '', yMin: 0, yMax: 100, xMax: 10, points: [] };

    const times = stream.map(s => s.timestamp);
    const xMax = times[times.length - 1];

    const vals = stream.map(s => {
      if (activeVar === 'altitude') return s.altitude;
      if (activeVar === 'velocity') return s.velocity;
      if (activeVar === 'acceleration') return s.acceleration;
      if (activeVar === 'dynamic_pressure') return s.dynamic_pressure;
      if (activeVar === 'vibration') return s.vibration;
      if (activeVar === 'guidance_error') return s.guidance_error;
      return s.velocity;
    });

    const yMin = Math.min(...vals, 0);
    const yMax = Math.max(...vals, 1);
    const ySpan = yMax - yMin || 1;

    let path = '';
    const points = stream.map((s, idx) => {
      const xPos = (s.timestamp / xMax) * w;
      const yPos = h - ((vals[idx] - yMin) / ySpan) * h;
      path += (idx === 0 ? 'M' : 'L') + ` ${xPos} ${yPos} `;
      return { x: xPos, y: yPos, time: s.timestamp, value: vals[idx], phase: s.phase };
    });

    return {
      path,
      yMin: this.roundTo(yMin, 1),
      yMax: this.roundTo(yMax, 1),
      xMax: Math.round(xMax),
      points
    };
  });

  // 5. SPC Control Chart subgroup tracking
  spcChartData = computed(() => {
    const spc = this.manufacturingSPC().spcResult;
    const w = 500;
    const h = 200;

    const means = spc.subgroupMeans;
    if (means.length === 0) return { meanPath: '', uclY: 0, lclY: 0, grandMeanY: 0, yMax: 1, points: [] };

    // Set scales based on USL/LSL and control bounds
    const limits = [spc.uclMean, spc.lclMean, ...means, this.manufacturingSPC().usl, this.manufacturingSPC().lsl];
    const yMin = Math.min(...limits) * 1.2;
    const yMax = Math.max(...limits) * 1.2;
    const span = yMax - yMin || 1;

    const mapY = (val: number) => h - ((val - yMin) / span) * h;

    let meanPath = '';
    const points = means.map((m, idx) => {
      const xPos = (idx / (means.length - 1 || 1)) * w;
      const yPos = mapY(m);
      meanPath += (idx === 0 ? 'M' : 'L') + ` ${xPos} ${yPos} `;
      return {
        cx: xPos,
        cy: yPos,
        val: m,
        out: m > spc.uclMean || m < spc.lclMean
      };
    });

    return {
      meanPath,
      uclY: mapY(spc.uclMean),
      lclY: mapY(spc.lclMean),
      grandMeanY: mapY(spc.grandMean),
      uslY: mapY(this.manufacturingSPC().usl),
      lslY: mapY(this.manufacturingSPC().lsl),
      yMin: this.roundTo(yMin, 2),
      yMax: this.roundTo(yMax, 2),
      points
    };
  });

  // 6. Bayesian Prior vs Posterior PDF Curve mapping
  bayesianChartData = computed(() => {
    const res = this.bayesianBeliefResult();
    const w = 500;
    const h = 200;

    const prior = res.priorPDF;
    const post = res.posteriorPDF;
    const p = res.pPoints;

    const maxDens = Math.max(...prior, ...post, 1);

    let priorPath = '';
    let postPath = '';
    let priorArea = 'M 0 200 ';
    let postArea = 'M 0 200 ';

    p.forEach((pt, idx) => {
      const xPos = pt * w;
      const yPrior = 200 - (prior[idx] / maxDens) * h;
      const yPost = 200 - (post[idx] / maxDens) * h;

      priorPath += (idx === 0 ? 'M' : 'L') + ` ${xPos} ${yPrior} `;
      postPath += (idx === 0 ? 'M' : 'L') + ` ${xPos} ${yPost} `;

      priorArea += `L ${xPos} ${yPrior} `;
      postArea += `L ${xPos} ${yPost} `;
    });

    priorArea += `L ${w} 200 Z`;
    postArea += `L ${w} 200 Z`;

    return {
      priorPath,
      postPath,
      priorArea,
      postArea,
      maxDens: Math.round(maxDens)
    };
  });

  // Helper calculation for rounding inside the computed fields
  private roundTo(val: number, decimals: number): number {
    if (isNaN(val) || !isFinite(val)) return 0;
    const factor = Math.pow(10, decimals);
    return Math.round(val * factor) / factor;
  }

  exportCSV() {
    // Build comma separated telemetry text
    const stream = this.telemetryStream();
    const headers = 'Timestamp,Altitude,Velocity,Acceleration,Pressure,Mach,Phase\n';
    const rows = stream.map(s => `${s.timestamp},${s.altitude},${s.velocity},${s.acceleration},${s.dynamic_pressure},${s.mach},${s.phase}`).join('\n');
    
    const blob = new Blob([headers + rows], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `NRSStats_telemetry_${this.selectedTelemetryFlight()}_${Date.now()}.csv`;
    a.click();
    window.URL.revokeObjectURL(url);
  }
}
