import { Injectable } from '@angular/core';
import {
  VehicleRecord,
  EngineRecord,
  TelemetryRecord,
  LandingRecord,
  TurnaroundRecord,
  AnomalyRecord,
  ManufacturingSPCRecord,
  FlightPhase
} from '../models/rocket-data';

// Deterministic Pseudo-Random Number Generator (Linear Congruential Generator)
export class SeededRandom {
  private m = 0x80000000; // 2**31
  private a = 1103515245;
  private c = 12345;
  private state: number;

  constructor(seed: number = 19690720) { // Default seed: Apollo 11 launch date
    this.state = seed ? seed : Math.floor(Math.random() * (this.m - 1));
  }

  // Returns a value between [0, 1)
  next(): number {
    this.state = (this.a * this.state + this.c) % this.m;
    return this.state / (this.m - 1);
  }

  // Returns an integer between [min, max]
  nextInt(min: number, max: number): number {
    return Math.floor(this.next() * (max - min + 1)) + min;
  }

  // Returns a value following standard normal distribution (Box-Muller transform)
  nextNormal(mean: number = 0, stdDev: number = 1): number {
    const u1 = this.next() || 0.0001; // Avoid 0
    const u2 = this.next();
    const randStdNormal = Math.sqrt(-2.0 * Math.log(u1)) * Math.cos(2.0 * Math.PI * u2);
    return mean + stdDev * randStdNormal;
  }

  // Returns a Weibull distributed value
  nextWeibull(scale: number, shape: number): number {
    return scale * Math.pow(-Math.log(1 - this.next() || 0.0001), 1 / shape);
  }

  // Returns a random element from an array
  choice<T>(arr: T[]): T {
    return arr[this.nextInt(0, arr.length - 1)];
  }
}

@Injectable({
  providedIn: 'root'
})
export class DataGenerator {
  generateDataset() {
    const rng = new SeededRandom(20260929); // Consistent seed for absolute reproducibility

    // 1. Generate 30 Vehicles
    const vehicles: VehicleRecord[] = [];
    const versions: ('V1_Block1' | 'V2_Block2' | 'V3_Starship')[] = ['V1_Block1', 'V2_Block2', 'V3_Starship'];
    const versionsWeight = [0.2, 0.4, 0.4]; // Distribution of version types

    for (let i = 1; i <= 30; i++) {
      const vIndex = i <= 6 ? 0 : i <= 18 ? 1 : 2; // Progressive upgrades
      const vehicle_id = `N-SH-${100 + i}`;
      const version = versions[vIndex];
      const isTest = i <= 8 ? 'Test' : 'Operational';
      const launchSite = rng.choice(['Starbase_PadA', 'KSC_LC39A', 'Vandenberg_SLC4E']);
      const missionType = rng.choice(['Cargo', 'Satellite', 'Propellant_Transfer', 'Crew']);

      // Base properties depending on version
      let vehicle_mass = 200000; // kg
      let propellant_mass = 3400000; // kg
      if (version === 'V2_Block2') {
        vehicle_mass = 190000;
        propellant_mass = 3600000;
      } else if (version === 'V3_Starship') {
        vehicle_mass = 180000;
        propellant_mass = 3800000;
      }

      vehicles.push({
        vehicle_id,
        vehicle_version: version,
        flight_id: '', // Will link to flights below
        mission_id: `M-${1000 + i}`,
        launch_date: new Date(2023, 0, 1 + (i * 35)).toISOString().split('T')[0],
        launch_site: launchSite as any,
        test_or_operational: isTest,
        mission_type: missionType as any,
        payload_mass: Math.round(rng.nextNormal(version === 'V3_Starship' ? 120000 : 75000, 10000)),
        vehicle_mass,
        propellant_mass,
        weather_conditions: rng.choice(['Clear', 'Overcast', 'High_Winds', 'Light_Rain']),
        temperature: Math.round(rng.nextNormal(21, 8)),
        pressure: Math.round(rng.nextNormal(1013, 10)),
        wind_speed: Math.round(rng.nextNormal(5, 3)),
        wind_direction: rng.nextInt(0, 359)
      });
    }

    // 2. Generate 100 Flights total, reusing vehicles to model reusability!
    const flights: VehicleRecord[] = [];
    const flightIdToVehicle = new Map<string, VehicleRecord>();
    
    // Each vehicle will fly between 1 and 8 times
    let flightCounter = 1;
    vehicles.forEach((veh, idx) => {
      const maxFlights = veh.vehicle_version === 'V1_Block1' ? rng.nextInt(1, 2) : 
                          veh.vehicle_version === 'V2_Block2' ? rng.nextInt(2, 4) : rng.nextInt(4, 8);
      
      for (let f = 1; f <= maxFlights && flightCounter <= 100; f++) {
        const flight_id = `N-FL-${String(flightCounter).padStart(3, '0')}`;
        const launchDate = new Date(2023, 0, 15 + (flightCounter * 11)).toISOString().split('T')[0];
        const mission_id = `M-${2000 + flightCounter}`;
        
        const flRecord: VehicleRecord = {
          ...veh,
          flight_id,
          mission_id,
          launch_date: launchDate,
          payload_mass: Math.round(veh.payload_mass * (1 + (rng.next() * 0.1 - 0.05))) // variance in mission payloads
        };
        flights.push(flRecord);
        flightIdToVehicle.set(flight_id, flRecord);
        flightCounter++;
      }
    });

    // Make sure we have exactly 100 flights (pad if necessary)
    while (flights.length < 100) {
      const flId = `N-FL-${String(flights.length + 1).padStart(3, '0')}`;
      const baseVeh = rng.choice(vehicles);
      flights.push({
        ...baseVeh,
        flight_id: flId,
        mission_id: `M-${2000 + flights.length + 1}`,
        launch_date: new Date(2025, 11, flights.length).toISOString().split('T')[0]
      });
    }

    // Sort flights chronologically
    flights.sort((a, b) => a.flight_id.localeCompare(b.flight_id));

    // 3. Generate 900 Engine-Flight Runs (representing a sample of engines across flights)
    // Booster runs 33 Raptor-like engines, let's track the central, inner, and outer core subsets
    const engines: EngineRecord[] = [];
    
    // Maintain a pool of ~150 unique engine units across the fleet to study lifetimes
    const enginePool: {
      engine_id: string;
      engine_version: 'R1' | 'R2' | 'R3';
      manufacturing_batch: 'Batch_Alpha' | 'Batch_Beta' | 'Batch_Gamma' | 'Batch_Delta';
      installation_date: string;
      totalFlights: number;
    }[] = [];

    for (let id = 101; id <= 250; id++) {
      const engine_id = `R-${id}`;
      const batch = rng.choice(['Batch_Alpha', 'Batch_Beta', 'Batch_Gamma', 'Batch_Delta']) as any;
      const version = id <= 130 ? 'R1' : id <= 190 ? 'R2' : 'R3';
      enginePool.push({
        engine_id,
        engine_version: version,
        manufacturing_batch: batch,
        installation_date: new Date(2022, 5, id - 100).toISOString().split('T')[0],
        totalFlights: 0
      });
    }

    // For each flight, we assign a subset of engines to positions (Center, Inner_Ring, Outer_Ring)
    // and save 9 summary engine performance statistics (representing 9 instrumented test runs per flight, totaling 900 records)
    flights.forEach((fl) => {
      // Choose 9 positions to document engine stats
      const positions: { pos: string; type: 'Raptor_Center' | 'Raptor_Boost' }[] = [
        { pos: 'Center', type: 'Raptor_Center' },
        { pos: 'Center_Dual', type: 'Raptor_Center' },
        { pos: 'Inner_01', type: 'Raptor_Boost' },
        { pos: 'Inner_02', type: 'Raptor_Boost' },
        { pos: 'Inner_03', type: 'Raptor_Boost' },
        { pos: 'Outer_01', type: 'Raptor_Boost' },
        { pos: 'Outer_02', type: 'Raptor_Boost' },
        { pos: 'Outer_03', type: 'Raptor_Boost' },
        { pos: 'Outer_04', type: 'Raptor_Boost' },
      ];

      positions.forEach((p, idx) => {
        // Pick an engine from pool based on age/version match
        const matchingEngs = enginePool.filter(e => {
          if (fl.vehicle_version === 'V1_Block1') return e.engine_version === 'R1';
          if (fl.vehicle_version === 'V2_Block2') return e.engine_version !== 'R3';
          return e.engine_version !== 'R1';
        });

        const selectedEng = matchingEngs.length > 0 ? rng.choice(matchingEngs) : rng.choice(enginePool);
        selectedEng.totalFlights++;

        // Base thrust/pressure depends on engine version and position
        let baseThrust = 2000; // kN
        let baseIsp = 327; // sec
        let baseChamberPressure = 250; // bar
        
        if (selectedEng.engine_version === 'R2') {
          baseThrust = 2200;
          baseIsp = 330;
          baseChamberPressure = 270;
        } else if (selectedEng.engine_version === 'R3') {
          baseThrust = 2690; // Raptor 3 thrust!
          baseIsp = 334;
          baseChamberPressure = 310;
        }

        // Adjust slightly based on installation location (inner vs outer cooling profile)
        const posGroup = p.pos.startsWith('Center') ? 'Center' : p.pos.startsWith('Inner') ? 'Inner_Ring' : 'Outer_Ring';
        if (posGroup === 'Center') {
          baseThrust -= 15; // throttled slightly for gimbal range
        } else if (posGroup === 'Outer_Ring') {
          baseThrust += 20; // boost mode
        }

        // Add some batch manufacturing variations
        if (selectedEng.manufacturing_batch === 'Batch_Alpha') {
          baseThrust *= 0.995; // minor calibration offset
        } else if (selectedEng.manufacturing_batch === 'Batch_Gamma') {
          baseThrust *= 1.006; // premium performance
        }

        // Engine lifetime degradation effect: slight decrease in Isp and Thrust with flight count
        const degradationFactor = Math.max(0.97, 1 - (selectedEng.totalFlights * 0.002));
        const finalThrust = rng.nextNormal(baseThrust * degradationFactor, baseThrust * 0.012);
        const finalChamberPressure = rng.nextNormal(baseChamberPressure * degradationFactor, baseChamberPressure * 0.015);
        const finalIsp = rng.nextNormal(baseIsp * degradationFactor, 1.2);

        // Fuel flows
        const fuelFlow = finalThrust / (finalIsp * 9.81 * 0.28); // approximation
        const oxFlow = fuelFlow * 3.6; // mixture ratio ~3.6

        engines.push({
          engine_id: selectedEng.engine_id,
          engine_type: p.type,
          engine_position: posGroup as any,
          engine_version: selectedEng.engine_version,
          manufacturing_batch: selectedEng.manufacturing_batch,
          installation_date: selectedEng.installation_date,
          flight_count: selectedEng.totalFlights,
          test_count: selectedEng.totalFlights * 2 + rng.nextInt(1, 3),
          engine_runtime: rng.nextInt(140, 165), // booster burns about 150 seconds
          fuel_flow: Math.round(fuelFlow * 10) / 10,
          oxidizer_flow: Math.round(oxFlow * 10) / 10,
          chamber_pressure: Math.round(finalChamberPressure * 10) / 10,
          turbopump_speed: Math.round(rng.nextNormal(18500 + (finalChamberPressure * 12), 200)),
          temperature: Math.round(rng.nextNormal(720, 25)),
          thrust: Math.round(finalThrust * 10) / 10,
          specific_impulse: Math.round(finalIsp * 10) / 10,
          vibration: Math.round(rng.nextNormal(posGroup === 'Center' ? 18.5 : 22.4, 1.8) * 10) / 10,
          flight_id: fl.flight_id,
          vehicle_id: fl.vehicle_id
        });
      });
    });

    // 4. Generate Landings (100 items - one for each flight)
    const landings: LandingRecord[] = [];
    flights.forEach((fl, index) => {
      const isV1 = fl.vehicle_version === 'V1_Block1';
      const isV2 = fl.vehicle_version === 'V2_Block2';
      const isV3 = fl.vehicle_version === 'V3_Starship';

      // Reusability improved landing success over time
      const successProb = isV1 ? 0.35 : isV2 ? 0.75 : 0.94;
      const success = rng.next() < successProb;

      const landingType = isV1 ? 'Sea_Recovery' : isV2 ? 'Pad_Landing' : 'Catch';
      const landingSite = isV1 ? 'Droneship_OCISLY' : isV2 ? 'LZ_1' : 'Mechazilla_Tower';

      // Landing error uses log-normal distribution (often fits spatial accuracy)
      // V3 has sub-meter accuracy! V1 has large scatter
      const errorScale = isV1 ? 15.0 : isV2 ? 4.5 : 0.8;
      const landing_error = success ? rng.nextWeibull(errorScale, 1.5) : rng.nextNormal(80, 30);

      landings.push({
        landing_id: `LD-${200 + index}`,
        vehicle_id: fl.vehicle_id,
        flight_id: fl.flight_id,
        landing_type: landingType as any,
        landing_error: Math.round(Math.max(0.05, landing_error) * 1000) / 1000,
        touchdown_velocity: success ? Math.abs(rng.nextNormal(1.2, 0.4)) : Math.abs(rng.nextNormal(12.4, 4.0)),
        touchdown_angle: success ? Math.abs(rng.nextNormal(0.4, 0.2)) : Math.abs(rng.nextNormal(8.5, 4.5)),
        fuel_remaining: success ? Math.round(rng.nextNormal(12000, 1500)) : Math.round(rng.nextNormal(800, 500)),
        landing_burn_duration: rng.nextInt(22, 31),
        landing_site: landingSite as any,
        success
      });
    });

    // 5. Generate Turnaround times
    // We only have turnarounds between consecutive flights of the SAME vehicle
    const turnarounds: TurnaroundRecord[] = [];
    const vehicleFlights = new Map<string, VehicleRecord[]>();
    flights.forEach(f => {
      const list = vehicleFlights.get(f.vehicle_id) || [];
      list.push(f);
      vehicleFlights.set(f.vehicle_id, list);
    });

    vehicleFlights.forEach((fls, vehId) => {
      // Sort flights of this vehicle chronologically
      fls.sort((a, b) => a.flight_id.localeCompare(b.flight_id));
      for (let s = 0; s < fls.length - 1; s++) {
        const prev = fls[s];
        const next = fls[s + 1];

        // Refurbishment duration is modeled via Weibull decay (faster as processes mature)
        // V1 takes 180 days, V3 takes 10-25 days!
        const version = prev.vehicle_version;
        let baseDays = 150;
        if (version === 'V2_Block2') baseDays = 50;
        if (version === 'V3_Starship') baseDays = 14;

        // Learn over sequence
        const learningFactor = Math.max(0.6, 1 - (s * 0.1));
        const finalBase = baseDays * learningFactor;

        const inspection = Math.round(rng.nextNormal(finalBase * 0.25, finalBase * 0.05) * 10) / 10;
        const refurbishment = Math.round(rng.nextWeibull(finalBase * 0.5, 1.8) * 10) / 10;
        const transport = Math.round(rng.nextNormal(2.5, 0.5) * 10) / 10;
        const integration = Math.round(rng.nextNormal(finalBase * 0.15, finalBase * 0.04) * 10) / 10;
        const processing = Math.round(rng.nextNormal(4.0, 1.0) * 10) / 10;

        turnarounds.push({
          vehicle_id: vehId,
          previous_flight: prev.flight_id,
          next_flight: next.flight_id,
          flight_sequence_number: s + 1,
          inspection_duration: Math.max(1, inspection),
          refurbishment_duration: Math.max(1, refurbishment),
          transport_duration: Math.max(0.5, transport),
          integration_duration: Math.max(1, integration),
          launch_processing_duration: Math.max(1, processing),
          total_turnaround_time: Math.round((inspection + refurbishment + transport + integration + processing) * 10) / 10
        });
      }
    });

    // 6. Generate Flight Anomalies/Failures (modeling historical reliability growth)
    const anomalies: AnomalyRecord[] = [];
    const components: AnomalyRecord['component'][] = [
      'Turbopump_Seal', 'Main_Oxidizer_Valve', 'Chamber_Cooling',
      'Gimbal_Actuator', 'Avionics_Bus_B', 'Thermal_Shield_Tile'
    ];
    const eventTypes: AnomalyRecord['event_type'][] = [
      'Sensor_Drift', 'Pressure_Spike', 'Vibration_Exceedance',
      'Temperature_Anomaly', 'Thrust_Asymmetry'
    ];

    flights.forEach((fl) => {
      // Probability of anomaly depends on version: V1 = 45% chance, V2 = 12% chance, V3 = 3% chance
      const prob = fl.vehicle_version === 'V1_Block1' ? 0.45 : fl.vehicle_version === 'V2_Block2' ? 0.12 : 0.03;
      if (rng.next() < prob) {
        const severity = rng.choice(['Minor', 'Minor', 'Moderate', 'Critical']) as any;
        const component = rng.choice(components);
        const eventType = rng.choice(eventTypes);
        const timestamp = rng.nextInt(12, 140); // happens during active burn

        let corrective = 'Sensor tolerance adjusted in telemetry software.';
        if (severity === 'Critical') {
          corrective = 'Redundant avionics line routed; manufacturing weld specs increased.';
        } else if (severity === 'Moderate') {
          corrective = 'Turbopump gasket changed to Nitrile alloy; inspection cycles increased.';
        }

        anomalies.push({
          event_id: `AN-${1000 + anomalies.length}`,
          flight_id: fl.flight_id,
          vehicle_id: fl.vehicle_id,
          timestamp,
          component,
          subsystem: component === 'Avionics_Bus_B' ? 'Avionics' :
                     component === 'Thermal_Shield_Tile' ? 'Thermal' :
                     component === 'Gimbal_Actuator' ? 'GNC' : 'Propulsion',
          event_type: eventType,
          severity,
          duration: rng.nextInt(1, 150),
          detected: rng.next() < 0.95,
          cause_category: rng.choice(['Manufacturing_Defect', 'Thermal_Stress', 'Fatigue', 'Debris_Impact']),
          corrective_action: corrective
        });
      }
    });

    // 7. Generate Manufacturing SPC Quality Records
    const spcRecords: ManufacturingSPCRecord[] = [];
    const compTypes: ManufacturingSPCRecord['component_type'][] = ['Dome_Section', 'LOX_Tank_Weld', 'Raptor_Nozzle', 'Grid_Fin_Shaft'];
    const suppliers: ManufacturingSPCRecord['supplier'][] = ['Newton_Internal_Forge', 'Space_Castings_Ltd', 'Apex_Metallurgy'];

    for (let p = 1; p <= 120; p++) {
      const type = rng.choice(compTypes);
      const supplier = rng.choice(suppliers);
      const batchId = `B-SPC-${String(Math.ceil(p / 15)).padStart(2, '0')}`;

      // Gage R&R analysis needs measurements under standard targets
      // Let's generate dimensional deviations (target = 0.0mm deviation)
      let bias = 0.0;
      let stdDev = 0.12; // mm

      // Supplier performance shifts
      if (supplier === 'Space_Castings_Ltd') {
        bias = 0.04;
        stdDev = 0.18; // higher variability
      } else if (supplier === 'Apex_Metallurgy') {
        bias = -0.02;
        stdDev = 0.08; // high precision
      }

      // Add a progressive manufacturing drift over time!
      const drift = (p / 120) * 0.03;

      spcRecords.push({
        part_id: `PT-${3000 + p}`,
        component_type: type,
        batch_id: batchId,
        supplier,
        dimension_error: Math.round(rng.nextNormal(bias + drift, stdDev) * 1000) / 1000,
        mass: Math.round(rng.nextNormal(type === 'Dome_Section' ? 1250 : type === 'Raptor_Nozzle' ? 420 : 85, 5) * 10) / 10,
        tensile_strength: Math.round(rng.nextNormal(type === 'LOX_Tank_Weld' ? 485 : 560, 25)),
        weld_void_percentage: Math.max(0, Math.round(rng.nextWeibull(0.4, 1.2) * 100) / 100),
        spc_date: new Date(2025, 0, p * 2).toISOString().split('T')[0]
      });
    }

    return {
      vehicles,
      flights,
      engines,
      landings,
      turnarounds,
      anomalies,
      manufacturing: spcRecords
    };
  }

  // High-frequency telemetry curve generator for standard flights
  generateTelemetry(flightId: string, vehicleVersion: string): TelemetryRecord[] {
    const rng = new SeededRandom(flightId.charCodeAt(5) * 1000 + flightId.charCodeAt(6));
    const telemetry: TelemetryRecord[] = [];

    // Map a complete trajectory profile: 0 to 240 seconds (downsampled to 80 intervals)
    const totalTime = 240;
    const intervals = 80;
    const dt = totalTime / intervals;

    let altitude = 0; // meters
    let velocity = 0; // m/s
    let acc = 0; // m/s^2
    const totalPropellant = 3400000; // kg

    for (let step = 0; step <= intervals; step++) {
      const t = step * dt;
      let phase: FlightPhase = 'Liftoff';

      // Assign flight phase boundaries
      if (t < 5) {
        phase = 'Startup';
      } else if (t < 40) {
        phase = 'Ascent';
      } else if (t < 65) {
        phase = 'MaxQ';
      } else if (t < 130) {
        phase = 'EngineThrottling';
      } else if (t < 150) {
        phase = 'StageSeparation';
      } else if (t < 210) {
        phase = 'Coast';
      } else if (t < 235) {
        phase = 'LandingBurn';
      } else {
        phase = 'Touchdown';
      }

      // Physics model approximation
      if (phase === 'Startup') {
        acc = rng.nextNormal(0.1, 0.05);
        velocity += acc * dt;
        altitude += velocity * dt;
      } else if (phase === 'Ascent' || phase === 'MaxQ' || phase === 'EngineThrottling') {
        const timeCoeff = (t - 5) / 140;
        acc = rng.nextNormal(11.5 + (timeCoeff * 22), 0.5); // Accel increases as mass decreases
        velocity += acc * dt;
        altitude += velocity * dt;
      } else if (phase === 'StageSeparation') {
        acc = rng.nextNormal(-3.5, 0.4); // brief coast & deceleration
        velocity += acc * dt;
        altitude += velocity * dt;
      } else if (phase === 'Coast') {
        acc = rng.nextNormal(-9.8, 0.1); // gravity dominates apex
        velocity += acc * dt;
        altitude += velocity * dt;
        if (altitude < 0) altitude = 0;
      } else if (phase === 'LandingBurn') {
        // High deceleration
        acc = rng.nextNormal(14.5, 1.2);
        velocity -= acc * dt;
        if (velocity < 2) velocity = 2; // slow to pad
        altitude -= velocity * dt;
        if (altitude < 10) altitude = 10;
      } else if (phase === 'Touchdown') {
        acc = 0;
        velocity = 0;
        altitude = 0;
      }

      // Calculate auxiliary variables
      const mach = Math.max(0, Math.round((velocity / 340) * 100) / 100);
      const atmosphericDensity = Math.exp(-altitude / 8500);
      const dynamic_pressure = Math.round(0.5 * 1.225 * atmosphericDensity * velocity * velocity / 1000 * 10) / 10; // kPa

      // Fuel burn profile
      const propellant_level = Math.max(0, Math.round((1.0 - (t / 150) * 0.95) * 100)); // active booster burn
      const propellant_pressure = t < 150 ? Math.round(rng.nextNormal(5.2, 0.15) * 100) / 100 : Math.round(rng.nextNormal(2.1, 0.1) * 100) / 100;

      // Guidance deviation
      const baseGuidanceDev = vehicleVersion === 'V3_Starship' ? 0.05 : vehicleVersion === 'V2_Block2' ? 0.15 : 0.45;
      const guidance_error = Math.max(0.01, Math.round(rng.nextWeibull(baseGuidanceDev * (1 + (t / 80)), 1.2) * 1000) / 1000);

      // Total thrust profile
      let totalThrust = 0;
      if (t > 3 && t < 145) {
        totalThrust = vehicleVersion === 'V3_Starship' ? 88000 : vehicleVersion === 'V2_Block2' ? 72000 : 66000;
        totalThrust *= rng.nextNormal(1.0, 0.008); // small jitter
      } else if (phase === 'LandingBurn') {
        totalThrust = 8000 * rng.nextNormal(1.0, 0.02); // 3 engines firing
      }

      telemetry.push({
        timestamp: Math.round(t * 100) / 100,
        flight_id: flightId,
        vehicle_id: `N-SH-${100 + Number(flightId.slice(-3)) % 30}`,
        altitude: Math.round(altitude),
        velocity: Math.round(velocity * 10) / 10,
        acceleration: Math.round(acc * 10) / 10,
        dynamic_pressure,
        mach,
        attitude: {
          pitch: Math.round((90 - (t < 150 ? (t / 150) * 80 : 80)) * 10) / 10,
          yaw: Math.round(rng.nextNormal(0, 0.05) * 100) / 100,
          roll: Math.round(rng.nextNormal(0, 0.02) * 100) / 100,
        },
        angular_velocity: Math.round(Math.abs(rng.nextNormal(0.02, 0.01)) * 100) / 100,
        propellant_level,
        propellant_pressure,
        engine_status: t < 3 ? 'Startup' : t < 145 ? 'Thrusting' : t < 150 ? 'Throttled' : t < 210 ? 'Shutdown' : t < 235 ? 'Thrusting' : 'Shutdown',
        thrust: Math.round(totalThrust),
        temperature: Math.round(rng.nextNormal(t < 150 ? 450 + (t * 1.5) : 675 - (t - 150) * 2, 8)),
        vibration: Math.round(rng.nextNormal(t < 150 ? 22.4 : 1.2, 1.5) * 10) / 10,
        guidance_error,
        phase
      });
    }

    return telemetry;
  }
}
