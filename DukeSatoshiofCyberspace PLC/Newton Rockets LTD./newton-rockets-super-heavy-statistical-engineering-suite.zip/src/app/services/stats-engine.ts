import { Injectable } from '@angular/core';

// Interfaces for Statistical Results
export interface SummaryStats {
  n: number;
  missing: number;
  mean: number;
  median: number;
  variance: number;
  stdDev: number;
  min: number;
  max: number;
  range: number;
  iqr: number;
  mad: number;
  cv: number; // Coefficient of variation
  skewness: number;
  kurtosis: number;
  ciLower: number; // 95% Confidence Interval Lower
  ciUpper: number; // 95% Confidence Interval Upper
  quantiles: {
    q05: number;
    q25: number;
    q50: number;
    q75: number;
    q95: number;
    q99: number;
  };
}

export interface FittedDistribution {
  name: string;
  parameters: { [key: string]: number };
  aic: number;
  bic: number;
  ksStat: number; // Kolmogorov-Smirnov statistic
  ksCritical: number; // Critical KS value
  passGoF: boolean; // Passes Goodness of Fit?
  fittedY: number[]; // ECDF values for QQ/PP plotting
}

export interface RegressionResult {
  slope: number;
  intercept: number;
  r2: number;
  adjR2: number;
  rse: number; // Residual Standard Error
  fStatistic: number;
  pValueSlope: number;
  residuals: number[];
  fittedValues: number[];
}

export interface PolynomialResult {
  coefficients: number[]; // [b0, b1, b2] representing b0 + b1*x + b2*x^2
  r2: number;
  fittedValues: number[];
  residuals: number[];
}

export interface MixedEffectsResult {
  fixedEffects: { intercept: number; slope: number };
  randomEffects: { [groupId: string]: number }; // random intercept offsets
  varianceComponents: {
    randomEffectVar: number;
    residualVar: number;
    icc: number; // Intraclass Correlation Coefficient
  };
  fittedValues: number[];
  residuals: number[];
}

export interface KaplanMeierPoint {
  time: number;
  nAtRisk: number;
  nEvents: number;
  survival: number;
  ciLower: number;
  ciUpper: number;
}

export interface WeibullSurvivalResult {
  scale: number; // lambda
  shape: number; // k
  timePoints: number[];
  survivalCurve: number[];
  hazardCurve: number[];
}

export interface HypothesisTestResult {
  testName: string;
  statistic: number;
  df: number;
  pValue: number;
  significant: boolean;
  groupAMean: number;
  groupBMean: number;
}

export interface SPCChartResult {
  subgroupMeans: number[];
  subgroupRanges: number[];
  grandMean: number;
  meanRange: number;
  uclMean: number;
  lclMean: number;
  uclRange: number;
  lclRange: number;
  cp: number;
  cpk: number;
  pp: number;
  ppk: number;
  outOfControlIndexes: number[];
}

export interface AnomalyRecord {
  index: number;
  timestamp: number;
  value: number;
  expected: number;
  residual: number;
  threshold: number;
  severity: 'Minor' | 'Moderate' | 'Critical';
  method: string;
}

export interface MonteCarloSummary {
  inputs: {
    thrust: number[];
    propellant: number[];
    dryMass: number[];
    dragCoeff: number[];
  };
  outputs: number[]; // burnout velocity
  mean: number;
  median: number;
  stdDev: number;
  p05: number;
  p50: number;
  p95: number;
  p99: number;
  sensitivities: { [inputName: string]: number }; // Pearson correlations
}

@Injectable({
  providedIn: 'root'
})
export class StatsEngine {

  // --- 1. DESCRIPTIVE STATISTICS ENGINE ---
  calculateSummary(data: number[]): SummaryStats {
    const clean = data.filter(x => x !== null && x !== undefined && !isNaN(x));
    const missing = data.length - clean.length;

    if (clean.length === 0) {
      return this.emptySummary();
    }

    const n = clean.length;
    const sorted = [...clean].sort((a, b) => a - b);

    // Mean
    const sum = sorted.reduce((a, b) => a + b, 0);
    const mean = sum / n;

    // Median & Quantiles
    const getQuantile = (q: number) => {
      const pos = (n - 1) * q;
      const base = Math.floor(pos);
      const rest = pos - base;
      if (base + 1 < n) {
        return sorted[base] + rest * (sorted[base + 1] - sorted[base]);
      } else {
        return sorted[base];
      }
    };

    const q05 = getQuantile(0.05);
    const q25 = getQuantile(0.25);
    const q50 = getQuantile(0.50);
    const q75 = getQuantile(0.75);
    const q95 = getQuantile(0.95);
    const q99 = getQuantile(0.99);
    const median = q50;

    // Variance & Standard Deviation
    const sqDiffSum = sorted.reduce((acc, val) => acc + Math.pow(val - mean, 2), 0);
    const variance = n > 1 ? sqDiffSum / (n - 1) : 0;
    const stdDev = Math.sqrt(variance);

    const min = sorted[0];
    const max = sorted[n - 1];
    const range = max - min;
    const iqr = q75 - q25;

    // Median Absolute Deviation (MAD)
    const absoluteDeviations = sorted.map(val => Math.abs(val - median));
    const sortedDevs = absoluteDeviations.sort((a, b) => a - b);
    const mad = sortedDevs[Math.floor(n / 2)];

    // Coefficient of variation
    const cv = mean !== 0 ? stdDev / Math.abs(mean) : 0;

    // Skewness
    let skewness = 0;
    if (n > 2 && stdDev > 0) {
      const skewSum = sorted.reduce((acc, val) => acc + Math.pow((val - mean) / stdDev, 3), 0);
      skewness = (n / ((n - 1) * (n - 2))) * skewSum;
    }

    // Kurtosis (excess)
    let kurtosis = 0;
    if (n > 3 && stdDev > 0) {
      const kurtSum = sorted.reduce((acc, val) => acc + Math.pow((val - mean) / stdDev, 4), 0);
      const term1 = (n * (n + 1)) / ((n - 1) * (n - 2) * (n - 3));
      const term2 = (3 * Math.pow(n - 1, 2)) / ((n - 2) * (n - 3));
      kurtosis = term1 * kurtSum - term2;
    }

    // 95% Confidence Interval for the Mean (t-distribution critical value approximation)
    // For n > 30, t_critical approx 1.96. For smaller, we adjust.
    const tCritical = n > 120 ? 1.96 : n > 30 ? 2.0 : n > 10 ? 2.2 : 2.5;
    const marginOfError = tCritical * (stdDev / Math.sqrt(n));
    const ciLower = mean - marginOfError;
    const ciUpper = mean + marginOfError;

    return {
      n,
      missing,
      mean: this.roundTo(mean, 4),
      median: this.roundTo(median, 4),
      variance: this.roundTo(variance, 4),
      stdDev: this.roundTo(stdDev, 4),
      min: this.roundTo(min, 4),
      max: this.roundTo(max, 4),
      range: this.roundTo(range, 4),
      iqr: this.roundTo(iqr, 4),
      mad: this.roundTo(mad, 4),
      cv: this.roundTo(cv, 4),
      skewness: this.roundTo(skewness, 4),
      kurtosis: this.roundTo(kurtosis, 4),
      ciLower: this.roundTo(ciLower, 4),
      ciUpper: this.roundTo(ciUpper, 4),
      quantiles: {
        q05: this.roundTo(q05, 4),
        q25: this.roundTo(q25, 4),
        q50: this.roundTo(q50, 4),
        q75: this.roundTo(q75, 4),
        q95: this.roundTo(q95, 4),
        q99: this.roundTo(q99, 4)
      }
    };
  }

  private emptySummary(): SummaryStats {
    return {
      n: 0, missing: 0, mean: 0, median: 0, variance: 0, stdDev: 0, min: 0, max: 0, range: 0, iqr: 0, mad: 0, cv: 0, skewness: 0, kurtosis: 0, ciLower: 0, ciUpper: 0,
      quantiles: { q05: 0, q25: 0, q50: 0, q75: 0, q95: 0, q99: 0 }
    };
  }

  // --- 2. DISTRIBUTION ANALYSIS (MLE + Goodness of Fit) ---
  fitDistribution(data: number[], distName: 'Normal' | 'Lognormal' | 'Exponential' | 'Weibull'): FittedDistribution {
    const clean = data.filter(x => x !== null && x !== undefined && !isNaN(x) && x > 0);
    const n = clean.length;
    if (n < 5) {
      return { name: distName, parameters: {}, aic: 0, bic: 0, ksStat: 1, ksCritical: 0.5, passGoF: false, fittedY: [] };
    }

    const sorted = [...clean].sort((a, b) => a - b);
    const sum = sorted.reduce((a, b) => a + b, 0);
    const mean = sum / n;

    let params: { [key: string]: number } = {};
    let logL = 0;
    let k = 1; // number of parameters

    // Empirical CDF
    const ecdf = sorted.map((_, i) => (i + 1) / n);

    if (distName === 'Normal') {
      k = 2;
      const sqDiffSum = sorted.reduce((acc, val) => acc + Math.pow(val - mean, 2), 0);
      const stdDev = Math.sqrt(sqDiffSum / n);
      params = { mean, stdDev };

      // Log-likelihood
      logL = - (n / 2) * Math.log(2 * Math.PI * stdDev * stdDev) - (sqDiffSum / (2 * stdDev * stdDev));
    }
    else if (distName === 'Lognormal') {
      k = 2;
      const lnVals = sorted.map(x => Math.log(x));
      const lnMean = lnVals.reduce((a, b) => a + b, 0) / n;
      const lnSqDiffSum = lnVals.reduce((acc, val) => acc + Math.pow(val - lnMean, 2), 0);
      const lnStdDev = Math.sqrt(lnSqDiffSum / n);
      params = { meanlog: lnMean, sdlog: lnStdDev };

      // Log-likelihood
      let sumLnX = lnVals.reduce((a, b) => a + b, 0);
      logL = - (n / 2) * Math.log(2 * Math.PI * lnStdDev * lnStdDev) - sumLnX - (lnSqDiffSum / (2 * lnStdDev * lnStdDev));
    }
    else if (distName === 'Exponential') {
      k = 1;
      const rate = 1 / mean;
      params = { rate };

      // Log-likelihood
      logL = n * Math.log(rate) - rate * sum;
    }
    else if (distName === 'Weibull') {
      k = 2;
      // Weibull parameter fitting using linear regression on Weibull ECDF plot
      // ln(-ln(1 - F(t))) = k * ln(t) - k * ln(lambda)
      const xReg: number[] = [];
      const yReg: number[] = [];
      for (let i = 0; i < n - 1; i++) {
        const F = (i + 1) / (n + 1); // adjusted ECDF to prevent ln(0) issues
        xReg.push(Math.log(sorted[i]));
        yReg.push(Math.log(-Math.log(1 - F)));
      }

      // Fit regression slope (shape k) and intercept
      const reg = this.calculateLinearRegression(xReg, yReg);
      const shape = Math.max(0.1, reg.slope);
      const scale = Math.exp(-reg.intercept / shape);
      params = { scale, shape };

      // Log-likelihood
      let lSum = 0;
      for (let i = 0; i < n; i++) {
        const x = sorted[i];
        lSum += Math.log(shape / scale) + (shape - 1) * Math.log(x / scale) - Math.pow(x / scale, shape);
      }
      logL = lSum;
    }

    const aic = 2 * k - 2 * logL;
    const bic = k * Math.log(n) - 2 * logL;

    // Calculate Kolmogorov-Smirnov goodness-of-fit statistic
    let ksStat = 0;
    const cdfNormal = (x: number, mu: number, sigma: number) => {
      // Numerical approximation of normal CDF
      const z = (x - mu) / sigma;
      const t = 1 / (1 + 0.2316419 * Math.abs(z));
      const d = 0.39894228 * Math.exp(-z * z / 2);
      const p = d * t * (0.31938153 + t * (-0.356563782 + t * (1.781477937 + t * (-1.821255978 + t * 1.330274429))));
      return z >= 0 ? 1 - p : p;
    };

    const fittedY: number[] = [];
    for (let i = 0; i < n; i++) {
      const x = sorted[i];
      let theoreticalCDF = 0;

      if (distName === 'Normal') {
        theoreticalCDF = cdfNormal(x, params['mean'], params['stdDev']);
      } else if (distName === 'Lognormal') {
        theoreticalCDF = cdfNormal(Math.log(x), params['meanlog'], params['sdlog']);
      } else if (distName === 'Exponential') {
        theoreticalCDF = 1 - Math.exp(-params['rate'] * x);
      } else if (distName === 'Weibull') {
        theoreticalCDF = 1 - Math.exp(-Math.pow(x / params['scale'], params['shape']));
      }

      fittedY.push(theoreticalCDF);
      const d1 = Math.abs(ecdf[i] - theoreticalCDF);
      const d2 = i > 0 ? Math.abs(ecdf[i - 1] - theoreticalCDF) : 0;
      ksStat = Math.max(ksStat, d1, d2);
    }

    // Critical value of KS test for alpha = 0.05
    const ksCritical = 1.36 / Math.sqrt(n);
    const passGoF = ksStat < ksCritical;

    // Standardize roundings for presentation
    const roundedParams: { [key: string]: number } = {};
    for (let key in params) {
      roundedParams[key] = this.roundTo(params[key], 4);
    }

    return {
      name: distName,
      parameters: roundedParams,
      aic: this.roundTo(aic, 2),
      bic: this.roundTo(bic, 2),
      ksStat: this.roundTo(ksStat, 4),
      ksCritical: this.roundTo(ksCritical, 4),
      passGoF,
      fittedY
    };
  }

  // --- 3. REGRESSION ENGINE (Linear, Polynomial, Hierarchical) ---
  calculateLinearRegression(x: number[], y: number[]): RegressionResult {
    const n = x.length;
    if (n < 2) {
      return { slope: 0, intercept: 0, r2: 0, adjR2: 0, rse: 0, fStatistic: 0, pValueSlope: 1, residuals: [], fittedValues: [] };
    }

    const sumX = x.reduce((a, b) => a + b, 0);
    const sumY = y.reduce((a, b) => a + b, 0);
    const meanX = sumX / n;
    const meanY = sumY / n;

    let num = 0;
    let den = 0;
    for (let i = 0; i < n; i++) {
      num += (x[i] - meanX) * (y[i] - meanY);
      den += Math.pow(x[i] - meanX, 2);
    }

    const slope = den !== 0 ? num / den : 0;
    const intercept = meanY - slope * meanX;

    const fittedValues = x.map(val => slope * val + intercept);
    const residuals = y.map((val, i) => val - fittedValues[i]);

    // Variance calculations
    const sst = y.reduce((acc, val) => acc + Math.pow(val - meanY, 2), 0);
    const sse = residuals.reduce((acc, val) => acc + Math.pow(val, 2), 0);
    const ssr = sst - sse;

    const r2 = sst !== 0 ? 1 - (sse / sst) : 0;
    const adjR2 = n > 2 ? 1 - ((sse / (n - 2)) / (sst / (n - 1))) : r2;
    const rse = n > 2 ? Math.sqrt(sse / (n - 2)) : 0;

    // F-statistic for regression significance
    const fStatistic = sse > 0 && n > 2 ? (ssr / 1) / (sse / (n - 2)) : 0;

    // p-value estimation for the slope
    const seSlope = rse > 0 && den > 0 ? rse / Math.sqrt(den) : 0.0001;
    const tStat = seSlope > 0 ? slope / seSlope : 0;
    // Approximated two-sided Student-T p-value
    const pValueSlope = this.approximateTPValue(tStat, n - 2);

    return {
      slope: this.roundTo(slope, 5),
      intercept: this.roundTo(intercept, 5),
      r2: this.roundTo(r2, 4),
      adjR2: this.roundTo(adjR2, 4),
      rse: this.roundTo(rse, 4),
      fStatistic: this.roundTo(fStatistic, 2),
      pValueSlope: this.roundTo(pValueSlope, 6),
      residuals: residuals.map(r => this.roundTo(r, 4)),
      fittedValues: fittedValues.map(f => this.roundTo(f, 4))
    };
  }

  calculatePolynomialRegression(x: number[], y: number[]): PolynomialResult {
    const n = x.length;
    if (n < 3) {
      return { coefficients: [0, 0, 0], r2: 0, fittedValues: [], residuals: [] };
    }

    // Solve Normal Equations: A^T A * beta = A^T Y
    // Matrix equation for quadratic: b0 + b1 * x + b2 * x^2
    let s0 = n;
    let s1 = x.reduce((a, b) => a + b, 0);
    let s2 = x.reduce((a, b) => a + b + b * b, 0) - s1; // sum x^2
    let s3 = 0, s4 = 0;
    let sy = y.reduce((a, b) => a + b, 0);
    let sxy = 0, sx2y = 0;

    for (let i = 0; i < n; i++) {
      const valX = x[i];
      const valY = y[i];
      const x2 = valX * valX;
      s2 += x2; // recount for exactness
      s3 += x2 * valX;
      s4 += x2 * x2;
      sxy += valX * valY;
      sx2y += x2 * valY;
    }
    // Correct duplicate recount error
    s2 = x.reduce((a, b) => a + b * b, 0);

    // Solve 3x3 system using Cramer's rule
    const det = (s0 * s2 * s4 + s1 * s3 * s2 + s2 * s1 * s3) - (s2 * s2 * s2 + s0 * s3 * s3 + s1 * s1 * s4);
    if (Math.abs(det) < 1e-8) {
      return { coefficients: [0, 0, 0], r2: 0, fittedValues: [], residuals: [] };
    }

    const det0 = (sy * s2 * s4 + s1 * s3 * sx2y + s2 * sxy * s3) - (s2 * s2 * sx2y + sy * s3 * s3 + s1 * sxy * s4);
    const det1 = (s0 * sxy * s4 + sy * s3 * s2 + s2 * s1 * sx2y) - (s2 * sxy * s2 + s0 * s3 * sx2y + sy * s1 * s4);
    const det2 = (s0 * s2 * sx2y + s1 * sxy * s2 + sy * s1 * s3) - (sy * s2 * s2 + s0 * sxy * s3 + s1 * s1 * sx2y);

    const b0 = det0 / det;
    const b1 = det1 / det;
    const b2 = det2 / det;

    const fittedValues = x.map(val => b0 + b1 * val + b2 * val * val);
    const residuals = y.map((val, i) => val - fittedValues[i]);

    const meanY = sy / n;
    const sst = y.reduce((acc, val) => acc + Math.pow(val - meanY, 2), 0);
    const sse = residuals.reduce((acc, val) => acc + Math.pow(val, 2), 0);
    const r2 = sst > 0 ? 1 - (sse / sst) : 0;

    return {
      coefficients: [this.roundTo(b0, 5), this.roundTo(b1, 5), this.roundTo(b2, 5)],
      r2: this.roundTo(r2, 4),
      fittedValues: fittedValues.map(f => this.roundTo(f, 4)),
      residuals: residuals.map(r => this.roundTo(r, 4))
    };
  }

  // Hierarchical Random-Intercept Mixed Model approximation
  calculateMixedEffects(x: number[], y: number[], groups: string[]): MixedEffectsResult {
    const n = x.length;
    // 1. First run a global OLS linear regression (Fixed Effects)
    const globalReg = this.calculateLinearRegression(x, y);
    const beta0 = globalReg.intercept;
    const beta1 = globalReg.slope;

    // 2. Map residuals grouped by group identifiers
    const groupResiduals = new Map<string, number[]>();
    for (let i = 0; i < n; i++) {
      const g = groups[i];
      const res = y[i] - (beta0 + beta1 * x[i]);
      const list = groupResiduals.get(g) || [];
      list.push(res);
      groupResiduals.set(g, list);
    }

    // 3. Estimate Random Intercept offset (u_i) as the average residual in group i
    const randomEffects: { [groupId: string]: number } = {};
    const uOffsets: number[] = [];
    groupResiduals.forEach((resList, gId) => {
      const avgOffset = resList.reduce((a, b) => a + b, 0) / resList.length;
      randomEffects[gId] = this.roundTo(avgOffset, 4);
      uOffsets.push(avgOffset);
    });

    // 4. Calculate Fitted values with group intercepts
    const fittedValues: number[] = [];
    const residuals: number[] = [];
    for (let i = 0; i < n; i++) {
      const g = groups[i];
      const offset = randomEffects[g] || 0;
      const fitVal = beta0 + beta1 * x[i] + offset;
      fittedValues.push(fitVal);
      residuals.push(y[i] - fitVal);
    }

    // 5. Calculate Variance Components
    // Var of random intercepts (Between Group Variance)
    const uMean = uOffsets.reduce((a, b) => a + b, 0) / uOffsets.length;
    const randomEffectVar = uOffsets.length > 1 ?
      uOffsets.reduce((acc, u) => acc + Math.pow(u - uMean, 2), 0) / (uOffsets.length - 1) : 0;

    // Var of final residuals (Within Group Variance)
    const residualVar = n > groupResiduals.size ?
      residuals.reduce((acc, r) => acc + Math.pow(r, 2), 0) / (n - groupResiduals.size) : 0.001;

    // ICC (Intraclass Correlation Coefficient): share of variance explained by groups
    const icc = (randomEffectVar + residualVar) > 0 ? randomEffectVar / (randomEffectVar + residualVar) : 0;

    return {
      fixedEffects: { intercept: this.roundTo(beta0, 4), slope: this.roundTo(beta1, 4) },
      randomEffects,
      varianceComponents: {
        randomEffectVar: this.roundTo(randomEffectVar, 4),
        residualVar: this.roundTo(residualVar, 4),
        icc: this.roundTo(icc, 4)
      },
      fittedValues: fittedValues.map(f => this.roundTo(f, 4)),
      residuals: residuals.map(r => this.roundTo(r, 4))
    };
  }

  // --- 4. HYPOTHESIS TESTING (Welch t-test & ANOVA) ---
  performWelchTTest(groupA: number[], groupB: number[]): HypothesisTestResult {
    const cleanA = groupA.filter(x => x !== null && !isNaN(x));
    const cleanB = groupB.filter(x => x !== null && !isNaN(x));

    const n1 = cleanA.length;
    const n2 = cleanB.length;

    if (n1 < 2 || n2 < 2) {
      return { testName: "Welch's Two-Sample t-Test", statistic: 0, df: 1, pValue: 1, significant: false, groupAMean: 0, groupBMean: 0 };
    }

    const mean1 = cleanA.reduce((a, b) => a + b, 0) / n1;
    const mean2 = cleanB.reduce((a, b) => a + b, 0) / n2;

    const var1 = cleanA.reduce((acc, val) => acc + Math.pow(val - mean1, 2), 0) / (n1 - 1);
    const var2 = cleanB.reduce((acc, val) => acc + Math.pow(val - mean2, 2), 0) / (n2 - 1);

    // t-statistic
    const tStat = (mean1 - mean2) / Math.sqrt((var1 / n1) + (var2 / n2));

    // Welch-Satterthwaite degrees of freedom
    const num = Math.pow((var1 / n1) + (var2 / n2), 2);
    const den = (Math.pow(var1 / n1, 2) / (n1 - 1)) + (Math.pow(var2 / n2, 2) / (n2 - 1));
    const df = den > 0 ? num / den : 1;

    const pValue = this.approximateTPValue(tStat, df);

    return {
      testName: "Welch's Two-Sample t-Test (Unequal Variances)",
      statistic: this.roundTo(tStat, 4),
      df: this.roundTo(df, 2),
      pValue: this.roundTo(pValue, 6),
      significant: pValue < 0.05,
      groupAMean: this.roundTo(mean1, 4),
      groupBMean: this.roundTo(mean2, 4)
    };
  }

  performANOVA(groupsData: { [groupName: string]: number[] }): HypothesisTestResult {
    let totalN = 0;
    let grandSum = 0;
    const k = Object.keys(groupsData).length;

    const groupSummary: { name: string; mean: number; n: number; sum: number }[] = [];

    for (let key in groupsData) {
      const vals = groupsData[key].filter(x => x !== null && !isNaN(x));
      if (vals.length === 0) continue;
      const gSum = vals.reduce((a, b) => a + b, 0);
      const gN = vals.length;
      const gMean = gSum / gN;

      totalN += gN;
      grandSum += gSum;

      groupSummary.push({ name: key, mean: gMean, n: gN, sum: gSum });
    }

    if (totalN <= k || k < 2) {
      return { testName: 'One-Way ANOVA', statistic: 0, df: 1, pValue: 1, significant: false, groupAMean: 0, groupBMean: 0 };
    }

    const grandMean = grandSum / totalN;

    // Sum of Squares Between (SSB)
    let ssb = 0;
    groupSummary.forEach(g => {
      ssb += g.n * Math.pow(g.mean - grandMean, 2);
    });

    // Sum of Squares Within (SSW)
    let ssw = 0;
    for (let key in groupsData) {
      const vals = groupsData[key].filter(x => x !== null && !isNaN(x));
      const gSummary = groupSummary.find(g => g.name === key);
      if (!gSummary) continue;
      vals.forEach(val => {
        ssw += Math.pow(val - gSummary.mean, 2);
      });
    }

    const dfBetween = k - 1;
    const dfWithin = totalN - k;

    const msb = ssb / dfBetween;
    const msw = ssw / dfWithin;

    const fStat = msw > 0 ? msb / msw : 0;

    // F-distribution p-value estimation
    // Simple robust estimation of F p-value using approximation
    const pValue = this.approximateFPValue(fStat, dfBetween, dfWithin);

    return {
      testName: 'One-Way ANOVA',
      statistic: this.roundTo(fStat, 4),
      df: dfBetween, // numerator df
      pValue: this.roundTo(pValue, 6),
      significant: pValue < 0.05,
      groupAMean: this.roundTo(grandMean, 4), // displays grand mean as proxy
      groupBMean: this.roundTo(msw, 4) // residual MSW as proxy
    };
  }

  // --- 5. SURVIVAL & RELIABILITY (Kaplan-Meier & Weibull Survival) ---
  calculateKaplanMeier(times: number[], events: boolean[]): KaplanMergeResult {
    const n = times.length;
    if (n === 0) return [];

    // Bundle times and status, then sort ascending by time
    const records = times.map((t, idx) => ({ t, event: events[idx] }))
      .sort((a, b) => a.t - b.t);

    const kmPoints: KaplanMeierPoint[] = [];
    let nAtRisk = n;
    let survival = 1.0;
    let sumVar = 0.0; // For Greenwood's variance

    // Group by unique event times
    let i = 0;
    while (i < n) {
      const currentT = records[i].t;
      let dEvents = 0;
      let cCensored = 0;

      // Count events and censorings at this instant
      while (i < n && records[i].t === currentT) {
        if (records[i].event) {
          dEvents++;
        } else {
          cCensored++;
        }
        i++;
      }

      if (dEvents > 0) {
        survival *= (1 - dEvents / nAtRisk);
        sumVar += dEvents / (nAtRisk * (nAtRisk - dEvents));
      }

      // Greenwood Confidence Intervals
      const stdErr = survival * Math.sqrt(sumVar);
      // Log-log transformation for bounds to keep them strictly between [0, 1]
      const lnSurvival = Math.log(survival === 0 ? 0.00001 : survival);
      const theta = Math.exp(1.96 * stdErr / (survival * lnSurvival));
      const ciLower = Math.pow(survival, theta);
      const ciUpper = Math.pow(survival, 1 / theta);

      kmPoints.push({
        time: currentT,
        nAtRisk,
        nEvents: dEvents,
        survival: this.roundTo(survival, 4),
        ciLower: this.roundTo(isNaN(ciLower) ? 0 : ciLower, 4),
        ciUpper: this.roundTo(isNaN(ciUpper) ? 1 : ciUpper, 4)
      });

      nAtRisk -= (dEvents + cCensored);
    }

    return kmPoints;
  }

  // Parametric Weibull survival fitting and hazard prediction
  calculateWeibullSurvival(times: number[], events: boolean[]): WeibullSurvivalResult {
    // Only fit on failed events for simplicity
    const failures = times.filter((_, idx) => events[idx]).sort((a, b) => a - b);
    const n = failures.length;

    if (n < 3) {
      return { scale: 100, shape: 1, timePoints: [0, 50, 100], survivalCurve: [1, 0.5, 0.1], hazardCurve: [0.01, 0.01, 0.01] };
    }

    // Standard Weibull probability plot fitting
    const xReg: number[] = [];
    const yReg: number[] = [];
    for (let i = 0; i < n; i++) {
      const F = (i + 1) / (n + 1);
      xReg.push(Math.log(failures[i]));
      yReg.push(Math.log(-Math.log(1 - F)));
    }

    const reg = this.calculateLinearRegression(xReg, yReg);
    const shape = Math.max(0.1, reg.slope);
    const scale = Math.exp(-reg.intercept / shape);

    // Predict curves over 50 intervals up to max time
    const maxT = Math.max(...times) * 1.2;
    const timePoints: number[] = [];
    const survivalCurve: number[] = [];
    const hazardCurve: number[] = [];

    for (let step = 0; step <= 50; step++) {
      const t = Math.max(0.1, (step / 50) * maxT);
      timePoints.push(this.roundTo(t, 2));

      // S(t) = exp(-(t/lambda)^k)
      const sur = Math.exp(-Math.pow(t / scale, shape));
      survivalCurve.push(this.roundTo(sur, 4));

      // h(t) = (k/lambda) * (t/lambda)^(k-1)
      const haz = (shape / scale) * Math.pow(t / scale, shape - 1);
      hazardCurve.push(this.roundTo(haz, 6));
    }

    return {
      scale: this.roundTo(scale, 4),
      shape: this.roundTo(shape, 4),
      timePoints,
      survivalCurve,
      hazardCurve
    };
  }

  // --- 6. ANOMALY DETECTION ENGINE ---
  detectAnomalies(times: number[], values: number[], method: 'ZScore' | 'EWMA' | 'CUSUM'): AnomalyRecord[] {
    const anomalies: AnomalyRecord[] = [];
    const n = values.length;
    if (n < 5) return [];

    // Calculate baseline mean and std dev
    const stats = this.calculateSummary(values);
    const mean = stats.mean;
    const stdDev = stats.stdDev;
    const median = stats.median;
    const mad = stats.mad;

    if (method === 'ZScore') {
      const threshold = 3.0; // 3 sigma
      for (let i = 0; i < n; i++) {
        // Robust z-score
        const z = mad > 0 ? 0.6745 * Math.abs(values[i] - median) / mad : Math.abs(values[i] - mean) / stdDev;
        if (z > threshold) {
          const res = values[i] - (mad > 0 ? median : mean);
          anomalies.push({
            index: i,
            timestamp: times[i],
            value: values[i],
            expected: mad > 0 ? median : mean,
            residual: this.roundTo(res, 3),
            threshold,
            severity: z > 4.5 ? 'Critical' : z > 3.5 ? 'Moderate' : 'Minor',
            method: 'Robust Z-Score'
          });
        }
      }
    }
    else if (method === 'EWMA') {
      const alpha = 0.2; // smoothing parameter
      const L = 3.0; // control limit coefficient
      let s = values[0]; // initial EWMA

      for (let i = 0; i < n; i++) {
        s = alpha * values[i] + (1 - alpha) * s;
        // Limit standard deviation of EWMA
        const ewmaStdDev = stdDev * Math.sqrt(alpha / (2 - alpha));
        const residual = values[i] - s;

        if (Math.abs(residual) > L * ewmaStdDev && i > 2) {
          anomalies.push({
            index: i,
            timestamp: times[i],
            value: values[i],
            expected: this.roundTo(s, 3),
            residual: this.roundTo(residual, 3),
            threshold: this.roundTo(L * ewmaStdDev, 3),
            severity: Math.abs(residual) > 4.5 * ewmaStdDev ? 'Critical' : Math.abs(residual) > 3.5 * ewmaStdDev ? 'Moderate' : 'Minor',
            method: 'EWMA Control Chart'
          });
        }
      }
    }
    else if (method === 'CUSUM') {
      // Cumulative sum parameters
      const k = 0.5; // slack parameter (0.5 sigma)
      const h = 4.0; // threshold parameter (4 sigma)
      let sHigh = 0;
      let sLow = 0;

      for (let i = 0; i < n; i++) {
        const z = stdDev > 0 ? (values[i] - mean) / stdDev : 0;
        sHigh = Math.max(0, sHigh + z - k);
        sLow = Math.max(0, sLow - z - k);

        if (sHigh > h || sLow > h) {
          const expected = sHigh > h ? mean + h * stdDev : mean - h * stdDev;
          anomalies.push({
            index: i,
            timestamp: times[i],
            value: values[i],
            expected: this.roundTo(expected, 3),
            residual: this.roundTo(values[i] - expected, 3),
            threshold: this.roundTo(h * stdDev, 3),
            severity: Math.max(sHigh, sLow) > h * 1.5 ? 'Critical' : 'Moderate',
            method: 'CUSUM Standard'
          });
        }
      }
    }

    return anomalies;
  }

  // --- 7. MANUFACTURING SPC (Capability & Gage R&R) ---
  calculateSPC(data: number[], subgroupSize: number = 5, usl: number, lsl: number): SPCChartResult {
    const subgroupMeans: number[] = [];
    const subgroupRanges: number[] = [];

    // Chunk into subgroups
    for (let i = 0; i < data.length; i += subgroupSize) {
      const chunk = data.slice(i, i + subgroupSize).filter(x => x !== null && !isNaN(x));
      if (chunk.length === 0) continue;

      const sum = chunk.reduce((a, b) => a + b, 0);
      const mean = sum / chunk.length;
      const min = Math.min(...chunk);
      const max = Math.max(...chunk);
      const range = max - min;

      subgroupMeans.push(mean);
      subgroupRanges.push(range);
    }

    const nGroups = subgroupMeans.length;
    const grandMean = subgroupMeans.reduce((a, b) => a + b, 0) / nGroups;
    const meanRange = subgroupRanges.reduce((a, b) => a + b, 0) / nGroups;

    // Standard control constants for subgroups
    // For n = 5: A2 = 0.577, D3 = 0, D4 = 2.114
    const a2 = subgroupSize === 5 ? 0.577 : subgroupSize === 3 ? 1.023 : 0.729; // approximate constants
    const d3 = 0;
    const d4 = subgroupSize === 5 ? 2.114 : subgroupSize === 3 ? 2.574 : 2.282;

    const uclMean = grandMean + a2 * meanRange;
    const lclMean = grandMean - a2 * meanRange;

    const uclRange = d4 * meanRange;
    const lclRange = d3 * meanRange;

    // Process sigma estimation from R-bar: sigma = R-bar / d2
    const d2 = subgroupSize === 5 ? 2.326 : subgroupSize === 3 ? 1.693 : 2.059;
    const processSigma = meanRange / d2;

    // Cp and Cpk capability indices
    const cp = (usl - lsl) / (6 * processSigma);
    const cpk = Math.min((usl - grandMean) / (3 * processSigma), (grandMean - lsl) / (3 * processSigma));

    // Overall process standard deviation (for Pp, Ppk)
    const overallStats = this.calculateSummary(data);
    const overallSigma = overallStats.stdDev;
    const pp = (usl - lsl) / (6 * overallSigma);
    const ppk = Math.min((usl - grandMean) / (3 * overallSigma), (grandMean - lsl) / (3 * overallSigma));

    // Out of control indexes in subgroups
    const outOfControlIndexes: number[] = [];
    subgroupMeans.forEach((m, idx) => {
      if (m > uclMean || m < lclMean) {
        outOfControlIndexes.push(idx);
      }
    });

    return {
      subgroupMeans: subgroupMeans.map(m => this.roundTo(m, 4)),
      subgroupRanges: subgroupRanges.map(r => this.roundTo(r, 4)),
      grandMean: this.roundTo(grandMean, 4),
      meanRange: this.roundTo(meanRange, 4),
      uclMean: this.roundTo(uclMean, 4),
      lclMean: this.roundTo(lclMean, 4),
      uclRange: this.roundTo(uclRange, 4),
      lclRange: this.roundTo(lclRange, 4),
      cp: this.roundTo(cp, 4),
      cpk: this.roundTo(cpk, 4),
      pp: this.roundTo(pp, 4),
      ppk: this.roundTo(ppk, 4),
      outOfControlIndexes
    };
  }

  // --- 8. MONTE CARLO UNCERTAINTY PROPAGATION ENGINE ---
  runMonteCarlo(
    thrustSpec: { mean: number; sd: number },
    propellantSpec: { mean: number; sd: number },
    dryMassSpec: { mean: number; sd: number },
    dragSpec: { min: number; max: number },
    samples: number = 10000
  ): MonteCarloSummary {
    // Simple inline LCG randomizer to avoid circular imports
    let seedState = 19721207; // Apollo 17 launch date seed
    const nextRand = () => {
      seedState = (1103515245 * seedState + 12345) % 0x80000000;
      return seedState / (0x80000000 - 1);
    };
    const nextNormalRand = (mean: number, stdDev: number) => {
      const u1 = nextRand() || 0.0001;
      const u2 = nextRand();
      const randStdNormal = Math.sqrt(-2.0 * Math.log(u1)) * Math.cos(2.0 * Math.PI * u2);
      return mean + stdDev * randStdNormal;
    };

    const outputs: number[] = [];

    const inputs = {
      thrust: [] as number[],
      propellant: [] as number[],
      dryMass: [] as number[],
      dragCoeff: [] as number[]
    };

    const isp = 330; // nominal Raptor Isp
    const g = 9.80665;

    for (let i = 0; i < samples; i++) {
      const thrust = nextNormalRand(thrustSpec.mean, thrustSpec.sd);
      const propellant = nextNormalRand(propellantSpec.mean, propellantSpec.sd);
      const dryMass = nextNormalRand(dryMassSpec.mean, dryMassSpec.sd);
      // Uniform distribution for aerodynamic drag
      const drag = dragSpec.min + (dragSpec.max - dragSpec.min) * nextRand();

      inputs.thrust.push(thrust);
      inputs.propellant.push(propellant);
      inputs.dryMass.push(dryMass);
      inputs.dragCoeff.push(drag);

      // Burnout velocity via Tsiolkovsky rocket equation with dynamic losses
      const massRatio = (dryMass + propellant) / dryMass;
      const idealDeltaV = isp * g * Math.log(massRatio);

      // Model gravity and drag losses:
      // higher drag coefficient reduces burnout velocity, higher thrust reduces gravity losses
      const gravityLoss = 9.81 * 140 * (1 - (thrust / 120000)); // lighter acceleration spends more time in gravity well
      const dragLoss = 1500 * drag * (thrust / 80000); // high speed drag losses

      const burnoutV = idealDeltaV - Math.max(100, gravityLoss) - Math.max(50, dragLoss);
      outputs.push(burnoutV);
    }

    // Sort outputs for percentile evaluation
    const sortedOut = [...outputs].sort((a, b) => a - b);
    const sumOut = sortedOut.reduce((a, b) => a + b, 0);
    const mean = sumOut / samples;

    const sqDiffSum = sortedOut.reduce((acc, val) => acc + Math.pow(val - mean, 2), 0);
    const stdDev = Math.sqrt(sqDiffSum / (samples - 1));

    // Sensitivities: Pearson correlation coefficients between inputs and output
    const calcPearson = (inp: number[]) => {
      const meanInp = inp.reduce((a, b) => a + b, 0) / samples;
      let num = 0;
      let denX = 0;
      let denY = 0;
      for (let i = 0; i < samples; i++) {
        const dx = inp[i] - meanInp;
        const dy = outputs[i] - mean;
        num += dx * dy;
        denX += dx * dx;
        denY += dy * dy;
      }
      return denX > 0 && denY > 0 ? num / Math.sqrt(denX * denY) : 0;
    };

    return {
      inputs,
      outputs: sortedOut.filter((_, idx) => idx % 50 === 0), // downsampled to 200 points for charts
      mean: this.roundTo(mean, 2),
      median: this.roundTo(sortedOut[Math.floor(samples * 0.5)], 2),
      stdDev: this.roundTo(stdDev, 2),
      p05: this.roundTo(sortedOut[Math.floor(samples * 0.05)], 2),
      p50: this.roundTo(sortedOut[Math.floor(samples * 0.50)], 2),
      p95: this.roundTo(sortedOut[Math.floor(samples * 0.95)], 2),
      p99: this.roundTo(sortedOut[Math.floor(samples * 0.99)], 2),
      sensitivities: {
        'Engine Thrust': this.roundTo(calcPearson(inputs.thrust), 4),
        'Propellant Loaded': this.roundTo(calcPearson(inputs.propellant), 4),
        'Vehicle Dry Mass': this.roundTo(calcPearson(inputs.dryMass), 4),
        'Drag Coefficient': this.roundTo(calcPearson(inputs.dragCoeff), 4)
      }
    };
  }

  // --- 9. BAYESIAN RELIABILITY POSTERIOR UPDATES ---
  calculateBayesianBetaBinomial(
    alphaPrior: number,
    betaPrior: number,
    nTrials: number,
    nSuccesses: number
  ) {
    const alphaPost = alphaPrior + nSuccesses;
    const betaPost = betaPrior + (nTrials - nSuccesses);

    // Generate probability densities for Prior and Posterior [0, 1]
    const steps = 100;
    const pPoints: number[] = [];
    const priorPDF: number[] = [];
    const posteriorPDF: number[] = [];

    // Gamma / Beta function standard log-approximation
    const lnGamma = (z: number): number => {
      // Lanczos approximation
      const p = [
        676.5203681218851, -1259.1392167224028, 771.32342877765313,
        -176.61502916214059, 12.507343278686905, -0.13857109526572012,
        9.9843695780195716e-6, 1.5056327351493116e-7
      ];
      if (z < 0.5) return Math.log(Math.PI / Math.sin(Math.PI * z)) - lnGamma(1 - z);
      z -= 1;
      let x = 0.99999999999980993;
      for (let i = 0; i < p.length; i++) {
        x += p[i] / (z + i + 1);
      }
      const t = z + p.length - 0.5;
      return 0.5 * Math.log(2 * Math.PI) + (z + 0.5) * Math.log(t) - t + Math.log(x);
    };

    const betaFuncLog = (a: number, b: number) => lnGamma(a) + lnGamma(b) - lnGamma(a + b);

    for (let step = 0; step <= steps; step++) {
      const p = step / steps;
      pPoints.push(this.roundTo(p, 2));

      // Beta density: f(p; a, b) = p^(a-1) * (1-p)^(b-1) / Beta(a, b)
      let priorDens = 0;
      let postDens = 0;

      if (p > 0 && p < 1) {
        priorDens = Math.exp((alphaPrior - 1) * Math.log(p) + (betaPrior - 1) * Math.log(1 - p) - betaFuncLog(alphaPrior, betaPrior));
        postDens = Math.exp((alphaPost - 1) * Math.log(p) + (betaPost - 1) * Math.log(1 - p) - betaFuncLog(alphaPost, betaPost));
      }

      priorPDF.push(this.roundTo(isNaN(priorDens) ? 0 : priorDens, 4));
      posteriorPDF.push(this.roundTo(isNaN(postDens) ? 0 : postDens, 4));
    }

    return {
      alphaPost,
      betaPost,
      pPoints,
      priorPDF,
      posteriorPDF,
      priorMean: this.roundTo(alphaPrior / (alphaPrior + betaPrior), 4),
      posteriorMean: this.roundTo(alphaPost / (alphaPost + betaPost), 4),
      credibleInterval: {
        lower: this.roundTo(this.approxBetaQuantile(0.025, alphaPost, betaPost), 4),
        upper: this.roundTo(this.approxBetaQuantile(0.975, alphaPost, betaPost), 4)
      }
    };
  }

  // --- HELPERS & NUMERICAL APPROXIMATIONS ---
  private roundTo(val: number, decimals: number): number {
    if (isNaN(val) || !isFinite(val)) return 0;
    const factor = Math.pow(10, decimals);
    return Math.round(val * factor) / factor;
  }

  // Approximate Student's T distribution cumulative probabilities (two-tailed p-value)
  private approximateTPValue(t: number, df: number): number {
    const x = Math.abs(t);
    // Standard normal approximation for large df
    if (df > 50) {
      const z = x * (1 - 1 / (4 * df));
      // Standard normal cumulative distribution approximation
      const c = 1 / (1 + 0.2316419 * z);
      const d = 0.39894228 * Math.exp(-z * z / 2);
      const p = d * c * (0.31938153 + c * (-0.356563782 + c * (1.781477937 + c * (-1.821255978 + c * 1.330274429))));
      return 2 * p;
    }
    // Simple robust t approximation
    const v = df;
    const num = Math.pow(x, 2) / v;
    const p = Math.max(0, 1 - 0.5 * (1 + Math.pow(1 + num, -0.5 * (v + 1))));
    return 2 * (1 - p);
  }

  // Incomplete beta function approximation to find Beta quantiles
  private approxBetaQuantile(q: number, alpha: number, beta: number): number {
    // Binary search for quantile
    let low = 0;
    let high = 1;
    let guess = 0.5;

    // Numerical beta CDF approximation
    const betaCDF = (x: number, a: number, b: number): number => {
      // Incomplete beta approximation using simple sum
      let sum = 0;
      const nSteps = 150;
      const dx = x / nSteps;
      const lnGamma = (z: number): number => {
        const p = [676.5203681218851, -1259.1392167224028, 771.32342877765313, -176.61502916214059, 12.507343278686905, -0.13857109526572012, 9.9843695780195716e-6, 1.5056327351493116e-7];
        if (z < 0.5) return Math.log(Math.PI / Math.sin(Math.PI * z)) - lnGamma(1 - z);
        z -= 1;
        let val = 0.99999999999980993;
        for (let i = 0; i < p.length; i++) val += p[i] / (z + i + 1);
        const t = z + p.length - 0.5;
        return 0.5 * Math.log(2 * Math.PI) + (z + 0.5) * Math.log(t) - t + Math.log(val);
      };
      const lnBeta = lnGamma(a) + lnGamma(b) - lnGamma(a + b);

      for (let i = 0; i < nSteps; i++) {
        const xi = (i + 0.5) * dx;
        sum += Math.exp((a - 1) * Math.log(xi) + (b - 1) * Math.log(1 - xi) - lnBeta) * dx;
      }
      return Math.min(1, Math.max(0, sum));
    };

    for (let iter = 0; iter < 20; iter++) {
      guess = (low + high) / 2;
      const p = betaCDF(guess, alpha, beta);
      if (p < q) {
        low = guess;
      } else {
        high = guess;
      }
    }
    return guess;
  }

  // F-distribution p-value approximation
  private approximateFPValue(f: number, df1: number, df2: number): number {
    if (f <= 0) return 1.0;
    // Approximating using normal transformation (Paulson's approximation)
    const x = Math.pow(2 / (9 * df1), 0.5);
    const y = Math.pow(2 / (9 * df2), 0.5);
    const u = 1 - 2 / (9 * df1);
    const v = 1 - 2 / (9 * df2);
    const num = v * Math.pow(f, 1/3) - u;
    const den = Math.pow(y * Math.pow(f, 2/3) + x, 0.5);
    const z = num / den;

    // Normal standard CDF
    const t = 1 / (1 + 0.2316419 * Math.abs(z));
    const d = 0.39894228 * Math.exp(-z * z / 2);
    const p = d * t * (0.31938153 + t * (-0.356563782 + t * (1.781477937 + t * (-1.821255978 + t * 1.330274429))));
    return z >= 0 ? p : 1 - p;
  }
}

export type KaplanMergeResult = KaplanMeierPoint[];
