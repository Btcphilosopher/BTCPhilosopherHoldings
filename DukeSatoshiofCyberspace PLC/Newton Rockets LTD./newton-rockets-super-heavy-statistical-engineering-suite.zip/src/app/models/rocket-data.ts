export interface VehicleRecord {
  vehicle_id: string; // e.g. "S20", "S24", "B7", "B9"
  vehicle_version: 'V1_Block1' | 'V2_Block2' | 'V3_Starship';
  flight_id: string;
  mission_id: string;
  launch_date: string;
  launch_site: 'Starbase_PadA' | 'KSC_LC39A' | 'Vandenberg_SLC4E';
  test_or_operational: 'Test' | 'Operational';
  mission_type: 'Cargo' | 'Crew' | 'Satellite' | 'Propellant_Transfer';
  payload_mass: number; // kg
  vehicle_mass: number; // kg
  propellant_mass: number; // kg
  weather_conditions: 'Clear' | 'Overcast' | 'High_Winds' | 'Light_Rain';
  temperature: number; // °C
  pressure: number; // hPa
  wind_speed: number; // m/s
  wind_direction: number; // degrees
}

export interface EngineRecord {
  engine_id: string; // e.g. "R104", "R128"
  engine_type: 'Raptor_Center' | 'Raptor_Boost';
  engine_position: 'Center' | 'Inner_Ring' | 'Outer_Ring';
  engine_version: 'R1' | 'R2' | 'R3';
  manufacturing_batch: 'Batch_Alpha' | 'Batch_Beta' | 'Batch_Gamma' | 'Batch_Delta';
  installation_date: string;
  flight_count: number;
  test_count: number;
  engine_runtime: number; // seconds
  fuel_flow: number; // kg/s
  oxidizer_flow: number; // kg/s
  chamber_pressure: number; // bar
  turbopump_speed: number; // rpm
  temperature: number; // °C
  thrust: number; // kN
  specific_impulse: number; // seconds
  vibration: number; // g-rms
  flight_id: string;
  vehicle_id: string;
}

export interface TelemetryRecord {
  timestamp: number; // seconds from liftoff (T+0)
  flight_id: string;
  vehicle_id: string;
  altitude: number; // meters
  velocity: number; // m/s
  acceleration: number; // m/s^2
  dynamic_pressure: number; // kPa
  mach: number;
  attitude: {
    pitch: number;
    yaw: number;
    roll: number;
  };
  angular_velocity: number; // deg/s
  propellant_level: number; // percentage
  propellant_pressure: number; // bar
  engine_status: 'PreLaunch' | 'Startup' | 'Thrusting' | 'Throttled' | 'Shutdown' | 'Anomaly';
  thrust: number; // total booster thrust, kN
  temperature: number; // average bulkhead temp, °C
  vibration: number; // g-rms
  guidance_error: number; // meters from nominal trajectory
  phase: FlightPhase;
}

export type FlightPhase =
  | 'PreLaunch'
  | 'Startup'
  | 'Liftoff'
  | 'Ascent'
  | 'MaxQ'
  | 'EngineThrottling'
  | 'StageSeparation'
  | 'SecondStageIgnition'
  | 'Coast'
  | 'Entry'
  | 'LandingBurn'
  | 'Touchdown'
  | 'PostFlight';

export interface LandingRecord {
  landing_id: string;
  vehicle_id: string;
  flight_id: string;
  landing_type: 'Catch' | 'Sea_Recovery' | 'Pad_Landing';
  landing_error: number; // radial distance from target, meters
  touchdown_velocity: number; // m/s (vertical)
  touchdown_angle: number; // degrees deviation from vertical
  fuel_remaining: number; // kg
  landing_burn_duration: number; // seconds
  landing_site: 'Mechazilla_Tower' | 'Droneship_OCISLY' | 'Droneship_ASOG' | 'LZ_1';
  success: boolean;
}

export interface TurnaroundRecord {
  vehicle_id: string;
  previous_flight: string;
  next_flight: string;
  flight_sequence_number: number;
  inspection_duration: number; // days
  refurbishment_duration: number; // days
  transport_duration: number; // days
  integration_duration: number; // days
  launch_processing_duration: number; // days
  total_turnaround_time: number; // days (sum of above)
}

export interface AnomalyRecord {
  event_id: string;
  flight_id: string;
  vehicle_id: string;
  timestamp: number; // seconds from liftoff
  component: 'Turbopump_Seal' | 'Main_Oxidizer_Valve' | 'Chamber_Cooling' | 'Gimbal_Actuator' | 'Avionics_Bus_B' | 'Thermal_Shield_Tile';
  subsystem: 'Propulsion' | 'Avionics' | 'Structures' | 'Thermal' | 'GNC';
  event_type: 'Sensor_Drift' | 'Pressure_Spike' | 'Vibration_Exceedance' | 'Temperature_Anomaly' | 'Thrust_Asymmetry';
  severity: 'Minor' | 'Moderate' | 'Critical';
  duration: number; // seconds
  detected: boolean;
  cause_category: 'Manufacturing_Defect' | 'Thermal_Stress' | 'Fatigue' | 'Software_Exception' | 'Debris_Impact';
  corrective_action: string;
}

export interface ManufacturingSPCRecord {
  part_id: string;
  component_type: 'Dome_Section' | 'LOX_Tank_Weld' | 'Raptor_Nozzle' | 'Grid_Fin_Shaft';
  batch_id: string;
  supplier: 'Newton_Internal_Forge' | 'Space_Castings_Ltd' | 'Apex_Metallurgy';
  dimension_error: number; // mm deviation from nominal
  mass: number; // kg
  tensile_strength: number; // MPa
  weld_void_percentage: number; // % void ratio via ultrasound
  ultraviolet_reflectance?: number;
  spc_date: string;
}
