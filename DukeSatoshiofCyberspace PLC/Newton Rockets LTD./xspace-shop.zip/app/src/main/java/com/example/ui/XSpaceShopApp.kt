package com.example.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.CartItemEntity
import com.example.data.OrderEntity
import com.example.data.ProductEntity
import com.example.ui.components.ProductIllustration
import com.example.ui.theme.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun XSpaceShopApp(viewModel: MainViewModel) {
    val currentScreen by viewModel.currentScreen.collectAsStateWithLifecycle()
    val searchOpen by viewModel.searchOpen.collectAsStateWithLifecycle()
    val cartItems by viewModel.cartItems.collectAsStateWithLifecycle()
    val products by viewModel.products.collectAsStateWithLifecycle()
    val wishlistItems by viewModel.wishlistItems.collectAsStateWithLifecycle()

    var mobileMenuOpen by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    // Handle back button presses for custom backstack navigation
    BackHandler(enabled = currentScreen != Screen.Home) {
        viewModel.navigateBack()
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(BackgroundBlack)
    ) {
        Scaffold(
            topBar = {
                // EXTREMELY CLEAN MINIMAL HEADER
                XSpaceHeader(
                    cartCount = cartItems.sumOf { it.quantity },
                    onSearchClick = { viewModel.searchOpen.value = true },
                    onCartClick = { viewModel.navigateTo(Screen.Cart) },
                    onWishlistClick = { viewModel.navigateTo(Screen.Wishlist) },
                    onAccountClick = { viewModel.navigateTo(Screen.Account) },
                    onLogoClick = { viewModel.navigateHome() },
                    onMenuToggle = { mobileMenuOpen = !mobileMenuOpen },
                    onCategoryClick = { category ->
                        viewModel.navigateTo(Screen.Collection(category))
                    }
                )
            },
            bottomBar = {
                // Cart summary indicator on mobile
                if (cartItems.isNotEmpty() && currentScreen != Screen.Cart && currentScreen != Screen.Checkout) {
                    MobileCartIndicator(
                        itemCount = cartItems.sumOf { it.quantity },
                        onClick = { viewModel.navigateTo(Screen.Cart) }
                    )
                }
            },
            containerColor = BackgroundBlack
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                // MAIN PAGE SWITCHER
                AnimatedContent(
                    targetState = currentScreen,
                    transitionSpec = {
                        fadeIn() togetherWith fadeOut()
                    },
                    label = "screen_transition"
                ) { screen ->
                    when (screen) {
                        is Screen.Home -> HomeScreen(viewModel)
                        is Screen.Collection -> CollectionScreen(screen.name, viewModel)
                        is Screen.ProductDetail -> ProductDetailScreen(screen.productSlug, viewModel)
                        is Screen.Cart -> CartScreen(viewModel)
                        is Screen.Checkout -> CheckoutScreen(viewModel)
                        is Screen.OrderConfirmation -> OrderConfirmationScreen(screen.orderId, viewModel)
                        is Screen.Account -> AccountScreen(viewModel)
                        is Screen.Wishlist -> WishlistScreen(viewModel)
                    }
                }
            }
        }

        // FULL SCREEN MOBILE NAVIGATION MENU OVERLAY
        AnimatedVisibility(
            visible = mobileMenuOpen,
            enter = slideInVertically(initialOffsetY = { -it }) + fadeIn(),
            exit = slideOutVertically(targetOffsetY = { -it }) + fadeOut()
        ) {
            MobileNavigationOverlay(
                onClose = { mobileMenuOpen = false },
                onNavigate = { screen ->
                    mobileMenuOpen = false
                    viewModel.navigateTo(screen)
                }
            )
        }

        // FULL SCREEN SEARCH OVERLAY
        AnimatedVisibility(
            visible = searchOpen,
            enter = fadeIn(),
            exit = fadeOut()
        ) {
            SearchOverlay(viewModel)
        }
    }
}

// ================= HEADER =================
@Composable
fun XSpaceHeader(
    cartCount: Int,
    onSearchClick: () -> Unit,
    onCartClick: () -> Unit,
    onWishlistClick: () -> Unit,
    onAccountClick: () -> Unit,
    onLogoClick: () -> Unit,
    onMenuToggle: () -> Unit,
    onCategoryClick: (String) -> Unit
) {
    val configuration = LocalConfiguration.current
    val isWideScreen = configuration.screenWidthDp > 600

    Surface(
        color = BackgroundBlack,
        contentColor = White,
        border = BorderStroke(width = 0.5.dp, color = Charcoal)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(64.dp)
                .padding(horizontal = 24.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            // LOGO
            Text(
                text = "XSPACE",
                style = Typography.titleLarge.copy(fontWeight = FontWeight.Black, letterSpacing = 4.sp),
                modifier = Modifier
                    .clickable { onLogoClick() }
                    .testTag("header_logo")
            )

            // CATEGORY NAVIGATION (WIDE SCREEN ONLY)
            if (isWideScreen) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(24.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    val categories = listOf("APPAREL", "MISSION", "ROCKETS", "ACCESSORIES", "COLLECTIBLES")
                    categories.forEach { cat ->
                        Text(
                            text = cat,
                            style = Typography.labelLarge,
                            modifier = Modifier
                                .clickable { onCategoryClick(cat) }
                                .padding(vertical = 8.dp)
                        )
                    }
                }
            }

            // ACTIONS
            Row(
                horizontalArrangement = Arrangement.spacedBy(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onSearchClick, modifier = Modifier.testTag("search_icon_button")) {
                    Icon(Icons.Default.Search, contentDescription = "Search Products", tint = White)
                }
                IconButton(onClick = onWishlistClick, modifier = Modifier.testTag("wishlist_icon_button")) {
                    Icon(Icons.Default.FavoriteBorder, contentDescription = "Saved Items", tint = White)
                }
                IconButton(onClick = onAccountClick, modifier = Modifier.testTag("account_icon_button")) {
                    Icon(Icons.Default.AccountCircle, contentDescription = "Account Profile", tint = White)
                }
                IconButton(onClick = onCartClick, modifier = Modifier.testTag("cart_icon_button")) {
                    BadgedBox(
                        badge = {
                            if (cartCount > 0) {
                                Badge(
                                    containerColor = AerospaceRed,
                                    contentColor = White
                                ) {
                                    Text(text = cartCount.toString(), style = Typography.labelSmall)
                                }
                            }
                        }
                    ) {
                        Icon(Icons.Default.ShoppingCart, contentDescription = "Shopping Cart", tint = White)
                    }
                }

                // Hamburger Menu for compact sizes
                if (!isWideScreen) {
                    IconButton(onClick = onMenuToggle, modifier = Modifier.testTag("hamburger_menu_button")) {
                        Icon(Icons.Default.Menu, contentDescription = "Menu", tint = White)
                    }
                }
            }
        }
    }
}

// ================= MOBILE NAVIGATION MENU =================
@Composable
fun MobileNavigationOverlay(
    onClose: () -> Unit,
    onNavigate: (Screen) -> Unit
) {
    Surface(
        color = Black,
        modifier = Modifier.fillMaxSize()
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(64.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "XSPACE",
                    style = Typography.titleLarge.copy(fontWeight = FontWeight.Black, letterSpacing = 4.sp)
                )
                IconButton(onClick = onClose, modifier = Modifier.testTag("close_menu_button")) {
                    Icon(Icons.Default.Close, contentDescription = "Close Menu", tint = White)
                }
            }

            Spacer(modifier = Modifier.height(48.dp))

            val menuItems = listOf(
                "SHOP ALL" to Screen.Collection("ALL"),
                "APPAREL" to Screen.Collection("APPAREL"),
                "MISSION" to Screen.Collection("MISSION"),
                "ROCKETS" to Screen.Collection("ROCKETS"),
                "ACCESSORIES" to Screen.Collection("ACCESSORIES"),
                "COLLECTIBLES" to Screen.Collection("COLLECTIBLES"),
                "STARSHIP COLLECTION" to Screen.Collection("STARSHIP"),
                "FALCON COLLECTION" to Screen.Collection("FALCON"),
                "DRAGON COLLECTION" to Screen.Collection("DRAGON"),
                "SAVED ITEMS" to Screen.Wishlist,
                "ORDER HISTORY / PROFILE" to Screen.Account
            )

            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(16.dp),
                modifier = Modifier.weight(1f)
            ) {
                items(menuItems) { (title, screen) ->
                    Text(
                        text = title,
                        style = Typography.displayLarge.copy(fontSize = 24.sp, letterSpacing = 2.sp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onNavigate(screen) }
                            .padding(vertical = 8.dp)
                    )
                }
            }

            Text(
                text = "UNOFFICIAL CONCEPT STORE",
                style = Typography.labelSmall.copy(color = SteelGrey)
            )
        }
    }
}

// ================= HOMEPAGE =================
@Composable
fun HomeScreen(viewModel: MainViewModel) {
    val featuredProducts by viewModel.featuredProducts.collectAsStateWithLifecycle()
    val scrollState = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
    ) {
        // 01 HERO SECTION
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(550.dp)
                .background(DarkCharcoal)
        ) {
            // Custom high contrast rocket technical display
            ProductIllustration(
                slug = "starship-flight-test-poster",
                modifier = Modifier
                    .fillMaxSize()
                    .alpha(0.35f)
            )

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(32.dp),
                verticalArrangement = Arrangement.Bottom,
                horizontalAlignment = Alignment.Start
            ) {
                Text(
                    text = "STARSHIP",
                    style = Typography.displayLarge.copy(fontSize = 44.sp, fontWeight = FontWeight.Black)
                )
                Text(
                    text = "THE NEXT GENERATION\nOF HUMAN FLIGHT",
                    style = Typography.titleMedium.copy(color = OffWhite, letterSpacing = 2.sp),
                    modifier = Modifier.padding(top = 8.dp, bottom = 24.dp)
                )
                Button(
                    onClick = { viewModel.navigateTo(Screen.Collection("STARSHIP")) },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = White,
                        contentColor = Black
                    ),
                    shape = RoundedCornerShape(0.dp),
                    modifier = Modifier
                        .height(48.dp)
                        .testTag("hero_shop_now_button")
                ) {
                    Text(
                        text = "[ SHOP STARSHIP ]",
                        style = Typography.labelLarge.copy(fontWeight = FontWeight.Bold)
                    )
                }
            }
        }

        // 02 NEW ARRIVALS
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp)
        ) {
            Text(
                text = "NEW ARRIVALS",
                style = Typography.displayMedium,
                modifier = Modifier.padding(bottom = 24.dp)
            )

            // Show 4 premium products
            val newArrivals = featuredProducts.take(4)
            ProductGridRow(products = newArrivals, onProductClick = { slug ->
                viewModel.navigateTo(Screen.ProductDetail(slug))
            })
        }

        // 03 ROCKETS SECTION
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(Charcoal)
                .padding(24.dp)
        ) {
            Text(
                text = "VEHICLES & ROCKETS",
                style = Typography.displayMedium.copy(color = White),
                modifier = Modifier.padding(bottom = 8.dp)
            )
            Text(
                text = "SELECT VEHICLE REPLICAS AND THEMATIC ENGINEERING KITS",
                style = Typography.labelSmall.copy(color = SteelGrey),
                modifier = Modifier.padding(bottom = 24.dp)
            )

            val vehicles = listOf(
                Triple("STARSHIP", "THE SECTOR'S HEAVIEST INTEGRATED SYSTEM", "starship-model"),
                Triple("FALCON", "THE WORLD'S REUSABLE FIRST CLASS WORKHORSE", "falcon-9-model"),
                Triple("DRAGON", "AUTONOMOUS HUMAN TRANSPORT MODULE", "dragon-spacecraft-model")
            )

            vehicles.forEach { (name, subtitle, slug) ->
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(180.dp)
                        .background(SurfaceBlack)
                        .border(0.5.dp, ConcreteGrey)
                        .clickable { viewModel.navigateTo(Screen.Collection(name)) }
                        .padding(16.dp)
                ) {
                    ProductIllustration(
                        slug = slug,
                        modifier = Modifier
                            .fillMaxHeight()
                            .width(140.dp)
                            .align(Alignment.CenterEnd)
                            .alpha(0.4f)
                    )
                    Column(
                        modifier = Modifier
                            .fillMaxHeight()
                            .fillMaxWidth(0.6f),
                        verticalArrangement = Arrangement.Center
                    ) {
                        Text(
                            text = name,
                            style = Typography.displayMedium.copy(fontSize = 20.sp)
                        )
                        Text(
                            text = subtitle,
                            style = Typography.labelSmall.copy(color = SteelGrey),
                            modifier = Modifier.padding(top = 4.dp, bottom = 12.dp)
                        )
                        Text(
                            text = "EXPLORE COLLECTION ->",
                            style = Typography.labelSmall.copy(color = AerospaceRed, fontWeight = FontWeight.Bold)
                        )
                    }
                }
                Spacer(modifier = Modifier.height(16.dp))
            }
        }

        // 04 MISSION SECTION (EDITORIAL)
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(300.dp)
                .background(SurfaceBlack)
                .padding(24.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize(),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "BUILT FOR FLIGHT.",
                    style = Typography.displayMedium.copy(textAlign = TextAlign.Center)
                )
                Text(
                    text = "DESIGNED FOR EARTH.",
                    style = Typography.displayMedium.copy(textAlign = TextAlign.Center, color = SteelGrey)
                )
                Spacer(modifier = Modifier.height(16.dp))
                Button(
                    onClick = { viewModel.navigateTo(Screen.Collection("MISSION")) },
                    colors = ButtonDefaults.buttonColors(containerColor = White, contentColor = Black),
                    shape = RoundedCornerShape(0.dp)
                ) {
                    Text(text = "[ SHOP MISSION MERCH ]", style = Typography.labelLarge)
                }
            }
        }

        // 05 FOOTER
        XSpaceFooter(
            onNavigate = { screen -> viewModel.navigateTo(screen) }
        )
    }
}

@Composable
fun ProductGridRow(products: List<ProductEntity>, onProductClick: (String) -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        products.forEach { product ->
            Box(
                modifier = Modifier
                    .weight(1f)
                    .clickable { onProductClick(product.slug) }
                    .testTag("product_card_${product.slug}")
            ) {
                Column {
                    ProductIllustration(
                        slug = product.slug,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(180.dp)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = product.name,
                        style = Typography.titleMedium.copy(fontSize = 14.sp),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = "$${product.price.toInt()} ${product.currency}",
                        style = Typography.labelLarge.copy(color = SteelGrey)
                    )
                }
            }
        }
    }
}

// ================= FOOTER =================
@Composable
fun XSpaceFooter(onNavigate: (Screen) -> Unit) {
    Surface(
        color = Black,
        contentColor = White,
        border = BorderStroke(width = 0.5.dp, color = Charcoal),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(24.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "SHOP",
                        style = Typography.labelLarge.copy(fontWeight = FontWeight.Bold, color = White)
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    listOf("APPAREL", "MISSION", "ROCKETS", "ACCESSORIES", "COLLECTIBLES").forEach { cat ->
                        Text(
                            text = cat,
                            style = Typography.bodyMedium.copy(color = SteelGrey),
                            modifier = Modifier
                                .clickable { onNavigate(Screen.Collection(cat)) }
                                .padding(vertical = 4.dp)
                        )
                    }
                }

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "COLLECTIONS",
                        style = Typography.labelLarge.copy(fontWeight = FontWeight.Bold, color = White)
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    listOf("STARSHIP", "FALCON", "DRAGON", "LAUNCH", "MARS").forEach { col ->
                        Text(
                            text = col,
                            style = Typography.bodyMedium.copy(color = SteelGrey),
                            modifier = Modifier
                                .clickable { onNavigate(Screen.Collection(col)) }
                                .padding(vertical = 4.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(32.dp))

            HorizontalDivider(color = Charcoal)

            Spacer(modifier = Modifier.height(24.dp))

            Text(
                text = "XSPACE SHOP",
                style = Typography.titleMedium.copy(letterSpacing = 2.sp, fontWeight = FontWeight.Bold)
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "UNOFFICIAL CONCEPT STORE\nNOT AFFILIATED WITH OR ENDORSED BY SPACEX",
                style = Typography.labelSmall.copy(color = SteelGrey, fontSize = 10.sp, lineHeight = 14.sp)
            )

            Spacer(modifier = Modifier.height(16.dp))

            Text(
                text = "© 2026 XSPACE. METADATA PLATFORM SYNC APPLIED.",
                style = Typography.labelSmall.copy(color = ConcreteGrey, fontSize = 9.sp)
            )
        }
    }
}

// ================= COLLECTION SCREEN =================
@Composable
fun CollectionScreen(collectionName: String, viewModel: MainViewModel) {
    val products by viewModel.products.collectAsStateWithLifecycle()
    val scrollState = rememberScrollState()

    // Filter products locally
    val filteredProducts = remember(collectionName, products) {
        if (collectionName == "ALL") {
            products
        } else {
            products.filter {
                it.category.equals(collectionName, ignoreCase = true) ||
                        it.collectionName.equals(collectionName, ignoreCase = true)
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
    ) {
        // Collection Banner
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(220.dp)
                .background(SurfaceBlack)
                .border(0.5.dp, Charcoal)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(24.dp),
                verticalArrangement = Arrangement.Bottom
            ) {
                Text(
                    text = collectionName,
                    style = Typography.displayLarge
                )
                Text(
                    text = "AEROSPACE GRADE COMMEMORATIVE GOODS / SERIAL UNITS FOUND: ${filteredProducts.size}",
                    style = Typography.labelSmall.copy(color = SteelGrey),
                    modifier = Modifier.padding(top = 4.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Product list/grid
        if (filteredProducts.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(250.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "NO PRODUCTS CURRENTLY DEPLOYED",
                    style = Typography.labelLarge.copy(color = SteelGrey)
                )
            }
        } else {
            // Render 2 columns manually to fit neatly inside the scroll view
            val chunked = filteredProducts.chunked(2)
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(24.dp)
            ) {
                chunked.forEach { rowItems ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        rowItems.forEach { product ->
                            Column(
                                modifier = Modifier
                                    .weight(1f)
                                    .clickable { viewModel.navigateTo(Screen.ProductDetail(product.slug)) }
                                    .testTag("collection_product_${product.slug}")
                            ) {
                                ProductIllustration(
                                    slug = product.slug,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(180.dp)
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = product.name,
                                    style = Typography.titleMedium.copy(fontSize = 14.sp),
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = "$${product.price.toInt()} USD",
                                    style = Typography.labelLarge.copy(color = SteelGrey)
                                )
                            }
                        }
                        // Fill remaining space if the row is incomplete
                        if (rowItems.size < 2) {
                            Box(modifier = Modifier.weight(1f))
                        }
                    }
                }
            }
        }

        XSpaceFooter(onNavigate = { screen -> viewModel.navigateTo(screen) })
    }
}

// ================= PRODUCT DETAIL SCREEN =================
@Composable
fun ProductDetailScreen(productSlug: String, viewModel: MainViewModel) {
    val products by viewModel.products.collectAsStateWithLifecycle()
    val wishlistItems by viewModel.wishlistItems.collectAsStateWithLifecycle()

    val product = remember(productSlug, products) {
        products.find { it.slug == productSlug }
    }

    if (product == null) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text(text = "PRODUCT DEPLOYMENT NOT FOUND", style = Typography.titleMedium)
        }
        return
    }

    // Initialize selections
    LaunchedEffect(product) {
        viewModel.resetSelections(product)
    }

    val selectedSize by viewModel.selectedSize.collectAsStateWithLifecycle()
    val selectedColor by viewModel.selectedColor.collectAsStateWithLifecycle()
    val qty by viewModel.quantity.collectAsStateWithLifecycle()
    val isSaved = remember(wishlistItems, product) {
        wishlistItems.any { it.productId == product.id }
    }

    val scrollState = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
    ) {
        Column(modifier = Modifier.padding(24.dp)) {
            // Large Product Image
            ProductIllustration(
                slug = product.slug,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(350.dp)
                    .testTag("product_detail_image")
            )

            Spacer(modifier = Modifier.height(24.dp))

            // Text Metadata
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = product.name,
                        style = Typography.displayMedium
                    )
                    Text(
                        text = "CODE: ${product.productCode}",
                        style = Typography.labelSmall.copy(color = SteelGrey),
                        modifier = Modifier.padding(top = 4.dp)
                    )
                }

                IconButton(
                    onClick = { viewModel.toggleWishlist(product.id) },
                    modifier = Modifier.testTag("wishlist_toggle_button")
                ) {
                    Icon(
                        imageVector = if (isSaved) Icons.Filled.Favorite else Icons.Outlined.FavoriteBorder,
                        contentDescription = "Save Product",
                        tint = if (isSaved) AerospaceRed else White
                    )
                }
            }

            Text(
                text = "$${product.price.toInt()} USD",
                style = Typography.displayLarge.copy(fontSize = 28.sp, color = White),
                modifier = Modifier.padding(vertical = 12.dp)
            )

            Text(
                text = product.description,
                style = Typography.bodyLarge,
                modifier = Modifier.padding(bottom = 24.dp)
            )

            // COLOR SELECTOR
            if (product.colors.isNotEmpty() && product.colors != "N/A") {
                Text(
                    text = "SPECIFIED FINISH / COLOUR",
                    style = Typography.labelSmall.copy(color = SteelGrey)
                )
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 8.dp, bottom = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    product.colors.split(",").forEach { col ->
                        val isSelected = selectedColor == col
                        Box(
                            modifier = Modifier
                                .border(
                                    width = if (isSelected) 2.dp else 1.dp,
                                    color = if (isSelected) White else ConcreteGrey
                                )
                                .clickable { viewModel.selectedColor.value = col }
                                .padding(horizontal = 16.dp, vertical = 8.dp)
                        ) {
                            Text(text = col, style = Typography.labelSmall)
                        }
                    }
                }
            }

            // SIZE SELECTOR
            if (product.sizes.isNotEmpty() && product.sizes != "O/S" && product.sizes != "N/A" && product.sizes != "3.5 INCH" && product.sizes != "4.0 INCH" && product.sizes != "XL SIZE" && product.sizes != "A5" && product.sizes != "750ML" && product.sizes != "350ML") {
                Text(
                    text = "CHOOSE DIMENSION / SIZE",
                    style = Typography.labelSmall.copy(color = SteelGrey)
                )
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 8.dp, bottom = 24.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    product.sizes.split(",").forEach { size ->
                        val isSelected = selectedSize == size
                        Box(
                            modifier = Modifier
                                .border(
                                    width = if (isSelected) 2.dp else 1.dp,
                                    color = if (isSelected) White else ConcreteGrey
                                )
                                .clickable { viewModel.selectedSize.value = size }
                                .padding(horizontal = 16.dp, vertical = 8.dp)
                        ) {
                            Text(text = size, style = Typography.labelLarge)
                        }
                    }
                }
            }

            // QUANTITY SELECTOR
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 24.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "DEPLOYMENT UNITS",
                    style = Typography.labelSmall.copy(color = SteelGrey)
                )

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    IconButton(
                        onClick = { if (qty > 1) viewModel.quantity.value = qty - 1 },
                        modifier = Modifier.border(0.5.dp, ConcreteGrey)
                    ) {
                        Icon(Icons.Default.Remove, contentDescription = "Decrease", tint = White)
                    }
                    Text(text = qty.toString(), style = Typography.titleLarge)
                    IconButton(
                        onClick = { viewModel.quantity.value = qty + 1 },
                        modifier = Modifier.border(0.5.dp, ConcreteGrey)
                    ) {
                        Icon(Icons.Default.Add, contentDescription = "Increase", tint = White)
                    }
                }
            }

            // ADD TO CART BUTTON
            Button(
                onClick = {
                    viewModel.addToCart(
                        product.id,
                        selectedSize,
                        selectedColor,
                        qty
                    )
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp)
                    .testTag("add_to_cart_button"),
                colors = ButtonDefaults.buttonColors(
                    containerColor = White,
                    contentColor = Black
                ),
                shape = RoundedCornerShape(0.dp)
            ) {
                Text(
                    text = "[ ADD TO UNIT MANIFEST ]",
                    style = Typography.labelLarge.copy(fontWeight = FontWeight.Bold)
                )
            }

            Spacer(modifier = Modifier.height(32.dp))

            // SPECIFICATIONS ACCORDION
            Column(
                modifier = Modifier.fillMaxWidth()
            ) {
                SpecRow(title = "MATERIAL COMPOSITION", detail = product.materials)
                SpecRow(title = "FIT CONSTRAINTS", detail = product.fit)
                SpecRow(title = "MANUFACTURING RECORD", detail = product.origin)
                SpecRow(title = "CARRIER FREIGHT", detail = "Calculated in manifest clearance. Instant parcel dispatch for certified coordinates.")
            }
        }

        XSpaceFooter(onNavigate = { screen -> viewModel.navigateTo(screen) })
    }
}

@Composable
fun SpecRow(title: String, detail: String) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 12.dp)
    ) {
        Text(text = title, style = Typography.labelSmall.copy(color = SteelGrey))
        Spacer(modifier = Modifier.height(4.dp))
        Text(text = detail, style = Typography.bodyLarge)
        Spacer(modifier = Modifier.height(12.dp))
        HorizontalDivider(color = Charcoal, thickness = 0.5.dp)
    }
}

// ================= SHOPPING CART SCREEN =================
@Composable
fun CartScreen(viewModel: MainViewModel) {
    val cartItems by viewModel.cartItems.collectAsStateWithLifecycle()
    val products by viewModel.products.collectAsStateWithLifecycle()

    val detailedCartItems = remember(cartItems, products) {
        cartItems.mapNotNull { item ->
            val product = products.find { it.id == item.productId }
            if (product != null) {
                Triple(item, product, product.price * item.quantity)
            } else null
        }
    }

    val subtotal = remember(detailedCartItems) {
        detailedCartItems.sumOf { it.third }
    }
    val shipping = remember(subtotal) {
        if (subtotal == 0.0) 0.0 else if (subtotal > 150.0) 0.0 else 15.0
    }
    val total = subtotal + shipping

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
    ) {
        Column(
            modifier = Modifier
                .padding(24.dp)
                .weight(1f, fill = false)
        ) {
            Text(
                text = "CARGO MANIFEST",
                style = Typography.displayLarge
            )
            Text(
                text = "PENDING SHIPMENT DEPLOYMENT",
                style = Typography.labelSmall.copy(color = SteelGrey),
                modifier = Modifier.padding(bottom = 24.dp)
            )

            if (detailedCartItems.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(300.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            Icons.Default.ShoppingCart,
                            contentDescription = "Empty",
                            tint = ConcreteGrey,
                            modifier = Modifier.size(64.dp)
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = "MANIFEST IS EMPTY",
                            style = Typography.labelLarge.copy(color = SteelGrey)
                        )
                    }
                }
            } else {
                // Cart items list
                detailedCartItems.forEach { (item, product, cost) ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.Top
                    ) {
                        ProductIllustration(
                            slug = product.slug,
                            modifier = Modifier
                                .size(80.dp)
                        )

                        Spacer(modifier = Modifier.width(16.dp))

                        Column(modifier = Modifier.weight(1f)) {
                            Text(text = product.name, style = Typography.titleMedium)
                            Text(
                                text = "COLOR: ${item.color} / SIZE: ${item.size}",
                                style = Typography.labelSmall.copy(color = SteelGrey)
                            )
                            Row(
                                modifier = Modifier.padding(top = 8.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                IconButton(
                                    onClick = { viewModel.updateCartQuantity(item.id, item.quantity - 1) },
                                    modifier = Modifier
                                        .size(24.dp)
                                        .border(0.5.dp, ConcreteGrey)
                                ) {
                                    Icon(Icons.Default.Remove, contentDescription = "Decrease", tint = White, modifier = Modifier.size(12.dp))
                                }
                                Text(text = item.quantity.toString(), style = Typography.labelLarge)
                                IconButton(
                                    onClick = { viewModel.updateCartQuantity(item.id, item.quantity + 1) },
                                    modifier = Modifier
                                        .size(24.dp)
                                        .border(0.5.dp, ConcreteGrey)
                                ) {
                                    Icon(Icons.Default.Add, contentDescription = "Increase", tint = White, modifier = Modifier.size(12.dp))
                                }
                            }
                        }

                        Column(horizontalAlignment = Alignment.End) {
                            Text(text = "$${cost.toInt()} USD", style = Typography.titleMedium)
                            IconButton(
                                onClick = { viewModel.removeFromCart(item.id) },
                                modifier = Modifier.padding(top = 8.dp)
                            ) {
                                Icon(Icons.Default.Delete, contentDescription = "Remove item", tint = SteelGrey)
                            }
                        }
                    }
                    HorizontalDivider(color = Charcoal, thickness = 0.5.dp)
                }

                Spacer(modifier = Modifier.height(32.dp))

                // Summary Block
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(SurfaceBlack)
                        .padding(16.dp)
                        .border(1.dp, Charcoal)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(text = "CARGO SUBTOTAL", style = Typography.bodyLarge.copy(color = SteelGrey))
                        Text(text = "$${subtotal.toInt()} USD", style = Typography.titleMedium)
                    }
                    Spacer(modifier = Modifier.height(12.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(text = "CARRIER FREIGHT", style = Typography.bodyLarge.copy(color = SteelGrey))
                        Text(
                            text = if (shipping == 0.0) "COMPLIMENTARY" else "$${shipping.toInt()} USD",
                            style = Typography.titleMedium.copy(color = if (shipping == 0.0) AerospaceRed else White)
                        )
                    }
                    Spacer(modifier = Modifier.height(16.dp))
                    HorizontalDivider(color = Charcoal)
                    Spacer(modifier = Modifier.height(16.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(text = "TOTAL EST. VALUE", style = Typography.titleLarge)
                        Text(text = "$${total.toInt()} USD", style = Typography.displayLarge.copy(fontSize = 24.sp, color = White))
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))

                Button(
                    onClick = { viewModel.navigateTo(Screen.Checkout) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(56.dp)
                        .testTag("checkout_button"),
                    colors = ButtonDefaults.buttonColors(containerColor = White, contentColor = Black),
                    shape = RoundedCornerShape(0.dp)
                ) {
                    Text(text = "[ INITIATE SECURE CHECKOUT ]", style = Typography.labelLarge.copy(fontWeight = FontWeight.Bold))
                }
            }
        }

        XSpaceFooter(onNavigate = { screen -> viewModel.navigateTo(screen) })
    }
}

// ================= CHECKOUT SCREEN =================
@Composable
fun CheckoutScreen(viewModel: MainViewModel) {
    val checkoutName by viewModel.checkoutName.collectAsStateWithLifecycle()
    val checkoutEmail by viewModel.checkoutEmail.collectAsStateWithLifecycle()
    val checkoutAddress by viewModel.checkoutAddress.collectAsStateWithLifecycle()
    val checkoutCity by viewModel.checkoutCity.collectAsStateWithLifecycle()
    val checkoutPostcode by viewModel.checkoutPostcode.collectAsStateWithLifecycle()
    val checkoutCountry by viewModel.checkoutCountry.collectAsStateWithLifecycle()
    val payMethod by viewModel.checkoutPaymentMethod.collectAsStateWithLifecycle()

    val cartItems by viewModel.cartItems.collectAsStateWithLifecycle()
    val products by viewModel.products.collectAsStateWithLifecycle()

    val detailedCartItems = remember(cartItems, products) {
        cartItems.mapNotNull { item ->
            val product = products.find { it.id == item.productId }
            if (product != null) {
                Triple(item, product, product.price * item.quantity)
            } else null
        }
    }

    val subtotal = remember(detailedCartItems) {
        detailedCartItems.sumOf { it.third }
    }
    val shipping = remember(subtotal) {
        if (subtotal > 150.0) 0.0 else 15.0
    }
    val total = subtotal + shipping

    val itemsSummary = remember(detailedCartItems) {
        detailedCartItems.joinToString(", ") { "${it.second.name} (${it.first.size}) x${it.first.quantity}" }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
    ) {
        Column(modifier = Modifier.padding(24.dp)) {
            Text(
                text = "SECURE CLEARANCE",
                style = Typography.displayLarge
            )
            Text(
                text = "ENTER SECURE SHIPMENT COORDINATES",
                style = Typography.labelSmall.copy(color = SteelGrey),
                modifier = Modifier.padding(bottom = 24.dp)
            )

            // Shipping Details Form
            XSpaceTextField(
                value = checkoutName,
                onValueChange = { viewModel.checkoutName.value = it },
                label = "RECIPIENT FULNAME",
                testTag = "checkout_name_field"
            )
            Spacer(modifier = Modifier.height(16.dp))

            XSpaceTextField(
                value = checkoutEmail,
                onValueChange = { viewModel.checkoutEmail.value = it },
                label = "SECURE COMMS EMAIL",
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                testTag = "checkout_email_field"
            )
            Spacer(modifier = Modifier.height(16.dp))

            XSpaceTextField(
                value = checkoutAddress,
                onValueChange = { viewModel.checkoutAddress.value = it },
                label = "DELIVERY STATION ADDRESS",
                testTag = "checkout_address_field"
            )
            Spacer(modifier = Modifier.height(16.dp))

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                XSpaceTextField(
                    value = checkoutCity,
                    onValueChange = { viewModel.checkoutCity.value = it },
                    label = "CITY / STATION",
                    modifier = Modifier.weight(1f),
                    testTag = "checkout_city_field"
                )
                XSpaceTextField(
                    value = checkoutPostcode,
                    onValueChange = { viewModel.checkoutPostcode.value = it },
                    label = "POSTCODE / ZIP",
                    modifier = Modifier.weight(1f),
                    testTag = "checkout_postcode_field"
                )
            }
            Spacer(modifier = Modifier.height(24.dp))

            // Payment Methods
            Text(text = "PAYMENT SETTLEMENT PROTOCOL", style = Typography.labelSmall.copy(color = SteelGrey))
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 12.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                listOf("CARD", "APPLE PAY", "GOOGLE PAY").forEach { method ->
                    val isSelected = payMethod == method
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(
                                width = if (isSelected) 2.dp else 1.dp,
                                color = if (isSelected) White else Charcoal
                            )
                            .clickable { viewModel.checkoutPaymentMethod.value = method }
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(
                            selected = isSelected,
                            onClick = { viewModel.checkoutPaymentMethod.value = method },
                            colors = RadioButtonDefaults.colors(selectedColor = White, unselectedColor = ConcreteGrey)
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Text(text = method, style = Typography.bodyLarge)
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Manifest review summary
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(SurfaceBlack)
                    .padding(16.dp)
                    .border(1.dp, Charcoal)
            ) {
                Text(text = "MANIFEST DEPLOYMENT SUMMARY", style = Typography.labelSmall.copy(color = SteelGrey))
                Spacer(modifier = Modifier.height(12.dp))
                detailedCartItems.forEach { (_, prod, cost) ->
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(text = prod.name, style = Typography.bodyMedium, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                        Text(text = "$${cost.toInt()} USD", style = Typography.labelLarge)
                    }
                }
                Spacer(modifier = Modifier.height(12.dp))
                HorizontalDivider(color = Charcoal)
                Spacer(modifier = Modifier.height(12.dp))
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(text = "GRAND TOTAL DUE", style = Typography.titleMedium)
                    Text(text = "$${total.toInt()} USD", style = Typography.titleLarge.copy(color = AerospaceRed))
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            Button(
                onClick = {
                    if (checkoutName.isNotBlank() && checkoutEmail.isNotBlank() && checkoutAddress.isNotBlank()) {
                        viewModel.processCheckout(itemsSummary, subtotal, shipping, total)
                    }
                },
                enabled = checkoutName.isNotBlank() && checkoutEmail.isNotBlank() && checkoutAddress.isNotBlank(),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp)
                    .testTag("submit_order_button"),
                colors = ButtonDefaults.buttonColors(
                    containerColor = White,
                    contentColor = Black,
                    disabledContainerColor = ConcreteGrey,
                    disabledContentColor = Charcoal
                ),
                shape = RoundedCornerShape(0.dp)
            ) {
                Text(text = "[ TRANSMIT MISSION ORDER ]", style = Typography.labelLarge.copy(fontWeight = FontWeight.Bold))
            }
        }

        XSpaceFooter(onNavigate = { screen -> viewModel.navigateTo(screen) })
    }
}

@Composable
fun XSpaceTextField(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
    modifier: Modifier = Modifier,
    keyboardOptions: KeyboardOptions = KeyboardOptions.Default,
    testTag: String = ""
) {
    Column(modifier = modifier) {
        Text(text = label, style = Typography.labelSmall.copy(color = SteelGrey, fontSize = 9.sp))
        Spacer(modifier = Modifier.height(4.dp))
        BasicTextField(
            value = value,
            onValueChange = onValueChange,
            textStyle = Typography.bodyLarge.copy(color = White),
            keyboardOptions = keyboardOptions,
            cursorBrush = SolidColor(White),
            modifier = Modifier
                .fillMaxWidth()
                .background(SurfaceBlack)
                .border(1.dp, Charcoal)
                .padding(16.dp)
                .testTag(testTag)
        )
    }
}

// ================= ORDER CONFIRMATION SCREEN =================
@Composable
fun OrderConfirmationScreen(orderId: String, viewModel: MainViewModel) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Black)
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(
                imageVector = Icons.Default.CheckCircle,
                contentDescription = "Success",
                tint = AerospaceRed,
                modifier = Modifier.size(80.dp)
            )

            Spacer(modifier = Modifier.height(24.dp))

            Text(
                text = "ORDER TRANSMITTED",
                style = Typography.displayLarge
            )
            Text(
                text = "DEPARTURE FLIGHT APPROVED",
                style = Typography.labelLarge.copy(color = SteelGrey)
            )

            Spacer(modifier = Modifier.height(16.dp))

            Surface(
                color = SurfaceBlack,
                border = BorderStroke(1.dp, Charcoal),
                modifier = Modifier.padding(16.dp)
            ) {
                Column(modifier = Modifier.padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(text = "MANIFEST TRACKING UNIT", style = Typography.labelSmall.copy(color = SteelGrey))
                    Text(
                        text = orderId,
                        style = Typography.displayLarge.copy(fontSize = 32.sp, color = White, fontWeight = FontWeight.Black)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "A copy of coordinates confirmation was dispatched to your secured comms mail.",
                        style = Typography.bodyMedium.copy(color = SteelGrey, textAlign = TextAlign.Center)
                    )
                }
            }

            Spacer(modifier = Modifier.height(32.dp))

            Button(
                onClick = { viewModel.navigateHome() },
                colors = ButtonDefaults.buttonColors(containerColor = White, contentColor = Black),
                shape = RoundedCornerShape(0.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp)
                    .testTag("continue_shopping_button")
            ) {
                Text(text = "[ RETURN TO MISSION HUB ]", style = Typography.labelLarge)
            }
        }
    }
}

// ================= ACCOUNT SCREEN =================
@Composable
fun AccountScreen(viewModel: MainViewModel) {
    val orders by viewModel.orders.collectAsStateWithLifecycle()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
    ) {
        Column(modifier = Modifier.padding(24.dp)) {
            Text(
                text = "MISSION LOGS",
                style = Typography.displayLarge
            )
            Text(
                text = "HISTORICAL ORDER MANIFESTS",
                style = Typography.labelSmall.copy(color = SteelGrey),
                modifier = Modifier.padding(bottom = 24.dp)
            )

            if (orders.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(200.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(text = "NO PRIOR DELIVERIES LOGGED", style = Typography.labelLarge.copy(color = SteelGrey))
                }
            } else {
                orders.forEach { order ->
                    Surface(
                        color = SurfaceBlack,
                        border = BorderStroke(0.5.dp, Charcoal),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 8.dp)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "LOG: ${order.orderId}",
                                    style = Typography.labelLarge.copy(fontWeight = FontWeight.Bold, color = White)
                                )
                                Box(
                                    modifier = Modifier
                                        .background(
                                            if (order.status == "DELIVERED") Color(0xFF0F2D1F) else Color(0xFF4C3000)
                                        )
                                        .padding(horizontal = 8.dp, vertical = 4.dp)
                                ) {
                                    Text(
                                        text = order.status,
                                        style = Typography.labelSmall.copy(
                                            color = if (order.status == "DELIVERED") Color(0xFF52FF9E) else Color(0xFFFFB03A)
                                        )
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(text = order.itemsSummary, style = Typography.bodyMedium)
                            Spacer(modifier = Modifier.height(12.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                val sdf = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault())
                                Text(
                                    text = sdf.format(Date(order.timestamp)),
                                    style = Typography.labelSmall.copy(color = SteelGrey)
                                )
                                Text(
                                    text = "$${order.total.toInt()} USD",
                                    style = Typography.labelLarge.copy(fontWeight = FontWeight.Bold, color = White)
                                )
                            }
                        }
                    }
                }
            }
        }

        XSpaceFooter(onNavigate = { screen -> viewModel.navigateTo(screen) })
    }
}

// ================= WISHLIST SCREEN =================
@Composable
fun WishlistScreen(viewModel: MainViewModel) {
    val wishlistItems by viewModel.wishlistItems.collectAsStateWithLifecycle()
    val products by viewModel.products.collectAsStateWithLifecycle()

    val wishlistedProducts = remember(wishlistItems, products) {
        products.filter { prod -> wishlistItems.any { it.productId == prod.id } }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
    ) {
        Column(modifier = Modifier.padding(24.dp)) {
            Text(
                text = "SAVED CARGO",
                style = Typography.displayLarge
            )
            Text(
                text = "WATCHLISTED VEHICLES & GOODS",
                style = Typography.labelSmall.copy(color = SteelGrey),
                modifier = Modifier.padding(bottom = 24.dp)
            )

            if (wishlistedProducts.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(250.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(text = "NO SAVED PROTOCOLS REGISTERED", style = Typography.labelLarge.copy(color = SteelGrey))
                }
            } else {
                val chunked = wishlistedProducts.chunked(2)
                Column(verticalArrangement = Arrangement.spacedBy(24.dp)) {
                    chunked.forEach { rowItems ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(16.dp)
                        ) {
                            rowItems.forEach { product ->
                                Column(
                                    modifier = Modifier
                                        .weight(1f)
                                        .clickable { viewModel.navigateTo(Screen.ProductDetail(product.slug)) }
                                ) {
                                    ProductIllustration(
                                        slug = product.slug,
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(180.dp)
                                    )
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Text(
                                        text = product.name,
                                        style = Typography.titleMedium.copy(fontSize = 14.sp),
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Text(
                                        text = "$${product.price.toInt()} USD",
                                        style = Typography.labelLarge.copy(color = SteelGrey)
                                    )
                                }
                            }
                            if (rowItems.size < 2) {
                                Box(modifier = Modifier.weight(1f))
                            }
                        }
                    }
                }
            }
        }

        XSpaceFooter(onNavigate = { screen -> viewModel.navigateTo(screen) })
    }
}

// ================= SEARCH OVERLAY =================
@Composable
fun SearchOverlay(viewModel: MainViewModel) {
    val query by viewModel.searchQuery.collectAsStateWithLifecycle()
    val results by viewModel.searchResults.collectAsStateWithLifecycle()

    Surface(
        color = Black.copy(alpha = 0.95f),
        modifier = Modifier.fillMaxSize()
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(64.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "SEARCH MANIFEST",
                    style = Typography.labelSmall.copy(color = SteelGrey)
                )
                IconButton(
                    onClick = {
                        viewModel.searchOpen.value = false
                        viewModel.searchQuery.value = ""
                    },
                    modifier = Modifier.testTag("close_search_button")
                ) {
                    Icon(Icons.Default.Close, contentDescription = "Close Search", tint = White)
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Massive input box
            BasicTextField(
                value = query,
                onValueChange = { viewModel.searchQuery.value = it },
                textStyle = Typography.displayLarge.copy(color = White, fontSize = 28.sp),
                cursorBrush = SolidColor(White),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, Charcoal)
                    .background(SurfaceBlack)
                    .padding(16.dp)
                    .testTag("search_input_field")
            )

            Spacer(modifier = Modifier.height(24.dp))

            if (query.length >= 2) {
                Text(
                    text = "SEARCH RESULTS / DETECTED MATCHES: ${results.size}",
                    style = Typography.labelSmall.copy(color = SteelGrey),
                    modifier = Modifier.padding(bottom = 16.dp)
                )

                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(16.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    items(results) { product ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    viewModel.searchOpen.value = false
                                    viewModel.searchQuery.value = ""
                                    viewModel.navigateTo(Screen.ProductDetail(product.slug))
                                }
                                .padding(vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            ProductIllustration(
                                slug = product.slug,
                                modifier = Modifier.size(50.dp)
                            )
                            Spacer(modifier = Modifier.width(16.dp))
                            Column {
                                Text(text = product.name, style = Typography.titleMedium)
                                Text(
                                    text = "${product.category} · $${product.price.toInt()} USD",
                                    style = Typography.labelSmall.copy(color = SteelGrey)
                                )
                            }
                        }
                    }
                }
            } else {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "TYPE AT LEAST 2 CHARACTERS TO COMMENCE SEARCH",
                        style = Typography.labelSmall.copy(color = ConcreteGrey)
                    )
                }
            }
        }
    }
}

// ================= MOBILE BOTTOM BAR CART INDICATOR =================
@Composable
fun MobileCartIndicator(itemCount: Int, onClick: () -> Unit) {
    Surface(
        color = AerospaceRed,
        contentColor = White,
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .testTag("mobile_cart_indicator")
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "ACTIVE MANIFEST CLEARANCE",
                style = Typography.labelLarge.copy(fontWeight = FontWeight.Bold)
            )
            Text(
                text = "$itemCount UNITS DISPATCHED ->",
                style = Typography.labelLarge.copy(fontWeight = FontWeight.Bold)
            )
        }
    }
}
