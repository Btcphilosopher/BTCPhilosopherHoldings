package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

sealed class Screen {
    object Home : Screen()
    data class Collection(val name: String) : Screen()
    data class ProductDetail(val productSlug: String) : Screen()
    object Cart : Screen()
    object Checkout : Screen()
    data class OrderConfirmation(val orderId: String) : Screen()
    object Account : Screen()
    object Wishlist : Screen()
}

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val database = AppDatabase.getDatabase(application)
    private val repository = XSpaceRepository(database)

    // Navigation Stack
    private val _navigationStack = MutableStateFlow<List<Screen>>(listOf(Screen.Home))
    val currentScreen: StateFlow<Screen> = _navigationStack
        .map { it.lastOrNull() ?: Screen.Home }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), Screen.Home)

    // Search overlay state
    val searchOpen = MutableStateFlow(false)
    val searchQuery = MutableStateFlow("")
    val searchResults = searchQuery
        .flatMapLatest { query ->
            if (query.length < 2) flowOf(emptyList())
            else repository.searchProducts(query)
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Database reactive streams
    val products = repository.allProducts.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val featuredProducts = repository.featuredProducts.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val cartItems = repository.cartItems.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val wishlistItems = repository.wishlistItems.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val orders = repository.allOrders.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Product detail current selections
    val selectedSize = MutableStateFlow("")
    val selectedColor = MutableStateFlow("")
    val quantity = MutableStateFlow(1)

    // Checkout form state
    val checkoutName = MutableStateFlow("")
    val checkoutEmail = MutableStateFlow("")
    val checkoutAddress = MutableStateFlow("")
    val checkoutCity = MutableStateFlow("")
    val checkoutPostcode = MutableStateFlow("")
    val checkoutCountry = MutableStateFlow("UNITED STATES")
    val checkoutPaymentMethod = MutableStateFlow("CARD") // CARD, APPLE_PAY, GOOGLE_PAY

    init {
        viewModelScope.launch {
            repository.initializeDatabase()
        }
    }

    // Navigation Functions
    fun navigateTo(screen: Screen) {
        val current = _navigationStack.value.toMutableList()
        // Avoid adding duplicate consecutive screens
        if (current.lastOrNull() != screen) {
            current.add(screen)
            _navigationStack.value = current
        }
    }

    fun navigateBack() {
        val current = _navigationStack.value.toMutableList()
        if (current.size > 1) {
            current.removeAt(current.size - 1)
            _navigationStack.value = current
        }
    }

    fun navigateHome() {
        _navigationStack.value = listOf(Screen.Home)
    }

    // Cart Management
    fun addToCart(productId: String, size: String, color: String, qty: Int) {
        viewModelScope.launch {
            repository.addToCart(productId, size, color, qty)
            navigateTo(Screen.Cart)
        }
    }

    fun updateCartQuantity(id: Long, qty: Int) {
        viewModelScope.launch {
            repository.updateCartQuantity(id, qty)
        }
    }

    fun removeFromCart(id: Long) {
        viewModelScope.launch {
            repository.removeFromCart(id)
        }
    }

    fun clearCart() {
        viewModelScope.launch {
            repository.clearCart()
        }
    }

    // Wishlist Management
    fun toggleWishlist(productId: String) {
        viewModelScope.launch {
            repository.toggleWishlist(productId)
        }
    }

    // Checkout
    fun processCheckout(itemsSummary: String, subtotal: Double, shipping: Double, total: Double) {
        viewModelScope.launch {
            val orderId = repository.submitOrder(
                itemsSummary = itemsSummary,
                subtotal = subtotal,
                shipping = shipping,
                total = total,
                name = checkoutName.value,
                email = checkoutEmail.value,
                address = checkoutAddress.value,
                city = checkoutCity.value,
                postcode = checkoutPostcode.value,
                country = checkoutCountry.value
            )
            // Navigate to Order Confirmation
            navigateTo(Screen.OrderConfirmation(orderId))
        }
    }

    // Helper: Reset selections when viewing a new product
    fun resetSelections(product: ProductEntity) {
        selectedSize.value = product.sizes.split(",").firstOrNull() ?: ""
        selectedColor.value = product.colors.split(",").firstOrNull() ?: ""
        quantity.value = 1
    }
}
