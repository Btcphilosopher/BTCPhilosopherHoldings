package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "products")
data class ProductEntity(
    @PrimaryKey val id: String,
    val slug: String,
    val name: String,
    val description: String,
    val price: Double,
    val currency: String,
    val category: String, // APPAREL, MISSION, ROCKETS, ACCESSORIES, COLLECTIBLES
    val collectionName: String, // STARSHIP, FALCON, DRAGON, ORBITAL, LUNAR, MARS, FLIGHT_TEST
    val productCode: String,
    val materials: String,
    val fit: String,
    val origin: String,
    val featured: Boolean,
    val sizes: String, // Comma-separated e.g. "S,M,L,XL,XXL"
    val colors: String // Comma-separated e.g. "BLACK,STEEL,CHARCOAL"
)

@Entity(tableName = "cart_items")
data class CartItemEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val productId: String,
    val size: String,
    val color: String,
    val quantity: Int
)

@Entity(tableName = "wishlist_items")
data class WishlistItemEntity(
    @PrimaryKey val productId: String
)

@Entity(tableName = "orders")
data class OrderEntity(
    @PrimaryKey val orderId: String,
    val timestamp: Long,
    val itemsSummary: String, // Summary string of items e.g. "STARSHIP TEE (M) x1, DRAGON MODEL x1"
    val subtotal: Double,
    val shipping: Double,
    val total: Double,
    val status: String, // "DELIVERED", "IN_TRANSIT", "PENDING"
    val name: String,
    val email: String,
    val address: String,
    val city: String,
    val postcode: String,
    val country: String
)
