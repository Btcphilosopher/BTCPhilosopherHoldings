package com.example.data

import android.content.Context
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import java.util.UUID

class XSpaceRepository(private val db: AppDatabase) {

    val allProducts: Flow<List<ProductEntity>> = db.productDao().getAllProducts()
    val featuredProducts: Flow<List<ProductEntity>> = db.productDao().getFeaturedProducts()
    val cartItems: Flow<List<CartItemEntity>> = db.cartDao().getCartItems()
    val wishlistItems: Flow<List<WishlistItemEntity>> = db.wishlistDao().getWishlistItems()
    val allOrders: Flow<List<OrderEntity>> = db.orderDao().getAllOrders()

    suspend fun initializeDatabase() {
        // Seed Products if none exist
        if (db.productDao().getCount() == 0) {
            db.productDao().insertAll(ProductCatalog.items)
        }

        // Seed 20 historical orders if none exist
        if (db.orderDao().getCount() == 0) {
            val seededOrders = generateHistoricalOrders()
            for (order in seededOrders) {
                db.orderDao().insertOrder(order)
            }
        }
    }

    suspend fun getProductBySlug(slug: String): ProductEntity? {
        return db.productDao().getProductBySlug(slug)
    }

    suspend fun getProductById(id: String): ProductEntity? {
        return db.productDao().getProductById(id)
    }

    fun getProductsByCategory(category: String): Flow<List<ProductEntity>> {
        return db.productDao().getProductsByCategory(category)
    }

    fun getProductsByCollection(collection: String): Flow<List<ProductEntity>> {
        return db.productDao().getProductsByCollection(collection)
    }

    fun searchProducts(query: String): Flow<List<ProductEntity>> {
        return db.productDao().searchProducts(query)
    }

    suspend fun addToCart(productId: String, size: String, color: String, quantity: Int) {
        db.cartDao().insertCartItem(
            CartItemEntity(
                productId = productId,
                size = size,
                color = color,
                quantity = quantity
            )
        )
    }

    suspend fun updateCartQuantity(id: Long, quantity: Int) {
        if (quantity <= 0) {
            db.cartDao().deleteCartItem(id)
        } else {
            db.cartDao().updateQuantity(id, quantity)
        }
    }

    suspend fun removeFromCart(id: Long) {
        db.cartDao().deleteCartItem(id)
    }

    suspend fun clearCart() {
        db.cartDao().clearCart()
    }

    suspend fun toggleWishlist(productId: String) {
        val isWish = db.wishlistDao().isWishlisted(productId)
        if (isWish) {
            db.wishlistDao().deleteWishlistItem(productId)
        } else {
            db.wishlistDao().insertWishlistItem(WishlistItemEntity(productId))
        }
    }

    suspend fun isWishlisted(productId: String): Boolean {
        return db.wishlistDao().isWishlisted(productId)
    }

    suspend fun submitOrder(
        itemsSummary: String,
        subtotal: Double,
        shipping: Double,
        total: Double,
        name: String,
        email: String,
        address: String,
        city: String,
        postcode: String,
        country: String
    ): String {
        val orderId = "XS" + (1000..9999).random().toString()
        val order = OrderEntity(
            orderId = orderId,
            timestamp = System.currentTimeMillis(),
            itemsSummary = itemsSummary,
            subtotal = subtotal,
            shipping = shipping,
            total = total,
            status = "PENDING",
            name = name,
            email = email,
            address = address,
            city = city,
            postcode = postcode,
            country = country
        )
        db.orderDao().insertOrder(order)
        db.cartDao().clearCart()
        return orderId
    }

    private fun generateHistoricalOrders(): List<OrderEntity> {
        val names = listOf("John Doe", "Sarah Connor", "Bruce Wayne", "Alan Shepard", "Peggy Whitson", "Ellen Ochoa")
        val cities = listOf("Boca Chica", "Cape Canaveral", "Houston", "Hawthorne", "Seattle", "Vandenberg")
        val products = ProductCatalog.items

        val ordersList = mutableListOf<OrderEntity>()
        var baseTime = System.currentTimeMillis() - (30L * 24L * 60L * 60L * 1000L) // 30 days ago

        for (i in 1..20) {
            val orderId = "XS${1000 + i}"
            val timestamp = baseTime + (1L * 24L * 60L * 60L * 1000L * i) + (1..12).random() * 3600000L
            val itemCount = (1..3).random()
            val orderItems = List(itemCount) { products.random() }
            val itemsStr = orderItems.joinToString(", ") { "${it.name} (${it.sizes.split(",").random()}) x${(1..2).random()}" }
            
            val subtotal = orderItems.sumOf { it.price }
            val shipping = if (subtotal > 150.0) 0.0 else 15.0
            val total = subtotal + shipping
            val status = if (i == 20) "IN_TRANSIT" else "DELIVERED"
            
            val shopperName = names.random()
            val shopperEmail = shopperName.lowercase().replace(" ", ".") + "@xspace.com"

            ordersList.add(
                OrderEntity(
                    orderId = orderId,
                    timestamp = timestamp,
                    itemsSummary = itemsStr,
                    subtotal = subtotal,
                    shipping = shipping,
                    total = total,
                    status = status,
                    name = shopperName,
                    email = shopperEmail,
                    address = "Launch Facility Suite ${(1..100).random()}",
                    city = cities.random(),
                    postcode = "${(10000..99999).random()}",
                    country = "UNITED STATES"
                )
            )
        }
        return ordersList
    }
}
