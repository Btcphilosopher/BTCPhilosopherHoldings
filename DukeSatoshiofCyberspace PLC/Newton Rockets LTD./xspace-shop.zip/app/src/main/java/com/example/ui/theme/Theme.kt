package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val AerospaceColorScheme = darkColorScheme(
    primary = White,
    onPrimary = Black,
    secondary = OffWhite,
    onSecondary = Black,
    tertiary = AerospaceRed,
    onTertiary = White,
    background = BackgroundBlack,
    onBackground = White,
    surface = SurfaceBlack,
    onSurface = White,
    surfaceVariant = Charcoal,
    onSurfaceVariant = OffWhite,
    outline = ConcreteGrey
)

@Composable
fun MyApplicationTheme(
    content: @Composable () -> Unit,
) {
    MaterialTheme(
        colorScheme = AerospaceColorScheme,
        typography = Typography,
        content = content
    )
}
