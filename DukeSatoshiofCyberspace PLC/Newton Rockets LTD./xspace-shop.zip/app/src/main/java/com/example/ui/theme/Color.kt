package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val Black = Color(0xFF000000)
val DarkCharcoal = Color(0xFF0F0F0F)
val Charcoal = Color(0xFF1E1E1E)
val LightCharcoal = Color(0xFF2E2E2E)
val ConcreteGrey = Color(0xFF4E4E4E)
val SteelGrey = Color(0xFF8E8E93)
val OffWhite = Color(0xFFF5F5F7)
val White = Color(0xFFFFFFFF)
val AerospaceRed = Color(0xFFE01E22)
val BackgroundBlack = Color(0xFF050505)
val SurfaceBlack = Color(0xFF121212)

