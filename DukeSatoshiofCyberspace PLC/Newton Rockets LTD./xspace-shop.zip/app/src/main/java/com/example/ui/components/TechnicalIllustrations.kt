package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.ui.theme.*

@Composable
fun ProductIllustration(
    slug: String,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .background(DarkCharcoal)
            .border(1.dp, Charcoal)
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val width = size.width
            val height = size.height
            val centerX = width / 2
            val centerY = height / 2

            // Draw technical engineering grid lines
            val gridSpacing = 30f
            val gridStroke = Stroke(
                width = 1f,
                pathEffect = PathEffect.dashPathEffect(floatArrayOf(4f, 8f), 0f)
            )
            val gridColor = Color(0xFF1E1E1E)

            // Horizontal grid lines
            var y = 0f
            while (y < height) {
                drawLine(gridColor, Offset(0f, y), Offset(width, y), strokeWidth = 1f)
                y += gridSpacing
            }
            // Vertical grid lines
            var x = 0f
            while (x < width) {
                drawLine(gridColor, Offset(x, 0f), Offset(x, height), strokeWidth = 1f)
                x += gridSpacing
            }

            // Draw steel grey border accent line
            drawRect(
                color = SteelGrey.copy(alpha = 0.2f),
                topLeft = Offset(15f, 15f),
                size = Size(width - 30f, height - 30f),
                style = Stroke(width = 1.5f)
            )

            // Drawing selector based on product slug/type
            when {
                slug.contains("model") -> {
                    // Desktop rocket model
                    drawRocketModel(centerX, centerY, width, height, slug)
                }
                slug.contains("tee") || slug.contains("hoodie") || slug.contains("jacket") -> {
                    // Technical Apparel
                    drawTechnicalApparel(centerX, centerY, width, height, slug)
                }
                slug.contains("patch") -> {
                    // Mission Patch
                    drawMissionPatch(centerX, centerY, width, height, slug)
                }
                slug.contains("poster") || slug.contains("blueprint") -> {
                    // Blueprint Poster
                    drawTechnicalPoster(centerX, centerY, width, height, slug)
                }
                slug.contains("cap") -> {
                    // Mission Cap
                    drawTechnicalCap(centerX, centerY, width, height, slug)
                }
                slug.contains("mug") || slug.contains("bottle") -> {
                    // Industrial containers
                    drawIndustrialContainer(centerX, centerY, width, height, slug)
                }
                else -> {
                    // Default Accessory / Collectible (e.g. keychain, notebook, coin)
                    drawGenericAccessory(centerX, centerY, width, height, slug)
                }
            }
        }
    }
}

private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawRocketModel(
    centerX: Float,
    centerY: Float,
    width: Float,
    height: Float,
    slug: String
) {
    val strokeColor = White
    val accentColor = AerospaceRed
    val fillCol = SurfaceBlack

    // Draw stand base
    val baseW = width * 0.4f
    val baseH = 15f
    val baseY = height - 60f
    drawRoundRect(
        color = SteelGrey,
        topLeft = Offset(centerX - baseW / 2, baseY),
        size = Size(baseW, baseH),
        cornerRadius = CornerRadius(4f, 4f)
    )

    // Draw stand vertical rod
    drawLine(
        color = SteelGrey,
        start = Offset(centerX, baseY),
        end = Offset(centerX, centerY + 20f),
        strokeWidth = 6f
    )

    if (slug.contains("starship") || slug.contains("booster")) {
        // Draw Starship (Stainless steel sleek rocket)
        val rWidth = 40f
        val rHeight = height * 0.65f
        val rTop = centerY - rHeight / 2 - 20f

        // Rocket body outline
        drawRect(
            color = strokeColor,
            topLeft = Offset(centerX - rWidth / 2, rTop),
            size = Size(rWidth, rHeight),
            style = Stroke(width = 3f)
        )

        // Nosecone curve
        val nosePath = Path().apply {
            moveTo(centerX - rWidth / 2, rTop)
            cubicTo(
                centerX - rWidth / 2, rTop - rWidth * 1.5f,
                centerX + rWidth / 2, rTop - rWidth * 1.5f,
                centerX + rWidth / 2, rTop
            )
            close()
        }
        drawPath(nosePath, strokeColor, style = Stroke(width = 3f))

        // Grid fins (Starship top)
        drawLine(strokeColor, Offset(centerX - rWidth / 2, rTop + 30f), Offset(centerX - rWidth / 2 - 15f, rTop + 25f), strokeWidth = 3f)
        drawLine(strokeColor, Offset(centerX + rWidth / 2, rTop + 30f), Offset(centerX + rWidth / 2 + 15f, rTop + 25f), strokeWidth = 3f)

        // Bottom fins (Aft flaps)
        val leftFlap = Path().apply {
            moveTo(centerX - rWidth / 2, baseY - 60f)
            lineTo(centerX - rWidth / 2 - 25f, baseY - 40f)
            lineTo(centerX - rWidth / 2 - 20f, baseY - 10f)
            lineTo(centerX - rWidth / 2, baseY - 20f)
            close()
        }
        drawPath(leftFlap, strokeColor, style = Stroke(width = 3f))
        drawPath(leftFlap, fillCol)

        val rightFlap = Path().apply {
            moveTo(centerX + rWidth / 2, baseY - 60f)
            lineTo(centerX + rWidth / 2 + 25f, baseY - 40f)
            lineTo(centerX + rWidth / 2 + 20f, baseY - 10f)
            lineTo(centerX + rWidth / 2, baseY - 20f)
            close()
        }
        drawPath(rightFlap, strokeColor, style = Stroke(width = 3f))
        drawPath(rightFlap, fillCol)

        // Stage separation line
        val sepY = rTop + rHeight * 0.4f
        drawLine(strokeColor, Offset(centerX - rWidth / 2, sepY), Offset(centerX + rWidth / 2, sepY), strokeWidth = 2f)

        // USA flag/text accent (Aerospace red)
        drawLine(accentColor, Offset(centerX - 5f, sepY + 40f), Offset(centerX - 5f, sepY + 60f), strokeWidth = 2f)
        drawLine(accentColor, Offset(centerX + 5f, sepY + 40f), Offset(centerX + 5f, sepY + 60f), strokeWidth = 2f)

    } else if (slug.contains("falcon")) {
        // Draw Falcon 9 (Triple booster for heavy or single)
        val rWidth = 25f
        val rHeight = height * 0.6f
        val rTop = centerY - rHeight / 2 - 20f

        // Booster core
        drawRect(
            color = strokeColor,
            topLeft = Offset(centerX - rWidth / 2, rTop),
            size = Size(rWidth, rHeight),
            style = Stroke(width = 3f)
        )

        // Nose cap
        val capPath = Path().apply {
            moveTo(centerX - rWidth / 2, rTop)
            lineTo(centerX, rTop - 25f)
            lineTo(centerX + rWidth / 2, rTop)
            close()
        }
        drawPath(capPath, strokeColor, style = Stroke(width = 3f))

        // Side boosters (Falcon Heavy)
        if (slug.contains("heavy")) {
            drawRect(
                color = strokeColor,
                topLeft = Offset(centerX - rWidth / 2 - rWidth - 4f, rTop + 20f),
                size = Size(rWidth, rHeight - 40f),
                style = Stroke(width = 2f)
            )
            drawRect(
                color = strokeColor,
                topLeft = Offset(centerX + rWidth / 2 + 4f, rTop + 20f),
                size = Size(rWidth, rHeight - 40f),
                style = Stroke(width = 2f)
            )
        }

        // Grid fins
        drawLine(strokeColor, Offset(centerX - rWidth / 2, rTop + 45f), Offset(centerX - rWidth / 2 - 12f, rTop + 45f), strokeWidth = 2f)
        drawLine(strokeColor, Offset(centerX + rWidth / 2, rTop + 45f), Offset(centerX + rWidth / 2 + 12f, rTop + 45f), strokeWidth = 2f)

        // Landing legs (folded)
        val leftLeg = Path().apply {
            moveTo(centerX - rWidth / 2, baseY - 50f)
            lineTo(centerX - rWidth / 2 - 10f, baseY - 20f)
            lineTo(centerX - rWidth / 2, baseY - 15f)
        }
        drawPath(leftLeg, strokeColor, style = Stroke(width = 2f))

        val rightLeg = Path().apply {
            moveTo(centerX + rWidth / 2, baseY - 50f)
            lineTo(centerX + rWidth / 2 + 10f, baseY - 20f)
            lineTo(centerX + rWidth / 2, baseY - 15f)
        }
        drawPath(rightLeg, strokeColor, style = Stroke(width = 2f))
    } else {
        // Dragon Spacecraft
        val rWidth = 80f
        val rHeight = height * 0.4f
        val rTop = centerY - rHeight / 2

        // Main cabin
        val capsulePath = Path().apply {
            moveTo(centerX - rWidth / 2, rTop + rHeight)
            lineTo(centerX - rWidth * 0.4f, rTop + 30f)
            lineTo(centerX - rWidth * 0.15f, rTop)
            lineTo(centerX + rWidth * 0.15f, rTop)
            lineTo(centerX + rWidth * 0.4f, rTop + 30f)
            lineTo(centerX + rWidth / 2, rTop + rHeight)
            close()
        }
        drawPath(capsulePath, strokeColor, style = Stroke(width = 3f))
        drawPath(capsulePath, fillCol)

        // Solar panel details
        drawRect(
            color = strokeColor,
            topLeft = Offset(centerX - rWidth / 2 + 10f, rTop + rHeight * 0.6f),
            size = Size(rWidth - 20f, rHeight * 0.3f),
            style = Stroke(width = 1.5f)
        )
        // Red accent indicator window
        drawCircle(accentColor, 4f, Offset(centerX, rTop + rHeight * 0.4f))
    }
}

private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawTechnicalApparel(
    centerX: Float,
    centerY: Float,
    width: Float,
    height: Float,
    slug: String
) {
    val strokeColor = White
    val accentColor = AerospaceRed
    val designStrokeColor = SteelGrey.copy(alpha = 0.8f)

    // Outline a classic minimalist t-shirt blueprint layout
    val path = Path().apply {
        // Neck opening
        moveTo(centerX - 35f, centerY - 80f)
        quadraticTo(centerX, centerY - 65f, centerX + 35f, centerY - 80f)
        // Shoulder right
        lineTo(centerX + 75f, centerY - 65f)
        // Sleeve right
        lineTo(centerX + 110f, centerY - 25f)
        lineTo(centerX + 85f, centerY + 0f)
        lineTo(centerX + 65f, centerY - 15f)
        // Underarm right down to bottom
        lineTo(centerX + 65f, centerY + 90f)
        // Bottom opening
        lineTo(centerX - 65f, centerY + 90f)
        // Underarm left up to sleeve
        lineTo(centerX - 65f, centerY - 15f)
        lineTo(centerX - 85f, centerY + 0f)
        lineTo(centerX - 110f, centerY - 25f)
        // Shoulder left
        lineTo(centerX - 75f, centerY - 65f)
        close()
    }

    // Fill with solid Charcoal background of shirt
    drawPath(path, color = Charcoal)
    // Draw technical outline
    drawPath(path, color = strokeColor, style = Stroke(width = 3f))

    // Stitch lines inside sleeves and bottom
    val stitchPathEffect = PathEffect.dashPathEffect(floatArrayOf(4f, 4f), 0f)
    drawLine(
        color = SteelGrey,
        start = Offset(centerX + 85f, centerY + 0f),
        end = Offset(centerX + 65f, centerY - 15f),
        strokeWidth = 1f,
        pathEffect = stitchPathEffect
    )
    drawLine(
        color = SteelGrey,
        start = Offset(centerX - 85f, centerY + 0f),
        end = Offset(centerX - 65f, centerY - 15f),
        strokeWidth = 1f,
        pathEffect = stitchPathEffect
    )
    drawLine(
        color = SteelGrey,
        start = Offset(centerX - 63f, centerY + 85f),
        end = Offset(centerX + 63f, centerY + 85f),
        strokeWidth = 1f,
        pathEffect = stitchPathEffect
    )

    // Draw visual blueprint graphic on chest/back of apparel
    if (slug.contains("starship")) {
        // Draw miniature Starship rocket drawing on center chest
        val startY = centerY - 40f
        drawLine(designStrokeColor, Offset(centerX, startY), Offset(centerX, startY + 60f), strokeWidth = 2f)
        drawCircle(accentColor, 3f, Offset(centerX, startY))
        drawCircle(strokeColor, 2f, Offset(centerX, startY + 20f))
        drawCircle(strokeColor, 2f, Offset(centerX, startY + 40f))
    } else if (slug.contains("falcon")) {
        // Draw grid fin icon
        drawRect(
            color = designStrokeColor,
            topLeft = Offset(centerX - 12f, centerY - 20f),
            size = Size(24f, 24f),
            style = Stroke(width = 1.5f)
        )
        drawLine(designStrokeColor, Offset(centerX - 12f, centerY - 8f), Offset(centerX + 12f, centerY - 8f), strokeWidth = 1f)
        drawLine(designStrokeColor, Offset(centerX, centerY - 20f), Offset(centerX, centerY + 4f), strokeWidth = 1f)
        drawCircle(accentColor, 3f, Offset(centerX, centerY - 20f))
    } else if (slug.contains("control")) {
        // Minimalist console panel graphics
        drawRect(
            color = designStrokeColor,
            topLeft = Offset(centerX - 25f, centerY - 25f),
            size = Size(50f, 30f),
            style = Stroke(width = 1.5f)
        )
        drawLine(accentColor, Offset(centerX - 20f, centerY - 10f), Offset(centerX + 20f, centerY - 10f), strokeWidth = 1.5f)
    } else {
        // Draw clean minimalist emblem (X)
        drawLine(strokeColor, Offset(centerX - 15f, centerY - 15f), Offset(centerX + 15f, centerY + 15f), strokeWidth = 3f)
        drawLine(strokeColor, Offset(centerX + 15f, centerY - 15f), Offset(centerX - 15f, centerY + 15f), strokeWidth = 3f)
        drawCircle(accentColor, 4f, Offset(centerX, centerY))
    }
}

private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawMissionPatch(
    centerX: Float,
    centerY: Float,
    width: Float,
    height: Float,
    slug: String
) {
    val strokeColor = White
    val accentColor = AerospaceRed
    val radius = width * 0.33f

    // Draw patch backing
    drawCircle(color = SurfaceBlack, radius = radius, center = Offset(centerX, centerY))
    drawCircle(color = strokeColor, radius = radius, center = Offset(centerX, centerY), style = Stroke(width = 4f))

    // Inner embroidered ring
    drawCircle(
        color = SteelGrey,
        radius = radius - 12f,
        center = Offset(centerX, centerY),
        style = Stroke(width = 1.5f, pathEffect = PathEffect.dashPathEffect(floatArrayOf(4f, 4f), 0f))
    )

    // Render astronomical objects inside
    if (slug.contains("mars")) {
        // Draw Red Planet Mars
        drawCircle(accentColor, radius * 0.4f, Offset(centerX, centerY))
        // Draw small moon Phobos
        drawCircle(White, 4f, Offset(centerX - radius * 0.5f, centerY - radius * 0.2f))
    } else if (slug.contains("lunar")) {
        // Draw Crescent Moon
        val moonPath = Path().apply {
            addArc(
                oval = Size(radius, radius).let {
                    androidx.compose.ui.geometry.Rect(centerX - radius / 2, centerY - radius / 2, centerX + radius / 2, centerY + radius / 2)
                },
                startAngleDegrees = 0f,
                sweepAngleDegrees = 180f
            )
        }
        drawPath(moonPath, strokeColor, style = Stroke(width = 2f))
    } else {
        // Orbital trajectory (Constellation loop)
        val orbitPath = Path().apply {
            moveTo(centerX - radius * 0.7f, centerY + radius * 0.2f)
            quadraticTo(
                centerX, centerY - radius * 0.8f,
                centerX + radius * 0.7f, centerY + radius * 0.2f
            )
            quadraticTo(
                centerX, centerY + radius * 0.8f,
                centerX - radius * 0.7f, centerY + radius * 0.2f
            )
        }
        drawPath(orbitPath, strokeColor, style = Stroke(width = 2f))
        
        // Stars
        drawCircle(White, 3f, Offset(centerX - 20f, centerY - 30f))
        drawCircle(White, 2f, Offset(centerX + 40f, centerY - 20f))
        drawCircle(accentColor, 3f, Offset(centerX + 10f, centerY + 30f))
    }
}

private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawTechnicalPoster(
    centerX: Float,
    centerY: Float,
    width: Float,
    height: Float,
    slug: String
) {
    val strokeColor = White
    val accentColor = AerospaceRed

    // Blueprint frame
    drawRect(
        color = SteelGrey,
        topLeft = Offset(30f, 30f),
        size = Size(width - 60f, height - 60f),
        style = Stroke(width = 2f)
    )

    // Blueprint blueprint schematic drawings
    val linesY = height * 0.55f
    drawLine(
        color = SteelGrey,
        start = Offset(45f, linesY),
        end = Offset(width - 45f, linesY),
        strokeWidth = 1f
    )

    // Draw side bar division
    drawLine(
        color = SteelGrey,
        start = Offset(width * 0.75f, linesY),
        end = Offset(width * 0.75f, height - 45f),
        strokeWidth = 1f
    )

    // Render a simplified multi-view rocket profile
    val rx = centerX
    val ry = centerY - 45f
    val rw = 30f
    val rh = 120f

    // Nosecone
    val nose = Path().apply {
        moveTo(rx - rw / 2, ry - rh / 2)
        quadraticTo(rx, ry - rh / 2 - 30f, rx + rw / 2, ry - rh / 2)
        close()
    }
    drawPath(nose, strokeColor, style = Stroke(width = 2f))

    // Core body
    drawRect(
        color = strokeColor,
        topLeft = Offset(rx - rw / 2, ry - rh / 2),
        size = Size(rw, rh),
        style = Stroke(width = 2f)
    )

    // Interstage line
    drawLine(strokeColor, Offset(rx - rw / 2, ry), Offset(rx + rw / 2, ry), strokeWidth = 1.5f)

    // Thrust vector indicators (red arrows)
    drawLine(accentColor, Offset(rx, ry + rh / 2 + 10f), Offset(rx, ry + rh / 2 + 35f), strokeWidth = 2f)
    drawLine(accentColor, Offset(rx - 8f, ry + rh / 2 + 10f), Offset(rx - 8f, ry + rh / 2 + 25f), strokeWidth = 2f)
    drawLine(accentColor, Offset(rx + 8f, ry + rh / 2 + 10f), Offset(rx + 8f, ry + rh / 2 + 25f), strokeWidth = 2f)
}

private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawTechnicalCap(
    centerX: Float,
    centerY: Float,
    width: Float,
    height: Float,
    slug: String
) {
    val strokeColor = White
    val accentColor = AerospaceRed

    // Cap crown outline
    val crownPath = Path().apply {
        moveTo(centerX - 80f, centerY + 30f)
        cubicTo(
            centerX - 80f, centerY - 70f,
            centerX + 80f, centerY - 70f,
            centerX + 80f, centerY + 30f
        )
        close()
    }
    drawPath(crownPath, strokeColor, style = Stroke(width = 3f))
    drawPath(crownPath, SurfaceBlack)

    // Visor / Bill
    val billPath = Path().apply {
        moveTo(centerX + 60f, centerY + 15f)
        quadraticTo(
            centerX + 110f, centerY + 25f,
            centerX + 125f, centerY + 45f
        )
        quadraticTo(
            centerX + 70f, centerY + 50f,
            centerX + 30f, centerY + 30f
        )
    }
    drawPath(billPath, strokeColor, style = Stroke(width = 3f))
    drawPath(billPath, Charcoal)

    // Adjustment strap back
    drawArc(
        color = SteelGrey,
        startAngleDegrees = 90f,
        sweepAngleDegrees = 60f,
        useCenter = false,
        topLeft = Offset(centerX - 85f, centerY + 15f),
        size = Size(30f, 30f),
        style = Stroke(width = 2f)
    )

    // Accent button on top
    drawCircle(accentColor, 6f, Offset(centerX, centerY - 45f))
}

private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawIndustrialContainer(
    centerX: Float,
    centerY: Float,
    width: Float,
    height: Float,
    slug: String
) {
    val strokeColor = White
    val accentColor = AerospaceRed

    val bWidth = 60f
    val bHeight = 150f
    val bTop = centerY - bHeight / 2

    // Main steel container body
    drawRoundRect(
        color = strokeColor,
        topLeft = Offset(centerX - bWidth / 2, bTop),
        size = Size(bWidth, bHeight),
        cornerRadius = CornerRadius(6f, 6f),
        style = Stroke(width = 3f)
    )

    // Container cap
    drawRect(
        color = SteelGrey,
        topLeft = Offset(centerX - bWidth / 4, bTop - 18f),
        size = Size(bWidth / 2, 18f),
        style = Stroke(width = 2f)
    )

    // Horizontal mechanical rib lines
    drawLine(strokeColor, Offset(centerX - bWidth / 2, bTop + 35f), Offset(centerX + bWidth / 2, bTop + 35f), strokeWidth = 1.5f)
    drawLine(strokeColor, Offset(centerX - bWidth / 2, bTop + 110f), Offset(centerX + bWidth / 2, bTop + 110f), strokeWidth = 1.5f)

    // Lock latch (red)
    drawRect(
        color = accentColor,
        topLeft = Offset(centerX - 6f, bTop - 10f),
        size = Size(12f, 12f)
    )
}

private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawGenericAccessory(
    centerX: Float,
    centerY: Float,
    width: Float,
    height: Float,
    slug: String
) {
    val strokeColor = White
    val accentColor = AerospaceRed

    if (slug.contains("notebook")) {
        // Engineering notebook
        val nW = 100f
        val nH = 130f
        val nL = centerX - nW / 2
        val nT = centerY - nH / 2

        drawRect(
            color = strokeColor,
            topLeft = Offset(nL, nT),
            size = Size(nW, nH),
            style = Stroke(width = 3f)
        )
        // Cover binder lines
        drawLine(strokeColor, Offset(nL + 15f, nT), Offset(nL + 15f, nT + nH), strokeWidth = 1.5f)

        // Title block box
        drawRect(
            color = SteelGrey,
            topLeft = Offset(nL + 30f, nT + 30f),
            size = Size(50f, 30f),
            style = Stroke(width = 1f)
        )
        // Red accent tag
        drawLine(accentColor, Offset(nL + 40f, nT + 40f), Offset(nL + 70f, nT + 40f), strokeWidth = 2f)
    } else {
        // Keychain / Commemorative coin
        drawCircle(color = SteelGrey, radius = 50f, center = Offset(centerX, centerY), style = Stroke(width = 3f))
        drawCircle(color = SurfaceBlack, radius = 47f, center = Offset(centerX, centerY))

        // Center star
        val starPath = Path().apply {
            moveTo(centerX, centerY - 25f)
            lineTo(centerX + 8f, centerY - 8f)
            lineTo(centerX + 25f, centerY - 5f)
            lineTo(centerX + 12f, centerY + 8f)
            lineTo(centerX + 15f, centerY + 25f)
            lineTo(centerX, centerY + 15f)
            lineTo(centerX - 15f, centerY + 25f)
            lineTo(centerX - 12f, centerY + 8f)
            lineTo(centerX - 25f, centerY - 5f)
            lineTo(centerX - 8f, centerY - 8f)
            close()
        }
        drawPath(starPath, accentColor)
        drawPath(starPath, strokeColor, style = Stroke(width = 1.5f))
    }
}
