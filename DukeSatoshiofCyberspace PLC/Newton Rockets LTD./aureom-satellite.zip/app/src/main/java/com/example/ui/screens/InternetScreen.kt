package com.example.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.SpeedTestResult
import com.example.data.model.TelemetryState
import com.example.ui.theme.AureomBorder
import com.example.ui.theme.AureomCyanPrimary
import com.example.ui.theme.AureomEmeraldSuccess
import com.example.ui.theme.AureomGraphite
import com.example.ui.theme.AureomSkyBlue
import com.example.ui.theme.AureomSlateCard
import com.example.ui.theme.AureomTextMuted
import com.example.ui.theme.AureomWhite

@Composable
fun InternetScreen(
    telemetry: TelemetryState,
    speedTest: SpeedTestResult,
    onStartSpeedTest: () -> Unit,
    modifier: Modifier = Modifier
) {
    LazyColumn(
        modifier = modifier
            .fillMaxWidth()
            .padding(16.dp)
            .testTag("internet_screen"),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Test Trigger Bar
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(AureomGraphite)
                    .border(1.dp, AureomBorder, RoundedCornerShape(12.dp))
                    .padding(16.dp)
            ) {
                Text(
                    text = "INTERNET DIAGNOSTICS & SPEED TEST",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold
                    ),
                    color = AureomWhite
                )

                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = onStartSpeedTest,
                        enabled = !speedTest.isRunning,
                        modifier = Modifier
                            .weight(1f)
                            .height(42.dp)
                            .testTag("run_speed_test_button"),
                        colors = ButtonDefaults.buttonColors(containerColor = AureomCyanPrimary, contentColor = AureomGraphite),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text("RUN SPEED TEST", fontWeight = FontWeight.Bold, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                    }

                    OutlinedButton(
                        onClick = onStartSpeedTest,
                        enabled = !speedTest.isRunning,
                        modifier = Modifier
                            .weight(1f)
                            .height(42.dp)
                            .testTag("run_latency_test_button"),
                        border = androidx.compose.foundation.BorderStroke(1.dp, AureomBorder),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text("RUN LATENCY TEST", fontSize = 11.sp, color = AureomWhite, fontFamily = FontFamily.Monospace)
                    }
                }
            }
        }

        // Live Speed Test Progress & Graph
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(AureomSlateCard)
                    .border(1.dp, AureomCyanPrimary.copy(alpha = 0.5f), RoundedCornerShape(12.dp))
                    .padding(16.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (speedTest.isRunning) "THROUGHPUT TEST IN PROGRESS..." else "LATEST NETWORK PERFORMANCE",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold
                        ),
                        color = AureomCyanPrimary
                    )

                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(AureomGraphite)
                            .border(1.dp, AureomBorder, RoundedCornerShape(4.dp))
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = "SIMULATED TEST",
                            style = MaterialTheme.typography.labelMedium.copy(fontSize = 10.sp, fontWeight = FontWeight.Bold),
                            color = AureomSkyBlue
                        )
                    }
                }

                if (speedTest.isRunning) {
                    Spacer(modifier = Modifier.height(10.dp))
                    LinearProgressIndicator(
                        progress = { speedTest.progressPct / 100f },
                        modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)),
                        color = AureomCyanPrimary,
                        trackColor = AureomGraphite
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Stats Row: Peak, Avg, Min, P95
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    StatPill("PEAK", "${speedTest.downloadPeakMbps.toInt()} Mbps")
                    StatPill("AVERAGE", "${speedTest.downloadAvgMbps.toInt()} Mbps")
                    StatPill("MINIMUM", "${speedTest.downloadMinMbps.toInt()} Mbps")
                    StatPill("P95", "${speedTest.downloadP95Mbps.toInt()} Mbps")
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Live Mbps vs Time Graph Canvas
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(140.dp)
                        .background(AureomGraphite, RoundedCornerShape(8.dp))
                        .border(1.dp, AureomBorder, RoundedCornerShape(8.dp))
                        .padding(12.dp)
                ) {
                    Canvas(modifier = Modifier.matchParentSize()) {
                        val samples = speedTest.samples
                        if (samples.size >= 2) {
                            val maxSpeed = samples.maxOf { it.second }.coerceAtLeast(100f)
                            val path = Path()
                            val widthStep = size.width / (samples.size - 1)

                            samples.forEachIndexed { index, pair ->
                                val x = index * widthStep
                                val y = size.height - ((pair.second / maxSpeed) * size.height)
                                if (index == 0) path.moveTo(x, y) else path.lineTo(x, y)
                            }

                            drawPath(
                                path = path,
                                color = AureomCyanPrimary,
                                style = Stroke(width = 4f)
                            )
                        } else {
                            // Baseline axis
                            drawLine(
                                color = AureomBorder,
                                start = Offset(0f, size.height - 10f),
                                end = Offset(size.width, size.height - 10f),
                                strokeWidth = 2f
                            )
                        }
                    }
                }
            }
        }

        // ISP Core Network Abstraction Metrics
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(AureomGraphite)
                    .border(1.dp, AureomBorder, RoundedCornerShape(12.dp))
                    .padding(16.dp)
            ) {
                Text(
                    text = "ISP NETWORK STACK & ROUTING ABSTRACTION",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold
                    ),
                    color = AureomWhite
                )

                Spacer(modifier = Modifier.height(12.dp))

                Row(modifier = Modifier.fillMaxWidth()) {
                    NetField("IPv4 ADDRESS", telemetry.publicIpV4, Modifier.weight(1f))
                    NetField("IPv6 SUBNET", telemetry.publicIpV6, Modifier.weight(1f))
                }
                Spacer(modifier = Modifier.height(10.dp))
                Row(modifier = Modifier.fillMaxWidth()) {
                    NetField("PRIMARY DNS", telemetry.dnsPrimary, Modifier.weight(1f))
                    NetField("NAT TYPE", telemetry.natType, Modifier.weight(1f))
                }
                Spacer(modifier = Modifier.height(10.dp))
                Row(modifier = Modifier.fillMaxWidth()) {
                    NetField("DHCP SUBNET", "192.168.1.0/24", Modifier.weight(1f))
                    NetField("QOS PROFILE", telemetry.qosPolicy, Modifier.weight(1f))
                }
            }
        }
    }
}

@Composable
private fun StatPill(label: String, value: String) {
    Column {
        Text(text = label, style = MaterialTheme.typography.labelMedium.copy(fontSize = 10.sp), color = AureomTextMuted)
        Text(text = value, style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace), color = AureomWhite)
    }
}

@Composable
private fun NetField(label: String, value: String, modifier: Modifier = Modifier) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(6.dp))
            .background(AureomSlateCard)
            .padding(10.dp)
    ) {
        Text(text = label, style = MaterialTheme.typography.labelMedium.copy(fontSize = 9.sp), color = AureomTextMuted)
        Text(text = value, style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace), color = AureomCyanPrimary)
    }
}
