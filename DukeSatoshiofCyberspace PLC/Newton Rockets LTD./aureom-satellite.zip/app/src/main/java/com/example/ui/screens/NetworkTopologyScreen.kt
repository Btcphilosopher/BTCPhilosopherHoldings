package com.example.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.data.model.TelemetryState
import com.example.ui.components.NetworkTopologyCanvas

@Composable
fun NetworkTopologyScreen(
    telemetry: TelemetryState,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(16.dp)
            .testTag("network_topology_screen"),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        NetworkTopologyCanvas(telemetry = telemetry)
    }
}
