package com.example.data.model

enum class UserRole {
    CUSTOMER,
    TECHNICIAN,
    NETWORK_OPERATOR,
    ADMIN
}

enum class TerminalStatus {
    ONLINE,
    CONNECTING,
    STOWED,
    DEGRADED,
    OFFLINE
}

enum class LinkStatus {
    LOCKED,
    TRACKING,
    SEARCHING,
    DEGRADED,
    DISCONNECTED
}

enum class StageStatus {
    PASS,
    WARNING,
    FAIL
}

data class TelemetryState(
    val timestamp: Long = System.currentTimeMillis(),
    val terminalId: String = "AUR-8820-9941-UK",
    val serialNumber: String = "AUR-8820-9941-UK",
    val satelliteId: String = "AUREOM-1042",
    val nextSatelliteId: String = "AUREOM-1077",
    val handoverCountdownSec: Int = 42,
    val linkQualityPct: Int = 94,
    val gatewayId: String = "LONDON-01",
    val gatewayName: String = "London Primary Gateway (UK-01)",
    val signalDb: Double = -68.4,
    val snrDb: Double = 16.2,
    val downlinkMbps: Double = 412.5,
    val uplinkMbps: Double = 48.2,
    val latencyMs: Int = 23,
    val jitterMs: Int = 2,
    val packetLossPct: Double = 0.02,
    val packetErrorRatePct: Double = 0.001,
    val temperatureC: Double = 41.5,
    val powerW: Double = 112.0,
    val uptimeDays: Int = 18,
    val firmwareVersion: String = "v4.18.2-sp1",
    val stagedFirmwareVersion: String = "v4.19.0-rc2",
    val isFirmwareStaged: Boolean = true,
    val isUpdatingFirmware: Boolean = false,
    val firmwareUpdateProgressPct: Int = 0,
    val terminalStatus: TerminalStatus = TerminalStatus.ONLINE,
    val linkStatus: LinkStatus = LinkStatus.LOCKED,
    val antennaState: String = "TRACKING (PHASED ARRAY)",
    val azimuthDeg: Double = 142.5,
    val elevationDeg: Double = 68.2,
    val modulationMcs: String = "256-APSK 3/4",
    val eirpDbw: Double = 45.2,
    val pathLossDb: Double = 172.4,
    val linkMarginDb: Double = 4.8,
    val dopplerShiftKhz: Double = +14.2,
    val publicIpV4: String = "185.220.101.42",
    val publicIpV6: String = "2a01:4f8:10a:1f32::1",
    val dnsPrimary: String = "1.1.1.1 (Aureom Secure Anycast)",
    val dnsSecondary: String = "8.8.8.8",
    val subnetMask: String = "255.255.255.0",
    val natType: String = "Full Cone NAT (CGNAT)",
    val qosPolicy: String = "Aureom Home Standard QoS",
    val isSimulatedMode: Boolean = true
)

data class ServicePlan(
    val id: String,
    val name: String,
    val priceMonthlyGbp: Double,
    val downloadMbps: String,
    val uploadMbps: String,
    val priorityLevel: String,
    val dataPolicy: String,
    val SLA: String,
    val features: List<String>
)

data class NetworkNodeInfo(
    val id: String,
    val name: String,
    val type: String, // CLIENT, TERMINAL, SATELLITE, GATEWAY, CORE, INTERNET
    val status: String, // UP, DEGRADED, DOWN
    val latencyMs: Int,
    val throughputMbps: Double,
    val packetLossPct: Double,
    val uptimePct: Double,
    val details: String
)

data class DiagnosticStage(
    val name: String,
    val status: StageStatus,
    val latencyMs: Int,
    val measuredReason: String
)

data class DiagnosticReport(
    val timestamp: Long = System.currentTimeMillis(),
    val overallStatus: StageStatus,
    val summary: String,
    val stages: List<DiagnosticStage>
)

data class UsageMetrics(
    val todayGb: Double = 14.8,
    val thisWeekGb: Double = 92.4,
    val thisMonthGb: Double = 348.6,
    val categoryBreakdown: Map<String, Double> = mapOf(
        "Streaming (4K/HD)" to 164.2,
        "Work & VPN" to 82.5,
        "Gaming & Voice" to 44.1,
        "Cloud & Backups" to 38.0,
        "Web & Social" to 19.8
    )
)

data class SpeedTestResult(
    val isRunning: Boolean = false,
    val progressPct: Int = 0,
    val currentMbps: Double = 0.0,
    val downloadPeakMbps: Double = 0.0,
    val downloadAvgMbps: Double = 0.0,
    val downloadMinMbps: Double = 0.0,
    val downloadP95Mbps: Double = 0.0,
    val uploadPeakMbps: Double = 0.0,
    val uploadAvgMbps: Double = 0.0,
    val uploadMinMbps: Double = 0.0,
    val uploadP95Mbps: Double = 0.0,
    val latencyMs: Int = 0,
    val jitterMs: Int = 0,
    val packetLossPct: Double = 0.0,
    val samples: List<Pair<Float, Float>> = emptyList() // (timeSec, mbps)
)
