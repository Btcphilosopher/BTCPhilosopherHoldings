package com.example.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import com.example.ui.components.AureomHeader
import com.example.ui.components.AureomNavBar
import com.example.ui.screens.DiagnosticsScreen
import com.example.ui.screens.EngineeringNocScreen
import com.example.ui.screens.InternetScreen
import com.example.ui.screens.NetworkTopologyScreen
import com.example.ui.screens.OverviewScreen
import com.example.ui.screens.PlanBillingScreen
import com.example.ui.screens.SettingsFirmwareScreen
import com.example.ui.screens.TerminalScreen
import com.example.ui.screens.UsageScreen
import com.example.ui.screens.WifiLanScreen
import com.example.ui.theme.AureomNavyDark

@Composable
fun AureomApp(
    viewModel: AureomViewModel,
    modifier: Modifier = Modifier
) {
    val telemetry by viewModel.telemetryState.collectAsState()
    val role by viewModel.currentRole.collectAsState()
    val currentTab by viewModel.currentTab.collectAsState()
    val selectedPlanId by viewModel.selectedPlanId.collectAsState()
    val speedTest by viewModel.speedTestState.collectAsState()
    val wifiSsid by viewModel.wifiSsid.collectAsState()
    val guestEnabled by viewModel.guestWifiEnabled.collectAsState()
    val devices by viewModel.devicesState.collectAsState()
    val invoices by viewModel.invoicesState.collectAsState()
    val diagnosticReport by viewModel.lastDiagnosticReport.collectAsState()
    val isUpdatingFirmware by viewModel.isFirmwareUpdating.collectAsState()
    val firmwareProgress by viewModel.firmwareProgress.collectAsState()

    Scaffold(
        modifier = modifier
            .fillMaxSize()
            .testTag("aureom_app_scaffold"),
        containerColor = AureomNavyDark
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(AureomNavyDark)
        ) {
            // Header Bar with Brand & Role
            AureomHeader(
                telemetry = telemetry,
                currentRole = role,
                onRoleChanged = { viewModel.setRole(it) }
            )

            // Scrollable Navigation Bar
            AureomNavBar(
                selectedTab = currentTab,
                onTabSelected = { viewModel.selectTab(it) }
            )

            // Content Area for active Tab
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
            ) {
                when (currentTab) {
                    AureomTab.OVERVIEW -> OverviewScreen(
                        telemetry = telemetry,
                        onNavigateTab = { viewModel.selectTab(it) },
                        onRunTest = { viewModel.startSpeedTest() }
                    )
                    AureomTab.INTERNET -> InternetScreen(
                        telemetry = telemetry,
                        speedTest = speedTest,
                        onStartSpeedTest = { viewModel.startSpeedTest() }
                    )
                    AureomTab.TERMINAL -> TerminalScreen(
                        telemetry = telemetry
                    )
                    AureomTab.NETWORK -> NetworkTopologyScreen(
                        telemetry = telemetry
                    )
                    AureomTab.DIAGNOSTICS -> DiagnosticsScreen(
                        telemetry = telemetry,
                        report = diagnosticReport,
                        onRunDiagnostics = { viewModel.runDiagnostics() }
                    )
                    AureomTab.USAGE -> UsageScreen(
                        usage = viewModel.usageMetrics
                    )
                    AureomTab.PLAN_BILLING -> PlanBillingScreen(
                        plans = viewModel.availablePlans,
                        selectedPlanId = selectedPlanId,
                        invoices = invoices,
                        onSelectPlan = { viewModel.selectPlan(it) }
                    )
                    AureomTab.WIFI_LAN -> WifiLanScreen(
                        devices = devices,
                        wifiSsid = wifiSsid,
                        guestEnabled = guestEnabled,
                        onUpdateSsid = { viewModel.updateWifiSsid(it) },
                        onToggleGuest = { viewModel.toggleGuestWifi(it) },
                        onTogglePauseDevice = { mac, paused -> viewModel.toggleDevicePause(mac, paused) }
                    )
                    AureomTab.ENGINEERING_NOC -> EngineeringNocScreen(
                        telemetry = telemetry
                    )
                    AureomTab.SETTINGS_FIRMWARE -> SettingsFirmwareScreen(
                        telemetry = telemetry,
                        isUpdating = isUpdatingFirmware,
                        progress = firmwareProgress,
                        onExecuteUpdate = { viewModel.executeFirmwareUpdate() }
                    )
                }
            }
        }
    }
}
