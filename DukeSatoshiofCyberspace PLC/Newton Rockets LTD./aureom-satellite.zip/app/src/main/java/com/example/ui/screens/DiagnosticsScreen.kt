package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.DiagnosticReport
import com.example.data.model.StageStatus
import com.example.data.model.TelemetryState
import com.example.ui.theme.AureomAmberWarning
import com.example.ui.theme.AureomBorder
import com.example.ui.theme.AureomCyanPrimary
import com.example.ui.theme.AureomEmeraldSuccess
import com.example.ui.theme.AureomGraphite
import com.example.ui.theme.AureomRedError
import com.example.ui.theme.AureomSlateCard
import com.example.ui.theme.AureomTextMuted
import com.example.ui.theme.AureomWhite

@Composable
fun DiagnosticsScreen(
    telemetry: TelemetryState,
    report: DiagnosticReport?,
    onRunDiagnostics: () -> Unit,
    modifier: Modifier = Modifier
) {
    LazyColumn(
        modifier = modifier
            .fillMaxWidth()
            .padding(16.dp)
            .testTag("diagnostics_screen"),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Trigger Box
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(AureomGraphite)
                    .border(1.dp, AureomBorder, RoundedCornerShape(12.dp))
                    .padding(16.dp)
            ) {
                Text(
                    text = "AUREOM OUTAGE DETECTION & GUIDED DIAGNOSTICS",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold
                    ),
                    color = AureomWhite
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Executes an automated 5-stage root-cause diagnostic sweep across RF, Gateway, and Core ISP layers.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = AureomTextMuted
                )

                Spacer(modifier = Modifier.height(16.dp))

                Button(
                    onClick = onRunDiagnostics,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("run_diagnostics_sweep_button"),
                    colors = ButtonDefaults.buttonColors(containerColor = AureomCyanPrimary, contentColor = AureomGraphite),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Icon(imageVector = Icons.Default.PlayArrow, contentDescription = "Run Sweep")
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "RUN DIAGNOSTIC SWEEP",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    )
                }
            }
        }

        // Diagnostic Report Summary
        if (report != null) {
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(AureomSlateCard)
                        .border(1.dp, AureomCyanPrimary.copy(alpha = 0.5f), RoundedCornerShape(12.dp))
                        .padding(16.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "DIAGNOSTIC REASONING SUMMARY",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold
                            ),
                            color = AureomCyanPrimary
                        )

                        StatusBadge(report.overallStatus)
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = report.summary,
                        style = MaterialTheme.typography.bodyLarge.copy(
                            fontWeight = FontWeight.SemiBold,
                            fontFamily = FontFamily.Monospace
                        ),
                        color = AureomWhite
                    )
                }
            }

            // Diagnostic Chain Stages
            items(report.stages.size) { idx ->
                val stage = report.stages[idx]
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(AureomGraphite)
                        .border(1.dp, AureomBorder, RoundedCornerShape(8.dp))
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(32.dp)
                            .clip(CircleShape)
                            .background(
                                when (stage.status) {
                                    StageStatus.PASS -> AureomEmeraldSuccess.copy(alpha = 0.2f)
                                    StageStatus.WARNING -> AureomAmberWarning.copy(alpha = 0.2f)
                                    StageStatus.FAIL -> AureomRedError.copy(alpha = 0.2f)
                                }
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = when (stage.status) {
                                StageStatus.PASS -> Icons.Default.CheckCircle
                                StageStatus.WARNING -> Icons.Default.Warning
                                StageStatus.FAIL -> Icons.Default.Error
                            },
                            contentDescription = stage.name,
                            tint = when (stage.status) {
                                StageStatus.PASS -> AureomEmeraldSuccess
                                StageStatus.WARNING -> AureomAmberWarning
                                StageStatus.FAIL -> AureomRedError
                            },
                            modifier = Modifier.size(20.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    Column(modifier = Modifier.weight(1f)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "STAGE ${idx + 1}: ${stage.name}",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp,
                                    fontFamily = FontFamily.Monospace
                                ),
                                color = AureomWhite
                            )
                            Text(
                                text = "${stage.latencyMs} ms",
                                style = MaterialTheme.typography.labelMedium,
                                color = AureomTextMuted
                            )
                        }

                        Spacer(modifier = Modifier.height(4.dp))

                        Text(
                            text = stage.measuredReason,
                            style = MaterialTheme.typography.bodyMedium,
                            color = AureomTextMuted
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun StatusBadge(status: StageStatus) {
    val color = when (status) {
        StageStatus.PASS -> AureomEmeraldSuccess
        StageStatus.WARNING -> AureomAmberWarning
        StageStatus.FAIL -> AureomRedError
    }
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(12.dp))
            .background(color.copy(alpha = 0.15f))
            .border(1.dp, color, RoundedCornerShape(12.dp))
            .padding(horizontal = 10.dp, vertical = 4.dp)
    ) {
        Text(
            text = status.name,
            style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
            color = color
        )
    }
}
