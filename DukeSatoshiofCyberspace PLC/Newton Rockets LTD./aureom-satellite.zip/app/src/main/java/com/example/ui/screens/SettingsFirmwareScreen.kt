package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.TelemetryState
import com.example.ui.theme.AureomBorder
import com.example.ui.theme.AureomCyanPrimary
import com.example.ui.theme.AureomGraphite
import com.example.ui.theme.AureomSkyBlue
import com.example.ui.theme.AureomSlateCard
import com.example.ui.theme.AureomTextMuted
import com.example.ui.theme.AureomWhite

@Composable
fun SettingsFirmwareScreen(
    telemetry: TelemetryState,
    isUpdating: Boolean,
    progress: Int,
    onExecuteUpdate: () -> Unit,
    modifier: Modifier = Modifier
) {
    LazyColumn(
        modifier = modifier
            .fillMaxWidth()
            .padding(16.dp)
            .testTag("settings_firmware_screen"),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Firmware Management Card
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(AureomGraphite)
                    .border(1.dp, AureomBorder, RoundedCornerShape(12.dp))
                    .padding(16.dp)
            ) {
                Text(
                    text = "AUREOM OVER-THE-AIR (OTA) FIRMWARE MANAGEMENT",
                    style = MaterialTheme.typography.titleLarge.copy(
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold
                    ),
                    color = AureomWhite
                )

                Spacer(modifier = Modifier.height(16.dp))

                Row(modifier = Modifier.fillMaxWidth()) {
                    FirmwareCell("CURRENT VERSION", telemetry.firmwareVersion, Modifier.weight(1f))
                    Spacer(modifier = Modifier.width(8.dp))
                    FirmwareCell("AVAILABLE STAGED", telemetry.stagedFirmwareVersion, Modifier.weight(1f))
                }

                Spacer(modifier = Modifier.height(12.dp))

                if (isUpdating) {
                    Text("STAGE & VERIFY SHA-256 CHECKSUM IN PROGRESS ($progress%)", style = MaterialTheme.typography.labelMedium, color = AureomCyanPrimary)
                    Spacer(modifier = Modifier.height(6.dp))
                    LinearProgressIndicator(
                        progress = { progress / 100f },
                        modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp)),
                        color = AureomCyanPrimary,
                        trackColor = AureomSlateCard
                    )
                } else {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = onExecuteUpdate,
                            modifier = Modifier
                                .weight(1f)
                                .height(44.dp)
                                .testTag("apply_firmware_update_button"),
                            colors = ButtonDefaults.buttonColors(containerColor = AureomCyanPrimary, contentColor = AureomGraphite),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("DOWNLOAD, STAGE & REBOOT", fontWeight = FontWeight.Bold, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                        }

                        OutlinedButton(
                            onClick = {},
                            modifier = Modifier
                                .weight(1f)
                                .height(44.dp),
                            border = androidx.compose.foundation.BorderStroke(1.dp, AureomBorder),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("A/B PARTITION ROLLBACK", fontSize = 11.sp, color = AureomWhite, fontFamily = FontFamily.Monospace)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun FirmwareCell(label: String, value: String, modifier: Modifier = Modifier) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .background(AureomSlateCard)
            .padding(12.dp)
    ) {
        Text(text = label, style = MaterialTheme.typography.labelMedium.copy(fontSize = 10.sp), color = AureomTextMuted)
        Spacer(modifier = Modifier.height(2.dp))
        Text(text = value, style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace), color = AureomCyanPrimary)
    }
}
