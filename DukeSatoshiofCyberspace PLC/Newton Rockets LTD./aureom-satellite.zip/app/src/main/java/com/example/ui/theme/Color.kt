package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val AureomNavyDark = Color(0xFF0A192F)
val AureomGraphite = Color(0xFF0D1117)
val AureomSlateCard = Color(0xFF1E293B)
val AureomBorder = Color(0xFF334155)

val AureomCyanPrimary = Color(0xFF00D2FF)
val AureomSkyBlue = Color(0xFF38BDF8)
val AureomWhite = Color(0xFFF8FAFC)
val AureomTextMuted = Color(0xFF94A3B8)

val AureomEmeraldSuccess = Color(0xFF10B981)
val AureomAmberWarning = Color(0xFFF59E0B)
val AureomRedError = Color(0xFFEF4444)

val AureomBadgeSimulated = Color(0xFF2563EB)
