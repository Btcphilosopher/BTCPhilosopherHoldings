package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.TelemetryState
import com.example.ui.theme.AureomBorder
import com.example.ui.theme.AureomCyanPrimary
import com.example.ui.theme.AureomEmeraldSuccess
import com.example.ui.theme.AureomGraphite
import com.example.ui.theme.AureomSlateCard
import com.example.ui.theme.AureomTextMuted
import com.example.ui.theme.AureomWhite

@Composable
fun EngineeringNocScreen(
    telemetry: TelemetryState,
    modifier: Modifier = Modifier
) {
    LazyColumn(
        modifier = modifier
            .fillMaxWidth()
            .padding(16.dp)
            .testTag("engineering_noc_screen"),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Network Health Index Header
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(AureomGraphite)
                    .border(1.dp, AureomCyanPrimary.copy(alpha = 0.5f), RoundedCornerShape(12.dp))
                    .padding(16.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "NETWORK OPERATIONS CENTER (NOC)",
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold
                        ),
                        color = AureomWhite
                    )

                    Text(
                        text = "GLOBAL HEALTH: 99.8%",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = AureomEmeraldSuccess,
                            fontFamily = FontFamily.Monospace
                        )
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                Row(modifier = Modifier.fillMaxWidth()) {
                    NocPill("SATELLITES FLEET", "148 ACTIVE", "UP", Modifier.weight(1f))
                    Spacer(modifier = Modifier.width(8.dp))
                    NocPill("GROUND STATIONS", "12 GLOBAL", "UP", Modifier.weight(1f))
                }

                Spacer(modifier = Modifier.height(8.dp))

                Row(modifier = Modifier.fillMaxWidth()) {
                    NocPill("CORE ROUTERS", "6 REGIONS", "UP", Modifier.weight(1f))
                    Spacer(modifier = Modifier.width(8.dp))
                    NocPill("OPTICAL ISL", "296 LINKS", "UP", Modifier.weight(1f))
                }
            }
        }

        // Deep RF Telemetry Dashboard
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(AureomSlateCard)
                    .border(1.dp, AureomBorder, RoundedCornerShape(12.dp))
                    .padding(16.dp)
            ) {
                Text(
                    text = "ADVANCED RF ENGINEERING METRICS",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold
                    ),
                    color = AureomCyanPrimary
                )

                Spacer(modifier = Modifier.height(12.dp))

                Row(modifier = Modifier.fillMaxWidth()) {
                    RfGrid("SNR", "${telemetry.snrDb} dB", Modifier.weight(1f))
                    Spacer(modifier = Modifier.width(8.dp))
                    RfGrid("RSSI", "${telemetry.signalDb} dBm", Modifier.weight(1f))
                    Spacer(modifier = Modifier.width(8.dp))
                    RfGrid("EIRP", "${telemetry.eirpDbw} dBW", Modifier.weight(1f))
                }

                Spacer(modifier = Modifier.height(8.dp))

                Row(modifier = Modifier.fillMaxWidth()) {
                    RfGrid("PATH LOSS (FSPL)", "${telemetry.pathLossDb} dB", Modifier.weight(1f))
                    Spacer(modifier = Modifier.width(8.dp))
                    RfGrid("LINK MARGIN", "${telemetry.linkMarginDb} dB", Modifier.weight(1f))
                    Spacer(modifier = Modifier.width(8.dp))
                    RfGrid("DOPPLER SHIFT", "${telemetry.dopplerShiftKhz} kHz", Modifier.weight(1f))
                }

                Spacer(modifier = Modifier.height(8.dp))

                Row(modifier = Modifier.fillMaxWidth()) {
                    RfGrid("MODULATION / CODING", telemetry.modulationMcs, Modifier.weight(1f))
                    Spacer(modifier = Modifier.width(8.dp))
                    RfGrid("PACKET ERROR RATE", "${telemetry.packetErrorRatePct}%", Modifier.weight(1f))
                }
            }
        }
    }
}

@Composable
private fun NocPill(label: String, val1: String, status: String, modifier: Modifier = Modifier) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .background(AureomSlateCard)
            .padding(10.dp)
    ) {
        Text(text = label, style = MaterialTheme.typography.labelMedium.copy(fontSize = 10.sp), color = AureomTextMuted)
        Text(text = val1, style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace), color = AureomWhite)
        Text(text = "STATUS: $status", style = MaterialTheme.typography.labelMedium.copy(fontSize = 10.sp, fontWeight = FontWeight.Bold), color = AureomEmeraldSuccess)
    }
}

@Composable
private fun RfGrid(label: String, value: String, modifier: Modifier = Modifier) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(6.dp))
            .background(AureomGraphite)
            .padding(8.dp)
    ) {
        Text(text = label, style = MaterialTheme.typography.labelMedium.copy(fontSize = 9.sp), color = AureomTextMuted)
        Text(text = value, style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace), color = AureomWhite)
    }
}
