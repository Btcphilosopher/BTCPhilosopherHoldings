package com.example.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.NetworkNodeInfo
import com.example.data.model.TelemetryState
import com.example.ui.theme.AureomBorder
import com.example.ui.theme.AureomCyanPrimary
import com.example.ui.theme.AureomEmeraldSuccess
import com.example.ui.theme.AureomGraphite
import com.example.ui.theme.AureomSkyBlue
import com.example.ui.theme.AureomSlateCard
import com.example.ui.theme.AureomTextMuted
import com.example.ui.theme.AureomWhite

@Composable
fun NetworkTopologyCanvas(
    telemetry: TelemetryState,
    modifier: Modifier = Modifier
) {
    val nodes = remember(telemetry) {
        listOf(
            NetworkNodeInfo(
                id = "customer_device",
                name = "CUSTOMER DEVICE",
                type = "CLIENT",
                status = "UP",
                latencyMs = 1,
                throughputMbps = telemetry.downlinkMbps,
                packetLossPct = 0.0,
                uptimePct = 99.99,
                details = "Wi-Fi 6E (6 GHz) / Gigabit Ethernet LAN Interface"
            ),
            NetworkNodeInfo(
                id = "terminal",
                name = "SATELLITE TERMINAL",
                type = "TERMINAL",
                status = if (telemetry.temperatureC > 70.0) "DEGRADED" else "UP",
                latencyMs = 2,
                throughputMbps = telemetry.downlinkMbps,
                packetLossPct = 0.0,
                uptimePct = 99.98,
                details = "Phased Array Terminal (${telemetry.serialNumber}), Temp: ${telemetry.temperatureC}°C, Power: ${telemetry.powerW}W"
            ),
            NetworkNodeInfo(
                id = "satellite",
                name = telemetry.satelliteId,
                type = "LEO SATELLITE",
                status = "UP",
                latencyMs = 12,
                throughputMbps = telemetry.downlinkMbps,
                packetLossPct = telemetry.packetLossPct,
                uptimePct = 99.95,
                details = "Walker-Delta Shell (550km), El: ${telemetry.elevationDeg.toInt()}°, Az: ${telemetry.azimuthDeg.toInt()}°, MCS: ${telemetry.modulationMcs}"
            ),
            NetworkNodeInfo(
                id = "gateway",
                name = telemetry.gatewayId,
                type = "GROUND GATEWAY",
                status = "UP",
                latencyMs = 18,
                throughputMbps = telemetry.downlinkMbps,
                packetLossPct = telemetry.packetLossPct,
                uptimePct = 99.99,
                details = "Ka-Band Tracking Array (${telemetry.gatewayName})"
            ),
            NetworkNodeInfo(
                id = "core",
                name = "AUREOM CORE",
                type = "ISP BACKBONE",
                status = "UP",
                latencyMs = 21,
                throughputMbps = 10000.0,
                packetLossPct = 0.0,
                uptimePct = 99.999,
                details = "London Primary Data Center & BGP Peering Exchange"
            ),
            NetworkNodeInfo(
                id = "internet",
                name = "PUBLIC INTERNET",
                type = "WAN",
                status = "UP",
                latencyMs = telemetry.latencyMs,
                throughputMbps = telemetry.downlinkMbps,
                packetLossPct = telemetry.packetLossPct,
                uptimePct = 100.0,
                details = "Public Transit IPv4 (${telemetry.publicIpV4}) / IPv6"
            )
        )
    }

    var selectedNode by remember { mutableStateOf(nodes[1]) }

    // Packet progress animation tied to active link data transfer
    val packetProgress = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        packetProgress.animateTo(
            targetValue = 1f,
            animationSpec = infiniteRepeatable(
                animation = tween(durationMillis = 1800, easing = LinearEasing)
            )
        )
    }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(AureomGraphite)
            .border(1.dp, AureomBorder, RoundedCornerShape(12.dp))
            .padding(16.dp)
            .testTag("network_topology_canvas_container")
    ) {
        Text(
            text = "END-TO-END SATELLITE NETWORK TOPOLOGY",
            style = MaterialTheme.typography.titleMedium.copy(
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold
            ),
            color = AureomWhite
        )
        Text(
            text = "Select any node below to inspect live RF & telemetry metrics",
            style = MaterialTheme.typography.bodyMedium,
            color = AureomTextMuted
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Canvas with animated packet transfer lines
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(110.dp)
                .background(AureomSlateCard.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                .border(1.dp, AureomBorder, RoundedCornerShape(8.dp))
                .padding(8.dp)
        ) {
            Canvas(modifier = Modifier.matchParentSize()) {
                val nodeCount = nodes.size
                val stepX = size.width / nodeCount
                val centerY = size.height / 2f

                for (i in 0 until nodeCount - 1) {
                    val x1 = stepX * i + stepX / 2f
                    val x2 = stepX * (i + 1) + stepX / 2f

                    // Dotted connection line
                    drawLine(
                        color = AureomBorder,
                        start = Offset(x1, centerY),
                        end = Offset(x2, centerY),
                        strokeWidth = 3f,
                        pathEffect = PathEffect.dashPathEffect(floatArrayOf(8f, 8f), 0f)
                    )

                    // Animated telemetry packet indicator
                    val currentProgress = (packetProgress.value + (i.toFloat() / nodeCount)) % 1.0f
                    val packetX = x1 + (x2 - x1) * currentProgress
                    drawCircle(
                        color = AureomCyanPrimary,
                        radius = 5f,
                        center = Offset(packetX, centerY)
                    )
                }
            }

            // Node overlay icons
            Row(
                modifier = Modifier.matchParentSize(),
                horizontalArrangement = Arrangement.SpaceAround,
                verticalAlignment = Alignment.CenterVertically
            ) {
                nodes.forEach { node ->
                    val isSelected = node.id == selectedNode.id
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (isSelected) AureomCyanPrimary.copy(alpha = 0.2f) else AureomSlateCard)
                            .border(1.dp, if (isSelected) AureomCyanPrimary else AureomBorder, RoundedCornerShape(8.dp))
                            .clickable { selectedNode = node }
                            .padding(8.dp)
                            .testTag("node_${node.id}")
                    ) {
                        Box(
                            modifier = Modifier
                                .size(10.dp)
                                .clip(RoundedCornerShape(5.dp))
                                .background(AureomEmeraldSuccess)
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = node.type,
                            style = MaterialTheme.typography.labelMedium.copy(fontSize = 9.sp),
                            color = if (isSelected) AureomCyanPrimary else AureomWhite
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Selected Node Inspection Sheet
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(8.dp))
                .background(AureomSlateCard)
                .border(1.dp, AureomCyanPrimary.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                .padding(14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "NODE INSPECTOR: ${selectedNode.name}",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold
                    ),
                    color = AureomCyanPrimary
                )
                Text(
                    text = "STATUS: ${selectedNode.status}",
                    style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                    color = AureomEmeraldSuccess
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                MetricColumn("LATENCY", "${selectedNode.latencyMs} ms")
                MetricColumn("THROUGHPUT", "${selectedNode.throughputMbps.toInt()} Mbps")
                MetricColumn("PACKET LOSS", "${selectedNode.packetLossPct}%")
                MetricColumn("UPTIME", "${selectedNode.uptimePct}%")
            }

            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = selectedNode.details,
                style = MaterialTheme.typography.bodyMedium,
                color = AureomTextMuted
            )
        }
    }
}

@Composable
private fun MetricColumn(label: String, value: String) {
    Column {
        Text(text = label, style = MaterialTheme.typography.labelMedium.copy(fontSize = 10.sp), color = AureomTextMuted)
        Text(text = value, style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace), color = AureomWhite)
    }
}
