package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.room.Room
import com.example.data.local.AureomDatabase
import com.example.data.repository.AureomRepository
import com.example.ui.AureomApp
import com.example.ui.AureomViewModel
import com.example.ui.AureomViewModelFactory
import com.example.ui.theme.AureomTheme

class MainActivity : ComponentActivity() {

    private val db by lazy {
        Room.databaseBuilder(
            applicationContext,
            AureomDatabase::class.java,
            "aureom_satellite_db"
        ).build()
    }

    private val repository by lazy {
        AureomRepository(db)
    }

    private val viewModel: AureomViewModel by viewModels {
        AureomViewModelFactory(repository)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            AureomTheme {
                AureomApp(viewModel = viewModel)
            }
        }
    }
}
