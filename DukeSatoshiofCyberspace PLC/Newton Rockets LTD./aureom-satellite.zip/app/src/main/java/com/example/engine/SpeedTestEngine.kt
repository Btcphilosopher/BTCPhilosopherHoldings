package com.example.engine

import com.example.data.model.SpeedTestResult
import com.example.data.model.TelemetryState
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlin.math.sin
import kotlin.random.Random

object SpeedTestEngine {

    fun executeSpeedTest(telemetry: TelemetryState): Flow<SpeedTestResult> = flow {
        val targetDown = telemetry.downlinkMbps
        val targetUp = telemetry.uplinkMbps
        val baseLatency = telemetry.latencyMs

        val samples = mutableListOf<Pair<Float, Float>>()

        // Step 1: Warmup & Ping (0-20%)
        for (i in 1..10) {
            val progress = i * 2
            val currMbps = (targetDown * 0.15 * (i / 10.0)).toFloat()
            samples.add(Pair((i * 0.2).toFloat(), currMbps))
            emit(
                SpeedTestResult(
                    isRunning = true,
                    progressPct = progress,
                    currentMbps = currMbps.toDouble(),
                    latencyMs = baseLatency + Random.nextInt(-2, 3),
                    jitterMs = telemetry.jitterMs,
                    packetLossPct = telemetry.packetLossPct,
                    samples = samples.toList()
                )
            )
            delay(150)
        }

        // Step 2: Download Speed Measurement (20-60%)
        val downSamples = mutableListOf<Double>()
        for (i in 1..20) {
            val progress = 20 + (i * 2)
            val timeSec = 2.0f + (i * 0.2f)
            val noise = Random.nextDouble(-12.0, 15.0)
            val ramp = (i / 8.0).coerceAtMost(1.0)
            val wave = sin(i * 0.4) * 8.0
            val speed = (targetDown * ramp + noise + wave).coerceAtLeast(10.0)
            downSamples.add(speed)

            samples.add(Pair(timeSec, speed.toFloat()))

            val avgSoFar = downSamples.average()
            val peakSoFar = downSamples.maxOrNull() ?: speed

            emit(
                SpeedTestResult(
                    isRunning = true,
                    progressPct = progress,
                    currentMbps = speed,
                    downloadPeakMbps = peakSoFar,
                    downloadAvgMbps = avgSoFar,
                    downloadMinMbps = downSamples.minOrNull() ?: speed,
                    downloadP95Mbps = calculateP95(downSamples),
                    latencyMs = baseLatency + Random.nextInt(-1, 2),
                    jitterMs = telemetry.jitterMs,
                    packetLossPct = telemetry.packetLossPct,
                    samples = samples.toList()
                )
            )
            delay(150)
        }

        val finalDownAvg = downSamples.average()
        val finalDownPeak = downSamples.maxOrNull() ?: targetDown
        val finalDownMin = downSamples.minOrNull() ?: (targetDown * 0.7)
        val finalDownP95 = calculateP95(downSamples)

        // Step 3: Upload Speed Measurement (60-100%)
        val upSamples = mutableListOf<Double>()
        for (i in 1..20) {
            val progress = 60 + (i * 2)
            val timeSec = 6.0f + (i * 0.2f)
            val noise = Random.nextDouble(-2.0, 3.0)
            val ramp = (i / 6.0).coerceAtMost(1.0)
            val speed = (targetUp * ramp + noise).coerceAtLeast(3.0)
            upSamples.add(speed)

            samples.add(Pair(timeSec, speed.toFloat()))

            val upAvgSoFar = upSamples.average()
            val upPeakSoFar = upSamples.maxOrNull() ?: speed

            emit(
                SpeedTestResult(
                    isRunning = true,
                    progressPct = progress,
                    currentMbps = speed,
                    downloadPeakMbps = finalDownPeak,
                    downloadAvgMbps = finalDownAvg,
                    downloadMinMbps = finalDownMin,
                    downloadP95Mbps = finalDownP95,
                    uploadPeakMbps = upPeakSoFar,
                    uploadAvgMbps = upAvgSoFar,
                    uploadMinMbps = upSamples.minOrNull() ?: speed,
                    uploadP95Mbps = calculateP95(upSamples),
                    latencyMs = baseLatency,
                    jitterMs = telemetry.jitterMs,
                    packetLossPct = telemetry.packetLossPct,
                    samples = samples.toList()
                )
            )
            delay(150)
        }

        val finalUpAvg = upSamples.average()
        val finalUpPeak = upSamples.maxOrNull() ?: targetUp
        val finalUpMin = upSamples.minOrNull() ?: (targetUp * 0.7)
        val finalUpP95 = calculateP95(upSamples)

        // Done
        emit(
            SpeedTestResult(
                isRunning = false,
                progressPct = 100,
                currentMbps = 0.0,
                downloadPeakMbps = finalDownPeak,
                downloadAvgMbps = finalDownAvg,
                downloadMinMbps = finalDownMin,
                downloadP95Mbps = finalDownP95,
                uploadPeakMbps = finalUpPeak,
                uploadAvgMbps = finalUpAvg,
                uploadMinMbps = finalUpMin,
                uploadP95Mbps = finalUpP95,
                latencyMs = baseLatency,
                jitterMs = telemetry.jitterMs,
                packetLossPct = telemetry.packetLossPct,
                samples = samples.toList()
            )
        )
    }

    private fun calculateP95(values: List<Double>): Double {
        if (values.isEmpty()) return 0.0
        val sorted = values.sorted()
        val index = (0.95 * (sorted.size - 1)).toInt()
        return sorted[index]
    }
}
