package com.example.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.local.DeviceEntity
import com.example.data.local.InvoiceEntity
import com.example.data.model.DiagnosticReport
import com.example.data.model.ServicePlan
import com.example.data.model.SpeedTestResult
import com.example.data.model.TelemetryState
import com.example.data.model.UsageMetrics
import com.example.data.model.UserRole
import com.example.data.repository.AureomRepository
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class AureomTab(val label: String) {
    OVERVIEW("OVERVIEW"),
    INTERNET("INTERNET"),
    TERMINAL("TERMINAL"),
    NETWORK("NETWORK"),
    DIAGNOSTICS("DIAGNOSTICS"),
    USAGE("USAGE"),
    PLAN_BILLING("PLAN & BILLING"),
    WIFI_LAN("WI-FI & LAN"),
    ENGINEERING_NOC("NOC & RF"),
    SETTINGS_FIRMWARE("SETTINGS")
}

class AureomViewModel(private val repository: AureomRepository) : ViewModel() {

    val telemetryState: StateFlow<TelemetryState> = repository.telemetryStream.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = TelemetryState()
    )

    val currentRole: StateFlow<UserRole> = repository.currentRole
    val selectedPlanId: StateFlow<String> = repository.selectedPlanId
    val speedTestState: StateFlow<SpeedTestResult> = repository.speedTestState
    val wifiSsid: StateFlow<String> = repository.wifiSsid
    val guestWifiEnabled: StateFlow<Boolean> = repository.guestWifiEnabled

    val devicesState: StateFlow<List<DeviceEntity>> = repository.devicesFlow.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val invoicesState: StateFlow<List<InvoiceEntity>> = repository.invoicesFlow.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    private val _currentTab = MutableStateFlow(AureomTab.OVERVIEW)
    val currentTab: StateFlow<AureomTab> = _currentTab.asStateFlow()

    private val _lastDiagnosticReport = MutableStateFlow<DiagnosticReport?>(null)
    val lastDiagnosticReport: StateFlow<DiagnosticReport?> = _lastDiagnosticReport.asStateFlow()

    private val _isFirmwareUpdating = MutableStateFlow(false)
    val isFirmwareUpdating: StateFlow<Boolean> = _isFirmwareUpdating.asStateFlow()

    private val _firmwareProgress = MutableStateFlow(0)
    val firmwareProgress: StateFlow<Int> = _firmwareProgress.asStateFlow()

    val availablePlans: List<ServicePlan> = repository.availablePlans
    val usageMetrics = UsageMetrics()

    fun selectTab(tab: AureomTab) {
        _currentTab.value = tab
    }

    fun setRole(role: UserRole) {
        repository.setRole(role)
    }

    fun selectPlan(planId: String) {
        repository.selectPlan(planId)
    }

    fun runDiagnostics() {
        val telemetry = telemetryState.value
        val report = repository.runDiagnosticsNow(telemetry)
        _lastDiagnosticReport.value = report
    }

    fun startSpeedTest() {
        repository.startSpeedTest(telemetryState.value)
    }

    fun toggleDevicePause(mac: String, currentPaused: Boolean) {
        viewModelScope.launch {
            repository.toggleDevicePause(mac, currentPaused)
        }
    }

    fun updateDeviceQos(mac: String, priority: String) {
        viewModelScope.launch {
            repository.updateDeviceQos(mac, priority)
        }
    }

    fun updateWifiSsid(ssid: String) {
        repository.updateWifiSsid(ssid)
    }

    fun toggleGuestWifi(enabled: Boolean) {
        repository.toggleGuestNetwork(enabled)
    }

    fun executeFirmwareUpdate() {
        if (_isFirmwareUpdating.value) return
        viewModelScope.launch {
            _isFirmwareUpdating.value = true
            _firmwareProgress.value = 0
            for (i in 1..100) {
                delay(80)
                _firmwareProgress.value = i
            }
            delay(500)
            _isFirmwareUpdating.value = false
        }
    }
}

class AureomViewModelFactory(private val repository: AureomRepository) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(AureomViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return AureomViewModel(repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
