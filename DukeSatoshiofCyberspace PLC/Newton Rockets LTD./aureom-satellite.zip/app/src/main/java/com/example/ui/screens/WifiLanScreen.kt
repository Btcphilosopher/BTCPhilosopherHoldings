package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.DeviceEntity
import com.example.ui.theme.AureomBorder
import com.example.ui.theme.AureomCyanPrimary
import com.example.ui.theme.AureomEmeraldSuccess
import com.example.ui.theme.AureomGraphite
import com.example.ui.theme.AureomRedError
import com.example.ui.theme.AureomSlateCard
import com.example.ui.theme.AureomTextMuted
import com.example.ui.theme.AureomWhite

@Composable
fun WifiLanScreen(
    devices: List<DeviceEntity>,
    wifiSsid: String,
    guestEnabled: Boolean,
    onUpdateSsid: (String) -> Unit,
    onToggleGuest: (Boolean) -> Unit,
    onTogglePauseDevice: (String, Boolean) -> Unit,
    modifier: Modifier = Modifier
) {
    var ssidInput by remember(wifiSsid) { mutableStateOf(wifiSsid) }

    LazyColumn(
        modifier = modifier
            .fillMaxWidth()
            .padding(16.dp)
            .testTag("wifi_lan_screen"),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Wi-Fi Settings Card
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(AureomGraphite)
                    .border(1.dp, AureomBorder, RoundedCornerShape(12.dp))
                    .padding(16.dp)
            ) {
                Text(
                    text = "LOCAL NETWORK & TRI-BAND WI-FI 6E",
                    style = MaterialTheme.typography.titleLarge.copy(
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold
                    ),
                    color = AureomWhite
                )

                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    BandBadge("2.4 GHz", true)
                    BandBadge("5 GHz", true)
                    BandBadge("6 GHz (Wi-Fi 6E)", true)
                }

                Spacer(modifier = Modifier.height(16.dp))

                OutlinedTextField(
                    value = ssidInput,
                    onValueChange = { ssidInput = it },
                    label = { Text("PRIMARY NETWORK SSID", color = AureomTextMuted) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("ssid_text_input"),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = AureomCyanPrimary,
                        unfocusedBorderColor = AureomBorder,
                        focusedTextColor = AureomWhite,
                        unfocusedTextColor = AureomWhite
                    ),
                    shape = RoundedCornerShape(8.dp)
                )

                Spacer(modifier = Modifier.height(10.dp))

                Button(
                    onClick = { onUpdateSsid(ssidInput) },
                    modifier = Modifier.fillMaxWidth().height(42.dp).testTag("save_ssid_button"),
                    colors = ButtonDefaults.buttonColors(containerColor = AureomCyanPrimary, contentColor = AureomGraphite),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("UPDATE NETWORK CREDENTIALS", fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                }
            }
        }

        // Guest Network Isolation Card
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(AureomSlateCard)
                    .border(1.dp, AureomCyanPrimary.copy(alpha = 0.5f), RoundedCornerShape(12.dp))
                    .padding(16.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "GUEST NETWORK ISOLATION (AUREOM-GUEST)",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold
                            ),
                            color = AureomCyanPrimary
                        )
                        Text(
                            text = "Strict VLAN firewall isolation prevents guests from accessing primary LAN resources.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = AureomTextMuted
                        )
                    }

                    Switch(
                        checked = guestEnabled,
                        onCheckedChange = onToggleGuest,
                        modifier = Modifier.testTag("guest_wifi_switch"),
                        colors = SwitchDefaults.colors(checkedThumbColor = AureomCyanPrimary)
                    )
                }
            }
        }

        // Connected LAN Devices
        item {
            Text(
                text = "CONNECTED LAN & WI-FI DEVICES (${devices.size})",
                style = MaterialTheme.typography.titleMedium.copy(
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                ),
                color = AureomWhite
            )
        }

        items(devices.size) { idx ->
            val dev = devices[idx]
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(AureomGraphite)
                    .border(1.dp, AureomBorder, RoundedCornerShape(8.dp))
                    .padding(12.dp)
                    .testTag("device_item_${dev.macAddress}")
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(text = dev.name, style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, fontSize = 14.sp), color = AureomWhite)
                        Text(text = "${dev.ipAddress} • ${dev.macAddress} • ${dev.band}", style = MaterialTheme.typography.bodyMedium.copy(fontSize = 11.sp), color = AureomTextMuted)
                    }

                    Button(
                        onClick = { onTogglePauseDevice(dev.macAddress, dev.isPaused) },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (dev.isPaused) AureomEmeraldSuccess else AureomRedError.copy(alpha = 0.2f),
                            contentColor = if (dev.isPaused) AureomWhite else AureomRedError
                        ),
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier.height(34.dp).testTag("pause_button_${dev.macAddress}")
                    ) {
                        Text(
                            text = if (dev.isPaused) "RESUME" else "PAUSE",
                            style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold, fontSize = 10.sp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(text = "Rx: ${dev.downloadSpeedMbps} Mbps • Tx: ${dev.uploadSpeedMbps} Mbps", style = MaterialTheme.typography.bodyMedium.copy(fontFamily = FontFamily.Monospace), color = AureomCyanPrimary)
                    Text(text = "QoS: ${dev.qosPriority}", style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold), color = AureomWhite)
                }
            }
        }
    }
}

@Composable
private fun BandBadge(name: String, active: Boolean) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(text = name, style = MaterialTheme.typography.labelMedium.copy(fontSize = 10.sp), color = AureomTextMuted)
        Text(text = if (active) "ACTIVE" else "OFF", style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold, color = if (active) AureomEmeraldSuccess else AureomRedError), modifier = Modifier.padding(top = 2.dp))
    }
}
