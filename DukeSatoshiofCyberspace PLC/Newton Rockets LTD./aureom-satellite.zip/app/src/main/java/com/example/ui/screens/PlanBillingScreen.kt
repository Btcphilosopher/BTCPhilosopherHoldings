package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CreditCard
import androidx.compose.material.icons.filled.Download
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.InvoiceEntity
import com.example.data.model.ServicePlan
import com.example.ui.theme.AureomBorder
import com.example.ui.theme.AureomCyanPrimary
import com.example.ui.theme.AureomEmeraldSuccess
import com.example.ui.theme.AureomGraphite
import com.example.ui.theme.AureomSlateCard
import com.example.ui.theme.AureomTextMuted
import com.example.ui.theme.AureomWhite

@Composable
fun PlanBillingScreen(
    plans: List<ServicePlan>,
    selectedPlanId: String,
    invoices: List<InvoiceEntity>,
    onSelectPlan: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val activePlan = plans.find { it.id == selectedPlanId } ?: plans.first()

    LazyColumn(
        modifier = modifier
            .fillMaxWidth()
            .padding(16.dp)
            .testTag("plan_billing_screen"),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Active Billing Account Summary
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(AureomGraphite)
                    .border(1.dp, AureomCyanPrimary.copy(alpha = 0.5f), RoundedCornerShape(12.dp))
                    .padding(16.dp)
            ) {
                Text(
                    text = "AUREOM BILLING & ACCOUNT MANAGEMENT",
                    style = MaterialTheme.typography.titleLarge.copy(
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold
                    ),
                    color = AureomWhite
                )

                Spacer(modifier = Modifier.height(16.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    BillingCell("CURRENT PLAN", activePlan.name, Modifier.weight(1f))
                    Spacer(modifier = Modifier.width(8.dp))
                    BillingCell("MONTHLY COST", "£${String.format("%.2f", activePlan.priceMonthlyGbp)}", Modifier.weight(1f))
                }

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    BillingCell("NEXT PAYMENT DATE", "2026-10-01", Modifier.weight(1f))
                    Spacer(modifier = Modifier.width(8.dp))
                    BillingCell("PAYMENT METHOD", "•••• 1234 (Visa)", Modifier.weight(1f))
                }
            }
        }

        // Available Service Plans
        item {
            Text(
                text = "AVAILABLE SATELLITE SERVICE PLANS",
                style = MaterialTheme.typography.titleMedium.copy(
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                ),
                color = AureomWhite
            )
        }

        items(plans.size) { idx ->
            val plan = plans[idx]
            val isSelected = plan.id == selectedPlanId

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(if (isSelected) AureomCyanPrimary.copy(alpha = 0.1f) else AureomSlateCard)
                    .border(1.dp, if (isSelected) AureomCyanPrimary else AureomBorder, RoundedCornerShape(12.dp))
                    .padding(16.dp)
                    .clickable { onSelectPlan(plan.id) }
                    .testTag("plan_card_${plan.id}")
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = plan.name,
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            ),
                            color = AureomWhite
                        )
                        Text(
                            text = "${plan.downloadMbps} / ${plan.uploadMbps}",
                            style = MaterialTheme.typography.bodyMedium,
                            color = AureomCyanPrimary
                        )
                    }

                    Text(
                        text = "£${plan.priceMonthlyGbp.toInt()}/mo",
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        ),
                        color = AureomWhite
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                plan.features.forEach { feature ->
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(vertical = 2.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Check, contentDescription = null, tint = AureomEmeraldSuccess, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(text = feature, style = MaterialTheme.typography.bodyMedium, color = AureomTextMuted)
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Button(
                    onClick = { onSelectPlan(plan.id) },
                    modifier = Modifier.fillMaxWidth().height(40.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isSelected) AureomEmeraldSuccess else AureomGraphite,
                        contentColor = AureomWhite
                    ),
                    shape = RoundedCornerShape(6.dp)
                ) {
                    Text(
                        text = if (isSelected) "ACTIVE PLAN" else "SELECT PLAN",
                        style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                    )
                }
            }
        }

        // Invoice History
        item {
            Text(
                text = "INVOICE HISTORY",
                style = MaterialTheme.typography.titleMedium.copy(
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                ),
                color = AureomWhite
            )
        }

        items(invoices.size) { idx ->
            val inv = invoices[idx]
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(AureomGraphite)
                    .border(1.dp, AureomBorder, RoundedCornerShape(8.dp))
                    .padding(12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(text = "${inv.invoiceId} • ${inv.dateIso}", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, fontSize = 13.sp), color = AureomWhite)
                    Text(text = "${inv.planName} • £${String.format("%.2f", inv.amountGbp)}", style = MaterialTheme.typography.bodyMedium, color = AureomTextMuted)
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(AureomEmeraldSuccess.copy(alpha = 0.2f))
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(text = inv.status, style = MaterialTheme.typography.labelMedium.copy(fontSize = 10.sp, fontWeight = FontWeight.Bold), color = AureomEmeraldSuccess)
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Icon(imageVector = Icons.Default.Download, contentDescription = "Download Invoice", tint = AureomCyanPrimary, modifier = Modifier.size(20.dp))
                }
            }
        }
    }
}

@Composable
private fun BillingCell(label: String, value: String, modifier: Modifier = Modifier) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .background(AureomSlateCard)
            .padding(12.dp)
    ) {
        Text(text = label, style = MaterialTheme.typography.labelMedium.copy(fontSize = 10.sp), color = AureomTextMuted)
        Spacer(modifier = Modifier.height(2.dp))
        Text(text = value, style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace), color = AureomWhite)
    }
}
