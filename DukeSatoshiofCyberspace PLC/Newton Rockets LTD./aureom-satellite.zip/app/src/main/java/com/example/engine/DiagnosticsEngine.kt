package com.example.engine

import com.example.data.model.DiagnosticReport
import com.example.data.model.DiagnosticStage
import com.example.data.model.StageStatus
import com.example.data.model.TelemetryState

object DiagnosticsEngine {

    fun runDiagnostics(telemetry: TelemetryState): DiagnosticReport {
        val stages = mutableListOf<DiagnosticStage>()

        // 1. LOCAL WI-FI / DEVICE
        stages.add(
            DiagnosticStage(
                name = "CUSTOMER DEVICE & WI-FI LAN",
                status = StageStatus.PASS,
                latencyMs = 1,
                measuredReason = "Local gateway response 1.2ms. Wi-Fi 6E (6 GHz) active with strong RSSI (-42 dBm)."
            )
        )

        // 2. TERMINAL HARDWARE
        val termStatus = when {
            telemetry.temperatureC > 70.0 -> StageStatus.WARNING to "Terminal temperature high (${telemetry.temperatureC}°C). Thermal throttling may occur."
            telemetry.powerW < 40.0 -> StageStatus.FAIL to "Low DC power input (${telemetry.powerW}W). Phased array power degraded."
            else -> StageStatus.PASS to "Terminal online, serial ${telemetry.serialNumber}, power ${telemetry.powerW}W, temp ${telemetry.temperatureC}°C."
        }
        stages.add(
            DiagnosticStage(
                name = "SATELLITE TERMINAL HARDWARE",
                status = termStatus.first,
                latencyMs = 2,
                measuredReason = termStatus.second
            )
        )

        // 3. SATELLITE LINK
        val linkStatus = when {
            telemetry.snrDb < 6.0 -> StageStatus.FAIL to "Low SNR (${telemetry.snrDb} dB). Ka-Band RF link lost or obstructed."
            telemetry.snrDb < 10.0 -> StageStatus.WARNING to "Degraded RF link (SNR ${telemetry.snrDb} dB). Weather rain fade active."
            else -> StageStatus.PASS to "Satellite link locked on ${telemetry.satelliteId} at ${telemetry.elevationDeg.toInt()}° elevation. SNR ${telemetry.snrDb} dB."
        }
        stages.add(
            DiagnosticStage(
                name = "SATELLITE RF LINK",
                status = linkStatus.first,
                latencyMs = 12,
                measuredReason = linkStatus.second
            )
        )

        // 4. GATEWAY GROUND STATION
        val gwStatus = when {
            telemetry.gatewayId.isEmpty() -> StageStatus.FAIL to "No gateway assigned."
            else -> StageStatus.PASS to "Ground station ${telemetry.gatewayId} responsive. Packet error rate ${telemetry.packetErrorRatePct}%."
        }
        stages.add(
            DiagnosticStage(
                name = "SATELLITE GATEWAY (GROUND STATION)",
                status = gwStatus.first,
                latencyMs = 18,
                measuredReason = gwStatus.second
            )
        )

        // 5. ISP CORE & PUBLIC INTERNET
        val netStatus = when {
            telemetry.packetLossPct > 5.0 -> StageStatus.WARNING to "Packet loss elevated (${telemetry.packetLossPct}%)."
            else -> StageStatus.PASS to "DNS resolution (1.1.1.1) 4.2ms. IPv4 ${telemetry.publicIpV4} & IPv6 route reachable."
        }
        stages.add(
            DiagnosticStage(
                name = "ISP CORE NETWORK & PUBLIC INTERNET",
                status = netStatus.first,
                latencyMs = telemetry.latencyMs,
                measuredReason = netStatus.second
            )
        )

        val overall = when {
            stages.any { it.status == StageStatus.FAIL } -> StageStatus.FAIL
            stages.any { it.status == StageStatus.WARNING } -> StageStatus.WARNING
            else -> StageStatus.PASS
        }

        val summary = when (overall) {
            StageStatus.PASS -> "All 5 network layers operating within optimal Aureom parameters. High-speed broadband available."
            StageStatus.WARNING -> "Minor link or thermal degradation detected. Connectivity maintained with fallback QoS."
            StageStatus.FAIL -> "Critical link outage identified in diagnostic chain. Automated route recovery initiated."
        }

        return DiagnosticReport(
            overallStatus = overall,
            summary = summary,
            stages = stages
        )
    }
}
