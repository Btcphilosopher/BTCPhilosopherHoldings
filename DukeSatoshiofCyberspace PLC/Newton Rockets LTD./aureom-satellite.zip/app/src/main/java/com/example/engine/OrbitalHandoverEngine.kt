package com.example.engine

import kotlin.math.sin

/**
 * LEO Satellite Synthetic Walker-Delta Constellation Pass & Inter-Satellite Handover Engine.
 */
class OrbitalHandoverEngine {
    private val satNames = listOf(
        "AUREOM-1042", "AUREOM-1077", "AUREOM-1104", "AUREOM-1129", "AUREOM-1150",
        "AUREOM-1188", "AUREOM-1215", "AUREOM-1240", "AUREOM-1299"
    )

    private var currentSatIndex = 0
    private var countdownSec = 120

    data class HandoverState(
        val currentSatellite: String,
        val nextSatellite: String,
        val countdownSec: Int,
        val elevationDeg: Double,
        val azimuthDeg: Double,
        val isHandoverInProgress: Boolean
    )

    fun tick(): HandoverState {
        countdownSec--
        if (countdownSec <= 0) {
            currentSatIndex = (currentSatIndex + 1) % satNames.size
            countdownSec = 180 // 3-minute LEO contact pass window in simulation
        }

        val nextSatIndex = (currentSatIndex + 1) % satNames.size
        val progress = 1.0 - (countdownSec.toDouble() / 180.0)

        // Synthetic elevation curve (peaks at 78 degrees in mid-pass)
        val elevationDeg = 20.0 + 58.0 * sin(progress * Math.PI)
        val azimuthDeg = (120.0 + progress * 80.0) % 360.0

        return HandoverState(
            currentSatellite = satNames[currentSatIndex],
            nextSatellite = satNames[nextSatIndex],
            countdownSec = countdownSec,
            elevationDeg = elevationDeg,
            azimuthDeg = azimuthDeg,
            isHandoverInProgress = countdownSec <= 5
        )
    }
}
