package com.example.data.local

import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.RoomDatabase
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "telemetry_logs")
data class TelemetryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val timestamp: Long,
    val terminalId: String,
    val satelliteId: String,
    val gatewayId: String,
    val signalDb: Double,
    val snrDb: Double,
    val downlinkMbps: Double,
    val uplinkMbps: Double,
    val latencyMs: Int,
    val packetLossPct: Double,
    val temperatureC: Double,
    val powerW: Double
)

@Entity(tableName = "lan_devices")
data class DeviceEntity(
    @PrimaryKey val macAddress: String,
    val name: String,
    val ipAddress: String,
    val band: String, // 2.4 GHz, 5 GHz, 6 GHz, Ethernet
    val downloadSpeedMbps: Double,
    val uploadSpeedMbps: Double,
    val isPaused: Boolean,
    val qosPriority: String, // LOW, NORMAL, HIGH
    val category: String, // Work, Streaming, Gaming, IoT, Mobile
    val lastSeenTimestamp: Long
)

@Entity(tableName = "diagnostic_runs")
data class DiagnosticRunEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val timestamp: Long,
    val overallResult: String, // PASS, WARNING, FAIL
    val localDeviceStatus: String,
    val terminalStatus: String,
    val satelliteLinkStatus: String,
    val gatewayStatus: String,
    val internetStatus: String,
    val summaryDetails: String
)

@Entity(tableName = "invoices")
data class InvoiceEntity(
    @PrimaryKey val invoiceId: String,
    val dateIso: String,
    val planName: String,
    val amountGbp: Double,
    val status: String, // PAID, PENDING
    val pdfUrl: String
)

@Dao
interface TelemetryDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTelemetry(telemetry: TelemetryEntity)

    @Query("SELECT * FROM telemetry_logs ORDER BY timestamp DESC LIMIT 100")
    fun getRecentTelemetry(): Flow<List<TelemetryEntity>>

    @Query("DELETE FROM telemetry_logs WHERE timestamp < :cutoff")
    suspend fun purgeOldTelemetry(cutoff: Long)
}

@Dao
interface DeviceDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertDevices(devices: List<DeviceEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertDevice(device: DeviceEntity)

    @Query("SELECT * FROM lan_devices ORDER BY lastSeenTimestamp DESC")
    fun getAllDevices(): Flow<List<DeviceEntity>>

    @Query("UPDATE lan_devices SET isPaused = :isPaused WHERE macAddress = :mac")
    suspend fun setDevicePaused(mac: String, isPaused: Boolean)

    @Query("UPDATE lan_devices SET qosPriority = :priority WHERE macAddress = :mac")
    suspend fun setDeviceQos(mac: String, priority: String)
}

@Dao
interface DiagnosticDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRun(run: DiagnosticRunEntity)

    @Query("SELECT * FROM diagnostic_runs ORDER BY timestamp DESC LIMIT 20")
    fun getRecentRuns(): Flow<List<DiagnosticRunEntity>>
}

@Dao
interface InvoiceDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertInvoices(invoices: List<InvoiceEntity>)

    @Query("SELECT * FROM invoices ORDER BY dateIso DESC")
    fun getAllInvoices(): Flow<List<InvoiceEntity>>
}

@Database(
    entities = [TelemetryEntity::class, DeviceEntity::class, DiagnosticRunEntity::class, InvoiceEntity::class],
    version = 1,
    exportSchema = false
)
abstract class AureomDatabase : RoomDatabase() {
    abstract fun telemetryDao(): TelemetryDao
    abstract fun deviceDao(): DeviceDao
    abstract fun diagnosticDao(): DiagnosticDao
    abstract fun invoiceDao(): InvoiceDao
}
