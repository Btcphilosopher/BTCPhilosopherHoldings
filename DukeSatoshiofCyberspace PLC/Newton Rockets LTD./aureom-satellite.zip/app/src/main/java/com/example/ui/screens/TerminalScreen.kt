package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.TelemetryState
import com.example.ui.theme.AureomBorder
import com.example.ui.theme.AureomCyanPrimary
import com.example.ui.theme.AureomEmeraldSuccess
import com.example.ui.theme.AureomGraphite
import com.example.ui.theme.AureomSkyBlue
import com.example.ui.theme.AureomSlateCard
import com.example.ui.theme.AureomTextMuted
import com.example.ui.theme.AureomWhite

@Composable
fun TerminalScreen(
    telemetry: TelemetryState,
    modifier: Modifier = Modifier
) {
    LazyColumn(
        modifier = modifier
            .fillMaxWidth()
            .padding(16.dp)
            .testTag("terminal_screen"),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Terminal Status Overview
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(AureomGraphite)
                    .border(1.dp, AureomBorder, RoundedCornerShape(12.dp))
                    .padding(16.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "TERMINAL MANAGEMENT",
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold
                        ),
                        color = AureomWhite
                    )

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .clip(CircleShape)
                                .background(AureomEmeraldSuccess)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "ONLINE",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = AureomEmeraldSuccess,
                                fontFamily = FontFamily.Monospace
                            )
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Row(modifier = Modifier.fillMaxWidth()) {
                    InfoCell("SERIAL", telemetry.serialNumber, Modifier.weight(1f))
                    Spacer(modifier = Modifier.width(8.dp))
                    InfoCell("FIRMWARE", telemetry.firmwareVersion, Modifier.weight(1f))
                }

                Spacer(modifier = Modifier.height(8.dp))

                Row(modifier = Modifier.fillMaxWidth()) {
                    InfoCell("UPTIME", "${telemetry.uptimeDays} days", Modifier.weight(1f))
                    Spacer(modifier = Modifier.width(8.dp))
                    InfoCell("TEMPERATURE", "${telemetry.temperatureC} °C", Modifier.weight(1f))
                    Spacer(modifier = Modifier.width(8.dp))
                    InfoCell("POWER", "${telemetry.powerW} W", Modifier.weight(1f))
                }

                Spacer(modifier = Modifier.height(8.dp))

                Row(modifier = Modifier.fillMaxWidth()) {
                    InfoCell("ANTENNA", telemetry.antennaState, Modifier.weight(1f))
                    Spacer(modifier = Modifier.width(8.dp))
                    InfoCell("SATELLITE LINK", telemetry.linkStatus.name, Modifier.weight(1f))
                }
            }
        }

        // Live Satellite RF Link Metrics
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(AureomSlateCard)
                    .border(1.dp, AureomCyanPrimary.copy(alpha = 0.5f), RoundedCornerShape(12.dp))
                    .padding(16.dp)
            ) {
                Text(
                    text = "SATELLITE LINK TELEMETRY",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold
                    ),
                    color = AureomCyanPrimary
                )

                Spacer(modifier = Modifier.height(12.dp))

                Row(modifier = Modifier.fillMaxWidth()) {
                    InfoCell("SIGNAL", "${telemetry.signalDb} dBm", Modifier.weight(1f))
                    Spacer(modifier = Modifier.width(8.dp))
                    InfoCell("SNR", "${telemetry.snrDb} dB", Modifier.weight(1f))
                }

                Spacer(modifier = Modifier.height(8.dp))

                Row(modifier = Modifier.fillMaxWidth()) {
                    InfoCell("DOWNLINK", "${telemetry.downlinkMbps} Mbps", Modifier.weight(1f))
                    Spacer(modifier = Modifier.width(8.dp))
                    InfoCell("UPLINK", "${telemetry.uplinkMbps} Mbps", Modifier.weight(1f))
                }

                Spacer(modifier = Modifier.height(8.dp))

                Row(modifier = Modifier.fillMaxWidth()) {
                    InfoCell("LATENCY", "${telemetry.latencyMs} ms", Modifier.weight(1f))
                    Spacer(modifier = Modifier.width(8.dp))
                    InfoCell("PACKET ERROR RATE", "${telemetry.packetErrorRatePct} %", Modifier.weight(1f))
                }
            }
        }

        // Orbital Handover Progress
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(AureomGraphite)
                    .border(1.dp, AureomBorder, RoundedCornerShape(12.dp))
                    .padding(16.dp)
            ) {
                Text(
                    text = "WALKER-DELTA LEO SATELLITE HANDOVER MODEL",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold
                    ),
                    color = AureomWhite
                )

                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text("CURRENT SATELLITE", style = MaterialTheme.typography.labelMedium, color = AureomTextMuted)
                        Text(telemetry.satelliteId, style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace), color = AureomCyanPrimary)
                    }

                    Column(horizontalAlignment = Alignment.End) {
                        Text("NEXT SATELLITE", style = MaterialTheme.typography.labelMedium, color = AureomTextMuted)
                        Text(telemetry.nextSatelliteId, style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace), color = AureomSkyBlue)
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Text("LINK QUALITY & PASS TRAJECTORY", style = MaterialTheme.typography.labelMedium, color = AureomTextMuted)
                Spacer(modifier = Modifier.height(4.dp))
                LinearProgressIndicator(
                    progress = { telemetry.linkQualityPct / 100f },
                    modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp)),
                    color = AureomCyanPrimary,
                    trackColor = AureomSlateCard
                )

                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "INTER-SATELLITE HANDOVER IN: ${telemetry.handoverCountdownSec} s",
                        style = MaterialTheme.typography.bodyLarge.copy(
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        ),
                        color = AureomEmeraldSuccess
                    )
                    Text(
                        text = "MAKE-BEFORE-BREAK READY",
                        style = MaterialTheme.typography.labelMedium,
                        color = AureomTextMuted
                    )
                }
            }
        }
    }
}

@Composable
private fun InfoCell(label: String, value: String, modifier: Modifier = Modifier) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(6.dp))
            .background(AureomSlateCard)
            .padding(10.dp)
    ) {
        Text(text = label, style = MaterialTheme.typography.labelMedium.copy(fontSize = 10.sp), color = AureomTextMuted)
        Spacer(modifier = Modifier.height(2.dp))
        Text(text = value, style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace), color = AureomWhite)
    }
}
