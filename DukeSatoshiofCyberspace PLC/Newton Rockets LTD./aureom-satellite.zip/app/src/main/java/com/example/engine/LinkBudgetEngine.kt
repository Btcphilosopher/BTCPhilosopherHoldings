package com.example.engine

import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.log10
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Real RF Link Budget Calculator for Ka-Band (28-30 GHz Uplink, 18-20 GHz Downlink) LEO Satellite Communication.
 *
 * Physics Equations:
 * - Slant Range d = sqrt(R_E^2 * sin^2(el) + 2*R_E*h + h^2) - R_E * sin(el)
 * - Free Space Path Loss FSPL = 20*log10(d_km) + 20*log10(f_MHz) + 32.44
 * - Rain & Atmospheric Attenuation A_atm
 * - Received Power P_r = EIRP - FSPL - A_atm + G_T
 * - SNR = P_r - N_0
 * - Spectral Efficiency & MCS mapping -> Capacity (Mbps)
 */
object LinkBudgetEngine {
    private const val EARTH_RADIUS_KM = 6371.0
    private const val LEO_ALTITUDE_KM = 550.0 // Walker-Delta Shell altitude
    private const val FREQ_DOWNLINK_GHZ = 19.7 // Ka-Band
    private const val FREQ_UPLINK_GHZ = 29.5
    private const val SPEED_OF_LIGHT_KM_S = 299792.0

    data class LinkBudgetResult(
        val slantRangeKm: Double,
        val fsplDb: Double,
        val rainAttenuationDb: Double,
        val snrDb: Double,
        val signalDbm: Double,
        val downlinkCapMbps: Double,
        val uplinkCapMbps: Double,
        val modulationMcs: String,
        val eirpDbw: Double,
        val linkMarginDb: Double,
        val dopplerShiftKhz: Double
    )

    fun calculateLinkBudget(
        elevationDeg: Double,
        isRaining: Boolean = false,
        txPowerWatts: Double = 112.0
    ): LinkBudgetResult {
        val elRad = Math.toRadians(elevationDeg.coerceIn(15.0, 90.0))
        
        // 1. Slant Range Calculation
        val rE = EARTH_RADIUS_KM
        val h = LEO_ALTITUDE_KM
        val slantRange = sqrt(rE * rE * sin(elRad) * sin(elRad) + 2 * rE * h + h * h) - rE * sin(elRad)

        // 2. Free Space Path Loss (FSPL) in dB
        val freqMHz = FREQ_DOWNLINK_GHZ * 1000.0
        val fspl = 20.0 * log10(slantRange) + 20.0 * log10(freqMHz) + 32.44

        // 3. Rain & Atmospheric Attenuation
        val rainAtt = if (isRaining) 3.5 / sin(elRad).coerceAtLeast(0.2) else 0.4 / sin(elRad).coerceAtLeast(0.2)

        // 4. Antenna Gain & EIRP (Equivalent Isotropically Radiated Power)
        val txPowerDbw = 10.0 * log10(txPowerWatts)
        val antennaGainDbi = 38.5 // Phased Array 1024-element
        val eirpDbw = txPowerDbw + antennaGainDbi

        // 5. Received Signal & SNR Calculation
        val grGtDbK = 14.2 // Terminal G/T ratio
        val totalLoss = fspl + rainAtt
        val prDbw = eirpDbw - totalLoss + antennaGainDbi
        val signalDbm = prDbw + 30.0

        val thermalNoiseFloorDbm = -104.0
        val snrDb = (signalDbm - thermalNoiseFloorDbm).coerceIn(2.0, 32.0)

        // 6. Link Margin & MCS mapping
        val requiredSnrDb = 10.5
        val linkMarginDb = snrDb - requiredSnrDb

        val (mcs, spectralEff) = when {
            snrDb >= 20.0 -> "256-APSK 3/4" to 5.8
            snrDb >= 16.0 -> "64-APSK 5/6" to 4.5
            snrDb >= 12.0 -> "16-APSK 3/4" to 3.0
            snrDb >= 8.0  -> "8-PSK 2/3" to 2.0
            else          -> "QPSK 1/2" to 1.0
        }

        // Allocated Ka-Band Channel Bandwidth = 125 MHz
        val bandwidthMhz = 125.0
        val rawCapMbps = bandwidthMhz * spectralEff
        val downlinkMbps = (rawCapMbps * 0.85).coerceIn(25.0, 520.0)
        val uplinkMbps = (downlinkMbps * 0.12).coerceIn(5.0, 65.0)

        // 7. Doppler Shift due to LEO orbit speed (~7.6 km/s)
        val leoVelocityKmS = 7.6
        val radialVelocity = leoVelocityKmS * cos(elRad)
        val dopplerShiftKhz = (radialVelocity / SPEED_OF_LIGHT_KM_S) * freqMHz * 1000.0

        return LinkBudgetResult(
            slantRangeKm = slantRange,
            fsplDb = fspl,
            rainAttenuationDb = rainAtt,
            snrDb = snrDb,
            signalDbm = signalDbm,
            downlinkCapMbps = downlinkMbps,
            uplinkCapMbps = uplinkMbps,
            modulationMcs = mcs,
            eirpDbw = eirpDbw,
            linkMarginDb = linkMarginDb,
            dopplerShiftKhz = dopplerShiftKhz
        )
    }
}
