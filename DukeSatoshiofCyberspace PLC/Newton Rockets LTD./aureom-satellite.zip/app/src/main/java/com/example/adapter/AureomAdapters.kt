package com.example.adapter

import com.example.data.model.LinkStatus
import com.example.data.model.TelemetryState
import com.example.data.model.TerminalStatus
import kotlinx.coroutines.flow.Flow

/**
 * Aureom Telecommunications Hardware Abstraction Layer (HAL).
 * Interfaces can be swapped with real physical hardware drivers (e.g. gRPC/SPI/Ethernet)
 * or connected to the high-fidelity simulator.
 */

interface TerminalAdapter {
    suspend fun getTerminalStatus(): TerminalStatus
    suspend fun rebootTerminal(): Boolean
    suspend fun stowAntenna(): Boolean
    suspend fun unstowAntenna(): Boolean
    suspend fun setPowerMode(ecoMode: Boolean): Boolean
}

interface SatelliteLinkAdapter {
    suspend fun getLinkStatus(): LinkStatus
    suspend fun forceHandover(targetSatelliteId: String): Boolean
    suspend fun alignPhasedArray(azimuth: Double, elevation: Double): Boolean
}

interface GatewayAdapter {
    suspend fun getActiveGatewayId(): String
    suspend fun testGatewayPing(): Int
    suspend fun setQosPriority(profile: String): Boolean
}

interface NetworkAdapter {
    suspend fun setWifiCredentials(ssid: String, wpa2Pass: String): Boolean
    suspend fun setGuestNetworkEnabled(enabled: Boolean): Boolean
    suspend fun setDevicePaused(macAddress: String, paused: Boolean): Boolean
}

interface TelemetryAdapter {
    fun observeTelemetryStream(): Flow<TelemetryState>
}

class SimulatedTerminalAdapter : TerminalAdapter {
    private var isEco = false
    private var isStowed = false

    override suspend fun getTerminalStatus(): TerminalStatus =
        if (isStowed) TerminalStatus.STOWED else TerminalStatus.ONLINE

    override suspend fun rebootTerminal(): Boolean = true

    override suspend fun stowAntenna(): Boolean {
        isStowed = true
        return true
    }

    override suspend fun unstowAntenna(): Boolean {
        isStowed = false
        return true
    }

    override suspend fun setPowerMode(ecoMode: Boolean): Boolean {
        isEco = ecoMode
        return true
    }
}

class SimulatedSatelliteLinkAdapter : SatelliteLinkAdapter {
    override suspend fun getLinkStatus(): LinkStatus = LinkStatus.LOCKED
    override suspend fun forceHandover(targetSatelliteId: String): Boolean = true
    override suspend fun alignPhasedArray(azimuth: Double, elevation: Double): Boolean = true
}

class SimulatedGatewayAdapter : GatewayAdapter {
    override suspend fun getActiveGatewayId(): String = "LONDON-01"
    override suspend fun testGatewayPing(): Int = 23
    override suspend fun setQosPriority(profile: String): Boolean = true
}

class SimulatedNetworkAdapter : NetworkAdapter {
    override suspend fun setWifiCredentials(ssid: String, wpa2Pass: String): Boolean = true
    override suspend fun setGuestNetworkEnabled(enabled: Boolean): Boolean = true
    override suspend fun setDevicePaused(macAddress: String, paused: Boolean): Boolean = true
}
