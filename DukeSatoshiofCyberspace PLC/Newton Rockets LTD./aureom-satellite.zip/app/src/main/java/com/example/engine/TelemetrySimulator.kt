package com.example.engine

import com.example.adapter.TelemetryAdapter
import com.example.data.model.LinkStatus
import com.example.data.model.TelemetryState
import com.example.data.model.TerminalStatus
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.flow
import kotlin.random.Random

class TelemetrySimulator : TelemetryAdapter {

    private val handoverEngine = OrbitalHandoverEngine()
    private val currentState = MutableStateFlow(TelemetryState())

    override fun observeTelemetryStream(): Flow<TelemetryState> = flow {
        var isRaining = false
        var rainCounter = 0

        while (true) {
            val handover = handoverEngine.tick()

            // Weather fluctuation simulation every ~45 ticks
            rainCounter++
            if (rainCounter > 45) {
                isRaining = !isRaining
                rainCounter = 0
            }

            // Link budget calculation based on satellite elevation and weather
            val budget = LinkBudgetEngine.calculateLinkBudget(
                elevationDeg = handover.elevationDeg,
                isRaining = isRaining,
                txPowerWatts = 112.0
            )

            // Random thermal and power jitter
            val tempC = (41.0 + Random.nextDouble(-0.8, 1.2)).coerceIn(30.0, 68.0)
            val powerW = (112.0 + Random.nextDouble(-2.5, 3.0)).coerceIn(80.0, 150.0)

            val updatedState = currentState.value.copy(
                timestamp = System.currentTimeMillis(),
                satelliteId = handover.currentSatellite,
                nextSatelliteId = handover.nextSatellite,
                handoverCountdownSec = handover.countdownSec,
                azimuthDeg = handover.azimuthDeg,
                elevationDeg = handover.elevationDeg,
                signalDb = String.format("%.1f", budget.signalDbm).toDouble(),
                snrDb = String.format("%.1f", budget.snrDb).toDouble(),
                downlinkMbps = String.format("%.1f", budget.downlinkCapMbps).toDouble(),
                uplinkMbps = String.format("%.1f", budget.uplinkCapMbps).toDouble(),
                latencyMs = (21 + (70.0 / handover.elevationDeg).toInt() + Random.nextInt(-1, 2)),
                packetLossPct = if (isRaining) 0.08 else 0.01,
                packetErrorRatePct = if (isRaining) 0.004 else 0.0008,
                temperatureC = String.format("%.1f", tempC).toDouble(),
                powerW = String.format("%.1f", powerW).toDouble(),
                modulationMcs = budget.modulationMcs,
                eirpDbw = String.format("%.1f", budget.eirpDbw).toDouble(),
                pathLossDb = String.format("%.1f", budget.fsplDb).toDouble(),
                linkMarginDb = String.format("%.1f", budget.linkMarginDb).toDouble(),
                dopplerShiftKhz = String.format("%.1f", budget.dopplerShiftKhz).toDouble(),
                linkStatus = if (handover.isHandoverInProgress) LinkStatus.TRACKING else LinkStatus.LOCKED,
                terminalStatus = TerminalStatus.ONLINE
            )

            currentState.value = updatedState
            emit(updatedState)
            delay(1000) // 1 Hz telemetry tick
        }
    }

    fun getCurrentTelemetry(): TelemetryState = currentState.value
}
