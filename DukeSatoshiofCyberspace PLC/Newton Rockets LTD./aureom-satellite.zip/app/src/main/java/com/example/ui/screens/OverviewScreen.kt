package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CellTower
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.NetworkCheck
import androidx.compose.material.icons.filled.Router
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.TelemetryState
import com.example.ui.AureomTab
import com.example.ui.theme.AureomBorder
import com.example.ui.theme.AureomCyanPrimary
import com.example.ui.theme.AureomEmeraldSuccess
import com.example.ui.theme.AureomGraphite
import com.example.ui.theme.AureomSkyBlue
import com.example.ui.theme.AureomSlateCard
import com.example.ui.theme.AureomTextMuted
import com.example.ui.theme.AureomWhite

@Composable
fun OverviewScreen(
    telemetry: TelemetryState,
    onNavigateTab: (AureomTab) -> Unit,
    onRunTest: () -> Unit,
    modifier: Modifier = Modifier
) {
    LazyColumn(
        modifier = modifier
            .fillMaxWidth()
            .padding(16.dp)
            .testTag("overview_screen"),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Main Customer Internet Card
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(AureomGraphite)
                    .border(1.dp, AureomCyanPrimary.copy(alpha = 0.6f), RoundedCornerShape(16.dp))
                    .padding(20.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "INTERNET",
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Black,
                            letterSpacing = 2.sp
                        ),
                        color = AureomWhite
                    )

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(10.dp)
                                .clip(CircleShape)
                                .background(AureomEmeraldSuccess)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "CONNECTED",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = AureomEmeraldSuccess,
                                fontFamily = FontFamily.Monospace
                            )
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Big Speed Metrics Grid
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    MetricBox(
                        title = "DOWNLOAD",
                        value = "${telemetry.downlinkMbps.toInt()} Mbps",
                        highlight = true,
                        modifier = Modifier.weight(1f)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    MetricBox(
                        title = "UPLOAD",
                        value = "${telemetry.uplinkMbps.toInt()} Mbps",
                        highlight = false,
                        modifier = Modifier.weight(1f)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    MetricBox(
                        title = "LATENCY",
                        value = "${telemetry.latencyMs} ms",
                        highlight = false,
                        modifier = Modifier.weight(1f)
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    MetricBox(title = "PACKET LOSS", value = "${telemetry.packetLossPct}%", highlight = false, modifier = Modifier.weight(1f))
                    Spacer(modifier = Modifier.width(8.dp))
                    MetricBox(title = "JITTER", value = "${telemetry.jitterMs} ms", highlight = false, modifier = Modifier.weight(1f))
                    Spacer(modifier = Modifier.width(8.dp))
                    MetricBox(title = "NETWORK", value = "AUREOM LEO", highlight = false, modifier = Modifier.weight(1f))
                }

                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(AureomSlateCard)
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "GATEWAY: ${telemetry.gatewayId}",
                        style = MaterialTheme.typography.bodyLarge.copy(
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        ),
                        color = AureomCyanPrimary
                    )
                    Text(
                        text = "SNR: ${telemetry.snrDb} dB",
                        style = MaterialTheme.typography.bodyMedium.copy(fontFamily = FontFamily.Monospace),
                        color = AureomTextMuted
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                Button(
                    onClick = {
                        onRunTest()
                        onNavigateTab(AureomTab.INTERNET)
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("run_connection_test_button"),
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = AureomCyanPrimary,
                        contentColor = AureomGraphite
                    )
                ) {
                    Icon(
                        imageVector = Icons.Default.Speed,
                        contentDescription = "Run Connection Test",
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "RUN CONNECTION TEST",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    )
                }
            }
        }

        // Quick Overview Shortcut Cards
        item {
            Text(
                text = "SYSTEM HIGHLIGHTS",
                style = MaterialTheme.typography.titleMedium.copy(
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                ),
                color = AureomTextMuted
            )
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                QuickCard(
                    title = "TERMINAL",
                    subtitle = "ONLINE • LOCK OK",
                    icon = Icons.Default.CellTower,
                    onClick = { onNavigateTab(AureomTab.TERMINAL) },
                    modifier = Modifier.weight(1f)
                )
                QuickCard(
                    title = "WI-FI & LAN",
                    subtitle = "5 DEVICES • 6 GHz",
                    icon = Icons.Default.Wifi,
                    onClick = { onNavigateTab(AureomTab.WIFI_LAN) },
                    modifier = Modifier.weight(1f)
                )
            }
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                QuickCard(
                    title = "DIAGNOSTICS",
                    subtitle = "5 STAGES PASS",
                    icon = Icons.Default.NetworkCheck,
                    onClick = { onNavigateTab(AureomTab.DIAGNOSTICS) },
                    modifier = Modifier.weight(1f)
                )
                QuickCard(
                    title = "TOPOLOGY",
                    subtitle = "END-TO-END MAP",
                    icon = Icons.Default.Router,
                    onClick = { onNavigateTab(AureomTab.NETWORK) },
                    modifier = Modifier.weight(1f)
                )
            }
        }
    }
}

@Composable
private fun MetricBox(
    title: String,
    value: String,
    highlight: Boolean,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .background(if (highlight) AureomCyanPrimary.copy(alpha = 0.15f) else AureomSlateCard)
            .border(1.dp, if (highlight) AureomCyanPrimary else AureomBorder, RoundedCornerShape(8.dp))
            .padding(10.dp)
    ) {
        Text(
            text = title,
            style = MaterialTheme.typography.labelMedium.copy(fontSize = 10.sp),
            color = AureomTextMuted
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = value,
            style = MaterialTheme.typography.titleMedium.copy(
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace
            ),
            color = if (highlight) AureomCyanPrimary else AureomWhite
        )
    }
}

@Composable
private fun QuickCard(
    title: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .background(AureomSlateCard)
            .border(1.dp, AureomBorder, RoundedCornerShape(12.dp))
            .padding(14.dp)
            .testTag("quick_card_${title.lowercase()}"),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = icon,
            contentDescription = title,
            tint = AureomCyanPrimary,
            modifier = Modifier.size(28.dp)
        )
        Spacer(modifier = Modifier.width(10.dp))
        Column {
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                color = AureomWhite
            )
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodyMedium.copy(fontSize = 11.sp),
                color = AureomTextMuted
            )
        }
    }
}
