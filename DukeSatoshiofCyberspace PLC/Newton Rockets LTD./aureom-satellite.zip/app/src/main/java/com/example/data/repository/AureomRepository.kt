package com.example.data.repository

import com.example.adapter.SimulatedNetworkAdapter
import com.example.adapter.SimulatedTerminalAdapter
import com.example.data.local.AureomDatabase
import com.example.data.local.DeviceEntity
import com.example.data.local.DiagnosticRunEntity
import com.example.data.local.InvoiceEntity
import com.example.data.local.TelemetryEntity
import com.example.data.model.DiagnosticReport
import com.example.data.model.ServicePlan
import com.example.data.model.SpeedTestResult
import com.example.data.model.TelemetryState
import com.example.data.model.UsageMetrics
import com.example.data.model.UserRole
import com.example.engine.DiagnosticsEngine
import com.example.engine.SpeedTestEngine
import com.example.engine.TelemetrySimulator
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

class AureomRepository(private val db: AureomDatabase) {

    private val simulator = TelemetrySimulator()
    private val terminalAdapter = SimulatedTerminalAdapter()
    private val networkAdapter = SimulatedNetworkAdapter()
    private val scope = CoroutineScope(Dispatchers.IO)

    val telemetryStream: Flow<TelemetryState> = simulator.observeTelemetryStream()

    private val _currentRole = MutableStateFlow(UserRole.CUSTOMER)
    val currentRole: StateFlow<UserRole> = _currentRole.asStateFlow()

    private val _selectedPlanId = MutableStateFlow("aureom_home")
    val selectedPlanId: StateFlow<String> = _selectedPlanId.asStateFlow()

    private val _speedTestState = MutableStateFlow(SpeedTestResult())
    val speedTestState: StateFlow<SpeedTestResult> = _speedTestState.asStateFlow()

    private val _wifiSsid = MutableStateFlow("AUREOM-HOME")
    val wifiSsid: StateFlow<String> = _wifiSsid.asStateFlow()

    private val _guestWifiEnabled = MutableStateFlow(true)
    val guestWifiEnabled: StateFlow<Boolean> = _guestWifiEnabled.asStateFlow()

    init {
        // Bootstrap initial database records if empty
        scope.launch {
            initDefaultDevices()
            initDefaultInvoices()

            // Periodically log telemetry snapshot to Room database
            telemetryStream.collect { state ->
                db.telemetryDao().insertTelemetry(
                    TelemetryEntity(
                        timestamp = state.timestamp,
                        terminalId = state.terminalId,
                        satelliteId = state.satelliteId,
                        gatewayId = state.gatewayId,
                        signalDb = state.signalDb,
                        snrDb = state.snrDb,
                        downlinkMbps = state.downlinkMbps,
                        uplinkMbps = state.uplinkMbps,
                        latencyMs = state.latencyMs,
                        packetLossPct = state.packetLossPct,
                        temperatureC = state.temperatureC,
                        powerW = state.powerW
                    )
                )
            }
        }
    }

    fun setRole(role: UserRole) {
        _currentRole.value = role
    }

    fun selectPlan(planId: String) {
        _selectedPlanId.value = planId
    }

    fun runDiagnosticsNow(state: TelemetryState): DiagnosticReport {
        val report = DiagnosticsEngine.runDiagnostics(state)
        scope.launch {
            db.diagnosticDao().insertRun(
                DiagnosticRunEntity(
                    timestamp = report.timestamp,
                    overallResult = report.overallStatus.name,
                    localDeviceStatus = report.stages[0].status.name,
                    terminalStatus = report.stages[1].status.name,
                    satelliteLinkStatus = report.stages[2].status.name,
                    gatewayStatus = report.stages[3].status.name,
                    internetStatus = report.stages[4].status.name,
                    summaryDetails = report.summary
                )
            )
        }
        return report
    }

    fun startSpeedTest(telemetryState: TelemetryState) {
        scope.launch {
            SpeedTestEngine.executeSpeedTest(telemetryState).collect { res ->
                _speedTestState.value = res
            }
        }
    }

    suspend fun toggleDevicePause(mac: String, currentPaused: Boolean) {
        db.deviceDao().setDevicePaused(mac, !currentPaused)
    }

    suspend fun updateDeviceQos(mac: String, priority: String) {
        db.deviceDao().setDeviceQos(mac, priority)
    }

    fun updateWifiSsid(newSsid: String) {
        _wifiSsid.value = newSsid
        scope.launch { networkAdapter.setWifiCredentials(newSsid, "••••••••") }
    }

    fun toggleGuestNetwork(enabled: Boolean) {
        _guestWifiEnabled.value = enabled
        scope.launch { networkAdapter.setGuestNetworkEnabled(enabled) }
    }

    val devicesFlow: Flow<List<DeviceEntity>> = db.deviceDao().getAllDevices()
    val invoicesFlow: Flow<List<InvoiceEntity>> = db.invoiceDao().getAllInvoices()

    val availablePlans = listOf(
        ServicePlan(
            id = "aureom_home",
            name = "AUREOM HOME",
            priceMonthlyGbp = 75.00,
            downloadMbps = "150 - 250 Mbps",
            uploadMbps = "20 - 40 Mbps",
            priorityLevel = "Standard Consumer",
            dataPolicy = "Unlimited Standard Data",
            SLA = "Best Effort High Availability",
            features = listOf(
                "Phased Array Terminal Access",
                "Dual-Band Wi-Fi 6 Router",
                "Standard Latency (20 - 35ms)",
                "24/7 Mobile App Diagnostics"
            )
        ),
        ServicePlan(
            id = "aureom_pro",
            name = "AUREOM PRO",
            priceMonthlyGbp = 140.00,
            downloadMbps = "350 - 500 Mbps",
            uploadMbps = "50 - 80 Mbps",
            priorityLevel = "High Priority QoS",
            dataPolicy = "Unlimited Priority Data",
            SLA = "99.5% Link SLA",
            features = listOf(
                "High-Throughput Phased Array Terminal",
                "Tri-Band Wi-Fi 6E / Mesh Included",
                "Ultra-Low Jitter Channel",
                "Priority UK Network Gateway Support"
            )
        ),
        ServicePlan(
            id = "aureom_business",
            name = "AUREOM BUSINESS",
            priceMonthlyGbp = 320.00,
            downloadMbps = "Up to 1.0 Gbps",
            uploadMbps = "Up to 150 Mbps",
            priorityLevel = "Mission Critical Dedicated",
            dataPolicy = "Unthrottled Tier-1 Transit",
            SLA = "99.9% Enterprise SLA",
            features = listOf(
                "Dedicated Public Static IPv4 & IPv6",
                "Enterprise Dual-Gate Redundancy",
                "Dedicated Network Operations Engineer",
                "Commercial Ground Station Interconnect"
            )
        ),
        ServicePlan(
            id = "aureom_remote",
            name = "AUREOM REMOTE",
            priceMonthlyGbp = 95.00,
            downloadMbps = "100 - 200 Mbps",
            uploadMbps = "15 - 30 Mbps",
            priorityLevel = "Global Mobility",
            dataPolicy = "Unlimited Roaming Data",
            SLA = "Global LEO Coverage",
            features = listOf(
                "In-Motion Tracking & Portability",
                "Ruggedized All-Weather Enclosure",
                "Auto-Stowing Motorized/Phased Array",
                "Global Coverage Shell Access"
            )
        )
    )

    private suspend fun initDefaultDevices() {
        val existing = db.deviceDao().getAllDevices().first()
        if (existing.isEmpty()) {
            db.deviceDao().upsertDevices(
                listOf(
                    DeviceEntity("3A:8F:12:C9:44:01", "MacBook Pro 16 (Workstation)", "192.168.1.102", "6 GHz", 184.2, 38.1, false, "HIGH", "Work", System.currentTimeMillis()),
                    DeviceEntity("7C:D2:99:10:E1:88", "Living Room 4K Smart TV", "192.168.1.108", "5 GHz", 42.0, 2.1, false, "NORMAL", "Streaming", System.currentTimeMillis()),
                    DeviceEntity("D4:11:00:88:F2:AA", "iPhone 15 Pro", "192.168.1.115", "5 GHz", 88.4, 12.0, false, "NORMAL", "Mobile", System.currentTimeMillis()),
                    DeviceEntity("AA:EE:22:90:71:04", "PlayStation 5", "192.168.1.120", "Ethernet", 240.0, 45.0, false, "HIGH", "Gaming", System.currentTimeMillis()),
                    DeviceEntity("B0:C4:01:99:32:55", "Aureom Guest Smartphone", "192.168.2.14", "2.4 GHz", 12.5, 3.0, false, "LOW", "IoT", System.currentTimeMillis())
                )
            )
        }
    }

    private suspend fun initDefaultInvoices() {
        val existing = db.invoiceDao().getAllInvoices().first()
        if (existing.isEmpty()) {
            db.invoiceDao().insertInvoices(
                listOf(
                    InvoiceEntity("INV-2026-09", "2026-09-01", "AUREOM HOME", 75.00, "PAID", "https://aureom.net/inv/202609.pdf"),
                    InvoiceEntity("INV-2026-08", "2026-08-01", "AUREOM HOME", 75.00, "PAID", "https://aureom.net/inv/202608.pdf"),
                    InvoiceEntity("INV-2026-07", "2026-07-01", "AUREOM HOME", 75.00, "PAID", "https://aureom.net/inv/202607.pdf")
                )
            )
        }
    }
}
