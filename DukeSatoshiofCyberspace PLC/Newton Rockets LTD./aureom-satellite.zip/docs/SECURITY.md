# AUREOM TELEMETRY & SECURITY SPECIFICATIONS

## Telemetry Schema

```json
{
  "timestamp": 1727670000000,
  "terminal_id": "AUR-8820-9941-UK",
  "satellite_id": "AUREOM-1042",
  "gateway_id": "LONDON-01",
  "signal_db": -68.4,
  "snr_db": 16.2,
  "downlink_mbps": 412.5,
  "uplink_mbps": 48.2,
  "latency_ms": 23,
  "packet_loss": 0.02,
  "temperature_c": 41.5,
  "power_w": 112.0
}
```

## Security & RBAC

- **Role-Based Access Control (RBAC)**: Enforces permission boundaries across CUSTOMER, TECHNICIAN, NETWORK_OPERATOR, and ADMIN roles.
- **TLS 1.3 Encryption**: Secure telemetry and command transport over WebSockets and REST.
- **Zero Raw Card Data Storage**: Tokenized payment card references (`•••• 1234`).
- **Firmware Verification**: Cryptographic SHA-256 signature verification prior to A/B partition staging.
