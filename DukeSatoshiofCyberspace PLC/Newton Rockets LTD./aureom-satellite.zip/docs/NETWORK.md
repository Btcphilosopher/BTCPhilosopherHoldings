# AUREOM SATELLITE NETWORKS - NETWORK SPECIFICATION

## Network Interfaces

- **IPv4 / IPv6 Dual Stack**: CGNAT IPv4 address allocation with dedicated IPv6 /64 prefix per terminal.
- **DHCP Server**: Built-in 192.168.1.0/24 LAN subnet manager with static IP lease reservation and custom DNS.
- **Wi-Fi 6E / 7**: Concurrent 2.4 GHz, 5 GHz, and 6 GHz tri-band radio streams.
- **Guest Network Isolation**: VLAN-tagged guest SSID (`AUREOM-GUEST`) isolated at layer 2 from primary LAN (`AUREOM-HOME`).
- **QoS Engine**: Priority queues for Work/VPN, Voice, and Gaming traffic over bulk download/updates.
