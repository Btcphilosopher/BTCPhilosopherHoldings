# AUREOM SATELLITE NETWORKS - SYSTEM ARCHITECTURE

## System Overview

Aureom Satellite Networks is a next-generation LEO (Low Earth Orbit) satellite broadband telecommunications platform.

```
CUSTOMER DEVICE
       ↓ (Wi-Fi 6E / Gigabit Ethernet)
SATELLITE TERMINAL (Phased Array)
       ↓ (Ka-Band RF Link 28-30 GHz / 18-20 GHz)
LEO SATELLITE CONSTELLATION (Walker-Delta Shell 550km)
       ↓ (Ka-Band Gateway Feeder Link)
SATELLITE GROUND GATEWAY (London-01, Frankfurt-02, Madrid-01)
       ↓ (Tier-1 Fiber Transit)
ISP CORE NETWORK & BGP PEERING
       ↓
PUBLIC INTERNET
```

## Subsystem Architecture

1. **Terminal Hardware Abstraction Layer (HAL)**
   - `TerminalAdapter`: Controls phased array beamsteering, DC power rail management, thermal throttling, and motorized auto-stowing.
   - `LinkBudgetEngine`: Implements real mathematical communications physics formulas ($FSPL$, slant range, $E_s/N_0$, $EIRP$, $G/T$, atmospheric rain fade, dynamic MCS mapping from QPSK up to 256APSK).

2. **Orbital & Handover Engine**
   - Simulates a synthetic Walker-Delta LEO constellation in 550 km altitude shells.
   - Tracks orbital contact windows (~8-12 minutes) and handles make-before-break inter-satellite beam handovers.

3. **ISP Core Network Abstraction**
   - IPv4 and IPv6 dual-stack routing.
   - CGNAT (Carrier-Grade NAT) and VLAN guest network isolation.
   - Anycast DNS (1.1.1.1) and configurable QoS traffic prioritization.

4. **Telemetry & Outage Diagnostics Engine**
   - 1 Hz live telemetry streaming via StateFlow and WebSockets.
   - 5-stage automated root-cause outage reasoning engine (Device -> Terminal -> RF Link -> Gateway -> Core ISP).
