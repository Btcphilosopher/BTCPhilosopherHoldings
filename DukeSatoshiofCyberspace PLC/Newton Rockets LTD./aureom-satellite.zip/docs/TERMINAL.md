# AUREOM SATELLITE TERMINAL SPECIFICATION

## Phased Array Antenna Array

- **Frequency Bands**: Ka-Band Uplink (28.5 – 30.0 GHz), Downlink (18.2 – 20.2 GHz)
- **Active Elements**: 1024 Tx/Rx beamforming modules with digital phase shifters
- **EIRP**: 45.2 dBW peak
- **G/T**: 14.2 dB/K at 50° elevation
- **Enclosure Rating**: IP67 all-weather sealed with heating elements for snow melting
- **Power Draw**: 112W active tracking, 35W idle
