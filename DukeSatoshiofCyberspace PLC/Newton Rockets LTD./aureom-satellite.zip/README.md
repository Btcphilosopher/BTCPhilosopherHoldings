# AUREOM SATELLITE NETWORKS

Production-grade telecommunications customer terminal, network management, and ISP service platform for Aureom Satellite Networks broadband LEO constellation.

## Features

- **Internet Status & Speeds**: Live telemetry displaying download Mbps, upload Mbps, latency, jitter, packet loss, and ground gateway.
- **Hardware Abstraction Layer (HAL)**: Pluggable hardware adapters (`TerminalAdapter`, `SatelliteLinkAdapter`, `GatewayAdapter`, `NetworkAdapter`, `TelemetryAdapter`).
- **RF Link Budget Engine**: Calculates Free-Space Path Loss ($FSPL$), $E_s/N_0$, Ka-Band rain attenuation, $EIRP$, $G/T$, and dynamic modulation & coding ($MCS$).
- **Orbital Handover Engine**: Walker-Delta LEO constellation contact pass tracking and make-before-break inter-satellite beam handover.
- **Guided 5-Stage Diagnostics**: Root cause outage reasoning chain (Device -> Terminal -> RF Link -> Gateway -> Core ISP).
- **Interactive Network Topology Canvas**: Interactive node inspection and animated data transfer packet flows.
- **Wi-Fi 6E & Guest Network Isolation**: Multi-band management, connected devices listing, bandwidth controls, and VLAN guest network isolation.
- **Data Usage & Service Plans**: Daily/Weekly/Monthly usage breakdown, plan switching (Home, Pro, Business, Remote), and invoice management.
- **OTA Firmware Management**: Firmware verification, staging to A/B partition, and reboot sequence.
- **Network Operations Center (NOC) & Engineering Mode**: Constellation health monitoring, optical ISL status, and advanced RF telemetry.
- **Role-Based Access Control (RBAC)**: Switch roles between CUSTOMER, TECHNICIAN, NETWORK_OPERATOR, and ADMIN.

## Setup & Execution

Run `compile_applet` to build and verify the Android application package.
