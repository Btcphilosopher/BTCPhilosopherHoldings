export type ValidationLevel = 
  | 'L0_UNIT_TESTS'
  | 'L1_ANALYTICAL_STATISTICAL'
  | 'L2_SYNTHETIC_VERIFIED'
  | 'L3_HISTORICAL_CALIBRATED'
  | 'L4_INDEPENDENT_CAMPAIGN_VALIDATED'
  | 'L5_INTEGRATED_SUBSYSTEM';

export type SensorQualityFlag = 'GOOD' | 'WARNING_NOISY' | 'FLATLINED' | 'SATURATED' | 'REPAIRED_SPIKE';

export type FailureMode = 
  | 'NOMINAL_SUCCESS'
  | 'NO_RESPONSE'
  | 'DELAYED_RESPONSE'
  | 'UNSTABLE_RESPONSE'
  | 'INSTRUMENTATION_FAILURE'
  | 'TEST_ABORT'
  | 'FEED_SYSTEM_ANOMALY'
  | 'THERMAL_ANOMALY'
  | 'ELECTRICAL_ANOMALY'
  | 'UNKNOWN';

export interface TelemetryPoint {
  time_s: number;
  chamber_pressure_bar: number;
  chamber_pressure_filtered_bar: number;
  chamber_pressure_expected_bar: number;
  chamber_pressure_p5_bar: number;
  chamber_pressure_p95_bar: number;
  lox_manifold_pressure_bar: number;
  ch4_manifold_pressure_bar: number;
  igniter_current_a: number;
  igniter_voltage_v: number;
  optical_flame_v: number;
  accelerometer_z_g: number;
  lox_inlet_temp_k: number;
  ch4_inlet_temp_k: number;
  dp_dt_bar_s: number;
}

export interface IgnitionEvent {
  id: string;
  name: string;
  label: string;
  time_s: number;
  detection_method: string;
  confidence: number;
  source_signals: string[];
  threshold_description: string;
  description: string;
}

export interface SensorHealth {
  sensor_id: string;
  channel_name: string;
  unit: string;
  sample_rate_hz: number;
  total_samples: number;
  missing_count: number;
  missing_pct: number;
  flatline_detected: boolean;
  saturation_detected: boolean;
  calibration_cert: string;
  status: 'HEALTHY' | 'WARNING' | 'CRITICAL';
}

export interface DataQualityAudit {
  test_id: string;
  audited_at: string;
  overall_passed: boolean;
  stages: {
    schema: { passed: boolean; details: string };
    units: { passed: boolean; details: string };
    timestamps: { passed: boolean; gaps: number; duplicates: number; dt_nominal_ms: number };
    missing_data: { passed: boolean; total_missing: number };
    outliers_spikes: { passed: boolean; clamped_count: number };
    sensor_health: { passed: boolean; details: string };
    synchronisation: { passed: boolean; rate_hz: number };
  };
  sensor_health: SensorHealth[];
  transformations: { timestamp: string; channel: string; action: string; note: string }[];
}

export interface IgnitionMetrics {
  induction_delay_ms: number;
  rise_time_10_90_ms: number;
  total_ignition_delay_ms: number;
  peak_pc_bar: number;
  overshoot_pct: number;
  settling_time_ms: number;
  fluctuation_rms_bar: number;
  fluctuation_roughness_pct: number;
  dominant_acoustic_freq_hz: number;
  acoustic_stability_status: 'STABLE_COMBUSTION' | 'ACOUSTIC_ANOMALY_WARNING';
}

export interface CampaignTestSummary {
  test_id: string;
  campaign_id: string;
  hardware_revision: string;
  date: string;
  delay_ms: number;
  rise_time_ms: number;
  peak_pc_bar: number;
  outcome: 'SUCCESS' | 'FAILURE' | 'CENSORED' | 'INVALID';
  failure_mode: FailureMode;
  inlet_temp_k: number;
  spark_energy_j: number;
}

export interface ReliabilityResult {
  sample_size: number;
  successes: number;
  failures: number;
  censored: number;
  invalid: number;
  point_estimate_pct: number;
  confidence_level: number;
  clopper_pearson_exact: { lower_pct: number; upper_pct: number };
  wilson_score: { lower_pct: number; upper_pct: number };
  bayesian_beta_binomial: {
    prior_alpha: number;
    prior_beta: number;
    posterior_alpha: number;
    posterior_beta: number;
    posterior_mean_pct: number;
    credible_lower_pct: number;
    credible_upper_pct: number;
  };
  weibull: {
    beta_shape: number;
    eta_scale_cycles: number;
    mttf_cycles: number;
    b10_life_cycles: number;
    regime: string;
  };
}

export interface RomCalibrationResult {
  parameter_name: string;
  nominal_value: number;
  calibrated_value: number;
  unit: string;
  standard_error: number;
  p_value: number;
  fit_quality_r2: number;
  rmse: number;
  mae: number;
  coverage_pct: number;
}

export interface SobolIndex {
  parameter: string;
  first_order_si: number;
  total_order_sti: number;
  interaction_effect: number;
  rank: number;
}
