import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { PipelineHeaderComponent } from './components/pipeline-header/pipeline-header';
import { OscillogramViewerComponent } from './components/oscillogram-viewer/oscillogram-viewer';
import { EventTimelineComponent } from './components/event-timeline/event-timeline';
import { QualityAuditComponent } from './components/quality-audit/quality-audit';
import { ReliabilityModuleComponent } from './components/reliability-module/reliability-module';
import { CalibrationModuleComponent } from './components/calibration-module/calibration-module';
import { UncertaintyModuleComponent } from './components/uncertainty-module/uncertainty-module';
import { DigitalTwinComponent } from './components/digital-twin/digital-twin';
import { RDossierComponent } from './components/r-dossier/r-dossier';
import { IgnitionDataService } from './services/ignition-data';

@Component({
  selector: 'app-root',
  imports: [
    CommonModule,
    MatIconModule,
    PipelineHeaderComponent,
    OscillogramViewerComponent,
    EventTimelineComponent,
    QualityAuditComponent,
    ReliabilityModuleComponent,
    CalibrationModuleComponent,
    UncertaintyModuleComponent,
    DigitalTwinComponent,
    RDossierComponent
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class App {
  dataService = inject(IgnitionDataService);
  activeTab = signal<string>('telemetry');

  onTestSelect(evt: Event) {
    const val = (evt.target as HTMLSelectElement).value;
    this.dataService.activeTestId.set(val);
    this.dataService.loadActiveTest();
  }
}
