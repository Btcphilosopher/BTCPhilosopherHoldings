import { ChangeDetectionStrategy, Component, inject, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { IgnitionDataService } from '../../services/ignition-data';

@Component({
  selector: 'app-reliability-module',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-6">
      <!-- Statistical Sample & Strict Uncertainty Banner -->
      <div class="bg-slate-900/90 border border-slate-800 rounded-xl p-5 shadow-lg">
        <div class="flex flex-wrap items-center justify-between gap-4">
          <div>
            <div class="flex items-center gap-2">
              <mat-icon class="text-purple-400">verified_user</mat-icon>
              <h3 class="font-mono text-base font-bold tracking-wide text-slate-100 uppercase">Ignition Reliability Engine</h3>
            </div>
            <p class="text-xs text-slate-400 font-mono mt-0.5">
              Newton Rockets Principle: Never report a reliability percentage without its sample size and exact uncertainty interval.
            </p>
          </div>

          <div class="flex items-center gap-3 font-mono text-xs">
            <div class="px-3 py-1.5 bg-slate-950 border border-slate-800 rounded">
              <span class="text-slate-500">SAMPLE SIZE:</span> <strong class="text-slate-100 text-sm ml-1">{{ dataService.reliabilityResult().sample_size }}</strong>
            </div>
            <div class="px-3 py-1.5 bg-emerald-950/60 border border-emerald-500/40 rounded text-emerald-300">
              <span class="text-emerald-500">SUCCESSES:</span> <strong class="text-sm ml-1">{{ dataService.reliabilityResult().successes }}</strong>
            </div>
            <div class="px-3 py-1.5 bg-rose-950/60 border border-rose-500/40 rounded text-rose-300">
              <span class="text-rose-500">FAILURES:</span> <strong class="text-sm ml-1">{{ dataService.reliabilityResult().failures }}</strong>
            </div>
          </div>
        </div>
      </div>

      <!-- Frequentist vs Bayesian Dual Workstation Grid -->
      <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <!-- Card 1: Binomial & Exact Clopper-Pearson Intervals -->
        <div class="bg-slate-900/80 border border-slate-800 rounded-xl p-5 shadow-lg flex flex-col justify-between">
          <div>
            <div class="flex items-center justify-between border-b border-slate-800 pb-3 mb-4">
              <div class="flex items-center gap-2">
                <mat-icon class="text-cyan-400">calculate</mat-icon>
                <h4 class="font-mono text-sm font-semibold text-slate-200 uppercase">Frequentist Exact Binomial Bounds</h4>
              </div>
              <span class="text-xs font-mono px-2 py-0.5 bg-slate-950 border border-slate-700 text-cyan-300 rounded">
                CL = {{ (dataService.confidenceLevel() * 100).toFixed(0) }}%
              </span>
            </div>

            <!-- Reliability Point Estimate -->
            <div class="bg-slate-950 border border-slate-800 rounded-xl p-4 mb-4">
              <div class="text-xs text-slate-400 font-mono">POINT ESTIMATE (k / n)</div>
              <div class="text-3xl font-bold font-mono text-slate-100 mt-1">
                {{ dataService.reliabilityResult().point_estimate_pct }}%
              </div>
              <div class="mt-3 space-y-2 font-mono text-xs">
                <div class="flex items-center justify-between py-1 border-b border-slate-800/60">
                  <span class="text-slate-400">Clopper-Pearson Exact 95% CI:</span>
                  <strong class="text-emerald-400">[{{ dataService.reliabilityResult().clopper_pearson_exact.lower_pct }}% - {{ dataService.reliabilityResult().clopper_pearson_exact.upper_pct }}%]</strong>
                </div>
                <div class="flex items-center justify-between py-1 border-b border-slate-800/60">
                  <span class="text-slate-400">Wilson Score Interval:</span>
                  <strong class="text-cyan-400">[{{ dataService.reliabilityResult().wilson_score.lower_pct }}% - {{ dataService.reliabilityResult().wilson_score.upper_pct }}%]</strong>
                </div>
                <div class="flex items-center justify-between py-1">
                  <span class="text-slate-400">Conservative Margin of Error:</span>
                  <span class="text-slate-300">± {{ (dataService.reliabilityResult().point_estimate_pct - dataService.reliabilityResult().clopper_pearson_exact.lower_pct).toFixed(1) }}%</span>
                </div>
              </div>
            </div>
          </div>

          <p class="text-[11px] text-slate-500 font-mono">
            Clopper-Pearson guarantees conservative minimum coverage via exact Beta quantiles: qbeta(alpha/2, k, n-k+1).
          </p>
        </div>

        <!-- Card 2: Bayesian Conjugate Beta-Binomial Updating -->
        <div class="bg-slate-900/80 border border-slate-800 rounded-xl p-5 shadow-lg flex flex-col justify-between">
          <div>
            <div class="flex items-center justify-between border-b border-slate-800 pb-3 mb-4">
              <div class="flex items-center gap-2">
                <mat-icon class="text-purple-400">insights</mat-icon>
                <h4 class="font-mono text-sm font-semibold text-slate-200 uppercase">Conjugate Bayesian Beta-Binomial</h4>
              </div>
              <span class="text-xs font-mono text-slate-400">Posterior Distribution</span>
            </div>

            <!-- Bayesian Posterior Metrics -->
            <div class="bg-slate-950 border border-slate-800 rounded-xl p-4 mb-4">
              <div class="flex items-center justify-between">
                <div>
                  <div class="text-xs text-slate-400 font-mono">POSTERIOR MEAN RELIABILITY</div>
                  <div class="text-3xl font-bold font-mono text-purple-300 mt-1">
                    {{ dataService.reliabilityResult().bayesian_beta_binomial.posterior_mean_pct }}%
                  </div>
                </div>
                <div class="text-right font-mono text-xs text-slate-400">
                  <div>PRIOR: <strong>Beta({{ dataService.bayesianPriorAlpha() }}, {{ dataService.bayesianPriorBeta() }})</strong></div>
                  <div class="text-purple-400 font-semibold">POST: <strong>Beta({{ dataService.reliabilityResult().bayesian_beta_binomial.posterior_alpha }}, {{ dataService.reliabilityResult().bayesian_beta_binomial.posterior_beta }})</strong></div>
                </div>
              </div>

              <!-- SVG Posterior Density Curve -->
              <div class="w-full h-28 mt-4 relative">
                <svg class="w-full h-full" viewBox="0 0 400 100" preserveAspectRatio="none">
                  <!-- Prior Curve (Dashed) -->
                  <path [attr.d]="priorSvgPath()" fill="none" stroke="#64748b" stroke-width="1.5" stroke-dasharray="3 3" />
                  <!-- Posterior Fill & Curve -->
                  <path [attr.d]="posteriorSvgPath()" fill="none" stroke="#a855f7" stroke-width="2.5" />
                </svg>
              </div>

              <div class="flex items-center justify-between mt-2 font-mono text-xs">
                <span class="text-slate-400">95% Equal-Tailed Credible Interval:</span>
                <strong class="text-purple-300">[{{ dataService.reliabilityResult().bayesian_beta_binomial.credible_lower_pct }}% - {{ dataService.reliabilityResult().bayesian_beta_binomial.credible_upper_pct }}%]</strong>
              </div>
            </div>
          </div>

          <div class="flex items-center gap-4 text-[11px] text-slate-400 font-mono">
            <div class="flex items-center gap-1.5">
              <span class="w-3 h-0.5 bg-slate-500 border-dashed"></span>
              <span>Prior Beta(1,1)</span>
            </div>
            <div class="flex items-center gap-1.5">
              <span class="w-3 h-1 bg-purple-500 rounded"></span>
              <span>Posterior Beta(47,3)</span>
            </div>
          </div>
        </div>
      </div>

      <!-- 2-Parameter Weibull Life Analysis & Failure Taxonomy -->
      <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <!-- Weibull Life Fit -->
        <div class="bg-slate-900/80 border border-slate-800 rounded-xl p-5 shadow-lg">
          <div class="flex items-center gap-2 border-b border-slate-800 pb-3 mb-4">
            <mat-icon class="text-amber-400">auto_graph</mat-icon>
            <h4 class="font-mono text-sm font-semibold text-slate-200 uppercase">2-Parameter Weibull Life Distribution</h4>
          </div>

          <div class="grid grid-cols-2 gap-3 font-mono text-xs mb-4">
            <div class="bg-slate-950 p-3 rounded-lg border border-slate-800">
              <span class="text-slate-500">SHAPE PARAMETER (beta):</span>
              <div class="text-xl font-bold text-amber-400 mt-1">{{ dataService.reliabilityResult().weibull.beta_shape }}</div>
              <p class="text-[10px] text-slate-400 mt-0.5">{{ dataService.reliabilityResult().weibull.regime }}</p>
            </div>
            <div class="bg-slate-950 p-3 rounded-lg border border-slate-800">
              <span class="text-slate-500">SCALE PARAMETER (eta):</span>
              <div class="text-xl font-bold text-slate-100 mt-1">{{ dataService.reliabilityResult().weibull.eta_scale_cycles }} <span class="text-xs font-normal">cycles</span></div>
              <p class="text-[10px] text-slate-400 mt-0.5">Characteristic life (63.2% failed)</p>
            </div>
          </div>

          <div class="space-y-2 font-mono text-xs bg-slate-950 p-3 rounded-lg border border-slate-800">
            <div class="flex justify-between text-slate-300">
              <span>Mean Time To Failure (MTTF):</span>
              <strong class="text-slate-100">{{ dataService.reliabilityResult().weibull.mttf_cycles }} firings</strong>
            </div>
            <div class="flex justify-between text-slate-300">
              <span>B10 Safe Design Life (10% Unreliability):</span>
              <strong class="text-amber-300">{{ dataService.reliabilityResult().weibull.b10_life_cycles }} firings</strong>
            </div>
          </div>
        </div>

        <!-- Failure Mode Taxonomy & Root Cause Rigour -->
        <div class="bg-slate-900/80 border border-slate-800 rounded-xl p-5 shadow-lg">
          <div class="flex items-center justify-between border-b border-slate-800 pb-3 mb-4">
            <div class="flex items-center gap-2">
              <mat-icon class="text-rose-400">bug_report</mat-icon>
              <h4 class="font-mono text-sm font-semibold text-slate-200 uppercase">Failure Mode Taxonomy & Root Cause</h4>
            </div>
            <span class="text-xs font-mono text-slate-400">2 Anomalies Recorded</span>
          </div>

          <div class="space-y-2 font-mono text-xs">
            <div class="p-3 bg-slate-950 border border-rose-900/60 rounded-lg">
              <div class="flex items-center justify-between">
                <span class="font-bold text-rose-300">TEST-HOTFIRE-014</span>
                <span class="px-1.5 py-0.5 bg-rose-950 border border-rose-800 text-rose-300 rounded text-[10px]">DELAYED_RESPONSE</span>
              </div>
              <p class="text-slate-300 mt-1 text-[11px]">Induction delay exceeded 100ms threshold (measured 112.4ms).</p>
              <div class="mt-2 text-[10px] text-slate-400 flex flex-wrap gap-3">
                <span>[OBSERVED]: Low spark current (0.45A)</span>
                <span>[INFERRED]: Capacitor bleeder leak</span>
                <span class="text-amber-400">[HYPOTHESISED]: Rev-C2 harness insulation</span>
              </div>
            </div>

            <div class="p-3 bg-slate-950 border border-amber-900/60 rounded-lg">
              <div class="flex items-center justify-between">
                <span class="font-bold text-amber-300">TEST-HOTFIRE-031</span>
                <span class="px-1.5 py-0.5 bg-amber-950 border border-amber-800 text-amber-300 rounded text-[10px]">FEED_SYSTEM_ANOMALY</span>
              </div>
              <p class="text-slate-300 mt-1 text-[11px]">LOX manifold chill temperature was 114K prior to arming command.</p>
              <div class="mt-2 text-[10px] text-slate-400 flex flex-wrap gap-3">
                <span>[OBSERVED]: Vapor lock bubble</span>
                <span>[INFERRED]: Slow prime fill</span>
                <span class="text-amber-400">[HYPOTHESISED]: Pre-purge timer too short</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  `
})
export class ReliabilityModuleComponent {
  dataService = inject(IgnitionDataService);

  readonly priorSvgPath = computed(() => {
    // Flat uniform prior
    return 'M 0 90 L 400 90';
  });

  readonly posteriorSvgPath = computed(() => {
    // Bell-shaped Beta(47, 3) peaked around 0.94
    const points: string[] = [];
    for (let i = 0; i <= 400; i += 4) {
      const p = i / 400;
      // Approximate Beta density peaked at 0.94
      let dens = 0;
      if (p > 0.75) {
        dens = Math.exp(-Math.pow((p - 0.94) / 0.035, 2)) * 80;
      }
      const y = Math.max(10, 95 - dens);
      points.push(`${i.toFixed(1)} ${y.toFixed(1)}`);
    }
    return `M ${points.join(' L ')}`;
  });
}
