import { ChangeDetectionStrategy, Component, inject, signal, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { IgnitionDataService } from '../../services/ignition-data';
import { TelemetryPoint } from '../../models/ignition.types';

@Component({
  selector: 'app-oscillogram-viewer',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="bg-slate-900/80 border border-slate-800 rounded-xl overflow-hidden shadow-lg">
      <!-- Toolbar & Controls -->
      <div class="px-4 py-3 bg-slate-950/70 border-b border-slate-800 flex flex-wrap items-center justify-between gap-3">
        <div class="flex items-center gap-2">
          <div class="w-2.5 h-2.5 rounded-full bg-cyan-400"></div>
          <span class="font-mono text-sm font-semibold tracking-wide text-slate-100 uppercase">Synchronized Multi-Channel Oscillogram</span>
          <span class="text-xs text-slate-400 font-mono">| Zero-Phase 1000 Hz DAAS</span>
        </div>

        <div class="flex flex-wrap items-center gap-2 text-xs font-mono">
          <!-- Zoom presets -->
          <div class="flex items-center bg-slate-900 border border-slate-700/80 rounded overflow-hidden">
            <button 
              type="button"
              (click)="setZoom('full')" 
              [class.bg-slate-800]="zoomPreset() === 'full'"
              [class.text-cyan-400]="zoomPreset() === 'full'"
              class="px-2.5 py-1 text-slate-300 hover:text-white transition">
              Full (0-1.0s)
            </button>
            <button 
              type="button"
              (click)="setZoom('transient')" 
              [class.bg-slate-800]="zoomPreset() === 'transient'"
              [class.text-cyan-400]="zoomPreset() === 'transient'"
              class="px-2.5 py-1 text-slate-300 hover:text-white border-l border-slate-700/80 transition">
              Transient (0.45-0.70s)
            </button>
            <button 
              type="button"
              (click)="setZoom('steady')" 
              [class.bg-slate-800]="zoomPreset() === 'steady'"
              [class.text-cyan-400]="zoomPreset() === 'steady'"
              class="px-2.5 py-1 text-slate-300 hover:text-white border-l border-slate-700/80 transition">
              Steady (0.60-1.0s)
            </button>
          </div>

          <!-- Unit Selector -->
          <div class="flex items-center bg-slate-900 border border-slate-700/80 rounded overflow-hidden">
            <button 
              type="button"
              (click)="dataService.selectedPressureUnit.set('bar')" 
              [class.bg-cyan-950]="dataService.selectedPressureUnit() === 'bar'"
              [class.text-cyan-300]="dataService.selectedPressureUnit() === 'bar'"
              class="px-2 py-1 text-slate-300 transition">
              bar
            </button>
            <button 
              type="button"
              (click)="dataService.selectedPressureUnit.set('MPa')" 
              [class.bg-cyan-950]="dataService.selectedPressureUnit() === 'MPa'"
              [class.text-cyan-300]="dataService.selectedPressureUnit() === 'MPa'"
              class="px-2 py-1 text-slate-300 border-l border-slate-700/80 transition">
              MPa
            </button>
            <button 
              type="button"
              (click)="dataService.selectedPressureUnit.set('psi')" 
              [class.bg-cyan-950]="dataService.selectedPressureUnit() === 'psi'"
              [class.text-cyan-300]="dataService.selectedPressureUnit() === 'psi'"
              class="px-2 py-1 text-slate-300 border-l border-slate-700/80 transition">
              psi
            </button>
          </div>

          <!-- Toggles -->
          <button 
            type="button"
            (click)="toggleFilter()"
            [class.bg-cyan-950]="dataService.filterEnabled()"
            [class.border-cyan-500]="dataService.filterEnabled()"
            [class.text-cyan-300]="dataService.filterEnabled()"
            class="px-2.5 py-1 bg-slate-900 border border-slate-700 rounded text-slate-300 flex items-center gap-1 transition">
            <mat-icon class="icon-sm">tune</mat-icon>
            <span>{{ dataService.filterEnabled() ? 'Filtered' : 'Raw Data' }}</span>
          </button>

          <button 
            type="button"
            (click)="toggleConfidenceBands()"
            [class.bg-cyan-950]="dataService.showConfidenceBands()"
            [class.border-cyan-500]="dataService.showConfidenceBands()"
            [class.text-cyan-300]="dataService.showConfidenceBands()"
            class="px-2.5 py-1 bg-slate-900 border border-slate-700 rounded text-slate-300 flex items-center gap-1 transition">
            <mat-icon class="icon-sm">stacked_line_chart</mat-icon>
            <span>95% Uncertainty Band</span>
          </button>

          <button 
            type="button"
            (click)="toggleExpectedBand()"
            [class.bg-cyan-950]="dataService.showExpectedBand()"
            [class.border-cyan-500]="dataService.showExpectedBand()"
            [class.text-cyan-300]="dataService.showExpectedBand()"
            class="px-2.5 py-1 bg-slate-900 border border-slate-700 rounded text-slate-300 flex items-center gap-1 transition">
            <mat-icon class="icon-sm">timeline</mat-icon>
            <span>Expected ROM</span>
          </button>
        </div>
      </div>

      <!-- Main Graph Area (SVG High-Precision Chart) -->
      <div class="relative p-4 bg-slate-950 oscilloscope-grid select-none" (mousemove)="onMouseMove($event)" (mouseleave)="hoverPoint.set(null)">
        <!-- Hover Readout HUD Bar -->
        <div class="flex flex-wrap items-center justify-between bg-slate-900/90 border border-slate-800 px-3 py-1.5 rounded-lg mb-3 text-xs font-mono">
          <div class="flex items-center gap-4">
            <div><span class="text-slate-500">TIME:</span> <strong class="text-cyan-400">{{ (activePoint()?.time_s ?? 0.58).toFixed(3) }} s</strong></div>
            <div><span class="text-slate-500">CHAMBER Pc:</span> <strong class="text-emerald-400">{{ formatPressure(activePoint()?.chamber_pressure_filtered_bar ?? 65.0) }}</strong></div>
            <div><span class="text-slate-500">LOX MANIFOLD:</span> <strong class="text-rose-400">{{ formatPressure(activePoint()?.lox_manifold_pressure_bar ?? 70.2) }}</strong></div>
            <div><span class="text-slate-500">CH4 MANIFOLD:</span> <strong class="text-amber-400">{{ formatPressure(activePoint()?.ch4_manifold_pressure_bar ?? 57.0) }}</strong></div>
          </div>
          <div class="flex items-center gap-4">
            <div><span class="text-slate-500">IGNITER CURRENT:</span> <strong class="text-yellow-300">{{ (activePoint()?.igniter_current_a ?? 0).toFixed(2) }} A</strong></div>
            <div><span class="text-slate-500">FLAME UV:</span> <strong class="text-sky-300">{{ (activePoint()?.optical_flame_v ?? 0).toFixed(2) }} V</strong></div>
            <div><span class="text-slate-500">dP/dt:</span> <strong class="text-purple-300">{{ (activePoint()?.dp_dt_bar_s ?? 0).toFixed(1) }} bar/s</strong></div>
          </div>
        </div>

        <!-- SVG Container -->
        <div class="w-full h-80 sm:h-96 relative">
          <svg class="w-full h-full" viewBox="0 0 1000 360" preserveAspectRatio="none">
            <defs>
              <!-- Uncertainty Band Gradient -->
              <linearGradient id="uncertaintyGradient" x1="0%" y1="0%" x2="0%" y2="100%">
                <stop offset="0%" stop-color="#0284c7" stop-opacity="0.25"/>
                <stop offset="100%" stop-color="#0284c7" stop-opacity="0.05"/>
              </linearGradient>
            </defs>

            <!-- Horizontal Grid Lines & Y Axis Labels -->
            @for (grid of yGridLines(); track grid.val) {
              <line x1="60" [attr.y1]="grid.y" x2="980" [attr.y2]="grid.y" stroke="#1e293b" stroke-width="1" stroke-dasharray="4 4" />
              <text x="50" [attr.y]="grid.y + 4" fill="#64748b" font-size="10" font-family="JetBrains Mono" text-anchor="end">{{ grid.label }}</text>
            }

            <!-- Vertical Grid Lines & Time Labels -->
            @for (tGrid of xGridLines(); track tGrid.t) {
              <line [attr.x1]="tGrid.x" y1="20" [attr.x2]="tGrid.x" y2="320" stroke="#1e293b" stroke-width="1" stroke-dasharray="4 4" />
              <text [attr.x]="tGrid.x" y="340" fill="#64748b" font-size="10" font-family="JetBrains Mono" text-anchor="middle">{{ tGrid.t.toFixed(2) }}s</text>
            }

            <!-- 95% Uncertainty Band Fill Polygon -->
            @if (dataService.showConfidenceBands() && uncertaintyBandPolygon()) {
              <polygon [attr.points]="uncertaintyBandPolygon()" fill="url(#uncertaintyGradient)" />
            }

            <!-- Expected ROM Nominal Path -->
            @if (dataService.showExpectedBand() && expectedPath()) {
              <path [attr.d]="expectedPath()" fill="none" stroke="#94a3b8" stroke-width="1.5" stroke-dasharray="6 4" />
            }

            <!-- LOX Manifold Line -->
            @if (loxPath()) {
              <path [attr.d]="loxPath()" fill="none" stroke="#f43f5e" stroke-width="1.5" opacity="0.8" />
            }

            <!-- CH4 Manifold Line -->
            @if (ch4Path()) {
              <path [attr.d]="ch4Path()" fill="none" stroke="#f59e0b" stroke-width="1.5" opacity="0.8" />
            }

            <!-- Optical Flame Photodiode Line -->
            @if (flamePath()) {
              <path [attr.d]="flamePath()" fill="none" stroke="#38bdf8" stroke-width="1.5" opacity="0.75" />
            }

            <!-- Igniter Current Line -->
            @if (currentPath()) {
              <path [attr.d]="currentPath()" fill="none" stroke="#facc15" stroke-width="1.5" opacity="0.9" />
            }

            <!-- Measured Chamber Pressure Line (Pc) -->
            @if (pcPath()) {
              <path [attr.d]="pcPath()" fill="none" stroke="#10b981" stroke-width="2.5" />
            }

            <!-- Event Vertical Markers -->
            @if (dataService.showEventMarkers()) {
              @for (evt of visibleEvents(); track evt.id) {
                <line [attr.x1]="timeToX(evt.time_s)" y1="20" [attr.x2]="timeToX(evt.time_s)" y2="320" stroke="#38bdf8" stroke-width="1.5" stroke-dasharray="2 2" />
                <rect [attr.x]="timeToX(evt.time_s) - 30" y="22" width="60" height="16" rx="3" fill="#0c4a6e" stroke="#0284c7" stroke-width="1"/>
                <text [attr.x]="timeToX(evt.time_s)" y="34" fill="#bae6fd" font-size="8" font-family="JetBrains Mono" font-weight="bold" text-anchor="middle">{{ evt.name }}</text>
              }
            }

            <!-- Interactive Cursor Line -->
            @if (activeCursorX()) {
              <line [attr.x1]="activeCursorX()" y1="20" [attr.x2]="activeCursorX()" y2="320" stroke="#f8fafc" stroke-width="1" opacity="0.75" />
              <circle [attr.cx]="activeCursorX()" [attr.cy]="activePcY()" r="4" fill="#10b981" stroke="#f8fafc" stroke-width="1.5" />
            }
          </svg>
        </div>

        <!-- Legend Bar -->
        <div class="mt-3 pt-3 border-t border-slate-800/80 flex flex-wrap items-center justify-between text-xs font-mono gap-y-2">
          <div class="flex flex-wrap items-center gap-4">
            <div class="flex items-center gap-1.5">
              <span class="w-3 h-1 bg-emerald-500 rounded"></span>
              <span class="text-slate-200">Chamber Pressure Pc (Filtered)</span>
            </div>
            <div class="flex items-center gap-1.5">
              <span class="w-3 h-1 bg-rose-500 rounded"></span>
              <span class="text-slate-300">LOX Manifold</span>
            </div>
            <div class="flex items-center gap-1.5">
              <span class="w-3 h-1 bg-amber-500 rounded"></span>
              <span class="text-slate-300">CH4 Manifold</span>
            </div>
            <div class="flex items-center gap-1.5">
              <span class="w-3 h-1 bg-yellow-400 rounded"></span>
              <span class="text-slate-300">Igniter Current (A)</span>
            </div>
            <div class="flex items-center gap-1.5">
              <span class="w-3 h-1 bg-sky-400 rounded"></span>
              <span class="text-slate-300">UV Flame Emission (V)</span>
            </div>
            <div class="flex items-center gap-1.5">
              <span class="w-3 h-1 border-t border-slate-400 border-dashed"></span>
              <span class="text-slate-400">Expected ROM</span>
            </div>
            <div class="flex items-center gap-1.5">
              <span class="w-3 h-3 bg-sky-900/50 border border-sky-500/40 rounded"></span>
              <span class="text-slate-400">95% Uncertainty Band</span>
            </div>
          </div>
          <div class="text-[11px] text-slate-500">
            Hover to inspect exact synchronized slice
          </div>
        </div>
      </div>
    </div>
  `
})
export class OscillogramViewerComponent {
  dataService = inject(IgnitionDataService);

  readonly zoomPreset = signal<'full' | 'transient' | 'steady'>('full');
  readonly hoverPoint = signal<TelemetryPoint | null>(null);

  readonly timeRange = computed(() => {
    switch (this.zoomPreset()) {
      case 'transient': return { min: 0.45, max: 0.70 };
      case 'steady': return { min: 0.60, max: 1.00 };
      default: return { min: 0.0, max: 1.0 };
    }
  });

  readonly visiblePoints = computed(() => {
    const range = this.timeRange();
    return this.dataService.telemetryData().filter(p => p.time_s >= range.min && p.time_s <= range.max);
  });

  readonly activePoint = computed(() => {
    return this.hoverPoint() || this.dataService.telemetryData()[580] || this.dataService.telemetryData()[0];
  });

  setZoom(preset: 'full' | 'transient' | 'steady') {
    this.zoomPreset.set(preset);
  }

  toggleFilter() {
    this.dataService.filterEnabled.set(!this.dataService.filterEnabled());
  }

  toggleConfidenceBands() {
    this.dataService.showConfidenceBands.set(!this.dataService.showConfidenceBands());
  }

  toggleExpectedBand() {
    this.dataService.showExpectedBand.set(!this.dataService.showExpectedBand());
  }

  formatPressure(barVal: number): string {
    const unit = this.dataService.selectedPressureUnit();
    if (unit === 'MPa') return `${(barVal / 10).toFixed(2)} MPa`;
    if (unit === 'psi') return `${(barVal * 14.5038).toFixed(1)} psi`;
    return `${barVal.toFixed(2)} bar`;
  }

  timeToX(t: number): number {
    const range = this.timeRange();
    const frac = (t - range.min) / (range.max - range.min);
    return 60 + Math.max(0, Math.min(920, frac * 920));
  }

  valToY(val: number, maxVal = 80): number {
    const frac = Math.max(0, Math.min(1.0, val / maxVal));
    return 310 - (frac * 280);
  }

  readonly xGridLines = computed(() => {
    const range = this.timeRange();
    const count = 6;
    const lines = [];
    for (let i = 0; i <= count; i++) {
      const t = range.min + (i / count) * (range.max - range.min);
      lines.push({ t, x: this.timeToX(t) });
    }
    return lines;
  });

  readonly yGridLines = computed(() => {
    const unit = this.dataService.selectedPressureUnit();
    return [
      { val: 0, y: this.valToY(0), label: unit === 'MPa' ? '0.0 MPa' : (unit === 'psi' ? '0 psi' : '0 bar') },
      { val: 20, y: this.valToY(20), label: unit === 'MPa' ? '2.0 MPa' : (unit === 'psi' ? '290 psi' : '20 bar') },
      { val: 40, y: this.valToY(40), label: unit === 'MPa' ? '4.0 MPa' : (unit === 'psi' ? '580 psi' : '40 bar') },
      { val: 65, y: this.valToY(65), label: unit === 'MPa' ? '6.5 MPa' : (unit === 'psi' ? '942 psi' : '65 bar') },
      { val: 80, y: this.valToY(80), label: unit === 'MPa' ? '8.0 MPa' : (unit === 'psi' ? '1160 psi' : '80 bar') }
    ];
  });

  readonly visibleEvents = computed(() => {
    const range = this.timeRange();
    return this.dataService.events().filter(e => e.time_s >= range.min && e.time_s <= range.max);
  });

  readonly pcPath = computed(() => {
    const pts = this.visiblePoints();
    if (pts.length === 0) return '';
    const filtered = this.dataService.filterEnabled();
    return pts.map((p, idx) => {
      const x = this.timeToX(p.time_s);
      const val = filtered ? p.chamber_pressure_filtered_bar : p.chamber_pressure_bar;
      const y = this.valToY(val);
      return `${idx === 0 ? 'M' : 'L'} ${x.toFixed(1)} ${y.toFixed(1)}`;
    }).join(' ');
  });

  readonly expectedPath = computed(() => {
    const pts = this.visiblePoints();
    if (pts.length === 0) return '';
    return pts.map((p, idx) => {
      const x = this.timeToX(p.time_s);
      const y = this.valToY(p.chamber_pressure_expected_bar);
      return `${idx === 0 ? 'M' : 'L'} ${x.toFixed(1)} ${y.toFixed(1)}`;
    }).join(' ');
  });

  readonly loxPath = computed(() => {
    const pts = this.visiblePoints();
    if (pts.length === 0) return '';
    return pts.map((p, idx) => {
      const x = this.timeToX(p.time_s);
      const y = this.valToY(p.lox_manifold_pressure_bar);
      return `${idx === 0 ? 'M' : 'L'} ${x.toFixed(1)} ${y.toFixed(1)}`;
    }).join(' ');
  });

  readonly ch4Path = computed(() => {
    const pts = this.visiblePoints();
    if (pts.length === 0) return '';
    return pts.map((p, idx) => {
      const x = this.timeToX(p.time_s);
      const y = this.valToY(p.ch4_manifold_pressure_bar);
      return `${idx === 0 ? 'M' : 'L'} ${x.toFixed(1)} ${y.toFixed(1)}`;
    }).join(' ');
  });

  readonly currentPath = computed(() => {
    const pts = this.visiblePoints();
    if (pts.length === 0) return '';
    return pts.map((p, idx) => {
      const x = this.timeToX(p.time_s);
      const scaledVal = (p.igniter_current_a / 3.0) * 16.0;
      const y = this.valToY(scaledVal);
      return `${idx === 0 ? 'M' : 'L'} ${x.toFixed(1)} ${y.toFixed(1)}`;
    }).join(' ');
  });

  readonly flamePath = computed(() => {
    const pts = this.visiblePoints();
    if (pts.length === 0) return '';
    return pts.map((p, idx) => {
      const x = this.timeToX(p.time_s);
      const scaledVal = (p.optical_flame_v / 5.0) * 30.0;
      const y = this.valToY(scaledVal);
      return `${idx === 0 ? 'M' : 'L'} ${x.toFixed(1)} ${y.toFixed(1)}`;
    }).join(' ');
  });

  readonly uncertaintyBandPolygon = computed(() => {
    const pts = this.visiblePoints();
    if (pts.length === 0) return '';
    const upperPoints = pts.map(p => `${this.timeToX(p.time_s).toFixed(1)},${this.valToY(p.chamber_pressure_p95_bar).toFixed(1)}`);
    const lowerPoints = [...pts].reverse().map(p => `${this.timeToX(p.time_s).toFixed(1)},${this.valToY(p.chamber_pressure_p5_bar).toFixed(1)}`);
    return `${upperPoints.join(' ')} ${lowerPoints.join(' ')}`;
  });

  readonly activeCursorX = computed(() => {
    const pt = this.activePoint();
    return pt ? this.timeToX(pt.time_s) : null;
  });

  readonly activePcY = computed(() => {
    const pt = this.activePoint();
    return pt ? this.valToY(pt.chamber_pressure_filtered_bar) : 0;
  });

  onMouseMove(evt: MouseEvent) {
    const target = evt.currentTarget as HTMLElement;
    const rect = target.getBoundingClientRect();
    const xRel = evt.clientX - rect.left;
    const frac = Math.max(0, Math.min(1.0, (xRel - 60) / (rect.width - 80)));
    const range = this.timeRange();
    const tTarget = range.min + frac * (range.max - range.min);
    
    const allPts = this.dataService.telemetryData();
    const idx = Math.max(0, Math.min(allPts.length - 1, Math.round(tTarget * 1000)));
    this.hoverPoint.set(allPts[idx]);
  }
}
