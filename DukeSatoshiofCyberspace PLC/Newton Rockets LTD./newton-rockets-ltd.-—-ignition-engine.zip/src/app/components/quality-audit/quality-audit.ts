import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { IgnitionDataService } from '../../services/ignition-data';

@Component({
  selector: 'app-quality-audit',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-6">
      <!-- 8-Stage Pipeline Progress Strip -->
      <div class="bg-slate-900/80 border border-slate-800 rounded-xl p-5 shadow-lg">
        <div class="flex flex-wrap items-center justify-between gap-2 mb-4">
          <div class="flex items-center gap-2">
            <mat-icon class="text-emerald-400">fact_check</mat-icon>
            <h3 class="font-mono text-sm font-semibold tracking-wide text-slate-100 uppercase">8-Stage Automated Data Quality & Health Audit</h3>
          </div>
          <div class="flex items-center gap-2">
            <span class="px-2.5 py-0.5 bg-emerald-950 border border-emerald-500 text-emerald-300 font-mono text-xs rounded-full font-bold">
              AUDIT STATUS: 100% PASSED (8/8)
            </span>
            <button 
              type="button" 
              (click)="reRunAudit()"
              class="px-3 py-1 bg-cyan-950 hover:bg-cyan-900 border border-cyan-500 text-cyan-300 font-mono text-xs rounded transition flex items-center gap-1">
              <mat-icon class="icon-sm" [class.animate-spin]="isAuditing()">refresh</mat-icon>
              <span>{{ isAuditing() ? 'Re-Auditing...' : 'Re-Run Audit' }}</span>
            </button>
          </div>
        </div>

        <!-- Stages Grid -->
        <div class="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-2 font-mono text-xs">
          <!-- Stage 1 -->
          <div class="bg-slate-950 border border-emerald-800/80 p-2.5 rounded-lg flex flex-col justify-between">
            <div class="flex items-center justify-between text-[10px] text-slate-400 mb-1">
              <span>01. IMPORT</span>
              <mat-icon class="icon-sm text-emerald-400">check_circle</mat-icon>
            </div>
            <div class="text-emerald-300 font-bold">PARQUET</div>
            <p class="text-[9px] text-slate-500 mt-1">SHA256 locked</p>
          </div>

          <!-- Stage 2 -->
          <div class="bg-slate-950 border border-emerald-800/80 p-2.5 rounded-lg flex flex-col justify-between">
            <div class="flex items-center justify-between text-[10px] text-slate-400 mb-1">
              <span>02. SCHEMA</span>
              <mat-icon class="icon-sm text-emerald-400">check_circle</mat-icon>
            </div>
            <div class="text-emerald-300 font-bold">12/12 HDRS</div>
            <p class="text-[9px] text-slate-500 mt-1">All meta valid</p>
          </div>

          <!-- Stage 3 -->
          <div class="bg-slate-950 border border-emerald-800/80 p-2.5 rounded-lg flex flex-col justify-between">
            <div class="flex items-center justify-between text-[10px] text-slate-400 mb-1">
              <span>03. UNITS</span>
              <mat-icon class="icon-sm text-emerald-400">check_circle</mat-icon>
            </div>
            <div class="text-emerald-300 font-bold">VERIFIED</div>
            <p class="text-[9px] text-slate-500 mt-1">bar, K, V, A, g</p>
          </div>

          <!-- Stage 4 -->
          <div class="bg-slate-950 border border-emerald-800/80 p-2.5 rounded-lg flex flex-col justify-between">
            <div class="flex items-center justify-between text-[10px] text-slate-400 mb-1">
              <span>04. CLOCKS</span>
              <mat-icon class="icon-sm text-emerald-400">check_circle</mat-icon>
            </div>
            <div class="text-emerald-300 font-bold">MONOTONIC</div>
            <p class="text-[9px] text-slate-500 mt-1">0 gaps, 0 dupes</p>
          </div>

          <!-- Stage 5 -->
          <div class="bg-slate-950 border border-emerald-800/80 p-2.5 rounded-lg flex flex-col justify-between">
            <div class="flex items-center justify-between text-[10px] text-slate-400 mb-1">
              <span>05. MISSING</span>
              <mat-icon class="icon-sm text-emerald-400">check_circle</mat-icon>
            </div>
            <div class="text-emerald-300 font-bold">0.0% NA</div>
            <p class="text-[9px] text-slate-500 mt-1">1000/1000 pts</p>
          </div>

          <!-- Stage 6 -->
          <div class="bg-slate-950 border border-emerald-800/80 p-2.5 rounded-lg flex flex-col justify-between">
            <div class="flex items-center justify-between text-[10px] text-slate-400 mb-1">
              <span>06. OUTLIERS</span>
              <mat-icon class="icon-sm text-emerald-400">check_circle</mat-icon>
            </div>
            <div class="text-emerald-300 font-bold">CLEAN</div>
            <p class="text-[9px] text-slate-500 mt-1">MAD Z &lt; 4.5</p>
          </div>

          <!-- Stage 7 -->
          <div class="bg-slate-950 border border-emerald-800/80 p-2.5 rounded-lg flex flex-col justify-between">
            <div class="flex items-center justify-between text-[10px] text-slate-400 mb-1">
              <span>07. HEALTH</span>
              <mat-icon class="icon-sm text-emerald-400">check_circle</mat-icon>
            </div>
            <div class="text-emerald-300 font-bold">6/6 HEALTHY</div>
            <p class="text-[9px] text-slate-500 mt-1">0 Flat / 0 Sat</p>
          </div>

          <!-- Stage 8 -->
          <div class="bg-slate-950 border border-emerald-800/80 p-2.5 rounded-lg flex flex-col justify-between">
            <div class="flex items-center justify-between text-[10px] text-slate-400 mb-1">
              <span>08. SYNC</span>
              <mat-icon class="icon-sm text-emerald-400">check_circle</mat-icon>
            </div>
            <div class="text-emerald-300 font-bold">1000 Hz</div>
            <p class="text-[9px] text-slate-500 mt-1">Uniform dt 1ms</p>
          </div>
        </div>
      </div>

      <!-- Sensor Health Detailed Table -->
      <div class="bg-slate-900/80 border border-slate-800 rounded-xl overflow-hidden shadow-lg">
        <div class="px-4 py-3 bg-slate-950/70 border-b border-slate-800 flex items-center justify-between">
          <div class="flex items-center gap-2">
            <mat-icon class="text-cyan-400">sensors</mat-icon>
            <h3 class="font-mono text-sm font-semibold tracking-wide text-slate-100 uppercase">Instrument Channel Health & Traceable Calibrations</h3>
          </div>
          <span class="text-xs text-slate-400 font-mono">UKAS & NIST Traceable Calibration Certificates</span>
        </div>

        <div class="p-4 overflow-x-auto">
          <table class="w-full text-left font-mono text-xs">
            <thead>
              <tr class="border-b border-slate-800 text-slate-400">
                <th class="py-2 px-3">Transducer ID</th>
                <th class="py-2 px-3">Signal Channel</th>
                <th class="py-2 px-3">Unit</th>
                <th class="py-2 px-3">DAQ Rate</th>
                <th class="py-2 px-3">Samples</th>
                <th class="py-2 px-3">Missing</th>
                <th class="py-2 px-3">Flatline</th>
                <th class="py-2 px-3">Saturation</th>
                <th class="py-2 px-3">Calibration Certificate</th>
                <th class="py-2 px-3 text-right">Status</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-slate-800/60 text-slate-200">
              @for (s of dataService.dataAudit()?.sensor_health; track s.sensor_id) {
                <tr class="hover:bg-slate-800/30">
                  <td class="py-2.5 px-3 font-bold text-cyan-300">{{ s.sensor_id }}</td>
                  <td class="py-2.5 px-3 font-semibold text-slate-100">{{ s.channel_name }}</td>
                  <td class="py-2.5 px-3 text-slate-400">{{ s.unit }}</td>
                  <td class="py-2.5 px-3 text-slate-300">{{ s.sample_rate_hz }} Hz</td>
                  <td class="py-2.5 px-3 text-slate-300">{{ s.total_samples }}</td>
                  <td class="py-2.5 px-3 text-emerald-400">{{ s.missing_pct }}%</td>
                  <td class="py-2.5 px-3 text-slate-400">{{ s.flatline_detected ? 'FAIL' : 'NO' }}</td>
                  <td class="py-2.5 px-3 text-slate-400">{{ s.saturation_detected ? 'FAIL' : 'NO' }}</td>
                  <td class="py-2.5 px-3 text-slate-400 underline">{{ s.calibration_cert }}</td>
                  <td class="py-2.5 px-3 text-right">
                    <span class="px-2 py-0.5 bg-emerald-950 border border-emerald-500/50 text-emerald-300 rounded font-bold text-[10px]">
                      {{ s.status }}
                    </span>
                  </td>
                </tr>
              }
            </tbody>
          </table>
        </div>
      </div>

      <!-- Non-Destructive Provenance Log -->
      <div class="bg-slate-900/80 border border-slate-800 rounded-xl p-4 shadow-lg">
        <div class="flex items-center gap-2 mb-3">
          <mat-icon class="text-amber-400">history_edu</mat-icon>
          <h3 class="font-mono text-sm font-semibold tracking-wide text-slate-100 uppercase">Non-Destructive Transformation Audit Trail</h3>
        </div>
        <p class="text-xs text-slate-400 font-mono mb-3">
          Newton Rockets Rule: Raw telemetry is immutable. Every mathematical transformation is recorded in the provenance journal.
        </p>
        <div class="space-y-2 font-mono text-xs">
          @for (log of dataService.dataAudit()?.transformations; track log.timestamp) {
            <div class="p-2.5 bg-slate-950 border border-slate-800 rounded-lg flex flex-wrap items-center justify-between text-slate-300 gap-2">
              <div class="flex items-center gap-2">
                <span class="text-slate-500">{{ log.timestamp }}</span>
                <span class="px-1.5 py-0.5 bg-slate-900 border border-slate-700 rounded text-cyan-300 text-[10px]">{{ log.channel }}</span>
                <strong class="text-slate-200">{{ log.action }}</strong>
              </div>
              <span class="text-slate-400 text-[11px]">{{ log.note }}</span>
            </div>
          }
        </div>
      </div>
    </div>
  `
})
export class QualityAuditComponent {
  dataService = inject(IgnitionDataService);
  isAuditing = signal<boolean>(false);

  reRunAudit() {
    this.isAuditing.set(true);
    setTimeout(() => {
      this.isAuditing.set(false);
    }, 600);
  }
}
