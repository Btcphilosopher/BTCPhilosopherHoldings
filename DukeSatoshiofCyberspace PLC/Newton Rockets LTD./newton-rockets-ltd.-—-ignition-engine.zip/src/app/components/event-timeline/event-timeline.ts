import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { IgnitionDataService } from '../../services/ignition-data';
import { IgnitionEvent } from '../../models/ignition.types';

@Component({
  selector: 'app-event-timeline',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-6">
      <!-- Top Metrics Summary Cards -->
      <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div class="bg-slate-900/90 border border-slate-800 rounded-xl p-4 shadow-sm">
          <div class="flex items-center justify-between text-slate-400 text-xs font-mono mb-1">
            <span>INDUCTION DELAY</span>
            <span class="text-cyan-400">Command -> Flame</span>
          </div>
          <div class="text-2xl font-bold font-mono text-slate-100 flex items-baseline gap-1">
            {{ dataService.metrics()?.induction_delay_ms ?? 42.0 }} <span class="text-xs font-normal text-slate-400">ms</span>
          </div>
          <p class="text-[11px] text-slate-500 font-mono mt-1">Optical photodiode threshold inflection</p>
        </div>

        <div class="bg-slate-900/90 border border-slate-800 rounded-xl p-4 shadow-sm">
          <div class="flex items-center justify-between text-slate-400 text-xs font-mono mb-1">
            <span>RISE DURATION (10-90%)</span>
            <span class="text-emerald-400">Pressurization</span>
          </div>
          <div class="text-2xl font-bold font-mono text-slate-100 flex items-baseline gap-1">
            {{ dataService.metrics()?.rise_time_10_90_ms ?? 76.0 }} <span class="text-xs font-normal text-slate-400">ms</span>
          </div>
          <p class="text-[11px] text-slate-500 font-mono mt-1">10% (6.5 bar) to 90% (58.5 bar) Pc</p>
        </div>

        <div class="bg-slate-900/90 border border-slate-800 rounded-xl p-4 shadow-sm">
          <div class="flex items-center justify-between text-slate-400 text-xs font-mono mb-1">
            <span>TOTAL IGNITION DELAY</span>
            <span class="text-purple-400">Spark -> Stable</span>
          </div>
          <div class="text-2xl font-bold font-mono text-slate-100 flex items-baseline gap-1">
            {{ dataService.metrics()?.total_ignition_delay_ms ?? 118.0 }} <span class="text-xs font-normal text-slate-400">ms</span>
          </div>
          <p class="text-[11px] text-slate-500 font-mono mt-1">Initiator current to 90% steady state</p>
        </div>

        <div class="bg-slate-900/90 border border-slate-800 rounded-xl p-4 shadow-sm">
          <div class="flex items-center justify-between text-slate-400 text-xs font-mono mb-1">
            <span>PEAK Pc & OVERSHOOT</span>
            <span class="text-amber-400">Transients</span>
          </div>
          <div class="text-2xl font-bold font-mono text-slate-100 flex items-baseline gap-1">
            {{ dataService.metrics()?.peak_pc_bar ?? 67.8 }} <span class="text-xs font-normal text-slate-400">bar</span>
            <span class="text-xs text-amber-400 font-normal ml-1">({{ dataService.metrics()?.overshoot_pct ?? 4.3 }}% OS)</span>
          </div>
          <p class="text-[11px] text-slate-500 font-mono mt-1">Settling within ±2% in {{ dataService.metrics()?.settling_time_ms ?? 135 }} ms</p>
        </div>
      </div>

      <!-- Horizontal Engineering Event Timeline -->
      <div class="bg-slate-900/80 border border-slate-800 rounded-xl p-5 shadow-lg">
        <div class="flex items-center justify-between mb-4">
          <div class="flex items-center gap-2">
            <mat-icon class="text-cyan-400">linear_scale</mat-icon>
            <h3 class="font-mono text-sm font-semibold tracking-wide text-slate-100 uppercase">Horizontal Ignition Sequence Timeline</h3>
          </div>
          <span class="text-xs text-slate-400 font-mono">Click any event node to inspect signal provenance & confidence</span>
        </div>

        <!-- Timeline Track -->
        <div class="relative py-8 px-4 overflow-x-auto">
          <div class="min-w-[700px] relative">
            <!-- Connecting Line -->
            <div class="absolute top-1/2 left-4 right-4 h-0.5 bg-slate-700 -translate-y-1/2"></div>
            
            <div class="flex justify-between items-center relative z-10">
              @for (evt of dataService.events(); track evt.id) {
                <button
                  type="button"
                  (click)="selectedEvent.set(evt)"
                  [class.ring-2]="selectedEvent()?.id === evt.id"
                  [class.ring-cyan-400]="selectedEvent()?.id === evt.id"
                  [class.bg-cyan-950]="selectedEvent()?.id === evt.id"
                  class="flex flex-col items-center group cursor-pointer focus:outline-none transition">
                  <div 
                    [class.bg-cyan-500]="selectedEvent()?.id === evt.id"
                    [class.text-slate-950]="selectedEvent()?.id === evt.id"
                    [class.bg-slate-950]="selectedEvent()?.id !== evt.id"
                    [class.text-cyan-400]="selectedEvent()?.id !== evt.id"
                    class="w-10 h-10 rounded-full border-2 border-cyan-500 flex items-center justify-center font-mono font-bold text-xs shadow-md group-hover:scale-110 transition">
                    {{ (evt.time_s).toFixed(2) }}
                  </div>
                  <span class="mt-2 text-xs font-mono font-semibold text-slate-200 group-hover:text-cyan-300 transition text-center max-w-[90px]">{{ evt.label }}</span>
                  <span class="text-[10px] font-mono text-slate-400 mt-0.5">{{ (evt.confidence * 100).toFixed(0) }}% conf</span>
                </button>
              }
            </div>
          </div>
        </div>

        <!-- Selected Event Inspector Card -->
        @if (selectedEvent(); as activeEvt) {
          <div class="mt-4 p-4 bg-slate-950 border border-cyan-800/60 rounded-xl flex flex-col md:flex-row items-start md:items-center justify-between gap-4 font-mono text-xs">
            <div class="space-y-1">
              <div class="flex items-center gap-2">
                <span class="px-2 py-0.5 bg-cyan-900/60 border border-cyan-500 text-cyan-200 rounded font-bold">{{ activeEvt.name }}</span>
                <span class="text-slate-300 font-semibold">T = {{ activeEvt.time_s.toFixed(3) }}s</span>
                <span class="text-emerald-400">Confidence: {{ (activeEvt.confidence * 100).toFixed(1) }}%</span>
              </div>
              <p class="text-slate-300">{{ activeEvt.description }}</p>
              <div class="text-slate-400 text-[11px]">
                <span>METHOD: <strong class="text-slate-200">{{ activeEvt.detection_method }}</strong></span> | 
                <span>THRESHOLD: <strong class="text-slate-200">{{ activeEvt.threshold_description }}</strong></span>
              </div>
            </div>

            <div class="flex items-center gap-2">
              <span class="text-slate-400 text-[11px]">SOURCE SIGNALS:</span>
              @for (src of activeEvt.source_signals; track src) {
                <span class="px-2 py-0.5 bg-slate-900 border border-slate-700 rounded text-cyan-300">{{ src }}</span>
              }
            </div>
          </div>
        }
      </div>

      <!-- Campaign-Level Delay Statistics Table (Percentiles P5, P50, P95, MAD) -->
      <div class="bg-slate-900/80 border border-slate-800 rounded-xl overflow-hidden shadow-lg">
        <div class="px-4 py-3 bg-slate-950/70 border-b border-slate-800 flex items-center justify-between">
          <div class="flex items-center gap-2">
            <mat-icon class="text-emerald-400">query_stats</mat-icon>
            <h3 class="font-mono text-sm font-semibold tracking-wide text-slate-100 uppercase">Repeated Campaign Delay Distribution (N = 48 Tests)</h3>
          </div>
          <span class="text-xs text-slate-400 font-mono">Student-t & Clopper-Pearson 95% Confidence Bounds</span>
        </div>

        <div class="p-4 overflow-x-auto">
          <table class="w-full text-left font-mono text-xs">
            <thead>
              <tr class="border-b border-slate-800 text-slate-400">
                <th class="py-2 px-3">Metric</th>
                <th class="py-2 px-3">Sample (N)</th>
                <th class="py-2 px-3">Mean</th>
                <th class="py-2 px-3">Std Dev (sigma)</th>
                <th class="py-2 px-3">Median (P50)</th>
                <th class="py-2 px-3">MAD</th>
                <th class="py-2 px-3 text-cyan-400">P5 (5th %ile)</th>
                <th class="py-2 px-3 text-cyan-400">P95 (95th %ile)</th>
                <th class="py-2 px-3 text-emerald-400">95% Confidence Interval</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-slate-800/60 text-slate-200">
              <tr class="hover:bg-slate-800/30">
                <td class="py-2.5 px-3 font-semibold text-slate-100">Induction Delay (Cmd -> Flame)</td>
                <td class="py-2.5 px-3">48</td>
                <td class="py-2.5 px-3">42.4 ms</td>
                <td class="py-2.5 px-3">3.1 ms</td>
                <td class="py-2.5 px-3">42.1 ms</td>
                <td class="py-2.5 px-3">2.4 ms</td>
                <td class="py-2.5 px-3 text-cyan-300">37.8 ms</td>
                <td class="py-2.5 px-3 text-cyan-300">47.6 ms</td>
                <td class="py-2.5 px-3 text-emerald-300 font-bold">[41.5 ms - 43.3 ms]</td>
              </tr>
              <tr class="hover:bg-slate-800/30">
                <td class="py-2.5 px-3 font-semibold text-slate-100">10-90% Chamber Rise Time</td>
                <td class="py-2.5 px-3">48</td>
                <td class="py-2.5 px-3">76.8 ms</td>
                <td class="py-2.5 px-3">4.5 ms</td>
                <td class="py-2.5 px-3">76.2 ms</td>
                <td class="py-2.5 px-3">3.2 ms</td>
                <td class="py-2.5 px-3 text-cyan-300">70.1 ms</td>
                <td class="py-2.5 px-3 text-cyan-300">84.5 ms</td>
                <td class="py-2.5 px-3 text-emerald-300 font-bold">[75.5 ms - 78.1 ms]</td>
              </tr>
              <tr class="hover:bg-slate-800/30">
                <td class="py-2.5 px-3 font-semibold text-slate-100">Total Ignition Delay to 90% Pc</td>
                <td class="py-2.5 px-3">48</td>
                <td class="py-2.5 px-3">119.2 ms</td>
                <td class="py-2.5 px-3">5.8 ms</td>
                <td class="py-2.5 px-3">118.5 ms</td>
                <td class="py-2.5 px-3">4.1 ms</td>
                <td class="py-2.5 px-3 text-cyan-300">110.2 ms</td>
                <td class="py-2.5 px-3 text-cyan-300">129.4 ms</td>
                <td class="py-2.5 px-3 text-emerald-300 font-bold">[117.5 ms - 120.9 ms]</td>
              </tr>
              <tr class="hover:bg-slate-800/30">
                <td class="py-2.5 px-3 font-semibold text-slate-100">Peak Chamber Pressure (Pc)</td>
                <td class="py-2.5 px-3">48</td>
                <td class="py-2.5 px-3">67.4 bar</td>
                <td class="py-2.5 px-3">1.2 bar</td>
                <td class="py-2.5 px-3">67.3 bar</td>
                <td class="py-2.5 px-3">0.9 bar</td>
                <td class="py-2.5 px-3 text-cyan-300">65.6 bar</td>
                <td class="py-2.5 px-3 text-cyan-300">69.2 bar</td>
                <td class="py-2.5 px-3 text-emerald-300 font-bold">[67.1 bar - 67.7 bar]</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  `
})
export class EventTimelineComponent {
  dataService = inject(IgnitionDataService);
  selectedEvent = signal<IgnitionEvent | null>(this.dataService.events()[2] ?? null);
}
