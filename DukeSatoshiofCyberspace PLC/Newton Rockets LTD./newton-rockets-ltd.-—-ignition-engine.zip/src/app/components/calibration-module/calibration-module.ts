import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { IgnitionDataService } from '../../services/ignition-data';

@Component({
  selector: 'app-calibration-module',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-6">
      <!-- Discipline Notice -->
      <div class="bg-slate-900/90 border border-slate-800 rounded-xl p-5 shadow-lg">
        <div class="flex items-center justify-between">
          <div class="flex items-center gap-2">
            <mat-icon class="text-cyan-400">tune</mat-icon>
            <h3 class="font-mono text-base font-bold tracking-wide text-slate-100 uppercase">
              Reduced-Order Model (ROM) Calibration & Independent Validation
            </h3>
          </div>
          <span class="px-2.5 py-0.5 bg-cyan-950 border border-cyan-500 text-cyan-300 font-mono text-xs rounded">
            minpack.lm :: nlsLM (Levenberg-Marquardt)
          </span>
        </div>
        <p class="text-xs text-slate-400 font-mono mt-1">
          Newton Rockets Principle: Calibration is not validation. Calibrated parameters are estimated from training tests (70% partition) and verified against held-out validation tests (30% partition).
        </p>
      </div>

      <!-- Parameter Fit Results Table -->
      <div class="bg-slate-900/80 border border-slate-800 rounded-xl overflow-hidden shadow-lg">
        <div class="px-4 py-3 bg-slate-950/70 border-b border-slate-800 flex items-center justify-between">
          <h4 class="font-mono text-sm font-semibold text-slate-200 uppercase">Calibrated Physical Parameters (Held-Out Split Verified)</h4>
          <span class="text-xs text-slate-400 font-mono">Training N = 34 | Validation N = 14</span>
        </div>

        <div class="p-4 overflow-x-auto">
          <table class="w-full text-left font-mono text-xs">
            <thead>
              <tr class="border-b border-slate-800 text-slate-400">
                <th class="py-2 px-3">Physical Parameter</th>
                <th class="py-2 px-3">Theoretical Nominal</th>
                <th class="py-2 px-3 text-cyan-300">Calibrated Value</th>
                <th class="py-2 px-3">Std Error (se)</th>
                <th class="py-2 px-3">p-Value</th>
                <th class="py-2 px-3">Fit Quality (R²)</th>
                <th class="py-2 px-3">Validation RMSE</th>
                <th class="py-2 px-3 text-emerald-400">95% PI Coverage</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-slate-800/60 text-slate-200">
              @for (param of dataService.romCalibration(); track param.parameter_name) {
                <tr class="hover:bg-slate-800/30">
                  <td class="py-2.5 px-3 font-semibold text-slate-100">{{ param.parameter_name }}</td>
                  <td class="py-2.5 px-3 text-slate-400">{{ param.nominal_value }} {{ param.unit }}</td>
                  <td class="py-2.5 px-3 text-cyan-300 font-bold">{{ param.calibrated_value }} {{ param.unit }}</td>
                  <td class="py-2.5 px-3 text-slate-400">± {{ param.standard_error }}</td>
                  <td class="py-2.5 px-3 text-emerald-400">&lt; 0.0001</td>
                  <td class="py-2.5 px-3 font-bold text-slate-100">{{ param.fit_quality_r2 }}</td>
                  <td class="py-2.5 px-3 text-slate-300">{{ param.rmse }} bar</td>
                  <td class="py-2.5 px-3 text-emerald-300 font-bold">{{ param.coverage_pct }}%</td>
                </tr>
              }
            </tbody>
          </table>
        </div>
      </div>

      <!-- Residual Diagnostic Plots -->
      <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <!-- Residual Time Series -->
        <div class="bg-slate-900/80 border border-slate-800 rounded-xl p-5 shadow-lg">
          <div class="flex items-center justify-between border-b border-slate-800 pb-3 mb-3">
            <h4 class="font-mono text-xs font-semibold text-slate-200 uppercase">Residual vs Time (Measured - ROM Predicted)</h4>
            <span class="text-[11px] font-mono text-emerald-400">Mean Bias: -0.014 bar</span>
          </div>

          <!-- SVG Residual Trace -->
          <div class="w-full h-44 relative bg-slate-950 rounded-lg p-2 oscilloscope-grid">
            <svg class="w-full h-full" viewBox="0 0 400 140" preserveAspectRatio="none">
              <!-- Zero Baseline -->
              <line x1="10" y1="70" x2="390" y2="70" stroke="#475569" stroke-width="1" stroke-dasharray="3 3" />
              <!-- +/- 2 bar limits -->
              <line x1="10" y1="20" x2="390" y2="20" stroke="#f43f5e" stroke-width="0.8" stroke-dasharray="2 2" opacity="0.5" />
              <line x1="10" y1="120" x2="390" y2="120" stroke="#f43f5e" stroke-width="0.8" stroke-dasharray="2 2" opacity="0.5" />
              
              <!-- Residual Path -->
              <path d="M 10 70 L 60 70 L 120 70 L 180 71 L 210 73 L 220 85 L 230 62 L 240 74 L 260 68 L 300 71 L 350 69 L 390 70" fill="none" stroke="#38bdf8" stroke-width="2" />
            </svg>
          </div>
          <div class="flex justify-between text-[10px] font-mono text-slate-500 mt-2">
            <span>T = 0.0s (Pre-fire)</span>
            <span>T = 0.54s (Ignition Transient)</span>
            <span>T = 1.0s (Steady Burn)</span>
          </div>
        </div>

        <!-- Residual Histogram & Normality Check -->
        <div class="bg-slate-900/80 border border-slate-800 rounded-xl p-5 shadow-lg">
          <div class="flex items-center justify-between border-b border-slate-800 pb-3 mb-3">
            <h4 class="font-mono text-xs font-semibold text-slate-200 uppercase">Residual Gaussian Distribution & QQ Check</h4>
            <span class="text-[11px] font-mono text-slate-400">Shapiro-Wilk p = 0.42 (Normal)</span>
          </div>

          <div class="w-full h-44 relative bg-slate-950 rounded-lg p-2 flex items-end justify-center gap-1">
            <!-- Histogram bars -->
            <div class="w-4 bg-slate-800 rounded-t h-4"></div>
            <div class="w-4 bg-slate-800 rounded-t h-8"></div>
            <div class="w-4 bg-slate-700 rounded-t h-16"></div>
            <div class="w-4 bg-cyan-700 rounded-t h-28"></div>
            <div class="w-4 bg-cyan-500 rounded-t h-36"></div>
            <div class="w-4 bg-cyan-700 rounded-t h-30"></div>
            <div class="w-4 bg-slate-700 rounded-t h-18"></div>
            <div class="w-4 bg-slate-800 rounded-t h-7"></div>
            <div class="w-4 bg-slate-800 rounded-t h-3"></div>
          </div>
          <div class="flex justify-between text-[10px] font-mono text-slate-500 mt-2">
            <span>-2.0 bar</span>
            <span>0.0 bar (Zero Mean)</span>
            <span>+2.0 bar</span>
          </div>
        </div>
      </div>
    </div>
  `
})
export class CalibrationModuleComponent {
  dataService = inject(IgnitionDataService);
}
