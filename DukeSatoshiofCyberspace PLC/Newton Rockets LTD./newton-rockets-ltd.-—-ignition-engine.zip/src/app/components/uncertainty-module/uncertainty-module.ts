import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { IgnitionDataService } from '../../services/ignition-data';

@Component({
  selector: 'app-uncertainty-module',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-6">
      <!-- Top Title -->
      <div class="bg-slate-900/90 border border-slate-800 rounded-xl p-5 shadow-lg">
        <div class="flex items-center justify-between">
          <div class="flex items-center gap-2">
            <mat-icon class="text-amber-400">casino</mat-icon>
            <h3 class="font-mono text-base font-bold tracking-wide text-slate-100 uppercase">
              Uncertainty Quantification & Global Sobol Sensitivity
            </h3>
          </div>
          <span class="px-2.5 py-0.5 bg-amber-950 border border-amber-600 text-amber-300 font-mono text-xs rounded font-bold">
            10,000 MONTE CARLO DRAWS
          </span>
        </div>
        <p class="text-xs text-slate-400 font-mono mt-1">
          Propagating fluid inlet temperature variations, spark energy jitter, sensor calibration tolerance, and model-form uncertainty into ignition delay and chamber overshoot.
        </p>
      </div>

      <!-- Monte Carlo Quantiles & Global Sobol Ranking Grid -->
      <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <!-- Monte Carlo Distribution Card -->
        <div class="bg-slate-900/80 border border-slate-800 rounded-xl p-5 shadow-lg">
          <div class="flex items-center justify-between border-b border-slate-800 pb-3 mb-4">
            <h4 class="font-mono text-sm font-semibold text-slate-200 uppercase">Ignition Delay Monte Carlo Distribution</h4>
            <span class="text-xs font-mono text-emerald-400">N = 10,000 Iterations</span>
          </div>

          <!-- Key Quantile Chips -->
          <div class="grid grid-cols-3 gap-3 font-mono text-xs mb-4">
            <div class="bg-slate-950 p-3 rounded-lg border border-slate-800 text-center">
              <span class="text-slate-500">P5 (5% Lower)</span>
              <div class="text-lg font-bold text-cyan-400 mt-1">38.2 ms</div>
            </div>
            <div class="bg-slate-950 p-3 rounded-lg border border-slate-800 text-center">
              <span class="text-slate-500">P50 (Median)</span>
              <div class="text-lg font-bold text-emerald-400 mt-1">42.4 ms</div>
            </div>
            <div class="bg-slate-950 p-3 rounded-lg border border-slate-800 text-center">
              <span class="text-slate-500">P95 (95% Upper)</span>
              <div class="text-lg font-bold text-amber-400 mt-1">47.6 ms</div>
            </div>
          </div>

          <!-- SVG Simulated Histogram -->
          <div class="w-full h-36 bg-slate-950 rounded-lg p-2 flex items-end justify-center gap-1.5 border border-slate-800/80">
            <div class="w-5 bg-cyan-900/60 rounded-t h-4"></div>
            <div class="w-5 bg-cyan-800/70 rounded-t h-10"></div>
            <div class="w-5 bg-cyan-700/80 rounded-t h-20"></div>
            <div class="w-5 bg-cyan-600 rounded-t h-28"></div>
            <div class="w-5 bg-cyan-400 rounded-t h-32"></div>
            <div class="w-5 bg-cyan-500 rounded-t h-30"></div>
            <div class="w-5 bg-cyan-700/80 rounded-t h-18"></div>
            <div class="w-5 bg-cyan-800/70 rounded-t h-8"></div>
            <div class="w-5 bg-cyan-900/60 rounded-t h-3"></div>
          </div>
          <div class="flex justify-between text-[10px] font-mono text-slate-500 mt-2">
            <span>36.0 ms</span>
            <span>Nominal: 42.4 ms (StdDev: 2.8 ms)</span>
            <span>50.0 ms</span>
          </div>
        </div>

        <!-- Global Sobol Sensitivity Ranking -->
        <div class="bg-slate-900/80 border border-slate-800 rounded-xl p-5 shadow-lg">
          <div class="flex items-center justify-between border-b border-slate-800 pb-3 mb-4">
            <h4 class="font-mono text-sm font-semibold text-slate-200 uppercase">Global Sobol Sensitivity Ranking</h4>
            <span class="text-xs font-mono text-slate-400">Variance Decomposition</span>
          </div>

          <div class="space-y-3 font-mono text-xs">
            @for (sob of dataService.sobolIndices(); track sob.rank) {
              <div class="bg-slate-950 p-2.5 rounded-lg border border-slate-800">
                <div class="flex items-center justify-between mb-1">
                  <span class="font-bold text-slate-200">#{{ sob.rank }} {{ sob.parameter }}</span>
                  <div class="text-[11px]">
                    <span class="text-cyan-400">Si: {{ sob.first_order_si }}</span> | 
                    <span class="text-purple-300">STi: {{ sob.total_order_sti }}</span>
                  </div>
                </div>
                <!-- Visual Bar Indicator -->
                <div class="w-full h-2 bg-slate-900 rounded-full overflow-hidden flex">
                  <div class="h-full bg-cyan-500" [style.width.%]="sob.first_order_si * 100"></div>
                  <div class="h-full bg-purple-500" [style.width.%]="sob.interaction_effect * 100"></div>
                </div>
              </div>
            }
          </div>

          <div class="flex items-center gap-4 text-[11px] text-slate-400 font-mono mt-3">
            <div class="flex items-center gap-1.5">
              <span class="w-2.5 h-2.5 bg-cyan-500 rounded-sm"></span>
              <span>First-Order Main Effect (Si)</span>
            </div>
            <div class="flex items-center gap-1.5">
              <span class="w-2.5 h-2.5 bg-purple-500 rounded-sm"></span>
              <span>Non-Linear Interaction Effect</span>
            </div>
          </div>
        </div>
      </div>

      <!-- Formal Metrological Uncertainty Budget Table (GUM Compliant) -->
      <div class="bg-slate-900/80 border border-slate-800 rounded-xl overflow-hidden shadow-lg">
        <div class="px-4 py-3 bg-slate-950/70 border-b border-slate-800 flex items-center justify-between">
          <h4 class="font-mono text-sm font-semibold text-slate-200 uppercase">ISO/GUM Metrological Uncertainty Budget (Chamber Pressure Sensor PT-101)</h4>
          <span class="text-xs text-slate-400 font-mono">Expanded k = 2.0 (95.45% Coverage)</span>
        </div>

        <div class="p-4 overflow-x-auto">
          <table class="w-full text-left font-mono text-xs">
            <thead>
              <tr class="border-b border-slate-800 text-slate-400">
                <th class="py-2 px-3">Uncertainty Source</th>
                <th class="py-2 px-3">Type</th>
                <th class="py-2 px-3">Standard Uncertainty u(xi)</th>
                <th class="py-2 px-3">Probability Distribution</th>
                <th class="py-2 px-3">Divisor</th>
                <th class="py-2 px-3 text-right">Sensitivity ci</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-slate-800/60 text-slate-200">
              <tr class="hover:bg-slate-800/30">
                <td class="py-2 px-3 font-semibold">Test-to-Test Random Firing Repeatability</td>
                <td class="py-2 px-3 text-cyan-300">Type A</td>
                <td class="py-2 px-3">0.420 bar</td>
                <td class="py-2 px-3">Normal</td>
                <td class="py-2 px-3">1.0</td>
                <td class="py-2 px-3 text-right">1.0</td>
              </tr>
              <tr class="hover:bg-slate-800/30">
                <td class="py-2 px-3 font-semibold">Piezoresistive Transducer Non-Linearity</td>
                <td class="py-2 px-3 text-purple-300">Type B</td>
                <td class="py-2 px-3">0.150 bar</td>
                <td class="py-2 px-3">Rectangular</td>
                <td class="py-2 px-3">sqrt(3)</td>
                <td class="py-2 px-3 text-right">1.0</td>
              </tr>
              <tr class="hover:bg-slate-800/30">
                <td class="py-2 px-3 font-semibold">24-Bit Sigma-Delta DAAS Digitizer & Gain Drift</td>
                <td class="py-2 px-3 text-purple-300">Type B</td>
                <td class="py-2 px-3">0.045 bar</td>
                <td class="py-2 px-3">Rectangular</td>
                <td class="py-2 px-3">sqrt(3)</td>
                <td class="py-2 px-3 text-right">1.0</td>
              </tr>
              <tr class="hover:bg-slate-800/30">
                <td class="py-2 px-3 font-semibold">Atmospheric Zero Reference Drift</td>
                <td class="py-2 px-3 text-purple-300">Type B</td>
                <td class="py-2 px-3">0.080 bar</td>
                <td class="py-2 px-3">Normal</td>
                <td class="py-2 px-3">1.0</td>
                <td class="py-2 px-3 text-right">1.0</td>
              </tr>
              <tr class="bg-slate-950 font-bold border-t border-slate-700">
                <td class="py-2.5 px-3 text-slate-100">Combined Standard Uncertainty uc</td>
                <td class="py-2.5 px-3 text-emerald-400">RSS</td>
                <td class="py-2.5 px-3 text-emerald-400">0.455 bar</td>
                <td class="py-2.5 px-3">Normal (CLT)</td>
                <td class="py-2.5 px-3">-</td>
                <td class="py-2.5 px-3 text-right text-emerald-400">0.70% of Span</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  `
})
export class UncertaintyModuleComponent {
  dataService = inject(IgnitionDataService);
}
