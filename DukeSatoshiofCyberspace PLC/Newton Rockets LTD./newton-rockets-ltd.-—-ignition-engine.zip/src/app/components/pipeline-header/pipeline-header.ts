import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { IgnitionDataService } from '../../services/ignition-data';

@Component({
  selector: 'app-pipeline-header',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <header class="border-b border-slate-800 bg-slate-950/95 backdrop-blur sticky top-0 z-50">
      <!-- Topmost brand & engineering badge bar -->
      <div class="max-w-7xl mx-auto px-4 sm:px-6 py-2.5 flex flex-wrap items-center justify-between gap-4">
        <div class="flex items-center gap-3">
          <div class="w-9 h-9 rounded bg-cyan-950 border border-cyan-500/40 flex items-center justify-center text-cyan-400 shadow-sm shadow-cyan-950">
            <mat-icon>rocket_launch</mat-icon>
          </div>
          <div>
            <div class="flex items-center gap-2">
              <span class="font-bold tracking-wider text-slate-100 text-sm sm:text-base uppercase font-mono">NEWTON ROCKETS LTD.</span>
              <span class="px-1.5 py-0.5 text-[10px] uppercase font-mono font-semibold bg-cyan-950 text-cyan-300 border border-cyan-700/50 rounded">IGNITION ENGINE</span>
              <span class="px-1.5 py-0.5 text-[10px] font-mono bg-slate-800 text-slate-300 border border-slate-700 rounded">R 4.4+ KERNEL</span>
            </div>
            <p class="text-[11px] text-slate-400 font-mono tracking-tight">Propulsion Ignition Test, Statistical Modelling & Digital-Twin Workstation</p>
          </div>
        </div>

        <!-- Right badges: Hierarchy Level & Mode -->
        <div class="flex items-center gap-2.5">
          <div class="flex items-center gap-1.5 px-2.5 py-1 bg-emerald-950/60 border border-emerald-500/30 rounded text-emerald-300 text-xs font-mono">
            <span class="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
            <span>LEVEL 4: CAMPAIGN VALIDATED</span>
          </div>

          <div class="hidden md:flex items-center gap-1 px-2.5 py-1 bg-slate-900 border border-slate-700/70 rounded text-slate-300 text-xs font-mono">
            <mat-icon class="icon-sm text-slate-400">lock</mat-icon>
            <span>IMMUTABLE TELEMETRY</span>
          </div>

          <div class="px-2.5 py-1 bg-amber-950/50 border border-amber-600/30 rounded text-amber-300 text-xs font-mono">
            <span>RESEARCH / NOT CERTIFICATION</span>
          </div>
        </div>
      </div>

      <!-- Newton Subsystems Pipeline Bar -->
      <div class="bg-slate-900/90 border-t border-slate-800/80 px-4 sm:px-6 py-1.5 overflow-x-auto">
        <div class="max-w-7xl mx-auto flex items-center gap-1.5 min-w-[850px] text-xs font-mono">
          <span class="text-slate-500 text-[10px] uppercase tracking-wider font-semibold mr-1">PROPULSION STACK:</span>

          <!-- Node 1: CryoTank -->
          <div class="flex items-center gap-1 px-2 py-0.5 bg-slate-950 border border-slate-800 rounded text-slate-400">
            <span class="w-1.5 h-1.5 rounded-full bg-cyan-400"></span>
            <span>NEWTON CRYOTANK (98.4 K)</span>
          </div>
          <mat-icon class="icon-sm text-slate-600">arrow_forward</mat-icon>

          <!-- Node 2: Feed System -->
          <div class="flex items-center gap-1 px-2 py-0.5 bg-slate-950 border border-slate-800 rounded text-slate-400">
            <span class="w-1.5 h-1.5 rounded-full bg-cyan-400"></span>
            <span>PROPELLANT / FEED (65 bar)</span>
          </div>
          <mat-icon class="icon-sm text-slate-600">arrow_forward</mat-icon>

          <!-- Node 3: Propulsion Digital Twin -->
          <div class="flex items-center gap-1 px-2 py-0.5 bg-slate-950 border border-slate-800 rounded text-slate-400">
            <span class="w-1.5 h-1.5 rounded-full bg-emerald-400"></span>
            <span>PROPULSION DIGITAL TWIN</span>
          </div>
          <mat-icon class="icon-sm text-slate-600">arrow_forward</mat-icon>

          <!-- Node 4: Ignition Engine (Active) -->
          <div class="flex items-center gap-1 px-2.5 py-0.5 bg-cyan-950 border border-cyan-500/60 rounded text-cyan-200 font-semibold shadow-sm">
            <span class="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-ping"></span>
            <span>IGNITION ENGINE (ACTIVE)</span>
          </div>
          <mat-icon class="icon-sm text-slate-600">arrow_forward</mat-icon>

          <!-- Node 5: Booster System -->
          <div class="flex items-center gap-1 px-2 py-0.5 bg-slate-950 border border-slate-800 rounded text-slate-400">
            <span>BOOSTER SYSTEM</span>
          </div>
          <mat-icon class="icon-sm text-slate-600">arrow_forward</mat-icon>

          <!-- Node 6: Telemetry -->
          <div class="flex items-center gap-1 px-2 py-0.5 bg-slate-950 border border-slate-800 rounded text-slate-400">
            <span>TEST / TELEMETRY</span>
          </div>
          <mat-icon class="icon-sm text-slate-600">arrow_forward</mat-icon>

          <!-- Node 7: Statistical Validation -->
          <div class="flex items-center gap-1 px-2 py-0.5 bg-slate-950 border border-emerald-800/60 rounded text-emerald-400">
            <mat-icon class="icon-sm text-emerald-400">verified</mat-icon>
            <span>STATISTICAL VALIDATION</span>
          </div>
        </div>
      </div>

      <!-- Test Metadata Breadcrumb Strip -->
      <div class="bg-slate-950/60 border-t border-slate-800/50 px-4 sm:px-6 py-1.5">
        <div class="max-w-7xl mx-auto flex flex-wrap items-center justify-between text-[11px] font-mono text-slate-400 gap-y-1">
          <div class="flex flex-wrap items-center gap-4">
            <div><span class="text-slate-500">CAMPAIGN:</span> <strong class="text-slate-200">{{ dataService.activeCampaign() }}</strong></div>
            <div class="border-l border-slate-800 pl-4"><span class="text-slate-500">TEST RUN:</span> <strong class="text-cyan-400 font-bold">{{ dataService.activeTestId() }}</strong></div>
            <div class="border-l border-slate-800 pl-4"><span class="text-slate-500">HARDWARE:</span> <strong class="text-slate-200">{{ dataService.hardwareRevision() }}</strong></div>
            <div class="border-l border-slate-800 pl-4"><span class="text-slate-500">PROPELLANT:</span> <span class="text-slate-300">LOX / CH4 (Subcooled)</span></div>
            <div class="border-l border-slate-800 pl-4"><span class="text-slate-500">DATE:</span> <span class="text-slate-300">{{ dataService.testDate() }}</span></div>
          </div>
          <div class="flex items-center gap-3 text-slate-400">
            <span>DAAS RATE: <strong class="text-emerald-400">1000 Hz</strong></span>
            <span>OPERATOR: <span class="text-slate-300">{{ dataService.operator() }}</span></span>
          </div>
        </div>
      </div>
    </header>
  `
})
export class PipelineHeaderComponent {
  dataService = inject(IgnitionDataService);
}
