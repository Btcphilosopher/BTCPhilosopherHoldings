import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { IgnitionDataService } from '../../services/ignition-data';
import { ReportGeneratorService } from '../../services/report-generator';

@Component({
  selector: 'app-r-dossier',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-6">
      <!-- Top Title & Export Suite -->
      <div class="bg-slate-900/90 border border-slate-800 rounded-xl p-5 shadow-lg">
        <div class="flex flex-wrap items-center justify-between gap-4">
          <div class="flex items-center gap-3">
            <div class="w-10 h-10 rounded bg-cyan-950 border border-cyan-500 flex items-center justify-center text-cyan-400">
              <mat-icon>description</mat-icon>
            </div>
            <div>
              <h3 class="font-mono text-base font-bold tracking-wide text-slate-100 uppercase">
                R Package Ecosystem & Engineering Dossier Export
              </h3>
              <p class="text-xs text-slate-400 font-mono">
                newton-ignition/ R package tree, reproducible _targets pipeline, RMarkdown templates & CLI automation.
              </p>
            </div>
          </div>

          <div class="flex flex-wrap items-center gap-2 font-mono text-xs">
            <button 
              type="button"
              (click)="downloadMarkdownReport()"
              class="px-3 py-1.5 bg-cyan-600 hover:bg-cyan-500 text-slate-950 font-bold rounded flex items-center gap-1.5 transition">
              <mat-icon class="icon-sm">download</mat-icon>
              <span>Download Dossier (.md)</span>
            </button>
            <button 
              type="button"
              (click)="downloadTelemetryCsv()"
              class="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded flex items-center gap-1.5 transition">
              <mat-icon class="icon-sm">table_view</mat-icon>
              <span>Export Telemetry (.csv)</span>
            </button>
          </div>
        </div>
      </div>

      <!-- Reproducible Targets Pipeline Graph -->
      <div class="bg-slate-900/80 border border-slate-800 rounded-xl p-5 shadow-lg">
        <div class="flex items-center justify-between border-b border-slate-800 pb-3 mb-4">
          <div class="flex items-center gap-2">
            <mat-icon class="text-emerald-400">account_tree</mat-icon>
            <h4 class="font-mono text-sm font-semibold text-slate-200 uppercase">Reproducible Targets Pipeline (DAG)</h4>
          </div>
          <span class="text-xs font-mono px-2 py-0.5 bg-slate-950 border border-emerald-500/50 text-emerald-300 rounded">
            targets::tar_make() Ready
          </span>
        </div>

        <div class="p-3 bg-slate-950 rounded-lg border border-slate-800 font-mono text-xs overflow-x-auto">
          <pre class="text-slate-300 leading-relaxed">
raw_data (Parquet/CSV)
   │
   ├──▶ quality_control (audit_data_quality)
   │       │
   │       └──▶ clean_data (clean_telemetry_signals)
   │               │
   │               └──▶ synchronised_data (resample_and_sync_signals @ 1000Hz)
   │                       │
   │                       ├──▶ event_detection (detect_ignition_events)
   │                       │       │
   │                       │       └──▶ derived_metrics (delays, rise time, overshoot)
   │                       │
   │                       ├──▶ model_calibration (minpack.lm::nlsLM @ 70% split)
   │                       │       │
   │                       │       └──▶ independent_validation (RMSE, MAE, 95% PI)
   │                       │
   │                       ├──▶ uncertainty_monte_carlo (10k draws)
   │                       │
   │                       └──▶ reliability_engine (Clopper-Pearson & Bayesian Beta)
   │                               │
   └───────────────────────────────┴──▶ engineering_dossier.md / .pdf
          </pre>
        </div>
      </div>

      <!-- CLI Command Reference Card -->
      <div class="bg-slate-900/80 border border-slate-800 rounded-xl p-5 shadow-lg font-mono text-xs">
        <div class="flex items-center justify-between border-b border-slate-800 pb-3 mb-4">
          <div class="flex items-center gap-2">
            <mat-icon class="text-cyan-400">terminal</mat-icon>
            <h4 class="text-sm font-semibold text-slate-200 uppercase">newton-ignition CLI Automation Suite</h4>
          </div>
          <span class="text-slate-400">Invokes the identical R package kernel</span>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 gap-3">
          <div class="p-2.5 bg-slate-950 rounded border border-slate-800">
            <div class="text-cyan-300 font-bold">$ newton-ignition import hotfire_042.csv</div>
            <p class="text-slate-400 text-[11px] mt-0.5">Ingests raw telemetry and records SHA256 checksum in provenance ledger.</p>
          </div>

          <div class="p-2.5 bg-slate-950 rounded border border-slate-800">
            <div class="text-cyan-300 font-bold">$ newton-ignition validate-data hotfire_042.csv</div>
            <p class="text-slate-400 text-[11px] mt-0.5">Executes full 8-stage data quality and sensor saturation audit.</p>
          </div>

          <div class="p-2.5 bg-slate-950 rounded border border-slate-800">
            <div class="text-cyan-300 font-bold">$ newton-ignition detect-events hotfire_042.csv</div>
            <p class="text-slate-400 text-[11px] mt-0.5">Calculates induction delay, rise time, and 90% steady state.</p>
          </div>

          <div class="p-2.5 bg-slate-950 rounded border border-slate-800">
            <div class="text-cyan-300 font-bold">$ newton-ignition reliability 46 48</div>
            <p class="text-slate-400 text-[11px] mt-0.5">Calculates Clopper-Pearson exact interval and Bayesian conjugate update.</p>
          </div>

          <div class="p-2.5 bg-slate-950 rounded border border-slate-800">
            <div class="text-cyan-300 font-bold">$ newton-ignition monte-carlo --draws 10000</div>
            <p class="text-slate-400 text-[11px] mt-0.5">Propagates parameter and sensor uncertainties into P5/P50/P95.</p>
          </div>

          <div class="p-2.5 bg-slate-950 rounded border border-slate-800">
            <div class="text-cyan-300 font-bold">$ newton-ignition report --format html</div>
            <p class="text-slate-400 text-[11px] mt-0.5">Renders complete publication-grade engineering dossier.</p>
          </div>
        </div>
      </div>

      <!-- Live Markdown Dossier Preview -->
      <div class="bg-slate-900/80 border border-slate-800 rounded-xl p-5 shadow-lg">
        <div class="flex items-center justify-between border-b border-slate-800 pb-3 mb-3">
          <div class="flex items-center gap-2">
            <mat-icon class="text-slate-400">preview</mat-icon>
            <h4 class="font-mono text-sm font-semibold text-slate-200 uppercase">Live Dossier Output Preview</h4>
          </div>
          <span class="text-xs font-mono text-slate-500">Auto-compiled from active test buffers</span>
        </div>

        <div class="bg-slate-950 p-4 rounded-lg border border-slate-800 font-mono text-xs max-h-80 overflow-y-auto text-slate-300">
          <pre class="whitespace-pre-wrap">{{ dossierText() }}</pre>
        </div>
      </div>
    </div>
  `
})
export class RDossierComponent {
  dataService = inject(IgnitionDataService);
  reportService = inject(ReportGeneratorService);

  dossierText() {
    return this.reportService.generateMarkdownDossier();
  }

  downloadMarkdownReport() {
    const text = this.reportService.generateMarkdownDossier();
    const blob = new Blob([text], { type: 'text/markdown;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `newton_ignition_dossier_${this.dataService.activeTestId()}.md`;
    link.click();
    URL.revokeObjectURL(url);
  }

  downloadTelemetryCsv() {
    const text = this.reportService.exportTelemetryCsv();
    const blob = new Blob([text], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `telemetry_${this.dataService.activeTestId()}.csv`;
    link.click();
    URL.revokeObjectURL(url);
  }
}
