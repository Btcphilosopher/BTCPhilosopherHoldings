import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { IgnitionDataService } from '../../services/ignition-data';

@Component({
  selector: 'app-digital-twin',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-6">
      <!-- Digital Twin Header & Playback Strip -->
      <div class="bg-slate-900/90 border border-slate-800 rounded-xl p-5 shadow-lg">
        <div class="flex flex-wrap items-center justify-between gap-4">
          <div class="flex items-center gap-3">
            <div class="w-10 h-10 rounded bg-cyan-950 border border-cyan-500 flex items-center justify-center text-cyan-400">
              <mat-icon>memory</mat-icon>
            </div>
            <div>
              <div class="flex items-center gap-2">
                <h3 class="font-mono text-base font-bold tracking-wide text-slate-100 uppercase">
                  Experimental Digital Twin (Live Replay Stream)
                </h3>
                <span class="px-2 py-0.5 bg-emerald-950 border border-emerald-500 text-emerald-300 font-mono text-xs rounded">
                  SYNCHRONISED
                </span>
              </div>
              <p class="text-xs text-slate-400 font-mono">
                Newton Rockets Principle: The Digital Twin is an analytical experimental state estimator, not an autonomous flight controller.
              </p>
            </div>
          </div>

          <!-- Playback Controls -->
          <div class="flex items-center gap-3 font-mono text-xs">
            <button 
              type="button"
              (click)="togglePlay()"
              class="px-3.5 py-1.5 bg-cyan-600 hover:bg-cyan-500 text-slate-950 font-bold rounded flex items-center gap-1.5 transition shadow">
              <mat-icon class="icon-sm">{{ isPlaying() ? 'pause' : 'play_arrow' }}</mat-icon>
              <span>{{ isPlaying() ? 'Pause' : 'Play Replay' }}</span>
            </button>
            <button 
              type="button"
              (click)="resetTime()"
              class="px-2.5 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded transition">
              Reset (T0)
            </button>
          </div>
        </div>

        <!-- Interactive Timeline Slider -->
        <div class="mt-5 space-y-2 font-mono text-xs">
          <div class="flex justify-between text-slate-400">
            <span>TEST ELAPSED TIME: <strong class="text-cyan-400 text-sm">{{ currentPlaybackTime().toFixed(3) }} s</strong></span>
            <span>BURNTIME SPAN: 0.000s - 1.000s</span>
          </div>
          <input 
            type="range" 
            min="0" 
            max="1" 
            step="0.005"
            [value]="currentPlaybackTime()"
            (input)="onSliderChange($event)"
            class="w-full accent-cyan-400 cursor-pointer bg-slate-800 rounded-lg h-2"
          />
        </div>
      </div>

      <!-- Live State Gauges Grid -->
      <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 font-mono">
        <!-- Chamber Pressure State -->
        <div class="bg-slate-900/80 border border-slate-800 rounded-xl p-4 shadow-lg">
          <div class="text-slate-400 text-xs flex justify-between">
            <span>CHAMBER PRESSURE (Pc)</span>
            <mat-icon class="icon-sm text-emerald-400">speed</mat-icon>
          </div>
          <div class="text-3xl font-bold text-slate-100 mt-2">
            {{ activePoint().chamber_pressure_filtered_bar.toFixed(1) }} <span class="text-xs font-normal text-slate-400">bar</span>
          </div>
          <div class="mt-2 text-[11px] text-slate-400 flex justify-between">
            <span>Target: 65.0 bar</span>
            <span [class.text-emerald-400]="activePoint().chamber_pressure_filtered_bar > 55" [class.text-amber-400]="activePoint().chamber_pressure_filtered_bar <= 55">
              {{ activePoint().chamber_pressure_filtered_bar > 55 ? 'Nominal Mainstage' : 'Transitional' }}
            </span>
          </div>
        </div>

        <!-- Characteristic Velocity c* Efficiency -->
        <div class="bg-slate-900/80 border border-slate-800 rounded-xl p-4 shadow-lg">
          <div class="text-slate-400 text-xs flex justify-between">
            <span>c* EFFICIENCY (eta_c*)</span>
            <mat-icon class="icon-sm text-cyan-400">flare</mat-icon>
          </div>
          <div class="text-3xl font-bold text-cyan-300 mt-2">
            {{ (cStarEfficiency() * 100).toFixed(1) }} <span class="text-xs font-normal text-slate-400">%</span>
          </div>
          <div class="mt-2 text-[11px] text-slate-400 flex justify-between">
            <span>c* actual: {{ cStarActual().toFixed(0) }} m/s</span>
            <span>c* theoretical: 1820 m/s</span>
          </div>
        </div>

        <!-- Oxidizer-to-Fuel Ratio -->
        <div class="bg-slate-900/80 border border-slate-800 rounded-xl p-4 shadow-lg">
          <div class="text-slate-400 text-xs flex justify-between">
            <span>ESTIMATED O/F RATIO</span>
            <mat-icon class="icon-sm text-rose-400">science</mat-icon>
          </div>
          <div class="text-3xl font-bold text-slate-100 mt-2">
            {{ ofRatio().toFixed(2) }} <span class="text-xs font-normal text-slate-400">: 1</span>
          </div>
          <div class="mt-2 text-[11px] text-slate-400 flex justify-between">
            <span>LOX/CH4 target: 2.80</span>
            <span class="text-emerald-400">Within ±2.5% envelope</span>
          </div>
        </div>

        <!-- Acoustic Stability Monitor -->
        <div class="bg-slate-900/80 border border-slate-800 rounded-xl p-4 shadow-lg">
          <div class="text-slate-400 text-xs flex justify-between">
            <span>ACOUSTIC COMBUSTION</span>
            <mat-icon class="icon-sm text-emerald-400">graphic_eq</mat-icon>
          </div>
          <div class="text-lg font-bold text-emerald-400 mt-3 flex items-center gap-1.5">
            <span class="w-2.5 h-2.5 rounded-full bg-emerald-400"></span>
            <span>STABLE (< 0.5% RMS)</span>
          </div>
          <div class="mt-2 text-[11px] text-slate-400 flex justify-between">
            <span>Chugging Mode: Clean</span>
            <span>FFT Peak: 124 Hz</span>
          </div>
        </div>
      </div>

      <!-- Active Phase & Physical State Card -->
      <div class="bg-slate-900/80 border border-slate-800 rounded-xl p-5 shadow-lg font-mono text-xs">
        <div class="flex items-center justify-between border-b border-slate-800 pb-3 mb-4">
          <h4 class="text-sm font-semibold text-slate-200 uppercase">Subsystem Integration Physical State Map</h4>
          <span class="text-cyan-400">Synchronized with Newton Propulsion Module</span>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-3 gap-4 text-slate-300">
          <div class="bg-slate-950 p-3 rounded-lg border border-slate-800">
            <div class="text-slate-500 font-bold mb-1">INLET FLUID STATE:</div>
            <div>LOX Manifold: <strong class="text-rose-400">{{ activePoint().lox_manifold_pressure_bar.toFixed(1) }} bar</strong> (98.4 K)</div>
            <div>CH4 Manifold: <strong class="text-amber-400">{{ activePoint().ch4_manifold_pressure_bar.toFixed(1) }} bar</strong> (112.1 K)</div>
          </div>

          <div class="bg-slate-950 p-3 rounded-lg border border-slate-800">
            <div class="text-slate-500 font-bold mb-1">IGNITER TELEMETRY:</div>
            <div>Current: <strong class="text-yellow-300">{{ activePoint().igniter_current_a.toFixed(2) }} A</strong></div>
            <div>Flame Emission: <strong class="text-sky-300">{{ activePoint().optical_flame_v.toFixed(2) }} V</strong></div>
          </div>

          <div class="bg-slate-950 p-3 rounded-lg border border-slate-800">
            <div class="text-slate-500 font-bold mb-1">DYNAMIC VIBRATION:</div>
            <div>Accelerometer Z: <strong class="text-purple-300">{{ activePoint().accelerometer_z_g.toFixed(2) }} g</strong></div>
            <div>dP/dt Pressurization: <strong class="text-emerald-400">{{ activePoint().dp_dt_bar_s.toFixed(1) }} bar/s</strong></div>
          </div>
        </div>
      </div>
    </div>
  `
})
export class DigitalTwinComponent {
  dataService = inject(IgnitionDataService);
  currentPlaybackTime = signal<number>(0.58);
  isPlaying = signal<boolean>(false);
  private timerId: ReturnType<typeof setInterval> | null = null;

  activePoint() {
    const t = this.currentPlaybackTime();
    const allPts = this.dataService.telemetryData();
    const idx = Math.max(0, Math.min(allPts.length - 1, Math.round(t * 1000)));
    return allPts[idx] || allPts[0];
  }

  cStarEfficiency(): number {
    const pc = this.activePoint().chamber_pressure_filtered_bar;
    return pc > 10 ? 0.968 : 0.0;
  }

  cStarActual(): number {
    return this.cStarEfficiency() * 1820.0;
  }

  ofRatio(): number {
    const pc = this.activePoint().chamber_pressure_filtered_bar;
    return pc > 10 ? 2.81 : 0.0;
  }

  togglePlay() {
    if (this.isPlaying()) {
      this.pause();
    } else {
      this.play();
    }
  }

  play() {
    this.isPlaying.set(true);
    if (this.currentPlaybackTime() >= 0.99) {
      this.currentPlaybackTime.set(0.0);
    }
    this.timerId = setInterval(() => {
      let tNext = this.currentPlaybackTime() + 0.005;
      if (tNext >= 1.0) {
        tNext = 1.0;
        this.pause();
      }
      this.currentPlaybackTime.set(Math.round(tNext * 1000) / 1000);
    }, 20);
  }

  pause() {
    this.isPlaying.set(false);
    if (this.timerId) {
      clearInterval(this.timerId);
      this.timerId = null;
    }
  }

  resetTime() {
    this.pause();
    this.currentPlaybackTime.set(0.0);
  }

  onSliderChange(evt: Event) {
    const val = parseFloat((evt.target as HTMLInputElement).value);
    this.currentPlaybackTime.set(val);
  }
}
