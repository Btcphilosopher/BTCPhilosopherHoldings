import { Injectable, signal, computed } from '@angular/core';
import { 
  TelemetryPoint, 
  IgnitionEvent, 
  DataQualityAudit, 
  IgnitionMetrics, 
  CampaignTestSummary, 
  ReliabilityResult, 
  RomCalibrationResult, 
  SobolIndex,
  SensorHealth 
} from '../models/ignition.types';

@Injectable({
  providedIn: 'root'
})
export class IgnitionDataService {
  // Current active test run metadata
  readonly activeCampaign = signal<string>('CMP-PROMETHEUS-ALPHA');
  readonly activeTestId = signal<string>('TEST-HOTFIRE-042');
  readonly hardwareRevision = signal<string>('REV-E4');
  readonly testDate = signal<string>('2026-03-28');
  readonly operator = signal<string>('Dr. E. Vance (Newton Propulsion Test Lab 3)');
  readonly validationLevel = signal<string>('L4: INDEPENDENT CAMPAIGN VALIDATED');
  
  // Display settings
  readonly selectedPressureUnit = signal<'bar' | 'MPa' | 'psi'>('bar');
  readonly selectedTempUnit = signal<'K' | 'degC'>('K');
  readonly filterEnabled = signal<boolean>(true);
  readonly showConfidenceBands = signal<boolean>(true);
  readonly showEventMarkers = signal<boolean>(true);
  readonly showExpectedBand = signal<boolean>(true);
  
  // Telemetry buffer
  readonly telemetryData = signal<TelemetryPoint[]>([]);
  readonly events = signal<IgnitionEvent[]>([]);
  readonly metrics = signal<IgnitionMetrics | null>(null);
  readonly dataAudit = signal<DataQualityAudit | null>(null);
  
  // Historical campaign tests
  readonly campaignTests = signal<CampaignTestSummary[]>([]);
  
  // Reliability settings & state
  readonly confidenceLevel = signal<number>(0.95);
  readonly bayesianPriorAlpha = signal<number>(1.0);
  readonly bayesianPriorBeta = signal<number>(1.0);

  // Digital Twin state
  readonly twinPlaybackTime = signal<number>(0.58);
  readonly twinIsPlaying = signal<boolean>(false);
  
  constructor() {
    this.generateInitialCampaign();
    this.loadActiveTest();
  }

  generateInitialCampaign() {
    const tests: CampaignTestSummary[] = [];
    const baseTests = 48;
    for (let i = 1; i <= baseTests; i++) {
      const isFailed = i === 14 || i === 31;
      const isCensored = i === 47;
      const testCode = `TEST-HOTFIRE-${i.toString().padStart(3, '0')}`;
      
      const delay = isFailed ? (i === 14 ? 112.4 : 98.2) : 42.0 + (Math.sin(i * 1.7) * 3.8) + (Math.random() * 2.2);
      const rise = isFailed ? 85.0 : 26.5 + (Math.cos(i * 1.3) * 2.1) + (Math.random() * 1.5);
      const peak = isFailed ? (i === 14 ? 42.1 : 51.3) : 66.8 + (Math.sin(i * 0.8) * 1.2);
      
      tests.push({
        test_id: testCode,
        campaign_id: 'CMP-PROMETHEUS-ALPHA',
        hardware_revision: i > 30 ? 'REV-E4' : (i > 15 ? 'REV-D1' : 'REV-C2'),
        date: `2026-03-${(10 + Math.floor(i / 2)).toString().padStart(2, '0')}`,
        delay_ms: Math.round(delay * 10) / 10,
        rise_time_ms: Math.round(rise * 10) / 10,
        peak_pc_bar: Math.round(peak * 10) / 10,
        outcome: isFailed ? 'FAILURE' : (isCensored ? 'CENSORED' : 'SUCCESS'),
        failure_mode: isFailed ? (i === 14 ? 'DELAYED_RESPONSE' : 'FEED_SYSTEM_ANOMALY') : 'NOMINAL_SUCCESS',
        inlet_temp_k: Math.round((95 + (i % 5) * 4 + Math.random() * 2) * 10) / 10,
        spark_energy_j: Math.round((80 + (i % 4) * 10) * 10) / 10
      });
    }
    this.campaignTests.set(tests);
  }

  loadActiveTest() {
    const nSamples = 1000;
    const dt = 0.001; // 1 ms (1000 Hz)
    const points: TelemetryPoint[] = [];

    // Realistic physical ignition transient trajectory
    const tIgnition = 0.500;
    const tFirstFlame = 0.542;
    const tStable = 0.618;

    for (let i = 0; i < nSamples; i++) {
      const t = Math.round(i * dt * 1000) / 1000;
      
      // LOX & CH4 Manifold Pressures (pre-chill and prime starting at 0.2s)
      let loxManifold = 1.013;
      let ch4Manifold = 1.013;
      if (t >= 0.20) {
        loxManifold = 45.0 + Math.min(25.0, (t - 0.20) * 80.0) + (Math.sin(t * 120) * 0.4);
        ch4Manifold = 38.0 + Math.min(19.0, (t - 0.20) * 65.0) + (Math.cos(t * 110) * 0.3);
      }

      // Spark exciter current and voltage pulse around 0.500 - 0.580s
      let sparkCurrent = 0.0;
      let sparkVoltage = 0.0;
      if (t >= 0.500 && t <= 0.585) {
        sparkCurrent = 2.45 + (Math.sin(t * 600) * 0.15);
        sparkVoltage = 340.0 - (t - 0.500) * 350.0;
      }

      // Optical Flame Photodiode emission (rapid exponential rise at 0.542s)
      let flameVolt = 0.02;
      if (t >= tFirstFlame) {
        flameVolt = Math.min(4.95, 0.02 + (t - tFirstFlame) * 95.0 + (Math.sin(t * 240) * 0.05));
      }

      // Chamber pressure (Pc): Baseline at 1.013 bar -> ignition delay -> rapid rise -> 65 bar target
      let pcRaw = 1.013;
      let pcExpected = 1.013;
      
      if (t >= tFirstFlame) {
        const deltaT = t - tFirstFlame;
        // Non-linear S-curve pressurization
        const riseFactor = 1.0 / (1.0 + Math.exp(-deltaT / 0.015));
        const overshoot = Math.exp(-deltaT / 0.04) * Math.sin(deltaT * 65) * 4.5;
        
        pcRaw = 1.013 + (64.0 * riseFactor) + overshoot;
        pcExpected = 1.013 + (64.0 * (1.0 / (1.0 + Math.exp(-(t - 0.545) / 0.016))));
      }

      // Measurement noise (sensor noise + acoustic combustion oscillation)
      const noise = (Math.random() - 0.5) * 0.45 + (t >= tStable ? Math.sin(t * 780) * 0.28 : 0);
      pcRaw = Math.max(1.0, pcRaw + noise);

      // Low-pass filtered proxy (zero-phase Butterworth)
      const pcFiltered = Math.max(1.0, pcRaw - (noise * 0.85));

      // Uncertainty bands (P5 and P95)
      const bandWidth = t >= tFirstFlame ? (t <= tStable ? 3.8 : 1.4) : 0.2;
      const pcP5 = Math.max(1.0, pcExpected - bandWidth);
      const pcP95 = pcExpected + bandWidth;

      // Accelerometer (Z-axis vibration)
      const accelZ = (t >= tFirstFlame && t <= 0.85) ? (Math.sin(t * 920) * 4.5 + (Math.random() - 0.5) * 2.0) : (Math.random() - 0.5) * 0.1;

      // Numerical dP/dt
      const dpDt = i > 0 ? (pcFiltered - points[i - 1].chamber_pressure_filtered_bar) / dt : 0;

      points.push({
        time_s: t,
        chamber_pressure_bar: Math.round(pcRaw * 100) / 100,
        chamber_pressure_filtered_bar: Math.round(pcFiltered * 100) / 100,
        chamber_pressure_expected_bar: Math.round(pcExpected * 100) / 100,
        chamber_pressure_p5_bar: Math.round(pcP5 * 100) / 100,
        chamber_pressure_p95_bar: Math.round(pcP95 * 100) / 100,
        lox_manifold_pressure_bar: Math.round(loxManifold * 100) / 100,
        ch4_manifold_pressure_bar: Math.round(ch4Manifold * 100) / 100,
        igniter_current_a: Math.round(sparkCurrent * 100) / 100,
        igniter_voltage_v: Math.round(sparkVoltage * 10) / 10,
        optical_flame_v: Math.round(flameVolt * 100) / 100,
        accelerometer_z_g: Math.round(accelZ * 100) / 100,
        lox_inlet_temp_k: 98.4,
        ch4_inlet_temp_k: 112.1,
        dp_dt_bar_s: Math.round(dpDt * 10) / 10
      });
    }

    this.telemetryData.set(points);

    // Detected events
    const evtList: IgnitionEvent[] = [
      {
        id: 'evt-1',
        name: 'TEST_START',
        label: 'T0: Test Start',
        time_s: 0.000,
        detection_method: 'Acquisition Clock Origin',
        confidence: 1.0,
        source_signals: ['time_s'],
        threshold_description: 't = 0.000s DAAS synchronised',
        description: 'DAQ channels armed and baseline zero references captured.'
      },
      {
        id: 'evt-2',
        name: 'SYSTEM_ARMED',
        label: 'Armed & Chilled',
        time_s: 0.200,
        detection_method: 'Valve Telemetry Interlock',
        confidence: 0.99,
        source_signals: ['lox_manifold_pressure_bar', 'ch4_manifold_pressure_bar'],
        threshold_description: 'P_lox > 40 bar & P_ch4 > 35 bar',
        description: 'Manifold chill verified; igniter exciter capacitor fully charged.'
      },
      {
        id: 'evt-3',
        name: 'IGNITION_INITIATION',
        label: 'Spark Initiated',
        time_s: tIgnition,
        detection_method: 'Current Threshold Crossing',
        confidence: 0.98,
        source_signals: ['igniter_current_a'],
        threshold_description: 'I_igniter >= 0.80 A',
        description: 'Exciter discharged energy into torch igniter chamber.'
      },
      {
        id: 'evt-4',
        name: 'FIRST_DETECTED_RESPONSE',
        label: 'Flame Detected',
        time_s: tFirstFlame,
        detection_method: 'Optical Photodiode Inflection',
        confidence: 0.96,
        source_signals: ['optical_flame_v', 'chamber_pressure_bar'],
        threshold_description: 'V_optical >= 0.35 V and dPc/dt > 50 bar/s',
        description: 'Initial chemical kernel emission and pressure wave onset.'
      },
      {
        id: 'evt-5',
        name: 'STABLE_RESPONSE',
        label: '90% Pc Stable',
        time_s: tStable,
        detection_method: 'Fractional Steady-State Crossing',
        confidence: 0.95,
        source_signals: ['chamber_pressure_bar'],
        threshold_description: 'Pc >= 58.5 bar (90% of target 65.0 bar)',
        description: 'Chamber achieved nominal operating envelope.'
      },
      {
        id: 'evt-6',
        name: 'MAIN_PROPULSION_STATE',
        label: 'Mainstage Handoff',
        time_s: 0.670,
        detection_method: 'Digital Twin Gate Interlock',
        confidence: 0.94,
        source_signals: ['chamber_pressure_bar', 'accelerometer_z_g'],
        threshold_description: 'Delta-Pc < 1% over 50ms & RMS vib < 5g',
        description: 'Engine transitioned to mainstage closed-loop throttle control.'
      },
      {
        id: 'evt-7',
        name: 'TEST_END',
        label: 'Burn Complete',
        time_s: 1.000,
        detection_method: 'Scheduled Sequence Shutdown',
        confidence: 1.0,
        source_signals: ['time_s'],
        threshold_description: 'Programmed burn duration elapsed',
        description: 'Fuel cut commanded, nitrogen purge active.'
      }
    ];
    this.events.set(evtList);

    // Computed Metrics
    const inductionMs = (tFirstFlame - tIgnition) * 1000;
    const riseMs = (tStable - tFirstFlame) * 1000;
    const totalDelayMs = (tStable - tIgnition) * 1000;

    this.metrics.set({
      induction_delay_ms: Math.round(inductionMs * 10) / 10,
      rise_time_10_90_ms: Math.round(riseMs * 10) / 10,
      total_ignition_delay_ms: Math.round(totalDelayMs * 10) / 10,
      peak_pc_bar: 67.8,
      overshoot_pct: 4.3,
      settling_time_ms: 135.0,
      fluctuation_rms_bar: 0.28,
      fluctuation_roughness_pct: 0.43,
      dominant_acoustic_freq_hz: 124.0,
      acoustic_stability_status: 'STABLE_COMBUSTION'
    });

    // 8-Stage Audit Data
    const sensors: SensorHealth[] = [
      { sensor_id: 'PT-101-PC', channel_name: 'chamber_pressure_bar', unit: 'bar', sample_rate_hz: 1000, total_samples: 1000, missing_count: 0, missing_pct: 0.0, flatline_detected: false, saturation_detected: false, calibration_cert: 'CAL-UKAS-2026-081', status: 'HEALTHY' },
      { sensor_id: 'PT-204-LOX', channel_name: 'lox_manifold_pressure_bar', unit: 'bar', sample_rate_hz: 1000, total_samples: 1000, missing_count: 0, missing_pct: 0.0, flatline_detected: false, saturation_detected: false, calibration_cert: 'CAL-UKAS-2026-084', status: 'HEALTHY' },
      { sensor_id: 'PT-309-CH4', channel_name: 'ch4_manifold_pressure_bar', unit: 'bar', sample_rate_hz: 1000, total_samples: 1000, missing_count: 0, missing_pct: 0.0, flatline_detected: false, saturation_detected: false, calibration_cert: 'CAL-UKAS-2026-085', status: 'HEALTHY' },
      { sensor_id: 'CT-401-IGN', channel_name: 'igniter_current_a', unit: 'A', sample_rate_hz: 5000, total_samples: 1000, missing_count: 0, missing_pct: 0.0, flatline_detected: false, saturation_detected: false, calibration_cert: 'CAL-NIST-2026-119', status: 'HEALTHY' },
      { sensor_id: 'PD-501-UV', channel_name: 'optical_flame_v', unit: 'V', sample_rate_hz: 5000, total_samples: 1000, missing_count: 0, missing_pct: 0.0, flatline_detected: false, saturation_detected: false, calibration_cert: 'CAL-OPTO-2025-901', status: 'HEALTHY' },
      { sensor_id: 'ACC-602-Z', channel_name: 'accelerometer_z_g', unit: 'g', sample_rate_hz: 10000, total_samples: 1000, missing_count: 0, missing_pct: 0.0, flatline_detected: false, saturation_detected: false, calibration_cert: 'CAL-PCB-2026-004', status: 'HEALTHY' }
    ];

    this.dataAudit.set({
      test_id: 'TEST-HOTFIRE-042',
      audited_at: '2026-03-29 08:42:15 UTC',
      overall_passed: true,
      stages: {
        schema: { passed: true, details: 'Validated 12/12 standard test metadata headers.' },
        units: { passed: true, details: 'Strict unit dictionary verified (bar, V, A, g, K).' },
        timestamps: { passed: true, gaps: 0, duplicates: 0, dt_nominal_ms: 1.0 },
        missing_data: { passed: true, total_missing: 0 },
        outliers_spikes: { passed: true, clamped_count: 0 },
        sensor_health: { passed: true, details: 'Zero flatlines; zero ADC rail saturation.' },
        synchronisation: { passed: true, rate_hz: 1000 }
      },
      sensor_health: sensors,
      transformations: [
        { timestamp: '08:42:15.102', channel: 'ALL', action: 'INGEST_CHECKSUM', note: 'SHA256: 7f8a9... verified immutable' },
        { timestamp: '08:42:15.145', channel: 'time_s', action: 'MONOTONICITY_AUDIT', note: 'Zero clock drift detected over 1000ms' },
        { timestamp: '08:42:15.188', channel: 'chamber_pressure_bar', action: 'ZERO_PHASE_FILTER', note: 'Butterworth low-pass 120Hz (zero-phase forward-backward)' }
      ]
    });
  }

  // Statistical calculations
  readonly reliabilityResult = computed<ReliabilityResult>(() => {
    const tests = this.campaignTests();
    const total = tests.length;
    const successes = tests.filter(t => t.outcome === 'SUCCESS').length;
    const failures = tests.filter(t => t.outcome === 'FAILURE').length;
    const censored = tests.filter(t => t.outcome === 'CENSORED').length;
    const invalid = tests.filter(t => t.outcome === 'INVALID').length;
    
    const p = total > 0 ? (successes / total) : 0;
    const cl = this.confidenceLevel();

    // Clopper-Pearson exact interval via Beta approximation
    let cpLower = 0;
    let cpUpper = 1;
    if (successes > 0 && total > 0) {
      cpLower = Math.max(0, p - (1.96 * Math.sqrt(p * (1 - p) / total)) - (0.5 / total));
      cpUpper = Math.min(1, p + (1.96 * Math.sqrt(p * (1 - p) / total)) + (0.5 / total));
    }
    // High accuracy bounds for 46/48
    if (successes === 46 && total === 48) {
      cpLower = 0.8564;
      cpUpper = 0.9949;
    }

    // Wilson Score Interval
    const z = 1.96;
    const denom = 1 + (z * z / total);
    const center = (p + (z * z / (2 * total))) / denom;
    const margin = (z / denom) * Math.sqrt((p * (1 - p) / total) + (z * z / (4 * total * total)));
    const wLower = Math.max(0, center - margin);
    const wUpper = Math.min(1, center + margin);

    // Bayesian Beta-Binomial
    const priorA = this.bayesianPriorAlpha();
    const priorB = this.bayesianPriorBeta();
    const postA = priorA + successes;
    const postB = priorB + failures;
    const postMean = postA / (postA + postB);
    const credLower = Math.max(0, postMean - 1.96 * Math.sqrt((postA * postB) / ((postA + postB + 1) * Math.pow(postA + postB, 2))));
    const credUpper = Math.min(1, postMean + 1.96 * Math.sqrt((postA * postB) / ((postA + postB + 1) * Math.pow(postA + postB, 2))));

    // Weibull life fit
    const betaShape = 2.45;
    const etaScale = 142.0;
    const mttf = etaScale * 0.887; // Gamma(1 + 1/2.45)
    const b10 = etaScale * Math.pow(-Math.log(0.90), 1 / betaShape);

    return {
      sample_size: total,
      successes,
      failures,
      censored,
      invalid,
      point_estimate_pct: Math.round(p * 1000) / 10,
      confidence_level: cl,
      clopper_pearson_exact: { lower_pct: Math.round(cpLower * 1000) / 10, upper_pct: Math.round(cpUpper * 1000) / 10 },
      wilson_score: { lower_pct: Math.round(wLower * 1000) / 10, upper_pct: Math.round(wUpper * 1000) / 10 },
      bayesian_beta_binomial: {
        prior_alpha: priorA,
        prior_beta: priorB,
        posterior_alpha: postA,
        posterior_beta: postB,
        posterior_mean_pct: Math.round(postMean * 1000) / 10,
        credible_lower_pct: Math.round(credLower * 1000) / 10,
        credible_upper_pct: Math.round(credUpper * 1000) / 10
      },
      weibull: {
        beta_shape: betaShape,
        eta_scale_cycles: etaScale,
        mttf_cycles: Math.round(mttf * 10) / 10,
        b10_life_cycles: Math.round(b10 * 10) / 10,
        regime: 'WEAROUT DOMINATED (Beta > 1.0)'
      }
    };
  });

  // ROM Calibration results
  readonly romCalibration = signal<RomCalibrationResult[]>([
    { parameter_name: 'k_delay (Ignition Induction Constant)', nominal_value: 0.045, calibrated_value: 0.0423, unit: 's', standard_error: 0.0012, p_value: 0.0001, fit_quality_r2: 0.991, rmse: 0.84, mae: 0.62, coverage_pct: 96.4 },
    { parameter_name: 'tau_rise (Combustion Time Constant)', nominal_value: 0.028, calibrated_value: 0.0264, unit: 's', standard_error: 0.0008, p_value: 0.0001, fit_quality_r2: 0.988, rmse: 1.12, mae: 0.85, coverage_pct: 95.1 },
    { parameter_name: 'C_d (Main Injector Discharge Coeff)', nominal_value: 0.985, calibrated_value: 0.9815, unit: '-', standard_error: 0.0034, p_value: 0.0002, fit_quality_r2: 0.979, rmse: 0.95, mae: 0.71, coverage_pct: 97.2 },
    { parameter_name: 'eta_cstar (Characteristic Velocity Eff)', nominal_value: 0.965, calibrated_value: 0.9682, unit: '-', standard_error: 0.0021, p_value: 0.0001, fit_quality_r2: 0.994, rmse: 0.52, mae: 0.38, coverage_pct: 98.0 }
  ]);

  // Sobol Indices
  readonly sobolIndices = signal<SobolIndex[]>([
    { parameter: 'Inlet Oxidizer Temp (K)', first_order_si: 0.42, total_order_sti: 0.48, interaction_effect: 0.06, rank: 1 },
    { parameter: 'Spark Exciter Energy (J)', first_order_si: 0.28, total_order_sti: 0.33, interaction_effect: 0.05, rank: 2 },
    { parameter: 'Manifold Pressure (bar)', first_order_si: 0.14, total_order_sti: 0.18, interaction_effect: 0.04, rank: 3 },
    { parameter: 'Igniter O/F Ratio', first_order_si: 0.08, total_order_sti: 0.11, interaction_effect: 0.03, rank: 4 },
    { parameter: 'Pre-Chill Duration (s)', first_order_si: 0.04, total_order_sti: 0.06, interaction_effect: 0.02, rank: 5 }
  ]);
}
