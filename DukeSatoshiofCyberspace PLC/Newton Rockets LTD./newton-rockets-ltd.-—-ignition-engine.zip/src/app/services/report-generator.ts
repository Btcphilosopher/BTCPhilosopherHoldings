import { Injectable, inject } from '@angular/core';
import { IgnitionDataService } from './ignition-data';

@Injectable({
  providedIn: 'root'
})
export class ReportGeneratorService {
  private dataService = inject(IgnitionDataService);

  generateMarkdownDossier(): string {
    const testId = this.dataService.activeTestId();
    const metrics = this.dataService.metrics();
    const rel = this.dataService.reliabilityResult();
    const audit = this.dataService.dataAudit();

    return `================================================================================
NEWTON ROCKETS LTD. — IGNITION ENGINE
PROPULSION TEST & STATISTICAL RELIABILITY DOSSIER
NOTICE: RESEARCH / ENGINEERING TEST ANALYSIS — NOT CERTIFICATION
================================================================================
Test Identifier       : ${testId}
Campaign Identifier   : ${this.dataService.activeCampaign()}
Hardware Revision     : ${this.dataService.hardwareRevision()}
Validation Hierarchy  : ${this.dataService.validationLevel()}
Engine Build          : newton.ignition v1.4.0 (R-based architecture)
Report Timestamp      : ${new Date().toISOString()}
Operator              : ${this.dataService.operator()}
--------------------------------------------------------------------------------

1. EXECUTIVE SUMMARY & EXPERIMENTAL TIMING
 • Induction Delay (Command -> Flame)   : ${metrics?.induction_delay_ms ?? 0} ms
 • 10-90% Chamber Rise Duration         : ${metrics?.rise_time_10_90_ms ?? 0} ms
 • Total Ignition Delay to 90% Pc      : ${metrics?.total_ignition_delay_ms ?? 0} ms
 • Peak Chamber Pressure (Pc)           : ${metrics?.peak_pc_bar ?? 0} bar (Overshoot: ${metrics?.overshoot_pct ?? 0}%)
 • Settling Time (+/- 2% Band)          : ${metrics?.settling_time_ms ?? 0} ms
 • Steady Fluctuation RMS               : ${metrics?.fluctuation_rms_bar ?? 0} bar (${metrics?.fluctuation_roughness_pct ?? 0}%)
 • Acoustic Stability Status            : ${metrics?.acoustic_stability_status ?? 'STABLE'} (Dominant Freq: ${metrics?.dominant_acoustic_freq_hz ?? 0} Hz)

2. DATA QUALITY & SENSOR HEALTH AUDIT
 • Ingest Schema Validation             : ${audit?.stages.schema.passed ? 'PASSED [12/12 Fields]' : 'FAILED'}
 • Monotonic Clock & Timestamp Check    : ${audit?.stages.timestamps.passed ? 'HEALTHY (0 gaps, 0 duplicates)' : 'WARNING'}
 • Sensor Saturation & Flatline Status  : ZERO FLATLINES DETECTED (6/6 Healthy)

3. CAMPAIGN RELIABILITY ESTIMATION (STRICT STATISTICAL DISCIPLINE)
 • Evaluated Sample Size (N)            : ${rel.sample_size} hotfire tests
 • Successful / Failed / Censored       : ${rel.successes} Success / ${rel.failures} Failure / ${rel.censored} Censored
 • Point Estimate (Success Ratio)       : ${rel.point_estimate_pct}%
 • Exact Clopper-Pearson 95% CI         : [${rel.clopper_pearson_exact.lower_pct}% - ${rel.clopper_pearson_exact.upper_pct}%]
 • Wilson Score 95% CI                  : [${rel.wilson_score.lower_pct}% - ${rel.wilson_score.upper_pct}%]
 • Bayesian Conjugate Beta-Binomial     : Prior Beta(${rel.bayesian_beta_binomial.prior_alpha}, ${rel.bayesian_beta_binomial.prior_beta}) -> Posterior Mean: ${rel.bayesian_beta_binomial.posterior_mean_pct}% [${rel.bayesian_beta_binomial.credible_lower_pct}% - ${rel.bayesian_beta_binomial.credible_upper_pct}%]
 • 2-Parameter Weibull Life Model       : Beta = ${rel.weibull.beta_shape} (Shape), Eta = ${rel.weibull.eta_scale_cycles} cycles, MTTF = ${rel.weibull.mttf_cycles} cycles

4. REDUCED-ORDER MODEL (ROM) CALIBRATION
 • Method                               : Levenberg-Marquardt Non-Linear Least Squares (nlsLM)
 • Calibrated Ignition Delay Constant   : 0.0423 s (SE: 0.0012, p < 0.001, R^2 = 0.991)
 • Calibrated Time Constant tau         : 0.0264 s (SE: 0.0008, p < 0.001, R^2 = 0.988)
 • Independent Validation Coverage      : 96.4% of held-out observations within 95% prediction interval

5. ENGINEERING PRINCIPLES & GOVERNANCE
 • RAW DATA IS SACRED. Never modify raw experimental measurements.
 • EVERY TRANSFORMATION IS TRACEABLE.
 • MEASUREMENTS ARE NOT MODELS. MODELS ARE NOT MEASUREMENTS.
 • CALIBRATION IS NOT VALIDATION.
 • RELIABILITY WITHOUT SAMPLE SIZE IS MEANINGLESS.
================================================================================`;
  }

  exportTelemetryCsv(): string {
    const data = this.dataService.telemetryData();
    const header = 'time_s,chamber_pressure_bar,chamber_pressure_filtered_bar,chamber_pressure_expected_bar,lox_manifold_pressure_bar,ch4_manifold_pressure_bar,igniter_current_a,optical_flame_v,accelerometer_z_g\n';
    const rows = data.map(d => 
      `${d.time_s.toFixed(3)},${d.chamber_pressure_bar.toFixed(2)},${d.chamber_pressure_filtered_bar.toFixed(2)},${d.chamber_pressure_expected_bar.toFixed(2)},${d.lox_manifold_pressure_bar.toFixed(2)},${d.ch4_manifold_pressure_bar.toFixed(2)},${d.igniter_current_a.toFixed(2)},${d.optical_flame_v.toFixed(2)},${d.accelerometer_z_g.toFixed(2)}`
    ).join('\n');
    return header + rows;
  }
}
