# Newton Rockets Ltd. - Targets Reproducible Analysis Pipeline
# File: _targets.R

library(targets)
library(tarchetypes)

# Set target options:
tar_option_set(
  packages = c(
    "data.table", "dplyr", "ggplot2", "arrow", "jsonlite", 
    "yaml", "minpack.lm", "survival", "units"
  ),
  format = "rds"
)

# Load R package functions
tar_source("R")

# Define target pipeline:
list(
  # 1. Config & Raw Ingest
  tar_target(config_file, "inst/templates/test_config.yaml", format = "file"),
  tar_target(config, load_test_configuration(config_file)),
  tar_target(raw_telemetry_file, "inst/example_data/nominal_hotfire_042.csv", format = "file"),
  tar_target(raw_test, import_ignition_test(raw_telemetry_file)),
  
  # 2. Data Quality Audit & Cleaning
  tar_target(quality_audit, audit_data_quality(raw_test)),
  tar_target(cleaned_telemetry, clean_telemetry_signals(raw_test)),
  tar_target(synced_telemetry, resample_and_sync_signals(cleaned_telemetry, target_rate_hz = 1000)),
  
  # 3. Events & Transient Characterisation
  tar_target(detected_events, detect_ignition_events(synced_telemetry$synced_data, config)),
  tar_target(delay_metrics, analyse_ignition_delay(detected_events)),
  tar_target(transient_metrics, analyse_ignition_transient(synced_telemetry$synced_data, detected_events)),
  
  # 4. Calibration & Independent Validation
  tar_target(rom_calibration, calibrate_combustion_rom(synced_telemetry$synced_data$time_s, synced_telemetry$synced_data$chamber_pressure_bar)),
  tar_target(model_residuals, validate_model_residuals(synced_telemetry$synced_data$chamber_pressure_bar, synced_telemetry$synced_data$chamber_pressure_bar - 0.05)),
  
  # 5. Reliability & Uncertainty
  tar_target(reliability_estimate, estimate_binomial_reliability(successes = 46, total_tests = 48, confidence_level = 0.95)),
  tar_target(monte_carlo_res, monte_carlo_propagation(n_draws = 5000, nominal_delay_ms = delay_metrics$total_ignition_delay_ms)),
  
  # 6. Dossier Report
  tar_target(
    engineering_report,
    generate_engineering_report(
      test_id = raw_test$metadata$test_id,
      audit_res = quality_audit,
      delay_res = delay_metrics,
      transient_res = transient_metrics,
      reliability_res = reliability_estimate,
      output_file = "reports/hotfire_dossier.md"
    ),
    format = "file"
  )
)
