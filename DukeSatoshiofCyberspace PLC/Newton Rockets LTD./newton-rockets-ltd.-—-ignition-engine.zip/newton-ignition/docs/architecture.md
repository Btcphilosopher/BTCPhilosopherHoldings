# NEWTON ROCKETS LTD. — IGNITION ENGINE ARCHITECTURE
## Propulsion Subsystem Integration & Data Flow

```
+-------------------------------------------------------------------------------+
|                       NEWTON CRYOTANK (Propellant Storage)                   |
|                                       |                                       |
|                                       v                                       |
|                       PROPELLANT / FEED SYSTEM (Valves & Purges)              |
|                                       |                                       |
|                                       v                                       |
|                       PROPULSION DIGITAL TWIN (Physics Estimator)             |
|                                       |                                       |
|                                       v                                       |
|                       IGNITION ENGINE (R Statistical & Analysis Core)         |
|                                       |                                       |
|                                       v                                       |
|                       BOOSTER SYSTEM (Structural & Stage Integration)         |
|                                       |                                       |
|                                       v                                       |
|                       TEST / TELEMETRY (DAAS High-Speed DAQ)                  |
|                                       |                                       |
|                                       v                                       |
|                       STATISTICAL VALIDATION (Hierarchy Levels L0 - L5)      |
+-------------------------------------------------------------------------------+
```

### Module Responsibilities
- **R Package (`newton.ignition`)**: Mathematical, statistical, and data-transformation kernel.
- **Data Quality Pipeline**: 8-stage non-destructive validation prior to any calculations.
- **Event Detector**: Robust derivative ($dP_c/dt$), CUSUM change-point, and multi-sensor correlation.
- **Reliability Engine**: Exact Clopper-Pearson, Wilson Score, conjugate Bayesian Beta-Binomial, and Weibull life analysis.
- **Reduced-Order Model (ROM) Calibration**: Levenberg-Marquardt NLS fit with strict calibration/validation split.
- **Uncertainty Quantification**: 10,000-draw Monte Carlo and global Sobol sensitivity ranking.
- **Digital Twin**: Live state synchronisation with real or replay telemetry buffers.
