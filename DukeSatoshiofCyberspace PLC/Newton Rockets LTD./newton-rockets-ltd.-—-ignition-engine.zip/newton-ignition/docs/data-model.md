# NEWTON ROCKETS LTD. — IGNITION TEST DATA MODEL

## 1. Test Metadata Specification
Every test record must explicitly specify:
- `test_id`: Unique alphanumeric test run code (e.g. `TEST-HOTFIRE-042`)
- `campaign_id`: Campaign grouping identifier (e.g. `CMP-PROMETHEUS-ALPHA`)
- `vehicle_or_test_article`: Associated stage or subscale test rig (e.g. `NEWTON-STAGE-1-BOOSTER`)
- `configuration_id`: Fluid and injector pin configuration (e.g. `CFG-KEROLOX-PINTE-V3`)
- `hardware_revision`: Physical metal revision (e.g. `REV-E4`)
- `date`: ISO-8601 calendar date
- `operator`: Test conductor callsign
- `instrumentation_revision`: DAAS sensor map revision
- `software_version`: R engine build identifier
- `environment`: Ambient pressure and cell temperature
- `propellant_configuration`: LOX / CH4 density and subcooling state
- `test_condition`: Target chamber pressure and mixture ratio

## 2. Signal Channel Representation
Each sampled telemetry channel carries:
- `signal_id`: Channel name identifier
- `timestamp`: Monotonic elapsed time $t$ in seconds
- `value`: Measured scalar amplitude
- `unit`: Verified unit symbol (`bar`, `MPa`, `psi`, `K`, `V`, `A`, `g`)
- `sensor_id`: Calibrated transducer serial number
- `sample_rate`: Clock rate in Hertz ($Hz$)
- `calibration_revision`: Traceable lab calibration certificate
- `quality_flag`: `GOOD`, `WARNING_FLATLINE`, `SATURATED`, `INTERPOLATED_SPIKE`
