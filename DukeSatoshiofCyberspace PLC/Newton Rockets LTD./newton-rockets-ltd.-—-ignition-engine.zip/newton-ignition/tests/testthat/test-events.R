library(testthat)

test_that("Ignition event detection properly identifies spark initiation and 90% rise", {
  sample_t <- seq(0, 1, by = 0.001)
  sample_current <- c(rep(0, 500), rep(2.5, 100), rep(0, 401))
  sample_pc <- c(rep(1.0, 530), seq(1.0, 65.0, length.out = 100), rep(65.0, 371))
  sample_flame <- c(rep(0.0, 535), seq(0.0, 4.9, length.out = 50), rep(4.9, 416))
  
  df <- data.frame(
    time_s = sample_t,
    chamber_pressure_bar = sample_pc,
    igniter_current_a = sample_current,
    optical_flame_v = sample_flame
  )
  
  events <- detect_ignition_events(df)
  expect_equal(events$IGNITION_INITIATION$time_s, 0.500)
  expect_true(events$FIRST_DETECTED_RESPONSE$time_s >= 0.535)
  expect_true(events$STABLE_RESPONSE$time_s >= 0.600)
})

test_that("Unit conversion matrix handles bar to MPa and psi correctly", {
  p_bar <- 10.0
  p_mpa <- convert_engineering_units(p_bar, "bar", "MPa")
  expect_equal(p_mpa, 1.0)
  
  p_psi <- convert_engineering_units(p_bar, "bar", "psi")
  expect_equal(round(p_psi, 1), 145.0)
})
