library(testthat)

test_that("Binomial Clopper-Pearson exact confidence intervals obey coverage", {
  res <- estimate_binomial_reliability(successes = 10, total_tests = 10, confidence_level = 0.95)
  expect_equal(res$point_estimate, 1.0)
  # Lower bound for 10/10 at 95% is (0.025)^0.1 = 0.6915029
  expect_equal(res$clopper_pearson_exact$lower, round(0.025^0.1, 4))
  expect_equal(res$clopper_pearson_exact$upper, 1.0)
})

test_that("Bayesian conjugate Beta-Binomial update calculates proper posterior", {
  res <- bayesian_beta_binomial(successes = 48, total_tests = 50, prior_alpha = 2, prior_beta = 2)
  expect_equal(res$posterior$alpha, 50)
  expect_equal(res$posterior$beta, 4)
  expect_true(res$posterior_mean > 0.90)
})

test_that("Reliability without sample size triggers error", {
  expect_error(estimate_binomial_reliability(0, 0))
})
