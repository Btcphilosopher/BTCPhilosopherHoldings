# Newton Rockets Ltd. - Ignition Analysis Workstation (Shiny + bslib)
# Run with: Rscript -e "shiny::runApp('dashboard', port = 3000, host = '0.0.0.0')"

library(shiny)
library(bslib)
library(ggplot2)
library(plotly)
library(DT)
library(newton.ignition)

ui <- page_navbar(
  title = "NEWTON ROCKETS LTD. — IGNITION ENGINE",
  theme = bs_theme(
    version = 5,
    bg = "#070c14",
    fg = "#e2e8f0",
    primary = "#0284c7",
    secondary = "#475569",
    base_font = font_google("Space Grotesk"),
    code_font = font_google("JetBrains Mono")
  ),
  
  nav_panel("Test Overview",
    layout_sidebar(
      sidebar = sidebar(
        selectInput("sel_campaign", "Active Campaign:", choices = c("CMP-PROMETHEUS-ALPHA", "CMP-BEACONSFIELD-PULSE")),
        selectInput("sel_test", "Test Run:", choices = c("TEST-HOTFIRE-042", "TEST-HOTFIRE-043", "TEST-HOTFIRE-044")),
        actionButton("btn_run_audit", "Run 8-Stage Audit", class = "btn-primary w-100 mb-2"),
        hr(),
        div(class = "small text-muted", "Newton Rockets Ltd. Propulsion Division | Internal Engineering Tool")
      ),
      card(
        card_header("Ignition Transient Telemetry & Event Timeline"),
        plotlyOutput("plot_transient_oscillogram", height = "450px")
      ),
      layout_columns(
        card(
          card_header("Key Experimental Timing Metrics"),
          tableOutput("tbl_timing_metrics")
        ),
        card(
          card_header("Data Quality & Sensor Health Status"),
          tableOutput("tbl_sensor_audit")
        )
      )
    )
  ),
  
  nav_panel("Reliability Analysis",
    layout_columns(
      card(
        card_header("Binomial & Bayesian Reliability Engine"),
        sliderInput("sld_conf", "Confidence Level:", min = 0.80, max = 0.99, value = 0.95, step = 0.01),
        plotOutput("plot_bayesian_posterior", height = "350px")
      ),
      card(
        card_header("Clopper-Pearson Exact vs Wilson Bounds"),
        DTOutput("dt_reliability_comparison")
      )
    )
  ),
  
  nav_panel("Model Calibration & ROM",
    layout_columns(
      card(
        card_header("Newton ROM Levenberg-Marquardt Calibration"),
        plotOutput("plot_rom_calibration", height = "350px")
      ),
      card(
        card_header("Residual Diagnostics & 95% Prediction Envelope"),
        plotOutput("plot_rom_residuals", height = "350px")
      )
    )
  ),
  
  nav_panel("Uncertainty & Sobol",
    layout_columns(
      card(
        card_header("10,000-Draw Monte Carlo Delay Propagation"),
        plotOutput("plot_monte_carlo_dist", height = "350px")
      ),
      card(
        card_header("Global Sobol Sensitivity Indices (Si & STi)"),
        DTOutput("dt_sobol_table")
      )
    )
  )
)

server <- function(input, output, session) {
  # Reactive test data
  test_data <- reactive({
    import_ignition_test("inst/example_data/nominal_hotfire_042.csv")
  })
  
  output$plot_transient_oscillogram <- renderPlotly({
    raw_t <- test_data()
    cleaned <- clean_telemetry_signals(raw_t)
    synced <- resample_and_sync_signals(cleaned)
    events <- detect_ignition_events(synced$synced_data)
    plot_synchronized_oscillogram(synced$synced_data, events, interactive = TRUE)
  })
  
  output$tbl_timing_metrics <- renderTable({
    raw_t <- test_data()
    cleaned <- clean_telemetry_signals(raw_t)
    synced <- resample_and_sync_signals(cleaned)
    events <- detect_ignition_events(synced$synced_data)
    delays <- analyse_ignition_delay(events)
    trans <- analyse_ignition_transient(synced$synced_data, events)
    format_engineering_summary_table(list(delay = delays, transient = trans))
  })
  
  output$tbl_sensor_audit <- renderTable({
    raw_t <- test_data()
    audit <- audit_data_quality(raw_t)
    do.call(rbind, lapply(audit$sensor_health, function(x) {
      data.frame(Sensor = x$channel, Status = x$status, Missing_Pct = sprintf("%.1f%%", x$missing_pct))
    }))
  })
  
  output$plot_bayesian_posterior <- renderPlot({
    bayes <- bayesian_beta_binomial(46, 48, prior_alpha = 1, prior_beta = 1)
    df <- data.frame(
      p = bayes$density_curves$p_grid,
      Prior = bayes$density_curves$prior_density,
      Posterior = bayes$density_curves$posterior_density
    )
    ggplot(df, aes(x = p)) +
      geom_line(aes(y = Prior, color = "Prior Beta(1,1)"), linetype = "dashed") +
      geom_line(aes(y = Posterior, color = "Posterior Beta(47,3)"), linewidth = 1.2) +
      theme_minimal() +
      labs(title = "Bayesian Beta-Binomial Updating", x = "Reliability Probability (p)", y = "Probability Density")
  })
  
  output$dt_reliability_comparison <- renderDT({
    datatable(compare_reliability_intervals(46, 48, input$sld_conf), options = list(dom = 't'))
  })
  
  output$dt_sobol_table <- renderDT({
    datatable(calculate_sobol_indices(), options = list(dom = 't'))
  })
}

shinyApp(ui, server)
