# NEWTON ROCKETS LTD. — IGNITION ENGINE
## R-Based Ignition Test, Statistics & Digital-Twin Analysis Platform

```
================================================================================
NEWTON CRYOTANK  →  PROPELLANT FEED  →  PROPULSION DIGITAL TWIN  →  IGNITION ENGINE
                                                                          ↓
STATISTICAL VALIDATION  ←  TEST / TELEMETRY  ←  BOOSTER SYSTEM
================================================================================
```

The **IGNITION ENGINE** is the core experimental analysis, statistical modelling, reduced-order calibration, and reliability engineering platform within the Newton Rockets propulsion engineering stack.

> **CRITICAL NOTICE**: This software is strictly for measurement, modelling, statistical analysis, model calibration, and engineering decision support. It is NOT flight-control software. It does NOT generate autonomous ignition commands.

---

### Key Capabilities

1. **Rigorous Engineering Data Quality Pipeline**
   - 8-stage verification: Schema → Units (`units` package) → Timestamps → Missing Data Check → Outlier / Spike Check → Sensor Health & Flatline Check → Signal Synchronization.
   - Non-destructive audit trail and provenance tracking for every sensor channel.

2. **Ignition Event Detection & Timing Analysis**
   - Configurable detection: Derivative peak $\left(\frac{dP_c}{dt}\right)$, CUSUM statistical change-point, threshold crossing, and multi-sensor optical/flame photodiode correlation.
   - Delay metrics (Command → Flame, Initiator → Stable $90\% P_c$) with full distribution statistics (Mean, Median, MAD, P5, P50, P95, Clopper-Pearson / Student-t CIs).

3. **Transient Characterisation & Acoustic Stability**
   - $10-90\%$ Rise time, settling time ($\pm2\%$), overshoot percentage, chamber pressure peak, steady-state fluctuation RMS, and fast Fourier transform (FFT) power spectral density for chugging/screaming instability modes.

4. **Reliability Analysis**
   - Binomial reliability with exact Clopper-Pearson and Wilson score intervals.
   - Conjugate Bayesian Beta-Binomial updating (`Beta(α, β)` prior to posterior).
   - Kaplan-Meier non-parametric survival analysis and 2-parameter Weibull life distribution fitting ($\beta$ shape, $\eta$ scale).
   - Mandatory sample size reporting discipline.

5. **Reduced-Order Model (ROM) Calibration & Independent Validation**
   - Non-linear least squares (`minpack.lm::nlsLM`) and profile likelihood parameter estimation.
   - Strict separation of calibration and held-out validation datasets.
   - Comprehensive residual metrics: RMSE, MAE, normalized bias, prediction interval coverage.

6. **Uncertainty Quantification & Sobol Sensitivity**
   - 10,000-draw Monte Carlo propagation across measurement, parameter, and model-form uncertainties.
   - Global Sobol sensitivity index estimation ($S_i$ first order and $S_{Ti}$ total effect) for identifying dominant driver parameters.

7. **Experimental Digital Twin**
   - `IgnitionDigitalTwin` R6/S4 class synchronised with recorded and real-time telemetry streams.
   - Live state estimator, pressure proxy, thermal envelope, and validation status compliance.

---

### Core Philosophy

* **RAW DATA IS SACRED.** Raw experimental telemetry is never mutated or overwritten.
* **EVERY TRANSFORMATION IS TRACEABLE.** Full provenance tracking across all data transformations.
* **MEASUREMENTS ARE NOT MODELS.** Models predict; sensors measure. They remain strictly decoupled.
* **CALIBRATION IS NOT VALIDATION.** Held-out test observations must validate calibrated models.
* **RELIABILITY WITHOUT SAMPLE SIZE IS MEANINGLESS.** Uncertainty must accompany every metric.

---

### Directory Architecture

```
newton-ignition/
├── DESCRIPTION
├── NAMESPACE
├── README.md
├── _targets.R
├── R/
│   ├── ignition_state.R
│   ├── configuration.R
│   ├── data/ (import, schema, cleaning, synchronisation, quality)
│   ├── signals/ (filtering, baseline, derivatives, event_detection, segmentation)
│   ├── ignition/ (event_definition, delay, transient, repeatability, stability)
│   ├── combustion/ (interface, state_estimation, reduced_order)
│   ├── reliability/ (binomial, weibull, survival, bayesian, confidence)
│   ├── calibration/ (parameter_fit, residuals, validation, cross_validation)
│   ├── uncertainty/ (monte_carlo, sensitivity, bootstrap, uncertainty_budget)
│   ├── experiments/ (campaign, test_matrix, conditions, comparison)
│   ├── telemetry/ (schema, replay, provenance)
│   ├── reporting/ (report, tables, plots)
│   └── validation/ (analytical, statistical, experimental)
├── inst/
│   ├── templates/
│   └── example_data/
├── tests/testthat/
├── cli/newton-ignition
├── dashboard/app.R
└── docs/
```
