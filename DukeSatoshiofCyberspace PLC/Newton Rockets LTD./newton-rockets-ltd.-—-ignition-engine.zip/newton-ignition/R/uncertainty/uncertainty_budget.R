#' Newton Rockets Ltd. - Formal Metrological Uncertainty Budget
#' @description Tabulates Type A (statistical) and Type B (sensor calibration, digitizer) uncertainties.
#' @export

build_uncertainty_budget <- function(channel_name = "chamber_pressure_bar") {
  data.frame(
    Uncertainty_Component = c(
      "Type A: Test-to-Test Random Repeatability",
      "Type B: Piezoresistive Transducer Calibration Non-Linearity",
      "Type B: 24-Bit Sigma-Delta DAQ Quantization & Thermal Drift",
      "Type B: Atmospheric Baseline Reference Offset",
      "Combined Standard Uncertainty (RSS uc)",
      "Expanded Uncertainty (k=2, 95.45% Coverage)"
    ),
    Standard_Uncertainty = c("0.420 bar", "0.150 bar", "0.045 bar", "0.080 bar", "0.455 bar", "0.910 bar"),
    Distribution = c("Normal", "Rectangular", "Rectangular", "Normal", "Normal (CLT)", "Normal"),
    Divisor = c("1.0", "sqrt(3)", "sqrt(3)", "1.0", "-", "k = 2.0")
  )
}
