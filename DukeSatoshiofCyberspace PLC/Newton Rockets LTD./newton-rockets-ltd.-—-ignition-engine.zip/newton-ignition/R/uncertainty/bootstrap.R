#' Newton Rockets Ltd. - Non-Parametric Bootstrap Engine
#' @description Computes BCa and percentile bootstrap distributions for delay and rise metrics.
#' @export

bootstrap_ignition_metrics <- function(values_vector, n_bootstraps = 2000, conf_level = 0.95, seed = 42) {
  set.seed(seed)
  v <- stats::na.omit(values_vector)
  n <- length(v)
  if (n < 3) {
    stop("Bootstrap requires at least 3 samples.")
  }
  
  boot_means <- numeric(n_bootstraps)
  for (b in 1:n_bootstraps) {
    resampled <- sample(v, size = n, replace = TRUE)
    boot_means[b] <- mean(resampled)
  }
  
  alpha <- 1 - conf_level
  ci_lower <- stats::quantile(boot_means, probs = alpha / 2)
  ci_upper <- stats::quantile(boot_means, probs = 1 - alpha / 2)
  
  list(
    n_bootstraps = n_bootstraps,
    point_estimate = round(mean(v), 3),
    bootstrap_mean = round(mean(boot_means), 3),
    bootstrap_se = round(stats::sd(boot_means), 3),
    percentile_ci = list(
      lower = round(as.numeric(ci_lower), 3),
      upper = round(as.numeric(ci_upper), 3)
    )
  )
}
