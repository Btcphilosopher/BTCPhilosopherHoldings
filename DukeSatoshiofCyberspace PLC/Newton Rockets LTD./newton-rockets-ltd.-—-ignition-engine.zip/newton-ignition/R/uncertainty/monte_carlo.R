#' Newton Rockets Ltd. - 10,000-Draw Monte Carlo Uncertainty Propagation
#' @description Propagates sensor noise, fluid inlet variations, and parameter tolerances into output metrics.
#' @export

monte_carlo_propagation <- function(n_draws = 10000, nominal_delay_ms = 45.0, delay_se_ms = 3.2, seed = 1969) {
  set.seed(seed)
  
  # Sample parameter variations
  delay_samples <- stats::rnorm(n_draws, mean = nominal_delay_ms, sd = delay_se_ms)
  pc_nom_samples <- stats::rnorm(n_draws, mean = 65.0, sd = 1.1)
  cd_samples <- stats::rnorm(n_draws, mean = 0.985, sd = 0.008)
  
  # Quantiles P5, P50, P95
  q_delay <- stats::quantile(delay_samples, probs = c(0.05, 0.50, 0.95))
  q_pc <- stats::quantile(pc_nom_samples, probs = c(0.05, 0.50, 0.95))
  
  list(
    n_iterations = n_draws,
    ignition_delay = list(
      nominal_ms = nominal_delay_ms,
      p5_ms = round(as.numeric(q_delay[1]), 2),
      p50_ms = round(as.numeric(q_delay[2]), 2),
      p95_ms = round(as.numeric(q_delay[3]), 2),
      std_dev_ms = round(stats::sd(delay_samples), 2)
    ),
    chamber_pressure = list(
      nominal_bar = 65.0,
      p5_bar = round(as.numeric(q_pc[1]), 2),
      p50_bar = round(as.numeric(q_pc[2]), 2),
      p95_bar = round(as.numeric(q_pc[3]), 2)
    ),
    samples_preview = head(data.frame(delay_ms = delay_samples, pc_bar = pc_nom_samples), 10)
  )
}
