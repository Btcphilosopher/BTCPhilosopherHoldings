#' Newton Rockets Ltd. - Precision Oscillogram & Residual Plots
#' @description Produces ggplot2 / plotly visualisations adhering to the British aerospace test bench palette.
#' @import ggplot2
#' @export

plot_synchronized_oscillogram <- function(synced_df, events, interactive = FALSE) {
  # Standard aerospace palette: Navy, Slate, Cyan, Amber, Brick
  p <- ggplot2::ggplot(synced_df, ggplot2::aes(x = time_s)) +
    ggplot2::geom_line(ggplot2::aes(y = chamber_pressure_bar, color = "Chamber Pressure Pc (bar)"), linewidth = 0.9) +
    ggplot2::geom_line(ggplot2::aes(y = lox_manifold_pressure_bar, color = "LOX Manifold (bar)"), linewidth = 0.6, alpha = 0.75) +
    ggplot2::geom_line(ggplot2::aes(y = ch4_manifold_pressure_bar, color = "CH4 Manifold (bar)"), linewidth = 0.6, alpha = 0.75) +
    ggplot2::geom_vline(xintercept = events$IGNITION_INITIATION$time_s, linetype = "dashed", color = "#f59e0b") +
    ggplot2::geom_vline(xintercept = events$FIRST_DETECTED_RESPONSE$time_s, linetype = "dotted", color = "#06b6d4") +
    ggplot2::geom_vline(xintercept = events$STABLE_RESPONSE$time_s, linetype = "dashed", color = "#10b981") +
    ggplot2::theme_minimal(base_family = "sans") +
    ggplot2::labs(
      title = "NEWTON ROCKETS LTD. — SYNCHRONIZED IGNITION TRANSIENT",
      subtitle = "Zero-Phase Filtered Telemetry Overlay with Event Detection Markers",
      x = "Test Elapsed Time (s)",
      y = "Pressure (bar)",
      color = "Channel"
    ) +
    ggplot2::scale_color_manual(values = c(
      "Chamber Pressure Pc (bar)" = "#38bdf8",
      "LOX Manifold (bar)" = "#f43f5e",
      "CH4 Manifold (bar)" = "#34d399"
    ))
  
  if (interactive) {
    plotly::ggplotly(p)
  } else {
    p
  }
}
