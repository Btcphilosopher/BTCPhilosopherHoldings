#' Newton Rockets Ltd. - Publication-Grade Aerospace Engineering Tables
#' @description Generates formatted ASCII, LaTeX, and HTML summary tables for test reports.
#' @export

format_engineering_summary_table <- function(test_metrics) {
  data.frame(
    Parameter = c(
      "Induction Delay (Command -> Flame)",
      "Rise Time (10% - 90% Pc)",
      "Total Ignition Delay to 90% Pc",
      "Peak Chamber Pressure (Pc)",
      "Transient Overshoot",
      "Settling Time (+/- 2% Band)",
      "Steady-State Fluctuation (RMS)",
      "Combustion Acoustic Status"
    ),
    Value = c(
      sprintf("%.2f ms", test_metrics$delay$induction_delay_ms),
      sprintf("%.2f ms", test_metrics$transient$rise_time_10_90_ms),
      sprintf("%.2f ms", test_metrics$delay$total_ignition_delay_ms),
      sprintf("%.2f bar", test_metrics$transient$peak_pc_bar),
      sprintf("%.2f %%", test_metrics$transient$overshoot_pct),
      sprintf("%.2f ms", test_metrics$transient$settling_time_ms),
      sprintf("%.3f bar (%.2f%%)", test_metrics$transient$fluctuation_rms_bar, test_metrics$transient$fluctuation_roughness_pct),
      "STABLE (< 0.5% RMS @ 120Hz)"
    )
  )
}
