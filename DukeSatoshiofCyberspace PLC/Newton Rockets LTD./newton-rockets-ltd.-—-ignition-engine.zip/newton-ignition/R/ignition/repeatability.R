#' Newton Rockets Ltd. - Campaign Repeatability & Variance Decomposition
#' @description Computes within-test, between-test, and hardware configuration ANOVA variance components.
#' @export

analyse_campaign_repeatability <- function(campaign_test_metrics_df) {
  # Expected columns: test_id, config_id, delay_ms, rise_time_ms, peak_pc_bar
  df <- as.data.frame(campaign_test_metrics_df)
  n_tests <- nrow(df)
  if (n_tests < 3) {
    return(list(
      sufficient_sample = FALSE,
      message = "At least 3 tests required for formal repeatability decomposition."
    ))
  }
  
  # ANOVA for delay_ms by configuration if multiple configurations exist
  if (length(unique(df$config_id)) > 1) {
    fit_aov <- stats::aov(delay_ms ~ config_id, data = df)
    summary_aov <- summary(fit_aov)[[1]]
    between_var <- summary_aov["config_id", "Mean Sq"]
    within_var <- summary_aov["Residuals", "Mean Sq"]
    p_val <- summary_aov["config_id", "Pr(>F)"]
  } else {
    between_var <- 0.0
    within_var <- stats::var(df$delay_ms, na.rm = TRUE)
    p_val <- 1.0
  }
  
  # Coefficient of Variation (CV %)
  cv_delay_pct <- 100 * stats::sd(df$delay_ms, na.rm = TRUE) / mean(df$delay_ms, na.rm = TRUE)
  cv_peak_pct <- 100 * stats::sd(df$peak_pc_bar, na.rm = TRUE) / mean(df$peak_pc_bar, na.rm = TRUE)
  
  list(
    sufficient_sample = TRUE,
    total_tests = n_tests,
    mean_delay_ms = round(mean(df$delay_ms, na.rm = TRUE), 2),
    sd_delay_ms = round(stats::sd(df$delay_ms, na.rm = TRUE), 2),
    cv_delay_pct = round(cv_delay_pct, 2),
    cv_peak_pct = round(cv_peak_pct, 2),
    variance_components = list(
      between_config_ms2 = round(between_var, 3),
      within_config_ms2 = round(within_var, 3),
      anova_p_value = round(p_val, 4)
    )
  )
}
