#' Newton Rockets Ltd. - Ignition Delay & Timing Statistics
#' @description Computes multi-phase ignition delays and campaign-level distribution metrics with uncertainty intervals.
#' @export

analyse_ignition_delay <- function(events) {
  t_init <- events$IGNITION_INITIATION$time_s
  t_resp <- events$FIRST_DETECTED_RESPONSE$time_s
  t_stable <- events$STABLE_RESPONSE$time_s
  
  # Delays in milliseconds
  induction_delay_ms <- (t_resp - t_init) * 1000
  rise_duration_ms <- (t_stable - t_resp) * 1000
  total_ignition_delay_ms <- (t_stable - t_init) * 1000
  
  list(
    induction_delay_ms = round(induction_delay_ms, 2),
    rise_duration_ms = round(rise_duration_ms, 2),
    total_ignition_delay_ms = round(total_ignition_delay_ms, 2),
    timestamps = list(
      initiation_s = t_init,
      first_response_s = t_resp,
      stable_response_s = t_stable
    )
  )
}

#' @export
calculate_campaign_delay_statistics <- function(delay_vector_ms, confidence_level = 0.95) {
  v <- stats::na.omit(delay_vector_ms)
  n <- length(v)
  if (n == 0) return(NULL)
  
  mean_val <- mean(v)
  sd_val <- if (n > 1) stats::sd(v) else 0.0
  med_val <- stats::median(v)
  mad_val <- stats::mad(v)
  
  # Quantiles P5, P50, P95
  q_vals <- stats::quantile(v, probs = c(0.05, 0.50, 0.95), type = 7)
  
  # Student-t / Normal confidence interval for the mean
  if (n > 1) {
    se <- sd_val / sqrt(n)
    t_crit <- stats::qt(1 - (1 - confidence_level) / 2, df = n - 1)
    ci_lower <- mean_val - t_crit * se
    ci_upper <- mean_val + t_crit * se
  } else {
    ci_lower <- mean_val
    ci_upper <- mean_val
  }
  
  list(
    n_samples = n,
    mean_ms = round(mean_val, 2),
    sd_ms = round(sd_val, 2),
    median_ms = round(med_val, 2),
    mad_ms = round(mad_val, 2),
    p5_ms = round(as.numeric(q_vals[1]), 2),
    p50_ms = round(as.numeric(q_vals[2]), 2),
    p95_ms = round(as.numeric(q_vals[3]), 2),
    ci_mean = list(
      level = confidence_level,
      lower_ms = round(ci_lower, 2),
      upper_ms = round(ci_upper, 2)
    )
  )
}
