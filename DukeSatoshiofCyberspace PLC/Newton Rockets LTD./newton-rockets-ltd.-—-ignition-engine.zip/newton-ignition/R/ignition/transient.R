#' Newton Rockets Ltd. - Ignition Transient Characterisation Engine
#' @description Computes 10-90% rise times, settling time, overshoot %, peak chamber pressure, and RMS roughness.
#' @export

analyse_ignition_transient <- function(synced_df, events, target_pc_bar = 65.0) {
  t <- synced_df$time_s
  pc <- synced_df$chamber_pressure_bar %||% synced_df$pc_bar %||% rep(0, length(t))
  
  t_init <- events$IGNITION_INITIATION$time_s
  t_end <- events$TEST_END$time_s
  
  # Active transient window
  active_mask <- which(t >= t_init & t <= t_end)
  t_act <- t[active_mask]
  pc_act <- pc[active_mask]
  
  if (length(pc_act) == 0) {
    stop("No active telemetry points in ignition window.")
  }
  
  pc_max <- max(pc_act, na.rm = TRUE)
  pc_max_idx <- which(pc_act == pc_max)[1]
  t_peak <- t_act[pc_max_idx]
  
  # 10% and 90% rise thresholds based on steady target
  p10 <- target_pc_bar * 0.10
  p90 <- target_pc_bar * 0.90
  
  t10_idx <- which(pc_act >= p10)[1]
  t90_idx <- which(pc_act >= p90)[1]
  
  t10 <- if (!is.na(t10_idx)) t_act[t10_idx] else t_init
  t90 <- if (!is.na(t90_idx)) t_act[t90_idx] else t_init + 0.1
  rise_time_10_90_ms <- (t90 - t10) * 1000
  
  # Overshoot percentage
  overshoot_pct <- max(0, 100 * (pc_max - target_pc_bar) / target_pc_bar)
  
  # Settling time (within ±2% of target)
  settling_band <- c(target_pc_bar * 0.98, target_pc_bar * 1.02)
  post_rise_mask <- which(t_act >= t90)
  
  # Find last time outside settling band
  outside_indices <- post_rise_mask[which(pc_act[post_rise_mask] < settling_band[1] | pc_act[post_rise_mask] > settling_band[2])]
  if (length(outside_indices) > 0) {
    t_settled <- t_act[max(outside_indices)] + (t_act[2] - t_act[1])
  } else {
    t_settled <- t90
  }
  settling_time_ms <- (t_settled - t_init) * 1000
  
  # Steady state RMS pressure fluctuation
  steady_mask <- which(t_act >= t_settled & t_act <= min(t_settled + 1.0, max(t_act)))
  if (length(steady_mask) > 5) {
    steady_pc <- pc_act[steady_mask]
    fluctuation_rms_bar <- sqrt(mean((steady_pc - mean(steady_pc))^2))
  } else {
    fluctuation_rms_bar <- 0.05
  }
  
  list(
    target_pc_bar = target_pc_bar,
    peak_pc_bar = round(pc_max, 2),
    t_peak_s = round(t_peak, 4),
    rise_time_10_90_ms = round(rise_time_10_90_ms, 2),
    settling_time_ms = round(settling_time_ms, 2),
    overshoot_pct = round(overshoot_pct, 2),
    fluctuation_rms_bar = round(fluctuation_rms_bar, 3),
    fluctuation_roughness_pct = round(100 * fluctuation_rms_bar / target_pc_bar, 2)
  )
}
