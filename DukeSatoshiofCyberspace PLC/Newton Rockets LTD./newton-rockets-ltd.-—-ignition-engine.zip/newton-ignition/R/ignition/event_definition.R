#' Newton Rockets Ltd. - Ignition Event Definitions
#' @description Formal definitions and metadata documentation for all propulsion event boundaries.
#' @export

IGNITION_STANDARD_EVENTS <- list(
  TEST_START = list(
    description = "Acquisition system clock origin and initial valve telemetry baseline check.",
    nominal_relative_time_s = 0.0
  ),
  SYSTEM_ARMED = list(
    description = "Pyro/spark igniter capacitor charged, purge valves verified closed, propellant chill confirmed.",
    nominal_relative_time_s = 0.2
  ),
  IGNITION_INITIATION = list(
    description = "Electrical trigger command or spark current pulse to exciter coil.",
    nominal_relative_time_s = 0.5
  ),
  FIRST_DETECTED_RESPONSE = list(
    description = "Initial optical flame emission or Pc inflection crossing > 2.5 bar above manifold baseline.",
    nominal_relative_time_s = 0.545
  ),
  STABLE_RESPONSE = list(
    description = "Chamber pressure achieves 90% of nominal target steady-state value.",
    nominal_relative_time_s = 0.620
  ),
  MAIN_PROPULSION_STATE = list(
    description = "Full propellant flow latching, transition to closed-loop digital twin monitoring.",
    nominal_relative_time_s = 0.670
  ),
  TEST_END = list(
    description = "Commanded shutdown sequence and purge activation.",
    nominal_relative_time_s = 3.0
  )
)
