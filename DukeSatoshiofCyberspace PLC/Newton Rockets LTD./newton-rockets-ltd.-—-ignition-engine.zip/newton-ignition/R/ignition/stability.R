#' Newton Rockets Ltd. - Combustion Acoustic Stability & Chugging Analysis
#' @description Computes Fast Fourier Transform (FFT) power spectra on high-speed dynamic chamber pressure.
#' @export

analyse_combustion_stability <- function(time_vector, dynamic_pc_vector, sample_rate_hz = 1000) {
  n <- length(dynamic_pc_vector)
  if (n < 64) {
    return(list(status = "INSUFFICIENT_DATA", peak_freq_hz = 0, peak_power = 0))
  }
  
  # Remove DC component
  sig_zero <- dynamic_pc_vector - mean(dynamic_pc_vector, na.rm = TRUE)
  
  # Apply Hanning window
  hanning_w <- 0.5 * (1 - cos(2 * pi * (0:(n - 1)) / (n - 1)))
  sig_windowed <- sig_zero * hanning_w
  
  # FFT
  fft_res <- stats::fft(sig_windowed)
  mag <- Mod(fft_res[1:(n / 2)])
  freqs <- (0:((n / 2) - 1)) * (sample_rate_hz / n)
  
  # Exclude very low drift (< 10 Hz)
  valid_freq_idx <- which(freqs >= 10)
  peak_sub_idx <- which.max(mag[valid_freq_idx])
  peak_freq <- freqs[valid_freq_idx[peak_sub_idx]]
  peak_mag <- mag[valid_freq_idx[peak_sub_idx]]
  
  # Instability classification (Chugging: 10-400 Hz, Screaming: > 1000 Hz)
  status <- if (peak_mag > 15.0) "ACOUSTIC_ANOMALY_WARNING" else "STABLE_COMBUSTION"
  
  list(
    status = status,
    dominant_frequency_hz = round(peak_freq, 1),
    spectral_peak_power = round(peak_mag, 2),
    frequencies = freqs[1:min(length(freqs), 200)],
    power_spectrum = mag[1:min(length(mag), 200)]
  )
}
