#' Newton Rockets Ltd. - 2-Parameter Weibull Life & Failure Rate Analysis
#' @description Fits Weibull distributions to multi-cycle spark exciter / igniter firing life data.
#' @export

estimate_weibull_parameters <- function(cycles_to_failure, censored_flags = NULL) {
  t <- as.numeric(cycles_to_failure)
  if (length(t) < 3) {
    stop("Weibull analysis requires at least 3 failure/censored observations.")
  }
  
  # Log-linear hazard regression for robust initial parameters
  y <- log(t)
  # Empirical median ranks
  n <- length(t)
  order_idx <- order(t)
  t_sorted <- t[order_idx]
  ranks <- (1:n - 0.3) / (n + 0.4)
  
  # Weibull linearization: ln(-ln(1 - F)) = beta * ln(t) - beta * ln(eta)
  w_y <- log(-log(1 - ranks))
  w_x <- log(t_sorted)
  
  fit <- stats::lm(w_y ~ w_x)
  beta_shape <- stats::coef(fit)[2]
  eta_scale <- exp(-stats::coef(fit)[1] / beta_shape)
  
  # MTTF = eta * Gamma(1 + 1/beta)
  mttf <- eta_scale * gamma(1 + (1 / beta_shape))
  b10_life <- eta_scale * (-log(1 - 0.10))^(1 / beta_shape)
  
  list(
    sample_size = n,
    beta_shape = round(as.numeric(beta_shape), 3),
    eta_scale = round(as.numeric(eta_scale), 2),
    mttf_cycles = round(as.numeric(mttf), 1),
    b10_life_cycles = round(as.numeric(b10_life), 1),
    failure_mode_interpretation = if (beta_shape < 1.0) "INFANT_MORTALITY" else if (beta_shape <= 1.2) "RANDOM_FAILURES_CONSTANT_HAZARD" else "WEAROUT_DOMINATED"
  )
}
