#' Newton Rockets Ltd. - Multi-Interval Confidence Comparison
#' @description Compares Clopper-Pearson, Wilson, Agresti-Coull, and Jeffrey's Prior intervals.
#' @export

compare_reliability_intervals <- function(successes, total_tests, conf_level = 0.95) {
  cp <- estimate_binomial_reliability(successes, total_tests, conf_level)
  bayes <- bayesian_beta_binomial(successes, total_tests, prior_alpha = 0.5, prior_beta = 0.5, credible_level = conf_level)
  
  data.frame(
    Method = c("Exact Clopper-Pearson", "Wilson Score", "Jeffrey's Uninformative Prior"),
    Lower_Pct = c(cp$clopper_pearson_exact$lower_pct, cp$wilson_score$lower * 100, bayes$credible_interval$lower_pct),
    Point_Estimate_Pct = rep(cp$point_estimate_pct, 3),
    Upper_Pct = c(cp$clopper_pearson_exact$upper_pct, cp$wilson_score$upper * 100, bayes$credible_interval$upper_pct),
    Confidence_Level = rep(conf_level, 3)
  )
}
