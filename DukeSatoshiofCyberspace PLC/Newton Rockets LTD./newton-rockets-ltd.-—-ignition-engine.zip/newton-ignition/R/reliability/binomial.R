#' Newton Rockets Ltd. - Binomial Reliability & Clopper-Pearson Exact Confidence
#' @description Computes frequentist reliability bounds with strict sample size and failure taxonomy discipline.
#' @export

estimate_binomial_reliability <- function(successes, total_tests, confidence_level = 0.95) {
  if (total_tests <= 0) {
    stop("Sample size (total_tests) must be > 0. Reliability without sample size is meaningless.")
  }
  if (successes > total_tests || successes < 0) {
    stop("Successes must be between 0 and total_tests.")
  }
  
  failures <- total_tests - successes
  point_estimate <- successes / total_tests
  
  # Exact Clopper-Pearson (Beta distribution quantiles)
  alpha <- 1 - confidence_level
  
  if (successes == 0) {
    ci_lower <- 0.0
  } else {
    ci_lower <- stats::qbeta(alpha / 2, successes, total_tests - successes + 1)
  }
  
  if (successes == total_tests) {
    ci_upper <- 1.0
  } else {
    ci_upper <- stats::qbeta(1 - alpha / 2, successes + 1, total_tests - successes)
  }
  
  # Wilson Score Interval
  z <- stats::qnorm(1 - alpha / 2)
  denom <- 1 + (z^2 / total_tests)
  center <- (point_estimate + (z^2 / (2 * total_tests))) / denom
  margin <- (z / denom) * sqrt((point_estimate * (1 - point_estimate) / total_tests) + (z^2 / (4 * total_tests^2)))
  
  wilson_lower <- max(0, center - margin)
  wilson_upper <- min(1, center + margin)
  
  list(
    sample_size = total_tests,
    successes = successes,
    failures = failures,
    point_estimate = round(point_estimate, 4),
    point_estimate_pct = round(point_estimate * 100, 2),
    confidence_level = confidence_level,
    clopper_pearson_exact = list(
      lower = round(ci_lower, 4),
      upper = round(ci_upper, 4),
      lower_pct = round(ci_lower * 100, 2),
      upper_pct = round(ci_upper * 100, 2)
    ),
    wilson_score = list(
      lower = round(wilson_lower, 4),
      upper = round(wilson_upper, 4)
    ),
    engineering_discipline_note = "Every reliability statement carries sample size and exact uncertainty bounds."
  )
}
