#' Newton Rockets Ltd. - Non-Parametric Kaplan-Meier Survival Analysis
#' @description Computes non-parametric survival curves and hazard rates for firing test sequences.
#' @importFrom survival Surv survfit
#' @export

estimate_survival_curve <- function(time_or_cycles, status_event) {
  # status_event: 1 = failure, 0 = censored / survived planned burn
  surv_obj <- survival::Surv(time = time_or_cycles, event = status_event)
  fit <- survival::survfit(surv_obj ~ 1)
  
  summary_fit <- summary(fit)
  
  list(
    time = summary_fit$time,
    n_risk = summary_fit$n.risk,
    n_event = summary_fit$n.event,
    survival_prob = round(summary_fit$surv, 4),
    lower_95_ci = round(summary_fit$lower, 4),
    upper_95_ci = round(summary_fit$upper, 4),
    median_survival = summary_fit$table["median"]
  )
}
