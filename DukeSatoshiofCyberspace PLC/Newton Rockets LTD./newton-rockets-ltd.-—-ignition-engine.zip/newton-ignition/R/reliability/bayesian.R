#' Newton Rockets Ltd. - Bayesian Conjugate Beta-Binomial Reliability Engine
#' @description Updates prior aerospace reliability beliefs with observed hotfire trial counts.
#' @export

bayesian_beta_binomial <- function(successes, total_tests, prior_alpha = 1.0, prior_beta = 1.0, credible_level = 0.95) {
  if (total_tests < 0 || successes < 0 || successes > total_tests) {
    stop("Invalid binomial observation counts.")
  }
  
  failures <- total_tests - successes
  post_alpha <- prior_alpha + successes
  post_beta <- prior_beta + failures
  
  post_mean <- post_alpha / (post_alpha + post_beta)
  post_mode <- if (post_alpha > 1 && post_beta > 1) {
    (post_alpha - 1) / (post_alpha + post_beta - 2)
  } else {
    post_mean
  }
  
  # Equal-tailed credible interval
  alpha_tail <- 1 - credible_level
  cred_lower <- stats::qbeta(alpha_tail / 2, post_alpha, post_beta)
  cred_upper <- stats::qbeta(1 - alpha_tail / 2, post_alpha, post_beta)
  
  # PDF points for plotting
  p_grid <- seq(0.001, 0.999, length.out = 150)
  prior_pdf <- stats::dbeta(p_grid, prior_alpha, prior_beta)
  post_pdf <- stats::dbeta(p_grid, post_alpha, post_beta)
  
  list(
    prior = list(alpha = prior_alpha, beta = prior_beta),
    posterior = list(alpha = post_alpha, beta = post_beta),
    posterior_mean = round(post_mean, 4),
    posterior_mean_pct = round(post_mean * 100, 2),
    posterior_mode = round(post_mode, 4),
    credible_level = credible_level,
    credible_interval = list(
      lower = round(cred_lower, 4),
      upper = round(cred_upper, 4),
      lower_pct = round(cred_lower * 100, 2),
      upper_pct = round(cred_upper * 100, 2)
    ),
    density_curves = list(
      p_grid = p_grid,
      prior_density = prior_pdf,
      posterior_density = post_pdf
    )
  )
}
