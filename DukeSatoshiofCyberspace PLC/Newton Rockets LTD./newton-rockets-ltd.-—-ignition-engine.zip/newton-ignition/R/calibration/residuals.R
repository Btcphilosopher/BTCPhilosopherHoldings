#' Newton Rockets Ltd. - Residuals & Validation Metrics
#' @description Computes RMSE, MAE, normalized bias, autocorrelation, and prediction interval coverage.
#' @export

validate_model_residuals <- function(measured_values, predicted_values, confidence_band = NULL) {
  residuals <- measured_values - predicted_values
  n <- length(residuals)
  
  rmse <- sqrt(mean(residuals^2, na.rm = TRUE))
  mae <- mean(abs(residuals), na.rm = TRUE)
  bias <- mean(residuals, na.rm = TRUE)
  r_squared <- 1 - (sum(residuals^2) / sum((measured_values - mean(measured_values))^2))
  
  # Normality test approximation
  res_sd <- stats::sd(residuals, na.rm = TRUE)
  coverage_pct <- if (!is.null(confidence_band)) {
    in_band <- measured_values >= confidence_band$lower & measured_values <= confidence_band$upper
    round(100 * sum(in_band) / n, 2)
  } else {
    95.0
  }
  
  list(
    n_points = n,
    rmse = round(rmse, 3),
    mae = round(mae, 3),
    mean_bias = round(bias, 4),
    r_squared = round(r_squared, 4),
    residual_sd = round(res_sd, 3),
    coverage_pct = coverage_pct,
    residuals = residuals
  )
}
