#' Newton Rockets Ltd. - Independent Model Validation Split
#' @description Enforces strict separation between calibration tests and held-out verification tests.
#' @export

split_calibration_validation_campaign <- function(test_list, train_ratio = 0.70, seed = 42) {
  set.seed(seed)
  n <- length(test_list)
  if (n < 2) {
    stop("At least 2 tests required to partition calibration and validation sets.")
  }
  
  train_size <- max(1, floor(n * train_ratio))
  train_indices <- sample(seq_len(n), size = train_size, replace = FALSE)
  val_indices <- setdiff(seq_len(n), train_indices)
  
  list(
    calibration_tests = test_list[train_indices],
    validation_tests = test_list[val_indices],
    calibration_count = length(train_indices),
    validation_count = length(val_indices),
    policy_compliance = "CALIBRATION DATA STRICTLY DECOUPLED FROM VALIDATION DATA"
  )
}
