#' Newton Rockets Ltd. - K-Fold Cross-Validation for Propulsion ROMs
#' @description Performs k-fold cross validation across multi-test campaign matrices.
#' @export

kfold_cross_validate_rom <- function(campaign_df, k = 5) {
  n <- nrow(campaign_df)
  if (n < k) k <- n
  
  folds <- sample(rep(1:k, length.out = n))
  fold_rmse <- numeric(k)
  
  for (i in 1:k) {
    train_set <- campaign_df[folds != i, ]
    val_set <- campaign_df[folds == i, ]
    
    # Estimate mean delay on train, test on val
    train_mean <- mean(train_set$delay_ms, na.rm = TRUE)
    fold_rmse[i] <- sqrt(mean((val_set$delay_ms - train_mean)^2, na.rm = TRUE))
  }
  
  list(
    k_folds = k,
    cv_rmse_mean = round(mean(fold_rmse), 2),
    cv_rmse_sd = round(stats::sd(fold_rmse), 2),
    fold_rmse = round(fold_rmse, 2)
  )
}
