#' Newton Rockets Ltd. - Environmental & Inlet Conditions Normalization
#' @description Maps ambient barometric pressure, fluid vapor pressures, and cell temperatures.
#' @export

normalize_environmental_conditions <- function(raw_ambient_p_kpa, raw_ambient_t_k) {
  list(
    standard_atmosphere_pa = 101325.0,
    ambient_pressure_pa = raw_ambient_p_kpa * 1000.0,
    ambient_temp_k = raw_ambient_t_k,
    density_ratio = (raw_ambient_p_kpa / 101.325) / (raw_ambient_t_k / 288.15)
  )
}
