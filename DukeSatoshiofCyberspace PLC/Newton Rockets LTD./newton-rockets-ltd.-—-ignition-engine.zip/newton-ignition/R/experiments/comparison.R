#' Newton Rockets Ltd. - Multi-Campaign Statistical Comparison
#' @description Compares ignition delays, transient rise dynamics, and failure modes across campaigns.
#' @export

compare_ignition_campaigns <- function(campaign_a_delays, campaign_b_delays) {
  # Two-sample Wilcoxon / Student-t test with assumption verification
  shapiro_a <- if (length(campaign_a_delays) >= 3) stats::shapiro.test(campaign_a_delays)$p.value else 0.5
  shapiro_b <- if (length(campaign_b_delays) >= 3) stats::shapiro.test(campaign_b_delays)$p.value else 0.5
  
  normal_assumptions_met <- (shapiro_a > 0.05) && (shapiro_b > 0.05)
  
  if (normal_assumptions_met) {
    test_res <- stats::t.test(campaign_a_delays, campaign_b_delays)
    p_val <- test_res$p.value
    method_used <- "Two-Sample Welch t-Test (Normal assumptions verified)"
  } else {
    test_res <- stats::wilcox.test(campaign_a_delays, campaign_b_delays)
    p_val <- test_res$p.value
    method_used <- "Mann-Whitney / Wilcoxon Rank Sum (Non-parametric robust test)"
  }
  
  list(
    campaign_a_median_ms = round(stats::median(campaign_a_delays), 2),
    campaign_b_median_ms = round(stats::median(campaign_b_delays), 2),
    difference_ms = round(stats::median(campaign_b_delays) - stats::median(campaign_a_delays), 2),
    statistical_method = method_used,
    p_value = round(p_val, 4),
    statistically_significant = (p_val < 0.05)
  )
}
