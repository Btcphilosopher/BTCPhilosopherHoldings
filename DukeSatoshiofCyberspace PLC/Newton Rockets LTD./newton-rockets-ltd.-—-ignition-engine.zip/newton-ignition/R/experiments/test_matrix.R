#' Newton Rockets Ltd. - Test Matrix Specification & Coverage
#' @description Represents multi-dimensional test design envelopes (inlet temperatures, pressures, mixtures).
#' @export

build_ignition_test_matrix <- function() {
  expand.grid(
    Inlet_Pressure_Bar = c(50.0, 65.0, 80.0),
    Inlet_Temp_K = c(95.0, 110.0, 125.0),
    Igniter_Energy_J = c(60.0, 85.0, 110.0),
    Hardware_Rev = c("REV-D1", "REV-E4")
  )
}
