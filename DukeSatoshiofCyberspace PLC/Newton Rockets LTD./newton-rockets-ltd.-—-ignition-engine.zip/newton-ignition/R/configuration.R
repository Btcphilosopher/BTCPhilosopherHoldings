#' Newton Rockets Ltd. - Ignition Engine Configuration Management
#' @description Loads, validates, and freezes ignition test analysis configurations.
#' @importFrom yaml read_yaml
#' @importFrom jsonlite fromJSON
#' @export

load_test_configuration <- function(config_path = NULL, config_list = NULL) {
  if (!is.null(config_path) && file.exists(config_path)) {
    if (grepl("\\.ya?ml$", config_path, ignore.case = TRUE)) {
      cfg <- yaml::read_yaml(config_path)
    } else {
      cfg <- jsonlite::fromJSON(config_path, simplifyVector = FALSE)
    }
  } else if (!is.null(config_list)) {
    cfg <- config_list
  } else {
    cfg <- get_default_ignition_config()
  }

  validated_cfg <- validate_configuration_schema(cfg)
  lock_configuration(validated_cfg)
}

get_default_ignition_config <- function() {
  list(
    software_version = "1.4.0",
    organization = "Newton Rockets Ltd.",
    module = "IGNITION ENGINE",
    sample_rate_target_hz = 1000,
    time_unit = "seconds",
    pressure_units = list(
      raw = "bar",
      standard = "MPa",
      display = "bar"
    ),
    event_thresholds = list(
      command_voltage_v = 18.0,
      spark_current_a = 0.8,
      chamber_pressure_rise_bar = 2.5,
      stable_pc_fraction = 0.90,
      steady_state_band_pct = 2.0,
      transient_timeout_s = 3.0
    ),
    detection_methods = list(
      initiator = "threshold_crossing",
      first_flame = "cusum_change_point",
      stable_combustion = "derivative_settling"
    ),
    filtering = list(
      method = "butterworth_lowpass",
      cutoff_hz = 120,
      order = 4
    ),
    reliability = list(
      confidence_level = 0.95,
      bayesian_prior = list(alpha = 1.0, beta = 1.0),
      weibull_method = "mle"
    ),
    validation_hierarchy_level = "L2_SYNTHETIC_VERIFIED"
  )
}

validate_configuration_schema <- function(cfg) {
  required_keys <- c("software_version", "event_thresholds", "filtering", "reliability")
  missing_keys <- setdiff(required_keys, names(cfg))
  if (length(missing_keys) > 0) {
    stop(sprintf("Invalid configuration: Missing required sections: %s", paste(missing_keys, collapse = ", ")))
  }
  cfg$validated_at <- Sys.time()
  cfg$config_hash <- digest_config(cfg)
  cfg
}

digest_config <- function(cfg) {
  # Simple deterministic hash string for provenance
  str_rep <- paste0(names(cfg), collapse = "-")
  paste0("CFG-", toupper(substr(sprintf("%08x", sum(utf8ToInt(str_rep))), 1, 8)))
}

lock_configuration <- function(cfg) {
  # Return immutable environment / list structure
  structure(cfg, class = c("newton_ignition_config", "list"))
}
