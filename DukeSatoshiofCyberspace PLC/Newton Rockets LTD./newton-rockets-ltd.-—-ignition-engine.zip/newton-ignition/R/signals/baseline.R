#' Newton Rockets Ltd. - Baseline Correction & Detrending
#' @description Computes pre-fire atmospheric offsets and zero-reference calibrations.
#' @export

correct_baseline_offset <- function(time_vector, signal_vector, pre_fire_window = c(0.0, 0.45)) {
  idx <- which(time_vector >= pre_fire_window[1] & time_vector <= pre_fire_window[2])
  if (length(idx) == 0) {
    offset_val <- mean(signal_vector[1:min(50, length(signal_vector))], na.rm = TRUE)
  } else {
    offset_val <- stats::median(signal_vector[idx], na.rm = TRUE)
  }
  
  list(
    corrected_signal = signal_vector - offset_val,
    baseline_offset = offset_val,
    pre_fire_window = pre_fire_window
  )
}
