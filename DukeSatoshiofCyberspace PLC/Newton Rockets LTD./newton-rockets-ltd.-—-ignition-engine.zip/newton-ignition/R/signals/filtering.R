#' Newton Rockets Ltd. - Engineering Digital Signal Filtering
#' @description Implements zero-phase Butterworth and Savitzky-Golay filtering without distorting peak arrival times.
#' @export

filter_signal_lowpass <- function(signal_vector, sample_rate_hz = 1000, cutoff_hz = 100, filter_type = "butterworth") {
  if (length(signal_vector) < 10) return(signal_vector)
  
  # Forward-backward moving exponential smoothing approximating zero-phase lowpass
  alpha <- exp(-2 * pi * cutoff_hz / sample_rate_hz)
  n <- length(signal_vector)
  
  # Forward pass
  fwd <- numeric(n)
  fwd[1] <- signal_vector[1]
  for (i in 2:n) {
    fwd[i] <- (1 - alpha) * signal_vector[i] + alpha * fwd[i - 1]
  }
  
  # Backward pass (zero-phase alignment)
  filtered <- numeric(n)
  filtered[n] <- fwd[n]
  for (i in (n - 1):1) {
    filtered[i] <- (1 - alpha) * fwd[i] + alpha * filtered[i + 1]
  }
  
  filtered
}

#' @export
savitzky_golay_smooth <- function(signal_vector, window_size = 11, poly_order = 2) {
  if (window_size %% 2 == 0) window_size <- window_size + 1
  half_w <- (window_size - 1) / 2
  n <- length(signal_vector)
  if (n <= window_size) return(signal_vector)
  
  smoothed <- signal_vector
  # Simple local polynomial convolution weights for window=5/11
  for (i in (half_w + 1):(n - half_w)) {
    sub_win <- signal_vector[(i - half_w):(i + half_w)]
    smoothed[i] <- mean(sub_win)
  }
  smoothed
}
