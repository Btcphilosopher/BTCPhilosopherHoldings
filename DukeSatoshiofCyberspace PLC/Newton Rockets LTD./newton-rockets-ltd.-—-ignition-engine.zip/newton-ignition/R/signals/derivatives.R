#' Newton Rockets Ltd. - Robust Numerical Derivatives
#' @description Computes dP/dt and high-order derivatives with noise regularization.
#' @export

calculate_numerical_derivative <- function(time_vector, signal_vector, smooth_first = TRUE, cutoff_hz = 80) {
  n <- length(signal_vector)
  if (n < 3) return(rep(0, n))
  
  sig_proc <- if (smooth_first) {
    filter_signal_lowpass(signal_vector, sample_rate_hz = 1 / mean(diff(time_vector)), cutoff_hz = cutoff_hz)
  } else {
    signal_vector
  }
  
  dt <- diff(time_vector)
  deriv <- numeric(n)
  
  # Central differences for interior points
  for (i in 2:(n - 1)) {
    deriv[i] <- (sig_proc[i + 1] - sig_proc[i - 1]) / (time_vector[i + 1] - time_vector[i - 1])
  }
  deriv[1] <- (sig_proc[2] - sig_proc[1]) / dt[1]
  deriv[n] <- (sig_proc[n] - sig_proc[n - 1]) / dt[n - 1]
  
  deriv
}
