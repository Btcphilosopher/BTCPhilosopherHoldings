#' Newton Rockets Ltd. - Telemetry Window Segmentation
#' @description Segments full hotfire runs into Pre-Chill, Arming, Ignition Transient, Mainstage, and Post-Purge.
#' @export

segment_ignition_phases <- function(synced_df, events) {
  t <- synced_df$time_s
  
  t_init <- events$IGNITION_INITIATION$time_s
  t_resp <- events$FIRST_DETECTED_RESPONSE$time_s
  t_stable <- events$STABLE_RESPONSE$time_s
  t_end <- events$TEST_END$time_s
  
  list(
    pre_fire = synced_df[t < t_init, ],
    induction_zone = synced_df[t >= t_init & t < t_resp, ],
    pressure_rise = synced_df[t >= t_resp & t < t_stable, ],
    steady_state = synced_df[t >= t_stable & t <= min(t_stable + 1.0, t_end), ],
    shutdown = synced_df[t > min(t_stable + 1.0, t_end), ]
  )
}
