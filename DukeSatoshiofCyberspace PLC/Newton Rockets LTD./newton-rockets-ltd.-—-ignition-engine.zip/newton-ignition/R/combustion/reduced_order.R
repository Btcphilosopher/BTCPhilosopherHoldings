#' Newton Rockets Ltd. - Multi-Zone Ignition Reduced Order Model
#' @description Parametric zero-dimensional transient model for flame kernel kernel growth and volume pressurization.
#' @export

solve_ignition_rom_transient <- function(time_vector, chamber_volume_m3 = 0.012, igniter_energy_j = 85.0) {
  # Physics based state integration
  pc_pred <- evaluate_newton_propulsion_rom(time_vector, list(
    t_ignition = 0.50,
    k_delay = 0.042 * (100 / igniter_energy_j)^0.3,
    tau_rise = 0.025 * (chamber_volume_m3 / 0.010),
    pc_nominal = 65.0,
    c_discharge = 0.985
  ))
  
  data.frame(
    time_s = time_vector,
    pc_predicted_bar = pc_pred,
    flame_volume_fraction = pmin(1.0, pmax(0.0, (pc_pred - 1.0) / 64.0))
  )
}
