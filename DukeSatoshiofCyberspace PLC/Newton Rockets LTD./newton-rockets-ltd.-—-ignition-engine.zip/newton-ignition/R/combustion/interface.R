#' Newton Rockets Ltd. - External Physics Engine Interface
#' @description Facilitates bi-directional coupling with Newton Propulsion C++/Rust/Python numerical kernels.
#' @export

evaluate_newton_propulsion_rom <- function(time_s, params = NULL) {
  p <- params %||% list(
    t_ignition = 0.50,
    k_delay = 0.045,
    tau_rise = 0.028,
    pc_nominal = 65.0,
    c_discharge = 0.985
  )
  
  # Semi-analytical double-exponential S-curve for ignition transient
  # Pc(t) = 0 for t < t_ign + k_delay
  # Pc(t) = Pc_nom * (1 - exp(-(t - (t_ign + k_delay)) / tau_rise))
  
  t_active <- time_s - (p$t_ignition + p$k_delay)
  pc_model <- numeric(length(time_s))
  
  pos_mask <- which(t_active > 0)
  if (length(pos_mask) > 0) {
    # Include small second-order damping overshoot
    t_sub <- t_active[pos_mask]
    pc_model[pos_mask] <- p$pc_nominal * (1 - exp(-t_sub / p$tau_rise) * (cos(35 * t_sub) + 0.15 * sin(35 * t_sub)))
  }
  
  # Atmospheric floor
  pc_model <- pmax(pc_model, 1.013)
  pc_model
}
