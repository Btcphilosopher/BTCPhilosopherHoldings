#' Newton Rockets Ltd. - Thermodynamic State Estimation
#' @description Computes real-time proxy estimates of c* efficiency, oxidizer-to-fuel ratio, and flame temperature.
#' @export

estimate_combustion_state <- function(pc_bar, lox_flow_kg_s, ch4_flow_kg_s, throat_area_m2 = 0.00314) {
  total_flow <- lox_flow_kg_s + ch4_flow_kg_s
  if (total_flow <= 0 || pc_bar <= 1.0) {
    return(list(of_ratio = 0.0, c_star_actual = 0.0, c_star_efficiency = 0.0))
  }
  
  of_ratio <- lox_flow_kg_s / pmax(ch4_flow_kg_s, 1e-4)
  
  # c* = Pc * At / m_dot
  pc_pa <- pc_bar * 1e5
  c_star_actual <- (pc_pa * throat_area_m2) / total_flow
  
  # Theoretical equilibrium c* for LOX/CH4 at MR=2.8 is ~1820 m/s
  c_star_theoretical <- 1820.0
  c_star_efficiency <- c_star_actual / c_star_theoretical
  
  list(
    of_ratio = round(of_ratio, 3),
    c_star_actual_m_s = round(c_star_actual, 1),
    c_star_efficiency = round(c_star_efficiency, 4),
    throat_area_m2 = throat_area_m2
  )
}
