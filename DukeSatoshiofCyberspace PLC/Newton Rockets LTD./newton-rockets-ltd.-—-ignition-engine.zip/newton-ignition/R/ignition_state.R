#' Newton Rockets Ltd. - Ignition Digital Twin State Container
#' @description Encapsulates experimental state, telemetry buffers, physical estimation, and model alignment.
#' @export

IgnitionDigitalTwin <- function(test_id, campaign_id, hardware_revision, initial_config = NULL) {
  env <- new.env(parent = emptyenv())
  env$test_id <- test_id
  env$campaign_id <- campaign_id
  env$hardware_revision <- hardware_revision
  env$config <- if (is.null(initial_config)) get_default_ignition_config() else initial_config
  env$timestamp_current <- 0.0
  
  # Sensor buffers
  env$raw_telemetry <- list()
  env$filtered_telemetry <- list()
  env$events_detected <- list()
  env$derived_metrics <- list()
  
  # Thermodynamic state estimation
  env$estimated_pc_bar <- 0.0
  env$estimated_of_ratio <- 2.45
  env$estimated_c_star_m_s <- 1780.0
  env$acoustic_stability_status <- "STABLE"
  env$validation_status <- "PENDING_RUN"
  env$provenance_log <- list()

  structure(env, class = "IgnitionDigitalTwin")
}

#' @export
update_digital_twin_telemetry <- function(twin, timestamp, sensor_map) {
  stopifnot(inherits(twin, "IgnitionDigitalTwin"))
  twin$timestamp_current <- timestamp
  
  for (s_name in names(sensor_map)) {
    val <- sensor_map[[s_name]]
    if (is.null(twin$raw_telemetry[[s_name]])) {
      twin$raw_telemetry[[s_name]] <- list(t = numeric(0), v = numeric(0))
    }
    twin$raw_telemetry[[s_name]]$t <- c(twin$raw_telemetry[[s_name]]$t, timestamp)
    twin$raw_telemetry[[s_name]]$v <- c(twin$raw_telemetry[[s_name]]$v, val)
  }
  
  # Simple dynamic state estimator
  if (!is.null(sensor_map$chamber_pressure_bar)) {
    twin$estimated_pc_bar <- sensor_map$chamber_pressure_bar
  }
  
  twin
}

#' @export
NewtonPropulsionReference <- function(model_name = "Newton-LPRE-ROM-v3", baseline_pc_bar = 65.0, nominal_delay_ms = 45.0) {
  list(
    model_name = model_name,
    baseline_pc_bar = baseline_pc_bar,
    nominal_delay_ms = nominal_delay_ms,
    parameters = list(
      ignition_delay_const = 0.042,
      combustion_time_const = 0.028,
      discharge_coeff = 0.985,
      cstar_efficiency = 0.965
    ),
    tolerance_band_pct = 5.0,
    created_at = Sys.time()
  )
}
