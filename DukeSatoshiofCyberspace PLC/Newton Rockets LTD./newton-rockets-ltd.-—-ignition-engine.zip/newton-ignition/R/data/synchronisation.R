#' Newton Rockets Ltd. - Telemetry Resampling & Time Synchronization
#' @description Aligns heterogeneous sensor clocks onto a uniform, monotonic timegrid.
#' @export

resample_and_sync_signals <- function(cleaned_obj, target_rate_hz = 1000) {
  df <- cleaned_obj$cleaned_data
  t_vec <- df$time_s
  
  t_start <- min(t_vec, na.rm = TRUE)
  t_end <- max(t_vec, na.rm = TRUE)
  dt <- 1 / target_rate_hz
  
  uniform_time <- seq(from = t_start, to = t_end, by = dt)
  synced_df <- data.frame(time_s = uniform_time)
  
  sensor_cols <- setdiff(names(df), "time_s")
  for (col in sensor_cols) {
    interp_fun <- stats::approxfun(df$time_s, df[[col]], rule = 2, method = "linear")
    synced_df[[col]] <- interp_fun(uniform_time)
  }
  
  list(
    synced_data = synced_df,
    target_rate_hz = target_rate_hz,
    total_samples = length(uniform_time),
    dt_s = dt,
    time_span_s = t_end - t_start
  )
}
