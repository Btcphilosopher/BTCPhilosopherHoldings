#' Newton Rockets Ltd. - Ignition Test Data Schema Specification
#' @description Rigorous schema definition and validator for raw test telemetry and campaign metadata.
#' @export

IGNITION_TEST_REQUIRED_METADATA <- c(
  "test_id",
  "campaign_id",
  "vehicle_or_test_article",
  "configuration_id",
  "hardware_revision",
  "date",
  "operator",
  "instrumentation_revision",
  "software_version",
  "environment",
  "propellant_configuration",
  "test_condition"
)

IGNITION_SIGNAL_REQUIRED_FIELDS <- c(
  "signal_id",
  "timestamp",
  "value",
  "unit",
  "sensor_id",
  "sample_rate",
  "calibration_revision",
  "quality_flag"
)

SUPPORTED_ENGINEERING_UNITS <- list(
  pressure = c("bar", "MPa", "psi", "Pa", "kPa"),
  temperature = c("K", "degC", "C", "degF"),
  mass_flow = c("kg/s", "g/s", "lbm/s"),
  voltage = c("V", "mV"),
  current = c("A", "mA"),
  acceleration = c("g", "m/s2"),
  optical = c("W/sr", "lumens", "counts", "V")
)

#' @export
validate_test_metadata_schema <- function(metadata_list) {
  missing_meta <- setdiff(IGNITION_TEST_REQUIRED_METADATA, names(metadata_list))
  if (length(missing_meta) > 0) {
    return(list(
      valid = FALSE,
      missing_fields = missing_meta,
      error = sprintf("Metadata schema violation: missing [%s]", paste(missing_meta, collapse = ", "))
    ))
  }
  list(valid = TRUE, missing_fields = character(0), error = NULL)
}

#' @export
convert_engineering_units <- function(values, from_unit, to_unit) {
  if (from_unit == to_unit) return(values)
  
  # Explicit conversion matrices - Never silently guess
  if (from_unit == "psi" && to_unit == "bar") return(values * 0.0689475729)
  if (from_unit == "bar" && to_unit == "psi") return(values / 0.0689475729)
  if (from_unit == "MPa" && to_unit == "bar") return(values * 10.0)
  if (from_unit == "bar" && to_unit == "MPa") return(values / 10.0)
  if (from_unit == "Pa" && to_unit == "bar") return(values * 1e-5)
  if (from_unit == "bar" && to_unit == "Pa") return(values * 1e5)
  
  if ((from_unit == "degC" || from_unit == "C") && to_unit == "K") return(values + 273.15)
  if (from_unit == "K" && (to_unit == "degC" || to_unit == "C")) return(values - 273.15)
  
  if (from_unit == "mA" && to_unit == "A") return(values * 0.001)
  if (from_unit == "A" && to_unit == "mA") return(values * 1000.0)
  
  stop(sprintf("Unsupported or hazardous unit conversion request: %s -> %s", from_unit, to_unit))
}
