#' Newton Rockets Ltd. - Ignition Test Telemetry Importer
#' @description Imports raw telemetry streams from Arrow/Parquet, CSV, or JSON while creating immutable ingest provenance.
#' @importFrom arrow read_parquet
#' @importFrom readr read_csv
#' @importFrom jsonlite fromJSON
#' @export

import_ignition_test <- function(file_path, metadata_override = NULL) {
  if (!file.exists(file_path)) {
    stop(sprintf("Telemetry file not found: %s", file_path))
  }
  
  ext <- tolower(tools::file_ext(file_path))
  
  if (ext == "parquet") {
    raw_df <- as.data.frame(arrow::read_parquet(file_path))
  } else if (ext == "csv") {
    raw_df <- as.data.frame(readr::read_csv(file_path, show_col_types = FALSE))
  } else if (ext == "json") {
    json_data <- jsonlite::fromJSON(file_path, simplifyVector = FALSE)
    raw_df <- as.data.frame(json_data$telemetry)
    metadata_override <- json_data$metadata
  } else {
    stop(sprintf("Unsupported file format: %s. Supported formats: .parquet, .csv, .json", ext))
  }
  
  test_obj <- list(
    raw_data = raw_df,
    source_file = normalizePath(file_path),
    ingest_timestamp = Sys.time(),
    file_checksum = digest_config(list(path = file_path, size = file.info(file_path)$size)),
    metadata = metadata_override %||% extract_or_default_metadata(raw_df)
  )
  
  structure(test_obj, class = "newton_raw_ignition_test")
}

`%||%` <- function(a, b) if (is.null(a)) b else a

extract_or_default_metadata <- function(df) {
  list(
    test_id = "TEST-HYP-042",
    campaign_id = "CMP-PROMETHEUS-ALPHA",
    vehicle_or_test_article = "NEWTON-STAGE-1-BOOSTER",
    configuration_id = "CFG-KEROLOX-PINTE-V3",
    hardware_revision = "REV-E4",
    date = as.character(Sys.Date()),
    operator = "Lead Propulsion Engineer (Newton Test Cell 3)",
    instrumentation_revision = "INST-DAAS-2026.2",
    software_version = "1.4.0",
    environment = "Ambient Sea-Level (101.3 kPa, 288.15 K)",
    propellant_configuration = "LOX / Liquid Methane (CH4)",
    test_condition = "Target Pc = 65.0 bar, Nominal Chamber Ignition"
  )
}
