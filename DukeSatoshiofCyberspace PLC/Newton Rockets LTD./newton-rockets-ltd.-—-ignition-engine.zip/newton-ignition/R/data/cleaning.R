#' Newton Rockets Ltd. - Telemetry Cleaning & Non-Destructive Provenance
#' @description Cleans raw telemetry without overwriting original sensors, recording every transformation.
#' @export

clean_telemetry_signals <- function(raw_test_obj, max_spike_z = 4.5) {
  df <- raw_test_obj$raw_data
  clean_df <- data.frame(time_s = df$time %||% df$timestamp %||% df$time_s)
  
  transform_log <- list()
  sensor_cols <- setdiff(names(df), c("time", "timestamp", "time_s", "test_id"))
  
  for (sc in sensor_cols) {
    raw_vals <- df[[sc]]
    
    # Check for NaN / Inf
    clean_vals <- raw_vals
    na_idx <- which(is.na(clean_vals) | is.infinite(clean_vals))
    if (length(na_idx) > 0) {
      # Linear interpolation with recorded trace
      clean_vals[na_idx] <- stats::approx(seq_along(raw_vals), raw_vals, xout = na_idx, rule = 2)$y
      transform_log[[paste0(sc, "_nan_repaired")]] <- list(
        action = "LINEAR_INTERPOLATION_MISSING",
        count = length(na_idx),
        indices = na_idx
      )
    }
    
    # Spike detection via rolling median absolute deviation
    med_val <- stats::median(clean_vals, na.rm = TRUE)
    mad_val <- stats::mad(clean_vals, na.rm = TRUE)
    if (mad_val > 1e-6) {
      z_scores <- abs(clean_vals - med_val) / mad_val
      spike_idx <- which(z_scores > max_spike_z)
      if (length(spike_idx) > 0) {
        clean_vals[spike_idx] <- med_val
        transform_log[[paste0(sc, "_spikes_clamped")]] <- list(
          action = "MAD_SPIKE_CLAMP",
          count = length(spike_idx),
          threshold_z = max_spike_z
        )
      }
    }
    
    # Store both raw and cleaned channels for total auditability
    clean_df[[paste0(sc, "_raw")]] <- raw_vals
    clean_df[[sc]] <- clean_vals
  }
  
  list(
    cleaned_data = clean_df,
    transformations = transform_log,
    cleaned_at = Sys.time()
  )
}
