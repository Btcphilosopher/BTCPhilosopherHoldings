#' Newton Rockets Ltd. - Telemetry Synchronous Replay Stream
#' @description Streams stored high-frequency hotfire test data to live websocket listeners or digital twins.
#' @export

stream_test_telemetry <- function(synced_df, playback_speed = 1.0, callback_fn = print) {
  dt <- synced_df$time_s[2] - synced_df$time_s[1]
  sleep_sec <- dt / playback_speed
  
  for (i in seq_len(nrow(synced_df))) {
    row_data <- as.list(synced_df[i, ])
    callback_fn(row_data)
    # If in interactive mode, sleep
    if (interactive() && sleep_sec > 0.001) {
      Sys.sleep(sleep_sec)
    }
  }
}
