#' Newton Rockets Ltd. - High-Rate Telemetry Binary Schema
#' @description Maps raw binary telemetry packets from Newton Rockets DAAS (Data Acquisition & Analytics System).
#' @export

IGNITION_TELEMETRY_CHANNELS <- list(
  time_s = list(unit = "s", rate_hz = 1000, type = "float64"),
  chamber_pressure_bar = list(unit = "bar", rate_hz = 1000, type = "float32", min = 0, max = 150),
  lox_manifold_pressure_bar = list(unit = "bar", rate_hz = 1000, type = "float32", min = 0, max = 150),
  ch4_manifold_pressure_bar = list(unit = "bar", rate_hz = 1000, type = "float32", min = 0, max = 150),
  igniter_current_a = list(unit = "A", rate_hz = 5000, type = "float32", min = 0, max = 10),
  igniter_voltage_v = list(unit = "V", rate_hz = 5000, type = "float32", min = 0, max = 500),
  optical_flame_v = list(unit = "V", rate_hz = 5000, type = "float32", min = 0, max = 5),
  accelerometer_z_g = list(unit = "g", rate_hz = 10000, type = "float32", min = -100, max = 100),
  lox_inlet_temp_k = list(unit = "K", rate_hz = 100, type = "float32", min = 50, max = 350),
  ch4_inlet_temp_k = list(unit = "K", rate_hz = 100, type = "float32", min = 50, max = 350)
)
