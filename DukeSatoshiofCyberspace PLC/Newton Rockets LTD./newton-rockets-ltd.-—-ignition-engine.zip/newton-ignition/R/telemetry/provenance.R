#' Newton Rockets Ltd. - End-to-End Cryptographic & Data Lineage Provenance
#' @description Attaches cryptographic hashes, transformation records, and algorithm versions to every result.
#' @export

add_provenance_step <- function(existing_provenance = list(), step_name, operation, parameters, inputs_hash) {
  step_entry <- list(
    step_id = length(existing_provenance) + 1,
    step_name = step_name,
    operation = operation,
    parameters = parameters,
    inputs_hash = inputs_hash,
    software_version = "1.4.0",
    timestamp = Sys.time()
  )
  
  c(existing_provenance, list(step_entry))
}
