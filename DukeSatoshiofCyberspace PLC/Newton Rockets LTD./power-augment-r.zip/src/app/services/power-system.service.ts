import { Injectable, signal, computed, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import {
  SystemParameters,
  createDefaultParameters,
  LoadItem,
  createDefaultLoads,
  SimulationResult,
  runFullSimulation,
  TelemetryPoint,
  AugmentationStrategy
} from '../core/physics-engine';
import { PowerEnvelopePoint, calculatePowerEnvelope } from '../core/power-envelope-engine';
import { MonteCarloResult, runMonteCarlo } from '../core/monte-carlo-engine';
import { SensitivityResult, runSensitivityAnalysis } from '../core/sensitivity-engine';
import { OptimizationResult, runParetoOptimization } from '../core/optimization-engine';
import { DigitalTwinFrame, DigitalTwinPipeline, InjectedFaults } from '../core/digital-twin-engine';
import { MissionScenario, getMissionScenarios } from '../core/scenarios-data';

export type ConsoleTab =
  | 'OVERVIEW'
  | 'POWER_FLOW'
  | 'GENERATION'
  | 'AUGMENTATION'
  | 'BUS'
  | 'STORAGE'
  | 'THERMAL'
  | 'LOADS'
  | 'ENVELOPE'
  | 'DIGITAL_TWIN'
  | 'FAULT_INJECTION'
  | 'MONTE_CARLO'
  | 'SENSITIVITY'
  | 'OPTIMISATION'
  | 'SCENARIOS'
  | 'TELEMETRY'
  | 'VALIDATION'
  | 'REPORTS'
  | 'R_PACKAGE';

@Injectable({
  providedIn: 'root'
})
export class PowerSystemService {
  private http = inject(HttpClient);
  private digitalTwin = new DigitalTwinPipeline();

  // Reactive State Signals
  readonly activeTab = signal<ConsoleTab>('OVERVIEW');
  readonly params = signal<SystemParameters>(createDefaultParameters());
  readonly loads = signal<LoadItem[]>(createDefaultLoads());
  readonly activeScenarioId = signal<string>('POWER_BOOST');
  readonly simDuration = signal<number>(600);
  readonly simTimestep = signal<number>(0.5);
  readonly simMethod = signal<'Euler' | 'RK2' | 'RK4'>('RK4');
  readonly boostMode = signal<boolean>(true);

  // Simulation & Analysis Results
  readonly simResult = signal<SimulationResult | null>(null);
  readonly envelopeData = signal<PowerEnvelopePoint[]>([]);
  readonly monteCarloResult = signal<MonteCarloResult | null>(null);
  readonly sensitivityResult = signal<SensitivityResult | null>(null);
  readonly optimizationResult = signal<OptimizationResult | null>(null);

  // Digital Twin & Telemetry Scrubbing
  readonly digitalTwinHistory = signal<DigitalTwinFrame[]>([]);
  readonly activeFaults = signal<InjectedFaults>({});
  readonly playbackIndex = signal<number>(0);
  readonly isPlaying = signal<boolean>(false);
  private playTimer: ReturnType<typeof setInterval> | null = null;

  // R Package Explorer State
  readonly rPackageFiles = signal<string[]>([]);
  readonly selectedRFile = signal<{ path: string; content: string } | null>(null);

  // Scenarios list
  readonly scenarios = signal<MissionScenario[]>(getMissionScenarios());

  // Convergence Validation Results
  readonly convergenceData = signal<{ dt: number; finalTemp: number; finalEnergyResidual: number; runtimeMs: number }[]>([]);

  // Computed Key Summary Metrics
  readonly latestTelemetry = computed<TelemetryPoint | null>(() => {
    const res = this.simResult();
    if (!res || !res.telemetry.length) return null;
    const idx = Math.min(this.playbackIndex(), res.telemetry.length - 1);
    return res.telemetry[idx];
  });

  readonly summaryMetrics = computed(() => {
    const res = this.simResult();
    const tel = this.latestTelemetry();
    if (!res || !tel) {
      return {
        baselinePowerMw: 1.80,
        augmentedGenMw: 2.40,
        grossIncreaseMw: 0.60,
        convLossMw: 0.09,
        busLossMw: 0.03,
        netAddPowerMw: 0.48,
        peakAvailMw: 2.95,
        sustainableMw: 2.28,
        storageContribMw: 0.55,
        thermalMarginPct: 17.4,
        systemEfficiencyPct: 88.6,
        powerGainPct: 26.7,
        powerMarginKw: 120.5,
        finalSoc: 0.74,
        isEnergyConserved: true,
        maxResidualMj: 0.000012
      };
    }

    const baseMw = tel.p_baseline / 1e6;
    const genGrossMw = tel.p_gen_gross / 1e6;
    const grossIncMw = genGrossMw - baseMw;
    const convLossMw = tel.p_conv_loss / 1e6;
    const busLossMw = tel.p_bus_loss / 1e6;
    const netAddMw = tel.delta_p / 1e6;
    const peakMw = res.summary.peak_usable_power_mw;
    const sustMw = res.summary.avg_usable_power_mw;
    const storMw = tel.p_stor_disch / 1e6;
    const thmPct = tel.thermal_margin * 100.0;
    const effPct = tel.eff_system * 100.0;
    const gainPct = tel.p_gain_pct;
    const marginKw = tel.p_margin / 1e3;

    return {
      baselinePowerMw: baseMw,
      augmentedGenMw: genGrossMw,
      grossIncreaseMw: grossIncMw,
      convLossMw: convLossMw,
      busLossMw: busLossMw,
      netAddPowerMw: netAddMw,
      peakAvailMw: peakMw,
      sustainableMw: sustMw,
      storageContribMw: storMw,
      thermalMarginPct: thmPct,
      systemEfficiencyPct: effPct,
      powerGainPct: gainPct,
      powerMarginKw: marginKw,
      finalSoc: tel.soc,
      isEnergyConserved: res.summary.is_energy_conserved,
      maxResidualMj: res.summary.max_energy_residual_mj
    };
  });

  constructor() {
    this.runFullSystemSimulation();
    this.computeEnvelope();
    this.loadRPackageFiles();
  }

  setTab(tab: ConsoleTab) {
    this.activeTab.set(tab);
    if (tab === 'ENVELOPE' && this.envelopeData().length === 0) {
      this.computeEnvelope();
    } else if (tab === 'MONTE_CARLO' && !this.monteCarloResult()) {
      this.runMonteCarlo();
    } else if (tab === 'SENSITIVITY' && !this.sensitivityResult()) {
      this.runSensitivity();
    } else if (tab === 'OPTIMISATION' && !this.optimizationResult()) {
      this.runOptimization();
    }
  }

  setStrategy(strategy: AugmentationStrategy) {
    this.params.update((p) => ({ ...p, strategy }));
    this.runFullSystemSimulation();
  }

  setScenario(scenarioId: string) {
    const sc = this.scenarios().find((s) => s.id === scenarioId);
    if (!sc) return;
    this.activeScenarioId.set(scenarioId);
    this.params.set(JSON.parse(JSON.stringify(sc.params)));
    this.simDuration.set(sc.duration);
    this.simTimestep.set(sc.dt);
    this.boostMode.set(sc.boost_mode);
    this.runFullSystemSimulation();
    this.computeEnvelope();
  }

  toggleLoad(loadId: string) {
    this.loads.update((arr) =>
      arr.map((l) => (l.id === loadId ? { ...l, active: !l.active } : l))
    );
    this.runFullSystemSimulation();
  }

  updateLoadPower(loadId: string, nominalPowerW: number) {
    this.loads.update((arr) =>
      arr.map((l) => (l.id === loadId ? { ...l, nominal_power: nominalPowerW } : l))
    );
    this.runFullSystemSimulation();
  }

  toggleFault(faultKey: keyof InjectedFaults, val?: unknown) {
    this.activeFaults.update((f) => {
      const updated = { ...f };
      if (val !== undefined) {
        (updated as Record<keyof InjectedFaults, unknown>)[faultKey] = val;
      } else {
        (updated as Record<keyof InjectedFaults, unknown>)[faultKey] = !(updated as Record<keyof InjectedFaults, unknown>)[faultKey];
      }
      return updated;
    });

    // Re-step digital twin with updated faults
    this.recomputeDigitalTwin();
  }

  runFullSystemSimulation() {
    const res = runFullSimulation(
      this.params(),
      this.simDuration(),
      this.simTimestep(),
      this.simMethod(),
      this.loads(),
      this.boostMode()
    );

    this.simResult.set(res);
    this.playbackIndex.set(0);
    this.recomputeDigitalTwin();
  }

  computeEnvelope() {
    const env = calculatePowerEnvelope(this.params());
    this.envelopeData.set(env);
  }

  runMonteCarlo(n = 300) {
    const mc = runMonteCarlo(this.params(), n);
    this.monteCarloResult.set(mc);
  }

  runSensitivity(perturbation = 0.10) {
    const sens = runSensitivityAnalysis(this.params(), perturbation);
    this.sensitivityResult.set(sens);
  }

  runOptimization(gridPoints = 5) {
    const opt = runParetoOptimization(this.params(), gridPoints);
    this.optimizationResult.set(opt);
  }

  runTimestepConvergenceTest() {
    const dts = [2.0, 1.0, 0.5, 0.25, 0.125];
    const results: { dt: number; finalTemp: number; finalEnergyResidual: number; runtimeMs: number }[] = [];

    for (const step of dts) {
      const t0 = performance.now();
      const res = runFullSimulation(this.params(), 300, step, 'RK4', this.loads(), this.boostMode());
      const runtime = performance.now() - t0;
      const lastPt = res.telemetry[res.telemetry.length - 1];
      results.push({
        dt: step,
        finalTemp: lastPt.t_generator,
        finalEnergyResidual: res.summary.max_energy_residual_mj,
        runtimeMs: Math.round(runtime * 10) / 10
      });
    }

    this.convergenceData.set(results);
  }

  private recomputeDigitalTwin() {
    const res = this.simResult();
    if (!res) return;
    const pipeline = new DigitalTwinPipeline();
    const faults = this.activeFaults();
    const frames: DigitalTwinFrame[] = [];

    for (let i = 0; i < res.telemetry.length; i += Math.max(1, Math.floor(res.telemetry.length / 120))) {
      const frame = pipeline.step(res.telemetry[i], faults);
      frames.push(frame);
    }
    this.digitalTwinHistory.set(frames);
  }

  // Playback controls for Telemetry Scrubber
  togglePlayback() {
    if (this.isPlaying()) {
      this.pausePlayback();
    } else {
      this.startPlayback();
    }
  }

  startPlayback() {
    const res = this.simResult();
    if (!res) return;
    this.isPlaying.set(true);
    if (this.playTimer) clearInterval(this.playTimer);

    this.playTimer = setInterval(() => {
      const current = this.playbackIndex();
      const maxIdx = res.telemetry.length - 1;
      if (current >= maxIdx) {
        this.playbackIndex.set(0);
      } else {
        this.playbackIndex.set(current + 1);
      }
    }, 50);
  }

  pausePlayback() {
    this.isPlaying.set(false);
    if (this.playTimer) {
      clearInterval(this.playTimer);
      this.playTimer = null;
    }
  }

  seekPlayback(index: number) {
    this.playbackIndex.set(index);
  }

  // R Package Repository Browser
  loadRPackageFiles() {
    const defaultFiles = [
      'DESCRIPTION',
      'NAMESPACE',
      'README.md',
      'R/constants.R',
      'R/units.R',
      'R/state.R',
      'R/generation.R',
      'R/augmentation.R',
      'R/storage.R',
      'R/converter.R',
      'R/power_bus.R',
      'R/loads.R',
      'R/thermal.R',
      'R/losses.R',
      'R/solver.R',
      'R/simulation.R',
      'R/constraints.R',
      'R/envelope.R',
      'R/monte_carlo.R',
      'R/sensitivity.R',
      'R/optimisation.R',
      'R/statistics.R',
      'R/digital_twin.R',
      'R/diagnostics.R',
      'R/fault_injection.R',
      'R/telemetry.R',
      'R/scenarios.R',
      'R/reporting.R',
      'R/cli.R',
      'tests/testthat/test_conservation.R',
      'tests/testthat/test_power_balance.R',
      'tests/testthat/test_numerical.R',
      'analysis/baseline.R',
      'inst/config/default_system.json'
    ];
    this.rPackageFiles.set(defaultFiles);
    this.fetchRFile('R/simulation.R');
  }

  fetchRFile(path: string) {
    this.http.get<{ path: string; content: string }>(`/api/r-package/file?path=${encodeURIComponent(path)}`).subscribe({
      next: (data) => this.selectedRFile.set(data),
      error: () => {
        // Fallback demo content if server SSR or client-side
        this.selectedRFile.set({
          path,
          content: `# Selected file: ${path}\n# power-augment-r R engineering package\n# Run 'Rscript R/cli.R simulate' to execute.`
        });
      }
    });
  }

  downloadTelemetryCSV() {
    const res = this.simResult();
    if (!res) return;
    const headers = Object.keys(res.telemetry[0]).join(',');
    const rows = res.telemetry.map((pt) => Object.values(pt).join(',')).join('\n');
    const blob = new Blob([`${headers}\n${rows}`], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `power_augment_telemetry_${Date.now()}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  }

  downloadTelemetryJSON() {
    const res = this.simResult();
    if (!res) return;
    const blob = new Blob([JSON.stringify(res, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `power_augment_sim_${Date.now()}.json`;
    a.click();
    URL.revokeObjectURL(url);
  }
}
