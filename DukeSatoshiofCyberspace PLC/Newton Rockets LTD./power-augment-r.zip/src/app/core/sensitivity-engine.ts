import { SystemParameters, createDefaultParameters } from './physics-engine';

export interface TornadoItem {
  param_id: string;
  param_name: string;
  unit: string;
  nominal_val: number;
  low_val: number;
  high_val: number;
  power_low_mw: number;
  power_high_mw: number;
  power_swing_mw: number;
  power_elasticity: number;
  thermal_low_pct: number;
  thermal_high_pct: number;
  thermal_swing_pct: number;
}

export interface SensitivityResult {
  base_usable_power_mw: number;
  base_thermal_margin_pct: number;
  tornado: TornadoItem[];
}

export function runSensitivityAnalysis(
  baseParams: SystemParameters = createDefaultParameters(),
  perturbationFraction = 0.10
): SensitivityResult {
  const evalModel = (p: SystemParameters) => {
    const p_gen = p.generation.augmented_power.val * p.generation.health.val * p.generation.efficiency_0.val;
    const p_conv = p_gen * p.converter.efficiency_nominal.val;
    const p_stor = p.storage.max_discharge_power.val * p.storage.health.val;
    const i_bus = 2.0e6 / p.bus.voltage_nominal.val;
    const p_bus_loss = i_bus * i_bus * p.bus.resistance.val;
    const p_usable = p_conv + p_stor - p_bus_loss;

    const sigma = 5.670374419e-8;
    const q_rad = p.thermal.emissivity.val * sigma * p.thermal.radiator_area.val * (Math.pow(345.0, 4) - Math.pow(p.thermal.t_ambient_sink.val, 4));
    const p_loss_tot = (p.generation.augmented_power.val - p_gen) + (p_gen - p_conv) + p_bus_loss;
    const thermal_margin_pct = Math.max(0, (100.0 * (q_rad - p_loss_tot)) / q_rad);

    return {
      usable_power_mw: p_usable / 1e6,
      thermal_margin_pct
    };
  };

  const baseEval = evalModel(baseParams);

  const targets: {
    id: string;
    name: string;
    unit: string;
    get: (p: SystemParameters) => number;
    set: (p: SystemParameters, v: number) => void;
  }[] = [
    { id: 'eta_gen', name: 'Generator Efficiency (η_gen)', unit: 'ratio', get: (p) => p.generation.efficiency_0.val, set: (p, v) => (p.generation.efficiency_0.val = v) },
    { id: 'eta_conv', name: 'Converter Efficiency (η_conv)', unit: 'ratio', get: (p) => p.converter.efficiency_nominal.val, set: (p, v) => (p.converter.efficiency_nominal.val = v) },
    { id: 'v_bus', name: 'Bus Nominal Voltage (V_bus)', unit: 'V', get: (p) => p.bus.voltage_nominal.val, set: (p, v) => (p.bus.voltage_nominal.val = v) },
    { id: 'r_bus', name: 'Bus Resistance (R_bus)', unit: 'Ω', get: (p) => p.bus.resistance.val, set: (p, v) => (p.bus.resistance.val = v) },
    { id: 'stor_power', name: 'Storage Discharge Power (P_stor)', unit: 'W', get: (p) => p.storage.max_discharge_power.val, set: (p, v) => (p.storage.max_discharge_power.val = v) },
    { id: 'rad_area', name: 'Radiator Surface Area (A_rad)', unit: 'm²', get: (p) => p.thermal.radiator_area.val, set: (p, v) => (p.thermal.radiator_area.val = v) },
    { id: 'emissivity', name: 'Radiator Emissivity (ε)', unit: 'ratio', get: (p) => p.thermal.emissivity.val, set: (p, v) => (p.thermal.emissivity.val = v) },
    { id: 't_ambient', name: 'Ambient Sink Temp (T_env)', unit: 'K', get: (p) => p.thermal.t_ambient_sink.val, set: (p, v) => (p.thermal.t_ambient_sink.val = v) }
  ];

  const tornado: TornadoItem[] = targets.map((t) => {
    const nominal = t.get(baseParams);

    const cloneLow = JSON.parse(JSON.stringify(baseParams)) as SystemParameters;
    t.set(cloneLow, nominal * (1.0 - perturbationFraction));
    const evalLow = evalModel(cloneLow);

    const cloneHigh = JSON.parse(JSON.stringify(baseParams)) as SystemParameters;
    t.set(cloneHigh, nominal * (1.0 + perturbationFraction));
    const evalHigh = evalModel(cloneHigh);

    const deltaY = evalHigh.usable_power_mw - evalLow.usable_power_mw;
    const elasticity = (deltaY / baseEval.usable_power_mw) / (2 * perturbationFraction);

    return {
      param_id: t.id,
      param_name: t.name,
      unit: t.unit,
      nominal_val: nominal,
      low_val: nominal * (1 - perturbationFraction),
      high_val: nominal * (1 + perturbationFraction),
      power_low_mw: evalLow.usable_power_mw,
      power_high_mw: evalHigh.usable_power_mw,
      power_swing_mw: Math.abs(evalHigh.usable_power_mw - evalLow.usable_power_mw),
      power_elasticity: elasticity,
      thermal_low_pct: evalLow.thermal_margin_pct,
      thermal_high_pct: evalHigh.thermal_margin_pct,
      thermal_swing_pct: Math.abs(evalHigh.thermal_margin_pct - evalLow.thermal_margin_pct)
    };
  });

  tornado.sort((a, b) => b.power_swing_mw - a.power_swing_mw);

  return {
    base_usable_power_mw: baseEval.usable_power_mw,
    base_thermal_margin_pct: baseEval.thermal_margin_pct,
    tornado
  };
}
