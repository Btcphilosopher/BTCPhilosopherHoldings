import { SystemParameters, createDefaultParameters } from './physics-engine';

export interface PowerEnvelopePoint {
  duration_s: number;
  duration_label: string;
  baseline_power_mw: number;
  sustainable_power_mw: number;
  storage_limited_power_mw: number;
  thermal_limited_power_mw: number;
  converter_limited_power_mw: number;
  bus_limited_power_mw: number;
  peak_power_mw: number;
  max_achievable_power_mw: number;
  limiting_subsystem: string;
  power_gain_percent: number;
}

export function calculatePowerEnvelope(
  params: SystemParameters = createDefaultParameters(),
  durations: number[] = [10, 30, 60, 120, 300, 600, 1200, 1800, 3600]
): PowerEnvelopePoint[] {
  const p_base = params.generation.baseline_power.val;
  const p_gen_aug = params.generation.augmented_power.val * params.generation.health.val;
  const eta_gen = params.generation.efficiency_0.val;
  const eta_conv = params.converter.efficiency_nominal.val;

  // Sustainable generation reaching bus
  const p_gen_sustainable_bus = p_gen_aug * eta_gen * eta_conv;

  // Hardware constraints
  const p_conv_max = params.converter.max_power_rating.val * eta_conv;
  const v_bus = params.bus.voltage_nominal.val;
  const i_max = params.bus.current_max.val;
  const r_bus = params.bus.resistance.val;
  const p_bus_max = v_bus * i_max - i_max * i_max * r_bus;

  const stor_cap_j =
    params.storage.capacity_total_j.val *
    (params.storage.soc_initial.val - params.storage.soc_min.val) *
    params.storage.health.val;
  const p_stor_disch_max = params.storage.max_discharge_power.val * params.storage.health.val;

  // Steady-state thermal radiator capacity
  const sigma = 5.670374419e-8;
  const a_rad = params.thermal.radiator_area.val;
  const eps = params.thermal.emissivity.val;
  const t_env = params.thermal.t_ambient_sink.val;
  const t_rad_max = 350.0; // K
  const q_rad_max = eps * sigma * a_rad * (Math.pow(t_rad_max, 4) - Math.pow(t_env, 4));

  const eta_sys_est = eta_gen * eta_conv * 0.98;
  const p_thermal_steady_limit = q_rad_max / ((1.0 - eta_sys_est) / eta_sys_est);

  const c_th_total =
    params.generation.thermal_mass.val +
    params.converter.thermal_mass.val +
    params.storage.thermal_mass.val;

  return durations.map((dur) => {
    const p_stor_energy_limit = stor_cap_j / dur;
    const p_stor_contrib = Math.min(p_stor_disch_max, p_stor_energy_limit);
    const p_peak_gross = p_gen_sustainable_bus + p_stor_contrib;

    // Transient heat sink absorption
    const delta_t_allowable = 25.0; // K allowable rise
    const e_absorb_j = c_th_total * delta_t_allowable;
    const p_thermal_transient = e_absorb_j / dur;
    const p_thermal_limit = p_thermal_steady_limit + p_thermal_transient;

    const p_conv_limit = p_conv_max;
    const p_bus_limit = p_bus_max;

    const candidates = [
      { name: 'Storage Energy Rating', val: p_peak_gross },
      { name: 'Radiator & Thermal Capacity', val: p_thermal_limit },
      { name: 'DC-DC Converter Rating', val: p_conv_limit },
      { name: 'DC Distribution Bus Ampacity', val: p_bus_limit }
    ];

    candidates.sort((a, b) => a.val - b.val);
    const limiting = candidates[0].name;
    const p_achievable = candidates[0].val;

    const label = dur < 60 ? `${dur}s` : dur < 3600 ? `${dur / 60}m` : `${dur / 3600}h`;

    return {
      duration_s: dur,
      duration_label: label,
      baseline_power_mw: p_base / 1e6,
      sustainable_power_mw: Math.min(p_gen_sustainable_bus, p_thermal_steady_limit) / 1e6,
      storage_limited_power_mw: (p_gen_sustainable_bus + p_stor_contrib) / 1e6,
      thermal_limited_power_mw: p_thermal_limit / 1e6,
      converter_limited_power_mw: p_conv_limit / 1e6,
      bus_limited_power_mw: p_bus_limit / 1e6,
      peak_power_mw: p_peak_gross / 1e6,
      max_achievable_power_mw: p_achievable / 1e6,
      limiting_subsystem: limiting,
      power_gain_percent: (100.0 * (p_achievable - p_base)) / p_base
    };
  });
}
