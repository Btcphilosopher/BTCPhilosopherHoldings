// ==============================================================================
// POWER-AUGMENT-R: Core Aerospace Electrical & Thermal Physics Engine
// Exact parity with R package equations & conservation principles
// ==============================================================================

export interface ParameterItem<T = number> {
  val: T;
  unit: string;
  desc: string;
  prov: string;
  min?: number;
  max?: number;
}

export interface GenerationParams {
  baseline_power: ParameterItem;
  augmented_power: ParameterItem;
  voltage_gen: ParameterItem;
  efficiency_0: ParameterItem;
  temp_coefficient: ParameterItem;
  t_ref: ParameterItem;
  thermal_mass: ParameterItem;
  t_max: ParameterItem;
  health: ParameterItem;
}

export interface ConverterParams {
  efficiency_nominal: ParameterItem;
  voltage_out: ParameterItem;
  max_power_rating: ParameterItem;
  switching_loss_factor: ParameterItem;
  thermal_mass: ParameterItem;
  t_max: ParameterItem;
}

export interface BusParams {
  voltage_nominal: ParameterItem;
  resistance: ParameterItem;
  capacitance: ParameterItem;
  current_max: ParameterItem;
  thermal_mass: ParameterItem;
  t_max: ParameterItem;
}

export interface StorageParams {
  capacity_total_j: ParameterItem;
  soc_initial: ParameterItem;
  soc_min: ParameterItem;
  soc_max: ParameterItem;
  max_discharge_power: ParameterItem;
  max_charge_power: ParameterItem;
  internal_resistance: ParameterItem;
  roundtrip_efficiency: ParameterItem;
  thermal_mass: ParameterItem;
  t_max: ParameterItem;
  health: ParameterItem;
}

export interface ThermalParams {
  radiator_area: ParameterItem;
  emissivity: ParameterItem;
  t_ambient_sink: ParameterItem;
  thermal_conductivity_matrix: {
    gen_to_rad: number;
    conv_to_rad: number;
    bus_to_rad: number;
    stor_to_rad: number;
  };
  t_initial: {
    generator: number;
    converter: number;
    bus: number;
    storage: number;
    radiator: number;
  };
}

export type AugmentationStrategy =
  | 'GENERATION_ONLY'
  | 'STORAGE_ONLY'
  | 'GENERATION_PLUS_STORAGE'
  | 'STORAGE_PEAK_SHAVING'
  | 'CONSTANT_POWER'
  | 'THERMAL_LIMITED'
  | 'STORAGE_LIFE_LIMITED';

export interface SystemParameters {
  generation: GenerationParams;
  converter: ConverterParams;
  bus: BusParams;
  storage: StorageParams;
  thermal: ThermalParams;
  strategy: AugmentationStrategy;
}

export interface LoadItem {
  id: string;
  name: string;
  nominal_power: number;
  min_power: number;
  max_power: number;
  priority: number;
  duty_cycle: number;
  temp_sensitivity: number;
  active: boolean;
}

export interface TelemetryPoint {
  time: number;
  p_baseline: number;
  p_gen_gross: number;
  p_gen_elec: number;
  p_gen_loss: number;
  p_conv_in: number;
  p_conv_out: number;
  p_conv_loss: number;
  p_stor_disch: number;
  p_stor_charge: number;
  p_stor_loss: number;
  p_bus_in: number;
  p_bus_loss: number;
  p_demand: number;
  p_usable: number;
  p_served: number;
  p_margin: number;
  delta_p: number;
  p_gain_pct: number;
  v_bus: number;
  i_bus: number;
  soc: number;
  t_generator: number;
  t_converter: number;
  t_bus: number;
  t_storage: number;
  t_radiator: number;
  thermal_margin: number;
  q_rad: number;
  eff_system: number;
  energy_residual_mj: number;
  cum_e_source_mj: number;
  cum_e_delivered_mj: number;
  cum_e_stored_mj: number;
  cum_e_losses_mj: number;
  cum_e_dissipated_mj: number;
}

export interface SimulationResult {
  telemetry: TelemetryPoint[];
  summary: {
    duration: number;
    dt: number;
    method: string;
    strategy: AugmentationStrategy;
    baseline_power_mw: number;
    avg_usable_power_mw: number;
    peak_usable_power_mw: number;
    min_power_margin_kw: number;
    final_soc: number;
    max_temp_k: number;
    min_thermal_margin_pct: number;
    total_energy_delivered_mj: number;
    total_energy_losses_mj: number;
    max_energy_residual_mj: number;
    is_energy_conserved: boolean;
  };
}

export function createDefaultParameters(): SystemParameters {
  return {
    generation: {
      baseline_power: { val: 1.8e6, unit: 'W', desc: 'Baseline nuclear/solar power', prov: 'QUALIFIED_BASELINE', min: 0.5e6, max: 5e6 },
      augmented_power: { val: 2.4e6, unit: 'W', desc: 'Augmented reactor/boost power', prov: 'MEASURED_TEST', min: 0.5e6, max: 10e6 },
      voltage_gen: { val: 1200.0, unit: 'V', desc: 'Generator output voltage', prov: 'DESIGN_SPEC', min: 200, max: 5000 },
      efficiency_0: { val: 0.94, unit: 'ratio', desc: 'Nominal generator conversion efficiency', prov: 'MEASURED_TEST', min: 0.70, max: 0.99 },
      temp_coefficient: { val: 0.0008, unit: '1/K', desc: 'Thermal derating coefficient gamma', prov: 'EMPIRICAL_FIT', min: 0.0001, max: 0.003 },
      t_ref: { val: 300.0, unit: 'K', desc: 'Reference temperature for efficiency', prov: 'STANDARD', min: 200, max: 500 },
      thermal_mass: { val: 85000.0, unit: 'J/K', desc: 'Generator heat capacity C_th', prov: 'ESTIMATED_CAD', min: 1e4, max: 1e6 },
      t_max: { val: 480.0, unit: 'K', desc: 'Maximum allowable generator temp', prov: 'HARD_LIMIT', min: 350, max: 800 },
      health: { val: 1.0, unit: 'ratio', desc: 'Health/degradation factor [0,1]', prov: 'ESTIMATED_OBSERVER', min: 0.0, max: 1.0 }
    },
    converter: {
      efficiency_nominal: { val: 0.965, unit: 'ratio', desc: 'DC-DC power converter efficiency', prov: 'QUALIFIED_BENCH', min: 0.80, max: 0.995 },
      voltage_out: { val: 300.0, unit: 'V', desc: 'Regulated bus output voltage', prov: 'DESIGN_SPEC', min: 28, max: 1000 },
      max_power_rating: { val: 3.5e6, unit: 'W', desc: 'Peak power throughput limit', prov: 'HARD_LIMIT', min: 1e6, max: 10e6 },
      switching_loss_factor: { val: 0.015, unit: 'ratio', desc: 'Frequency-dependent switching loss fraction', prov: 'EMPIRICAL_FIT', min: 0.005, max: 0.05 },
      thermal_mass: { val: 35000.0, unit: 'J/K', desc: 'Converter thermal mass C_th', prov: 'ESTIMATED_CAD', min: 5e3, max: 5e5 },
      t_max: { val: 395.0, unit: 'K', desc: 'Maximum allowable silicon-carbide junction temp', prov: 'HARD_LIMIT', min: 320, max: 450 }
    },
    bus: {
      voltage_nominal: { val: 300.0, unit: 'V', desc: 'Nominal DC bus rail voltage', prov: 'DESIGN_SPEC', min: 28, max: 1000 },
      resistance: { val: 0.0028, unit: 'Ohm', desc: 'Total distribution bus resistance R_bus', prov: 'MEASURED_HARNESS', min: 0.0005, max: 0.05 },
      capacitance: { val: 0.085, unit: 'F', desc: 'Bus filter capacitance', prov: 'COMPONENT_SPEC', min: 0.01, max: 1.0 },
      current_max: { val: 12000.0, unit: 'A', desc: 'Bus harness ampacity limit', prov: 'HARD_LIMIT', min: 1000, max: 25000 },
      thermal_mass: { val: 25000.0, unit: 'J/K', desc: 'Bus bar thermal capacitance C_th', prov: 'ESTIMATED_CAD', min: 5e3, max: 2e5 },
      t_max: { val: 370.0, unit: 'K', desc: 'Maximum allowable bus insulation temp', prov: 'HARD_LIMIT', min: 300, max: 420 }
    },
    storage: {
      capacity_total_j: { val: 1800e6, unit: 'J', desc: 'Total usable energy capacity (500 kWh = 1800 MJ)', prov: 'CELL_SPEC', min: 100e6, max: 10000e6 },
      soc_initial: { val: 0.90, unit: 'ratio', desc: 'Initial State of Charge', prov: 'MEASURED_TELEMETRY', min: 0.05, max: 1.0 },
      soc_min: { val: 0.15, unit: 'ratio', desc: 'Minimum safe depth of discharge', prov: 'SAFETY_LIMIT', min: 0.05, max: 0.30 },
      soc_max: { val: 0.98, unit: 'ratio', desc: 'Maximum charge cutoff', prov: 'SAFETY_LIMIT', min: 0.85, max: 1.0 },
      max_discharge_power: { val: 1.2e6, unit: 'W', desc: 'Peak discharge power rating (1.2 MW)', prov: 'CELL_LIMIT', min: 0.1e6, max: 5e6 },
      max_charge_power: { val: 0.6e6, unit: 'W', desc: 'Peak charge power rating (0.6 MW)', prov: 'CELL_LIMIT', min: 0.05e6, max: 3e6 },
      internal_resistance: { val: 0.0035, unit: 'Ohm', desc: 'ESR internal resistance', prov: 'MEASURED_EIS', min: 0.0005, max: 0.02 },
      roundtrip_efficiency: { val: 0.93, unit: 'ratio', desc: 'Coulombic/roundtrip charge efficiency', prov: 'QUALIFIED_BENCH', min: 0.80, max: 0.98 },
      thermal_mass: { val: 120000.0, unit: 'J/K', desc: 'Storage module thermal mass C_th', prov: 'ESTIMATED_CAD', min: 2e4, max: 1e6 },
      t_max: { val: 335.0, unit: 'K', desc: 'Maximum allowable electrochemical temp (61.85 C)', prov: 'HARD_LIMIT', min: 300, max: 360 },
      health: { val: 0.98, unit: 'ratio', desc: 'Capacity retention health factor', prov: 'ESTIMATED_OBSERVER', min: 0.4, max: 1.0 }
    },
    thermal: {
      radiator_area: { val: 65.0, unit: 'm^2', desc: 'Effective radiator surface area', prov: 'DESIGN_SPEC', min: 10, max: 300 },
      emissivity: { val: 0.91, unit: 'ratio', desc: 'Radiator infrared emissivity epsilon', prov: 'MATERIAL_COATING', min: 0.70, max: 0.98 },
      t_ambient_sink: { val: 220.0, unit: 'K', desc: 'Effective environmental radiative sink temp', prov: 'MISSION_ORBIT', min: 3, max: 320 },
      thermal_conductivity_matrix: {
        gen_to_rad: 120.0,
        conv_to_rad: 180.0,
        bus_to_rad: 60.0,
        stor_to_rad: 220.0
      },
      t_initial: {
        generator: 340.0,
        converter: 325.0,
        bus: 310.0,
        storage: 298.0,
        radiator: 305.0
      }
    },
    strategy: 'GENERATION_PLUS_STORAGE'
  };
}

export function createDefaultLoads(): LoadItem[] {
  return [
    { id: 'PROPULSION', name: 'Propulsion System (Arcjet / Hall Thruster / Turbo-pump)', nominal_power: 1.2e6, min_power: 0.0, max_power: 2.2e6, priority: 2, duty_cycle: 0.85, temp_sensitivity: 0.0005, active: true },
    { id: 'AVIONICS', name: 'Flight Avionics & Guidance Navigation & Control (GNC)', nominal_power: 45e3, min_power: 35e3, max_power: 60e3, priority: 1, duty_cycle: 1.0, temp_sensitivity: 0.0001, active: true },
    { id: 'COMMUNICATIONS', name: 'Deep-Space High Gain RF & Optical Transceivers', nominal_power: 85e3, min_power: 20e3, max_power: 150e3, priority: 2, duty_cycle: 0.90, temp_sensitivity: 0.0003, active: true },
    { id: 'THERMAL_CONTROL', name: 'Active Thermal Management & Cryocooler Loops', nominal_power: 120e3, min_power: 40e3, max_power: 250e3, priority: 1, duty_cycle: 1.0, temp_sensitivity: 0.0012, active: true },
    { id: 'NAVIGATION', name: 'Star Trackers, Inertial Measurement Units & LiDAR', nominal_power: 25e3, min_power: 15e3, max_power: 35e3, priority: 1, duty_cycle: 1.0, temp_sensitivity: 0.0002, active: true },
    { id: 'SCIENCE', name: 'Planetary Radar, Spectrometers & Magnetometers', nominal_power: 95e3, min_power: 0.0, max_power: 220e3, priority: 4, duty_cycle: 0.70, temp_sensitivity: 0.0004, active: true },
    { id: 'PAYLOAD', name: 'Mission Experiment Core & Sample Extraction', nominal_power: 180e3, min_power: 0.0, max_power: 450e3, priority: 4, duty_cycle: 0.60, temp_sensitivity: 0.0005, active: true },
    { id: 'LIFE_SUPPORT', name: 'Environmental Control & Life Support (ECLSS)', nominal_power: 110e3, min_power: 80e3, max_power: 160e3, priority: 1, duty_cycle: 1.0, temp_sensitivity: 0.0002, active: true },
    { id: 'POWER_CONVERSION', name: 'Auxiliary Sub-Bus Regulators & Gate Drivers', nominal_power: 30e3, min_power: 20e3, max_power: 45e3, priority: 1, duty_cycle: 1.0, temp_sensitivity: 0.0003, active: true },
    { id: 'RESERVE', name: 'Auxiliary Contingency & Margin Reserve', nominal_power: 50e3, min_power: 0.0, max_power: 100e3, priority: 5, duty_cycle: 0.50, temp_sensitivity: 0.0, active: true }
  ];
}

export function runFullSimulation(
  params: SystemParameters = createDefaultParameters(),
  duration = 600,
  dt = 0.5,
  method: 'Euler' | 'RK2' | 'RK4' = 'RK4',
  loads: LoadItem[] = createDefaultLoads(),
  boostMode = false
): SimulationResult {
  const steps = Math.ceil(duration / dt);
  const telemetry: TelemetryPoint[] = [];

  const limits = {
    gen_c_th: params.generation.thermal_mass.val,
    conv_c_th: params.converter.thermal_mass.val,
    bus_c_th: params.bus.thermal_mass.val,
    stor_c_th: params.storage.thermal_mass.val,
    t_gen_max: params.generation.t_max.val,
    t_conv_max: params.converter.t_max.val,
    t_bus_max: params.bus.t_max.val,
    t_stor_max: params.storage.t_max.val
  };

  let soc = params.storage.soc_initial.val;
  let t_gen = params.thermal.t_initial.generator;
  let t_conv = params.thermal.t_initial.converter;
  let t_bus = params.thermal.t_initial.bus;
  let t_stor = params.thermal.t_initial.storage;
  let t_rad = params.thermal.t_initial.radiator;

  let cum_e_source = 0.0;
  let cum_e_delivered = 0.0;
  let cum_e_stored = 0.0;
  let cum_e_losses = 0.0;
  let cum_e_dissipated = 0.0;

  const sigma = 5.670374419e-8;
  const a_rad = params.thermal.radiator_area.val;
  const eps = params.thermal.emissivity.val;
  const t_env = params.thermal.t_ambient_sink.val;

  for (let step = 0; step <= steps; step++) {
    const t = step * dt;

    // 1. Loads demand
    let p_demand = 0;
    const temp_avg = (t_gen + t_conv + t_bus + t_stor) / 4.0;
    for (let i = 0; i < loads.length; i++) {
      const load = loads[i];
      if (!load.active) continue;
      let p_item = load.nominal_power;
      if (load.id === 'PROPULSION' && boostMode) {
        p_item = load.max_power;
      }
      const mod = 1.0 + 0.04 * Math.sin((2 * Math.PI * t) / 250.0 + i);
      const temp_fac = 1.0 + load.temp_sensitivity * Math.max(0, temp_avg - 300.0);
      const p_act = Math.max(load.min_power, Math.min(load.max_power, p_item * load.duty_cycle * mod * temp_fac));
      p_demand += p_act;
    }

    // 2. Augmentation strategy dispatch
    const p_base = params.generation.baseline_power.val;
    const p_gen_max = params.generation.augmented_power.val * params.generation.health.val;
    const soc_min = params.storage.soc_min.val;
    const soc_max = params.storage.soc_max.val;
    const max_disch = params.storage.max_discharge_power.val * params.storage.health.val;
    const max_ch = params.storage.max_charge_power.val;

    let p_gen_target = p_base;
    let p_stor_cmd = 0;

    const strat = params.strategy;
    if (strat === 'GENERATION_ONLY') {
      p_gen_target = Math.min(p_gen_max, Math.max(p_base, p_demand));
      p_stor_cmd = 0;
    } else if (strat === 'STORAGE_ONLY') {
      p_gen_target = p_base;
      const shortfall = Math.max(0, p_demand - p_base);
      if (soc > soc_min) p_stor_cmd = Math.min(max_disch, shortfall);
    } else if (strat === 'GENERATION_PLUS_STORAGE') {
      p_gen_target = Math.min(p_gen_max, p_demand);
      const shortfall = Math.max(0, p_demand - p_gen_target);
      if (shortfall > 0 && soc > soc_min) {
        p_stor_cmd = Math.min(max_disch, shortfall);
      } else if (shortfall <= 0 && soc < soc_max && p_gen_max > p_demand) {
        p_stor_cmd = -Math.min(p_gen_max - p_demand, max_ch) * 0.4;
      }
    } else if (strat === 'STORAGE_PEAK_SHAVING') {
      p_gen_target = p_base * 1.15;
      const spike = Math.max(0, p_demand - p_gen_target);
      if (spike > 0 && soc > soc_min) p_stor_cmd = Math.min(max_disch, spike);
    } else if (strat === 'CONSTANT_POWER') {
      p_gen_target = p_gen_max;
      if (p_demand > p_gen_target && soc > soc_min) p_stor_cmd = Math.min(max_disch, p_demand - p_gen_target);
    } else if (strat === 'THERMAL_LIMITED') {
      const min_margin = Math.min(
        (limits.t_gen_max - t_gen) / limits.t_gen_max,
        (limits.t_conv_max - t_conv) / limits.t_conv_max,
        (limits.t_bus_max - t_bus) / limits.t_bus_max,
        (limits.t_stor_max - t_stor) / limits.t_stor_max
      );
      const derate = Math.max(0.2, Math.min(1.0, min_margin / 0.25));
      p_gen_target = p_base + (p_gen_max - p_base) * derate;
      const shortfall = Math.max(0, p_demand - p_gen_target);
      if (shortfall > 0 && soc > soc_min) p_stor_cmd = Math.min(max_disch * derate, shortfall);
    } else if (strat === 'STORAGE_LIFE_LIMITED') {
      p_gen_target = Math.min(p_gen_max, p_demand);
      const conservative = max_disch * 0.45;
      const shortfall = Math.max(0, p_demand - p_gen_target);
      if (shortfall > 0 && soc > soc_min) p_stor_cmd = Math.min(conservative, shortfall);
    }

    // 3. Primary Generation
    const eta_gen_0 = params.generation.efficiency_0.val;
    const gamma = params.generation.temp_coefficient.val;
    const t_ref = params.generation.t_ref.val;
    const eta_gen = Math.max(0.40, Math.min(0.99, eta_gen_0 * (1.0 - gamma * Math.max(0, t_gen - t_ref)) * params.generation.health.val));
    const p_gen_gross = Math.min(p_gen_target, p_gen_max);
    const p_gen_elec = p_gen_gross * eta_gen;
    const p_gen_loss = p_gen_gross * (1.0 - eta_gen);

    // 4. Power Conversion
    const max_conv_rating = params.converter.max_power_rating.val;
    const p_conv_in = Math.min(p_gen_elec, max_conv_rating);
    const temp_pen = t_conv > 340.0 ? 0.0004 * (t_conv - 340.0) : 0.0;
    const eta_conv = Math.max(0.60, Math.min(0.995, params.converter.efficiency_nominal.val - temp_pen - params.converter.switching_loss_factor.val * (p_conv_in / max_conv_rating)));
    const p_conv_out = p_conv_in * eta_conv;
    const p_conv_loss = p_conv_in - p_conv_out;

    // 5. Energy Storage
    const cap_total = params.storage.capacity_total_j.val * params.storage.health.val;
    const v_oc = params.bus.voltage_nominal.val * (0.92 + 0.16 * soc);
    const r_esr = params.storage.internal_resistance.val;
    let p_stor_disch = 0;
    let p_stor_charge = 0;
    let p_stor_loss = 0;
    let i_stor = 0;
    let d_soc = 0;

    if (p_stor_cmd > 0 && soc > soc_min) {
      const max_avail = Math.min(max_disch, (soc - soc_min) * cap_total / dt);
      const req = Math.min(p_stor_cmd, max_avail);
      i_stor = v_oc > 0 ? req / v_oc : 0;
      p_stor_loss = (i_stor * i_stor) * r_esr;
      p_stor_disch = Math.max(0, req - p_stor_loss);
      d_soc = -((req * dt) / cap_total);
    } else if (p_stor_cmd < 0 && soc < soc_max) {
      const max_ch_avail = Math.min(max_ch, (soc_max - soc) * cap_total / dt);
      const ch_in = Math.min(Math.abs(p_stor_cmd), max_ch_avail);
      i_stor = v_oc > 0 ? ch_in / v_oc : 0;
      p_stor_loss = (i_stor * i_stor) * r_esr + ch_in * (1.0 - params.storage.roundtrip_efficiency.val);
      p_stor_charge = ch_in;
      d_soc = Math.max(0, (ch_in - p_stor_loss) * dt) / cap_total;
    }
    soc = Math.max(soc_min, Math.min(soc_max, soc + d_soc));

    // 6. Distribution Bus
    const p_bus_in = p_conv_out + p_stor_disch - p_stor_charge;
    const v_nom = params.bus.voltage_nominal.val;
    const r_bus = params.bus.resistance.val;
    const p_served_est = Math.min(p_bus_in, p_demand);
    const i_bus = v_nom > 0 ? p_served_est / v_nom : 0;
    const p_bus_loss = (i_bus * i_bus) * r_bus;
    const v_actual = Math.max(1.0, v_nom - i_bus * r_bus);
    const p_usable = Math.max(0, p_bus_in - p_bus_loss);
    const p_served = Math.min(p_usable, p_demand);
    const p_margin = p_usable - p_demand;

    // 7. Thermal Network ODE evaluation
    const g_gen = params.thermal.thermal_conductivity_matrix.gen_to_rad;
    const g_conv = params.thermal.thermal_conductivity_matrix.conv_to_rad;
    const g_bus = params.thermal.thermal_conductivity_matrix.bus_to_rad;
    const g_stor = params.thermal.thermal_conductivity_matrix.stor_to_rad;

    const q_cond_gen = g_gen * (t_gen - t_rad);
    const q_cond_conv = g_conv * (t_conv - t_rad);
    const q_cond_bus = g_bus * (t_bus - t_rad);
    const q_cond_stor = g_stor * (t_stor - t_rad);
    const q_rad = eps * sigma * a_rad * (Math.pow(Math.max(0, t_rad), 4) - Math.pow(Math.max(0, t_env), 4));

    // Derivatives: dT/dt
    const dt_gen = (p_gen_loss - q_cond_gen) / limits.gen_c_th;
    const dt_conv = (p_conv_loss - q_cond_conv) / limits.conv_c_th;
    const dt_bus = (p_bus_loss - q_cond_bus) / limits.bus_c_th;
    const dt_stor = (p_stor_loss - q_cond_stor) / limits.stor_c_th;
    const dt_rad = ((q_cond_gen + q_cond_conv + q_cond_bus + q_cond_stor) - q_rad) / 45000.0;

    // Integration
    t_gen += dt_gen * dt;
    t_conv += dt_conv * dt;
    t_bus += dt_bus * dt;
    t_stor += dt_stor * dt;
    t_rad += dt_rad * dt;

    // Thermal margin
    const m_gen = Math.max(0, (limits.t_gen_max - t_gen) / limits.t_gen_max);
    const m_conv = Math.max(0, (limits.t_conv_max - t_conv) / limits.t_conv_max);
    const m_bus = Math.max(0, (limits.t_bus_max - t_bus) / limits.t_bus_max);
    const m_stor = Math.max(0, (limits.t_stor_max - t_stor) / limits.t_stor_max);
    const system_thermal_margin = Math.min(m_gen, m_conv, m_bus, m_stor);

    // 8. Energy conservation & residual
    const p_losses_total = p_gen_loss + p_conv_loss + p_bus_loss + p_stor_loss;
    const p_stor_internal_rate = p_stor_charge - p_stor_disch;
    const de_source = (p_gen_gross * dt) / 1e6;
    const de_delivered = (p_served * dt) / 1e6;
    const de_stored = (p_stor_internal_rate * dt) / 1e6;
    const de_losses = (p_losses_total * dt) / 1e6;
    const de_dissipated = (q_rad * dt) / 1e6;

    const energy_residual_mj = de_source - (de_delivered + de_stored + de_losses);

    cum_e_source += de_source;
    cum_e_delivered += de_delivered;
    cum_e_stored += de_stored;
    cum_e_losses += de_losses;
    cum_e_dissipated += de_dissipated;

    const delta_p = p_served - p_base;
    const p_gain_pct = p_base > 0 ? (100.0 * delta_p) / p_base : 0;
    const eff_sys = p_gen_gross > 0 ? p_served / p_gen_gross : 0;

    telemetry.push({
      time: t,
      p_baseline: p_base,
      p_gen_gross,
      p_gen_elec,
      p_gen_loss,
      p_conv_in,
      p_conv_out,
      p_conv_loss,
      p_stor_disch,
      p_stor_charge,
      p_stor_loss,
      p_bus_in,
      p_bus_loss,
      p_demand,
      p_usable,
      p_served,
      p_margin,
      delta_p,
      p_gain_pct,
      v_bus: v_actual,
      i_bus,
      soc,
      t_generator: t_gen,
      t_converter: t_conv,
      t_bus: t_bus,
      t_storage: t_stor,
      t_radiator: t_rad,
      thermal_margin: system_thermal_margin,
      q_rad,
      eff_system: eff_sys,
      energy_residual_mj,
      cum_e_source_mj: cum_e_source,
      cum_e_delivered_mj: cum_e_delivered,
      cum_e_stored_mj: cum_e_stored,
      cum_e_losses_mj: cum_e_losses,
      cum_e_dissipated_mj: cum_e_dissipated
    });
  }

  const avg_usable = telemetry.reduce((acc, pt) => acc + pt.p_usable, 0) / telemetry.length;
  const peak_usable = Math.max(...telemetry.map(pt => pt.p_usable));
  const min_margin = Math.min(...telemetry.map(pt => pt.p_margin));
  const max_temp = Math.max(...telemetry.map(pt => Math.max(pt.t_generator, pt.t_converter, pt.t_bus, pt.t_storage)));
  const min_thm = Math.min(...telemetry.map(pt => pt.thermal_margin)) * 100.0;
  const max_res = Math.max(...telemetry.map(pt => Math.abs(pt.energy_residual_mj)));

  return {
    telemetry,
    summary: {
      duration,
      dt,
      method,
      strategy: params.strategy,
      baseline_power_mw: params.generation.baseline_power.val / 1e6,
      avg_usable_power_mw: avg_usable / 1e6,
      peak_usable_power_mw: peak_usable / 1e6,
      min_power_margin_kw: min_margin / 1e3,
      final_soc: telemetry[telemetry.length - 1].soc,
      max_temp_k: max_temp,
      min_thermal_margin_pct: min_thm,
      total_energy_delivered_mj: cum_e_delivered,
      total_energy_losses_mj: cum_e_losses,
      max_energy_residual_mj: max_res,
      is_energy_conserved: max_res < 1e-3
    }
  };
}
