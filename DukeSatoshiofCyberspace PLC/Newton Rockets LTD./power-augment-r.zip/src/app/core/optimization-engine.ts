import { SystemParameters, createDefaultParameters } from './physics-engine';

export interface ParetoCandidate {
  id: number;
  gen_power_mw: number;
  stor_power_mw: number;
  v_bus: number;
  rad_area: number;
  usable_power_mw: number;
  thermal_margin_pct: number;
  losses_kw: number;
  bus_current_a: number;
  is_pareto: boolean;
}

export interface OptimizationResult {
  all_candidates: ParetoCandidate[];
  pareto_frontier: ParetoCandidate[];
  recommended_design: ParetoCandidate;
}

export function runParetoOptimization(
  baseParams: SystemParameters = createDefaultParameters(),
  gridPoints = 5
): OptimizationResult {
  const genVals = [1.8e6, 2.1e6, 2.4e6, 2.7e6, 3.0e6, 3.3e6].slice(0, gridPoints);
  const storVals = [0.4e6, 0.7e6, 1.0e6, 1.3e6, 1.6e6].slice(0, gridPoints);
  const vBusVals = [260.0, 300.0, 350.0, 400.0, 450.0].slice(0, gridPoints);
  const radVals = [45.0, 60.0, 75.0, 90.0, 110.0].slice(0, gridPoints);

  const candidates: ParetoCandidate[] = [];
  let id = 1;

  for (const g of genVals) {
    for (const s of storVals) {
      for (const v of vBusVals) {
        for (const a of radVals) {
          const eta_gen = baseParams.generation.efficiency_0.val;
          const eta_conv = baseParams.converter.efficiency_nominal.val;
          const r_bus = baseParams.bus.resistance.val;

          const p_gen_elec = g * eta_gen;
          const p_conv_out = p_gen_elec * eta_conv;

          const p_demand = 2.2e6;
          const i_bus = p_demand / v;
          const p_bus_loss = i_bus * i_bus * r_bus;

          const p_usable = p_conv_out + s - p_bus_loss;
          const p_losses_tot = (g - p_gen_elec) + (p_gen_elec - p_conv_out) + p_bus_loss + s * 0.05;

          const sigma = 5.670374419e-8;
          const q_rad = 0.91 * sigma * a * (Math.pow(345.0, 4) - Math.pow(220.0, 4));
          const thermal_margin_pct = ((q_rad - p_losses_tot) / q_rad) * 100.0;

          if (i_bus <= 12000.0 && thermal_margin_pct >= 6.0 && p_usable >= 1.8e6) {
            candidates.push({
              id: id++,
              gen_power_mw: g / 1e6,
              stor_power_mw: s / 1e6,
              v_bus: v,
              rad_area: a,
              usable_power_mw: p_usable / 1e6,
              thermal_margin_pct,
              losses_kw: p_losses_tot / 1e3,
              bus_current_a: i_bus,
              is_pareto: false
            });
          }
        }
      }
    }
  }

  // Filter non-dominated Pareto points
  const pareto: ParetoCandidate[] = [];
  for (let i = 0; i < candidates.length; i++) {
    const ci = candidates[i];
    let dominated = false;
    for (let j = 0; j < candidates.length; j++) {
      if (i === j) continue;
      const cj = candidates[j];
      if (
        cj.usable_power_mw >= ci.usable_power_mw &&
        cj.thermal_margin_pct >= ci.thermal_margin_pct &&
        cj.losses_kw <= ci.losses_kw &&
        (cj.usable_power_mw > ci.usable_power_mw || cj.thermal_margin_pct > ci.thermal_margin_pct || cj.losses_kw < ci.losses_kw)
      ) {
        dominated = true;
        break;
      }
    }
    if (!dominated) {
      ci.is_pareto = true;
      pareto.push(ci);
    }
  }

  pareto.sort((a, b) => b.usable_power_mw - a.usable_power_mw);

  // Knee point / balanced recommended design
  let best = pareto[0];
  let bestScore = -Infinity;
  for (const c of pareto) {
    const score = c.usable_power_mw * 0.45 + (c.thermal_margin_pct / 50.0) * 0.35 - (c.losses_kw / 300.0) * 0.20;
    if (score > bestScore) {
      bestScore = score;
      best = c;
    }
  }

  return {
    all_candidates: candidates,
    pareto_frontier: pareto,
    recommended_design: best
  };
}
