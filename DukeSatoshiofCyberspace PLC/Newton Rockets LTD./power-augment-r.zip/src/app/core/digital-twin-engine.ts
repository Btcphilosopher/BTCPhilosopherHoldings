import { TelemetryPoint } from './physics-engine';

export interface DigitalTwinState {
  p_gen: number;
  v_bus: number;
  i_bus: number;
  soc: number;
  t_gen: number;
  t_conv: number;
  t_stor: number;
  t_bus: number;
}

export type HealthClassification = 'NORMAL' | 'WARNING' | 'LIMITED' | 'FAULT';

export interface DigitalTwinFrame {
  time: number;
  true_state: DigitalTwinState;
  measured_state: DigitalTwinState;
  estimated_state: DigitalTwinState;
  innovation_residuals: DigitalTwinState;
  health_status: HealthClassification;
  fault_flags: string[];
  subsystem_health: {
    generator: HealthClassification;
    converter: HealthClassification;
    bus: HealthClassification;
    storage: HealthClassification;
    sensors: HealthClassification;
  };
}

export interface InjectedFaults {
  generator_efficiency_drop?: boolean;
  converter_efficiency_drop?: boolean;
  bus_resistance_increase?: boolean;
  storage_capacity_loss?: boolean;
  sensor_bias?: { v_bus: number; t_conv: number };
  sensor_noise_boost?: number;
  load_spike?: boolean;
  radiator_fouling?: boolean;
}

export class DigitalTwinPipeline {
  private xHat: DigitalTwinState = {
    p_gen: 2.2e6,
    v_bus: 300.0,
    i_bus: 4500.0,
    soc: 0.90,
    t_gen: 340.0,
    t_conv: 325.0,
    t_stor: 298.0,
    t_bus: 310.0
  };

  private readonly noiseSd = {
    p_gen: 12000.0,
    v_bus: 1.1,
    i_bus: 28.0,
    soc: 0.006,
    t_gen: 0.7,
    t_conv: 0.5,
    t_stor: 0.4,
    t_bus: 0.5
  };

  step(pt: TelemetryPoint, faults: InjectedFaults = {}): DigitalTwinFrame {
    // 1. True physical state
    const trueState: DigitalTwinState = {
      p_gen: pt.p_gen_elec,
      v_bus: pt.v_bus,
      i_bus: pt.i_bus,
      soc: pt.soc,
      t_gen: pt.t_generator,
      t_conv: pt.t_converter,
      t_stor: pt.t_storage,
      t_bus: pt.t_bus
    };

    // 2. Sensor Model with noise + bias + injected faults
    const noiseMultiplier = faults.sensor_noise_boost || 1.0;
    const gaussian = () => (Math.random() - 0.5 + (Math.random() - 0.5)) * 1.732;

    const biasV = faults.sensor_bias?.v_bus || 0;
    const biasT = faults.sensor_bias?.t_conv || 0;

    const measuredState: DigitalTwinState = {
      p_gen: trueState.p_gen + gaussian() * this.noiseSd.p_gen * noiseMultiplier,
      v_bus: trueState.v_bus + biasV + gaussian() * this.noiseSd.v_bus * noiseMultiplier,
      i_bus: trueState.i_bus + gaussian() * this.noiseSd.i_bus * noiseMultiplier,
      soc: Math.max(0, Math.min(1, trueState.soc + gaussian() * this.noiseSd.soc * noiseMultiplier)),
      t_gen: trueState.t_gen + gaussian() * this.noiseSd.t_gen * noiseMultiplier,
      t_conv: trueState.t_conv + biasT + gaussian() * this.noiseSd.t_conv * noiseMultiplier,
      t_stor: trueState.t_stor + gaussian() * this.noiseSd.t_stor * noiseMultiplier,
      t_bus: trueState.t_bus + gaussian() * this.noiseSd.t_bus * noiseMultiplier
    };

    // 3. EKF Observer State Estimation & Innovation
    const kGain = {
      p_gen: 0.45,
      v_bus: 0.65,
      i_bus: 0.60,
      soc: 0.50,
      t_gen: 0.35,
      t_conv: 0.35,
      t_stor: 0.30,
      t_bus: 0.35
    };

    const residuals: DigitalTwinState = {
      p_gen: measuredState.p_gen - this.xHat.p_gen,
      v_bus: measuredState.v_bus - this.xHat.v_bus,
      i_bus: measuredState.i_bus - this.xHat.i_bus,
      soc: measuredState.soc - this.xHat.soc,
      t_gen: measuredState.t_gen - this.xHat.t_gen,
      t_conv: measuredState.t_conv - this.xHat.t_conv,
      t_stor: measuredState.t_stor - this.xHat.t_stor,
      t_bus: measuredState.t_bus - this.xHat.t_bus
    };

    this.xHat = {
      p_gen: this.xHat.p_gen + kGain.p_gen * residuals.p_gen,
      v_bus: this.xHat.v_bus + kGain.v_bus * residuals.v_bus,
      i_bus: this.xHat.i_bus + kGain.i_bus * residuals.i_bus,
      soc: this.xHat.soc + kGain.soc * residuals.soc,
      t_gen: this.xHat.t_gen + kGain.t_gen * residuals.t_gen,
      t_conv: this.xHat.t_conv + kGain.t_conv * residuals.t_conv,
      t_stor: this.xHat.t_stor + kGain.t_stor * residuals.t_stor,
      t_bus: this.xHat.t_bus + kGain.t_bus * residuals.t_bus
    };

    // 4. Subsystem & Global Health Classification
    const faultFlags: string[] = [];
    let genH: HealthClassification = 'NORMAL';
    let convH: HealthClassification = 'NORMAL';
    let busH: HealthClassification = 'NORMAL';
    let storH: HealthClassification = 'NORMAL';
    let sensorH: HealthClassification = 'NORMAL';

    if (trueState.t_gen > 430) genH = 'WARNING';
    if (trueState.t_gen > 460) genH = 'LIMITED';
    if (trueState.t_gen >= 480) {
      genH = 'FAULT';
      faultFlags.push('GENERATOR_OVERHEAT');
    }

    if (trueState.t_conv > 365) convH = 'WARNING';
    if (trueState.t_conv > 385) convH = 'LIMITED';
    if (trueState.t_conv >= 395) {
      convH = 'FAULT';
      faultFlags.push('CONVERTER_JUNCTION_CRITICAL');
    }

    if (trueState.i_bus > 9500) busH = 'WARNING';
    if (trueState.i_bus > 11200) busH = 'LIMITED';
    if (trueState.i_bus >= 12000) {
      busH = 'FAULT';
      faultFlags.push('BUS_AMPACITY_EXCEEDED');
    }

    if (trueState.soc < 0.25 || trueState.t_stor > 320) storH = 'WARNING';
    if (trueState.soc < 0.16 || trueState.t_stor > 330) storH = 'LIMITED';
    if (trueState.soc <= 0.10 || trueState.t_stor >= 335) {
      storH = 'FAULT';
      faultFlags.push('STORAGE_DEPLETED_OR_OVERTEMP');
    }

    if (Math.abs(residuals.v_bus) > 4.5 || Math.abs(residuals.t_conv) > 6.0) {
      sensorH = 'WARNING';
      faultFlags.push('SENSOR_RESIDUAL_DRIFT');
    }
    if (Math.abs(residuals.v_bus) > 10.0 || Math.abs(residuals.t_conv) > 12.0) {
      sensorH = 'FAULT';
      faultFlags.push('SENSOR_CALIBRATION_FAULT');
    }

    const rank = { NORMAL: 1, WARNING: 2, LIMITED: 3, FAULT: 4 };
    const allH = [genH, convH, busH, storH, sensorH];
    allH.sort((a, b) => rank[b] - rank[a]);
    const overall = allH[0];

    return {
      time: pt.time,
      true_state: trueState,
      measured_state: measuredState,
      estimated_state: { ...this.xHat },
      innovation_residuals: residuals,
      health_status: overall,
      fault_flags: faultFlags,
      subsystem_health: {
        generator: genH,
        converter: convH,
        bus: busH,
        storage: storH,
        sensors: sensorH
      }
    };
  }
}
