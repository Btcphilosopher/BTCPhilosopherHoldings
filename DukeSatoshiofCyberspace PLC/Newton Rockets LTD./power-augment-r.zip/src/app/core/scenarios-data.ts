import { SystemParameters, createDefaultParameters } from './physics-engine';

export interface MissionScenario {
  id: string;
  code: string;
  name: string;
  category: 'NOMINAL' | 'BOOST' | 'THERMAL' | 'DEGRADED' | 'HARDWARE_LIMIT';
  description: string;
  duration: number;
  dt: number;
  boost_mode: boolean;
  params: SystemParameters;
}

export function getMissionScenarios(): MissionScenario[] {
  const base = createDefaultParameters();

  const clone = (fn: (p: SystemParameters) => void): SystemParameters => {
    const p = JSON.parse(JSON.stringify(base)) as SystemParameters;
    fn(p);
    return p;
  };

  return [
    {
      id: 'BASELINE',
      code: 'SCN-01',
      name: 'Baseline Cruise Power',
      category: 'NOMINAL',
      description: 'Nominal deep-space cruise with steady baseline generator output (1.80 MW) and floating battery storage buffer.',
      duration: 600,
      dt: 0.5,
      boost_mode: false,
      params: clone((p) => {
        p.strategy = 'GENERATION_ONLY';
      })
    },
    {
      id: 'POWER_BOOST',
      code: 'SCN-02',
      name: 'Power Boost Propulsion Maneuver',
      category: 'BOOST',
      description: 'Full-throttle power augmentation combining reactor ramp to 2.4 MW and storage discharge for a 2.2 MW arcjet burn.',
      duration: 600,
      dt: 0.5,
      boost_mode: true,
      params: clone((p) => {
        p.strategy = 'GENERATION_PLUS_STORAGE';
      })
    },
    {
      id: 'PEAK_POWER_EVENT',
      code: 'SCN-03',
      name: 'Peak Power Science & Radar Pulse',
      category: 'BOOST',
      description: 'High-energy synthetic aperture radar mapping event drawing peak battery storage buffer capacity.',
      duration: 300,
      dt: 0.25,
      boost_mode: false,
      params: clone((p) => {
        p.strategy = 'STORAGE_PEAK_SHAVING';
      })
    },
    {
      id: 'LONG_DURATION_HIGH_LOAD',
      code: 'SCN-04',
      name: 'Long-Duration High-Load Injection',
      category: 'BOOST',
      description: 'Sustained 30-minute high electrical load testing thermal radiative equilibrium and component temperature plateaus.',
      duration: 1800,
      dt: 1.0,
      boost_mode: true,
      params: clone((p) => {
        p.strategy = 'GENERATION_PLUS_STORAGE';
      })
    },
    {
      id: 'HIGH_TEMPERATURE',
      code: 'SCN-05',
      name: 'High-Temperature Perihelion Pass',
      category: 'THERMAL',
      description: 'Elevated ambient sink temperature (290 K) reducing radiator Stefan-Boltzmann rejection and thermal margins.',
      duration: 600,
      dt: 0.5,
      boost_mode: false,
      params: clone((p) => {
        p.thermal.t_ambient_sink.val = 290.0;
        p.strategy = 'THERMAL_LIMITED';
      })
    },
    {
      id: 'LOW_TEMPERATURE',
      code: 'SCN-06',
      name: 'Low-Temperature Deep Space Cruise',
      category: 'THERMAL',
      description: 'Deep space cold sink (40 K) providing high radiative headroom with increased battery internal resistance.',
      duration: 600,
      dt: 0.5,
      boost_mode: false,
      params: clone((p) => {
        p.thermal.t_ambient_sink.val = 40.0;
        p.storage.internal_resistance.val = 0.0065;
      })
    },
    {
      id: 'DEGRADED_GENERATOR',
      code: 'SCN-07',
      name: 'Degraded Primary Generator (EOL)',
      category: 'DEGRADED',
      description: 'Primary generation health degraded to 78% with increased thermal derating penalty.',
      duration: 600,
      dt: 0.5,
      boost_mode: false,
      params: clone((p) => {
        p.generation.health.val = 0.78;
        p.generation.efficiency_0.val = 0.86;
      })
    },
    {
      id: 'DEGRADED_STORAGE',
      code: 'SCN-08',
      name: 'Degraded Energy Storage Battery',
      category: 'DEGRADED',
      description: 'Battery capacity retention fade to 65% with elevated ESR resistance limiting discharge rate.',
      duration: 600,
      dt: 0.5,
      boost_mode: true,
      params: clone((p) => {
        p.storage.health.val = 0.65;
        p.storage.internal_resistance.val = 0.0085;
      })
    },
    {
      id: 'HIGH_BUS_LOAD',
      code: 'SCN-09',
      name: 'High DC Bus Load & I²R Stress',
      category: 'HARDWARE_LIMIT',
      description: 'Severe electrical current draw stressing bus harness ampacity and increasing distribution resistive heating.',
      duration: 600,
      dt: 0.5,
      boost_mode: true,
      params: clone((p) => {
        p.bus.resistance.val = 0.0055;
      })
    },
    {
      id: 'CONVERTER_LIMIT',
      code: 'SCN-10',
      name: 'Converter Throughput Clamping',
      category: 'HARDWARE_LIMIT',
      description: 'DC-DC converter maximum rating throttled to 2.2 MW to evaluate conversion bottlenecking.',
      duration: 600,
      dt: 0.5,
      boost_mode: true,
      params: clone((p) => {
        p.converter.max_power_rating.val = 2.2e6;
      })
    },
    {
      id: 'THERMAL_LIMIT',
      code: 'SCN-11',
      name: 'Radiator Fouling & Thermal Limit',
      category: 'THERMAL',
      description: 'Radiator coating degradation reducing emissivity to 0.68, triggering thermal-limited throttling.',
      duration: 900,
      dt: 0.5,
      boost_mode: true,
      params: clone((p) => {
        p.thermal.emissivity.val = 0.68;
        p.strategy = 'THERMAL_LIMITED';
      })
    },
    {
      id: 'COMBINED_DEGRADATION',
      code: 'SCN-12',
      name: 'Combined Multi-Subsystem Degradation',
      category: 'DEGRADED',
      description: 'Simultaneous end-of-mission degradation across generator, converter, bus resistance, and storage buffer.',
      duration: 600,
      dt: 0.5,
      boost_mode: true,
      params: clone((p) => {
        p.generation.health.val = 0.82;
        p.storage.health.val = 0.70;
        p.bus.resistance.val = 0.0048;
        p.converter.efficiency_nominal.val = 0.93;
        p.thermal.emissivity.val = 0.78;
      })
    }
  ];
}
