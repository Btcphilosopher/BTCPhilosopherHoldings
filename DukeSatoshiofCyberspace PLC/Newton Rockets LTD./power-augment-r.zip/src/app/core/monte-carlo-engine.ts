import { SystemParameters, createDefaultParameters } from './physics-engine';

export interface MonteCarloSample {
  iter: number;
  eta_generator: number;
  eta_converter: number;
  r_bus_mohm: number;
  r_esr_mohm: number;
  storage_health: number;
  emissivity: number;
  t_ambient_k: number;
  usable_power_mw: number;
  power_gain_mw: number;
  power_margin_mw: number;
  thermal_margin_pct: number;
  total_losses_kw: number;
}

export interface MetricDistribution {
  mean: number;
  sd: number;
  min: number;
  max: number;
  p10: number;
  p50: number;
  p90: number;
  p99: number;
  histogram: { binStart: number; binEnd: number; count: number; freq: number }[];
}

export interface MonteCarloResult {
  n_iterations: number;
  samples: MonteCarloSample[];
  distributions: {
    usable_power: MetricDistribution;
    power_gain: MetricDistribution;
    power_margin: MetricDistribution;
    thermal_margin: MetricDistribution;
    total_losses: MetricDistribution;
  };
}

function randNormal(mean: number, sd: number): number {
  let u = 0, v = 0;
  while (u === 0) u = Math.random();
  while (v === 0) v = Math.random();
  const z = Math.sqrt(-2.0 * Math.log(u)) * Math.cos(2.0 * Math.PI * v);
  return mean + z * sd;
}

function computeDist(arr: number[], numBins = 15): MetricDistribution {
  const sorted = [...arr].sort((a, b) => a - b);
  const n = sorted.length;
  const mean = sorted.reduce((a, b) => a + b, 0) / n;
  const variance = sorted.reduce((a, b) => a + Math.pow(b - mean, 2), 0) / n;
  const sd = Math.sqrt(variance);

  const getP = (p: number) => {
    const idx = Math.min(n - 1, Math.max(0, Math.floor(p * n)));
    return sorted[idx];
  };

  const min = sorted[0];
  const max = sorted[n - 1];
  const binWidth = (max - min) / numBins || 1;
  const histogram: { binStart: number; binEnd: number; count: number; freq: number }[] = [];

  for (let b = 0; b < numBins; b++) {
    const bStart = min + b * binWidth;
    const bEnd = min + (b + 1) * binWidth;
    const count = sorted.filter((v) => v >= bStart && (b === numBins - 1 ? v <= bEnd : v < bEnd)).length;
    histogram.push({
      binStart: bStart,
      binEnd: bEnd,
      count,
      freq: count / n
    });
  }

  return {
    mean,
    sd,
    min,
    max,
    p10: getP(0.10),
    p50: getP(0.50),
    p90: getP(0.90),
    p99: getP(0.99),
    histogram
  };
}

export function runMonteCarlo(
  baseParams: SystemParameters = createDefaultParameters(),
  nIterations = 500
): MonteCarloResult {
  const samples: MonteCarloSample[] = [];

  for (let i = 1; i <= nIterations; i++) {
    const eta_gen = Math.max(0.80, Math.min(0.98, randNormal(baseParams.generation.efficiency_0.val, 0.015)));
    const eta_conv = Math.max(0.88, Math.min(0.99, randNormal(baseParams.converter.efficiency_nominal.val, 0.008)));
    const r_bus = Math.max(0.001, Math.min(0.01, baseParams.bus.resistance.val * Math.exp(randNormal(0, 0.15))));
    const r_esr = Math.max(0.001, Math.min(0.012, randNormal(baseParams.storage.internal_resistance.val, 0.0006)));
    const stor_health = Math.max(0.65, Math.min(1.0, randNormal(baseParams.storage.health.val, 0.04)));
    const emissivity = Math.max(0.75, Math.min(0.96, randNormal(baseParams.thermal.emissivity.val, 0.02)));
    const t_ambient = 180.0 + Math.random() * 80.0;

    const p_gen_nom = baseParams.generation.augmented_power.val * baseParams.generation.health.val;
    const p_gen_elec = p_gen_nom * eta_gen;
    const p_conv_out = p_gen_elec * eta_conv;
    const p_stor_avail = baseParams.storage.max_discharge_power.val * stor_health;

    const p_load = 1.85e6;
    const v_bus = baseParams.bus.voltage_nominal.val;
    const i_bus = p_load / v_bus;
    const p_bus_loss = i_bus * i_bus * r_bus;

    const p_usable = p_conv_out + p_stor_avail - p_bus_loss;
    const p_gain_mw = (p_usable - baseParams.generation.baseline_power.val) / 1e6;
    const p_margin_mw = (p_usable - p_load) / 1e6;

    const sigma = 5.670374419e-8;
    const q_rad = emissivity * sigma * baseParams.thermal.radiator_area.val * (Math.pow(345.0, 4) - Math.pow(t_ambient, 4));
    const p_loss_tot = (p_gen_nom - p_gen_elec) + (p_gen_elec - p_conv_out) + p_bus_loss;
    const thermal_margin_pct = Math.max(0.0, Math.min(100.0, (100.0 * (q_rad - p_loss_tot)) / q_rad));

    samples.push({
      iter: i,
      eta_generator: eta_gen,
      eta_converter: eta_conv,
      r_bus_mohm: r_bus * 1e3,
      r_esr_mohm: r_esr * 1e3,
      storage_health: stor_health,
      emissivity,
      t_ambient_k: t_ambient,
      usable_power_mw: p_usable / 1e6,
      power_gain_mw: p_gain_mw,
      power_margin_mw: p_margin_mw,
      thermal_margin_pct,
      total_losses_kw: p_loss_tot / 1e3
    });
  }

  return {
    n_iterations: nIterations,
    samples,
    distributions: {
      usable_power: computeDist(samples.map((s) => s.usable_power_mw)),
      power_gain: computeDist(samples.map((s) => s.power_gain_mw)),
      power_margin: computeDist(samples.map((s) => s.power_margin_mw)),
      thermal_margin: computeDist(samples.map((s) => s.thermal_margin_pct)),
      total_losses: computeDist(samples.map((s) => s.total_losses_kw))
    }
  };
}
