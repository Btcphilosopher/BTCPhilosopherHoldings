import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PowerSystemService } from './services/power-system.service';
import { HeaderComponent } from './components/header/header';
import { OverviewComponent } from './components/overview/overview';
import { PowerFlowComponent } from './components/power-flow/power-flow';
import { GenerationComponent } from './components/generation/generation';
import { AugmentationComponent } from './components/augmentation/augmentation';
import { BusComponent } from './components/bus/bus';
import { StorageComponent } from './components/storage/storage';
import { ThermalComponent } from './components/thermal/thermal';
import { LoadsComponent } from './components/loads/loads';
import { EnvelopeComponent } from './components/envelope/envelope';
import { DigitalTwinComponent } from './components/digital-twin/digital-twin';
import { FaultInjectionComponent } from './components/fault-injection/fault-injection';
import { MonteCarloComponent } from './components/monte-carlo/monte-carlo';
import { SensitivityComponent } from './components/sensitivity/sensitivity';
import { OptimisationComponent } from './components/optimisation/optimisation';
import { ScenariosComponent } from './components/scenarios/scenarios';
import { TelemetryComponent } from './components/telemetry/telemetry';
import { ValidationComponent } from './components/validation/validation';
import { ReportsComponent } from './components/reports/reports';
import { RPackageComponent } from './components/r-package/r-package';

@Component({
  selector: 'app-root',
  imports: [
    CommonModule,
    HeaderComponent,
    OverviewComponent,
    PowerFlowComponent,
    GenerationComponent,
    AugmentationComponent,
    BusComponent,
    StorageComponent,
    ThermalComponent,
    LoadsComponent,
    EnvelopeComponent,
    DigitalTwinComponent,
    FaultInjectionComponent,
    MonteCarloComponent,
    SensitivityComponent,
    OptimisationComponent,
    ScenariosComponent,
    TelemetryComponent,
    ValidationComponent,
    ReportsComponent,
    RPackageComponent
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class App {
  service = inject(PowerSystemService);
}
