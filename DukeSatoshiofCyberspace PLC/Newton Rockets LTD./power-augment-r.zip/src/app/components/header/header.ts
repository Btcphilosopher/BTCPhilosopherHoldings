import { Component, ChangeDetectionStrategy, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { PowerSystemService, ConsoleTab } from '../../services/power-system.service';

@Component({
  selector: 'app-header',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <header class="bg-white border-b border-slate-200 sticky top-0 z-30 shadow-xs">
      <!-- Zone 1, 2, 3 Top Bar Contract -->
      <div class="max-w-7xl mx-auto px-4 sm:px-6 flex items-center justify-between h-14">
        <!-- Zone 1: Brand single text element wordmark -->
        <div class="flex items-center gap-3">
          <span class="font-bold text-slate-900 text-base sm:text-lg tracking-tight font-tech">
            POWER-AUGMENT-R
          </span>
          <span class="hidden md:inline-block text-xs font-mono text-slate-500 border-l border-slate-200 pl-3">
            Digital Twin v1.0 · Aerospace Lab
          </span>
        </div>

        <!-- Zone 2: Primary Navigation Tabs (4-6 clean text links) -->
        <nav class="hidden lg:flex items-center gap-5 text-xs font-medium text-slate-600">
          <button
            (click)="service.setTab('OVERVIEW')"
            class="hover:text-slate-900 py-1 transition-colors whitespace-nowrap"
            [class.text-slate-900]="service.activeTab() === 'OVERVIEW'"
            [class.font-semibold]="service.activeTab() === 'OVERVIEW'"
            [class.border-b-2]="service.activeTab() === 'OVERVIEW'"
            [class.border-slate-900]="service.activeTab() === 'OVERVIEW'">
            Overview
          </button>
          <button
            (click)="service.setTab('POWER_FLOW')"
            class="hover:text-slate-900 py-1 transition-colors whitespace-nowrap"
            [class.text-slate-900]="service.activeTab() === 'POWER_FLOW'"
            [class.font-semibold]="service.activeTab() === 'POWER_FLOW'"
            [class.border-b-2]="service.activeTab() === 'POWER_FLOW'"
            [class.border-slate-900]="service.activeTab() === 'POWER_FLOW'">
            Power Flow
          </button>
          <button
            (click)="service.setTab('ENVELOPE')"
            class="hover:text-slate-900 py-1 transition-colors whitespace-nowrap"
            [class.text-slate-900]="service.activeTab() === 'ENVELOPE'"
            [class.font-semibold]="service.activeTab() === 'ENVELOPE'"
            [class.border-b-2]="service.activeTab() === 'ENVELOPE'"
            [class.border-slate-900]="service.activeTab() === 'ENVELOPE'">
            Envelope
          </button>
          <button
            (click)="service.setTab('DIGITAL_TWIN')"
            class="hover:text-slate-900 py-1 transition-colors whitespace-nowrap"
            [class.text-slate-900]="service.activeTab() === 'DIGITAL_TWIN'"
            [class.font-semibold]="service.activeTab() === 'DIGITAL_TWIN'"
            [class.border-b-2]="service.activeTab() === 'DIGITAL_TWIN'"
            [class.border-slate-900]="service.activeTab() === 'DIGITAL_TWIN'">
            Digital Twin
          </button>
          <button
            (click)="service.setTab('SCENARIOS')"
            class="hover:text-slate-900 py-1 transition-colors whitespace-nowrap"
            [class.text-slate-900]="service.activeTab() === 'SCENARIOS'"
            [class.font-semibold]="service.activeTab() === 'SCENARIOS'"
            [class.border-b-2]="service.activeTab() === 'SCENARIOS'"
            [class.border-slate-900]="service.activeTab() === 'SCENARIOS'">
            Scenarios
          </button>
          <button
            (click)="service.setTab('R_PACKAGE')"
            class="hover:text-slate-900 py-1 transition-colors whitespace-nowrap"
            [class.text-slate-900]="service.activeTab() === 'R_PACKAGE'"
            [class.font-semibold]="service.activeTab() === 'R_PACKAGE'"
            [class.border-b-2]="service.activeTab() === 'R_PACKAGE'"
            [class.border-slate-900]="service.activeTab() === 'R_PACKAGE'">
            R Package
          </button>
        </nav>

        <!-- Zone 3: Primary Actions -->
        <div class="flex items-center gap-2">
          <button
            (click)="service.runFullSystemSimulation()"
            class="px-3 py-1.5 text-xs font-medium text-white bg-slate-900 rounded-md hover:bg-slate-800 transition-colors flex items-center gap-1.5 shadow-xs whitespace-nowrap">
            <mat-icon class="text-sm! w-4! h-4!">play_arrow</mat-icon>
            <span>Execute Run</span>
          </button>
          <button
            (click)="service.setTab('REPORTS')"
            class="px-3 py-1.5 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-md transition-colors flex items-center gap-1.5 whitespace-nowrap">
            <mat-icon class="text-sm! w-4! h-4!">description</mat-icon>
            <span class="hidden sm:inline">Dossier</span>
          </button>
        </div>
      </div>

      <!-- Secondary Sub-Navigation Toolbar (All 19 Lab Subsystems) -->
      <div class="border-t border-slate-100 bg-slate-50/80 px-4 sm:px-6 overflow-x-auto no-scrollbar">
        <div class="max-w-7xl mx-auto flex items-center gap-1 py-1 text-xs">
          @for (tab of allTabs; track tab.id) {
            <button
              (click)="service.setTab(tab.id)"
              class="px-2.5 py-1 rounded transition-colors whitespace-nowrap font-mono flex items-center gap-1.5"
              [class.bg-white]="service.activeTab() === tab.id"
              [class.text-slate-900]="service.activeTab() === tab.id"
              [class.font-medium]="service.activeTab() === tab.id"
              [class.shadow-xs]="service.activeTab() === tab.id"
              [class.text-slate-500]="service.activeTab() !== tab.id"
              [class.hover:text-slate-900]="service.activeTab() !== tab.id">
              <mat-icon class="text-xs! w-3.5! h-3.5!">{{ tab.icon }}</mat-icon>
              <span>{{ tab.label }}</span>
            </button>
          }
        </div>
      </div>
    </header>
  `
})
export class HeaderComponent {
  service = inject(PowerSystemService);

  readonly allTabs: { id: ConsoleTab; label: string; icon: string }[] = [
    { id: 'OVERVIEW', label: 'Overview', icon: 'dashboard' },
    { id: 'POWER_FLOW', label: 'Power Flow', icon: 'account_tree' },
    { id: 'GENERATION', label: 'Generation (Mode A)', icon: 'solar_power' },
    { id: 'AUGMENTATION', label: 'Hybrid Augment (Mode C)', icon: 'tune' },
    { id: 'BUS', label: 'DC Bus', icon: 'linear_scale' },
    { id: 'STORAGE', label: 'Storage Boost (Mode B)', icon: 'battery_charging_full' },
    { id: 'THERMAL', label: 'Thermal & Radiator', icon: 'thermostat' },
    { id: 'LOADS', label: 'Loads', icon: 'power' },
    { id: 'ENVELOPE', label: 'Power Envelope', icon: 'area_chart' },
    { id: 'DIGITAL_TWIN', label: 'Digital Twin Observer', icon: 'sensors' },
    { id: 'FAULT_INJECTION', label: 'Fault Matrix', icon: 'warning' },
    { id: 'MONTE_CARLO', label: 'Monte Carlo', icon: 'casino' },
    { id: 'SENSITIVITY', label: 'Sensitivity (Tornado)', icon: 'bar_chart' },
    { id: 'OPTIMISATION', label: 'Pareto Optimizer', icon: 'insights' },
    { id: 'SCENARIOS', label: '12 Scenarios', icon: 'list_alt' },
    { id: 'TELEMETRY', label: 'Telemetry Replay', icon: 'timeline' },
    { id: 'VALIDATION', label: 'Physics & Convergence', icon: 'verified' },
    { id: 'REPORTS', label: 'Engineering Report', icon: 'summarize' },
    { id: 'R_PACKAGE', label: 'R Repository', icon: 'folder_zip' }
  ];
}
