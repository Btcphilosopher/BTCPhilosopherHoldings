import { Component, ChangeDetectionStrategy, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { PowerSystemService } from '../../services/power-system.service';

@Component({
  selector: 'app-generation',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-6">
      <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-200 pb-4">
        <div>
          <h1 class="text-xl font-bold text-slate-900 tracking-tight font-tech">
            Primary Generation Model (Mode A: Generation Augmentation)
          </h1>
          <p class="text-xs text-slate-500 font-mono mt-0.5">
            Primary Power Source · Thermal Derating Model η(T) = η_0 · [1 - γ · (T - T_ref)] · Health
          </p>
        </div>
      </div>

      <div class="grid grid-cols-1 md:grid-cols-2 gap-6 font-mono text-xs">
        <div class="bg-white border border-slate-200 rounded-lg p-5 shadow-xs space-y-4">
          <h2 class="font-bold text-slate-900 uppercase border-b border-slate-100 pb-2">
            Primary Generator Parameters
          </h2>

          <div>
            <div class="text-slate-500 flex justify-between">
              <span>Baseline Generation Capacity</span>
              <span class="font-bold text-slate-900">{{ gen().baseline_power.val / 1e6 | number:'1.2-2' }} MW</span>
            </div>
            <input
              type="range"
              min="500000"
              max="5000000"
              step="50000"
              [value]="gen().baseline_power.val"
              (input)="updateParam('baseline_power', $event)"
              class="w-full mt-1 accent-slate-900 cursor-pointer" />
          </div>

          <div>
            <div class="text-slate-500 flex justify-between">
              <span>Augmented Max Generation Capacity</span>
              <span class="font-bold text-slate-900">{{ gen().augmented_power.val / 1e6 | number:'1.2-2' }} MW</span>
            </div>
            <input
              type="range"
              min="1000000"
              max="8000000"
              step="100000"
              [value]="gen().augmented_power.val"
              (input)="updateParam('augmented_power', $event)"
              class="w-full mt-1 accent-slate-900 cursor-pointer" />
          </div>

          <div>
            <div class="text-slate-500 flex justify-between">
              <span>Nominal Conversion Efficiency (η_0)</span>
              <span class="font-bold text-slate-900">{{ (gen().efficiency_0.val * 100) | number:'1.1-1' }}%</span>
            </div>
            <input
              type="range"
              min="0.70"
              max="0.99"
              step="0.005"
              [value]="gen().efficiency_0.val"
              (input)="updateParam('efficiency_0', $event)"
              class="w-full mt-1 accent-slate-900 cursor-pointer" />
          </div>

          <div>
            <div class="text-slate-500 flex justify-between">
              <span>Health / Degradation Factor</span>
              <span class="font-bold text-slate-900">{{ (gen().health.val * 100) | number:'1.0-0' }}%</span>
            </div>
            <input
              type="range"
              min="0.50"
              max="1.0"
              step="0.01"
              [value]="gen().health.val"
              (input)="updateParam('health', $event)"
              class="w-full mt-1 accent-slate-900 cursor-pointer" />
          </div>
        </div>

        <div class="bg-white border border-slate-200 rounded-lg p-5 shadow-xs space-y-3">
          <h2 class="font-bold text-slate-900 uppercase border-b border-slate-100 pb-2">
            Mode A Generation Augmentation Calculation
          </h2>
          <p class="text-slate-600 leading-relaxed">
            Mode A increases available continuous generation capacity at the source (e.g. throttling nuclear reactor control rods or unfolding solar array wings).
          </p>
          <div class="bg-slate-50 p-3 rounded space-y-1">
            <div class="flex justify-between"><span>P_baseline:</span><span class="font-bold">{{ gen().baseline_power.val / 1e6 | number:'1.2-2' }} MW</span></div>
            <div class="flex justify-between"><span>P_augmented:</span><span class="font-bold">{{ gen().augmented_power.val / 1e6 | number:'1.2-2' }} MW</span></div>
            <div class="flex justify-between border-t border-slate-200 pt-1 text-emerald-700 font-bold">
              <span>ΔP_generation:</span>
              <span>+{{ (gen().augmented_power.val - gen().baseline_power.val) / 1e6 | number:'1.2-2' }} MW</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  `
})
export class GenerationComponent {
  service = inject(PowerSystemService);
  gen = () => this.service.params().generation;

  updateParam(key: string, event: Event) {
    const val = parseFloat((event.target as HTMLInputElement).value);
    this.service.params.update((p) => {
      const copy = { ...p };
      (copy.generation as unknown as Record<string, { val: number }>)[key].val = val;
      return copy;
    });
    this.service.runFullSystemSimulation();
  }
}
