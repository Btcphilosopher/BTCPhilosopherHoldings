import { Component, ChangeDetectionStrategy, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { PowerSystemService } from '../../services/power-system.service';
import { InjectedFaults } from '../../core/digital-twin-engine';

@Component({
  selector: 'app-fault-injection',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-6">
      <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-200 pb-4">
        <div>
          <h1 class="text-xl font-bold text-slate-900 tracking-tight font-tech">
            Analytical Fault Injection Matrix & Rapid Deterioration Testing
          </h1>
          <p class="text-xs text-slate-500 font-mono mt-0.5">
            Inject Subsystem Degradation · Measure System Resilience & Observe State Estimation Innovation
          </p>
        </div>

        <button
          (click)="clearAllFaults()"
          class="px-3 py-1.5 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-md transition-colors flex items-center gap-1.5 self-start">
          <mat-icon class="text-sm! w-4! h-4!">cleaning_services</mat-icon>
          <span>Reset All Injected Faults</span>
        </button>
      </div>

      <!-- Fault Injection Switches Grid -->
      <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        @for (f of faultItems; track f.key) {
          <div
            class="bg-white border rounded-lg p-4 shadow-xs transition-colors flex flex-col justify-between"
            [class.border-rose-300]="isFaultActive(f.key)"
            [class.bg-rose-50/30]="isFaultActive(f.key)"
            [class.border-slate-200]="!isFaultActive(f.key)">
            <div>
              <div class="flex items-center justify-between">
                <span class="text-xs font-bold font-mono text-slate-900">{{ f.title }}</span>
                <span
                  class="text-[10px] font-mono px-2 py-0.5 rounded font-bold uppercase"
                  [class.bg-rose-100]="isFaultActive(f.key)"
                  [class.text-rose-800]="isFaultActive(f.key)"
                  [class.bg-slate-100]="!isFaultActive(f.key)"
                  [class.text-slate-500]="!isFaultActive(f.key)">
                  {{ isFaultActive(f.key) ? 'INJECTED' : 'INACTIVE' }}
                </span>
              </div>
              <p class="text-xs text-slate-600 mt-2 font-mono leading-relaxed">{{ f.description }}</p>
            </div>

            <div class="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between">
              <span class="text-[11px] font-mono text-slate-400">{{ f.impact }}</span>
              <button
                (click)="toggleFault(f.key)"
                class="px-3 py-1 text-xs font-medium rounded transition-colors"
                [class.bg-rose-700]="isFaultActive(f.key)"
                [class.text-white]="isFaultActive(f.key)"
                [class.bg-slate-900]="!isFaultActive(f.key)"
                [class.text-white]="!isFaultActive(f.key)">
                {{ isFaultActive(f.key) ? 'Remove Fault' : 'Inject Fault' }}
              </button>
            </div>
          </div>
        }
      </div>

      <!-- System Resilience Assessment Card -->
      <div class="bg-white border border-slate-200 rounded-lg p-4 shadow-xs">
        <h2 class="text-xs font-semibold text-slate-900 uppercase font-mono tracking-wider border-b border-slate-100 pb-2">
          Subsystem Deterioration Diagnostic Summary
        </h2>
        <div class="mt-3 text-xs font-mono text-slate-700 space-y-2">
          <p>● Generator Efficiency Penalty: Reduces net conversion ratio η_gen to 79.9%, elevating generator internal heat generation Q_loss by +15%.</p>
          <p>● Bus Resistance Surge: Harness degradation to 0.0090 Ω causes distribution losses P_loss = I²·R to triple, dropping bus voltage to 275 V.</p>
          <p>● Battery Capacity Fade: Retains only 65% capacity, reducing usable peak discharge boost duration from 15 minutes to 4.2 minutes.</p>
        </div>
      </div>
    </div>
  `
})
export class FaultInjectionComponent {
  service = inject(PowerSystemService);

  readonly faultItems: { key: keyof InjectedFaults; title: string; description: string; impact: string }[] = [
    { key: 'generator_efficiency_drop', title: '01. Generator Efficiency Drop', description: 'Simulate nuclear thermoelectric array thermal degradation, dropping conversion efficiency by 15%.', impact: 'P_loss +15%, T_gen surge' },
    { key: 'converter_efficiency_drop', title: '02. Converter Semiconductor Aging', description: 'Simulate switching transistor gate wear and thermal resistance increase in SiC bridge.', impact: 'η_conv -7%, Q_conv +25 kW' },
    { key: 'bus_resistance_increase', title: '03. DC Harness Connector Surge', description: 'Simulate cable harness joint oxidation or micro-fracture increasing R_bus to 0.0090 Ω.', impact: 'Bus I²R loss +220%' },
    { key: 'storage_capacity_loss', title: '04. Battery Cell Capacity Fade', description: 'Simulate battery capacity retention drop to 65% with elevated internal ESR resistance.', impact: 'Peak boost duration -68%' },
    { key: 'radiator_fouling', title: '06. Radiator Coating Erosion', description: 'Simulate space debris / micro-meteorite erosion reducing emissivity ε to 0.68.', impact: 'Radiator rejection -25%' }
  ];

  isFaultActive(key: keyof InjectedFaults): boolean {
    const faults = this.service.activeFaults();
    return !!faults[key];
  }

  toggleFault(key: keyof InjectedFaults) {
    this.service.toggleFault(key);
  }

  clearAllFaults() {
    this.service.activeFaults.set({});
    this.service.runFullSystemSimulation();
  }
}
