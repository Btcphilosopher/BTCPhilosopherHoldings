import { Component, ChangeDetectionStrategy, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { PowerSystemService } from '../../services/power-system.service';

@Component({
  selector: 'app-sensitivity',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-6">
      <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-200 pb-4">
        <div>
          <h1 class="text-xl font-bold text-slate-900 tracking-tight font-tech">
            Sensitivity Analysis & Tornado Rankings: run_sensitivity_analysis()
          </h1>
          <p class="text-xs text-slate-500 font-mono mt-0.5">
            One-At-a-Time (OAT) ±10% Perturbations · Parameter Elasticities & Usable Power Swing Rankings
          </p>
        </div>

        <button
          (click)="service.runSensitivity(0.10)"
          class="px-3 py-1.5 text-xs font-medium text-white bg-slate-900 rounded-md hover:bg-slate-800 transition-colors flex items-center gap-1.5 self-start">
          <mat-icon class="text-sm! w-4! h-4!">bar_chart</mat-icon>
          <span>Recompute Sensitivity</span>
        </button>
      </div>

      <!-- Tornado Plot Graphical View -->
      @let sens = service.sensitivityResult();
      @if (sens) {
        <div class="bg-white border border-slate-200 rounded-lg p-6 shadow-xs">
          <h2 class="text-xs font-semibold text-slate-900 uppercase font-mono tracking-wider mb-4">
            Tornado Chart: Usable Power Swing (MW) under ±10% Parameter Shift
          </h2>

          <div class="space-y-3 font-mono text-xs">
            @for (item of sens.tornado; track item.param_id) {
              <div>
                <div class="flex justify-between text-slate-700 font-medium mb-1">
                  <span>{{ item.param_name }}</span>
                  <span class="tabular-nums">Swing: ±{{ (item.power_swing_mw / 2) | number:'1.3-3' }} MW (Elasticity: {{ item.power_elasticity | number:'1.2-2' }})</span>
                </div>

                <!-- Tornado Bar -->
                <div class="w-full bg-slate-100 h-5 rounded overflow-hidden flex items-center relative">
                  <div class="w-1/2 flex justify-end pr-1 border-r border-slate-400">
                    <div
                      class="bg-rose-500 h-3.5 rounded-l"
                      [style.width.%]="Math.min(100, (item.power_swing_mw / 0.5) * 100)"></div>
                  </div>
                  <div class="w-1/2 flex justify-start pl-1">
                    <div
                      class="bg-emerald-600 h-3.5 rounded-r"
                      [style.width.%]="Math.min(100, (item.power_swing_mw / 0.5) * 100)"></div>
                  </div>
                </div>
              </div>
            }
          </div>
        </div>

        <!-- Sensitivity Table -->
        <div class="bg-white border border-slate-200 rounded-lg overflow-hidden shadow-xs">
          <div class="p-4 border-b border-slate-100 flex items-center justify-between">
            <h2 class="text-xs font-semibold text-slate-900 uppercase font-mono tracking-wider">
              Parameter Sensitivity Ranking Table
            </h2>
            <span class="text-xs font-mono text-slate-500">Base Power: {{ sens.base_usable_power_mw | number:'1.2-2' }} MW</span>
          </div>

          <div class="overflow-x-auto">
            <table class="w-full text-xs font-mono">
              <thead class="bg-slate-50 text-slate-600 border-b border-slate-200">
                <tr>
                  <th class="py-2.5 px-4 text-left">Parameter</th>
                  <th class="py-2.5 px-3 text-right">Nominal</th>
                  <th class="py-2.5 px-3 text-right">-10% Low Power</th>
                  <th class="py-2.5 px-3 text-right">+10% High Power</th>
                  <th class="py-2.5 px-3 text-right">Power Swing</th>
                  <th class="py-2.5 px-3 text-right">Elasticity (dY/dX)</th>
                  <th class="py-2.5 px-3 text-right">Thermal Swing</th>
                </tr>
              </thead>
              <tbody class="divide-y divide-slate-100">
                @for (row of sens.tornado; track row.param_id) {
                  <tr class="hover:bg-slate-50/80">
                    <td class="py-2 px-4 font-semibold text-slate-900">{{ row.param_name }}</td>
                    <td class="py-2 px-3 text-right text-slate-600 tabular-nums">{{ row.nominal_val | number:'1.2-4' }} {{ row.unit }}</td>
                    <td class="py-2 px-3 text-right text-rose-600 tabular-nums">{{ row.power_low_mw | number:'1.3-3' }} MW</td>
                    <td class="py-2 px-3 text-right text-emerald-700 tabular-nums">{{ row.power_high_mw | number:'1.3-3' }} MW</td>
                    <td class="py-2 px-3 text-right font-bold text-slate-900 tabular-nums">±{{ (row.power_swing_mw / 2) | number:'1.3-3' }} MW</td>
                    <td class="py-2 px-3 text-right text-sky-800 tabular-nums font-semibold">{{ row.power_elasticity | number:'1.2-2' }}</td>
                    <td class="py-2 px-3 text-right text-slate-600 tabular-nums">±{{ (row.thermal_swing_pct / 2) | number:'1.1-1' }}%</td>
                  </tr>
                }
              </tbody>
            </table>
          </div>
        </div>
      }
    </div>
  `
})
export class SensitivityComponent {
  service = inject(PowerSystemService);
  Math = Math;
}
