import { Component, ChangeDetectionStrategy, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { PowerSystemService } from '../../services/power-system.service';

@Component({
  selector: 'app-telemetry',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-6">
      <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-200 pb-4">
        <div>
          <h1 class="text-xl font-bold text-slate-900 tracking-tight font-tech">
            Telemetry Channels, Real-Time Playback Scrubber & Export
          </h1>
          <p class="text-xs text-slate-500 font-mono mt-0.5">
            Multi-Channel Time-Series Inspection · Stream Scrubbing · Export to CSV, JSON, Parquet Structure
          </p>
        </div>

        <div class="flex items-center gap-2">
          <button
            (click)="service.downloadTelemetryCSV()"
            class="px-3 py-1.5 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-md transition-colors flex items-center gap-1.5">
            <mat-icon class="text-sm! w-4! h-4!">download</mat-icon>
            <span>Export CSV</span>
          </button>
          <button
            (click)="service.downloadTelemetryJSON()"
            class="px-3 py-1.5 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-md transition-colors flex items-center gap-1.5">
            <mat-icon class="text-sm! w-4! h-4!">code</mat-icon>
            <span>Export JSON</span>
          </button>
        </div>
      </div>

      <!-- Playback Scrubber Control Bar -->
      <div class="bg-white border border-slate-200 rounded-lg p-4 shadow-xs flex flex-col sm:flex-row items-center gap-4">
        <button
          (click)="service.togglePlayback()"
          class="w-10 h-10 rounded-full bg-slate-900 text-white flex items-center justify-center hover:bg-slate-800 transition-colors shrink-0">
          <mat-icon class="text-base! w-5! h-5!">
            {{ service.isPlaying() ? 'pause' : 'play_arrow' }}
          </mat-icon>
        </button>

        <div class="flex-1 w-full space-y-1">
          <div class="flex justify-between text-xs font-mono text-slate-600">
            <span>SCRUBBER: T+{{ (latest()?.time || 0) | number:'1.1-1' }}s</span>
            <span>TOTAL: {{ (maxTime() || 0) | number:'1.0-0' }}s</span>
          </div>
          <input
            type="range"
            min="0"
            [max]="maxIndex()"
            [value]="service.playbackIndex()"
            (input)="onScrub($event)"
            class="w-full accent-slate-900 cursor-pointer" />
        </div>
      </div>

      <!-- Key Telemetry Graphs -->
      <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
        <!-- Power Output Trajectory -->
        <div class="bg-white border border-slate-200 rounded-lg p-5 shadow-xs">
          <h2 class="text-xs font-semibold text-slate-900 uppercase font-mono tracking-wider mb-3">
            Power Trajectory (MW) vs Time
          </h2>

          <div class="w-full overflow-x-auto">
            <svg viewBox="0 0 500 180" class="w-full min-w-[350px] font-mono select-none">
              <line x1="40" y1="20" x2="40" y2="150" stroke="#cbd5e1" stroke-width="1" />
              <line x1="40" y1="150" x2="480" y2="150" stroke="#cbd5e1" stroke-width="1" />

              <text x="35" y="25" text-anchor="end" font-size="8" fill="#64748b">3.0 MW</text>
              <text x="35" y="85" text-anchor="end" font-size="8" fill="#64748b">1.5 MW</text>
              <text x="35" y="150" text-anchor="end" font-size="8" fill="#64748b">0 MW</text>

              <!-- Polyline Usable Power -->
              <polyline
                [attr.points]="powerPoints()"
                fill="none"
                stroke="#0f172a"
                stroke-width="2" />

              <!-- Polyline Demand -->
              <polyline
                [attr.points]="demandPoints()"
                fill="none"
                stroke="#e11d48"
                stroke-width="1.5"
                stroke-dasharray="3,3" />
            </svg>
          </div>
          <div class="flex items-center gap-4 text-xs font-mono mt-2 justify-center">
            <span class="text-slate-900 font-bold">─ P_usable</span>
            <span class="text-rose-600 font-bold">┈ P_demand</span>
          </div>
        </div>

        <!-- Component Temperatures Trajectory -->
        <div class="bg-white border border-slate-200 rounded-lg p-5 shadow-xs">
          <h2 class="text-xs font-semibold text-slate-900 uppercase font-mono tracking-wider mb-3">
            Subsystem Temperatures (K) vs Time
          </h2>

          <div class="w-full overflow-x-auto">
            <svg viewBox="0 0 500 180" class="w-full min-w-[350px] font-mono select-none">
              <line x1="40" y1="20" x2="40" y2="150" stroke="#cbd5e1" stroke-width="1" />
              <line x1="40" y1="150" x2="480" y2="150" stroke="#cbd5e1" stroke-width="1" />

              <text x="35" y="25" text-anchor="end" font-size="8" fill="#64748b">500 K</text>
              <text x="35" y="85" text-anchor="end" font-size="8" fill="#64748b">350 K</text>
              <text x="35" y="150" text-anchor="end" font-size="8" fill="#64748b">200 K</text>

              <polyline [attr.points]="tempGenPoints()" fill="none" stroke="#e11d48" stroke-width="1.8" />
              <polyline [attr.points]="tempConvPoints()" fill="none" stroke="#0284c7" stroke-width="1.8" />
              <polyline [attr.points]="tempStorPoints()" fill="none" stroke="#059669" stroke-width="1.8" />
            </svg>
          </div>
          <div class="flex items-center gap-4 text-xs font-mono mt-2 justify-center">
            <span class="text-rose-600 font-bold">─ T_generator</span>
            <span class="text-sky-600 font-bold">─ T_converter</span>
            <span class="text-emerald-600 font-bold">─ T_storage</span>
          </div>
        </div>
      </div>
    </div>
  `
})
export class TelemetryComponent {
  service = inject(PowerSystemService);
  latest = this.service.latestTelemetry;

  maxIndex = () => (this.service.simResult()?.telemetry.length || 1) - 1;
  maxTime = () => this.service.simResult()?.telemetry[this.maxIndex()]?.time || 600;

  onScrub(event: Event) {
    const input = event.target as HTMLInputElement;
    this.service.seekPlayback(parseInt(input.value, 10));
  }

  powerPoints = () => {
    const tel = this.service.simResult()?.telemetry;
    if (!tel || !tel.length) return '';
    const step = Math.max(1, Math.floor(tel.length / 100));
    return tel
      .filter((_, idx) => idx % step === 0)
      .map((pt, i) => {
        const x = 40 + i * (440 / 100);
        const y = 150 - (pt.p_usable / 3.0e6) * 130;
        return `${x},${y}`;
      })
      .join(' ');
  };

  demandPoints = () => {
    const tel = this.service.simResult()?.telemetry;
    if (!tel || !tel.length) return '';
    const step = Math.max(1, Math.floor(tel.length / 100));
    return tel
      .filter((_, idx) => idx % step === 0)
      .map((pt, i) => {
        const x = 40 + i * (440 / 100);
        const y = 150 - (pt.p_demand / 3.0e6) * 130;
        return `${x},${y}`;
      })
      .join(' ');
  };

  tempGenPoints = () => {
    const tel = this.service.simResult()?.telemetry;
    if (!tel || !tel.length) return '';
    const step = Math.max(1, Math.floor(tel.length / 100));
    return tel
      .filter((_, idx) => idx % step === 0)
      .map((pt, i) => {
        const x = 40 + i * (440 / 100);
        const y = 150 - ((pt.t_generator - 200) / 300.0) * 130;
        return `${x},${y}`;
      })
      .join(' ');
  };

  tempConvPoints = () => {
    const tel = this.service.simResult()?.telemetry;
    if (!tel || !tel.length) return '';
    const step = Math.max(1, Math.floor(tel.length / 100));
    return tel
      .filter((_, idx) => idx % step === 0)
      .map((pt, i) => {
        const x = 40 + i * (440 / 100);
        const y = 150 - ((pt.t_converter - 200) / 300.0) * 130;
        return `${x},${y}`;
      })
      .join(' ');
  };

  tempStorPoints = () => {
    const tel = this.service.simResult()?.telemetry;
    if (!tel || !tel.length) return '';
    const step = Math.max(1, Math.floor(tel.length / 100));
    return tel
      .filter((_, idx) => idx % step === 0)
      .map((pt, i) => {
        const x = 40 + i * (440 / 100);
        const y = 150 - ((pt.t_storage - 200) / 300.0) * 130;
        return `${x},${y}`;
      })
      .join(' ');
  };
}
