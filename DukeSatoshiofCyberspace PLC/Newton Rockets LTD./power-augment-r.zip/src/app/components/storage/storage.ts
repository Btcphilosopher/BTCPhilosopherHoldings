import { Component, ChangeDetectionStrategy, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { PowerSystemService } from '../../services/power-system.service';

@Component({
  selector: 'app-storage',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-6 font-mono text-xs">
      <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-200 pb-4">
        <div>
          <h1 class="text-xl font-bold text-slate-900 tracking-tight font-tech">
            Energy Storage Buffer Model (Mode B: Temporary Peak Storage Boost)
          </h1>
          <p class="text-xs text-slate-500 font-mono mt-0.5">
            Electrochemical / Supercapacitor Matrix · Distinguish Sustainable Power from Peak Power
          </p>
        </div>
      </div>

      <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div class="bg-white border border-slate-200 rounded-lg p-5 shadow-xs space-y-4">
          <h2 class="font-bold text-slate-900 uppercase border-b border-slate-100 pb-2">
            Storage Parameters
          </h2>

          <div>
            <div class="text-slate-500 flex justify-between">
              <span>Total Energy Capacity</span>
              <span class="font-bold text-slate-900">{{ (stor().capacity_total_j.val / 1e6) | number:'1.0-0' }} MJ (500 kWh)</span>
            </div>
            <input
              type="range"
              min="200000000"
              max="5000000000"
              step="100000000"
              [value]="stor().capacity_total_j.val"
              (input)="updateParam('capacity_total_j', $event)"
              class="w-full mt-1 accent-slate-900 cursor-pointer" />
          </div>

          <div>
            <div class="text-slate-500 flex justify-between">
              <span>Max Discharge Power Rating</span>
              <span class="font-bold text-slate-900">{{ (stor().max_discharge_power.val / 1e6) | number:'1.2-2' }} MW</span>
            </div>
            <input
              type="range"
              min="200000"
              max="3000000"
              step="50000"
              [value]="stor().max_discharge_power.val"
              (input)="updateParam('max_discharge_power', $event)"
              class="w-full mt-1 accent-slate-900 cursor-pointer" />
          </div>

          <div>
            <div class="text-slate-500 flex justify-between">
              <span>Internal ESR Resistance</span>
              <span class="font-bold text-slate-900">{{ (stor().internal_resistance.val * 1000) | number:'1.2-2' }} mΩ</span>
            </div>
            <input
              type="range"
              min="0.0005"
              max="0.015"
              step="0.0005"
              [value]="stor().internal_resistance.val"
              (input)="updateParam('internal_resistance', $event)"
              class="w-full mt-1 accent-slate-900 cursor-pointer" />
          </div>

          <div>
            <div class="text-slate-500 flex justify-between">
              <span>Initial State of Charge (SOC)</span>
              <span class="font-bold text-slate-900">{{ (stor().soc_initial.val * 100) | number:'1.0-0' }}%</span>
            </div>
            <input
              type="range"
              min="0.15"
              max="1.0"
              step="0.05"
              [value]="stor().soc_initial.val"
              (input)="updateParam('soc_initial', $event)"
              class="w-full mt-1 accent-slate-900 cursor-pointer" />
          </div>
        </div>

        <div class="bg-white border border-slate-200 rounded-lg p-5 shadow-xs space-y-3">
          <h2 class="font-bold text-slate-900 uppercase border-b border-slate-100 pb-2">
            Peak vs Sustainable Power Distinction
          </h2>
          <p class="text-slate-600 leading-relaxed">
            A 500 kW increase available for 20 seconds is not equivalent to a 500 kW continuous increase.
          </p>

          <div class="bg-slate-50 p-3 rounded space-y-2">
            <div class="flex justify-between"><span>Current SOC:</span><span class="font-bold text-slate-900">{{ ((latest()?.soc || 0.9) * 100) | number:'1.1-1' }}%</span></div>
            <div class="flex justify-between"><span>Active Discharge Rate:</span><span class="font-bold text-emerald-700">{{ (latest()?.p_stor_disch || 0) / 1e6 | number:'1.2-2' }} MW</span></div>
            <div class="flex justify-between"><span>ESR Loss P_loss = I²·R_esr:</span><span class="font-bold text-rose-700">{{ (latest()?.p_stor_loss || 0) / 1e3 | number:'1.1-1' }} kW</span></div>
          </div>
        </div>
      </div>
    </div>
  `
})
export class StorageComponent {
  service = inject(PowerSystemService);
  stor = () => this.service.params().storage;
  latest = this.service.latestTelemetry;

  updateParam(key: string, event: Event) {
    const val = parseFloat((event.target as HTMLInputElement).value);
    this.service.params.update((p) => {
      const copy = { ...p };
      (copy.storage as unknown as Record<string, { val: number }>)[key].val = val;
      return copy;
    });
    this.service.runFullSystemSimulation();
  }
}
