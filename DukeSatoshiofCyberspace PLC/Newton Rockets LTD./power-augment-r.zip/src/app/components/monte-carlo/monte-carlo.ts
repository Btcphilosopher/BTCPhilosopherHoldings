import { Component, ChangeDetectionStrategy, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { PowerSystemService } from '../../services/power-system.service';

@Component({
  selector: 'app-monte-carlo',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-6">
      <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-200 pb-4">
        <div>
          <h1 class="text-xl font-bold text-slate-900 tracking-tight font-tech">
            Stochastic Monte Carlo Uncertainty Propagation Engine: run_monte_carlo()
          </h1>
          <p class="text-xs text-slate-500 font-mono mt-0.5">
            Randomize Uncertain Parameters (η_gen, η_conv, R_bus, ESR, A_rad, T_env) · Probability Distributions & Quantiles
          </p>
        </div>

        <div class="flex items-center gap-2">
          <button
            (click)="service.runMonteCarlo(300)"
            class="px-3 py-1.5 text-xs font-medium text-white bg-slate-900 rounded-md hover:bg-slate-800 transition-colors flex items-center gap-1.5">
            <mat-icon class="text-sm! w-4! h-4!">casino</mat-icon>
            <span>Run 300 Iterations</span>
          </button>
          <button
            (click)="service.runMonteCarlo(1000)"
            class="px-3 py-1.5 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-md transition-colors flex items-center gap-1.5">
            <span>Run 1,000 Iterations</span>
          </button>
        </div>
      </div>

      <!-- Quantile Summary Cards (P10, P50 Median, P90, P99) -->
      @let mc = service.monteCarloResult();
      @if (mc) {
        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <!-- Usable Power Quantiles -->
          <div class="bg-white border border-slate-200 rounded-lg p-4 shadow-xs">
            <div class="text-slate-400 uppercase text-[10px] font-mono tracking-wider">Usable Power Distribution</div>
            <div class="mt-2 text-2xl font-bold font-mono tabular-nums text-slate-900">
              {{ mc.distributions.usable_power.p50 | number:'1.2-2' }} <span class="text-xs text-slate-400 font-normal">MW (P50)</span>
            </div>
            <div class="mt-3 space-y-1 text-xs font-mono text-slate-600 border-t border-slate-100 pt-2">
              <div class="flex justify-between"><span>P10 (Conservative):</span><span class="font-bold tabular-nums">{{ mc.distributions.usable_power.p10 | number:'1.2-2' }} MW</span></div>
              <div class="flex justify-between"><span>P90 (Optimistic):</span><span class="font-bold tabular-nums">{{ mc.distributions.usable_power.p90 | number:'1.2-2' }} MW</span></div>
              <div class="flex justify-between"><span>Std Dev (σ):</span><span class="tabular-nums">±{{ mc.distributions.usable_power.sd | number:'1.3-3' }} MW</span></div>
            </div>
          </div>

          <!-- Power Gain Quantiles -->
          <div class="bg-white border border-slate-200 rounded-lg p-4 shadow-xs">
            <div class="text-slate-400 uppercase text-[10px] font-mono tracking-wider">Net Power Gain ΔP</div>
            <div class="mt-2 text-2xl font-bold font-mono tabular-nums text-emerald-700">
              +{{ mc.distributions.power_gain.p50 | number:'1.2-2' }} <span class="text-xs text-slate-400 font-normal">MW</span>
            </div>
            <div class="mt-3 space-y-1 text-xs font-mono text-slate-600 border-t border-slate-100 pt-2">
              <div class="flex justify-between"><span>P10:</span><span class="font-bold tabular-nums">+{{ mc.distributions.power_gain.p10 | number:'1.2-2' }} MW</span></div>
              <div class="flex justify-between"><span>P90:</span><span class="font-bold tabular-nums">+{{ mc.distributions.power_gain.p90 | number:'1.2-2' }} MW</span></div>
              <div class="flex justify-between"><span>Mean:</span><span class="tabular-nums">+{{ mc.distributions.power_gain.mean | number:'1.2-2' }} MW</span></div>
            </div>
          </div>

          <!-- Thermal Margin Quantiles -->
          <div class="bg-white border border-slate-200 rounded-lg p-4 shadow-xs">
            <div class="text-slate-400 uppercase text-[10px] font-mono tracking-wider">Thermal Margin Probability</div>
            <div class="mt-2 text-2xl font-bold font-mono tabular-nums text-slate-900">
              {{ mc.distributions.thermal_margin.p50 | number:'1.1-1' }} <span class="text-xs text-slate-400 font-normal">%</span>
            </div>
            <div class="mt-3 space-y-1 text-xs font-mono text-slate-600 border-t border-slate-100 pt-2">
              <div class="flex justify-between"><span>P10 (Thermal Floor):</span><span class="font-bold tabular-nums text-amber-600">{{ mc.distributions.thermal_margin.p10 | number:'1.1-1' }}%</span></div>
              <div class="flex justify-between"><span>P90 (Headroom):</span><span class="font-bold tabular-nums text-emerald-700">{{ mc.distributions.thermal_margin.p90 | number:'1.1-1' }}%</span></div>
              <div class="flex justify-between"><span>Min Observed:</span><span class="tabular-nums text-rose-600">{{ mc.distributions.thermal_margin.min | number:'1.1-1' }}%</span></div>
            </div>
          </div>

          <!-- Total Electrical Loss Quantiles -->
          <div class="bg-white border border-slate-200 rounded-lg p-4 shadow-xs">
            <div class="text-slate-400 uppercase text-[10px] font-mono tracking-wider">Total Electrical Losses</div>
            <div class="mt-2 text-2xl font-bold font-mono tabular-nums text-slate-900">
              {{ mc.distributions.total_losses.p50 | number:'1.0-0' }} <span class="text-xs text-slate-400 font-normal">kW</span>
            </div>
            <div class="mt-3 space-y-1 text-xs font-mono text-slate-600 border-t border-slate-100 pt-2">
              <div class="flex justify-between"><span>P10 (Best Case):</span><span class="font-bold tabular-nums">{{ mc.distributions.total_losses.p10 | number:'1.0-0' }} kW</span></div>
              <div class="flex justify-between"><span>P90 (Worst Case):</span><span class="font-bold tabular-nums text-rose-600">{{ mc.distributions.total_losses.p90 | number:'1.0-0' }} kW</span></div>
              <div class="flex justify-between"><span>P99 Worst Spike:</span><span class="tabular-nums">{{ mc.distributions.total_losses.p99 | number:'1.0-0' }} kW</span></div>
            </div>
          </div>
        </div>

        <!-- Histogram Visualization of Usable Power -->
        <div class="bg-white border border-slate-200 rounded-lg p-6 shadow-xs">
          <h2 class="text-xs font-semibold text-slate-900 uppercase font-mono tracking-wider mb-4">
            Usable Power Probability Density Function ({{ mc.n_iterations }} Monte Carlo Samples)
          </h2>

          <div class="w-full overflow-x-auto">
            <svg viewBox="0 0 700 200" class="w-full min-w-[550px] font-mono select-none">
              <!-- Histogram Bars -->
              @for (bin of mc.distributions.usable_power.histogram; track bin.binStart; let idx = $index) {
                @let barHeight = (bin.count / 35.0) * 140;
                <rect
                  [attr.x]="60 + idx * 42"
                  [attr.y]="170 - barHeight"
                  width="38"
                  [attr.height]="barHeight"
                  fill="#0284c7"
                  opacity="0.8"
                  rx="1" />
                <text
                  [attr.x]="60 + idx * 42 + 19"
                  [attr.y]="165 - barHeight"
                  text-anchor="middle"
                  font-size="8"
                  fill="#0369a1"
                  font-weight="bold">
                  {{ bin.count }}
                </text>
                <text
                  [attr.x]="60 + idx * 42 + 19"
                  y="185"
                  text-anchor="middle"
                  font-size="8"
                  fill="#64748b">
                  {{ bin.binStart | number:'1.2-2' }}
                </text>
              }
              <line x1="50" y1="170" x2="680" y2="170" stroke="#cbd5e1" stroke-width="1" />
            </svg>
          </div>
        </div>
      }
    </div>
  `
})
export class MonteCarloComponent {
  service = inject(PowerSystemService);
  Math = Math;
}
