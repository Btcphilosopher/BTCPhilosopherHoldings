import { Component, ChangeDetectionStrategy, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { PowerSystemService } from '../../services/power-system.service';
import { AugmentationStrategy } from '../../core/physics-engine';

@Component({
  selector: 'app-augmentation',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-6">
      <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-200 pb-4">
        <div>
          <h1 class="text-xl font-bold text-slate-900 tracking-tight font-tech">
            Hybrid Power Augmentation (Mode C: Combined Generation & Storage)
          </h1>
          <p class="text-xs text-slate-500 font-mono mt-0.5">
            P_total = P_generation + P_storage - P_losses · Configurable Operating Dispatch Strategies
          </p>
        </div>
      </div>

      <div class="grid grid-cols-1 md:grid-cols-2 gap-6 font-mono text-xs">
        <div class="bg-white border border-slate-200 rounded-lg p-5 shadow-xs space-y-3">
          <h2 class="font-bold text-slate-900 uppercase border-b border-slate-100 pb-2">
            Select Active Augmentation Strategy
          </h2>

          <div class="space-y-2">
            @for (st of strategies; track st.id) {
              <button
                (click)="service.setStrategy(st.id)"
                class="w-full p-3 text-left rounded border transition-colors flex items-center justify-between"
                [class.border-slate-900]="service.params().strategy === st.id"
                [class.bg-slate-900]="service.params().strategy === st.id"
                [class.text-white]="service.params().strategy === st.id"
                [class.border-slate-200]="service.params().strategy !== st.id"
                [class.bg-slate-50]="service.params().strategy !== st.id"
                [class.text-slate-700]="service.params().strategy !== st.id">
                <div>
                  <div class="font-bold text-xs">{{ st.label }}</div>
                  <div class="text-[11px] opacity-80 mt-0.5">{{ st.desc }}</div>
                </div>
                @if (service.params().strategy === st.id) {
                  <mat-icon class="text-sm! w-4! h-4!">check_circle</mat-icon>
                }
              </button>
            }
          </div>
        </div>

        <div class="bg-white border border-slate-200 rounded-lg p-5 shadow-xs space-y-4">
          <h2 class="font-bold text-slate-900 uppercase border-b border-slate-100 pb-2">
            Strategy Dispatch Principles
          </h2>

          <p class="text-slate-600 leading-relaxed">
            These analysis modes model how generation capacity and stored energy are combined to satisfy time-varying spacecraft loads under physical constraints.
          </p>

          <div class="bg-slate-50 p-4 rounded border border-slate-200 space-y-2">
            <div class="font-bold text-slate-900">Current Strategy: {{ service.params().strategy }}</div>
            <p class="text-slate-600">
              Combines primary generation boost up to augmented rating with temporary high-rate battery buffer discharge during pulse maneuvers.
            </p>
          </div>
        </div>
      </div>
    </div>
  `
})
export class AugmentationComponent {
  service = inject(PowerSystemService);

  readonly strategies: { id: AugmentationStrategy; label: string; desc: string }[] = [
    { id: 'GENERATION_PLUS_STORAGE', label: '01. GENERATION_PLUS_STORAGE', desc: 'Ramp reactor capacity + discharge storage buffer on peak demand spikes.' },
    { id: 'GENERATION_ONLY', label: '02. GENERATION_ONLY', desc: 'Mode A: Increase generator output only, no battery storage contribution.' },
    { id: 'STORAGE_ONLY', label: '03. STORAGE_ONLY', desc: 'Mode B: Keep generation strictly baseline, boost peaks with battery.' },
    { id: 'STORAGE_PEAK_SHAVING', label: '04. STORAGE_PEAK_SHAVING', desc: 'Maintain steady base output, shave transient load spikes with storage.' },
    { id: 'CONSTANT_POWER', label: '05. CONSTANT_POWER', desc: 'Deliver fixed continuous augmented power regardless of load variations.' },
    { id: 'THERMAL_LIMITED', label: '06. THERMAL_LIMITED', desc: 'Automatically derate generation when radiator thermal margin drops < 25%.' },
    { id: 'STORAGE_LIFE_LIMITED', label: '07. STORAGE_LIFE_LIMITED', desc: 'Limit battery C-rate discharge to 0.45x max to prevent cycle degradation.' }
  ];
}
