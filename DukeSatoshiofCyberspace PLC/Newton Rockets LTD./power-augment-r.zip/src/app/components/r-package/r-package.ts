import { Component, ChangeDetectionStrategy, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { PowerSystemService } from '../../services/power-system.service';

@Component({
  selector: 'app-r-package',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-6">
      <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-200 pb-4">
        <div>
          <h1 class="text-xl font-bold text-slate-900 tracking-tight font-tech">
            R Package Source Repository Explorer: power-augment-r/
          </h1>
          <p class="text-xs text-slate-500 font-mono mt-0.5">
            Complete Executable R Library · R 4.x, deSolve, data.table, ggplot2, R6, testthat, CLI
          </p>
        </div>

        <button
          (click)="copyCode()"
          class="px-3 py-1.5 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-md transition-colors flex items-center gap-1.5 self-start">
          <mat-icon class="text-sm! w-4! h-4!">content_copy</mat-icon>
          <span>Copy Source Code</span>
        </button>
      </div>

      <div class="grid grid-cols-1 lg:grid-cols-4 gap-6">
        <!-- Directory Tree Navigation -->
        <div class="bg-white border border-slate-200 rounded-lg p-3 shadow-xs">
          <h2 class="text-xs font-semibold text-slate-900 uppercase font-mono tracking-wider mb-2 px-2 border-b border-slate-100 pb-1.5">
            Repository Files
          </h2>
          <div class="space-y-1 font-mono text-xs max-h-[500px] overflow-y-auto">
            @for (file of service.rPackageFiles(); track file) {
              <button
                (click)="service.fetchRFile(file)"
                class="w-full text-left px-2 py-1.5 rounded transition-colors flex items-center gap-2 truncate"
                [class.bg-slate-900]="service.selectedRFile()?.path === file"
                [class.text-white]="service.selectedRFile()?.path === file"
                [class.text-slate-700]="service.selectedRFile()?.path !== file"
                [class.hover:bg-slate-100]="service.selectedRFile()?.path !== file">
                <mat-icon class="text-xs! w-3.5! h-3.5! shrink-0">
                  {{ file.endsWith('.R') ? 'code' : file.endsWith('.json') ? 'data_object' : 'description' }}
                </mat-icon>
                <span class="truncate">{{ file }}</span>
              </button>
            }
          </div>
        </div>

        <!-- Code Viewer Panel -->
        <div class="lg:col-span-3 bg-slate-900 text-slate-100 rounded-lg p-4 shadow-sm font-mono text-xs flex flex-col justify-between overflow-hidden">
          <div class="border-b border-slate-800 pb-2 mb-3 flex items-center justify-between text-slate-400">
            <span>FILE: {{ service.selectedRFile()?.path || 'R/simulation.R' }}</span>
            <span class="text-[10px] uppercase">R 4.2+ Language</span>
          </div>

          <pre class="bg-slate-950 p-4 rounded border border-slate-800 text-slate-200 overflow-x-auto max-h-[520px] leading-relaxed select-text">{{ service.selectedRFile()?.content || '# Select an R file from the left tree' }}</pre>

          <div class="mt-3 pt-2 border-t border-slate-800 flex justify-between items-center text-[11px] text-slate-500">
            <span>power-augment-r R Package Architecture</span>
            <span>Executable in RStudio & Command Line</span>
          </div>
        </div>
      </div>
    </div>
  `
})
export class RPackageComponent {
  service = inject(PowerSystemService);

  copyCode() {
    const code = this.service.selectedRFile()?.content;
    if (code) {
      navigator.clipboard.writeText(code);
    }
  }
}
