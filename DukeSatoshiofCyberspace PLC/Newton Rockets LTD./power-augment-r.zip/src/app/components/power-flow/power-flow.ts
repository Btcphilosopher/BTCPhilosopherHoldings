import { Component, ChangeDetectionStrategy, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { PowerSystemService } from '../../services/power-system.service';

@Component({
  selector: 'app-power-flow',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-6">
      <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-200 pb-4">
        <div>
          <h1 class="text-xl font-bold text-slate-900 tracking-tight font-tech">
            Spacecraft Power Flow Topology & Single-Line Electrical Schematic
          </h1>
          <p class="text-xs text-slate-500 font-mono mt-0.5">
            Real-Time Energy Conservation Map · Generator → Conditioning → Main DC Rail → Loads & Storage
          </p>
        </div>

        <div class="flex items-center gap-3 text-xs font-mono">
          <span class="text-slate-500">SIMULATION TIME:</span>
          <span class="font-bold tabular-nums text-slate-900 bg-slate-100 px-2 py-1 rounded">
            T+{{ (latest()?.time || 0) | number:'1.1-1' }} s
          </span>
        </div>
      </div>

      <!-- Main Interactive Vector Diagram Canvas -->
      <div class="bg-white border border-slate-200 rounded-lg p-6 shadow-xs relative overflow-hidden">
        <div class="absolute top-3 right-3 text-[10px] font-mono text-slate-400">
          [ AEROSPACE ELECTRICAL SCHEMATIC · DRAWING DWG-APEX-PWR-001 ]
        </div>

        <!-- SVG Visual Diagram -->
        <div class="w-full overflow-x-auto">
          <svg viewBox="0 0 1000 480" class="w-full min-w-[850px] max-h-[500px] font-mono select-none">
            <defs>
              <!-- Flow Arrow Marker -->
              <marker id="arrow" viewBox="0 0 10 10" refX="6" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse">
                <path d="M 0 1 L 10 5 L 0 9 z" fill="#475569" />
              </marker>
              <marker id="arrow-emerald" viewBox="0 0 10 10" refX="6" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse">
                <path d="M 0 1 L 10 5 L 0 9 z" fill="#059669" />
              </marker>
              <marker id="arrow-cyan" viewBox="0 0 10 10" refX="6" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse">
                <path d="M 0 1 L 10 5 L 0 9 z" fill="#0891b2" />
              </marker>
              <marker id="arrow-rose" viewBox="0 0 10 10" refX="6" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse">
                <path d="M 0 1 L 10 5 L 0 9 z" fill="#e11d48" />
              </marker>
            </defs>

            <!-- 1. ENERGY SOURCE (Nuclear Reactor / Solar Array) -->
            <g class="cursor-pointer" (click)="selectedNode.set('SOURCE')">
              <rect x="30" y="80" width="140" height="90" rx="4" fill="#f8fafc" stroke="#334155" stroke-width="1.5" />
              <text x="100" y="105" text-anchor="middle" font-size="11" font-weight="bold" fill="#0f172a">ENERGY SOURCE</text>
              <text x="100" y="125" text-anchor="middle" font-size="9" fill="#64748b">Nuclear / Solar</text>
              <text x="100" y="150" text-anchor="middle" font-size="12" font-weight="bold" fill="#0f172a" class="tabular-nums">
                {{ (latest()?.p_gen_gross || 0) / 1e6 | number:'1.2-2' }} MW
              </text>
            </g>

            <!-- Line: Source -> Generation -->
            <path d="M 170 125 L 220 125" stroke="#334155" stroke-width="2" marker-end="url(#arrow)" />

            <!-- 2. PRIMARY GENERATION -->
            <g class="cursor-pointer" (click)="selectedNode.set('GENERATOR')">
              <rect x="220" y="80" width="150" height="90" rx="4" fill="#f8fafc" stroke="#0284c7" stroke-width="1.5" />
              <text x="295" y="105" text-anchor="middle" font-size="11" font-weight="bold" fill="#0369a1">GENERATOR</text>
              <text x="295" y="122" text-anchor="middle" font-size="9" fill="#64748b">η = 94.0% · 1200 V</text>
              <text x="295" y="142" text-anchor="middle" font-size="11" font-weight="bold" fill="#0f172a" class="tabular-nums">
                P_elec: {{ (latest()?.p_gen_elec || 0) / 1e6 | number:'1.2-2' }} MW
              </text>
              <text x="295" y="160" text-anchor="middle" font-size="9" fill="#e11d48">
                T: {{ (latest()?.t_generator || 0) | number:'1.1-1' }} K
              </text>
            </g>

            <!-- Line: Generator -> Converter -->
            <path d="M 370 125 L 420 125" stroke="#0284c7" stroke-width="2" marker-end="url(#arrow)" />

            <!-- 3. POWER CONVERTER -->
            <g class="cursor-pointer" (click)="selectedNode.set('CONVERTER')">
              <rect x="420" y="80" width="150" height="90" rx="4" fill="#f8fafc" stroke="#334155" stroke-width="1.5" />
              <text x="495" y="105" text-anchor="middle" font-size="11" font-weight="bold" fill="#0f172a">DC-DC CONVERTER</text>
              <text x="495" y="122" text-anchor="middle" font-size="9" fill="#64748b">η = 96.5% · Regulated</text>
              <text x="495" y="142" text-anchor="middle" font-size="11" font-weight="bold" fill="#0f172a" class="tabular-nums">
                P_out: {{ (latest()?.p_conv_out || 0) / 1e6 | number:'1.2-2' }} MW
              </text>
              <text x="495" y="160" text-anchor="middle" font-size="9" fill="#e11d48">
                T: {{ (latest()?.t_converter || 0) | number:'1.1-1' }} K
              </text>
            </g>

            <!-- Line: Converter -> DC Bus -->
            <path d="M 570 125 L 620 125" stroke="#334155" stroke-width="2" marker-end="url(#arrow)" />

            <!-- 4. MAIN DC POWER DISTRIBUTION BUS (Vertical Backbone) -->
            <g class="cursor-pointer" (click)="selectedNode.set('BUS')">
              <!-- Thick Bus Bar -->
              <rect x="620" y="40" width="18" height="380" rx="2" fill="#0f172a" />
              <text x="610" y="30" text-anchor="end" font-size="11" font-weight="bold" fill="#0f172a">MAIN DC BUS (300 V)</text>
              <text x="610" y="45" text-anchor="end" font-size="9" fill="#64748b" class="tabular-nums">
                V: {{ (latest()?.v_bus || 300) | number:'1.1-1' }} V · I: {{ (latest()?.i_bus || 0) | number:'1.0-0' }} A
              </text>
              <text x="610" y="60" text-anchor="end" font-size="9" fill="#e11d48" class="tabular-nums">
                Loss I²R: {{ (latest()?.p_bus_loss || 0) / 1e3 | number:'1.1-1' }} kW
              </text>
            </g>

            <!-- 5. SPACECRAFT LOADS (Branching Right from DC Bus) -->
            <!-- Propulsion Load -->
            <path d="M 638 90 L 710 90" stroke="#0f172a" stroke-width="2" marker-end="url(#arrow-emerald)" />
            <g class="cursor-pointer" (click)="selectedNode.set('PROPULSION')">
              <rect x="710" y="65" width="250" height="50" rx="4" fill="#f0fdf4" stroke="#059669" stroke-width="1.5" />
              <text x="720" y="85" font-size="10" font-weight="bold" fill="#065f46">PROPULSION (Arcjet / EP)</text>
              <text x="720" y="103" font-size="11" font-weight="bold" fill="#065f46" class="tabular-nums">
                Demand: {{ (service.loads()[0].nominal_power || 1.2e6) / 1e6 | number:'1.2-2' }} MW
              </text>
            </g>

            <!-- Avionics & GNC -->
            <path d="M 638 160 L 710 160" stroke="#0f172a" stroke-width="2" marker-end="url(#arrow)" />
            <g class="cursor-pointer" (click)="selectedNode.set('AVIONICS')">
              <rect x="710" y="135" width="250" height="50" rx="4" fill="#f8fafc" stroke="#64748b" stroke-width="1.2" />
              <text x="720" y="155" font-size="10" font-weight="bold" fill="#334155">AVIONICS & GNC (Priority 1)</text>
              <text x="720" y="173" font-size="11" font-weight="bold" fill="#0f172a" class="tabular-nums">
                45.0 kW
              </text>
            </g>

            <!-- Communications -->
            <path d="M 638 230 L 710 230" stroke="#0f172a" stroke-width="2" marker-end="url(#arrow)" />
            <g class="cursor-pointer" (click)="selectedNode.set('COMMS')">
              <rect x="710" y="205" width="250" height="50" rx="4" fill="#f8fafc" stroke="#64748b" stroke-width="1.2" />
              <text x="720" y="225" font-size="10" font-weight="bold" fill="#334155">COMMUNICATIONS (High Gain RF)</text>
              <text x="720" y="243" font-size="11" font-weight="bold" fill="#0f172a" class="tabular-nums">
                85.0 kW
              </text>
            </g>

            <!-- Science & Life Support -->
            <path d="M 638 300 L 710 300" stroke="#0f172a" stroke-width="2" marker-end="url(#arrow)" />
            <g class="cursor-pointer" (click)="selectedNode.set('SCIENCE')">
              <rect x="710" y="275" width="250" height="50" rx="4" fill="#f8fafc" stroke="#64748b" stroke-width="1.2" />
              <text x="720" y="295" font-size="10" font-weight="bold" fill="#334155">SCIENCE / PAYLOAD / ECLSS</text>
              <text x="720" y="313" font-size="11" font-weight="bold" fill="#0f172a" class="tabular-nums">
                415.0 kW Total
              </text>
            </g>

            <!-- Total Usable Power Delivery Readout -->
            <path d="M 638 370 L 710 370" stroke="#059669" stroke-width="2" marker-end="url(#arrow-emerald)" />
            <g>
              <rect x="710" y="345" width="250" height="50" rx="4" fill="#f8fafc" stroke="#0f172a" stroke-width="2" />
              <text x="720" y="365" font-size="10" font-weight="bold" fill="#0f172a">NET POWER DELIVERED</text>
              <text x="720" y="383" font-size="12" font-weight="bold" fill="#047857" class="tabular-nums">
                P_served: {{ (latest()?.p_served || 0) / 1e6 | number:'1.2-2' }} MW
              </text>
            </g>

            <!-- 6. ENERGY STORAGE (Bidirectional Buffer below Converter) -->
            <!-- Bidirectional arrow bus <-> storage -->
            <path d="M 620 390 L 495 390 L 495 350" stroke="#0891b2" stroke-width="2" marker-end="url(#arrow-cyan)" fill="none" />
            <g class="cursor-pointer" (click)="selectedNode.set('STORAGE')">
              <rect x="420" y="260" width="150" height="90" rx="4" fill="#ecfeff" stroke="#0891b2" stroke-width="1.5" />
              <text x="495" y="285" text-anchor="middle" font-size="11" font-weight="bold" fill="#0e7490">STORAGE BUFFER</text>
              <text x="495" y="302" text-anchor="middle" font-size="9" fill="#155e75">
                SOC: {{ ((latest()?.soc || 0.9) * 100) | number:'1.1-1' }}% · 1800 MJ
              </text>
              <text x="495" y="322" text-anchor="middle" font-size="11" font-weight="bold" fill="#0f172a" class="tabular-nums">
                {{ (latest()?.p_stor_disch || 0) > 0 ? 'Disch: +' + ((latest()?.p_stor_disch || 0) / 1e6 | number:'1.2-2') + ' MW' : 'Recharge / Idle' }}
              </text>
              <text x="495" y="340" text-anchor="middle" font-size="9" fill="#e11d48">
                T: {{ (latest()?.t_storage || 0) | number:'1.1-1' }} K
              </text>
            </g>

            <!-- 7. THERMAL NETWORK & RADIATOR (Below Storage & Generator) -->
            <!-- Heat arrows from nodes down to radiator -->
            <path d="M 295 170 L 295 240 L 200 240 L 200 280" stroke="#e11d48" stroke-dasharray="3,3" stroke-width="1.5" marker-end="url(#arrow-rose)" fill="none" />
            <g class="cursor-pointer" (click)="selectedNode.set('RADIATOR')">
              <rect x="50" y="280" width="220" height="110" rx="4" fill="#fff1f2" stroke="#e11d48" stroke-width="1.5" />
              <text x="160" y="305" text-anchor="middle" font-size="11" font-weight="bold" fill="#9f1239">THERMAL RADIATOR</text>
              <text x="160" y="322" text-anchor="middle" font-size="9" fill="#881337">
                Q_rad = ε·σ·A·(T⁴ - T_env⁴)
              </text>
              <text x="160" y="342" text-anchor="middle" font-size="11" font-weight="bold" fill="#e11d48" class="tabular-nums">
                Q_reject: {{ (latest()?.q_rad || 0) / 1e3 | number:'1.1-1' }} kW
              </text>
              <text x="160" y="360" text-anchor="middle" font-size="9" fill="#0f172a">
                T_rad: {{ (latest()?.t_radiator || 0) | number:'1.1-1' }} K · A: 65 m²
              </text>
              <text x="160" y="378" text-anchor="middle" font-size="9" font-weight="bold" fill="#047857">
                Thermal Margin: {{ ((latest()?.thermal_margin || 0) * 100) | number:'1.1-1' }}%
              </text>
            </g>
          </svg>
        </div>
      </div>

      <!-- Node Detail Inspector Card -->
      <div class="bg-white border border-slate-200 rounded-lg p-4 shadow-xs">
        <div class="flex items-center justify-between border-b border-slate-100 pb-2">
          <h2 class="text-xs font-semibold text-slate-900 uppercase font-mono tracking-wider">
            Subsystem Physical Diagnostics: {{ selectedNode() }}
          </h2>
          <span class="text-xs text-slate-400 font-mono">Click any block in the schematic above to inspect</span>
        </div>

        <div class="mt-3 text-xs font-mono text-slate-700 leading-relaxed">
          @switch (selectedNode()) {
            @case ('SOURCE') {
              <p>Primary Energy Source: Nuclear Fission Reactor / Solar Array Field providing gross input thermal/photovoltaic power. Gross rating: 2.40 MW gross capacity.</p>
            }
            @case ('GENERATOR') {
              <p>Primary Generation Subsystem: Converts primary source into regulated DC electrical power (1200 V). Electrical power: {{ (latest()?.p_gen_elec || 0) / 1e6 | number:'1.2-2' }} MW. Internal conversion losses: {{ (latest()?.p_gen_loss || 0) / 1e3 | number:'1.1-1' }} kW dissipated directly into generator thermal mass (C_th = 85,000 J/K).</p>
            }
            @case ('CONVERTER') {
              <p>DC-DC Conditioning Converter: Silicon-carbide solid-state bridge stepping down voltage to 300 V DC bus. Throughput: {{ (latest()?.p_conv_out || 0) / 1e6 | number:'1.2-2' }} MW. Switching & conduction loss: {{ (latest()?.p_conv_loss || 0) / 1e3 | number:'1.1-1' }} kW.</p>
            }
            @case ('BUS') {
              <p>Main DC Power Bus: High-conductivity aluminum harness rail operating at nominal 300 V. Current: {{ (latest()?.i_bus || 0) | number:'1.0-0' }} A. Total loop resistance R_bus = 0.0028 Ω. Distribution loss P_loss = I²·R = {{ (latest()?.p_bus_loss || 0) / 1e3 | number:'1.1-1' }} kW.</p>
            }
            @case ('STORAGE') {
              <p>Electrochemical Energy Storage Buffer (LiFePO4 / Supercapacitor matrix): 1800 MJ (500 kWh) total capacity. Provides instantaneous peak power discharge up to 1.2 MW to bridge pulse loads without stalling reactor.</p>
            }
            @case ('RADIATOR') {
              <p>Thermal Radiator Panel Network: Stefan-Boltzmann fourth-power radiation to deep space sink. Surface area A = 65 m², emissivity ε = 0.91. Radiative rejection capacity: {{ (latest()?.q_rad || 0) / 1e3 | number:'1.1-1' }} kW.</p>
            }
            @default {
              <p>Propulsion Load Interface: High-voltage pulsed inductive thruster / arcjet drawing primary electrical power to generate interplanetary thrust Δv.</p>
            }
          }
        </div>
      </div>
    </div>
  `
})
export class PowerFlowComponent {
  service = inject(PowerSystemService);
  latest = this.service.latestTelemetry;
  selectedNode = signal<string>('GENERATOR');
}
