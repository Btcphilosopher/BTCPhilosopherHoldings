import { Component, ChangeDetectionStrategy, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { PowerSystemService } from '../../services/power-system.service';

@Component({
  selector: 'app-loads',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-6 font-mono text-xs">
      <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-200 pb-4">
        <div>
          <h1 class="text-xl font-bold text-slate-900 tracking-tight font-tech">
            Spacecraft Subsystem Loads Management & Priority Shedding Matrix
          </h1>
          <p class="text-xs text-slate-500 font-mono mt-0.5">
            10 Subsystem Loads · Nominal, Min, Max Envelope · Priority Levels (1 = Essential, 5 = Shed First)
          </p>
        </div>
      </div>

      <div class="bg-white border border-slate-200 rounded-lg overflow-hidden shadow-xs">
        <div class="overflow-x-auto">
          <table class="w-full text-xs font-mono">
            <thead class="bg-slate-50 text-slate-600 border-b border-slate-200">
              <tr>
                <th class="py-2.5 px-4 text-center">Active</th>
                <th class="py-2.5 px-4 text-left">Subsystem Load Name</th>
                <th class="py-2.5 px-3 text-center">Priority</th>
                <th class="py-2.5 px-3 text-right">Nominal Power</th>
                <th class="py-2.5 px-3 text-right">Min Power</th>
                <th class="py-2.5 px-3 text-right">Max Power</th>
                <th class="py-2.5 px-3 text-right">Duty Cycle</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-slate-100">
              @for (item of service.loads(); track item.id) {
                <tr class="hover:bg-slate-50/80" [class.opacity-50]="!item.active">
                  <td class="py-2 px-4 text-center">
                    <input
                      type="checkbox"
                      [checked]="item.active"
                      (change)="service.toggleLoad(item.id)"
                      class="rounded accent-slate-900 cursor-pointer" />
                  </td>
                  <td class="py-2 px-4 font-semibold text-slate-900">{{ item.name }}</td>
                  <td class="py-2 px-3 text-center font-bold">
                    <span
                      class="px-2 py-0.5 rounded text-[10px]"
                      [class.bg-rose-100]="item.priority === 1"
                      [class.text-rose-800]="item.priority === 1"
                      [class.bg-slate-100]="item.priority > 1"
                      [class.text-slate-700]="item.priority > 1">
                      Priority {{ item.priority }}
                    </span>
                  </td>
                  <td class="py-2 px-3 text-right font-mono font-bold text-slate-900 tabular-nums">
                    {{ (item.nominal_power / 1e3) | number:'1.0-0' }} kW
                  </td>
                  <td class="py-2 px-3 text-right font-mono text-slate-500 tabular-nums">
                    {{ (item.min_power / 1e3) | number:'1.0-0' }} kW
                  </td>
                  <td class="py-2 px-3 text-right font-mono text-slate-500 tabular-nums">
                    {{ (item.max_power / 1e3) | number:'1.0-0' }} kW
                  </td>
                  <td class="py-2 px-3 text-right font-mono text-slate-700 tabular-nums">
                    {{ (item.duty_cycle * 100) | number:'1.0-0' }}%
                  </td>
                </tr>
              }
            </tbody>
          </table>
        </div>
      </div>
    </div>
  `
})
export class LoadsComponent {
  service = inject(PowerSystemService);
}
