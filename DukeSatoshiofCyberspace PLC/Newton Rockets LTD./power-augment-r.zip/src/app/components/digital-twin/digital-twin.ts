import { Component, ChangeDetectionStrategy, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { PowerSystemService } from '../../services/power-system.service';

@Component({
  selector: 'app-digital-twin',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-6">
      <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-200 pb-4">
        <div>
          <h1 class="text-xl font-bold text-slate-900 tracking-tight font-tech">
            Digital Twin Observer & Extended Kalman Filter (EKF) Pipeline
          </h1>
          <p class="text-xs text-slate-500 font-mono mt-0.5">
            Physical Model (x_true) → Sensor Transducers (z_m) → EKF State Estimator (x̂) → Innovation Residuals (e_t)
          </p>
        </div>

        <div class="flex items-center gap-2">
          <span class="text-xs font-mono text-slate-500">SYSTEM HEALTH:</span>
          @let status = currentFrame()?.health_status || 'NORMAL';
          <span
            class="text-xs font-mono font-bold px-2.5 py-1 rounded"
            [class.bg-emerald-100]="status === 'NORMAL'"
            [class.text-emerald-800]="status === 'NORMAL'"
            [class.bg-amber-100]="status === 'WARNING'"
            [class.text-amber-800]="status === 'WARNING'"
            [class.bg-purple-100]="status === 'LIMITED'"
            [class.text-purple-800]="status === 'LIMITED'"
            [class.bg-rose-100]="status === 'FAULT'"
            [class.text-rose-800]="status === 'FAULT'">
            ● {{ status }}
          </span>
        </div>
      </div>

      <!-- 3-Way State Comparison Table (True vs Measured vs Estimated) -->
      <div class="bg-white border border-slate-200 rounded-lg overflow-hidden shadow-xs">
        <div class="p-4 border-b border-slate-100 flex items-center justify-between">
          <h2 class="text-xs font-semibold text-slate-900 uppercase font-mono tracking-wider">
            State Vector Telemetry Co-Inspection (At Simulation Timestamp T+{{ (currentFrame()?.time || 0) | number:'1.1-1' }}s)
          </h2>
          <span class="text-xs font-mono text-slate-400">Never silently substitute one state for another</span>
        </div>

        <div class="overflow-x-auto">
          <table class="w-full text-xs font-mono">
            <thead class="bg-slate-50 text-slate-600 border-b border-slate-200">
              <tr>
                <th class="py-2.5 px-4 text-left">State Channel</th>
                <th class="py-2.5 px-4 text-right">True Physical x(t)</th>
                <th class="py-2.5 px-4 text-right">Measured Sensor z_m(t)</th>
                <th class="py-2.5 px-4 text-right">EKF Estimated x̂(t)</th>
                <th class="py-2.5 px-4 text-right">Innovation Residual e(t)</th>
                <th class="py-2.5 px-4 text-center">Sensor Unit</th>
                <th class="py-2.5 px-4 text-left">Observer Status</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-slate-100">
              <!-- Generator Power -->
              <tr class="hover:bg-slate-50/80">
                <td class="py-2.5 px-4 font-semibold text-slate-900">Generator Electrical Power</td>
                <td class="py-2.5 px-4 text-right tabular-nums text-slate-700">{{ (currentFrame()?.true_state?.p_gen || 0) / 1e6 | number:'1.3-3' }}</td>
                <td class="py-2.5 px-4 text-right tabular-nums text-sky-800">{{ (currentFrame()?.measured_state?.p_gen || 0) / 1e6 | number:'1.3-3' }}</td>
                <td class="py-2.5 px-4 text-right tabular-nums font-bold text-slate-900">{{ (currentFrame()?.estimated_state?.p_gen || 0) / 1e6 | number:'1.3-3' }}</td>
                <td class="py-2.5 px-4 text-right tabular-nums text-slate-500">{{ (currentFrame()?.innovation_residuals?.p_gen || 0) / 1e3 | number:'1.1-1' }} kW</td>
                <td class="py-2.5 px-4 text-center text-slate-400">MW</td>
                <td class="py-2.5 px-4 text-emerald-700">Calibrated</td>
              </tr>

              <!-- Bus Voltage -->
              <tr class="hover:bg-slate-50/80">
                <td class="py-2.5 px-4 font-semibold text-slate-900">Main DC Bus Voltage</td>
                <td class="py-2.5 px-4 text-right tabular-nums text-slate-700">{{ currentFrame()?.true_state?.v_bus | number:'1.2-2' }}</td>
                <td class="py-2.5 px-4 text-right tabular-nums text-sky-800">{{ currentFrame()?.measured_state?.v_bus | number:'1.2-2' }}</td>
                <td class="py-2.5 px-4 text-right tabular-nums font-bold text-slate-900">{{ currentFrame()?.estimated_state?.v_bus | number:'1.2-2' }}</td>
                <td class="py-2.5 px-4 text-right tabular-nums" [class.text-rose-600]="mathAbs(currentFrame()?.innovation_residuals?.v_bus || 0) > 3.0" [class.text-slate-500]="mathAbs(currentFrame()?.innovation_residuals?.v_bus || 0) <= 3.0">
                  {{ currentFrame()?.innovation_residuals?.v_bus | number:'1.2-2' }} V
                </td>
                <td class="py-2.5 px-4 text-center text-slate-400">V</td>
                <td class="py-2.5 px-4 text-emerald-700">Nominal</td>
              </tr>

              <!-- Bus Current -->
              <tr class="hover:bg-slate-50/80">
                <td class="py-2.5 px-4 font-semibold text-slate-900">Main DC Bus Current</td>
                <td class="py-2.5 px-4 text-right tabular-nums text-slate-700">{{ currentFrame()?.true_state?.i_bus | number:'1.1-1' }}</td>
                <td class="py-2.5 px-4 text-right tabular-nums text-sky-800">{{ currentFrame()?.measured_state?.i_bus | number:'1.1-1' }}</td>
                <td class="py-2.5 px-4 text-right tabular-nums font-bold text-slate-900">{{ currentFrame()?.estimated_state?.i_bus | number:'1.1-1' }}</td>
                <td class="py-2.5 px-4 text-right tabular-nums text-slate-500">{{ currentFrame()?.innovation_residuals?.i_bus | number:'1.1-1' }} A</td>
                <td class="py-2.5 px-4 text-center text-slate-400">A</td>
                <td class="py-2.5 px-4 text-emerald-700">Tracking</td>
              </tr>

              <!-- Storage SOC -->
              <tr class="hover:bg-slate-50/80">
                <td class="py-2.5 px-4 font-semibold text-slate-900">Battery Buffer SOC</td>
                <td class="py-2.5 px-4 text-right tabular-nums text-slate-700">{{ ((currentFrame()?.true_state?.soc || 0) * 100) | number:'1.2-2' }}%</td>
                <td class="py-2.5 px-4 text-right tabular-nums text-sky-800">{{ ((currentFrame()?.measured_state?.soc || 0) * 100) | number:'1.2-2' }}%</td>
                <td class="py-2.5 px-4 text-right tabular-nums font-bold text-slate-900">{{ ((currentFrame()?.estimated_state?.soc || 0) * 100) | number:'1.2-2' }}%</td>
                <td class="py-2.5 px-4 text-right tabular-nums text-slate-500">{{ ((currentFrame()?.innovation_residuals?.soc || 0) * 100) | number:'1.2-2' }}%</td>
                <td class="py-2.5 px-4 text-center text-slate-400">ratio</td>
                <td class="py-2.5 px-4 text-emerald-700">Coulomb Count + EKF</td>
              </tr>

              <!-- Generator Temp -->
              <tr class="hover:bg-slate-50/80">
                <td class="py-2.5 px-4 font-semibold text-slate-900">Generator Temperature</td>
                <td class="py-2.5 px-4 text-right tabular-nums text-slate-700">{{ currentFrame()?.true_state?.t_gen | number:'1.1-1' }}</td>
                <td class="py-2.5 px-4 text-right tabular-nums text-sky-800">{{ currentFrame()?.measured_state?.t_gen | number:'1.1-1' }}</td>
                <td class="py-2.5 px-4 text-right tabular-nums font-bold text-slate-900">{{ currentFrame()?.estimated_state?.t_gen | number:'1.1-1' }}</td>
                <td class="py-2.5 px-4 text-right tabular-nums text-slate-500">{{ currentFrame()?.innovation_residuals?.t_gen | number:'1.2-2' }} K</td>
                <td class="py-2.5 px-4 text-center text-slate-400">K</td>
                <td class="py-2.5 px-4 text-emerald-700">RTD Channel A</td>
              </tr>

              <!-- Converter Temp -->
              <tr class="hover:bg-slate-50/80">
                <td class="py-2.5 px-4 font-semibold text-slate-900">Converter Junction Temp</td>
                <td class="py-2.5 px-4 text-right tabular-nums text-slate-700">{{ currentFrame()?.true_state?.t_conv | number:'1.1-1' }}</td>
                <td class="py-2.5 px-4 text-right tabular-nums text-sky-800">{{ currentFrame()?.measured_state?.t_conv | number:'1.1-1' }}</td>
                <td class="py-2.5 px-4 text-right tabular-nums font-bold text-slate-900">{{ currentFrame()?.estimated_state?.t_conv | number:'1.1-1' }}</td>
                <td class="py-2.5 px-4 text-right tabular-nums" [class.text-rose-600]="mathAbs(currentFrame()?.innovation_residuals?.t_conv || 0) > 4.0" [class.text-slate-500]="mathAbs(currentFrame()?.innovation_residuals?.t_conv || 0) <= 4.0">
                  {{ currentFrame()?.innovation_residuals?.t_conv | number:'1.2-2' }} K
                </td>
                <td class="py-2.5 px-4 text-center text-slate-400">K</td>
                <td class="py-2.5 px-4 text-emerald-700">Junction Probe</td>
              </tr>

              <!-- Storage Temp -->
              <tr class="hover:bg-slate-50/80">
                <td class="py-2.5 px-4 font-semibold text-slate-900">Storage Core Temp</td>
                <td class="py-2.5 px-4 text-right tabular-nums text-slate-700">{{ currentFrame()?.true_state?.t_stor | number:'1.1-1' }}</td>
                <td class="py-2.5 px-4 text-right tabular-nums text-sky-800">{{ currentFrame()?.measured_state?.t_stor | number:'1.1-1' }}</td>
                <td class="py-2.5 px-4 text-right tabular-nums font-bold text-slate-900">{{ currentFrame()?.estimated_state?.t_stor | number:'1.1-1' }}</td>
                <td class="py-2.5 px-4 text-right tabular-nums text-slate-500">{{ currentFrame()?.innovation_residuals?.t_stor | number:'1.2-2' }} K</td>
                <td class="py-2.5 px-4 text-center text-slate-400">K</td>
                <td class="py-2.5 px-4 text-emerald-700">Pack Thermistor</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>

      <!-- Subsystem Diagnostics Status Matrix -->
      <div class="grid grid-cols-2 sm:grid-cols-5 gap-3">
        @let sub = currentFrame()?.subsystem_health;
        <div class="bg-white border border-slate-200 rounded-lg p-3 text-xs font-mono shadow-xs">
          <div class="text-slate-400 uppercase text-[10px]">GENERATOR</div>
          <div class="font-bold mt-1" [class.text-emerald-700]="sub?.generator === 'NORMAL'" [class.text-amber-600]="sub?.generator === 'WARNING'" [class.text-rose-600]="sub?.generator === 'FAULT'">
            {{ sub?.generator }}
          </div>
        </div>

        <div class="bg-white border border-slate-200 rounded-lg p-3 text-xs font-mono shadow-xs">
          <div class="text-slate-400 uppercase text-[10px]">CONVERTER</div>
          <div class="font-bold mt-1" [class.text-emerald-700]="sub?.converter === 'NORMAL'" [class.text-amber-600]="sub?.converter === 'WARNING'" [class.text-rose-600]="sub?.converter === 'FAULT'">
            {{ sub?.converter }}
          </div>
        </div>

        <div class="bg-white border border-slate-200 rounded-lg p-3 text-xs font-mono shadow-xs">
          <div class="text-slate-400 uppercase text-[10px]">POWER BUS</div>
          <div class="font-bold mt-1" [class.text-emerald-700]="sub?.bus === 'NORMAL'" [class.text-amber-600]="sub?.bus === 'WARNING'" [class.text-rose-600]="sub?.bus === 'FAULT'">
            {{ sub?.bus }}
          </div>
        </div>

        <div class="bg-white border border-slate-200 rounded-lg p-3 text-xs font-mono shadow-xs">
          <div class="text-slate-400 uppercase text-[10px]">STORAGE</div>
          <div class="font-bold mt-1" [class.text-emerald-700]="sub?.storage === 'NORMAL'" [class.text-amber-600]="sub?.storage === 'WARNING'" [class.text-rose-600]="sub?.storage === 'FAULT'">
            {{ sub?.storage }}
          </div>
        </div>

        <div class="bg-white border border-slate-200 rounded-lg p-3 text-xs font-mono shadow-xs">
          <div class="text-slate-400 uppercase text-[10px]">SENSORS</div>
          <div class="font-bold mt-1" [class.text-emerald-700]="sub?.sensors === 'NORMAL'" [class.text-amber-600]="sub?.sensors === 'WARNING'" [class.text-rose-600]="sub?.sensors === 'FAULT'">
            {{ sub?.sensors }}
          </div>
        </div>
      </div>
    </div>
  `
})
export class DigitalTwinComponent {
  service = inject(PowerSystemService);

  currentFrame = () => {
    const history = this.service.digitalTwinHistory();
    if (!history || history.length === 0) return null;
    const idx = Math.min(this.service.playbackIndex(), history.length - 1);
    return history[idx] || history[history.length - 1];
  };

  mathAbs(v: number): number {
    return Math.abs(v);
  }
}
