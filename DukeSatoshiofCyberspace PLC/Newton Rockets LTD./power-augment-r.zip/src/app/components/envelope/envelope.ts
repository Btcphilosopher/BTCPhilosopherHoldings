import { Component, ChangeDetectionStrategy, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { PowerSystemService } from '../../services/power-system.service';

@Component({
  selector: 'app-envelope',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-6">
      <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-200 pb-4">
        <div>
          <h1 class="text-xl font-bold text-slate-900 tracking-tight font-tech">
            Power-Increase Operational Envelope: calculate_power_envelope()
          </h1>
          <p class="text-xs text-slate-500 font-mono mt-0.5">
            Duration-Dependent Multi-Constraint Bounds · Peak vs Sustainable vs Thermal vs Hardware Limits
          </p>
        </div>

        <button
          (click)="service.computeEnvelope()"
          class="px-3 py-1.5 text-xs font-medium text-white bg-slate-900 rounded-md hover:bg-slate-800 transition-colors flex items-center gap-1.5 self-start">
          <mat-icon class="text-sm! w-4! h-4!">refresh</mat-icon>
          <span>Recompute Envelope</span>
        </button>
      </div>

      <!-- Envelope Graphical Chart SVG -->
      <div class="bg-white border border-slate-200 rounded-lg p-6 shadow-xs">
        <h2 class="text-xs font-semibold text-slate-900 uppercase font-mono tracking-wider mb-3">
          Spacecraft Power Capability vs Burn Duration (10s to 1 hour)
        </h2>

        <div class="w-full overflow-x-auto">
          <svg viewBox="0 0 800 320" class="w-full min-w-[650px] font-mono select-none">
            <!-- Grid lines -->
            <line x1="80" y1="40" x2="750" y2="40" stroke="#f1f5f9" stroke-width="1" />
            <line x1="80" y1="100" x2="750" y2="100" stroke="#f1f5f9" stroke-width="1" />
            <line x1="80" y1="160" x2="750" y2="160" stroke="#f1f5f9" stroke-width="1" />
            <line x1="80" y1="220" x2="750" y2="220" stroke="#f1f5f9" stroke-width="1" />
            <line x1="80" y1="280" x2="750" y2="280" stroke="#cbd5e1" stroke-width="1.5" />
            <line x1="80" y1="20" x2="80" y2="280" stroke="#cbd5e1" stroke-width="1.5" />

            <!-- Y Axis Labels (0 to 3.5 MW) -->
            <text x="70" y="284" text-anchor="end" font-size="10" fill="#64748b">0.0 MW</text>
            <text x="70" y="224" text-anchor="end" font-size="10" fill="#64748b">1.0 MW</text>
            <text x="70" y="164" text-anchor="end" font-size="10" fill="#64748b">2.0 MW</text>
            <text x="70" y="104" text-anchor="end" font-size="10" fill="#64748b">3.0 MW</text>
            <text x="70" y="44" text-anchor="end" font-size="10" fill="#64748b">4.0 MW</text>

            <!-- Curve 1: Peak Power Available (Gross) -->
            <path
              d="M 120 75 L 180 85 L 260 105 L 340 125 L 420 145 L 500 152 L 600 155 L 720 156"
              fill="none"
              stroke="#0284c7"
              stroke-width="2.5" />

            <!-- Curve 2: Thermal-Limited Power -->
            <path
              d="M 120 50 L 180 65 L 260 90 L 340 120 L 420 148 L 500 158 L 600 162 L 720 165"
              fill="none"
              stroke="#e11d48"
              stroke-width="2"
              stroke-dasharray="4,3" />

            <!-- Curve 3: Sustainable Continuous Generation Baseline (Horizontal Line at ~2.17 MW -> y=150) -->
            <line x1="80" y1="150" x2="750" y2="150" stroke="#059669" stroke-width="2" stroke-dasharray="6,4" />
            <text x="740" y="142" text-anchor="end" font-size="10" font-weight="bold" fill="#059669">SUSTAINABLE CONTINUOUS (2.17 MW)</text>

            <!-- Curve 4: Baseline Generation (Horizontal Line at 1.80 MW -> y=172) -->
            <line x1="80" y1="172" x2="750" y2="172" stroke="#64748b" stroke-width="1.5" stroke-dasharray="2,2" />
            <text x="740" y="185" text-anchor="end" font-size="9" fill="#64748b">BASELINE CRUISE (1.80 MW)</text>

            <!-- Data Point Markers for Achievable Envelope -->
            @for (pt of service.envelopeData(); track pt.duration_s; let idx = $index) {
              <circle
                [attr.cx]="120 + idx * 75"
                [attr.cy]="280 - (pt.max_achievable_power_mw / 4.0) * 240"
                r="4.5"
                fill="#0f172a"
                stroke="#ffffff"
                stroke-width="1.5" />
              <text
                [attr.x]="120 + idx * 75"
                y="300"
                text-anchor="middle"
                font-size="9"
                fill="#64748b">
                {{ pt.duration_label }}
              </text>
            }
          </svg>
        </div>

        <div class="flex flex-wrap items-center justify-center gap-6 mt-4 text-xs font-mono">
          <div class="flex items-center gap-1.5">
            <span class="w-3 h-0.5 bg-sky-600 inline-block"></span>
            <span class="text-slate-700">Peak Storage+Gen Capability</span>
          </div>
          <div class="flex items-center gap-1.5">
            <span class="w-3 h-0.5 bg-rose-600 inline-block border-b border-dashed border-rose-600"></span>
            <span class="text-slate-700">Thermal Radiator Limit</span>
          </div>
          <div class="flex items-center gap-1.5">
            <span class="w-3 h-0.5 bg-emerald-600 inline-block"></span>
            <span class="text-slate-700">Sustainable Generation</span>
          </div>
          <div class="flex items-center gap-1.5">
            <span class="w-2.5 h-2.5 rounded-full bg-slate-900 inline-block"></span>
            <span class="text-slate-900 font-bold">Max Achievable Power</span>
          </div>
        </div>
      </div>

      <!-- Precise Envelope Numerical Data Table -->
      <div class="bg-white border border-slate-200 rounded-lg overflow-hidden shadow-xs">
        <div class="p-4 border-b border-slate-100 flex items-center justify-between">
          <h2 class="text-xs font-semibold text-slate-900 uppercase font-mono tracking-wider">
            Operational Power Limits by Target Burn Duration
          </h2>
          <span class="text-xs font-mono text-slate-500">Calculated from First Principles</span>
        </div>

        <div class="overflow-x-auto">
          <table class="w-full text-xs font-mono">
            <thead class="bg-slate-50 text-slate-600 border-b border-slate-200">
              <tr>
                <th class="py-2.5 px-4 text-left">Duration</th>
                <th class="py-2.5 px-3 text-right">Baseline</th>
                <th class="py-2.5 px-3 text-right">Peak Avail</th>
                <th class="py-2.5 px-3 text-right">Thermal Limit</th>
                <th class="py-2.5 px-3 text-right">Storage Limit</th>
                <th class="py-2.5 px-3 text-right">Max Achievable</th>
                <th class="py-2.5 px-3 text-right">Net Gain</th>
                <th class="py-2.5 px-4 text-left">Limiting Subsystem</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-slate-100">
              @for (row of service.envelopeData(); track row.duration_s) {
                <tr class="hover:bg-slate-50/80">
                  <td class="py-2 px-4 font-semibold text-slate-900">{{ row.duration_label }} ({{ row.duration_s }}s)</td>
                  <td class="py-2 px-3 text-right text-slate-500 tabular-nums">{{ row.baseline_power_mw | number:'1.2-2' }} MW</td>
                  <td class="py-2 px-3 text-right text-sky-700 tabular-nums font-medium">{{ row.peak_power_mw | number:'1.2-2' }} MW</td>
                  <td class="py-2 px-3 text-right text-rose-600 tabular-nums">{{ row.thermal_limited_power_mw | number:'1.2-2' }} MW</td>
                  <td class="py-2 px-3 text-right text-cyan-700 tabular-nums">{{ row.storage_limited_power_mw | number:'1.2-2' }} MW</td>
                  <td class="py-2 px-3 text-right font-bold text-slate-900 tabular-nums bg-slate-50/50">{{ row.max_achievable_power_mw | number:'1.2-2' }} MW</td>
                  <td class="py-2 px-3 text-right font-semibold text-emerald-700 tabular-nums">+{{ row.power_gain_percent | number:'1.1-1' }}%</td>
                  <td class="py-2 px-4 text-slate-700">
                    <span class="text-[11px] font-mono bg-slate-100 px-2 py-0.5 rounded text-slate-800">
                      {{ row.limiting_subsystem }}
                    </span>
                  </td>
                </tr>
              }
            </tbody>
          </table>
        </div>
      </div>
    </div>
  `
})
export class EnvelopeComponent {
  service = inject(PowerSystemService);
}
