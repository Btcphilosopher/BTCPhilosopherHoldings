import { Component, ChangeDetectionStrategy, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { PowerSystemService } from '../../services/power-system.service';

@Component({
  selector: 'app-optimisation',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-6">
      <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-200 pb-4">
        <div>
          <h1 class="text-xl font-bold text-slate-900 tracking-tight font-tech">
            Multi-Objective Pareto Frontier Optimization: run_optimisation()
          </h1>
          <p class="text-xs text-slate-500 font-mono mt-0.5">
            Maximize Net Usable Power & Thermal Margin while Minimizing Electrical Losses
          </p>
        </div>

        <button
          (click)="service.runOptimization(5)"
          class="px-3 py-1.5 text-xs font-medium text-white bg-slate-900 rounded-md hover:bg-slate-800 transition-colors flex items-center gap-1.5 self-start">
          <mat-icon class="text-sm! w-4! h-4!">insights</mat-icon>
          <span>Run Pareto Optimizer</span>
        </button>
      </div>

      <!-- Recommended Knee Point Design Card -->
      @let opt = service.optimizationResult();
      @if (opt && opt.recommended_design) {
        @let rec = opt.recommended_design;
        <div class="bg-white border-2 border-slate-900 rounded-lg p-5 shadow-sm">
          <div class="flex items-center justify-between border-b border-slate-100 pb-2">
            <div class="flex items-center gap-2">
              <span class="w-2.5 h-2.5 rounded-full bg-emerald-600"></span>
              <h2 class="text-xs font-bold text-slate-900 uppercase font-mono tracking-wider">
                Recommended Pareto Knee Compromise Design
              </h2>
            </div>
            <span class="text-xs font-mono font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded">
              NON-DOMINATED OPTIMAL
            </span>
          </div>

          <div class="grid grid-cols-2 sm:grid-cols-4 gap-4 mt-4 font-mono text-xs">
            <div class="bg-slate-50 p-3 rounded">
              <div class="text-slate-400 uppercase text-[10px]">Augmented Reactor Rating</div>
              <div class="text-base font-bold text-slate-900 mt-1">{{ rec.gen_power_mw | number:'1.2-2' }} MW</div>
            </div>
            <div class="bg-slate-50 p-3 rounded">
              <div class="text-slate-400 uppercase text-[10px]">Storage Peak Discharge</div>
              <div class="text-base font-bold text-slate-900 mt-1">{{ rec.stor_power_mw | number:'1.2-2' }} MW</div>
            </div>
            <div class="bg-slate-50 p-3 rounded">
              <div class="text-slate-400 uppercase text-[10px]">Main DC Bus Voltage</div>
              <div class="text-base font-bold text-slate-900 mt-1">{{ rec.v_bus | number:'1.0-0' }} V</div>
            </div>
            <div class="bg-slate-50 p-3 rounded">
              <div class="text-slate-400 uppercase text-[10px]">Radiator Surface Area</div>
              <div class="text-base font-bold text-slate-900 mt-1">{{ rec.rad_area | number:'1.0-0' }} m²</div>
            </div>
          </div>

          <div class="grid grid-cols-3 gap-4 mt-3 font-mono text-xs border-t border-slate-100 pt-3">
            <div>
              <span class="text-slate-500">Achievable Power:</span>
              <span class="font-bold text-emerald-700 ml-2">{{ rec.usable_power_mw | number:'1.2-2' }} MW</span>
            </div>
            <div>
              <span class="text-slate-500">Thermal Margin:</span>
              <span class="font-bold text-slate-900 ml-2">{{ rec.thermal_margin_pct | number:'1.1-1' }}%</span>
            </div>
            <div>
              <span class="text-slate-500">Electrical Losses:</span>
              <span class="font-bold text-rose-700 ml-2">{{ rec.losses_kw | number:'1.0-0' }} kW</span>
            </div>
          </div>
        </div>

        <!-- Pareto Frontier Table -->
        <div class="bg-white border border-slate-200 rounded-lg overflow-hidden shadow-xs">
          <div class="p-4 border-b border-slate-100 flex items-center justify-between">
            <h2 class="text-xs font-semibold text-slate-900 uppercase font-mono tracking-wider">
              Non-Dominated Pareto Optimal Frontier ({{ opt.pareto_frontier.length }} Candidates)
            </h2>
            <span class="text-xs font-mono text-slate-500">Trade-offs Exposed</span>
          </div>

          <div class="overflow-x-auto">
            <table class="w-full text-xs font-mono">
              <thead class="bg-slate-50 text-slate-600 border-b border-slate-200">
                <tr>
                  <th class="py-2.5 px-4 text-left">Candidate ID</th>
                  <th class="py-2.5 px-3 text-right">Reactor Gen</th>
                  <th class="py-2.5 px-3 text-right">Storage Disch</th>
                  <th class="py-2.5 px-3 text-right">Bus Voltage</th>
                  <th class="py-2.5 px-3 text-right">Radiator Area</th>
                  <th class="py-2.5 px-3 text-right">Usable Power</th>
                  <th class="py-2.5 px-3 text-right">Thermal Margin</th>
                  <th class="py-2.5 px-3 text-right">Total Losses</th>
                </tr>
              </thead>
              <tbody class="divide-y divide-slate-100">
                @for (c of opt.pareto_frontier; track c.id) {
                  <tr class="hover:bg-slate-50/80" [class.bg-slate-50]="c.id === rec.id">
                    <td class="py-2 px-4 font-semibold text-slate-900">#{{ c.id }} {{ c.id === rec.id ? '(Recommended Knee)' : '' }}</td>
                    <td class="py-2 px-3 text-right tabular-nums text-slate-700">{{ c.gen_power_mw | number:'1.2-2' }} MW</td>
                    <td class="py-2 px-3 text-right tabular-nums text-slate-700">{{ c.stor_power_mw | number:'1.2-2' }} MW</td>
                    <td class="py-2 px-3 text-right tabular-nums text-slate-700">{{ c.v_bus | number:'1.0-0' }} V</td>
                    <td class="py-2 px-3 text-right tabular-nums text-slate-700">{{ c.rad_area | number:'1.0-0' }} m²</td>
                    <td class="py-2 px-3 text-right tabular-nums font-bold text-emerald-700">{{ c.usable_power_mw | number:'1.2-2' }} MW</td>
                    <td class="py-2 px-3 text-right tabular-nums font-semibold text-slate-900">{{ c.thermal_margin_pct | number:'1.1-1' }}%</td>
                    <td class="py-2 px-3 text-right tabular-nums text-rose-600">{{ c.losses_kw | number:'1.0-0' }} kW</td>
                  </tr>
                }
              </tbody>
            </table>
          </div>
        </div>
      }
    </div>
  `
})
export class OptimisationComponent {
  service = inject(PowerSystemService);
}
