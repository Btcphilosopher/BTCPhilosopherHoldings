import { Component, ChangeDetectionStrategy, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { PowerSystemService } from '../../services/power-system.service';

@Component({
  selector: 'app-scenarios',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-6">
      <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-200 pb-4">
        <div>
          <h1 class="text-xl font-bold text-slate-900 tracking-tight font-tech">
            Versioned Mission Scenarios Engine (12 Reference Cases)
          </h1>
          <p class="text-xs text-slate-500 font-mono mt-0.5">
            Pre-Configured Aerospace Operational Conditions · 1-Click Execution & Parameter Diffs
          </p>
        </div>

        <div class="text-xs font-mono text-slate-500">
          ACTIVE SCENARIO: <span class="font-bold text-slate-900">{{ service.activeScenarioId() }}</span>
        </div>
      </div>

      <!-- Scenarios Cards Grid -->
      <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        @for (sc of service.scenarios(); track sc.id) {
          <div
            class="bg-white border rounded-lg p-4 shadow-xs flex flex-col justify-between transition-colors"
            [class.border-slate-900]="service.activeScenarioId() === sc.id"
            [class.bg-slate-50/50]="service.activeScenarioId() === sc.id"
            [class.border-slate-200]="service.activeScenarioId() !== sc.id">
            <div>
              <div class="flex items-center justify-between">
                <span class="text-xs font-bold font-mono text-slate-900">{{ sc.code }} · {{ sc.name }}</span>
                <span class="text-[10px] font-mono px-2 py-0.5 bg-slate-100 rounded text-slate-600 uppercase font-semibold">
                  {{ sc.category }}
                </span>
              </div>
              <p class="text-xs text-slate-600 mt-2 font-mono leading-relaxed">{{ sc.description }}</p>
            </div>

            <div class="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-xs font-mono">
              <span class="text-slate-400">{{ sc.duration }}s · dt = {{ sc.dt }}s</span>
              <button
                (click)="service.setScenario(sc.id)"
                class="px-3 py-1 font-medium rounded transition-colors"
                [class.bg-slate-900]="service.activeScenarioId() === sc.id"
                [class.text-white]="service.activeScenarioId() === sc.id"
                [class.bg-slate-100]="service.activeScenarioId() !== sc.id"
                [class.text-slate-700]="service.activeScenarioId() !== sc.id"
                [class.hover:bg-slate-200]="service.activeScenarioId() !== sc.id">
                {{ service.activeScenarioId() === sc.id ? 'Active' : 'Load Scenario' }}
              </button>
            </div>
          </div>
        }
      </div>
    </div>
  `
})
export class ScenariosComponent {
  service = inject(PowerSystemService);
}
