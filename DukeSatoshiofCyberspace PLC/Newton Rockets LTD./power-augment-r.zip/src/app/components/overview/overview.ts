import { Component, ChangeDetectionStrategy, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { PowerSystemService } from '../../services/power-system.service';
import { AugmentationStrategy } from '../../core/physics-engine';

@Component({
  selector: 'app-overview',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-6">
      <!-- Section Header -->
      <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-200 pb-4">
        <div>
          <h1 class="text-xl font-bold text-slate-900 tracking-tight font-tech">
            Power Augmentation Engineering Executive Dashboard
          </h1>
          <p class="text-xs text-slate-500 font-mono mt-0.5">
            Interplanetary Rocket Electrical Balance · Energy Residual Conservation Checked
          </p>
        </div>

        <div class="flex items-center gap-2">
          <!-- Active Scenario Selector -->
          <div class="flex items-center gap-1.5 bg-slate-100 p-1 rounded-md text-xs font-mono">
            <span class="text-slate-500 px-1">SCENARIO:</span>
            <select
              [value]="service.activeScenarioId()"
              (change)="onScenarioChange($event)"
              class="bg-white border border-slate-200 rounded px-2 py-1 text-slate-900 font-medium focus:outline-hidden focus:ring-1 focus:ring-slate-400">
              @for (sc of service.scenarios(); track sc.id) {
                <option [value]="sc.id">{{ sc.code }} · {{ sc.name }}</option>
              }
            </select>
          </div>

          <!-- Propulsion Burn Toggle -->
          <button
            (click)="toggleBoost()"
            class="px-3 py-1 text-xs font-medium rounded-md transition-colors flex items-center gap-1.5"
            [class.bg-emerald-700]="service.boostMode()"
            [class.text-white]="service.boostMode()"
            [class.bg-slate-200]="!service.boostMode()"
            [class.text-slate-700]="!service.boostMode()">
            <mat-icon class="text-xs! w-3.5! h-3.5!">rocket_launch</mat-icon>
            <span>{{ service.boostMode() ? 'BOOST ON' : 'BOOST OFF' }}</span>
          </button>
        </div>
      </div>

      <!-- Core Power Augmentation Balance Metrics Grid (10 Key Technical Displays) -->
      <div class="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
        <!-- Baseline Gen -->
        <div class="bg-white border border-slate-200 rounded-lg p-3 shadow-xs">
          <div class="text-slate-400 uppercase text-[10px] font-mono tracking-wider">Baseline Generation</div>
          <div class="mt-1 flex items-baseline">
            <span class="text-xl font-bold font-mono tabular-nums text-slate-900">
              {{ metrics().baselinePowerMw | number:'1.2-2' }}
            </span>
            <span class="text-[10px] font-mono text-slate-500 ml-1">MW</span>
          </div>
          <div class="text-[11px] text-slate-500 mt-1">Nuclear / Solar Base</div>
        </div>

        <!-- Augmented Gen -->
        <div class="bg-white border border-slate-200 rounded-lg p-3 shadow-xs">
          <div class="text-slate-400 uppercase text-[10px] font-mono tracking-wider">Augmented Gen (Gross)</div>
          <div class="mt-1 flex items-baseline">
            <span class="text-xl font-bold font-mono tabular-nums text-slate-900">
              {{ metrics().augmentedGenMw | number:'1.2-2' }}
            </span>
            <span class="text-[10px] font-mono text-slate-500 ml-1">MW</span>
          </div>
          <div class="text-[11px] text-slate-600 font-mono mt-1">Gross +{{ metrics().grossIncreaseMw | number:'1.2-2' }} MW</div>
        </div>

        <!-- Net Additional Power -->
        <div class="bg-white border border-slate-200 rounded-lg p-3 shadow-xs bg-slate-50/50">
          <div class="text-slate-500 uppercase text-[10px] font-mono tracking-wider">Net Additional Power</div>
          <div class="mt-1 flex items-baseline">
            <span class="text-xl font-bold font-mono tabular-nums text-emerald-700">
              +{{ metrics().netAddPowerMw | number:'1.2-2' }}
            </span>
            <span class="text-[10px] font-mono text-slate-500 ml-1">MW</span>
          </div>
          <div class="text-[11px] text-emerald-700 font-mono mt-1">Gain +{{ metrics().powerGainPct | number:'1.1-1' }}%</div>
        </div>

        <!-- Peak Available Power -->
        <div class="bg-white border border-slate-200 rounded-lg p-3 shadow-xs">
          <div class="text-slate-400 uppercase text-[10px] font-mono tracking-wider">Peak Available Power</div>
          <div class="mt-1 flex items-baseline">
            <span class="text-xl font-bold font-mono tabular-nums text-slate-900">
              {{ metrics().peakAvailMw | number:'1.2-2' }}
            </span>
            <span class="text-[10px] font-mono text-slate-500 ml-1">MW</span>
          </div>
          <div class="text-[11px] text-slate-500 font-mono mt-1">Gen + Storage Buffer</div>
        </div>

        <!-- Sustainable Power -->
        <div class="bg-white border border-slate-200 rounded-lg p-3 shadow-xs">
          <div class="text-slate-400 uppercase text-[10px] font-mono tracking-wider">Sustainable Power</div>
          <div class="mt-1 flex items-baseline">
            <span class="text-xl font-bold font-mono tabular-nums text-slate-900">
              {{ metrics().sustainableMw | number:'1.2-2' }}
            </span>
            <span class="text-[10px] font-mono text-slate-500 ml-1">MW</span>
          </div>
          <div class="text-[11px] text-slate-500 font-mono mt-1">Continuous Safe Load</div>
        </div>

        <!-- Power Margin -->
        <div class="bg-white border border-slate-200 rounded-lg p-3 shadow-xs">
          <div class="text-slate-400 uppercase text-[10px] font-mono tracking-wider">Net Power Margin</div>
          <div class="mt-1 flex items-baseline">
            <span class="text-xl font-bold font-mono tabular-nums" [class.text-emerald-700]="metrics().powerMarginKw >= 0" [class.text-rose-600]="metrics().powerMarginKw < 0">
              {{ metrics().powerMarginKw >= 0 ? '+' : '' }}{{ metrics().powerMarginKw | number:'1.1-1' }}
            </span>
            <span class="text-[10px] font-mono text-slate-500 ml-1">kW</span>
          </div>
          <div class="text-[11px] text-slate-500 mt-1">P_usable - P_demand</div>
        </div>
      </div>

      <!-- Secondary Technical Row: Efficiency, Thermal, Battery SOC, and Loss Accounting -->
      <div class="grid grid-cols-1 md:grid-cols-4 gap-4">
        <!-- System Efficiency -->
        <div class="bg-white border border-slate-200 rounded-lg p-4 shadow-xs">
          <div class="flex items-center justify-between">
            <span class="text-xs font-mono text-slate-500 uppercase">System Energy Efficiency</span>
            <mat-icon class="text-slate-400 text-sm! w-4! h-4!">bolt</mat-icon>
          </div>
          <div class="mt-2 flex items-baseline">
            <span class="text-2xl font-bold font-mono tabular-nums text-slate-900">
              {{ metrics().systemEfficiencyPct | number:'1.1-1' }}
            </span>
            <span class="text-xs font-mono text-slate-400 ml-1">%</span>
          </div>
          <div class="mt-3 w-full bg-slate-100 rounded-full h-1.5 overflow-hidden">
            <div
              class="bg-slate-800 h-full rounded-full"
              [style.width.%]="metrics().systemEfficiencyPct"></div>
          </div>
          <div class="mt-2 text-[11px] text-slate-500 flex justify-between font-mono">
            <span>Gen: 94.0%</span>
            <span>Conv: 96.5%</span>
          </div>
        </div>

        <!-- Thermal Margin -->
        <div class="bg-white border border-slate-200 rounded-lg p-4 shadow-xs">
          <div class="flex items-center justify-between">
            <span class="text-xs font-mono text-slate-500 uppercase">Thermal Margin</span>
            <mat-icon class="text-slate-400 text-sm! w-4! h-4!">thermostat</mat-icon>
          </div>
          <div class="mt-2 flex items-baseline">
            <span class="text-2xl font-bold font-mono tabular-nums" [class.text-emerald-700]="metrics().thermalMarginPct > 15" [class.text-amber-600]="metrics().thermalMarginPct <= 15 && metrics().thermalMarginPct > 5" [class.text-rose-600]="metrics().thermalMarginPct <= 5">
              {{ metrics().thermalMarginPct | number:'1.1-1' }}
            </span>
            <span class="text-xs font-mono text-slate-400 ml-1">%</span>
          </div>
          <div class="mt-3 w-full bg-slate-100 rounded-full h-1.5 overflow-hidden">
            <div
              class="h-full rounded-full transition-all"
              [class.bg-emerald-600]="metrics().thermalMarginPct > 15"
              [class.bg-amber-500]="metrics().thermalMarginPct <= 15 && metrics().thermalMarginPct > 5"
              [class.bg-rose-600]="metrics().thermalMarginPct <= 5"
              [style.width.%]="metrics().thermalMarginPct"></div>
          </div>
          <div class="mt-2 text-[11px] text-slate-500 font-mono">
            Radiator Stefan-Boltzmann Rejection
          </div>
        </div>

        <!-- Energy Storage Buffer SOC -->
        <div class="bg-white border border-slate-200 rounded-lg p-4 shadow-xs">
          <div class="flex items-center justify-between">
            <span class="text-xs font-mono text-slate-500 uppercase">Storage State of Charge</span>
            <mat-icon class="text-slate-400 text-sm! w-4! h-4!">battery_5_bar</mat-icon>
          </div>
          <div class="mt-2 flex items-baseline">
            <span class="text-2xl font-bold font-mono tabular-nums text-slate-900">
              {{ (metrics().finalSoc * 100) | number:'1.1-1' }}
            </span>
            <span class="text-xs font-mono text-slate-400 ml-1">%</span>
          </div>
          <div class="mt-3 w-full bg-slate-100 rounded-full h-1.5 overflow-hidden">
            <div
              class="bg-cyan-600 h-full rounded-full"
              [style.width.%]="metrics().finalSoc * 100"></div>
          </div>
          <div class="mt-2 text-[11px] text-slate-500 flex justify-between font-mono">
            <span>Min: 15%</span>
            <span>Contrib: {{ metrics().storageContribMw | number:'1.2-2' }} MW</span>
          </div>
        </div>

        <!-- First Law Energy Balance Residual Verification -->
        <div class="bg-white border border-slate-200 rounded-lg p-4 shadow-xs">
          <div class="flex items-center justify-between">
            <span class="text-xs font-mono text-slate-500 uppercase">Energy Balance Residual</span>
            <mat-icon class="text-emerald-600 text-sm! w-4! h-4!">verified</mat-icon>
          </div>
          <div class="mt-2 flex items-baseline">
            <span class="text-xl font-bold font-mono tabular-nums text-slate-900">
              {{ metrics().maxResidualMj | number:'1.6-6' }}
            </span>
            <span class="text-xs font-mono text-slate-400 ml-1">MJ</span>
          </div>
          <div class="mt-2 flex items-center gap-1.5 text-xs font-mono text-emerald-700">
            <span class="w-2 h-2 rounded-full bg-emerald-500"></span>
            <span>E_source = Σ E_deliv + E_loss + ΔE_stor</span>
          </div>
          <div class="mt-1 text-[11px] text-slate-500 font-mono">
            Tolerance: &lt; 0.000100 MJ
          </div>
        </div>
      </div>

      <!-- Electrical Loss Breakdown & Strategy Dispatch Selector -->
      <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <!-- Left: Loss Accounting Table -->
        <div class="bg-white border border-slate-200 rounded-lg p-4 shadow-xs">
          <h2 class="text-xs font-semibold text-slate-900 uppercase font-mono tracking-wider border-b border-slate-100 pb-2">
            Rigorous Loss Accounting Breakdown
          </h2>
          <table class="w-full mt-3 text-xs font-mono">
            <tbody>
              <tr class="border-b border-slate-50 py-1.5">
                <td class="text-slate-500 py-1.5">Primary Conversion Loss (1 - η_gen)</td>
                <td class="text-right font-medium tabular-nums text-slate-800">
                  {{ (latest()?.p_gen_loss || 0) / 1e3 | number:'1.1-1' }} kW
                </td>
              </tr>
              <tr class="border-b border-slate-50 py-1.5">
                <td class="text-slate-500 py-1.5">Power Conditioning & DC-DC Loss</td>
                <td class="text-right font-medium tabular-nums text-slate-800">
                  {{ (latest()?.p_conv_loss || 0) / 1e3 | number:'1.1-1' }} kW
                </td>
              </tr>
              <tr class="border-b border-slate-50 py-1.5">
                <td class="text-slate-500 py-1.5">DC Distribution Bus Loss (I²R)</td>
                <td class="text-right font-medium tabular-nums text-slate-800">
                  {{ (latest()?.p_bus_loss || 0) / 1e3 | number:'1.1-1' }} kW
                </td>
              </tr>
              <tr class="border-b border-slate-50 py-1.5">
                <td class="text-slate-500 py-1.5">Storage Internal ESR Loss (I²R_esr)</td>
                <td class="text-right font-medium tabular-nums text-slate-800">
                  {{ (latest()?.p_stor_loss || 0) / 1e3 | number:'1.1-1' }} kW
                </td>
              </tr>
              <tr class="font-semibold text-slate-900 pt-2">
                <td class="py-2">Total Electrical Heat Generated</td>
                <td class="text-right text-rose-700 tabular-nums py-2">
                  {{ (((latest()?.p_gen_loss || 0) + (latest()?.p_conv_loss || 0) + (latest()?.p_bus_loss || 0) + (latest()?.p_stor_loss || 0)) / 1e3) | number:'1.1-1' }} kW
                </td>
              </tr>
            </tbody>
          </table>
          <p class="text-[11px] text-slate-400 mt-2 font-mono">
            Every watt of loss is strictly routed to the thermal network.
          </p>
        </div>

        <!-- Middle & Right: Augmentation Strategy Matrix -->
        <div class="lg:col-span-2 bg-white border border-slate-200 rounded-lg p-4 shadow-xs">
          <div class="flex items-center justify-between border-b border-slate-100 pb-2">
            <h2 class="text-xs font-semibold text-slate-900 uppercase font-mono tracking-wider">
              Augmentation Dispatch Strategy Mode (Mode C)
            </h2>
            <span class="text-xs font-mono text-slate-500">Active: {{ service.params().strategy }}</span>
          </div>

          <div class="grid grid-cols-2 sm:grid-cols-4 gap-2 mt-3">
            @for (st of strategies; track st.id) {
              <button
                (click)="service.setStrategy(st.id)"
                class="p-2.5 text-left rounded-md border text-xs transition-colors flex flex-col justify-between"
                [class.border-slate-900]="service.params().strategy === st.id"
                [class.bg-slate-900]="service.params().strategy === st.id"
                [class.text-white]="service.params().strategy === st.id"
                [class.border-slate-200]="service.params().strategy !== st.id"
                [class.bg-slate-50]="service.params().strategy !== st.id"
                [class.text-slate-700]="service.params().strategy !== st.id"
                [class.hover:bg-slate-100]="service.params().strategy !== st.id">
                <span class="font-semibold font-mono text-[11px]">{{ st.label }}</span>
                <span class="text-[10px] opacity-75 mt-1 leading-tight">{{ st.desc }}</span>
              </button>
            }
          </div>

          <div class="mt-4 p-3 bg-slate-50 rounded border border-slate-200/80 flex items-center justify-between text-xs font-mono">
            <div class="flex items-center gap-2">
              <mat-icon class="text-slate-500 text-sm! w-4! h-4!">info</mat-icon>
              <span class="text-slate-600">
                Operating Principle: The power source provides energy. The conversion system makes it usable. The distribution system makes it available. The thermal system determines how long it can remain available.
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  `
})
export class OverviewComponent {
  service = inject(PowerSystemService);

  metrics = this.service.summaryMetrics;
  latest = this.service.latestTelemetry;

  readonly strategies: { id: AugmentationStrategy; label: string; desc: string }[] = [
    { id: 'GENERATION_PLUS_STORAGE', label: 'Gen + Storage', desc: 'Ramp generation + peak boost' },
    { id: 'GENERATION_ONLY', label: 'Generation Only', desc: 'Mode A: Reactor throttle only' },
    { id: 'STORAGE_ONLY', label: 'Storage Only', desc: 'Mode B: Base gen + battery boost' },
    { id: 'STORAGE_PEAK_SHAVING', label: 'Peak Shaving', desc: 'Discharge on load spikes' },
    { id: 'CONSTANT_POWER', label: 'Constant Power', desc: 'Maintain constant augmented load' },
    { id: 'THERMAL_LIMITED', label: 'Thermal Limited', desc: 'Derate power when radiator hot' },
    { id: 'STORAGE_LIFE_LIMITED', label: 'Life Limited', desc: 'Preserve battery cycle life' }
  ];

  onScenarioChange(event: Event) {
    const select = event.target as HTMLSelectElement;
    this.service.setScenario(select.value);
  }

  toggleBoost() {
    this.service.boostMode.update((b) => !b);
    this.service.runFullSystemSimulation();
  }
}
