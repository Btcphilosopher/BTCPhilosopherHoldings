import { Component, ChangeDetectionStrategy, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { PowerSystemService } from '../../services/power-system.service';

@Component({
  selector: 'app-bus',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-6 font-mono text-xs">
      <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-200 pb-4">
        <div>
          <h1 class="text-xl font-bold text-slate-900 tracking-tight font-tech">
            DC Distribution Power Bus & Harness Loss Model
          </h1>
          <p class="text-xs text-slate-500 font-mono mt-0.5">
            I_bus = P_bus / V_bus · Resistive Loss P_loss = I_bus² · R_bus · Ampacity Headroom
          </p>
        </div>
      </div>

      <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div class="bg-white border border-slate-200 rounded-lg p-5 shadow-xs space-y-4">
          <h2 class="font-bold text-slate-900 uppercase border-b border-slate-100 pb-2">
            DC Bus Configuration
          </h2>

          <div>
            <div class="text-slate-500 flex justify-between">
              <span>Nominal Rail Voltage (V_bus)</span>
              <span class="font-bold text-slate-900">{{ bus().voltage_nominal.val | number:'1.0-0' }} V</span>
            </div>
            <input
              type="range"
              min="120"
              max="600"
              step="10"
              [value]="bus().voltage_nominal.val"
              (input)="updateParam('voltage_nominal', $event)"
              class="w-full mt-1 accent-slate-900 cursor-pointer" />
          </div>

          <div>
            <div class="text-slate-500 flex justify-between">
              <span>Harness Resistance (R_bus)</span>
              <span class="font-bold text-slate-900">{{ (bus().resistance.val * 1000) | number:'1.2-2' }} mΩ</span>
            </div>
            <input
              type="range"
              min="0.0005"
              max="0.01"
              step="0.0001"
              [value]="bus().resistance.val"
              (input)="updateParam('resistance', $event)"
              class="w-full mt-1 accent-slate-900 cursor-pointer" />
          </div>

          <div>
            <div class="text-slate-500 flex justify-between">
              <span>Current Ampacity Limit (I_max)</span>
              <span class="font-bold text-slate-900">{{ bus().current_max.val | number:'1.0-0' }} A</span>
            </div>
            <input
              type="range"
              min="2000"
              max="20000"
              step="500"
              [value]="bus().current_max.val"
              (input)="updateParam('current_max', $event)"
              class="w-full mt-1 accent-slate-900 cursor-pointer" />
          </div>
        </div>

        <div class="bg-white border border-slate-200 rounded-lg p-5 shadow-xs space-y-3">
          <h2 class="font-bold text-slate-900 uppercase border-b border-slate-100 pb-2">
            Live Bus Electrical State Readout
          </h2>

          <div class="bg-slate-50 p-3 rounded space-y-2">
            <div class="flex justify-between"><span>Nominal Rail Voltage:</span><span class="font-bold">{{ bus().voltage_nominal.val | number:'1.0-0' }} V</span></div>
            <div class="flex justify-between"><span>Regulated Bus Voltage:</span><span class="font-bold text-slate-900">{{ (latest()?.v_bus || 300) | number:'1.1-1' }} V</span></div>
            <div class="flex justify-between"><span>Bus Current Draw:</span><span class="font-bold text-slate-900">{{ (latest()?.i_bus || 0) | number:'1.0-0' }} A</span></div>
            <div class="flex justify-between border-t border-slate-200 pt-1 font-bold text-rose-700">
              <span>Resistive Loss I²R:</span>
              <span>{{ (latest()?.p_bus_loss || 0) / 1e3 | number:'1.1-1' }} kW</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  `
})
export class BusComponent {
  service = inject(PowerSystemService);
  bus = () => this.service.params().bus;
  latest = this.service.latestTelemetry;

  updateParam(key: string, event: Event) {
    const val = parseFloat((event.target as HTMLInputElement).value);
    this.service.params.update((p) => {
      const copy = { ...p };
      (copy.bus as unknown as Record<string, { val: number }>)[key].val = val;
      return copy;
    });
    this.service.runFullSystemSimulation();
  }
}
