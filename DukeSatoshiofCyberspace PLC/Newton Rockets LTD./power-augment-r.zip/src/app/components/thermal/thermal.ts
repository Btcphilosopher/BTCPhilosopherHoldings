import { Component, ChangeDetectionStrategy, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { PowerSystemService } from '../../services/power-system.service';

@Component({
  selector: 'app-thermal',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-6 font-mono text-xs">
      <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-200 pb-4">
        <div>
          <h1 class="text-xl font-bold text-slate-900 tracking-tight font-tech">
            Multi-Node Thermal Network & Stefan-Boltzmann Radiator
          </h1>
          <p class="text-xs text-slate-500 font-mono mt-0.5">
            dU/dt = Q_generated - Q_rejected · Radiative Rejection Q_rad = ε·σ·A·(T⁴ - T_env⁴)
          </p>
        </div>
      </div>

      <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div class="bg-white border border-slate-200 rounded-lg p-5 shadow-xs space-y-4">
          <h2 class="font-bold text-slate-900 uppercase border-b border-slate-100 pb-2">
            Radiator & Sink Parameters
          </h2>

          <div>
            <div class="text-slate-500 flex justify-between">
              <span>Radiator Area (A)</span>
              <span class="font-bold text-slate-900">{{ th().radiator_area.val | number:'1.0-0' }} m²</span>
            </div>
            <input
              type="range"
              min="20"
              max="200"
              step="5"
              [value]="th().radiator_area.val"
              (input)="updateParam('radiator_area', $event)"
              class="w-full mt-1 accent-slate-900 cursor-pointer" />
          </div>

          <div>
            <div class="text-slate-500 flex justify-between">
              <span>Infrared Emissivity (ε)</span>
              <span class="font-bold text-slate-900">{{ th().emissivity.val | number:'1.2-2' }}</span>
            </div>
            <input
              type="range"
              min="0.60"
              max="0.98"
              step="0.01"
              [value]="th().emissivity.val"
              (input)="updateParam('emissivity', $event)"
              class="w-full mt-1 accent-slate-900 cursor-pointer" />
          </div>

          <div>
            <div class="text-slate-500 flex justify-between">
              <span>Ambient Sink Temp (T_env)</span>
              <span class="font-bold text-slate-900">{{ th().t_ambient_sink.val | number:'1.0-0' }} K</span>
            </div>
            <input
              type="range"
              min="3"
              max="300"
              step="5"
              [value]="th().t_ambient_sink.val"
              (input)="updateParam('t_ambient_sink', $event)"
              class="w-full mt-1 accent-slate-900 cursor-pointer" />
          </div>
        </div>

        <div class="bg-white border border-slate-200 rounded-lg p-5 shadow-xs space-y-3">
          <h2 class="font-bold text-slate-900 uppercase border-b border-slate-100 pb-2">
            5-Node Temperature State & Margins
          </h2>

          <div class="bg-slate-50 p-3 rounded space-y-2">
            <div class="flex justify-between"><span>Generator Node (T_gen):</span><span class="font-bold text-slate-900">{{ (latest()?.t_generator || 340) | number:'1.1-1' }} K</span></div>
            <div class="flex justify-between"><span>Converter Junction (T_conv):</span><span class="font-bold text-slate-900">{{ (latest()?.t_converter || 325) | number:'1.1-1' }} K</span></div>
            <div class="flex justify-between"><span>Distribution Bus (T_bus):</span><span class="font-bold text-slate-900">{{ (latest()?.t_bus || 310) | number:'1.1-1' }} K</span></div>
            <div class="flex justify-between"><span>Storage Buffer (T_stor):</span><span class="font-bold text-slate-900">{{ (latest()?.t_storage || 298) | number:'1.1-1' }} K</span></div>
            <div class="flex justify-between border-t border-slate-200 pt-1 font-bold text-rose-700">
              <span>Radiator Heat Rejection:</span>
              <span>{{ (latest()?.q_rad || 0) / 1e3 | number:'1.1-1' }} kW</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  `
})
export class ThermalComponent {
  service = inject(PowerSystemService);
  th = () => this.service.params().thermal;
  latest = this.service.latestTelemetry;

  updateParam(key: string, event: Event) {
    const val = parseFloat((event.target as HTMLInputElement).value);
    this.service.params.update((p) => {
      const copy = { ...p };
      (copy.thermal as unknown as Record<string, { val: number }>)[key].val = val;
      return copy;
    });
    this.service.runFullSystemSimulation();
  }
}
