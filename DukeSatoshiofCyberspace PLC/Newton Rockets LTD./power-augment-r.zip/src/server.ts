import {
  AngularNodeAppEngine,
  createNodeRequestHandler,
  isMainModule,
  writeResponseToNodeResponse,
} from '@angular/ssr/node';
import express from 'express';
import { join } from 'node:path';
import { readdirSync, readFileSync, statSync, existsSync } from 'node:fs';
import {
  runFullSimulation,
  createDefaultParameters,
  createDefaultLoads
} from './app/core/physics-engine';
import { calculatePowerEnvelope } from './app/core/power-envelope-engine';
import { runMonteCarlo } from './app/core/monte-carlo-engine';
import { runSensitivityAnalysis } from './app/core/sensitivity-engine';
import { runParetoOptimization } from './app/core/optimization-engine';
import { DigitalTwinPipeline } from './app/core/digital-twin-engine';
import { getMissionScenarios } from './app/core/scenarios-data';

const browserDistFolder = join(import.meta.dirname, '../browser');

const app = express();
app.use(express.json({ limit: '10mb' }));
const angularApp = new AngularNodeAppEngine();
const serverDigitalTwin = new DigitalTwinPipeline();

/**
 * Aerospace Digital Twin REST API Endpoints
 */
app.get('/api/health', (req, res) => {
  res.json({ status: 'HEALTHY', timestamp: new Date().toISOString(), system: 'power-augment-r' });
});

app.get('/api/scenarios', (req, res) => {
  res.json(getMissionScenarios());
});

const getErrMsg = (err: unknown): string => (err instanceof Error ? err.message : String(err));

app.post('/api/simulate', (req, res) => {
  try {
    const { params, duration, dt, method, loads, boost_mode } = req.body || {};
    const result = runFullSimulation(
      params || createDefaultParameters(),
      duration || 600,
      dt || 0.5,
      method || 'RK4',
      loads || createDefaultLoads(),
      !!boost_mode
    );
    res.json(result);
  } catch (err: unknown) {
    res.status(400).json({ error: getErrMsg(err) || 'Simulation execution failed' });
  }
});

app.post('/api/envelope', (req, res) => {
  try {
    const { params, durations } = req.body || {};
    const result = calculatePowerEnvelope(params || createDefaultParameters(), durations);
    res.json(result);
  } catch (err: unknown) {
    res.status(400).json({ error: getErrMsg(err) || 'Envelope calculation failed' });
  }
});

app.post('/api/monte-carlo', (req, res) => {
  try {
    const { params, n_iterations } = req.body || {};
    const result = runMonteCarlo(params || createDefaultParameters(), n_iterations || 500);
    res.json(result);
  } catch (err: unknown) {
    res.status(400).json({ error: getErrMsg(err) || 'Monte Carlo failed' });
  }
});

app.post('/api/sensitivity', (req, res) => {
  try {
    const { params, perturbation } = req.body || {};
    const result = runSensitivityAnalysis(params || createDefaultParameters(), perturbation || 0.10);
    res.json(result);
  } catch (err: unknown) {
    res.status(400).json({ error: getErrMsg(err) || 'Sensitivity calculation failed' });
  }
});

app.post('/api/optimize', (req, res) => {
  try {
    const { params, grid_points } = req.body || {};
    const result = runParetoOptimization(params || createDefaultParameters(), grid_points || 5);
    res.json(result);
  } catch (err: unknown) {
    res.status(400).json({ error: getErrMsg(err) || 'Optimization failed' });
  }
});

app.post('/api/digital-twin/step', (req, res) => {
  try {
    const { telemetry_point, faults } = req.body || {};
    if (!telemetry_point) {
      res.status(400).json({ error: 'Missing telemetry_point' });
      return;
    }
    const frame = serverDigitalTwin.step(telemetry_point, faults || {});
    res.json(frame);
    return;
  } catch (err: unknown) {
    res.status(400).json({ error: getErrMsg(err) || 'Digital twin step failed' });
    return;
  }
});

app.get('/api/r-package/files', (req, res) => {
  try {
    const baseDir = join(process.cwd(), 'power-augment-r');
    if (!existsSync(baseDir)) {
      res.json({ files: [] });
      return;
    }

    const getAllFiles = (dir: string, fileList: string[] = []): string[] => {
      const entries = readdirSync(dir);
      for (const entry of entries) {
        const fullPath = join(dir, entry);
        if (statSync(fullPath).isDirectory()) {
          getAllFiles(fullPath, fileList);
        } else {
          fileList.push(fullPath.replace(baseDir + '/', ''));
        }
      }
      return fileList;
    };

    const files = getAllFiles(baseDir);
    res.json({ baseDir: 'power-augment-r', files });
    return;
  } catch (err: unknown) {
    res.status(500).json({ error: getErrMsg(err) });
    return;
  }
});

app.get('/api/r-package/file', (req, res) => {
  try {
    const relativePath = (req.query['path'] as string) || 'DESCRIPTION';
    // prevent directory traversal
    const safePath = relativePath.replace(/\.\./g, '');
    const fullPath = join(process.cwd(), 'power-augment-r', safePath);
    if (!existsSync(fullPath)) {
      res.status(404).json({ error: 'File not found' });
      return;
    }
    const content = readFileSync(fullPath, 'utf-8');
    res.json({ path: safePath, content });
    return;
  } catch (err: unknown) {
    res.status(500).json({ error: getErrMsg(err) });
    return;
  }
});

/**
 * Serve static files from /browser
 */
app.use(
  express.static(browserDistFolder, {
    maxAge: '1y',
    index: false,
    redirect: false,
  }),
);

/**
 * Handle all other requests by rendering the Angular application.
 */
app.use((req, res, next) => {
  angularApp
    .handle(req)
    .then((response) =>
      response ? writeResponseToNodeResponse(response, res) : next(),
    )
    .catch(next);
});

/**
 * Start the server if this module is the main entry point, or it is ran via PM2.
 * The server listens on the port defined by the `PORT` environment variable, or defaults to 4000.
 */
if (isMainModule(import.meta.url) || process.env['pm_id']) {
  const port = process.env['PORT'] || 4000;
  app.listen(port, (error) => {
    if (error) {
      throw error;
    }

    console.log(`Node Express server listening on http://localhost:${port}`);
  });
}

/**
 * Request handler used by the Angular CLI (for dev-server and during build) or Firebase Cloud Functions.
 */
export const reqHandler = createNodeRequestHandler(app);
