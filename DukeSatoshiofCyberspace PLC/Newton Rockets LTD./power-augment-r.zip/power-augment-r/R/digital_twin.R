# ==============================================================================
# POWER-AUGMENT-R: Digital Twin Architecture & Extended Kalman Filter (EKF) Observer
# ==============================================================================

#' Create Digital Twin Pipeline Object
#' Pipeline: Physical Model -> Sensor Model (Noise + Bias) -> State Estimation (EKF) -> Diagnostics
#' @param params System configuration
#' @return R6 Digital Twin Engine instance
#' @export
create_digital_twin <- function(params = create_default_parameters()) {
  # State vector x = [P_gen, V_bus, I_bus, SOC, T_gen, T_conv, T_stor, T_bus]
  x_true <- c(
    p_gen = params$generation$augmented_power$val * 0.94,
    v_bus = params$bus$voltage_nominal$val,
    i_bus = 4500.0,
    soc = params$storage$soc_initial$val,
    t_gen = params$thermal$t_initial$generator,
    t_conv = params$thermal$t_initial$converter,
    t_stor = params$thermal$t_initial$storage,
    t_bus = params$thermal$t_initial$bus
  )
  
  # Sensor noise standard deviations (Measurement Covariance R)
  sensor_noise_sd <- c(
    p_gen = 15000.0,  # 15 kW sensor noise
    v_bus = 1.2,      # 1.2 V noise
    i_bus = 35.0,     # 35 A noise
    soc = 0.008,      # 0.8% SOC ADC noise
    t_gen = 0.8,      # 0.8 K RTD thermocouple noise
    t_conv = 0.6,
    t_stor = 0.4,
    t_bus = 0.5
  )
  
  # Sensor calibration biases
  sensor_bias <- c(
    p_gen = 0.0,
    v_bus = 0.0,
    i_bus = 0.0,
    soc = 0.0,
    t_gen = 0.0,
    t_conv = 0.0,
    t_stor = 0.0,
    t_bus = 0.0
  )
  
  # State Estimate x_hat and Initial Error Covariance P_cov
  x_hat <- x_true
  p_cov <- diag(c(1e8, 5.0, 1000.0, 0.001, 2.0, 2.0, 2.0, 2.0))
  
  list(
    params = params,
    x_true = x_true,
    sensor_noise_sd = sensor_noise_sd,
    sensor_bias = sensor_bias,
    x_hat = x_hat,
    p_cov = p_cov
  )
}

#' Step Digital Twin Observer Pipeline
#' @param dt_obj Digital twin state object
#' @param true_physics Physical state output from simulation
#' @param faults Active injected faults list
#' @param dt Step size [s]
#' @return List with True State, Measured State, Estimated State, Innovation Residuals, and Health Diagnostics
#' @export
step_digital_twin <- function(dt_obj, true_physics, faults = list(), dt = 0.5) {
  # 1. Update Physical True State from physics engine
  x_true <- c(
    p_gen = true_physics$p_gen_elec,
    v_bus = true_physics$v_bus,
    i_bus = true_physics$i_bus,
    soc = true_physics$soc,
    t_gen = true_physics$t_generator,
    t_conv = true_physics$t_converter,
    t_stor = true_physics$t_storage,
    t_bus = true_physics$t_bus
  )
  
  # 2. Sensor Model (Apply sensor noise, bias, and injected sensor faults)
  bias_vec <- dt_obj$sensor_bias
  if (!is.null(faults$sensor_bias)) {
    bias_vec["v_bus"] <- bias_vec["v_bus"] + faults$sensor_bias$v_bus
    bias_vec["t_conv"] <- bias_vec["t_conv"] + faults$sensor_bias$t_conv
  }
  
  noise_mult <- if (!is.null(faults$sensor_noise_boost)) faults$sensor_noise_boost else 1.0
  noise_vec <- rnorm(length(x_true), mean = 0, sd = dt_obj$sensor_noise_sd * noise_mult)
  
  # Measured Telemetry
  z_measured <- x_true + bias_vec + noise_vec
  
  # 3. State Estimation (EKF Observer Filtering)
  # Predict step: x_hat_prior = f(x_hat, dt)
  x_hat_prior <- dt_obj$x_hat
  x_hat_prior["soc"] <- max(0.05, min(1.0, x_hat_prior["soc"] + (true_physics$p_stor_charge - true_physics$p_stor_disch) * dt / 1800e6))
  x_hat_prior["t_gen"] <- x_hat_prior["t_gen"] + (true_physics$p_gen_loss / 85000.0) * dt
  
  # Innovation residual: e = z - H*x_hat_prior
  innovation_residual <- z_measured - x_hat_prior
  
  # Kalman Gain update K = P * H^T * (H * P * H^T + R)^-1
  # For diagonal approximation in real-time step:
  kalman_gain <- c(0.45, 0.65, 0.60, 0.50, 0.35, 0.35, 0.30, 0.35)
  x_hat_updated <- x_hat_prior + kalman_gain * innovation_residual
  
  # Update internal state
  dt_obj$x_true <- x_true
  dt_obj$x_hat <- x_hat_updated
  
  # 4. Diagnostics & Health Rating
  # Compute statistical anomaly thresholds
  health_status <- "NORMAL"
  fault_flags <- list()
  
  if (abs(innovation_residual["v_bus"]) > 6.0 || abs(innovation_residual["t_conv"]) > 8.0) {
    health_status <- "WARNING"
    fault_flags$sensor_discrepancy <- TRUE
  }
  
  if (x_true["t_conv"] > 380.0 || x_true["t_stor"] > 330.0 || x_true["soc"] < 0.18) {
    health_status <- "LIMITED"
    fault_flags$thermal_or_soc_limit <- TRUE
  }
  
  if (x_true["t_gen"] > 475.0 || x_true["i_bus"] > 11500.0) {
    health_status <- "FAULT"
    fault_flags$critical_ampacity_or_thermal_exceeded <- TRUE
  }

  list(
    true_state = as.list(x_true),
    measured_state = as.list(z_measured),
    estimated_state = as.list(x_hat_updated),
    innovation_residual = as.list(innovation_residual),
    health_status = health_status,
    fault_flags = fault_flags,
    updated_dt_obj = dt_obj
  )
}
