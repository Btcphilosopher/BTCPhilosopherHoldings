# ==============================================================================
# POWER-AUGMENT-R: Energy Storage (Battery / Supercapacitor Buffer)
# ==============================================================================

#' Model Electrochemical & Supercapacitor Energy Storage Node
#' @param p_cmd Storage commanded power [W] (positive = discharge, negative = charge)
#' @param soc Current State of Charge [0,1]
#' @param v_bus Current DC bus voltage [V]
#' @param dt Simulation timestep [s]
#' @param stor_params Storage configuration parameters
#' @return List with electrical power delivered/absorbed, losses, new SOC, and current
#' @export
create_storage_system <- function(p_cmd, soc, v_bus, dt, stor_params) {
  cap_total <- stor_params$capacity_total_j$val * stor_params$health$val
  soc_min <- stor_params$soc_min$val
  soc_max <- stor_params$soc_max$val
  r_esr <- stor_params$internal_resistance$val
  eff_rt <- stor_params$roundtrip_efficiency$val
  max_disch <- stor_params$max_discharge_power$val * stor_params$health$val
  max_ch <- stor_params$max_charge_power$val
  
  # Open-circuit voltage model as function of SOC: Voc(SOC) = V_nom * (0.92 + 0.16 * SOC)
  v_oc <- v_bus * (0.92 + 0.16 * soc)

  p_delivered <- 0.0
  p_absorbed <- 0.0
  p_loss <- 0.0
  i_stor <- 0.0
  d_soc <- 0.0

  if (p_cmd > 0) {
    # Discharge mode (Providing power to spacecraft bus)
    if (soc > soc_min) {
      # Clamped to maximum discharge rating and remaining usable energy
      max_power_avail <- min(max_disch, (soc - soc_min) * cap_total / dt)
      p_requested <- min(p_cmd, max_power_avail)
      
      # Internal current estimate
      i_stor <- if (v_oc > 0) p_requested / v_oc else 0
      p_loss <- (i_stor^2) * r_esr
      p_delivered <- max(0, p_requested - p_loss)
      
      # Energy depleted from internal chemical potential
      energy_depleted <- (p_requested) * dt
      d_soc <- - (energy_depleted / cap_total)
    }
  } else if (p_cmd < 0) {
    # Charge mode (Absorbing power from excess generation)
    if (soc < soc_max) {
      max_charge_avail <- min(max_ch, (soc_max - soc) * cap_total / dt)
      p_charge_in <- min(abs(p_cmd), max_charge_avail)
      
      i_stor <- if (v_oc > 0) p_charge_in / v_oc else 0
      p_loss <- (i_stor^2) * r_esr + p_charge_in * (1.0 - eff_rt)
      p_absorbed <- p_charge_in
      
      energy_stored_eff <- (p_charge_in - p_loss) * dt
      d_soc <- (max(0, energy_stored_eff) / cap_total)
    }
  }

  new_soc <- max(soc_min, min(soc_max, soc + d_soc))

  list(
    p_disch = p_delivered,
    p_charge = p_absorbed,
    p_loss = p_loss,
    i_stor = i_stor,
    soc = new_soc,
    d_soc_dt = d_soc / dt,
    v_oc = v_oc
  )
}
