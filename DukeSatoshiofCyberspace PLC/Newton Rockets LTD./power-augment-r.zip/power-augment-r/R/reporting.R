# ==============================================================================
# POWER-AUGMENT-R: Automated Engineering Dossier & Report Generator
# ==============================================================================

#' Generate Aerospace Electrical Power Engineering Report
#' @param sim_result Simulation output object from run_simulation()
#' @param envelope_df Optional envelope dataframe
#' @param mc_result Optional Monte Carlo result
#' @param opt_result Optional optimization result
#' @param format "html", "markdown", or "json"
#' @return Formatted report text string
#' @export
generate_engineering_report <- function(sim_result, envelope_df = NULL, mc_result = NULL, opt_result = NULL, format = "markdown") {
  telemetry <- sim_result$telemetry
  summ <- sim_result$summary
  
  p_base_mw <- telemetry$p_baseline[1] / 1e6
  p_gen_aug_mw <- mean(telemetry$p_gen_gross) / 1e6
  gross_increase_mw <- p_gen_aug_mw - p_base_mw
  conv_loss_mw <- mean(telemetry$p_conv_loss) / 1e6
  dist_loss_mw <- mean(telemetry$p_bus_loss) / 1e6
  net_add_mw <- mean(telemetry$delta_p) / 1e6
  peak_avail_mw <- max(telemetry$p_usable) / 1e6
  sustainable_mw <- mean(telemetry$p_usable) / 1e6
  stor_contrib_mw <- mean(telemetry$p_stor_disch) / 1e6
  thermal_margin_pct <- min(telemetry$thermal_margin) * 100.0
  sys_eff_pct <- mean(telemetry$eff_system) * 100.0
  p_gain_pct <- mean(telemetry$p_gain_pct)
  max_residual_mj <- summ$max_energy_residual_mj
  
  if (format == "json") {
    report_data <- list(
      executive_summary = list(
        baseline_generation_mw = p_base_mw,
        augmented_generation_mw = p_gen_aug_mw,
        gross_increase_mw = gross_increase_mw,
        conversion_losses_mw = conv_loss_mw,
        distribution_losses_mw = dist_loss_mw,
        net_additional_power_mw = net_add_mw,
        peak_available_power_mw = peak_avail_mw,
        sustainable_power_mw = sustainable_mw,
        storage_contribution_mw = stor_contrib_mw,
        thermal_margin_pct = thermal_margin_pct,
        system_efficiency_pct = sys_eff_pct,
        power_increase_pct = p_gain_pct,
        energy_residual_max_mj = max_residual_mj,
        is_energy_conserved = summ$is_energy_conserved
      ),
      summary = summ
    )
    return(jsonlite::toJSON(report_data, pretty = TRUE, auto_unbox = TRUE))
  }
  
  # Markdown / Text Engineering Dossier
  report_md <- paste0(
"================================================================================
           POWER AUGMENTATION ENGINEERING DOSSIER & DIGITAL TWIN
================================================================================
Organization : Aerospace Electrical Systems Engineering Group
Classification: Production Engineering Digital Twin
Date / UTC   : ", format(Sys.time(), "%Y-%m-%d %H:%M:%S UTC"), "
Strategy     : ", summ$strategy, "
Integration  : Numerical Solver = ", summ$method, " (dt = ", summ$dt, " s)
================================================================================

1. EXECUTIVE POWER AUGMENTATION BALANCE
────────────────────────────────────────────────────────────────────────────────
Baseline Generation               : ", sprintf("%6.2f MW", p_base_mw), "
Augmented Generation (Gross)      : ", sprintf("%6.2f MW", p_gen_aug_mw), "

Gross Generation Increase         : ", sprintf("%+6.2f MW", gross_increase_mw), "
Power Conversion Losses           : ", sprintf("%6.2f MW", conv_loss_mw), "
DC Distribution Bus Losses (I²R)  : ", sprintf("%6.2f MW", dist_loss_mw), "

Net Additional Power              : ", sprintf("%+6.2f MW", net_add_mw), "

Peak Available Power (w/ Storage) : ", sprintf("%6.2f MW", peak_avail_mw), "
Sustainable Power (Continuous)    : ", sprintf("%6.2f MW", sustainable_mw), "
Storage Contribution (Discharge)  : ", sprintf("%6.2f MW", stor_contrib_mw), "

System Thermal Margin (Minimum)   : ", sprintf("%6.1f %%", thermal_margin_pct), "
System Energy Efficiency          : ", sprintf("%6.1f %%", sys_eff_pct), "
Net Power Gain Percentage         : ", sprintf("%+6.1f %%", p_gain_pct), "
────────────────────────────────────────────────────────────────────────────────

2. FIRST LAW OF THERMODYNAMICS & ENERGY CONSERVATION AUDIT
────────────────────────────────────────────────────────────────────────────────
Cumulative Energy Generated       : ", sprintf("%8.2f MJ", tail(telemetry$cum_e_source_mj, 1)), "
Cumulative Energy Delivered Loads : ", sprintf("%8.2f MJ", tail(telemetry$cum_e_delivered_mj, 1)), "
Cumulative Energy Delta Stored    : ", sprintf("%8.2f MJ", tail(telemetry$cum_e_stored_mj, 1)), "
Cumulative Electrical Losses      : ", sprintf("%8.2f MJ", tail(telemetry$cum_e_losses_mj, 1)), "
Cumulative Radiative Heat Reject. : ", sprintf("%8.2f MJ", tail(telemetry$cum_e_dissipated_mj, 1)), "

Maximum Timestep Energy Residual  : ", sprintf("%8.6f MJ", max_residual_mj), "
Energy Conservation Status        : ", if (summ$is_energy_conserved) "[VERIFIED - RESIDUAL ≈ 0]" else "[ALERT - RESIDUAL EXCEEDED TOLERANCE]", "
────────────────────────────────────────────────────────────────────────────────

3. THERMAL STATE & COMPONENT MARGINS
────────────────────────────────────────────────────────────────────────────────
Primary Generator Final Temp      : ", sprintf("%6.1f K (Limit: 480.0 K)", tail(telemetry$t_generator, 1)), "
Power Converter Final Temp        : ", sprintf("%6.1f K (Limit: 395.0 K)", tail(telemetry$t_converter, 1)), "
DC Distribution Bus Final Temp    : ", sprintf("%6.1f K (Limit: 370.0 K)", tail(telemetry$t_bus, 1)), "
Storage Battery Buffer Final Temp : ", sprintf("%6.1f K (Limit: 335.0 K)", tail(telemetry$t_storage, 1)), "
Thermal Radiator Equilibrium Temp : ", sprintf("%6.1f K", tail(telemetry$t_radiator, 1)), "
────────────────────────────────────────────────────────────────────────────────
"
  )
  
  report_md
}
