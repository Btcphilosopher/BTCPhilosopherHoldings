# ==============================================================================
# POWER-AUGMENT-R: Sensitivity Analysis Engine & Tornado Rankings
# ==============================================================================

#' Compute One-At-a-Time (OAT) & Elasticity Sensitivity Indices
#' Measures sensitivity of Usable Power, Thermal Margin, and Distribution Losses
#' across physical parameters (+/- 10% perturbation)
#' @param base_params Base parameters
#' @param perturbation_pct Fractional perturbation (default 0.10 for +/- 10%)
#' @return Tibble of sensitivity derivatives, elasticities, and Tornado ranking
#' @export
run_sensitivity_analysis <- function(base_params = create_default_parameters(), perturbation_pct = 0.10) {
  params_to_test <- list(
    list(id = "eta_generator", name = "Generator Efficiency (eta_gen)", path = c("generation", "efficiency_0", "val"), unit = "ratio"),
    list(id = "eta_converter", name = "Converter Efficiency (eta_conv)", path = c("converter", "efficiency_nominal", "val"), unit = "ratio"),
    list(id = "v_bus", name = "Bus Nominal Voltage (V_bus)", path = c("bus", "voltage_nominal", "val"), unit = "V"),
    list(id = "r_bus", name = "Bus Harness Resistance (R_bus)", path = c("bus", "resistance", "val"), unit = "Ohm"),
    list(id = "stor_cap", name = "Storage Capacity (C_stor)", path = c("storage", "capacity_total_j", "val"), unit = "J"),
    list(id = "stor_power", name = "Storage Discharge Power (P_stor_max)", path = c("storage", "max_discharge_power", "val"), unit = "W"),
    list(id = "rad_area", name = "Radiator Area (A_rad)", path = c("thermal", "radiator_area", "val"), unit = "m^2"),
    list(id = "emissivity", name = "Radiator Emissivity (eps)", path = c("thermal", "emissivity", "val"), unit = "ratio"),
    list(id = "t_ambient", name = "Ambient Sink Temperature (T_env)", path = c("thermal", "t_ambient_sink", "val"), unit = "K")
  )
  
  # Base evaluation function
  eval_model <- function(p) {
    p_gen <- p$generation$augmented_power$val * p$generation$health$val * p$generation$efficiency_0$val
    p_conv <- p_gen * p$converter$efficiency_nominal$val
    p_stor <- p$storage$max_discharge_power$val * p$storage$health$val
    
    # Bus loss at 2.0 MW load
    i_bus <- 2.0e6 / p$bus$voltage_nominal$val
    p_bus_loss <- (i_bus^2) * p$bus$resistance$val
    p_usable <- p_conv + p_stor - p_bus_loss
    
    # Thermal margin
    sigma <- 5.670374419e-8
    q_rad <- p$thermal$emissivity$val * sigma * p$thermal$radiator_area$val * (345.0^4 - p$thermal$t_ambient_sink$val^4)
    p_loss_tot <- (p$generation$augmented_power$val - p_gen) + (p_gen - p_conv) + p_bus_loss
    thermal_margin_pct <- max(0, 100.0 * (q_rad - p_loss_tot) / q_rad)
    
    list(
      usable_power_mw = p_usable / 1e6,
      thermal_margin_pct = thermal_margin_pct,
      bus_loss_kw = p_bus_loss / 1e3
    )
  }
  
  base_eval <- eval_model(base_params)
  tornado_rows <- list()
  
  for (item in params_to_test) {
    val_nominal <- base_params[[item$path[1]]][[item$path[2]]][[item$path[3]]]
    
    # Perturb low (-10%)
    p_low <- base_params
    p_low[[item$path[1]]][[item$path[2]]][[item$path[3]]] <- val_nominal * (1.0 - perturbation_pct)
    eval_low <- eval_model(p_low)
    
    # Perturb high (+10%)
    p_high <- base_params
    p_high[[item$path[1]]][[item$path[2]]][[item$path[3]]] <- val_nominal * (1.0 + perturbation_pct)
    eval_high <- eval_model(p_high)
    
    # Elasticity: (dY/Y) / (dX/X)
    delta_y_power <- eval_high$usable_power_mw - eval_low$usable_power_mw
    elasticity_power <- (delta_y_power / base_eval$usable_power_mw) / (2 * perturbation_pct)
    
    delta_y_thermal <- eval_high$thermal_margin_pct - eval_low$thermal_margin_pct
    
    tornado_rows[[length(tornado_rows) + 1]] <- list(
      param_id = item$id,
      param_name = item$name,
      unit = item$unit,
      nominal_val = val_nominal,
      low_val = val_nominal * (1 - perturbation_pct),
      high_val = val_nominal * (1 + perturbation_pct),
      power_low_mw = eval_low$usable_power_mw,
      power_high_mw = eval_high$usable_power_mw,
      power_swing_mw = abs(eval_high$usable_power_mw - eval_low$usable_power_mw),
      power_elasticity = elasticity_power,
      thermal_low_pct = eval_low$thermal_margin_pct,
      thermal_high_pct = eval_high$thermal_margin_pct,
      thermal_swing_pct = abs(eval_high$thermal_margin_pct - eval_low$thermal_margin_pct)
    )
  }
  
  df_tornado <- dplyr::bind_rows(tornado_rows) %>%
    dplyr::arrange(desc(power_swing_mw))
  
  list(
    base_metrics = base_eval,
    tornado = df_tornado
  )
}
