# ==============================================================================
# POWER-AUGMENT-R: Multi-Node Lumped-Parameter Thermal Network & Radiative Rejection
# ==============================================================================

#' 5-Node Spacecraft Thermal Network with Stefan-Boltzmann Radiator
#' Nodes: Generator (1), Converter (2), Bus (3), Storage (4), Radiator (5)
#' @param q_gen Heat generated in primary generator [W]
#' @param q_conv Heat generated in power converter [W]
#' @param q_bus Heat generated in distribution bus [W]
#' @param q_stor Heat generated in energy storage [W]
#' @param temps Current temperatures vector (T_gen, T_conv, T_bus, T_stor, T_rad) [K]
#' @param thermal_params Thermal configuration parameters
#' @param limits Limit parameters
#' @return List of dT/dt derivatives, radiated heat, margins, and limit statuses
#' @export
create_thermal_network <- function(q_gen, q_conv, q_bus, q_stor, temps, thermal_params, limits) {
  sigma <- 5.670374419e-8 # Stefan-Boltzmann constant
  a_rad <- thermal_params$radiator_area$val
  eps <- thermal_params$emissivity$val
  t_env <- thermal_params$t_ambient_sink$val
  
  t_gen <- temps["generator"]
  t_conv <- temps["converter"]
  t_bus <- temps["bus"]
  t_stor <- temps["storage"]
  t_rad <- temps["radiator"]
  
  # Conductive couplings to radiator loop [W/K]
  g_gen_rad <- thermal_params$thermal_conductivity_matrix$gen_to_rad
  g_conv_rad <- thermal_params$thermal_conductivity_matrix$conv_to_rad
  g_bus_rad <- thermal_params$thermal_conductivity_matrix$bus_to_rad
  g_stor_rad <- thermal_params$thermal_conductivity_matrix$stor_to_rad
  
  # Conductive heat transfer rates into the radiator loop [W]
  q_cond_gen <- g_gen_rad * (t_gen - t_rad)
  q_cond_conv <- g_conv_rad * (t_conv - t_rad)
  q_cond_bus <- g_bus_rad * (t_bus - t_rad)
  q_cond_stor <- g_stor_rad * (t_stor - t_rad)
  
  # Radiative heat rejection from radiator to space: Q_rad = eps * sigma * A * (T_rad^4 - T_env^4)
  t_rad_clamped <- max(0.0, t_rad)
  t_env_clamped <- max(0.0, t_env)
  q_rad <- eps * sigma * a_rad * (t_rad_clamped^4 - t_env_clamped^4)
  
  # Thermal capacitances C_th [J/K]
  c_gen <- limits$gen_c_th
  c_conv <- limits$conv_c_th
  c_bus <- limits$bus_c_th
  c_stor <- limits$stor_c_th
  c_rad <- 45000.0 # Radiator panel thermal capacitance
  
  # Energy conservation differential equations: C_i * dT_i/dt = Q_gen_i - Q_cond_i
  dt_gen <- (q_gen - q_cond_gen) / c_gen
  dt_conv <- (q_conv - q_cond_conv) / c_conv
  dt_bus <- (q_bus - q_cond_bus) / c_bus
  dt_stor <- (q_stor - q_cond_stor) / c_stor
  
  # Radiator loop node: C_rad * dT_rad/dt = sum(Q_cond_in) - Q_rad
  q_cond_total_in <- q_cond_gen + q_cond_conv + q_cond_bus + q_cond_stor
  dt_rad <- (q_cond_total_in - q_rad) / c_rad
  
  # Thermal Margins to maximum allowable temperatures
  t_gen_max <- limits$t_gen_max
  t_conv_max <- limits$t_conv_max
  t_bus_max <- limits$t_bus_max
  t_stor_max <- limits$t_stor_max
  
  margin_gen <- max(0, (t_gen_max - t_gen) / t_gen_max)
  margin_conv <- max(0, (t_conv_max - t_conv) / t_conv_max)
  margin_bus <- max(0, (t_bus_max - t_bus) / t_bus_max)
  margin_stor <- max(0, (t_stor_max - t_stor) / t_stor_max)
  
  system_thermal_margin <- min(margin_gen, margin_conv, margin_bus, margin_stor)
  
  # Is any subsystem thermally violated?
  is_thermal_limit_exceeded <- (t_gen > t_gen_max || t_conv > t_conv_max || t_bus > t_bus_max || t_stor > t_stor_max)
  
  list(
    derivatives = c(
      generator = dt_gen,
      converter = dt_conv,
      bus = dt_bus,
      storage = dt_stor,
      radiator = dt_rad
    ),
    q_heat_total_generated = q_gen + q_conv + q_bus + q_stor,
    q_rejected_rad = q_rad,
    thermal_margin = system_thermal_margin,
    margins = list(
      generator = margin_gen,
      converter = margin_conv,
      bus = margin_bus,
      storage = margin_stor
    ),
    is_limit_exceeded = is_thermal_limit_exceeded
  )
}
