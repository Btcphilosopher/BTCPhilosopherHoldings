# ==============================================================================
# POWER-AUGMENT-R: Telemetry Recording, Replay, and Serialization
# ==============================================================================

#' Replay Recorded Mission Telemetry Stream
#' @param file_path Path to JSON or CSV telemetry file
#' @param playback_speed Speed factor (1.0 = real-time, 10.0 = fast)
#' @return Parsed telemetry dataframe with metadata
#' @export
replay_telemetry <- function(file_path, playback_speed = 1.0) {
  if (!file.exists(file_path)) {
    stop("Telemetry file does not exist: ", file_path)
  }
  
  if (grepl("\\.json$", file_path, ignore.case = TRUE)) {
    data <- jsonlite::fromJSON(file_path)
    if (is.list(data) && !is.data.frame(data) && "telemetry" %in% names(data)) {
      df <- as.data.frame(data$telemetry)
    } else {
      df <- as.data.frame(data)
    }
  } else {
    df <- readr::read_csv(file_path, show_col_types = FALSE)
  }
  
  list(
    data = df,
    records_count = nrow(df),
    duration_s = max(df$time, na.rm = TRUE),
    playback_speed = playback_speed
  )
}

#' Export Telemetry to Multiple Standard Formats (CSV, JSON)
#' @param telemetry_df Telemetry dataframe
#' @param out_base_path Base output path without extension
#' @export
export_telemetry_files <- function(telemetry_df, out_base_path = "output/telemetry_export") {
  dir.create(dirname(out_base_path), showWarnings = FALSE, recursive = TRUE)
  
  # CSV
  csv_file <- paste0(out_base_path, ".csv")
  readr::write_csv(telemetry_df, csv_file)
  
  # JSON
  json_file <- paste0(out_base_path, ".json")
  jsonlite::write_json(telemetry_df, json_file, pretty = TRUE, auto_unbox = TRUE)
  
  list(csv = csv_file, json = json_file)
}
