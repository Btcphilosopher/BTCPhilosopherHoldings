# ==============================================================================
# POWER-AUGMENT-R: System Parameters and State Vectors
# ==============================================================================

#' Create Default Spacecraft Power System Parameters
#' @return A comprehensive list of validated engineering parameters with metadata
#' @export
create_default_parameters <- function() {
  list(
    # Primary Generation
    generation = list(
      baseline_power = list(val = 1.8e6, unit = "W", desc = "Baseline nuclear/solar power", prov = "QUALIFIED_BASELINE", min = 0.5e6, max = 5e6),
      augmented_power = list(val = 2.4e6, unit = "W", desc = "Augmented reactor/boost power", prov = "MEASURED_TEST", min = 0.5e6, max = 10e6),
      voltage_gen = list(val = 1200.0, unit = "V", desc = "Generator output voltage", prov = "DESIGN_SPEC", min = 200, max = 5000),
      efficiency_0 = list(val = 0.94, unit = "ratio", desc = "Nominal generator conversion efficiency", prov = "MEASURED_TEST", min = 0.70, max = 0.99),
      temp_coefficient = list(val = 0.0008, unit = "1/K", desc = "Thermal derating coefficient gamma", prov = "EMPIRICAL_FIT", min = 0.0001, max = 0.003),
      t_ref = list(val = 300.0, unit = "K", desc = "Reference temperature for efficiency", prov = "STANDARD", min = 200, max = 500),
      thermal_mass = list(val = 85000.0, unit = "J/K", desc = "Generator heat capacity C_th", prov = "ESTIMATED_CAD", min = 1e4, max = 1e6),
      t_max = list(val = 480.0, unit = "K", desc = "Maximum allowable generator temp", prov = "HARD_LIMIT", min = 350, max = 800),
      health = list(val = 1.0, unit = "ratio", desc = "Health/degradation factor [0,1]", prov = "ESTIMATED_OBSERVER", min = 0.0, max = 1.0)
    ),

    # Power Conversion & Conditioning
    converter = list(
      efficiency_nominal = list(val = 0.965, unit = "ratio", desc = "DC-DC power converter efficiency", prov = "QUALIFIED_BENCH", min = 0.80, max = 0.995),
      voltage_out = list(val = 300.0, unit = "V", desc = "Regulated bus output voltage", prov = "DESIGN_SPEC", min = 28, max = 1000),
      max_power_rating = list(val = 3.5e6, unit = "W", desc = "Peak power throughput limit", prov = "HARD_LIMIT", min = 1e6, max = 10e6),
      switching_loss_factor = list(val = 0.015, unit = "ratio", desc = "Frequency-dependent switching loss fraction", prov = "EMPIRICAL_FIT", min = 0.005, max = 0.05),
      thermal_mass = list(val = 35000.0, unit = "J/K", desc = "Converter thermal mass C_th", prov = "ESTIMATED_CAD", min = 5e3, max = 5e5),
      t_max = list(val = 395.0, unit = "K", desc = "Maximum allowable silicon-carbide junction temp", prov = "HARD_LIMIT", min = 320, max = 450)
    ),

    # DC Power Distribution Bus
    bus = list(
      voltage_nominal = list(val = 300.0, unit = "V", desc = "Nominal DC bus rail voltage", prov = "DESIGN_SPEC", min = 28, max = 1000),
      resistance = list(val = 0.0028, unit = "Ohm", desc = "Total distribution bus resistance R_bus", prov = "MEASURED_HARNESS", min = 0.0005, max = 0.05),
      capacitance = list(val = 0.085, unit = "F", desc = "Bus filter capacitance", prov = "COMPONENT_SPEC", min = 0.01, max = 1.0),
      current_max = list(val = 12000.0, unit = "A", desc = "Bus harness ampacity limit", prov = "HARD_LIMIT", min = 1000, max = 25000),
      thermal_mass = list(val = 25000.0, unit = "J/K", desc = "Bus bar thermal capacitance C_th", prov = "ESTIMATED_CAD", min = 5e3, max = 2e5),
      t_max = list(val = 370.0, unit = "K", desc = "Maximum allowable bus insulation temp", prov = "HARD_LIMIT", min = 300, max = 420)
    ),

    # Energy Storage Buffer (Battery / Supercapacitor matrix)
    storage = list(
      capacity_total_j = list(val = 1800e6, unit = "J", desc = "Total usable energy capacity (500 kWh = 1800 MJ)", prov = "CELL_SPEC", min = 100e6, max = 10000e6),
      soc_initial = list(val = 0.90, unit = "ratio", desc = "Initial State of Charge", prov = "MEASURED_TELEMETRY", min = 0.05, max = 1.0),
      soc_min = list(val = 0.15, unit = "ratio", desc = "Minimum safe depth of discharge", prov = "SAFETY_LIMIT", min = 0.05, max = 0.30),
      soc_max = list(val = 0.98, unit = "ratio", desc = "Maximum charge cutoff", prov = "SAFETY_LIMIT", min = 0.85, max = 1.0),
      max_discharge_power = list(val = 1.2e6, unit = "W", desc = "Peak discharge power rating (1.2 MW)", prov = "CELL_LIMIT", min = 0.1e6, max = 5e6),
      max_charge_power = list(val = 0.6e6, unit = "W", desc = "Peak charge power rating (0.6 MW)", prov = "CELL_LIMIT", min = 0.05e6, max = 3e6),
      internal_resistance = list(val = 0.0035, unit = "Ohm", desc = "ESR internal resistance", prov = "MEASURED_EIS", min = 0.0005, max = 0.02),
      roundtrip_efficiency = list(val = 0.93, unit = "ratio", desc = "Coulombic/roundtrip charge efficiency", prov = "QUALIFIED_BENCH", min = 0.80, max = 0.98),
      thermal_mass = list(val = 120000.0, unit = "J/K", desc = "Storage module thermal mass C_th", prov = "ESTIMATED_CAD", min = 2e4, max = 1e6),
      t_max = list(val = 335.0, unit = "K", desc = "Maximum allowable electrochemical temp (61.85 C)", prov = "HARD_LIMIT", min = 300, max = 360),
      health = list(val = 0.98, unit = "ratio", desc = "Capacity retention health factor", prov = "ESTIMATED_OBSERVER", min = 0.4, max = 1.0)
    ),

    # Thermal Rejection & Radiator System
    thermal = list(
      radiator_area = list(val = 65.0, unit = "m^2", desc = "Effective radiator surface area", prov = "DESIGN_SPEC", min = 10, max = 300),
      emissivity = list(val = 0.91, unit = "ratio", desc = "Radiator infrared emissivity epsilon", prov = "MATERIAL_COATING", min = 0.70, max = 0.98),
      t_ambient_sink = list(val = 220.0, unit = "K", desc = "Effective environmental radiative sink temp", prov = "MISSION_ORBIT", min = 3, max = 320),
      thermal_conductivity_matrix = list(
        gen_to_rad = 120.0,   # W/K
        conv_to_rad = 180.0,  # W/K
        bus_to_rad = 60.0,    # W/K
        stor_to_rad = 220.0   # W/K
      ),
      t_initial = list(
        generator = 340.0,
        converter = 325.0,
        bus = 310.0,
        storage = 298.0,
        radiator = 305.0
      )
    ),

    # Operational Strategy
    strategy = "GENERATION_PLUS_STORAGE" # GENERATION_ONLY, STORAGE_ONLY, GENERATION_PLUS_STORAGE, STORAGE_PEAK_SHAVING, CONSTANT_POWER, THERMAL_LIMITED, STORAGE_LIFE_LIMITED
  )
}
