#!/usr/bin/env Rscript
# ==============================================================================
# POWER-AUGMENT-R: Command-Line Interface (CLI) Dispatcher
# ==============================================================================

suppressPackageStartupMessages({
  library(tibble)
  library(dplyr)
  library(jsonlite)
})

# Source internal modules if running from script
script_dir <- tryCatch({
  dirname(normalizePath(sys.frame(1)$ofile))
}, error = function(e) {
  "R"
})

r_files <- list.files(script_dir, pattern = "\\.R$", full.names = TRUE)
r_files <- r_files[!grepl("cli\\.R$", r_files)]
for (f in r_files) {
  tryCatch(source(f), error = function(e) {})
}

args <- commandArgs(trailingOnly = TRUE)

if (length(args) == 0) {
  cat("
POWER-AUGMENT-R: Command-Line Interface
Usage:
  Rscript R/cli.R simulate [--strategy STRATEGY] [--duration SEC] [--step DT] [--out FILE]
  Rscript R/cli.R scenario <scenario_name> [--out FILE]
  Rscript R/cli.R envelope [--durations DURS] [--out FILE]
  Rscript R/cli.R monte-carlo [--n ITERATIONS] [--out FILE]
  Rscript R/cli.R sensitivity [--out FILE]
  Rscript R/cli.R optimise [--grid POINTS] [--out FILE]
  Rscript R/cli.R validate [--tolerance TOL]
  Rscript R/cli.R report [--format markdown|json|html] [--out FILE]
\n")
  quit(status = 0)
}

subcmd <- tolower(args[1])

if (subcmd == "simulate") {
  cat("[POWER-AUGMENT-R] Running Time-Domain Simulation...\n")
  res <- run_simulation()
  rep <- generate_engineering_report(res)
  cat(rep)
  
} else if (subcmd == "scenario") {
  sc_name <- if (length(args) >= 2) toupper(args[2]) else "POWER_BOOST"
  cat("[POWER-AUGMENT-R] Executing Scenario:", sc_name, "\n")
  res <- run_scenario(sc_name)
  rep <- generate_engineering_report(res)
  cat(rep)
  
} else if (subcmd == "envelope") {
  cat("[POWER-AUGMENT-R] Computing Multi-Constraint Power Envelope...\n")
  env_df <- calculate_power_envelope()
  print(as.data.frame(env_df))
  
} else if (subcmd == "monte-carlo") {
  cat("[POWER-AUGMENT-R] Running Stochastic Monte Carlo Engine...\n")
  mc <- run_monte_carlo(n_iterations = 200)
  cat("=== MONTE CARLO QUANTILE SUMMARY ===\n")
  print(mc$quantiles)
  
} else if (subcmd == "sensitivity") {
  cat("[POWER-AUGMENT-R] Running One-At-a-Time (OAT) Sensitivity Analysis...\n")
  sens <- run_sensitivity_analysis()
  cat("=== TORNADO RANKING BY USABLE POWER SWING ===\n")
  print(as.data.frame(sens$tornado[, c("param_name", "nominal_val", "power_swing_mw", "power_elasticity", "thermal_swing_pct")]))
  
} else if (subcmd == "optimise" || subcmd == "optimize") {
  cat("[POWER-AUGMENT-R] Running Multi-Objective Pareto Optimization...\n")
  opt <- run_optimisation(grid_points = 5)
  cat("=== RECOMMENDED PARETO KNEE DESIGN ===\n")
  print(opt$recommended_design)
  
} else if (subcmd == "validate") {
  cat("[POWER-AUGMENT-R] Executing Physics & Energy Conservation Test Suite...\n")
  sim <- run_simulation(duration = 300, dt = 0.25)
  max_residual <- sim$summary$max_energy_residual_mj
  cat("Maximum Energy Residual: ", max_residual, " MJ\n")
  if (max_residual < 1e-3) {
    cat("[PASS] First Law of Thermodynamics Energy Conservation VERIFIED.\n")
  } else {
    cat("[FAIL] Energy residual exceeded tolerance!\n")
  }
  
} else if (subcmd == "report") {
  cat("[POWER-AUGMENT-R] Generating Aerospace Engineering Dossier...\n")
  sim <- run_simulation(duration = 600, dt = 0.5)
  rep <- generate_engineering_report(sim)
  cat(rep)
} else {
  cat("Unknown command:", subcmd, "\n")
}
