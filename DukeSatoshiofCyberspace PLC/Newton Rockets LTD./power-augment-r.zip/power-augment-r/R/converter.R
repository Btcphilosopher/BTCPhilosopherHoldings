# ==============================================================================
# POWER-AUGMENT-R: Power Conversion & DC Conditioning
# ==============================================================================

#' Power Converter Model (DC-DC / Solid-State Conditioning)
#' @param p_in Input power from generator [W]
#' @param temp_conv Converter temperature [K]
#' @param conv_params Converter configuration parameters
#' @return List of output power, dissipated loss, efficiency, and status
#' @export
create_power_converter <- function(p_in, temp_conv, conv_params) {
  eta_nom <- conv_params$efficiency_nominal$val
  max_rating <- conv_params$max_power_rating$val
  switch_factor <- conv_params$switching_loss_factor$val
  t_max <- conv_params$t_max$val
  
  # Power clamped to converter hardware envelope
  p_clamped_in <- min(p_in, max_rating)
  
  # Efficiency derating with temperature and switching dynamics
  temp_penalty <- if (temp_conv > 340.0) 0.0004 * (temp_conv - 340.0) else 0.0
  eta_eff <- max(0.60, min(0.995, eta_nom - temp_penalty - switch_factor * (p_clamped_in / max_rating)))
  
  p_out <- p_clamped_in * eta_eff
  p_loss <- p_clamped_in - p_out
  
  is_limited <- (p_in > max_rating)
  
  list(
    p_in = p_clamped_in,
    p_out = p_out,
    p_loss = p_loss,
    efficiency = eta_eff,
    is_limited = is_limited,
    headroom = max_rating - p_clamped_in
  )
}
