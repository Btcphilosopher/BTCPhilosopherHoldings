# ==============================================================================
# POWER-AUGMENT-R: Spacecraft Loads Model & Priority Shedding
# ==============================================================================

#' Create Default Spacecraft Subsystem Loads
#' @return List of 10 aerospace loads with priority, power envelope, duty cycle, and temp sensitivity
#' @export
create_default_loads <- function() {
  list(
    PROPULSION = list(
      name = "Propulsion System (Arcjet / Hall Thruster / Turbo-pump)",
      nominal_power = 1.2e6, # 1.2 MW
      min_power = 0.0,
      max_power = 2.2e6,
      priority = 2,          # 1 = highest, 5 = shed first
      duty_cycle = 0.85,
      temp_sensitivity = 0.0005,
      active = TRUE
    ),
    AVIONICS = list(
      name = "Flight Avionics & Guidance Navigation & Control (GNC)",
      nominal_power = 45e3,  # 45 kW
      min_power = 35e3,
      max_power = 60e3,
      priority = 1,          # Critical flight computer
      duty_cycle = 1.0,
      temp_sensitivity = 0.0001,
      active = TRUE
    ),
    COMMUNICATIONS = list(
      name = "Deep-Space High Gain RF & Optical Transceivers",
      nominal_power = 85e3,  # 85 kW
      min_power = 20e3,
      max_power = 150e3,
      priority = 2,
      duty_cycle = 0.90,
      temp_sensitivity = 0.0003,
      active = TRUE
    ),
    THERMAL_CONTROL = list(
      name = "Active Thermal Management & Cryocooler Loops",
      nominal_power = 120e3, # 120 kW
      min_power = 40e3,
      max_power = 250e3,
      priority = 1,
      duty_cycle = 1.0,
      temp_sensitivity = 0.0012,
      active = TRUE
    ),
    NAVIGATION = list(
      name = "Star Trackers, Inertial Measurement Units & LiDAR",
      nominal_power = 25e3,  # 25 kW
      min_power = 15e3,
      max_power = 35e3,
      priority = 1,
      duty_cycle = 1.0,
      temp_sensitivity = 0.0002,
      active = TRUE
    ),
    SCIENCE = list(
      name = "Planetary Radar, Spectrometers & Magnetometers",
      nominal_power = 95e3,  # 95 kW
      min_power = 0.0,
      max_power = 220e3,
      priority = 4,
      duty_cycle = 0.70,
      temp_sensitivity = 0.0004,
      active = TRUE
    ),
    PAYLOAD = list(
      name = "Mission Experiment Core & Sample Extraction",
      nominal_power = 180e3, # 180 kW
      min_power = 0.0,
      max_power = 450e3,
      priority = 4,
      duty_cycle = 0.60,
      temp_sensitivity = 0.0005,
      active = TRUE
    ),
    LIFE_SUPPORT = list(
      name = "Environmental Control & Life Support (ECLSS)",
      nominal_power = 110e3, # 110 kW
      min_power = 80e3,
      max_power = 160e3,
      priority = 1,
      duty_cycle = 1.0,
      temp_sensitivity = 0.0002,
      active = TRUE
    ),
    POWER_CONVERSION = list(
      name = "Auxiliary Sub-Bus Regulators & Gate Drivers",
      nominal_power = 30e3,  # 30 kW
      min_power = 20e3,
      max_power = 45e3,
      priority = 1,
      duty_cycle = 1.0,
      temp_sensitivity = 0.0003,
      active = TRUE
    ),
    RESERVE = list(
      name = "Auxiliary Contingency & Margin Reserve",
      nominal_power = 50e3,  # 50 kW
      min_power = 0.0,
      max_power = 100e3,
      priority = 5,
      duty_cycle = 0.50,
      temp_sensitivity = 0.0,
      active = TRUE
    )
  )
}

#' Calculate Dynamic Spacecraft Load Demand
#' @param loads_config List of loads
#' @param t Current simulation time [s]
#' @param temp_avg Spacecraft average temperature [K]
#' @param boost_mode Logical flag for high-power propulsion boost
#' @return List with total demand, subsystem breakdowns, and priority buckets
#' @export
calculate_total_load_demand <- function(loads_config, t, temp_avg = 300.0, boost_mode = FALSE) {
  total_demand <- 0.0
  breakdown <- list()
  
  for (load_id in names(loads_config)) {
    item <- loads_config[[load_id]]
    if (!isTRUE(item$active)) {
      breakdown[[load_id]] <- 0.0
      next
    }
    
    # Base load
    p_base <- item$nominal_power
    
    # Propulsion boost scaling
    if (load_id == "PROPULSION" && boost_mode) {
      p_base <- item$max_power
    }
    
    # Time-varying sinusoidal perturbation to simulate realistic mission activities
    modulation <- 1.0 + 0.05 * sin(2 * pi * t / 300.0 + which(names(loads_config) == load_id))
    
    # Thermal sensitivity: some loads require more power at elevated temps (e.g. thermal control pumps)
    temp_factor <- 1.0 + item$temp_sensitivity * max(0, temp_avg - 300.0)
    
    p_actual <- p_base * item$duty_cycle * modulation * temp_factor
    p_clamped <- max(item$min_power, min(item$max_power, p_actual))
    
    breakdown[[load_id]] <- p_clamped
    total_demand <- total_demand + p_clamped
  }
  
  list(
    total_demand = total_demand,
    breakdown = breakdown
  )
}
