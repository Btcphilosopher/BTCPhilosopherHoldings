# ==============================================================================
# POWER-AUGMENT-R: DC Power Distribution Bus
# ==============================================================================

#' DC Power Distribution Bus Model
#' @param p_in Total power delivered onto the bus from converter and storage [W]
#' @param p_demanded Total power demanded by active spacecraft loads [W]
#' @param bus_params DC bus parameters
#' @return List with bus voltage, bus current, resistive losses, usable power, and margin
#' @export
create_power_bus <- function(p_in, p_demanded, bus_params) {
  v_nom <- bus_params$voltage_nominal$val
  r_bus <- bus_params$resistance$val
  i_max <- bus_params$current_max$val
  
  # Power delivered to loads cannot exceed total input
  p_actual_served <- min(p_in, p_demanded)
  
  # Bus current: I_bus = P_bus / V_bus
  i_bus <- if (v_nom > 0) p_actual_served / v_nom else 0.0
  
  # Resistive distribution I^2 R loss
  p_bus_loss <- (i_bus^2) * r_bus
  
  # Voltage drop across harness: V_actual = V_nom - I_bus * R_bus
  v_actual <- max(1.0, v_nom - i_bus * r_bus)
  
  # Net usable power reaching loads
  p_usable <- max(0.0, p_in - p_bus_loss)
  p_margin <- p_usable - p_demanded
  
  # Ampacity headroom check
  is_current_limited <- (i_bus > i_max)
  
  list(
    v_bus = v_actual,
    i_bus = i_bus,
    p_in = p_in,
    p_usable = p_usable,
    p_loss = p_bus_loss,
    p_demanded = p_demanded,
    p_served = min(p_usable, p_demanded),
    p_margin = p_margin,
    is_current_limited = is_current_limited,
    current_headroom = max(0, i_max - i_bus)
  )
}
