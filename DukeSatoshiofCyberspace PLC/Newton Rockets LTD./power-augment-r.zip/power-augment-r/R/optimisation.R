# ==============================================================================
# POWER-AUGMENT-R: Multi-Objective Pareto Optimization Engine
# ==============================================================================

#' Run Multi-Objective Offline Parameter Optimization
#' Objectives:
#' 1. Maximize Net Usable Power [MW]
#' 2. Maximize Thermal Margin [%]
#' 3. Minimize Electrical Losses [kW]
#' Subject to: Voltage limit, Current limit, Temperature limits, SOC bounds
#' @param base_params Base parameters
#' @param grid_points Resolution per optimization axis
#' @return List with candidate grid points, non-dominated Pareto frontier, and optimal trade-off point
#' @export
run_optimisation <- function(base_params = create_default_parameters(), grid_points = 6) {
  # Decision variables:
  # x1: Generator Augmented Power [1.8 MW to 3.2 MW]
  # x2: Storage Discharge Cap [0.4 MW to 1.8 MW]
  # x3: Bus Voltage [250 V to 450 V]
  # x4: Radiator Area [40 m^2 to 110 m^2]
  
  gen_vals <- seq(1.8e6, 3.2e6, length.out = grid_points)
  stor_vals <- seq(0.4e6, 1.8e6, length.out = grid_points)
  v_bus_vals <- seq(250.0, 450.0, length.out = grid_points)
  rad_area_vals <- seq(40.0, 110.0, length.out = grid_points)
  
  candidates <- list()
  
  for (g in gen_vals) {
    for (s in stor_vals) {
      for (v in v_bus_vals) {
        for (a in rad_area_vals) {
          # Evaluate system metrics
          eta_gen <- base_params$generation$efficiency_0$val
          eta_conv <- base_params$converter$efficiency_nominal$val
          r_bus <- base_params$bus$resistance$val
          
          p_gen_elec <- g * eta_gen
          p_conv_out <- p_gen_elec * eta_conv
          
          # Bus distribution at 2.2 MW demand
          p_demand_target <- 2.2e6
          i_bus <- p_demand_target / v
          p_bus_loss <- (i_bus^2) * r_bus
          
          p_usable <- p_conv_out + s - p_bus_loss
          p_losses_tot <- (g - p_gen_elec) + (p_gen_elec - p_conv_out) + p_bus_loss + (s * 0.05)
          
          # Radiative thermal rejection
          sigma <- 5.670374419e-8
          q_rad <- 0.91 * sigma * a * (345.0^4 - 220.0^4)
          thermal_margin_pct <- (q_rad - p_losses_tot) / q_rad * 100.0
          
          # Constraint checks
          is_feasible <- (i_bus <= 12000.0) && (thermal_margin_pct >= 5.0) && (p_usable >= 1.8e6)
          
          if (is_feasible) {
            candidates[[length(candidates) + 1]] <- list(
              gen_power_mw = g / 1e6,
              stor_power_mw = s / 1e6,
              v_bus = v,
              rad_area = a,
              usable_power_mw = p_usable / 1e6,
              thermal_margin_pct = thermal_margin_pct,
              losses_kw = p_losses_tot / 1e3,
              bus_current_a = i_bus
            )
          }
        }
      }
    }
  }
  
  df_all <- dplyr::bind_rows(candidates)
  
  if (nrow(df_all) == 0) {
    return(list(all = df_all, pareto = df_all, best = NULL))
  }
  
  # Identify non-dominated Pareto frontier points (Maximize Power, Maximize Thermal Margin, Minimize Losses)
  is_dominated <- rep(FALSE, nrow(df_all))
  
  # Sample a representative subset for crisp Pareto frontier
  for (i in seq_len(nrow(df_all))) {
    p_i <- df_all$usable_power_mw[i]
    t_i <- df_all$thermal_margin_pct[i]
    l_i <- df_all$losses_kw[i]
    
    for (j in seq_len(nrow(df_all))) {
      if (i != j) {
        p_j <- df_all$usable_power_mw[j]
        t_j <- df_all$thermal_margin_pct[j]
        l_j <- df_all$losses_kw[j]
        
        if (p_j >= p_i && t_j >= t_i && l_j <= l_i && (p_j > p_i || t_j > t_i || l_j < l_i)) {
          is_dominated[i] <- TRUE
          break
        }
      }
    }
  }
  
  df_pareto <- df_all[!is_dominated, ] %>%
    dplyr::arrange(desc(usable_power_mw))
  
  # Select balanced compromise design (TOPSIS / Knee point on frontier)
  best_idx <- which.max(df_pareto$usable_power_mw * 0.45 + (df_pareto$thermal_margin_pct / 50.0) * 0.35 - (df_pareto$losses_kw / 300.0) * 0.20)
  best_candidate <- df_pareto[best_idx, ]
  
  list(
    all_feasible = df_all,
    pareto_frontier = df_pareto,
    recommended_design = as.list(best_candidate)
  )
}
