# ==============================================================================
# POWER-AUGMENT-R: Numerical Integration Solvers (Euler, RK2, RK4)
# ==============================================================================

#' Numerical Integration Step
#' Supports explicit Euler, RK2 (Midpoint/Heun), and classical RK4 (Runge-Kutta 4th order)
#' @param method "Euler", "RK2", or "RK4"
#' @param ode_func Function(t, state, params) returning d(state)/dt list
#' @param t Current time [s]
#' @param state Current numerical state vector
#' @param dt Step size [s]
#' @param params ODE parameter bundle
#' @return Updated state vector at t + dt
#' @export
integrate_step <- function(method = "RK4", ode_func, t, state, dt, params) {
  if (method == "Euler") {
    derivs <- ode_func(t, state, params)
    return(state + derivs * dt)
  }
  
  if (method == "RK2") {
    k1 <- ode_func(t, state, params)
    state_mid <- state + 0.5 * dt * k1
    k2 <- ode_func(t + 0.5 * dt, state_mid, params)
    return(state + dt * k2)
  }
  
  # RK4 (Default high-precision method)
  k1 <- ode_func(t, state, params)
  k2 <- ode_func(t + 0.5 * dt, state + 0.5 * dt * k1, params)
  k3 <- ode_func(t + 0.5 * dt, state + 0.5 * dt * k2, params)
  k4 <- ode_func(t + dt, state + dt * k3, params)
  
  state_next <- state + (dt / 6.0) * (k1 + 2.0 * k2 + 2.0 * k3 + k4)
  return(state_next)
}
