# ==============================================================================
# POWER-AUGMENT-R: Analytical Fault Injection Engine
# ==============================================================================

#' Apply Active Faults to System Configuration Parameters
#' Fault Types:
#' - GENERATOR_EFFICIENCY_DROP
#' - CONVERTER_EFFICIENCY_DROP
#' - BUS_RESISTANCE_INCREASE
#' - STORAGE_CAPACITY_LOSS
#' - STORAGE_TEMPERATURE_RISE
#' - SENSOR_BIAS
#' - SENSOR_NOISE
#' - POWER_LOAD_SPIKE
#' - THERMAL_REJECTION_DEGRADATION
#' @param base_params Base parameters
#' @param active_faults Vector of fault identifiers
#' @return Modified parameters list with active injected faults
#' @export
apply_injected_faults <- function(base_params, active_faults = c()) {
  p <- base_params
  
  if ("GENERATOR_EFFICIENCY_DROP" %in% active_faults) {
    p$generation$efficiency_0$val <- p$generation$efficiency_0$val * 0.85 # 15% efficiency penalty
    p$generation$health$val <- 0.88
  }
  
  if ("CONVERTER_EFFICIENCY_DROP" %in% active_faults) {
    p$converter$efficiency_nominal$val <- p$converter$efficiency_nominal$val * 0.90
    p$converter$switching_loss_factor$val <- p$converter$switching_loss_factor$val * 2.5
  }
  
  if ("BUS_RESISTANCE_INCREASE" %in% active_faults) {
    p$bus$resistance$val <- p$bus$resistance$val * 3.2 # Cable harness connector degradation
  }
  
  if ("STORAGE_CAPACITY_LOSS" %in% active_faults) {
    p$storage$health$val <- 0.70 # 30% battery capacity fade
    p$storage$internal_resistance$val <- p$storage$internal_resistance$val * 2.2
  }
  
  if ("STORAGE_TEMPERATURE_RISE" %in% active_faults) {
    p$thermal$t_initial$storage <- p$thermal$t_initial$storage + 25.0
  }
  
  if ("THERMAL_REJECTION_DEGRADATION" %in% active_faults) {
    p$thermal$emissivity$val <- p$thermal$emissivity$val * 0.75 # Radiator coating micro-meteorite erosion
    p$thermal$radiator_area$val <- p$thermal$radiator_area$val * 0.80
  }
  
  p
}
