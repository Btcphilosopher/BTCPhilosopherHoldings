# ==============================================================================
# POWER-AUGMENT-R: Energy Accounting, Losses Breakdown & Residual Validation
# ==============================================================================

#' Calculate Complete Energy Balance and Conservation Residual
#' @param p_gen_gross Gross primary generation power [W]
#' @param p_gen_loss Generation internal loss [W]
#' @param p_conv_loss Power conversion loss [W]
#' @param p_bus_loss Distribution bus I^2*R loss [W]
#' @param p_stor_loss Storage ESR loss [W]
#' @param p_delivered Electrical power delivered to spacecraft loads [W]
#' @param p_stor_change Storage internal power rate (dE_stor/dt) [W]
#' @param q_rad Radiative heat rejected to space [W]
#' @param dt Timestep duration [s]
#' @return List of instantaneous powers, energy increments, cumulative integrals, and conservation residual
#' @export
calculate_energy_balance <- function(p_gen_gross, p_gen_loss, p_conv_loss, p_bus_loss, p_stor_loss, p_delivered, p_stor_change, q_rad, dt) {
  # Total power dissipated as electrical losses
  p_losses_total <- p_gen_loss + p_conv_loss + p_bus_loss + p_stor_loss
  
  # Instantaneous power balance residual: P_gen_gross - (P_delivered + P_stor_change + P_losses_total)
  power_residual <- p_gen_gross - (p_delivered + p_stor_change + p_losses_total)
  
  # Incremental energies [Joules]
  de_source <- p_gen_gross * dt
  de_delivered <- p_delivered * dt
  de_stored <- p_stor_change * dt
  de_losses <- p_losses_total * dt
  de_dissipated <- q_rad * dt
  
  # First Law of Thermodynamics energy conservation residual [MJ]
  energy_residual_j <- de_source - (de_delivered + de_stored + de_losses)
  energy_residual_mj <- energy_residual_j / 1e6

  # System energy efficiency: Useful delivered power / Gross source power
  efficiency_sys <- if (p_gen_gross > 0) p_delivered / p_gen_gross else 0.0

  list(
    p_losses_total = p_losses_total,
    power_residual_w = power_residual,
    energy_residual_mj = energy_residual_mj,
    efficiency_system = efficiency_sys,
    de_source_mj = de_source / 1e6,
    de_delivered_mj = de_delivered / 1e6,
    de_stored_mj = de_stored / 1e6,
    de_losses_mj = de_losses / 1e6,
    de_dissipated_mj = de_dissipated / 1e6
  )
}
