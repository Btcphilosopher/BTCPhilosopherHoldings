# ==============================================================================
# POWER-AUGMENT-R: Stochastic Monte Carlo Uncertainty Engine
# ==============================================================================

#' Run Stochastic Monte Carlo Uncertainty Propagation
#' @param base_params System nominal parameters
#' @param n_iterations Number of Monte Carlo samples (e.g. 500 to 5000)
#' @param seed Random seed for reproducibility
#' @return List with iteration tibble, quantile summary, and correlation matrix
#' @export
run_monte_carlo <- function(base_params = create_default_parameters(), n_iterations = 500, seed = 42) {
  set.seed(seed)
  
  results <- vector("list", n_iterations)
  
  for (i in seq_len(n_iterations)) {
    # Sample physical parameters with realistic aerospace manufacturing & operational distributions
    p <- base_params
    
    # 1. Generator efficiency ~ Beta or Truncated Normal
    eta_gen_sample <- rnorm(1, mean = base_params$generation$efficiency_0$val, sd = 0.015)
    p$generation$efficiency_0$val <- max(0.80, min(0.98, eta_gen_sample))
    
    # 2. Converter efficiency ~ Normal
    eta_conv_sample <- rnorm(1, mean = base_params$converter$efficiency_nominal$val, sd = 0.008)
    p$converter$efficiency_nominal$val <- max(0.88, min(0.99, eta_conv_sample))
    
    # 3. Bus resistance ~ Lognormal variation
    r_bus_sample <- rlnorm(1, meanlog = log(base_params$bus$resistance$val), sdlog = 0.15)
    p$bus$resistance$val <- max(0.001, min(0.01, r_bus_sample))
    
    # 4. Storage internal ESR resistance ~ Normal
    r_esr_sample <- rnorm(1, mean = base_params$storage$internal_resistance$val, sd = 0.0006)
    p$storage$internal_resistance$val <- max(0.001, min(0.012, r_esr_sample))
    
    # 5. Storage Capacity Retention / Health ~ Beta(20, 1)
    stor_health_sample <- rbeta(1, 25, 1)
    p$storage$health$val <- stor_health_sample
    
    # 6. Radiator area / coating degradation ~ Normal
    eps_sample <- rnorm(1, mean = base_params$thermal$emissivity$val, sd = 0.02)
    p$thermal$emissivity$val <- max(0.75, min(0.96, eps_sample))
    
    # 7. Ambient sink temperature variation ~ Uniform
    p$thermal$t_ambient_sink$val <- runif(1, min = 180.0, max = 260.0)
    
    # Evaluate fast analytical power augmentation balance
    p_gen_nom <- p$generation$augmented_power$val * p$generation$health$val
    p_gen_elec <- p_gen_nom * p$generation$efficiency_0$val
    p_conv_out <- p_gen_elec * p$converter$efficiency_nominal$val
    
    # Storage contribution
    p_stor_avail <- p$storage$max_discharge_power$val * p$storage$health$val
    
    # Distribution bus losses at 1.8 MW load
    p_load_nominal <- 1.85e6
    v_bus <- p$bus$voltage_nominal$val
    i_bus <- p_load_nominal / v_bus
    p_bus_loss <- (i_bus^2) * p$bus$resistance$val
    
    p_usable <- p_conv_out + p_stor_avail - p_bus_loss
    p_gain_mw <- (p_usable - base_params$generation$baseline_power$val) / 1e6
    p_margin_mw <- (p_usable - p_load_nominal) / 1e6
    
    # Thermal steady-state radiator heat rejection limit
    sigma <- 5.670374419e-8
    q_rad <- p$thermal$emissivity$val * sigma * p$thermal$radiator_area$val * (345.0^4 - p$thermal$t_ambient_sink$val^4)
    p_loss_tot <- (p_gen_nom - p_gen_elec) + (p_gen_elec - p_conv_out) + p_bus_loss
    thermal_margin_pct <- max(0.0, min(100.0, 100.0 * (q_rad - p_loss_tot) / q_rad))
    
    results[[i]] <- list(
      iter = i,
      eta_generator = p$generation$efficiency_0$val,
      eta_converter = p$converter$efficiency_nominal$val,
      r_bus_mohm = p$bus$resistance$val * 1e3,
      r_esr_mohm = p$storage$internal_resistance$val * 1e3,
      storage_health = p$storage$health$val,
      emissivity = p$thermal$emissivity$val,
      t_ambient_k = p$thermal$t_ambient_sink$val,
      usable_power_mw = p_usable / 1e6,
      power_gain_mw = p_gain_mw,
      power_margin_mw = p_margin_mw,
      thermal_margin_pct = thermal_margin_pct,
      total_losses_kw = p_loss_tot / 1e3
    )
  }
  
  df_mc <- dplyr::bind_rows(results)
  
  # Compute statistical quantiles: P10, P50 (median), P90, P99
  calc_quantiles <- function(vec) {
    stats <- quantile(vec, probs = c(0.01, 0.05, 0.10, 0.25, 0.50, 0.75, 0.90, 0.95, 0.99), na.rm = TRUE)
    list(
      mean = mean(vec),
      sd = sd(vec),
      p10 = as.numeric(stats["10%"]),
      p50 = as.numeric(stats["50%"]),
      p90 = as.numeric(stats["90%"]),
      p99 = as.numeric(stats["99%"])
    )
  }
  
  quantiles_summary <- list(
    usable_power = calc_quantiles(df_mc$usable_power_mw),
    power_gain = calc_quantiles(df_mc$power_gain_mw),
    power_margin = calc_quantiles(df_mc$power_margin_mw),
    thermal_margin = calc_quantiles(df_mc$thermal_margin_pct),
    total_losses = calc_quantiles(df_mc$total_losses_kw)
  )
  
  list(
    samples = df_mc,
    quantiles = quantiles_summary,
    n_iterations = n_iterations
  )
}
