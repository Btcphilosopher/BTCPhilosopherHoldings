# ==============================================================================
# POWER-AUGMENT-R: Statistical Engine & Correlation Matrix
# ==============================================================================

#' Compute Statistical Profile of Numeric Vector
#' @param x Numeric vector
#' @return List of mean, median, sd, var, min, max, P10, P90, and CI95
#' @export
compute_statistical_profile <- function(x) {
  x_clean <- x[!is.na(x)]
  n <- length(x_clean)
  if (n == 0) return(NULL)
  
  mean_val <- mean(x_clean)
  sd_val <- sd(x_clean)
  se_val <- if (n > 1) sd_val / sqrt(n) else 0.0
  
  list(
    n = n,
    mean = mean_val,
    median = median(x_clean),
    sd = sd_val,
    variance = var(x_clean),
    min = min(x_clean),
    max = max(x_clean),
    p10 = as.numeric(quantile(x_clean, 0.10)),
    p25 = as.numeric(quantile(x_clean, 0.25)),
    p75 = as.numeric(quantile(x_clean, 0.75)),
    p90 = as.numeric(quantile(x_clean, 0.90)),
    p99 = as.numeric(quantile(x_clean, 0.99)),
    ci_95_lower = mean_val - 1.96 * se_val,
    ci_95_upper = mean_val + 1.96 * se_val
  )
}

#' Compute System Correlation Matrix for Telemetry Variables
#' @param telemetry_df Telemetry dataframe
#' @return Correlation matrix as tibble
#' @export
compute_telemetry_correlations <- function(telemetry_df) {
  cols_to_cor <- c("p_gen_gross", "p_usable", "p_margin", "soc", "t_generator", "t_converter", "t_storage", "t_bus", "i_bus", "thermal_margin", "eff_system")
  valid_cols <- intersect(cols_to_cor, names(telemetry_df))
  
  sub_df <- telemetry_df[, valid_cols]
  cor_mat <- cor(sub_df, use = "pairwise.complete.obs")
  
  as.data.frame(cor_mat)
}
