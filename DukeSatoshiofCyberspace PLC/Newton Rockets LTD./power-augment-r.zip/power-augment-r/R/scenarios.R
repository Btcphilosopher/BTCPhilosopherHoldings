# ==============================================================================
# POWER-AUGMENT-R: Versioned Standard Mission Scenarios
# ==============================================================================

#' Create 12 Predefined Versioned Aerospace Mission Scenarios
#' @return Named list of scenario bundles
#' @export
create_default_scenarios <- function() {
  base_p <- create_default_parameters()
  
  scenarios <- list(
    BASELINE = list(
      id = "BASELINE",
      name = "01. Baseline Cruise Power",
      description = "Nominal deep-space cruise with steady baseline generator output and floating energy storage.",
      duration = 600,
      dt = 0.5,
      boost_mode = FALSE,
      params = base_p
    ),
    
    POWER_BOOST = list(
      id = "POWER_BOOST",
      name = "02. Power Boost Propulsion Maneuver",
      description = "Full throttle power augmentation combining primary reactor ramp and battery storage boost for high-thrust propulsion.",
      duration = 600,
      dt = 0.5,
      boost_mode = TRUE,
      params = base_p
    ),
    
    PEAK_POWER_EVENT = list(
      id = "PEAK_POWER_EVENT",
      name = "03. Peak Power Science & Radar Pulse",
      description = "High-energy short-duration synthetic aperture radar mapping event drawing peak storage buffer capacity.",
      duration = 300,
      dt = 0.25,
      boost_mode = FALSE,
      params = within(base_p, {
        strategy <- "STORAGE_PEAK_SHAVING"
      })
    ),
    
    LONG_DURATION_HIGH_LOAD = list(
      id = "LONG_DURATION_HIGH_LOAD",
      name = "04. Long-Duration High-Load Injection",
      description = "Sustained high electrical power operation testing thermal equilibrium and continuous dissipation limits.",
      duration = 1800,
      dt = 1.0,
      boost_mode = TRUE,
      params = base_p
    ),
    
    HIGH_TEMPERATURE = list(
      id = "HIGH_TEMPERATURE",
      name = "05. High-Temperature Perihelion Pass",
      description = "Elevated ambient sink temperature (290 K) constraining radiative rejection and reducing thermal margins.",
      duration = 600,
      dt = 0.5,
      boost_mode = FALSE,
      params = within(base_p, {
        thermal$t_ambient_sink$val <- 290.0
      })
    ),
    
    LOW_TEMPERATURE = list(
      id = "LOW_TEMPERATURE",
      name = "06. Low-Temperature Deep Space Cruise",
      description = "Deep space cold environment (40 K) providing high thermal radiative headroom but increased battery ESR.",
      duration = 600,
      dt = 0.5,
      boost_mode = FALSE,
      params = within(base_p, {
        thermal$t_ambient_sink$val <- 40.0
        storage$internal_resistance$val <- 0.0065
      })
    ),
    
    DEGRADED_GENERATOR = list(
      id = "DEGRADED_GENERATOR",
      name = "07. Degraded Primary Generator (EOL)",
      description = "Primary generation health degraded to 78% with increased thermal derating penalty.",
      duration = 600,
      dt = 0.5,
      boost_mode = FALSE,
      params = within(base_p, {
        generation$health$val <- 0.78
        generation$efficiency_0$val <- 0.86
      })
    ),
    
    DEGRADED_STORAGE = list(
      id = "DEGRADED_STORAGE",
      name = "08. Degraded Energy Storage Battery",
      description = "Battery capacity fade to 65% with elevated internal resistance limiting discharge rate.",
      duration = 600,
      dt = 0.5,
      boost_mode = TRUE,
      params = within(base_p, {
        storage$health$val <- 0.65
        storage$internal_resistance$val <- 0.0085
      })
    ),
    
    HIGH_BUS_LOAD = list(
      id = "HIGH_BUS_LOAD",
      name = "09. High DC Bus Load & I²R Stress",
      description = "Severe electrical current draw stressing bus harness ampacity and increasing distribution resistive heating.",
      duration = 600,
      dt = 0.5,
      boost_mode = TRUE,
      params = within(base_p, {
        bus$resistance$val <- 0.0055
      })
    ),
    
    CONVERTER_LIMIT = list(
      id = "CONVERTER_LIMIT",
      name = "10. Converter Throughput Clamping",
      description = "DC-DC converter maximum rating throttled to 2.2 MW to evaluate conversion bottlenecking.",
      duration = 600,
      dt = 0.5,
      boost_mode = TRUE,
      params = within(base_p, {
        converter$max_power_rating$val <- 2.2e6
      })
    ),
    
    THERMAL_LIMIT = list(
      id = "THERMAL_LIMIT",
      name = "11. Radiator Fouling & Thermal Limit",
      description = "Radiator coating degradation reducing effective emissivity to 0.68, triggering thermal-limited throttling.",
      duration = 900,
      dt = 0.5,
      boost_mode = TRUE,
      params = within(base_p, {
        thermal$emissivity$val <- 0.68
        strategy <- "THERMAL_LIMITED"
      })
    ),
    
    COMBINED_DEGRADATION = list(
      id = "COMBINED_DEGRADATION",
      name = "12. Combined Multi-Subsystem Degradation",
      description = "Simultaneous end-of-mission degradation across generator, converter, bus resistance, and storage buffer.",
      duration = 600,
      dt = 0.5,
      boost_mode = TRUE,
      params = within(base_p, {
        generation$health$val <- 0.82
        storage$health$val <- 0.70
        bus$resistance$val <- 0.0048
        converter$efficiency_nominal$val <- 0.93
        thermal$emissivity$val <- 0.78
      })
    )
  )
  
  scenarios
}

#' Run Specific Predefined Scenario by Name
#' @param scenario_id ID of scenario (e.g. "POWER_BOOST")
#' @return Simulation results object
#' @export
run_scenario <- function(scenario_id = "POWER_BOOST") {
  scenarios <- create_default_scenarios()
  if (!scenario_id %in% names(scenarios)) {
    stop("Scenario not found: ", scenario_id)
  }
  
  sc <- scenarios[[scenario_id]]
  run_simulation(
    params = sc$params,
    duration = sc$duration,
    dt = sc$dt,
    method = "RK4",
    boost_mode = sc$boost_mode
  )
}
