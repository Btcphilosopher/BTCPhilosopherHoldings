# ==============================================================================
# POWER-AUGMENT-R: Deterministic Time-Domain Simulation Engine
# ==============================================================================

#' Run Full Spacecraft Power Augmentation Simulation
#' @param params Validated system parameters
#' @param duration Simulation duration [s]
#' @param dt Timestep size [s]
#' @param method Numerical solver method ("Euler", "RK2", "RK4")
#' @param loads Custom loads list or NULL for default
#' @param boost_mode Logical flag for high-power propulsion boost
#' @return Comprehensive simulation results tibble with trajectory telemetry and validation audits
#' @export
run_simulation <- function(params = create_default_parameters(), duration = 600, dt = 0.5, method = "RK4", loads = NULL, boost_mode = FALSE) {
  if (is.null(loads)) {
    loads <- create_default_loads()
  }
  
  steps <- ceiling(duration / dt)
  time_vec <- seq(0, duration, length.out = steps + 1)
  
  # Limits bundle for quick lookup
  limits <- list(
    gen_c_th = params$generation$thermal_mass$val,
    conv_c_th = params$converter$thermal_mass$val,
    bus_c_th = params$bus$thermal_mass$val,
    stor_c_th = params$storage$thermal_mass$val,
    t_gen_max = params$generation$t_max$val,
    t_conv_max = params$converter$t_max$val,
    t_bus_max = params$bus$t_max$val,
    t_stor_max = params$storage$t_max$val
  )
  
  # Initialize states
  soc <- params$storage$soc_initial$val
  temps <- c(
    generator = params$thermal$t_initial$generator,
    converter = params$thermal$t_initial$converter,
    bus = params$thermal$t_initial$bus,
    storage = params$thermal$t_initial$storage,
    radiator = params$thermal$t_initial$radiator
  )
  
  # Cumulative energy integrals [MJ]
  cum_e_source <- 0.0
  cum_e_delivered <- 0.0
  cum_e_stored_net <- 0.0
  cum_e_losses <- 0.0
  cum_e_dissipated <- 0.0
  
  records <- vector("list", length = steps + 1)
  
  for (i in seq_along(time_vec)) {
    t <- time_vec[i]
    
    # 1. Evaluate Spacecraft Loads Demand
    temp_avg <- mean(temps)
    load_state <- calculate_total_load_demand(loads, t, temp_avg, boost_mode)
    p_demand <- load_state$total_demand
    
    # 2. Evaluate Augmentation Strategy Dispatch
    p_gen_max <- params$generation$augmented_power$val
    p_base <- params$generation$baseline_power$val
    thermal_margin_est <- min(
      (limits$t_gen_max - temps["generator"]) / limits$t_gen_max,
      (limits$t_conv_max - temps["converter"]) / limits$t_conv_max,
      (limits$t_bus_max - temps["bus"]) / limits$t_bus_max,
      (limits$t_stor_max - temps["storage"]) / limits$t_stor_max
    )
    
    dispatch <- calculate_augmentation_dispatch(
      strategy = params$strategy,
      p_demand = p_demand,
      p_gen_max = p_gen_max,
      p_base = p_base,
      soc = soc,
      stor_params = params$storage,
      thermal_margin = thermal_margin_est
    )
    
    # 3. Generator Physics
    gen <- create_primary_generator(dispatch$p_gen_target, temps["generator"], params$generation)
    
    # 4. Power Converter Conditioning
    conv <- create_power_converter(gen$p_elec, temps["converter"], params$converter)
    
    # 5. Energy Storage Dispatch
    stor <- create_storage_system(dispatch$p_stor_cmd, soc, params$bus$voltage_nominal$val, dt, params$storage)
    soc <- stor$soc
    
    # 6. DC Power Bus Distribution
    p_bus_input <- conv$p_out + stor$p_disch - stor$p_charge
    bus <- create_power_bus(p_bus_input, p_demand, params$bus)
    
    # 7. Thermal Multi-Node Network
    thermal <- create_thermal_network(
      q_gen = gen$p_loss,
      q_conv = conv$p_loss,
      q_bus = bus$p_loss,
      q_stor = stor$p_loss,
      temps = temps,
      thermal_params = params$thermal,
      limits = limits
    )
    
    # Integrate temperatures with selected numerical solver
    thermal_ode <- function(tau, t_state, p) {
      th_res <- create_thermal_network(gen$p_loss, conv$p_loss, bus$p_loss, stor$p_loss, t_state, params$thermal, limits)
      th_res$derivatives
    }
    temps <- integrate_step(method, thermal_ode, t, temps, dt, NULL)
    
    # 8. Energy Accounting & Residual Check
    p_stor_internal_rate <- (stor$p_charge - stor$p_disch)
    bal <- calculate_energy_balance(
      p_gen_gross = gen$p_gross,
      p_gen_loss = gen$p_loss,
      p_conv_loss = conv$p_loss,
      p_bus_loss = bus$p_loss,
      p_stor_loss = stor$p_loss,
      p_delivered = bus$p_served,
      p_stor_change = p_stor_internal_rate,
      q_rad = thermal$q_rejected_rad,
      dt = dt
    )
    
    cum_e_source <- cum_e_source + bal$de_source_mj
    cum_e_delivered <- cum_e_delivered + bal$de_delivered_mj
    cum_e_stored_net <- cum_e_stored_net + bal$de_stored_mj
    cum_e_losses <- cum_e_losses + bal$de_losses_mj
    cum_e_dissipated <- cum_e_dissipated + bal$de_dissipated_mj
    
    # Power Increase metrics
    delta_p <- bus$p_served - p_base
    p_gain_pct <- if (p_base > 0) 100.0 * (bus$p_served - p_base) / p_base else 0.0
    
    records[[i]] <- list(
      time = t,
      p_baseline = p_base,
      p_gen_gross = gen$p_gross,
      p_gen_elec = gen$p_elec,
      p_gen_loss = gen$p_loss,
      p_conv_in = conv$p_in,
      p_conv_out = conv$p_out,
      p_conv_loss = conv$p_loss,
      p_stor_disch = stor$p_disch,
      p_stor_charge = stor$p_charge,
      p_stor_loss = stor$p_loss,
      p_bus_in = p_bus_input,
      p_bus_loss = bus$p_loss,
      p_demand = p_demand,
      p_usable = bus$p_usable,
      p_served = bus$p_served,
      p_margin = bus$p_margin,
      delta_p = delta_p,
      p_gain_pct = p_gain_pct,
      v_bus = bus$v_bus,
      i_bus = bus$i_bus,
      soc = soc,
      t_generator = temps["generator"],
      t_converter = temps["converter"],
      t_bus = temps["bus"],
      t_storage = temps["storage"],
      t_radiator = temps["radiator"],
      thermal_margin = thermal$thermal_margin,
      q_rad = thermal$q_rejected_rad,
      eff_system = bal$efficiency_system,
      energy_residual_mj = bal$energy_residual_mj,
      cum_e_source_mj = cum_e_source,
      cum_e_delivered_mj = cum_e_delivered,
      cum_e_stored_mj = cum_e_stored_net,
      cum_e_losses_mj = cum_e_losses,
      cum_e_dissipated_mj = cum_e_dissipated
    )
  }
  
  df_res <- dplyr::bind_rows(records)
  
  list(
    telemetry = df_res,
    summary = list(
      duration = duration,
      dt = dt,
      method = method,
      strategy = params$strategy,
      avg_usable_power_mw = mean(df_res$p_usable) / 1e6,
      peak_usable_power_mw = max(df_res$p_usable) / 1e6,
      min_power_margin_kw = min(df_res$p_margin) / 1e3,
      final_soc = tail(df_res$soc, 1),
      max_temp_k = max(c(df_res$t_generator, df_res$t_converter, df_res$t_storage, df_res$t_bus)),
      min_thermal_margin_pct = min(df_res$thermal_margin) * 100.0,
      total_energy_delivered_mj = tail(df_res$cum_e_delivered_mj, 1),
      total_energy_losses_mj = tail(df_res$cum_e_losses_mj, 1),
      max_energy_residual_mj = max(abs(df_res$energy_residual_mj)),
      is_energy_conserved = (max(abs(df_res$energy_residual_mj)) < 1e-3)
    )
  )
}
