# ==============================================================================
# POWER-AUGMENT-R: Primary Generation Physics
# ==============================================================================

#' Primary Generator Model
#' @param p_target Target power demand or capability [W]
#' @param temp_gen Current generator temperature [K]
#' @param gen_params Generator configuration parameters
#' @return List with electrical power, losses, and current
#' @export
create_primary_generator <- function(p_target, temp_gen, gen_params) {
  p_nom <- gen_params$augmented_power$val
  p_base <- gen_params$baseline_power$val
  v_gen <- gen_params$voltage_gen$val
  eta_0 <- gen_params$efficiency_0$val
  gamma <- gen_params$temp_coefficient$val
  t_ref <- gen_params$t_ref$val
  health <- gen_params$health$val

  # Thermal derating model: eta(T) = eta_0 * (1 - gamma * (T - T_ref)) * health
  temp_delta <- max(0, temp_gen - t_ref)
  eta_actual <- max(0.40, min(0.99, eta_0 * (1.0 - gamma * temp_delta) * health))

  # Available gross primary generation
  p_gen_gross <- min(p_target, p_nom * health)
  
  # Electrical power delivered to converter
  p_gen_elec <- p_gen_gross * eta_actual
  
  # Conversion loss dissipated as heat inside the generator
  p_gen_loss <- p_gen_gross * (1.0 - eta_actual)
  
  # Output current: I = P / V
  i_gen <- if (v_gen > 0) p_gen_elec / v_gen else 0

  list(
    p_gross = p_gen_gross,
    p_elec = p_gen_elec,
    p_loss = p_gen_loss,
    efficiency = eta_actual,
    current = i_gen,
    voltage = v_gen
  )
}
