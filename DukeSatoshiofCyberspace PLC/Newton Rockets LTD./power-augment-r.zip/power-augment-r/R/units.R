# ==============================================================================
# POWER-AUGMENT-R: Engineering Unit Conversions & Validation
# ==============================================================================

#' Convert Watts to Megawatts
#' @param w Power in Watts
#' @return Power in Megawatts
#' @export
w_to_mw <- function(w) { w / 1e6 }

#' Convert Megawatts to Watts
#' @param mw Power in Megawatts
#' @return Power in Watts
#' @export
mw_to_w <- function(mw) { mw * 1e6 }

#' Convert Watts to Kilowatts
#' @param w Power in Watts
#' @return Power in Kilowatts
#' @export
w_to_kw <- function(w) { w / 1e3 }

#' Convert Kilowatts to Watts
#' @param kw Power in Kilowatts
#' @return Power in Watts
#' @export
kw_to_w <- function(kw) { kw * 1e3 }

#' Convert Joules to Megajoules
#' @param j Energy in Joules
#' @return Energy in Megajoules
#' @export
j_to_mj <- function(j) { j / 1e6 }

#' Convert Megajoules to Joules
#' @param mj Energy in Megajoules
#' @return Energy in Joules
#' @export
mj_to_j <- function(mj) { mj * 1e6 }

#' Convert Kilowatt-hours to Megajoules
#' @param kwh Energy in kWh
#' @return Energy in MJ
#' @export
kwh_to_mj <- function(kwh) { kwh * 3.6 }

#' Convert Kelvin to Celsius
#' @param k Temperature in Kelvin
#' @return Temperature in Celsius
#' @export
k_to_c <- function(k) { k - 273.15 }

#' Convert Celsius to Kelvin
#' @param c Temperature in Celsius
#' @return Temperature in Kelvin
#' @export
c_to_k <- function(c) { c + 273.15 }
