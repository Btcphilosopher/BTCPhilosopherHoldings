# ==============================================================================
# POWER-AUGMENT-R: Multi-Constraint Power Envelope Analysis
# ==============================================================================

#' Calculate Spacecraft Power-Increase Envelope Across Time Durations
#' Determines maximum power, minimum power, sustainable power, peak power,
#' thermal-limited power, storage-limited power, converter-limited power, and bus-limited power.
#' @param params System parameters
#' @param durations_vec Vector of boost durations in seconds (e.g., 10s to 3600s)
#' @return Tibble of power envelope limits
#' @export
calculate_power_envelope <- function(params = create_default_parameters(), durations_vec = c(10, 30, 60, 120, 300, 600, 1200, 1800, 3600)) {
  p_base <- params$generation$baseline_power$val
  p_gen_aug <- params$generation$augmented_power$val * params$generation$health$val
  eta_gen <- params$generation$efficiency_0$val
  eta_conv <- params$converter$efficiency_nominal$val
  
  # Generation sustainable power reaching bus after nominal losses
  p_gen_sustainable_bus <- p_gen_aug * eta_gen * eta_conv
  
  # Hardware limits
  p_conv_max <- params$converter$max_power_rating$val * eta_conv
  v_bus <- params$bus$voltage_nominal$val
  i_max <- params$bus$current_max$val
  r_bus <- params$bus$resistance$val
  p_bus_max <- (v_bus * i_max) - (i_max^2 * r_bus)
  
  # Storage energy and discharge rating
  stor_cap_j <- params$storage$capacity_total_j$val * (params$storage$soc_initial$val - params$storage$soc_min$val) * params$storage$health$val
  p_stor_disch_max <- params$storage$max_discharge_power$val * params$storage$health$val
  
  # Radiator continuous steady-state heat rejection at maximum allowable radiator temp (approx 340 K)
  sigma <- 5.670374419e-8
  a_rad <- params$thermal$radiator_area$val
  eps <- params$thermal$emissivity$val
  t_env <- params$thermal$t_ambient_sink$val
  t_rad_limit <- 350.0 # K
  q_rad_max <- eps * sigma * a_rad * (t_rad_limit^4 - t_env^4)
  
  # Radiator-limited continuous power: P_deliv * ((1 - eta_sys)/eta_sys) <= Q_rad_max
  eta_sys_est <- eta_gen * eta_conv * 0.98
  p_thermal_steady_limit <- q_rad_max / ((1.0 - eta_sys_est) / eta_sys_est)

  envelope_rows <- list()

  for (dur in durations_vec) {
    # 1. Storage limited power for this duration
    p_stor_energy_limit <- stor_cap_j / dur
    p_stor_contrib <- min(p_stor_disch_max, p_stor_energy_limit)
    
    # 2. Peak Power (Generation + Peak Storage)
    p_peak_gross <- p_gen_sustainable_bus + p_stor_contrib
    
    # 3. Thermal Transient Allowance: Component Thermal Capacitances absorb heat for short bursts
    c_th_total <- params$generation$thermal_mass$val + params$converter$thermal_mass$val + params$storage$thermal_mass$val
    delta_t_allowable <- 25.0 # K rise allowable
    e_thermal_absorb_j <- c_th_total * delta_t_allowable
    p_thermal_transient_boost <- e_thermal_absorb_j / dur
    p_thermal_limit <- p_thermal_steady_limit + p_thermal_transient_boost
    
    # 4. Converter & Bus Hard Hardware Limits
    p_conv_limit <- p_conv_max
    p_bus_limit <- p_bus_max
    
    # Absolute achievable power constrained by physics
    p_achievable <- min(p_peak_gross, p_thermal_limit, p_conv_limit, p_bus_limit)
    
    envelope_rows[[length(envelope_rows) + 1]] <- list(
      duration_s = dur,
      baseline_power_mw = p_base / 1e6,
      sustainable_power_mw = min(p_gen_sustainable_bus, p_thermal_steady_limit) / 1e6,
      storage_limited_power_mw = (p_gen_sustainable_bus + p_stor_contrib) / 1e6,
      thermal_limited_power_mw = p_thermal_limit / 1e6,
      converter_limited_power_mw = p_conv_limit / 1e6,
      bus_limited_power_mw = p_bus_limit / 1e6,
      peak_power_mw = p_peak_gross / 1e6,
      max_achievable_power_mw = p_achievable / 1e6,
      power_gain_percent = 100.0 * (p_achievable - p_base) / p_base
    )
  }

  dplyr::bind_rows(envelope_rows)
}
