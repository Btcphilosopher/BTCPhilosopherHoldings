# ==============================================================================
# POWER-AUGMENT-R: Power Augmentation Strategies & Modes
# ==============================================================================

#' Determine Augmentation Dispatch across Primary Generation & Energy Storage
#' @param strategy Active augmentation strategy name
#' @param p_demand Total load demand [W]
#' @param p_gen_max Maximum generation capacity [W]
#' @param p_base Baseline generation level [W]
#' @param soc Current storage state of charge [0,1]
#' @param stor_params Storage parameters
#' @param thermal_margin Current system thermal margin [0,1]
#' @return List of dispatched generation target and storage dispatch power
#' @export
calculate_augmentation_dispatch <- function(strategy, p_demand, p_gen_max, p_base, soc, stor_params, thermal_margin = 1.0) {
  soc_min <- stor_params$soc_min$val
  soc_max <- stor_params$soc_max$val
  max_disch <- stor_params$max_discharge_power$val * stor_params$health$val
  max_ch <- stor_params$max_charge_power$val
  
  # Available storage discharge headroom
  storage_can_discharge <- (soc > soc_min)
  storage_can_charge <- (soc < soc_max)
  
  p_gen_target <- p_base
  p_stor_cmd <- 0.0 # Positive = discharge (power out to bus), Negative = charge (absorbing from bus)
  
  if (strategy == "GENERATION_ONLY") {
    # Mode A: Increase generation up to max capacity, no storage boost
    p_gen_target <- min(p_gen_max, max(p_base, p_demand))
    p_stor_cmd <- 0.0
    
  } else if (strategy == "STORAGE_ONLY") {
    # Mode B: Keep generation strictly at baseline, satisfy excess with storage boost
    p_gen_target <- p_base
    shortfall <- max(0, p_demand - p_base)
    if (storage_can_discharge) {
      p_stor_cmd <- min(max_disch, shortfall)
    } else {
      p_stor_cmd <- 0.0
    }
    
  } else if (strategy == "GENERATION_PLUS_STORAGE") {
    # Mode C: Ramp generation to augmented capacity, boost peaks with storage
    p_gen_target <- min(p_gen_max, p_demand)
    shortfall <- max(0, p_demand - p_gen_target)
    if (shortfall > 0 && storage_can_discharge) {
      p_stor_cmd <- min(max_disch, shortfall)
    } else if (shortfall <= 0 && storage_can_charge && (p_gen_max > p_demand)) {
      # Opportunity charge storage from excess available generation
      excess <- min(p_gen_max - p_demand, max_ch)
      p_stor_cmd <- -excess * 0.5 # Gentle recharge
    }
    
  } else if (strategy == "STORAGE_PEAK_SHAVING") {
    # Maintain constant base generation, discharge aggressively on demand spikes
    p_gen_target <- p_base * 1.15
    spike <- max(0, p_demand - p_gen_target)
    if (spike > 0 && storage_can_discharge) {
      p_stor_cmd <- min(max_disch, spike)
    }
    
  } else if (strategy == "CONSTANT_POWER") {
    # Provide fixed augmented output
    p_gen_target <- p_gen_max
    if (p_demand > p_gen_target && storage_can_discharge) {
      p_stor_cmd <- min(max_disch, p_demand - p_gen_target)
    }
    
  } else if (strategy == "THERMAL_LIMITED") {
    # Automatically throttle generation and storage when thermal margin is low
    derate_factor <- max(0.2, min(1.0, thermal_margin / 0.25)) # Throttles when margin < 25%
    p_gen_target <- p_base + (p_gen_max - p_base) * derate_factor
    shortfall <- max(0, p_demand - p_gen_target)
    if (shortfall > 0 && storage_can_discharge) {
      p_stor_cmd <- min(max_disch * derate_factor, shortfall)
    }
    
  } else if (strategy == "STORAGE_LIFE_LIMITED") {
    # Constrain C-rate / discharge power to preserve cycle life
    p_gen_target <- min(p_gen_max, p_demand)
    conservative_disch <- max_disch * 0.45
    shortfall <- max(0, p_demand - p_gen_target)
    if (shortfall > 0 && storage_can_discharge) {
      p_stor_cmd <- min(conservative_disch, shortfall)
    }
  }
  
  list(
    strategy = strategy,
    p_gen_target = p_gen_target,
    p_stor_cmd = p_stor_cmd,
    delta_p_generation = p_gen_target - p_base
  )
}
