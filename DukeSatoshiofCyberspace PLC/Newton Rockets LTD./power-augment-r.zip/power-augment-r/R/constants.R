# ==============================================================================
# POWER-AUGMENT-R: Physical Constants & Environmental Parameters
# ==============================================================================

#' Physical Constants for Spacecraft Electrical & Thermal Systems
#' @export
CONSTANTS <- list(
  # Stefan-Boltzmann constant [W / (m^2 * K^4)]
  STEFAN_BOLTZMANN = 5.670374419e-8,

  # Absolute Zero [K]
  ABSOLUTE_ZERO_C = -273.15,

  # Deep Space Cosmic Microwave Background Temperature [K]
  T_DEEP_SPACE = 3.0,

  # Low Earth Orbit (LEO) Average Effective Radiative Sink Temperature [K]
  T_LEO_ENV = 250.0,

  # Interplanetary (1 AU) Solar Radiation Flux [W/m^2]
  SOLAR_FLUX_1AU = 1361.0,

  # Numerical Tolerance for Energy Conservation Check [MJ]
  ENERGY_RESIDUAL_TOLERANCE = 1e-4,

  # Reference Standard Temperature [K]
  T_REF_STANDARD = 298.15,

  # Electron Charge [C]
  ELEMENTARY_CHARGE = 1.602176634e-19,

  # Faraday Constant [C/mol]
  FARADAY_CONSTANT = 96485.33212
)
