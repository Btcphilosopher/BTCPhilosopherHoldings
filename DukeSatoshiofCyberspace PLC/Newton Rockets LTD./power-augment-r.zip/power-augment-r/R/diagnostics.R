# ==============================================================================
# POWER-AUGMENT-R: Diagnostic Health Classification & Analytics
# ==============================================================================

#' Classify Subsystem Health Statuses
#' Subsystems: GENERATOR, CONVERTER, POWER_BUS, STORAGE, RADIATOR, SENSORS
#' Levels: NORMAL, WARNING, LIMITED, FAULT
#' @param true_state State list
#' @param innovation_residuals Innovation residual vector
#' @param limits Parameter limits
#' @return List of subsystem health records
#' @export
classify_system_health <- function(true_state, innovation_residuals, limits) {
  # Generator Health
  gen_health <- "NORMAL"
  if (true_state$t_gen > limits$t_gen_max * 0.90) gen_health <- "WARNING"
  if (true_state$t_gen > limits$t_gen_max * 0.96) gen_health <- "LIMITED"
  if (true_state$t_gen >= limits$t_gen_max) gen_health <- "FAULT"
  
  # Converter Health
  conv_health <- "NORMAL"
  if (true_state$t_conv > limits$t_conv_max * 0.90) conv_health <- "WARNING"
  if (true_state$t_conv > limits$t_conv_max * 0.97) conv_health <- "LIMITED"
  if (true_state$t_conv >= limits$t_conv_max) conv_health <- "FAULT"
  
  # DC Bus Health
  bus_health <- "NORMAL"
  if (true_state$i_bus > 10000.0) bus_health <- "WARNING"
  if (true_state$i_bus > 11500.0) bus_health <- "LIMITED"
  if (true_state$i_bus >= 12000.0) bus_health <- "FAULT"
  
  # Storage Health
  stor_health <- "NORMAL"
  if (true_state$soc < 0.25 || true_state$t_stor > limits$t_stor_max * 0.92) stor_health <- "WARNING"
  if (true_state$soc < 0.16 || true_state$t_stor > limits$t_stor_max * 0.97) stor_health <- "LIMITED"
  if (true_state$soc <= 0.10 || true_state$t_stor >= limits$t_stor_max) stor_health <- "FAULT"
  
  # Sensor Observer Health
  sensor_health <- "NORMAL"
  if (abs(innovation_residuals$v_bus) > 4.0 || abs(innovation_residuals$t_conv) > 5.0) sensor_health <- "WARNING"
  if (abs(innovation_residuals$v_bus) > 10.0 || abs(innovation_residuals$t_conv) > 12.0) sensor_health <- "FAULT"

  list(
    generator = gen_health,
    converter = conv_health,
    power_bus = bus_health,
    storage = stor_health,
    sensors = sensor_health,
    overall = max(c(gen_health, conv_health, bus_health, stor_health, sensor_health))
  )
}
