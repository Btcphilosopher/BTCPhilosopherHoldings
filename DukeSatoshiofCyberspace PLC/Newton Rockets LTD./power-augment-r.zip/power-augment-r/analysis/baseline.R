# ==============================================================================
# POWER-AUGMENT-R: Baseline Cruise & Augmentation Boost Analysis Script
# ==============================================================================

library(poweraugmentr)
library(ggplot2)
library(dplyr)

cat("[INFO] Running baseline analysis...\n")
res_base <- run_scenario("BASELINE")
rep_base <- generate_engineering_report(res_base)
cat(rep_base)

cat("\n[INFO] Running power boost propulsion burn analysis...\n")
res_boost <- run_scenario("POWER_BOOST")
rep_boost <- generate_engineering_report(res_boost)
cat(rep_boost)
