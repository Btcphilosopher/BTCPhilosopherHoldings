library(testthat)
library(poweraugmentr)

test_check("poweraugmentr")
