test_that("Timestep convergence test (dt, dt/2, dt/4) demonstrates asymptotic error reduction", {
  sim_1 <- run_simulation(duration = 200, dt = 1.0, method = "RK4")
  sim_2 <- run_simulation(duration = 200, dt = 0.5, method = "RK4")
  sim_4 <- run_simulation(duration = 200, dt = 0.25, method = "RK4")
  
  final_t_1 <- tail(sim_1$telemetry$t_generator, 1)
  final_t_2 <- tail(sim_2$telemetry$t_generator, 1)
  final_t_4 <- tail(sim_4$telemetry$t_generator, 1)
  
  diff_1_2 <- abs(final_t_1 - final_t_2)
  diff_2_4 <- abs(final_t_2 - final_t_4)
  
  # Error strictly decreases with finer step
  expect_lte(diff_2_4, diff_1_2 + 1e-4)
})
