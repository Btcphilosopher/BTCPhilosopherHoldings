test_that("First Law of Thermodynamics Energy Residual is strictly zero within numerical precision", {
  sim <- run_simulation(duration = 300, dt = 0.5, method = "RK4")
  expect_true(sim$summary$is_energy_conserved)
  expect_lt(sim$summary$max_energy_residual_mj, 1e-4)
})

test_that("Conversion efficiency obeys P_out <= P_in", {
  conv <- create_power_converter(1.5e6, 320.0, create_default_parameters()$converter)
  expect_lte(conv$p_out, conv$p_in)
  expect_gte(conv$p_loss, 0.0)
})

test_that("Storage State of Charge remains in physical bounds [0, 1]", {
  sim <- run_simulation(duration = 600, dt = 1.0)
  expect_true(all(sim$telemetry$soc >= 0.0))
  expect_true(all(sim$telemetry$soc <= 1.0))
})
