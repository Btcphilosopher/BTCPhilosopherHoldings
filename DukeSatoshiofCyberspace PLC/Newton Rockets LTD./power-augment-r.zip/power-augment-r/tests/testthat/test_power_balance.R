test_that("Electrical distribution loss satisfies P_bus_loss = I^2 * R", {
  bus_params <- create_default_parameters()$bus
  bus <- create_power_bus(2.0e6, 2.0e6, bus_params)
  
  expected_i <- 2.0e6 / bus_params$voltage_nominal$val
  expected_loss <- (expected_i^2) * bus_params$resistance$val
  
  expect_equal(bus$i_bus, expected_i, tolerance = 1e-4)
  expect_equal(bus$p_loss, expected_loss, tolerance = 1e-4)
})

test_that("Net usable power correctly accounts for generation, storage and losses", {
  sim <- run_simulation(duration = 100, dt = 1.0)
  t <- sim$telemetry
  
  # P_usable = P_gen + P_stor_disch - P_stor_charge - P_conv_loss - P_bus_loss
  calculated_usable <- t$p_conv_out + t$p_stor_disch - t$p_stor_charge - t$p_bus_loss
  expect_equal(t$p_usable, calculated_usable, tolerance = 1e-3)
})
