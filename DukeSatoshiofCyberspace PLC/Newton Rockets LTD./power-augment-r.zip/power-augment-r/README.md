# POWER-AUGMENT-R
## Rocket Power Increase & Energy Augmentation Digital Twin
### Production-Grade R Aerospace Electrical Systems Laboratory

```
========================================================================================
                                 POWER FLOW TOPOLOGY
========================================================================================
 ENERGY SOURCE (Solar / Fission / RTG)
       │
       ▼
 PRIMARY GENERATION (Baseline + Augmentation)  ──► [Loss: P_gen_loss] ──► Heat Q_gen
       │
       ▼
 POWER CONVERSION (DC-DC / Switching / Rect.) ──► [Loss: P_conv_loss] ──► Heat Q_conv
       │
       ▼
 POWER DISTRIBUTION BUS (Main DC Rail, V_bus)  ──► [Loss: I²R_bus]   ──► Heat Q_bus
       ├───► PROPULSION INTERFACE (High Voltage Arcjet / Magnetoplasmadynamic / Pump)
       ├───► AVIONICS & GNC (Guidance, Navigation, Control)
       ├───► COMMUNICATIONS (Deep Space High-Gain RF/Optical Transceiver)
       ├───► THERMAL MANAGEMENT SYSTEM (Cryocoolers, Pumps, Heaters)
       ├───► SCIENCE & PAYLOAD (Spectrometers, Radar, Drilling)
       ├───► LIFE SUPPORT / ECLSS (O2 Electrolysis, CO2 Scrubbers)
       │
       ▲
       │ Bidirectional Energy Flow
       ▼
 ENERGY STORAGE BUFFER (LiFePO4 / Supercapacitor Matrix) ──► [Loss: I²R_esr] ──► Heat Q_stor
       │
       ▼
 THERMAL RADIATOR NETWORK ──► Radiative Dissipation Q_rad = ε·σ·A·(T⁴ - T_env⁴)
========================================================================================
```

---

## 1. Physical Principles & Core Equations

Power is not a number on a screen. Power is a continuous energy flow constrained by generation, conversion, distribution, storage, and heat dissipation.

### 1.1 Generated Power
$$P_{\text{gen}} = V_{\text{gen}} \cdot I_{\text{gen}}$$
Thermal derating model:
$$\eta_{\text{gen}}(T) = \eta_{\text{gen},0} \cdot [1 - \gamma_{\text{gen}} \cdot (T_{\text{gen}} - T_0)] \cdot h_{\text{gen}}$$

### 1.2 Power Conversion
$$P_{\text{conv,out}} = \eta_{\text{conv}} \cdot P_{\text{conv,in}}$$
$$P_{\text{conv,loss}} = P_{\text{conv,in}} - P_{\text{conv,out}} = (1 - \eta_{\text{conv}}) \cdot P_{\text{conv,in}}$$

### 1.3 DC Power Distribution Bus
$$I_{\text{bus}} = \frac{P_{\text{bus,load}}}{V_{\text{bus}}}$$
$$P_{\text{bus,loss}} = I_{\text{bus}}^2 \cdot R_{\text{bus}}$$

### 1.4 Energy Storage (Electrochemical / Supercapacitor Matrix)
$$P_{\text{storage,loss}} = I_{\text{stor}}^2 \cdot R_{\text{esr}}$$
$$\frac{d\text{SOC}}{dt} = -\frac{I_{\text{stor}}}{C_{\text{rated}}} = -\frac{P_{\text{stor,internal}}}{V_{\text{oc}}(\text{SOC}) \cdot E_{\text{nom}}}$$

### 1.5 Net Usable Power & Power Margin
$$P_{\text{usable}} = P_{\text{gen}} + P_{\text{storage,discharge}} - P_{\text{storage,charge}} - P_{\text{conv,loss}} - P_{\text{bus,loss}}$$
$$P_{\text{margin}} = P_{\text{usable}} - P_{\text{demand}}$$
$$\Delta P = P_{\text{augmented}} - P_{\text{baseline}}$$
$$\text{Power Gain \%} = 100 \times \frac{P_{\text{augmented}} - P_{\text{baseline}}}{P_{\text{baseline}}}$$

### 1.6 First Law of Thermodynamics: Energy Balance Validation
At every simulation timestep $t_k$:
$$E_{\text{source}}(t) = E_{\text{delivered}}(t) + E_{\text{stored}}(t) + E_{\text{dissipated}}(t) + E_{\text{losses}}(t)$$
$$\text{Residual} = E_{\text{source}} - (E_{\text{delivered}} + \Delta E_{\text{stored}} + E_{\text{dissipated}} + E_{\text{losses}})$$
The validation engine flags any numerical residual where $|\text{Residual}| > \varepsilon_{\text{tolerance}}$ ($10^{-5}$ MJ).

### 1.7 Radiative Heat Rejection (Stefan-Boltzmann)
$$Q_{\text{rad}} = \varepsilon \cdot \sigma \cdot A_{\text{radiator}} \cdot (T_{\text{radiator}}^4 - T_{\text{env}}^4)$$
where $\sigma = 5.670374419 \times 10^{-8} \text{ W}/(\text{m}^2\cdot\text{K}^4)$.

---

## 2. Command-Line Interface (CLI)

The package includes an executable script `power-augment-cli.R`:

```bash
# Run standard baseline simulation
Rscript R/cli.R simulate --strategy GENERATION_PLUS_STORAGE --duration 1200 --step 0.5

# Execute predefined scenario
Rscript R/cli.R scenario --name POWER_BOOST --out output/power_boost.json

# Calculate multi-constraint power envelope
Rscript R/cli.R envelope --tmax 3600 --points 50

# Run Monte Carlo uncertainty analysis (2000 iterations)
Rscript R/cli.R monte-carlo --n 2000 --threads 4

# Run Sobol & OAT sensitivity analysis
Rscript R/cli.R sensitivity --params eta_gen,eta_conv,R_bus,A_rad,C_stor

# Multi-objective Pareto optimization
Rscript R/cli.R optimise --obj max_power,min_loss,max_thermal_margin

# Replay recorded telemetry stream
Rscript R/cli.R telemetry replay --file data/telemetry/sample_boost_run.json

# Run formal physics and numerical convergence tests
Rscript R/cli.R validate --tolerance 1e-5

# Compile complete aerospace engineering dossier
Rscript R/cli.R report --format html --out reports/engineering_dossier.html
```

---

## 3. Digital Twin & Observer Pipeline

```
 [ Physical System ] ──► True State x(t) = [P_gen, V_bus, I_bus, SOC, T_gen, T_conv, T_stor, T_bus]
        │
        ▼
 [ Sensor Model ]    ──► y_m(t) = H·x(t) + Bias(t) + Noise ~ N(0, R_sensor) + Quantization
        │
        ▼
 [ State Estimator ] ──► Extended Kalman Filter (EKF) state estimate x̂(t|t), Covariance P(t|t)
        │
        ▼
 [ Health Diagn. ]  ──► Innovation Residual e(t) = y_m(t) - H·x̂(t|t-1)
                         Status Classification: [NORMAL | WARNING | LIMITED | FAULT]
```

---

## 4. Package Structure

```
power-augment-r/
├── DESCRIPTION
├── NAMESPACE
├── README.md
├── renv.lock
├── R/
│   ├── constants.R           # Stefan-Boltzmann, physical constants & standards
│   ├── units.R               # Engineering unit converters (W, kW, MW, V, A, K, °C, MJ)
│   ├── state.R               # State vectors, parameters, and telemetry data structures
│   ├── generation.R          # Primary & augmented generation physics
│   ├── augmentation.R        # Modes A, B, C & hybrid operational strategies
│   ├── storage.R             # Battery & supercapacitor electrochemical buffer
│   ├── converter.R           # DC-DC conversion, switching, and conditioning
│   ├── power_bus.R           # DC distribution bus, I²R loss, and voltage drop
│   ├── loads.R               # 10 aerospace load subsystems and priority shedding
│   ├── thermal.R             # 5-node lumped thermal network & radiative rejection
│   ├── losses.R              # Complete loss breakdown and energy accounting
│   ├── solver.R              # Euler, RK2, RK4 integration solvers with step validation
│   ├── simulation.R          # Deterministic time-domain simulation engine
│   ├── constraints.R         # Operating envelope limits and margin calculation
│   ├── envelope.R            # calculate_power_envelope() multi-constraint curves
│   ├── monte_carlo.R         # Stochastic Monte Carlo uncertainty engine
│   ├── sensitivity.R         # One-at-a-time (OAT) & Sobol sensitivity indices
│   ├── optimisation.R        # Multi-objective Pareto frontier optimizer
│   ├── statistics.R          # Statistical distributions, quantiles, and correlations
│   ├── digital_twin.R        # Sensor model, noise injection, and EKF observer
│   ├── diagnostics.R         # Fault detection and health classification
│   ├── fault_injection.R     # Analytical fault injection engine
│   ├── telemetry.R           # Telemetry recording, scrubbing, replay, and export
│   ├── scenarios.R           # 12 versioned aerospace mission scenarios
│   ├── reporting.R           # Automated engineering report generator
│   └── cli.R                 # Command-line interface dispatcher
├── inst/
│   ├── config/               # Default YAML configuration files
│   └── schemas/              # JSON schemas for parameters and telemetry
├── tests/
│   ├── testthat/             # Core testthat test suites
│   ├── test_conservation.R   # Energy conservation residual test
│   ├── test_power_balance.R  # Kirchhoff & power balance test
│   ├── test_thermal.R        # Second law of thermodynamics test
│   └── test_numerical.R      # Timestep convergence (Δt, Δt/2, Δt/4) test
├── analysis/
│   ├── baseline.R            # Baseline power mission profile script
│   ├── augmentation.R        # Power augmentation boost analysis
│   ├── power_envelope.R      # Power envelope calculation
│   ├── monte_carlo.R         # Monte Carlo script
│   └── optimisation.R        # Pareto optimization script
├── data/
│   ├── scenarios/            # Mission scenario JSON datasets
│   └── telemetry/            # Sample recorded telemetry runs
└── reports/                  # Generated aerospace engineering reports
```

---

## 5. Engineering Governance

Every parameter in `power-augment-r` is strictly registered with:
- `name`: Unique engineering identifier
- `value`: Standard SI quantity
- `unit`: Formatted unit string
- `source`: Reference datasheet, empirical test, or qualification doc
- `valid_range`: Physical envelope $[min, max]$
- `uncertainty`: $1\sigma$ or $3\sigma$ measurement tolerance
- `revision`: Aerospace engineering revision code
- `provenance`: `MEASURED`, `SIMULATED`, `ESTIMATED`, or `USER_DEFINED_PARAMETER`
