# GRAVITAS

**A precision Earth-gravity measurement digital twin and simulator.**

GRAVITAS models a hypothetical precision spring gravimeter and the physical environment it
works in, from the Earth's gravity field to a measured value with a traceable uncertainty:

```
EARTH → EARTH GRAVITY FIELD → LOCAL ENVIRONMENT → GRAVIMETER → SENSOR → ANALOG/DIGITAL SIGNAL CHAIN
      → CALIBRATION → ESTIMATION → UNCERTAINTY → MEASURED GRAVITY
```

> The physics is the product. The digital twin is the instrument. The interface is only the observation layer.

Every number the console displays comes from the engine and can be traced to a named
channel of the measurement chain (`truth.*`, `sensor.*`, `instrument.*`, `raw.*`,
`filter.*`, `calibration.*`, `correction.*`, `estimate.*`). Nothing is hard-coded in the UI.

**Status: synthetic.** GRAVITAS is a simulator of a *generic* instrument. Performance figures
below were demonstrated in simulation against synthetic truth. They are not claims of
laboratory accuracy and do not describe any commercial instrument.

---

## What is modelled

| Layer | Contents |
|---|---|
| Earth | WGS84 ellipsoid; geodetic/ECEF/ENU with strict validation; spherical model GM/r²; rotating oblate model (zonal series J₂…J₁₀ + centrifugal), cross-checked against Somigliana to < 1e-12 m/s²; free-air gradient; GMST; geoid (Bruns); terrain prisms |
| Tides | reduced-order lunar and solar ephemerides (Meeus); exact differential tide; elastic gravimetric factor; lunar, solar and combined components exposed separately and kept at physical scale (~±150 µGal on 9.81 m/s²) |
| Anomalies | **SYNTHETIC GEOPHYSICAL MODEL**: point mass, sphere, rectangular slab (Nagy prism), horizontal layer (infinite / faulted), Gaussian density anomaly; survey grids and profiles |
| Environment | thermostatted thermal model; microseism, cultural and broadband vibration; Eötvös effect for moving platforms |
| Instrument | proof mass + spring + damper (exact ZOH integration, Numba), mechanical stops, equilibrium and force-feedback (PID) modes, quadrature interferometer with fringe counting, ADC/DAC quantisation |
| Sensor | bias, scale factor (y = Sx), drift (linear, quadratic, settling, random walk), white noise, flicker-like correlated noise, temperature bias, vibration, cross-axis and tilt |
| Estimation | moving average, low-pass, Butterworth, Kalman (explicit state space), Kalman/RLS gravity estimator (gravity, drift, tidal admittance), calibration (zero, scale, temperature, drift, joint), Allan deviation with noise identification |
| Uncertainty | GUM budget with 10 traceable contributions; linear and Monte Carlo propagation; full-chain Monte Carlo validation |
| Data | strict telemetry schema; CSV / Parquet / HDF5 / JSON recording with manifests; replay (load, play, pause, seek, filter, correct, analyse, export) |
| Validation | 250 pytest tests; independent R statistics; Kotlin contract tests against real engine payloads |
| Console | Kotlin + Compose for Desktop: Overview, Gravity, Instrument, Signal, Earth, Tides, Anomalies, Calibration, Uncertainty, Allan, Experiments, Map, Telemetry, Physics Inspector |

## Quick start

Requirements: Python ≥ 3.12, (optional) R ≥ 4.1 with `jsonlite`, JDK 17+ for the console.

```bash
pip install -e ".[dev]"
```

```bash
python -m pytest -q
```

```bash
gravitas analyse --validate
```

Experiments (outputs: summary JSON, manifest, CSV series, PNG + interactive HTML plots):

```bash
gravitas static --duration 3600 --sample-rate 10
```

```bash
gravitas anomaly --duration 1800 --sample-rate 10
```

Other commands: `gravitas simulate | altitude | latitude | tides | vibration | calibrate |
analyse | allan | monte-carlo | replay | export | serve` (`gravitas <cmd> --help`).

Engine API + console:

```bash
gravitas serve --port 8765 --speed 1
```

```bash
cd kotlin/gravitas-console && ./gradlew run --args="--engine http://127.0.0.1:8765"
```

Independent R validation:

```bash
make r-validate
```

## Demonstrated results (this release)

| Check | Result |
|---|---|
| Zonal series vs Somigliana on the ellipsoid | < 1e-12 m/s² at all latitudes |
| Rotation effect at equator | ω²a = 3.392 Gal (exact); 0 at the pole |
| Free-air gradient recovered by instrument occupations (0–1000 m) | −3.0842e-6 vs model −3.0850e-6 m/s²/m (0.02 %) |
| Gravimetric factor recovered from a 72 h record | 1.1567 vs 1.1563 true (Kalman) |
| Anomaly survey (1.4 km line, 0.78 m/s) | 0.73 µGal RMS error on a ±316 µGal synthetic anomaly, r = 0.99999 |
| Calibration campaign (injected 150 µGal bias, 200 ppm scale, 50 µGal/K, 17 µGal/day) | residual 198 µGal → 1.0 µGal RMS |
| Vibration (×20 ground motion) | Butterworth reduces scatter 125×, moving average 89× |
| Monte Carlo (100 trials) vs analytical uncertainty | ratio 0.98, k = 2 coverage 95 % |
| Reproducibility | identical seed ⇒ bit-identical output for any chunking |

Known limitation: the drift-rate calibration over a 6 h campaign is only marginally consistent
with its stated uncertainty (2.4 σ Python, 3.9 σ R-HAC) because the flicker-like noise is
almost degenerate with a linear trend at that length. See `docs/CALIBRATION.md`.

![static](docs/figures/static.png)
![anomaly](docs/figures/anomaly.png)

## Documentation

* [ARCHITECTURE](docs/ARCHITECTURE.md) — layers, chain, determinism, manifest
* [PHYSICS](docs/PHYSICS.md) — Newtonian, zonal, centrifugal, tidal, anomaly, thermal, vibration models
* [EARTH_MODEL](docs/EARTH_MODEL.md) — ellipsoid, coordinates, gravity models, rotation, tides, geoid
* [INSTRUMENT](docs/INSTRUMENT.md) — proof mass, spring, feedback, optical readout, ADC
* [MEASUREMENT_MODEL](docs/MEASUREMENT_MODEL.md) — true gravity → raw measurement, sensor errors, processing
* [CALIBRATION](docs/CALIBRATION.md) — calibration procedures, filters, Kalman state spaces, Allan deviation
* [UNCERTAINTY](docs/UNCERTAINTY.md) — budget, propagation, Monte Carlo
* [VALIDATION](docs/VALIDATION.md) — tests, R layer, console integration, defects found and fixed
* [API](docs/API.md) — engine HTTP/JSON contract used by the console

Each approximation is documented with MODEL · ASSUMPTIONS · EQUATIONS · LIMITATIONS · EXPECTED VALIDITY.

## Repository layout

```
src/gravitas/        engine (constants, earth, physics, instrument, sensors, estimation,
                     simulation, experiments, telemetry, uncertainty, validation, api, cli)
tests/               pytest suite
r/                   independent R validation (validation, uncertainty, allan_variance, calibration)
kotlin/gravitas-console/   Compose for Desktop engineering console
simulator/           configurations, scenarios, reference datasets (+ generator)
docs/                documentation and figures
tools/               capture of real engine payloads for console integration tests
```

## Notes on the console build

Compose for Desktop libraries are pinned to 1.5.12 so that the build resolves from Maven
Central only. Where Google Maven is reachable, the newer Compose line can be enabled; see
`kotlin/gravitas-console/README.md`.

## Licence

MIT — see [LICENSE](LICENSE).
