#!/usr/bin/env Rscript
# GRAVITAS — independent residual & regression validation of a static record.
#
# Input : static_telemetry.csv (telemetry schema), static_estimate.json
# Checks: (1) corrected − true residual is unbiased relative to the Python
#             uncertainty claim (z-score);
#         (2) R's own regression of the residual on time and temperature finds
#             remaining drift / temperature terms consistent with the stated
#             calibration uncertainties (HAC SE);
#         (3) raw − true reproduces the injected sensor bias recorded in the
#             telemetry (bias_mps2 column), via R's own linear model;
#         (4) the Python Type-A noise term is not overconfident relative to R's
#             Newey–West standard error of the mean;
#         (5) R-computed mean of corrected record agrees with Python estimate.
#         Ljung–Box is reported for information (correlated noise is modelled).
source(file.path(dirname(sub("--file=", "", grep("--file=", commandArgs(FALSE), value = TRUE))), "common.R"))
a <- gv_args()
d <- gv_read_csv(file.path(a$data, "static_telemetry.csv"))
est <- fromJSON(file.path(a$data, "static_estimate.json"))

keep <- d$sim_time_s >= 300                       # discard settling
d <- d[keep, ]
resid <- d$corrected_measurement_mps2 - d$static_gravity_mps2
t <- d$sim_time_s
temp <- d$temperature_c

# block means at 60 s (1 Hz data) to reduce serial correlation
m <- 60
rb <- gv_block_mean(resid, m); tb <- gv_block_mean(t, m); Tb <- gv_block_mean(temp, m)
fit <- lm(rb ~ I(tb - tb[1]) + I(Tb - 20))
V <- gv_newey_west(fit)
co <- coef(fit); se <- sqrt(diag(V))
z_drift <- co[2] / se[2]; z_temp <- co[3] / se[3]

u_python <- est$standard_uncertainty_mps2
r_mean <- mean(resid)
z_bias <- r_mean / u_python

# Residual drift / temperature dependence must be consistent with the calibration
# certificate's *stated* uncertainties (they are not expected to be zero).
man <- fromJSON(file.path(a$data, "static_telemetry.csv.manifest.json"))
calp <- man$calibration_parameters
z_drift_c <- co[2] / sqrt(se[2]^2 + calp$u_drift_rate_mps2_per_s^2)
z_temp_c <- co[3] / sqrt(se[3]^2 + calp$u_temperature_coefficient_mps2_per_k^2)

# Recorded injected bias vs raw − true: level, and slope on 60 s blocks with HAC SE
raw_minus_true <- d$raw_measurement_mps2 - d$true_gravity_mps2
bb <- gv_block_mean(d$bias_mps2, m); rbt <- gv_block_mean(raw_minus_true, m)
bs <- 1e-8  # rescale the regressor to O(1) for conditioning
bfit <- lm(rbt ~ I((bb - mean(bb)) / bs))
bse <- sqrt(diag(gv_newey_west(bfit)))[2] / bs
bslope <- unname(coef(bfit)[2]) / bs

# Noise term of the Python budget vs R's HAC standard error of the record mean
mfit <- lm(rb ~ 1)
se_mean_hac <- sqrt(gv_newey_west(mfit)[1, 1])
u_noise_py <- est$contributions$standard_uncertainty_mps2[est$contributions$name == "sensor_noise"]
lb <- Box.test(rb - fitted(fit), lag = min(10, length(rb) %/% 5), type = "Ljung-Box")

r_est <- mean(d$corrected_measurement_mps2[d$sim_time_s >= max(d$sim_time_s) - 3600])
checks <- list(
  gv_check("residual_mean_within_3u", abs(z_bias) < 3, z_bias, 0, 3, "mean(corrected − truth)/u_python"),
  gv_check("residual_drift_consistent_with_calibration_u", abs(z_drift_c) < 4, unname(z_drift_c), 0, 4,
           "HAC drift term / √(se² + u_drift²)"),
  gv_check("residual_temperature_consistent_with_calibration_u", abs(z_temp_c) < 4, unname(z_temp_c), 0, 4,
           "HAC temperature term / √(se² + u_cT²)"),
  gv_check("raw_bias_slope_vs_injected_bias", abs(bslope - 1) < 4 * bse + 0.05, bslope, 1, unname(4 * bse + 0.05),
           "60 s blocks of raw − true regressed on recorded injected bias (HAC)"),
  gv_check("raw_bias_level", abs(mean(raw_minus_true) - mean(d$bias_mps2)) < 2e-8,
           mean(raw_minus_true), mean(d$bias_mps2), 2e-8, "mean(raw − true) vs mean injected bias"),
  gv_check("python_noise_term_not_overconfident", u_noise_py >= 0.5 * se_mean_hac, u_noise_py, se_mean_hac,
           0.5, "Python Type-A noise term ≥ ½ × R Newey–West SE of the mean"),
  gv_check("python_estimate_agrees_with_R_mean", abs(r_est - est$value_mps2) < 3 * u_python,
           r_est, est$value_mps2, 3 * u_python, "last-hour mean of corrected record vs Python estimate")
)
dir.create(a$out, showWarnings = FALSE, recursive = TRUE)
png(file.path(a$out, "validation_residuals.png"), width = 1000, height = 700)
par(mfrow = c(2, 2))
plot(t / 3600, resid * 1e8, type = "l", col = "grey40", xlab = "time [h]", ylab = "corrected − true [µGal]",
     main = "Residual (independent R analysis)")
lines(tb / 3600, rb * 1e8, col = "navy", lwd = 2)
hist(rb * 1e8, breaks = 30, col = "steelblue", border = "white", main = "60 s block residuals", xlab = "µGal")
qqnorm(rb * 1e8, main = "Normal Q–Q (block residuals)"); qqline(rb * 1e8, col = "firebrick")
acf(rb, main = "ACF of block residuals")
dev.off()
ok <- gv_report("R residual validation", checks,
                list(residual_mean_mps2 = r_mean, python_u_mps2 = u_python, drift_coef = unname(co[2]),
                     drift_se_hac = unname(se[2]), temp_coef = unname(co[3]), temp_se_hac = unname(se[3]),
                     se_mean_hac_mps2 = se_mean_hac, python_noise_term_mps2 = u_noise_py,
                     ljung_box_p_informational = lb$p.value,
                     note = "Residuals are serially correlated by design (flicker + random-walk sensor noise); Ljung-Box is informational.",
                     n_blocks = length(rb)),
                a$out, "validation.json")
quit(status = if (ok) 0 else 1)
