#!/usr/bin/env Rscript
# Run every R validation script; non-zero exit if any fails.
a <- commandArgs(trailingOnly = TRUE)
data <- if (length(a) >= 1) a[1] else "simulator/datasets"
out <- if (length(a) >= 2) a[2] else "output/r"
here <- dirname(sub("--file=", "", grep("--file=", commandArgs(FALSE), value = TRUE)))
scripts <- c("validation.R", "uncertainty.R", "allan_variance.R", "calibration.R")
status <- vapply(scripts, function(s) system2("Rscript", c(file.path(here, s), data, out)), integer(1))
cat(sprintf("\nR validation: %d/%d scripts passed\n", sum(status == 0), length(status)))
quit(status = if (all(status == 0)) 0 else 1)
