# GRAVITAS — shared helpers for the independent R validation layer.
# Base R + jsonlite only. Nothing here imports or re-uses Python code: the
# statistics are re-derived from the exported data.

suppressPackageStartupMessages(library(jsonlite))

gv_args <- function() {
  a <- commandArgs(trailingOnly = TRUE)
  list(data = if (length(a) >= 1) a[1] else "simulator/datasets",
       out  = if (length(a) >= 2) a[2] else "output/r")
}

gv_read_csv <- function(path) {
  if (!file.exists(path)) stop(sprintf("dataset not found: %s (run `make datasets`)", path))
  read.csv(path, stringsAsFactors = FALSE)
}

gv_check <- function(name, passed, value, expected, tolerance, detail = "") {
  list(name = name, passed = isTRUE(passed), value = value, expected = expected,
       tolerance = tolerance, detail = detail)
}

gv_report <- function(title, checks, extra, out_dir, file) {
  dir.create(out_dir, showWarnings = FALSE, recursive = TRUE)
  passed <- all(vapply(checks, function(c) c$passed, logical(1)))
  rep <- list(title = title, passed = passed, checks = checks, results = extra,
              r_version = R.version.string, generated = format(Sys.time(), "%Y-%m-%dT%H:%M:%SZ", tz = "UTC"))
  write_json(rep, file.path(out_dir, file), auto_unbox = TRUE, digits = NA, pretty = TRUE)
  cat(sprintf("== %s: %s\n", title, if (passed) "PASS" else "FAIL"))
  for (c in checks) cat(sprintf("   [%s] %-45s value=%-14s expected=%-14s tol=%s\n",
                                if (c$passed) "ok" else "FAIL", c$name,
                                format(signif(c$value, 6)), format(signif(c$expected, 6)), format(c$tolerance)))
  invisible(passed)
}

# Block means (approximate whitening of correlated series)
gv_block_mean <- function(x, m) {
  n <- (length(x) %/% m) * m
  colMeans(matrix(x[seq_len(n)], nrow = m))
}

# Newey–West (Bartlett kernel) HAC covariance for an lm fit — implemented here
# so the R layer does not depend on the `sandwich` package.
gv_newey_west <- function(fit, lag = NULL) {
  X <- model.matrix(fit)
  e <- residuals(fit)
  n <- nrow(X)
  if (is.null(lag)) lag <- floor(4 * (n / 100)^(2 / 9))
  XtXi <- solve(crossprod(X))
  u <- X * e
  S <- crossprod(u)
  if (lag > 0) for (l in seq_len(lag)) {
    w <- 1 - l / (lag + 1)
    G <- crossprod(u[(l + 1):n, , drop = FALSE], u[1:(n - l), , drop = FALSE])
    S <- S + w * (G + t(G))
  }
  XtXi %*% S %*% XtXi
}
