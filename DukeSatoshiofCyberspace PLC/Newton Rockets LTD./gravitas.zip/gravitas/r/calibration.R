#!/usr/bin/env Rscript
# GRAVITAS — independent calibration-quality analysis and tidal-admittance regression.
#
# 1. Re-fits the calibration model  raw = b0 + S·ref + cT·(T − 20) + r·t  with lm()
#    and Newey–West (HAC) standard errors computed in R, then compares with the
#    injected truth and with the Python estimates.
# 2. Regresses the calibrated tide record on the model tide (with drift term) to
#    estimate the gravimetric factor independently.
source(file.path(dirname(sub("--file=", "", grep("--file=", commandArgs(FALSE), value = TRUE))), "common.R"))
a <- gv_args()
c <- gv_read_csv(file.path(a$data, "calibration_campaign.csv"))
s <- fromJSON(file.path(a$data, "calibration_summary.json"))
# predictors are rescaled to O(1) for numerical conditioning, then transformed back
sc <- c(1, 1e-3, 1, 3600)
fit <- lm(raw_dev_mps2 ~ I(reference_dev_mps2 / sc[2]) + I(temperature_c - 20) + I(t_s / sc[4]), data = c)
# The sensor noise model contains correlation times up to 1e4 s (flicker-like
# Gauss–Markov ensemble + bias random walk), so the HAC window must span hours,
# not the default few samples: Bartlett lag = n/5 (≈ 1.2 h of 20 s blocks).
V <- gv_newey_west(fit, lag = floor(nrow(c) / 5))
co <- unname(coef(fit)) / sc; se <- sqrt(diag(V)) / sc
inj <- c(s$injected$bias_mps2, s$injected$scale_factor, s$injected$temperature_coefficient_mps2_per_k,
         s$injected$drift_rate_mps2_per_s)
pyv <- c(s$estimated$bias_mps2, s$estimated$scale_factor, s$estimated$temperature_coefficient_mps2_per_k,
         s$estimated$drift_rate_mps2_per_s)
nm <- c("bias", "scale_factor", "temperature_coefficient", "drift_rate")
z <- (co - inj) / se
checks <- lapply(seq_along(nm), function(i)
  gv_check(paste0("recovers_injected_", nm[i], "_HAC_z"), abs(z[i]) < 4, z[i], 0, 4,
           sprintf("R estimate %.6g vs injected %.6g", co[i], inj[i])))
checks <- c(checks, lapply(seq_along(nm), function(i)
  gv_check(paste0("python_", nm[i], "_within_R_HAC_2se"), abs(pyv[i] - co[i]) < 2 * se[i] + 1e-3 * abs(co[i]),
           pyv[i], co[i], 2 * se[i], "Python joint fit vs R lm")))
checks[[length(checks) + 1]] <- gv_check("calibration_improves_residual",
  s$residual_rms_calibrated_mps2 < 0.1 * s$residual_rms_uncalibrated_mps2,
  s$residual_rms_calibrated_mps2, s$residual_rms_uncalibrated_mps2, 0.1, "validation-run RMS after/before")

# --- tidal admittance ---------------------------------------------------------
td <- gv_read_csv(file.path(a$data, "tides_series.csv"))
tsum <- fromJSON(file.path(a$data, "tides_summary.json"))
td <- td[td$t_s > 600, ]
tf <- lm(I(calibrated_mps2 - static_true_mps2) ~ I(tide_model_mps2 / 1e-6) + I(t_s / 86400), data = td)
Vt <- gv_newey_west(tf, lag = floor(nrow(td) / 5))
delta_r <- unname(coef(tf)[2]) / 1e-6 * tsum$gravimetric_factor_model
delta_se <- sqrt(Vt[2, 2]) / 1e-6 * tsum$gravimetric_factor_model
checks[[length(checks) + 1]] <- gv_check("gravimetric_factor_recovered_HAC",
  abs(delta_r - tsum$gravimetric_factor_true) < 4 * delta_se + 5e-4, delta_r, tsum$gravimetric_factor_true,
  4 * delta_se + 5e-4, "R regression of measured tide on model tide")

dir.create(a$out, showWarnings = FALSE, recursive = TRUE)
png(file.path(a$out, "calibration_r.png"), width = 1000, height = 450)
par(mfrow = c(1, 2))
plot(c$reference_dev_mps2 * 1e5, residuals(fit) * 1e8, pch = 20, col = "navy",
     xlab = "reference deviation [mGal]", ylab = "fit residual [µGal]", main = "Calibration fit residuals (R)")
abline(h = 0, col = "firebrick")
plot(td$t_s / 3600, (td$calibrated_mps2 - td$static_true_mps2) * 1e8, type = "l", col = "grey40",
     xlab = "time [h]", ylab = "µGal", main = "Measured vs model tide")
lines(td$t_s / 3600, (fitted(tf)) * 1e8, col = "darkorange3")
dev.off()
ok <- gv_report("R calibration & admittance validation", checks,
                list(r_coefficients = setNames(as.list(co), nm), r_hac_se = setNames(as.list(se), nm),
                     injected = setNames(as.list(inj), nm), python = setNames(as.list(pyv), nm),
                     gravimetric_factor_r = delta_r, gravimetric_factor_r_se = delta_se,
                     gravimetric_factor_python_kalman = tsum$gravimetric_factor_kalman), a$out, "calibration.json")
quit(status = if (ok) 0 else 1)
