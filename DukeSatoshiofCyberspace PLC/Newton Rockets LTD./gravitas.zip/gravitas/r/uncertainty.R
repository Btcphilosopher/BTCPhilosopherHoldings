#!/usr/bin/env Rscript
# GRAVITAS — independent statistics of the Monte Carlo uncertainty validation.
#
# Re-derives, from the per-trial errors only: mean, sd, RMSE, bootstrap CIs,
# chi-square test of sd against the analytical u, coverage with a binomial
# test, Shapiro–Wilk normality; and cross-checks Python's summary numbers.
source(file.path(dirname(sub("--file=", "", grep("--file=", commandArgs(FALSE), value = TRUE))), "common.R"))
a <- gv_args()
mc <- gv_read_csv(file.path(a$data, "monte_carlo_trials.csv"))
s <- fromJSON(file.path(a$data, "monte_carlo_summary.json"))
e <- mc$error_mps2
u <- mc$analytic_u_mps2
n <- length(e)
set.seed(2026)
B <- 4000
boot_sd <- replicate(B, sd(sample(e, n, replace = TRUE)))
boot_mean <- replicate(B, mean(sample(e, n, replace = TRUE)))
u_rms <- sqrt(mean(u^2))
ratio <- sd(e) / u_rms
# chi-square test: H0 sd = u_rms
chi <- (n - 1) * var(e) / u_rms^2
p_chi <- 2 * min(pchisq(chi, n - 1), 1 - pchisq(chi, n - 1))
covered <- sum(abs(e) <= 2 * u)
bt <- binom.test(covered, n, p = 0.9545)
sw <- shapiro.test(e)
checks <- list(
  gv_check("r_sd_equals_python_sd", abs(sd(e) - s$mc_std_mps2) < 1e-15 + 1e-9 * s$mc_std_mps2, sd(e), s$mc_std_mps2, 1e-9,
           "independent recomputation"),
  gv_check("r_rmse_equals_python_rmse", abs(sqrt(mean(e^2)) - s$rmse_mps2) < 1e-9 * s$rmse_mps2, sqrt(mean(e^2)), s$rmse_mps2, 1e-9, ""),
  gv_check("mc_sd_consistent_with_analytic_chisq_p", p_chi > 0.001, p_chi, 0.05, 0.001, "χ² test of sd = analytical u"),
  gv_check("ratio_in_bootstrap_ci", quantile(boot_sd, 0.0005) / u_rms < 1 && quantile(boot_sd, 0.9995) / u_rms > 1,
           ratio, 1, NA, "99.9 % bootstrap interval of sd/u contains 1"),
  gv_check("coverage_binomial_p", bt$p.value > 0.001, covered / n, 0.9545, 0.001, "binomial test of k = 2 coverage"),
  gv_check("bias_ci_contains_zero", quantile(boot_mean, 0.0005) < 0 && quantile(boot_mean, 0.9995) > 0,
           mean(e), 0, NA, "99.9 % bootstrap CI of the mean error"),
  gv_check("errors_normal_shapiro_p", sw$p.value > 0.001, sw$p.value, 0.05, 0.001, "Shapiro–Wilk")
)
dir.create(a$out, showWarnings = FALSE, recursive = TRUE)
png(file.path(a$out, "monte_carlo_r.png"), width = 1000, height = 450)
par(mfrow = c(1, 2))
hist(e * 1e8, breaks = 20, freq = FALSE, col = "steelblue", border = "white",
     main = "Monte Carlo errors vs analytical N(0, u²)", xlab = "error [µGal]")
xx <- seq(min(e), max(e), length.out = 200)
lines(xx * 1e8, dnorm(xx, 0, u_rms) * 1e-8, col = "firebrick", lwd = 2)
qqnorm(e / u_rms, main = "Q–Q of e / u"); abline(0, 1, col = "firebrick")
dev.off()
ok <- gv_report("R Monte Carlo uncertainty validation", checks,
                list(n = n, mean = mean(e), sd = sd(e), rmse = sqrt(mean(e^2)), u_rms = u_rms, ratio = ratio,
                     sd_boot_ci95 = unname(quantile(boot_sd, c(0.025, 0.975))),
                     mean_boot_ci95 = unname(quantile(boot_mean, c(0.025, 0.975))),
                     coverage = covered / n, chisq_p = p_chi, shapiro_p = sw$p.value), a$out, "uncertainty.json")
quit(status = if (ok) 0 else 1)
