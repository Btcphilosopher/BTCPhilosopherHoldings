#!/usr/bin/env Rscript
# GRAVITAS — independent Allan-deviation implementation and cross-check.
#
# R implements the *non-overlapping* and *overlapping* Allan variance directly
# from the definition (no shared code with Python) and compares with the
# Python export; it also fits the log–log slopes with lm().
source(file.path(dirname(sub("--file=", "", grep("--file=", commandArgs(FALSE), value = TRUE))), "common.R"))
a <- gv_args()
d <- gv_read_csv(file.path(a$data, "static_telemetry.csv"))
py <- gv_read_csv(file.path(a$data, "allan_python.csv"))
y <- d$raw_measurement_mps2 - mean(d$raw_measurement_mps2)
tau0 <- median(diff(d$sim_time_s))

oadev <- function(y, m, tau0) {
  # overlapping: averages ybar_k over windows of m, differences of adjacent (lag m) averages
  cs <- c(0, cumsum(y))
  n <- length(y)
  ybar <- (cs[(m + 1):(n + 1)] - cs[1:(n - m + 1)]) / m
  dif <- ybar[(m + 1):length(ybar)] - ybar[1:(length(ybar) - m)]
  sqrt(0.5 * mean(dif^2))
}
nadev <- function(y, m) {
  k <- length(y) %/% m
  yb <- colMeans(matrix(y[1:(k * m)], nrow = m))
  sqrt(0.5 * mean(diff(yb)^2))
}

ms <- round(py$tau_s / tau0)
r_o <- vapply(ms, function(m) oadev(y, m, tau0), numeric(1))
r_n <- vapply(ms, function(m) nadev(y, m), numeric(1))
rel <- abs(r_o / py$adev_mps2 - 1)

short <- py$tau_s <= 10 & py$tau_s >= 1
fit_short <- lm(log10(r_o[short]) ~ log10(py$tau_s[short]))
mid <- py$tau_s >= 20 & py$tau_s <= max(py$tau_s) / 2
fit_mid <- lm(log10(r_o[mid]) ~ log10(py$tau_s[mid]))
# non-overlapping ADEV has fewer degrees of freedom: compare loosely at short τ only
nrel <- abs(r_n[py$tau_s <= 100] / r_o[py$tau_s <= 100] - 1)

checks <- list(
  gv_check("overlapping_adev_matches_python_max_rel", max(rel) < 1e-6, max(rel), 0, 1e-6,
           "independent R overlapping ADEV vs Python"),
  gv_check("non_overlapping_consistent_short_tau", median(nrel) < 0.15, median(nrel), 0, 0.15,
           "non-overlapping vs overlapping (median rel. diff, τ ≤ 100 s)"),
  gv_check("short_tau_slope_is_white_or_steeper", coef(fit_short)[2] < -0.3, unname(coef(fit_short)[2]), -0.5, 0.2,
           "log–log slope 1–10 s"),
  gv_check("long_tau_not_white", coef(fit_mid)[2] > -0.45, unname(coef(fit_mid)[2]), 0, 0.45,
           "flicker / drift flattens ADEV at long τ")
)
dir.create(a$out, showWarnings = FALSE, recursive = TRUE)
png(file.path(a$out, "allan_r.png"), width = 800, height = 600)
plot(py$tau_s, py$adev_mps2 * 1e8, log = "xy", pch = 19, col = "navy", xlab = expression(tau ~ "[s]"),
     ylab = "Allan deviation [µGal]", main = "Allan deviation — Python (points) vs R (line)")
lines(py$tau_s, r_o * 1e8, col = "darkorange3", lwd = 2)
lines(py$tau_s, r_n * 1e8, col = "grey50", lty = 2)
legend("topright", c("Python overlapping", "R overlapping", "R non-overlapping"),
       col = c("navy", "darkorange3", "grey50"), pch = c(19, NA, NA), lty = c(NA, 1, 2))
grid()
dev.off()
write.csv(data.frame(tau_s = py$tau_s, adev_python = py$adev_mps2, adev_r_overlapping = r_o, adev_r_nonoverlapping = r_n),
          file.path(a$out, "allan_r.csv"), row.names = FALSE)
ok <- gv_report("R Allan deviation", checks,
                list(slope_short = unname(coef(fit_short)[2]), slope_mid = unname(coef(fit_mid)[2]),
                     min_adev_mps2 = min(r_o), tau_at_min_s = py$tau_s[which.min(r_o)]), a$out, "allan.json")
quit(status = if (ok) 0 else 1)
