# GRAVITAS Engine API (v1)

The Kotlin engineering console never computes physics. It observes the Python
engine through this HTTP/JSON interface, served by:

```
gravitas serve --host 127.0.0.1 --port 8765 [--config simulator/configurations/default.json] [--speed 1.0]
```

* Transport: HTTP/1.1, JSON bodies, UTF-8. No authentication (bind to localhost).
* Base URL: `http://127.0.0.1:8765/api/v1`
* **Units are always in the field name** (`_mps2`, `_m`, `_s`, `_deg`, `_c`, `_n`, `_kg`, `_v`, `_rad`).
  All accelerations are SI m/s². Conversion to Gal / mGal / µGal is a
  presentation concern (1 Gal = 1e-2 m/s², 1 mGal = 1e-5 m/s², 1 µGal = 1e-8 m/s²).
* Floats are IEEE-754 doubles serialised with full precision (`repr`). Non-finite
  values are never emitted; missing values are `null`.
* Errors: HTTP 4xx/5xx with `{"error": "<message>"}`.
* A live simulation runs in a background thread. Simulated time advances at
  `speed` × wall-clock (default 1.0). Every value below is produced by that
  simulation (or by an on-demand engine computation for profile endpoints).

## Endpoints

### `GET /health`
```json
{"status": "ok", "software_version": "1.0.0", "sim_time_s": 12.3, "running": true, "speed": 1.0}
```

### `GET /overview`
```json
{
  "timestamp": "2026-01-01T12:00:12.300000Z",
  "sim_time_s": 12.3,
  "latitude_deg": 53.38, "longitude_deg": -1.47, "altitude_m": 100.0,
  "mode": "equilibrium",
  "local_gravity_mps2": 9.8135...,          // TRUE gravity at the sensor incl. tides + anomaly
  "static_gravity_mps2": 9.8135...,         // TRUE gravity excluding tides
  "raw_measurement_mps2": 9.8135...,        // ADC output converted with nominal instrument constant
  "filtered_mps2": 9.8135...,
  "calibrated_mps2": 9.8135...,
  "corrected_gravity_mps2": 9.8135...,      // calibrated minus modelled tide (estimate of static gravity)
  "estimate_mps2": 9.8135...,               // gravity estimator (Kalman) output
  "bias_mps2": 1.2e-7,                      // instantaneous total injected sensor bias (truth, for twin inspection)
  "tidal_component_mps2": -4.1e-7,
  "temperature_c": 20.03,
  "vibration_rms_mps2": 3.1e-6,             // RMS vertical platform acceleration over last 1 s
  "standard_uncertainty_mps2": 2.1e-8,
  "expanded_uncertainty_mps2": 4.2e-8,
  "coverage_factor": 2.0,
  "instrument_status": "STABLE",            // STABLE | SETTLING | SATURATED | UNLOCKED | PAUSED
  "status_reasons": []
}
```

### `GET /series?window_s=60&max_points=2000`
Most recent `window_s` seconds of every pipeline stage (decimated by stride to at most `max_points`).
```json
{
  "window_s": 60, "sample_rate_hz": 10.0,
  "t_s": [...],
  "true_mps2": [...], "raw_mps2": [...], "filtered_mps2": [...],
  "calibrated_mps2": [...], "corrected_mps2": [...], "estimate_mps2": [...],
  "estimate_sigma_mps2": [...], "tide_mps2": [...], "static_true_mps2": [...],
  "temperature_c": [...], "vibration_mps2": [...], "bias_mps2": [...]
}
```
The live buffer holds 24 h of simulated time; windows supported by the console: 1, 10, 60, 600, 3600, 86400 s.

### `GET /instrument`
```json
{
  "mode": "equilibrium",
  "proof_mass_kg": 0.01, "spring_constant_npm": 0.3948, "damping_nspm": 0.0126,
  "natural_frequency_hz": 1.0, "damping_ratio": 0.1, "reference_gravity_mps2": 9.81,
  "proof_mass_position_m": 1.2e-9, "proof_mass_velocity_mps": 3.0e-12,
  "spring_force_n": 0.0981..., "gravity_force_n": 0.0981..., "feedback_force_n": 0.0,
  "net_force_n": 1.0e-12,
  "readout": {"type": "optical", "wavelength_m": 1.55e-6, "phase_rad": 1.5708,
              "intensity_i_v": 1.0, "intensity_q_v": 2.0, "measured_displacement_m": 1.2e-9},
  "adc": {"bits": 24, "full_scale_v": 5.0, "lsb_v": 5.96e-7, "code_i": 123, "code_q": 456, "saturated": false},
  "temperature_c": 20.0, "bias_mps2": 1.0e-7, "noise_rms_mps2": 5.0e-8,
  "history": {"t_s": [...], "position_m": [...], "velocity_mps": [...], "feedback_force_n": [...]}
}
```

### `GET /physics` · `POST /physics`
Switches used by the live simulation. POST body may be partial: `{"switches": {"moon": false}}`.
Disabling an effect changes the simulation from the next simulated chunk onward.
```json
{"switches": {"earth_gravity": true, "earth_oblateness": true, "earth_rotation": true,
              "altitude": true, "latitude": true, "moon": true, "sun": true,
              "local_anomaly": true, "temperature": true, "vibration": true,
              "sensor_bias": true, "sensor_noise": true}}
```

### `GET /earth?lat_deg=53.38&lon_deg=-1.47&alt_m=100`
(Parameters optional; default = current instrument location.)
```json
{
  "location": {"latitude_deg": 53.38, "longitude_deg": -1.47, "altitude_m": 100.0},
  "spherical_mps2": 9.80...,
  "newtonian_mps2": 9.83..., "newtonian_enu_mps2": [e, n, u],
  "centrifugal_mps2": 0.020..., "centrifugal_enu_mps2": [e, n, u],
  "effective_mps2": 9.81..., "effective_enu_mps2": [e, n, u],
  "somigliana_mps2": 9.81..., "somigliana_free_air_mps2": 9.81...,
  "model_discrepancy_mps2": 1e-9,
  "free_air_gradient_mps2_per_m": -3.08e-6,
  "latitude_profile": {"lat_deg": [...], "effective_mps2": [...], "no_rotation_mps2": [...],
                       "spherical_mps2": [...], "centrifugal_up_mps2": [...]},
  "altitude_profile": {"alt_m": [...], "effective_mps2": [...], "spherical_mps2": [...]}
}
```

### `GET /tides?hours=48&step_s=600`
Tides at the instrument location starting at the current simulated epoch.
```json
{"t_s": [...], "timestamps": [...], "lunar_mps2": [...], "solar_mps2": [...], "combined_mps2": [...],
 "gravimetric_factor": 1.16, "current": {"lunar_mps2": ..., "solar_mps2": ..., "combined_mps2": ...}}
```

### `GET /anomalies` · `POST /anomalies/survey`
```json
{
  "label": "SYNTHETIC GEOPHYSICAL MODEL",
  "bodies": [{"kind": "sphere", "description": "...", "params": {"radius_m": 50.0, "density_contrast_kgpm3": 800.0, "center_enu_m": [0, 0, -120]}}],
  "profile": {"distance_m": [...], "east_m": [...], "north_m": [...], "anomaly_mps2": [...]},
  "grid": {"east_m": [...], "north_m": [...], "anomaly_mps2": [[...], ...]},
  "survey": null | {"distance_m": [...], "true_anomaly_mps2": [...], "measured_anomaly_mps2": [...], "uncertainty_mps2": [...], "rms_error_mps2": ...}
}
```
`POST /anomalies/survey` body `{"duration_s": 1800, "sample_rate_hz": 10}` runs the anomaly experiment and returns the same document with `survey` populated.

### `GET /calibration` · `POST /calibration/run`
Body `{"seed": 7}` optional. Returns the latest calibration report (or `null` if none yet for GET):
```json
{
  "injected": {"bias_mps2": ..., "scale_factor": ..., "temperature_coefficient_mps2_per_k": ..., "drift_rate_mps2_per_s": ...},
  "estimated": {"bias_mps2": ..., "scale_factor": ..., "temperature_coefficient_mps2_per_k": ..., "drift_rate_mps2_per_s": ...},
  "estimated_uncertainty": {"bias_mps2": ..., "scale_factor": ..., "temperature_coefficient_mps2_per_k": ..., "drift_rate_mps2_per_s": ...},
  "residual_rms_uncalibrated_mps2": ..., "residual_rms_calibrated_mps2": ...,
  "series": {"t_s": [...], "true_mps2": [...], "uncalibrated_mps2": [...], "calibrated_mps2": [...], "temperature_c": [...]}
}
```

### `GET /uncertainty` · `POST /uncertainty/monte-carlo`
```json
{
  "value_mps2": 9.81..., "standard_uncertainty_mps2": ..., "expanded_uncertainty_mps2": ..., "coverage_factor": 2.0,
  "contributions": [
    {"name": "sensor_noise", "standard_uncertainty_mps2": ..., "type": "A",
     "sensitivity": 1.0, "input_uncertainty": ..., "input_unit": "m/s^2", "description": "..."}
  ]
}
```
`POST /uncertainty/monte-carlo` body `{"trials": 50, "duration_s": 300}` →
```json
{"trials": 50, "analytical_std_mps2": ..., "mc_std_mps2": ..., "mc_mean_error_mps2": ..., "rmse_mps2": ...,
 "ci95_mps2": [lo, hi], "coverage_probability": 0.95, "ratio_mc_to_analytical": 1.02, "errors_mps2": [...]}
```

### `GET /allan?max_points=60`
Overlapping Allan deviation of the live raw-measurement record.
```json
{"tau_s": [...], "adev_mps2": [...], "adev_lo_mps2": [...], "adev_hi_mps2": [...], "n_samples": 36000,
 "identification": {"white_noise_mps2_per_rthz": ..., "bias_instability_mps2": ..., "bias_instability_tau_s": ...,
                    "regions": [{"tau_from_s": 0.1, "tau_to_s": 10, "slope": -0.5, "label": "white noise"}]}}
```

### `GET /experiments` · `POST /experiments/{name}`
`GET` → `{"experiments": [{"name": "static", "description": "..."}, ...]}`
names: `static`, `altitude`, `latitude`, `tides`, `anomaly`, `vibration`.
`POST` body `{"duration_s": 600, "sample_rate_hz": 10}` (optional) →
```json
{"name": "static", "summary": {"<key>": <number>, ...},
 "series": {"x": [...], "x_label": "time [s]", "curves": {"<name>": [...]}, "y_unit": "m/s^2"}}
```

### `GET /map`
```json
{
  "instrument": {"latitude_deg": ..., "longitude_deg": ..., "altitude_m": ..., "gravity_mps2": ..., "uncertainty_mps2": ...},
  "survey_path": [{"latitude_deg": ..., "longitude_deg": ..., "anomaly_mps2": ...}],
  "gravity_grid": {"lat_deg": [...], "lon_deg": [...], "g_mps2": [[...]]},
  "anomaly_grid": {"lat_deg": [...], "lon_deg": [...], "anomaly_mps2": [[...]]}
}
```

### `GET /telemetry?n=50`
`{"frames": [TelemetryFrame, ...]}` — most recent `n` frames, schema in `gravitas.telemetry.schema.TelemetryFrame`:
```json
{"timestamp": "2026-01-01T12:00:00Z", "sim_time_s": 0.0, "latitude_deg": 53.38, "longitude_deg": -1.47,
 "altitude_m": 100.0, "true_gravity_mps2": ..., "raw_measurement_mps2": ..., "filtered_mps2": ...,
 "calibrated_mps2": ..., "corrected_measurement_mps2": ..., "tidal_component_mps2": ...,
 "lunar_component_mps2": ..., "solar_component_mps2": ..., "anomaly_component_mps2": ...,
 "bias_mps2": ..., "temperature_c": ..., "vibration_mps2": ..., "uncertainty_mps2": ...,
 "proof_mass_position_m": ..., "feedback_force_n": ..., "adc_code": ..., "status": "STABLE"}
```

### `GET /config`
Reproducibility manifest: seed, timestep, duration, Earth model, instrument model, sensor model,
calibration parameters, location, environment, software version, config hash.

### `POST /control`
```json
{"action": "pause"} | {"action": "resume"} | {"action": "reset", "seed": 42} |
{"action": "set_speed", "speed": 60.0} |
{"action": "set_location", "latitude_deg": 0.0, "longitude_deg": 0.0, "altitude_m": 0.0} |
{"action": "set_mode", "mode": "feedback"}
```
Returns `/health`.
