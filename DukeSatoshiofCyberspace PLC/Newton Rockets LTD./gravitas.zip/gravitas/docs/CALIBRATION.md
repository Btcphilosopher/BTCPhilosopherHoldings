# GRAVITAS — Calibration and Estimation

## 1. Sensor model and its inverse (`estimation/calibration.py`)

```
Δraw(t) = S·Δa(t) + b₀ + c_T (T_m − T_ref) + r (t − t₀) + noise
Δcal(t) = [Δraw(t) − b̂₀ − ĉ_T (T_m − T_ref) − r̂ (t − t₀)] / Ŝ
```

`CalibrationParameters` carries the coefficients **and their uncertainties**, which feed
the uncertainty budget. The default configuration uses a *synthetic factory calibration
certificate* whose values differ from the injected errors by about one stated σ — as a real,
imperfect calibration would. The identity calibration (b̂ = 0, Ŝ = 1, …) is available as
`simulator/configurations/uncalibrated.json`.

## 2. Procedures

| Procedure | Data | Estimator |
|---|---|---|
| Zero calibration | occupation of a reference station | b̂₀ = mean(Δraw − Δref), u from block means |
| Scale factor | ≥ 2 stations of known Δg (calibration line) | OLS slope |
| Temperature | thermal-chamber set-point steps | OLS slope of residual vs T |
| Drift | long occupation | OLS slope of residual vs t |
| **Joint** (recommended) | all of the above | LS with A = [1, Δref, T_m − T_ref, t − t₀] |

Joint-fit covariance = s²(AᵀA)⁻¹ × AR(1) inflation (1+ρ)/(1−ρ) for serially correlated
residuals **plus** the exactly propagated station reference errors
u_ref²(A⁺Z)(A⁺Z)ᵀ (Z = station indicator matrix — a reference error is common to every
sample at that station). Columns are scaled for conditioning.

## 3. Calibration campaign experiment (`experiments/calibration.py`, `gravitas calibrate`)

1. **Inject** known errors (the sensor configuration: b₀ = 1.5e-6 m/s², S = 1.0002,
   c_T = 5e-7 m/s²/K, r = 2e-12 m/s³, plus noise, flicker and random walk).
2. **Campaign** One continuous 6 h record: calibration line 0/150/300/150/0/300/0 m
   (Δg ≈ 93 mGal; synthetic reference values with u_ref = 0.5 µGal per station),
   instrument set-point steps 20→22→18→21→19 °C, fixed range setting.
3. **Fit** joint least squares on 20 s block means of dwell data (transits and 300 s after
   arrival excluded).
4. **Validate** apply the fitted calibration to an independent 1 h run (new seed, different
   temperature) and compare with the identity calibration.

### Demonstrated (seed 7, `tests/test_calibration.py`, `r/calibration.R`)

| Parameter | Injected | Recovered (Python) | Normalised error |
|---|---|---|---|
| b₀ | 1.500e-6 m/s² | 1.5024e-6 | +0.5 σ |
| S | 1.000200 | 1.000197 | −0.3 σ |
| c_T | 5.000e-7 m/s²/K | 4.995e-7 | −0.4 σ |
| r | 2.0e-12 m/s³ | 2.52e-12 | +2.4 σ |

Residual vs truth in the validation run: 198 µGal RMS uncalibrated → **1.0 µGal** calibrated
(improvement ≈ 196×). The independent R refit (Newey–West HAC errors, Bartlett lag ≈ 1.2 h)
agrees with Python within 2 HAC σ for every coefficient.

**Honest limitation.** The drift rate is the weakest parameter: over a 6 h campaign the
flicker-like noise (τ up to 10⁴ s) and the bias random walk are nearly degenerate with a
linear trend, so its error is 2.4 σ (Python, AR(1)-inflated) and 3.9 σ (R, HAC). Longer
campaigns or repeated base-station loops are needed for a robust drift calibration.

## 4. Filters (`estimation/filtering.py`)

| Filter | Definition | State carried |
|---|---|---|
| moving average | y[k] = (1/N) Σ x[k−i] | FIR delay line |
| low-pass | y[k] = y[k−1] + α(x[k] − y[k−1]), α = 1 − e^{−2πf_cΔt} | 1 |
| Butterworth | n-th order, SOS, causal (zero-phase `sosfiltfilt` available for replay) | SOS zi |
| Kalman | Model A below | x, P |

All are streaming (chunk-invariant) and start at steady state on the first sample.

## 5. Kalman filters — explicit state-space definitions (`estimation/kalman.py`)

Generic: x_k = F x_{k−1} + w (Q), z_k = H_k x_k + v (R); Joseph-form update.

**Model A — constant-velocity gravity tracker** (filter stage)
* state x = [Δg, Δġ]
* transition F = [[1, Δt], [0, 1]]
* observation H = [1, 0]
* process covariance Q = q [[Δt³/3, Δt²/2], [Δt²/2, Δt]] (white jerk PSD q)
* measurement covariance R = σ² (per-sample white noise of the raw stream)

**Model B — gravity estimator** (`gravity_estimator.py`)
* state x = [g₀, β, ε] (static gravity deviation, residual drift rate, residual tidal admittance)
* transition F = I₃, Q = diag(q_g Δt, q_β Δt, 0) (q_g > 0 only for surveys)
* observation H_k = [1, t_k − t₀, T_nom(t_k)] (time-varying; inactive states pinned to 0)
* measurement R_k = σ̂², σ̂² = ⟨(z_k − z_{k−1})²⟩/2 adaptively, seeded by a prior
* samples are taken every max(1/f_s, 1/(2·ENBW), 1 s) and only after the settling time
With Q = 0 this is recursive least squares (tested: equals the sample mean, P = σ²/N).
RTS smoothing is available for offline use.

## 6. Allan deviation (`estimation/allan.py`)

Overlapping ADEV via cumulative sums (O(N) per τ), χ² confidence intervals with Howe's
white-FM equivalent degrees of freedom, log-spaced τ. Noise identification by local log–log
slope (−1 quantisation, −½ white, 0 bias instability = σ_min/0.664, +½ random walk,
+1 drift with rate √2 σ/τ). Exported as CSV/JSON (`gravitas allan`). Independently
re-implemented in R: agreement 1e-15 relative.
