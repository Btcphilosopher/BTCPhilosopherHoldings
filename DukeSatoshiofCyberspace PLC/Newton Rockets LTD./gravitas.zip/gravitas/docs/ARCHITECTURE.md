# GRAVITAS — Architecture

> The physics is the product. The digital twin is the instrument. The interface is only the observation layer.

## 1. Layers

```
┌───────────────────────────── Kotlin + Compose engineering console (kotlin/gravitas-console)
│      observation only: polls the API, converts units, plots. No physics.
├───────────────────────────── HTTP/JSON API  (src/gravitas/api, docs/API.md)
│      LiveSimulation: background thread, ring buffers, on-demand engine calls
├───────────────────────────── Simulation engine (src/gravitas/simulation)
│      SimulationConfig → SimulationEngine.step(n) → ChainChunk (every stage)
│      Monte Carlo engine, clock, scenario schema, inspectable state
├─────────── Estimation & uncertainty (estimation/, uncertainty/)
├─────────── Instrument & sensor twins (instrument/, sensors/)
├─────────── Physics & Earth (physics/, earth/, constants/)
└─────────── Telemetry, replay, validation, experiments; R independent validation (r/)
```

Dependencies point strictly downwards: `earth` and `physics` know nothing about
instruments; the instrument knows nothing about the Earth; only the engine
composes them. The console depends only on the API contract.

## 2. The measurement chain (exactly as implemented in `simulation/engine.py`)

| # | Stage | Module(s) | Chain channels |
|---|-------|-----------|----------------|
| 1 | EARTH | `earth.gravity`, `physics.acceleration`, `physics.centrifugal` | `earth.newtonian_mps2`, `earth.centrifugal_mps2`, `earth.effective_mps2` |
| 2 | TRUE GRAVITY | `earth.tides`, `physics.anomalies` | `tide.*`, `anomaly.delta_g_mps2`, `truth.static_gravity_mps2`, `truth.gravity_mps2` |
| 3 | ENVIRONMENT | `instrument.thermal`, `sensors.vibration`, Eötvös | `environment.*` |
| 4 | SENSOR (equivalent input errors) | `sensors.*` | `sensor.*` |
| 5 | INSTRUMENT | `instrument.gravimeter` (proof mass, spring, feedback) | `instrument.*` |
| 6 | ADC / READOUT | `instrument.optical_readout`, `interferometer`, `adc` | `adc.*` |
| 7 | RAW MEASUREMENT | nominal instrument constant | `raw.gravity_mps2` |
| 8 | FILTER | `estimation.filtering` | `filter.gravity_mps2` |
| 9 | CALIBRATION | `estimation.calibration` | `calibration.gravity_mps2` |
| 10 | CORRECTION | tide model, Eötvös | `correction.*` |
| 11 | GRAVITY ESTIMATOR | `estimation.gravity_estimator` (Kalman / RLS) | `estimate.gravity_mps2`, `estimate.sigma_mps2` |
| 12 | UNCERTAINTY | `uncertainty.budget` | `GravityEstimate` |
| 13 | FINAL MEASUREMENT | `SimulationResult.final_estimate()` | value ± U (k = 2) |

Every intermediate array is kept in a `ChainChunk` (`simulation/state.py`) and is
recorded by `telemetry.recorder` (`content="chain"`): any value shown in the console
can be traced to a named channel, and each telemetry field's source channel is
declared in `telemetry.schema.FIELD_SOURCES`.

## 3. Time, chunks and determinism

* Time is derived from an integer sample counter (`SimulationClock`), never accumulated.
* The engine is stateful and chunked. Proof-mass state, filter memories, Kalman state,
  thermal node, drift walk, Gauss–Markov states and RNG positions are carried between
  chunks. Tide grids are aligned to the global sample index and random walks are
  accumulated sequentially, so **any chunking is bit-identical** to a single run
  (`tests/test_reproducibility.py`).
* Random numbers come from `SeedSequence(seed).spawn()` into named streams
  (`RNG_STREAMS`). Every stream draws a fixed number of variates per sample whatever the
  physics switches, so switching an effect off never changes other noise realisations.
* Two rates: output rate `f_s` and internal rate `f_s · oversample`. The oversample factor
  is raised automatically so that the internal Nyquist frequency exceeds 1.25 × the
  highest vibration frequency (no simulation aliasing); the value used is in the manifest.

## 4. Reproducibility manifest

`SimulationEngine.manifest()` records the seed, RNG streams, output and internal
time-steps, duration, start epoch, Earth model (ellipsoid, zonal degree, switches),
tide models (truth and correction), anomaly bodies, instrument model, sensor model,
calibration parameters, filter, estimator, location, trajectory, environment,
uncertainty settings, software version, the full configuration, and its SHA-256 hash.
Feeding `manifest["config"]` back into `SimulationConfig` reproduces the run exactly.

## 5. Interfaces

* **Python API**: `SimulationEngine(cfg).run()` → `SimulationResult` (`.chain`, `.manifest`,
  `.final_estimate()`, `.to_xarray()`).
* **CLI**: `gravitas simulate | static | altitude | latitude | tides | anomaly | vibration |
  calibrate | analyse | allan | monte-carlo | replay | export | serve`.
* **HTTP API**: `docs/API.md`, served by `gravitas serve` (stdlib `http.server`).
* **Files**: CSV (+ sidecar manifest), Parquet (schema metadata), HDF5 (root attribute),
  JSON (top-level `manifest`). Lossless float64 round-trip is tested.

## 6. Technology

| Concern | Choice |
|---|---|
| Numerics | NumPy, SciPy (`expm`, signal filters, statistics) |
| Hot loop | Numba `@njit(cache=True)` gravimeter kernel (~10⁷ internal steps/s) |
| Configuration | Pydantic v2 (strict, `extra="forbid"`) |
| Data | pandas, xarray, h5py, PyArrow |
| Plots | Matplotlib (PNG), Plotly (HTML) |
| Independent statistics | R (base + jsonlite) |
| Console | Kotlin 2.0, Compose for Desktop, kotlinx-serialization, `java.net.http` |

JAX / CuPy acceleration is declared as an optional extra (`pip install .[accel]`) but is
**not used** by the current code: the Numba kernel already runs a 24 h, 10 Hz
simulation in a few seconds on a CPU.

## 7. Directory map

```
src/gravitas/constants     physical constants (cited), exact unit conversions
src/gravitas/earth         ellipsoid, coordinates, normal gravity, gravity model, rotation, tides, geoid, terrain
src/gravitas/physics       potentials, accelerations, centrifugal/Eötvös, tidal acceleration, anomaly bodies
src/gravitas/instrument    proof mass, spring, feedback, interferometer, optical readout, ADC, thermal, gravimeter kernel
src/gravitas/sensors       bias, scale factor, drift, noise, vibration, cross-axis
src/gravitas/estimation    filters, Kalman, gravity estimator, calibration, Allan deviation
src/gravitas/simulation    scenario schema, clock, state, engine, Monte Carlo engine
src/gravitas/experiments   static, altitude, latitude, tides, anomaly, vibration, calibration
src/gravitas/telemetry     schema, recorder, replay
src/gravitas/uncertainty   budget, propagation, Monte Carlo statistics
src/gravitas/validation    analytical checks, published reference values, residual diagnostics
src/gravitas/api           live simulation service + HTTP server
tests/                     pytest suite (250 tests)
r/                         independent statistical validation
kotlin/gravitas-console/   engineering console
simulator/                 configurations, scenarios, reference datasets
tools/                     API fixture capture for console integration tests
```
