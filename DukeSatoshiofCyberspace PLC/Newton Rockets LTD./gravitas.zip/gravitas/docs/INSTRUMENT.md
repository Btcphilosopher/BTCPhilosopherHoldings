# GRAVITAS — Instrument Twin

A **generic** precision spring gravimeter. It does not reproduce any commercial instrument.

## 1. Proof mass, spring and damper (`proof_mass.py`, `spring.py`)

* **MODEL** Mass m = 10 g on a Hookean spring (f₀ = 1 Hz, k = mω₀² = 0.3948 N/m) with viscous
  damping ζ = 0.7. The spring pre-tension x₀ is set at range adjustment so k x₀ = m g_ref.
  Displacement x is positive downward along the sensitive axis.
* **EQUATIONS**
  ```
  m ẍ = F_gravity − F_spring − F_damping + F_feedback
  F_gravity = m a_in,  F_spring = k (x + x₀),  F_damping = c ẋ
  ⇒ ẍ = (a_in − g_ref) − ω₀² x − 2ζω₀ ẋ + F_fb/m
  equilibrium:  a = g_ref + ω₀² x        (1 µGal ⇔ 0.253 nm)
  ```
* **Mechanical stops** |x| ≤ 50 µm (±197 mGal). Contact holds the mass at the stop and
  flags SATURATED.
* **Range adjustment** g_ref is the coarse nulling (1 mGal resolution) at the start station;
  the exact zero offset is part of the sensor bias and is removed by calibration.

## 2. Numerical integration

Exact zero-order-hold discretisation of the linear 2-state system,
s_{k+1} = A_d s_k + B_d u_k with [A_d B_d] from `scipy.linalg.expm` of the augmented
matrix. Unconditionally stable, no numerical damping (tested: undamped oscillator is
area-preserving; under-damped step response matches the analytic solution to 1e-12 m).
The loop is a Numba kernel at the internal rate f_s·oversample (default 100 Hz for 10 Hz
output). At start-up the mass is placed at static equilibrium for the first input block.

## 3. Feedback (force-rebalance) mode (`feedback.py`)

* **MODEL** Discrete PID with anti-windup, PD gains placed for a closed-loop bandwidth of
  5 Hz (ζ_c = 0.7), integral time 0.5 s, force limit 0.2 mN (±2 Gal), 24-bit DAC.
* **MEASUREMENT** a = g_ref + ω₀² x̂ − F̂_fb/m (feedback force plus residual displacement).
* **VALIDITY** Holds x at < 1e-12 m; reads a 500 µGal step to 0.05 µGal (tested). DAC
  quantisation (0.24 µGal/LSB at 24 bit) is visible as extra short-term noise.

## 4. Optical readout (`interferometer.py`, `optical_readout.py`)

* **MODEL** Double-pass Michelson, λ = 1550 nm, φ = 4πx/λ + π/4, quadrature detection
  I = (P₀/2)(1 + V cos φ), Q = (P₀/2)(1 + V sin φ), photodetector noise (20 µV) and readout
  noise (10 µV), 20-bit ADC per channel, atan2 demodulation and fringe counting.
* **Fringe order** At start-up the fringe order is resolved by a coarse auxiliary sensor
  (modelled ideal at the λ/2 level); afterwards the phase is tracked purely by counting.
  A true phase step > π between internal samples is flagged UNLOCKED (fringe loss) and
  never silently repaired. (A one-fringe error is 3.06 mGal — this was a real bug found
  and fixed during validation; see VALIDATION.md.)
* **Alternative** Linear (capacitive-style) transducer 0.2 V/µm, 24-bit ±10 V ADC
  (quantisation-limited at ≈ 0.024 µGal).

## 5. ADC (`adc.py`)

Mid-tread uniform quantiser: LSB = FS/2ⁿ, clipping flagged as saturation, optional input
noise (requires an explicit RNG). Verified: |error| ≤ LSB/2, σ = LSB/√12.

## 6. Integrating output

Each output sample is the block mean of the internal samples (integrating ADC):
proof-mass position, measured position and feedback force. This is the anti-alias
filter of the output stream.

## 7. Inspectable internal state (`instrument.*`, `adc.*` channels; `/instrument` endpoint)

proof-mass position, velocity, spring force, gravity force, feedback force, net force,
optical phase, I/Q voltages, ADC codes, saturation, instrument temperature, bias, noise.

## 8. Limitations

Linear spring (no hysteresis, no anelastic creep beyond the drift model); single-axis
proof mass; no electrostatic spring-softening; ideal quadrature; thermal effects enter only
through the sensor error models (see MEASUREMENT_MODEL.md).
