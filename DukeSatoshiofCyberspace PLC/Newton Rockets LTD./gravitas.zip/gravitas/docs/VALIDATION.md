# GRAVITAS — Validation

Validation has four independent layers. All of them were run for this release; results
below are from that run (Python 3.13, NumPy 2.5, R 4.3.3, JDK 21).

## 1. pytest suite (`tests/`, 250 tests — all passing)

```
python -m pytest -q             # 250 passed (≈ 25 s)
python -m pytest -q -m slow     # Monte Carlo (80 trials) and 48 h tide recovery
```

| Required check | Where | Criterion |
|---|---|---|
| Newtonian g ∝ 1/r² | test_gravity::TestNewtonian | g r² = GM to 1e-15; g(R)/g(2R) = 4 |
| ∇V consistency | test_gravity, test_anomalies | analytic a = numerical ∇V |
| Ellipsoid constants | test_gravity::TestEllipsoid | TR8350.2 γ_e, γ_p, k, m, J₂, b |
| Normal gravity | test_gravity::TestNormalGravity | series = Somigliana < 1e-9 m/s² at 9 latitudes; plumb ⟂ ellipsoid |
| Altitude decrease | test_gravity::TestAltitude, test_experiments | strictly decreasing −0.5…30 km; free-air gradient −3.0855e-6 at 45° |
| Rotation vs latitude | test_gravity::TestRotationAndLatitude | Δg_rot(equator) = ω²a; 0 at the pole; monotonic; γ_p − γ_e |
| Coordinates | test_coordinates | round trips < 1e-12 rad / 1e-6 m; invalid input rejected |
| Sidereal time / ephemerides | test_rotation, test_tides | Meeus 12.a, 25.a, 47.a; distance ranges over a year |
| Tide physics | test_tides | exact vs degree 2 (< 3 %); −110 µGal Moon at zenith; amplitudes physically scaled; M₂ / O₁,K₁ |
| Anomalies | test_anomalies | point-mass limit, Bouguer limit, sphere inside/outside, Gaussian mass, layer edge |
| Instrument response | test_instrument | known input ⇒ expected reading (5 levels, 2e-11 m/s²); analytic step response (1e-12 m); vibration attenuation (f₀/f)²; feedback; stops; readout-noise propagation (15 %) |
| ADC | test_instrument | |e| ≤ LSB/2, σ = LSB/√12, saturation flagged |
| Bias appears | test_sensor | raw − true = injected bias ± 2e-9; disappears when switched off |
| Scale factor | test_sensor | y = S x with S = 1.01 to 2e-5 |
| Noise statistics | test_sensor | σ (0.6 %), KS normality, Welch ASD (5 %), ADEV slope −½, GM variance/correlation, flicker plateau, random-walk variance ∝ t |
| Filters | test_estimator | DC preserved; stream = batch; σ_out = √(N₀·ENBW) (10 %); Butterworth stop-band |
| Kalman | test_estimator | Q = 0 ⇒ mean and σ²/N; ramp tracking; RTS improves |
| Estimator | test_estimator | static + drift; tidal admittance; engine estimate within 3u of truth |
| Calibration reduces bias | test_calibration | campaign recovers all four injected errors (|z| < 4), residual 198 → 1 µGal |
| Uncertainty | test_uncertainty | all 10 contributions present and traceable; sensitivities model-derived |
| Monte Carlo agreement | test_uncertainty (slow) | 0.7 < sd/u < 1.3, coverage ≥ 85 % |
| Reproducibility | test_reproducibility | identical seeds ⇒ bit-identical channels; chunking 0.1–1000 s ⇒ bit-identical; switch toggles do not perturb other streams; manifest round trip |
| Telemetry & serialization | test_telemetry | strict schema; CSV/Parquet/HDF5/JSON lossless; replay play/pause/seek/filter/correct/analyse/export |
| Experiments | test_experiments | static, altitude (gradient < 0.2 %), latitude, tides (δ within 0.3 %), anomaly (r > 0.999), vibration (filter gain > 20×) |
| API | test_api | every endpoint JSON-safe; values trace to the chain; switches change the simulation |

`gravitas analyse --validate` runs a fast analytical subset on any installation.

## 2. Independent R layer (`r/`, `make r-validate`)

R re-derives statistics from exported files with its own implementations (base R + jsonlite):

| Script | Independent analysis | Result |
|---|---|---|
| validation.R | residual regression with Newey–West HAC errors (own implementation); bias regression; HAC standard error of the mean vs the Python noise term | PASS (7/7) |
| uncertainty.R | MC sd/RMSE recomputation, bootstrap CIs, χ² variance test, binomial coverage test, Shapiro–Wilk | PASS (7/7) |
| allan_variance.R | overlapping and non-overlapping ADEV from the definition; log–log slopes | PASS (4/4); Python vs R agree to 1.3e-15 |
| calibration.R | refit of the calibration model with HAC errors; tidal admittance regression | PASS (10/10); δ = 1.1558 ± 0.0004 vs 1.1563 true |

Ljung–Box on residuals is reported but not used as a pass criterion: the sensor model
intentionally contains correlated (flicker-like and random-walk) noise.

## 3. Console integration (Kotlin)

`./gradlew test` — 53 tests: unit conversions, axis/log math, contract fixtures, HTTP client,
store behaviour, headless rendering of all 13 screens, and `EngineCaptureTest`, which decodes
payloads captured from the **real** engine (`tools/capture_api_fixtures.py`). The console was
also run under Xvfb against `gravitas serve` and displayed live engine values (STABLE).

## 4. Defects found by validation and fixed

| Defect | Found by | Fix |
|---|---|---|
| Prism formula used `atan2`, giving π jumps (1000× error above the prism) | point-mass limit | principal-value arctan |
| Fringe order at start-up ambiguous when initial phase > π → exactly one-fringe (3.06 mGal) errors at some stations and under vibration | latitude experiment | coarse-sensor fringe-order initialisation; equilibrium start on block mean |
| Instrument start-up transient polluted the estimator | static-run error analysis | equilibrium initialisation + estimator settling window |
| Broadband vibration extending to 0.05 Hz dominated the band (unrealistic floor) | uncertainty analysis | cultural band 0.5–20 Hz |
| Calibration covariance far too optimistic (12σ drift error) | campaign normalised errors | AR(1) inflation + exact station reference-error propagation |
| Tide interpolation and random-walk accumulation not chunk-invariant (1-ulp differences) | reproducibility test | global grid alignment, sequential accumulation |
| Free-air closed formula validity overstated in docstring | series comparison | corrected to ≈ 0.3 µGal / 100 m |

## 5. What is *not* validated

No comparison with a real instrument or real survey data has been made. Performance numbers
in these documents are properties of the synthetic configuration, demonstrated in simulation,
and must not be read as laboratory accuracy.
