# GRAVITAS — Measurement Model

GRAVITAS distinguishes **true gravitational acceleration** from **what the instrument
observes**. The raw measurement is built, per sample, from separately computed and
recorded terms:

```
TRUE GRAVITY        g_true = |g_earth(position)| + δg_tide(t) + δg_anomaly(position)
                             (Newtonian + centrifugal, oblate, altitude, latitude)
PLATFORM            − δg_Eötvös(v) + a_vib,U(t)
CROSS-AXIS          + (θ_E + c_E) a_vib,E + (θ_N + c_N) a_vib,N − g_true θ²/2
──────────────────  = a_axis  (specific force along the sensitive axis)
SCALE FACTOR        g_ref + S(T)·(a_axis − g_ref)
BIAS                + b₀
TEMPERATURE         + c_T (T_i − T_ref)
DRIFT               + r t + q t² + A(1 − e^{−t/τ}) + w(t)     (w: random walk)
LOW-FREQ NOISE      + n_GM(t)    (Gauss–Markov ensemble ≈ flicker)
WHITE NOISE         + n_w(t)     (ASD 3 µGal/√Hz, internal rate)
──────────────────  = a_in  → proof-mass dynamics → readout noise → ADC QUANTISATION
                    = RAW MEASUREMENT  g_raw = g_ref + ω₀² x̂ (− F̂_fb/m)
```

Each term is a chain channel (`truth.*`, `environment.*`, `sensor.*`, `instrument.*`, `adc.*`).

## Sensor error models (`sensors/`)

| Model | Equation | Default | Notes |
|---|---|---|---|
| Bias | b(t) = b₀ + c_T(T − T_ref) | 150 µGal, 50 µGal/K | equivalent input acceleration |
| Scale factor | y = S x, S = 1 + ε + α(T − T_ref) | ε = 200 ppm | acts on deviation from g_ref (relative instrument) |
| Drift | r t + q t² + A(1−e^{−t/τ}) + random walk | 2e-12 m/s³ (≈ 17 µGal/day), RW 2e-11 m/s²/√s | chunk-invariant accumulation |
| White noise | σ = n √(f/2) | n = 3e-8 m/s²/√Hz | ADEV slope −½ |
| Low-frequency noise | K log-spaced Gauss–Markov, τ ∈ [10, 10⁴] s | σ = 5e-9 m/s² | flat ADEV ("bias instability") |
| Quantisation | ADC LSB | 20-bit optical, 24-bit DAC | |
| Temperature | bias(T) = coefficient × (T − T_reference) | | uses *instrument* temperature |
| Vibration | platform acceleration added on the axis | | attenuated by the mechanics above f₀ |
| Cross-axis | (θ + c)·a_horizontal, −gθ²/2 | c = 1e-4, θ = 5 µrad | |

**Why equivalent-input terms?** Physically, bias and drift are spring pre-tension changes and
creep, and the scale factor is the true/nominal spring-constant ratio. Representing them as
explicit equivalent input accelerations keeps every error independently switchable and
inspectable while the proof-mass/readout/ADC chain stays physical.

## Processing chain

```
RAW → FILTER → CALIBRATION → CORRECTION → GRAVITY ESTIMATOR → UNCERTAINTY → FINAL
```

* **Filter** (`estimation/filtering.py`) operates on Δg = g − g_ref to keep float64 well
  conditioned; stateful causal moving average, first-order low-pass, n-th order Butterworth
  (SOS) or a constant-velocity Kalman filter. Each reports its noise-equivalent bandwidth
  ENBW = (f_s/2)Σh²/(Σh)².
* **Calibration** Δcal = (Δfilt − b̂₀ − ĉ_T(T_m − T_ref) − r̂(t − t₀))/Ŝ using the *measured*
  temperature (sensor bias and noise included).
* **Correction** − tide model (δ = 1.16, operator's model) + Eötvös (known velocity).
  The correction model is independent of the physics switches: switching the Moon off in
  the truth leaves the operator's lunar correction in place, exactly as it would in reality.
* **Estimator** Kalman/RLS with state [g₀, drift, tidal admittance] on samples spaced at
  ~1/(2·ENBW) (approximately independent); see CALIBRATION.md and UNCERTAINTY.md.

## Status

Each chunk is classified STABLE / SETTLING / SATURATED (stops or ADC clipping) / UNLOCKED
(fringe loss), with reasons, and high vibration is reported.

## Units and precision

Internal: SI float64, deviation-domain processing. Presentation conversions are exact powers
of ten (`constants/units.py`); rounding happens only in `format_gravity` and in the console.
