# GRAVITAS — Earth Model

## 1. Reference ellipsoid (`earth/ellipsoid.py`)

* **MODEL** WGS84 rotating level ellipsoid: a = 6 378 137 m, 1/f = 298.257223563,
  GM = 3.986004418e14 m³/s², ω = 7.292115e-5 rad/s. A non-rotating sphere with the
  same GM and the IUGG mean radius R₁ = 6 371 008.7714 m is the spherical reference.
* **EQUATIONS** b = a(1−f), e² = f(2−f), e′² = e²/(1−e²), E = √(a²−b²), m = ω²a²b/GM.
  Zonal coefficients (Heiskanen & Moritz 1967, eq. 2-92):
  J₂ = e²/3 (1 − 2me′/(15q₀)), J₂ₙ = (−1)ⁿ⁺¹ 3e²ⁿ/((2n+1)(2n+3)) (1 − n + 5nJ₂/e²),
  q₀ = ½[(1 + 3/e′²) arctan e′ − 3/e′].
  Normal gravity at equator/pole (H&M 2-141) from (a, b, GM, m, e′, q₀, q₀′).
* **EXPECTED VALIDITY** Reproduces the NIMA TR8350.2 derived constants γ_e, γ_p, k, m, J₂, b
  to their published precision (tests/test_gravity.py::TestEllipsoid).

## 2. Coordinates (`earth/coordinates.py`)

* Internal units: radians and metres. Public constructors name their units
  (`from_degrees`, `from_radians`, `latitude_deg`, `height_m`).
* Geodetic → ECEF: x = (N+h)cosφcosλ, y = (N+h)cosφsinλ, z = (N(1−e²)+h)sinφ,
  N = a/√(1−e²sin²φ).
* ECEF → geodetic: Bowring initial value + fixed-point iteration to 1e-14 rad, height
  from h = p cosφ + z sinφ − a²/N (stable at all latitudes). Non-convergence raises.
* ENU: rotation rows (E, N, U); Up is the ellipsoidal normal (the plumb line differs by
  the deflection of the vertical, reported by `GravityBreakdown.deflection_from_normal_rad`).
* **Validation** Invalid input (NaN/∞, |φ| > 90°, λ ∉ [−180°, 180°], h ∉ [−12 km, 5e7 m])
  raises `CoordinateError`; nothing is wrapped silently (`normalize_longitude_deg` is explicit).
  Round trips: < 1e-12 rad and < 1e-6 m over random points and from −11 km to GEO.

## 3. Gravity models (`earth/gravity.py`, `earth/normal_gravity.py`)

| Model | Equation | Validity |
|---|---|---|
| Spherical, non-rotating | g = GM/(R₁+h)² | ignores the 5.186 Gal equator–pole difference; 0.65 Gal too high at 53° N |
| Point mass at true geocentric radius | g = GM/r² | no flattening, no rotation |
| Oblate, non-rotating | zonal series J₂…J₁₀ | — |
| **Rotating oblate (default)** | zonal series + ω²(x,y,0) | = Somigliana at h = 0 to < 1e-12 m/s² |
| Somigliana (closed form, h = 0) | γ = γ_e(1 + k sin²φ)/√(1 − e² sin²φ) | exact on the ellipsoid |
| Free-air series (closed form) | γ_h = γ[1 − 2/a(1+f+m−2f sin²φ)h + 3h²/a²] | first order in (f, m): ≈ 0.3 µGal per 100 m error vs the series model |

`EarthGravityModel.evaluate()` exposes the **Newtonian**, **centrifugal** and
**effective** vectors (ENU) and magnitudes separately; `components()` is the
vectorised version used by the engine. Numerical vertical and horizontal gradients
are provided for the uncertainty budget.

### Physics switches (they modify the simulation)
`earth_gravity` (off ⇒ no Earth field — the meter saturates, as a real one would),
`earth_oblateness` (off ⇒ point mass at the true radius), `earth_rotation` (off ⇒ no
centrifugal term, no rotational Eötvös term), `altitude` (off ⇒ h = 0),
`latitude` (off ⇒ evaluated at a reference latitude, default 45°).

## 4. Earth rotation (`earth/rotation.py`)

* **MODEL** GMST (IAU 1982, Meeus eq. 12.4) rotates mean-equinox-of-date vectors into ECEF.
* **ASSUMPTIONS** UT1 ≈ UTC; nutation (≤ 17″), polar motion (≤ 0.5″) ignored.
* **EXPECTED VALIDITY** Meeus example 12.a reproduced to 1e-5°; sidereal rate = ω to 1e-6.

## 5. Tides (`earth/tides.py`)

* **MODEL** Reduced-order ephemerides: Sun (Meeus ch. 25), Moon (Meeus ch. 47: 19 largest
  longitude/distance terms, 13 latitude terms, additive A1–A3 terms). Exact differential
  tidal acceleration projected on the plumb line; elastic Earth by the degree-2
  gravimetric factor δ (truth: 1.1563; correction model: 1.16).
* **ASSUMPTIONS** TT ≈ UTC (69 s ⇒ 0.01° lunar position). Frequency-independent δ.
  No ocean loading, atmospheric loading or pole tide.
* **LIMITATIONS** Not a tidal-catalogue (ETERNA/Tamura) prediction; ~0.3 % amplitude level.
* **EXPECTED VALIDITY** Meeus examples: Moon λ within 0.0034°, distance within 29 km;
  Sun λ within 1e-5°. Lunar ptp 60–200 µGal, solar 20–80 µGal, M₂ dominant at the equator,
  O₁/K₁ present at 53° N (all tested). The engine evaluates tides on a 1 s global grid with
  linear interpolation (interpolation error < 1e-12 m/s²).
* **Exposed separately** lunar, solar, combined (`tide.lunar_mps2`, `tide.solar_mps2`,
  `tide.combined_mps2`). The tidal signal (±~1 µm/s²) is ~1e-7 of the baseline and is
  never amplified.

## 6. Geoid (`earth/geoid.py`)

* **MODEL** h = H + N. Default `ConstantGeoid(N = 0)`; `AnomalyGeoid` adds Bruns'
  N = T/γ from a synthetic anomaly field. `location.altitude_m` is orthometric; the
  engine uses h = H + N with `earth.geoid_undulation_m` (recorded in the manifest).
* **LIMITATIONS** No real geoid model bundled (EGM2008 undulations reach ±100 m;
  1 m ≈ 0.31 mGal of free-air gravity).
