# GRAVITAS — Physics

Conventions: SI units throughout; accelerations in m/s² (1 µGal = 1e-8 m/s²).
Potentials are positive with attraction **a = +∇V**. Gravity changes δg are
positive when the instrument sees *more* gravity (along the plumb line, downward).

Each model below is documented as MODEL · ASSUMPTIONS · EQUATIONS · LIMITATIONS ·
EXPECTED VALIDITY. Earth-specific models are in [EARTH_MODEL.md](EARTH_MODEL.md).

---

## 1. Newtonian point mass (`physics/acceleration.py`, `physics/potential.py`)

* **MODEL** A point (or spherically symmetric) mass M.
* **EQUATIONS** V = GM/r, a = −GM r̂ / r².
* **ASSUMPTIONS** Spherical symmetry; static.
* **LIMITATIONS** Singular at r = 0 (raises `ZeroDivisionError`).
* **EXPECTED VALIDITY** Exact for spherically symmetric bodies outside their surface.
  Verified: g·r² = GM to 1e-15 relative; a = ∇V numerically.

## 2. Zonal-harmonic (level-ellipsoid) attraction

* **MODEL** External potential of the WGS84 level ellipsoid,
  V = GM/r [1 − Σₙ J₂ₙ (a/r)²ⁿ P₂ₙ(sin φ_c)], n = 1…5.
* **EQUATIONS** Gradient with u = sin φ_c:
  ∂V/∂r = −GM/r² + GM Σ (n+1) Jₙ aⁿ r^{−(n+2)} Pₙ(u); ∂V/∂u = −GM Σ Jₙ aⁿ r^{−(n+1)} P′ₙ(u);
  a = ∂V/∂r r̂ + ∂V/∂u (ẑ − u r̂)/r. Legendre derivatives by the non-singular
  recurrence P′ₙ₊₁ = P′ₙ₋₁ + (2n+1)Pₙ.
* **ASSUMPTIONS** Level ellipsoid (normal field only).
* **LIMITATIONS** Valid outside the sphere of radius E = 521.9 km (enforced). No
  tesseral harmonics (real-Earth anomalies of ±100s mGal are absent unless modelled synthetically).
* **EXPECTED VALIDITY** With rotation added it reproduces Somigliana's closed formula on
  the ellipsoid to < 1e-12 m/s² (tested at 1e-9) and the plumb line is normal to the
  ellipsoid to < 1e-9 rad.

## 3. Centrifugal acceleration and Eötvös effect (`physics/centrifugal.py`)

* **MODEL** Uniform rotation ω about the ECEF Z axis.
* **EQUATIONS** a_c = ω²(x, y, 0); Φ_c = ½ω²(x²+y²); Coriolis −2ω×v;
  Eötvös δg_E = 2ω v_E cos φ + (v_E² + v_N²)/R (positive ⇒ reading reduced).
* **ASSUMPTIONS** No polar motion or length-of-day variation (< 0.1 µGal).
* **LIMITATIONS** Eötvös formula is the standard first-order form (Harlan 1968).
* **EXPECTED VALIDITY** Exact for the stated rotation; ω²a = 0.03392 m/s² at the equator (tested).

## 4. Tide-raising acceleration (`physics/tidal.py`)

* **MODEL** Exact Newtonian differential acceleration from a point-mass body.
* **EQUATIONS** a = GM_B [(R − r)/|R − r|³ − R/|R|³]; degree-2 reference:
  a_up ≈ GM_B r/d³ (3cos²ψ − 1).
* **ASSUMPTIONS** Bodies are point masses.
* **LIMITATIONS** Rigid-Earth quantity; elastic response applied in `earth/tides.py`.
* **EXPECTED VALIDITY** Exact differential (all degrees); agrees with degree 2 to the size
  of degree 3 (≈ r/d ≈ 1.7 %, tested < 3 %). Moon at zenith ⇒ −110 µGal (tested).

## 5. Synthetic anomaly bodies (`physics/anomalies.py`) — SYNTHETIC GEOPHYSICAL MODEL

All bodies are density *contrasts* in a local ENU frame (Up positive; buried bodies have
negative Up). They are clearly labelled synthetic and never represent real geology.

| Body | EQUATIONS | ASSUMPTIONS / LIMITATIONS | VALIDATION |
|---|---|---|---|
| PointMass | a = −GM d/|d|³ | point; singular at source (rejected) | peak GM/z², half-width 0.766 z |
| Sphere | outside: point mass M = 4/3πR³Δρ; inside: a = −GM d/R³ | uniform density | equals point mass outside; linear inside |
| Slab (prism) | Nagy (1966)/Plouff: a_w = GΔρ Σ μ_ijk [u ln(v+r) + v ln(u+r) − w arctan(uv/(wr))] | axis-aligned prism; principal-value arctan; stable logs | far field = point mass (2e-3); wide slab = Bouguer plate 2πGΔρt (1e-3) |
| Layer | infinite: 2πGΔρt; semi-infinite: 2GΔρt(π/2 + atan(s/z)) | thin-sheet approximation, error O((t/z)²); horizontal components undefined for an unbounded sheet (vertical only) | half value at the edge; full value far over the sheet |
| Gaussian | ρ = Δρ₀ e^{−d²/2σ²}; M(d) = M[erf(d/√2σ) − √(2/π)(d/σ)e^{−d²/2σ²}], M = Δρ₀(2π)^{3/2}σ³ | spherically symmetric | total mass vs numerical volume integral (1e-6); far field = point mass |

Accelerations of the point mass, sphere and Gaussian are verified to be the gradient of
their closed-form potentials. Bruns' formula N = T/γ converts the anomalous potential
to a geoid perturbation (`earth/geoid.py`).

## 6. Terrain (`earth/terrain.py`)

* **MODEL** Bouguer plate 2πGρH; gridded synthetic terrain as a sum of vertical prisms.
* **ASSUMPTIONS** Planar geometry; uniform ρ = 2670 kg/m³.
* **LIMITATIONS** Valid within ≈ 20 km (Earth curvature neglected). No real DEM bundled.
* **EXPECTED VALIDITY** Bouguer gradient 1.1197e-6 m/s²/m (= 0.11197 mGal/m) vs textbook 0.11195 mGal/m.

## 7. Thermal environment (`instrument/thermal.py`)

* **MODEL** Ambient T_a = T₀ + A sin(2πt/86400 + φ) + random walk; thermostatted enclosure
  T_eff = T_set + β(T_a − T_set); first-order lag dT_i/dt = (T_eff − T_i)/τ (exact
  discretisation); sensor T_m = T_i + b_T + noise; optional set-point schedule (thermal chamber).
* **LIMITATIONS** Single thermal node; no gradients.

## 8. Platform vibration (`sensors/vibration.py`)

* **MODEL** Spectral lines (microseism 0.15–0.17 Hz, cultural 8 Hz) plus broadband Gaussian
  noise band-passed 0.5–20 Hz (4th-order Butterworth, stateful).
* **LIMITATIONS** Stationary; amplitudes are illustrative, not a site survey. A zero-mean
  vibration does not bias a linear instrument; rectification paths (stops, ADC clipping,
  fringe loss, tilt × horizontal) are modelled explicitly.

## 9. Constants

All constants are in `constants/physical.py` with citations: CODATA 2018 (G),
NIMA TR8350.2 (WGS84), IERS Conventions 2010 (GM of Moon and Sun, Love numbers),
IAU 2012 (au). The degree-2 gravimetric factor is δ = 1 + h₂ − 3/2 k₂ = 1.1563.
