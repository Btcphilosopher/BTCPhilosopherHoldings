# GRAVITAS — Uncertainty

## 1. Measurand and output

The measurand is the **static gravity at the nominal station position** (tides removed).
Every final measurement is returned as

```python
GravityEstimate(value=..., standard_uncertainty=..., expanded_uncertainty=..., coverage_factor=2.0,
                contributions=[Contribution(name, standard_uncertainty_mps2, type, sensitivity,
                                            input_uncertainty, input_unit, description), ...])
```

u_c² = Σ (cᵢ u(xᵢ))² (first-order GUM, uncorrelated inputs); U = k u_c, k = 2.

## 2. Contributions (`uncertainty/budget.py`)

| Name | Type | Evaluation | Source of the input uncertainty |
|---|---|---|---|
| sensor_noise | A | Allan deviation of the corrected record, decimated to ~independent samples; white-noise extrapolation over the longest decade of τ when the long-τ slope < −0.35, otherwise RMS σ_A of that decade (no further averaging assumed) | the record itself |
| bias | B | u(b̂₀) | calibration certificate / fit |
| scale_factor | B | u(Ŝ)·|Δg|/Ŝ (Δg = span from g_ref) | calibration |
| temperature | B | √[(u(ĉ_T)|T̄_m − T_ref|)² + (ĉ_T u(T))²] | calibration + thermometer spec |
| position | B | |∂g/∂n|·u_h (Earth model + anomaly gradient, numerical) | `uncertainty.u_horizontal_position_m` |
| altitude | B | |∂g/∂h|·u_h (free-air + anomaly vertical gradient) | `uncertainty.u_altitude_m` |
| earth_model | B | stated model uncertainty ⊕ |closed-form free-air − zonal series| | config + computed discrepancy |
| tidal_correction | B | |mean applied tide|·√(u_δ,rel² + u_eph,rel²) | config (1 %, 0.3 %) |
| vibration | A | standard error of the mean of the filtered auxiliary platform record (batch means) | record |
| calibration | B | u_ref ⊕ u(r̂)·|t̄ − t₀| | calibration |

Default static station (900 s): u_c ≈ 3.7 µGal, dominated by the bias certificate
(3 µGal), altitude (0.5 cm × 3.09 µGal/cm = 1.5 µGal), calibration (1 µGal) and tidal
correction (≈ 1 µGal). The sensor-noise term is ≈ 0.1–0.3 µGal. These numbers describe the
**synthetic** instrument configuration; they are not a claim about any real instrument.

## 3. Propagation (`uncertainty/propagation.py`)

* Linear: u_y² = J Σ Jᵀ with a central-difference Jacobian.
* Monte Carlo (GUM-S1): Cholesky draws, mean, std, shortest coverage interval.
Both agree to 3 % for a mildly non-linear product (tested).

## 4. Monte Carlo engine (`simulation/monte_carlo.py`, `gravitas monte-carlo`)

Each trial runs the **full chain** with the *truth* drawn from the distributions the
budget claims — new noise/vibration/thermal seed; bias ~ b̂ + N(0, u_b²) + N(0, u_ref²);
S ~ Ŝ(1 + N(0, u_S²)); c_T ~ ĉ_T + N(0, u_cT²); thermometer bias ~ N(0, u_T²);
drift ~ r̂ + N(0, u_r²); true position offset ~ N(0, u_h²) (E, N) and N(0, u_alt²) (Up);
δ_true ~ δ_model(1 + N(0, u_δ² + u_eph²)) — while processing uses the nominal calibration,
tide model and position. Errors e_j = ĝ_j − g_static(nominal) are compared with the
analytical u_j restricted to randomised terms (`earth_model` is not randomised).

Statistics (`uncertainty/monte_carlo.py`): mean (bias), sd, RMSE, t-CI of the bias,
χ²-CI of the sd, empirical 2.5–97.5 % interval, coverage P(|e| ≤ k u), ratio sd/u_rms,
D'Agostino normality.

### Demonstrated (60 trials × 300 s, seed 12345)

| Quantity | Value |
|---|---|
| analytical u (RMS) | 3.73 µGal |
| Monte Carlo sd | 3.57 µGal (95 % CI 3.03–4.35) |
| ratio MC / analytical | 0.956 |
| mean error | −0.25 µGal (CI includes 0) |
| coverage (k = 2) | 95.0 % |

The R layer independently confirms: χ² test of sd = u (p = 0.67), binomial coverage test,
bootstrap CIs, Shapiro–Wilk (p = 0.22). The pytest slow test (80 trials) requires
0.7 < ratio < 1.3 and coverage ≥ 85 %.

## 5. Limitations

* Correlations between inputs are neglected in the budget (the joint-calibration covariance is
  available for a full treatment).
* The noise term assumes the Allan deviation is representative; for strongly non-stationary
  records it is conservative only in the non-white branch.
* Model-shared systematics (e.g. ephemeris errors common to truth and correction) are
  invisible to the Monte Carlo by construction and are carried as Type B terms.
