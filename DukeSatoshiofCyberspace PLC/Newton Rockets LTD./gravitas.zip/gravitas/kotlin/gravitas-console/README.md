# GRAVITAS Engineering Console (Kotlin · Compose for Desktop)

Desktop engineering console for **GRAVITAS**, the precision Earth-gravity measurement digital
twin. The console is a pure *observer/controller* of the Python simulation engine: it reads
everything over the engine's HTTP/JSON API (`docs/API.md`, v1) and performs **no physics**.
Its only computations are presentation: unit conversion (m/s² → Gal / mGal / µGal), number
formatting, axis scaling, plotting, map projection of engine-supplied coordinates, binning of
engine-supplied Monte Carlo errors into a histogram, and subtracting a stated reference
(the mean of the TRUE series) to plot deviations.

When the engine is unreachable the console shows **NO ENGINE DATA** and every value is `—`.
All engine data is discarded on disconnect, so no stale or invented number is ever displayed.

## Running

Start the engine first (from the repository root):

```bash
gravitas serve --host 127.0.0.1 --port 8765
```

Then run the console:

```bash
cd kotlin/gravitas-console
./gradlew run                                             # engine at http://127.0.0.1:8765
./gradlew run --args="--engine http://127.0.0.1:8765"     # explicit engine URL
GRAVITAS_ENGINE=http://10.0.0.5:8765 ./gradlew run        # via environment variable
```

`--engine` takes the engine root; `/api/v1` is appended automatically (a URL that already ends
in `/api/v1` is accepted too). Precedence: `--engine` > `GRAVITAS_ENGINE` > default
`http://127.0.0.1:8765`. `--help` prints usage.

Window title: **GRAVITAS — Engineering Console**. Main class: `org.gravitas.console.MainKt`.

Native installers (optional): `./gradlew packageDeb` (or `packageMsi` / `packageDmg` on those
platforms).

## Building and testing

```bash
./gradlew build      # compile + all tests (unit, JSON contract, HTTP client, store, headless render)
./gradlew test
```

The headless render test (`RenderScreensTest`) draws every screen from the contract fixtures
with Skia via `ImageComposeScene` (no window system required) and writes PNGs to
`build/screenshots/` for visual review.

## Screens

Navigation sidebar: OVERVIEW, GRAVITY, INSTRUMENT, SIGNAL, EARTH, TIDES, ANOMALIES,
CALIBRATION, UNCERTAINTY, ALLAN, EXPERIMENTS, MAP, TELEMETRY. The top bar shows engine URL,
connection state, simulated time, speed, run state, engine software version, the gravity-unit
selector (m/s², Gal, mGal, µGal — default µGal) and a toggle for the **Physics Inspector**
drawer, which is available from every screen (it is also embedded on GRAVITY).

| Screen | Endpoints | Content |
|---|---|---|
| OVERVIEW | `/overview`, `/series` | local / raw / corrected gravity, bias, tide, estimate, temperature °C, vibration µm/s², standard & expanded uncertainty with k, status + reasons, location, sim time, recent-signal plot |
| GRAVITY | `/overview`, `/earth`, `/physics` | pipeline breakdown, Earth-model breakdown with ENU vectors, physics switches (POST `/physics`) |
| INSTRUMENT | `/instrument`, `/control` | proof mass state, forces, mechanical parameters, optical readout, ADC, thermal/noise, history plots, Canvas schematic annotated with live values, EQUILIBRIUM/FEEDBACK mode switch (`set_mode`) |
| SIGNAL | `/series` | true, raw, filtered, calibrated and final estimate (±1σ band) as deviations from the stated reference `g_ref` (mean of TRUE in the window); windows 1 s, 10 s, 1 min, 10 min, 1 h, 24 h; tide, bias, temperature, vibration |
| EARTH | `/earth`, `/control` | lat/lon/alt query, values, latitude profile (effective / no-rotation / spherical), centrifugal-up profile, altitude profile; "move instrument here" (`set_location`) |
| TIDES | `/tides` | lunar, solar, combined; spans 24 / 48 / 168 / 720 h |
| ANOMALIES | `/anomalies`, `/anomalies/survey` | **SYNTHETIC GEOPHYSICAL MODEL** banner, bodies table, profile, plan-view heat map with colour scale, survey run with measured ± u vs true overlay and RMS error |
| CALIBRATION | `/calibration`, `/calibration/run` | injected vs estimated ± uncertainty, residual RMS before/after, true vs uncalibrated vs calibrated plots |
| UNCERTAINTY | `/uncertainty`, `/uncertainty/monte-carlo` | budget table, contribution bars, combined/expanded/k, Monte Carlo results with error histogram and CI95 |
| ALLAN | `/allan` | log–log ADEV with confidence band, bias-instability marker, noise identification and slope regions |
| EXPERIMENTS | `/experiments`, `/experiments/{name}` | list, duration / sample-rate fields, run, summary table (units derived from key suffixes), curves |
| MAP | `/map` | equirectangular (plate carrée) graticule map with shaded `gravity_grid`, instrument marker and survey path (Region / World extent); orthographic wire-frame graticule "Earth view" centred on the instrument (no coastlines are drawn); local `anomaly_grid` heat map with survey path |
| TELEMETRY | `/telemetry`, `/control`, `/config` | recent frames table (units in column headers), pause / resume / reset(seed) / speed, reproducibility manifest flattened to key paths |

## Polling

* Fast loop, 4 Hz: `/health`, `/overview`, `/series` (OVERVIEW and SIGNAL; ≤ 0.5 Hz for ≥ 1 h
  windows), `/instrument` (INSTRUMENT only).
* Slow loop, 1 Hz tick: `/physics` every 2 s; `/telemetry` 1 s; `/allan`, `/uncertainty`, `/map`
  5 s; `/tides`, `/anomalies`, `/calibration` 10 s — each only while its screen is visible;
  `/earth`, `/experiments`, `/config` on first visit / on demand.
* POST operations (survey, calibration, Monte Carlo, experiments, control, physics) run in
  their own coroutines; their buttons are disabled while in flight. A poll that times out while
  a long run is in flight is reported as "engine busy" rather than as a disconnect.

## Code layout

```
src/main/kotlin/org/gravitas/console/
  Main.kt                     entry point, --engine / GRAVITAS_ENGINE, window
  api/Dto.kt                  @Serializable DTOs mirroring API.md field names (all nullable)
  api/GravitasClient.kt       GravitasApi interface + java.net.http client, JSON config
  state/ConsoleStore.kt       observable state, polling, actions, disconnect handling
  units/GravityUnit.kt        GravityUnit (MPS2, GAL, MGAL, UGAL) + Fmt formatting helpers
  ui/App.kt                   top bar, navigation sidebar, inspector drawer
  ui/theme/Theme.kt           palette (white/graphite/navy/steel/muted blue/amber/red), type
  ui/chart/AxisMath.kt        autoscaling, nice ticks, log-axis math, tick labels (pure)
  ui/chart/Charts.kt          LineChart (multi-series, bands, markers, log-log), HeatMap, Histogram
  ui/components/Components.kt Panel, Readout, KeyValue, StatusBadge, DataTable, Segmented, ...
  ui/screens/*.kt             the thirteen screens
src/test/kotlin/...           UnitsTest, AxisMathTest, JsonParsingTest, ClientTest (in-process
                              HTTP server), StoreTest, RenderScreensTest (headless PNGs)
src/test/resources/fixtures/  JSON payloads mirroring every endpoint in API.md
```

## API contract interpretation

The console implements `docs/API.md` field-for-field. Where the contract leaves room, it reads:

* **Grids** (`/anomalies grid.anomaly_mps2`, `/map gravity_grid.g_mps2`, `/map anomaly_grid.anomaly_mps2`)
  are row-major with rows along the second axis listed: `anomaly_mps2[i][j]` ↔ `north_m[i]`,
  `east_m[j]`; `g_mps2[i][j]` ↔ `lat_deg[i]`, `lon_deg[j]`. A grid sent transposed is detected by
  shape and accepted; an inconsistent shape is shown as no data.
* `GET /calibration` may return JSON `null` (no report yet); this is shown as such, not as zeros.
* `POST /calibration/run` and `POST /experiments/{name}` are sent `{}` when no seed / no
  parameters are entered (bodies are documented as optional).
* `POST /physics` sends only the changed switch (`{"switches": {"moon": false}}`) and uses the
  response as the new switch document (falling back to `GET /physics` if it is empty).
* Integer quantities (ADC bits/codes, `n_samples`, `trials`, `adc_code`) are accepted as either
  JSON integers or floats.
* `/config` is free-form; it is displayed as flattened key paths.
* Experiment `summary` keys carry units in their suffix (`_mps2`, `_s`, `_m`, ...); `_mps2`
  values and curves with `y_unit` `m/s^2` are converted to the selected gravity unit.
* Unknown fields are ignored and missing/`null` fields render as `—`, so additive contract
  changes do not break the console.

## Build environment

* Gradle 8.14.3 (wrapper included), JDK 21 toolchain.
* Kotlin 2.0.21 (`kotlin("jvm")`, `plugin.serialization`, `org.jetbrains.kotlin.plugin.compose`).
* Compose Multiplatform Gradle plugin `org.jetbrains.compose` 1.6.11; Compose **libraries
  pinned to 1.5.12** (skiko 0.7.85.4). Reason: every Compose ≥ 1.6 desktop artifact depends on
  androidx artifacts (`androidx.collection`, `androidx.annotation`, and from 1.6.10
  `androidx.lifecycle`) that are published only on Google Maven (dl.google.com), which is not
  reachable from the environment this was built in. Compose 1.5.12 resolves entirely from Maven
  Central. With Google Maven available, set `composeLibsVersion = null` in `build.gradle.kts`
  and add `google()` to the repositories to use the plugin's own Compose version.
* kotlinx-serialization-json 1.7.3, kotlinx-coroutines-swing 1.8.0, JUnit 5.10.3 + kotlin-test.
* HTTP: `java.net.http.HttpClient` (HTTP/1.1; no proxy for loopback engines).
