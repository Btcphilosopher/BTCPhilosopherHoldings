import org.jetbrains.compose.desktop.application.dsl.TargetFormat

plugins {
    kotlin("jvm") version "2.0.21"
    kotlin("plugin.serialization") version "2.0.21"
    id("org.jetbrains.kotlin.plugin.compose") version "2.0.21"
    id("org.jetbrains.compose") version "1.6.11"
}

group = "org.gravitas"
version = "1.0.0"

kotlin {
    jvmToolchain(21)
}

// Dependency note (see README "Build environment"):
// Compose Multiplatform >= 1.6.0 desktop artifacts depend on androidx.collection /
// androidx.annotation (and >= 1.6.10 on androidx.lifecycle) published ONLY on Google Maven
// (dl.google.com), which is not reachable from the build environment. Compose 1.5.12 desktop
// resolves entirely from Maven Central, so the Compose *libraries* are pinned to it, while the
// 1.6.11 Compose Gradle plugin is used because it supports Kotlin 2.0 with the
// org.jetbrains.kotlin.plugin.compose compiler plugin. Where Google Maven is reachable, the
// pin can be removed (set composeLibsVersion = null) to use the plugin's own version.
val composeLibsVersion: String? = "1.5.12"
configurations.all {
    resolutionStrategy.eachDependency {
        if (composeLibsVersion != null && requested.group.startsWith("org.jetbrains.compose") &&
            requested.group != "org.jetbrains.compose.compiler"
        ) {
            useVersion(composeLibsVersion)
            because("Compose >= 1.6 desktop requires Google-Maven-only androidx artifacts")
        }
    }
}

dependencies {
    implementation(compose.desktop.currentOs)
    implementation(compose.material)
    implementation("org.jetbrains.kotlinx:kotlinx-serialization-json:1.7.3")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-swing:1.8.0")

    testImplementation(kotlin("test"))
    testImplementation("org.junit.jupiter:junit-jupiter:5.10.3")
    testRuntimeOnly("org.junit.platform:junit-platform-launcher")
}

tasks.test {
    useJUnitPlatform()
    // Headless Skia rendering of screens to build/screenshots (see RenderScreensTest).
    systemProperty("java.awt.headless", "true")
    systemProperty("gravitas.screenshotDir", layout.buildDirectory.dir("screenshots").get().asFile.absolutePath)
    testLogging {
        events("passed", "skipped", "failed")
        showStandardStreams = false
        exceptionFormat = org.gradle.api.tasks.testing.logging.TestExceptionFormat.FULL
    }
}

compose.desktop {
    application {
        mainClass = "org.gravitas.console.MainKt"
        nativeDistributions {
            targetFormats(TargetFormat.Deb, TargetFormat.Msi, TargetFormat.Dmg)
            packageName = "gravitas-console"
            packageVersion = "1.0.0"
        }
    }
}
