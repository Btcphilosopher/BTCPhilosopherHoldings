package org.gravitas.console

import androidx.compose.ui.unit.DpSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Window
import androidx.compose.ui.window.application
import androidx.compose.ui.window.rememberWindowState
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import org.gravitas.console.api.GravitasClient
import org.gravitas.console.state.ConsoleStore
import org.gravitas.console.ui.ConsoleApp
import kotlin.system.exitProcess

const val WINDOW_TITLE = "GRAVITAS — Engineering Console"

fun main(args: Array<String>) {
    if (args.any { it == "--help" || it == "-h" }) {
        println(
            """
            GRAVITAS Engineering Console

            Usage: gravitas-console [--engine <url>]

              --engine <url>   Engine root URL (default ${GravitasClient.DEFAULT_ENGINE});
                               '/api/v1' is appended automatically.
              GRAVITAS_ENGINE  Environment variable used when --engine is not given.
            """.trimIndent(),
        )
        exitProcess(0)
    }
    val engine = GravitasClient.resolveEngine(args)
    val client = GravitasClient(engine)
    val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    val store = ConsoleStore(client, scope)
    store.start()
    application {
        Window(
            onCloseRequest = { scope.cancel(); exitApplication() },
            title = WINDOW_TITLE,
            state = rememberWindowState(size = DpSize(1600.dp, 1000.dp)),
        ) {
            ConsoleApp(store)
        }
    }
}
