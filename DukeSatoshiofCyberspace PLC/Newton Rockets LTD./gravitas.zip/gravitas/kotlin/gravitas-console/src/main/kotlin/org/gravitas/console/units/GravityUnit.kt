package org.gravitas.console.units

import java.math.BigDecimal
import java.math.RoundingMode
import java.util.Locale
import kotlin.math.abs
import kotlin.math.floor
import kotlin.math.log10
import kotlin.math.max

/**
 * Presentation units for acceleration. The engine always speaks SI (m/s²).
 *
 * 1 Gal = 1e-2 m/s², 1 mGal = 1e-5 m/s², 1 µGal = 1e-8 m/s².
 *
 * Conversions multiply/divide by [perMps2], which is an integer power of ten that is exactly
 * representable as an IEEE-754 double (1, 100, 1e5, 1e8). A single correctly-rounded
 * multiplication is therefore the most exact conversion available in binary floating point
 * (dividing by 1e-8, which is *not* exactly representable, would add a second rounding).
 */
enum class GravityUnit(
    val symbol: String,
    /** Number of this unit in one m/s². */
    val perMps2: Double,
    /** Decimals used for absolute gravity values (resolution ≈ 0.1 µGal). */
    val absoluteDecimals: Int,
) {
    MPS2("m/s²", 1.0, 9),
    GAL("Gal", 1.0e2, 7),
    MGAL("mGal", 1.0e5, 4),
    UGAL("µGal", 1.0e8, 1);

    fun fromMps2(valueMps2: Double): Double = valueMps2 * perMps2
    fun toMps2(value: Double): Double = value / perMps2

    companion object {
        val DEFAULT = UGAL
    }
}

/** Number formatting helpers. All use [Locale.ROOT]; none of them ever drop the unit. */
object Fmt {
    const val DASH = "—"

    fun fixed(v: Double?, decimals: Int): String {
        if (v == null || !v.isFinite()) return DASH
        val d = decimals.coerceIn(0, 15)
        // BigDecimal half-even avoids binary artefacts such as 0.30000000000000004 → "0.3".
        val s = BigDecimal(v.toString()).setScale(d, RoundingMode.HALF_EVEN).toPlainString()
        return if (s.startsWith("-") && s.trim('-', '0', '.').isEmpty()) s.substring(1) else s
    }

    /** Scientific notation with [sig] significant digits, e.g. `5.000e-8`. */
    fun sci(v: Double?, sig: Int = 4): String {
        if (v == null || !v.isFinite()) return DASH
        if (v == 0.0) return "0"
        return String.format(Locale.ROOT, "%.${(sig - 1).coerceAtLeast(0)}e", v)
            .replace(Regex("e([+-])0*(\\d)"), "e$1$2")
            .replace("e+", "e")
    }

    /**
     * Value with [sig] significant digits; switches to scientific notation outside
     * 1e-3 ≤ |v| < 1e7 so that small engineering values remain readable.
     */
    fun sig(v: Double?, sig: Int = 4): String {
        if (v == null || !v.isFinite()) return DASH
        if (v == 0.0) return fixed(0.0, (sig - 1).coerceAtLeast(0))
        val a = abs(v)
        if (a < 1e-3 || a >= 1e7) return sci(v, sig)
        val mag = floor(log10(a)).toInt()
        return fixed(v, max(0, sig - 1 - mag))
    }

    fun integer(v: Double?): String =
        if (v == null || !v.isFinite()) DASH else BigDecimal(v.toString()).setScale(0, RoundingMode.HALF_EVEN).toPlainString()

    /** Absolute gravity value in [unit] at the unit's standard resolution. */
    fun gravity(valueMps2: Double?, unit: GravityUnit): String =
        if (valueMps2 == null) DASH else fixed(unit.fromMps2(valueMps2), unit.absoluteDecimals)

    /**
     * A small acceleration (bias, tide, uncertainty, ...) in [unit]. Uses fixed decimals that
     * resolve 0.01 µGal when the magnitude allows, otherwise significant-digit formatting.
     */
    fun small(valueMps2: Double?, unit: GravityUnit, sigDigits: Int = 4): String {
        if (valueMps2 == null || !valueMps2.isFinite()) return DASH
        val v = unit.fromMps2(valueMps2)
        val a = abs(v)
        if (a == 0.0) return fixed(0.0, smallDecimals(unit))
        // Large magnitudes (e.g. a full gravity vector component): absolute-gravity resolution.
        if (a >= 1e5) return fixed(v, unit.absoluteDecimals)
        if (a >= 1e7 || a < 1e-4) return sci(v, sigDigits)
        val mag = floor(log10(a)).toInt()
        return fixed(v, max(sigDigits - 1 - mag, 0).coerceAtMost(smallDecimals(unit) + 3))
    }

    private fun smallDecimals(unit: GravityUnit) = when (unit) {
        GravityUnit.MPS2 -> 10
        GravityUnit.GAL -> 8
        GravityUnit.MGAL -> 5
        GravityUnit.UGAL -> 2
    }

    /** `value unit` string — used where a composite string is needed (tables, tooltips). */
    fun withUnit(value: String, unit: String): String = if (value == DASH) DASH else "$value $unit"

    private val prefixes = listOf(
        1e-15 to "f", 1e-12 to "p", 1e-9 to "n", 1e-6 to "µ", 1e-3 to "m", 1.0 to "", 1e3 to "k", 1e6 to "M",
    )

    /**
     * SI-prefixed engineering value: `siPrefixed(1.2e-9, "m")` → ("1.200", "nm").
     * The unit string is always returned (never hidden), even for a missing value.
     */
    fun siPrefixed(v: Double?, unit: String, sig: Int = 4): Pair<String, String> {
        if (v == null || !v.isFinite()) return DASH to unit
        if (v == 0.0) return fixed(0.0, sig - 1) to unit
        val a = abs(v)
        val (scale, prefix) = prefixes.lastOrNull { a >= it.first * 0.9999999 } ?: prefixes.first()
        val scaled = v / scale
        val mag = floor(log10(abs(scaled))).toInt()
        return fixed(scaled, max(0, sig - 1 - mag)) to (prefix + unit)
    }

    /** Simulated time as `Dd HH:MM:SS.s`. */
    fun simTime(seconds: Double?): String {
        if (seconds == null || !seconds.isFinite()) return DASH
        val neg = seconds < 0
        val s = abs(seconds)
        val days = floor(s / 86400.0).toLong()
        var rem = s - days * 86400.0
        val h = floor(rem / 3600.0).toLong(); rem -= h * 3600.0
        val m = floor(rem / 60.0).toLong(); rem -= m * 60.0
        val sec = String.format(Locale.ROOT, "%04.1f", floor(rem * 10.0) / 10.0)
        return (if (neg) "-" else "") + String.format(Locale.ROOT, "%dd %02d:%02d:", days, h, m) + sec
    }
}
