package org.gravitas.console.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.Divider
import androidx.compose.material.Switch
import androidx.compose.material.SwitchDefaults
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.gravitas.console.units.Fmt
import org.gravitas.console.ui.theme.Palette
import org.gravitas.console.ui.theme.Type

/** Upper-cases Latin letters only, so symbols such as σ, τ, µ and uᵢ keep their meaning. */
fun caps(s: String): String = buildString(s.length) { for (c in s) append(if (c in 'a'..'z') c.uppercaseChar() else c) }

/** True for "—" and "± —" (a missing value, possibly with a ± prefix). */
fun isMissing(value: String): Boolean = value.trim().removePrefix("±").trim() == Fmt.DASH

/** White instrument panel with a small-caps title and a thin rule. */
@Composable
fun Panel(
    title: String,
    modifier: Modifier = Modifier,
    trailing: @Composable RowScope.() -> Unit = {},
    content: @Composable ColumnScope.() -> Unit,
) {
    Column(
        modifier
            .background(Palette.Panel)
            .border(1.dp, Palette.Rule)
            .padding(horizontal = 16.dp, vertical = 12.dp),
    ) {
        Row(Modifier.fillMaxWidth().heightIn(min = 22.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(caps(title), style = Type.Section, modifier = Modifier.weight(1f))
            trailing()
        }
        Divider(color = Palette.Rule, thickness = 1.dp, modifier = Modifier.padding(top = 6.dp, bottom = 10.dp))
        content()
    }
}

/**
 * Value readout: LABEL over a large monospaced value with its unit, plus optional uncertainty
 * and note lines. The unit is always shown, even when the value is "—".
 */
@Composable
fun Readout(
    label: String,
    value: String,
    unit: String,
    modifier: Modifier = Modifier,
    uncertainty: String? = null,
    note: String? = null,
    large: Boolean = true,
    valueColor: Color = Palette.Graphite,
) {
    Column(modifier.padding(vertical = 4.dp)) {
        Text(caps(label), style = Type.Label, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Spacer(Modifier.height(3.dp))
        Row(verticalAlignment = Alignment.Bottom) {
            Text(if (isMissing(value)) Fmt.DASH else value, style = (if (large) Type.ValueLarge else Type.Value).copy(color = if (isMissing(value)) Palette.SteelLight else valueColor), maxLines = 1)
            Spacer(Modifier.width(6.dp))
            Text(unit, style = Type.Unit, modifier = Modifier.padding(bottom = if (large) 4.dp else 2.dp), maxLines = 1)
        }
        if (uncertainty != null) Text(uncertainty, style = Type.ValueSmall.copy(color = Palette.GraphiteSoft), maxLines = 1)
        if (note != null) Text(note, style = Type.BodySmall.copy(fontSize = 10.5.sp, color = Palette.Steel), maxLines = 2)
    }
}

/** Compact label / value / unit row for dense parameter lists. */
@Composable
fun KeyValue(label: String, value: String, unit: String = "", modifier: Modifier = Modifier, labelWidth: Dp = 190.dp) {
    Row(modifier.fillMaxWidth().padding(vertical = 3.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, style = Type.Body.copy(color = Palette.GraphiteSoft), modifier = Modifier.width(labelWidth), maxLines = 1, overflow = TextOverflow.Ellipsis)
        Text(if (isMissing(value)) Fmt.DASH else value, style = Type.ValueSmall.copy(fontSize = 13.sp, color = if (isMissing(value)) Palette.SteelLight else Palette.Graphite), textAlign = TextAlign.End, modifier = Modifier.weight(1f))
        Spacer(Modifier.width(8.dp))
        Text(unit, style = Type.Unit, modifier = Modifier.width(78.dp), maxLines = 1)
    }
}

enum class Severity { OK, CAUTION, FAULT, NEUTRAL }

fun statusSeverity(status: String?): Severity = when (status?.uppercase()) {
    "STABLE", "OK", "CONNECTED", "RUNNING" -> Severity.OK
    "SETTLING", "PAUSED" -> Severity.CAUTION
    "SATURATED", "UNLOCKED", "DISCONNECTED", "ERROR" -> Severity.FAULT
    else -> Severity.NEUTRAL
}

/** Rectangular status badge: outlined, small caps, colour by severity. */
@Composable
fun StatusBadge(text: String, severity: Severity = statusSeverity(text), modifier: Modifier = Modifier) {
    val (fg, bg) = when (severity) {
        Severity.OK -> Palette.Navy to Palette.NavyLight
        Severity.CAUTION -> Palette.Amber to Palette.AmberLight
        Severity.FAULT -> Palette.Red to Palette.RedLight
        Severity.NEUTRAL -> Palette.Steel to Palette.PanelAlt
    }
    Box(
        modifier.background(bg).border(1.dp, fg).padding(horizontal = 8.dp, vertical = 3.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(caps(text), style = Type.Label.copy(color = fg, fontWeight = FontWeight.Bold), maxLines = 1)
    }
}

/** Column specification for [DataTable]; the header carries the unit, e.g. "BIAS [µGal]". */
class Col(val header: String, val width: Dp, val alignEnd: Boolean = true, val mono: Boolean = true)

/** Plain data table with thin rules and zebra rows; horizontally scrollable when wide. */
@Composable
fun DataTable(
    columns: List<Col>,
    rows: List<List<String>>,
    modifier: Modifier = Modifier,
    emptyText: String = "NO ENGINE DATA",
    scrollable: Boolean = false,
) {
    val content: @Composable () -> Unit = {
        Column(Modifier.width(IntrinsicSize.Max)) {
            Row(Modifier.background(Palette.PanelAlt).padding(vertical = 6.dp)) {
                for (c in columns) Text(
                    c.header, style = Type.Label.copy(fontSize = 10.sp),
                    modifier = Modifier.width(c.width).padding(horizontal = 6.dp),
                    textAlign = if (c.alignEnd) TextAlign.End else TextAlign.Start, maxLines = 2,
                )
            }
            Divider(color = Palette.RuleStrong, thickness = 1.dp)
            if (rows.isEmpty()) {
                Text(emptyText, style = Type.Label, modifier = Modifier.padding(10.dp))
            }
            rows.forEachIndexed { i, r ->
                Row(Modifier.background(if (i % 2 == 1) Palette.Paper else Palette.Panel).padding(vertical = 4.dp)) {
                    columns.forEachIndexed { j, c ->
                        val raw = r.getOrElse(j) { Fmt.DASH }
                        val v = if (isMissing(raw)) Fmt.DASH else raw
                        Text(
                            v,
                            style = (if (c.mono) Type.ValueSmall else Type.Body).copy(color = if (v == Fmt.DASH) Palette.SteelLight else Palette.Graphite),
                            modifier = Modifier.width(c.width).padding(horizontal = 6.dp),
                            textAlign = if (c.alignEnd) TextAlign.End else TextAlign.Start,
                            maxLines = 2, overflow = TextOverflow.Ellipsis,
                        )
                    }
                }
                Divider(color = Palette.Rule.copy(alpha = 0.6f), thickness = 1.dp)
            }
        }
    }
    if (scrollable) Box(modifier.horizontalScroll(rememberScrollState())) { content() } else Box(modifier) { content() }
}

/** Segmented selector (window / hours / unit). */
@Composable
fun <T> Segmented(options: List<T>, selected: T, label: (T) -> String, onSelect: (T) -> Unit, modifier: Modifier = Modifier) {
    Row(modifier.border(1.dp, Palette.RuleStrong)) {
        options.forEachIndexed { i, o ->
            val sel = o == selected
            if (i > 0) Box(Modifier.width(1.dp).height(26.dp).background(Palette.RuleStrong))
            Box(
                Modifier.background(if (sel) Palette.Navy else Palette.Panel).clickable { onSelect(o) }.height(26.dp).padding(horizontal = 10.dp),
                contentAlignment = Alignment.Center,
            ) {
                Text(label(o), style = Type.BodySmall.copy(color = if (sel) Color.White else Palette.Graphite, fontWeight = if (sel) FontWeight.SemiBold else FontWeight.Normal))
            }
        }
    }
}

/** Flat rectangular push button. */
@Composable
fun ActionButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    primary: Boolean = true,
    danger: Boolean = false,
) {
    val fg = when { !enabled -> Palette.SteelLight; primary -> Color.White; danger -> Palette.Red; else -> Palette.Navy }
    val bg = when { !enabled -> Palette.PanelAlt; primary -> if (danger) Palette.Red else Palette.Navy; else -> Palette.Panel }
    val border = when { !enabled -> Palette.Rule; danger -> Palette.Red; else -> Palette.Navy }
    Box(
        modifier.background(bg).border(BorderStroke(1.dp, border))
            .then(if (enabled) Modifier.clickable(onClick = onClick) else Modifier)
            .height(28.dp).padding(horizontal = 12.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(caps(text), style = Type.Label.copy(color = fg, fontWeight = FontWeight.Bold), maxLines = 1)
    }
}

/** Labelled numeric/text input field with a unit suffix. */
@Composable
fun InputField(label: String, value: String, onChange: (String) -> Unit, unit: String = "", width: Dp = 110.dp, modifier: Modifier = Modifier) {
    Column(modifier) {
        Text(caps(label), style = Type.Label)
        Spacer(Modifier.height(3.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            BasicTextField(
                value = value,
                onValueChange = onChange,
                singleLine = true,
                textStyle = Type.ValueSmall.copy(fontSize = 13.sp),
                cursorBrush = SolidColor(Palette.Navy),
                keyboardOptions = KeyboardOptions.Default,
                modifier = Modifier.width(width).background(Palette.PanelAlt).border(1.dp, Palette.RuleStrong).padding(horizontal = 6.dp, vertical = 5.dp),
            )
            if (unit.isNotEmpty()) {
                Spacer(Modifier.width(5.dp)); Text(unit, style = Type.Unit)
            }
        }
    }
}

/** Physics/feature switch row. */
@Composable
fun SwitchRow(label: String, checked: Boolean?, onChange: (Boolean) -> Unit, enabled: Boolean = true) {
    Row(Modifier.fillMaxWidth().height(30.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, style = Type.Body, modifier = Modifier.weight(1f))
        Text(
            when (checked) { true -> "ON"; false -> "OFF"; null -> Fmt.DASH },
            style = Type.ValueSmall.copy(color = when (checked) { true -> Palette.Navy; false -> Palette.Amber; null -> Palette.SteelLight }),
            modifier = Modifier.widthIn(min = 30.dp),
        )
        Switch(
            checked = checked == true,
            onCheckedChange = onChange,
            enabled = enabled && checked != null,
            colors = SwitchDefaults.colors(
                checkedThumbColor = Palette.Navy, checkedTrackColor = Palette.NavySoft,
                uncheckedThumbColor = Palette.Panel, uncheckedTrackColor = Palette.SteelLight,
            ),
        )
    }
}

/** Prominent banner for missing engine data — never replaced by invented numbers. */
@Composable
fun NoEngineData(modifier: Modifier = Modifier, detail: String? = null) {
    Column(
        modifier.fillMaxWidth().background(Palette.Panel).border(1.dp, Palette.Rule).padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text("NO ENGINE DATA", style = Type.Section.copy(color = Palette.Red, fontSize = 13.sp))
        if (detail != null) {
            Spacer(Modifier.height(4.dp)); Text(detail, style = Type.BodySmall)
        }
    }
}

/** Small explanatory caption under charts. */
@Composable
fun Caption(text: String, modifier: Modifier = Modifier) {
    Text(text, style = Type.BodySmall.copy(color = Palette.Steel, fontSize = 10.5.sp), modifier = modifier.padding(top = 4.dp))
}

@Composable
fun HSpace(w: Dp) = Spacer(Modifier.width(w))

@Composable
fun VSpace(h: Dp) = Spacer(Modifier.height(h))

/** Equal-width row of children with a gap. */
@Composable
fun GridRow(gap: Dp = 12.dp, modifier: Modifier = Modifier, content: @Composable RowScope.() -> Unit) {
    Row(modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(gap), content = content)
}

/** Horizontal bar chart drawn with layout primitives (crisp text, exact widths). */
@Composable
fun HorizontalBars(
    items: List<Pair<String, Double?>>,
    format: (Double?) -> String,
    unit: String,
    modifier: Modifier = Modifier,
    color: Color = Palette.MutedBlue,
) {
    val max = items.mapNotNull { it.second?.takeIf { v -> v.isFinite() } }.maxOfOrNull { kotlin.math.abs(it) } ?: 0.0
    Column(modifier) {
        for ((name, v) in items) {
            Row(Modifier.fillMaxWidth().height(24.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(name, style = Type.BodySmall, modifier = Modifier.width(150.dp), maxLines = 1, overflow = TextOverflow.Ellipsis)
                Box(Modifier.weight(1f).height(14.dp).background(Palette.Paper)) {
                    val f = if (v != null && v.isFinite() && max > 0) (kotlin.math.abs(v) / max).toFloat().coerceIn(0f, 1f) else 0f
                    if (f > 0f) Box(Modifier.fillMaxWidth(f).height(14.dp).background(color))
                }
                Text(format(v), style = Type.ValueSmall, textAlign = TextAlign.End, modifier = Modifier.width(96.dp))
                Spacer(Modifier.width(4.dp))
                Text(unit, style = Type.Unit, modifier = Modifier.width(44.dp))
            }
        }
    }
}
