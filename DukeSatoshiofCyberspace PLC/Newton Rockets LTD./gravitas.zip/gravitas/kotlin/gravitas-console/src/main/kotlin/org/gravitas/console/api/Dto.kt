package org.gravitas.console.api

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject

/*
 * Data-transfer objects for the GRAVITAS Engine API v1 (docs/API.md).
 *
 * Field names mirror the contract exactly (units are part of the name). Every field is
 * nullable with a null default: the engine emits `null` for missing values and the console
 * must render "—" rather than an invented number. Numeric arrays are `List<Double?>` so that
 * a null element is preserved (plotted as a gap) instead of failing the whole document.
 * Integer-valued quantities (ADC bits/codes, sample counts) are decoded as Double so that
 * either `24` or `24.0` on the wire is accepted.
 */

typealias NumArray = List<Double?>

@Serializable
data class Health(
    val status: String? = null,
    @SerialName("software_version") val softwareVersion: String? = null,
    @SerialName("sim_time_s") val simTimeS: Double? = null,
    val running: Boolean? = null,
    val speed: Double? = null,
)

@Serializable
data class Overview(
    val timestamp: String? = null,
    @SerialName("sim_time_s") val simTimeS: Double? = null,
    @SerialName("latitude_deg") val latitudeDeg: Double? = null,
    @SerialName("longitude_deg") val longitudeDeg: Double? = null,
    @SerialName("altitude_m") val altitudeM: Double? = null,
    val mode: String? = null,
    @SerialName("local_gravity_mps2") val localGravityMps2: Double? = null,
    @SerialName("static_gravity_mps2") val staticGravityMps2: Double? = null,
    @SerialName("raw_measurement_mps2") val rawMeasurementMps2: Double? = null,
    @SerialName("filtered_mps2") val filteredMps2: Double? = null,
    @SerialName("calibrated_mps2") val calibratedMps2: Double? = null,
    @SerialName("corrected_gravity_mps2") val correctedGravityMps2: Double? = null,
    @SerialName("estimate_mps2") val estimateMps2: Double? = null,
    @SerialName("bias_mps2") val biasMps2: Double? = null,
    @SerialName("tidal_component_mps2") val tidalComponentMps2: Double? = null,
    @SerialName("temperature_c") val temperatureC: Double? = null,
    @SerialName("vibration_rms_mps2") val vibrationRmsMps2: Double? = null,
    @SerialName("standard_uncertainty_mps2") val standardUncertaintyMps2: Double? = null,
    @SerialName("expanded_uncertainty_mps2") val expandedUncertaintyMps2: Double? = null,
    @SerialName("coverage_factor") val coverageFactor: Double? = null,
    @SerialName("instrument_status") val instrumentStatus: String? = null,
    @SerialName("status_reasons") val statusReasons: List<String>? = null,
)

@Serializable
data class Series(
    @SerialName("window_s") val windowS: Double? = null,
    @SerialName("sample_rate_hz") val sampleRateHz: Double? = null,
    @SerialName("t_s") val tS: NumArray? = null,
    @SerialName("true_mps2") val trueMps2: NumArray? = null,
    @SerialName("raw_mps2") val rawMps2: NumArray? = null,
    @SerialName("filtered_mps2") val filteredMps2: NumArray? = null,
    @SerialName("calibrated_mps2") val calibratedMps2: NumArray? = null,
    @SerialName("corrected_mps2") val correctedMps2: NumArray? = null,
    @SerialName("estimate_mps2") val estimateMps2: NumArray? = null,
    @SerialName("estimate_sigma_mps2") val estimateSigmaMps2: NumArray? = null,
    @SerialName("tide_mps2") val tideMps2: NumArray? = null,
    @SerialName("static_true_mps2") val staticTrueMps2: NumArray? = null,
    @SerialName("temperature_c") val temperatureC: NumArray? = null,
    @SerialName("vibration_mps2") val vibrationMps2: NumArray? = null,
    @SerialName("bias_mps2") val biasMps2: NumArray? = null,
)

@Serializable
data class Readout(
    val type: String? = null,
    @SerialName("wavelength_m") val wavelengthM: Double? = null,
    @SerialName("phase_rad") val phaseRad: Double? = null,
    @SerialName("intensity_i_v") val intensityIV: Double? = null,
    @SerialName("intensity_q_v") val intensityQV: Double? = null,
    @SerialName("measured_displacement_m") val measuredDisplacementM: Double? = null,
)

@Serializable
data class Adc(
    val bits: Double? = null,
    @SerialName("full_scale_v") val fullScaleV: Double? = null,
    @SerialName("lsb_v") val lsbV: Double? = null,
    @SerialName("code_i") val codeI: Double? = null,
    @SerialName("code_q") val codeQ: Double? = null,
    val saturated: Boolean? = null,
)

@Serializable
data class InstrumentHistory(
    @SerialName("t_s") val tS: NumArray? = null,
    @SerialName("position_m") val positionM: NumArray? = null,
    @SerialName("velocity_mps") val velocityMps: NumArray? = null,
    @SerialName("feedback_force_n") val feedbackForceN: NumArray? = null,
)

@Serializable
data class Instrument(
    val mode: String? = null,
    @SerialName("proof_mass_kg") val proofMassKg: Double? = null,
    @SerialName("spring_constant_npm") val springConstantNpm: Double? = null,
    @SerialName("damping_nspm") val dampingNspm: Double? = null,
    @SerialName("natural_frequency_hz") val naturalFrequencyHz: Double? = null,
    @SerialName("damping_ratio") val dampingRatio: Double? = null,
    @SerialName("reference_gravity_mps2") val referenceGravityMps2: Double? = null,
    @SerialName("proof_mass_position_m") val proofMassPositionM: Double? = null,
    @SerialName("proof_mass_velocity_mps") val proofMassVelocityMps: Double? = null,
    @SerialName("spring_force_n") val springForceN: Double? = null,
    @SerialName("gravity_force_n") val gravityForceN: Double? = null,
    @SerialName("feedback_force_n") val feedbackForceN: Double? = null,
    @SerialName("net_force_n") val netForceN: Double? = null,
    val readout: Readout? = null,
    val adc: Adc? = null,
    @SerialName("temperature_c") val temperatureC: Double? = null,
    @SerialName("bias_mps2") val biasMps2: Double? = null,
    @SerialName("noise_rms_mps2") val noiseRmsMps2: Double? = null,
    val history: InstrumentHistory? = null,
)

/** Physics switch document. Keys are kept as a map so that new switches appear automatically. */
@Serializable
data class PhysicsSwitches(
    val switches: Map<String, Boolean> = emptyMap(),
)

@Serializable
data class Location(
    @SerialName("latitude_deg") val latitudeDeg: Double? = null,
    @SerialName("longitude_deg") val longitudeDeg: Double? = null,
    @SerialName("altitude_m") val altitudeM: Double? = null,
)

@Serializable
data class LatitudeProfile(
    @SerialName("lat_deg") val latDeg: NumArray? = null,
    @SerialName("effective_mps2") val effectiveMps2: NumArray? = null,
    @SerialName("no_rotation_mps2") val noRotationMps2: NumArray? = null,
    @SerialName("spherical_mps2") val sphericalMps2: NumArray? = null,
    @SerialName("centrifugal_up_mps2") val centrifugalUpMps2: NumArray? = null,
)

@Serializable
data class AltitudeProfile(
    @SerialName("alt_m") val altM: NumArray? = null,
    @SerialName("effective_mps2") val effectiveMps2: NumArray? = null,
    @SerialName("spherical_mps2") val sphericalMps2: NumArray? = null,
)

@Serializable
data class Earth(
    val location: Location? = null,
    @SerialName("spherical_mps2") val sphericalMps2: Double? = null,
    @SerialName("newtonian_mps2") val newtonianMps2: Double? = null,
    @SerialName("newtonian_enu_mps2") val newtonianEnuMps2: NumArray? = null,
    @SerialName("centrifugal_mps2") val centrifugalMps2: Double? = null,
    @SerialName("centrifugal_enu_mps2") val centrifugalEnuMps2: NumArray? = null,
    @SerialName("effective_mps2") val effectiveMps2: Double? = null,
    @SerialName("effective_enu_mps2") val effectiveEnuMps2: NumArray? = null,
    @SerialName("somigliana_mps2") val somiglianaMps2: Double? = null,
    @SerialName("somigliana_free_air_mps2") val somiglianaFreeAirMps2: Double? = null,
    @SerialName("model_discrepancy_mps2") val modelDiscrepancyMps2: Double? = null,
    @SerialName("free_air_gradient_mps2_per_m") val freeAirGradientMps2PerM: Double? = null,
    @SerialName("latitude_profile") val latitudeProfile: LatitudeProfile? = null,
    @SerialName("altitude_profile") val altitudeProfile: AltitudeProfile? = null,
)

@Serializable
data class TideCurrent(
    @SerialName("lunar_mps2") val lunarMps2: Double? = null,
    @SerialName("solar_mps2") val solarMps2: Double? = null,
    @SerialName("combined_mps2") val combinedMps2: Double? = null,
)

@Serializable
data class Tides(
    @SerialName("t_s") val tS: NumArray? = null,
    val timestamps: List<String?>? = null,
    @SerialName("lunar_mps2") val lunarMps2: NumArray? = null,
    @SerialName("solar_mps2") val solarMps2: NumArray? = null,
    @SerialName("combined_mps2") val combinedMps2: NumArray? = null,
    @SerialName("gravimetric_factor") val gravimetricFactor: Double? = null,
    val current: TideCurrent? = null,
)

@Serializable
data class AnomalyBody(
    val kind: String? = null,
    val description: String? = null,
    /** Free-form parameter map; units are encoded in the key names (e.g. `radius_m`). */
    val params: JsonObject? = null,
)

@Serializable
data class AnomalyProfile(
    @SerialName("distance_m") val distanceM: NumArray? = null,
    @SerialName("east_m") val eastM: NumArray? = null,
    @SerialName("north_m") val northM: NumArray? = null,
    @SerialName("anomaly_mps2") val anomalyMps2: NumArray? = null,
)

/** `anomaly_mps2[i][j]` is interpreted as row i = `north_m[i]`, column j = `east_m[j]`. */
@Serializable
data class AnomalyGrid(
    @SerialName("east_m") val eastM: NumArray? = null,
    @SerialName("north_m") val northM: NumArray? = null,
    @SerialName("anomaly_mps2") val anomalyMps2: List<NumArray>? = null,
)

@Serializable
data class Survey(
    @SerialName("distance_m") val distanceM: NumArray? = null,
    @SerialName("true_anomaly_mps2") val trueAnomalyMps2: NumArray? = null,
    @SerialName("measured_anomaly_mps2") val measuredAnomalyMps2: NumArray? = null,
    @SerialName("uncertainty_mps2") val uncertaintyMps2: NumArray? = null,
    @SerialName("rms_error_mps2") val rmsErrorMps2: Double? = null,
)

@Serializable
data class Anomalies(
    val label: String? = null,
    val bodies: List<AnomalyBody>? = null,
    val profile: AnomalyProfile? = null,
    val grid: AnomalyGrid? = null,
    val survey: Survey? = null,
)

@Serializable
data class CalibrationParams(
    @SerialName("bias_mps2") val biasMps2: Double? = null,
    @SerialName("scale_factor") val scaleFactor: Double? = null,
    @SerialName("temperature_coefficient_mps2_per_k") val temperatureCoefficientMps2PerK: Double? = null,
    @SerialName("drift_rate_mps2_per_s") val driftRateMps2PerS: Double? = null,
)

@Serializable
data class CalibrationSeries(
    @SerialName("t_s") val tS: NumArray? = null,
    @SerialName("true_mps2") val trueMps2: NumArray? = null,
    @SerialName("uncalibrated_mps2") val uncalibratedMps2: NumArray? = null,
    @SerialName("calibrated_mps2") val calibratedMps2: NumArray? = null,
    @SerialName("temperature_c") val temperatureC: NumArray? = null,
)

@Serializable
data class CalibrationReport(
    val injected: CalibrationParams? = null,
    val estimated: CalibrationParams? = null,
    @SerialName("estimated_uncertainty") val estimatedUncertainty: CalibrationParams? = null,
    @SerialName("residual_rms_uncalibrated_mps2") val residualRmsUncalibratedMps2: Double? = null,
    @SerialName("residual_rms_calibrated_mps2") val residualRmsCalibratedMps2: Double? = null,
    val series: CalibrationSeries? = null,
)

@Serializable
data class UncertaintyContribution(
    val name: String? = null,
    @SerialName("standard_uncertainty_mps2") val standardUncertaintyMps2: Double? = null,
    val type: String? = null,
    val sensitivity: Double? = null,
    @SerialName("input_uncertainty") val inputUncertainty: Double? = null,
    @SerialName("input_unit") val inputUnit: String? = null,
    val description: String? = null,
)

@Serializable
data class UncertaintyBudget(
    @SerialName("value_mps2") val valueMps2: Double? = null,
    @SerialName("standard_uncertainty_mps2") val standardUncertaintyMps2: Double? = null,
    @SerialName("expanded_uncertainty_mps2") val expandedUncertaintyMps2: Double? = null,
    @SerialName("coverage_factor") val coverageFactor: Double? = null,
    val contributions: List<UncertaintyContribution>? = null,
)

@Serializable
data class MonteCarloResult(
    val trials: Double? = null,
    @SerialName("analytical_std_mps2") val analyticalStdMps2: Double? = null,
    @SerialName("mc_std_mps2") val mcStdMps2: Double? = null,
    @SerialName("mc_mean_error_mps2") val mcMeanErrorMps2: Double? = null,
    @SerialName("rmse_mps2") val rmseMps2: Double? = null,
    @SerialName("ci95_mps2") val ci95Mps2: NumArray? = null,
    @SerialName("coverage_probability") val coverageProbability: Double? = null,
    @SerialName("ratio_mc_to_analytical") val ratioMcToAnalytical: Double? = null,
    @SerialName("errors_mps2") val errorsMps2: NumArray? = null,
)

@Serializable
data class AllanRegion(
    @SerialName("tau_from_s") val tauFromS: Double? = null,
    @SerialName("tau_to_s") val tauToS: Double? = null,
    val slope: Double? = null,
    val label: String? = null,
)

@Serializable
data class AllanIdentification(
    @SerialName("white_noise_mps2_per_rthz") val whiteNoiseMps2PerRtHz: Double? = null,
    @SerialName("bias_instability_mps2") val biasInstabilityMps2: Double? = null,
    @SerialName("bias_instability_tau_s") val biasInstabilityTauS: Double? = null,
    val regions: List<AllanRegion>? = null,
)

@Serializable
data class Allan(
    @SerialName("tau_s") val tauS: NumArray? = null,
    @SerialName("adev_mps2") val adevMps2: NumArray? = null,
    @SerialName("adev_lo_mps2") val adevLoMps2: NumArray? = null,
    @SerialName("adev_hi_mps2") val adevHiMps2: NumArray? = null,
    @SerialName("n_samples") val nSamples: Double? = null,
    val identification: AllanIdentification? = null,
)

@Serializable
data class ExperimentInfo(
    val name: String,
    val description: String? = null,
)

@Serializable
data class ExperimentList(
    val experiments: List<ExperimentInfo> = emptyList(),
)

@Serializable
data class ExperimentSeries(
    val x: NumArray? = null,
    @SerialName("x_label") val xLabel: String? = null,
    val curves: Map<String, NumArray>? = null,
    @SerialName("y_unit") val yUnit: String? = null,
)

@Serializable
data class ExperimentResult(
    val name: String? = null,
    /** `{"<key>": <number>, ...}`; kept as JSON so a non-numeric value cannot break decoding. */
    val summary: Map<String, JsonElement>? = null,
    val series: ExperimentSeries? = null,
)

@Serializable
data class MapInstrument(
    @SerialName("latitude_deg") val latitudeDeg: Double? = null,
    @SerialName("longitude_deg") val longitudeDeg: Double? = null,
    @SerialName("altitude_m") val altitudeM: Double? = null,
    @SerialName("gravity_mps2") val gravityMps2: Double? = null,
    @SerialName("uncertainty_mps2") val uncertaintyMps2: Double? = null,
)

@Serializable
data class SurveyPoint(
    @SerialName("latitude_deg") val latitudeDeg: Double? = null,
    @SerialName("longitude_deg") val longitudeDeg: Double? = null,
    @SerialName("anomaly_mps2") val anomalyMps2: Double? = null,
)

/** `g_mps2[i][j]` is interpreted as row i = `lat_deg[i]`, column j = `lon_deg[j]`. */
@Serializable
data class GravityGrid(
    @SerialName("lat_deg") val latDeg: NumArray? = null,
    @SerialName("lon_deg") val lonDeg: NumArray? = null,
    @SerialName("g_mps2") val gMps2: List<NumArray>? = null,
)

/** `anomaly_mps2[i][j]` is interpreted as row i = `lat_deg[i]`, column j = `lon_deg[j]`. */
@Serializable
data class LatLonAnomalyGrid(
    @SerialName("lat_deg") val latDeg: NumArray? = null,
    @SerialName("lon_deg") val lonDeg: NumArray? = null,
    @SerialName("anomaly_mps2") val anomalyMps2: List<NumArray>? = null,
)

@Serializable
data class MapData(
    val instrument: MapInstrument? = null,
    @SerialName("survey_path") val surveyPath: List<SurveyPoint>? = null,
    @SerialName("gravity_grid") val gravityGrid: GravityGrid? = null,
    @SerialName("anomaly_grid") val anomalyGrid: LatLonAnomalyGrid? = null,
)

@Serializable
data class TelemetryFrame(
    val timestamp: String? = null,
    @SerialName("sim_time_s") val simTimeS: Double? = null,
    @SerialName("latitude_deg") val latitudeDeg: Double? = null,
    @SerialName("longitude_deg") val longitudeDeg: Double? = null,
    @SerialName("altitude_m") val altitudeM: Double? = null,
    @SerialName("true_gravity_mps2") val trueGravityMps2: Double? = null,
    @SerialName("raw_measurement_mps2") val rawMeasurementMps2: Double? = null,
    @SerialName("filtered_mps2") val filteredMps2: Double? = null,
    @SerialName("calibrated_mps2") val calibratedMps2: Double? = null,
    @SerialName("corrected_measurement_mps2") val correctedMeasurementMps2: Double? = null,
    @SerialName("tidal_component_mps2") val tidalComponentMps2: Double? = null,
    @SerialName("lunar_component_mps2") val lunarComponentMps2: Double? = null,
    @SerialName("solar_component_mps2") val solarComponentMps2: Double? = null,
    @SerialName("anomaly_component_mps2") val anomalyComponentMps2: Double? = null,
    @SerialName("bias_mps2") val biasMps2: Double? = null,
    @SerialName("temperature_c") val temperatureC: Double? = null,
    @SerialName("vibration_mps2") val vibrationMps2: Double? = null,
    @SerialName("uncertainty_mps2") val uncertaintyMps2: Double? = null,
    @SerialName("proof_mass_position_m") val proofMassPositionM: Double? = null,
    @SerialName("feedback_force_n") val feedbackForceN: Double? = null,
    @SerialName("adc_code") val adcCode: Double? = null,
    val status: String? = null,
)

@Serializable
data class Telemetry(
    val frames: List<TelemetryFrame> = emptyList(),
)

@Serializable
data class ApiError(
    val error: String? = null,
)

/* ---------------------------------------------------------------- request bodies */

@Serializable
data class PhysicsPatch(val switches: Map<String, Boolean>)

@Serializable
data class SurveyRequest(
    @SerialName("duration_s") val durationS: Double,
    @SerialName("sample_rate_hz") val sampleRateHz: Double,
)

@Serializable
data class SeedRequest(val seed: Long)

@Serializable
data class MonteCarloRequest(
    val trials: Int,
    @SerialName("duration_s") val durationS: Double,
)

@Serializable
data class ExperimentRequest(
    @SerialName("duration_s") val durationS: Double,
    @SerialName("sample_rate_hz") val sampleRateHz: Double,
)

/** POST /control bodies; only the fields relevant to the chosen action are encoded. */
@Serializable
data class ControlRequest(
    val action: String,
    val seed: Long? = null,
    val speed: Double? = null,
    @SerialName("latitude_deg") val latitudeDeg: Double? = null,
    @SerialName("longitude_deg") val longitudeDeg: Double? = null,
    @SerialName("altitude_m") val altitudeM: Double? = null,
    val mode: String? = null,
) {
    companion object {
        fun pause() = ControlRequest("pause")
        fun resume() = ControlRequest("resume")
        fun reset(seed: Long?) = ControlRequest("reset", seed = seed)
        fun setSpeed(speed: Double) = ControlRequest("set_speed", speed = speed)
        fun setLocation(lat: Double, lon: Double, alt: Double) =
            ControlRequest("set_location", latitudeDeg = lat, longitudeDeg = lon, altitudeM = alt)
        fun setMode(mode: String) = ControlRequest("set_mode", mode = mode)
    }
}

/** Converts a contract number array to a DoubleArray, mapping `null` to NaN (a plot gap). */
fun NumArray?.toArr(): DoubleArray {
    if (this == null) return DoubleArray(0)
    return DoubleArray(size) { this[it] ?: Double.NaN }
}
