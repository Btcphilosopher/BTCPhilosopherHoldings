package org.gravitas.console.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.doubleOrNull
import org.gravitas.console.api.CalibrationParams
import org.gravitas.console.api.toArr
import org.gravitas.console.state.ConsoleStore
import org.gravitas.console.units.Fmt
import org.gravitas.console.units.GravityUnit
import org.gravitas.console.ui.chart.ChartMarker
import org.gravitas.console.ui.chart.ChartSeries
import org.gravitas.console.ui.chart.Histogram
import org.gravitas.console.ui.chart.LineChart
import org.gravitas.console.ui.components.ActionButton
import org.gravitas.console.ui.components.Caption
import org.gravitas.console.ui.components.Col
import org.gravitas.console.ui.components.DataTable
import org.gravitas.console.ui.components.GridRow
import org.gravitas.console.ui.components.HorizontalBars
import org.gravitas.console.ui.components.InputField
import org.gravitas.console.ui.components.KeyValue
import org.gravitas.console.ui.components.Panel
import org.gravitas.console.ui.components.Readout
import org.gravitas.console.ui.theme.Palette
import org.gravitas.console.ui.theme.Type

/* ============================================================== CALIBRATION */

@Composable
fun CalibrationScreen(store: ConsoleStore) {
    val u = store.unit
    val c = if (store.connected) store.calibration else null
    var seed by remember { mutableStateOf("7") }
    val busy = store.busy["calibration"] == true
    ScreenBody(
        "Calibration", "Injected instrument errors versus the engine's calibration estimates (/calibration).",
        trailing = {
            Row(verticalAlignment = Alignment.Bottom) {
                InputField("Seed", seed, { seed = it }, width = 70.dp)
                Spacer(Modifier.width(10.dp))
                ActionButton(if (busy) "Running…" else "Run calibration", { store.runCalibration(seed.trim().toLongOrNull()) }, enabled = store.connected && !busy)
            }
        },
    ) {
        if (!store.connected) DisconnectedNotice(store)
        else if (c == null) {
            org.gravitas.console.ui.components.NoEngineData(
                detail = if (store.calibrationChecked) "The engine reports no calibration yet (GET /calibration → null). Run one with POST /calibration/run."
                else "Awaiting /calibration…",
            )
        }
        GridRow {
            Panel("Parameters", Modifier.weight(1.6f)) {
                fun row(name: String, unit: String, f: (CalibrationParams?) -> Double?, fmt: (Double?) -> String) =
                    listOf(name, unit, fmt(f(c?.injected)), fmt(f(c?.estimated)), "± " + fmt(f(c?.estimatedUncertainty)))
                DataTable(
                    listOf(Col("PARAMETER", 210.dp, false, false), Col("UNIT", 80.dp, false), Col("INJECTED", 150.dp), Col("ESTIMATED", 150.dp), Col("± UNCERTAINTY", 140.dp)),
                    if (c == null) emptyList() else listOf(
                        row("Bias", u.symbol, { it?.biasMps2 }) { Fmt.small(it, u) },
                        row("Scale factor", "1", { it?.scaleFactor }) { v -> if (v != null && kotlin.math.abs(v) < 1e-3) Fmt.sci(v, 3) else Fmt.fixed(v, 9) },
                        row("Temperature coefficient", "${u.symbol}/K", { it?.temperatureCoefficientMps2PerK }) { Fmt.small(it, u) },
                        row("Drift rate", "${u.symbol}/s", { it?.driftRateMps2PerS }) { Fmt.small(it, u) },
                    ),
                )
            }
            Panel("Residual RMS", Modifier.weight(1f)) {
                Readout("Before calibration", Fmt.small(c?.residualRmsUncalibratedMps2, u), u.symbol)
                Readout("After calibration", Fmt.small(c?.residualRmsCalibratedMps2, u), u.symbol, valueColor = Palette.Navy)
            }
        }
        val s = c?.series
        val t = s?.tS.toArr()
        val tru = s?.trueMps2.toArr()
        val ref = tru.finiteMean()
        val xl = "time [s]"
        GridRow {
            Panel("True vs uncalibrated vs calibrated", Modifier.weight(1f)) {
                LineChart(
                    if (s == null || ref == null) emptyList() else listOf(
                        ChartSeries("uncalibrated", t, s.uncalibratedMps2.toArr().deviationInUnit(ref, u), Palette.Red, 1.2f),
                        ChartSeries("calibrated", t, s.calibratedMps2.toArr().deviationInUnit(ref, u), Palette.MutedBlue, 1.2f),
                        ChartSeries("true", t, tru.deviationInUnit(ref, u), Palette.Graphite, 1.6f),
                    ),
                    Modifier.fillMaxWidth().height(300.dp), xLabel = xl, yLabel = "Δg = g − g_ref [${u.symbol}]",
                    emptyText = if (store.connected) "NO CALIBRATION REPORT" else "NO ENGINE DATA",
                )
                if (ref != null) Caption("g_ref = mean of TRUE over the calibration record = ${Fmt.gravity(ref, u)} ${u.symbol}")
            }
            Panel("Detail: true vs calibrated", Modifier.weight(1f)) {
                LineChart(
                    if (s == null || ref == null) emptyList() else listOf(
                        ChartSeries("calibrated", t, s.calibratedMps2.toArr().deviationInUnit(ref, u), Palette.MutedBlue, 1.2f),
                        ChartSeries("true", t, tru.deviationInUnit(ref, u), Palette.Graphite, 1.6f),
                    ),
                    Modifier.fillMaxWidth().height(300.dp), xLabel = xl, yLabel = "Δg [${u.symbol}]",
                    emptyText = if (store.connected) "NO CALIBRATION REPORT" else "NO ENGINE DATA",
                )
            }
        }
        Panel("Temperature during calibration record") {
            LineChart(
                if (s == null) emptyList() else listOf(ChartSeries("temperature", t, s.temperatureC.toArr(), Palette.Amber)),
                Modifier.fillMaxWidth().height(170.dp), xLabel = xl, yLabel = "[°C]", legend = false,
                emptyText = if (store.connected) "NO CALIBRATION REPORT" else "NO ENGINE DATA",
            )
        }
    }
}

/* ============================================================== UNCERTAINTY */

private fun isAccelUnit(s: String?) = s != null && s.replace(" ", "") in setOf("m/s^2", "m/s²", "m s^-2", "mps2")

@Composable
fun UncertaintyScreen(store: ConsoleStore) {
    val u = store.unit
    val b = if (store.connected) store.uncertainty else null
    val mc = if (store.connected) store.monteCarlo else null
    var trials by remember { mutableStateOf("50") }
    var duration by remember { mutableStateOf("300") }
    val busy = store.busy["mc"] == true
    ScreenBody("Uncertainty", "GUM-style uncertainty budget of the gravity estimate (/uncertainty) and Monte Carlo validation.") {
        if (!store.connected) DisconnectedNotice(store)
        GridRow {
            Readout("Value", Fmt.gravity(b?.valueMps2, u), u.symbol, Modifier.weight(1.4f))
            Readout("Combined standard uncertainty u_c", "± " + Fmt.small(b?.standardUncertaintyMps2, u), u.symbol, Modifier.weight(1f))
            Readout("Expanded uncertainty U", "± " + Fmt.small(b?.expandedUncertaintyMps2, u), u.symbol, Modifier.weight(1f), valueColor = Palette.Navy)
            Readout("Coverage factor k", Fmt.fixed(b?.coverageFactor, 2), "", Modifier.weight(0.7f))
        }
        val contributions = b?.contributions.orEmpty()
        Panel("Budget") {
            DataTable(
                listOf(
                    Col("COMPONENT", 150.dp, false, false), Col("TYPE", 50.dp, false), Col("INPUT u(xᵢ)", 110.dp), Col("INPUT UNIT", 80.dp, false),
                    Col("SENSITIVITY cᵢ", 110.dp), Col("CONTRIBUTION uᵢ [${u.symbol}]", 150.dp), Col("DESCRIPTION", 380.dp, false, false),
                ),
                contributions.map { c ->
                    val accel = isAccelUnit(c.inputUnit)
                    listOf(
                        c.name ?: Fmt.DASH, c.type ?: Fmt.DASH,
                        if (accel) Fmt.small(c.inputUncertainty, u) else Fmt.sig(c.inputUncertainty, 4),
                        if (accel) u.symbol else (c.inputUnit ?: Fmt.DASH),
                        Fmt.sig(c.sensitivity, 4),
                        Fmt.small(c.standardUncertaintyMps2, u),
                        c.description ?: Fmt.DASH,
                    )
                },
                emptyText = if (b == null) "NO ENGINE DATA" else "No contributions reported",
            )
        }
        Panel("Contributions uᵢ") {
            HorizontalBars(contributions.map { (it.name ?: Fmt.DASH) to it.standardUncertaintyMps2 }, { Fmt.small(it, u) }, u.symbol)
            Caption("Bar length ∝ |uᵢ| as reported by the engine; combined u_c = ± ${Fmt.small(b?.standardUncertaintyMps2, u)} ${u.symbol}.")
        }
        Panel("Monte Carlo validation", trailing = {
            Row(verticalAlignment = Alignment.Bottom) {
                InputField("Trials", trials, { trials = it }, width = 70.dp)
                Spacer(Modifier.width(10.dp))
                InputField("Duration", duration, { duration = it }, "s", width = 80.dp)
                Spacer(Modifier.width(10.dp))
                ActionButton(if (busy) "Running…" else "Run Monte Carlo", {
                    val n = trials.toIntOrNull(); val d = duration.toDoubleOrNull()
                    if (n != null && d != null) store.runMonteCarlo(n, d)
                }, enabled = store.connected && !busy && trials.toIntOrNull() != null && duration.toDoubleOrNull() != null)
            }
        }) {
            if (mc == null) Text(if (busy) "Running POST /uncertainty/monte-carlo…" else "No Monte Carlo result yet.", style = Type.BodySmall)
            else Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                Column(Modifier.weight(1f)) {
                    KeyValue("Trials", Fmt.integer(mc.trials), "")
                    KeyValue("Analytical std", Fmt.small(mc.analyticalStdMps2, u), u.symbol)
                    KeyValue("Monte Carlo std", Fmt.small(mc.mcStdMps2, u), u.symbol)
                    KeyValue("Ratio MC / analytical", Fmt.fixed(mc.ratioMcToAnalytical, 3), "")
                    KeyValue("Mean error", Fmt.small(mc.mcMeanErrorMps2, u), u.symbol)
                    KeyValue("RMSE", Fmt.small(mc.rmseMps2, u), u.symbol)
                    val ci = mc.ci95Mps2.toArr()
                    KeyValue("95 % CI", if (ci.size >= 2) "[${Fmt.small(ci[0], u)}, ${Fmt.small(ci[1], u)}]" else Fmt.DASH, u.symbol)
                    KeyValue("Coverage probability", Fmt.fixed(mc.coverageProbability, 3), "")
                }
                Column(Modifier.weight(1.3f)) {
                    val ci = mc.ci95Mps2.toArr()
                    Histogram(
                        mc.errorsMps2.toArr().inUnit(u), Modifier.fillMaxWidth().height(240.dp), bins = 24,
                        xLabel = "estimate error [${u.symbol}]",
                        vLines = if (ci.size >= 2) listOf(u.fromMps2(ci[0]) to "CI95 lo", u.fromMps2(ci[1]) to "CI95 hi") else emptyList(),
                    )
                }
            }
        }
    }
}

/* ============================================================== ALLAN */

@Composable
fun AllanScreen(store: ConsoleStore) {
    val u = store.unit
    val a = if (store.connected) store.allan else null
    ScreenBody("Allan deviation", "Overlapping Allan deviation of the live raw-measurement record (/allan).") {
        if (!store.connected) DisconnectedNotice(store)
        val id = a?.identification
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Panel("ADEV σ(τ) · log–log", Modifier.weight(1.8f)) {
                val tau = a?.tauS.toArr()
                val markers = buildList {
                    val bt = id?.biasInstabilityTauS; val bv = id?.biasInstabilityMps2
                    if (bt != null && bv != null) add(ChartMarker(bt, u.fromMps2(bv), "bias instability", Palette.Red))
                }
                LineChart(
                    if (a == null) emptyList() else listOf(
                        ChartSeries(
                            "ADEV with confidence band", tau, a.adevMps2.toArr().inUnit(u), Palette.Navy, 1.8f, markers = true,
                            bandLo = a.adevLoMps2.toArr().inUnit(u), bandHi = a.adevHiMps2.toArr().inUnit(u),
                        ),
                    ),
                    Modifier.fillMaxWidth().height(460.dp), xLabel = "averaging time τ [s]", yLabel = "σ_A(τ) [${u.symbol}]",
                    xLog = true, yLog = true, markers = markers,
                )
                Caption("Samples in record: ${Fmt.integer(a?.nSamples)}. Shaded band: engine-reported confidence interval.")
            }
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Panel("Noise identification") {
                    Readout("White noise density", Fmt.small(id?.whiteNoiseMps2PerRtHz, u), "${u.symbol}/√Hz", large = false)
                    Readout("Bias instability", Fmt.small(id?.biasInstabilityMps2, u), u.symbol, large = false)
                    Readout("at τ", Fmt.sig(id?.biasInstabilityTauS, 4), "s", large = false)
                }
                Panel("Regions") {
                    DataTable(
                        listOf(Col("τ FROM [s]", 80.dp), Col("τ TO [s]", 80.dp), Col("SLOPE", 60.dp), Col("REGION", 130.dp, false, false)),
                        id?.regions.orEmpty().map { listOf(Fmt.sig(it.tauFromS, 3), Fmt.sig(it.tauToS, 3), Fmt.fixed(it.slope, 2), it.label ?: Fmt.DASH) },
                        emptyText = if (a == null) "NO ENGINE DATA" else "No regions identified",
                    )
                }
            }
        }
    }
}

/* ============================================================== EXPERIMENTS */

/** Maps a `<name>_<unit>` key to a display unit and converted value (presentation only). */
internal fun summaryCell(key: String, v: Double?, u: GravityUnit): Pair<String, String> {
    val k = key.lowercase()
    fun n(x: Double?) = if (x != null && x == Math.rint(x) && kotlin.math.abs(x) < 1e12) Fmt.integer(x) else Fmt.sig(x, 6)
    return when {
        k.endsWith("_mps2_per_m") -> Fmt.small(v, u) to "${u.symbol}/m"
        k.endsWith("_mps2_per_rthz") -> Fmt.small(v, u) to "${u.symbol}/√Hz"
        k.endsWith("_mps2") -> Fmt.small(v, u) to u.symbol
        k.endsWith("_s") -> n(v) to "s"
        k.endsWith("_hz") -> n(v) to "Hz"
        k.endsWith("_deg") -> n(v) to "°"
        k.endsWith("_m") -> n(v) to "m"
        k.endsWith("_c") -> n(v) to "°C"
        k.endsWith("_n") -> n(v) to "N"
        k.endsWith("_kg") -> n(v) to "kg"
        k.endsWith("_v") -> n(v) to "V"
        k.endsWith("_rad") -> n(v) to "rad"
        else -> n(v) to ""
    }
}

@Composable
fun ExperimentsScreen(store: ConsoleStore) {
    val u = store.unit
    val list = if (store.connected) store.experiments?.experiments else null
    var selected by remember { mutableStateOf<String?>(null) }
    var duration by remember { mutableStateOf("600") }
    var rate by remember { mutableStateOf("10") }
    val sel = selected ?: list?.firstOrNull()?.name
    ScreenBody("Experiments", "Scripted engine experiments (/experiments). Results are engine computations.") {
        if (!store.connected) DisconnectedNotice(store)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Panel("Available", Modifier.width(300.dp)) {
                if (list == null) Text(if (store.connected) "Awaiting /experiments…" else "NO ENGINE DATA", style = Type.Label)
                list.orEmpty().forEach { e ->
                    val isSel = e.name == sel
                    Column(
                        Modifier.fillMaxWidth().background(if (isSel) Palette.NavyLight else Palette.Panel)
                            .border(1.dp, if (isSel) Palette.Navy else Palette.Rule).clickable { selected = e.name }.padding(8.dp),
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(e.name.uppercase(), style = Type.Label.copy(color = Palette.Navy, fontWeight = FontWeight.Bold), modifier = Modifier.weight(1f))
                            if (store.experimentResults.containsKey(e.name)) Text("RESULT", style = Type.Label.copy(color = Palette.MutedBlue))
                            if (store.busy["exp:${e.name}"] == true) Text("RUNNING", style = Type.Label.copy(color = Palette.Amber))
                        }
                        Text(e.description ?: "", style = Type.BodySmall)
                    }
                    Spacer(Modifier.height(6.dp))
                }
            }
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Panel("Run ${sel?.uppercase() ?: Fmt.DASH}") {
                    Row(verticalAlignment = Alignment.Bottom) {
                        InputField("Duration", duration, { duration = it }, "s")
                        Spacer(Modifier.width(14.dp))
                        InputField("Sample rate", rate, { rate = it }, "Hz")
                        Spacer(Modifier.width(18.dp))
                        val busy = sel != null && store.busy["exp:$sel"] == true
                        ActionButton(if (busy) "Running…" else "Run experiment", {
                            if (sel != null) store.runExperiment(sel, duration.toDoubleOrNull(), rate.toDoubleOrNull())
                        }, enabled = store.connected && sel != null && !busy)
                    }
                    Caption("POST /experiments/{name} with {duration_s, sample_rate_hz}. Leave a field empty to use the engine defaults.")
                }
                val r = sel?.let { store.experimentResults[it] }
                Panel("Summary") {
                    DataTable(
                        listOf(Col("QUANTITY", 260.dp, false, false), Col("VALUE", 170.dp), Col("UNIT", 90.dp, false)),
                        r?.summary.orEmpty().map { (k, v) ->
                            val num = (v as? JsonPrimitive)?.doubleOrNull
                            if (num != null) { val (s, un) = summaryCell(k, num, u); listOf(k, s, un) }
                            else listOf(k, (v as? JsonPrimitive)?.content ?: v.toString(), "")
                        },
                        emptyText = if (r == null) "Run the experiment to see its summary." else "Empty summary",
                    )
                }
                Panel("Curves") {
                    val sr = r?.series
                    val x = sr?.x.toArr()
                    val accel = isAccelUnit(sr?.yUnit)
                    val curves = sr?.curves.orEmpty().entries.mapIndexed { i, (name, ys) ->
                        val y = ys.toArr()
                        ChartSeries(name, x, if (accel) y.inUnit(u) else y, Palette.series[i % Palette.series.size], if (i == 0) 1.8f else 1.3f)
                    }
                    LineChart(
                        curves, Modifier.fillMaxWidth().height(320.dp),
                        xLabel = sr?.xLabel ?: "", yLabel = if (accel) "[${u.symbol}]" else "[${sr?.yUnit ?: ""}]",
                        emptyText = if (r == null) "NO RESULT" else "NO CURVES",
                    )
                }
            }
        }
    }
}
