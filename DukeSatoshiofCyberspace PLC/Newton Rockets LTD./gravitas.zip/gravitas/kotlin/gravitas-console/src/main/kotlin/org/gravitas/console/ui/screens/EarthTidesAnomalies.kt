package org.gravitas.console.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonNull
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.doubleOrNull
import org.gravitas.console.api.ControlRequest
import org.gravitas.console.api.toArr
import org.gravitas.console.state.ConsoleStore
import org.gravitas.console.state.TideSpan
import org.gravitas.console.units.Fmt
import org.gravitas.console.ui.chart.ChartSeries
import org.gravitas.console.ui.chart.HeatMap
import org.gravitas.console.ui.chart.LineChart
import org.gravitas.console.ui.components.ActionButton
import org.gravitas.console.ui.components.Caption
import org.gravitas.console.ui.components.Col
import org.gravitas.console.ui.components.DataTable
import org.gravitas.console.ui.components.GridRow
import org.gravitas.console.ui.components.InputField
import org.gravitas.console.ui.components.KeyValue
import org.gravitas.console.ui.components.Panel
import org.gravitas.console.ui.components.Readout
import org.gravitas.console.ui.components.Segmented
import org.gravitas.console.ui.theme.Palette
import org.gravitas.console.ui.theme.Type

@Composable
fun EarthScreen(store: ConsoleStore) {
    val u = store.unit
    val e = if (store.connected) store.earth else null
    var lat by remember { mutableStateOf("") }
    var lon by remember { mutableStateOf("") }
    var alt by remember { mutableStateOf("") }
    ScreenBody("Earth", "Earth gravity model evaluated by the engine (/earth). Profiles are engine computations.") {
        if (!store.connected) DisconnectedNotice(store)
        Panel("Query location") {
            Row(verticalAlignment = Alignment.Bottom) {
                InputField("Latitude", lat, { lat = it }, "°")
                Spacer(Modifier.width(14.dp))
                InputField("Longitude", lon, { lon = it }, "°")
                Spacer(Modifier.width(14.dp))
                InputField("Altitude", alt, { alt = it }, "m")
                Spacer(Modifier.width(18.dp))
                ActionButton("Query /earth", {
                    store.loadEarth(lat.toDoubleOrNull(), lon.toDoubleOrNull(), alt.toDoubleOrNull())
                }, enabled = store.connected && store.busy["earth"] != true)
                Spacer(Modifier.width(8.dp))
                ActionButton("Instrument location", { lat = ""; lon = ""; alt = ""; store.loadEarth(null, null, null) }, primary = false, enabled = store.connected)
                Spacer(Modifier.width(8.dp))
                val la = lat.toDoubleOrNull(); val lo = lon.toDoubleOrNull(); val al = alt.toDoubleOrNull()
                ActionButton("Move instrument here", { if (la != null && lo != null && al != null) store.control(ControlRequest.setLocation(la, lo, al)) },
                    primary = false, enabled = store.connected && la != null && lo != null && al != null)
            }
            Caption("Empty fields use the current instrument location. “Move instrument here” sends POST /control set_location.")
        }
        GridRow {
            Panel("Gravity at location", Modifier.weight(1f)) {
                val l = e?.location
                KeyValue("Location", l?.let { "${Fmt.fixed(it.latitudeDeg, 4)}°, ${Fmt.fixed(it.longitudeDeg, 4)}°, ${Fmt.fixed(it.altitudeM, 1)} m" } ?: Fmt.DASH, "")
                KeyValue("Effective gravity", Fmt.gravity(e?.effectiveMps2, u), u.symbol)
                KeyValue("Newtonian attraction", Fmt.gravity(e?.newtonianMps2, u), u.symbol)
                KeyValue("Centrifugal", Fmt.small(e?.centrifugalMps2, u, 6), u.symbol)
                KeyValue("Spherical model", Fmt.gravity(e?.sphericalMps2, u), u.symbol)
            }
            Panel("Normal gravity", Modifier.weight(1f)) {
                KeyValue("Somigliana", Fmt.gravity(e?.somiglianaMps2, u), u.symbol)
                KeyValue("Somigliana + free-air", Fmt.gravity(e?.somiglianaFreeAirMps2, u), u.symbol)
                KeyValue("Model discrepancy", Fmt.small(e?.modelDiscrepancyMps2, u), u.symbol)
                KeyValue("Free-air gradient", Fmt.small(e?.freeAirGradientMps2PerM, u), "${u.symbol}/m")
            }
        }
        val lp = e?.latitudeProfile
        val latX = lp?.latDeg.toArr()
        GridRow {
            Panel("Latitude profile", Modifier.weight(1.4f)) {
                LineChart(
                    if (lp == null) emptyList() else listOf(
                        ChartSeries("effective", latX, lp.effectiveMps2.toArr().inUnit(u), Palette.Navy, 1.8f),
                        ChartSeries("no rotation", latX, lp.noRotationMps2.toArr().inUnit(u), Palette.MutedBlue, 1.4f, dashed = true),
                        ChartSeries("spherical", latX, lp.sphericalMps2.toArr().inUnit(u), Palette.SteelLight, 1.4f),
                    ),
                    Modifier.fillMaxWidth().height(300.dp), xLabel = "geodetic latitude [°]", yLabel = "g [${u.symbol}]",
                )
            }
            Panel("Centrifugal (up component)", Modifier.weight(1f)) {
                LineChart(
                    if (lp == null) emptyList() else listOf(ChartSeries("centrifugal up", latX, lp.centrifugalUpMps2.toArr().inUnit(u), Palette.Amber, 1.6f)),
                    Modifier.fillMaxWidth().height(300.dp), xLabel = "geodetic latitude [°]", yLabel = "a_c,up [${u.symbol}]", zeroLine = true,
                )
            }
        }
        val ap = e?.altitudeProfile
        Panel("Altitude profile") {
            val ax = ap?.altM.toArr()
            LineChart(
                if (ap == null) emptyList() else listOf(
                    ChartSeries("effective", ax, ap.effectiveMps2.toArr().inUnit(u), Palette.Navy, 1.8f),
                    ChartSeries("spherical", ax, ap.sphericalMps2.toArr().inUnit(u), Palette.SteelLight, 1.4f),
                ),
                Modifier.fillMaxWidth().height(260.dp), xLabel = "altitude [m]", yLabel = "g [${u.symbol}]",
            )
        }
    }
}

@Composable
fun TidesScreen(store: ConsoleStore) {
    val u = store.unit
    val td = if (store.connected) store.tides else null
    ScreenBody(
        "Tides", "Solid-Earth tidal gravity at the instrument from the current simulated epoch (/tides).",
        trailing = { LabelledRow("Span") { Segmented(TideSpan.entries, store.tideSpan, { "${it.hours} h" }, { store.selectTideSpan(it) }) } },
    ) {
        if (!store.connected) DisconnectedNotice(store)
        GridRow {
            Readout("Lunar (now)", Fmt.small(td?.current?.lunarMps2, u), u.symbol, Modifier.weight(1f))
            Readout("Solar (now)", Fmt.small(td?.current?.solarMps2, u), u.symbol, Modifier.weight(1f))
            Readout("Combined (now)", Fmt.small(td?.current?.combinedMps2, u), u.symbol, Modifier.weight(1f), valueColor = Palette.Navy)
            Readout("Gravimetric factor δ", Fmt.fixed(td?.gravimetricFactor, 3), "", Modifier.weight(1f))
        }
        val t = td?.tS.toArr()
        val t0 = t.firstOrNull { it.isFinite() } ?: 0.0
        val hours = DoubleArray(t.size) { (t[it] - t0) / 3600.0 }
        val start = td?.timestamps?.firstOrNull() ?: Fmt.DASH
        Panel("Tidal gravity · ${store.tideSpan.hours} h") {
            LineChart(
                if (td == null) emptyList() else listOf(
                    ChartSeries("lunar", hours, td.lunarMps2.toArr().inUnit(u), Palette.MutedBlue, 1.4f),
                    ChartSeries("solar", hours, td.solarMps2.toArr().inUnit(u), Palette.Amber, 1.4f),
                    ChartSeries("combined", hours, td.combinedMps2.toArr().inUnit(u), Palette.Navy, 2f),
                ),
                Modifier.fillMaxWidth().height(380.dp), xLabel = "hours from $start", yLabel = "Δg_tide [${u.symbol}]", zeroLine = true,
            )
        }
        GridRow {
            Panel("Lunar", Modifier.weight(1f)) {
                LineChart(if (td == null) emptyList() else listOf(ChartSeries("lunar", hours, td.lunarMps2.toArr().inUnit(u), Palette.MutedBlue)),
                    Modifier.fillMaxWidth().height(180.dp), xLabel = "hours", yLabel = "[${u.symbol}]", legend = false, zeroLine = true)
            }
            Panel("Solar", Modifier.weight(1f)) {
                LineChart(if (td == null) emptyList() else listOf(ChartSeries("solar", hours, td.solarMps2.toArr().inUnit(u), Palette.Amber)),
                    Modifier.fillMaxWidth().height(180.dp), xLabel = "hours", yLabel = "[${u.symbol}]", legend = false, zeroLine = true)
            }
        }
    }
}

@Composable
fun AnomaliesScreen(store: ConsoleStore) {
    val u = store.unit
    val a = if (store.connected) store.anomalies else null
    var duration by remember { mutableStateOf("1800") }
    var rate by remember { mutableStateOf("10") }
    ScreenBody("Anomalies", "Buried-body gravity anomalies used by the simulation (/anomalies).") {
        // Prominent model label — this is not observed geophysics.
        Row(
            Modifier.fillMaxWidth().background(Palette.AmberLight).border(1.dp, Palette.Amber).padding(horizontal = 14.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(a?.label ?: "SYNTHETIC GEOPHYSICAL MODEL", style = Type.Section.copy(color = Palette.Amber, fontSize = 14.sp, letterSpacing = 3.sp))
            Spacer(Modifier.width(14.dp))
            Text("Bodies and anomalies are synthetic model inputs, not survey data of a real site.", style = Type.BodySmall.copy(color = Palette.Amber))
        }
        if (!store.connected) DisconnectedNotice(store)
        Panel("Bodies") {
            DataTable(
                listOf(Col("#", 36.dp), Col("KIND", 100.dp, false, false), Col("DESCRIPTION", 260.dp, false, false), Col("PARAMETERS (units in key)", 560.dp, false)),
                a?.bodies.orEmpty().mapIndexed { i, b -> listOf("${i + 1}", b.kind ?: Fmt.DASH, b.description ?: Fmt.DASH, paramsText(b.params)) },
                emptyText = if (a == null) "NO ENGINE DATA" else "No bodies in model",
            )
        }
        GridRow {
            Panel("Profile", Modifier.weight(1f)) {
                val p = a?.profile
                LineChart(
                    if (p == null) emptyList() else listOf(ChartSeries("anomaly", p.distanceM.toArr(), p.anomalyMps2.toArr().inUnit(u), Palette.Navy, 1.8f)),
                    Modifier.fillMaxWidth().height(300.dp), xLabel = "distance along profile [m]", yLabel = "Δg [${u.symbol}]", legend = false, zeroLine = true,
                )
            }
            Panel("Anomaly grid (plan view)", Modifier.weight(1f)) {
                val g = a?.grid
                HeatMap(
                    g?.eastM.toArr(), g?.northM.toArr(), g?.anomalyMps2.orEmpty().map { it.toArr() },
                    Modifier.fillMaxWidth().height(300.dp), xLabel = "east [m]", yLabel = "north [m]", valueLabel = "Δg [${u.symbol}]",
                    toDisplay = { u.fromMps2(it) },
                    overlayX = a?.profile?.eastM.toArr(), overlayY = a?.profile?.northM.toArr(), overlayLabel = "profile line",
                )
            }
        }
        Panel("Survey") {
            Row(verticalAlignment = Alignment.Bottom) {
                InputField("Duration", duration, { duration = it }, "s")
                Spacer(Modifier.width(14.dp))
                InputField("Sample rate", rate, { rate = it }, "Hz")
                Spacer(Modifier.width(18.dp))
                val busy = store.busy["survey"] == true
                ActionButton(if (busy) "Running survey…" else "Run survey", {
                    val d = duration.toDoubleOrNull(); val r = rate.toDoubleOrNull()
                    if (d != null && r != null) store.runSurvey(d, r)
                }, enabled = store.connected && !busy && duration.toDoubleOrNull() != null && rate.toDoubleOrNull() != null)
                Spacer(Modifier.width(24.dp))
                Readout("RMS error (measured − true)", Fmt.small(a?.survey?.rmsErrorMps2, u), u.symbol, large = false)
            }
            Spacer(Modifier.height(8.dp))
            val s = a?.survey
            if (s == null) {
                Text(if (a == null) "NO ENGINE DATA" else "No survey yet. Run POST /anomalies/survey to overlay measured against true anomaly.", style = Type.BodySmall)
            } else {
                val d = s.distanceM.toArr()
                val m = s.measuredAnomalyMps2.toArr()
                val unc = s.uncertaintyMps2.toArr()
                val hasBand = unc.size == m.size
                LineChart(
                    listOf(
                        ChartSeries("true anomaly", d, s.trueAnomalyMps2.toArr().inUnit(u), Palette.Graphite, 1.6f),
                        ChartSeries(
                            "measured ± u", d, m.inUnit(u), Palette.MutedBlue, 1.2f, markers = true,
                            bandLo = if (hasBand) DoubleArray(m.size) { u.fromMps2(m[it] - unc[it]) } else null,
                            bandHi = if (hasBand) DoubleArray(m.size) { u.fromMps2(m[it] + unc[it]) } else null,
                        ),
                    ),
                    Modifier.fillMaxWidth().height(300.dp), xLabel = "distance along survey [m]", yLabel = "Δg [${u.symbol}]", zeroLine = true,
                )
            }
        }
    }
}

/** Flattens a body parameter object, e.g. `radius_m = 50, center_enu_m = [0, 0, -120]`. */
internal fun paramsText(p: JsonObject?): String =
    p?.entries?.joinToString(",  ") { (k, v) -> "$k = ${jsonText(v)}" } ?: Fmt.DASH

internal fun jsonText(v: JsonElement): String = when (v) {
    is JsonNull -> Fmt.DASH
    is JsonPrimitive -> v.doubleOrNull?.let { Fmt.sig(it, 6).trimZeros() } ?: v.content
    is JsonArray -> v.joinToString(", ", "[", "]") { jsonText(it) }
    is JsonObject -> v.entries.joinToString(", ", "{", "}") { (k, x) -> "$k: ${jsonText(x)}" }
}

internal fun String.trimZeros(): String {
    val mant = substringBefore('e')
    val exp = if (contains('e')) "e" + substringAfter('e') else ""
    val m = if (mant.contains('.')) mant.trimEnd('0').trimEnd('.') else mant
    return m + exp
}

