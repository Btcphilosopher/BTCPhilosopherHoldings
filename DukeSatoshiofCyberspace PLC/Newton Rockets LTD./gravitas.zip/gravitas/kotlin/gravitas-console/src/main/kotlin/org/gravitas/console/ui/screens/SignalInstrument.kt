package org.gravitas.console.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.unit.dp
import org.gravitas.console.api.Instrument
import org.gravitas.console.api.toArr
import org.gravitas.console.state.ConsoleStore
import org.gravitas.console.state.SeriesWindow
import org.gravitas.console.units.Fmt
import org.gravitas.console.ui.chart.ChartSeries
import org.gravitas.console.ui.chart.LineChart
import org.gravitas.console.ui.chart.text
import org.gravitas.console.ui.components.ActionButton
import org.gravitas.console.ui.components.Caption
import org.gravitas.console.ui.components.GridRow
import org.gravitas.console.ui.components.KeyValue
import org.gravitas.console.ui.components.Panel
import org.gravitas.console.ui.components.Segmented
import org.gravitas.console.ui.components.StatusBadge
import org.gravitas.console.ui.theme.Palette
import org.gravitas.console.ui.theme.Type
import kotlin.math.abs
import kotlin.math.max

@Composable
fun SignalScreen(store: ConsoleStore) {
    val u = store.unit
    val s = if (store.connected) store.series else null
    ScreenBody(
        "Signal", "All pipeline stages from /series plotted simultaneously as deviations from a stated reference.",
        trailing = {
            LabelledRow("Window") { Segmented(SeriesWindow.entries, store.window, { it.label }, { store.selectWindow(it) }) }
        },
    ) {
        if (!store.connected) DisconnectedNotice(store)
        Panel("Pipeline stages · window ${store.window.label}") {
            SignalChart(store, Modifier.fillMaxWidth().height(440.dp))
        }
        val t = s?.tS.toArr()
        val t0 = t.firstOrNull { it.isFinite() } ?: 0.0
        val x = DoubleArray(t.size) { t[it] - t0 }
        val xl = "time since ${Fmt.simTime(t0)} [s]"
        GridRow {
            Panel("Tide (engine model)", Modifier.weight(1f)) {
                LineChart(
                    if (s == null) emptyList() else listOf(ChartSeries("tide", x, s.tideMps2.toArr().inUnit(u), Palette.MutedBlue)),
                    Modifier.fillMaxWidth().height(180.dp), xLabel = xl, yLabel = "[${u.symbol}]", legend = false,
                )
            }
            Panel("Sensor bias (injected)", Modifier.weight(1f)) {
                LineChart(
                    if (s == null) emptyList() else listOf(ChartSeries("bias", x, s.biasMps2.toArr().inUnit(u), Palette.Amber)),
                    Modifier.fillMaxWidth().height(180.dp), xLabel = xl, yLabel = "[${u.symbol}]", legend = false,
                )
            }
        }
        GridRow {
            Panel("Temperature", Modifier.weight(1f)) {
                LineChart(
                    if (s == null) emptyList() else listOf(ChartSeries("temperature", x, s.temperatureC.toArr(), Palette.Red)),
                    Modifier.fillMaxWidth().height(180.dp), xLabel = xl, yLabel = "[°C]", legend = false,
                )
            }
            Panel("Platform vibration", Modifier.weight(1f)) {
                LineChart(
                    if (s == null) emptyList() else listOf(ChartSeries("vibration", x, s.vibrationMps2.toArr().scaled(1e6), Palette.Steel, 1f)),
                    Modifier.fillMaxWidth().height(180.dp), xLabel = xl, yLabel = "[µm/s²]", legend = false,
                )
            }
        }
    }
}

@Composable
fun InstrumentScreen(store: ConsoleStore) {
    val i = if (store.connected) store.instrument else null
    val u = store.unit
    ScreenBody(
        "Instrument", "Spring-mass gravimeter with optical readout and ADC (/instrument).",
        trailing = {
            LabelledRow("Mode") {
                StatusBadge(i?.mode ?: Fmt.DASH)
                Spacer(Modifier.width(8.dp))
                ActionButton("Equilibrium", { store.control(org.gravitas.console.api.ControlRequest.setMode("equilibrium")) }, primary = i?.mode == "equilibrium", enabled = store.connected)
                Spacer(Modifier.width(4.dp))
                ActionButton("Feedback", { store.control(org.gravitas.console.api.ControlRequest.setMode("feedback")) }, primary = i?.mode == "feedback", enabled = store.connected)
            }
        },
    ) {
        if (!store.connected) DisconnectedNotice(store)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Panel("Schematic", Modifier.weight(1.25f)) {
                InstrumentSchematic(i, Modifier.fillMaxWidth().height(430.dp))
                Caption("Not to scale. Annotations are live engine values; the position bar is normalised to the recent history range.")
            }
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Panel("Proof mass & forces") {
                    si("Position z", i?.proofMassPositionM, "m")
                    si("Velocity", i?.proofMassVelocityMps, "m/s")
                    KeyValue("Spring force", Fmt.fixed(i?.springForceN, 9), "N")
                    KeyValue("Gravity force", Fmt.fixed(i?.gravityForceN, 9), "N")
                    si("Feedback force", i?.feedbackForceN, "N")
                    si("Net force", i?.netForceN, "N")
                }
                Panel("Mechanical parameters") {
                    KeyValue("Proof mass", Fmt.sig(i?.proofMassKg?.times(1e3), 4), "g")
                    KeyValue("Spring constant", Fmt.sig(i?.springConstantNpm, 5), "N/m")
                    KeyValue("Damping", Fmt.sig(i?.dampingNspm, 4), "N·s/m")
                    KeyValue("Natural frequency", Fmt.sig(i?.naturalFrequencyHz, 4), "Hz")
                    KeyValue("Damping ratio ζ", Fmt.sig(i?.dampingRatio, 3), "")
                    KeyValue("Reference gravity", Fmt.gravity(i?.referenceGravityMps2, u), u.symbol)
                }
            }
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Panel("Optical readout") {
                    KeyValue("Type", i?.readout?.type?.uppercase() ?: Fmt.DASH, "")
                    si("Wavelength", i?.readout?.wavelengthM, "m")
                    KeyValue("Phase", Fmt.fixed(i?.readout?.phaseRad, 5), "rad")
                    KeyValue("Intensity I", Fmt.fixed(i?.readout?.intensityIV, 6), "V")
                    KeyValue("Intensity Q", Fmt.fixed(i?.readout?.intensityQV, 6), "V")
                    si("Measured displacement", i?.readout?.measuredDisplacementM, "m")
                }
                Panel("ADC") {
                    KeyValue("Resolution", Fmt.integer(i?.adc?.bits), "bits")
                    KeyValue("Full scale", Fmt.sig(i?.adc?.fullScaleV, 4), "V")
                    si("LSB", i?.adc?.lsbV, "V")
                    KeyValue("Code I", Fmt.integer(i?.adc?.codeI), "LSB")
                    KeyValue("Code Q", Fmt.integer(i?.adc?.codeQ), "LSB")
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Saturation", style = Type.Body.copy(color = Palette.GraphiteSoft), modifier = Modifier.width(190.dp))
                        StatusBadge(when (i?.adc?.saturated) { true -> "SATURATED"; false -> "IN RANGE"; null -> Fmt.DASH },
                            severity = when (i?.adc?.saturated) { true -> org.gravitas.console.ui.components.Severity.FAULT; false -> org.gravitas.console.ui.components.Severity.OK; null -> org.gravitas.console.ui.components.Severity.NEUTRAL })
                    }
                }
                Panel("Thermal & noise") {
                    KeyValue("Temperature", Fmt.fixed(i?.temperatureC, 3), "°C")
                    KeyValue("Bias", Fmt.small(i?.biasMps2, u), u.symbol)
                    KeyValue("Noise (RMS)", Fmt.small(i?.noiseRmsMps2, u), u.symbol)
                }
            }
        }
        val h = i?.history
        val t = h?.tS.toArr()
        val t0 = t.firstOrNull { it.isFinite() } ?: 0.0
        val x = DoubleArray(t.size) { t[it] - t0 }
        val xl = "time since ${Fmt.simTime(t0)} [s]"
        GridRow {
            Panel("Position history", Modifier.weight(1f)) {
                LineChart(if (h == null) emptyList() else listOf(ChartSeries("z", x, h.positionM.toArr().scaled(1e9), Palette.Navy)),
                    Modifier.fillMaxWidth().height(170.dp), xLabel = xl, yLabel = "z [nm]", legend = false)
            }
            Panel("Velocity history", Modifier.weight(1f)) {
                LineChart(if (h == null) emptyList() else listOf(ChartSeries("v", x, h.velocityMps.toArr().scaled(1e9), Palette.MutedBlue)),
                    Modifier.fillMaxWidth().height(170.dp), xLabel = xl, yLabel = "v [nm/s]", legend = false)
            }
            Panel("Feedback force history", Modifier.weight(1f)) {
                LineChart(if (h == null) emptyList() else listOf(ChartSeries("F_fb", x, h.feedbackForceN.toArr().scaled(1e9), Palette.Amber)),
                    Modifier.fillMaxWidth().height(170.dp), xLabel = xl, yLabel = "F_fb [nN]", legend = false)
            }
        }
    }
}

@Composable
private fun si(label: String, v: Double?, unit: String) {
    val (value, prefixed) = Fmt.siPrefixed(v, unit)
    KeyValue(label, value, prefixed)
}

/** Spring / proof mass / optical readout schematic annotated with live values. */
@Composable
fun InstrumentSchematic(i: Instrument?, modifier: Modifier) {
    val tm = rememberTextMeasurer()
    Canvas(modifier) {
        val w = size.width; val h = size.height
        val cx = w * 0.33f
        val ink = Palette.Graphite
        val st = Type.Axis.copy(color = Palette.Graphite)
        val stv = Type.Axis.copy(color = Palette.Navy, fontWeight = FontWeight.SemiBold)
        // Support frame with hatching
        val beamTop = 18f; val beamH = 16f
        drawRect(Palette.PanelAlt, Offset(cx - 120f, beamTop), Size(240f, beamH))
        drawRect(ink, Offset(cx - 120f, beamTop), Size(240f, beamH), style = Stroke(1.2f))
        var hx = cx - 116f
        while (hx < cx + 116f) { drawLine(Palette.SteelLight, Offset(hx, beamTop + beamH), Offset(hx + 10f, beamTop), 1f); hx += 9f }
        text(tm, "RIGID FRAME", cx + 128f, beamTop + 1f, Type.Label)
        // Spring (zig-zag)
        val springTop = beamTop + beamH
        val massTop = h * 0.50f
        val p = Path().apply {
            moveTo(cx, springTop); lineTo(cx, springTop + 14f)
            val n = 12; val seg = (massTop - springTop - 28f) / n
            for (k in 0 until n) lineTo(cx + if (k % 2 == 0) 18f else -18f, springTop + 14f + seg * (k + 0.5f))
            lineTo(cx, massTop - 14f); lineTo(cx, massTop)
        }
        drawPath(p, ink, style = Stroke(1.6f))
        text(tm, "k = ${Fmt.sig(i?.springConstantNpm, 5)} N/m", cx + 28f, springTop + 30f, st)
        text(tm, "c = ${Fmt.sig(i?.dampingNspm, 4)} N·s/m", cx + 28f, springTop + 46f, st)
        // Dashpot (parallel)
        val dx = cx - 60f
        drawLine(ink, Offset(dx, springTop), Offset(dx, springTop + 60f), 1.2f)
        drawRect(ink, Offset(dx - 9f, springTop + 60f), Size(18f, 40f), style = Stroke(1.2f))
        drawLine(ink, Offset(dx - 6f, springTop + 80f), Offset(dx + 6f, springTop + 80f), 2f)
        drawLine(ink, Offset(dx, springTop + 80f), Offset(dx, massTop), 1.2f)
        // Proof mass
        val mw = 120f; val mh = 64f
        drawRect(Palette.NavyLight, Offset(cx - mw / 2, massTop), Size(mw, mh))
        drawRect(Palette.Navy, Offset(cx - mw / 2, massTop), Size(mw, mh), style = Stroke(1.6f))
        text(tm, "PROOF MASS", cx, massTop + 12f, Type.Label.copy(color = Palette.Navy), alignX = 0.5f)
        text(tm, "m = ${Fmt.sig(i?.proofMassKg?.times(1e3), 4)} g", cx, massTop + 30f, stv, alignX = 0.5f)
        // Mirror on mass (right face)
        drawLine(Palette.Steel, Offset(cx + mw / 2 + 3f, massTop + 10f), Offset(cx + mw / 2 + 3f, massTop + mh - 10f), 3f)
        // Force arrows
        fun arrow(x: Float, y0: Float, y1: Float, c: Color) {
            drawLine(c, Offset(x, y0), Offset(x, y1), 2f)
            val d = if (y1 > y0) -1f else 1f
            drawLine(c, Offset(x, y1), Offset(x - 5f, y1 + 8f * d), 2f)
            drawLine(c, Offset(x, y1), Offset(x + 5f, y1 + 8f * d), 2f)
        }
        val ax = cx - mw / 2 - 26f
        arrow(ax, massTop + mh / 2, massTop + mh / 2 - 54f, Palette.Navy)
        text(tm, "F_spring", ax - 6f, massTop + mh / 2 - 74f, Type.Axis.copy(color = Palette.Navy), alignX = 1f)
        text(tm, Fmt.fixed(i?.springForceN, 9) + " N", ax - 6f, massTop + mh / 2 - 60f, Type.Axis.copy(color = Palette.Navy), alignX = 1f)
        arrow(ax, massTop + mh / 2, massTop + mh / 2 + 54f, ink)
        text(tm, "F_gravity", ax - 6f, massTop + mh / 2 + 44f, st, alignX = 1f)
        text(tm, Fmt.fixed(i?.gravityForceN, 9) + " N", ax - 6f, massTop + mh / 2 + 58f, st, alignX = 1f)
        // Feedback actuator below the mass
        val coilTop = massTop + mh + 34f
        drawLine(Palette.Amber, Offset(cx, massTop + mh), Offset(cx, coilTop), 1.2f, pathEffect = PathEffect.dashPathEffect(floatArrayOf(4f, 3f)))
        drawRect(Palette.AmberLight, Offset(cx - 70f, coilTop), Size(140f, 30f))
        drawRect(Palette.Amber, Offset(cx - 70f, coilTop), Size(140f, 30f), style = Stroke(1.2f))
        text(tm, "FEEDBACK ACTUATOR", cx, coilTop + 9f, Type.Label.copy(color = Palette.Amber), alignX = 0.5f)
        val (fb, fbU) = Fmt.siPrefixed(i?.feedbackForceN, "N")
        text(tm, "F_fb = $fb $fbU   (mode: ${i?.mode ?: Fmt.DASH})", cx, coilTop + 38f, Type.Axis.copy(color = Palette.Amber), alignX = 0.5f)
        // Ground
        val gy = coilTop + 66f
        drawLine(ink, Offset(cx - 120f, gy), Offset(cx + 120f, gy), 1.2f)
        // Position gauge (normalised to recent history range)
        val gx = cx + mw / 2 + 36f
        val hist = i?.history?.positionM.toArr().filter { it.isFinite() }
        val z = i?.proofMassPositionM
        val zmax = max(hist.maxOfOrNull { abs(it) } ?: 0.0, abs(z ?: 0.0))
        drawLine(Palette.SteelLight, Offset(gx, massTop - 30f), Offset(gx, massTop + mh + 30f), 1f)
        for (k in -2..2) drawLine(Palette.SteelLight, Offset(gx - 4f, massTop + mh / 2 - k * 15f), Offset(gx + 4f, massTop + mh / 2 - k * 15f), 1f)
        if (z != null && zmax > 0) {
            val yz = massTop + mh / 2 - (z / zmax * 30.0).toFloat()
            drawLine(Palette.Red, Offset(gx - 8f, yz), Offset(gx + 8f, yz), 2f)
        }
        val (zv, zu) = Fmt.siPrefixed(z, "m")
        text(tm, "z = $zv $zu", gx - 10f, massTop - 34f, Type.Axis.copy(color = Palette.Red), alignY = 1f)
        // Optical readout: laser → mirror → detector
        val ly = massTop + mh / 2
        val lx = w - 124f
        drawRect(Palette.PanelAlt, Offset(lx, ly - 52f), Size(116f, 34f))
        drawRect(ink, Offset(lx, ly - 52f), Size(116f, 34f), style = Stroke(1.2f))
        text(tm, "LASER", lx + 58f, ly - 46f, Type.Label, alignX = 0.5f)
        text(tm, "λ = ${Fmt.siPrefixed(i?.readout?.wavelengthM, "m").let { it.first + " " + it.second }}", lx + 58f, ly - 32f, Type.Axis, alignX = 0.5f)
        drawRect(Palette.PanelAlt, Offset(lx, ly + 18f), Size(116f, 34f))
        drawRect(ink, Offset(lx, ly + 18f), Size(116f, 34f), style = Stroke(1.2f))
        text(tm, "I/Q DETECTOR", lx + 58f, ly + 24f, Type.Label, alignX = 0.5f)
        val mirrorX = cx + mw / 2 + 4f
        drawLine(Palette.Red.copy(alpha = 0.8f), Offset(lx, ly - 35f), Offset(mirrorX, ly), 1.2f)
        drawLine(Palette.Red.copy(alpha = 0.8f), Offset(mirrorX, ly), Offset(lx, ly + 35f), 1.2f, pathEffect = PathEffect.dashPathEffect(floatArrayOf(5f, 3f)))
        val ro = i?.readout
        val rx = w - 190f
        var ry = ly + 66f
        for (line in listOf(
            "φ  = ${Fmt.fixed(ro?.phaseRad, 4)} rad",
            "I  = ${Fmt.fixed(ro?.intensityIV, 4)} V",
            "Q  = ${Fmt.fixed(ro?.intensityQV, 4)} V",
            "Δz = ${Fmt.siPrefixed(ro?.measuredDisplacementM, "m").let { it.first + " " + it.second }}",
            "ADC ${Fmt.integer(i?.adc?.bits)} bit",
            "code I ${Fmt.integer(i?.adc?.codeI)} · Q ${Fmt.integer(i?.adc?.codeQ)}",
        )) { text(tm, line, rx, ry, stv); ry += 15f }
    }
}

@Composable
fun DisconnectedNotice(store: ConsoleStore) {
    org.gravitas.console.ui.components.NoEngineData(detail = "Engine at ${store.api.engineUrl} is not reachable. Values are shown as “—”.")
}

