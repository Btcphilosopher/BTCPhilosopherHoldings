package org.gravitas.console.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import org.gravitas.console.api.toArr
import org.gravitas.console.state.ConsoleStore
import org.gravitas.console.units.Fmt
import org.gravitas.console.units.GravityUnit
import org.gravitas.console.ui.chart.ChartSeries
import org.gravitas.console.ui.chart.LineChart
import org.gravitas.console.ui.components.Caption
import org.gravitas.console.ui.components.Col
import org.gravitas.console.ui.components.DataTable
import org.gravitas.console.ui.components.GridRow
import org.gravitas.console.ui.components.KeyValue
import org.gravitas.console.ui.components.Panel
import org.gravitas.console.ui.components.Readout
import org.gravitas.console.ui.components.StatusBadge
import org.gravitas.console.ui.components.SwitchRow
import org.gravitas.console.ui.theme.Palette
import org.gravitas.console.ui.theme.Type

@Composable
fun OverviewScreen(store: ConsoleStore) {
    val u = store.unit
    val o = if (store.connected) store.overview else null
    ScreenBody("Overview", "Live state of the simulated gravimeter. Gravity values in ${u.symbol}; switch units in the top bar.") {
        if (!store.connected) DisconnectedNotice(store)
        GridRow {
            Panel("Gravity", Modifier.weight(2.2f)) {
                GridRow {
                    Readout("Local gravity", Fmt.gravity(o?.localGravityMps2, u), u.symbol, Modifier.weight(1f), note = "True g at sensor incl. tides + anomaly")
                    Readout("Raw measurement", Fmt.gravity(o?.rawMeasurementMps2, u), u.symbol, Modifier.weight(1f), note = "ADC output, nominal instrument constant")
                    Readout(
                        "Corrected gravity", Fmt.gravity(o?.correctedGravityMps2, u), u.symbol, Modifier.weight(1f),
                        uncertainty = pm(o?.expandedUncertaintyMps2, u, o?.coverageFactor), note = "Calibrated minus modelled tide",
                        valueColor = Palette.Navy,
                    )
                }
                Spacer(Modifier.height(10.dp))
                GridRow {
                    Readout("Bias", Fmt.small(o?.biasMps2, u), u.symbol, Modifier.weight(1f), large = false, note = "Injected sensor bias (twin truth)")
                    Readout("Tidal component", Fmt.small(o?.tidalComponentMps2, u), u.symbol, Modifier.weight(1f), large = false)
                    Readout("Estimate (Kalman)", Fmt.gravity(o?.estimateMps2, u), u.symbol, Modifier.weight(1f), large = false)
                }
                GridRow {
                    Readout("Static gravity (true)", Fmt.gravity(o?.staticGravityMps2, u), u.symbol, Modifier.weight(1f), large = false)
                    Readout("Filtered", Fmt.gravity(o?.filteredMps2, u), u.symbol, Modifier.weight(1f), large = false)
                    Readout("Calibrated", Fmt.gravity(o?.calibratedMps2, u), u.symbol, Modifier.weight(1f), large = false)
                }
            }
            Panel("Instrument", Modifier.weight(1f)) {
                Text("STATUS", style = Type.Label)
                Spacer(Modifier.height(4.dp))
                StatusBadge(o?.instrumentStatus ?: Fmt.DASH)
                val reasons = o?.statusReasons.orEmpty()
                Spacer(Modifier.height(4.dp))
                if (o != null) Text(if (reasons.isEmpty()) "No status reasons reported." else reasons.joinToString("\n") { "• $it" }, style = Type.BodySmall)
                Spacer(Modifier.height(8.dp))
                KeyValue("Mode", o?.mode?.uppercase() ?: Fmt.DASH, "", labelWidth = 110.dp)
                Readout("Temperature", Fmt.fixed(o?.temperatureC, 3), "°C", large = false)
                Readout("Vibration (RMS, 1 s)", Fmt.fixed(o?.vibrationRmsMps2?.times(1e6), 3), "µm/s²", large = false)
            }
        }
        GridRow {
            Panel("Uncertainty", Modifier.weight(1f)) {
                GridRow {
                    Readout("Standard (k = 1)", "± " + Fmt.small(o?.standardUncertaintyMps2, u), u.symbol, Modifier.weight(1f), large = false)
                    Readout("Expanded", "± " + Fmt.small(o?.expandedUncertaintyMps2, u), u.symbol, Modifier.weight(1f), large = false)
                    Readout("Coverage factor k", Fmt.fixed(o?.coverageFactor, 2), "", Modifier.weight(1f), large = false)
                }
            }
            Panel("Location & time", Modifier.weight(1f)) {
                GridRow {
                    Readout("Latitude", Fmt.fixed(o?.latitudeDeg, 5), "°", Modifier.weight(1f), large = false)
                    Readout("Longitude", Fmt.fixed(o?.longitudeDeg, 5), "°", Modifier.weight(1f), large = false)
                    Readout("Altitude", Fmt.fixed(o?.altitudeM, 2), "m", Modifier.weight(1f), large = false)
                }
                KeyValue("Simulated epoch (UTC)", o?.timestamp ?: Fmt.DASH, "", labelWidth = 170.dp)
                KeyValue("Simulated time", Fmt.simTime(o?.simTimeS), "", labelWidth = 170.dp)
            }
        }
        Panel("Recent signal · ${store.window.label}", Modifier.fillMaxWidth()) {
            SignalChart(store, Modifier.fillMaxWidth().height(260.dp), compact = true)
        }
    }
}

/** Deviation plot of pipeline stages from /series; reference = mean of true over the window. */
@Composable
fun SignalChart(store: ConsoleStore, modifier: Modifier, compact: Boolean = false) {
    val s = if (store.connected) store.series else null
    val u = store.unit
    val t = s?.tS.toArr()
    val trueArr = s?.trueMps2.toArr()
    val ref = trueArr.finiteMean()
    if (s == null || ref == null || t.isEmpty()) {
        LineChart(emptyList(), modifier, emptyText = if (store.connected) "AWAITING /series" else "NO ENGINE DATA")
        return
    }
    val t0 = t.firstOrNull { it.isFinite() } ?: 0.0
    val x = DoubleArray(t.size) { t[it] - t0 }
    val est = s.estimateMps2.toArr()
    val sig = s.estimateSigmaMps2.toArr()
    val estDev = est.deviationInUnit(ref, u)
    val bandLo = if (sig.size == est.size) DoubleArray(est.size) { u.fromMps2(est[it] - sig[it] - ref) } else null
    val bandHi = if (sig.size == est.size) DoubleArray(est.size) { u.fromMps2(est[it] + sig[it] - ref) } else null
    val series = buildList {
        add(ChartSeries("raw", x, s.rawMps2.toArr().deviationInUnit(ref, u), Palette.SteelLight, 1f))
        add(ChartSeries("filtered", x, s.filteredMps2.toArr().deviationInUnit(ref, u), Palette.MutedBlue, 1.3f))
        add(ChartSeries("calibrated", x, s.calibratedMps2.toArr().deviationInUnit(ref, u), Palette.Navy, 1.3f, dashed = true))
        add(ChartSeries("final estimate ±1σ", x, estDev, Palette.Amber, 1.8f, bandLo = bandLo, bandHi = bandHi))
        add(ChartSeries("true", x, trueArr.deviationInUnit(ref, u), Palette.Graphite, 1.6f))
    }
    Column(modifier) {
        LineChart(
            series, Modifier.fillMaxWidth().weight(1f),
            xLabel = "time since ${Fmt.simTime(t0)} [s]", yLabel = "Δg = g − g_ref [${u.symbol}]", zeroLine = true,
        )
        Caption(
            "Reference g_ref = mean of TRUE over the displayed window = ${Fmt.gravity(ref, u)} ${u.symbol}" +
                (if (!compact) "  ·  ${t.size} points, sample rate ${Fmt.sig(s.sampleRateHz, 3)} Hz (decimated by engine)" else ""),
        )
    }
}

@Composable
fun GravityScreen(store: ConsoleStore) {
    val u = store.unit
    val o = if (store.connected) store.overview else null
    val e = if (store.connected) store.earth else null
    ScreenBody("Gravity", "Breakdown of the gravity signal (from /overview and /earth) and the physics switches used by the live simulation.") {
        if (!store.connected) DisconnectedNotice(store)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Column(Modifier.weight(2f), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Panel("Live pipeline (/overview)") {
                    val rows = listOf(
                        Triple("Local gravity (true, incl. tides + anomaly)", Fmt.gravity(o?.localGravityMps2, u), u.symbol),
                        Triple("Static gravity (true, excl. tides)", Fmt.gravity(o?.staticGravityMps2, u), u.symbol),
                        Triple("Tidal component", Fmt.small(o?.tidalComponentMps2, u), u.symbol),
                        Triple("Sensor bias (injected)", Fmt.small(o?.biasMps2, u), u.symbol),
                        Triple("Raw measurement", Fmt.gravity(o?.rawMeasurementMps2, u), u.symbol),
                        Triple("Filtered", Fmt.gravity(o?.filteredMps2, u), u.symbol),
                        Triple("Calibrated", Fmt.gravity(o?.calibratedMps2, u), u.symbol),
                        Triple("Corrected (calibrated − modelled tide)", Fmt.gravity(o?.correctedGravityMps2, u), u.symbol),
                        Triple("Estimate (Kalman)", Fmt.gravity(o?.estimateMps2, u), u.symbol),
                        Triple("Standard uncertainty", "± " + Fmt.small(o?.standardUncertaintyMps2, u), u.symbol),
                        Triple("Expanded uncertainty (k = ${Fmt.sig(o?.coverageFactor, 2)})", "± " + Fmt.small(o?.expandedUncertaintyMps2, u), u.symbol),
                    )
                    for ((l, v, un) in rows) KeyValue(l, v, un, labelWidth = 300.dp)
                }
                Panel("Earth model at instrument (/earth)") {
                    val rows = listOf(
                        Triple("Spherical (point mass)", Fmt.gravity(e?.sphericalMps2, u), u.symbol),
                        Triple("Newtonian (ellipsoidal attraction)", Fmt.gravity(e?.newtonianMps2, u), u.symbol),
                        Triple("Centrifugal", Fmt.small(e?.centrifugalMps2, u, 6), u.symbol),
                        Triple("Effective (attraction + centrifugal)", Fmt.gravity(e?.effectiveMps2, u), u.symbol),
                        Triple("Somigliana (normal gravity, ellipsoid)", Fmt.gravity(e?.somiglianaMps2, u), u.symbol),
                        Triple("Somigliana + free-air", Fmt.gravity(e?.somiglianaFreeAirMps2, u), u.symbol),
                        Triple("Model discrepancy", Fmt.small(e?.modelDiscrepancyMps2, u), u.symbol),
                        Triple("Free-air gradient", Fmt.small(e?.freeAirGradientMps2PerM, u), "${u.symbol}/m"),
                    )
                    for ((l, v, un) in rows) KeyValue(l, v, un, labelWidth = 300.dp)
                    Spacer(Modifier.height(8.dp))
                    EnuTable(e?.newtonianEnuMps2.toArr(), e?.centrifugalEnuMps2.toArr(), e?.effectiveEnuMps2.toArr(), u)
                    Caption("Location: " + (e?.location?.let { "${Fmt.fixed(it.latitudeDeg, 5)}°, ${Fmt.fixed(it.longitudeDeg, 5)}°, ${Fmt.fixed(it.altitudeM, 1)} m" } ?: Fmt.DASH))
                }
            }
            Panel("Physics inspector", Modifier.weight(1f)) {
                PhysicsInspector(store)
            }
        }
    }
}

@Composable
private fun EnuTable(n: DoubleArray, c: DoubleArray, e: DoubleArray, u: GravityUnit) {
    fun cell(a: DoubleArray, i: Int) = if (i < a.size) Fmt.small(a[i], u, 6) else Fmt.DASH
    DataTable(
        listOf(Col("VECTOR", 150.dp, alignEnd = false, mono = false), Col("EAST [${u.symbol}]", 150.dp), Col("NORTH [${u.symbol}]", 150.dp), Col("UP [${u.symbol}]", 150.dp)),
        listOf(
            listOf("Newtonian", cell(n, 0), cell(n, 1), cell(n, 2)),
            listOf("Centrifugal", cell(c, 0), cell(c, 1), cell(c, 2)),
            listOf("Effective", cell(e, 0), cell(e, 1), cell(e, 2)),
        ),
    )
}

private val switchLabels = linkedMapOf(
    "earth_gravity" to "Earth gravity",
    "earth_oblateness" to "Oblateness (J2 / ellipsoid)",
    "earth_rotation" to "Earth rotation (centrifugal)",
    "altitude" to "Altitude (free-air)",
    "latitude" to "Latitude dependence",
    "moon" to "Moon (lunar tide)",
    "sun" to "Sun (solar tide)",
    "local_anomaly" to "Local anomaly",
    "temperature" to "Temperature effects",
    "vibration" to "Platform vibration",
    "sensor_bias" to "Sensor bias",
    "sensor_noise" to "Sensor noise",
)

/** Switches that POST /physics. Shown on GRAVITY and in the right-hand drawer from any screen. */
@Composable
fun PhysicsInspector(store: ConsoleStore) {
    val sw = if (store.connected) store.physics?.switches else null
    Column {
        Text("Toggle an effect to change the live simulation from the next simulated chunk onward (POST /physics).", style = Type.BodySmall)
        Spacer(Modifier.height(8.dp))
        val keys = (switchLabels.keys + (sw?.keys ?: emptySet())).distinct()
        for (k in keys) {
            SwitchRow(
                switchLabels[k] ?: k,
                sw?.get(k),
                { store.setPhysicsSwitch(k, it) },
                enabled = store.connected && store.busy["physics:$k"] != true,
            )
        }
        if (sw == null) Text("NO ENGINE DATA — switch states unknown.", style = Type.Label.copy(color = Palette.Red), modifier = Modifier.padding(top = 6.dp))
    }
}

@Composable
internal fun LabelledRow(label: String, content: @Composable () -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(org.gravitas.console.ui.components.caps(label), style = Type.Label)
        Spacer(Modifier.width(8.dp))
        content()
    }
}

internal fun GravityUnit.per(suffix: String) = "$symbol$suffix"
