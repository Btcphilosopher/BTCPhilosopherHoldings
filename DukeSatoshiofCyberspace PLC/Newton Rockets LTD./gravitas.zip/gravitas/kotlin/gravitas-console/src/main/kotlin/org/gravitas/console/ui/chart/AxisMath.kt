package org.gravitas.console.ui.chart

import java.math.BigDecimal
import java.math.RoundingMode
import java.util.Locale
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.log10
import kotlin.math.max
import kotlin.math.pow

/** A closed numeric interval used for an axis. Always satisfies min < max and both finite. */
data class AxisRange(val min: Double, val max: Double) {
    init {
        require(min.isFinite() && max.isFinite() && min < max) { "invalid axis range [$min, $max]" }
    }
    val span: Double get() = max - min
}

data class Ticks(val values: List<Double>, val step: Double)

/** Pure axis arithmetic: autoscaling, "nice" linear ticks, decade log ticks, label text. */
object AxisMath {

    /**
     * Autoscale range over the finite values of [data]. Robust to:
     *  * empty / all-NaN input → `null` (caller shows "no data"),
     *  * constant series (span 0) → symmetric padding around the value,
     *  * huge offsets with tiny spans (e.g. 9.81 m/s² ± 1e-9) → padding relative to the span,
     *    not to the magnitude, with a floor tied to double precision so min < max always holds.
     */
    fun autoRange(data: Sequence<Double>, padFraction: Double = 0.05): AxisRange? {
        var lo = Double.POSITIVE_INFINITY
        var hi = Double.NEGATIVE_INFINITY
        for (v in data) if (v.isFinite()) { if (v < lo) lo = v; if (v > hi) hi = v }
        if (lo > hi) return null
        return padded(lo, hi, padFraction)
    }

    fun padded(lo: Double, hi: Double, padFraction: Double = 0.05): AxisRange {
        val mag = max(abs(lo), abs(hi))
        // Smallest span representable around this magnitude with some headroom.
        val epsSpan = max(mag * 1e-12, Double.MIN_VALUE * 1e10)
        val span = hi - lo
        return if (span <= epsSpan) {
            val half = when {
                mag == 0.0 -> 1.0
                else -> max(mag * 1e-3, epsSpan)
            }
            AxisRange(lo - half, hi + half)
        } else {
            val pad = span * padFraction
            AxisRange(lo - pad, hi + pad)
        }
    }

    /** "Nice" step (1, 2, 2.5, 5 × 10^k) so that about [target] ticks cover [span]. */
    fun niceStep(span: Double, target: Int = 6): Double {
        require(span > 0 && span.isFinite()) { "span must be positive" }
        val raw = span / max(1, target)
        val exp = floor(log10(raw))
        val base = 10.0.pow(exp)
        val f = raw / base
        // Nearest nice mantissa (thresholds at the geometric means of neighbours).
        val nice = when {
            f < 1.4142 -> 1.0
            f < 2.2361 -> 2.0
            f < 3.5355 -> 2.5
            f < 7.0711 -> 5.0
            else -> 10.0
        }
        return nice * base
    }

    /** Linear ticks inside [range] at multiples of a nice step. */
    fun linearTicks(range: AxisRange, target: Int = 6): Ticks {
        val t = linearTicksOnce(range, target)
        return if (t.values.size >= 2 || target > 40) t else linearTicks(range, target * 2)
    }

    private fun linearTicksOnce(range: AxisRange, target: Int): Ticks {
        val step = niceStep(range.span, target)
        val first = ceil(range.min / step - 1e-9)
        val last = floor(range.max / step + 1e-9)
        val values = ArrayList<Double>()
        var k = first
        while (k <= last && values.size < 1000) {
            val v = k * step
            values.add(if (abs(v) < step * 1e-9) 0.0 else v)
            k += 1.0
        }
        return Ticks(values, step)
    }

    /** Range expanded outward to whole decades, for log axes. Non-positive data is ignored. */
    fun logRange(data: Sequence<Double>): AxisRange? {
        var lo = Double.POSITIVE_INFINITY
        var hi = Double.NEGATIVE_INFINITY
        for (v in data) if (v.isFinite() && v > 0) { if (v < lo) lo = v; if (v > hi) hi = v }
        if (lo > hi) return null
        var dLo = floor(log10(lo))
        var dHi = ceil(log10(hi))
        if (dHi <= dLo) { dLo -= 0.5; dHi += 0.5 }
        return AxisRange(10.0.pow(dLo), 10.0.pow(dHi))
    }

    /** Major ticks at each power of ten inside [range]. */
    fun logMajorTicks(range: AxisRange): List<Double> {
        require(range.min > 0) { "log axis requires positive range" }
        val a = ceil(log10(range.min) - 1e-9).toInt()
        val b = floor(log10(range.max) + 1e-9).toInt()
        return (a..b).map { 10.0.pow(it) }
    }

    /** Minor ticks 2..9 × 10^k inside [range]. */
    fun logMinorTicks(range: AxisRange): List<Double> {
        require(range.min > 0) { "log axis requires positive range" }
        val a = floor(log10(range.min)).toInt()
        val b = ceil(log10(range.max)).toInt()
        val out = ArrayList<Double>()
        for (d in a..b) for (m in 2..9) {
            val v = m * 10.0.pow(d)
            if (v > range.min && v < range.max) out.add(v)
        }
        return out
    }

    /** Fractional position (0 at min, 1 at max) of [v] along a linear or log axis. */
    fun fraction(v: Double, range: AxisRange, log: Boolean): Double =
        if (!log) (v - range.min) / range.span
        else {
            if (v <= 0.0) Double.NaN
            else (log10(v) - log10(range.min)) / (log10(range.max) - log10(range.min))
        }

    /** Inverse of [fraction]. */
    fun valueAt(fraction: Double, range: AxisRange, log: Boolean): Double =
        if (!log) range.min + fraction * range.span
        else 10.0.pow(log10(range.min) + fraction * (log10(range.max) - log10(range.min)))

    /** Tick label for a linear axis with the given step: just enough decimals to distinguish ticks. */
    fun linearLabel(v: Double, step: Double): String {
        val a = abs(v)
        if (v == 0.0) return "0"
        if (a >= 1e10 || (step < 1e-6 && a < 1e-6)) return String.format(Locale.ROOT, "%.2e", v)
        val decimals = max(0, -floor(log10(step) + 1e-9).toInt() + (if (isHalfStep(step)) 1 else 0))
        val s = BigDecimal(v.toString()).setScale(decimals.coerceAtMost(12), RoundingMode.HALF_EVEN).toPlainString()
        return if (s.startsWith("-") && s.trim('-', '0', '.').isEmpty()) s.substring(1) else s
    }

    private fun isHalfStep(step: Double): Boolean {
        val f = step / 10.0.pow(floor(log10(step)))
        return abs(f - 2.5) < 1e-9
    }

    /** Decade label for log axes: `1e-8`, `0.1`, `1`, `10`, `100`, `1e3` ... */
    fun logLabel(v: Double): String {
        val e = Math.round(log10(v)).toInt()
        return when (e) {
            -2 -> "0.01"; -1 -> "0.1"; 0 -> "1"; 1 -> "10"; 2 -> "100"
            else -> "1e$e"
        }
    }
}
