package org.gravitas.console.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import org.gravitas.console.state.ConsoleStore
import org.gravitas.console.units.Fmt
import org.gravitas.console.units.GravityUnit
import org.gravitas.console.ui.components.NoEngineData
import org.gravitas.console.ui.theme.Type

/** Scrollable screen body with a title row. */
@Composable
fun ScreenBody(
    title: String,
    subtitle: String? = null,
    trailing: @Composable () -> Unit = {},
    content: @Composable ColumnScope.() -> Unit,
) {
    Box(Modifier.fillMaxSize()) {
        Column(
            Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 22.dp, vertical = 18.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(org.gravitas.console.ui.components.caps(title), style = Type.Title)
                    if (subtitle != null) Text(subtitle, style = Type.BodySmall)
                }
                trailing()
            }
            content()
        }
    }
}

/** Renders [content] only when the engine is connected and [data] is present. */
@Composable
fun <T : Any> Requires(store: ConsoleStore, data: T?, waiting: String = "Awaiting engine response…", content: @Composable (T) -> Unit) {
    when {
        !store.connected -> NoEngineData(detail = "Engine at ${store.api.engineUrl} is not reachable. No values are shown.")
        data == null -> NoEngineData(detail = waiting)
        else -> content(data)
    }
}

fun DoubleArray.inUnit(unit: GravityUnit): DoubleArray = DoubleArray(size) { unit.fromMps2(this[it]) }

/** Deviation from [refMps2] expressed in [unit] (presentation only). */
fun DoubleArray.deviationInUnit(refMps2: Double, unit: GravityUnit): DoubleArray =
    DoubleArray(size) { unit.fromMps2(this[it] - refMps2) }

fun DoubleArray.finiteMean(): Double? {
    var s = 0.0; var n = 0
    for (v in this) if (v.isFinite()) { s += v; n++ }
    return if (n == 0) null else s / n
}

fun DoubleArray.scaled(f: Double): DoubleArray = DoubleArray(size) { this[it] * f }

/** "± u unit (k = 2)" text for an expanded uncertainty. */
fun pm(valueMps2: Double?, unit: GravityUnit, k: Double? = null): String =
    if (valueMps2 == null) "± ${Fmt.DASH} ${unit.symbol}"
    else "± ${Fmt.small(valueMps2, unit)} ${unit.symbol}" + (k?.let { " (k = ${Fmt.sig(it, 3)})" } ?: "")

@Composable
fun Gap() = Spacer(Modifier.width(12.dp))
