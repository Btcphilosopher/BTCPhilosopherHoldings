package org.gravitas.console.api

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.KSerializer
import kotlinx.serialization.json.Json
import kotlinx.serialization.serializer
import java.io.IOException
import java.net.InetAddress
import java.net.URI
import java.net.URLEncoder
import java.net.http.HttpClient
import java.net.http.HttpRequest
import java.net.http.HttpResponse
import java.nio.charset.StandardCharsets
import java.time.Duration

/** Shared JSON configuration: tolerant of fields added to the contract later. */
val GravitasJson: Json = Json {
    ignoreUnknownKeys = true
    explicitNulls = false
    coerceInputValues = true
    isLenient = false
}

/** The engine answered with an HTTP error (`{"error": "..."}` body). */
class ApiException(val status: Int, message: String) : Exception(message)

/** The engine could not be reached at all (connection refused, timeout, DNS ...). */
class EngineUnreachableException(message: String, cause: Throwable? = null) : IOException(message, cause)

/**
 * Read/write access to the GRAVITAS engine. The HTTP implementation is [GravitasClient];
 * tests provide fixture-backed implementations.
 */
interface GravitasApi {
    /** Human-readable engine root, e.g. `http://127.0.0.1:8765`. */
    val engineUrl: String

    suspend fun health(): Health
    suspend fun overview(): Overview
    suspend fun series(windowS: Double, maxPoints: Int = 2000): Series
    suspend fun instrument(): Instrument
    suspend fun physics(): PhysicsSwitches
    suspend fun setPhysics(switches: Map<String, Boolean>): PhysicsSwitches
    suspend fun earth(latDeg: Double? = null, lonDeg: Double? = null, altM: Double? = null): Earth
    suspend fun tides(hours: Int, stepS: Int): Tides
    suspend fun anomalies(): Anomalies
    suspend fun runSurvey(durationS: Double, sampleRateHz: Double): Anomalies
    suspend fun calibration(): CalibrationReport?
    suspend fun runCalibration(seed: Long?): CalibrationReport?
    suspend fun uncertainty(): UncertaintyBudget
    suspend fun runMonteCarlo(trials: Int, durationS: Double): MonteCarloResult
    suspend fun allan(maxPoints: Int = 60): Allan
    suspend fun experiments(): ExperimentList
    suspend fun runExperiment(name: String, durationS: Double?, sampleRateHz: Double?): ExperimentResult
    suspend fun map(): MapData
    suspend fun telemetry(n: Int): Telemetry
    suspend fun config(): kotlinx.serialization.json.JsonObject
    suspend fun control(request: ControlRequest): Health
}

/**
 * HTTP/JSON client for the GRAVITAS engine using `java.net.http.HttpClient`.
 *
 * @param engine engine root such as `http://127.0.0.1:8765`; `/api/v1` is appended unless
 *               already present.
 */
class GravitasClient(engine: String) : GravitasApi {

    override val engineUrl: String = engine.trim().trimEnd('/').removeSuffix("/api/v1").trimEnd('/')
    val baseUrl: String = "$engineUrl/api/v1"

    private val http: HttpClient = run {
        val builder = HttpClient.newBuilder()
            .version(HttpClient.Version.HTTP_1_1)
            .connectTimeout(Duration.ofMillis(1500))
        if (isLoopback(engineUrl)) builder.proxy(HttpClient.Builder.NO_PROXY)
        builder.build()
    }

    private val fastTimeout = Duration.ofSeconds(4)
    private val runTimeout = Duration.ofMinutes(15)

    private suspend fun <T> get(path: String, serializer: KSerializer<T>, timeout: Duration = fastTimeout): T =
        exchange(HttpRequest.newBuilder(URI.create(baseUrl + path)).GET().timeout(timeout).build(), serializer)

    private suspend fun <B, T> post(
        path: String, body: B, bodySerializer: KSerializer<B>, serializer: KSerializer<T>,
        timeout: Duration = runTimeout,
    ): T {
        val json = GravitasJson.encodeToString(bodySerializer, body)
        val request = HttpRequest.newBuilder(URI.create(baseUrl + path))
            .header("Content-Type", "application/json")
            .POST(HttpRequest.BodyPublishers.ofString(json, StandardCharsets.UTF_8))
            .timeout(timeout)
            .build()
        return exchange(request, serializer)
    }

    private suspend fun <T> exchange(request: HttpRequest, serializer: KSerializer<T>): T =
        withContext(Dispatchers.IO) {
            val response = try {
                http.send(request, HttpResponse.BodyHandlers.ofString(StandardCharsets.UTF_8))
            } catch (e: IOException) {
                throw EngineUnreachableException("${request.method()} ${request.uri().path}: ${e.message ?: e.javaClass.simpleName}", e)
            } catch (e: InterruptedException) {
                throw EngineUnreachableException("interrupted", e)
            }
            val body = response.body() ?: ""
            if (response.statusCode() !in 200..299) {
                val message = runCatching { GravitasJson.decodeFromString(ApiError.serializer(), body).error }.getOrNull()
                throw ApiException(response.statusCode(), message ?: "HTTP ${response.statusCode()}")
            }
            GravitasJson.decodeFromString(serializer, body)
        }

    override suspend fun health() = get("/health", Health.serializer())
    override suspend fun overview() = get("/overview", Overview.serializer())
    override suspend fun series(windowS: Double, maxPoints: Int) =
        get("/series?window_s=${num(windowS)}&max_points=$maxPoints", Series.serializer())
    override suspend fun instrument() = get("/instrument", Instrument.serializer())
    override suspend fun physics() = get("/physics", PhysicsSwitches.serializer())
    override suspend fun setPhysics(switches: Map<String, Boolean>) =
        post("/physics", PhysicsPatch(switches), PhysicsPatch.serializer(), PhysicsSwitches.serializer(), fastTimeout)

    override suspend fun earth(latDeg: Double?, lonDeg: Double?, altM: Double?): Earth {
        val q = listOfNotNull(
            latDeg?.let { "lat_deg=${num(it)}" },
            lonDeg?.let { "lon_deg=${num(it)}" },
            altM?.let { "alt_m=${num(it)}" },
        ).joinToString("&")
        return get(if (q.isEmpty()) "/earth" else "/earth?$q", Earth.serializer(), Duration.ofSeconds(20))
    }

    override suspend fun tides(hours: Int, stepS: Int) =
        get("/tides?hours=$hours&step_s=$stepS", Tides.serializer(), Duration.ofSeconds(30))
    override suspend fun anomalies() = get("/anomalies", Anomalies.serializer(), Duration.ofSeconds(20))
    override suspend fun runSurvey(durationS: Double, sampleRateHz: Double) =
        post("/anomalies/survey", SurveyRequest(durationS, sampleRateHz), SurveyRequest.serializer(), Anomalies.serializer())
    override suspend fun calibration() = get("/calibration", serializer<CalibrationReport?>(), Duration.ofSeconds(20))
    override suspend fun runCalibration(seed: Long?): CalibrationReport? =
        if (seed != null) post("/calibration/run", SeedRequest(seed), SeedRequest.serializer(), serializer<CalibrationReport?>())
        else post("/calibration/run", EmptyBody, EmptyBody.serializer(), serializer<CalibrationReport?>())
    override suspend fun uncertainty() = get("/uncertainty", UncertaintyBudget.serializer(), Duration.ofSeconds(20))
    override suspend fun runMonteCarlo(trials: Int, durationS: Double) =
        post("/uncertainty/monte-carlo", MonteCarloRequest(trials, durationS), MonteCarloRequest.serializer(), MonteCarloResult.serializer())
    override suspend fun allan(maxPoints: Int) = get("/allan?max_points=$maxPoints", Allan.serializer(), Duration.ofSeconds(30))
    override suspend fun experiments() = get("/experiments", ExperimentList.serializer())
    override suspend fun runExperiment(name: String, durationS: Double?, sampleRateHz: Double?): ExperimentResult {
        val path = "/experiments/" + URLEncoder.encode(name, StandardCharsets.UTF_8)
        return if (durationS != null && sampleRateHz != null)
            post(path, ExperimentRequest(durationS, sampleRateHz), ExperimentRequest.serializer(), ExperimentResult.serializer())
        else post(path, EmptyBody, EmptyBody.serializer(), ExperimentResult.serializer())
    }
    override suspend fun map() = get("/map", MapData.serializer(), Duration.ofSeconds(20))
    override suspend fun telemetry(n: Int) = get("/telemetry?n=$n", Telemetry.serializer())
    override suspend fun config() = get("/config", kotlinx.serialization.json.JsonObject.serializer())
    override suspend fun control(request: ControlRequest) =
        post("/control", request, ControlRequest.serializer(), Health.serializer(), Duration.ofSeconds(10))

    companion object {
        const val DEFAULT_ENGINE = "http://127.0.0.1:8765"

        /** Formats a query-string number without locale effects or exponent surprises. */
        fun num(v: Double): String =
            if (v == Math.rint(v) && kotlin.math.abs(v) < 1e15) v.toLong().toString()
            else v.toBigDecimal().stripTrailingZeros().toPlainString()

        fun isLoopback(url: String): Boolean = runCatching {
            val host = URI.create(url).host ?: return false
            host.equals("localhost", ignoreCase = true) || InetAddress.getByName(host).isLoopbackAddress
        }.getOrDefault(false)

        /**
         * Resolves the engine root from `--engine <url>` / `--engine=<url>`, then the
         * `GRAVITAS_ENGINE` environment variable, then [DEFAULT_ENGINE].
         */
        fun resolveEngine(args: Array<String>, env: Map<String, String> = System.getenv()): String {
            var fromArgs: String? = null
            var i = 0
            while (i < args.size) {
                val a = args[i]
                when {
                    a == "--engine" && i + 1 < args.size -> { fromArgs = args[i + 1]; i++ }
                    a.startsWith("--engine=") -> fromArgs = a.substringAfter("=")
                }
                i++
            }
            return (fromArgs ?: env["GRAVITAS_ENGINE"])?.takeIf { it.isNotBlank() } ?: DEFAULT_ENGINE
        }
    }
}

@kotlinx.serialization.Serializable
object EmptyBody
