package org.gravitas.console.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.unit.dp
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject
import org.gravitas.console.api.ControlRequest
import org.gravitas.console.api.MapData
import org.gravitas.console.api.TelemetryFrame
import org.gravitas.console.api.toArr
import org.gravitas.console.state.ConsoleStore
import org.gravitas.console.units.Fmt
import org.gravitas.console.units.GravityUnit
import org.gravitas.console.ui.chart.AxisMath
import org.gravitas.console.ui.chart.AxisRange
import org.gravitas.console.ui.chart.HeatMap
import org.gravitas.console.ui.chart.drawColourScale
import org.gravitas.console.ui.chart.drawNoData
import org.gravitas.console.ui.chart.orientGrid
import org.gravitas.console.ui.chart.text
import org.gravitas.console.ui.components.ActionButton
import org.gravitas.console.ui.components.Caption
import org.gravitas.console.ui.components.Col
import org.gravitas.console.ui.components.DataTable
import org.gravitas.console.ui.components.InputField
import org.gravitas.console.ui.components.KeyValue
import org.gravitas.console.ui.components.Panel
import org.gravitas.console.ui.components.Segmented
import org.gravitas.console.ui.theme.Palette
import org.gravitas.console.ui.theme.Type
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/* ============================================================== MAP */

private enum class MapExtent { REGION, WORLD }

@Composable
fun MapScreen(store: ConsoleStore) {
    val u = store.unit
    val m = if (store.connected) store.map else null
    var extent by remember { mutableStateOf(MapExtent.REGION) }
    ScreenBody(
        "Map", "Instrument location, modelled gravity field and survey path (/map). No coastline data is drawn.",
        trailing = { LabelledRow("Extent") { Segmented(MapExtent.entries, extent, { it.name.lowercase().replaceFirstChar { c -> c.uppercase() } }, { extent = it }) } },
    ) {
        if (!store.connected) DisconnectedNotice(store)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Panel("Equirectangular · gravity grid", Modifier.weight(1.6f)) {
                EquirectangularMap(m, u, extent, Modifier.fillMaxWidth().height(430.dp))
                Caption("Plate carrée (1° lon = 1° lat). Shading: gravity_grid g in ${u.symbol}. Red cross: instrument. Amber: survey path.")
            }
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Panel("Earth view · orthographic graticule") {
                    OrthographicView(m, Modifier.fillMaxWidth().height(300.dp))
                }
                Panel("Instrument") {
                    val i = m?.instrument
                    KeyValue("Latitude", Fmt.fixed(i?.latitudeDeg, 5), "°", labelWidth = 120.dp)
                    KeyValue("Longitude", Fmt.fixed(i?.longitudeDeg, 5), "°", labelWidth = 120.dp)
                    KeyValue("Altitude", Fmt.fixed(i?.altitudeM, 2), "m", labelWidth = 120.dp)
                    KeyValue("Gravity", Fmt.gravity(i?.gravityMps2, u), u.symbol, labelWidth = 120.dp)
                    KeyValue("Uncertainty", "± " + Fmt.small(i?.uncertaintyMps2, u), u.symbol, labelWidth = 120.dp)
                    KeyValue("Survey points", m?.surveyPath?.size?.toString() ?: Fmt.DASH, "", labelWidth = 120.dp)
                }
            }
        }
        Panel("Local anomaly grid and survey path") {
            val ag = m?.anomalyGrid
            val path = m?.surveyPath.orEmpty()
            HeatMap(
                ag?.lonDeg.toArr(), ag?.latDeg.toArr(), ag?.anomalyMps2.orEmpty().map { it.toArr() },
                Modifier.fillMaxWidth().height(380.dp), xLabel = "longitude [°]", yLabel = "latitude [°]", valueLabel = "Δg [${u.symbol}]",
                toDisplay = { u.fromMps2(it) },
                overlayX = DoubleArray(path.size) { path[it].longitudeDeg ?: Double.NaN },
                overlayY = DoubleArray(path.size) { path[it].latitudeDeg ?: Double.NaN },
                overlayLabel = "survey path",
                marker = m?.instrument?.let { i -> if (i.longitudeDeg != null && i.latitudeDeg != null) i.longitudeDeg to i.latitudeDeg else null },
                markerLabel = "instrument",
            )
            Caption("SYNTHETIC GEOPHYSICAL MODEL — anomaly_grid from the engine's buried-body model.")
        }
    }
}

@Composable
private fun EquirectangularMap(m: MapData?, u: GravityUnit, extent: MapExtent, modifier: Modifier) {
    val tm = rememberTextMeasurer()
    val gg = m?.gravityGrid
    val prepared = remember(gg) { gg?.let { orientGrid(it.lonDeg.toArr(), it.latDeg.toArr(), it.gMps2.orEmpty().map { r -> r.toArr() }) } }
    Canvas(modifier) {
        if (m == null) { drawNoData(tm, "NO ENGINE DATA"); return@Canvas }
        // Extent: whole Earth, or the gravity grid / instrument neighbourhood.
        var lon0 = -180.0; var lon1 = 180.0; var lat0 = -90.0; var lat1 = 90.0
        if (extent == MapExtent.REGION) {
            val lons = ArrayList<Double>(); val lats = ArrayList<Double>()
            prepared?.let { (gx, gy, _) -> lons += gx.filter { it.isFinite() }; lats += gy.filter { it.isFinite() } }
            m.instrument?.longitudeDeg?.let { lons += it }; m.instrument?.latitudeDeg?.let { lats += it }
            m.surveyPath.orEmpty().forEach { p -> p.longitudeDeg?.let { lons += it }; p.latitudeDeg?.let { lats += it } }
            if (lons.isNotEmpty() && lats.isNotEmpty()) {
                val padLon = max((lons.max() - lons.min()) * 0.12, 0.5); val padLat = max((lats.max() - lats.min()) * 0.12, 0.5)
                lon0 = max(-180.0, lons.min() - padLon); lon1 = min(180.0, lons.max() + padLon)
                lat0 = max(-90.0, lats.min() - padLat); lat1 = min(90.0, lats.max() + padLat)
            }
        }
        val legendW = 96f; val labelH = 16f; val labelW = 44f
        val availW = size.width - legendW - labelW; val availH = size.height - labelH * 2
        val scale = min(availW / (lon1 - lon0), availH / (lat1 - lat0)).toFloat()
        val w = ((lon1 - lon0) * scale).toFloat(); val h = ((lat1 - lat0) * scale).toFloat()
        val rect = Rect(labelW, labelH, labelW + w, labelH + h)
        fun px(lon: Double) = (rect.left + (lon - lon0) * scale).toFloat()
        fun py(lat: Double) = (rect.bottom - (lat - lat0) * scale).toFloat()
        drawRect(Palette.Paper, rect.topLeft, rect.size)
        // gravity grid shading
        var vr: AxisRange? = null
        if (prepared != null) {
            val (gx, gy, cells) = prepared
            val vals = cells.flatMap { r -> r.filter { it.isFinite() }.map { u.fromMps2(it) } }
            if (vals.isNotEmpty()) {
                vr = AxisMath.padded(vals.min(), vals.max(), 0.0)
                clipRect(rect.left, rect.top, rect.right, rect.bottom) {
                    for (r in gy.indices) for (c in gx.indices) {
                        val v = cells[r][c]; if (!v.isFinite()) continue
                        val dLon = if (gx.size > 1) abs(gx[min(c + 1, gx.size - 1)] - gx[max(c - 1, 0)]) / (if (c == 0 || c == gx.size - 1) 1 else 2) else 1.0
                        val dLat = if (gy.size > 1) abs(gy[min(r + 1, gy.size - 1)] - gy[max(r - 1, 0)]) / (if (r == 0 || r == gy.size - 1) 1 else 2) else 1.0
                        val x0 = px(gx[c] - dLon / 2); val y0 = py(gy[r] + dLat / 2)
                        drawRect(
                            Palette.sequential(AxisMath.fraction(u.fromMps2(v), vr!!, false)),
                            Offset(x0, y0), Size((dLon * scale).toFloat() + 0.6f, (dLat * scale).toFloat() + 0.6f),
                        )
                    }
                }
            }
        }
        // graticule
        val step = AxisMath.niceStep(max(lon1 - lon0, lat1 - lat0), 8).let { s -> listOf(0.1, 0.25, 0.5, 1.0, 2.0, 5.0, 10.0, 15.0, 30.0).firstOrNull { it >= s } ?: 30.0 }
        var g = kotlin.math.ceil(lon0 / step) * step
        while (g <= lon1 + 1e-9) {
            val x = px(g)
            drawLine(if (abs(g) < 1e-9) Palette.RuleStrong else Palette.Rule, Offset(x, rect.top), Offset(x, rect.bottom), 1f)
            text(tm, AxisMath.linearLabel(g, step) + "°", x, rect.bottom + 2f, Type.Axis, alignX = 0.5f)
            g += step
        }
        g = kotlin.math.ceil(lat0 / step) * step
        while (g <= lat1 + 1e-9) {
            val y = py(g)
            drawLine(if (abs(g) < 1e-9) Palette.RuleStrong else Palette.Rule, Offset(rect.left, y), Offset(rect.right, y), 1f)
            text(tm, AxisMath.linearLabel(g, step) + "°", rect.left - 4f, y, Type.Axis, alignX = 1f, alignY = 0.5f)
            g += step
        }
        drawRect(Palette.RuleStrong, rect.topLeft, rect.size, style = Stroke(1f))
        // survey path + instrument
        clipRect(rect.left, rect.top, rect.right, rect.bottom) {
            val p = Path(); var pen = false
            for (pt in m.surveyPath.orEmpty()) {
                val la = pt.latitudeDeg; val lo = pt.longitudeDeg
                if (la == null || lo == null) { pen = false; continue }
                if (pen) p.lineTo(px(lo), py(la)) else { p.moveTo(px(lo), py(la)); pen = true }
            }
            drawPath(p, Palette.Amber, style = Stroke(2f))
            val i = m.instrument
            if (i?.latitudeDeg != null && i.longitudeDeg != null) {
                val c = Offset(px(i.longitudeDeg), py(i.latitudeDeg))
                drawCircle(Palette.Red, 5f, c, style = Stroke(1.8f))
                drawLine(Palette.Red, Offset(c.x - 11f, c.y), Offset(c.x + 11f, c.y), 1.2f)
                drawLine(Palette.Red, Offset(c.x, c.y - 11f), Offset(c.x, c.y + 11f), 1.2f)
            }
        }
        text(tm, "lat [°] / lon [°]", 0f, 0f, Type.Axis.copy(color = Palette.GraphiteSoft))
        vr?.let { drawColourScale(tm, Rect(rect.right + 18f, rect.top + 14f, rect.right + 32f, rect.bottom), it, "g [${u.symbol}]") }
    }
}

@Composable
private fun OrthographicView(m: MapData?, modifier: Modifier) {
    val tm = rememberTextMeasurer()
    Canvas(modifier) {
        val i = m?.instrument
        val lat0d = i?.latitudeDeg; val lon0d = i?.longitudeDeg
        if (m == null || lat0d == null || lon0d == null) { drawNoData(tm, "NO ENGINE DATA"); return@Canvas }
        val r = min(size.width, size.height) / 2f - 14f
        val cx = size.width / 2f; val cy = size.height / 2f
        val phi0 = Math.toRadians(lat0d); val lam0 = Math.toRadians(lon0d)
        /** Orthographic projection centred on the instrument; null when on the far hemisphere. */
        fun proj(latDeg: Double, lonDeg: Double): Offset? {
            val phi = Math.toRadians(latDeg); val dl = Math.toRadians(lonDeg) - lam0
            val cosC = sin(phi0) * sin(phi) + cos(phi0) * cos(phi) * cos(dl)
            if (cosC < 0) return null
            val x = cos(phi) * sin(dl)
            val y = cos(phi0) * sin(phi) - sin(phi0) * cos(phi) * cos(dl)
            return Offset(cx + (x * r).toFloat(), cy - (y * r).toFloat())
        }
        fun polyline(points: List<Pair<Double, Double>>, color: androidx.compose.ui.graphics.Color, width: Float) {
            val p = Path(); var pen = false
            for ((la, lo) in points) {
                val o = proj(la, lo)
                if (o == null) { pen = false; continue }
                if (pen) p.lineTo(o.x, o.y) else { p.moveTo(o.x, o.y); pen = true }
            }
            drawPath(p, color, style = Stroke(width))
        }
        drawCircle(Palette.Panel, r, Offset(cx, cy))
        for (lat in -75..75 step 15) polyline((-180..180 step 2).map { lat.toDouble() to it.toDouble() }, if (lat == 0) Palette.RuleStrong else Palette.Rule, 1f)
        for (lon in -180 until 180 step 15) polyline((-90..90 step 2).map { it.toDouble() to lon.toDouble() }, if (lon == 0) Palette.RuleStrong else Palette.Rule, 1f)
        drawCircle(Palette.Steel, r, Offset(cx, cy), style = Stroke(1.2f))
        polyline(m.surveyPath.orEmpty().mapNotNull { p -> if (p.latitudeDeg != null && p.longitudeDeg != null) p.latitudeDeg to p.longitudeDeg else null }, Palette.Amber, 2.5f)
        proj(lat0d, lon0d)?.let { c ->
            drawCircle(Palette.Red, 4.5f, c, style = Stroke(1.8f))
            drawLine(Palette.Red, Offset(c.x - 10f, c.y), Offset(c.x + 10f, c.y), 1.2f)
            drawLine(Palette.Red, Offset(c.x, c.y - 10f), Offset(c.x, c.y + 10f), 1.2f)
            text(tm, "${Fmt.fixed(lat0d, 2)}°, ${Fmt.fixed(lon0d, 2)}°", c.x + 8f, c.y + 6f, Type.Axis.copy(color = Palette.Red))
        }
        text(tm, "graticule 15° · centred on instrument", 0f, size.height - 12f, Type.Axis)
    }
}

/* ============================================================== TELEMETRY */

@Composable
fun TelemetryScreen(store: ConsoleStore) {
    val u = store.unit
    val h = if (store.connected) store.health else null
    val frames = if (store.connected) store.telemetry?.frames else null
    var seed by remember { mutableStateOf("42") }
    var speed by remember { mutableStateOf("") }
    ScreenBody("Telemetry", "Recent telemetry frames (/telemetry), simulation control (/control) and reproducibility manifest (/config).") {
        if (!store.connected) DisconnectedNotice(store)
        Panel("Simulation control") {
            Row(verticalAlignment = Alignment.Bottom) {
                ActionButton("Pause", { store.control(ControlRequest.pause()) }, enabled = store.connected && h?.running != false)
                Spacer(Modifier.width(6.dp))
                ActionButton("Resume", { store.control(ControlRequest.resume()) }, enabled = store.connected && h?.running != true)
                Spacer(Modifier.width(20.dp))
                InputField("Reset seed", seed, { seed = it }, width = 80.dp)
                Spacer(Modifier.width(6.dp))
                ActionButton("Reset", { store.control(ControlRequest.reset(seed.trim().toLongOrNull())) }, enabled = store.connected, primary = false, danger = true)
                Spacer(Modifier.width(20.dp))
                InputField("Speed", speed, { speed = it }, "× real time", width = 80.dp)
                Spacer(Modifier.width(6.dp))
                ActionButton("Set speed", { speed.toDoubleOrNull()?.let { store.control(ControlRequest.setSpeed(it)) } }, enabled = store.connected && speed.toDoubleOrNull() != null, primary = false)
                Spacer(Modifier.width(10.dp))
                for (p in listOf(1.0, 10.0, 60.0, 600.0)) {
                    ActionButton("×" + Fmt.sig(p, 3).removeSuffix(".0").removeSuffix(".00"), { store.control(ControlRequest.setSpeed(p)) }, enabled = store.connected, primary = h?.speed == p)
                    Spacer(Modifier.width(4.dp))
                }
            }
            Caption("Current: ${when (h?.running) { true -> "RUNNING"; false -> "PAUSED"; null -> Fmt.DASH }} · speed ×${Fmt.sig(h?.speed, 3)} · sim time ${Fmt.simTime(h?.simTimeS)}")
        }
        Panel("Frames (most recent first)", trailing = {
            LabelledRow("Frames") { Segmented(listOf(20, 50, 200), store.telemetryN, { "$it" }, { store.selectTelemetryN(it) }) }
        }) {
            val us = u.symbol
            val cols = listOf(
                Col("SIM TIME [s]", 92.dp), Col("TIMESTAMP (UTC)", 190.dp, false), Col("STATUS", 86.dp, false, false),
                Col("TRUE g [$us]", 128.dp), Col("RAW [$us]", 128.dp), Col("FILTERED [$us]", 128.dp), Col("CALIBRATED [$us]", 128.dp),
                Col("CORRECTED [$us]", 128.dp), Col("TIDE [$us]", 90.dp), Col("LUNAR [$us]", 90.dp), Col("SOLAR [$us]", 90.dp),
                Col("ANOMALY [$us]", 96.dp), Col("BIAS [$us]", 90.dp), Col("UNC. [$us]", 84.dp), Col("TEMP [°C]", 80.dp),
                Col("VIBR. [µm/s²]", 92.dp), Col("POSITION [nm]", 96.dp), Col("F_FB [nN]", 90.dp), Col("ADC [LSB]", 92.dp),
                Col("LAT [°]", 84.dp), Col("LON [°]", 84.dp), Col("ALT [m]", 74.dp),
            )
            DataTable(
                cols, frames.orEmpty().asReversed().map { telemetryRow(it, u) }, scrollable = true,
                emptyText = if (frames == null) "NO ENGINE DATA" else "No frames",
            )
        }
        Panel("Reproducibility manifest (/config)") {
            val cfg = if (store.connected) store.config else null
            DataTable(
                listOf(Col("KEY", 340.dp, false, false), Col("VALUE", 520.dp, false)),
                cfg?.let { flatten(it) }.orEmpty().map { listOf(it.first, it.second) },
                emptyText = if (cfg == null) "NO ENGINE DATA" else "Empty manifest",
            )
        }
    }
}

private fun telemetryRow(f: TelemetryFrame, u: GravityUnit): List<String> = listOf(
    Fmt.fixed(f.simTimeS, 2), f.timestamp ?: Fmt.DASH, f.status ?: Fmt.DASH,
    Fmt.gravity(f.trueGravityMps2, u), Fmt.gravity(f.rawMeasurementMps2, u), Fmt.gravity(f.filteredMps2, u),
    Fmt.gravity(f.calibratedMps2, u), Fmt.gravity(f.correctedMeasurementMps2, u),
    Fmt.small(f.tidalComponentMps2, u), Fmt.small(f.lunarComponentMps2, u), Fmt.small(f.solarComponentMps2, u),
    Fmt.small(f.anomalyComponentMps2, u), Fmt.small(f.biasMps2, u), Fmt.small(f.uncertaintyMps2, u),
    Fmt.fixed(f.temperatureC, 3), Fmt.fixed(f.vibrationMps2?.times(1e6), 3), Fmt.fixed(f.proofMassPositionM?.times(1e9), 4),
    Fmt.fixed(f.feedbackForceN?.times(1e9), 4), Fmt.integer(f.adcCode),
    Fmt.fixed(f.latitudeDeg, 5), Fmt.fixed(f.longitudeDeg, 5), Fmt.fixed(f.altitudeM, 1),
)

/** Flattens a JSON object into dotted key paths, e.g. `earth_model.name = GRS80`. */
internal fun flatten(o: JsonObject, prefix: String = ""): List<Pair<String, String>> =
    o.entries.flatMap { (k, v) ->
        val key = if (prefix.isEmpty()) k else "$prefix.$k"
        when (v) {
            is JsonObject -> if (v.isEmpty()) listOf(key to "{}") else flatten(v, key)
            is JsonArray -> listOf(key to jsonText(v as JsonElement))
            else -> listOf(key to jsonText(v))
        }
    }

