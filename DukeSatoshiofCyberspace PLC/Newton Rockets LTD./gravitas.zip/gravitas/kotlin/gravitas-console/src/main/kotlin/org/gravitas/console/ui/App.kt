package org.gravitas.console.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.Divider
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.gravitas.console.state.ConsoleStore
import org.gravitas.console.state.Screen
import org.gravitas.console.units.Fmt
import org.gravitas.console.units.GravityUnit
import org.gravitas.console.ui.components.ActionButton
import org.gravitas.console.ui.components.Segmented
import org.gravitas.console.ui.components.Severity
import org.gravitas.console.ui.components.StatusBadge
import org.gravitas.console.ui.screens.AllanScreen
import org.gravitas.console.ui.screens.AnomaliesScreen
import org.gravitas.console.ui.screens.CalibrationScreen
import org.gravitas.console.ui.screens.EarthScreen
import org.gravitas.console.ui.screens.ExperimentsScreen
import org.gravitas.console.ui.screens.GravityScreen
import org.gravitas.console.ui.screens.InstrumentScreen
import org.gravitas.console.ui.screens.MapScreen
import org.gravitas.console.ui.screens.OverviewScreen
import org.gravitas.console.ui.screens.PhysicsInspector
import org.gravitas.console.ui.screens.SignalScreen
import org.gravitas.console.ui.screens.TelemetryScreen
import org.gravitas.console.ui.screens.TidesScreen
import org.gravitas.console.ui.screens.UncertaintyScreen
import org.gravitas.console.ui.theme.GravitasTheme
import org.gravitas.console.ui.theme.Palette
import org.gravitas.console.ui.theme.Type

@Composable
fun ConsoleApp(store: ConsoleStore) {
    GravitasTheme {
        Column(Modifier.fillMaxSize().background(Palette.Paper)) {
            TopBar(store)
            Row(Modifier.fillMaxSize()) {
                NavigationSidebar(store)
                Box(Modifier.weight(1f).fillMaxHeight()) {
                    ScreenContent(store)
                }
                if (store.inspectorOpen) {
                    Column(
                        Modifier.width(330.dp).fillMaxHeight().background(Palette.Panel)
                            .border(1.dp, Palette.Rule).verticalScroll(rememberScrollState()).padding(16.dp),
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("PHYSICS INSPECTOR", style = Type.Section, modifier = Modifier.weight(1f))
                            ActionButton("Close", { store.inspectorOpen = false }, primary = false)
                        }
                        Divider(color = Palette.Rule, modifier = Modifier.padding(vertical = 8.dp))
                        PhysicsInspector(store)
                    }
                }
            }
        }
    }
}

@Composable
private fun ScreenContent(store: ConsoleStore) {
    when (store.screen) {
        Screen.OVERVIEW -> OverviewScreen(store)
        Screen.GRAVITY -> GravityScreen(store)
        Screen.INSTRUMENT -> InstrumentScreen(store)
        Screen.SIGNAL -> SignalScreen(store)
        Screen.EARTH -> EarthScreen(store)
        Screen.TIDES -> TidesScreen(store)
        Screen.ANOMALIES -> AnomaliesScreen(store)
        Screen.CALIBRATION -> CalibrationScreen(store)
        Screen.UNCERTAINTY -> UncertaintyScreen(store)
        Screen.ALLAN -> AllanScreen(store)
        Screen.EXPERIMENTS -> ExperimentsScreen(store)
        Screen.MAP -> MapScreen(store)
        Screen.TELEMETRY -> TelemetryScreen(store)
    }
}

@Composable
private fun TopBar(store: ConsoleStore) {
    val h = store.health
    Column(Modifier.fillMaxWidth().background(Palette.Panel)) {
        Row(
            Modifier.fillMaxWidth().height(52.dp).padding(horizontal = 18.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column {
                Text("GRAVITAS", style = Type.Title.copy(color = Palette.Navy, letterSpacing = 4.sp, fontSize = 17.sp))
                Text("ENGINEERING CONSOLE · EARTH-GRAVITY DIGITAL TWIN", style = Type.Label.copy(fontSize = 9.sp))
            }
            Spacer(Modifier.width(28.dp))
            TopField("ENGINE", store.api.engineUrl)
            Spacer(Modifier.width(14.dp))
            if (store.connected) StatusBadge("CONNECTED", Severity.OK)
            else StatusBadge(if (store.everConnected) "DISCONNECTED" else "NO ENGINE", Severity.FAULT)
            Spacer(Modifier.width(22.dp))
            TopField("SIM TIME", Fmt.simTime(h?.simTimeS))
            Spacer(Modifier.width(18.dp))
            TopField("SPEED", h?.speed?.let { "×" + Fmt.sig(it, 3) } ?: Fmt.DASH)
            Spacer(Modifier.width(18.dp))
            TopField("STATE", when (h?.running) { true -> "RUNNING"; false -> "PAUSED"; null -> Fmt.DASH })
            Spacer(Modifier.width(18.dp))
            TopField("ENGINE SW", h?.softwareVersion ?: Fmt.DASH)
            Spacer(Modifier.weight(1f))
            Text("UNIT", style = Type.Label)
            Spacer(Modifier.width(8.dp))
            Segmented(GravityUnit.entries, store.unit, { it.symbol }, { store.unit = it })
            Spacer(Modifier.width(14.dp))
            ActionButton(
                if (store.inspectorOpen) "Inspector ▸" else "◂ Physics Inspector",
                { store.inspectorOpen = !store.inspectorOpen }, primary = store.inspectorOpen,
            )
        }
        if (!store.connected) {
            Row(Modifier.fillMaxWidth().background(Palette.RedLight).padding(horizontal = 18.dp, vertical = 5.dp)) {
                Text("NO ENGINE DATA", style = Type.Label.copy(color = Palette.Red, fontWeight = FontWeight.Bold))
                Spacer(Modifier.width(12.dp))
                Text(
                    "Waiting for the GRAVITAS engine at ${store.api.engineUrl}/api/v1 — start it with `gravitas serve`." +
                        (store.lastError?.let { "  Last error: $it" } ?: ""),
                    style = Type.BodySmall.copy(color = Palette.Red), maxLines = 1,
                )
            }
        } else if (store.message != null) {
            Row(Modifier.fillMaxWidth().background(Palette.AmberLight).padding(horizontal = 18.dp, vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(store.message ?: "", style = Type.BodySmall.copy(color = Palette.Amber), modifier = Modifier.weight(1f), maxLines = 1)
                Text("DISMISS", style = Type.Label.copy(color = Palette.Amber), modifier = Modifier.clickable { store.message = null })
            }
        }
        Divider(color = Palette.RuleStrong, thickness = 1.dp)
    }
}

@Composable
private fun TopField(label: String, value: String) {
    Column {
        Text(label, style = Type.Label.copy(fontSize = 9.sp))
        Text(value, style = Type.ValueSmall.copy(fontSize = 12.5.sp, color = if (value == Fmt.DASH) Palette.SteelLight else Palette.Graphite), maxLines = 1)
    }
}

@Composable
private fun NavigationSidebar(store: ConsoleStore) {
    Column(Modifier.width(176.dp).fillMaxHeight().background(Palette.Panel).border(1.dp, Palette.Rule).padding(vertical = 10.dp)) {
        Screen.entries.forEachIndexed { i, s ->
            val sel = store.screen == s
            Row(
                Modifier.fillMaxWidth().height(34.dp).background(if (sel) Palette.NavyLight else Color.Transparent)
                    .clickable { store.selectScreen(s) },
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Box(Modifier.width(3.dp).fillMaxHeight().background(if (sel) Palette.Navy else Color.Transparent))
                Spacer(Modifier.width(12.dp))
                Text(String.format("%02d", i + 1), style = Type.Axis.copy(color = if (sel) Palette.Navy else Palette.SteelLight))
                Spacer(Modifier.width(10.dp))
                Text(
                    s.name, style = Type.Label.copy(
                        fontSize = 11.sp, color = if (sel) Palette.Navy else Palette.GraphiteSoft,
                        fontWeight = if (sel) FontWeight.Bold else FontWeight.SemiBold,
                    ),
                )
            }
        }
        Spacer(Modifier.weight(1f))
        Column(Modifier.padding(horizontal = 14.dp)) {
            Divider(color = Palette.Rule, modifier = Modifier.padding(bottom = 8.dp))
            Text("All values are produced by the engine. The console performs unit conversion and plotting only.", style = Type.BodySmall.copy(fontSize = 9.5.sp, color = Palette.Steel))
        }
    }
}
