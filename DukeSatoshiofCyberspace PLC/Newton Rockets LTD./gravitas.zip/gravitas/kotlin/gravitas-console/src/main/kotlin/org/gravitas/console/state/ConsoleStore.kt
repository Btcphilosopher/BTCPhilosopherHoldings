package org.gravitas.console.state

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.serialization.json.JsonObject
import org.gravitas.console.api.Allan
import org.gravitas.console.api.Anomalies
import org.gravitas.console.api.ApiException
import org.gravitas.console.api.CalibrationReport
import org.gravitas.console.api.ControlRequest
import org.gravitas.console.api.EngineUnreachableException
import org.gravitas.console.api.Earth
import org.gravitas.console.api.ExperimentList
import org.gravitas.console.api.ExperimentResult
import org.gravitas.console.api.GravitasApi
import org.gravitas.console.api.Health
import org.gravitas.console.api.Instrument
import org.gravitas.console.api.MapData
import org.gravitas.console.api.MonteCarloResult
import org.gravitas.console.api.Overview
import org.gravitas.console.api.PhysicsSwitches
import org.gravitas.console.api.Series
import org.gravitas.console.api.Telemetry
import org.gravitas.console.api.Tides
import org.gravitas.console.api.UncertaintyBudget
import org.gravitas.console.units.GravityUnit

enum class Screen(val title: String) {
    OVERVIEW("Overview"), GRAVITY("Gravity"), INSTRUMENT("Instrument"), SIGNAL("Signal"),
    EARTH("Earth"), TIDES("Tides"), ANOMALIES("Anomalies"), CALIBRATION("Calibration"),
    UNCERTAINTY("Uncertainty"), ALLAN("Allan"), EXPERIMENTS("Experiments"), MAP("Map"),
    TELEMETRY("Telemetry"),
}

/** Signal windows supported by the console (API.md: 1, 10, 60, 600, 3600, 86400 s). */
enum class SeriesWindow(val seconds: Double, val label: String) {
    S1(1.0, "1 s"), S10(10.0, "10 s"), M1(60.0, "1 min"), M10(600.0, "10 min"), H1(3600.0, "1 h"), H24(86400.0, "24 h"),
}

/** Tide spans offered by the console, with a step chosen to keep ≤ ~750 points. */
enum class TideSpan(val hours: Int, val stepS: Int) { H24(24, 300), H48(48, 600), H168(168, 1800), H720(720, 3600) }

/**
 * Observable console state. Every number shown by the UI is read from here and every value
 * here came from the engine. On loss of connection all engine data is cleared so the UI shows
 * "NO ENGINE DATA"/"—" rather than stale or invented values.
 *
 * Polling (when [start]ed):
 *  * fast loop, 4 Hz: /health, /overview, /series (current window) and, on INSTRUMENT, /instrument;
 *  * slow loop, 1 Hz tick: /physics every 2 s, plus screen-specific heavier endpoints
 *    (/telemetry 1 s; /allan, /uncertainty, /map 5 s; /tides, /anomalies, /calibration 10 s;
 *    /earth and /experiments on demand / first visit; /config once).
 */
class ConsoleStore(val api: GravitasApi, private val scope: CoroutineScope) {

    // ------------------------------------------------------------------ connection
    var connected by mutableStateOf(false); private set
    var everConnected by mutableStateOf(false); private set
    var lastError by mutableStateOf<String?>(null); private set
    var message by mutableStateOf<String?>(null)

    // ------------------------------------------------------------------ presentation state
    var screen by mutableStateOf(Screen.OVERVIEW); private set
    var unit by mutableStateOf(GravityUnit.DEFAULT)
    var inspectorOpen by mutableStateOf(false)
    var window by mutableStateOf(SeriesWindow.M1); private set
    var tideSpan by mutableStateOf(TideSpan.H48); private set
    var telemetryN by mutableStateOf(50); private set

    // ------------------------------------------------------------------ engine data
    var health by mutableStateOf<Health?>(null)
    var overview by mutableStateOf<Overview?>(null)
    var series by mutableStateOf<Series?>(null)
    var instrument by mutableStateOf<Instrument?>(null)
    var physics by mutableStateOf<PhysicsSwitches?>(null)
    var earth by mutableStateOf<Earth?>(null)
    var tides by mutableStateOf<Tides?>(null)
    var anomalies by mutableStateOf<Anomalies?>(null)
    var calibration by mutableStateOf<CalibrationReport?>(null)
    var calibrationChecked by mutableStateOf(false)
    var uncertainty by mutableStateOf<UncertaintyBudget?>(null)
    var monteCarlo by mutableStateOf<MonteCarloResult?>(null)
    var allan by mutableStateOf<Allan?>(null)
    var experiments by mutableStateOf<ExperimentList?>(null)
    val experimentResults = mutableStateMapOf<String, ExperimentResult>()
    var map by mutableStateOf<MapData?>(null)
    var telemetry by mutableStateOf<Telemetry?>(null)
    var config by mutableStateOf<JsonObject?>(null)

    /** Long-running operations in flight (e.g. "survey", "calibration", "mc", "exp:static"). */
    val busy = mutableStateMapOf<String, Boolean>()

    private var jobs: List<Job> = emptyList()
    private val lastFetch = HashMap<String, Long>()

    // ------------------------------------------------------------------ lifecycle
    fun start() {
        if (jobs.isNotEmpty()) return
        jobs = listOf(
            scope.launch { while (isActive) { pollFast(); delay(250) } },
            scope.launch { while (isActive) { pollSlow(); delay(1000) } },
        )
    }

    fun stop() { jobs.forEach { it.cancel() }; jobs = emptyList() }

    fun selectScreen(s: Screen) {
        screen = s
        scope.launch { pollScreen(force = true) }
    }

    fun selectWindow(w: SeriesWindow) {
        window = w
        series = null
        scope.launch { fetch("series") { api.series(w.seconds) }?.let { series = it } }
    }

    fun selectTideSpan(t: TideSpan) {
        tideSpan = t
        scope.launch { fetch("tides") { api.tides(t.hours, t.stepS) }?.let { tides = it } }
    }

    fun selectTelemetryN(n: Int) {
        telemetryN = n
        scope.launch { fetch("telemetry") { api.telemetry(n) }?.let { telemetry = it } }
    }

    // ------------------------------------------------------------------ polling
    suspend fun pollFast() {
        val h = fetch("health") { api.health() } ?: return
        health = h
        fetch("overview") { api.overview() }?.let { overview = it }
        val needSeries = screen in setOf(Screen.OVERVIEW, Screen.SIGNAL)
        // Long windows change slowly; refresh them at ≤ 0.5 Hz.
        val seriesPeriod = if (window.seconds >= 3600) 2000L else 0L
        if (needSeries && due("series", seriesPeriod)) fetch("series") { api.series(window.seconds) }?.let { series = it }
        if (screen == Screen.INSTRUMENT) fetch("instrument") { api.instrument() }?.let { instrument = it }
    }

    suspend fun pollSlow() {
        if (!connected) return
        if (due("physics", 2000)) fetch("physics") { api.physics() }?.let { physics = it }
        pollScreen(force = false)
    }

    private suspend fun pollScreen(force: Boolean) {
        if (!connected && !force) return
        when (screen) {
            Screen.GRAVITY -> if (earth == null || force) loadEarth(null, null, null)
            Screen.EARTH -> if (earth == null) loadEarth(null, null, null)
            Screen.TIDES -> if (force || due("tides", 10_000)) fetch("tides") { api.tides(tideSpan.hours, tideSpan.stepS) }?.let { tides = it }
            Screen.ANOMALIES -> if (force || due("anomalies", 10_000)) fetch("anomalies") { api.anomalies() }?.let { mergeAnomalies(it) }
            Screen.CALIBRATION -> if (force || due("calibration", 10_000)) {
                if (busy["calibration"] != true) fetch("calibration") { api.calibration() }.also { calibrationChecked = true }?.let { calibration = it }
            }
            Screen.UNCERTAINTY -> if (force || due("uncertainty", 5000)) fetch("uncertainty") { api.uncertainty() }?.let { uncertainty = it }
            Screen.ALLAN -> if (force || due("allan", 5000)) fetch("allan") { api.allan(60) }?.let { allan = it }
            Screen.EXPERIMENTS -> if (experiments == null) fetch("experiments") { api.experiments() }?.let { experiments = it }
            Screen.MAP -> if (force || due("map", 5000)) fetch("map") { api.map() }?.let { map = it }
            Screen.TELEMETRY -> {
                if (force || due("telemetry", 1000)) fetch("telemetry") { api.telemetry(telemetryN) }?.let { telemetry = it }
                if (config == null || force) fetch("config") { api.config() }?.let { config = it }
            }
            Screen.INSTRUMENT -> if (force) fetch("instrument") { api.instrument() }?.let { instrument = it }
            Screen.OVERVIEW, Screen.SIGNAL -> if (force) fetch("series") { api.series(window.seconds) }?.let { series = it }
        }
    }

    /** A GET /anomalies without a survey must not erase a survey we already ran this session. */
    private fun mergeAnomalies(a: Anomalies) {
        val prev = anomalies?.survey
        anomalies = if (a.survey == null && prev != null) a.copy(survey = prev) else a
    }

    private fun due(key: String, periodMs: Long): Boolean {
        val now = System.currentTimeMillis()
        val last = lastFetch[key] ?: 0L
        return if (now - last >= periodMs) { lastFetch[key] = now; true } else false
    }

    /**
     * Runs one API call. Connection failures mark the engine disconnected and clear all
     * engine data; HTTP errors are reported in [message] without disconnecting.
     */
    private suspend fun <T> fetch(what: String, block: suspend () -> T): T? = try {
        val r = block()
        if (!connected) { connected = true; everConnected = true; lastError = null }
        r
    } catch (e: CancellationException) {
        throw e
    } catch (e: EngineUnreachableException) {
        if (e.cause is java.net.http.HttpTimeoutException && longRunInFlight()) {
            // A single-threaded engine may not answer polls while it runs a long experiment;
            // that is "busy", not "disconnected". No values are invented meanwhile.
            message = "Engine busy (${busy.keys.joinToString()}) — live polling delayed"
        } else markDisconnected(e.message)
        null
    } catch (e: ApiException) {
        message = "$what: HTTP ${e.status} — ${e.message}"; null
    } catch (e: Exception) {
        message = "$what: ${e.javaClass.simpleName}: ${e.message}"; null
    }

    private fun longRunInFlight(): Boolean =
        busy.keys.any { it == "survey" || it == "calibration" || it == "mc" || it.startsWith("exp:") }

    private fun markDisconnected(reason: String?) {
        if (connected || health != null) clearEngineData()
        connected = false
        lastError = reason
    }

    /** Drop every engine-derived value (no stale numbers survive a disconnect). */
    fun clearEngineData() {
        health = null; overview = null; series = null; instrument = null; physics = null; earth = null
        tides = null; anomalies = null; calibration = null; calibrationChecked = false; uncertainty = null
        monteCarlo = null; allan = null; experiments = null; experimentResults.clear(); map = null
        telemetry = null; config = null
    }

    // ------------------------------------------------------------------ actions
    private fun action(key: String, block: suspend () -> Unit) {
        if (busy[key] == true) return
        busy[key] = true
        message = null
        scope.launch {
            try { block() } finally { busy.remove(key) }
        }
    }

    fun setPhysicsSwitch(name: String, value: Boolean) = action("physics:$name") {
        fetch("physics") { api.setPhysics(mapOf(name to value)) }?.let { resp ->
            // The POST response is the updated document; fall back to a GET if it was partial.
            physics = if (resp.switches.isNotEmpty()) resp else fetch("physics") { api.physics() } ?: physics
        }
    }

    fun loadEarth(lat: Double?, lon: Double?, alt: Double?) = action("earth") {
        fetch("earth") { api.earth(lat, lon, alt) }?.let { earth = it }
    }

    fun runSurvey(durationS: Double, sampleRateHz: Double) = action("survey") {
        fetch("survey") { api.runSurvey(durationS, sampleRateHz) }?.let { anomalies = it }
    }

    fun runCalibration(seed: Long?) = action("calibration") {
        fetch("calibration") { api.runCalibration(seed) }?.let { calibration = it; calibrationChecked = true }
    }

    fun runMonteCarlo(trials: Int, durationS: Double) = action("mc") {
        fetch("monte-carlo") { api.runMonteCarlo(trials, durationS) }?.let { monteCarlo = it }
    }

    fun runExperiment(name: String, durationS: Double?, sampleRateHz: Double?) = action("exp:$name") {
        fetch("experiment $name") { api.runExperiment(name, durationS, sampleRateHz) }?.let { experimentResults[name] = it }
    }

    fun control(request: ControlRequest) = action("control:${request.action}") {
        fetch("control ${request.action}") { api.control(request) }?.let { health = it }
        if (request.action == "set_location" || request.action == "reset") {
            earth = null; map = null; tides = null
            pollScreen(force = true)
        }
        if (request.action == "set_mode") fetch("instrument") { api.instrument() }?.let { instrument = it }
    }

    /** Fetch every endpoint once (used by tests and on first connection). */
    suspend fun refreshAll() {
        fetch("health") { api.health() }?.let { health = it } ?: return
        fetch("overview") { api.overview() }?.let { overview = it }
        fetch("series") { api.series(window.seconds) }?.let { series = it }
        fetch("instrument") { api.instrument() }?.let { instrument = it }
        fetch("physics") { api.physics() }?.let { physics = it }
        fetch("earth") { api.earth() }?.let { earth = it }
        fetch("tides") { api.tides(tideSpan.hours, tideSpan.stepS) }?.let { tides = it }
        fetch("anomalies") { api.anomalies() }?.let { mergeAnomalies(it) }
        fetch("calibration") { api.calibration() }.also { calibrationChecked = true }?.let { calibration = it }
        fetch("uncertainty") { api.uncertainty() }?.let { uncertainty = it }
        fetch("allan") { api.allan(60) }?.let { allan = it }
        fetch("experiments") { api.experiments() }?.let { experiments = it }
        fetch("map") { api.map() }?.let { map = it }
        fetch("telemetry") { api.telemetry(telemetryN) }?.let { telemetry = it }
        fetch("config") { api.config() }?.let { config = it }
    }

    /** Test hook: set the screen without triggering network activity. */
    fun showScreenForTest(s: Screen) { screen = s }
}
