package org.gravitas.console.ui.chart

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.TextMeasurer
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.unit.dp
import org.gravitas.console.ui.theme.Palette
import org.gravitas.console.ui.theme.Type
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/** One plotted curve. Arrays are in *display* units already; NaN breaks the line. */
class ChartSeries(
    val name: String,
    val x: DoubleArray,
    val y: DoubleArray,
    val color: Color,
    val width: Float = 1.4f,
    val dashed: Boolean = false,
    /** Optional shaded band (same length as x), e.g. ±σ or a confidence interval. */
    val bandLo: DoubleArray? = null,
    val bandHi: DoubleArray? = null,
    val markers: Boolean = false,
    val showLine: Boolean = true,
)

/** A labelled point marker (e.g. bias-instability point on an Allan plot). */
class ChartMarker(val x: Double, val y: Double, val label: String, val color: Color = Palette.Red)

/** Maps data coordinates to pixels inside [rect]. */
class PlotGeometry(
    val rect: Rect,
    val xRange: AxisRange,
    val yRange: AxisRange,
    val xLog: Boolean,
    val yLog: Boolean,
) {
    fun px(x: Double): Float = (rect.left + AxisMath.fraction(x, xRange, xLog) * rect.width).toFloat()
    fun py(y: Double): Float = (rect.bottom - AxisMath.fraction(y, yRange, yLog) * rect.height).toFloat()
    fun valid(x: Double, y: Double): Boolean =
        x.isFinite() && y.isFinite() && (!xLog || x > 0) && (!yLog || y > 0)
}

private val gridColor = Palette.Rule.copy(alpha = 0.55f)
private val gridMinorColor = Palette.Rule.copy(alpha = 0.30f)

internal fun TextMeasurer.size(text: String, style: TextStyle): Size {
    val r = measure(AnnotatedString(text), style)
    return Size(r.size.width.toFloat(), r.size.height.toFloat())
}

internal fun DrawScope.text(tm: TextMeasurer, text: String, x: Float, y: Float, style: TextStyle, alignX: Float = 0f, alignY: Float = 0f) {
    val r = tm.measure(AnnotatedString(text), style)
    drawText(r, topLeft = Offset(x - r.size.width * alignX, y - r.size.height * alignY))
}

/** Tick values + labels for one axis. */
internal class AxisTicks(val major: List<Double>, val minor: List<Double>, val labels: List<String>)

internal fun axisTicks(range: AxisRange, log: Boolean, target: Int): AxisTicks =
    if (log) {
        val maj = AxisMath.logMajorTicks(range)
        AxisTicks(maj, AxisMath.logMinorTicks(range), maj.map { AxisMath.logLabel(it) })
    } else {
        val t = AxisMath.linearTicks(range, target)
        AxisTicks(t.values, emptyList(), t.values.map { AxisMath.linearLabel(it, t.step) })
    }

/**
 * Lays out a plot rectangle with room for tick labels, then draws frame, grid, ticks and labels.
 * Returns the geometry for drawing data.
 */
internal fun DrawScope.drawAxes(
    tm: TextMeasurer,
    xRange: AxisRange,
    yRange: AxisRange,
    xLog: Boolean,
    yLog: Boolean,
    xLabel: String,
    yLabel: String,
    rightMargin: Float = 10f,
): PlotGeometry {
    val st = Type.Axis
    val yt = axisTicks(yRange, yLog, max(3, (size.height / 55f).toInt()))
    val labelW = yt.labels.maxOfOrNull { tm.size(it, st).width } ?: 20f
    val lineH = tm.size("0", st).height
    val left = labelW + 10f
    val top = lineH + 8f
    val bottom = size.height - (lineH * 2 + 10f)
    val right = size.width - rightMargin
    val rect = Rect(left, top, max(left + 10f, right), max(top + 10f, bottom))
    val xt = axisTicks(xRange, xLog, max(3, (rect.width / 90f).toInt()))
    val g = PlotGeometry(rect, xRange, yRange, xLog, yLog)

    // minor grid (log axes)
    for (v in xt.minor) { val x = g.px(v); drawLine(gridMinorColor, Offset(x, rect.top), Offset(x, rect.bottom), 1f) }
    for (v in yt.minor) { val y = g.py(v); drawLine(gridMinorColor, Offset(rect.left, y), Offset(rect.right, y), 1f) }
    // major grid + ticks + labels
    xt.major.forEachIndexed { i, v ->
        val x = g.px(v)
        if (x < rect.left - 0.5f || x > rect.right + 0.5f) return@forEachIndexed
        drawLine(gridColor, Offset(x, rect.top), Offset(x, rect.bottom), 1f)
        drawLine(Palette.RuleStrong, Offset(x, rect.bottom), Offset(x, rect.bottom + 4f), 1f)
        text(tm, xt.labels[i], x, rect.bottom + 6f, st, alignX = 0.5f)
    }
    yt.major.forEachIndexed { i, v ->
        val y = g.py(v)
        if (y < rect.top - 0.5f || y > rect.bottom + 0.5f) return@forEachIndexed
        drawLine(gridColor, Offset(rect.left, y), Offset(rect.right, y), 1f)
        drawLine(Palette.RuleStrong, Offset(rect.left - 4f, y), Offset(rect.left, y), 1f)
        text(tm, yt.labels[i], rect.left - 6f, y, st, alignX = 1f, alignY = 0.5f)
    }
    drawRect(Palette.RuleStrong, rect.topLeft, rect.size, style = Stroke(1f))
    // axis titles: y title above the axis (left-aligned), x title centred under tick labels
    text(tm, yLabel, 2f, 0f, st.copy(color = Palette.GraphiteSoft))
    text(tm, xLabel, rect.center.x, size.height - lineH - 1f, st.copy(color = Palette.GraphiteSoft), alignX = 0.5f)
    return g
}

internal fun DrawScope.drawNoData(tm: TextMeasurer, message: String) {
    drawRect(Palette.Rule, Offset.Zero, size, style = Stroke(1f))
    text(tm, message, size.width / 2, size.height / 2, Type.Label, alignX = 0.5f, alignY = 0.5f)
}

/**
 * Multi-series line chart drawn on Canvas: linear or log axes, autoscaling robust to
 * constant series, optional bands, legend, and labelled markers.
 */
@Composable
fun LineChart(
    series: List<ChartSeries>,
    modifier: Modifier = Modifier,
    xLabel: String = "",
    yLabel: String = "",
    xLog: Boolean = false,
    yLog: Boolean = false,
    xRange: AxisRange? = null,
    yRange: AxisRange? = null,
    markers: List<ChartMarker> = emptyList(),
    legend: Boolean = true,
    emptyText: String = "NO ENGINE DATA",
    zeroLine: Boolean = false,
) {
    val tm = rememberTextMeasurer()
    Column(modifier) {
        if (legend && series.isNotEmpty()) Legend(series)
        Canvas(Modifier.fillMaxWidth().weight(1f)) {
            val xr = xRange ?: rangeOf(series.asSequence().flatMap { s -> s.x.asSequence() }, xLog)
            val yr = yRange ?: rangeOf(
                series.asSequence().flatMap { s ->
                    s.y.asSequence() + (s.bandLo?.asSequence() ?: emptySequence()) + (s.bandHi?.asSequence() ?: emptySequence())
                } + markers.asSequence().map { it.y },
                yLog,
            )
            if (xr == null || yr == null) {
                drawNoData(tm, emptyText); return@Canvas
            }
            val g = drawAxes(tm, xr, yr, xLog, yLog, xLabel, yLabel)
            clipRect(g.rect.left, g.rect.top, g.rect.right, g.rect.bottom) {
                if (zeroLine && !yLog && yr.min < 0 && yr.max > 0) {
                    val y0 = g.py(0.0)
                    drawLine(Palette.SteelLight, Offset(g.rect.left, y0), Offset(g.rect.right, y0), 1f)
                }
                for (s in series) drawBand(g, s)
                for (s in series) drawSeries(g, s)
            }
            for (m in markers) {
                if (!g.valid(m.x, m.y)) continue
                val c = Offset(g.px(m.x), g.py(m.y))
                if (!g.rect.contains(c)) continue
                drawCircle(m.color, 4f, c, style = Stroke(1.5f))
                text(tm, m.label, c.x + 7f, c.y - 7f, Type.Axis.copy(color = m.color), alignY = 1f)
            }
        }
    }
}

private fun rangeOf(values: Sequence<Double>, log: Boolean): AxisRange? =
    if (log) AxisMath.logRange(values) else AxisMath.autoRange(values)

private fun DrawScope.drawBand(g: PlotGeometry, s: ChartSeries) {
    val lo = s.bandLo ?: return
    val hi = s.bandHi ?: return
    val n = minOf(s.x.size, lo.size, hi.size)
    // Draw contiguous segments where all three are valid.
    var i = 0
    while (i < n) {
        while (i < n && !(g.valid(s.x[i], lo[i]) && g.valid(s.x[i], hi[i]))) i++
        val start = i
        while (i < n && g.valid(s.x[i], lo[i]) && g.valid(s.x[i], hi[i])) i++
        val end = i
        if (end - start >= 2) {
            val p = Path()
            p.moveTo(g.px(s.x[start]), g.py(hi[start]))
            for (k in start + 1 until end) p.lineTo(g.px(s.x[k]), g.py(hi[k]))
            for (k in end - 1 downTo start) p.lineTo(g.px(s.x[k]), g.py(lo[k]))
            p.close()
            drawPath(p, s.color.copy(alpha = 0.14f))
        }
    }
}

private fun DrawScope.drawSeries(g: PlotGeometry, s: ChartSeries) {
    val n = min(s.x.size, s.y.size)
    if (s.showLine) {
        val p = Path()
        var pen = false
        for (i in 0 until n) {
            if (!g.valid(s.x[i], s.y[i])) { pen = false; continue }
            val x = g.px(s.x[i]); val y = g.py(s.y[i])
            if (pen) p.lineTo(x, y) else { p.moveTo(x, y); pen = true }
        }
        drawPath(
            p, s.color,
            style = Stroke(width = s.width, pathEffect = if (s.dashed) PathEffect.dashPathEffect(floatArrayOf(6f, 4f)) else null),
        )
    }
    if (s.markers) {
        for (i in 0 until n) if (g.valid(s.x[i], s.y[i])) drawCircle(s.color, 2.2f, Offset(g.px(s.x[i]), g.py(s.y[i])))
    }
}

@Composable
fun Legend(series: List<ChartSeries>) {
    Row(
        Modifier.fillMaxWidth().padding(bottom = 4.dp),
        horizontalArrangement = Arrangement.spacedBy(14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        for (s in series) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Canvas(Modifier.width(18.dp).height(8.dp)) {
                    val y = size.height / 2
                    if (s.bandLo != null) drawRect(s.color.copy(alpha = 0.14f), Offset(0f, 0f), size)
                    if (s.showLine) drawLine(
                        s.color, Offset(0f, y), Offset(size.width, y), s.width + 0.4f,
                        pathEffect = if (s.dashed) PathEffect.dashPathEffect(floatArrayOf(4f, 3f)) else null,
                    )
                    if (s.markers) drawCircle(s.color, 2.5f, Offset(size.width / 2, y))
                }
                Spacer(Modifier.width(5.dp))
                Text(s.name, style = Type.BodySmall)
            }
        }
    }
}

/**
 * Heat map of `grid[row][col]` where row ↔ [ys] and column ↔ [xs] (display units for the axes;
 * [toDisplay] converts the cell value for colour and legend). Optional overlay polyline and marker.
 */
@Composable
fun HeatMap(
    xs: DoubleArray,
    ys: DoubleArray,
    grid: List<DoubleArray>,
    modifier: Modifier = Modifier,
    xLabel: String,
    yLabel: String,
    valueLabel: String,
    toDisplay: (Double) -> Double = { it },
    overlayX: DoubleArray? = null,
    overlayY: DoubleArray? = null,
    overlayLabel: String? = null,
    marker: Pair<Double, Double>? = null,
    markerLabel: String? = null,
    emptyText: String = "NO ENGINE DATA",
) {
    val tm = rememberTextMeasurer()
    val prepared = remember(xs, ys, grid) { orientGrid(xs, ys, grid) }
    Canvas(modifier) {
        if (prepared == null) { drawNoData(tm, emptyText); return@Canvas }
        val (gx, gy, cells) = prepared
        var vmin = Double.POSITIVE_INFINITY; var vmax = Double.NEGATIVE_INFINITY
        for (row in cells) for (v in row) if (v.isFinite()) { val d = toDisplay(v); vmin = min(vmin, d); vmax = max(vmax, d) }
        if (vmin > vmax) { drawNoData(tm, emptyText); return@Canvas }
        val vr = AxisMath.padded(vmin, vmax, 0.0)
        val xr = cellRange(gx); val yr = cellRange(gy)
        val legendW = 92f
        val g = drawAxes(tm, xr, yr, false, false, xLabel, yLabel, rightMargin = legendW)
        clipRect(g.rect.left, g.rect.top, g.rect.right, g.rect.bottom) {
            for (r in gy.indices) for (c in gx.indices) {
                val v = cells[r][c]
                val x0 = g.px(edge(gx, c, -1)); val x1 = g.px(edge(gx, c, +1))
                val y0 = g.py(edge(gy, r, +1)); val y1 = g.py(edge(gy, r, -1))
                val t = if (v.isFinite()) AxisMath.fraction(toDisplay(v), vr, false) else Double.NaN
                drawRect(Palette.sequential(t), Offset(min(x0, x1), min(y0, y1)), Size(abs(x1 - x0) + 0.6f, abs(y1 - y0) + 0.6f))
            }
            if (overlayX != null && overlayY != null) {
                val p = Path(); var pen = false
                for (i in 0 until min(overlayX.size, overlayY.size)) {
                    if (!g.valid(overlayX[i], overlayY[i])) { pen = false; continue }
                    val px = g.px(overlayX[i]); val py = g.py(overlayY[i])
                    if (pen) p.lineTo(px, py) else { p.moveTo(px, py); pen = true }
                }
                drawPath(p, Palette.Amber, style = Stroke(2f))
                for (i in 0 until min(overlayX.size, overlayY.size)) if (g.valid(overlayX[i], overlayY[i]))
                    drawCircle(Palette.Amber, 2.2f, Offset(g.px(overlayX[i]), g.py(overlayY[i])))
            }
            if (marker != null && g.valid(marker.first, marker.second)) {
                val c = Offset(g.px(marker.first), g.py(marker.second))
                drawCircle(Color.White, 6f, c); drawCircle(Palette.Red, 6f, c, style = Stroke(2f))
                drawLine(Palette.Red, Offset(c.x - 10f, c.y), Offset(c.x + 10f, c.y), 1f)
                drawLine(Palette.Red, Offset(c.x, c.y - 10f), Offset(c.x, c.y + 10f), 1f)
            }
        }
        if (overlayLabel != null) text(tm, "— $overlayLabel", g.rect.left + 6f, g.rect.top + 4f, Type.Axis.copy(color = Palette.Amber))
        if (marker != null && markerLabel != null && g.valid(marker.first, marker.second)) {
            text(tm, markerLabel, g.px(marker.first) + 9f, g.py(marker.second) + 6f, Type.Axis.copy(color = Palette.Red))
        }
        drawColourScale(tm, Rect(g.rect.right + 16f, g.rect.top, g.rect.right + 30f, g.rect.bottom), vr, valueLabel)
    }
}

/** Vertical sequential colour bar with tick labels in display units. */
internal fun DrawScope.drawColourScale(tm: TextMeasurer, bar: Rect, vr: AxisRange, label: String) {
    val steps = 64
    for (i in 0 until steps) {
        val t0 = i / steps.toFloat()
        val y = bar.bottom - (i + 1) * bar.height / steps
        drawRect(Palette.sequential(t0 + 0.5 / steps), Offset(bar.left, y), Size(bar.width, bar.height / steps + 0.6f))
    }
    drawRect(Palette.RuleStrong, bar.topLeft, bar.size, style = Stroke(1f))
    val t = AxisMath.linearTicks(vr, 5)
    for (v in t.values) {
        val y = (bar.bottom - AxisMath.fraction(v, vr, false) * bar.height).toFloat()
        drawLine(Palette.Graphite, Offset(bar.right, y), Offset(bar.right + 3f, y), 1f)
        text(tm, AxisMath.linearLabel(v, t.step), bar.right + 5f, y, Type.Axis, alignY = 0.5f)
    }
    text(tm, label, bar.left - 4f, bar.top - 4f, Type.Axis.copy(color = Palette.GraphiteSoft), alignY = 1f)
}

private fun cellRange(c: DoubleArray): AxisRange {
    val lo = edge(c, 0, -1); val hi = edge(c, c.size - 1, +1)
    return if (hi > lo) AxisRange(lo, hi) else AxisMath.padded(min(lo, hi), max(lo, hi))
}

/** Cell edge between coordinate i and its neighbour in direction [dir] (half-way). */
private fun edge(c: DoubleArray, i: Int, dir: Int): Double {
    if (c.size == 1) return c[0] + dir * 0.5
    val j = i + dir
    return if (j in c.indices) (c[i] + c[j]) / 2 else c[i] + (c[i] - c[i - dir]) / 2
}

/**
 * Validates the grid and returns (x, y, rows) with rows indexed by y. A grid sent transposed
 * (rows indexed by x) is accepted and transposed. Returns null if shapes are inconsistent.
 */
internal fun orientGrid(xs: DoubleArray, ys: DoubleArray, grid: List<DoubleArray>): Triple<DoubleArray, DoubleArray, List<DoubleArray>>? {
    if (xs.isEmpty() || ys.isEmpty() || grid.isEmpty()) return null
    if (grid.size == ys.size && grid.all { it.size == xs.size }) return Triple(xs, ys, grid)
    if (grid.size == xs.size && grid.all { it.size == ys.size }) {
        val t = List(ys.size) { r -> DoubleArray(xs.size) { c -> grid[c][r] } }
        return Triple(xs, ys, t)
    }
    return null
}

/** Simple histogram of [values] (display units) with [bins] equal-width bins. */
@Composable
fun Histogram(
    values: DoubleArray,
    modifier: Modifier = Modifier,
    bins: Int = 30,
    xLabel: String,
    yLabel: String = "count",
    color: Color = Palette.MutedBlue,
    vLines: List<Pair<Double, String>> = emptyList(),
    emptyText: String = "NO DATA",
) {
    val tm = rememberTextMeasurer()
    val counts = remember(values, bins) { histogram(values, bins) }
    Box(modifier) {
        Canvas(Modifier.fillMaxSize()) {
            if (counts == null) { drawNoData(tm, emptyText); return@Canvas }
            val (lo, hi, c) = counts
            val xr = AxisRange(lo, hi)
            val yr = AxisRange(0.0, max(1, c.maxOrNull() ?: 1) * 1.1)
            val g = drawAxes(tm, xr, yr, false, false, xLabel, yLabel)
            val w = (hi - lo) / c.size
            clipRect(g.rect.left, g.rect.top, g.rect.right, g.rect.bottom) {
                for (i in c.indices) {
                    val x0 = g.px(lo + i * w); val x1 = g.px(lo + (i + 1) * w)
                    val y = g.py(c[i].toDouble())
                    drawRect(color.copy(alpha = 0.55f), Offset(x0, y), Size(x1 - x0 - 1f, g.rect.bottom - y))
                    drawRect(color, Offset(x0, y), Size(x1 - x0 - 1f, g.rect.bottom - y), style = Stroke(1f))
                }
                for ((v, _) in vLines) {
                    val x = g.px(v)
                    drawLine(Palette.Amber, Offset(x, g.rect.top), Offset(x, g.rect.bottom), 1.5f, pathEffect = PathEffect.dashPathEffect(floatArrayOf(5f, 4f)))
                }
            }
            vLines.forEachIndexed { i, (v, label) ->
                val x = g.px(v)
                if (x >= g.rect.left && x <= g.rect.right) text(tm, label, x + 4f, g.rect.top + 4f + i * 14f, Type.Axis.copy(color = Palette.Amber))
            }
        }
    }
}

/** Equal-width binning (presentation only). Returns (lo, hi, counts) or null if no finite data. */
fun histogram(values: DoubleArray, bins: Int): Triple<Double, Double, IntArray>? {
    val finite = values.filter { it.isFinite() }
    if (finite.isEmpty() || bins < 1) return null
    val r = AxisMath.padded(finite.min(), finite.max(), 0.02)
    val counts = IntArray(bins)
    val w = r.span / bins
    for (v in finite) counts[((v - r.min) / w).toInt().coerceIn(0, bins - 1)]++
    return Triple(r.min, r.max, counts)
}
