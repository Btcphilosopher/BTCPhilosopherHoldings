package org.gravitas.console.ui.theme

import androidx.compose.material.MaterialTheme
import androidx.compose.material.Shapes
import androidx.compose.material.Typography
import androidx.compose.material.lightColors
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * GRAVITAS palette: British scientific laboratory / aerospace instrumentation.
 * White paper, graphite ink, deep navy structure, steel secondary, muted blue data,
 * restrained amber caution and restrained red fault. No neon, no gradients.
 */
object Palette {
    val Paper = Color(0xFFF6F6F3)       // page background (warm laboratory white)
    val Panel = Color(0xFFFFFFFF)       // instrument panels
    val PanelAlt = Color(0xFFF0F1F2)    // table zebra / input wells
    val Rule = Color(0xFFD3D7DC)        // thin rules
    val RuleStrong = Color(0xFFADB4BC)
    val Graphite = Color(0xFF24282D)    // primary ink
    val GraphiteSoft = Color(0xFF4A5058)
    val Steel = Color(0xFF6B7682)       // labels, units
    val SteelLight = Color(0xFF9AA4AF)
    val Navy = Color(0xFF15294A)        // structure, primary accent
    val NavySoft = Color(0xFF2C4470)
    val MutedBlue = Color(0xFF3F6C9F)   // data
    val MutedBlueLight = Color(0xFFB9CCE0)
    val Amber = Color(0xFFB07A1C)       // caution
    val AmberLight = Color(0xFFF1E3C8)
    val Red = Color(0xFFA3362B)         // fault
    val RedLight = Color(0xFFF2D9D5)
    val NavyLight = Color(0xFFDCE3EE)

    /** Ordered series colours for plots: distinct but restrained. */
    val series = listOf(
        Graphite, MutedBlue, Amber, Navy, SteelLight, Red, Color(0xFF6E8B5A), Color(0xFF8A6D4E),
    )

    /** Sequential blue ramp for heat maps (low → high). */
    val sequentialBlue = listOf(
        Color(0xFFF4F7FB), Color(0xFFDCE6F1), Color(0xFFBCCFE4), Color(0xFF94B2D3),
        Color(0xFF6A90BD), Color(0xFF46709F), Color(0xFF2B5281), Color(0xFF15294A),
    )

    fun sequential(t: Double): Color {
        if (!t.isFinite()) return PanelAlt
        val x = t.coerceIn(0.0, 1.0) * (sequentialBlue.size - 1)
        val i = x.toInt().coerceAtMost(sequentialBlue.size - 2)
        val f = (x - i).toFloat()
        val a = sequentialBlue[i]; val b = sequentialBlue[i + 1]
        return Color(
            red = a.red + (b.red - a.red) * f,
            green = a.green + (b.green - a.green) * f,
            blue = a.blue + (b.blue - a.blue) * f,
        )
    }
}

object Type {
    val Mono = FontFamily.Monospace
    val Sans = FontFamily.SansSerif

    val Label = TextStyle(fontFamily = Sans, fontSize = 10.5.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 1.1.sp, color = Palette.Steel)
    val Section = TextStyle(fontFamily = Sans, fontSize = 11.5.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.6.sp, color = Palette.Navy)
    val Title = TextStyle(fontFamily = Sans, fontSize = 18.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 2.sp, color = Palette.Graphite)
    val Body = TextStyle(fontFamily = Sans, fontSize = 12.5.sp, color = Palette.Graphite)
    val BodySmall = TextStyle(fontFamily = Sans, fontSize = 11.sp, color = Palette.GraphiteSoft)
    val ValueLarge = TextStyle(fontFamily = Mono, fontSize = 24.sp, fontWeight = FontWeight.Medium, color = Palette.Graphite)
    val Value = TextStyle(fontFamily = Mono, fontSize = 16.sp, color = Palette.Graphite)
    val ValueSmall = TextStyle(fontFamily = Mono, fontSize = 12.sp, color = Palette.Graphite)
    val Unit = TextStyle(fontFamily = Sans, fontSize = 11.5.sp, color = Palette.Steel)
    val Axis = TextStyle(fontFamily = Mono, fontSize = 10.sp, color = Palette.Steel)
}

@Composable
fun GravitasTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colors = lightColors(
            primary = Palette.Navy,
            primaryVariant = Palette.NavySoft,
            secondary = Palette.MutedBlue,
            background = Palette.Paper,
            surface = Palette.Panel,
            error = Palette.Red,
            onPrimary = Color.White,
            onSecondary = Color.White,
            onBackground = Palette.Graphite,
            onSurface = Palette.Graphite,
        ),
        typography = Typography(defaultFontFamily = Type.Sans),
        shapes = Shapes(
            small = RoundedCornerShape(2.dp),
            medium = RoundedCornerShape(2.dp),
            large = RoundedCornerShape(2.dp),
        ),
        content = content,
    )
}
