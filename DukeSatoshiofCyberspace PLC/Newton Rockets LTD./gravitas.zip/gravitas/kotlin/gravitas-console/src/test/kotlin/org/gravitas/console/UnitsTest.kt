package org.gravitas.console

import org.gravitas.console.units.Fmt
import org.gravitas.console.units.GravityUnit
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertTrue

class UnitsTest {
    @Test
    fun `unit definitions are exact`() {
        assertEquals(1e-2, GravityUnit.GAL.toMps2(1.0))
        assertEquals(1e-5, GravityUnit.MGAL.toMps2(1.0))
        assertEquals(1e-8, GravityUnit.UGAL.toMps2(1.0))
        assertEquals(1.0, GravityUnit.MPS2.toMps2(1.0))
        assertEquals(100.0, GravityUnit.GAL.fromMps2(1.0))
        assertEquals(1e5, GravityUnit.MGAL.fromMps2(1.0))
        assertEquals(1e8, GravityUnit.UGAL.fromMps2(1.0))
        // scale factors are exactly representable powers of ten
        for (u in GravityUnit.entries) assertEquals(u.perMps2, Math.rint(u.perMps2))
    }

    @Test
    fun `cross-unit relations`() {
        val g = 9.812345678
        assertEquals(GravityUnit.GAL.fromMps2(g) * 1000, GravityUnit.MGAL.fromMps2(g), 1e-9)
        assertEquals(GravityUnit.MGAL.fromMps2(g) * 1000, GravityUnit.UGAL.fromMps2(g), 1e-6)
        assertEquals(981234567.8, GravityUnit.UGAL.fromMps2(g), 1e-6)
        assertEquals(1.0, GravityUnit.UGAL.fromMps2(1e-8), 0.0)
        assertEquals(1.0, GravityUnit.MGAL.fromMps2(1e-5), 1e-15)
    }

    @Test
    fun `round trip conversion is stable`() {
        val values = listOf(9.80665, 9.832186, 9.780327, -4.1e-7, 2.1e-8, 0.0, 1e-12)
        for (u in GravityUnit.entries) for (v in values) {
            assertEquals(v, u.toMps2(u.fromMps2(v)), kotlin.math.abs(v) * 1e-15 + 1e-300)
        }
    }

    @Test
    fun `absolute gravity formatting per unit`() {
        val g = 9.812345678
        assertEquals("981234567.8", Fmt.gravity(g, GravityUnit.UGAL))
        assertEquals("981234.5678", Fmt.gravity(g, GravityUnit.MGAL))
        assertEquals("981.2345678", Fmt.gravity(g, GravityUnit.GAL))
        assertEquals("9.812345678", Fmt.gravity(g, GravityUnit.MPS2))
    }

    @Test
    fun `missing values render as dash never as a number`() {
        assertEquals(Fmt.DASH, Fmt.gravity(null, GravityUnit.UGAL))
        assertEquals(Fmt.DASH, Fmt.small(null, GravityUnit.UGAL))
        assertEquals(Fmt.DASH, Fmt.fixed(Double.NaN, 3))
        assertEquals(Fmt.DASH, Fmt.sig(null))
        assertEquals(Fmt.DASH, Fmt.simTime(null))
        // the unit is still returned for a missing SI value
        assertEquals(Fmt.DASH to "m", Fmt.siPrefixed(null, "m"))
    }

    @Test
    fun `small accelerations`() {
        assertEquals("2.100", Fmt.small(2.1e-8, GravityUnit.UGAL))
        assertEquals("-41.00", Fmt.small(-4.1e-7, GravityUnit.UGAL))
        assertEquals("0.002100", Fmt.small(2.1e-8, GravityUnit.MGAL))
        assertTrue(Fmt.small(2.1e-8, GravityUnit.MPS2).contains("e-8"))
        assertEquals("-308.6", Fmt.small(-3.0857e-6, GravityUnit.UGAL))
    }

    @Test
    fun `fixed and significant formatting`() {
        assertEquals("0.3", Fmt.fixed(0.30000000000000004, 1))
        assertEquals("0.000", Fmt.fixed(-0.0001, 3))
        assertEquals("20.031", Fmt.fixed(20.031, 3))
        assertEquals("1.235", Fmt.sig(1.23456, 4))
        assertEquals("5.000e-8", Fmt.sci(5e-8, 4))
        assertEquals("1.200e6", Fmt.sci(1.2e6, 4))
        assertEquals("24", Fmt.integer(24.0))
    }

    @Test
    fun `si prefixes`() {
        assertEquals("1.200" to "nm", Fmt.siPrefixed(1.2e-9, "m"))
        assertEquals("1.550" to "µm", Fmt.siPrefixed(1.55e-6, "m"))
        assertEquals("596.0" to "nV", Fmt.siPrefixed(5.96e-7, "V"))
        assertEquals("98.12" to "mN", Fmt.siPrefixed(0.09812, "N"))
        assertEquals("3.000" to "pm/s", Fmt.siPrefixed(3e-12, "m/s"))
    }

    @Test
    fun `simulated time formatting`() {
        assertEquals("0d 00:00:12.3", Fmt.simTime(12.3))
        assertEquals("1d 01:01:01.5", Fmt.simTime(86400.0 + 3661.5))
    }
}
