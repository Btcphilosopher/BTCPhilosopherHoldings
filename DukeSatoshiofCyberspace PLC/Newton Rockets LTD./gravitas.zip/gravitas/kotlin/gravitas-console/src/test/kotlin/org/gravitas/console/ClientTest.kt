package org.gravitas.console

import com.sun.net.httpserver.HttpServer
import kotlinx.coroutines.runBlocking
import org.gravitas.console.api.ApiException
import org.gravitas.console.api.ControlRequest
import org.gravitas.console.api.EngineUnreachableException
import org.gravitas.console.api.GravitasClient
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.util.concurrent.ConcurrentLinkedQueue
import kotlin.test.AfterTest
import kotlin.test.BeforeTest
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFailsWith
import kotlin.test.assertNull
import kotlin.test.assertTrue

/** Exercises [GravitasClient] against an in-process HTTP server serving the fixtures. */
class ClientTest {
    private lateinit var server: HttpServer
    private val requests = ConcurrentLinkedQueue<Triple<String, String, String>>() // method, uri, body

    private val routes = mapOf(
        "/api/v1/health" to "health.json", "/api/v1/overview" to "overview.json", "/api/v1/series" to "series.json",
        "/api/v1/instrument" to "instrument.json", "/api/v1/physics" to "physics.json", "/api/v1/earth" to "earth.json",
        "/api/v1/tides" to "tides.json", "/api/v1/anomalies" to "anomalies_nosurvey.json", "/api/v1/anomalies/survey" to "anomalies.json",
        "/api/v1/calibration" to "calibration_null.json", "/api/v1/calibration/run" to "calibration.json",
        "/api/v1/uncertainty" to "uncertainty.json", "/api/v1/uncertainty/monte-carlo" to "monte_carlo.json",
        "/api/v1/allan" to "allan.json", "/api/v1/experiments" to "experiments.json", "/api/v1/experiments/static" to "experiment_static.json",
        "/api/v1/map" to "map.json", "/api/v1/telemetry" to "telemetry.json", "/api/v1/config" to "config.json", "/api/v1/control" to "health.json",
    )

    @BeforeTest
    fun start() {
        server = HttpServer.create(InetSocketAddress("127.0.0.1", 0), 0)
        server.createContext("/") { ex ->
            val body = ex.requestBody.readBytes().decodeToString()
            requests += Triple(ex.requestMethod, ex.requestURI.toString(), body)
            val f = routes[ex.requestURI.path]
            val (code, payload) = if (f != null) 200 to fixture(f) else 404 to fixture("error.json")
            val bytes = payload.toByteArray()
            ex.responseHeaders.add("Content-Type", "application/json")
            ex.sendResponseHeaders(code, bytes.size.toLong())
            ex.responseBody.use { it.write(bytes) }
        }
        server.start()
    }

    @AfterTest
    fun stop() = server.stop(0)

    private fun client() = GravitasClient("http://127.0.0.1:${server.address.port}")

    @Test
    fun `GET endpoints decode`() = runBlocking<Unit> {
        val c = client()
        assertEquals("ok", c.health().status)
        assertEquals("STABLE", c.overview().instrumentStatus)
        assertEquals(600, c.series(60.0).tS!!.size)
        assertEquals(24.0, c.instrument().adc!!.bits)
        assertEquals(12, c.physics().switches.size)
        assertEquals(1.16, c.tides(48, 600).gravimetricFactor)
        assertNull(c.calibration())
        assertEquals(6, c.experiments().experiments.size)
        assertEquals(50, c.telemetry(50).frames.size)
        assertTrue(c.config().containsKey("seed"))
        assertEquals(3, c.allan(60).identification!!.regions!!.size)
        val uris = requests.map { it.second }
        assertTrue("/api/v1/series?window_s=60&max_points=2000" in uris, uris.toString())
        assertTrue("/api/v1/tides?hours=48&step_s=600" in uris)
        assertTrue("/api/v1/telemetry?n=50" in uris)
        assertTrue("/api/v1/allan?max_points=60" in uris)
    }

    @Test
    fun `earth query parameters`() = runBlocking<Unit> {
        val c = client()
        c.earth()
        c.earth(53.38, -1.47, 100.0)
        val uris = requests.map { it.second }
        assertTrue("/api/v1/earth" in uris)
        assertTrue("/api/v1/earth?lat_deg=53.38&lon_deg=-1.47&alt_m=100" in uris, uris.toString())
    }

    @Test
    fun `POST bodies follow the contract`() = runBlocking<Unit> {
        val c = client()
        c.control(ControlRequest.setSpeed(60.0))
        c.setPhysics(mapOf("moon" to false))
        c.runSurvey(1800.0, 10.0)
        c.runCalibration(7)
        c.runMonteCarlo(50, 300.0)
        c.runExperiment("static", 600.0, 10.0)
        val posts = requests.filter { it.first == "POST" }.associate { it.second to it.third }
        assertEquals("""{"action":"set_speed","speed":60.0}""", posts["/api/v1/control"])
        assertEquals("""{"switches":{"moon":false}}""", posts["/api/v1/physics"])
        assertEquals("""{"duration_s":1800.0,"sample_rate_hz":10.0}""", posts["/api/v1/anomalies/survey"])
        assertEquals("""{"seed":7}""", posts["/api/v1/calibration/run"])
        assertEquals("""{"trials":50,"duration_s":300.0}""", posts["/api/v1/uncertainty/monte-carlo"])
        assertEquals("""{"duration_s":600.0,"sample_rate_hz":10.0}""", posts["/api/v1/experiments/static"])
    }

    @Test
    fun `HTTP errors surface the engine message`() = runBlocking<Unit> {
        val e = assertFailsWith<ApiException> { client().runExperiment("foo", null, null) }
        assertEquals(404, e.status)
        assertEquals("unknown experiment 'foo'", e.message)
    }

    @Test
    fun `unreachable engine`() = runBlocking<Unit> {
        val port = ServerSocket(0).use { it.localPort }
        assertFailsWith<EngineUnreachableException> { GravitasClient("http://127.0.0.1:$port").health() }
        Unit
    }

    @Test
    fun `engine URL resolution`() {
        assertEquals("http://127.0.0.1:8765", GravitasClient.resolveEngine(emptyArray(), emptyMap()))
        assertEquals("http://h:1", GravitasClient.resolveEngine(arrayOf("--engine", "http://h:1"), mapOf("GRAVITAS_ENGINE" to "http://e:2")))
        assertEquals("http://h:3", GravitasClient.resolveEngine(arrayOf("--engine=http://h:3"), emptyMap()))
        assertEquals("http://e:2", GravitasClient.resolveEngine(emptyArray(), mapOf("GRAVITAS_ENGINE" to "http://e:2")))
        assertEquals("http://127.0.0.1:8765/api/v1", GravitasClient("http://127.0.0.1:8765/").baseUrl)
        assertEquals("http://127.0.0.1:8765/api/v1", GravitasClient("http://127.0.0.1:8765/api/v1").baseUrl)
        assertEquals("53.38", GravitasClient.num(53.38))
        assertEquals("100", GravitasClient.num(100.0))
        assertEquals("0.0000001", GravitasClient.num(1e-7))
    }
}
