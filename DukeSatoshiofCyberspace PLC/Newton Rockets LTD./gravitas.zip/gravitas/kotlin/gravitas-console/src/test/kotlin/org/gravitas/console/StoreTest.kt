package org.gravitas.console

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.runBlocking
import org.gravitas.console.api.ControlRequest
import org.gravitas.console.state.ConsoleStore
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFalse
import kotlin.test.assertNotNull
import kotlin.test.assertNull
import kotlin.test.assertTrue

class StoreTest {
    private fun store(api: FixtureApi) = ConsoleStore(api, CoroutineScope(SupervisorJob() + Dispatchers.Unconfined))

    @Test
    fun `refreshAll populates every endpoint`() = runBlocking<Unit> {
        val s = store(FixtureApi())
        s.refreshAll()
        assertTrue(s.connected)
        listOf(s.health, s.overview, s.series, s.instrument, s.physics, s.earth, s.tides, s.anomalies, s.calibration,
            s.uncertainty, s.allan, s.experiments, s.map, s.telemetry, s.config).forEach { assertNotNull(it) }
    }

    @Test
    fun `losing the engine clears all engine data`() = runBlocking<Unit> {
        val api = FixtureApi()
        val s = store(api)
        s.refreshAll()
        api.online = false
        s.pollFast()
        assertFalse(s.connected)
        assertNotNull(s.lastError)
        listOf(s.health, s.overview, s.series, s.instrument, s.physics, s.earth, s.tides, s.anomalies, s.calibration,
            s.uncertainty, s.allan, s.experiments, s.map, s.telemetry, s.config).forEach { assertNull(it) }
        api.online = true
        s.pollFast()
        assertTrue(s.connected)
        assertNotNull(s.overview)
    }

    @Test
    fun `actions call the engine`() = runBlocking<Unit> {
        val api = FixtureApi()
        val s = store(api)
        s.refreshAll()
        s.control(ControlRequest.setSpeed(60.0))
        assertEquals(listOf(ControlRequest.setSpeed(60.0)), api.controls)
        s.runSurvey(1800.0, 10.0)
        assertNotNull(s.anomalies?.survey)
        s.runMonteCarlo(50, 300.0)
        assertNotNull(s.monteCarlo)
        s.runExperiment("static", 600.0, 10.0)
        assertNotNull(s.experimentResults["static"])
        s.setPhysicsSwitch("moon", false)
        assertEquals(false, s.physics!!.switches["moon"])
        assertTrue(s.busy.isEmpty())
    }
}
