package org.gravitas.console

import org.gravitas.console.ui.chart.AxisMath
import org.gravitas.console.ui.chart.AxisRange
import org.gravitas.console.ui.chart.histogram
import org.gravitas.console.ui.chart.orientGrid
import kotlin.math.abs
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFailsWith
import kotlin.test.assertNotNull
import kotlin.test.assertNull
import kotlin.test.assertTrue

class AxisMathTest {
    @Test
    fun `nice steps are 1 2 2_5 5 times a power of ten`() {
        assertEquals(1.0, AxisMath.niceStep(5.0, 5))
        assertEquals(2.0, AxisMath.niceStep(10.0, 6))
        assertEquals(0.5, AxisMath.niceStep(2.3, 6))
        assertEquals(2e-9, AxisMath.niceStep(1.3e-8, 6), 1e-24)
        assertEquals(5.0, AxisMath.niceStep(20.0, 3))
        assertEquals(1e6, AxisMath.niceStep(5.2e6, 6))
    }

    @Test
    fun `linear ticks lie inside the range and are evenly spaced`() {
        val r = AxisRange(-3.7, 12.2)
        val t = AxisMath.linearTicks(r, 6)
        assertTrue(t.values.size in 3..12, "ticks: ${t.values}")
        assertTrue(t.values.all { it >= r.min - 1e-12 && it <= r.max + 1e-12 })
        t.values.zipWithNext().forEach { (a, b) -> assertEquals(t.step, b - a, t.step * 1e-9) }
        assertTrue(t.values.contains(0.0))
        // every tick is an integer multiple of the step
        t.values.forEach { assertEquals(0.0, abs(it / t.step - Math.rint(it / t.step)), 1e-9) }
    }

    @Test
    fun `ticks for tiny span on a large offset`() {
        // e.g. absolute gravity in m/s² varying by a few nm/s²
        val r = AxisMath.autoRange(sequenceOf(9.812345670, 9.812345690))!!
        val t = AxisMath.linearTicks(r, 5)
        assertTrue(t.values.size >= 2, "ticks: ${t.values}")
        val labels = t.values.map { AxisMath.linearLabel(it, t.step) }
        assertEquals(labels.size, labels.toSet().size, "labels must be distinct: $labels")
    }

    @Test
    fun `constant series autoscale to a valid non-degenerate range`() {
        val r = AxisMath.autoRange(sequenceOf(5.0, 5.0, 5.0))!!
        assertTrue(r.min < 5.0 && r.max > 5.0)
        val z = AxisMath.autoRange(sequenceOf(0.0, 0.0))!!
        assertEquals(-1.0, z.min); assertEquals(1.0, z.max)
        val g = AxisMath.autoRange(sequenceOf(981234567.8, 981234567.8))!!
        assertTrue(g.min < g.max)
        assertTrue(AxisMath.linearTicks(g).values.isNotEmpty())
    }

    @Test
    fun `empty and non-finite input gives no range`() {
        assertNull(AxisMath.autoRange(emptySequence()))
        assertNull(AxisMath.autoRange(sequenceOf(Double.NaN, Double.POSITIVE_INFINITY)))
        assertNull(AxisMath.logRange(sequenceOf(0.0, -1.0, Double.NaN)))
        assertNotNull(AxisMath.autoRange(sequenceOf(Double.NaN, 1.0, 2.0)))
    }

    @Test
    fun `invalid range rejected`() {
        assertFailsWith<IllegalArgumentException> { AxisRange(1.0, 1.0) }
        assertFailsWith<IllegalArgumentException> { AxisRange(Double.NaN, 1.0) }
    }

    @Test
    fun `log range expands to whole decades`() {
        val r = AxisMath.logRange(sequenceOf(0.13, 2.0, 3000.0, -5.0, 0.0))!!
        assertEquals(0.1, r.min, 1e-15)
        assertEquals(10000.0, r.max, 1e-9)
        val single = AxisMath.logRange(sequenceOf(100.0, 100.0))!!
        assertTrue(single.min < 100.0 && single.max > 100.0)
    }

    @Test
    fun `log ticks`() {
        val r = AxisRange(1e-9, 1e-6)
        val major = AxisMath.logMajorTicks(r)
        assertEquals(4, major.size)
        major.zip(listOf(1e-9, 1e-8, 1e-7, 1e-6)).forEach { (a, b) -> assertEquals(b, a, b * 1e-12) }
        val minor = AxisMath.logMinorTicks(r)
        assertEquals(3 * 8, minor.size)
        assertTrue(minor.all { it > r.min && it < r.max })
        assertEquals(listOf("1e-9", "1e-8", "1e-7", "1e-6"), major.map { AxisMath.logLabel(it) })
        assertEquals(listOf("0.1", "1", "10", "100"), AxisMath.logMajorTicks(AxisRange(0.1, 100.0)).map { AxisMath.logLabel(it) })
    }

    @Test
    fun `log axis fractions`() {
        val r = AxisRange(0.1, 1000.0)
        assertEquals(0.0, AxisMath.fraction(0.1, r, true), 1e-12)
        assertEquals(0.25, AxisMath.fraction(1.0, r, true), 1e-12)
        assertEquals(0.5, AxisMath.fraction(10.0, r, true), 1e-12)
        assertEquals(1.0, AxisMath.fraction(1000.0, r, true), 1e-12)
        assertTrue(AxisMath.fraction(0.0, r, true).isNaN())
        assertTrue(AxisMath.fraction(-1.0, r, true).isNaN())
        // sqrt(10) sits half way between 1 and 10
        assertEquals(0.375, AxisMath.fraction(Math.sqrt(10.0), r, true), 1e-12)
        for (f in listOf(0.0, 0.1, 0.33, 0.9, 1.0)) assertEquals(f, AxisMath.fraction(AxisMath.valueAt(f, r, true), r, true), 1e-12)
    }

    @Test
    fun `linear axis fractions`() {
        val r = AxisRange(-2.0, 2.0)
        assertEquals(0.5, AxisMath.fraction(0.0, r, false))
        assertEquals(1.5, AxisMath.valueAt(0.875, r, false))
    }

    @Test
    fun `tick labels`() {
        assertEquals("0", AxisMath.linearLabel(0.0, 0.5))
        assertEquals("1.5", AxisMath.linearLabel(1.5, 0.5))
        assertEquals("2.50", AxisMath.linearLabel(2.5, 0.25))
        assertEquals("981234000", AxisMath.linearLabel(981234000.0, 1000.0))
        assertEquals("-0.002", AxisMath.linearLabel(-0.002, 0.001))
    }

    @Test
    fun `grid orientation and histogram`() {
        val xs = doubleArrayOf(0.0, 1.0, 2.0); val ys = doubleArrayOf(10.0, 20.0)
        val rows = listOf(doubleArrayOf(1.0, 2.0, 3.0), doubleArrayOf(4.0, 5.0, 6.0))
        assertEquals(rows, orientGrid(xs, ys, rows)!!.third)
        val transposed = listOf(doubleArrayOf(1.0, 4.0), doubleArrayOf(2.0, 5.0), doubleArrayOf(3.0, 6.0))
        assertEquals(rows.map { it.toList() }, orientGrid(xs, ys, transposed)!!.third.map { it.toList() })
        assertNull(orientGrid(xs, ys, listOf(doubleArrayOf(1.0))))
        val h = histogram(doubleArrayOf(0.0, 0.1, 0.2, 1.0, Double.NaN), 5)!!
        assertEquals(4, h.third.sum())
        assertNull(histogram(doubleArrayOf(Double.NaN), 5))
    }
}
