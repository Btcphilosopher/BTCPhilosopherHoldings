package org.gravitas.console

import kotlinx.serialization.KSerializer
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.serializer
import org.gravitas.console.api.Allan
import org.gravitas.console.api.Anomalies
import org.gravitas.console.api.CalibrationReport
import org.gravitas.console.api.ControlRequest
import org.gravitas.console.api.Earth
import org.gravitas.console.api.EngineUnreachableException
import org.gravitas.console.api.ExperimentList
import org.gravitas.console.api.ExperimentResult
import org.gravitas.console.api.GravitasApi
import org.gravitas.console.api.GravitasJson
import org.gravitas.console.api.Health
import org.gravitas.console.api.Instrument
import org.gravitas.console.api.MapData
import org.gravitas.console.api.MonteCarloResult
import org.gravitas.console.api.Overview
import org.gravitas.console.api.PhysicsSwitches
import org.gravitas.console.api.Series
import org.gravitas.console.api.Telemetry
import org.gravitas.console.api.Tides
import org.gravitas.console.api.UncertaintyBudget

/** Reads a fixture payload from src/test/resources/fixtures. */
fun fixture(name: String): String =
    requireNotNull(FixtureApi::class.java.getResource("/fixtures/$name")) { "missing fixture $name" }.readText()

fun <T> decodeFixture(name: String, s: KSerializer<T>): T = GravitasJson.decodeFromString(s, fixture(name))

/** [GravitasApi] backed by the contract fixtures; `online = false` simulates a dead engine. */
class FixtureApi(var online: Boolean = true) : GravitasApi {
    override val engineUrl = "http://127.0.0.1:8765"
    val controls = mutableListOf<ControlRequest>()

    private fun <T> load(name: String, s: KSerializer<T>): T {
        if (!online) throw EngineUnreachableException("connection refused")
        return decodeFixture(name, s)
    }

    override suspend fun health() = load("health.json", Health.serializer())
    override suspend fun overview() = load("overview.json", Overview.serializer())
    override suspend fun series(windowS: Double, maxPoints: Int) = load("series.json", Series.serializer())
    override suspend fun instrument() = load("instrument.json", Instrument.serializer())
    override suspend fun physics() = load("physics.json", PhysicsSwitches.serializer())
    override suspend fun setPhysics(switches: Map<String, Boolean>) =
        load("physics.json", PhysicsSwitches.serializer()).let { it.copy(switches = it.switches + switches) }
    override suspend fun earth(latDeg: Double?, lonDeg: Double?, altM: Double?) = load("earth.json", Earth.serializer())
    override suspend fun tides(hours: Int, stepS: Int) = load("tides.json", Tides.serializer())
    override suspend fun anomalies() = load("anomalies_nosurvey.json", Anomalies.serializer())
    override suspend fun runSurvey(durationS: Double, sampleRateHz: Double) = load("anomalies.json", Anomalies.serializer())
    override suspend fun calibration() = load("calibration.json", serializer<CalibrationReport?>())
    override suspend fun runCalibration(seed: Long?) = load("calibration.json", serializer<CalibrationReport?>())
    override suspend fun uncertainty() = load("uncertainty.json", UncertaintyBudget.serializer())
    override suspend fun runMonteCarlo(trials: Int, durationS: Double) = load("monte_carlo.json", MonteCarloResult.serializer())
    override suspend fun allan(maxPoints: Int) = load("allan.json", Allan.serializer())
    override suspend fun experiments() = load("experiments.json", ExperimentList.serializer())
    override suspend fun runExperiment(name: String, durationS: Double?, sampleRateHz: Double?) =
        load("experiment_static.json", ExperimentResult.serializer())
    override suspend fun map() = load("map.json", MapData.serializer())
    override suspend fun telemetry(n: Int) = load("telemetry.json", Telemetry.serializer())
    override suspend fun config() = load("config.json", JsonObject.serializer())
    override suspend fun control(request: ControlRequest): Health {
        controls += request
        return load("health.json", Health.serializer())
    }
}
