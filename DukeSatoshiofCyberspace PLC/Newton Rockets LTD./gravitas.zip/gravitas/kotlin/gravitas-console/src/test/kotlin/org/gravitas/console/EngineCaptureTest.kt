package org.gravitas.console

import kotlinx.serialization.KSerializer
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.serializer
import org.gravitas.console.api.*
import kotlin.test.Test
import kotlin.test.assertNotNull
import kotlin.test.assertTrue

/**
 * Integration contract test: payloads captured from the *real* Python engine
 * (tools/capture_api_fixtures.py) must decode into the console's DTOs.
 */
class EngineCaptureTest {
    private fun <T> eng(name: String, s: KSerializer<T>): T = decodeFixture("engine/$name.json", s)

    @Test
    fun everyEndpointDecodes() {
        val ov = eng("overview", Overview.serializer())
        assertNotNull(ov.localGravityMps2)
        assertTrue(ov.localGravityMps2!! > 9.7 && ov.localGravityMps2!! < 9.9)
        assertNotNull(eng("health", Health.serializer()))
        val s = eng("series", Series.serializer())
        assertTrue(!s.tS.isNullOrEmpty())
        assertNotNull(eng("instrument", Instrument.serializer()))
        assertNotNull(eng("physics", PhysicsSwitches.serializer()))
        assertNotNull(eng("physics_post", PhysicsSwitches.serializer()))
        assertNotNull(eng("earth", Earth.serializer()))
        assertNotNull(eng("tides", Tides.serializer()))
        assertNotNull(eng("anomalies_nosurvey", Anomalies.serializer()))
        assertNotNull(eng("anomalies", Anomalies.serializer()).survey)
        assertNotNull(eng("calibration", serializer<CalibrationReport?>()))
        assertNotNull(eng("uncertainty", UncertaintyBudget.serializer()))
        assertNotNull(eng("monte_carlo", MonteCarloResult.serializer()))
        assertNotNull(eng("allan", Allan.serializer()))
        assertTrue(!eng("experiments", ExperimentList.serializer()).experiments.isNullOrEmpty())
        assertNotNull(eng("experiment_static", ExperimentResult.serializer()))
        assertNotNull(eng("map", MapData.serializer()))
        assertTrue(!eng("telemetry", Telemetry.serializer()).frames.isNullOrEmpty())
        assertNotNull(eng("config", JsonObject.serializer()))
        assertNotNull(eng("control", Health.serializer()))
    }
}
