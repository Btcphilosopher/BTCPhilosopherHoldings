package org.gravitas.console

import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.serializer
import org.gravitas.console.api.Allan
import org.gravitas.console.api.Anomalies
import org.gravitas.console.api.ApiError
import org.gravitas.console.api.CalibrationReport
import org.gravitas.console.api.ControlRequest
import org.gravitas.console.api.Earth
import org.gravitas.console.api.ExperimentList
import org.gravitas.console.api.ExperimentResult
import org.gravitas.console.api.GravitasJson
import org.gravitas.console.api.Health
import org.gravitas.console.api.Instrument
import org.gravitas.console.api.MapData
import org.gravitas.console.api.MonteCarloResult
import org.gravitas.console.api.Overview
import org.gravitas.console.api.PhysicsPatch
import org.gravitas.console.api.PhysicsSwitches
import org.gravitas.console.api.Series
import org.gravitas.console.api.SurveyRequest
import org.gravitas.console.api.Telemetry
import org.gravitas.console.api.Tides
import org.gravitas.console.api.UncertaintyBudget
import org.gravitas.console.api.toArr
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFalse
import kotlin.test.assertNotNull
import kotlin.test.assertNull
import kotlin.test.assertTrue

class JsonParsingTest {
    @Test
    fun health() {
        val h = decodeFixture("health.json", Health.serializer())
        assertEquals("ok", h.status); assertEquals("1.0.0", h.softwareVersion)
        assertEquals(3723.4, h.simTimeS); assertEquals(true, h.running); assertEquals(1.0, h.speed)
    }

    @Test
    fun overview() {
        val o = decodeFixture("overview.json", Overview.serializer())
        assertEquals("STABLE", o.instrumentStatus)
        assertEquals(emptyList(), o.statusReasons)
        assertEquals(2.0, o.coverageFactor)
        assertEquals(53.38, o.latitudeDeg)
        assertEquals(1.2e-7, o.biasMps2)
        assertEquals(-4.1e-7, o.tidalComponentMps2)
        assertNotNull(o.correctedGravityMps2); assertNotNull(o.estimateMps2); assertNotNull(o.vibrationRmsMps2)
        assertEquals("equilibrium", o.mode)
    }

    @Test
    fun `overview tolerates nulls and unknown fields`() {
        val o = GravitasJson.decodeFromString(
            Overview.serializer(),
            """{"sim_time_s": 1.0, "local_gravity_mps2": null, "instrument_status": "SETTLING",
               "status_reasons": ["filter converging"], "future_field_mps2": 1.0, "nested": {"a": [1,2]}}""",
        )
        assertNull(o.localGravityMps2)
        assertEquals(listOf("filter converging"), o.statusReasons)
        assertNull(o.temperatureC)
    }

    @Test
    fun series() {
        val s = decodeFixture("series.json", Series.serializer())
        val n = s.tS!!.size
        assertEquals(600, n)
        for (arr in listOf(s.trueMps2, s.rawMps2, s.filteredMps2, s.calibratedMps2, s.correctedMps2, s.estimateMps2,
            s.estimateSigmaMps2, s.tideMps2, s.staticTrueMps2, s.temperatureC, s.vibrationMps2, s.biasMps2)) {
            assertEquals(n, arr!!.size)
        }
        assertEquals(10.0, s.sampleRateHz); assertEquals(60.0, s.windowS)
    }

    @Test
    fun `null array elements become NaN gaps`() {
        val s = GravitasJson.decodeFromString(Series.serializer(), """{"t_s": [0, 1, 2], "raw_mps2": [9.8, null, 9.81]}""")
        val raw = s.rawMps2.toArr()
        assertEquals(9.8, raw[0]); assertTrue(raw[1].isNaN()); assertEquals(9.81, raw[2])
        assertEquals(0, s.trueMps2.toArr().size)
    }

    @Test
    fun instrument() {
        val i = decodeFixture("instrument.json", Instrument.serializer())
        assertEquals("optical", i.readout!!.type)
        assertEquals(1.55e-6, i.readout!!.wavelengthM)
        assertEquals(24.0, i.adc!!.bits); assertEquals(123.0, i.adc!!.codeI); assertEquals(false, i.adc!!.saturated)
        assertEquals(0.3948, i.springConstantNpm)
        assertEquals(200, i.history!!.positionM!!.size)
    }

    @Test
    fun physics() {
        val p = decodeFixture("physics.json", PhysicsSwitches.serializer())
        assertEquals(12, p.switches.size)
        assertEquals(false, p.switches["sun"]); assertEquals(true, p.switches["moon"])
        assertEquals("""{"switches":{"moon":false}}""", GravitasJson.encodeToString(PhysicsPatch.serializer(), PhysicsPatch(mapOf("moon" to false))))
    }

    @Test
    fun earth() {
        val e = decodeFixture("earth.json", Earth.serializer())
        assertEquals(3, e.newtonianEnuMps2!!.size)
        assertEquals(-3.0857e-6, e.freeAirGradientMps2PerM)
        val lp = e.latitudeProfile!!
        assertEquals(lp.latDeg!!.size, lp.centrifugalUpMps2!!.size)
        assertEquals(101, e.altitudeProfile!!.altM!!.size)
        assertEquals(53.38, e.location!!.latitudeDeg)
    }

    @Test
    fun tides() {
        val t = decodeFixture("tides.json", Tides.serializer())
        assertEquals(t.tS!!.size, t.timestamps!!.size)
        assertEquals(1.16, t.gravimetricFactor)
        assertNotNull(t.current!!.combinedMps2)
    }

    @Test
    fun anomalies() {
        val none = decodeFixture("anomalies_nosurvey.json", Anomalies.serializer())
        assertEquals("SYNTHETIC GEOPHYSICAL MODEL", none.label)
        assertNull(none.survey)
        val b = none.bodies!!.first()
        assertEquals("sphere", b.kind)
        assertEquals(50.0, b.params!!["radius_m"]!!.jsonPrimitive.content.toDouble())
        val g = none.grid!!
        assertEquals(g.northM!!.size, g.anomalyMps2!!.size)
        assertEquals(g.eastM!!.size, g.anomalyMps2!!.first().size)
        val with = decodeFixture("anomalies.json", Anomalies.serializer())
        assertEquals(1.4e-8, with.survey!!.rmsErrorMps2)
        assertEquals(with.survey!!.distanceM!!.size, with.survey!!.uncertaintyMps2!!.size)
        assertEquals("""{"duration_s":1800.0,"sample_rate_hz":10.0}""", GravitasJson.encodeToString(SurveyRequest.serializer(), SurveyRequest(1800.0, 10.0)))
    }

    @Test
    fun calibration() {
        val c = decodeFixture("calibration.json", serializer<CalibrationReport?>())!!
        assertEquals(2e-6, c.injected!!.biasMps2)
        assertEquals(1.0002, c.injected!!.scaleFactor)
        assertEquals(5e-9, c.estimatedUncertainty!!.temperatureCoefficientMps2PerK)
        assertEquals(1e-10, c.injected!!.driftRateMps2PerS)
        assertEquals(c.series!!.tS!!.size, c.series!!.uncalibratedMps2!!.size)
        // GET /calibration before any run returns JSON null
        assertNull(decodeFixture("calibration_null.json", serializer<CalibrationReport?>()))
    }

    @Test
    fun uncertainty() {
        val u = decodeFixture("uncertainty.json", UncertaintyBudget.serializer())
        assertEquals(6, u.contributions!!.size)
        val c = u.contributions!!.first()
        assertEquals("sensor_noise", c.name); assertEquals("A", c.type); assertEquals("m/s^2", c.inputUnit)
        assertEquals(2.0, u.coverageFactor)
        val mc = decodeFixture("monte_carlo.json", MonteCarloResult.serializer())
        assertEquals(200.0, mc.trials); assertEquals(2, mc.ci95Mps2!!.size); assertEquals(200, mc.errorsMps2!!.size)
        assertEquals(1.024, mc.ratioMcToAnalytical)
    }

    @Test
    fun allan() {
        val a = decodeFixture("allan.json", Allan.serializer())
        assertEquals(a.tauS!!.size, a.adevMps2!!.size)
        assertEquals(a.tauS!!.size, a.adevLoMps2!!.size)
        assertEquals(36000.0, a.nSamples)
        val id = a.identification!!
        assertEquals(5e-8, id.whiteNoiseMps2PerRtHz)
        assertEquals(3, id.regions!!.size)
        assertEquals(-0.5, id.regions!!.first().slope)
        assertEquals("white noise", id.regions!!.first().label)
    }

    @Test
    fun experiments() {
        val l = decodeFixture("experiments.json", ExperimentList.serializer())
        assertEquals(listOf("static", "altitude", "latitude", "tides", "anomaly", "vibration"), l.experiments.map { it.name })
        val r = decodeFixture("experiment_static.json", ExperimentResult.serializer())
        assertEquals("static", r.name)
        assertEquals(3.2e-9, (r.summary!!["final_error_mps2"] as JsonPrimitive).content.toDouble())
        assertEquals("m/s^2", r.series!!.yUnit)
        assertEquals("time [s]", r.series!!.xLabel)
        assertEquals(setOf("true", "estimate"), r.series!!.curves!!.keys)
    }

    @Test
    fun map() {
        val m = decodeFixture("map.json", MapData.serializer())
        assertEquals(53.38, m.instrument!!.latitudeDeg)
        assertEquals(21, m.surveyPath!!.size)
        val g = m.gravityGrid!!
        assertEquals(g.latDeg!!.size, g.gMps2!!.size); assertEquals(g.lonDeg!!.size, g.gMps2!!.first().size)
        assertEquals(m.anomalyGrid!!.latDeg!!.size, m.anomalyGrid!!.anomalyMps2!!.size)
    }

    @Test
    fun telemetry() {
        val t = decodeFixture("telemetry.json", Telemetry.serializer())
        assertEquals(50, t.frames.size)
        val f = t.frames.first()
        assertEquals("STABLE", f.status); assertEquals(8388608.0, f.adcCode)
        assertNotNull(f.lunarComponentMps2); assertNotNull(f.proofMassPositionM); assertNotNull(f.correctedMeasurementMps2)
    }

    @Test
    fun config() {
        val c = decodeFixture("config.json", JsonObject.serializer())
        assertEquals("42", c["seed"]!!.jsonPrimitive.content)
        assertTrue(c.containsKey("config_hash"))
    }

    @Test
    fun `error body`() {
        assertEquals("unknown experiment 'foo'", decodeFixture("error.json", ApiError.serializer()).error)
    }

    @Test
    fun `control requests encode only relevant fields`() {
        fun enc(r: ControlRequest) = GravitasJson.encodeToString(ControlRequest.serializer(), r)
        assertEquals("""{"action":"pause"}""", enc(ControlRequest.pause()))
        assertEquals("""{"action":"resume"}""", enc(ControlRequest.resume()))
        assertEquals("""{"action":"reset","seed":42}""", enc(ControlRequest.reset(42)))
        assertEquals("""{"action":"set_speed","speed":60.0}""", enc(ControlRequest.setSpeed(60.0)))
        assertEquals("""{"action":"set_mode","mode":"feedback"}""", enc(ControlRequest.setMode("feedback")))
        assertEquals(
            """{"action":"set_location","latitude_deg":0.0,"longitude_deg":0.0,"altitude_m":0.0}""",
            enc(ControlRequest.setLocation(0.0, 0.0, 0.0)),
        )
        assertFalse(enc(ControlRequest.pause()).contains("null"))
    }
}
