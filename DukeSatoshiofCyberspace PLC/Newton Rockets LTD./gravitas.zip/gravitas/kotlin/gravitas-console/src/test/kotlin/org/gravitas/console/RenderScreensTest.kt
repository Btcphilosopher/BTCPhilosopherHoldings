package org.gravitas.console

import androidx.compose.ui.ImageComposeScene
import androidx.compose.ui.unit.Density
import androidx.compose.ui.use
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.runBlocking
import org.gravitas.console.state.ConsoleStore
import org.gravitas.console.state.Screen
import org.gravitas.console.ui.ConsoleApp
import org.jetbrains.skia.EncodedImageFormat
import java.io.File
import kotlin.test.Test
import kotlin.test.assertTrue

/**
 * Headless render check: draws every screen from fixture data with Skia (no window system)
 * and writes PNGs to build/screenshots for visual inspection.
 */
class RenderScreensTest {
    private val outDir = File(System.getProperty("gravitas.screenshotDir") ?: "build/screenshots").apply { mkdirs() }

    private fun render(store: ConsoleStore, name: String, width: Int = 1600, height: Int = 1250): File {
        val image = ImageComposeScene(width, height, Density(1f)) { ConsoleApp(store) }.use { scene ->
            scene.render(0L)
            scene.render(16_000_000L)
        }
        val data = requireNotNull(image.encodeToData(EncodedImageFormat.PNG)) { "PNG encoding failed" }
        val f = File(outDir, "$name.png")
        f.writeBytes(data.bytes)
        return f
    }

    private fun connectedStore(): ConsoleStore {
        val api = FixtureApi()
        val s = ConsoleStore(api, CoroutineScope(SupervisorJob() + Dispatchers.Unconfined))
        runBlocking {
            s.refreshAll()
            s.anomalies = api.runSurvey(1800.0, 10.0)
            s.monteCarlo = api.runMonteCarlo(200, 300.0)
            s.experimentResults["static"] = api.runExperiment("static", 600.0, 10.0)
        }
        return s
    }

    @Test
    fun `render every screen from fixtures`() {
        val store = connectedStore()
        for (screen in Screen.entries) {
            store.showScreenForTest(screen)
            val f = render(store, "%02d-%s".format(screen.ordinal + 1, screen.name.lowercase()))
            assertTrue(f.length() > 20_000, "${f.name} looks blank (${f.length()} bytes)")
        }
    }

    @Test
    fun `render with physics inspector drawer and alternate unit`() {
        val store = connectedStore()
        store.showScreenForTest(Screen.SIGNAL)
        store.inspectorOpen = true
        store.unit = org.gravitas.console.units.GravityUnit.MGAL
        assertTrue(render(store, "14-signal-inspector-mgal").length() > 20_000)
    }

    @Test
    fun `render disconnected state`() {
        val api = FixtureApi(online = false)
        val store = ConsoleStore(api, CoroutineScope(SupervisorJob() + Dispatchers.Unconfined))
        runBlocking { store.pollFast() }
        store.showScreenForTest(Screen.OVERVIEW)
        assertTrue(render(store, "15-overview-disconnected").length() > 5_000)
    }
}
