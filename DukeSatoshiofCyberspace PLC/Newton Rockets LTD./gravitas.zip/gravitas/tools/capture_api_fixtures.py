"""Capture real engine API responses as fixtures for the Kotlin console's integration tests.

    python tools/capture_api_fixtures.py [out_dir]

Runs the live engine in-process (deterministic: the background thread is not
started; the twin is advanced explicitly), calls every endpoint through the
same route table the HTTP server uses, and writes the JSON payloads.
"""

from __future__ import annotations

import json
import sys
from pathlib import Path

from gravitas.api.live import LiveSimulation, live_default_config
from gravitas.api.server import Api, sanitize


def main() -> None:
    out = Path(sys.argv[1] if len(sys.argv) > 1 else "kotlin/gravitas-console/src/test/resources/fixtures/engine")
    out.mkdir(parents=True, exist_ok=True)
    live = LiveSimulation(live_default_config())
    live.advance(int(900 * live.engine.config.sample_rate_hz))
    api = Api(live)

    def get(path, **q):
        return api.handle("GET", "/api/v1" + path, {k: [str(v)] for k, v in q.items()}, None)

    def post(path, body):
        return api.handle("POST", "/api/v1" + path, {}, body)

    payloads = {
        "health": get("/health"), "overview": get("/overview"), "series": get("/series", window_s=600, max_points=400),
        "instrument": get("/instrument"), "physics": get("/physics"), "earth": get("/earth"),
        "tides": get("/tides", hours=48, step_s=1800), "anomalies_nosurvey": get("/anomalies"),
        "calibration_null": get("/calibration"), "uncertainty": get("/uncertainty"), "allan": get("/allan"),
        "experiments": get("/experiments"), "map": get("/map"), "telemetry": get("/telemetry", n=20),
        "config": get("/config"),
        "experiment_static": post("/experiments/static", {"duration_s": 300, "max_points": 300}),
        "anomalies": post("/anomalies/survey", {"duration_s": 900, "sample_rate_hz": 10}),
        "calibration": post("/calibration/run", {"seed": 7}),
        "monte_carlo": post("/uncertainty/monte-carlo", {"trials": 8, "duration_s": 120}),
        "physics_post": post("/physics", {"switches": {"moon": False}}),
        "control": post("/control", {"action": "set_speed", "speed": 2}),
    }
    for name, p in payloads.items():
        (out / f"{name}.json").write_text(json.dumps(sanitize(p), allow_nan=False))
    print(json.dumps({"written": sorted(payloads), "dir": str(out)}))


if __name__ == "__main__":
    main()
