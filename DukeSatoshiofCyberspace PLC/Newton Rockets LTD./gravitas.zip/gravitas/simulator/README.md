# simulator/

* `configurations/` — instrument/environment variants (complete `SimulationConfig` JSON files).
* `scenarios/` — complete runnable scenarios (location, trajectory, duration).
* `datasets/` — engine-generated reference datasets analysed independently by `r/`;
  regenerate with `make datasets` (`python simulator/datasets/generate_datasets.py`).

Every file is a strict `SimulationConfig` (unknown keys are rejected). Use with any command:

```bash
gravitas simulate --config simulator/scenarios/anomaly_survey.json --out output/survey
```
