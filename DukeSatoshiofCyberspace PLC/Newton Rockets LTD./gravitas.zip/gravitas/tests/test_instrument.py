"""Gravimeter twin: measurement relationship, dynamics, feedback, optical readout, ADC."""

import math

import numpy as np
import pytest

from gravitas.instrument.adc import ADC
from gravitas.instrument.feedback import FeedbackController
from gravitas.instrument.gravimeter import Gravimeter, GravimeterConfig, zoh_discretise
from gravitas.instrument.interferometer import Interferometer
from gravitas.instrument.optical_readout import OpticalReadout
from gravitas.instrument.proof_mass import ProofMass
from gravitas.instrument.spring import Spring
from gravitas.instrument.thermal import ThermalConfig, ThermalModel

G_REF = 9.81


def _run(cfg, a, sr=10.0, noise=False, seed=0):
    gm = Gravimeter(cfg, sr, G_REF)
    n = a.size
    rng = np.random.default_rng(seed)
    s1, s2 = gm.readout_noise_sigmas()
    n1 = rng.standard_normal(n) * s1 if noise else np.zeros(n)
    n2 = rng.standard_normal(n) * s2 if noise else np.zeros(n)
    return gm, gm.run(a, n1, n2)


def test_spring_measurement_relationship():
    sp = Spring(1.0, 0.7)
    m = 0.01
    k = sp.spring_constant(m)
    assert k == pytest.approx(m * (2 * math.pi) ** 2)
    x = sp.equilibrium_displacement(G_REF + 1e-8, G_REF)
    assert x == pytest.approx(1e-8 / (2 * math.pi) ** 2)  # 0.253 nm per µGal
    # F = m g balanced by F = k (x + x0)
    assert sp.force(x, m, G_REF) == pytest.approx(m * (G_REF + 1e-8), rel=1e-15)


@pytest.mark.parametrize("dg", [0.0, 1e-8, 5e-7, -3e-6, 1e-4])
def test_known_input_gives_expected_static_reading(dg):
    cfg = GravimeterConfig()
    n = 600 * cfg.oversample
    gm = Gravimeter(cfg, 10.0, G_REF)
    gm.initialise_equilibrium(G_REF + dg)
    out = gm.run(np.full(n, G_REF + dg), np.zeros(n), np.zeros(n))
    assert out.raw_gravity_mps2[-10:].mean() - G_REF == pytest.approx(dg, abs=2e-11)
    assert out.position_m[-1] == pytest.approx(dg / gm.omega0**2, rel=1e-6, abs=1e-15)
    assert out.gravity_force_n[-1] == pytest.approx(gm.mass * (G_REF + dg))
    assert out.spring_force_n[-1] == pytest.approx(gm.mass * (G_REF + dg), rel=1e-12)


def test_step_response_matches_second_order_system():
    cfg = GravimeterConfig(spring=Spring(1.0, 0.2), oversample=100)
    n = 20 * 10 * cfg.oversample
    gm = Gravimeter(cfg, 10.0, G_REF)
    a = np.full(n, G_REF + 1e-5)
    out = gm.run(a, np.zeros(n), np.zeros(n))
    # analytic step response of an under-damped oscillator
    w0, z = 2 * math.pi, 0.2
    wd = w0 * math.sqrt(1 - z * z)
    t = (np.arange(out.position_last_m.size) + 1) * 0.1
    x_an = 1e-5 / w0**2 * (1 - np.exp(-z * w0 * t) * (np.cos(wd * t) + z / math.sqrt(1 - z * z) * np.sin(wd * t)))
    assert np.max(np.abs(out.position_last_m - x_an)) < 1e-12


def test_zoh_discretisation_is_exact_for_free_oscillation():
    ad, bd = zoh_discretise(2 * math.pi, 0.0, 0.01)
    assert np.linalg.det(ad) == pytest.approx(1.0, abs=1e-12)  # undamped: area-preserving
    s = np.array([1.0, 0.0])
    for _ in range(100):
        s = ad @ s
    assert s[0] == pytest.approx(math.cos(2 * math.pi * 1.0), abs=1e-10)


def test_high_frequency_vibration_is_attenuated():
    cfg = GravimeterConfig(oversample=20)
    sr = 10.0
    n = 120 * int(sr) * cfg.oversample
    t = np.arange(n) / (sr * cfg.oversample)
    a = G_REF + 1e-5 * np.sin(2 * math.pi * 8.0 * t)
    _, out = _run(cfg, a, sr)
    resp = np.std(out.position_last_m[100:]) * math.sqrt(2)
    static = 1e-5 / (2 * math.pi) ** 2
    assert resp < static / 30  # (f0/f)² ≈ 1/64 for f ≫ f0


def test_feedback_mode_reads_through_actuator_force():
    cfg = GravimeterConfig(mode="feedback", feedback=FeedbackController(enabled=True))
    n = 600 * cfg.oversample
    gm = Gravimeter(cfg, 10.0, G_REF)
    a = np.full(n, G_REF + 5e-6)
    out = gm.run(a, np.zeros(n), np.zeros(n))
    assert abs(out.position_m[-1]) < 1e-12  # proof mass held at null
    assert out.feedback_force_n[-50:].mean() == pytest.approx(-gm.mass * 5e-6, rel=1e-3)
    assert out.raw_gravity_mps2[-200:].mean() - G_REF == pytest.approx(5e-6, abs=5e-10)


def test_mechanical_stops_saturate():
    cfg = GravimeterConfig()
    n = 100 * cfg.oversample
    _, out = _run(cfg, np.full(n, G_REF + 0.1))  # 10 Gal off-range
    assert out.stop_contact_count.sum() > 0
    assert np.max(out.position_m) <= cfg.proof_mass.stop_m * (1 + 1e-12)


def test_interferometer_phase_and_demodulation():
    ifo = Interferometer()
    x = np.linspace(-2e-7, 2e-7, 11)
    i, q = ifo.intensities(x)
    ph = ifo.demodulate(i, q)
    assert np.allclose(ifo.displacement_from_phase(ph), x, atol=1e-15)
    assert ifo.phase_per_metre == pytest.approx(4 * math.pi / 1.55e-6)


def test_optical_and_linear_readouts_agree():
    # tolerance = ADC quantisation referred to gravity: linear transducer LSB 1.19 µV / (2e5 V/m) × ω₀² ≈ 2.4e-10
    for opt, tol in ((True, 1e-11), (False, 3e-10)):
        cfg = GravimeterConfig(optical=OpticalReadout(enabled=opt))
        n = 300 * cfg.oversample
        gm = Gravimeter(cfg, 10.0, G_REF)
        gm.initialise_equilibrium(G_REF + 2e-6)
        out = gm.run(np.full(n, G_REF + 2e-6), np.zeros(n), np.zeros(n))
        assert out.raw_gravity_mps2[-1] - G_REF == pytest.approx(2e-6, abs=tol)


def test_readout_noise_propagates_with_expected_level():
    cfg = GravimeterConfig()
    n = 600 * cfg.oversample
    gm = Gravimeter(cfg, 10.0, G_REF)
    rng = np.random.default_rng(3)
    s = 1e-3  # exaggerated photodetector noise [V]
    out = gm.run(np.full(n, G_REF), rng.standard_normal(n) * s, rng.standard_normal(n) * s)
    # phase noise σφ = σV / (P0/2 · V), averaged over the oversample block
    ifo = cfg.optical.interferometer
    sig_phi = s / (0.5 * ifo.peak_voltage_v * ifo.visibility)
    expected = sig_phi / ifo.phase_per_metre / math.sqrt(cfg.oversample) * gm.omega0**2
    got = np.std(out.raw_gravity_mps2[50:] - np.mean(out.raw_gravity_mps2[50:]))
    assert got == pytest.approx(expected, rel=0.15)


def test_adc_quantisation_properties(rng):
    adc = ADC(bits=12, v_min=0.0, v_max=4.096)
    assert adc.lsb_v == pytest.approx(0.001)
    v = rng.uniform(0.5, 3.5, 200_000)
    codes, vq, sat = adc.quantise(v)
    assert not sat.any()
    err = vq - v
    assert np.max(np.abs(err)) <= adc.lsb_v / 2 + 1e-15
    assert np.std(err) == pytest.approx(adc.quantisation_noise_v, rel=0.02)
    codes, _, sat = adc.quantise(np.array([-1.0, 10.0]))
    assert sat.all() and codes[0] == 0 and codes[1] == 4095
    with pytest.raises(ValueError):
        ADC(bits=12, v_min=0, v_max=1, noise_v_rms=1e-3).quantise(np.zeros(3))


def test_invalid_instrument_parameters():
    with pytest.raises(ValueError):
        ProofMass(-1.0)
    with pytest.raises(ValueError):
        Spring(0.0)
    with pytest.raises(ValueError):
        GravimeterConfig(mode="magic")
    gm = Gravimeter(GravimeterConfig(), 10.0, G_REF)
    with pytest.raises(FloatingPointError):
        gm.run(np.full(10, np.nan), np.zeros(10), np.zeros(10))
    with pytest.raises(ValueError):
        gm.run(np.zeros(7), np.zeros(7), np.zeros(7))


def test_thermal_first_order_lag():
    cfg = ThermalConfig(diurnal_amplitude_k=0.0, ambient_random_walk_k_per_rts=0.0, thermostat_leakage=1.0,
                        ambient_mean_c=25.0, set_point_c=20.0, time_constant_s=100.0, sensor_noise_k=0.0)
    th = ThermalModel(cfg, np.random.default_rng(0), np.random.default_rng(1))
    th._t_inst = 20.0
    out = th.step(np.arange(0, 1000, 1.0), 1.0)
    # T(t) = 25 − 5 e^{−t/τ}
    assert out["instrument_c"][100] == pytest.approx(25 - 5 * math.exp(-1.0), rel=1e-9)
