"""Coordinate transformations: geodetic ↔ ECEF ↔ ENU, validation of invalid input."""

import math

import numpy as np
import pytest

from gravitas.earth.coordinates import (CoordinateError, GeodeticPosition, ecef_to_enu, ecef_to_geodetic,
                                        enu_to_ecef, enu_to_geodetic, enu_rotation_matrix, geodetic_to_ecef,
                                        normalize_longitude_deg, validate_geodetic, vector_ecef_to_enu)
from gravitas.earth.ellipsoid import SPHERE, WGS84


def test_known_ecef_values():
    # equator / prime meridian
    assert np.allclose(geodetic_to_ecef(0.0, 0.0, 0.0), [WGS84.a, 0, 0], atol=1e-9)
    # north pole
    assert np.allclose(geodetic_to_ecef(math.pi / 2, 0.0, 0.0), [0, 0, WGS84.b], atol=1e-6)
    # 90° E at 100 m
    assert np.allclose(geodetic_to_ecef(0.0, math.pi / 2, 100.0), [0, WGS84.a + 100.0, 0], atol=1e-6)


@pytest.mark.parametrize("lat", [-89.999, -45.0, -1e-7, 0.0, 33.3, 53.38, 89.999, 90.0])
@pytest.mark.parametrize("h", [-11_000.0, 0.0, 100.0, 8848.0, 400_000.0, 3.6e7])
def test_round_trip_geodetic_ecef(lat, h):
    lon = math.radians(-1.47)
    x = geodetic_to_ecef(math.radians(lat), lon, h)
    la, lo, hh = ecef_to_geodetic(x)
    assert abs(math.degrees(float(la)) - lat) < 1e-9
    if abs(lat) < 90:
        assert abs(float(lo) - lon) < 1e-12
    assert abs(float(hh) - h) < 1e-5


def test_vectorised_round_trip(rng):
    lat = rng.uniform(-math.pi / 2, math.pi / 2, 5000)
    lon = rng.uniform(-math.pi, math.pi, 5000)
    h = rng.uniform(-1000, 50_000, 5000)
    la, lo, hh = ecef_to_geodetic(geodetic_to_ecef(lat, lon, h))
    assert np.max(np.abs(la - lat)) < 1e-12
    assert np.max(np.abs(hh - h)) < 1e-6


def test_sphere_round_trip():
    x = geodetic_to_ecef(0.3, 0.2, 10.0, SPHERE)
    la, lo, hh = ecef_to_geodetic(x, SPHERE)
    assert float(la) == pytest.approx(0.3, abs=1e-14) and float(hh) == pytest.approx(10.0, abs=1e-8)


def test_enu_round_trip_and_orthonormality():
    o = GeodeticPosition.from_degrees(53.38, -1.47, 100.0)
    r = enu_rotation_matrix(o.latitude_rad, o.longitude_rad)
    assert np.allclose(r @ r.T, np.eye(3), atol=1e-15)
    assert np.linalg.det(r) == pytest.approx(1.0, abs=1e-14)
    enu = np.array([[100.0, -250.0, 12.0], [0.0, 0.0, 0.0], [-5e3, 7e3, -30.0]])
    back = ecef_to_enu(enu_to_ecef(enu, o), o)
    assert np.allclose(back, enu, atol=1e-7)


def test_enu_up_is_ellipsoidal_normal():
    o = GeodeticPosition.from_degrees(45.0, 10.0, 0.0)
    lat, lon, h = enu_to_geodetic(np.array([0.0, 0.0, 50.0]), o)
    assert math.degrees(float(lat)) == pytest.approx(45.0, abs=1e-10)
    assert float(h) == pytest.approx(50.0, abs=1e-6)


def test_east_vector_is_horizontal():
    v = vector_ecef_to_enu(np.array([0.0, 1.0, 0.0]), 0.0, 0.0)
    assert np.allclose(v, [1, 0, 0])


@pytest.mark.parametrize("lat,lon,h", [(91.0, 0.0, 0.0), (-90.5, 0, 0), (0, 181, 0), (0, -180.1, 0),
                                       (float("nan"), 0, 0), (0, 0, float("inf")), (0, 0, -20_000.0), (0, 0, 1e9)])
def test_invalid_coordinates_rejected(lat, lon, h):
    with pytest.raises(CoordinateError):
        validate_geodetic(lat, lon, h)
    with pytest.raises(CoordinateError):
        GeodeticPosition.from_degrees(lat, lon, h)


def test_no_silent_wrapping_but_explicit_helper():
    with pytest.raises(CoordinateError):
        GeodeticPosition.from_degrees(0.0, 190.0, 0.0)
    assert normalize_longitude_deg(190.0) == pytest.approx(-170.0)


def test_centre_of_earth_rejected():
    with pytest.raises(CoordinateError):
        ecef_to_geodetic(np.zeros(3))


def test_degree_radian_constructors_agree():
    a = GeodeticPosition.from_degrees(53.38, -1.47, 100.0)
    b = GeodeticPosition.from_radians(math.radians(53.38), math.radians(-1.47), 100.0)
    assert a.latitude_rad == pytest.approx(b.latitude_rad, abs=0) and a.as_dict()["latitude_deg"] == pytest.approx(53.38)
