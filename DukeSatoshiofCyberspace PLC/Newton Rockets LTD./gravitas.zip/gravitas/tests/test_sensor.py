"""Sensor error models: bias, scale factor, drift, white & correlated noise, vibration, cross-axis.

Statistical tests use fixed seeds and tolerances derived from the sampling
distribution of the estimator (≈ 4–5 σ), so they are deterministic and not flaky.
"""

import math

import numpy as np
import pytest
from scipy import stats

from gravitas.estimation.allan import overlapping_adev
from gravitas.sensors.bias import ConstantBias, TemperatureBias
from gravitas.sensors.cross_axis import CrossAxisConfig, CrossAxisModel
from gravitas.sensors.drift import DriftConfig, DriftModel
from gravitas.sensors.noise import GaussMarkovEnsemble, NoiseConfig, WhiteNoise
from gravitas.sensors.scale_factor import ScaleFactor
from gravitas.sensors.vibration import VibrationConfig, VibrationLine, VibrationModel
from gravitas.simulation.engine import SimulationEngine


def test_constant_and_temperature_bias():
    assert np.all(ConstantBias(1.5e-6).evaluate(4) == 1.5e-6)
    tb = TemperatureBias(5e-7, 20.0)
    assert np.allclose(tb.evaluate([19.0, 20.0, 22.0]), [-5e-7, 0.0, 1e-6])
    with pytest.raises(ValueError):
        ConstantBias(float("nan"))


def test_scale_factor_y_equals_s_x():
    sf = ScaleFactor(error_ppm=200.0, temperature_coefficient_ppm_per_k=10.0)
    assert sf.apply(1e-3) == pytest.approx(1.0002e-3)
    assert sf.apply(1e-3, 21.0) == pytest.approx(1e-3 * (1.0002 + 1e-5))
    with pytest.raises(ValueError):
        ScaleFactor(error_ppm=2e5)


def test_drift_deterministic_terms():
    d = DriftModel(DriftConfig(linear_rate_mps2_per_s=2e-12, quadratic_mps2_per_s2=1e-18,
                               settling_amplitude_mps2=1e-7, settling_time_constant_s=100.0), np.random.default_rng(0))
    t = np.array([0.0, 100.0, 1e4])
    out = d.step(t, 1.0)
    exp = 2e-12 * t + 1e-18 * t**2 + 1e-7 * (1 - np.exp(-t / 100.0))
    assert np.allclose(out["total_mps2"], exp, rtol=1e-12, atol=0)


def test_drift_random_walk_variance_grows_linearly():
    sig = 1e-10
    walks = []
    for s in range(400):
        d = DriftModel(DriftConfig(random_walk_mps2_per_rts=sig), np.random.default_rng(s))
        walks.append(d.step(np.arange(0, 1000.0, 1.0), 1.0)["random_walk_mps2"][-1])
    var = np.var(walks, ddof=1)
    assert var == pytest.approx(sig**2 * 1000.0, rel=0.25)  # χ²(399): ±~3σ ≈ ±21 %


def test_white_noise_distribution_matches_configuration():
    w = WhiteNoise(3e-8, 100.0, np.random.default_rng(42))
    x = w.step(400_000)
    assert w.sigma == pytest.approx(3e-8 * math.sqrt(50.0))
    assert abs(x.mean()) < 5 * w.sigma / math.sqrt(x.size)
    assert x.std(ddof=1) == pytest.approx(w.sigma, rel=0.006)
    assert stats.kstest(x / w.sigma, "norm").pvalue > 1e-3
    # one-sided ASD recovered by Welch PSD
    from scipy.signal import welch

    f, p = welch(x, fs=100.0, nperseg=4096)
    assert math.sqrt(np.median(p[5:-5])) == pytest.approx(3e-8, rel=0.05)


def test_white_noise_allan_slope_is_minus_half():
    w = WhiteNoise(1e-7, 10.0, np.random.default_rng(5))
    r = overlapping_adev(w.step(200_000), 0.1)
    sel = (r.tau_s > 0.5) & (r.tau_s < 500)
    slope = np.polyfit(np.log10(r.tau_s[sel]), np.log10(r.adev[sel]), 1)[0]
    assert slope == pytest.approx(-0.5, abs=0.05)
    assert r.at(1.0) == pytest.approx(1e-7 / math.sqrt(2.0), rel=0.05)


def test_gauss_markov_stationary_variance_and_correlation():
    cfg = NoiseConfig(correlated_sigma_mps2=1e-8, correlated_tau_min_s=20.0, correlated_tau_max_s=20.0,
                      correlated_components=1)
    gm = GaussMarkovEnsemble(cfg, 1.0, np.random.default_rng(9))
    x = gm.step(400_000)
    assert np.std(x) == pytest.approx(1e-8, rel=0.05)
    rho = np.corrcoef(x[:-20], x[20:])[0, 1]
    assert rho == pytest.approx(math.exp(-1.0), abs=0.02)


def test_correlated_noise_produces_flat_allan_region():
    cfg = NoiseConfig(correlated_sigma_mps2=1e-8, correlated_tau_min_s=10.0, correlated_tau_max_s=1e4,
                      correlated_components=8)
    x = GaussMarkovEnsemble(cfg, 1.0, np.random.default_rng(2)).step(300_000)
    r = overlapping_adev(x, 1.0)
    sel = (r.tau_s > 30) & (r.tau_s < 3000)
    slope = np.polyfit(np.log10(r.tau_s[sel]), np.log10(r.adev[sel]), 1)[0]
    assert abs(slope) < 0.25  # approximately flicker: bias-instability plateau


def test_chunked_noise_equals_one_shot():
    a = WhiteNoise(1e-8, 10.0, np.random.default_rng(1)).step(1000)
    w = WhiteNoise(1e-8, 10.0, np.random.default_rng(1))
    b = np.concatenate([w.step(300), w.step(700)])
    assert np.array_equal(a, b)
    cfg = NoiseConfig(correlated_sigma_mps2=1e-8)
    g1 = GaussMarkovEnsemble(cfg, 0.1, np.random.default_rng(3)).step(1000)
    g = GaussMarkovEnsemble(cfg, 0.1, np.random.default_rng(3))
    g2 = np.concatenate([g.step(1), g.step(499), g.step(500)])
    assert np.allclose(g1, g2, rtol=0, atol=1e-24)


def test_vibration_spectrum_lines_and_band():
    cfg = VibrationConfig(lines=[VibrationLine(0.2, 1e-6, 2)], broadband_rms_mps2=(0.0, 0.0, 1e-6), band_hz=(0.5, 20.0))
    v = VibrationModel(cfg, 100.0, np.random.default_rng(4))
    a = v.step(np.arange(0, 600, 0.01))
    assert a[:, 0].std() == 0.0
    from scipy.signal import welch

    f, p = welch(a[:, 2], fs=100.0, nperseg=2**14)
    assert f[np.argmax(p)] == pytest.approx(0.2, abs=0.01)
    assert np.sqrt(np.mean(a[:, 2] ** 2)) == pytest.approx(math.sqrt(1e-12 / 2 + 1e-12), rel=0.1)
    off = VibrationModel(cfg, 100.0, np.random.default_rng(4), enabled=False).step(np.arange(0, 1, 0.01))
    assert not off.any()


def test_cross_axis_leakage_and_tilt():
    m = CrossAxisModel(CrossAxisConfig(coupling_east=1e-3, coupling_north=0.0, tilt_east_rad=1e-4, tilt_north_rad=0.0))
    assert m.leakage(1.0, 1.0) == pytest.approx(1e-3 + 1e-4)
    assert m.tilt_term(9.81) == pytest.approx(-9.81 * 1e-8 / 2)


def test_injected_bias_appears_in_measurement(quiet_config):
    cfg = quiet_config.model_copy(update={"sensor": quiet_config.sensor.model_copy(update={"bias_mps2": 7.0e-6})})
    r = SimulationEngine(cfg).run()
    sel = r.t_s > 30
    resid = r["raw.gravity_mps2"][sel] - r["truth.gravity_mps2"][sel]
    # raw − true = S·0 + bias + drift + temperature bias + tilt (small)
    assert resid.mean() == pytest.approx(7.0e-6, abs=2e-9)
    no_bias = cfg.model_copy(update={"physics": cfg.physics.model_copy(update={"sensor_bias": False})})
    r2 = SimulationEngine(no_bias).run()
    assert abs((r2["raw.gravity_mps2"][sel] - r2["truth.gravity_mps2"][sel]).mean()) < 2e-9


def test_scale_factor_error_scales_deviation(quiet_config):
    sensor = quiet_config.sensor.model_copy(update={"bias_mps2": 0.0, "scale_factor_error_ppm": 1e4,
                                                    "drift_linear_mps2_per_s": 0.0, "drift_random_walk_mps2_per_rts": 0.0,
                                                    "temperature_coefficient_mps2_per_k": 0.0, "correlated_sigma_mps2": 0.0})
    g_true = SimulationEngine(quiet_config.model_copy(update={"duration_s": 1.0}))._true_static_at(np.zeros((1, 3)))[0]
    cfg = quiet_config.model_copy(update={"sensor": sensor, "g_ref_override_mps2": float(g_true) - 1e-3})
    r = SimulationEngine(cfg).run()
    dev_true = r["truth.gravity_mps2"][-100:].mean() - (g_true - 1e-3)
    dev_raw = r["raw.gravity_mps2"][-100:].mean() - (g_true - 1e-3)
    assert dev_raw / dev_true == pytest.approx(1.01, abs=2e-5)
