"""Earth gravity field: Newtonian inverse square, oblateness, rotation, altitude, latitude, units."""

import math

import numpy as np
import pytest

from gravitas.constants import physical as pc
from gravitas.constants.units import GravityUnit, convert, format_gravity, mps2_to_ugal, parse_unit, ugal_to_mps2
from gravitas.earth.ellipsoid import SPHERE, WGS84, Ellipsoid
from gravitas.earth.gravity import EarthGravityModel, EarthModelSwitches, compare_models
from gravitas.earth.normal_gravity import (free_air_gradient, normal_gravity_free_air, somigliana,
                                           spherical_gravity, spherical_gravity_at_radius)
from gravitas.physics.acceleration import point_mass_acceleration, zonal_acceleration
from gravitas.physics.potential import effective_potential, numerical_gradient, zonal_potential
from gravitas.validation.reference import get as ref


class TestEllipsoid:
    def test_wgs84_derived_constants_match_tr8350(self):
        assert WGS84.gamma_e == pytest.approx(ref("wgs84_gamma_equator").value, abs=1e-10)
        assert WGS84.gamma_p == pytest.approx(ref("wgs84_gamma_pole").value, abs=1e-10)
        assert WGS84.k_somigliana == pytest.approx(ref("wgs84_somigliana_k").value, abs=1e-12)
        assert WGS84.m == pytest.approx(ref("wgs84_m").value, abs=1e-13)
        assert WGS84.j2n(1) == pytest.approx(ref("wgs84_J2").value, abs=1e-11)
        assert WGS84.b == pytest.approx(ref("wgs84_b").value, abs=1e-3)

    def test_zonal_coefficients_alternate_and_decay(self):
        j = WGS84.zonal_coefficients(5)
        assert j[0] > 0 and j[1] < 0 and j[2] > 0
        assert all(abs(j[i + 1]) < abs(j[i]) * 1e-2 for i in range(4))

    def test_invalid_ellipsoid_rejected(self):
        with pytest.raises(ValueError):
            Ellipsoid("bad", -1.0, 0.0, 1.0, 0.0)
        with pytest.raises(ValueError):
            Ellipsoid("bad", 1.0, 1.5, 1.0, 0.0)

    def test_sphere_has_no_flattening(self):
        assert SPHERE.is_sphere and SPHERE.j2n(1) == 0.0


class TestNewtonian:
    def test_inverse_square_law(self):
        r = np.array([1.0, 2.0, 3.0, 10.0]) * pc.EARTH_MEAN_RADIUS
        g = spherical_gravity_at_radius(r)
        assert np.allclose(g * r**2, pc.WGS84_GM, rtol=1e-15)
        assert g[0] / g[1] == pytest.approx(4.0, rel=1e-14)

    def test_point_mass_vector_points_to_centre(self):
        r = np.array([7e6, 1e6, -2e6])
        a = point_mass_acceleration(r, pc.WGS84_GM)
        assert np.dot(a, r) < 0
        assert np.linalg.norm(a) == pytest.approx(pc.WGS84_GM / np.dot(r, r), rel=1e-14)

    def test_point_mass_singularity_raises(self):
        with pytest.raises(ZeroDivisionError):
            point_mass_acceleration(np.zeros(3), 1.0)

    def test_zonal_acceleration_is_gradient_of_potential(self):
        r = np.array([3.8e6, -1.0e5, 5.1e6])
        a = zonal_acceleration(r, WGS84)
        g = numerical_gradient(lambda x: zonal_potential(x, WGS84), r, step_m=0.5)
        assert np.allclose(a, g, atol=1e-11)

    def test_zonal_refuses_inside_convergence_sphere(self):
        with pytest.raises(ValueError):
            zonal_acceleration(np.array([1e5, 0, 0]), WGS84)


class TestNormalGravity:
    @pytest.mark.parametrize("lat_deg", [-90, -60, -30, 0, 15, 45, 53.38, 75, 90])
    def test_series_reproduces_somigliana_on_ellipsoid(self, lat_deg):
        lat = math.radians(lat_deg)
        b = EarthGravityModel().evaluate(lat, 0.7, 0.0)
        assert b.effective_mps2 == pytest.approx(float(somigliana(lat)), abs=1e-9)  # 0.1 µGal

    @pytest.mark.parametrize("lat_deg", [0, 30, 60, 89])
    def test_gravity_is_normal_to_ellipsoid(self, lat_deg):
        b = EarthGravityModel().evaluate(math.radians(lat_deg), 0.0, 0.0)
        assert b.deflection_from_normal_rad < 1e-9

    def test_effective_gradient_of_effective_potential(self):
        from gravitas.earth.coordinates import geodetic_to_ecef

        r = geodetic_to_ecef(math.radians(40), math.radians(10), 300.0)
        m = EarthGravityModel()
        a_n, a_c = m.evaluate_ecef(r)
        g = numerical_gradient(lambda x: effective_potential(x, WGS84), r, step_m=0.5)
        assert np.allclose(a_n + a_c, g, atol=1e-11)

    def test_somigliana_endpoints(self):
        assert somigliana(0.0) == pytest.approx(pc.WGS84_GAMMA_E, abs=1e-10)
        assert somigliana(math.pi / 2) == pytest.approx(pc.WGS84_GAMMA_P, abs=1e-10)


class TestAltitude:
    def test_gravity_decreases_with_altitude(self):
        m = EarthGravityModel()
        h = np.linspace(-500, 30_000, 200)
        g = m.magnitude(np.full(h.size, math.radians(53.38)), 0.0, h)
        assert np.all(np.diff(g) < 0)

    def test_free_air_gradient_value(self):
        m = EarthGravityModel()
        grad = m.vertical_gradient(math.radians(45), 0.0, 0.0)
        assert grad == pytest.approx(ref("free_air_gradient_45deg").value, abs=1e-8)
        assert grad == pytest.approx(float(free_air_gradient(math.radians(45))), rel=1e-4)

    def test_free_air_formula_agrees_with_series_at_low_altitude(self):
        m = EarthGravityModel()
        lat = math.radians(53.38)
        for h in (0.0, 100.0, 1000.0):
            diff = m.magnitude(lat, 0.0, h)[0] - normal_gravity_free_air(lat, h)
            assert abs(diff) < 4e-9 * max(1.0, h / 100.0)  # documented ≈0.3 µGal / 100 m

    def test_spherical_model(self):
        assert spherical_gravity(0.0) == pytest.approx(pc.WGS84_GM / pc.EARTH_MEAN_RADIUS**2, rel=1e-15)
        with pytest.raises(ValueError):
            spherical_gravity(-2 * pc.EARTH_MEAN_RADIUS)

    def test_altitude_switch_freezes_height(self):
        m = EarthGravityModel(switches=EarthModelSwitches(altitude=False))
        assert m.evaluate(0.9, 0.0, 5000.0).effective_mps2 == pytest.approx(m.evaluate(0.9, 0.0, 0.0).effective_mps2, abs=0)


class TestRotationAndLatitude:
    def test_rotation_reduces_equatorial_gravity_by_omega2_a(self):
        on = EarthGravityModel().evaluate(0.0, 0.0, 0.0).effective_mps2
        off = EarthGravityModel(switches=EarthModelSwitches(earth_rotation=False)).evaluate(0.0, 0.0, 0.0).effective_mps2
        assert off - on == pytest.approx(pc.WGS84_OMEGA**2 * pc.WGS84_A, rel=1e-12)

    def test_no_rotation_effect_at_pole(self):
        on = EarthGravityModel().evaluate(math.pi / 2, 0.0, 0.0).effective_mps2
        off = EarthGravityModel(switches=EarthModelSwitches(earth_rotation=False)).evaluate(math.pi / 2, 0.0, 0.0).effective_mps2
        assert abs(on - off) < 1e-12

    def test_effective_gravity_increases_toward_pole(self):
        lat = np.radians(np.linspace(0, 90, 91))
        g = EarthGravityModel().magnitude(lat, 0.0, 0.0)
        assert np.all(np.diff(g) > 0)
        assert g[-1] - g[0] == pytest.approx(pc.WGS84_GAMMA_P - pc.WGS84_GAMMA_E, abs=1e-9)

    def test_components_are_exposed_separately(self):
        b = EarthGravityModel().evaluate(math.radians(53.38), 0.0, 100.0)
        assert b.newtonian_mps2 > b.effective_mps2
        assert b.centrifugal_mps2 == pytest.approx(pc.WGS84_OMEGA**2 * 6378137 * math.cos(math.radians(53.38)), rel=5e-3)
        assert np.allclose(b.effective_enu_mps2, b.newtonian_enu_mps2 + b.centrifugal_enu_mps2)

    def test_spherical_vs_oblate_comparison(self):
        c = compare_models(math.radians(53.38), 0.0, 100.0)
        assert c["spherical_mps2"] != c["rotating_oblate_mps2"]
        assert c["oblate_no_rotation_mps2"] - c["rotating_oblate_mps2"] > 0.01

    def test_latitude_switch_uses_reference_latitude(self):
        m = EarthGravityModel(switches=EarthModelSwitches(latitude=False, reference_latitude_deg=45.0))
        assert m.evaluate(0.1, 0.0, 0.0).effective_mps2 == pytest.approx(float(somigliana(math.radians(45))), abs=1e-9)

    def test_earth_gravity_switch(self):
        m = EarthGravityModel(switches=EarthModelSwitches(earth_gravity=False))
        assert m.evaluate(0.5, 0.0, 0.0).effective_mps2 == 0.0


class TestUnits:
    def test_exact_conversions(self):
        assert convert(1.0, "Gal", "m/s^2") == 1e-2
        assert convert(1.0, "mGal", "m/s^2") == 1e-5
        assert convert(1.0, "uGal", "m/s^2") == 1e-8
        assert convert(9.81, "m/s^2", "uGal") == pytest.approx(981_000_000.0, rel=1e-16)
        assert mps2_to_ugal(ugal_to_mps2(123.456)) == pytest.approx(123.456, rel=1e-15)

    def test_round_trip_all_units_preserves_precision(self):
        x = 9.813371214824205
        for u in GravityUnit:
            back = convert(convert(x, "m/s^2", u), u, "m/s^2")
            assert abs(back - x) <= 2 * np.spacing(x)

    def test_unknown_unit_rejected(self):
        with pytest.raises(ValueError):
            parse_unit("furlong/fortnight^2")

    def test_formatting_only_at_presentation(self):
        assert format_gravity(9.81234567, "uGal", 1) == "981234567.0 µGal"
        assert format_gravity(1e-8, "uGal", 3) == "1.000 µGal"
