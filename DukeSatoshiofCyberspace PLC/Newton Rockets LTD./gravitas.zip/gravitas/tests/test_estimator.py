"""Filters, Kalman filter, gravity estimator and Allan deviation."""

import math

import numpy as np
import pytest

from gravitas.estimation.allan import identify_noise, overlapping_adev
from gravitas.estimation.filtering import FilterConfig, StreamingFilter, zero_phase_butterworth
from gravitas.estimation.gravity_estimator import EstimatorConfig, GravityEstimator
from gravitas.estimation.kalman import KalmanFilter, constant_velocity_model, rts_smoother
from gravitas.simulation.engine import SimulationEngine
from gravitas.simulation.scenario import SimulationConfig

KINDS = ["none", "moving_average", "lowpass", "butterworth", "kalman"]


@pytest.mark.parametrize("kind", KINDS)
def test_filters_preserve_dc_and_stream_equals_batch(kind, rng):
    fs = 10.0
    x = 3e-6 + rng.normal(0, 1e-7, 3000)
    cfg = FilterConfig(kind=kind, cutoff_hz=0.1, window_s=5.0, kalman_process_asd=1e-10)
    a = StreamingFilter(cfg, fs, 1e-7).process(x)
    f = StreamingFilter(cfg, fs, 1e-7)
    b = np.concatenate([f.process(x[:1234]), f.process(x[1234:2000]), f.process(x[2000:])])
    assert np.allclose(a, b, rtol=0, atol=1e-20)
    assert np.mean(a[1000:]) == pytest.approx(3e-6, abs=2e-8)


@pytest.mark.parametrize("kind", ["moving_average", "lowpass", "butterworth", "kalman"])
def test_filters_reduce_white_noise_per_enbw(kind, rng):
    fs = 10.0
    sig = 1e-7
    x = rng.normal(0, sig, 200_000)
    f = StreamingFilter(FilterConfig(kind=kind, cutoff_hz=0.05, window_s=10.0, kalman_process_asd=1e-10), fs, sig)
    y = f.process(x)[5000:]
    n0 = 2 * sig**2 / fs  # one-sided PSD
    assert np.std(y) == pytest.approx(math.sqrt(n0 * f.enbw_hz), rel=0.1)
    assert np.std(y) < sig / 3


def test_butterworth_attenuates_out_of_band():
    fs = 10.0
    t = np.arange(0, 600, 1 / fs)
    x = np.sin(2 * math.pi * 1.0 * t)
    y = StreamingFilter(FilterConfig(kind="butterworth", cutoff_hz=0.05, order=4), fs).process(x)
    assert np.std(y[1000:]) < 1e-4  # (0.05/1)^4·… ≈ 6e-6


def test_zero_phase_has_no_delay():
    fs = 10.0
    t = np.arange(0, 2000, 1 / fs)
    x = np.sin(2 * math.pi * t / 500.0)
    y = zero_phase_butterworth(x, fs, 0.05)
    assert np.max(np.abs(y[2000:-2000] - x[2000:-2000])) < 1e-3


def test_invalid_filter_rejected():
    with pytest.raises(ValueError):
        FilterConfig(kind="magic")


def test_kalman_matches_least_squares_for_constant():
    # static state, Q = 0 ⇒ the KF is recursive least squares: x̂ = mean, P = σ²/N
    kf = KalmanFilter(np.eye(1), np.eye(1), np.zeros((1, 1)), np.array([[1e-14]]), np.zeros(1), np.array([[1e6]]))
    z = np.random.default_rng(0).normal(5e-6, 1e-7, 1000)
    for v in z:
        kf.predict()
        kf.update(np.array([v]))
    assert kf.x[0] == pytest.approx(z.mean(), rel=1e-9)
    assert kf.p[0, 0] == pytest.approx(1e-14 / 1000, rel=1e-3)


def test_constant_velocity_model_structure():
    f, h, q, r = constant_velocity_model(0.5, 2.0, 3.0)
    assert np.allclose(f, [[1, 0.5], [0, 1]]) and np.allclose(h, [[1, 0]])
    assert np.allclose(q, 2.0 * np.array([[0.5**3 / 3, 0.5**2 / 2], [0.5**2 / 2, 0.5]]))
    assert np.all(np.linalg.eigvalsh(q) >= -1e-18) and r[0, 0] == 3.0


def test_kalman_tracks_ramp_and_rts_improves():
    rng = np.random.default_rng(1)
    dt = 1.0
    f, h, q, r = constant_velocity_model(dt, 1e-6, 1.0)
    kf = KalmanFilter(f, h, q, r, np.zeros(2), np.eye(2) * 100)
    truth = 0.01 * np.arange(2000)
    xs, ps = [], []
    for v in truth + rng.normal(0, 1.0, truth.size):
        kf.predict()
        kf.update(np.array([v]))
        xs.append(kf.x.copy())
        ps.append(kf.p.copy())
    xs, ps = np.array(xs), np.array(ps)
    assert kf.x[1] == pytest.approx(0.01, abs=2e-3)
    sm, _ = rts_smoother(xs, ps, f, q)
    err_f = np.sqrt(np.mean((xs[500:, 0] - truth[500:]) ** 2))
    err_s = np.sqrt(np.mean((sm[500:-1, 0] - truth[500:-1]) ** 2))
    assert err_s < err_f


def test_gravity_estimator_static_and_drift():
    rng = np.random.default_rng(2)
    fs = 1.0
    t = np.arange(0, 20_000, 1 / fs)
    z = 4e-6 + 1e-12 * t + rng.normal(0, 5e-8, t.size)
    est = GravityEstimator(EstimatorConfig(estimate_drift=True, noise_prior_mps2=5e-8), fs, 1.0)
    out = est.process(t, z, np.zeros_like(t))
    assert out["estimate_dev_mps2"][-1] == pytest.approx(4e-6, abs=5 * out["sigma_mps2"][-1])
    assert out["drift_rate"][-1] == pytest.approx(1e-12, abs=2e-13)
    assert est.measurement_sigma == pytest.approx(5e-8, rel=0.05)


def test_gravity_estimator_recovers_tidal_admittance():
    rng = np.random.default_rng(3)
    t = np.arange(0, 3 * 86400, 10.0)
    tide = 1e-6 * np.sin(2 * math.pi * t / 44_712.0)
    z = 2e-6 + 0.004 * tide + rng.normal(0, 1e-9, t.size)
    est = GravityEstimator(EstimatorConfig(estimate_tidal_admittance=True, noise_prior_mps2=1e-9), 0.1, 10.0)
    out = est.process(t, z, tide)
    assert out["tidal_admittance"][-1] == pytest.approx(0.004, abs=2e-4)


def test_engine_estimate_converges_to_truth_within_uncertainty():
    r = SimulationEngine(SimulationConfig(duration_s=900, seed=3)).run()
    est = r.final_estimate()
    err = est.value - r["truth.static_gravity_mps2"][-1]
    assert abs(err) < 3 * est.standard_uncertainty


def test_allan_drift_and_identification():
    t = np.arange(0, 100_000, 1.0)
    rng = np.random.default_rng(4)
    y = 1e-11 * t + rng.normal(0, 1e-8, t.size)
    r = overlapping_adev(y, 1.0)
    ident = r.identification
    assert ident["long_term_slope"] > 0.75
    assert ident["drift_rate_estimate_mps2_per_s"] == pytest.approx(1e-11, rel=0.2)
    labels = [g["label"] for g in ident["regions"]]
    assert labels[0] == "white noise" and labels[-1] == "drift (linear rate)"
    assert ident["white_noise_mps2_per_rthz"] == pytest.approx(1e-8 * math.sqrt(2.0), rel=0.15)


def test_allan_confidence_interval_contains_estimate():
    r = overlapping_adev(np.random.default_rng(5).normal(size=10_000), 1.0)
    assert np.all(r.adev_lo <= r.adev) and np.all(r.adev <= r.adev_hi)
    with pytest.raises(ValueError):
        overlapping_adev(np.array([1.0, np.nan] * 10), 1.0)
