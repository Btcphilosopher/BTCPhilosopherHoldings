import numpy as np
import pytest

from gravitas.simulation.scenario import SimulationConfig


@pytest.fixture
def quiet_config():
    """Configuration with environment noise sources removed (for analytic checks)."""
    cfg = SimulationConfig(duration_s=300.0, sample_rate_hz=10.0, seed=11)
    phys = cfg.physics.model_copy(update={"vibration": False, "sensor_noise": False, "temperature": False})
    return cfg.model_copy(update={"physics": phys})


@pytest.fixture
def rng():
    return np.random.default_rng(1234)
