"""Synthetic anomaly bodies: analytic limits, superposition, survey profile, potential/geoid."""

import math

import numpy as np
import pytest

from gravitas.constants.physical import G
from gravitas.earth.geoid import AnomalyGeoid, ConstantGeoid, bruns_undulation
from gravitas.earth.terrain import TerrainModel, bouguer_gradient, bouguer_plate, synthetic_gaussian_hill
from gravitas.physics.anomalies import (AnomalyField, GaussianAnomaly, Layer, PointMass, Slab, Sphere,
                                        body_from_dict)
from gravitas.physics.potential import numerical_gradient
from gravitas.validation.reference import get as ref


def test_point_mass_peak_and_half_width():
    z = 100.0
    pm = PointMass(1e9, [0, 0, -z])
    x = np.linspace(-500, 500, 2001)
    g = pm.delta_g(np.column_stack([x, 0 * x, 0 * x]))
    assert g.max() == pytest.approx(G * 1e9 / z**2, rel=1e-12)
    half = x[g >= g.max() / 2]
    assert (half.max() - half.min()) / 2 == pytest.approx(0.766 * z, rel=0.01)  # x½ = 0.766 z


def test_sphere_equals_point_mass_outside_and_linear_inside():
    s = Sphere(50.0, 800.0, [0, 0, -120])
    pm = PointMass(s.mass_kg, [0, 0, -120])
    pts = np.array([[0, 0, 0], [80, -30, 10], [300, 300, 0]], float)
    assert np.allclose(s.acceleration_enu(pts), pm.acceleration_enu(pts), rtol=1e-12)
    inside = np.array([[0, 0, -120 + 25.0]])
    assert -s.acceleration_enu(inside)[0, 2] == pytest.approx(G * s.mass_kg * 25.0 / 50.0**3, rel=1e-12)


def test_slab_far_field_is_point_mass():
    s = Slab([0, 0, -100], [10, 10, 10], 1000.0)
    pm = PointMass(s.mass_kg, [0, 0, -100])
    pts = np.array([[0, 0, 0], [30, -20, 5], [500, 0, 0], [0, 0, -200]], float)
    assert np.allclose(s.acceleration_enu(pts), pm.acceleration_enu(pts), rtol=2e-3, atol=1e-15)


def test_wide_slab_is_bouguer_plate():
    s = Slab([0, 0, -60], [1e6, 1e6, 20], 1000.0)
    assert s.delta_g([[0, 0, 0]])[0] == pytest.approx(2 * math.pi * G * 1000 * 20, rel=1e-3)
    r = ref("bouguer_gradient_2670")
    assert bouguer_gradient(2670.0) == pytest.approx(r.value, abs=r.tolerance)


def test_layer_infinite_and_edge():
    inf = Layer(100.0, 5.0, 500.0)
    assert inf.delta_g([[0, 0, 0]])[0] == pytest.approx(2 * math.pi * G * 500 * 5, rel=1e-12)
    edge = Layer(100.0, 5.0, 500.0, edge_offset_m=0.0)
    g = edge.delta_g(np.array([[-1e6, 0, 0], [0, 0, 0], [1e6, 0, 0]], float))
    full = 2 * math.pi * G * 500 * 5
    assert g[0] == pytest.approx(0.0, abs=full * 1e-3)
    assert g[1] == pytest.approx(full / 2, rel=1e-12)
    assert g[2] == pytest.approx(full, rel=1e-3)


def test_gaussian_total_mass_and_far_field():
    ga = GaussianAnomaly(500.0, 30.0, [0, 0, -400])
    assert ga.enclosed_mass(1e4) == pytest.approx(ga.mass_kg, rel=1e-12)
    far = PointMass(ga.mass_kg, [0, 0, -400])
    assert ga.delta_g([[0, 0, 0]])[0] == pytest.approx(far.delta_g([[0, 0, 0]])[0], rel=1e-9)
    # numerical volume integral of the density (independent check of the mass formula)
    r = np.linspace(0, 300, 30001)
    m_num = np.trapezoid(4 * math.pi * r**2 * 500.0 * np.exp(-r**2 / (2 * 30.0**2)), r)
    assert m_num == pytest.approx(ga.mass_kg, rel=1e-6)


@pytest.mark.parametrize("body", [PointMass(5e8, [10, -5, -80]), Sphere(30.0, 600.0, [0, 0, -100]),
                                  GaussianAnomaly(300.0, 25.0, [5, 5, -150])])
def test_acceleration_is_gradient_of_potential(body):
    p = np.array([20.0, 15.0, 2.0])
    g = numerical_gradient(lambda x: body.potential(x.reshape(1, 3))[0], p, step_m=0.01)
    assert np.allclose(body.acceleration_enu(p.reshape(1, 3))[0], g, rtol=1e-5, atol=1e-16)


def test_superposition_and_grid():
    a = Sphere(40.0, 1500.0, [0, 0, -90])
    b = Slab([250, 0, -60], [120, 400, 40], -400.0)
    f = AnomalyField([a, b])
    pts = np.array([[0, 0, 0], [250, 0, 0], [-300, 10, 0]], float)
    assert np.allclose(f.delta_g(pts), a.delta_g(pts) + b.delta_g(pts))
    grid = f.grid(np.linspace(-100, 100, 5), np.linspace(-50, 50, 3))
    assert grid.shape == (3, 5)
    assert f.label == "SYNTHETIC GEOPHYSICAL MODEL"


def test_body_from_dict_and_validation():
    b = body_from_dict({"kind": "sphere", "radius_m": 10.0, "density_contrast_kgpm3": 100.0, "center_enu_m": [0, 0, -50]})
    assert isinstance(b, Sphere)
    with pytest.raises(ValueError):
        body_from_dict({"kind": "unicorn"})
    with pytest.raises(ValueError):
        Sphere(-1.0, 100.0, [0, 0, -10])
    with pytest.raises(ValueError):
        Slab([0, 0, -10], [1, -1, 1], 100.0)


def test_bruns_geoid_perturbation_sign_and_size():
    s = Sphere(200.0, 500.0, [0, 0, -500])
    geo = AnomalyGeoid(AnomalyField([s]))
    n = geo.undulation(math.radians(45), 0.0, np.array([[0, 0, 0.0]]))
    assert n[0] > 0  # excess mass raises the geoid
    assert n[0] == pytest.approx(bruns_undulation(s.potential([[0, 0, 0]]), math.radians(45))[0])
    assert ConstantGeoid(12.0).undulation(0.1, 0.2)[0] == 12.0
    with pytest.raises(ValueError):
        ConstantGeoid(1000.0)


def test_terrain_prisms_and_plate():
    assert bouguer_plate(100.0) == pytest.approx(2 * math.pi * G * 2670 * 100, rel=1e-12)
    e, n, h = synthetic_gaussian_hill(extent_m=1000, n=21, peak_m=20.0, width_m=150.0)
    t = TerrainModel(e, n, h)
    on_top = t.gravity_effect([0, 0, 25.0])
    assert on_top > 0  # mass below the station pulls down
    assert on_top < bouguer_plate(20.0)
