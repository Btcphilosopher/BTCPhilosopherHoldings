"""Engine API: every endpoint returns engine-derived, JSON-safe data; controls modify the simulation."""

import json
import math
import threading
import urllib.request

import numpy as np
import pytest

from gravitas.api.live import LiveSimulation, RingBuffer, live_default_config
from gravitas.api.server import Api, make_handler, sanitize


@pytest.fixture(scope="module")
def api():
    live = LiveSimulation(live_default_config())
    live.advance(1200)  # 120 s of data, deterministic (thread not started)
    return Api(live)


def get(api, path, **q):
    return api.handle("GET", "/api/v1" + path, {k: [str(v)] for k, v in q.items()}, None)


def test_ring_buffer_wraps():
    rb = RingBuffer(5)
    rb.append({"a": np.arange(3.0)})
    rb.append({"a": np.arange(3.0, 7.0)})
    assert rb.last()["a"].tolist() == [2, 3, 4, 5, 6]
    assert rb.last(2)["a"].tolist() == [5, 6]


def test_overview_values_trace_to_chain(api):
    ov = get(api, "/overview")
    last = api.live.full.last(1)
    assert ov["raw_measurement_mps2"] == float(last["raw.gravity_mps2"][-1])
    assert ov["local_gravity_mps2"] == float(last["truth.gravity_mps2"][-1])
    assert ov["standard_uncertainty_mps2"] > 0
    assert ov["instrument_status"] in ("STABLE", "SETTLING", "SATURATED", "UNLOCKED", "PAUSED")


@pytest.mark.parametrize("path,q", [("/health", {}), ("/series", {"window_s": 10, "max_points": 50}), ("/instrument", {}),
                                    ("/physics", {}), ("/earth", {}), ("/tides", {"hours": 2, "step_s": 600}),
                                    ("/anomalies", {}), ("/uncertainty", {}), ("/allan", {}), ("/experiments", {}),
                                    ("/map", {}), ("/telemetry", {"n": 3}), ("/config", {})])
def test_endpoints_json_safe(api, path, q):
    d = get(api, path, **q)
    s = json.dumps(sanitize(d), allow_nan=False)
    assert len(s) > 10


def test_series_lengths_consistent(api):
    s = get(api, "/series", window_s=60, max_points=100)
    n = len(s["t_s"])
    assert 0 < n <= 100
    assert all(len(s[k]) == n for k in ("true_mps2", "raw_mps2", "filtered_mps2", "calibrated_mps2", "estimate_mps2"))


def test_physics_switch_changes_simulation(api):
    live = api.live
    api.handle("POST", "/api/v1/physics", {}, {"switches": {"moon": False}})
    try:
        chunk = live.advance(10)
        assert np.all(chunk["tide.lunar_mps2"] == 0.0)
    finally:
        api.handle("POST", "/api/v1/physics", {}, {"switches": {"moon": True}})
    chunk = live.advance(10)
    assert np.all(chunk["tide.lunar_mps2"] != 0.0)
    with pytest.raises(ValueError):
        api.handle("POST", "/api/v1/physics", {}, {"switches": {"gravity_waves": True}})


def test_control_actions(api):
    h = api.handle("POST", "/api/v1/control", {}, {"action": "set_speed", "speed": 5})
    assert h["speed"] == 5
    api.handle("POST", "/api/v1/control", {}, {"action": "pause"})
    assert get(api, "/overview")["instrument_status"] == "PAUSED"
    api.handle("POST", "/api/v1/control", {}, {"action": "resume"})
    with pytest.raises(ValueError):
        api.handle("POST", "/api/v1/control", {}, {"action": "explode"})
    with pytest.raises(KeyError):
        get(api, "/nonexistent")


def test_experiment_endpoint_flattens_summary(api):
    d = api.handle("POST", "/api/v1/experiments/static", {}, {"duration_s": 120})
    assert all(isinstance(v, float) for v in d["summary"].values())
    assert d["series"]["curves"]


def test_http_transport(api):
    from http.server import ThreadingHTTPServer

    srv = ThreadingHTTPServer(("127.0.0.1", 0), make_handler(api))
    th = threading.Thread(target=srv.serve_forever, daemon=True)
    th.start()
    try:
        port = srv.server_address[1]
        with urllib.request.urlopen(f"http://127.0.0.1:{port}/api/v1/health") as r:
            assert json.loads(r.read())["status"] == "ok"
        try:
            urllib.request.urlopen(f"http://127.0.0.1:{port}/api/v1/missing")
        except urllib.error.HTTPError as e:
            assert e.code == 404
    finally:
        srv.shutdown()
