"""Calibration: model inversion, individual procedures, joint fit, campaign recovers injected errors."""

import math

import numpy as np
import pytest

from gravitas.estimation.calibration import (CalibrationParameters, ar1_inflation, drift_estimation, joint_calibration,
                                             linear_fit, scale_factor_calibration, temperature_calibration,
                                             zero_calibration)
from gravitas.experiments import calibration as cal_exp


def test_apply_inverts_sensor_model(rng):
    p = CalibrationParameters(bias_mps2=1e-6, scale_factor=1.001, temperature_coefficient_mps2_per_k=3e-7,
                              reference_temperature_c=20.0, drift_rate_mps2_per_s=1e-12)
    x = rng.normal(0, 1e-4, 1000)
    t = np.arange(1000.0)
    temp = 20 + rng.normal(0, 1, 1000)
    raw = 1.001 * x + 1e-6 + 3e-7 * (temp - 20) + 1e-12 * t
    assert np.allclose(p.apply(raw, temp, t), x, atol=1e-18)
    with pytest.raises(ValueError):
        CalibrationParameters(scale_factor=0.0)


def test_zero_calibration(rng):
    ref = np.zeros(10_000)
    raw = 2e-6 + rng.normal(0, 1e-7, 10_000)
    b, u = zero_calibration(raw, ref)
    assert b == pytest.approx(2e-6, abs=5 * 1e-7 / 100)
    assert u == pytest.approx(1e-7 / 100, rel=0.05)


def test_linear_fit_standard_errors(rng):
    x = np.linspace(0, 1, 500)
    slopes = []
    for s in range(200):
        y = 1.0 + 2.0 * x + np.random.default_rng(s).normal(0, 0.1, x.size)
        a, b, ua, ub, rms = linear_fit(x, y)
        slopes.append(b)
    assert np.std(slopes) == pytest.approx(ub, rel=0.2)


def test_scale_temperature_drift_procedures(rng):
    ref = np.repeat([0.0, -4e-4, -9e-4], 300)
    raw = 1.0003 * ref + 1e-6 + rng.normal(0, 1e-8, ref.size)
    r = scale_factor_calibration(raw, ref)
    assert r["scale_factor"] == pytest.approx(1.0003, abs=5 * r["u_scale_factor"])
    temp = np.linspace(18, 22, 1000)
    res = 4e-7 * (temp - 20) + rng.normal(0, 1e-9, 1000)
    tr = temperature_calibration(res, temp, 20.0)
    assert tr["temperature_coefficient_mps2_per_k"] == pytest.approx(4e-7, abs=5 * tr["u_temperature_coefficient_mps2_per_k"])
    t = np.arange(0, 86400, 60.0)
    dr = drift_estimation(3e-12 * t + rng.normal(0, 1e-9, t.size), t)
    assert dr["drift_rate_mps2_per_s"] == pytest.approx(3e-12, abs=5 * dr["u_drift_rate_mps2_per_s"])


def test_joint_calibration_on_synthetic_data(rng):
    n = 5000
    t = np.linspace(0, 20_000, n)
    ref = np.repeat([0.0, -5e-4, -1e-3, -5e-4, 0.0], n // 5)
    temp = 20 + 2 * np.sin(t / 3000)
    raw = 1.0002 * ref + 1.5e-6 + 5e-7 * (temp - 20) + 2e-12 * t + rng.normal(0, 5e-9, n)
    fit = joint_calibration(raw, ref, temp, t)
    p = fit.parameters
    assert p.bias_mps2 == pytest.approx(1.5e-6, abs=5 * p.u_bias_mps2)
    assert p.scale_factor == pytest.approx(1.0002, abs=5 * p.u_scale_factor)
    assert p.temperature_coefficient_mps2_per_k == pytest.approx(5e-7, abs=5 * p.u_temperature_coefficient_mps2_per_k)
    assert p.drift_rate_mps2_per_s == pytest.approx(2e-12, abs=5 * p.u_drift_rate_mps2_per_s)
    assert fit.residual_rms_mps2 == pytest.approx(5e-9, rel=0.1)


def test_ar1_inflation():
    rng = np.random.default_rng(0)
    e = rng.normal(size=20000)
    x = np.zeros_like(e)
    for i in range(1, e.size):
        x[i] = 0.8 * x[i - 1] + e[i]
    rho, infl = ar1_inflation(x)
    assert rho == pytest.approx(0.8, abs=0.02)
    assert infl == pytest.approx(9.0, rel=0.1)
    assert ar1_inflation(rng.normal(size=5000))[1] == pytest.approx(1.0, abs=0.1)


@pytest.fixture(scope="module")
def campaign():
    return cal_exp.run(duration_s=6 * 3600.0, sample_rate_hz=2.0, seed=7)


def test_campaign_recovers_injected_errors(campaign):
    s = campaign.summary
    for k in ("bias_mps2", "scale_factor", "temperature_coefficient_mps2_per_k", "drift_rate_mps2_per_s"):
        z = (s["estimated"][k] - s["injected"][k]) / s["estimated_uncertainty"][k]
        assert abs(z) < 4.0, (k, z)
    assert s["estimated"]["bias_mps2"] == pytest.approx(s["injected"]["bias_mps2"], abs=3e-9)  # 0.3 µGal
    assert s["estimated"]["scale_factor"] == pytest.approx(s["injected"]["scale_factor"], abs=1e-5)


def test_calibration_reduces_known_bias(campaign):
    s = campaign.summary
    assert s["residual_rms_uncalibrated_mps2"] > 1e-6          # ≈ injected 150 µGal
    assert s["residual_rms_calibrated_mps2"] < 3e-8            # < 3 µGal after calibration
    assert s["improvement_factor"] > 50
