"""Uncertainty budget, propagation and Monte Carlo agreement."""

import math

import numpy as np
import pytest

from gravitas.simulation.engine import SimulationEngine
from gravitas.simulation.monte_carlo import run_monte_carlo
from gravitas.simulation.scenario import SimulationConfig
from gravitas.uncertainty.budget import GravityEstimate, compute_budget, noise_term_from_adev
from gravitas.uncertainty.monte_carlo import summarise
from gravitas.uncertainty.propagation import numerical_jacobian, propagate_linear, propagate_monte_carlo

REQUIRED = {"sensor_noise", "bias", "scale_factor", "temperature", "position", "altitude", "earth_model",
            "tidal_correction", "vibration", "calibration"}


@pytest.fixture(scope="module")
def static_result():
    return SimulationEngine(SimulationConfig(duration_s=900.0, seed=21)).run()


def test_budget_has_every_traceable_contribution(static_result):
    est = compute_budget(static_result)
    assert isinstance(est, GravityEstimate)
    names = {c.name for c in est.contributions}
    assert REQUIRED <= names
    for c in est.contributions:
        assert c.standard_uncertainty_mps2 >= 0 and math.isfinite(c.standard_uncertainty_mps2)
        assert c.type in ("A", "B") and c.description
    assert est.standard_uncertainty == pytest.approx(math.sqrt(sum(c.standard_uncertainty_mps2**2 for c in est.contributions)))
    assert est.expanded_uncertainty == pytest.approx(2.0 * est.standard_uncertainty)
    d = est.to_dict()
    assert set(d) >= {"value_mps2", "standard_uncertainty_mps2", "expanded_uncertainty_mps2", "contributions"}


def test_budget_sensitivities_are_model_derived(static_result):
    est = compute_budget(static_result)
    alt = next(c for c in est.contributions if c.name == "altitude")
    assert alt.sensitivity == pytest.approx(3.08e-6, rel=0.01)  # free-air gradient
    assert alt.standard_uncertainty_mps2 == pytest.approx(alt.sensitivity * alt.input_uncertainty)


def test_budget_responds_to_inputs(static_result):
    cfg = static_result.config
    worse = static_result.config.model_copy(update={"calibration": cfg.calibration.model_copy(update={"u_bias_mps2": 1e-6})})
    static_result.config = worse
    try:
        u_worse = compute_budget(static_result).standard_uncertainty
    finally:
        static_result.config = cfg
    assert u_worse > 1e-6 > compute_budget(static_result).standard_uncertainty


def test_noise_term_white_noise_is_standard_error():
    rng = np.random.default_rng(0)
    x = rng.normal(0, 1e-7, 20_000)
    u, meta = noise_term_from_adev(x, 1.0)
    assert u == pytest.approx(1e-7 / math.sqrt(x.size), rel=0.25)


def test_linear_propagation_matches_analytic():
    f = lambda x: np.array([x[0] * x[1], x[0] + 3 * x[1]])
    mean = np.array([2.0, 5.0])
    cov = np.diag([0.01**2, 0.02**2])
    y, cy = propagate_linear(f, mean, cov)
    assert np.allclose(y, [10.0, 17.0])
    assert cy[0, 0] == pytest.approx((5 * 0.01) ** 2 + (2 * 0.02) ** 2, rel=1e-6)
    assert cy[1, 1] == pytest.approx(0.01**2 + 9 * 0.02**2, rel=1e-6)
    j = numerical_jacobian(f, mean)
    assert np.allclose(j, [[5, 2], [1, 3]], atol=1e-6)


def test_monte_carlo_propagation_agrees_with_linear_for_mild_nonlinearity():
    f = lambda x: np.array([x[0] * x[1]])
    mean = np.array([2.0, 5.0])
    cov = np.diag([0.01**2, 0.02**2])
    _, cy = propagate_linear(f, mean, cov)
    mc = propagate_monte_carlo(f, mean, cov, 20_000, np.random.default_rng(1))
    assert mc["std"][0] == pytest.approx(math.sqrt(cy[0, 0]), rel=0.03)
    assert mc["interval_lo"][0] < 10.0 < mc["interval_hi"][0]


def test_summarise_statistics():
    rng = np.random.default_rng(2)
    e = rng.normal(1e-9, 2e-8, 4000)
    s = summarise(e, np.full(e.size, 2e-8))
    assert s["ratio_mc_to_analytical"] == pytest.approx(1.0, abs=0.05)
    assert s["coverage_probability"] == pytest.approx(0.954, abs=0.015)
    assert s["bias_ci95_mps2"][0] < 1e-9 < s["bias_ci95_mps2"][1]
    assert s["rmse_mps2"] == pytest.approx(math.sqrt(2e-8**2 + 1e-9**2), rel=0.05)


@pytest.mark.slow
def test_monte_carlo_validates_analytical_uncertainty():
    r = run_monte_carlo(SimulationConfig(), trials=80, duration_s=300.0, mc_seed=99)
    s = r.summary
    # with N = 80 the sample std has ≈ 8 % relative standard error; allow ±30 %
    assert 0.7 < s["ratio_mc_to_analytical"] < 1.3
    assert 0.85 <= s["coverage_probability"] <= 1.0
    assert abs(s["mc_mean_error_mps2"]) < 4 * s["mc_std_mps2"] / math.sqrt(s["trials"]) + 5e-9
    assert len(r.errors_mps2) == 80 and len(r.draws) == 80
