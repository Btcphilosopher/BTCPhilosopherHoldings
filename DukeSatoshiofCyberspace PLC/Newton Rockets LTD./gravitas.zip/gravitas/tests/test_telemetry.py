"""Telemetry schema, recording in every format, replay controls."""

import math

import numpy as np
import pytest
from pydantic import ValidationError

from gravitas.simulation.clock import SimulationClock
from gravitas.simulation.engine import SimulationEngine
from gravitas.simulation.scenario import SimulationConfig
from gravitas.telemetry.recorder import read_table, record
from gravitas.telemetry.replay import ReplaySession
from gravitas.telemetry.schema import COLUMNS, FIELD_SOURCES, TelemetryFrame, frames_from_chunk


@pytest.fixture(scope="module")
def result():
    from gravitas.simulation.scenario import default_anomaly_bodies

    return SimulationEngine(SimulationConfig(duration_s=120.0, seed=31, anomalies=default_anomaly_bodies())).run()


def test_frames_are_built_from_engine_output(result):
    clock = SimulationClock(result.config.start_epoch, result.config.sample_rate_hz)
    frames = frames_from_chunk(result.chain, clock, "STABLE", stride=100)
    assert len(frames) == 12
    f = frames[3]
    i = 300
    assert f.true_gravity_mps2 == result["truth.gravity_mps2"][i]
    assert f.raw_measurement_mps2 == result["raw.gravity_mps2"][i]
    assert f.timestamp.startswith("2026-01-01T12:00:30")
    for fld in FIELD_SOURCES:
        assert getattr(f, fld) != 0.0 or fld in ("feedback_force_n",)  # nothing left as placeholder zero


def test_frame_is_strict():
    base = {k: 1.0 for k in FIELD_SOURCES}
    base.update({"timestamp": "2026-01-01T12:00:00Z", "sim_time_s": 0.0, "adc_code": 5, "status": "STABLE",
                 "latitude_deg": 53.0, "longitude_deg": -1.0})
    TelemetryFrame(**base)
    with pytest.raises(ValidationError):
        TelemetryFrame(**{**base, "extra_field": 1.0})
    with pytest.raises(ValidationError):
        TelemetryFrame(**{**base, "raw_measurement_mps2": float("nan")})
    with pytest.raises(ValidationError):
        TelemetryFrame(**{**base, "status": "FINE"})
    with pytest.raises(ValidationError):
        TelemetryFrame(**{**base, "latitude_deg": 100.0})


@pytest.mark.parametrize("fmt,ext", [("csv", "csv"), ("parquet", "parquet"), ("hdf5", "h5"), ("json", "json")])
def test_record_and_read_back_lossless(result, tmp_path, fmt, ext):
    p = record(result, tmp_path / f"run.{ext}", fmt)
    table, manifest = read_table(p)
    assert manifest["random_seed"] == 31
    assert np.array_equal(table["raw.gravity_mps2"], result["raw.gravity_mps2"])
    assert np.array_equal(table["sim_time_s"], result.t_s)
    assert set(table["status"]) <= {"STABLE", "SETTLING", "SATURATED", "UNLOCKED"}


def test_telemetry_content_columns(result, tmp_path):
    p = record(result, tmp_path / "tele.csv", content="telemetry")
    table, _ = read_table(p)
    assert set(COLUMNS) <= set(table)


def test_replay_controls(result, tmp_path):
    p = record(result, tmp_path / "run.parquet")
    rs = ReplaySession.load(p)
    assert rs.n == result.t_s.size and rs.sample_rate_hz == pytest.approx(10.0)
    assert rs.tick(10) == {}  # paused
    rs.play()
    rows = rs.tick(25)
    assert len(rows["sim_time_s"]) == 25 and rs.cursor == 25
    rs.pause()
    assert rs.tick(5) == {}
    rs.seek(60.0)
    assert rs.t[rs.cursor] == pytest.approx(60.0)
    with pytest.raises(ValueError):
        rs.seek(1e6)
    rs.play()
    while rs.playing:
        rs.tick(500)
    assert rs.cursor == rs.n


def test_replay_reprocessing_reproduces_chain(result, tmp_path):
    rs = ReplaySession.load(record(result, tmp_path / "run.h5"))
    filt = rs.filter(kind="butterworth", cutoff_hz=result.config.filter.cutoff_hz, order=result.config.filter.order)
    # identical filter on identical raw data, but the replay uses its own reference offset
    sel = rs.t > 60
    assert np.max(np.abs(filt[sel] - result["filter.gravity_mps2"][sel])) < 1e-9
    corr = rs.correct()
    assert np.max(np.abs(corr[sel] - result["correction.gravity_mps2"][sel])) < 1e-9
    a = rs.analyse()
    assert "allan" in a and a["residual_rms_mps2"] < 1e-6
    out = rs.export(tmp_path / "replayed.json")
    table, manifest = read_table(out)
    assert "replay.corrected_mps2" in table and manifest["replay"]["derived_columns"]


def test_unknown_format_rejected(result, tmp_path):
    with pytest.raises(ValueError):
        record(result, tmp_path / "run.xlsx")
