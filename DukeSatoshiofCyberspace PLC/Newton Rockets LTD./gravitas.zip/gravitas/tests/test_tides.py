"""Tidal model: ephemerides, exact vs degree-2 tide, physical scaling, component exposure."""

import math

import numpy as np
import pytest

from gravitas.constants import physical as pc
from gravitas.earth.coordinates import geodetic_to_ecef
from gravitas.earth.tides import TideModel, body_positions_ecef, moon_ecliptic, sun_ecliptic
from gravitas.physics.tidal import degree2_vertical_tide, tidal_acceleration
from gravitas.validation.reference import get as ref

JD_2026 = 2_461_041.5  # 2026-01-01 00:00 UTC
LAT, LON = math.radians(53.38), math.radians(-1.47)


def test_moon_matches_meeus_example():
    lon, lat, d = moon_ecliptic(np.array([2_448_724.5]))
    assert math.degrees(lon[0]) == pytest.approx(ref("moon_longitude_1992_04_12").value, abs=0.02)
    assert math.degrees(lat[0]) == pytest.approx(ref("moon_latitude_1992_04_12").value, abs=0.01)
    assert d[0] / 1e3 == pytest.approx(ref("moon_distance_1992_04_12").value, abs=60.0)


def test_sun_matches_meeus_example():
    lon, lat, d = sun_ecliptic(np.array([2_448_908.5]))
    assert math.degrees(lon[0]) == pytest.approx(ref("sun_longitude_1992_10_13").value, abs=1e-3)
    assert d[0] / pc.ASTRONOMICAL_UNIT == pytest.approx(ref("sun_distance_1992_10_13").value, abs=1e-5)


def test_ephemeris_distances_stay_physical_over_a_year():
    jd = JD_2026 + np.arange(0, 366, 0.25)
    moon, sun = body_positions_ecef(jd)
    dm = np.linalg.norm(moon, axis=1) / 1e3
    ds = np.linalg.norm(sun, axis=1) / pc.ASTRONOMICAL_UNIT
    assert 355_000 < dm.min() < 360_000 and 404_000 < dm.max() < 407_500
    assert 0.9830 < ds.min() < 0.9835 and 1.0165 < ds.max() < 1.0170


def test_exact_tide_matches_degree2_formula():
    r = geodetic_to_ecef(LAT, LON, 0.0)
    jd = JD_2026 + np.arange(0, 2, 0.01)
    moon, _ = body_positions_ecef(jd)
    up = r / np.linalg.norm(r)  # geocentric radial direction for the degree-2 comparison
    a = tidal_acceleration(r, moon, pc.GM_MOON)
    a_up = a @ up
    d = np.linalg.norm(moon, axis=1)
    cosz = (moon @ up) / d
    approx = degree2_vertical_tide(np.linalg.norm(r), d, cosz, pc.GM_MOON)
    # degree-3 terms are ~ r/d ≈ 1.7 % of degree 2
    assert np.max(np.abs(a_up - approx)) < 0.03 * np.max(np.abs(approx))


def test_tide_amplitudes_are_physically_scaled():
    jd = JD_2026 + np.arange(0, 30, 1 / 48)
    tc = TideModel(gravimetric_factor=1.0).compute(jd, LAT, LON, 100.0)
    assert 60e-8 < np.ptp(tc.lunar_mps2) < 200e-8       # 60–200 µGal peak-to-peak
    assert 20e-8 < np.ptp(tc.solar_mps2) < 80e-8
    ratio = np.ptp(tc.lunar_mps2) / np.ptp(tc.solar_mps2)
    assert 1.8 < ratio < 3.2                              # GM r/d³ ratio ≈ 2.2
    assert np.max(np.abs(tc.combined_mps2)) < 3e-6        # never more than ~300 µGal


def test_moon_overhead_reduces_gravity_by_about_110_ugal():
    r = np.array([[pc.WGS84_A, 0.0, 0.0]])
    moon = np.array([[pc.MEAN_EARTH_MOON_DISTANCE, 0.0, 0.0]])
    a = tidal_acceleration(r, moon, pc.GM_MOON)
    dg = -a[0, 0]  # down = −x here
    assert dg == pytest.approx(-2 * pc.GM_MOON * pc.WGS84_A / pc.MEAN_EARTH_MOON_DISTANCE**3, rel=0.03)
    assert -1.2e-6 < dg < -1.0e-6


def test_components_exposed_and_switchable():
    jd = JD_2026 + np.arange(0, 1, 0.01)
    both = TideModel().compute(jd, LAT, LON, 0.0)
    nomoon = TideModel(include_moon=False).compute(jd, LAT, LON, 0.0)
    nosun = TideModel(include_sun=False).compute(jd, LAT, LON, 0.0)
    assert np.allclose(both.combined_mps2, both.lunar_mps2 + both.solar_mps2)
    assert np.all(nomoon.lunar_mps2 == 0) and np.allclose(nomoon.solar_mps2, both.solar_mps2)
    assert np.all(nosun.solar_mps2 == 0) and np.allclose(nosun.lunar_mps2, both.lunar_mps2)


def test_gravimetric_factor_scales_linearly():
    jd = JD_2026 + np.arange(0, 1, 0.05)
    rigid = TideModel(gravimetric_factor=1.0).compute(jd, LAT, LON, 0.0)
    elastic = TideModel().compute(jd, LAT, LON, 0.0)
    assert np.allclose(elastic.combined_mps2, pc.GRAVIMETRIC_FACTOR * rigid.combined_mps2, rtol=1e-12, atol=0)
    assert 1.15 < pc.GRAVIMETRIC_FACTOR < 1.17


def test_tidal_species_periods():
    """At the equator the diurnal species vanish (∝ sin 2φ) and M2 dominates; at 53° N the
    diurnal O1/K1 lines are present."""
    jd = JD_2026 + np.arange(0, 30, 1 / 96)
    x = TideModel().compute(jd, 0.0, LON, 0.0).lunar_mps2
    f = np.fft.rfftfreq(x.size, d=1 / 96)  # cycles per day
    p = np.abs(np.fft.rfft(x - x.mean()))
    peak = f[np.argmax(p[1:]) + 1]
    assert peak == pytest.approx(1.932, abs=0.05)  # M2 = 1.9323 cycles/day
    y = TideModel().compute(jd, LAT, LON, 0.0).lunar_mps2
    py = np.abs(np.fft.rfft(y - y.mean()))
    diurnal = py[(f > 0.85) & (f < 1.1)].max()
    assert diurnal > 0.3 * py[(f > 1.85) & (f < 2.0)].max()
