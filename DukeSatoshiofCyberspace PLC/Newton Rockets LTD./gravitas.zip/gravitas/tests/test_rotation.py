"""Earth rotation: angular velocity, sidereal time, centrifugal and Eötvös terms."""

import math
from datetime import datetime, timezone

import numpy as np
import pytest

from gravitas.constants import physical as pc
from gravitas.earth.rotation import (angular_velocity_vector, celestial_to_ecef, datetime_to_julian_date,
                                     earth_rotation_angle_rad, gmst_rad)
from gravitas.physics.centrifugal import (centrifugal_acceleration, coriolis_acceleration, eotvos_correction)
from gravitas.physics.potential import centrifugal_potential, numerical_gradient
from gravitas.validation.reference import get as ref


def test_julian_date_of_j2000():
    jd = datetime_to_julian_date(datetime(2000, 1, 1, 12, tzinfo=timezone.utc))
    assert jd == pytest.approx(pc.JD_J2000, abs=1e-9)


def test_naive_datetime_rejected():
    with pytest.raises(ValueError):
        datetime_to_julian_date(datetime(2000, 1, 1))


def test_gmst_meeus_example_12a():
    jd = datetime_to_julian_date(datetime(1987, 4, 10, 0, 0, tzinfo=timezone.utc))
    assert math.degrees(float(gmst_rad(jd))) == pytest.approx(ref("gmst_1987_04_10_0h").value, abs=1e-5)


def test_sidereal_rate_matches_omega():
    jd0 = 2_461_041.5
    dt_days = 1e-3
    d = (float(gmst_rad(jd0 + dt_days)) - float(gmst_rad(jd0))) % (2 * math.pi)
    assert d / (dt_days * 86400.0) == pytest.approx(pc.WGS84_OMEGA, rel=1e-6)


def test_era_and_gmst_close():
    jd = 2_461_041.5
    diff = (float(gmst_rad(jd)) - float(earth_rotation_angle_rad(jd)) + math.pi) % (2 * math.pi) - math.pi
    assert abs(diff) < math.radians(0.5)  # differ by accumulated precession in RA only


def test_celestial_rotation_is_orthogonal():
    v = np.array([[1.0, 2.0, 3.0]])
    out = celestial_to_ecef(v, np.array([1.234]))
    assert np.linalg.norm(out) == pytest.approx(np.linalg.norm(v))
    assert out[0, 2] == 3.0


def test_centrifugal_magnitude_and_gradient():
    r = np.array([4e6, 3e6, 4.2e6])
    a = centrifugal_acceleration(r, pc.WGS84_OMEGA)
    assert np.linalg.norm(a) == pytest.approx(pc.WGS84_OMEGA**2 * 5e6, rel=1e-14)
    assert a[2] == 0.0
    g = numerical_gradient(lambda x: centrifugal_potential(x, pc.WGS84_OMEGA), r)
    assert np.allclose(a, g, atol=1e-12)


def test_coriolis_perpendicular_to_velocity():
    v = np.array([1.0, 2.0, 0.5])
    c = coriolis_acceleration(v, pc.WGS84_OMEGA)
    assert abs(np.dot(c, v)) < 1e-18
    assert np.allclose(np.cross(-2 * angular_velocity_vector(), v), c)


def test_eotvos_eastward_motion():
    # 10 m/s east at the equator: 2 ω v ≈ 1.46 mGal plus v²/R ≈ 0.0016 mGal
    e = eotvos_correction(0.0, 10.0, 0.0, pc.WGS84_OMEGA, 6.378e6)
    assert e == pytest.approx(2 * pc.WGS84_OMEGA * 10 + 100 / 6.378e6, rel=1e-12)
    assert eotvos_correction(0.0, 0.0, 0.0, pc.WGS84_OMEGA, 6.378e6) == 0.0
    # westward motion increases measured gravity
    assert eotvos_correction(0.5, -10.0, 0.0, pc.WGS84_OMEGA, 6.378e6) < 0
