"""Experiment library outputs (short durations)."""

import math

import numpy as np
import pytest

from gravitas.constants import physical as pc
from gravitas.experiments import list_experiments, run_experiment


def test_registry():
    names = {e["name"] for e in list_experiments()}
    assert {"static", "altitude", "latitude", "tides", "anomaly", "vibration", "calibration"} <= names


def test_static_outputs(tmp_path):
    r = run_experiment("static", duration_s=600.0)
    s = r.summary
    for k in ("true_static_gravity_mps2", "raw_mean_mps2", "corrected_mean_mps2", "injected_bias_mean_mps2",
              "raw_std_mps2", "residual_drift_rate_mps2_per_s", "standard_uncertainty_mps2"):
        assert math.isfinite(s[k]), k
    assert abs(s["estimate_error_mps2"]) < 3 * s["standard_uncertainty_mps2"]
    assert s["raw_minus_true_mean_mps2"] == pytest.approx(s["injected_bias_mean_mps2"], abs=5e-8)
    files = r.save(tmp_path, plots=True)
    assert any(str(f).endswith(".png") for f in files) and any(str(f).endswith(".html") for f in files)
    d = r.to_dict(max_points=100)
    assert len(d["series"]["x"]) <= 100


def test_altitude_recovers_free_air_gradient():
    r = run_experiment("altitude", duration_s=900.0)
    s = r.summary
    assert s["monotonic_decrease"]
    assert abs(s["gradient_relative_error"]) < 2e-3
    assert s["model_free_air_gradient_mps2_per_m"] == pytest.approx(-3.085e-6, rel=2e-3)


def test_latitude_rotation_effects():
    r = run_experiment("latitude", duration_s=700.0)
    s = r.summary
    assert s["monotonic_increase"]
    assert s["equator_to_pole_difference_mps2"] == pytest.approx(pc.WGS84_GAMMA_P - pc.WGS84_GAMMA_E, abs=1e-9)
    assert s["rotation_effect_at_equator_mps2"] == pytest.approx(pc.WGS84_OMEGA**2 * pc.WGS84_A, rel=1e-9)
    assert abs(s["rotation_effect_at_pole_mps2"]) < 1e-12
    assert s["station_error_rms_mps2"] < 1e-7


@pytest.mark.slow
def test_tides_recover_gravimetric_factor():
    r = run_experiment("tides", duration_s=2 * 86400.0, sample_rate_hz=0.5)
    s = r.summary
    assert 1.0e-6 < s["combined_range_mps2"] < 3.5e-6
    assert s["tide_to_baseline_ratio"] < 4e-7  # tiny perturbation on a large baseline
    assert s["gravimetric_factor_kalman"] == pytest.approx(s["gravimetric_factor_true"], rel=3e-3)
    assert s["residual_rms_after_tide_removal_mps2"] < 0.05 * s["residual_rms_without_tide_removal_mps2"]


def test_anomaly_profile_matches_synthetic_truth():
    r = run_experiment("anomaly", duration_s=1200.0)
    s = r.summary
    assert s["label"] == "SYNTHETIC GEOPHYSICAL MODEL"
    assert s["correlation_true_measured"] > 0.999
    assert s["rms_error_mps2"] < 0.05 * s["peak_true_anomaly_mps2"]
    assert s["eotvos_correction_mps2"] > 0  # eastward survey reduces measured g


def test_vibration_filters_improve_measurement():
    r = run_experiment("vibration", duration_s=600.0)
    rows = r.tables["filters"]
    red = dict(zip(rows["filter"], rows["reduction_factor"]))
    assert red["none"] == pytest.approx(1.0)
    assert red["butterworth"] > 20 and red["moving_average"] > 20 and red["lowpass"] > 3 and red["kalman"] > 3
    assert r.summary["raw_identical_across_filters"]
