"""Reproducibility: identical seeds ⇒ identical output; chunking invariance; manifest completeness."""

import numpy as np
import pytest

from gravitas.simulation.engine import SimulationEngine
from gravitas.simulation.scenario import SimulationConfig

MANIFEST_KEYS = {"random_seed", "simulation_timestep_s", "simulation_duration_s", "earth_model", "instrument_model",
                 "sensor_model", "calibration_parameters", "location", "environment", "software", "config_hash_sha256"}


def test_identical_seed_identical_results():
    a = SimulationEngine(SimulationConfig(duration_s=120, seed=77)).run()
    b = SimulationEngine(SimulationConfig(duration_s=120, seed=77)).run()
    for k in a.chain.channels:
        assert np.array_equal(a[k], b[k], equal_nan=True), k


def test_different_seed_different_noise():
    a = SimulationEngine(SimulationConfig(duration_s=60, seed=1)).run()
    b = SimulationEngine(SimulationConfig(duration_s=60, seed=2)).run()
    assert not np.array_equal(a["raw.gravity_mps2"], b["raw.gravity_mps2"])
    assert np.array_equal(a["truth.gravity_mps2"], b["truth.gravity_mps2"])  # physics is seed-independent


@pytest.mark.parametrize("chunk_s", [0.1, 7.3, 60.0, 1000.0])
def test_chunking_does_not_change_results(chunk_s):
    ref = SimulationEngine(SimulationConfig(duration_s=150, seed=5, chunk_s=150.0)).run()
    other = SimulationEngine(SimulationConfig(duration_s=150, seed=5, chunk_s=chunk_s)).run()
    for k in ("raw.gravity_mps2", "filter.gravity_mps2", "estimate.gravity_mps2", "environment.vibration_up_mps2",
              "sensor.drift_mps2", "environment.instrument_temperature_c"):
        assert np.array_equal(ref[k], other[k]), k


def test_reset_reproduces_and_seed_override():
    e = SimulationEngine(SimulationConfig(duration_s=30, seed=3))
    a = e.run()["raw.gravity_mps2"]
    e.reset()
    b = e.run()["raw.gravity_mps2"]
    assert np.array_equal(a, b)
    e.reset(seed=4)
    assert e.config.seed == 4


def test_toggling_a_switch_does_not_perturb_other_streams():
    base = SimulationConfig(duration_s=60, seed=9)
    a = SimulationEngine(base).run()
    b = SimulationEngine(base.model_copy(update={"physics": base.physics.model_copy(update={"vibration": False})})).run()
    assert np.array_equal(a["sensor.white_noise_mps2"], b["sensor.white_noise_mps2"])
    assert np.array_equal(a["environment.instrument_temperature_c"], b["environment.instrument_temperature_c"])
    assert not np.array_equal(a["raw.gravity_mps2"], b["raw.gravity_mps2"])


def test_manifest_records_everything():
    r = SimulationEngine(SimulationConfig(duration_s=10, seed=8)).run()
    m = r.manifest
    assert MANIFEST_KEYS <= set(m)
    assert m["random_seed"] == 8 and m["simulation_timestep_s"] == pytest.approx(0.1)
    cfg2 = SimulationConfig.model_validate(m["config"])
    assert cfg2.config_hash() == m["config_hash_sha256"]
    r2 = SimulationEngine(cfg2).run()
    assert np.array_equal(r["raw.gravity_mps2"], r2["raw.gravity_mps2"])


def test_config_round_trip_file(tmp_path):
    cfg = SimulationConfig(duration_s=42.0, seed=123)
    p = tmp_path / "cfg.json"
    cfg.to_file(p)
    assert SimulationConfig.from_file(p).config_hash() == cfg.config_hash()


def test_config_rejects_unknown_and_invalid_fields():
    from pydantic import ValidationError

    with pytest.raises(ValidationError):
        SimulationConfig(sample_rat_hz=10.0)
    with pytest.raises(ValidationError):
        SimulationConfig(location={"latitude_deg": 95.0, "longitude_deg": 0.0, "altitude_m": 0.0})
    with pytest.raises(ValidationError):
        SimulationConfig(sample_rate_hz=-1.0)
