"""Live simulation service behind the engine API.

A background thread advances a :class:`SimulationEngine` so that simulated
time tracks ``speed × wall-clock``. Recent output is kept in two ring buffers:

    full-rate buffer   every channel needed by the console, last ``full_window_s`` (1 h)
    decimated buffer   1 s block means of the plotted channels, last 24 h

Every value served by the API is read from these buffers or computed on demand
by engine modules (Earth, tide, anomaly models; experiments; Monte Carlo).
Nothing is synthesised in this layer.
"""

from __future__ import annotations

import math
import threading
import time
from collections import deque

import numpy as np

from gravitas import SOFTWARE_VERSION
from gravitas.earth.coordinates import GeodeticPosition, enu_to_geodetic
from gravitas.earth.gravity import EarthGravityModel, EarthModelSwitches
from gravitas.earth.normal_gravity import normal_gravity_free_air, somigliana, spherical_gravity
from gravitas.earth.tides import TideModel
from gravitas.estimation.allan import overlapping_adev
from gravitas.physics.anomalies import AnomalyField, body_from_dict
from gravitas.simulation.engine import SimulationEngine, SimulationResult
from gravitas.simulation.scenario import SimulationConfig, default_anomaly_bodies
from gravitas.simulation.state import ChainChunk
from gravitas.telemetry.schema import FIELD_SOURCES, TelemetryFrame

SERIES_CHANNELS = {
    "true_mps2": "truth.gravity_mps2", "static_true_mps2": "truth.static_gravity_mps2", "raw_mps2": "raw.gravity_mps2",
    "filtered_mps2": "filter.gravity_mps2", "calibrated_mps2": "calibration.gravity_mps2",
    "corrected_mps2": "correction.gravity_mps2", "estimate_mps2": "estimate.gravity_mps2",
    "estimate_sigma_mps2": "estimate.sigma_mps2", "tide_mps2": "tide.combined_mps2",
    "temperature_c": "environment.instrument_temperature_c", "vibration_mps2": "environment.vibration_up_mps2",
    "bias_mps2": "sensor.total_bias_mps2",
}

SWITCH_NAMES = ("earth_gravity", "earth_oblateness", "earth_rotation", "altitude", "latitude", "moon", "sun",
                "local_anomaly", "temperature", "vibration", "sensor_bias", "sensor_noise")


class RingBuffer:
    def __init__(self, capacity: int):
        self.capacity = int(capacity)
        self.data: dict[str, np.ndarray] = {}
        self.size = 0
        self.head = 0  # next write position

    def append(self, cols: dict[str, np.ndarray]) -> None:
        n = len(next(iter(cols.values())))
        if not self.data:
            self.data = {k: np.zeros(self.capacity, dtype=np.asarray(v).dtype if np.asarray(v).dtype != bool else bool)
                         for k, v in cols.items()}
        if n >= self.capacity:
            for k, v in cols.items():
                self.data[k][:] = np.asarray(v)[-self.capacity:]
            self.head = 0
            self.size = self.capacity
            return
        idx = (self.head + np.arange(n)) % self.capacity
        for k, v in cols.items():
            self.data[k][idx] = v
        self.head = (self.head + n) % self.capacity
        self.size = min(self.capacity, self.size + n)

    def last(self, n: int | None = None) -> dict[str, np.ndarray]:
        if self.size == 0:
            return {}
        n = self.size if n is None else min(int(n), self.size)
        idx = (self.head - n + np.arange(n)) % self.capacity
        return {k: v[idx] for k, v in self.data.items()}

    def clear(self) -> None:
        self.data = {}
        self.size = 0
        self.head = 0


def live_default_config() -> SimulationConfig:
    return SimulationConfig(name="live", duration_s=86400.0 * 365, anomalies=default_anomaly_bodies(), chunk_s=1.0)


class LiveSimulation:
    def __init__(self, config: SimulationConfig | None = None, speed: float = 1.0, full_window_s: float = 3600.0):
        self.base_config = config or live_default_config()
        self.speed = float(speed)
        self.full_window_s = full_window_s
        self.lock = threading.RLock()
        self.running = False
        self._thread: threading.Thread | None = None
        self._stop = threading.Event()
        self.last_calibration: dict | None = None
        self.last_survey: dict | None = None
        self.last_monte_carlo: dict | None = None
        self._budget_cache: tuple[float, dict] | None = None
        self.paused = False
        self._init_engine(self.base_config)

    # -------------------------------------------------------------- lifecycle
    def _init_engine(self, cfg: SimulationConfig) -> None:
        with self.lock:
            self.engine = SimulationEngine(cfg)
            fs = cfg.sample_rate_hz
            self.full = RingBuffer(int(self.full_window_s * fs))
            self.dec = RingBuffer(86_400)
            self._dec_acc: list[dict[str, np.ndarray]] = []
            self._dec_count = 0
            self.status = ("SETTLING", ["starting"])
            self.sim_time_s = 0.0
            self._wall0 = time.monotonic()
            self._sim0 = 0.0
            self._budget_cache = None
            self.telemetry_recent: deque = deque(maxlen=1)

    def start(self) -> None:
        if self._thread and self._thread.is_alive():
            return
        self._stop.clear()
        self.running = True
        self._thread = threading.Thread(target=self._loop, name="gravitas-live", daemon=True)
        self._thread.start()

    def stop(self) -> None:
        self._stop.set()
        self.running = False
        if self._thread:
            self._thread.join(timeout=5)

    def _loop(self) -> None:
        fs = self.engine.config.sample_rate_hz
        while not self._stop.is_set():
            if self.paused:
                time.sleep(0.05)
                continue
            target = self._sim0 + (time.monotonic() - self._wall0) * self.speed
            lag = target - self.sim_time_s
            if lag * fs >= 1:
                n = int(min(lag, 60.0) * fs)
                self.advance(max(1, n))
            else:
                time.sleep(0.02)

    def advance(self, n: int) -> ChainChunk:
        with self.lock:
            chunk = self.engine.step(n)
            self._ingest(chunk)
            return chunk

    def _ingest(self, chunk: ChainChunk) -> None:
        cols = {"t_s": chunk.t_s, **chunk.channels}
        for k, v in chunk.flags.items():
            cols["flag." + k] = v
        self.full.append(cols)
        fs = self.engine.config.sample_rate_hz
        per = max(1, int(round(fs)))
        plot = {"t_s": chunk.t_s, **{k: chunk.channels[v] for k, v in SERIES_CHANNELS.items()}}
        self._dec_acc.append(plot)
        self._dec_count += chunk.n
        if self._dec_count >= per:
            merged = {k: np.concatenate([a[k] for a in self._dec_acc]) for k in plot}
            m = (merged["t_s"].size // per) * per
            if m:
                self.dec.append({k: v[:m].reshape(-1, per).mean(axis=1) for k, v in merged.items()})
            rest = {k: v[m:] for k, v in merged.items()}
            self._dec_acc = [rest] if rest["t_s"].size else []
            self._dec_count = rest["t_s"].size
        self.sim_time_s = float(chunk.t_s[-1] + 1.0 / fs)
        self.status = self.engine.status_for(chunk)

    # -------------------------------------------------------------- controls
    def control(self, action: str, **kw) -> dict:
        with self.lock:
            if action == "pause":
                self.paused = True
            elif action == "resume":
                self.paused = False
                self._wall0 = time.monotonic()
                self._sim0 = self.sim_time_s
            elif action == "reset":
                seed = kw.get("seed")
                cfg = self.engine.config if seed is None else self.engine.config.model_copy(update={"seed": int(seed)})
                self._init_engine(cfg)
            elif action == "set_speed":
                sp = float(kw["speed"])
                if not (0 < sp <= 10_000):
                    raise ValueError("speed must be in (0, 10000]")
                self._sim0 = self.sim_time_s
                self._wall0 = time.monotonic()
                self.speed = sp
            elif action == "set_location":
                loc = self.engine.config.location.model_copy(update={
                    "latitude_deg": float(kw["latitude_deg"]), "longitude_deg": float(kw["longitude_deg"]),
                    "altitude_m": float(kw.get("altitude_m", 0.0))})
                from gravitas.simulation.scenario import LocationConfig

                LocationConfig(**loc.model_dump())  # validate
                self._init_engine(self.engine.config.model_copy(update={"location": loc}))
            elif action == "set_mode":
                self.engine.set_mode(str(kw["mode"]))
            else:
                raise ValueError(f"unknown control action {action!r}")
        return self.health()

    def set_switches(self, switches: dict) -> dict:
        unknown = set(switches) - set(SWITCH_NAMES)
        if unknown:
            raise ValueError(f"unknown physics switches: {sorted(unknown)}")
        with self.lock:
            self.engine.apply_physics_switches(**{k: bool(v) for k, v in switches.items()})
        return self.physics()

    # -------------------------------------------------------------- views
    def health(self) -> dict:
        return {"status": "ok", "software_version": SOFTWARE_VERSION, "sim_time_s": self.sim_time_s,
                "running": self.running and not self.paused, "speed": self.speed}

    def physics(self) -> dict:
        p = self.engine.config.physics
        return {"switches": {k: bool(getattr(p, k)) for k in SWITCH_NAMES}}

    def _require_data(self) -> dict[str, np.ndarray]:
        d = self.full.last(1)
        if not d:
            raise LookupError("no simulation data yet")
        return {k: v[-1] for k, v in d.items()}

    def overview(self) -> dict:
        with self.lock:
            last = self._require_data()
            fs = self.engine.config.sample_rate_hz
            sec = self.full.last(max(1, int(fs)))
            vib_rms = float(np.sqrt(np.mean(sec["environment.vibration_up_rms_mps2"] ** 2)))
            budget = self.uncertainty()
            status, reasons = ("PAUSED", ["simulation paused"]) if self.paused else self.status
            cfg = self.engine.config
            return {
                "timestamp": self.engine.clock.iso(float(last["t_s"])), "sim_time_s": float(last["t_s"]),
                "latitude_deg": float(last["position.latitude_deg"]), "longitude_deg": float(last["position.longitude_deg"]),
                "altitude_m": cfg.location.altitude_m, "mode": cfg.instrument.mode,
                "local_gravity_mps2": float(last["truth.gravity_mps2"]),
                "static_gravity_mps2": float(last["truth.static_gravity_mps2"]),
                "raw_measurement_mps2": float(last["raw.gravity_mps2"]),
                "filtered_mps2": float(last["filter.gravity_mps2"]),
                "calibrated_mps2": float(last["calibration.gravity_mps2"]),
                "corrected_gravity_mps2": float(last["correction.gravity_mps2"]),
                "estimate_mps2": float(last["estimate.gravity_mps2"]),
                "bias_mps2": float(last["sensor.total_bias_mps2"]),
                "tidal_component_mps2": float(last["tide.combined_mps2"]),
                "temperature_c": float(last["environment.instrument_temperature_c"]),
                "vibration_rms_mps2": vib_rms,
                "standard_uncertainty_mps2": budget["standard_uncertainty_mps2"],
                "expanded_uncertainty_mps2": budget["expanded_uncertainty_mps2"],
                "coverage_factor": budget["coverage_factor"],
                "instrument_status": status, "status_reasons": reasons,
            }

    def series(self, window_s: float = 60.0, max_points: int = 2000) -> dict:
        with self.lock:
            fs = self.engine.config.sample_rate_hz
            if window_s <= self.full_window_s:
                data = self.full.last(int(window_s * fs))
                rate = fs
                keys = {"t_s": "t_s", **SERIES_CHANNELS}
                data = {k: data[v] for k, v in keys.items()} if data else {}
            else:
                data = self.dec.last(int(window_s))
                rate = 1.0
            if not data:
                raise LookupError("no simulation data yet")
            n = data["t_s"].size
            idx = np.unique(np.linspace(0, n - 1, min(n, max_points)).round().astype(int))
            out = {"window_s": window_s, "sample_rate_hz": rate}
            out.update({k: v[idx].tolist() for k, v in data.items()})
            return out

    def instrument(self, history_s: float = 60.0) -> dict:
        with self.lock:
            last = self._require_data()
            g = self.engine.gravimeter
            d = g.describe()
            fs = self.engine.config.sample_rate_hz
            h = self.full.last(int(history_s * fs))
            opt = g.cfg.optical
            adc = opt.adc if opt.enabled else g.cfg.transducer.adc
            x = float(last["instrument.proof_mass_position_m"])
            k = g.spring_constant
            noise_rms = float(np.std(h["sensor.white_noise_mps2"] + h["sensor.correlated_noise_mps2"]))
            return {
                "mode": d["mode"], "proof_mass_kg": d["proof_mass_kg"], "spring_constant_npm": d["spring_constant_npm"],
                "damping_nspm": d["damping_nspm"], "natural_frequency_hz": d["natural_frequency_hz"],
                "damping_ratio": d["damping_ratio"], "reference_gravity_mps2": d["reference_gravity_mps2"],
                "proof_mass_position_m": x, "proof_mass_velocity_mps": float(last["instrument.proof_mass_velocity_mps"]),
                "spring_force_n": float(last["instrument.spring_force_n"]),
                "gravity_force_n": float(last["instrument.gravity_force_n"]),
                "feedback_force_n": float(last["instrument.feedback_force_n"]),
                "net_force_n": float(last["instrument.gravity_force_n"] - last["instrument.spring_force_n"] + last["instrument.feedback_force_n"]),
                "readout": {"type": d["readout"], "wavelength_m": d["wavelength_m"],
                            "phase_rad": float(last["instrument.optical_phase_rad"]),
                            "intensity_i_v": float(last["adc.channel1_v"]), "intensity_q_v": float(last["adc.channel2_v"]),
                            "measured_displacement_m": float(last["instrument.measured_position_m"])},
                "adc": {"bits": adc.bits, "full_scale_v": adc.full_scale_v, "lsb_v": adc.lsb_v,
                        "code_i": int(last["adc.code1"]), "code_q": int(last["adc.code2"]),
                        "saturated": bool(last["flag.adc_saturated"])},
                "temperature_c": float(last["environment.instrument_temperature_c"]),
                "bias_mps2": float(last["sensor.total_bias_mps2"]), "noise_rms_mps2": noise_rms,
                "history": {"t_s": h["t_s"].tolist(), "position_m": h["instrument.proof_mass_position_m"].tolist(),
                            "velocity_mps": h["instrument.proof_mass_velocity_mps"].tolist(),
                            "feedback_force_n": h["instrument.feedback_force_n"].tolist()},
                "spring_extension_m": x + g.mass * g.g_ref / k,
            }

    def _recent_result(self, max_s: float = 3600.0) -> SimulationResult:
        fs = self.engine.config.sample_rate_hz
        d = self.full.last(int(max_s * fs))
        if not d or d["t_s"].size < 32:
            raise LookupError("not enough simulation data yet")
        channels = {k: v for k, v in d.items() if k != "t_s" and not k.startswith("flag.")}
        flags = {k[5:]: v for k, v in d.items() if k.startswith("flag.")}
        chain = ChainChunk(d["t_s"], channels, flags)
        cfg = self.engine.config.model_copy(update={"settle_time_s": float(d["t_s"][0]) + min(self.engine.config.settle_time_s, 0.1 * (d["t_s"][-1] - d["t_s"][0]))})
        return SimulationResult(cfg, chain, {"filter": self.engine.filter.describe()}, list(self.engine.status_log[-5:]))

    def uncertainty(self) -> dict:
        with self.lock:
            now = self.sim_time_s
            if self._budget_cache and abs(now - self._budget_cache[0]) < 2.0 * max(1.0, self.speed):
                return self._budget_cache[1]
            try:
                est = self._recent_result().final_estimate().to_dict()
            except LookupError:
                last = self._require_data()
                prior = float(last["estimate.sigma_mps2"])
                est = {"value_mps2": float(last["estimate.gravity_mps2"]), "standard_uncertainty_mps2": prior,
                       "expanded_uncertainty_mps2": self.engine.config.uncertainty.coverage_factor * prior,
                       "coverage_factor": self.engine.config.uncertainty.coverage_factor, "contributions": []}
            self._budget_cache = (now, est)
            return est

    def allan(self, max_points: int = 60) -> dict:
        with self.lock:
            dd = self.dec.last()
            fs = self.engine.config.sample_rate_hz
            if dd and dd["t_s"].size >= 3600:
                y, dt = dd["raw_mps2"], 1.0
            else:
                d = self.full.last()
                if not d or d["t_s"].size < 64:
                    raise LookupError("not enough data for Allan deviation")
                y, dt = d["raw.gravity_mps2"], 1.0 / fs
        res = overlapping_adev(y - y.mean(), dt)
        out = res.to_dict()
        out.pop("n_terms", None)
        return out

    def telemetry(self, n: int = 50) -> dict:
        with self.lock:
            d = self.full.last(int(n))
            if not d:
                return {"frames": []}
            status = "PAUSED" if self.paused else self.status[0]
            budget = self.uncertainty()
            frames = []
            for i in range(d["t_s"].size):
                rec = {"timestamp": self.engine.clock.iso(float(d["t_s"][i])), "sim_time_s": float(d["t_s"][i]), "status": status}
                for fld, src in FIELD_SOURCES.items():
                    rec[fld] = int(d[src][i]) if fld == "adc_code" else float(d[src][i])
                rec["uncertainty_mps2"] = budget["standard_uncertainty_mps2"]
                frames.append(TelemetryFrame(**rec).model_dump())
            return {"frames": frames}

    # -------------------------------------------------------------- on-demand physics
    def earth(self, lat_deg=None, lon_deg=None, alt_m=None) -> dict:
        cfg = self.engine.config
        lat_deg = cfg.location.latitude_deg if lat_deg is None else float(lat_deg)
        lon_deg = cfg.location.longitude_deg if lon_deg is None else float(lon_deg)
        alt_m = cfg.location.altitude_m if alt_m is None else float(alt_m)
        pos = GeodeticPosition.from_degrees(lat_deg, lon_deg, alt_m)
        sw = self.engine.earth.switches
        model = EarthGravityModel(switches=sw)
        b = model.evaluate_position(pos)
        lats = np.linspace(0.0, 90.0, 91)
        full = EarthGravityModel()
        comp = full.components(np.radians(lats), pos.longitude_rad, np.zeros_like(lats))
        norot = EarthGravityModel(switches=EarthModelSwitches(earth_rotation=False)).magnitude(np.radians(lats), pos.longitude_rad, 0.0)
        alts = np.linspace(0.0, 10_000.0, 101)
        alt_eff = full.magnitude(np.full(alts.size, pos.latitude_rad), pos.longitude_rad, alts)
        series_here = float(full.magnitude(pos.latitude_rad, pos.longitude_rad, alt_m)[0])
        return {
            "location": {"latitude_deg": lat_deg, "longitude_deg": lon_deg, "altitude_m": alt_m},
            "switches": {k: getattr(sw, k) for k in ("earth_gravity", "earth_oblateness", "earth_rotation", "altitude", "latitude")},
            "spherical_mps2": float(spherical_gravity(alt_m)),
            "newtonian_mps2": b.newtonian_mps2, "newtonian_enu_mps2": b.newtonian_enu_mps2.tolist(),
            "centrifugal_mps2": b.centrifugal_mps2, "centrifugal_enu_mps2": b.centrifugal_enu_mps2.tolist(),
            "effective_mps2": b.effective_mps2, "effective_enu_mps2": b.effective_enu_mps2.tolist(),
            "somigliana_mps2": float(somigliana(pos.latitude_rad)),
            "somigliana_free_air_mps2": float(normal_gravity_free_air(pos.latitude_rad, alt_m)),
            "model_discrepancy_mps2": float(normal_gravity_free_air(pos.latitude_rad, alt_m)) - series_here,
            "free_air_gradient_mps2_per_m": full.vertical_gradient(pos.latitude_rad, pos.longitude_rad, alt_m),
            "latitude_profile": {"lat_deg": lats.tolist(), "effective_mps2": comp["effective_mps2"].tolist(),
                                 "no_rotation_mps2": norot.tolist(),
                                 "spherical_mps2": [float(spherical_gravity(0.0))] * lats.size,
                                 "centrifugal_up_mps2": comp["centrifugal_vertical_mps2"].tolist()},
            "altitude_profile": {"alt_m": alts.tolist(), "effective_mps2": alt_eff.tolist(),
                                 "spherical_mps2": spherical_gravity(alts).tolist()},
        }

    def tides(self, hours: float = 48.0, step_s: float = 600.0) -> dict:
        cfg = self.engine.config
        if not (0 < hours <= 24 * 60) or step_s <= 0:
            raise ValueError("hours must be in (0, 1440] and step_s > 0")
        t = np.arange(0.0, hours * 3600.0 + 1e-9, step_s) + self.sim_time_s
        jd = self.engine.clock.julian_dates(t)
        o = self.engine.origin
        tm = TideModel(include_moon=cfg.physics.moon, include_sun=cfg.physics.sun,
                       gravimetric_factor=cfg.tides.gravimetric_factor_true)
        c = tm.compute(jd, o.latitude_rad, o.longitude_rad, o.height_m)
        now = tm.compute(self.engine.clock.julian_dates(np.array([self.sim_time_s])), o.latitude_rad, o.longitude_rad, o.height_m)
        return {"t_s": t.tolist(), "timestamps": [self.engine.clock.iso(x) for x in t],
                "lunar_mps2": c.lunar_mps2.tolist(), "solar_mps2": c.solar_mps2.tolist(),
                "combined_mps2": c.combined_mps2.tolist(), "gravimetric_factor": cfg.tides.gravimetric_factor_true,
                "current": {"lunar_mps2": float(now.lunar_mps2[0]), "solar_mps2": float(now.solar_mps2[0]),
                            "combined_mps2": float(now.combined_mps2[0])}}

    def _field(self) -> AnomalyField:
        return AnomalyField([body_from_dict({"kind": b.kind, **b.params}) for b in self.engine.config.anomalies])

    def anomalies(self) -> dict:
        f = self._field()
        east = np.linspace(-600.0, 800.0, 281)
        prof = f.delta_g(np.column_stack([east, np.zeros_like(east), np.zeros_like(east)])) if len(f) else np.zeros_like(east)
        ge = np.linspace(-600.0, 800.0, 71)
        gn = np.linspace(-400.0, 400.0, 41)
        grid = f.grid(ge, gn) if len(f) else np.zeros((gn.size, ge.size))
        return {"label": AnomalyField.label,
                "bodies": [{"kind": b.kind, "description": b.description, "params": b.params} for b in self.engine.config.anomalies],
                "profile": {"distance_m": (east - east[0]).tolist(), "east_m": east.tolist(),
                            "north_m": [0.0] * east.size, "anomaly_mps2": prof.tolist()},
                "grid": {"east_m": ge.tolist(), "north_m": gn.tolist(), "anomaly_mps2": grid.tolist()},
                "survey": self.last_survey}

    def run_survey(self, duration_s: float = 1800.0, sample_rate_hz: float = 10.0) -> dict:
        from gravitas.experiments import anomaly

        r = anomaly.run(duration_s=duration_s, sample_rate_hz=sample_rate_hz, config=self.engine.config.model_copy(
            update={"trajectory": self.base_config.trajectory, "chunk_s": 60.0}), seed=self.engine.config.seed)
        idx = np.unique(np.linspace(0, r.x.size - 1, min(r.x.size, 1500)).round().astype(int))
        ch = r.simulation_results[0].chain.channels
        self.last_survey = {
            "distance_m": (r.x[idx] - r.x[0]).tolist(), "east_m": r.x[idx].tolist(),
            "latitude_deg": ch["position.latitude_deg"][idx].tolist(), "longitude_deg": ch["position.longitude_deg"][idx].tolist(),
            "true_anomaly_mps2": r.curves["true_anomaly_mps2"][idx].tolist(),
            "measured_anomaly_mps2": r.curves["measured_anomaly_mps2"][idx].tolist(),
            "uncertainty_mps2": r.curves["uncertainty_mps2"][idx].tolist(),
            "rms_error_mps2": r.summary["rms_error_mps2"]}
        return self.anomalies()

    def run_calibration(self, seed: int = 7) -> dict:
        from gravitas.experiments import calibration

        r = calibration.run(seed=seed, config=self.engine.config.model_copy(update={"trajectory": self.base_config.trajectory}))
        s = r.summary
        idx = np.unique(np.linspace(0, r.x.size - 1, min(r.x.size, 1500)).round().astype(int))
        self.last_calibration = {
            "injected": s["injected"], "estimated": s["estimated"], "estimated_uncertainty": s["estimated_uncertainty"],
            "residual_rms_uncalibrated_mps2": s["residual_rms_uncalibrated_mps2"],
            "residual_rms_calibrated_mps2": s["residual_rms_calibrated_mps2"],
            "improvement_factor": s["improvement_factor"],
            "series": {"t_s": r.x[idx].tolist(), "true_mps2": r.curves["true_mps2"][idx].tolist(),
                       "uncalibrated_mps2": r.curves["uncalibrated_mps2"][idx].tolist(),
                       "calibrated_mps2": r.curves["calibrated_mps2"][idx].tolist(),
                       "temperature_c": r.curves["temperature_c"][idx].tolist()}}
        return self.last_calibration

    def run_monte_carlo(self, trials: int = 50, duration_s: float = 300.0) -> dict:
        from gravitas.simulation.monte_carlo import run_monte_carlo

        if not (3 <= trials <= 500):
            raise ValueError("trials must be within [3, 500]")
        base = self.engine.config.model_copy(update={"trajectory": self.base_config.trajectory, "chunk_s": 60.0})
        r = run_monte_carlo(base, trials=trials, duration_s=duration_s)
        d = r.to_dict(include_samples=True)
        d.pop("draws", None)
        d.pop("analytic_u_mps2", None)
        self.last_monte_carlo = d
        return d

    def map(self) -> dict:
        with self.lock:
            last = self._require_data()
            budget = self.uncertainty()
        lat = np.arange(-90.0, 90.1, 5.0)
        lon = np.arange(-180.0, 180.1, 10.0)
        model = EarthGravityModel(switches=self.engine.earth.switches)
        g = np.array([model.magnitude(np.full(lon.size, math.radians(la)), np.radians(lon), 0.0) for la in lat])
        f = self._field()
        ge = np.linspace(-600.0, 800.0, 36)
        gn = np.linspace(-400.0, 400.0, 21)
        grid = f.grid(ge, gn) if len(f) else np.zeros((gn.size, ge.size))
        o = self.engine.origin
        glat, glon, _ = enu_to_geodetic(np.column_stack([ge, np.zeros_like(ge), np.zeros_like(ge)]), o)
        nlat, _, _ = enu_to_geodetic(np.column_stack([np.zeros_like(gn), gn, np.zeros_like(gn)]), o)
        if self.last_survey:
            path = [{"latitude_deg": a, "longitude_deg": b, "anomaly_mps2": c} for a, b, c in
                    zip(self.last_survey["latitude_deg"][::10], self.last_survey["longitude_deg"][::10],
                        self.last_survey["measured_anomaly_mps2"][::10])]
        else:
            east = np.linspace(-600.0, 800.0, 57)
            plat, plon, _ = enu_to_geodetic(np.column_stack([east, np.zeros_like(east), np.zeros_like(east)]), o)
            an = f.delta_g(np.column_stack([east, np.zeros_like(east), np.zeros_like(east)])) if len(f) else np.zeros_like(east)
            path = [{"latitude_deg": float(np.degrees(a)), "longitude_deg": float(np.degrees(b)), "anomaly_mps2": float(c)}
                    for a, b, c in zip(plat, plon, an)]
        return {"instrument": {"latitude_deg": float(last["position.latitude_deg"]), "longitude_deg": float(last["position.longitude_deg"]),
                               "altitude_m": self.engine.config.location.altitude_m,
                               "gravity_mps2": float(last["estimate.gravity_mps2"]),
                               "uncertainty_mps2": budget["standard_uncertainty_mps2"]},
                "survey_path": path, "survey_path_kind": "measured" if self.last_survey else "planned",
                "gravity_grid": {"lat_deg": lat.tolist(), "lon_deg": lon.tolist(), "g_mps2": g.tolist()},
                "anomaly_grid": {"lat_deg": np.degrees(nlat).tolist(), "lon_deg": np.degrees(glon).tolist(),
                                 "anomaly_mps2": grid.tolist()}}

    def config_manifest(self) -> dict:
        return self.engine.manifest()


__all__ = ["LiveSimulation", "RingBuffer", "live_default_config", "SERIES_CHANNELS", "SWITCH_NAMES"]
