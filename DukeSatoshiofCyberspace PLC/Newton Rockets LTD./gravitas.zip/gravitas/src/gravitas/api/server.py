"""HTTP/JSON server for the engine API (stdlib ``http.server``, no extra dependencies).

See docs/API.md for the contract. All responses are JSON; non-finite floats
are converted to ``null`` (never emitted as NaN/Infinity).
"""

from __future__ import annotations

import json
import math
import re
import traceback
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlparse

import numpy as np

from gravitas.api.live import LiveSimulation
from gravitas.experiments import list_experiments, run_experiment

API_PREFIX = "/api/v1"


def sanitize(obj):
    """Recursively convert to JSON-safe types; non-finite floats → None."""
    if isinstance(obj, dict):
        return {str(k): sanitize(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [sanitize(v) for v in obj]
    if isinstance(obj, np.ndarray):
        return sanitize(obj.tolist())
    if isinstance(obj, (np.bool_, bool)):
        return bool(obj)
    if isinstance(obj, (np.integer,)):
        return int(obj)
    if isinstance(obj, (float, np.floating)):
        f = float(obj)
        return f if math.isfinite(f) else None
    return obj


def flatten_numeric(d: dict, prefix: str = "") -> dict:
    out = {}
    for k, v in d.items():
        key = f"{prefix}{k}"
        if isinstance(v, dict):
            out.update(flatten_numeric(v, key + "."))
        elif isinstance(v, (bool, np.bool_)):
            out[key] = 1.0 if v else 0.0
        elif isinstance(v, (int, float, np.integer, np.floating)):
            out[key] = float(v)
    return out


class Api:
    """Route table independent of the HTTP transport (unit-testable)."""

    def __init__(self, live: LiveSimulation):
        self.live = live

    def handle(self, method: str, path: str, query: dict, body: dict | None):
        q = {k: v[-1] for k, v in query.items()}
        live = self.live
        if not path.startswith(API_PREFIX):
            raise KeyError(path)
        p = path[len(API_PREFIX):].rstrip("/") or "/"
        b = body or {}
        if method == "GET":
            if p == "/health":
                return live.health()
            if p == "/overview":
                return live.overview()
            if p == "/series":
                return live.series(float(q.get("window_s", 60)), int(q.get("max_points", 2000)))
            if p == "/instrument":
                return live.instrument()
            if p == "/physics":
                return live.physics()
            if p == "/earth":
                return live.earth(q.get("lat_deg"), q.get("lon_deg"), q.get("alt_m"))
            if p == "/tides":
                return live.tides(float(q.get("hours", 48)), float(q.get("step_s", 600)))
            if p == "/anomalies":
                return live.anomalies()
            if p == "/calibration":
                return live.last_calibration
            if p == "/uncertainty":
                return live.uncertainty()
            if p == "/allan":
                return live.allan(int(q.get("max_points", 60)))
            if p == "/experiments":
                return {"experiments": list_experiments()}
            if p == "/map":
                return live.map()
            if p == "/telemetry":
                return live.telemetry(int(q.get("n", 50)))
            if p == "/config":
                return live.config_manifest()
            if p == "/uncertainty/monte-carlo":
                return live.last_monte_carlo
        if method == "POST":
            if p == "/physics":
                return live.set_switches(b.get("switches", {}))
            if p == "/control":
                action = b.get("action")
                if not action:
                    raise ValueError("control body needs an 'action'")
                return live.control(action, **{k: v for k, v in b.items() if k != "action"})
            if p == "/anomalies/survey":
                return live.run_survey(float(b.get("duration_s", 1800)), float(b.get("sample_rate_hz", 10)))
            if p == "/calibration/run":
                return live.run_calibration(int(b.get("seed", 7)))
            if p == "/uncertainty/monte-carlo":
                return live.run_monte_carlo(int(b.get("trials", 50)), float(b.get("duration_s", 300)))
            m = re.fullmatch(r"/experiments/([a-z_]+)", p)
            if m:
                kwargs = {}
                if "duration_s" in b:
                    kwargs["duration_s"] = float(b["duration_s"])
                if "sample_rate_hz" in b:
                    kwargs["sample_rate_hz"] = float(b["sample_rate_hz"])
                if "seed" in b:
                    kwargs["seed"] = int(b["seed"])
                res = run_experiment(m.group(1), **kwargs)
                d = res.to_dict(max_points=int(b.get("max_points", 2000)))
                d["summary"] = flatten_numeric(res.summary)
                return d
        raise KeyError(path)


def make_handler(api: Api):
    class Handler(BaseHTTPRequestHandler):
        server_version = "GRAVITAS/1.0"

        def log_message(self, fmt, *args):  # quiet by default
            pass

        def _send(self, code: int, payload) -> None:
            data = json.dumps(sanitize(payload), allow_nan=False).encode()
            self.send_response(code)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Content-Length", str(len(data)))
            self.send_header("Access-Control-Allow-Origin", "*")
            self.end_headers()
            self.wfile.write(data)

        def _dispatch(self, method: str) -> None:
            u = urlparse(self.path)
            body = None
            if method == "POST":
                n = int(self.headers.get("Content-Length") or 0)
                raw = self.rfile.read(n) if n else b""
                try:
                    body = json.loads(raw) if raw else {}
                except json.JSONDecodeError as exc:
                    self._send(400, {"error": f"invalid JSON body: {exc}"})
                    return
            try:
                self._send(200, api.handle(method, u.path, parse_qs(u.query), body))
            except KeyError as exc:
                self._send(404, {"error": f"not found: {exc}"})
            except LookupError as exc:
                self._send(503, {"error": str(exc)})
            except (ValueError, TypeError) as exc:
                self._send(400, {"error": str(exc)})
            except Exception as exc:  # pragma: no cover - defensive
                self._send(500, {"error": repr(exc), "trace": traceback.format_exc(limit=5)})

        def do_GET(self):
            self._dispatch("GET")

        def do_POST(self):
            self._dispatch("POST")

        def do_OPTIONS(self):
            self.send_response(204)
            self.send_header("Access-Control-Allow-Origin", "*")
            self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
            self.send_header("Access-Control-Allow-Headers", "Content-Type")
            self.end_headers()

    return Handler


def serve(host: str = "127.0.0.1", port: int = 8765, live: LiveSimulation | None = None, block: bool = True):
    live = live or LiveSimulation()
    live.start()
    httpd = ThreadingHTTPServer((host, port), make_handler(Api(live)))
    httpd.daemon_threads = True
    if block:
        try:
            httpd.serve_forever()
        finally:
            live.stop()
            httpd.server_close()
    return httpd, live


__all__ = ["serve", "Api", "sanitize", "flatten_numeric", "API_PREFIX"]
