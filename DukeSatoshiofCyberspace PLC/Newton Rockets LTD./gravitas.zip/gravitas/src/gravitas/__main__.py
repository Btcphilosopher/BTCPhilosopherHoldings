from gravitas.cli import main
import sys
sys.exit(main())
