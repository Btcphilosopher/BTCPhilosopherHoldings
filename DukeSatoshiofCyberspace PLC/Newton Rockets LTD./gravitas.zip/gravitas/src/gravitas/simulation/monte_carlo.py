"""Monte Carlo engine: repeated full-chain simulations with randomised inputs.

For each trial j the *true* instrument and environment are drawn from the
distributions that the analytical uncertainty budget claims:

    noise / vibration / thermal realisations   new engine seed
    bias              b_true = b̂ + N(0, u_b²) + N(0, u_ref²)
    scale factor      S_true = Ŝ (1 + N(0, u_S²))
    temperature coef. c_true = ĉ_T + N(0, u_cT²)
    temperature sensor bias  N(0, u_T²)
    drift rate        r_true = r̂ + N(0, u_r²)
    position          East/North ~ N(0, u_h²), Up ~ N(0, u_alt²)  (true vs nominal)
    tidal factor      δ_true = δ_model (1 + N(0, u_δ² + u_eph²))
    vibration         new phases and broadband realisation (via the seed)

while the *processing* (calibration coefficients, tide model, nominal
position) stays fixed — exactly the situation the analytical budget describes.
The estimate error e_j = ĝ_j − g_static(nominal) is compared with the
analytical u_j restricted to the randomised contributions.
"""

from __future__ import annotations

import math
import time
from dataclasses import dataclass, field

import numpy as np

from gravitas.earth.coordinates import enu_to_geodetic, GeodeticPosition
from gravitas.simulation.engine import SimulationEngine
from gravitas.simulation.scenario import SimulationConfig
from gravitas.uncertainty.monte_carlo import summarise


@dataclass
class MonteCarloResult:
    errors_mps2: np.ndarray
    analytic_u_mps2: np.ndarray
    full_u_mps2: np.ndarray
    draws: list[dict]
    summary: dict
    elapsed_s: float
    contributions_rms: dict = field(default_factory=dict)

    def to_dict(self, include_samples: bool = True) -> dict:
        d = dict(self.summary)
        d["elapsed_s"] = self.elapsed_s
        d["contributions_rms_mps2"] = self.contributions_rms
        if include_samples:
            d["errors_mps2"] = self.errors_mps2.tolist()
            d["analytic_u_mps2"] = self.analytic_u_mps2.tolist()
            d["draws"] = self.draws
        return d


def _trial_config(base: SimulationConfig, rng: np.random.Generator, seed: int) -> tuple[SimulationConfig, dict]:
    cal = base.calibration
    uc = base.uncertainty
    draw = {
        "seed": seed,
        "bias_mps2": cal.bias_mps2 + rng.normal(0, cal.u_bias_mps2) + rng.normal(0, cal.u_reference_mps2),
        "scale_factor": cal.scale_factor * (1.0 + rng.normal(0, cal.u_scale_factor)),
        "temperature_coefficient_mps2_per_k": cal.temperature_coefficient_mps2_per_k + rng.normal(0, cal.u_temperature_coefficient_mps2_per_k),
        "temperature_sensor_bias_k": rng.normal(0, uc.u_temperature_k),
        "drift_rate_mps2_per_s": cal.drift_rate_mps2_per_s + rng.normal(0, cal.u_drift_rate_mps2_per_s),
        "offset_east_m": rng.normal(0, uc.u_horizontal_position_m / math.sqrt(2.0)),
        "offset_north_m": rng.normal(0, uc.u_horizontal_position_m / math.sqrt(2.0)),
        "offset_up_m": rng.normal(0, uc.u_altitude_m),
        "tidal_factor": base.tides.gravimetric_factor_model * (1.0 + rng.normal(0, math.hypot(uc.u_tide_relative, uc.u_ephemeris_relative))),
    }
    origin = GeodeticPosition.from_degrees(base.location.latitude_deg, base.location.longitude_deg, base.location.altitude_m)
    lat, lon, h = enu_to_geodetic(np.array([draw["offset_east_m"], draw["offset_north_m"], draw["offset_up_m"]]), origin)
    sensor = base.sensor.model_copy(update={
        "bias_mps2": draw["bias_mps2"],
        "scale_factor_error_ppm": (draw["scale_factor"] - 1.0) * 1e6,
        "temperature_coefficient_mps2_per_k": draw["temperature_coefficient_mps2_per_k"],
        "drift_linear_mps2_per_s": draw["drift_rate_mps2_per_s"],
    })
    thermal = base.environment.thermal.model_copy(update={"sensor_bias_k": draw["temperature_sensor_bias_k"]})
    env = base.environment.model_copy(update={"thermal": thermal})
    loc = base.location.model_copy(update={"latitude_deg": float(np.degrees(lat)), "longitude_deg": float(np.degrees(lon)),
                                           "altitude_m": float(h)})
    tides = base.tides.model_copy(update={"gravimetric_factor_true": draw["tidal_factor"]})
    # keep the instrument's range setting fixed at the nominal station's value
    g_ref = SimulationEngine(base.model_copy(update={"duration_s": 1.0})).gravimeter.g_ref
    cfg = base.model_copy(update={"seed": seed, "sensor": sensor, "environment": env, "location": loc,
                                  "tides": tides, "g_ref_override_mps2": g_ref})
    return cfg, draw


def run_monte_carlo(base: SimulationConfig, trials: int = 100, mc_seed: int = 12345,
                    duration_s: float | None = None, progress=None) -> MonteCarloResult:
    if trials < 3:
        raise ValueError("Monte Carlo requires at least 3 trials")
    t0 = time.time()
    if duration_s is not None:
        base = base.model_copy(update={"duration_s": duration_s})
    nominal = SimulationEngine(base.model_copy(update={"duration_s": 1.0}))
    g_true_nominal = float(nominal._true_static_at(np.zeros((1, 3)))[0])
    ss = np.random.SeedSequence(mc_seed)
    children = ss.spawn(trials)
    errors, u_matched, u_full, draws = [], [], [], []
    contrib_sq: dict[str, float] = {}
    for j, child in enumerate(children):
        rng = np.random.default_rng(child)
        seed = int(rng.integers(0, 2**31 - 1))
        cfg, draw = _trial_config(base, rng, seed)
        # the processing chain uses the *nominal* calibration and the nominal tide model
        res = SimulationEngine(cfg).run()
        # budget evaluated with the nominal configuration (what the operator believes)
        res.config = cfg.model_copy(update={"location": base.location, "calibration": base.calibration})
        est = res.final_estimate()
        e = est.value - g_true_nominal
        errors.append(e)
        u_matched.append(est.matched_standard_uncertainty())
        u_full.append(est.standard_uncertainty)
        for c in est.contributions:
            contrib_sq[c.name] = contrib_sq.get(c.name, 0.0) + c.standard_uncertainty_mps2**2
        draw["error_mps2"] = e
        draw["analytic_u_mps2"] = u_matched[-1]
        draw["estimate_mps2"] = est.value
        draws.append(draw)
        if progress is not None:
            progress(j + 1, trials)
    errors = np.array(errors)
    u_matched = np.array(u_matched)
    summary = summarise(errors, u_matched, base.uncertainty.coverage_factor)
    summary["analytical_full_std_mps2"] = float(math.sqrt(np.mean(np.array(u_full) ** 2)))
    summary["true_static_gravity_mps2"] = g_true_nominal
    return MonteCarloResult(errors, u_matched, np.array(u_full), draws, summary, time.time() - t0,
                            {k: math.sqrt(v / trials) for k, v in contrib_sq.items()})


__all__ = ["MonteCarloResult", "run_monte_carlo"]
