"""The GRAVITAS simulation engine: the complete measurement chain.

    EARTH → TRUE GRAVITY → ENVIRONMENT → INSTRUMENT → SENSOR → ADC → RAW
          → FILTER → CALIBRATION → CORRECTION → GRAVITY ESTIMATOR
          → UNCERTAINTY → FINAL MEASUREMENT

The engine is *stateful and chunked*: :meth:`SimulationEngine.step` advances
the twin by ``n`` output samples, carrying every internal state (proof-mass
dynamics, filter memories, random streams, thermal node, drift walk, Kalman
state). Running in chunks of any size yields bit-identical results to a single
run (tested in tests/test_reproducibility.py).

Random streams
    One ``numpy.random.SeedSequence(seed)`` is spawned into named,
    independent streams in a fixed order (:data:`RNG_STREAMS`). Each stream
    draws a fixed number of variates per sample regardless of physics
    switches, so toggling an effect never perturbs the other noise
    realisations.

Composition of the specific force on the sensitive axis (per sample)
    a_axis   = g_true(t) − δg_Eötvös(t) − g θ²/2 + a_vib,U + leak(a_vib,E, a_vib,N)
    a_in     = g_ref + S(T) · (a_axis − g_ref) + b₀ + c_T (T_i − T_ref) + d(t) + n_corr + n_white
    The proof mass responds to a_in; the readout/ADC produce g_raw.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from datetime import timezone

import numpy as np

from gravitas import SOFTWARE_VERSION
from gravitas.earth.coordinates import GeodeticPosition, enu_to_geodetic, meridian_radius, prime_vertical_radius
from gravitas.earth.ellipsoid import WGS84
from gravitas.earth.gravity import EarthGravityModel, EarthModelSwitches
from gravitas.earth.normal_gravity import normal_gravity_free_air, somigliana
from gravitas.earth.tides import TideModel
from gravitas.estimation.calibration import CalibrationParameters
from gravitas.estimation.filtering import FilterConfig, StreamingFilter
from gravitas.estimation.gravity_estimator import EstimatorConfig, GravityEstimator
from gravitas.instrument.adc import ADC
from gravitas.instrument.feedback import FeedbackController
from gravitas.instrument.gravimeter import Gravimeter, GravimeterConfig
from gravitas.instrument.interferometer import Interferometer
from gravitas.instrument.optical_readout import LinearTransducer, OpticalReadout
from gravitas.instrument.proof_mass import ProofMass
from gravitas.instrument.spring import Spring
from gravitas.instrument.thermal import ThermalConfig, ThermalModel
from gravitas.physics.anomalies import AnomalyField, body_from_dict
from gravitas.physics.centrifugal import eotvos_correction
from gravitas.sensors.bias import ConstantBias, TemperatureBias
from gravitas.sensors.cross_axis import CrossAxisConfig, CrossAxisModel
from gravitas.sensors.drift import DriftConfig, DriftModel
from gravitas.sensors.noise import GaussMarkovEnsemble, NoiseConfig, WhiteNoise
from gravitas.sensors.scale_factor import ScaleFactor
from gravitas.sensors.vibration import VibrationConfig, VibrationLine, VibrationModel
from gravitas.simulation.clock import SimulationClock
from gravitas.simulation.scenario import SimulationConfig
from gravitas.simulation.state import ChainChunk, concatenate_chunks

RNG_STREAMS = ("white_noise", "correlated_noise", "drift_walk", "vibration", "thermal_walk", "thermal_sensor",
               "readout_1", "readout_2", "spare_1", "spare_2")

STATUS_STABLE = "STABLE"
STATUS_SETTLING = "SETTLING"
STATUS_SATURATED = "SATURATED"
STATUS_UNLOCKED = "UNLOCKED"


@dataclass
class SimulationResult:
    config: SimulationConfig
    chain: ChainChunk
    manifest: dict
    status_log: list[dict] = field(default_factory=list)

    @property
    def t_s(self) -> np.ndarray:
        return self.chain.t_s

    def __getitem__(self, key: str) -> np.ndarray:
        return self.chain.channels[key]

    def to_xarray(self):
        import xarray as xr

        data_vars = {k.replace(".", "__"): ("time", v) for k, v in self.chain.channels.items()}
        for k, v in self.chain.flags.items():
            data_vars["flag__" + k] = ("time", v.astype(np.int8))
        ds = xr.Dataset(data_vars, coords={"time": self.chain.t_s})
        ds.attrs["manifest_json"] = __import__("json").dumps(self.manifest, default=str)
        return ds

    def final_estimate(self):
        from gravitas.uncertainty.budget import compute_budget

        return compute_budget(self)


class SimulationEngine:
    """Stateful digital twin. Construct, then :meth:`step` or :meth:`run`."""

    def __init__(self, config: SimulationConfig):
        self.config = config
        self.reset()

    # ------------------------------------------------------------------ setup
    def reset(self, seed: int | None = None) -> None:
        if seed is not None:
            self.config = self.config.model_copy(update={"seed": int(seed)})
        cfg = self.config
        self.clock = SimulationClock(cfg.start_epoch, cfg.sample_rate_hz)
        ss = np.random.SeedSequence(cfg.seed)
        self.rngs = {name: np.random.default_rng(child) for name, child in zip(RNG_STREAMS, ss.spawn(len(RNG_STREAMS)))}
        # location.altitude_m is an orthometric height; the ellipsoidal height is H + N
        self.origin = GeodeticPosition.from_degrees(cfg.location.latitude_deg, cfg.location.longitude_deg,
                                                    cfg.location.altitude_m + cfg.earth.geoid_undulation_m)
        self._build_models()
        self._static_cache: dict | None = None
        self.status_log: list[dict] = []
        self.chunks_produced = 0

    def _earth_switches(self) -> EarthModelSwitches:
        p = self.config.physics
        return EarthModelSwitches(earth_gravity=p.earth_gravity, earth_oblateness=p.earth_oblateness,
                                  earth_rotation=p.earth_rotation, altitude=p.altitude, latitude=p.latitude,
                                  reference_latitude_deg=p.reference_latitude_deg)

    def _build_models(self) -> None:
        cfg = self.config
        p = cfg.physics
        self.earth = EarthGravityModel(WGS84, cfg.earth.n_zonal, self._earth_switches())
        self.tide_truth = TideModel(include_moon=p.moon, include_sun=p.sun,
                                    gravimetric_factor=cfg.tides.gravimetric_factor_true)
        self.tide_correction = TideModel(include_moon=cfg.tides.correction_moon, include_sun=cfg.tides.correction_sun,
                                         gravimetric_factor=cfg.tides.gravimetric_factor_model)
        self.anomalies = AnomalyField([body_from_dict({"kind": b.kind, **b.params, **({"description": b.description} if b.description else {})})
                                       for b in cfg.anomalies])
        ic = cfg.instrument
        # Internal rate must resolve the vibration band (avoid simulation aliasing)
        vib_fmax = max([ln.frequency_hz for ln in cfg.environment.vibration.lines] + [cfg.environment.vibration.band_hz[1]])
        oversample = max(ic.oversample, int(math.ceil(2.5 * vib_fmax / cfg.sample_rate_hz)))
        self.oversample = oversample
        gcfg = GravimeterConfig(
            mode=ic.mode,
            proof_mass=ProofMass(ic.proof_mass_kg, ic.stop_m),
            spring=Spring(ic.natural_frequency_hz, ic.damping_ratio),
            feedback=FeedbackController(enabled=ic.mode == "feedback", bandwidth_hz=ic.feedback_bandwidth_hz,
                                        integral_time_s=ic.feedback_integral_time_s,
                                        max_force_n=ic.feedback_max_force_n, dac_bits=ic.dac_bits),
            optical=OpticalReadout(enabled=ic.optical_enabled,
                                   interferometer=Interferometer(ic.wavelength_m, 1.0, math.pi / 4, ic.visibility, ic.peak_voltage_v),
                                   photodetector_noise_v=ic.photodetector_noise_v, readout_noise_v=ic.readout_noise_v,
                                   displacement_bias_m=ic.displacement_bias_m,
                                   adc=ADC(ic.adc_bits, ic.adc_v_min, ic.adc_v_max)),
            transducer=LinearTransducer(gain_v_per_m=ic.transducer_gain_v_per_m, noise_v=ic.transducer_noise_v,
                                        displacement_bias_m=ic.displacement_bias_m,
                                        adc=ADC(max(ic.adc_bits, 16), -10.0, 10.0)),
            oversample=oversample,
            range_resolution_mps2=ic.range_resolution_mps2,
        )
        # Coarse range adjustment ("nulling") at the start location using the
        # *instrument's own* first reading model: the operator turns the range
        # screw until the beam is near centre. Resolution = 1 mGal by default.
        g_start = self._true_static_at(np.zeros((1, 3)))[0]
        if cfg.g_ref_override_mps2 is not None:
            g_ref = cfg.g_ref_override_mps2
        else:
            g_ref = Gravimeter.range_adjust(g_start if g_start > 1.0 else 9.80665, ic.range_resolution_mps2)
        self.gravimeter = Gravimeter(gcfg, cfg.sample_rate_hz, g_ref)
        sc = cfg.sensor
        self.bias0 = ConstantBias(sc.bias_mps2)
        self.temp_bias = TemperatureBias(sc.temperature_coefficient_mps2_per_k, sc.reference_temperature_c)
        self.scale = ScaleFactor(sc.scale_factor_error_ppm, sc.scale_factor_tc_ppm_per_k, sc.reference_temperature_c)
        self.drift = DriftModel(DriftConfig(sc.drift_linear_mps2_per_s, sc.drift_quadratic_mps2_per_s2,
                                            sc.drift_settling_amplitude_mps2, sc.drift_settling_tau_s,
                                            sc.drift_random_walk_mps2_per_rts), self.rngs["drift_walk"])
        fs_int = cfg.sample_rate_hz * oversample
        self.white = WhiteNoise(sc.white_asd_mps2_per_rthz, fs_int, self.rngs["white_noise"])
        self.corr = GaussMarkovEnsemble(NoiseConfig(sc.white_asd_mps2_per_rthz, sc.correlated_sigma_mps2,
                                                    sc.correlated_tau_min_s, max(sc.correlated_tau_max_s, sc.correlated_tau_min_s),
                                                    sc.correlated_components), 1.0 / cfg.sample_rate_hz,
                                        self.rngs["correlated_noise"])
        self.cross = CrossAxisModel(CrossAxisConfig(sc.cross_coupling_east, sc.cross_coupling_north,
                                                    sc.tilt_east_rad, sc.tilt_north_rad))
        th = cfg.environment.thermal
        self.thermal = ThermalModel(ThermalConfig(th.ambient_mean_c, th.diurnal_amplitude_k, th.diurnal_phase_rad,
                                                  th.ambient_random_walk_k_per_rts, th.set_point_c,
                                                  th.thermostat_leakage, th.time_constant_s, th.sensor_noise_k,
                                                  th.sensor_bias_k),
                                    self.rngs["thermal_walk"], self.rngs["thermal_sensor"], enabled=p_enabled(cfg, "temperature"))
        vs = cfg.environment.vibration
        self.vibration = VibrationModel(VibrationConfig([VibrationLine(l.frequency_hz, l.amplitude_mps2, l.axis) for l in vs.lines],
                                                        tuple(vs.broadband_rms_mps2), tuple(vs.band_hz), vs.scale),
                                        fs_int, self.rngs["vibration"], enabled=cfg.physics.vibration)
        self.calibration = CalibrationParameters(**cfg.calibration.model_dump())
        sigma_meas = max(sc.white_asd_mps2_per_rthz * math.sqrt(cfg.sample_rate_hz / 2.0), 1e-12)
        self.filter = StreamingFilter(FilterConfig(**cfg.filter.model_dump()), cfg.sample_rate_hz, sigma_meas)
        est = cfg.estimator
        self.estimator = GravityEstimator(EstimatorConfig(est.estimate_drift, est.estimate_tidal_admittance,
                                                          est.process_noise_gravity_mps2_per_rts, 0.0, 1e-3,
                                                          est.noise_prior_mps2, est.min_interval_s, cfg.settle_time_s),
                                          cfg.sample_rate_hz, self.filter.independent_sample_interval_s)

    def apply_physics_switches(self, **switches: bool) -> None:
        """Change physics switches *without* resetting state (live inspector)."""
        updated = self.config.physics.model_copy(update=switches)
        self.config = self.config.model_copy(update={"physics": updated})
        self.earth.switches = self._earth_switches()
        self.tide_truth.include_moon = updated.moon
        self.tide_truth.include_sun = updated.sun
        self.thermal.enabled = updated.temperature
        self.vibration.enabled = updated.vibration
        self._static_cache = None

    def set_mode(self, mode: str) -> None:
        self.gravimeter.set_mode(mode)
        self.config = self.config.model_copy(update={"instrument": self.config.instrument.model_copy(update={"mode": mode})})

    # ------------------------------------------------------------- geometry
    def _trajectory(self, t_s: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
        """(ENU positions (N,3), ENU velocities (N,3)) at times t_s."""
        tr = self.config.trajectory
        n = t_s.size
        if tr.kind == "static":
            return np.zeros((n, 3)), np.zeros((n, 3))
        wt = np.array([w.t_s for w in tr.waypoints])
        wp = np.array([[w.east_m, w.north_m, w.up_m] for w in tr.waypoints])
        pos = np.column_stack([np.interp(t_s, wt, wp[:, i]) for i in range(3)])
        seg = np.clip(np.searchsorted(wt, t_s, side="right") - 1, 0, len(wt) - 2)
        vel = (wp[seg + 1] - wp[seg]) / (wt[seg + 1] - wt[seg])[:, None]
        vel[(t_s < wt[0]) | (t_s >= wt[-1])] = 0.0
        return pos, vel

    def _geodetic(self, enu: np.ndarray):
        if np.all(enu == 0.0):
            n = enu.shape[0]
            return (np.full(n, self.origin.latitude_rad), np.full(n, self.origin.longitude_rad),
                    np.full(n, self.origin.height_m))
        lat, lon, h = enu_to_geodetic(enu, self.origin)
        return lat, lon, h

    def _true_static_at(self, enu: np.ndarray) -> np.ndarray:
        """Earth + anomaly gravity (no tides) at ENU points — the 'static truth'."""
        lat, lon, h = self._geodetic(enu)
        g = self.earth.magnitude(lat, lon, h)
        if self.config.physics.local_anomaly and len(self.anomalies):
            g = g + self.anomalies.delta_g(enu)
        return g

    # ---------------------------------------------------------------- step
    def step(self, n: int) -> ChainChunk:
        """Advance the twin by ``n`` output samples and return every stage."""
        if n <= 0:
            raise ValueError("n must be positive")
        cfg = self.config
        fs = cfg.sample_rate_hz
        os_ = self.oversample
        dt = 1.0 / fs
        t = self.clock.times(n)
        jd = self.clock.julian_dates(t)
        ch: dict[str, np.ndarray] = {}

        # ---------------- EARTH / POSITION --------------------------------
        enu, vel = self._trajectory(t)
        lat, lon, h = self._geodetic(enu)
        static_traj = cfg.trajectory.kind == "static"
        if static_traj:
            if self._static_cache is None:
                comp = self.earth.components(lat[:1], lon[:1], h[:1])
                self._static_cache = {k: float(v[0]) for k, v in comp.items()}
            comp = {k: np.full(n, v) for k, v in self._static_cache.items()}
        else:
            comp = self.earth.components(lat, lon, h)
        g_earth = comp["effective_mps2"]
        ch["earth.newtonian_mps2"] = comp["newtonian_mps2"]
        ch["earth.centrifugal_mps2"] = comp["centrifugal_mps2"]
        ch["earth.centrifugal_vertical_mps2"] = comp["centrifugal_vertical_mps2"]
        ch["earth.effective_mps2"] = g_earth
        ch["position.latitude_deg"] = np.degrees(lat)
        ch["position.longitude_deg"] = np.degrees(lon)
        ch["position.altitude_m"] = np.asarray(h, dtype=float)
        ch["position.east_m"] = enu[:, 0]
        ch["position.north_m"] = enu[:, 1]
        ch["position.up_m"] = enu[:, 2]

        # ---------------- TIDES (computed on a coarse grid, linearly interpolated) --
        # The grid is aligned to the *global* sample index so that the interpolated
        # values do not depend on how the run is chunked.
        step = max(1, int(round(cfg.tides.grid_step_s * fs)))
        i0 = self.clock.index
        g_idx = np.arange((i0 // step) * step, i0 + n - 1 + step + 1, step)
        g_t = g_idx / fs
        g_jd = self.clock.julian_dates(g_t)
        if static_traj:
            g_lat, g_lon, g_h = (np.full(g_idx.size, v[0]) for v in (lat, lon, h))
        else:
            g_enu, _ = self._trajectory(g_t)
            g_lat, g_lon, g_h = self._geodetic(g_enu)
        loc_idx = i0 + np.arange(n)
        tide_t = self.tide_truth.compute(g_jd, g_lat, g_lon, g_h)
        lunar = np.interp(loc_idx, g_idx, tide_t.lunar_mps2)
        solar = np.interp(loc_idx, g_idx, tide_t.solar_mps2)
        ch["tide.lunar_mps2"] = lunar
        ch["tide.solar_mps2"] = solar
        ch["tide.combined_mps2"] = lunar + solar

        # ---------------- ANOMALY -------------------------------------------
        if cfg.physics.local_anomaly and len(self.anomalies):
            anom = self.anomalies.delta_g(enu) if not static_traj else np.full(n, self.anomalies.delta_g(enu[:1])[0])
        else:
            anom = np.zeros(n)
        ch["anomaly.delta_g_mps2"] = anom

        # ---------------- TRUE GRAVITY ----------------------------------------
        static_true = g_earth + anom
        true_total = static_true + lunar + solar
        ch["truth.static_gravity_mps2"] = static_true
        ch["truth.gravity_mps2"] = true_total

        # ---------------- ENVIRONMENT ------------------------------------------
        sp_sched = cfg.environment.thermal.set_point_schedule
        if sp_sched:
            ts_, vs_ = zip(*sorted(sp_sched))
            # piecewise-constant set point schedule
            k = np.clip(np.searchsorted(np.array(ts_), t, side="right") - 1, 0, len(ts_) - 1)
            set_points = np.where(t >= ts_[0], np.array(vs_)[k], cfg.environment.thermal.set_point_c)
            self.thermal.cfg.set_point_c = float(set_points[-1])
            th = self._thermal_with_schedule(t, dt, set_points)
        else:
            th = self.thermal.step(t, dt)
        ch["environment.ambient_temperature_c"] = th["ambient_c"]
        ch["environment.instrument_temperature_c"] = th["instrument_c"]
        ch["environment.measured_temperature_c"] = th["measured_c"]
        if static_traj:
            eot = np.zeros(n)
        else:
            # Eötvös: rotation part 2ω v_E cos φ (absent if Earth rotation is switched off) + curvature v²/R
            r_earth = prime_vertical_radius(lat) + h
            omega = WGS84.omega if cfg.physics.earth_rotation else 0.0
            eot = eotvos_correction(lat, vel[:, 0], vel[:, 1], omega, r_earth)
        ch["environment.eotvos_mps2"] = eot
        t_int = (self.clock.index * os_ + np.arange(n * os_)) / (fs * os_)
        vib = self.vibration.step(t_int)  # (n*os, 3) ENU
        vib_blocks = vib.reshape(n, os_, 3)
        ch["environment.vibration_up_mps2"] = vib_blocks[:, :, 2].mean(axis=1)
        ch["environment.vibration_up_rms_mps2"] = np.sqrt((vib_blocks[:, :, 2] ** 2).mean(axis=1))
        ch["environment.vibration_east_mps2"] = vib_blocks[:, :, 0].mean(axis=1)
        ch["environment.vibration_north_mps2"] = vib_blocks[:, :, 1].mean(axis=1)

        # ---------------- SENSOR (equivalent-input error terms) --------------
        T_i = th["instrument_c"]
        bias_on = cfg.physics.sensor_bias
        noise_on = cfg.physics.sensor_noise
        b0 = self.bias0.evaluate(n) if bias_on else np.zeros(n)
        bT = self.temp_bias.evaluate(T_i)
        dr = self.drift.step(t, dt)
        drift = dr["total_mps2"] if bias_on else np.zeros(n)
        corr = self.corr.step(n)
        corr = corr if noise_on else np.zeros(n)
        white_int = self.white.step(n * os_)
        white_int = white_int if noise_on else np.zeros_like(white_int)
        S = np.asarray(self.scale.factor(T_i), dtype=float) * np.ones(n)
        ch["sensor.bias_constant_mps2"] = b0
        ch["sensor.bias_temperature_mps2"] = bT
        ch["sensor.drift_mps2"] = drift
        ch["sensor.correlated_noise_mps2"] = corr
        ch["sensor.white_noise_mps2"] = white_int.reshape(n, os_).mean(axis=1)
        ch["sensor.scale_factor"] = S
        ch["sensor.total_bias_mps2"] = b0 + bT + drift

        # ---------------- SPECIFIC FORCE ON THE AXIS ---------------------------
        g_ref = self.gravimeter.g_ref
        tilt = self.cross.tilt_term(true_total)
        leak_int = self.cross.leakage(vib[:, 0], vib[:, 1])
        slow_axis = true_total - eot + tilt
        a_axis_int = np.repeat(slow_axis, os_) + vib[:, 2] + leak_int
        slow_bias = b0 + bT + drift + corr
        a_in_int = (g_ref + np.repeat(S, os_) * (a_axis_int - g_ref) + np.repeat(slow_bias, os_) + white_int)
        ch["sensor.cross_axis_mps2"] = leak_int.reshape(n, os_).mean(axis=1) + tilt
        ch["instrument.input_acceleration_mps2"] = a_in_int.reshape(n, os_).mean(axis=1)

        # ---------------- INSTRUMENT + READOUT + ADC --------------------------------
        if self.clock.index == 0:
            # the instrument has been standing at the station: start at static equilibrium
            # (use the slow part of the input: the block mean over the first output sample)
            self.gravimeter.initialise_equilibrium(float(a_in_int[:os_].mean()))
        s1, s2 = self.gravimeter.readout_noise_sigmas()
        nz1 = self.rngs["readout_1"].standard_normal(n * os_) * s1
        nz2 = self.rngs["readout_2"].standard_normal(n * os_) * s2
        out = self.gravimeter.run(a_in_int, nz1, nz2)
        ch["instrument.proof_mass_position_m"] = out.position_m
        ch["instrument.proof_mass_velocity_mps"] = out.velocity_mps
        ch["instrument.measured_position_m"] = out.measured_position_m
        ch["instrument.feedback_force_n"] = out.feedback_force_n
        ch["instrument.spring_force_n"] = out.spring_force_n
        ch["instrument.gravity_force_n"] = out.gravity_force_n
        ch["instrument.optical_phase_rad"] = out.phase_rad
        ch["adc.channel1_v"] = out.channel1_v
        ch["adc.channel2_v"] = out.channel2_v
        ch["adc.code1"] = out.code1
        ch["adc.code2"] = out.code2
        raw = out.raw_gravity_mps2
        ch["raw.gravity_mps2"] = raw
        flags = {"adc_saturated": out.adc_saturation_count > 0, "fringe_loss": out.fringe_loss_count > 0,
                 "stop_contact": out.stop_contact_count > 0}

        # ---------------- FILTER (deviation domain) -----------------------------------
        raw_dev = raw - g_ref
        filt_dev = self.filter.process(raw_dev)
        ch["filter.gravity_mps2"] = filt_dev + g_ref

        # ---------------- CALIBRATION ---------------------------------------------------
        T_m = th["measured_c"]
        cal_dev = self.calibration.apply(filt_dev, T_m, t)
        ch["calibration.gravity_mps2"] = cal_dev + g_ref

        # ---------------- CORRECTION ------------------------------------------------------
        if cfg.tides.apply_correction:
            tc = self.tide_correction.compute(g_jd, g_lat, g_lon, g_h)
            tide_corr = np.interp(loc_idx, g_idx, tc.combined_mps2)
        else:
            tide_corr = np.zeros(n)
        eot_corr = eot  # operator knows the platform velocity (GNSS) ⇒ applies Eötvös correction
        corr_dev = cal_dev - tide_corr + eot_corr
        ch["correction.tide_model_mps2"] = tide_corr
        ch["correction.eotvos_mps2"] = eot_corr
        ch["correction.gravity_mps2"] = corr_dev + g_ref

        # ---------------- ESTIMATOR --------------------------------------------------------
        est = self.estimator.process(t, corr_dev, tide_corr)
        ch["estimate.gravity_mps2"] = est["estimate_dev_mps2"] + g_ref
        ch["estimate.sigma_mps2"] = est["sigma_mps2"]
        ch["estimate.drift_rate_mps2_per_s"] = est["drift_rate"]
        ch["estimate.tidal_admittance"] = est["tidal_admittance"]
        ch["instrument.reference_gravity_mps2"] = np.full(n, g_ref)

        # ---------------- STATUS ---------------------------------------------------------------
        chunk = ChainChunk(t, ch, flags)
        self._log_status(chunk)
        self.clock.advance(n)
        self.chunks_produced += 1
        return chunk

    def _thermal_with_schedule(self, t, dt, set_points):
        """Thermal step with a piecewise-constant set point (thermal-chamber calibration)."""
        out = {"ambient_c": np.empty(t.size), "instrument_c": np.empty(t.size), "measured_c": np.empty(t.size)}
        # process in runs of constant set point to reuse the exact discretisation
        start = 0
        while start < t.size:
            end = start + 1
            while end < t.size and set_points[end] == set_points[start]:
                end += 1
            self.thermal.cfg.set_point_c = float(set_points[start])
            r = self.thermal.step(t[start:end], dt)
            for k in out:
                out[k][start:end] = r[k]
            start = end
        return out

    def status_for(self, chunk: ChainChunk) -> tuple[str, list[str]]:
        reasons: list[str] = []
        status = STATUS_STABLE
        if chunk.flags["stop_contact"].any() or chunk.flags["adc_saturated"].any():
            status = STATUS_SATURATED
            if chunk.flags["stop_contact"].any():
                reasons.append("proof mass on mechanical stop (input outside dynamic range)")
            if chunk.flags["adc_saturated"].any():
                reasons.append("ADC input outside conversion range")
        elif chunk.flags["fringe_loss"].any():
            status = STATUS_UNLOCKED
            reasons.append("interferometer fringe count lost (phase step > π)")
        elif float(chunk.t_s[-1]) < self.config.settle_time_s:
            status = STATUS_SETTLING
            reasons.append(f"settling (t < {self.config.settle_time_s:.0f} s)")
        vib_rms = float(np.sqrt(np.mean(chunk["environment.vibration_up_rms_mps2"] ** 2)))
        if vib_rms > 1e-4:
            reasons.append(f"high platform vibration ({vib_rms:.2e} m/s² RMS)")
        return status, reasons

    def _log_status(self, chunk: ChainChunk) -> None:
        status, reasons = self.status_for(chunk)
        self.status_log.append({"t_start_s": float(chunk.t_s[0]), "t_end_s": float(chunk.t_s[-1]),
                                "status": status, "reasons": reasons})

    # ------------------------------------------------------------------ run
    def run(self, duration_s: float | None = None) -> SimulationResult:
        cfg = self.config
        total = int(round((duration_s if duration_s is not None else cfg.duration_s) * cfg.sample_rate_hz))
        if total <= 0:
            raise ValueError("duration too short for the sample rate")
        chunk_n = max(1, int(round(cfg.chunk_s * cfg.sample_rate_hz)))
        chunks = []
        done = 0
        while done < total:
            k = min(chunk_n, total - done)
            chunks.append(self.step(k))
            done += k
        chain = concatenate_chunks(chunks)
        return SimulationResult(cfg, chain, self.manifest(), list(self.status_log))

    # -------------------------------------------------------------- manifest
    def manifest(self) -> dict:
        cfg = self.config
        return {
            "software": {"name": "GRAVITAS", "version": SOFTWARE_VERSION},
            "random_seed": cfg.seed,
            "rng": {"generator": "PCG64", "streams": list(RNG_STREAMS)},
            "simulation_timestep_s": 1.0 / cfg.sample_rate_hz,
            "internal_timestep_s": self.gravimeter.dt_internal,
            "oversample": self.oversample,
            "simulation_duration_s": cfg.duration_s,
            "start_epoch": cfg.start_epoch.astimezone(timezone.utc).isoformat(),
            "earth_model": self.earth.describe(),
            "tide_model_truth": self.tide_truth.describe(),
            "tide_model_correction": self.tide_correction.describe(),
            "anomaly_model": {"label": AnomalyField.label, "bodies": self.anomalies.describe()},
            "instrument_model": self.gravimeter.describe(),
            "sensor_model": cfg.sensor.model_dump(),
            "calibration_parameters": self.calibration.to_dict(),
            "filter": self.filter.describe(),
            "estimator": self.estimator.describe(),
            "location": cfg.location.model_dump(),
            "trajectory": cfg.trajectory.model_dump(),
            "environment": cfg.environment.model_dump(mode="json"),
            "physics_switches": cfg.physics.model_dump(),
            "uncertainty_settings": cfg.uncertainty.model_dump(),
            "config_hash_sha256": cfg.config_hash(),
            "config": cfg.model_dump(mode="json"),
        }


def p_enabled(cfg: SimulationConfig, name: str) -> bool:
    return bool(getattr(cfg.physics, name))


def reference_values(cfg: SimulationConfig) -> dict:
    """Closed-form reference values at the configured location (for validation)."""
    lat = math.radians(cfg.location.latitude_deg)
    return {"somigliana_mps2": float(somigliana(lat)),
            "somigliana_free_air_mps2": float(normal_gravity_free_air(lat, cfg.location.altitude_m)),
            "meridian_radius_m": float(meridian_radius(lat))}


__all__ = ["SimulationEngine", "SimulationResult", "RNG_STREAMS", "reference_values",
           "STATUS_STABLE", "STATUS_SETTLING", "STATUS_SATURATED", "STATUS_UNLOCKED"]
