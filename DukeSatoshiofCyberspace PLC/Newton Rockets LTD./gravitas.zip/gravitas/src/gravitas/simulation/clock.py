"""Simulation clock: integer sample counter → time, epoch and Julian date.

Time is derived from an integer sample index, never accumulated by repeated
floating-point addition, so there is no clock drift over long runs:

    t_k = k / f_s                       [s since start]
    JD_k = JD₀ + t_k / 86400            [d]
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timedelta, timezone

import numpy as np

from gravitas.constants.physical import SECONDS_PER_DAY
from gravitas.earth.rotation import datetime_to_julian_date


@dataclass
class SimulationClock:
    start_epoch: datetime
    sample_rate_hz: float
    index: int = 0

    def __post_init__(self) -> None:
        if self.start_epoch.tzinfo is None:
            raise ValueError("start epoch must be timezone-aware")
        if self.sample_rate_hz <= 0:
            raise ValueError("sample rate must be positive")
        self.jd0 = datetime_to_julian_date(self.start_epoch)

    @property
    def dt(self) -> float:
        return 1.0 / self.sample_rate_hz

    @property
    def time_s(self) -> float:
        return self.index / self.sample_rate_hz

    def times(self, n: int, start_index: int | None = None) -> np.ndarray:
        i0 = self.index if start_index is None else start_index
        return (i0 + np.arange(n, dtype=np.int64)) / self.sample_rate_hz

    def julian_dates(self, t_s: np.ndarray) -> np.ndarray:
        return self.jd0 + np.asarray(t_s, dtype=float) / SECONDS_PER_DAY

    def epoch_at(self, t_s: float) -> datetime:
        return (self.start_epoch + timedelta(seconds=float(t_s))).astimezone(timezone.utc)

    def iso(self, t_s: float) -> str:
        return self.epoch_at(t_s).strftime("%Y-%m-%dT%H:%M:%S.%fZ")

    def advance(self, n: int) -> None:
        self.index += int(n)

    def reset(self) -> None:
        self.index = 0


__all__ = ["SimulationClock"]
