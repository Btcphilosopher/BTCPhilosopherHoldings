"""Inspectable per-stage state of the measurement chain.

Every chunk produced by the engine is a :class:`ChainChunk`: a mapping from
*stage-qualified* channel names to arrays sampled at the output rate. The
stage prefixes follow the measurement chain exactly::

    earth.*        Earth field (Newtonian, centrifugal, effective)
    tide.*         lunar, solar, combined tidal gravity
    anomaly.*      synthetic anomaly contribution
    truth.*        true gravity (static and total)
    environment.*  temperature, platform vibration, Eötvös
    sensor.*       injected bias / drift / temperature bias / noise / scale
    instrument.*   proof-mass and actuator states
    adc.*          converter codes and flags
    raw.*          raw measurement
    filter.*       filtered measurement
    calibration.*  calibrated measurement
    correction.*   tide / Eötvös corrections and corrected measurement
    estimate.*     gravity estimator output and its σ
    position.*     geodetic position of the instrument

Units are always the suffix of the channel name.
"""

from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np

STAGES = ("earth", "tide", "anomaly", "truth", "environment", "sensor", "instrument", "adc", "raw", "filter",
          "calibration", "correction", "estimate", "position")


@dataclass
class ChainChunk:
    t_s: np.ndarray
    channels: dict[str, np.ndarray] = field(default_factory=dict)
    flags: dict[str, np.ndarray] = field(default_factory=dict)

    def __getitem__(self, key: str) -> np.ndarray:
        return self.channels[key]

    def __contains__(self, key: str) -> bool:
        return key in self.channels

    def stage(self, name: str) -> dict[str, np.ndarray]:
        if name not in STAGES:
            raise KeyError(f"unknown stage {name!r}")
        pre = name + "."
        return {k[len(pre):]: v for k, v in self.channels.items() if k.startswith(pre)}

    @property
    def n(self) -> int:
        return int(self.t_s.size)


def concatenate_chunks(chunks: list[ChainChunk]) -> ChainChunk:
    if not chunks:
        raise ValueError("no chunks to concatenate")
    keys = chunks[0].channels.keys()
    fkeys = chunks[0].flags.keys()
    return ChainChunk(
        t_s=np.concatenate([c.t_s for c in chunks]),
        channels={k: np.concatenate([c.channels[k] for c in chunks]) for k in keys},
        flags={k: np.concatenate([c.flags[k] for c in chunks]) for k in fkeys},
    )


__all__ = ["ChainChunk", "concatenate_chunks", "STAGES"]
