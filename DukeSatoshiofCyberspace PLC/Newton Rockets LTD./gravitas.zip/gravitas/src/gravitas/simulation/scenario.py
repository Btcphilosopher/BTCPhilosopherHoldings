"""Simulation configuration (strict, validated, serialisable).

Every quantity that influences a simulation lives here; the manifest written
with every run is derived from this model, which makes runs reproducible:
identical configuration + identical seed ⇒ bit-identical output.

Unknown keys are rejected (``extra="forbid"``): a misspelt parameter can never
be silently ignored.
"""

from __future__ import annotations

import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Literal, Optional

from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator

from gravitas.earth.coordinates import validate_geodetic


class _Strict(BaseModel):
    model_config = ConfigDict(extra="forbid", validate_assignment=True)


class LocationConfig(_Strict):
    latitude_deg: float = 53.38
    longitude_deg: float = -1.47
    altitude_m: float = 100.0

    @model_validator(mode="after")
    def _validate(self) -> "LocationConfig":
        validate_geodetic(self.latitude_deg, self.longitude_deg, self.altitude_m)
        return self


class Waypoint(_Strict):
    t_s: float = Field(ge=0.0)
    east_m: float = 0.0
    north_m: float = 0.0
    up_m: float = 0.0


class TrajectoryConfig(_Strict):
    """Instrument path in the local ENU frame of ``location`` (linear between waypoints)."""

    kind: Literal["static", "waypoints"] = "static"
    waypoints: list[Waypoint] = Field(default_factory=list)

    @model_validator(mode="after")
    def _validate(self) -> "TrajectoryConfig":
        if self.kind == "waypoints":
            if len(self.waypoints) < 2:
                raise ValueError("waypoint trajectory needs at least two waypoints")
            ts = [w.t_s for w in self.waypoints]
            if any(b <= a for a, b in zip(ts, ts[1:])):
                raise ValueError("waypoint times must be strictly increasing")
        return self


class PhysicsSwitches(_Strict):
    earth_gravity: bool = True
    earth_oblateness: bool = True
    earth_rotation: bool = True
    altitude: bool = True
    latitude: bool = True
    moon: bool = True
    sun: bool = True
    local_anomaly: bool = True
    temperature: bool = True
    vibration: bool = True
    sensor_bias: bool = True
    sensor_noise: bool = True
    reference_latitude_deg: float = Field(45.0, ge=-90.0, le=90.0)


class EarthConfig(_Strict):
    ellipsoid: Literal["WGS84"] = "WGS84"
    n_zonal: int = Field(5, ge=1, le=10)
    geoid_undulation_m: float = Field(0.0, ge=-200.0, le=200.0)


class TideConfig(_Strict):
    gravimetric_factor_true: float = Field(1.1563, gt=0.5, lt=2.0)
    gravimetric_factor_model: float = Field(1.16, gt=0.5, lt=2.0)
    apply_correction: bool = True
    correction_moon: bool = True
    correction_sun: bool = True
    grid_step_s: float = Field(1.0, gt=0.0, le=600.0)


class AnomalyBodyConfig(_Strict):
    kind: Literal["point_mass", "sphere", "slab", "layer", "gaussian"]
    params: dict[str, Any]
    description: str = ""


class ThermalSettings(_Strict):
    ambient_mean_c: float = 20.0
    diurnal_amplitude_k: float = Field(0.5, ge=0.0)
    diurnal_phase_rad: float = 0.0
    ambient_random_walk_k_per_rts: float = Field(2.0e-4, ge=0.0)
    set_point_c: float = 20.0
    thermostat_leakage: float = Field(0.05, ge=0.0, le=1.0)
    time_constant_s: float = Field(1800.0, gt=0.0)
    sensor_noise_k: float = Field(1.0e-3, ge=0.0)
    sensor_bias_k: float = 0.0
    set_point_schedule: list[tuple[float, float]] = Field(default_factory=list)  #: (t_s, set point °C)


class VibrationLineConfig(_Strict):
    frequency_hz: float = Field(gt=0.0)
    amplitude_mps2: float = Field(ge=0.0)
    axis: int = Field(2, ge=0, le=2)


class VibrationSettings(_Strict):
    lines: list[VibrationLineConfig] = Field(default_factory=lambda: [
        VibrationLineConfig(frequency_hz=0.15, amplitude_mps2=2.0e-7, axis=2),
        VibrationLineConfig(frequency_hz=0.15, amplitude_mps2=1.5e-7, axis=0),
        VibrationLineConfig(frequency_hz=0.17, amplitude_mps2=1.5e-7, axis=1),
        VibrationLineConfig(frequency_hz=8.0, amplitude_mps2=5.0e-6, axis=2),
    ])
    broadband_rms_mps2: tuple[float, float, float] = (5.0e-7, 5.0e-7, 1.0e-6)
    band_hz: tuple[float, float] = (0.5, 20.0)
    scale: float = Field(1.0, ge=0.0)


class EnvironmentConfig(_Strict):
    thermal: ThermalSettings = Field(default_factory=ThermalSettings)
    vibration: VibrationSettings = Field(default_factory=VibrationSettings)


class InstrumentConfig(_Strict):
    mode: Literal["equilibrium", "feedback"] = "equilibrium"
    proof_mass_kg: float = Field(0.01, gt=0.0)
    natural_frequency_hz: float = Field(1.0, gt=0.0)
    damping_ratio: float = Field(0.7, ge=0.0)
    stop_m: float = Field(5.0e-5, gt=0.0)
    oversample: int = Field(10, ge=1, le=1000)
    range_resolution_mps2: float = Field(1.0e-5, gt=0.0)
    optical_enabled: bool = True
    wavelength_m: float = Field(1.55e-6, gt=0.0)
    visibility: float = Field(0.95, gt=0.0, le=1.0)
    peak_voltage_v: float = Field(4.0, gt=0.0)
    photodetector_noise_v: float = Field(2.0e-5, ge=0.0)
    readout_noise_v: float = Field(1.0e-5, ge=0.0)
    displacement_bias_m: float = 0.0
    adc_bits: int = Field(20, ge=4, le=32)
    adc_v_min: float = 0.0
    adc_v_max: float = 5.0
    transducer_gain_v_per_m: float = Field(2.0e5, gt=0.0)
    transducer_noise_v: float = Field(1.0e-6, ge=0.0)
    feedback_bandwidth_hz: float = Field(5.0, gt=0.0)
    feedback_integral_time_s: float = Field(0.5, gt=0.0)
    feedback_max_force_n: float = Field(2.0e-4, gt=0.0)
    dac_bits: int = Field(24, ge=8, le=32)


class SensorConfig(_Strict):
    bias_mps2: float = 1.5e-6  #: 150 µGal zero offset
    scale_factor_error_ppm: float = 200.0
    scale_factor_tc_ppm_per_k: float = 0.0
    temperature_coefficient_mps2_per_k: float = 5.0e-7  #: 50 µGal/K
    reference_temperature_c: float = 20.0
    drift_linear_mps2_per_s: float = 2.0e-12  #: ≈ 17 µGal/day
    drift_quadratic_mps2_per_s2: float = 0.0
    drift_settling_amplitude_mps2: float = 0.0
    drift_settling_tau_s: float = Field(3600.0, gt=0.0)
    drift_random_walk_mps2_per_rts: float = Field(2.0e-11, ge=0.0)
    white_asd_mps2_per_rthz: float = Field(3.0e-8, ge=0.0)
    correlated_sigma_mps2: float = Field(5.0e-9, ge=0.0)
    correlated_tau_min_s: float = Field(10.0, gt=0.0)
    correlated_tau_max_s: float = Field(10_000.0, gt=0.0)
    correlated_components: int = Field(5, ge=1, le=20)
    cross_coupling_east: float = 1.0e-4
    cross_coupling_north: float = 1.0e-4
    tilt_east_rad: float = 5.0e-6
    tilt_north_rad: float = 5.0e-6


class CalibrationConfig(_Strict):
    """Calibration coefficients applied by the correction stage.

    Defaults represent a *synthetic factory calibration certificate* whose
    values differ from the injected sensor errors (``SensorConfig``) by about
    one stated standard uncertainty — as a real, imperfect calibration would.
    Run ``gravitas calibrate`` to replace them with a fitted calibration.
    """

    bias_mps2: float = 1.47e-6
    scale_factor: float = Field(1.000_19, gt=0.0)
    temperature_coefficient_mps2_per_k: float = 4.9e-7
    reference_temperature_c: float = 20.0
    drift_rate_mps2_per_s: float = 2.2e-12
    drift_epoch_s: float = 0.0
    u_bias_mps2: float = Field(3.0e-8, ge=0.0)
    u_scale_factor: float = Field(2.0e-5, ge=0.0)
    u_temperature_coefficient_mps2_per_k: float = Field(2.0e-8, ge=0.0)
    u_drift_rate_mps2_per_s: float = Field(3.0e-13, ge=0.0)
    u_reference_mps2: float = Field(1.0e-8, ge=0.0)
    source: str = "synthetic factory calibration certificate"


class FilterSettings(_Strict):
    kind: Literal["none", "moving_average", "lowpass", "butterworth", "kalman"] = "butterworth"
    cutoff_hz: float = Field(0.05, gt=0.0)
    order: int = Field(4, ge=1, le=10)
    window_s: float = Field(10.0, gt=0.0)
    kalman_process_asd: float = Field(1.0e-9, gt=0.0)


class EstimatorSettings(_Strict):
    estimate_drift: bool = False
    estimate_tidal_admittance: bool = False
    process_noise_gravity_mps2_per_rts: float = Field(0.0, ge=0.0)
    noise_prior_mps2: float = Field(1.0e-7, gt=0.0)
    min_interval_s: float = Field(1.0, gt=0.0)


class UncertaintySettings(_Strict):
    coverage_factor: float = Field(2.0, gt=0.0)
    u_horizontal_position_m: float = Field(0.5, ge=0.0)
    u_altitude_m: float = Field(0.005, ge=0.0)
    u_temperature_k: float = Field(0.01, ge=0.0)
    u_tide_relative: float = Field(0.01, ge=0.0)
    u_ephemeris_relative: float = Field(0.003, ge=0.0)
    u_earth_model_mps2: float = Field(0.0, ge=0.0)


class SimulationConfig(_Strict):
    name: str = "static"
    description: str = ""
    seed: int = Field(20260101, ge=0)
    sample_rate_hz: float = Field(10.0, gt=0.0, le=1000.0)
    duration_s: float = Field(600.0, gt=0.0)
    chunk_s: float = Field(60.0, gt=0.0)
    start_epoch: datetime = datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc)
    location: LocationConfig = Field(default_factory=LocationConfig)
    trajectory: TrajectoryConfig = Field(default_factory=TrajectoryConfig)
    physics: PhysicsSwitches = Field(default_factory=PhysicsSwitches)
    earth: EarthConfig = Field(default_factory=EarthConfig)
    tides: TideConfig = Field(default_factory=TideConfig)
    anomalies: list[AnomalyBodyConfig] = Field(default_factory=list)
    environment: EnvironmentConfig = Field(default_factory=EnvironmentConfig)
    instrument: InstrumentConfig = Field(default_factory=InstrumentConfig)
    sensor: SensorConfig = Field(default_factory=SensorConfig)
    calibration: CalibrationConfig = Field(default_factory=CalibrationConfig)
    filter: FilterSettings = Field(default_factory=FilterSettings)
    estimator: EstimatorSettings = Field(default_factory=EstimatorSettings)
    uncertainty: UncertaintySettings = Field(default_factory=UncertaintySettings)
    g_ref_override_mps2: Optional[float] = None
    settle_time_s: float = Field(60.0, ge=0.0)

    @field_validator("start_epoch")
    @classmethod
    def _utc(cls, v: datetime) -> datetime:
        if v.tzinfo is None:
            raise ValueError("start_epoch must be timezone-aware (UTC)")
        return v.astimezone(timezone.utc)

    @property
    def n_samples(self) -> int:
        return int(round(self.duration_s * self.sample_rate_hz))

    def config_hash(self) -> str:
        blob = json.dumps(self.model_dump(mode="json"), sort_keys=True, separators=(",", ":"))
        return hashlib.sha256(blob.encode()).hexdigest()

    # --------------------------------------------------------------
    @classmethod
    def from_file(cls, path: str | Path) -> "SimulationConfig":
        return cls.model_validate_json(Path(path).read_text())

    def to_file(self, path: str | Path) -> None:
        Path(path).write_text(self.model_dump_json(indent=2))


def default_anomaly_bodies() -> list[AnomalyBodyConfig]:
    """The default SYNTHETIC GEOPHYSICAL MODEL: a dense ore-like sphere and a buried slab."""
    return [
        AnomalyBodyConfig(kind="sphere", description="synthetic dense body (e.g. ore lens)",
                          params={"radius_m": 40.0, "density_contrast_kgpm3": 1500.0, "center_enu_m": [0.0, 0.0, -90.0]}),
        AnomalyBodyConfig(kind="slab", description="synthetic low-density slab (e.g. sediment-filled channel)",
                          params={"center_enu_m": [250.0, 0.0, -60.0], "size_enu_m": [120.0, 400.0, 40.0],
                                  "density_contrast_kgpm3": -400.0}),
    ]


__all__ = [
    "SimulationConfig", "LocationConfig", "TrajectoryConfig", "Waypoint", "PhysicsSwitches", "EarthConfig",
    "TideConfig", "AnomalyBodyConfig", "EnvironmentConfig", "ThermalSettings", "VibrationSettings",
    "VibrationLineConfig", "InstrumentConfig", "SensorConfig", "CalibrationConfig", "FilterSettings",
    "EstimatorSettings", "UncertaintySettings", "default_anomaly_bodies",
]
