"""Suspension spring and damper.

MODEL
    Linear (Hookean) spring with constant k and a pre-tension extension x₀ chosen
    at manufacture ("range adjustment") so that k x₀ = m g_ref. Linear viscous
    damping c = 2 ζ ω₀ m. The *measurement relationship* in equilibrium is

        m a = k (x + x₀)   ⇒   a = g_ref + (k/m) x = g_ref + ω₀² x.

    With f₀ = 1 Hz, ω₀² ≈ 39.48 s⁻², so 1 µGal ⇔ 0.253 nm of displacement.

ASSUMPTIONS
    Perfectly linear spring, no hysteresis. Thermal and ageing effects on the
    spring are represented as *equivalent input accelerations* by the sensor
    error models (:mod:`gravitas.sensors`), which keeps every error source
    separately inspectable.
"""

from __future__ import annotations

import math
from dataclasses import dataclass


@dataclass
class Spring:
    natural_frequency_hz: float = 1.0
    damping_ratio: float = 0.7

    def __post_init__(self) -> None:
        if not (self.natural_frequency_hz > 0 and math.isfinite(self.natural_frequency_hz)):
            raise ValueError("natural frequency must be positive")
        if not (self.damping_ratio >= 0 and math.isfinite(self.damping_ratio)):
            raise ValueError("damping ratio must be non-negative")

    @property
    def omega0(self) -> float:
        return 2.0 * math.pi * self.natural_frequency_hz

    def spring_constant(self, mass_kg: float) -> float:
        """k = m ω₀² [N/m]."""
        return mass_kg * self.omega0**2

    def damping_coefficient(self, mass_kg: float) -> float:
        """c = 2 ζ ω₀ m [N s/m]."""
        return 2.0 * self.damping_ratio * self.omega0 * mass_kg

    def pretension_extension(self, mass_kg: float, g_ref_mps2: float) -> float:
        """x₀ = m g_ref / k [m]."""
        return mass_kg * g_ref_mps2 / self.spring_constant(mass_kg)

    def force(self, x_m: float, mass_kg: float, g_ref_mps2: float) -> float:
        """F_spring = k (x + x₀) [N]."""
        k = self.spring_constant(mass_kg)
        return k * (x_m + self.pretension_extension(mass_kg, g_ref_mps2))

    def equilibrium_displacement(self, a_in_mps2: float, g_ref_mps2: float) -> float:
        """Static x for constant input: x = (a − g_ref) / ω₀²."""
        return (a_in_mps2 - g_ref_mps2) / self.omega0**2


__all__ = ["Spring"]
