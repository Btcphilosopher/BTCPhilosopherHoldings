"""Generic quadrature (homodyne) Michelson interferometer.

MODEL
    The proof mass carries one mirror of a Michelson interferometer (double
    pass). A displacement x changes the optical phase by

        φ = 4π n x / λ + φ₀

    Two photodetector channels in quadrature (90° optical phase offset, e.g.
    via a polarising beam splitter and a quarter-wave plate) give

        I = (P₀/2)(1 + V cos φ),   Q = (P₀/2)(1 + V sin φ)

    (expressed as photodetector voltages). The phase is recovered as
    φ̂ = atan2(Q − P₀/2, I − P₀/2) and unwrapped (fringe counting).

ASSUMPTIONS
    Perfect quadrature, equal channel gains, refractive index n of the
    (vacuum) cavity = 1, laser wavelength stable. Not a model of any specific
    commercial instrument.
"""

from __future__ import annotations

import math
from dataclasses import dataclass

import numpy as np


@dataclass
class Interferometer:
    wavelength_m: float = 1.55e-6
    refractive_index: float = 1.0
    operating_phase_rad: float = math.pi / 4.0
    visibility: float = 0.95
    peak_voltage_v: float = 4.0  #: P₀ expressed as detector voltage [V]

    def __post_init__(self) -> None:
        if self.wavelength_m <= 0 or not (0 < self.visibility <= 1) or self.peak_voltage_v <= 0:
            raise ValueError("invalid interferometer parameters")

    @property
    def phase_per_metre(self) -> float:
        return 4.0 * math.pi * self.refractive_index / self.wavelength_m

    def phase(self, x_m):
        return self.phase_per_metre * np.asarray(x_m, dtype=float) + self.operating_phase_rad

    def intensities(self, x_m):
        ph = self.phase(x_m)
        half = 0.5 * self.peak_voltage_v
        return half * (1.0 + self.visibility * np.cos(ph)), half * (1.0 + self.visibility * np.sin(ph))

    def displacement_from_phase(self, phase_rad):
        return (np.asarray(phase_rad, dtype=float) - self.operating_phase_rad) / self.phase_per_metre

    def demodulate(self, i_v, q_v):
        """Wrapped phase estimate from I/Q voltages."""
        half = 0.5 * self.peak_voltage_v
        return np.arctan2(np.asarray(q_v) - half, np.asarray(i_v) - half)


__all__ = ["Interferometer"]
