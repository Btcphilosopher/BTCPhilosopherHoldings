"""Thermal environment and instrument thermal response.

MODEL
    Ambient (room / vault) temperature
        T_a(t) = T_a0 + A_d sin(2π t / 86400 + φ_d) + w(t)
        w: random walk, dw = σ_rw dW  (σ_rw in K/√s)

    Instrument internal temperature: thermostatted enclosure modelled as a
    first-order lag toward an effective set point that leaks a fraction β of
    the ambient deviation through the thermostat:

        T_eff = T_set + β (T_a − T_set)
        dT_i/dt = (T_eff − T_i) / τ

    discretised exactly for piecewise-constant T_eff:
        T_i[k+1] = T_eff[k] + (T_i[k] − T_eff[k]) e^{−Δt/τ}

    Temperature sensor: T_meas = T_i + b_T + N(0, σ_T²).

ASSUMPTIONS
    Lumped (single node) thermal mass; no gradients inside the sensor.
"""

from __future__ import annotations

import math
from dataclasses import dataclass

import numpy as np


@dataclass
class ThermalConfig:
    ambient_mean_c: float = 20.0
    diurnal_amplitude_k: float = 0.5
    diurnal_phase_rad: float = 0.0
    ambient_random_walk_k_per_rts: float = 2.0e-4
    set_point_c: float = 20.0
    thermostat_leakage: float = 0.05
    time_constant_s: float = 1800.0
    sensor_noise_k: float = 1.0e-3
    sensor_bias_k: float = 0.0

    def __post_init__(self) -> None:
        if self.time_constant_s <= 0:
            raise ValueError("thermal time constant must be positive")
        if not (0.0 <= self.thermostat_leakage <= 1.0):
            raise ValueError("thermostat leakage must be in [0, 1]")
        for name in ("diurnal_amplitude_k", "ambient_random_walk_k_per_rts", "sensor_noise_k"):
            if getattr(self, name) < 0:
                raise ValueError(f"{name} must be non-negative")


class ThermalModel:
    """Stateful, chunk-invariant thermal simulator."""

    def __init__(self, cfg: ThermalConfig, rng_walk: np.random.Generator, rng_sensor: np.random.Generator,
                 enabled: bool = True):
        self.cfg = cfg
        self.rng_walk = rng_walk
        self.rng_sensor = rng_sensor
        self.enabled = enabled
        self._walk = 0.0
        self._t_inst = cfg.set_point_c + cfg.thermostat_leakage * (cfg.ambient_mean_c - cfg.set_point_c)

    def step(self, t_s: np.ndarray, dt_s: float) -> dict[str, np.ndarray]:
        cfg = self.cfg
        n = t_s.size
        # Random numbers are always drawn so that toggling `enabled` never shifts other streams.
        dw = self.rng_walk.standard_normal(n) * cfg.ambient_random_walk_k_per_rts * math.sqrt(dt_s)
        sensor_noise = self.rng_sensor.standard_normal(n) * cfg.sensor_noise_k
        walk = np.cumsum(np.concatenate([[self._walk], dw]))[1:]  # chunk-invariant accumulation
        self._walk = float(walk[-1]) if n else self._walk
        ambient = (cfg.ambient_mean_c + cfg.diurnal_amplitude_k
                   * np.sin(2.0 * math.pi * t_s / 86_400.0 + cfg.diurnal_phase_rad) + walk)
        t_eff = cfg.set_point_c + cfg.thermostat_leakage * (ambient - cfg.set_point_c)
        alpha = math.exp(-dt_s / cfg.time_constant_s)
        inst = np.empty(n)
        ti = self._t_inst
        for k in range(n):
            inst[k] = ti
            ti = t_eff[k] + (ti - t_eff[k]) * alpha
        self._t_inst = ti
        if not self.enabled:
            ambient = np.full(n, cfg.set_point_c)
            inst = np.full(n, cfg.set_point_c)
        measured = inst + cfg.sensor_bias_k + sensor_noise
        return {"ambient_c": ambient, "instrument_c": inst, "measured_c": measured}


__all__ = ["ThermalConfig", "ThermalModel"]
