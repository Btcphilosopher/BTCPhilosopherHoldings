"""Abstract precision spring gravimeter: proof mass + spring + damper +
(optional) force feedback + displacement readout + ADC.

This is a *generic scientific-instrument model*; it does not reproduce any
commercial instrument.

SIGNAL FLOW (per internal step Δt = 1 / (f_s · oversample))
    a_in  (specific force along the sensitive axis, incl. sensor-error terms)
      │
      ├─► proof-mass dynamics  ẍ = (a_in − g_ref) − ω₀² x − 2ζω₀ ẋ + F_fb/m
      │      exact zero-order-hold discretisation:  s_{k+1} = A_d s_k + B_d u_k
      │      mechanical stops |x| ≤ x_stop
      ├─► readout (optical I/Q or linear transducer) + noise + ADC
      ├─► [feedback mode] PID → DAC-quantised actuator force F_fb
      └─► integrating ADC: block average of x̂ and F_fb over each output sample

MEASUREMENT EQUATIONS (nominal instrument constants)
    equilibrium mode:   g_raw = g_ref + ω₀² x̂
    feedback mode:      g_raw = g_ref + ω₀² x̂ − F̂_fb / m

NUMERICS
    The ZOH discretisation is exact for piecewise-constant input, so the
    integrator is unconditionally stable and introduces no numerical damping.
    The inner loop is compiled with Numba (``cache=True``).
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field

import numba
import numpy as np
from scipy.linalg import expm

from gravitas.instrument.adc import ADC
from gravitas.instrument.feedback import FeedbackController
from gravitas.instrument.optical_readout import LinearTransducer, OpticalReadout
from gravitas.instrument.proof_mass import ProofMass
from gravitas.instrument.spring import Spring

MODE_EQUILIBRIUM = 0
MODE_FEEDBACK = 1


def zoh_discretise(omega0: float, zeta: float, dt: float) -> tuple[np.ndarray, np.ndarray]:
    """Exact ZOH discretisation of ẋ = v, v̇ = −ω₀²x − 2ζω₀v + u."""
    a = np.array([[0.0, 1.0], [-(omega0**2), -2.0 * zeta * omega0]])
    b = np.array([[0.0], [1.0]])
    m = np.zeros((3, 3))
    m[:2, :2] = a * dt
    m[:2, 2:] = b * dt
    e = expm(m)
    return e[:2, :2].copy(), e[:2, 2].copy()


@numba.njit(cache=True, fastmath=False)
def _wrap(a):
    return (a + math.pi) % (2.0 * math.pi) - math.pi


@numba.njit(cache=True, fastmath=False)
def _quantise(v, vmin, lsb, top):
    c = math.floor((v - vmin) / lsb + 0.5)
    sat = 0
    if c < 0:
        c = 0.0
        sat = 1
    elif c > top:
        c = top
        sat = 1
    return c, vmin + c * lsb, sat


@numba.njit(cache=True, fastmath=False)
def gravimeter_kernel(a_in, n1, n2, oversample, p, state):
    """Numba inner loop. See module docstring.

    p (float64 parameters):
      0 g_ref, 1 mass, 2 ad00, 3 ad01, 4 ad10, 5 ad11, 6 bd0, 7 bd1, 8 omega0², 9 x_stop,
      10 mode, 11 kp, 12 ki, 13 kd, 14 fmax, 15 dac_lsb, 16 dt,
      17 optical(1/0), 18 phase_per_m, 19 phase0, 20 vis, 21 peak_v,
      22 adc_vmin, 23 adc_lsb, 24 adc_top, 25 lin_gain, 26 lin_mid, 27 x_bias
    state: 0 x, 1 v, 2 integ, 3 prev_err, 4 phase_unwrapped, 5 initialised, 6 true_phase_prev, 7 f_fb
    """
    n_int = a_in.size
    n_out = n_int // oversample
    x_mean = np.zeros(n_out)
    xm_mean = np.zeros(n_out)
    f_mean = np.zeros(n_out)
    v_last = np.zeros(n_out)
    x_last = np.zeros(n_out)
    phase_last = np.zeros(n_out)
    ch1_last = np.zeros(n_out)
    ch2_last = np.zeros(n_out)
    code1_last = np.zeros(n_out)
    code2_last = np.zeros(n_out)
    sat_count = np.zeros(n_out)
    unlock_count = np.zeros(n_out)
    stop_count = np.zeros(n_out)

    g_ref = p[0]
    mass = p[1]
    ad00, ad01, ad10, ad11, bd0, bd1 = p[2], p[3], p[4], p[5], p[6], p[7]
    x_stop = p[9]
    mode = int(p[10])
    kp, ki, kd, fmax, dac_lsb, dt = p[11], p[12], p[13], p[14], p[15], p[16]
    optical = p[17] > 0.5
    ppm, ph0, vis, peak = p[18], p[19], p[20], p[21]
    vmin, lsb, top = p[22], p[23], p[24]
    lin_gain, lin_mid, x_bias = p[25], p[26], p[27]
    half = 0.5 * peak

    x = state[0]
    v = state[1]
    integ = state[2]
    prev_err = state[3]
    ph_unw = state[4]
    init = state[5]
    tph_prev = state[6]
    f_fb = state[7]

    for k in range(n_int):
        j = k // oversample
        # ---------------- readout -----------------------------------------
        sat = 0
        if optical:
            tph = ppm * x + ph0
            c1 = half * (1.0 + vis * math.cos(tph)) + n1[k]
            c2 = half * (1.0 + vis * math.sin(tph)) + n2[k]
            code1, q1, s1 = _quantise(c1, vmin, lsb, top)
            code2, q2, s2 = _quantise(c2, vmin, lsb, top)
            sat = s1 + s2
            wrapped = math.atan2(q2 - half, q1 - half)
            if init < 0.5:
                # Start-up: the fringe order is resolved by the coarse auxiliary
                # displacement sensor (resolution << λ/2), so the unwrapped phase
                # starts on the correct fringe. Afterwards only fringe counting is used.
                ph_unw = wrapped + 2.0 * math.pi * math.floor((tph - wrapped) / (2.0 * math.pi) + 0.5)
                tph_prev = tph
                init = 1.0
            else:
                ph_unw = ph_unw + _wrap(wrapped - _wrap(ph_unw))
                if abs(tph - tph_prev) > math.pi:
                    unlock_count[j] += 1.0
                tph_prev = tph
            xm = (ph_unw - ph0) / ppm + x_bias
            phase_last[j] = ph_unw
        else:
            vlin = lin_mid + lin_gain * x + n1[k]
            code1, q1, s1 = _quantise(vlin, vmin, lsb, top)
            code2 = 0.0
            q2 = 0.0
            sat = s1
            xm = (q1 - lin_mid) / lin_gain + x_bias
            c1 = vlin
            c2 = 0.0
        if sat > 0:
            sat_count[j] += 1.0
        # ---------------- feedback ----------------------------------------
        if mode == 1:
            err = -xm
            integ = integ + ki * err * dt
            if integ > fmax:
                integ = fmax
            elif integ < -fmax:
                integ = -fmax
            deriv = kd * (err - prev_err) / dt
            prev_err = err
            cmd = kp * err + integ + deriv
            if cmd > fmax:
                cmd = fmax
            elif cmd < -fmax:
                cmd = -fmax
            f_fb = math.floor(cmd / dac_lsb + 0.5) * dac_lsb
        else:
            f_fb = 0.0
        # ---------------- dynamics (exact ZOH) ----------------------------
        u = (a_in[k] - g_ref) + f_fb / mass
        xn = ad00 * x + ad01 * v + bd0 * u
        vn = ad10 * x + ad11 * v + bd1 * u
        x = xn
        v = vn
        if x > x_stop:
            x = x_stop
            v = 0.0
            stop_count[j] += 1.0
        elif x < -x_stop:
            x = -x_stop
            v = 0.0
            stop_count[j] += 1.0
        # ---------------- integrating ADC (block averages) ----------------
        x_mean[j] += x
        xm_mean[j] += xm
        f_mean[j] += f_fb
        v_last[j] = v
        x_last[j] = x
        ch1_last[j] = c1
        ch2_last[j] = c2
        code1_last[j] = code1
        code2_last[j] = code2

    inv = 1.0 / oversample
    for j in range(n_out):
        x_mean[j] *= inv
        xm_mean[j] *= inv
        f_mean[j] *= inv
    state[0] = x
    state[1] = v
    state[2] = integ
    state[3] = prev_err
    state[4] = ph_unw
    state[5] = init
    state[6] = tph_prev
    state[7] = f_fb
    return (x_mean, xm_mean, f_mean, v_last, x_last, phase_last, ch1_last, ch2_last,
            code1_last, code2_last, sat_count, unlock_count, stop_count)


@dataclass
class GravimeterConfig:
    mode: str = "equilibrium"  #: "equilibrium" | "feedback"
    proof_mass: ProofMass = field(default_factory=ProofMass)
    spring: Spring = field(default_factory=Spring)
    feedback: FeedbackController = field(default_factory=FeedbackController)
    optical: OpticalReadout = field(default_factory=OpticalReadout)
    transducer: LinearTransducer = field(default_factory=LinearTransducer)
    oversample: int = 10
    range_resolution_mps2: float = 1.0e-5  #: coarse range-adjust (nulling) resolution, 1 mGal

    def __post_init__(self) -> None:
        if self.mode not in ("equilibrium", "feedback"):
            raise ValueError("mode must be 'equilibrium' or 'feedback'")
        if not (1 <= self.oversample <= 1000):
            raise ValueError("oversample must be in [1, 1000]")


@dataclass
class GravimeterOutput:
    """Per-output-sample instrument states (block averages unless 'last')."""

    position_m: np.ndarray
    measured_position_m: np.ndarray
    feedback_force_n: np.ndarray
    velocity_mps: np.ndarray
    position_last_m: np.ndarray
    phase_rad: np.ndarray
    channel1_v: np.ndarray
    channel2_v: np.ndarray
    code1: np.ndarray
    code2: np.ndarray
    adc_saturation_count: np.ndarray
    fringe_loss_count: np.ndarray
    stop_contact_count: np.ndarray
    raw_gravity_mps2: np.ndarray
    spring_force_n: np.ndarray
    gravity_force_n: np.ndarray


class Gravimeter:
    """Stateful gravimeter twin (chunk-invariant)."""

    def __init__(self, cfg: GravimeterConfig, sample_rate_hz: float, g_ref_mps2: float):
        if sample_rate_hz <= 0:
            raise ValueError("sample rate must be positive")
        self.cfg = cfg
        self.sample_rate_hz = float(sample_rate_hz)
        self.dt_internal = 1.0 / (self.sample_rate_hz * cfg.oversample)
        self.g_ref = float(g_ref_mps2)
        self.state = np.zeros(8)
        # start at static equilibrium for zero deviation
        self._params = self._build_params()

    @staticmethod
    def range_adjust(g_estimate_mps2: float, resolution_mps2: float) -> float:
        """Coarse nulling: choose g_ref to the nearest range-screw step."""
        return round(g_estimate_mps2 / resolution_mps2) * resolution_mps2

    @property
    def mass(self) -> float:
        return self.cfg.proof_mass.mass_kg

    @property
    def omega0(self) -> float:
        return self.cfg.spring.omega0

    @property
    def spring_constant(self) -> float:
        return self.cfg.spring.spring_constant(self.mass)

    @property
    def damping_coefficient(self) -> float:
        return self.cfg.spring.damping_coefficient(self.mass)

    def set_mode(self, mode: str) -> None:
        if mode not in ("equilibrium", "feedback"):
            raise ValueError("mode must be 'equilibrium' or 'feedback'")
        self.cfg.mode = mode
        self.state[2] = 0.0
        self.state[3] = 0.0
        self._params = self._build_params()

    def _build_params(self) -> np.ndarray:
        cfg = self.cfg
        ad, bd = zoh_discretise(self.omega0, cfg.spring.damping_ratio, self.dt_internal)
        kp, ki, kd = cfg.feedback.gains(self.mass, self.omega0, cfg.spring.damping_ratio)
        opt = cfg.optical
        adc: ADC = opt.adc if opt.enabled else cfg.transducer.adc
        p = np.zeros(28)
        p[0] = self.g_ref
        p[1] = self.mass
        p[2:6] = ad.ravel()
        p[6:8] = bd
        p[8] = self.omega0**2
        p[9] = cfg.proof_mass.stop_m
        p[10] = MODE_FEEDBACK if cfg.mode == "feedback" else MODE_EQUILIBRIUM
        p[11], p[12], p[13] = kp, ki, kd
        p[14] = cfg.feedback.max_force_n
        p[15] = cfg.feedback.dac_lsb_n
        p[16] = self.dt_internal
        p[17] = 1.0 if opt.enabled else 0.0
        p[18] = opt.interferometer.phase_per_metre
        p[19] = opt.interferometer.operating_phase_rad
        p[20] = opt.interferometer.visibility
        p[21] = opt.interferometer.peak_voltage_v
        p[22] = adc.v_min
        p[23] = adc.lsb_v
        p[24] = float(2**adc.bits - 1)
        p[25] = cfg.transducer.gain_v_per_m
        p[26] = cfg.transducer.mid_voltage_v
        p[27] = opt.displacement_bias_m if opt.enabled else cfg.transducer.displacement_bias_m
        return p

    def initialise_equilibrium(self, a_in_mps2: float) -> None:
        """Place the proof mass at static equilibrium for a constant input (and preload the
        feedback integrator in feedback mode), as for an instrument that has settled at the station."""
        dev = a_in_mps2 - self.g_ref
        if self.cfg.mode == "feedback":
            f = max(-self.cfg.feedback.max_force_n, min(self.cfg.feedback.max_force_n, -self.mass * dev))
            self.state[0] = 0.0
            self.state[2] = f
            self.state[7] = f
        else:
            self.state[0] = max(-self.cfg.proof_mass.stop_m, min(self.cfg.proof_mass.stop_m, dev / self.omega0**2))
        self.state[1] = 0.0

    def readout_noise_sigmas(self) -> tuple[float, float]:
        if self.cfg.optical.enabled:
            s = self.cfg.optical.total_voltage_noise_v
            return s, s
        return self.cfg.transducer.noise_v, 0.0

    def run(self, a_in_internal: np.ndarray, noise1: np.ndarray, noise2: np.ndarray) -> GravimeterOutput:
        a = np.ascontiguousarray(a_in_internal, dtype=np.float64)
        if a.size % self.cfg.oversample != 0:
            raise ValueError("internal input length must be a multiple of the oversample factor")
        if not np.all(np.isfinite(a)):
            raise FloatingPointError("non-finite input acceleration supplied to the gravimeter")
        res = gravimeter_kernel(a, np.ascontiguousarray(noise1), np.ascontiguousarray(noise2),
                                self.cfg.oversample, self._params, self.state)
        (x_mean, xm_mean, f_mean, v_last, x_last, ph, c1, c2, k1, k2, sat, unl, stop) = res
        w0sq = self.omega0**2
        if self.cfg.mode == "feedback":
            g_raw = self.g_ref + w0sq * xm_mean - f_mean / self.mass
        else:
            g_raw = self.g_ref + w0sq * xm_mean
        k = self.spring_constant
        x0 = self.mass * self.g_ref / k
        a_block = a.reshape(-1, self.cfg.oversample).mean(axis=1)
        return GravimeterOutput(
            position_m=x_mean, measured_position_m=xm_mean, feedback_force_n=f_mean, velocity_mps=v_last,
            position_last_m=x_last, phase_rad=ph, channel1_v=c1, channel2_v=c2, code1=k1, code2=k2,
            adc_saturation_count=sat, fringe_loss_count=unl, stop_contact_count=stop,
            raw_gravity_mps2=g_raw, spring_force_n=k * (x_mean + x0), gravity_force_n=self.mass * a_block,
        )

    def describe(self) -> dict:
        cfg = self.cfg
        adc = cfg.optical.adc if cfg.optical.enabled else cfg.transducer.adc
        return {
            "mode": cfg.mode, "proof_mass_kg": self.mass, "spring_constant_npm": self.spring_constant,
            "damping_nspm": self.damping_coefficient, "natural_frequency_hz": cfg.spring.natural_frequency_hz,
            "damping_ratio": cfg.spring.damping_ratio, "reference_gravity_mps2": self.g_ref,
            "stop_m": cfg.proof_mass.stop_m, "oversample": cfg.oversample, "internal_dt_s": self.dt_internal,
            "readout": "optical" if cfg.optical.enabled else "linear_transducer",
            "wavelength_m": cfg.optical.interferometer.wavelength_m,
            "adc_bits": adc.bits, "adc_full_scale_v": adc.full_scale_v, "adc_lsb_v": adc.lsb_v,
            "feedback_bandwidth_hz": cfg.feedback.bandwidth_hz, "feedback_max_force_n": cfg.feedback.max_force_n,
            "dac_bits": cfg.feedback.dac_bits,
        }


__all__ = ["Gravimeter", "GravimeterConfig", "GravimeterOutput", "zoh_discretise", "gravimeter_kernel",
           "MODE_EQUILIBRIUM", "MODE_FEEDBACK"]
