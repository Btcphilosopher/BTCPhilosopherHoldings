"""Displacement readout chain: optical (interferometric) or linear transducer.

OPTICAL CHAIN (per internal sample)
    true displacement x
      → interferometer phase φ = 4πx/λ + φ₀
      → photodetector voltages I, Q
      + photodetector (shot/electronic) noise  σ_pd  [V]
      + readout amplifier noise                σ_ro  [V]
      → ADC (n bits) on each channel
      → atan2 demodulation, fringe unwrapping
      → measured displacement x̂ (+ readout bias b_x)

LINEAR TRANSDUCER CHAIN (capacitive-style, used when optical is disabled)
    V = V_mid + G_v · x + noise → ADC → x̂ = (V̂ − V_mid)/G_v + b_x

FRINGE ORDER AT START-UP
    The interferometer measures phase modulo 2π. At start-up the fringe order
    is taken from a coarse auxiliary displacement sensor (ideal at the λ/2
    level); thereafter the phase is tracked purely by fringe counting.

FRINGE LOSS
    If the phase changes by more than π between internal samples the fringe
    count is ambiguous; the sample is flagged UNLOCKED. GRAVITAS never "repairs"
    such samples silently.
"""

from __future__ import annotations

from dataclasses import dataclass, field

from gravitas.instrument.adc import ADC
from gravitas.instrument.interferometer import Interferometer


@dataclass
class OpticalReadout:
    enabled: bool = True
    interferometer: Interferometer = field(default_factory=Interferometer)
    photodetector_noise_v: float = 2.0e-5
    readout_noise_v: float = 1.0e-5
    displacement_bias_m: float = 0.0
    adc: ADC = field(default_factory=lambda: ADC(bits=20, v_min=0.0, v_max=5.0))

    @property
    def total_voltage_noise_v(self) -> float:
        return (self.photodetector_noise_v**2 + self.readout_noise_v**2) ** 0.5


@dataclass
class LinearTransducer:
    gain_v_per_m: float = 2.0e5  #: 0.2 V/µm
    mid_voltage_v: float = 0.0
    noise_v: float = 1.0e-6
    displacement_bias_m: float = 0.0
    adc: ADC = field(default_factory=lambda: ADC(bits=24, v_min=-10.0, v_max=10.0))


__all__ = ["OpticalReadout", "LinearTransducer"]
