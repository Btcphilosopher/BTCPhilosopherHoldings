"""Force-feedback (force-rebalance) loop.

MODEL
    A discrete PID controller drives an electrostatic/electromagnetic actuator
    that holds the proof mass at x_ref = 0. In steady state the actuator force
    balances the gravity residual:

        0 = m (a − g_ref) − k x + F_fb   ⇒   a = g_ref + ω₀² x − F_fb / m

    so the measurement is derived from the feedback force (plus the small
    residual displacement term).

EQUATIONS (per internal step Δt, error e = x_ref − x_meas)
    I_k   = clamp(I_{k-1} + K_i e Δt, ±F_max)        (anti-windup clamp)
    D_k   = K_d (e_k − e_{k-1}) / Δt
    F_cmd = clamp(K_p e + I_k + D_k, ±F_max)
    F_fb  = DAC quantisation of F_cmd with n_bits over ±F_max

    Default gains are designed from the plant ω₀ for a closed-loop bandwidth
    ω_c (≈ 5 ω₀) using pole placement on the PD part.
"""

from __future__ import annotations

import math
from dataclasses import dataclass


@dataclass
class FeedbackController:
    enabled: bool = False
    bandwidth_hz: float = 5.0
    integral_time_s: float = 0.5
    max_force_n: float = 2.0e-4
    dac_bits: int = 24

    def __post_init__(self) -> None:
        if self.bandwidth_hz <= 0 or self.integral_time_s <= 0 or self.max_force_n <= 0:
            raise ValueError("feedback parameters must be positive")
        if not (8 <= self.dac_bits <= 32):
            raise ValueError("DAC bits must be within [8, 32]")

    def gains(self, mass_kg: float, omega0: float, damping_ratio: float) -> tuple[float, float, float]:
        """(K_p [N/m], K_i [N/(m s)], K_d [N s/m]) placing closed-loop PD poles at ω_c, ζ = 0.7."""
        wc = 2.0 * math.pi * self.bandwidth_hz
        kp = mass_kg * max(wc * wc - omega0 * omega0, 0.0)
        kd = mass_kg * max(2.0 * 0.7 * wc - 2.0 * damping_ratio * omega0, 0.0)
        ki = kp / self.integral_time_s
        return kp, ki, kd

    @property
    def dac_lsb_n(self) -> float:
        return 2.0 * self.max_force_n / (2**self.dac_bits)


def force_to_acceleration(feedback_force_n: float, mass_kg: float) -> float:
    """a_fb = F_fb / m [m/s²]."""
    return feedback_force_n / mass_kg


__all__ = ["FeedbackController", "force_to_acceleration"]
