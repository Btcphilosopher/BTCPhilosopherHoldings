"""Analogue-to-digital converter.

MODEL
    Ideal mid-tread uniform quantiser with n bits over the input range
    [v_min, v_max], optional input-referred Gaussian noise, hard clipping at
    the range limits (saturation is flagged, never hidden).

EQUATIONS
    LSB  = (v_max − v_min) / 2ⁿ
    code = clamp(round((v − v_min)/LSB), 0, 2ⁿ − 1)
    v̂    = v_min + code · LSB
    Quantisation noise of a busy signal: σ_q = LSB / √12.
"""

from __future__ import annotations

import math
from dataclasses import dataclass

import numpy as np


@dataclass
class ADC:
    bits: int = 24
    v_min: float = 0.0
    v_max: float = 5.0
    noise_v_rms: float = 0.0

    def __post_init__(self) -> None:
        if not (4 <= self.bits <= 32):
            raise ValueError("ADC bits must be within [4, 32]")
        if not (self.v_max > self.v_min):
            raise ValueError("ADC range must satisfy v_max > v_min")
        if self.noise_v_rms < 0:
            raise ValueError("ADC noise must be non-negative")

    @property
    def lsb_v(self) -> float:
        return (self.v_max - self.v_min) / (2**self.bits)

    @property
    def full_scale_v(self) -> float:
        return self.v_max - self.v_min

    @property
    def quantisation_noise_v(self) -> float:
        return self.lsb_v / math.sqrt(12.0)

    def quantise(self, v, rng: np.random.Generator | None = None):
        """Return (codes, reconstructed voltage, saturated mask)."""
        v = np.asarray(v, dtype=float)
        if self.noise_v_rms > 0:
            if rng is None:
                raise ValueError("ADC with noise requires an explicit random generator")
            v = v + rng.normal(0.0, self.noise_v_rms, v.shape)
        raw = np.round((v - self.v_min) / self.lsb_v)
        top = 2**self.bits - 1
        sat = (raw < 0) | (raw > top)
        codes = np.clip(raw, 0, top).astype(np.int64)
        return codes, self.v_min + codes * self.lsb_v, sat


__all__ = ["ADC"]
