"""Proof mass: the inertial element of the gravimeter.

MODEL
    A point proof mass m constrained to move along the instrument's sensitive
    axis (positive *downward*, i.e. along the plumb line). Its displacement x is
    measured from the mechanical reference (null) position.

EQUATIONS (Newton's second law along the axis)
    m ẍ = F_gravity − F_spring − F_damping + F_feedback
    F_gravity  = m a_in                    (a_in: total specific force along the axis)
    F_spring   = k (x + x₀),  k x₀ = m g_ref   (pre-tension nulls g_ref)
    F_damping  = c ẋ
    ⇒ ẍ = (a_in − g_ref) − ω₀² x − 2ζω₀ ẋ + F_feedback / m

    Mechanical stops limit |x| ≤ x_stop; on contact the mass is held at the stop
    (inelastic, velocity set to zero) and the reading is flagged SATURATED.
"""

from __future__ import annotations

import math
from dataclasses import dataclass


@dataclass
class ProofMass:
    mass_kg: float = 0.01
    stop_m: float = 5.0e-5  #: mechanical stop half-range [m]

    def __post_init__(self) -> None:
        if not (self.mass_kg > 0 and math.isfinite(self.mass_kg)):
            raise ValueError("proof mass must be positive and finite")
        if not (self.stop_m > 0 and math.isfinite(self.stop_m)):
            raise ValueError("stop range must be positive and finite")

    def gravity_force(self, a_in_mps2: float) -> float:
        """F = m g [N]."""
        return self.mass_kg * a_in_mps2


@dataclass
class ProofMassState:
    """Instantaneous proof-mass state (SI)."""

    position_m: float = 0.0
    velocity_mps: float = 0.0
    acceleration_mps2: float = 0.0


__all__ = ["ProofMass", "ProofMassState"]
