"""GUM-style uncertainty budget for a gravity measurement.

MEASURAND
    Static gravity g at the nominal station position (tides removed), i.e. the
    quantity the gravity estimator reports.

MODEL
    g = g_ref + [ (Δraw_f − b₀ − c_T (T_m − T_ref) − r (t − t₀)) / S ] − T_model + δg_E

    Combined standard uncertainty (independent inputs, first-order GUM):
        u_c² = Σ_i (c_i u(x_i))²,   U = k u_c

CONTRIBUTIONS (each traceable to a named input and its source)
    sensor_noise      A  Allan deviation of the corrected record at τ = record length
                         (white-noise extrapolation only if the long-τ slope ≈ −½;
                         otherwise the last computed σ_A is used, conservatively)
    bias              B  u(b̂₀) from the calibration certificate / fit
    scale_factor      B  u(Ŝ) · |Δg|      (Δg = measured deviation from g_ref)
    temperature       B  √[(u(ĉ_T)·|T̄_m − T_ref|)² + (ĉ_T · u(T))²]
    position          B  |∂g/∂n| · u(horizontal), from the Earth + anomaly model
    altitude          B  |∂g/∂h| · u(h),           from the Earth + anomaly model
    earth_model       B  stated model uncertainty ⊕ |closed-form − series| discrepancy
    tidal_correction  B  |mean tide model| · √(u_δ,rel² + u_eph,rel²)
    vibration         A  standard error of the mean of the auxiliary platform record
                         after the measurement filter (batch means)
    calibration       B  reference-value uncertainty ⊕ u(r̂)·|t̄ − t₀|

LIMITATIONS
    Inputs are treated as uncorrelated; the joint-calibration covariance is
    available in :class:`~gravitas.estimation.calibration.CalibrationFit` for a
    full treatment via :mod:`gravitas.uncertainty.propagation`.
"""

from __future__ import annotations

import math
from dataclasses import asdict, dataclass, field

import numpy as np

from gravitas.estimation.allan import overlapping_adev


@dataclass
class Contribution:
    name: str
    standard_uncertainty_mps2: float
    type: str  # "A" | "B"
    sensitivity: float
    input_uncertainty: float
    input_unit: str
    description: str
    randomised_in_monte_carlo: bool = True

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass
class GravityEstimate:
    value: float
    standard_uncertainty: float
    expanded_uncertainty: float
    coverage_factor: float = 2.0
    unit: str = "m/s^2"
    contributions: list[Contribution] = field(default_factory=list)

    def to_dict(self) -> dict:
        return {"value_mps2": self.value, "standard_uncertainty_mps2": self.standard_uncertainty,
                "expanded_uncertainty_mps2": self.expanded_uncertainty, "coverage_factor": self.coverage_factor,
                "contributions": [c.to_dict() for c in self.contributions]}

    def matched_standard_uncertainty(self) -> float:
        """u_c restricted to contributions that the Monte Carlo engine randomises."""
        return math.sqrt(sum(c.standard_uncertainty_mps2**2 for c in self.contributions if c.randomised_in_monte_carlo))

    def __repr__(self) -> str:  # pragma: no cover - cosmetic
        return (f"GravityEstimate(value={self.value!r}, standard_uncertainty={self.standard_uncertainty!r}, "
                f"expanded_uncertainty={self.expanded_uncertainty!r})")


def noise_term_from_adev(series: np.ndarray, sample_interval_s: float) -> tuple[float, dict]:
    """Standard uncertainty of the record mean from its Allan deviation."""
    x = np.asarray(series, dtype=float)
    n = x.size
    record = n * sample_interval_s
    if n < 16:
        return float(np.std(x, ddof=1) / math.sqrt(max(n, 1))) if n > 1 else float("inf"), {"method": "short record"}
    res = overlapping_adev(x, sample_interval_s)
    slope = res.identification.get("long_term_slope", -0.5)
    tau_last = float(res.tau_s[-1])
    sig_last = float(res.adev[-1])
    # use the longest decade of τ (several points) rather than the single noisiest last point
    top = res.tau_s >= tau_last / 10.0
    if slope < -0.35:
        # white-dominated: σ_A(τ)·√(τ/T) is constant; RMS over the top decade
        u = float(np.sqrt(np.mean((res.adev[top] ** 2) * res.tau_s[top] / record)))
        method = "white-noise extrapolation of σ_A (longest decade) to the record length"
    else:
        u = float(np.sqrt(np.mean(res.adev[top] ** 2)))
        method = "RMS σ_A over the longest decade (no further averaging assumed: non-white long-term noise)"
    return u, {"method": method, "tau_last_s": tau_last, "adev_last_mps2": sig_last, "long_term_slope": slope}


def compute_budget(result, settle_s: float | None = None) -> GravityEstimate:
    """Uncertainty budget for a :class:`~gravitas.simulation.engine.SimulationResult` (static occupation)."""
    from gravitas.earth.gravity import EarthGravityModel
    from gravitas.earth.normal_gravity import normal_gravity_free_air

    cfg = result.config
    ch = result.chain.channels
    fs = cfg.sample_rate_hz
    uc = cfg.uncertainty
    cal = cfg.calibration
    t = result.chain.t_s
    skip = settle_s if settle_s is not None else cfg.settle_time_s
    sel = t >= min(skip, t[-1] * 0.5)
    corr = ch["correction.gravity_mps2"][sel]
    value = float(ch["estimate.gravity_mps2"][-1])
    g_ref = float(ch["instrument.reference_gravity_mps2"][-1])
    contributions: list[Contribution] = []

    # decimate the corrected record to ~independent samples before the Allan analysis
    stride = max(1, int(round(_independent_interval(result) * fs)))
    dec = corr[: (corr.size // stride) * stride].reshape(-1, stride).mean(axis=1) if stride > 1 else corr
    u_noise, meta = noise_term_from_adev(dec, stride / fs)
    contributions.append(Contribution("sensor_noise", u_noise, "A", 1.0, u_noise, "m/s^2",
                                      f"Allan deviation of corrected record ({meta.get('method')})"))
    contributions.append(Contribution("bias", cal.u_bias_mps2, "B", 1.0, cal.u_bias_mps2, "m/s^2",
                                      f"zero-offset uncertainty from calibration ({cal.source})"))
    dg = abs(value - g_ref)
    contributions.append(Contribution("scale_factor", cal.u_scale_factor * dg / cal.scale_factor, "B", dg / cal.scale_factor,
                                      cal.u_scale_factor, "1", "scale-factor uncertainty × measured span from g_ref"))
    t_m = float(np.mean(ch["environment.measured_temperature_c"][sel]))
    u_t = math.hypot(cal.u_temperature_coefficient_mps2_per_k * abs(t_m - cal.reference_temperature_c),
                     cal.temperature_coefficient_mps2_per_k * uc.u_temperature_k)
    contributions.append(Contribution("temperature", u_t, "B", cal.temperature_coefficient_mps2_per_k, uc.u_temperature_k, "K",
                                      "temperature-coefficient uncertainty and temperature-sensor uncertainty"))
    # position / altitude sensitivities from the model actually used for the truth
    lat = math.radians(float(ch["position.latitude_deg"][-1]))
    lon = math.radians(float(ch["position.longitude_deg"][-1]))
    h = float(ch["position.altitude_m"][-1])
    model = EarthGravityModel()
    dgdn = model.horizontal_gradient(lat, lon, h)
    dgdh = model.vertical_gradient(lat, lon, h)
    anom_grad_h, anom_grad_v = _anomaly_gradients(result)
    dgdn_tot = math.hypot(dgdn, anom_grad_h)
    dgdh_tot = dgdh + anom_grad_v
    contributions.append(Contribution("position", abs(dgdn_tot) * uc.u_horizontal_position_m, "B", abs(dgdn_tot),
                                      uc.u_horizontal_position_m, "m", "horizontal position uncertainty × horizontal gravity gradient"))
    contributions.append(Contribution("altitude", abs(dgdh_tot) * uc.u_altitude_m, "B", abs(dgdh_tot), uc.u_altitude_m, "m",
                                      "sensor-height uncertainty × vertical gravity gradient (free-air + anomaly)"))
    discrepancy = abs(float(normal_gravity_free_air(lat, h)) - model.magnitude(lat, lon, h)[0])
    u_em = math.hypot(uc.u_earth_model_mps2, discrepancy)
    contributions.append(Contribution("earth_model", u_em, "B", 1.0, u_em, "m/s^2",
                                      "stated Earth-model uncertainty ⊕ closed-form vs series discrepancy", False))
    tide_mean = float(np.mean(ch["correction.tide_model_mps2"][sel]))
    u_tide = abs(tide_mean) * math.hypot(uc.u_tide_relative, uc.u_ephemeris_relative)
    contributions.append(Contribution("tidal_correction", u_tide, "B", abs(tide_mean), math.hypot(uc.u_tide_relative, uc.u_ephemeris_relative),
                                      "1", "relative uncertainty of tidal factor and ephemeris × mean applied tide"))
    u_vib = _vibration_term(result, sel)
    contributions.append(Contribution("vibration", u_vib, "A", 1.0, u_vib, "m/s^2",
                                      "standard error of mean of filtered platform acceleration (batch means)"))
    t_mean = float(np.mean(t[sel]))
    u_cal = math.hypot(cal.u_reference_mps2, cal.u_drift_rate_mps2_per_s * abs(t_mean - cal.drift_epoch_s))
    contributions.append(Contribution("calibration", u_cal, "B", 1.0, u_cal, "m/s^2",
                                      "calibration reference-value uncertainty ⊕ drift-rate uncertainty × elapsed time"))
    u_c = math.sqrt(sum(c.standard_uncertainty_mps2**2 for c in contributions))
    return GravityEstimate(value=value, standard_uncertainty=u_c, expanded_uncertainty=uc.coverage_factor * u_c,
                           coverage_factor=uc.coverage_factor, contributions=contributions)


def _independent_interval(result) -> float:
    filt = result.manifest.get("filter", {})
    enbw = filt.get("enbw_hz")
    if enbw:
        return 1.0 / (2.0 * enbw)
    return 1.0 / result.config.sample_rate_hz


def _anomaly_gradients(result) -> tuple[float, float]:
    from gravitas.physics.anomalies import AnomalyField, body_from_dict

    cfg = result.config
    if not cfg.anomalies or not cfg.physics.local_anomaly:
        return 0.0, 0.0
    field_ = AnomalyField([body_from_dict({"kind": b.kind, **b.params}) for b in cfg.anomalies])
    ch = result.chain.channels
    p = np.array([ch["position.east_m"][-1], ch["position.north_m"][-1], ch["position.up_m"][-1]])
    d = 0.5
    ge = (field_.delta_g(p + [d, 0, 0]) - field_.delta_g(p - [d, 0, 0]))[0] / (2 * d)
    gn = (field_.delta_g(p + [0, d, 0]) - field_.delta_g(p - [0, d, 0]))[0] / (2 * d)
    gu = (field_.delta_g(p + [0, 0, d]) - field_.delta_g(p - [0, 0, d]))[0] / (2 * d)
    return float(math.hypot(ge, gn)), float(gu)


def _vibration_term(result, sel: np.ndarray, n_batches: int = 10) -> float:
    from gravitas.estimation.filtering import FilterConfig, StreamingFilter

    cfg = result.config
    vib = result.chain.channels["environment.vibration_up_mps2"]
    f = StreamingFilter(FilterConfig(**cfg.filter.model_dump()), cfg.sample_rate_hz)
    fv = f.process(vib)[sel]
    if fv.size < n_batches * 2:
        return float(np.std(fv) / math.sqrt(max(fv.size, 1)))
    m = (fv.size // n_batches) * n_batches
    means = fv[:m].reshape(n_batches, -1).mean(axis=1)
    return float(np.std(means, ddof=1) / math.sqrt(n_batches))


__all__ = ["Contribution", "GravityEstimate", "compute_budget", "noise_term_from_adev"]
