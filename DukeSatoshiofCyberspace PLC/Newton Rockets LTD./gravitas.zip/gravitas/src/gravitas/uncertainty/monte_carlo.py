"""Statistics for Monte Carlo validation of the uncertainty model.

Given per-trial errors e_j = ĝ_j − g_true and per-trial analytical standard
uncertainties u_j, compute

    mean error (bias)        ē = (1/N) Σ e_j
    standard deviation       s = √[Σ (e_j − ē)² / (N − 1)]
    RMSE                     √[(1/N) Σ e_j²]
    95 % CI of the bias      ē ± t_{0.975, N−1} s / √N
    95 % CI of s             χ²-based: s √[(N−1)/χ²_{0.975}], s √[(N−1)/χ²_{0.025}]
    empirical 95 % interval  2.5th–97.5th percentile of e
    coverage probability     fraction of trials with |e_j| ≤ k u_j
    ratio                    s / RMS(u_j)    (≈ 1 if the analytical model is right)
    normality                D'Agostino–Pearson K² test p-value
"""

from __future__ import annotations

import math

import numpy as np
from scipy import stats


def summarise(errors: np.ndarray, analytic_u: np.ndarray, coverage_factor: float = 2.0) -> dict:
    e = np.asarray(errors, dtype=float)
    u = np.asarray(analytic_u, dtype=float)
    n = e.size
    if n < 3:
        raise ValueError("need at least 3 Monte Carlo trials")
    mean = float(e.mean())
    sd = float(e.std(ddof=1))
    tq = float(stats.t.ppf(0.975, n - 1))
    u_rms = float(math.sqrt(np.mean(u * u)))
    out = {
        "trials": n,
        "mc_mean_error_mps2": mean,
        "mc_std_mps2": sd,
        "rmse_mps2": float(math.sqrt(np.mean(e * e))),
        "bias_ci95_mps2": [mean - tq * sd / math.sqrt(n), mean + tq * sd / math.sqrt(n)],
        "std_ci95_mps2": [sd * math.sqrt((n - 1) / stats.chi2.ppf(0.975, n - 1)),
                          sd * math.sqrt((n - 1) / stats.chi2.ppf(0.025, n - 1))],
        "ci95_mps2": [float(np.percentile(e, 2.5)), float(np.percentile(e, 97.5))],
        "analytical_std_mps2": u_rms,
        "ratio_mc_to_analytical": sd / u_rms if u_rms > 0 else float("inf"),
        "coverage_probability": float(np.mean(np.abs(e) <= coverage_factor * u)),
        "coverage_factor": coverage_factor,
    }
    if n >= 8:
        out["normality_pvalue"] = float(stats.normaltest(e).pvalue)
    return out


__all__ = ["summarise"]
