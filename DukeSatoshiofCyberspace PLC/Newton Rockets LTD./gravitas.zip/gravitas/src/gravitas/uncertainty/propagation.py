"""Uncertainty propagation: first-order (GUM) and Monte Carlo (GUM Supplement 1).

LINEAR PROPAGATION
    y = f(x),  x ~ (μ, Σ)
    J_i = ∂f/∂x_i  (central differences with step h_i = max(|x_i|·1e-6, 1e-12·…))
    u_y² = J Σ Jᵀ

MONTE CARLO PROPAGATION
    Draw x⁽ʲ⁾ ~ N(μ, Σ) (Cholesky), evaluate y⁽ʲ⁾ = f(x⁽ʲ⁾), report mean, std
    and the shortest coverage interval.

Both accept vector-valued f. The two are compared in tests; they agree for
mildly non-linear models and diverge (correctly) for strongly non-linear ones.
"""

from __future__ import annotations

from typing import Callable

import numpy as np


def numerical_jacobian(f: Callable[[np.ndarray], np.ndarray], x: np.ndarray, rel_step: float = 1e-6,
                       abs_step: np.ndarray | None = None) -> np.ndarray:
    x = np.asarray(x, dtype=float)
    y0 = np.atleast_1d(f(x))
    jac = np.zeros((y0.size, x.size))
    for i in range(x.size):
        h = abs(x[i]) * rel_step
        if abs_step is not None:
            h = max(h, float(abs_step[i]))
        if h == 0:
            h = rel_step
        xp = x.copy()
        xm = x.copy()
        xp[i] += h
        xm[i] -= h
        jac[:, i] = (np.atleast_1d(f(xp)) - np.atleast_1d(f(xm))) / (2 * h)
    return jac


def propagate_linear(f, mean: np.ndarray, cov: np.ndarray, abs_step: np.ndarray | None = None) -> tuple[np.ndarray, np.ndarray]:
    """(y, Cov_y) by first-order propagation."""
    mean = np.asarray(mean, dtype=float)
    cov = np.atleast_2d(np.asarray(cov, dtype=float))
    if abs_step is None:
        abs_step = 1e-3 * np.sqrt(np.clip(np.diag(cov), 0, None))
    j = numerical_jacobian(f, mean, abs_step=abs_step)
    return np.atleast_1d(f(mean)), j @ cov @ j.T


def propagate_monte_carlo(f, mean: np.ndarray, cov: np.ndarray, n: int, rng: np.random.Generator,
                          coverage: float = 0.95) -> dict:
    mean = np.asarray(mean, dtype=float)
    cov = np.atleast_2d(np.asarray(cov, dtype=float))
    l = np.linalg.cholesky(cov + 1e-300 * np.eye(mean.size))
    xs = mean + rng.standard_normal((n, mean.size)) @ l.T
    ys = np.array([np.atleast_1d(f(x)) for x in xs])
    ys_sorted = np.sort(ys, axis=0)
    k = int(np.ceil(coverage * n))
    widths = ys_sorted[k - 1:] - ys_sorted[: n - k + 1]
    j = np.argmin(widths, axis=0)
    lo = ys_sorted[j, np.arange(ys.shape[1])]
    hi = ys_sorted[j + k - 1, np.arange(ys.shape[1])]
    return {"mean": ys.mean(axis=0), "std": ys.std(axis=0, ddof=1), "interval_lo": lo, "interval_hi": hi,
            "samples": ys}


__all__ = ["numerical_jacobian", "propagate_linear", "propagate_monte_carlo"]
