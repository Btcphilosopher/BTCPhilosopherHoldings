"""GRAVITAS — precision Earth-gravity measurement digital twin.

The physics is the product. The digital twin is the instrument. The interface
is only the observation layer.

Package layout follows the measurement chain::

    earth → physics → (environment) → instrument → sensors → estimation
          → uncertainty → simulation / experiments → telemetry → validation

All accelerations are SI m/s² (float64) internally; see
:mod:`gravitas.constants.units` for presentation conversions.
"""

__version__ = "1.0.0"
SOFTWARE_VERSION = __version__

__all__ = ["__version__", "SOFTWARE_VERSION"]
