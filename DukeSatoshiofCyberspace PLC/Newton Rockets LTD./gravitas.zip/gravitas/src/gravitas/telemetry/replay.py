"""Replay of recorded experiments.

A :class:`ReplaySession` loads a recording (CSV / Parquet / HDF5 / JSON) and
offers ``load · play · pause · seek · filter · correct · analyse · export``.

Playback is driven by an explicit cursor and a *replay clock* (``tick``) so
it is deterministic and testable; :meth:`play_realtime` provides wall-clock
pacing for interactive use. Re-processing (``filter``, ``correct``) operates on
the recorded raw stage, never on the recorded processed stages, so a replay
can test alternative processing on identical raw data.
"""

from __future__ import annotations

import math
import time
from pathlib import Path

import numpy as np

from gravitas.estimation.allan import overlapping_adev
from gravitas.estimation.calibration import CalibrationParameters
from gravitas.estimation.filtering import FilterConfig, StreamingFilter, zero_phase_butterworth
from gravitas.telemetry.recorder import read_table, write_table


class ReplaySession:
    def __init__(self, table: dict[str, np.ndarray], manifest: dict):
        if "sim_time_s" not in table:
            raise ValueError("recording has no sim_time_s column")
        self.table = table
        self.manifest = manifest
        self.t = np.asarray(table["sim_time_s"], dtype=float)
        if self.t.size < 2:
            raise ValueError("recording must contain at least 2 samples")
        self.dt = float(np.median(np.diff(self.t)))
        self.cursor = 0
        self.playing = False
        self.derived: dict[str, np.ndarray] = {}
        self.raw_key = "raw.gravity_mps2" if "raw.gravity_mps2" in table else "raw_measurement_mps2"

    # ------------------------------------------------------------- loading
    @classmethod
    def load(cls, path: str | Path, fmt: str | None = None) -> "ReplaySession":
        table, manifest = read_table(path, fmt)
        return cls(table, manifest)

    @property
    def n(self) -> int:
        return int(self.t.size)

    @property
    def sample_rate_hz(self) -> float:
        return 1.0 / self.dt

    # ------------------------------------------------------------ playback
    def play(self) -> None:
        self.playing = True

    def pause(self) -> None:
        self.playing = False

    def seek(self, t_s: float) -> int:
        if not (self.t[0] <= t_s <= self.t[-1]):
            raise ValueError(f"seek time {t_s} outside recording [{self.t[0]}, {self.t[-1]}]")
        self.cursor = int(np.searchsorted(self.t, t_s, side="left"))
        return self.cursor

    def tick(self, n: int = 1) -> dict[str, np.ndarray]:
        """Advance the cursor by ``n`` samples if playing; return the emitted rows."""
        if not self.playing or self.cursor >= self.n:
            return {}
        sl = slice(self.cursor, min(self.n, self.cursor + n))
        self.cursor = sl.stop
        if self.cursor >= self.n:
            self.playing = False
        return {k: np.asarray(v)[sl] for k, v in self.table.items()}

    def current(self) -> dict:
        i = min(self.cursor, self.n - 1)
        return {k: (np.asarray(v)[i].item() if hasattr(np.asarray(v)[i], "item") else np.asarray(v)[i])
                for k, v in self.table.items()}

    def play_realtime(self, speed: float = 1.0, max_seconds: float | None = None, callback=None) -> None:
        self.play()
        t_wall0 = time.monotonic()
        t_sim0 = self.t[self.cursor] if self.cursor < self.n else self.t[-1]
        while self.playing:
            elapsed = (time.monotonic() - t_wall0) * speed
            target = t_sim0 + elapsed
            k = int(np.searchsorted(self.t, target, side="right")) - self.cursor
            if k > 0:
                rows = self.tick(k)
                if callback:
                    callback(rows)
            if max_seconds is not None and time.monotonic() - t_wall0 > max_seconds:
                self.pause()
            time.sleep(min(0.05, self.dt / max(speed, 1e-9)))

    # ---------------------------------------------------------- processing
    def filter(self, kind: str = "butterworth", zero_phase: bool = False, **kw) -> np.ndarray:
        raw = np.asarray(self.table[self.raw_key], dtype=float)
        ref = float(np.round(raw[0], 5))
        if zero_phase:
            if kind != "butterworth":
                raise ValueError("zero-phase replay filtering is available for butterworth only")
            y = zero_phase_butterworth(raw - ref, self.sample_rate_hz, kw.get("cutoff_hz", 0.05), kw.get("order", 4))
        else:
            f = StreamingFilter(FilterConfig(kind=kind, **kw), self.sample_rate_hz)
            y = f.process(raw - ref)
        self.derived["filtered_mps2"] = y + ref
        return self.derived["filtered_mps2"]

    def correct(self, calibration: CalibrationParameters | None = None, remove_tide: bool = True) -> np.ndarray:
        if "filtered_mps2" not in self.derived:
            self.filter()
        if calibration is None:
            recorded = self.manifest.get("calibration_parameters")
            calibration = CalibrationParameters(**recorded) if recorded else CalibrationParameters()
        cal = calibration
        g_ref = float(self.table.get("instrument.reference_gravity_mps2", np.round(self.derived["filtered_mps2"][:1], 5))[0])
        tkey = "environment.measured_temperature_c" if "environment.measured_temperature_c" in self.table else "temperature_c"
        cal_dev = cal.apply(self.derived["filtered_mps2"] - g_ref, np.asarray(self.table[tkey], float), self.t)
        out = cal_dev + g_ref
        if remove_tide:
            tide_key = "correction.tide_model_mps2" if "correction.tide_model_mps2" in self.table else "tidal_component_mps2"
            out = out - np.asarray(self.table[tide_key], float)
        self.derived["corrected_mps2"] = out
        return out

    def analyse(self, key: str | None = None) -> dict:
        series = self.derived.get("corrected_mps2") if key is None else np.asarray(self.table[key], float)
        if series is None:
            series = self.correct()
        truth_key = "truth.static_gravity_mps2" if "truth.static_gravity_mps2" in self.table else "static_gravity_mps2"
        stats = {"n": self.n, "duration_s": float(self.t[-1] - self.t[0]), "mean_mps2": float(np.mean(series)),
                 "std_mps2": float(np.std(series, ddof=1)), "min_mps2": float(np.min(series)), "max_mps2": float(np.max(series))}
        if truth_key in self.table:
            resid = series - np.asarray(self.table[truth_key], float)
            stats["residual_mean_mps2"] = float(np.mean(resid))
            stats["residual_rms_mps2"] = float(math.sqrt(np.mean(resid**2)))
        adev = overlapping_adev(np.asarray(self.table[self.raw_key], float), self.dt)
        stats["allan"] = adev.to_dict()
        return stats

    def export(self, path: str | Path, fmt: str | None = None) -> Path:
        table = dict(self.table)
        for k, v in self.derived.items():
            table["replay." + k] = v
        manifest = dict(self.manifest)
        manifest["replay"] = {"derived_columns": sorted(self.derived)}
        return write_table(table, path, manifest, fmt)


__all__ = ["ReplaySession"]
