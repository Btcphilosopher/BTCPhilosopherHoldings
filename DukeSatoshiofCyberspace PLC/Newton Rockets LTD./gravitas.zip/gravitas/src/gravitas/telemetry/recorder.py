"""Telemetry and full-chain recording to CSV, Parquet, HDF5 and JSON.

Every file carries the reproducibility manifest:
    CSV      sidecar ``<file>.manifest.json``
    Parquet  schema metadata key ``gravitas_manifest``
    HDF5     root attribute ``gravitas_manifest`` (JSON string)
    JSON     top-level key ``manifest``

Two content levels:
    telemetry   the strict TelemetryFrame columns (see schema.py)
    chain       every inspectable stage channel of the measurement chain
Floats are written at full double precision (CSV uses ``%.17g``).
"""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np

from gravitas.telemetry.schema import SCHEMA_VERSION, table_from_chain

FORMATS = ("csv", "parquet", "hdf5", "json")


def _format_of(path: Path, fmt: str | None) -> str:
    if fmt:
        if fmt not in FORMATS:
            raise ValueError(f"unsupported format {fmt!r}; expected one of {FORMATS}")
        return fmt
    ext = path.suffix.lower().lstrip(".")
    ext = {"h5": "hdf5", "hdf": "hdf5", "pq": "parquet"}.get(ext, ext)
    if ext not in FORMATS:
        raise ValueError(f"cannot infer format from extension {path.suffix!r}")
    return ext


def build_table(result, content: str = "chain") -> dict[str, np.ndarray]:
    from gravitas.simulation.clock import SimulationClock

    clock = SimulationClock(result.config.start_epoch, result.config.sample_rate_hz)
    tele = table_from_chain(result.chain, clock, result.status_log)
    if content == "telemetry":
        return tele
    if content != "chain":
        raise ValueError("content must be 'telemetry' or 'chain'")
    table = {"sim_time_s": tele["sim_time_s"], "timestamp": tele["timestamp"], "status": tele["status"]}
    for k, v in result.chain.channels.items():
        table[k] = v
    for k, v in result.chain.flags.items():
        table["flag." + k] = v.astype(np.int8)
    return table


def write_table(table: dict[str, np.ndarray], path: str | Path, manifest: dict, fmt: str | None = None) -> Path:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    fmt = _format_of(path, fmt)
    meta = {"schema_version": SCHEMA_VERSION, **manifest}
    if fmt == "csv":
        import pandas as pd

        df = pd.DataFrame(table)
        df.to_csv(path, index=False, float_format="%.17g")
        Path(str(path) + ".manifest.json").write_text(json.dumps(meta, indent=2, default=str))
    elif fmt == "parquet":
        import pyarrow as pa
        import pyarrow.parquet as pq

        tbl = pa.table({k: pa.array(v) for k, v in table.items()})
        tbl = tbl.replace_schema_metadata({"gravitas_manifest": json.dumps(meta, default=str)})
        pq.write_table(tbl, path)
    elif fmt == "hdf5":
        import h5py

        with h5py.File(path, "w") as f:
            f.attrs["gravitas_manifest"] = json.dumps(meta, default=str)
            g = f.create_group("data")
            for k, v in table.items():
                arr = np.asarray(v)
                if arr.dtype.kind in ("U", "O"):
                    g.create_dataset(k, data=arr.astype("S"))
                else:
                    g.create_dataset(k, data=arr, compression="gzip", compression_opts=4)
    elif fmt == "json":
        payload = {"manifest": meta, "columns": {k: np.asarray(v).tolist() for k, v in table.items()}}
        path.write_text(json.dumps(payload, default=str))
    return path


def record(result, path: str | Path, fmt: str | None = None, content: str = "chain") -> Path:
    """Record a :class:`~gravitas.simulation.engine.SimulationResult`."""
    return write_table(build_table(result, content), path, result.manifest, fmt)


def read_table(path: str | Path, fmt: str | None = None) -> tuple[dict[str, np.ndarray], dict]:
    path = Path(path)
    fmt = _format_of(path, fmt)
    if fmt == "csv":
        import pandas as pd

        df = pd.read_csv(path, float_precision="round_trip")
        table = {c: df[c].to_numpy() for c in df.columns}
        side = Path(str(path) + ".manifest.json")
        manifest = json.loads(side.read_text()) if side.exists() else {}
    elif fmt == "parquet":
        import pyarrow.parquet as pq

        tbl = pq.read_table(path)
        table = {c: tbl.column(c).to_numpy(zero_copy_only=False) for c in tbl.column_names}
        md = tbl.schema.metadata or {}
        manifest = json.loads(md.get(b"gravitas_manifest", b"{}"))
    elif fmt == "hdf5":
        import h5py

        with h5py.File(path, "r") as f:
            manifest = json.loads(f.attrs.get("gravitas_manifest", "{}"))
            table = {}
            for k in f["data"].keys():
                arr = f["data"][k][()]
                if arr.dtype.kind == "S":
                    arr = arr.astype(str)
                table[k] = arr
    else:
        payload = json.loads(path.read_text())
        manifest = payload.get("manifest", {})
        table = {k: np.asarray(v) for k, v in payload["columns"].items()}
    for k, v in list(table.items()):
        if np.asarray(v).dtype == object:
            table[k] = np.asarray(v).astype(str)
    return table, manifest


__all__ = ["record", "build_table", "write_table", "read_table", "FORMATS"]
