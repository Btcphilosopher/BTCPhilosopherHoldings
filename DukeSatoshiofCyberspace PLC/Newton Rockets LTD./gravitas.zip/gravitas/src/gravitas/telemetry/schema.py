"""Strict telemetry schema.

A :class:`TelemetryFrame` is one output sample of the measurement chain. All
fields are required, finite, and carry their unit in the name. Unknown fields
are rejected. Frames are produced *only* from engine output
(:func:`frames_from_chunk`) — there is no other constructor path in the
application code.
"""

from __future__ import annotations

import math
from datetime import datetime
from typing import Literal

import numpy as np
from pydantic import BaseModel, ConfigDict, field_validator

SCHEMA_VERSION = "1.0"

Status = Literal["STABLE", "SETTLING", "SATURATED", "UNLOCKED", "PAUSED"]


class TelemetryFrame(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)

    timestamp: str
    sim_time_s: float
    latitude_deg: float
    longitude_deg: float
    altitude_m: float
    true_gravity_mps2: float
    static_gravity_mps2: float
    raw_measurement_mps2: float
    filtered_mps2: float
    calibrated_mps2: float
    corrected_measurement_mps2: float
    estimate_mps2: float
    tidal_component_mps2: float
    lunar_component_mps2: float
    solar_component_mps2: float
    anomaly_component_mps2: float
    bias_mps2: float
    temperature_c: float
    vibration_mps2: float
    uncertainty_mps2: float
    proof_mass_position_m: float
    feedback_force_n: float
    adc_code: int
    status: Status

    @field_validator("*", mode="before")
    @classmethod
    def _finite(cls, v, info):
        if isinstance(v, (float, np.floating)) and not math.isfinite(float(v)):
            raise ValueError(f"{info.field_name} must be finite")
        if isinstance(v, np.generic):
            return v.item()
        return v

    @field_validator("latitude_deg")
    @classmethod
    def _lat(cls, v):
        if not -90.0 <= v <= 90.0:
            raise ValueError("latitude out of range")
        return v

    @field_validator("longitude_deg")
    @classmethod
    def _lon(cls, v):
        if not -180.0 <= v <= 180.0:
            raise ValueError("longitude out of range")
        return v

    @field_validator("timestamp")
    @classmethod
    def _ts(cls, v):
        datetime.fromisoformat(v.replace("Z", "+00:00"))
        return v


#: Mapping from telemetry field → engine chain channel (the traceable origin of each value).
FIELD_SOURCES: dict[str, str] = {
    "latitude_deg": "position.latitude_deg",
    "longitude_deg": "position.longitude_deg",
    "altitude_m": "position.altitude_m",
    "true_gravity_mps2": "truth.gravity_mps2",
    "static_gravity_mps2": "truth.static_gravity_mps2",
    "raw_measurement_mps2": "raw.gravity_mps2",
    "filtered_mps2": "filter.gravity_mps2",
    "calibrated_mps2": "calibration.gravity_mps2",
    "corrected_measurement_mps2": "correction.gravity_mps2",
    "estimate_mps2": "estimate.gravity_mps2",
    "tidal_component_mps2": "tide.combined_mps2",
    "lunar_component_mps2": "tide.lunar_mps2",
    "solar_component_mps2": "tide.solar_mps2",
    "anomaly_component_mps2": "anomaly.delta_g_mps2",
    "bias_mps2": "sensor.total_bias_mps2",
    "temperature_c": "environment.instrument_temperature_c",
    "vibration_mps2": "environment.vibration_up_mps2",
    "uncertainty_mps2": "estimate.sigma_mps2",
    "proof_mass_position_m": "instrument.proof_mass_position_m",
    "feedback_force_n": "instrument.feedback_force_n",
    "adc_code": "adc.code1",
}

COLUMNS = ["timestamp", "sim_time_s"] + list(FIELD_SOURCES) + ["status"]


def frames_from_chunk(chunk, clock, status: str, uncertainty_override: np.ndarray | None = None,
                      stride: int = 1) -> list[TelemetryFrame]:
    """Build validated frames from a :class:`~gravitas.simulation.state.ChainChunk`."""
    ch = chunk.channels
    frames = []
    for i in range(0, chunk.n, stride):
        rec = {"timestamp": clock.iso(float(chunk.t_s[i])), "sim_time_s": float(chunk.t_s[i]), "status": status}
        for fld, src in FIELD_SOURCES.items():
            v = ch[src][i]
            rec[fld] = int(v) if fld == "adc_code" else float(v)
        if uncertainty_override is not None:
            rec["uncertainty_mps2"] = float(uncertainty_override[i])
        frames.append(TelemetryFrame(**rec))
    return frames


def table_from_chain(chain, clock, status_log: list[dict]) -> dict[str, np.ndarray]:
    """Columnar telemetry table (all samples) for recording."""
    ch = chain.channels
    t = chain.t_s
    out: dict[str, np.ndarray] = {"sim_time_s": t}
    out["timestamp"] = np.array([clock.iso(float(x)) for x in t])
    for fld, src in FIELD_SOURCES.items():
        out[fld] = ch[src].astype(np.int64) if fld == "adc_code" else ch[src].astype(float)
    status = np.full(t.size, "STABLE", dtype=object)
    for entry in status_log:
        m = (t >= entry["t_start_s"]) & (t <= entry["t_end_s"])
        status[m] = entry["status"]
    out["status"] = status.astype(str)
    return out


__all__ = ["TelemetryFrame", "FIELD_SOURCES", "COLUMNS", "SCHEMA_VERSION", "frames_from_chunk", "table_from_chain"]
