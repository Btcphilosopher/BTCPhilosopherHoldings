"""Experiment library. Each experiment exposes ``run(duration_s, sample_rate_hz, seed, config=None)``."""

from gravitas.experiments import altitude, anomaly, calibration, latitude, static, tides, vibration

REGISTRY = {
    "static": static,
    "altitude": altitude,
    "latitude": latitude,
    "tides": tides,
    "anomaly": anomaly,
    "vibration": vibration,
    "calibration": calibration,
}


def run_experiment(name: str, **kwargs):
    if name not in REGISTRY:
        raise KeyError(f"unknown experiment {name!r}; available: {sorted(REGISTRY)}")
    return REGISTRY[name].run(**kwargs)


def list_experiments() -> list[dict]:
    return [{"name": k, "description": m.DESCRIPTION} for k, m in REGISTRY.items()]


__all__ = ["REGISTRY", "run_experiment", "list_experiments"]
