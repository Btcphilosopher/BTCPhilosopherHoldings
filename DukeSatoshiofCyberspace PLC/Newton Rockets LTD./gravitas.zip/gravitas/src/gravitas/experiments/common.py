"""Shared experiment infrastructure: result container, decimation, output writing, plots."""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path

import numpy as np


@dataclass
class ExperimentResult:
    name: str
    description: str
    summary: dict
    x: np.ndarray
    x_label: str
    curves: dict[str, np.ndarray]
    y_unit: str = "m/s^2"
    manifest: dict = field(default_factory=dict)
    tables: dict[str, dict] = field(default_factory=dict)
    simulation_results: list = field(default_factory=list)

    def to_dict(self, max_points: int = 2000) -> dict:
        idx = decimation_index(self.x.size, max_points)
        return {
            "name": self.name, "description": self.description, "summary": _jsonable(self.summary),
            "series": {"x": self.x[idx].tolist(), "x_label": self.x_label, "y_unit": self.y_unit,
                       "curves": {k: np.asarray(v)[idx].tolist() for k, v in self.curves.items()}},
            "tables": _jsonable(self.tables),
        }

    def save(self, out_dir: str | Path, formats: tuple[str, ...] = ("csv", "json"), plots: bool = True) -> list[Path]:
        out = Path(out_dir)
        out.mkdir(parents=True, exist_ok=True)
        written: list[Path] = []
        (out / f"{self.name}_summary.json").write_text(json.dumps(_jsonable({"name": self.name, "summary": self.summary,
                                                                              "tables": self.tables}), indent=2))
        written.append(out / f"{self.name}_summary.json")
        (out / f"{self.name}_manifest.json").write_text(json.dumps(self.manifest, indent=2, default=str))
        written.append(out / f"{self.name}_manifest.json")
        import pandas as pd

        df = pd.DataFrame({self.x_label: self.x, **{k: np.asarray(v) for k, v in self.curves.items()}})
        if "csv" in formats:
            p = out / f"{self.name}_series.csv"
            df.to_csv(p, index=False, float_format="%.17g")
            written.append(p)
        if "parquet" in formats:
            p = out / f"{self.name}_series.parquet"
            df.to_parquet(p)
            written.append(p)
        for tname, tab in self.tables.items():
            if isinstance(tab, dict) and tab and all(isinstance(v, (list, np.ndarray)) for v in tab.values()):
                p = out / f"{self.name}_{tname}.csv"
                pd.DataFrame({k: np.asarray(v) for k, v in tab.items()}).to_csv(p, index=False, float_format="%.17g")
                written.append(p)
        if plots:
            written.extend(self.plot(out))
        return written

    def _panels(self) -> list[dict]:
        """Group curves into readable panels (presentation only; data are untouched).

        Absolute gravity curves (~9.8 m/s²) are shown as deviations from a stated
        reference; small accelerations are shown directly; temperatures separately.
        The unit (µGal or mGal) is chosen from the data range and always labelled.
        """
        absolute, small, temps = {}, {}, {}
        for k, v in self.curves.items():
            v = np.asarray(v, dtype=float)
            if k.endswith("_c"):
                temps[k] = v
            elif self.y_unit == "m/s^2" and np.nanmedian(np.abs(v)) > 1.0:
                absolute[k] = v
            else:
                small[k] = v
        panels = []

        def unit_for(arrs):
            rng = max((np.nanmax(a) - np.nanmin(a)) for a in arrs) if arrs else 0.0
            return ("mGal", 1e5) if rng > 1e-5 else ("µGal", 1e8)

        if absolute:
            ref = float(np.nanmean(next(iter(absolute.values()))))
            name, f = unit_for([a - ref for a in absolute.values()])
            panels.append({"curves": {k: (v - ref) * f for k, v in absolute.items()},
                           "ylabel": f"Δ from {ref:.9f} m/s² [{name}]"})
        if small:
            if self.y_unit == "m/s^2":
                name, f = unit_for(list(small.values()))
                panels.append({"curves": {k: v * f for k, v in small.items()}, "ylabel": f"[{name}]"})
            else:
                panels.append({"curves": small, "ylabel": self.y_unit})
        if temps:
            panels.append({"curves": temps, "ylabel": "temperature [°C]"})
        return panels

    def plot(self, out: Path) -> list[Path]:
        import matplotlib

        matplotlib.use("Agg")
        import matplotlib.pyplot as plt

        panels = self._panels()
        fig, axes = plt.subplots(len(panels), 1, figsize=(10, 3.2 * len(panels) + 0.8), dpi=110, sharex=True,
                                 squeeze=False)
        for ax, pnl in zip(axes[:, 0], panels):
            for k, v in pnl["curves"].items():
                ax.plot(self.x, v, lw=0.9, label=k)
            ax.set_ylabel(pnl["ylabel"])
            ax.grid(True, lw=0.3)
            ax.legend(fontsize=7, loc="best")
        axes[-1, 0].set_xlabel(self.x_label)
        axes[0, 0].set_title(f"GRAVITAS — {self.name}")
        p = out / f"{self.name}.png"
        fig.tight_layout()
        fig.savefig(p)
        plt.close(fig)
        paths = [p]
        try:
            import plotly.graph_objects as go
            from plotly.subplots import make_subplots

            figp = make_subplots(rows=len(panels), cols=1, shared_xaxes=True)
            idx = decimation_index(self.x.size, 20000)
            for i, pnl in enumerate(panels, start=1):
                for k, v in pnl["curves"].items():
                    figp.add_trace(go.Scattergl(x=self.x[idx], y=np.asarray(v)[idx], name=k, mode="lines"), row=i, col=1)
                figp.update_yaxes(title_text=pnl["ylabel"], row=i, col=1)
            figp.update_layout(title=f"GRAVITAS — {self.name}", template="simple_white", height=320 * len(panels) + 80)
            figp.update_xaxes(title_text=self.x_label, row=len(panels), col=1)
            ph = out / f"{self.name}.html"
            figp.write_html(ph, include_plotlyjs="cdn")
            paths.append(ph)
        except Exception as exc:  # pragma: no cover - optional dependency path
            (out / f"{self.name}_plotly_error.txt").write_text(repr(exc))
        return paths


def decimation_index(n: int, max_points: int) -> np.ndarray:
    if n <= max_points:
        return np.arange(n)
    return np.unique(np.linspace(0, n - 1, max_points).round().astype(int))


def _jsonable(obj):
    if isinstance(obj, dict):
        return {str(k): _jsonable(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [_jsonable(v) for v in obj]
    if isinstance(obj, np.ndarray):
        return obj.tolist()
    if isinstance(obj, np.generic):
        return obj.item()
    return obj


__all__ = ["ExperimentResult", "decimation_index"]
