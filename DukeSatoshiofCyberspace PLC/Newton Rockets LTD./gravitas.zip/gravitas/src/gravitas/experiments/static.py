"""STATIC experiment: a stationary gravimeter for a configurable duration.

Outputs true gravity, raw, corrected, bias, noise, drift and the uncertainty
budget of the final estimate.
"""

from __future__ import annotations

import math

import numpy as np

from gravitas.estimation.allan import overlapping_adev
from gravitas.estimation.calibration import drift_estimation
from gravitas.experiments.common import ExperimentResult
from gravitas.simulation.engine import SimulationEngine
from gravitas.simulation.scenario import SimulationConfig

DESCRIPTION = "Stationary gravimeter: true vs raw vs corrected gravity, bias, noise, drift and uncertainty."


def run(duration_s: float = 3600.0, sample_rate_hz: float = 10.0, seed: int = 20260101,
        config: SimulationConfig | None = None) -> ExperimentResult:
    cfg = (config or SimulationConfig(name="static")).model_copy(
        update={"duration_s": duration_s, "sample_rate_hz": sample_rate_hz, "seed": seed, "name": "static"})
    res = SimulationEngine(cfg).run()
    ch = res.chain.channels
    t = res.t_s
    sel = t >= cfg.settle_time_s
    est = res.final_estimate()
    truth_static = float(ch["truth.static_gravity_mps2"][-1])
    raw = ch["raw.gravity_mps2"]
    resid_raw = raw - ch["truth.gravity_mps2"]
    adev = overlapping_adev(raw[sel] - raw[sel].mean(), 1.0 / sample_rate_hz)
    resid_corr = ch["correction.gravity_mps2"] - ch["truth.static_gravity_mps2"]
    stride = max(1, int(sample_rate_hz * 10))
    drift_fit = drift_estimation(resid_corr[sel], t[sel], stride=stride) if sel.sum() > 3 * stride else {}
    summary = {
        "true_gravity_mean_mps2": float(ch["truth.gravity_mps2"].mean()),
        "true_static_gravity_mps2": truth_static,
        "raw_mean_mps2": float(raw[sel].mean()),
        "raw_std_mps2": float(raw[sel].std(ddof=1)),
        "corrected_mean_mps2": float(ch["correction.gravity_mps2"][sel].mean()),
        "estimate_mps2": est.value,
        "estimate_error_mps2": est.value - truth_static,
        "standard_uncertainty_mps2": est.standard_uncertainty,
        "expanded_uncertainty_mps2": est.expanded_uncertainty,
        "coverage_factor": est.coverage_factor,
        "error_over_u": (est.value - truth_static) / est.standard_uncertainty,
        "injected_bias_mean_mps2": float(ch["sensor.total_bias_mps2"].mean()),
        "raw_minus_true_mean_mps2": float(resid_raw[sel].mean()),
        "raw_short_tau_asd_mps2_per_rthz": adev.identification["white_noise_mps2_per_rthz"],
        "configured_white_asd_mps2_per_rthz": cfg.sensor.white_asd_mps2_per_rthz,
        "residual_drift_rate_mps2_per_s": drift_fit.get("drift_rate_mps2_per_s", float("nan")),
        "residual_drift_rate_uncertainty_mps2_per_s": drift_fit.get("u_drift_rate_mps2_per_s", float("nan")),
        "injected_drift_rate_mps2_per_s": cfg.sensor.drift_linear_mps2_per_s,
        "tide_range_mps2": float(np.ptp(ch["tide.combined_mps2"])),
        "status_final": res.status_log[-1]["status"],
    }
    tables = {"uncertainty_budget": {"name": [c.name for c in est.contributions],
                                     "type": [c.type for c in est.contributions],
                                     "standard_uncertainty_mps2": [c.standard_uncertainty_mps2 for c in est.contributions]},
              "allan": {"tau_s": adev.tau_s.tolist(), "adev_mps2": adev.adev.tolist()}}
    curves = {k: ch[v] for k, v in {
        "true_mps2": "truth.gravity_mps2", "static_true_mps2": "truth.static_gravity_mps2", "raw_mps2": "raw.gravity_mps2",
        "filtered_mps2": "filter.gravity_mps2", "calibrated_mps2": "calibration.gravity_mps2",
        "corrected_mps2": "correction.gravity_mps2", "estimate_mps2": "estimate.gravity_mps2",
        "bias_mps2": "sensor.total_bias_mps2", "tide_mps2": "tide.combined_mps2"}.items()}
    r = ExperimentResult("static", DESCRIPTION, summary, t, "time_s", curves, manifest=res.manifest, tables=tables)
    r.simulation_results.append(res)
    r.estimate = est
    return r


__all__ = ["run", "DESCRIPTION"]
