"""GRAVITY ANOMALY experiment — SYNTHETIC GEOPHYSICAL MODEL.

    dense underground body → gravity anomaly → moving gravimeter → measured anomaly profile

The gravimeter is carried along a straight East–West survey line over the
synthetic bodies at constant speed. Processing (standard for continuous
surveys):
    1. zero-phase Butterworth filter of the raw record (post-processing, no delay)
    2. calibration (certificate coefficients)
    3. tide correction (model) and Eötvös correction (known velocity)
    4. subtraction of normal gravity at each position (Earth model)
    5. removal of the base-station level (relative survey: mean over the first
       ``base_fraction`` of the line, where the synthetic anomaly is negligible)
The measured profile is compared with the true synthetic anomaly.
"""

from __future__ import annotations

import math

import numpy as np

from gravitas.estimation.filtering import zero_phase_butterworth
from gravitas.experiments.common import ExperimentResult
from gravitas.physics.anomalies import AnomalyField, body_from_dict
from gravitas.simulation.engine import SimulationEngine
from gravitas.simulation.scenario import SimulationConfig, TrajectoryConfig, Waypoint, default_anomaly_bodies

DESCRIPTION = "Moving gravimeter over a SYNTHETIC buried anomaly: measured vs true anomaly profile."


def run(duration_s: float = 1800.0, sample_rate_hz: float = 10.0, seed: int = 20260101,
        config: SimulationConfig | None = None, line_start_m: float = -600.0, line_end_m: float = 800.0,
        cutoff_hz: float = 0.02, base_fraction: float = 0.12) -> ExperimentResult:
    base = config or SimulationConfig(name="anomaly")
    bodies = base.anomalies or default_anomaly_bodies()
    traj = TrajectoryConfig(kind="waypoints", waypoints=[Waypoint(t_s=0.0, east_m=line_start_m),
                                                         Waypoint(t_s=duration_s, east_m=line_end_m)])
    cfg = base.model_copy(update={"duration_s": duration_s, "sample_rate_hz": sample_rate_hz, "seed": seed,
                                  "name": "anomaly", "anomalies": bodies, "trajectory": traj,
                                  "settle_time_s": 0.0})
    eng = SimulationEngine(cfg)
    res = eng.run()
    ch = res.chain.channels
    t = res.t_s
    g_ref = float(ch["instrument.reference_gravity_mps2"][0])
    raw_dev = ch["raw.gravity_mps2"] - g_ref
    filt = zero_phase_butterworth(raw_dev, sample_rate_hz, cutoff_hz, 4)
    cal = eng.calibration.apply(filt, ch["environment.measured_temperature_c"], t)
    corrected = cal - ch["correction.tide_model_mps2"] + ch["correction.eotvos_mps2"] + g_ref
    normal = ch["earth.effective_mps2"]
    measured_anom = corrected - normal
    true_anom = ch["anomaly.delta_g_mps2"]
    east = ch["position.east_m"]
    # filter edge effects are excluded from the base level and from the statistics
    edge = int(3.0 / cutoff_hz * sample_rate_hz)
    if t.size <= 4 * edge:
        edge = 0
    core = slice(edge, t.size - edge)
    nb = max(10, int(base_fraction * t.size))
    base_win = slice(edge, edge + nb)
    measured_anom = measured_anom - (measured_anom[base_win].mean() - true_anom[base_win].mean())
    err = measured_anom[core] - true_anom[core]
    # point uncertainty from the residual scatter after filtering (Type A) + base-level uncertainty
    u_point = float(np.std(err, ddof=1))
    u_base = u_point / math.sqrt(max(1.0, nb / (sample_rate_hz / (2 * cutoff_hz))))
    u = np.full(t.size, math.hypot(u_point, u_base))
    field_ = AnomalyField([body_from_dict({"kind": b.kind, **b.params}) for b in bodies])
    x_grid = np.linspace(line_start_m, line_end_m, 141)
    y_grid = np.linspace(-400.0, 400.0, 81)
    grid = field_.grid(x_grid, y_grid)
    speed = (line_end_m - line_start_m) / duration_s
    summary = {
        "label": AnomalyField.label,
        "line_length_m": line_end_m - line_start_m, "speed_mps": speed,
        "peak_true_anomaly_mps2": float(true_anom.max()), "min_true_anomaly_mps2": float(true_anom.min()),
        "peak_measured_anomaly_mps2": float(measured_anom[core].max()),
        "rms_error_mps2": float(np.sqrt(np.mean(err**2))),
        "max_abs_error_mps2": float(np.max(np.abs(err))),
        "point_uncertainty_mps2": float(u[0]),
        "correlation_true_measured": float(np.corrcoef(true_anom[core], measured_anom[core])[0, 1]),
        "eotvos_correction_mps2": float(np.mean(ch["correction.eotvos_mps2"])),
        "normal_gravity_variation_along_line_mps2": float(np.ptp(normal)),
        "filter_cutoff_hz": cutoff_hz, "spatial_resolution_m": speed / (2 * cutoff_hz),
    }
    raw_minus_normal = ch["raw.gravity_mps2"] - normal - (ch["raw.gravity_mps2"] - normal)[base_win].mean()
    # order: noisy raw first so that measured and true profiles are drawn on top
    curves = {"raw_minus_normal_mps2": raw_minus_normal, "measured_anomaly_mps2": measured_anom,
              "true_anomaly_mps2": true_anom, "uncertainty_mps2": u}
    tables = {"grid_east_m": {"east_m": x_grid.tolist()}, "grid_north_m": {"north_m": y_grid.tolist()},
              "bodies": {"description": [b.description for b in bodies], "kind": [b.kind for b in bodies]}}
    r = ExperimentResult("anomaly", DESCRIPTION, summary, east, "east_m", curves, manifest=res.manifest, tables=tables)
    r.grid = {"east_m": x_grid, "north_m": y_grid, "anomaly_mps2": grid}
    r.simulation_results.append(res)
    return r


__all__ = ["run", "DESCRIPTION"]
