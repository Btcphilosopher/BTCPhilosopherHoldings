"""CALIBRATION campaign: inject known errors, run calibration, quantify the residual.

Campaign (one continuous record, one instrument, fixed range setting):
    * calibration line — occupations at stations of different height (known
      reference gravity from the Earth model, u_ref configurable): gives
      zero offset and scale factor;
    * thermal-chamber steps of the instrument set point: temperature coefficient;
    * total record length: drift rate.
A joint weighted least-squares fit recovers (b₀, S, c_T, r). The fitted
calibration is then applied to an *independent validation run* (new seed,
static) and compared with the uncalibrated (identity) processing.
"""

from __future__ import annotations

import numpy as np

from gravitas.estimation.calibration import CalibrationParameters, joint_calibration
from gravitas.experiments.common import ExperimentResult
from gravitas.simulation.engine import SimulationEngine
from gravitas.simulation.scenario import CalibrationConfig, SimulationConfig, TrajectoryConfig, Waypoint

DESCRIPTION = "Calibration campaign with injected errors: zero, scale factor, temperature, drift."


def campaign_trajectory(stations_m, dwell_s: float, transit_s: float) -> tuple[TrajectoryConfig, list[tuple[float, float]]]:
    wps, dwell_windows = [], []
    t = 0.0
    for i, h in enumerate(stations_m):
        wps.append(Waypoint(t_s=t, up_m=float(h)))
        dwell_windows.append((t, t + dwell_s))
        t += dwell_s
        wps.append(Waypoint(t_s=t, up_m=float(h)))
        if i < len(stations_m) - 1:
            t += transit_s
    return TrajectoryConfig(kind="waypoints", waypoints=wps), dwell_windows


def run(duration_s: float = 6 * 3600.0, sample_rate_hz: float = 2.0, seed: int = 7,
        config: SimulationConfig | None = None, stations_m=(0.0, 150.0, 300.0, 150.0, 0.0, 300.0, 0.0),
        u_reference_mps2: float = 5.0e-9, settle_after_arrival_s: float = 300.0) -> ExperimentResult:
    base = config or SimulationConfig(name="calibration")
    transit = 120.0
    dwell = (duration_s - transit * (len(stations_m) - 1)) / len(stations_m)
    if dwell < 2 * settle_after_arrival_s:
        raise ValueError("campaign too short for the number of stations")
    traj, windows = campaign_trajectory(stations_m, dwell, transit)
    total = windows[-1][1]
    sched = [(0.0, 20.0), (total * 0.15, 22.0), (total * 0.40, 18.0), (total * 0.65, 21.0), (total * 0.85, 19.0)]
    identity = CalibrationConfig(bias_mps2=0.0, scale_factor=1.0, temperature_coefficient_mps2_per_k=0.0,
                                 drift_rate_mps2_per_s=0.0, source="identity (uncalibrated)")
    thermal = base.environment.thermal.model_copy(update={"set_point_schedule": sched, "time_constant_s": 900.0})
    cfg = base.model_copy(update={"duration_s": total, "sample_rate_hz": sample_rate_hz, "seed": seed,
                                  "name": "calibration", "trajectory": traj, "calibration": identity,
                                  "environment": base.environment.model_copy(update={"thermal": thermal}),
                                  "chunk_s": 600.0})
    res = SimulationEngine(cfg).run()
    ch = res.chain.channels
    t = res.t_s
    g_ref = float(ch["instrument.reference_gravity_mps2"][0])
    mask = np.zeros(t.size, bool)
    for a, b in windows:
        mask |= (t >= a + settle_after_arrival_s) & (t < b)
    # measured: filtered stage minus the tide model; reference: known station gravity (static truth)
    raw_dev = (ch["filter.gravity_mps2"] - ch["correction.tide_model_mps2"] - g_ref)[mask]
    rng = np.random.default_rng(seed + 1)
    # each distinct calibration-line station has one reference value with its own error
    levels = np.array(sorted(set(float(h) for h in stations_m)))
    station_err = rng.normal(0.0, u_reference_mps2, levels.size)
    sid = np.argmin(np.abs(ch["position.up_m"][mask][:, None] - levels[None, :]), axis=1)
    ref_dev = (ch["truth.static_gravity_mps2"] - g_ref)[mask] + station_err[sid]
    tm = ch["environment.measured_temperature_c"][mask]
    tt = t[mask]
    stride = max(1, int(round(20.0 * sample_rate_hz)))
    fit = joint_calibration(raw_dev, ref_dev, tm, tt, reference_temperature_c=cfg.sensor.reference_temperature_c,
                            drift_epoch_s=0.0, stride=stride, u_reference_mps2=u_reference_mps2, station_ids=sid)
    p = fit.parameters
    sc = cfg.sensor
    injected = {"bias_mps2": sc.bias_mps2, "scale_factor": 1.0 + sc.scale_factor_error_ppm * 1e-6,
                "temperature_coefficient_mps2_per_k": sc.temperature_coefficient_mps2_per_k,
                "drift_rate_mps2_per_s": sc.drift_linear_mps2_per_s}
    estimated = {"bias_mps2": p.bias_mps2, "scale_factor": p.scale_factor,
                 "temperature_coefficient_mps2_per_k": p.temperature_coefficient_mps2_per_k,
                 "drift_rate_mps2_per_s": p.drift_rate_mps2_per_s}
    est_u = {"bias_mps2": p.u_bias_mps2, "scale_factor": p.u_scale_factor,
             "temperature_coefficient_mps2_per_k": p.u_temperature_coefficient_mps2_per_k,
             "drift_rate_mps2_per_s": p.u_drift_rate_mps2_per_s}
    # ---- independent validation run -------------------------------------------------
    vt = 3600.0
    val_base = base.model_copy(update={"duration_s": vt, "sample_rate_hz": sample_rate_hz, "seed": seed + 1000,
                                       "name": "calibration-validation",
                                       "environment": base.environment.model_copy(update={"thermal": base.environment.thermal.model_copy(update={"set_point_c": 21.0})})})
    val_uncal = SimulationEngine(val_base.model_copy(update={"calibration": identity})).run()
    cal_cfg = CalibrationConfig(**{k: v for k, v in p.to_dict().items() if k in CalibrationConfig.model_fields})
    val_cal = SimulationEngine(val_base.model_copy(update={"calibration": cal_cfg})).run()
    vsel = val_cal.t_s >= 120.0
    truth_v = val_cal["truth.static_gravity_mps2"][vsel]
    unc_res = val_uncal["correction.gravity_mps2"][vsel] - truth_v
    cal_res = val_cal["correction.gravity_mps2"][vsel] - truth_v
    summary = {
        "injected": injected, "estimated": estimated, "estimated_uncertainty": est_u,
        "normalised_errors": {k: (estimated[k] - injected[k]) / est_u[k] if est_u[k] > 0 else float("nan") for k in injected},
        "residual_rms_uncalibrated_mps2": float(np.sqrt(np.mean(unc_res**2))),
        "residual_rms_calibrated_mps2": float(np.sqrt(np.mean(cal_res**2))),
        "residual_mean_uncalibrated_mps2": float(np.mean(unc_res)),
        "residual_mean_calibrated_mps2": float(np.mean(cal_res)),
        "improvement_factor": float(np.sqrt(np.mean(unc_res**2)) / np.sqrt(np.mean(cal_res**2))),
        "fit_residual_rms_mps2": fit.residual_rms_mps2, "fit_samples": fit.n_used,
        "fit_lag1_autocorrelation": fit.extra["lag1_autocorrelation"], "fit_variance_inflation": fit.extra["variance_inflation"],
        "campaign_duration_s": total, "stations_m": list(map(float, stations_m)),
        "calibration_parameters": p.to_dict(),
    }
    tv = val_cal.t_s
    curves = {"true_mps2": val_cal["truth.static_gravity_mps2"], "uncalibrated_mps2": val_uncal["correction.gravity_mps2"],
              "calibrated_mps2": val_cal["correction.gravity_mps2"], "temperature_c": val_cal["environment.measured_temperature_c"]}
    tables = {"campaign": {"t_s": t[mask][::stride].tolist(), "raw_dev_mps2": raw_dev[::stride].tolist(),
                           "reference_dev_mps2": ref_dev[::stride].tolist(), "temperature_c": tm[::stride].tolist()}}
    r = ExperimentResult("calibration", DESCRIPTION, summary, tv, "time_s", curves, manifest=res.manifest, tables=tables)
    r.simulation_results.extend([res, val_uncal, val_cal])
    r.fit = fit
    return r


__all__ = ["run", "DESCRIPTION", "campaign_trajectory"]
