"""TIDES experiment: long static record; lunar and solar tidal components.

The gravity estimator runs with tidal-admittance estimation enabled, so the
experiment also *recovers the gravimetric factor δ* from the measurement and
compares it with the value used to generate the truth.
"""

from __future__ import annotations

import numpy as np

from gravitas.estimation.calibration import ar1_inflation
from gravitas.experiments.common import ExperimentResult
from gravitas.simulation.engine import SimulationEngine
from gravitas.simulation.scenario import SimulationConfig

DESCRIPTION = "Long static record showing lunar and solar tides; recovery of the gravimetric factor."


def run(duration_s: float = 3 * 86400.0, sample_rate_hz: float = 1.0, seed: int = 20260101,
        config: SimulationConfig | None = None) -> ExperimentResult:
    base = config or SimulationConfig(name="tides")
    cfg = base.model_copy(update={
        "duration_s": duration_s, "sample_rate_hz": sample_rate_hz, "seed": seed, "name": "tides",
        "chunk_s": 3600.0,
        "estimator": base.estimator.model_copy(update={"estimate_drift": True, "estimate_tidal_admittance": True}),
    })
    res = SimulationEngine(cfg).run()
    ch = res.chain.channels
    t = res.t_s
    sel = t >= cfg.settle_time_s
    # independent admittance estimate by regression: calibrated − static truth vs nominal tide model
    stride = max(1, int(sample_rate_hz * 60))
    y = ch["calibration.gravity_mps2"][sel] - ch["calibration.gravity_mps2"][sel].mean()
    x = ch["correction.tide_model_mps2"][sel]
    n = (y.size // stride) * stride
    yd, xd = y[:n].reshape(-1, stride).mean(1), x[:n].reshape(-1, stride).mean(1)
    td = t[sel][:n].reshape(-1, stride).mean(1)
    a_mat = np.column_stack([np.ones_like(xd), xd, td - td[0]])
    theta, *_ = np.linalg.lstsq(a_mat, yd, rcond=None)
    resid = yd - a_mat @ theta
    rho, infl = ar1_inflation(resid)
    cov = float(resid @ resid) / max(1, yd.size - 3) * infl * np.linalg.inv(a_mat.T @ a_mat)
    slope, u_slope = float(theta[1]), float(np.sqrt(cov[1, 1]))
    delta_model = cfg.tides.gravimetric_factor_model
    est_admittance = float(ch["estimate.tidal_admittance"][-1])
    summary = {
        "duration_h": duration_s / 3600.0,
        "lunar_min_mps2": float(ch["tide.lunar_mps2"].min()), "lunar_max_mps2": float(ch["tide.lunar_mps2"].max()),
        "solar_min_mps2": float(ch["tide.solar_mps2"].min()), "solar_max_mps2": float(ch["tide.solar_mps2"].max()),
        "combined_range_mps2": float(np.ptp(ch["tide.combined_mps2"])),
        "lunar_to_solar_amplitude_ratio": float(np.ptp(ch["tide.lunar_mps2"]) / np.ptp(ch["tide.solar_mps2"])),
        "gravimetric_factor_true": cfg.tides.gravimetric_factor_true,
        "gravimetric_factor_model": delta_model,
        "gravimetric_factor_regression": slope * delta_model,
        "gravimetric_factor_regression_uncertainty": u_slope * delta_model,
        "gravimetric_factor_kalman": delta_model * (1.0 + est_admittance),
        "regression_variance_inflation": infl,
        "residual_rms_after_tide_removal_mps2": float(np.std(ch["correction.gravity_mps2"][sel] - ch["truth.static_gravity_mps2"][sel])),
        "residual_rms_without_tide_removal_mps2": float(np.std(ch["calibration.gravity_mps2"][sel] - ch["truth.static_gravity_mps2"][sel])),
        "baseline_gravity_mps2": float(ch["truth.static_gravity_mps2"][-1]),
        "tide_to_baseline_ratio": float(np.ptp(ch["tide.combined_mps2"]) / ch["truth.static_gravity_mps2"][-1]),
    }
    curves = {"lunar_mps2": ch["tide.lunar_mps2"], "solar_mps2": ch["tide.solar_mps2"],
              "combined_mps2": ch["tide.combined_mps2"],
              "measured_tide_mps2": ch["calibration.gravity_mps2"] - ch["truth.static_gravity_mps2"]}
    r = ExperimentResult("tides", DESCRIPTION, summary, t / 3600.0, "time_h", curves, manifest=res.manifest)
    r.simulation_results.append(res)
    return r


__all__ = ["run", "DESCRIPTION"]
