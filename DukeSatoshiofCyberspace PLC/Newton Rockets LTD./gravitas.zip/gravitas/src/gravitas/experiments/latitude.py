"""LATITUDE experiment: g from the equator to the pole, with rotation effects separated.

Curves: effective gravity (rotating oblate), oblate without rotation, spherical
non-rotating Earth, the centrifugal component along the plumb line, and
Somigliana's closed formula. Instrument occupations every 15° measure the
effective gravity through the full chain.
"""

from __future__ import annotations

import math

import numpy as np

from gravitas.earth.gravity import EarthGravityModel, EarthModelSwitches
from gravitas.earth.normal_gravity import somigliana, spherical_gravity
from gravitas.experiments.common import ExperimentResult
from gravitas.simulation.engine import SimulationEngine
from gravitas.simulation.scenario import SimulationConfig

DESCRIPTION = "Gravity vs latitude (equator → pole): effective, no-rotation, spherical; centrifugal component."

DEFAULT_STATIONS_DEG = (0.0, 15.0, 30.0, 45.0, 60.0, 75.0, 89.9)


def run(duration_s: float = 1800.0, sample_rate_hz: float = 10.0, seed: int = 20260101,
        config: SimulationConfig | None = None, stations_deg=DEFAULT_STATIONS_DEG) -> ExperimentResult:
    base = config or SimulationConfig(name="latitude")
    lon = math.radians(base.location.longitude_deg)
    lat_deg = np.linspace(0.0, 90.0, 181)
    lat = np.radians(lat_deg)
    full = EarthGravityModel()
    norot = EarthGravityModel(switches=EarthModelSwitches(earth_rotation=False))
    comp = full.components(lat, lon, np.zeros_like(lat))
    g_eff = comp["effective_mps2"]
    g_norot = norot.magnitude(lat, lon, np.zeros_like(lat))
    g_sph = np.full_like(lat, float(spherical_gravity(0.0)))
    cen_v = comp["centrifugal_vertical_mps2"]
    per = max(60.0, duration_s / len(stations_deg))
    meas, truth, unc, sims = [], [], [], []
    for i, ld in enumerate(stations_deg):
        cfg = base.model_copy(update={"duration_s": per, "sample_rate_hz": sample_rate_hz, "seed": seed + i,
                                      "location": base.location.model_copy(update={"latitude_deg": float(ld), "altitude_m": 0.0}),
                                      "settle_time_s": min(base.settle_time_s, per / 4)})
        res = SimulationEngine(cfg).run()
        est = res.final_estimate()
        meas.append(est.value)
        unc.append(est.expanded_uncertainty)
        truth.append(float(res["truth.static_gravity_mps2"][-1]))
        sims.append(res)
    meas, truth, unc = np.array(meas), np.array(truth), np.array(unc)
    summary = {
        "equator_effective_mps2": float(g_eff[0]),
        "pole_effective_mps2": float(g_eff[-1]),
        "equator_to_pole_difference_mps2": float(g_eff[-1] - g_eff[0]),
        "centrifugal_at_equator_mps2": float(-cen_v[0]),
        "rotation_effect_at_equator_mps2": float(g_norot[0] - g_eff[0]),
        "rotation_effect_at_pole_mps2": float(g_norot[-1] - g_eff[-1]),
        "max_series_minus_somigliana_mps2": float(np.max(np.abs(g_eff - somigliana(lat)))),
        "station_error_rms_mps2": float(np.sqrt(np.mean((meas - truth) ** 2))),
        "monotonic_increase": bool(np.all(np.diff(g_eff) > 0)),
    }
    tables = {"stations": {"latitude_deg": list(map(float, stations_deg)), "measured_mps2": meas.tolist(),
                           "true_mps2": truth.tolist(), "expanded_uncertainty_mps2": unc.tolist(),
                           "error_mps2": (meas - truth).tolist()}}
    curves = {"effective_mps2": g_eff, "no_rotation_mps2": g_norot, "spherical_mps2": g_sph,
              "centrifugal_vertical_mps2": cen_v, "somigliana_mps2": somigliana(lat)}
    r = ExperimentResult("latitude", DESCRIPTION, summary, lat_deg, "latitude_deg", curves, manifest=sims[0].manifest, tables=tables)
    r.simulation_results.extend(sims)
    return r


__all__ = ["run", "DESCRIPTION"]
