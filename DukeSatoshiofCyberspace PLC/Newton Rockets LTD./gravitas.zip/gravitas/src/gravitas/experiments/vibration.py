"""VIBRATION experiment: gravimeter on a vibrating platform.

The same seed is used for every filter variant, so the *raw* data are
bit-identical across variants and only the processing differs. Compares
platform acceleration, raw, filtered and corrected measurements, and reports
the RMS error versus truth for each filter.
"""

from __future__ import annotations

import numpy as np

from gravitas.experiments.common import ExperimentResult
from gravitas.simulation.engine import SimulationEngine
from gravitas.simulation.scenario import SimulationConfig

DESCRIPTION = "Vibrating platform: platform acceleration vs raw / filtered / corrected for several filters."

FILTER_VARIANTS = {
    "none": {"kind": "none"},
    "moving_average": {"kind": "moving_average", "window_s": 20.0},
    "lowpass": {"kind": "lowpass", "cutoff_hz": 0.02},
    "butterworth": {"kind": "butterworth", "cutoff_hz": 0.05, "order": 4},
    "kalman": {"kind": "kalman", "kalman_process_asd": 1.0e-10},
}


def run(duration_s: float = 1800.0, sample_rate_hz: float = 10.0, seed: int = 20260101,
        config: SimulationConfig | None = None, vibration_scale: float = 20.0) -> ExperimentResult:
    base = config or SimulationConfig(name="vibration")
    env = base.environment.model_copy(update={"vibration": base.environment.vibration.model_copy(update={"scale": vibration_scale})})
    results = {}
    for name, fs in FILTER_VARIANTS.items():
        cfg = base.model_copy(update={"duration_s": duration_s, "sample_rate_hz": sample_rate_hz, "seed": seed,
                                      "name": f"vibration-{name}", "environment": env,
                                      "filter": base.filter.model_copy(update=fs)})
        results[name] = SimulationEngine(cfg).run()
    ref = results["butterworth"]
    ch = ref.chain.channels
    t = ref.t_s
    sel = t >= 120.0
    truth = ch["truth.gravity_mps2"]
    static = ch["truth.static_gravity_mps2"]
    summary = {"vibration_scale": vibration_scale,
               "platform_rms_mps2": float(np.sqrt(np.mean(ch["environment.vibration_up_rms_mps2"][sel] ** 2))),
               "raw_rms_error_mps2": float(np.sqrt(np.mean((ch["raw.gravity_mps2"][sel] - truth[sel]) ** 2)))}
    rows = {"filter": [], "filtered_rms_error_mps2": [], "corrected_rms_error_mps2": [], "estimate_error_mps2": [],
            "reduction_factor": []}
    raw_rms = np.std(ch["raw.gravity_mps2"][sel] - truth[sel])
    for name, r in results.items():
        c = r.chain.channels
        f_err = np.std(c["filter.gravity_mps2"][sel] - truth[sel])
        c_err = np.sqrt(np.mean((c["correction.gravity_mps2"][sel] - static[sel]) ** 2))
        rows["filter"].append(name)
        rows["filtered_rms_error_mps2"].append(float(f_err))
        rows["corrected_rms_error_mps2"].append(float(c_err))
        rows["estimate_error_mps2"].append(float(c["estimate.gravity_mps2"][-1] - static[-1]))
        rows["reduction_factor"].append(float(raw_rms / f_err) if f_err > 0 else float("inf"))
        summary[f"{name}_filtered_scatter_mps2"] = float(f_err)
    # raw data identity across variants (same seed ⇒ same raw)
    summary["raw_identical_across_filters"] = bool(all(np.array_equal(r["raw.gravity_mps2"], ch["raw.gravity_mps2"])
                                                       for r in results.values()))
    g0 = float(static[-1])
    curves = {"platform_up_mps2": ch["environment.vibration_up_mps2"],
              "raw_minus_static_mps2": ch["raw.gravity_mps2"] - g0,
              "filtered_minus_static_mps2": ch["filter.gravity_mps2"] - g0,
              "corrected_minus_static_mps2": ch["correction.gravity_mps2"] - g0,
              "kalman_filtered_minus_static_mps2": results["kalman"]["filter.gravity_mps2"] - g0}
    r = ExperimentResult("vibration", DESCRIPTION, summary, t, "time_s", curves, manifest=ref.manifest, tables={"filters": rows})
    r.simulation_results.extend(results.values())
    return r


__all__ = ["run", "DESCRIPTION", "FILTER_VARIANTS"]
