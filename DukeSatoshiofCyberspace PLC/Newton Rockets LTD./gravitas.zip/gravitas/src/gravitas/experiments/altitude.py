"""ALTITUDE experiment: g vs altitude (model curves + instrument occupations).

Model curves (0–10 km): rotating oblate Earth (zonal series), spherical Earth
GM/(R+h)², and the closed-form free-air formula. Instrument stations: short
static occupations at several heights (the meter is re-nulled per station),
from which the free-air gradient is estimated by least squares and compared
with the model gradient.
"""

from __future__ import annotations

import math

import numpy as np

from gravitas.earth.gravity import EarthGravityModel
from gravitas.earth.normal_gravity import normal_gravity_free_air, spherical_gravity
from gravitas.estimation.calibration import linear_fit
from gravitas.experiments.common import ExperimentResult
from gravitas.simulation.engine import SimulationEngine
from gravitas.simulation.scenario import SimulationConfig

DESCRIPTION = "Gravity vs altitude: model curves and instrument occupations; free-air gradient recovery."

DEFAULT_STATIONS_M = (0.0, 50.0, 100.0, 250.0, 500.0, 1000.0)


def run(duration_s: float = 1800.0, sample_rate_hz: float = 10.0, seed: int = 20260101,
        config: SimulationConfig | None = None, stations_m=DEFAULT_STATIONS_M) -> ExperimentResult:
    base = config or SimulationConfig(name="altitude")
    lat = math.radians(base.location.latitude_deg)
    lon = math.radians(base.location.longitude_deg)
    h = np.linspace(0.0, 10_000.0, 201)
    model = EarthGravityModel()
    g_series = model.magnitude(np.full(h.size, lat), lon, h)
    g_sph = spherical_gravity(h)
    g_fa = normal_gravity_free_air(lat, h)
    per = max(60.0, duration_s / len(stations_m))
    meas, unc, truth = [], [], []
    sims = []
    for i, hs in enumerate(stations_m):
        cfg = base.model_copy(update={"duration_s": per, "sample_rate_hz": sample_rate_hz, "seed": seed + i,
                                      "location": base.location.model_copy(update={"altitude_m": float(hs)}),
                                      "settle_time_s": min(base.settle_time_s, per / 4)})
        res = SimulationEngine(cfg).run()
        est = res.final_estimate()
        meas.append(est.value)
        unc.append(est.expanded_uncertainty)
        truth.append(float(res["truth.static_gravity_mps2"][-1]))
        sims.append(res)
    st = np.array(stations_m, float)
    meas, unc, truth = np.array(meas), np.array(unc), np.array(truth)
    a, b, ua, ub, rms = linear_fit(st, meas)
    gm = model.vertical_gradient(lat, lon, 0.0)
    summary = {
        "model_free_air_gradient_mps2_per_m": gm,
        "measured_free_air_gradient_mps2_per_m": b,
        "measured_gradient_uncertainty_mps2_per_m": ub,
        "gradient_relative_error": (b - gm) / gm,
        "g_at_0m_series_mps2": float(g_series[0]),
        "g_at_10km_series_mps2": float(g_series[-1]),
        "spherical_minus_series_at_0m_mps2": float(g_sph[0] - g_series[0]),
        "free_air_formula_minus_series_at_10km_mps2": float(g_fa[-1] - g_series[-1]),
        "station_error_rms_mps2": float(np.sqrt(np.mean((meas - truth) ** 2))),
        "monotonic_decrease": bool(np.all(np.diff(g_series) < 0)),
    }
    tables = {"stations": {"altitude_m": st.tolist(), "measured_mps2": meas.tolist(), "expanded_uncertainty_mps2": unc.tolist(),
                           "true_mps2": truth.tolist(), "error_mps2": (meas - truth).tolist()}}
    curves = {"rotating_oblate_mps2": g_series, "spherical_mps2": g_sph, "free_air_formula_mps2": g_fa}
    r = ExperimentResult("altitude", DESCRIPTION, summary, h, "altitude_m", curves, manifest=sims[0].manifest, tables=tables)
    r.simulation_results.extend(sims)
    return r


__all__ = ["run", "DESCRIPTION"]
