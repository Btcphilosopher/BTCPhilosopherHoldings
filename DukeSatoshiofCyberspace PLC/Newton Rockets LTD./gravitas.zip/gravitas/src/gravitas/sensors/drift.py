"""Instrument drift (slowly varying bias).

MODEL
    d(t) = r · t + q · t² + A (1 − e^{−t/τ_s}) + w(t)
    r     linear drift rate [m/s² per s]  (spring creep; typical 1–100 µGal/day)
    q     quadratic term   [m/s² per s²]
    A, τ_s exponential settling after transport / clamping
    w(t)  bias random walk, dw = σ_rw dW   [m/s² /√s]

    Random-walk increments are drawn per output sample from a dedicated random
    stream, so the drift realisation is identical regardless of chunking.
"""

from __future__ import annotations

import math
from dataclasses import dataclass

import numpy as np


@dataclass
class DriftConfig:
    linear_rate_mps2_per_s: float = 0.0
    quadratic_mps2_per_s2: float = 0.0
    settling_amplitude_mps2: float = 0.0
    settling_time_constant_s: float = 3600.0
    random_walk_mps2_per_rts: float = 0.0

    def __post_init__(self) -> None:
        if self.settling_time_constant_s <= 0:
            raise ValueError("settling time constant must be positive")
        if self.random_walk_mps2_per_rts < 0:
            raise ValueError("random-walk coefficient must be non-negative")


class DriftModel:
    def __init__(self, cfg: DriftConfig, rng: np.random.Generator):
        self.cfg = cfg
        self.rng = rng
        self._walk = 0.0

    def deterministic(self, t_s) -> np.ndarray:
        c = self.cfg
        t = np.asarray(t_s, dtype=float)
        return (c.linear_rate_mps2_per_s * t + c.quadratic_mps2_per_s2 * t * t
                + c.settling_amplitude_mps2 * (1.0 - np.exp(-t / c.settling_time_constant_s)))

    def step(self, t_s: np.ndarray, dt_s: float) -> dict[str, np.ndarray]:
        n = t_s.size
        dw = self.rng.standard_normal(n) * self.cfg.random_walk_mps2_per_rts * math.sqrt(dt_s)
        # sequential accumulation from the carried state ⇒ bit-identical under any chunking
        walk = np.cumsum(np.concatenate([[self._walk], dw]))[1:]
        if n:
            self._walk = float(walk[-1])
        det = self.deterministic(t_s)
        return {"deterministic_mps2": det, "random_walk_mps2": walk, "total_mps2": det + walk}


__all__ = ["DriftConfig", "DriftModel"]
