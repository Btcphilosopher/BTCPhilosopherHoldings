"""Stochastic sensor noise models (equivalent input acceleration).

WHITE NOISE
    One-sided amplitude spectral density n_w [m/s² /√Hz]. Sampled at rate f_s
    the per-sample standard deviation is σ = n_w √(f_s / 2).
    Allan deviation: σ_A(τ) = n_w / √(2τ)   (slope −½).

LOW-FREQUENCY (CORRELATED) NOISE
    Sum of K independent first-order Gauss–Markov processes with correlation
    times log-spaced in [τ_min, τ_max]:
        x_i[k+1] = φ_i x_i[k] + σ_i √(1 − φ_i²) ε,  φ_i = e^{−Δt/τ_i}
    Each process has stationary std σ_i = σ_GM / √K. A log-spaced ensemble of
    equal-variance GM processes approximates 1/f (flicker) noise between
    1/(2πτ_max) and 1/(2πτ_min), giving the flat Allan-deviation region that
    is identified as "bias instability". The exact discretisation keeps the
    process stationary for any Δt.

All generators are stateful and draw from dedicated random streams so that
chunked and one-shot simulations are bit-identical.
"""

from __future__ import annotations

import math
from dataclasses import dataclass

import numpy as np
from scipy.signal import lfilter


@dataclass
class NoiseConfig:
    white_asd_mps2_per_rthz: float = 3.0e-8  #: 3 µGal/√Hz
    correlated_sigma_mps2: float = 0.0
    correlated_tau_min_s: float = 10.0
    correlated_tau_max_s: float = 10_000.0
    correlated_components: int = 5

    def __post_init__(self) -> None:
        if self.white_asd_mps2_per_rthz < 0 or self.correlated_sigma_mps2 < 0:
            raise ValueError("noise levels must be non-negative")
        if not (0 < self.correlated_tau_min_s <= self.correlated_tau_max_s):
            raise ValueError("require 0 < tau_min <= tau_max")
        if self.correlated_components < 1:
            raise ValueError("need at least one correlated component")


class WhiteNoise:
    def __init__(self, asd_mps2_per_rthz: float, sample_rate_hz: float, rng: np.random.Generator):
        self.asd = asd_mps2_per_rthz
        self.sample_rate_hz = sample_rate_hz
        self.rng = rng

    @property
    def sigma(self) -> float:
        return self.asd * math.sqrt(self.sample_rate_hz / 2.0)

    def step(self, n: int) -> np.ndarray:
        return self.rng.standard_normal(n) * self.sigma


class GaussMarkovEnsemble:
    def __init__(self, cfg: NoiseConfig, dt_s: float, rng: np.random.Generator):
        self.cfg = cfg
        self.rng = rng
        k = cfg.correlated_components
        self.taus = np.geomspace(cfg.correlated_tau_min_s, cfg.correlated_tau_max_s, k)
        self.phi = np.exp(-dt_s / self.taus)
        self.sig = cfg.correlated_sigma_mps2 / math.sqrt(k)
        # stationary initial state
        self.state = self.rng.standard_normal(k) * self.sig

    def step(self, n: int) -> np.ndarray:
        k = self.taus.size
        eps = self.rng.standard_normal((n, k))
        out = np.zeros(n)
        for i in range(k):
            drive = eps[:, i] * self.sig * math.sqrt(1.0 - self.phi[i] ** 2)
            y, zf = lfilter([1.0], [1.0, -self.phi[i]], drive, zi=[self.phi[i] * self.state[i]])
            self.state[i] = y[-1] if n else self.state[i]
            out += y
        return out


__all__ = ["NoiseConfig", "WhiteNoise", "GaussMarkovEnsemble"]
