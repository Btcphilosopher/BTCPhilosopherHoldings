"""Sensor bias models (equivalent input acceleration, m/s²).

MODEL
    b(t) = b₀ + b_T(t)
    b₀           constant zero offset (e.g. pretension / range-screw error)
    b_T(t)       temperature-induced bias  b_T = c_T · (T(t) − T_ref)

    Slowly varying bias (drift, random walk, bias instability) lives in
    :mod:`gravitas.sensors.drift` and :mod:`gravitas.sensors.noise` so that each
    process stays separately inspectable.

EQUATIONS
    bias(T) = coefficient × (T − T_reference)       (linear temperature model)
"""

from __future__ import annotations

import math
from dataclasses import dataclass

import numpy as np


@dataclass
class ConstantBias:
    bias_mps2: float = 0.0

    def __post_init__(self) -> None:
        if not math.isfinite(self.bias_mps2):
            raise ValueError("bias must be finite")

    def evaluate(self, n: int) -> np.ndarray:
        return np.full(n, self.bias_mps2)


@dataclass
class TemperatureBias:
    coefficient_mps2_per_k: float = 0.0
    reference_temperature_c: float = 20.0

    def __post_init__(self) -> None:
        if not (math.isfinite(self.coefficient_mps2_per_k) and math.isfinite(self.reference_temperature_c)):
            raise ValueError("temperature bias parameters must be finite")

    def evaluate(self, temperature_c) -> np.ndarray:
        return self.coefficient_mps2_per_k * (np.asarray(temperature_c, dtype=float) - self.reference_temperature_c)


__all__ = ["ConstantBias", "TemperatureBias"]
