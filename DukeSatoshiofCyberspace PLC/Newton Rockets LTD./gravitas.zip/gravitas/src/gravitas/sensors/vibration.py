"""Platform vibration (ground / vehicle acceleration) model.

MODEL
    a_platform(t) = Σ_i A_i sin(2π f_i t + φ_i) ê_i  +  band-limited Gaussian noise
    Default spectrum (vertical): secondary microseism (0.15 Hz) plus cultural
    noise (8 Hz) plus broadband noise band-passed 0.05–20 Hz (4th-order
    Butterworth). Horizontal components use the same structure with their own
    amplitudes and phases.

    Phases are drawn once from the vibration random stream at construction;
    broadband noise uses a stateful IIR filter (``sosfilt`` with carried
    initial conditions) so chunked runs equal one-shot runs.

PHYSICAL NOTE
    A zero-mean vibration does not bias the *mean* reading of a linear
    instrument; it adds variance. Non-linear coupling (cross-axis + tilt,
    stop contact, ADC clipping, fringe loss) can rectify it into a bias — these
    paths are modelled explicitly elsewhere.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field

import numpy as np
from scipy.signal import butter, sosfilt, sosfilt_zi


@dataclass
class VibrationLine:
    frequency_hz: float
    amplitude_mps2: float
    axis: int = 2  #: 0 = East, 1 = North, 2 = Up


@dataclass
class VibrationConfig:
    lines: list[VibrationLine] = field(default_factory=lambda: [
        VibrationLine(0.15, 2.0e-7, 2), VibrationLine(0.15, 1.5e-7, 0), VibrationLine(0.17, 1.5e-7, 1),
        VibrationLine(8.0, 5.0e-6, 2),
    ])
    broadband_rms_mps2: tuple[float, float, float] = (5.0e-7, 5.0e-7, 1.0e-6)
    band_hz: tuple[float, float] = (0.5, 20.0)
    scale: float = 1.0  #: overall multiplier (vibration experiment sweeps this)

    def __post_init__(self) -> None:
        if self.band_hz[0] <= 0 or self.band_hz[1] <= self.band_hz[0]:
            raise ValueError("vibration band must satisfy 0 < f_lo < f_hi")
        if self.scale < 0:
            raise ValueError("vibration scale must be non-negative")


class VibrationModel:
    def __init__(self, cfg: VibrationConfig, sample_rate_hz: float, rng: np.random.Generator, enabled: bool = True):
        self.cfg = cfg
        self.fs = sample_rate_hz
        self.rng = rng
        self.enabled = enabled
        self.phases = rng.uniform(0.0, 2.0 * math.pi, len(cfg.lines))
        nyq = 0.5 * sample_rate_hz
        hi = min(cfg.band_hz[1], 0.45 * sample_rate_hz)
        lo = min(cfg.band_hz[0], 0.5 * hi)
        self.sos = butter(4, [lo / nyq, hi / nyq], btype="bandpass", output="sos")
        # normalise the broadband filter to unit output variance for unit white input
        imp = np.zeros(int(20 * sample_rate_hz / lo) + 1)
        imp[0] = 1.0
        h = sosfilt(self.sos, imp)
        self.gain = 1.0 / math.sqrt(float(np.sum(h * h)))
        self.zi = [np.zeros((self.sos.shape[0], 2)) for _ in range(3)]

    def step(self, t_s: np.ndarray) -> np.ndarray:
        """Platform acceleration ENU (N, 3) [m/s²] at internal-rate times ``t_s``."""
        n = t_s.size
        w = self.rng.standard_normal((n, 3))
        out = np.zeros((n, 3))
        for ax in range(3):
            y, self.zi[ax] = sosfilt(self.sos, w[:, ax] * self.gain, zi=self.zi[ax])
            out[:, ax] = y * self.cfg.broadband_rms_mps2[ax]
        for line, ph in zip(self.cfg.lines, self.phases):
            out[:, line.axis] += line.amplitude_mps2 * np.sin(2.0 * math.pi * line.frequency_hz * t_s + ph)
        if not self.enabled:
            return np.zeros_like(out)
        return out * self.cfg.scale


__all__ = ["VibrationLine", "VibrationConfig", "VibrationModel"]
