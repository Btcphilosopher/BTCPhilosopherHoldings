"""Cross-axis sensitivity and levelling (tilt) error.

MODEL
    A levelled gravimeter's sensitive axis is aligned with the plumb line to
    within a tilt (θ_E, θ_N). The specific force projected on the tilted axis is

        a_axis = (g + a_U) cos θ + a_E sin θ_E' + a_N sin θ_N'

    For small angles (θ = |θ|):
        a_axis ≈ (g + a_U)(1 − θ²/2) + θ_E a_E + θ_N a_N
    Additional *electromechanical* cross-coupling (imperfect suspension
    geometry) adds c_E a_E + c_N a_N.

EQUATIONS
    leak    = (θ_E + c_E) a_E + (θ_N + c_N) a_N
    tilt    = −(g + a_U) θ² / 2          (always reduces the reading)

    With θ = 10 µrad the tilt term is −0.05 µGal; with θ = 100 µrad, −4.9 µGal.
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np


@dataclass
class CrossAxisConfig:
    coupling_east: float = 1.0e-4
    coupling_north: float = 1.0e-4
    tilt_east_rad: float = 5.0e-6
    tilt_north_rad: float = 5.0e-6


class CrossAxisModel:
    def __init__(self, cfg: CrossAxisConfig):
        self.cfg = cfg

    @property
    def tilt_rad(self) -> float:
        return float(np.hypot(self.cfg.tilt_east_rad, self.cfg.tilt_north_rad))

    def leakage(self, a_east, a_north) -> np.ndarray:
        c = self.cfg
        return (c.tilt_east_rad + c.coupling_east) * np.asarray(a_east) + (c.tilt_north_rad + c.coupling_north) * np.asarray(a_north)

    def tilt_term(self, g_vertical) -> np.ndarray:
        th2 = self.cfg.tilt_east_rad**2 + self.cfg.tilt_north_rad**2
        return -np.asarray(g_vertical, dtype=float) * th2 / 2.0


__all__ = ["CrossAxisConfig", "CrossAxisModel"]
