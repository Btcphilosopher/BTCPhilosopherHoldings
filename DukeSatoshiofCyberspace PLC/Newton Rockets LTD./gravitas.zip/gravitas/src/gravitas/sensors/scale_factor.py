"""Scale-factor model.

MODEL
    y = S · x      with x = a − g_ref (the deviation the spring actually measures)
    S = 1 + ε_S + α_S (T − T_ref)

    Physically ε_S is the mismatch between the true and the nominal spring
    constant (or actuator force constant in feedback mode), and α_S its
    temperature coefficient. Because a spring gravimeter is a *relative*
    instrument, S multiplies the deviation from the nulled reference g_ref, not
    the full 9.8 m/s².
"""

from __future__ import annotations

import math
from dataclasses import dataclass

import numpy as np


@dataclass
class ScaleFactor:
    error_ppm: float = 0.0
    temperature_coefficient_ppm_per_k: float = 0.0
    reference_temperature_c: float = 20.0

    def __post_init__(self) -> None:
        if not (math.isfinite(self.error_ppm) and abs(self.error_ppm) < 1e5):
            raise ValueError("scale-factor error must be finite and < 10 %")

    @property
    def nominal(self) -> float:
        return 1.0 + self.error_ppm * 1e-6

    def factor(self, temperature_c=None) -> np.ndarray | float:
        s = self.nominal
        if temperature_c is None or self.temperature_coefficient_ppm_per_k == 0.0:
            return s if temperature_c is None else np.full(np.shape(temperature_c), s)
        dt = np.asarray(temperature_c, dtype=float) - self.reference_temperature_c
        return s + self.temperature_coefficient_ppm_per_k * 1e-6 * dt

    def apply(self, x, temperature_c=None):
        """y = S x."""
        return self.factor(temperature_c) * np.asarray(x, dtype=float)


__all__ = ["ScaleFactor"]
