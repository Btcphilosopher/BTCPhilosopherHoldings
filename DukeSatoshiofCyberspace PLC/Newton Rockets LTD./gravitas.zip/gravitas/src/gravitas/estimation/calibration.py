"""Instrument calibration: model, inversion and least-squares estimation.

SENSOR MODEL (deviation domain, Δ = value − g_ref)
    Δraw(t) = S · Δa(t) + b₀ + c_T (T_m(t) − T_ref) + r (t − t₀) + noise

CALIBRATION (inverse model)
    Δcal(t) = [Δraw(t) − b̂₀ − ĉ_T (T_m(t) − T_ref) − r̂ (t − t₀)] / Ŝ

PROCEDURES
    zero calibration        occupy a reference station of known gravity:
                            b̂₀ = mean(Δraw − Δref); u(b̂₀) from the Allan
                            deviation at the occupation length.
    scale-factor            occupy ≥ 2 stations with known Δg (calibration
                            line); Ŝ = slope of Δraw vs Δref.
    temperature             thermal-chamber steps; ĉ_T = slope of residual vs T.
    drift                   long occupation; r̂ = slope of residual vs t.
    joint (recommended)     weighted least squares on all data with design
                            matrix A = [1, Δref, (T_m − T_ref), (t − t₀)];
                            θ = (AᵀA)⁻¹Aᵀy, Cov(θ) = s² (AᵀA)⁻¹,
                            with data block-averaged, s² the residual variance
                            inflated for residual serial correlation (AR(1):
                            ×(1+ρ)/(1−ρ)), plus the exactly propagated
                            station reference-value errors. Ŝ = θ₁.
"""

from __future__ import annotations

import math
from dataclasses import asdict, dataclass, field

import numpy as np


@dataclass
class CalibrationParameters:
    """Calibration coefficients applied by the correction stage (with uncertainties)."""

    bias_mps2: float = 0.0
    scale_factor: float = 1.0
    temperature_coefficient_mps2_per_k: float = 0.0
    reference_temperature_c: float = 20.0
    drift_rate_mps2_per_s: float = 0.0
    drift_epoch_s: float = 0.0
    u_bias_mps2: float = 0.0
    u_scale_factor: float = 0.0
    u_temperature_coefficient_mps2_per_k: float = 0.0
    u_drift_rate_mps2_per_s: float = 0.0
    u_reference_mps2: float = 0.0  #: uncertainty of the calibration reference values themselves
    source: str = "nominal (uncalibrated)"
    covariance: list | None = None

    def __post_init__(self) -> None:
        if not (self.scale_factor > 0 and math.isfinite(self.scale_factor)):
            raise ValueError("scale factor must be positive")

    def apply(self, raw_dev, temperature_measured_c, t_s):
        raw = np.asarray(raw_dev, dtype=float)
        tm = np.asarray(temperature_measured_c, dtype=float)
        t = np.asarray(t_s, dtype=float)
        corr = (self.bias_mps2 + self.temperature_coefficient_mps2_per_k * (tm - self.reference_temperature_c)
                + self.drift_rate_mps2_per_s * (t - self.drift_epoch_s))
        return (raw - corr) / self.scale_factor

    def to_dict(self) -> dict:
        return asdict(self)

    @classmethod
    def from_dict(cls, d: dict) -> "CalibrationParameters":
        return cls(**d)


@dataclass
class CalibrationFit:
    parameters: CalibrationParameters
    residual_rms_mps2: float
    n_used: int
    design_columns: list[str]
    theta: np.ndarray
    covariance: np.ndarray
    extra: dict = field(default_factory=dict)


def _decimate(arrs: list[np.ndarray], stride: int) -> list[np.ndarray]:
    """Block-average each array over ``stride`` samples (approximate whitening)."""
    if stride <= 1:
        return arrs
    n = (arrs[0].size // stride) * stride
    return [a[:n].reshape(-1, stride).mean(axis=1) for a in arrs]


def zero_calibration(raw_dev: np.ndarray, reference_dev: np.ndarray, stride: int = 1) -> tuple[float, float]:
    """(b̂₀, u(b̂₀)) from an occupation of a reference station."""
    r = np.asarray(raw_dev, float) - np.asarray(reference_dev, float)
    (rd,) = _decimate([r], stride)
    if rd.size < 2:
        raise ValueError("need at least 2 (decimated) samples for zero calibration")
    return float(rd.mean()), float(rd.std(ddof=1) / math.sqrt(rd.size))


def linear_fit(x: np.ndarray, y: np.ndarray) -> tuple[float, float, float, float, float]:
    """OLS y = a + b x → (a, b, u_a, u_b, residual_rms)."""
    x = np.asarray(x, float)
    y = np.asarray(y, float)
    a_mat = np.column_stack([np.ones_like(x), x])
    theta, *_ = np.linalg.lstsq(a_mat, y, rcond=None)
    res = y - a_mat @ theta
    dof = max(1, y.size - 2)
    s2 = float(res @ res) / dof
    cov = s2 * np.linalg.inv(a_mat.T @ a_mat)
    return float(theta[0]), float(theta[1]), float(math.sqrt(cov[0, 0])), float(math.sqrt(cov[1, 1])), float(math.sqrt(s2))


def scale_factor_calibration(raw_dev: np.ndarray, reference_dev: np.ndarray, stride: int = 1) -> dict:
    x, y = _decimate([np.asarray(reference_dev, float), np.asarray(raw_dev, float)], stride)
    a, b, ua, ub, rms = linear_fit(x, y)
    return {"scale_factor": b, "u_scale_factor": ub, "offset_mps2": a, "u_offset_mps2": ua, "residual_rms_mps2": rms}


def temperature_calibration(residual: np.ndarray, temperature_c: np.ndarray, reference_temperature_c: float,
                            stride: int = 1) -> dict:
    x, y = _decimate([np.asarray(temperature_c, float) - reference_temperature_c, np.asarray(residual, float)], stride)
    a, b, ua, ub, rms = linear_fit(x, y)
    return {"temperature_coefficient_mps2_per_k": b, "u_temperature_coefficient_mps2_per_k": ub,
            "offset_mps2": a, "residual_rms_mps2": rms}


def drift_estimation(residual: np.ndarray, t_s: np.ndarray, stride: int = 1) -> dict:
    x, y = _decimate([np.asarray(t_s, float), np.asarray(residual, float)], stride)
    a, b, ua, ub, rms = linear_fit(x, y)
    return {"drift_rate_mps2_per_s": b, "u_drift_rate_mps2_per_s": ub, "offset_mps2": a, "residual_rms_mps2": rms}


def ar1_inflation(residuals: np.ndarray) -> tuple[float, float]:
    """(ρ₁, inflation) for serially correlated residuals.

    With lag-1 autocorrelation ρ the effective sample size of an AR(1) process
    is n_eff = n (1 − ρ)/(1 + ρ); parameter variances from OLS are inflated by
    (1 + ρ)/(1 − ρ). Negative ρ is not used to deflate (conservative).
    """
    r = np.asarray(residuals, float) - np.mean(residuals)
    if r.size < 3 or not np.any(r):
        return 0.0, 1.0
    rho = float(np.sum(r[1:] * r[:-1]) / np.sum(r * r))
    rho_c = min(max(rho, 0.0), 0.99)
    return rho, (1.0 + rho_c) / (1.0 - rho_c)


def joint_calibration(raw_dev: np.ndarray, reference_dev: np.ndarray, temperature_c: np.ndarray, t_s: np.ndarray,
                      reference_temperature_c: float = 20.0, drift_epoch_s: float = 0.0, stride: int = 1,
                      fit_temperature: bool = True, fit_drift: bool = True, u_reference_mps2: float = 0.0,
                      station_ids: np.ndarray | None = None) -> CalibrationFit:
    """Joint least-squares estimate of (b₀, S, c_T, r) from calibration-campaign data.

    Covariance = AR(1)-inflated residual covariance  +  propagated reference-value
    errors. Reference errors are *common to all samples of one station*
    (``station_ids``), so they are propagated exactly as
    Cov_ref = u_ref² (A⁺Z)(A⁺Z)ᵀ, with Z the station indicator matrix and A⁺ the
    least-squares pseudo-inverse.
    """
    raw, ref, tm, t = (np.asarray(a, float) for a in (raw_dev, reference_dev, temperature_c, t_s))
    if not (raw.shape == ref.shape == tm.shape == t.shape):
        raise ValueError("calibration arrays must have equal shapes")
    sid = None if station_ids is None else np.asarray(station_ids)
    if sid is not None and stride > 1:
        n_keep = (sid.size // stride) * stride
        sid = sid[:n_keep].reshape(-1, stride)[:, 0]
    raw, ref, tm, t = _decimate([raw, ref, tm, t], stride)
    cols = [np.ones_like(ref), ref]
    names = ["bias", "scale_factor"]
    if fit_temperature:
        cols.append(tm - reference_temperature_c)
        names.append("temperature_coefficient")
    if fit_drift:
        cols.append(t - drift_epoch_s)
        names.append("drift_rate")
    a_mat = np.column_stack(cols)
    # column scaling for conditioning
    scale = np.max(np.abs(a_mat), axis=0)
    scale[scale == 0] = 1.0
    a_s = a_mat / scale
    theta_s, *_ = np.linalg.lstsq(a_s, raw, rcond=None)
    res = raw - a_s @ theta_s
    dof = max(1, raw.size - a_mat.shape[1])
    s2 = float(res @ res) / dof
    rho, infl = ar1_inflation(res)
    ata_inv = np.linalg.inv(a_s.T @ a_s)
    cov_s = s2 * infl * ata_inv
    if sid is not None and u_reference_mps2 > 0:
        stations = np.unique(sid)
        z = (sid[:, None] == stations[None, :]).astype(float)
        apz = ata_inv @ a_s.T @ z
        cov_s = cov_s + u_reference_mps2**2 * apz @ apz.T
    theta = theta_s / scale
    cov = cov_s / np.outer(scale, scale)
    u = np.sqrt(np.diag(cov))
    get = dict(zip(names, zip(theta, u)))
    params = CalibrationParameters(
        bias_mps2=float(get["bias"][0]), scale_factor=float(get["scale_factor"][0]),
        temperature_coefficient_mps2_per_k=float(get.get("temperature_coefficient", (0.0, 0.0))[0]),
        reference_temperature_c=reference_temperature_c,
        drift_rate_mps2_per_s=float(get.get("drift_rate", (0.0, 0.0))[0]), drift_epoch_s=drift_epoch_s,
        u_bias_mps2=float(get["bias"][1]), u_scale_factor=float(get["scale_factor"][1]),
        u_temperature_coefficient_mps2_per_k=float(get.get("temperature_coefficient", (0.0, 0.0))[1]),
        u_drift_rate_mps2_per_s=float(get.get("drift_rate", (0.0, 0.0))[1]),
        u_reference_mps2=u_reference_mps2,
        source="joint least-squares calibration", covariance=cov.tolist(),
    )
    return CalibrationFit(params, math.sqrt(s2), raw.size, names, theta, cov,
                          extra={"lag1_autocorrelation": rho, "variance_inflation": infl})


__all__ = [
    "CalibrationParameters", "CalibrationFit", "zero_calibration", "linear_fit", "scale_factor_calibration",
    "temperature_calibration", "drift_estimation", "joint_calibration", "ar1_inflation",
]
