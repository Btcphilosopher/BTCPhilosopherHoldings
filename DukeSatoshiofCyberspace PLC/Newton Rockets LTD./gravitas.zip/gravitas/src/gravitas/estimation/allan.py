"""Allan deviation and noise identification.

DEFINITION (overlapping Allan variance, IEEE Std 952 / 1139)
    For a rate-like signal y sampled at τ₀ with averaging factor m (τ = m τ₀),
    using the cumulative sum X_k = τ₀ Σ_{i<k} y_i:

        σ²(τ) = 1 / (2 τ² (N − 2m)) Σ_{k=0}^{N−2m−1} (X_{k+2m} − 2 X_{k+m} + X_k)²

    which is O(N) per τ.

CONFIDENCE INTERVALS
    χ² with equivalent degrees of freedom; for white FM noise (Howe et al. 1981)
        edf ≈ (3(N−1)/(2m) − 2(N−2)/N) · 4m² / (4m² + 5).
    Interval: [σ √(edf/χ²_{0.975}), σ √(edf/χ²_{0.025})].

NOISE IDENTIFICATION (log-log slopes of σ(τ))
    −1   quantisation / white phase-like
    −½   white noise (velocity/acceleration random walk); coefficient N = σ(τ)·√(2τ)… reported as ASD
     0   bias instability (flicker); B = σ_min / 0.664
    +½   random walk of the bias
    +1   linear drift (rate R: σ = R τ / √2)
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field

import numpy as np
from scipy.stats import chi2


@dataclass
class AllanResult:
    tau_s: np.ndarray
    adev: np.ndarray
    adev_lo: np.ndarray
    adev_hi: np.ndarray
    n_terms: np.ndarray
    n_samples: int
    sample_interval_s: float
    identification: dict = field(default_factory=dict)

    def to_dict(self) -> dict:
        return {"tau_s": self.tau_s.tolist(), "adev_mps2": self.adev.tolist(), "adev_lo_mps2": self.adev_lo.tolist(),
                "adev_hi_mps2": self.adev_hi.tolist(), "n_terms": self.n_terms.tolist(), "n_samples": self.n_samples,
                "sample_interval_s": self.sample_interval_s, "identification": self.identification}

    def at(self, tau_s: float) -> float:
        """Log-log interpolation of σ(τ); white-noise extrapolation beyond the last τ."""
        if tau_s <= self.tau_s[0]:
            return float(self.adev[0] * math.sqrt(self.tau_s[0] / tau_s))
        if tau_s >= self.tau_s[-1]:
            return float(self.adev[-1] * math.sqrt(self.tau_s[-1] / tau_s))
        return float(np.exp(np.interp(np.log(tau_s), np.log(self.tau_s), np.log(self.adev))))


def log_spaced_factors(n: int, points_per_decade: int = 10, max_fraction: float = 0.25) -> np.ndarray:
    m_max = max(1, int(n * max_fraction))
    ms = np.unique(np.round(np.logspace(0, math.log10(m_max), max(2, int(points_per_decade * math.log10(max(m_max, 10))) + 1))).astype(int))
    return ms[ms >= 1]


def overlapping_adev(y: np.ndarray, sample_interval_s: float, factors: np.ndarray | None = None,
                     confidence: float = 0.683) -> AllanResult:
    y = np.asarray(y, dtype=float)
    if y.ndim != 1 or y.size < 8:
        raise ValueError("Allan deviation needs a 1-D series of at least 8 samples")
    if not np.all(np.isfinite(y)):
        raise ValueError("Allan deviation input contains non-finite values")
    n = y.size
    t0 = float(sample_interval_s)
    if factors is None:
        factors = log_spaced_factors(n)
    y0 = y - y.mean()  # offset-invariant; improves conditioning of the cumulative sum
    x = np.concatenate([[0.0], np.cumsum(y0) * t0])
    taus, devs, lo, hi, nts = [], [], [], [], []
    a = (1.0 - confidence) / 2.0
    for m in factors:
        m = int(m)
        if n - 2 * m < 1:
            continue
        d = x[2 * m:] - 2.0 * x[m:-m] + x[:-2 * m]
        tau = m * t0
        avar = float(np.sum(d * d)) / (2.0 * tau * tau * d.size)
        dev = math.sqrt(avar)
        edf = (3.0 * (n - 1) / (2.0 * m) - 2.0 * (n - 2) / n) * 4.0 * m * m / (4.0 * m * m + 5.0)
        edf = max(edf, 1.0)
        taus.append(tau)
        devs.append(dev)
        lo.append(dev * math.sqrt(edf / chi2.ppf(1.0 - a, edf)))
        hi.append(dev * math.sqrt(edf / chi2.ppf(a, edf)))
        nts.append(d.size)
    res = AllanResult(np.array(taus), np.array(devs), np.array(lo), np.array(hi), np.array(nts), n, t0)
    res.identification = identify_noise(res)
    return res


_SLOPE_LABELS = [(-1.0, "quantisation / white phase"), (-0.5, "white noise"), (0.0, "bias instability (flicker)"),
                 (0.5, "bias random walk"), (1.0, "drift (linear rate)")]


def identify_noise(res: AllanResult) -> dict:
    tau, dev = res.tau_s, res.adev
    if tau.size < 3:
        return {"regions": []}
    lt, ld = np.log10(tau), np.log10(dev)
    slope = np.gradient(ld, lt)
    # label each τ by the nearest canonical slope, then merge contiguous runs
    labels = [min(_SLOPE_LABELS, key=lambda s: abs(s[0] - sl)) for sl in slope]
    regions = []
    start = 0
    for i in range(1, len(labels) + 1):
        if i == len(labels) or labels[i][1] != labels[start][1]:
            seg = slice(start, i)
            if i - start >= 2:
                fit = np.polyfit(lt[seg], ld[seg], 1)[0]
            else:
                fit = float(slope[start])
            regions.append({"tau_from_s": float(tau[start]), "tau_to_s": float(tau[i - 1]),
                            "slope": float(fit), "label": labels[start][1]})
            start = i
    # white-noise coefficient: fit σ = N/√(2τ)… use the shortest-τ points with slope ≈ −½
    early = slice(0, max(3, tau.size // 5))
    n_white = float(np.median(dev[early] * np.sqrt(2.0 * tau[early])))  # one-sided ASD [unit/√Hz]
    i_min = int(np.argmin(dev))
    out = {
        "white_noise_mps2_per_rthz": n_white,
        "bias_instability_mps2": float(dev[i_min] / 0.664),
        "bias_instability_tau_s": float(tau[i_min]),
        "minimum_adev_mps2": float(dev[i_min]),
        "regions": regions,
    }
    late = slice(max(0, tau.size - 4), tau.size)
    late_slope = float(np.polyfit(lt[late], ld[late], 1)[0]) if tau.size >= 4 else float(slope[-1])
    out["long_term_slope"] = late_slope
    if late_slope > 0.75:
        out["drift_rate_estimate_mps2_per_s"] = float(dev[-1] * math.sqrt(2.0) / tau[-1])
    return out


def export_allan(res: AllanResult, path: str) -> None:
    """Export to CSV or JSON depending on the file extension."""
    import json

    if path.endswith(".json"):
        with open(path, "w") as f:
            json.dump(res.to_dict(), f, indent=2)
        return
    arr = np.column_stack([res.tau_s, res.adev, res.adev_lo, res.adev_hi, res.n_terms])
    np.savetxt(path, arr, delimiter=",", header="tau_s,adev_mps2,adev_lo_mps2,adev_hi_mps2,n_terms", comments="")


__all__ = ["AllanResult", "overlapping_adev", "identify_noise", "log_spaced_factors", "export_allan"]
