"""Linear Kalman filter with explicit state-space definitions.

GENERIC MODEL
    state transition    x_k = F x_{k−1} + w_k,   w_k ~ N(0, Q)
    observation         z_k = H_k x_k + v_k,     v_k ~ N(0, R)

    predict   x⁻ = F x,          P⁻ = F P Fᵀ + Q
    update    S = H P⁻ Hᵀ + R,   K = P⁻ Hᵀ S⁻¹
              x = x⁻ + K (z − H x⁻)
              P = (I − K H) P⁻ (I − K H)ᵀ + K R Kᵀ     (Joseph form, numerically stable)

MODEL A — constant-velocity gravity tracker (used by the "kalman" filter)
    state       x = [Δg, Δġ]ᵀ                  [m/s², m/s³]
    transition  F = [[1, Δt], [0, 1]]
    process     Q = q [[Δt³/3, Δt²/2], [Δt²/2, Δt]]   (white "jerk" of PSD q)
    observation H = [1, 0]
    measurement R = σ²   (per-sample white measurement noise)

MODEL B — static gravity + drift + tidal admittance (gravity estimator)
    state       x = [g₀, β, δ]ᵀ  (static gravity offset, drift rate, tide factor)
    transition  F = I₃  (parameters are constant, optionally with random walk Q)
    observation z_k = g₀ + β t_k + δ · T_model(t_k) + v_k
                H_k = [1, t_k, T_model(t_k)]   (time-varying)
    measurement R = σ²_eff
    With Q = 0 this is exactly recursive weighted least squares.
"""

from __future__ import annotations

import numpy as np


class KalmanFilter:
    def __init__(self, f: np.ndarray, h: np.ndarray, q: np.ndarray, r: np.ndarray,
                 x0: np.ndarray, p0: np.ndarray):
        self.f = np.atleast_2d(np.asarray(f, dtype=float))
        self.h = np.atleast_2d(np.asarray(h, dtype=float))
        self.q = np.atleast_2d(np.asarray(q, dtype=float))
        self.r = np.atleast_2d(np.asarray(r, dtype=float))
        self.x = np.asarray(x0, dtype=float).copy()
        self.p = np.atleast_2d(np.asarray(p0, dtype=float)).copy()
        n = self.x.size
        if self.f.shape != (n, n) or self.q.shape != (n, n) or self.p.shape != (n, n):
            raise ValueError("inconsistent state dimensions")
        self.innovations: list[float] = []

    def predict(self) -> None:
        self.x = self.f @ self.x
        self.p = self.f @ self.p @ self.f.T + self.q

    def update(self, z: np.ndarray, h: np.ndarray | None = None, r: np.ndarray | None = None) -> np.ndarray:
        hh = self.h if h is None else np.atleast_2d(np.asarray(h, dtype=float))
        rr = self.r if r is None else np.atleast_2d(np.asarray(r, dtype=float))
        z = np.atleast_1d(np.asarray(z, dtype=float))
        y = z - hh @ self.x
        s = hh @ self.p @ hh.T + rr
        k = np.linalg.solve(s.T, (self.p @ hh.T).T).T
        self.x = self.x + k @ y
        i_kh = np.eye(self.x.size) - k @ hh
        self.p = i_kh @ self.p @ i_kh.T + k @ rr @ k.T
        return y

    @property
    def std(self) -> np.ndarray:
        return np.sqrt(np.clip(np.diag(self.p), 0.0, None))


def constant_velocity_model(dt: float, q_psd: float, r_var: float):
    """(F, H, Q, R) for Model A."""
    f = np.array([[1.0, dt], [0.0, 1.0]])
    h = np.array([[1.0, 0.0]])
    q = q_psd * np.array([[dt**3 / 3.0, dt**2 / 2.0], [dt**2 / 2.0, dt]])
    r = np.array([[r_var]])
    return f, h, q, r


def rts_smoother(xs: np.ndarray, ps: np.ndarray, f: np.ndarray, q: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    """Rauch–Tung–Striebel fixed-interval smoother for a time-invariant model.

    ``xs``/``ps`` are the filtered states/covariances (N, n) / (N, n, n).
    """
    n = xs.shape[0]
    xs_s = xs.copy()
    ps_s = ps.copy()
    for k in range(n - 2, -1, -1):
        p_pred = f @ ps[k] @ f.T + q
        c = ps[k] @ f.T @ np.linalg.inv(p_pred)
        xs_s[k] = xs[k] + c @ (xs_s[k + 1] - f @ xs[k])
        ps_s[k] = ps[k] + c @ (ps_s[k + 1] - p_pred) @ c.T
    return xs_s, ps_s


__all__ = ["KalmanFilter", "constant_velocity_model", "rts_smoother"]
