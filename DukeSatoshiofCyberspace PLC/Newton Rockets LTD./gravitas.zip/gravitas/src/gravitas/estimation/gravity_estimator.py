"""Gravity estimator: recursive estimation of static gravity from the corrected stream.

MODEL (Model B of :mod:`gravitas.estimation.kalman`)
    Input: corrected deviation Δg_c(t) = calibrated − modelled tide − Eötvös
           (relative to the instrument reference g_ref), decimated to
           approximately independent samples at interval D = max(1/f_s, 1/(2·ENBW)).

    state        x = [g₀, β, ε]ᵀ
                   g₀  static gravity deviation           [m/s²]
                   β   residual drift rate                 [m/s² per s]   (optional)
                   ε   residual tidal admittance (δ̂ = δ_nom (1 + ε))    (optional)
    transition   F = I,   Q = diag(q_g Δt, q_β Δt, 0)
    observation  z_k = g₀ + β (t_k − t₀) + ε · T_nom(t_k) + v_k
    measurement  R_k = σ̂²  — adaptively estimated from the scatter of successive
                 decimated samples, σ̂² = ⟨(z_k − z_{k−1})²⟩ / 2, seeded with a prior.

    Final value: g = g_ref + g₀ (+ the drift term evaluated at the reference
    epoch, which is t₀ by construction).

LIMITATIONS
    The Kalman covariance assumes white measurement noise at the decimated
    rate. Correlated (flicker / random-walk) noise makes it optimistic; the
    uncertainty budget therefore takes its noise term from the Allan deviation
    instead (see :mod:`gravitas.uncertainty.budget`).
"""

from __future__ import annotations

import math
from dataclasses import dataclass

import numpy as np

from gravitas.estimation.kalman import KalmanFilter


@dataclass
class EstimatorConfig:
    estimate_drift: bool = False
    estimate_tidal_admittance: bool = False
    process_noise_gravity_mps2_per_rts: float = 0.0  #: random walk of g₀ (non-zero for surveys)
    process_noise_drift: float = 0.0
    prior_sigma_mps2: float = 1.0e-3
    noise_prior_mps2: float = 1.0e-7
    min_interval_s: float = 1.0
    start_time_s: float = 0.0  #: ignore samples before this time (instrument/filter settling)


class GravityEstimator:
    def __init__(self, cfg: EstimatorConfig, sample_rate_hz: float, independent_interval_s: float):
        self.cfg = cfg
        self.fs = float(sample_rate_hz)
        self.stride = max(1, int(math.ceil(max(independent_interval_s, cfg.min_interval_s, 1.0 / self.fs) * self.fs)))
        self.interval_s = self.stride / self.fs
        n = 3
        self.active = np.array([True, cfg.estimate_drift, cfg.estimate_tidal_admittance])
        p0 = np.diag([cfg.prior_sigma_mps2**2, (1e-9) ** 2, 0.05**2])
        self.kf = KalmanFilter(np.eye(n), np.zeros((1, n)), np.zeros((n, n)), np.array([[cfg.noise_prior_mps2**2]]),
                               x0=np.zeros(n), p0=p0)
        self._t0: float | None = None
        self._counter = 0
        self._prev_z: float | None = None
        self._diff_sq_sum = 0.0
        self._diff_n = 0
        self._last_t: float | None = None
        self.history_t: list[float] = []
        self.history_x: list[np.ndarray] = []
        self.history_sigma: list[float] = []
        self._initialised = False

    @property
    def measurement_sigma(self) -> float:
        if self._diff_n >= 10:
            return math.sqrt(self._diff_sq_sum / self._diff_n / 2.0)
        return self.cfg.noise_prior_mps2

    def process(self, t_s: np.ndarray, z_dev: np.ndarray, tide_nominal: np.ndarray) -> dict[str, np.ndarray]:
        """Consume a chunk; return per-sample (held) estimate, σ and drift arrays."""
        n = t_s.size
        est = np.empty(n)
        sig = np.empty(n)
        beta = np.empty(n)
        eps = np.empty(n)
        for k in range(n):
            if t_s[k] < self.cfg.start_time_s:
                est[k] = z_dev[k] if not self._initialised else self.kf.x[0]
                sig[k] = self.cfg.prior_sigma_mps2
                beta[k] = 0.0
                eps[k] = 0.0
                continue
            self._counter += 1
            if self._counter >= self.stride:
                self._counter = 0
                self._update(float(t_s[k]), float(z_dev[k]), float(tide_nominal[k]))
            if not self._initialised:
                # before the first update there is no estimate: expose the input value
                est[k] = z_dev[k]
                sig[k] = self.cfg.prior_sigma_mps2
                beta[k] = 0.0
                eps[k] = 0.0
                continue
            x = self.kf.x
            est[k] = x[0]
            sig[k] = math.sqrt(max(self.kf.p[0, 0], 0.0))
            beta[k] = x[1]
            eps[k] = x[2]
        return {"estimate_dev_mps2": est, "sigma_mps2": sig, "drift_rate": beta, "tidal_admittance": eps}

    def _update(self, t: float, z: float, tide: float) -> None:
        if self._t0 is None:
            self._t0 = t
            self.kf.x[0] = z
        if self._prev_z is not None:
            self._diff_sq_sum += (z - self._prev_z) ** 2
            self._diff_n += 1
        self._prev_z = z
        dt = 0.0 if self._last_t is None else t - self._last_t
        self._last_t = t
        q = np.zeros((3, 3))
        q[0, 0] = self.cfg.process_noise_gravity_mps2_per_rts**2 * dt
        q[1, 1] = self.cfg.process_noise_drift**2 * dt
        self.kf.q = q
        self.kf.predict()
        h = np.array([[1.0, (t - self._t0) if self.active[1] else 0.0, tide if self.active[2] else 0.0]])
        r = np.array([[self.measurement_sigma**2]])
        self.kf.update(np.array([z]), h=h, r=r)
        # inactive states are pinned at zero with zero covariance
        for i in (1, 2):
            if not self.active[i]:
                self.kf.x[i] = 0.0
                self.kf.p[i, :] = 0.0
                self.kf.p[:, i] = 0.0
        self._initialised = True
        self.history_t.append(t)
        self.history_x.append(self.kf.x.copy())
        self.history_sigma.append(math.sqrt(max(self.kf.p[0, 0], 0.0)))

    @property
    def n_updates(self) -> int:
        return len(self.history_t)

    def describe(self) -> dict:
        return {"model": "Kalman/RLS [g0, drift, tidal admittance]", "stride_samples": self.stride,
                "interval_s": self.interval_s, "estimate_drift": self.cfg.estimate_drift,
                "estimate_tidal_admittance": self.cfg.estimate_tidal_admittance,
                "process_noise_gravity_mps2_per_rts": self.cfg.process_noise_gravity_mps2_per_rts}


__all__ = ["EstimatorConfig", "GravityEstimator"]
