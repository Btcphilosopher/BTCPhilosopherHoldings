"""Configurable, stateful (streaming) digital filters.

All filters operate on the *deviation from the instrument reference*
(Δg = g − g_ref) to keep accumulations well-conditioned in float64, and
carry their internal state between chunks so that streaming and batch results
are identical.

FILTERS
    none            y = x
    moving_average  y[k] = (1/N) Σ_{i=0}^{N−1} x[k−i]                (FIR, causal)
    lowpass         y[k] = y[k−1] + α (x[k] − y[k−1]), α = 1 − e^{−2π f_c Δt}
    butterworth     n-th order Butterworth low-pass (SOS form), causal
    kalman          constant-velocity Kalman smoother-in-time (see kalman.py)

Each filter reports its noise-equivalent bandwidth (ENBW, one-sided)

    ENBW = f_s / 2 · Σ h[k]²  (for unit DC gain)

so that the white-noise variance at its output is σ_out² = N₀ · ENBW with N₀
the one-sided PSD of the input.
"""

from __future__ import annotations

import math
from dataclasses import dataclass

import numpy as np
from scipy.signal import butter, lfilter, sosfilt, sosfilt_zi

from gravitas.estimation.kalman import KalmanFilter, constant_velocity_model

FILTER_KINDS = ("none", "moving_average", "lowpass", "butterworth", "kalman")


@dataclass
class FilterConfig:
    kind: str = "butterworth"
    cutoff_hz: float = 0.05
    order: int = 4
    window_s: float = 10.0
    kalman_process_asd: float = 1.0e-9  #: random-acceleration-of-gravity PSD^½ [m/s² /s /√Hz]
    kalman_measurement_sigma: float | None = None  #: per-sample σ; default from noise model

    def __post_init__(self) -> None:
        if self.kind not in FILTER_KINDS:
            raise ValueError(f"unknown filter kind {self.kind!r}; expected one of {FILTER_KINDS}")
        if self.cutoff_hz <= 0 or self.window_s <= 0 or not (1 <= self.order <= 10):
            raise ValueError("invalid filter parameters")


class StreamingFilter:
    """Causal filter with persistent state. ``process`` may be called per chunk."""

    def __init__(self, cfg: FilterConfig, sample_rate_hz: float, measurement_sigma: float = 1e-7):
        self.cfg = cfg
        self.fs = float(sample_rate_hz)
        dt = 1.0 / self.fs
        self._initialised = False
        kind = cfg.kind
        if kind == "moving_average":
            self.n = max(1, int(round(cfg.window_s * self.fs)))
            self.b = np.full(self.n, 1.0 / self.n)
            self.a = np.array([1.0])
            self.zi = None
        elif kind == "lowpass":
            alpha = 1.0 - math.exp(-2.0 * math.pi * min(cfg.cutoff_hz, 0.45 * self.fs) * dt)
            self.b = np.array([alpha])
            self.a = np.array([1.0, -(1.0 - alpha)])
            self.zi = None
        elif kind == "butterworth":
            wn = min(cfg.cutoff_hz, 0.45 * self.fs) / (0.5 * self.fs)
            self.sos = butter(cfg.order, wn, btype="low", output="sos")
            self.zi = None
        elif kind == "kalman":
            r = cfg.kalman_measurement_sigma if cfg.kalman_measurement_sigma is not None else measurement_sigma
            f, h, q, rr = constant_velocity_model(dt, cfg.kalman_process_asd**2, r * r)
            self.kf = KalmanFilter(f, h, q, rr, x0=np.zeros(2), p0=np.diag([1e-2, 1e-6]))
        self._enbw = None

    # ------------------------------------------------------------------
    def process(self, x: np.ndarray) -> np.ndarray:
        x = np.asarray(x, dtype=float)
        if x.size == 0:
            return x.copy()
        kind = self.cfg.kind
        if kind == "none":
            return x.copy()
        if kind in ("moving_average", "lowpass"):
            if not self._initialised:
                # start from steady state at the first sample (no artificial start-up transient)
                if kind == "lowpass":
                    self.zi = np.array([(1.0 - self.b[0]) * x[0]])
                else:
                    self.zi = np.zeros(self.n - 1) if self.n > 1 else np.zeros(0)
                    if self.n > 1:
                        # zi for FIR such that the output starts at x[0]
                        self.zi = np.array([x[0] * (self.n - 1 - i) / self.n for i in range(self.n - 1)])
                self._initialised = True
            if kind == "moving_average" and self.n == 1:
                return x.copy()
            y, self.zi = lfilter(self.b, self.a, x, zi=self.zi)
            return y
        if kind == "butterworth":
            if not self._initialised:
                self.zi = sosfilt_zi(self.sos) * x[0]
                self._initialised = True
            y, self.zi = sosfilt(self.sos, x, zi=self.zi)
            return y
        if kind == "kalman":
            if not self._initialised:
                self.kf.x = np.array([x[0], 0.0])
                self._initialised = True
            out = np.empty_like(x)
            for k in range(x.size):
                self.kf.predict()
                self.kf.update(np.array([x[k]]))
                out[k] = self.kf.x[0]
            return out
        raise AssertionError(kind)  # pragma: no cover

    # ------------------------------------------------------------------
    def impulse_response(self, n: int | None = None) -> np.ndarray:
        if n is None:
            n = int(max(200, 50 * self.fs / max(self.cfg.cutoff_hz, 1e-3))) if self.cfg.kind != "moving_average" else self.n + 1
            n = min(n, 2_000_000)
        imp = np.zeros(n)
        imp[0] = 1.0
        kind = self.cfg.kind
        if kind == "none":
            return imp
        if kind in ("moving_average", "lowpass"):
            return lfilter(self.b, self.a, imp)
        if kind == "butterworth":
            return sosfilt(self.sos, imp)
        if kind == "kalman":
            # steady-state gain of the CV Kalman filter → equivalent IIR
            kf = KalmanFilter(self.kf.f, self.kf.h, self.kf.q, self.kf.r, x0=np.zeros(2), p0=np.diag([1e-2, 1e-6]))
            for _ in range(20000):
                kf.predict()
                kf.update(np.array([0.0]))
            out = np.empty(n)
            for k in range(n):
                kf.predict()
                kf.update(np.array([imp[k]]))
                out[k] = kf.x[0]
            return out
        raise AssertionError(kind)  # pragma: no cover

    @property
    def enbw_hz(self) -> float:
        """One-sided noise-equivalent bandwidth [Hz]."""
        if self._enbw is None:
            if self.cfg.kind == "none":
                self._enbw = 0.5 * self.fs
            else:
                h = self.impulse_response()
                self._enbw = 0.5 * self.fs * float(np.sum(h * h)) / float(np.sum(h)) ** 2
        return self._enbw

    @property
    def independent_sample_interval_s(self) -> float:
        """Spacing at which filtered samples are approximately uncorrelated: 1 / (2 ENBW)."""
        return 1.0 / (2.0 * self.enbw_hz)

    def describe(self) -> dict:
        d = {"kind": self.cfg.kind, "sample_rate_hz": self.fs, "enbw_hz": self.enbw_hz}
        if self.cfg.kind in ("lowpass", "butterworth"):
            d["cutoff_hz"] = self.cfg.cutoff_hz
        if self.cfg.kind == "butterworth":
            d["order"] = self.cfg.order
        if self.cfg.kind == "moving_average":
            d["window_s"] = self.cfg.window_s
        if self.cfg.kind == "kalman":
            d["process_asd"] = self.cfg.kalman_process_asd
        return d


def zero_phase_butterworth(x: np.ndarray, sample_rate_hz: float, cutoff_hz: float, order: int = 4) -> np.ndarray:
    """Offline zero-phase (forward–backward) Butterworth for replay analysis."""
    from scipy.signal import sosfiltfilt

    wn = min(cutoff_hz, 0.45 * sample_rate_hz) / (0.5 * sample_rate_hz)
    sos = butter(order, wn, btype="low", output="sos")
    x = np.asarray(x, dtype=float)
    if x.size < 3 * (2 * sos.shape[0] + 1):
        return x.copy()
    return sosfiltfilt(sos, x)


def moving_average(x: np.ndarray, n: int) -> np.ndarray:
    """Batch causal moving average with steady-state start (convenience)."""
    f = StreamingFilter(FilterConfig(kind="moving_average", window_s=n), 1.0)
    return f.process(x)


__all__ = ["FilterConfig", "StreamingFilter", "zero_phase_butterworth", "moving_average", "FILTER_KINDS"]
