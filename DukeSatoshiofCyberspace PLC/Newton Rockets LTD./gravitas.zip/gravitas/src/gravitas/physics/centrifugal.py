"""Centrifugal acceleration in the rotating Earth-fixed frame.

MODEL
    Uniform rotation ω about the ECEF Z axis (no polar motion, no length-of-day
    variation — both change g by < 0.1 µGal and are ignored).

EQUATIONS
    a_c = −ω × (ω × r) = ω² (x, y, 0)
    |a_c| = ω² p,  p = sqrt(x² + y²) (distance from the rotation axis)
    Φ_c = ½ ω² p²

    For an observer moving with velocity v relative to the Earth, the Coriolis
    acceleration −2 ω × v and the change of centripetal acceleration give the
    Eötvös effect, see :func:`eotvos_correction`.
"""

from __future__ import annotations

import numpy as np


def centrifugal_acceleration(r_ecef, omega: float) -> np.ndarray:
    xyz = np.asarray(r_ecef, dtype=float)
    out = np.zeros_like(xyz)
    out[..., 0] = omega**2 * xyz[..., 0]
    out[..., 1] = omega**2 * xyz[..., 1]
    return out


def coriolis_acceleration(v_ecef, omega: float) -> np.ndarray:
    """−2 ω × v for ω = (0, 0, omega)."""
    v = np.asarray(v_ecef, dtype=float)
    out = np.zeros_like(v)
    out[..., 0] = 2.0 * omega * v[..., 1]
    out[..., 1] = -2.0 * omega * v[..., 0]
    return out


def eotvos_correction(latitude_rad, v_east_mps, v_north_mps, omega: float, radius_m):
    """Eötvös effect on *measured vertical gravity* for a moving platform [m/s²].

    δg_E = 2 ω v_E cos φ + (v_E² + v_N²) / R

    A positive value means the platform's motion *reduces* measured gravity by
    δg_E, i.e. the measurement must be corrected by +δg_E (Harlan 1968).
    """
    ve = np.asarray(v_east_mps, dtype=float)
    vn = np.asarray(v_north_mps, dtype=float)
    return 2.0 * omega * ve * np.cos(latitude_rad) + (ve**2 + vn**2) / np.asarray(radius_m, dtype=float)


__all__ = ["centrifugal_acceleration", "coriolis_acceleration", "eotvos_correction"]
