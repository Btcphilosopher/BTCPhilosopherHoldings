"""Tide-generating acceleration from a third body.

MODEL
    Exact Newtonian differential (tide-raising) acceleration of a point mass
    body B at geocentric position R on an observer at geocentric position r:

        a_tide = GM_B [ (R − r)/|R − r|³ − R/|R|³ ]

    The first term is the body's attraction at the observer; the second is its
    attraction at the geocentre, which accelerates the whole Earth and is
    therefore not observable by an Earth-fixed instrument.

    The degree-2 approximation (used for validation) is

        a_up ≈ GM_B r / d³ · (3 cos² ψ − 1),

    where ψ is the geocentric zenith angle of the body.

ASSUMPTIONS
    Rigid Earth unless an elastic gravimetric factor δ is applied by the caller
    (see :mod:`gravitas.earth.tides`). The ocean-loading contribution
    (≈ 1–10 µGal near coasts) is not modelled.
"""

from __future__ import annotations

import numpy as np


def tidal_acceleration(r_obs_ecef, r_body_ecef, gm_body: float) -> np.ndarray:
    """Exact differential tidal acceleration [m/s²]; broadcasting over (..., 3)."""
    r = np.asarray(r_obs_ecef, dtype=float)
    rb = np.asarray(r_body_ecef, dtype=float)
    d = rb - r
    dn = np.linalg.norm(d, axis=-1, keepdims=True)
    rbn = np.linalg.norm(rb, axis=-1, keepdims=True)
    return gm_body * (d / dn**3 - rb / rbn**3)


def degree2_vertical_tide(r_obs_m: float, distance_m, cos_zenith, gm_body: float):
    """Degree-2 radial tidal acceleration (positive = upward) [m/s²]."""
    c = np.asarray(cos_zenith, dtype=float)
    return gm_body * r_obs_m / np.asarray(distance_m, dtype=float) ** 3 * (3.0 * c * c - 1.0)


def tidal_potential_degree2(r_obs_m: float, distance_m, cos_zenith, gm_body: float):
    """Degree-2 tide-generating potential W2 = GM r²/d³ · P2(cos ψ) [m²/s²]."""
    c = np.asarray(cos_zenith, dtype=float)
    return gm_body * r_obs_m**2 / np.asarray(distance_m, dtype=float) ** 3 * 0.5 * (3.0 * c * c - 1.0)


__all__ = ["tidal_acceleration", "degree2_vertical_tide", "tidal_potential_degree2"]
