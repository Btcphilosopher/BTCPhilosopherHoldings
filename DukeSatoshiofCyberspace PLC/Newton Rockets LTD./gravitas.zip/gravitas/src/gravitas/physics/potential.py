"""Gravitational and centrifugal potentials.

Sign convention (geodetic): the potential ``V`` is *positive* and the
attraction is ``a = +∇V`` (so for a point mass V = GM/r and a = -GM r̂/r²).

MODEL / EQUATIONS
    Point mass              V = GM / r
    Zonal series            V = GM/r · [1 - Σ_{n=1}^{N} J_{2n} (a/r)^{2n} P_{2n}(sin φ_c)]
    Centrifugal             Φ = ½ ω² (x² + y²)
    Effective (gravity)     W = V + Φ

ASSUMPTIONS
    The zonal series is the external potential of a *level ellipsoid*; it is
    valid outside the sphere of radius E (linear eccentricity ≈ 521.9 km for WGS84),
    i.e. everywhere a gravimeter can physically be.

LIMITATIONS
    Tesseral / sectorial harmonics of the real Earth (EGM2008, ±100s mGal) are
    not included; they are part of the "anomalous" field, which GRAVITAS models
    only synthetically.
"""

from __future__ import annotations

import numpy as np

from gravitas.earth.ellipsoid import Ellipsoid


def legendre_p_and_dp(n_max: int, u):
    """Legendre polynomials P_0..P_n_max and derivatives at ``u`` (|u| ≤ 1).

    Recurrences (non-singular at the poles):
        (n+1) P_{n+1} = (2n+1) u P_n - n P_{n-1}
        P'_{n+1}      = P'_{n-1} + (2n+1) P_n
    Returns arrays of shape (n_max+1, *u.shape).
    """
    u = np.asarray(u, dtype=float)
    p = np.zeros((n_max + 1,) + u.shape)
    dp = np.zeros_like(p)
    p[0] = 1.0
    if n_max >= 1:
        p[1] = u
        dp[1] = 1.0
    for n in range(1, n_max):
        p[n + 1] = ((2 * n + 1) * u * p[n] - n * p[n - 1]) / (n + 1)
        dp[n + 1] = dp[n - 1] + (2 * n + 1) * p[n]
    return p, dp


def point_mass_potential(r_ecef, gm: float):
    r = np.linalg.norm(np.asarray(r_ecef, dtype=float), axis=-1)
    return gm / r


def zonal_potential(r_ecef, ellipsoid: Ellipsoid, n_zonal: int = 5):
    """External potential of the level ellipsoid, zonal terms J2..J_{2 n_zonal}."""
    xyz = np.asarray(r_ecef, dtype=float)
    r = np.linalg.norm(xyz, axis=-1)
    u = xyz[..., 2] / r
    j = ellipsoid.zonal_coefficients(n_zonal)
    p, _ = legendre_p_and_dp(2 * n_zonal, u)
    s = np.zeros_like(r)
    for k, jk in enumerate(j, start=1):
        s += jk * (ellipsoid.a / r) ** (2 * k) * p[2 * k]
    return ellipsoid.gm / r * (1.0 - s)


def centrifugal_potential(r_ecef, omega: float):
    xyz = np.asarray(r_ecef, dtype=float)
    return 0.5 * omega**2 * (xyz[..., 0] ** 2 + xyz[..., 1] ** 2)


def effective_potential(r_ecef, ellipsoid: Ellipsoid, n_zonal: int = 5, include_rotation: bool = True):
    w = zonal_potential(r_ecef, ellipsoid, n_zonal)
    if include_rotation:
        w = w + centrifugal_potential(r_ecef, ellipsoid.omega)
    return w


def numerical_gradient(potential_fn, r_ecef, step_m: float = 1.0) -> np.ndarray:
    """Central-difference gradient of a scalar potential (validation utility).

    Truncation error O(step²·∂³V) ≈ 1e-12 m/s² for step = 1 m near the Earth.
    """
    r0 = np.asarray(r_ecef, dtype=float)
    g = np.zeros(3)
    for i in range(3):
        dp = r0.copy()
        dm = r0.copy()
        dp[i] += step_m
        dm[i] -= step_m
        g[i] = (potential_fn(dp) - potential_fn(dm)) / (2.0 * step_m)
    return g


__all__ = [
    "legendre_p_and_dp", "point_mass_potential", "zonal_potential", "centrifugal_potential",
    "effective_potential", "numerical_gradient",
]
