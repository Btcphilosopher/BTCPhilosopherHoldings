"""Gravitational acceleration vectors (analytic gradients of the potentials).

All functions accept ECEF positions of shape (3,) or (N, 3) [m] and return
accelerations of the same shape [m/s²].
"""

from __future__ import annotations

import numpy as np

from gravitas.earth.ellipsoid import Ellipsoid
from gravitas.physics.potential import legendre_p_and_dp


def point_mass_acceleration(r_obs, gm: float, r_src=None) -> np.ndarray:
    """a = -GM (r - r_src) / |r - r_src|³."""
    d = np.asarray(r_obs, dtype=float)
    if r_src is not None:
        d = d - np.asarray(r_src, dtype=float)
    dist = np.linalg.norm(d, axis=-1, keepdims=True)
    if np.any(dist == 0):
        raise ZeroDivisionError("point-mass acceleration is singular at the source position")
    return -gm * d / dist**3


def zonal_acceleration(r_ecef, ellipsoid: Ellipsoid, n_zonal: int = 5) -> np.ndarray:
    """Gradient of the zonal (level-ellipsoid) potential.

    With u = z/r = sin φ_c and V(r, u) = GM/r − GM Σ J_n aⁿ r^{-(n+1)} P_n(u):

        ∂V/∂r = −GM/r² + GM Σ (n+1) J_n aⁿ r^{-(n+2)} P_n(u)
        ∂V/∂u = −GM Σ J_n aⁿ r^{-(n+1)} P'_n(u)
        ∇r = r̂,   ∇u = (ẑ − u r̂) / r
        a = ∂V/∂r · r̂ + ∂V/∂u · (ẑ − u r̂)/r
    """
    xyz = np.asarray(r_ecef, dtype=float)
    r = np.linalg.norm(xyz, axis=-1)
    if np.any(r < ellipsoid.linear_eccentricity):
        raise ValueError("zonal series evaluated inside its convergence sphere (r < E)")
    u = xyz[..., 2] / r
    gm, a = ellipsoid.gm, ellipsoid.a
    j = ellipsoid.zonal_coefficients(n_zonal)
    p, dp = legendre_p_and_dp(2 * n_zonal, u)
    dv_dr = -gm / r**2
    dv_du = np.zeros_like(r)
    for k, jk in enumerate(j, start=1):
        n = 2 * k
        ratio = (a / r) ** n
        dv_dr = dv_dr + gm * (n + 1) * jk * ratio * p[n] / r**2
        dv_du = dv_du - gm * jk * ratio * dp[n] / r
    rhat = xyz / r[..., None]
    zhat = np.zeros_like(xyz)
    zhat[..., 2] = 1.0
    return dv_dr[..., None] * rhat + (dv_du / r)[..., None] * (zhat - u[..., None] * rhat)


__all__ = ["point_mass_acceleration", "zonal_acceleration"]
