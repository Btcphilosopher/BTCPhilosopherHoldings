"""Synthetic local gravity anomalies — SYNTHETIC GEOPHYSICAL MODEL.

Every body here is a *synthetic* density contrast Δρ (relative to the
surrounding rock) placed in a local East-North-Up frame (metres, Up positive;
buried bodies have negative Up coordinates). None of these represent real
geology unless the user supplies real parameters.

Each body exposes
    ``acceleration_enu(points)``  attraction vector [m/s²] at ENU points (N, 3)
    ``delta_g(points)``           change in measured (downward) gravity
                                  δg = −a_up [m/s²]; positive above excess mass
    ``potential(points)``         anomalous potential [m²/s²] (where finite)
    ``mass_kg``                   anomalous mass (where finite)

MODELS / EQUATIONS
    PointMass        a = −G M d/|d|³
    Sphere           outside: point mass M = 4/3 π R³ Δρ;
                     inside : a = −G M d / R³
    Slab (prism)     right rectangular prism, closed form of Nagy (1966) /
                     Plouff (1976):  a_w = G Δρ Σ_{ijk} μ_ijk F(u_i, v_j, w_k)
                     F(u,v,w) = u ln(v + r) + v ln(u + r) − w atan(u v / (w r))
    Layer            horizontal thin sheet of thickness t at depth z:
                     infinite: δg = 2π G Δρ t
                     semi-infinite (edge at s=0, sheet on s>0):
                     δg = 2 G Δρ t (π/2 + atan(s / z))      (Telford et al. 1990)
    Gaussian         ρ(d) = Δρ₀ exp(−d²/2σ²); enclosed mass
                     M(d) = M [erf(d/(√2σ)) − √(2/π) (d/σ) exp(−d²/2σ²)],
                     M = Δρ₀ (2π)^{3/2} σ³; a = −G M(d) d̂ / d²

LIMITATIONS
    * Layer uses the thin-sheet approximation (error O((t/z)²)); keep t ≪ z.
    * Prism formulas lose precision when the observation point lies exactly on
      a prism edge/corner; such points are rejected.
    * No topography, no compaction gradients, no magnetisation (gravity only).
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Literal, Sequence, Union

import numpy as np
from scipy.special import erf

from gravitas.constants.physical import G


def _as_points(points) -> np.ndarray:
    p = np.atleast_2d(np.asarray(points, dtype=float))
    if p.shape[-1] != 3:
        raise ValueError("points must have shape (N, 3) in ENU metres")
    if not np.all(np.isfinite(p)):
        raise ValueError("points must be finite")
    return p


def _require_finite_positive(name: str, v: float, allow_zero: bool = False) -> None:
    if not math.isfinite(v) or (v < 0 if allow_zero else v <= 0):
        raise ValueError(f"{name} must be {'non-negative' if allow_zero else 'positive'} and finite, got {v}")


class AnomalyBody:
    """Base class. Subclasses implement :meth:`acceleration_enu`."""

    kind: str = "body"

    def acceleration_enu(self, points) -> np.ndarray:  # pragma: no cover - abstract
        raise NotImplementedError

    def delta_g(self, points) -> np.ndarray:
        return -self.acceleration_enu(points)[:, 2]

    def describe(self) -> dict:
        raise NotImplementedError  # pragma: no cover


@dataclass
class PointMass(AnomalyBody):
    mass_kg: float
    position_enu_m: Sequence[float]
    description: str = "synthetic point mass"
    kind: str = field(default="point_mass", init=False)

    def __post_init__(self) -> None:
        if not math.isfinite(self.mass_kg):
            raise ValueError("mass must be finite")
        self.position_enu_m = np.asarray(self.position_enu_m, dtype=float)

    def acceleration_enu(self, points) -> np.ndarray:
        d = _as_points(points) - self.position_enu_m
        r = np.linalg.norm(d, axis=1, keepdims=True)
        if np.any(r == 0):
            raise ValueError("observation point coincides with point mass")
        return -G * self.mass_kg * d / r**3

    def potential(self, points) -> np.ndarray:
        d = _as_points(points) - self.position_enu_m
        return G * self.mass_kg / np.linalg.norm(d, axis=1)

    def describe(self) -> dict:
        return {"kind": self.kind, "description": self.description,
                "params": {"mass_kg": self.mass_kg, "position_enu_m": list(map(float, self.position_enu_m))}}


@dataclass
class Sphere(AnomalyBody):
    radius_m: float
    density_contrast_kgpm3: float
    center_enu_m: Sequence[float]
    description: str = "synthetic uniform sphere"
    kind: str = field(default="sphere", init=False)

    def __post_init__(self) -> None:
        _require_finite_positive("radius_m", self.radius_m)
        if not math.isfinite(self.density_contrast_kgpm3):
            raise ValueError("density contrast must be finite")
        self.center_enu_m = np.asarray(self.center_enu_m, dtype=float)

    @property
    def mass_kg(self) -> float:
        return 4.0 / 3.0 * math.pi * self.radius_m**3 * self.density_contrast_kgpm3

    def acceleration_enu(self, points) -> np.ndarray:
        d = _as_points(points) - self.center_enu_m
        r = np.linalg.norm(d, axis=1, keepdims=True)
        m = self.mass_kg
        outside = -G * m * d / np.where(r == 0, 1.0, r) ** 3
        inside = -G * m * d / self.radius_m**3
        return np.where(r >= self.radius_m, outside, inside)

    def potential(self, points) -> np.ndarray:
        d = _as_points(points) - self.center_enu_m
        r = np.linalg.norm(d, axis=1)
        m, a = self.mass_kg, self.radius_m
        inside = G * m * (3.0 * a * a - r * r) / (2.0 * a**3)
        return np.where(r >= a, G * m / np.where(r == 0, 1.0, r), inside)

    def describe(self) -> dict:
        return {"kind": self.kind, "description": self.description,
                "params": {"radius_m": self.radius_m, "density_contrast_kgpm3": self.density_contrast_kgpm3,
                           "center_enu_m": list(map(float, self.center_enu_m)), "mass_kg": self.mass_kg}}


def _safe_log_sum(a: np.ndarray, r: np.ndarray) -> np.ndarray:
    """ln(a + r) computed stably when a ≈ −r (a < 0): ln((r² − a²)/(r − a))."""
    s = a + r
    alt = (r * r - a * a) / np.where(r - a == 0, 1.0, r - a)
    val = np.where(a >= 0, s, alt)
    return np.log(np.where(val <= 0, np.finfo(float).tiny, val))


def _prism_component(u1, u2, v1, v2, w1, w2) -> np.ndarray:
    """∫∫∫ w / r³ dV over [u1,u2]×[v1,v2]×[w1,w2] (observer at origin).

    This is the attraction component along +w per unit Gρ (pointing from the
    observer into the mass for w > 0).
    """
    total = 0.0
    for i, u in enumerate((u1, u2)):
        for j, v in enumerate((v1, v2)):
            for k, w in enumerate((w1, w2)):
                mu = (-1.0) ** (i + j + k)
                r = np.sqrt(u * u + v * v + w * w)
                wr = w * r
                # principal-value arctan (NOT atan2): the antiderivative is continuous
                # across w < 0; the w·atan term vanishes when w = 0.
                at = np.where(wr == 0, 0.0, np.arctan(u * v / np.where(wr == 0, 1.0, wr)))
                f = u * _safe_log_sum(v, r) + v * _safe_log_sum(u, r) - w * at
                total = total + mu * f
    # With μ = (−1)^{i+j+k} and index 0 = lower bound, Σ μ F = +∫∫∫ w/r³ dV.
    # Validated against the point-mass limit and the Bouguer-plate limit in
    # tests/test_anomalies.py.
    return total


@dataclass
class Slab(AnomalyBody):
    """Right rectangular prism (finite slab) aligned with the ENU axes."""

    center_enu_m: Sequence[float]
    size_enu_m: Sequence[float]  # full lengths along E, N, U
    density_contrast_kgpm3: float
    description: str = "synthetic rectangular slab (prism)"
    kind: str = field(default="slab", init=False)

    def __post_init__(self) -> None:
        self.center_enu_m = np.asarray(self.center_enu_m, dtype=float)
        self.size_enu_m = np.asarray(self.size_enu_m, dtype=float)
        if self.size_enu_m.shape != (3,) or np.any(self.size_enu_m <= 0) or not np.all(np.isfinite(self.size_enu_m)):
            raise ValueError("slab size must be three positive finite lengths")
        if not math.isfinite(self.density_contrast_kgpm3):
            raise ValueError("density contrast must be finite")

    @property
    def mass_kg(self) -> float:
        return float(np.prod(self.size_enu_m) * self.density_contrast_kgpm3)

    def acceleration_enu(self, points) -> np.ndarray:
        p = _as_points(points)
        lo = self.center_enu_m - 0.5 * self.size_enu_m
        hi = self.center_enu_m + 0.5 * self.size_enu_m
        d1 = lo[None, :] - p  # relative bounds, observer at origin
        d2 = hi[None, :] - p
        out = np.empty_like(p)
        # component along axis k: permute axes so that w = axis k
        for k in range(3):
            i, j = [ax for ax in range(3) if ax != k]
            out[:, k] = _prism_component(d1[:, i], d2[:, i], d1[:, j], d2[:, j], d1[:, k], d2[:, k])
        return G * self.density_contrast_kgpm3 * out

    def describe(self) -> dict:
        return {"kind": self.kind, "description": self.description,
                "params": {"center_enu_m": list(map(float, self.center_enu_m)),
                           "size_enu_m": list(map(float, self.size_enu_m)),
                           "density_contrast_kgpm3": self.density_contrast_kgpm3, "mass_kg": self.mass_kg}}


@dataclass
class Layer(AnomalyBody):
    """Horizontal thin layer (sheet) at depth below the survey datum.

    If ``edge_offset_m`` is ``None`` the layer is laterally infinite (Bouguer
    plate). Otherwise the layer occupies the half-plane s > edge_offset_m where s
    is the horizontal coordinate along ``strike_normal_azimuth_deg`` (0° = North,
    90° = East): a buried fault step / truncated bed.
    """

    top_depth_m: float
    thickness_m: float
    density_contrast_kgpm3: float
    edge_offset_m: Union[float, None] = None
    strike_normal_azimuth_deg: float = 90.0
    description: str = "synthetic horizontal layer"
    kind: str = field(default="layer", init=False)

    def __post_init__(self) -> None:
        _require_finite_positive("top_depth_m", self.top_depth_m)
        _require_finite_positive("thickness_m", self.thickness_m)
        if not math.isfinite(self.density_contrast_kgpm3):
            raise ValueError("density contrast must be finite")

    @property
    def mid_depth_m(self) -> float:
        return self.top_depth_m + 0.5 * self.thickness_m

    def acceleration_enu(self, points) -> np.ndarray:
        p = _as_points(points)
        z = self.mid_depth_m + p[:, 2]  # depth of sheet below observer
        if np.any(z <= 0):
            raise ValueError("observation point must be above the layer")
        sigma = G * self.density_contrast_kgpm3 * self.thickness_m
        out = np.zeros_like(p)
        if self.edge_offset_m is None:
            out[:, 2] = -2.0 * math.pi * sigma
            return out
        az = math.radians(self.strike_normal_azimuth_deg)
        nhat = np.array([math.sin(az), math.cos(az)])
        s = p[:, :2] @ nhat - self.edge_offset_m
        out[:, 2] = -2.0 * sigma * (0.5 * math.pi + np.arctan2(s, z))
        # Horizontal components: the attraction of a laterally unbounded sheet
        # diverges logarithmically and is physically undefined. The layer model
        # therefore contributes only to the vertical (measurement) axis; this is
        # documented in docs/PHYSICS.md (Layer, LIMITATIONS).
        return out

    def describe(self) -> dict:
        return {"kind": self.kind, "description": self.description,
                "params": {"top_depth_m": self.top_depth_m, "thickness_m": self.thickness_m,
                           "density_contrast_kgpm3": self.density_contrast_kgpm3,
                           "edge_offset_m": self.edge_offset_m,
                           "strike_normal_azimuth_deg": self.strike_normal_azimuth_deg}}


@dataclass
class GaussianAnomaly(AnomalyBody):
    """Spherically symmetric Gaussian density anomaly ρ(d) = Δρ₀ exp(−d²/2σ²)."""

    peak_density_contrast_kgpm3: float
    sigma_m: float
    center_enu_m: Sequence[float]
    description: str = "synthetic Gaussian density anomaly"
    kind: str = field(default="gaussian", init=False)

    def __post_init__(self) -> None:
        _require_finite_positive("sigma_m", self.sigma_m)
        if not math.isfinite(self.peak_density_contrast_kgpm3):
            raise ValueError("density contrast must be finite")
        self.center_enu_m = np.asarray(self.center_enu_m, dtype=float)

    @property
    def mass_kg(self) -> float:
        return self.peak_density_contrast_kgpm3 * (2.0 * math.pi) ** 1.5 * self.sigma_m**3

    def enclosed_mass(self, d) -> np.ndarray:
        x = np.asarray(d, dtype=float) / self.sigma_m
        return self.mass_kg * (erf(x / math.sqrt(2.0)) - math.sqrt(2.0 / math.pi) * x * np.exp(-0.5 * x * x))

    def acceleration_enu(self, points) -> np.ndarray:
        dv = _as_points(points) - self.center_enu_m
        d = np.linalg.norm(dv, axis=1)
        safe = np.where(d == 0, 1.0, d)
        mag = G * self.enclosed_mass(d) / safe**2
        return np.where(d[:, None] == 0, 0.0, -mag[:, None] * dv / safe[:, None])

    def potential(self, points) -> np.ndarray:
        dv = _as_points(points) - self.center_enu_m
        d = np.linalg.norm(dv, axis=1)
        safe = np.where(d == 0, 1.0, d)
        outer = 4.0 * math.pi * self.peak_density_contrast_kgpm3 * self.sigma_m**2 * np.exp(-0.5 * (d / self.sigma_m) ** 2)
        # M(d)/d -> 0 as d -> 0 because M(d) ~ d^3 near the centre.
        inner = np.where(d == 0, 0.0, self.enclosed_mass(d) / safe)
        return G * (inner + outer)

    def describe(self) -> dict:
        return {"kind": self.kind, "description": self.description,
                "params": {"peak_density_contrast_kgpm3": self.peak_density_contrast_kgpm3,
                           "sigma_m": self.sigma_m, "center_enu_m": list(map(float, self.center_enu_m)),
                           "mass_kg": self.mass_kg}}


class AnomalyField:
    """Superposition of synthetic anomaly bodies. LABEL: SYNTHETIC GEOPHYSICAL MODEL."""

    label = "SYNTHETIC GEOPHYSICAL MODEL"

    def __init__(self, bodies: Sequence[AnomalyBody] = ()):
        self.bodies = list(bodies)

    def acceleration_enu(self, points) -> np.ndarray:
        p = _as_points(points)
        total = np.zeros_like(p)
        for b in self.bodies:
            total += b.acceleration_enu(p)
        return total

    def delta_g(self, points) -> np.ndarray:
        return -self.acceleration_enu(points)[:, 2]

    def potential(self, points) -> np.ndarray:
        p = _as_points(points)
        total = np.zeros(p.shape[0])
        for b in self.bodies:
            if not hasattr(b, "potential"):
                raise ValueError(f"body {b.kind} has no finite potential (laterally infinite)")
            total += b.potential(p)
        return total

    def grid(self, east_m: np.ndarray, north_m: np.ndarray, up_m: float = 0.0) -> np.ndarray:
        ee, nn = np.meshgrid(east_m, north_m)
        pts = np.column_stack([ee.ravel(), nn.ravel(), np.full(ee.size, up_m)])
        return self.delta_g(pts).reshape(ee.shape)

    def describe(self) -> list[dict]:
        return [b.describe() for b in self.bodies]

    def __len__(self) -> int:
        return len(self.bodies)


BodyKind = Literal["point_mass", "sphere", "slab", "layer", "gaussian"]


def body_from_dict(d: dict) -> AnomalyBody:
    """Construct a body from a configuration dictionary ``{"kind": ..., **params}``."""
    d = dict(d)
    kind = d.pop("kind")
    d.pop("mass_kg", None) if kind != "point_mass" else None
    builders = {"point_mass": PointMass, "sphere": Sphere, "slab": Slab, "layer": Layer, "gaussian": GaussianAnomaly}
    if kind not in builders:
        raise ValueError(f"unknown anomaly kind {kind!r}")
    return builders[kind](**d)


__all__ = ["AnomalyBody", "PointMass", "Sphere", "Slab", "Layer", "GaussianAnomaly", "AnomalyField", "body_from_dict"]
