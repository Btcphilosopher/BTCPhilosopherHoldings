"""Reference ellipsoids of revolution.

MODEL
    An oblate ellipsoid of revolution defined by semi-major axis ``a`` and
    flattening ``f``, carrying total mass ``GM`` and rotating with angular rate
    ``omega`` about its minor axis. With ``f = 0`` it degenerates to a sphere.

EQUATIONS
    b   = a (1 - f)                      semi-minor axis
    e²  = f (2 - f)                      first eccentricity squared
    e'² = e² / (1 - e²)                  second eccentricity squared
    E   = sqrt(a² - b²)                  linear eccentricity
    m   = ω² a² b / GM                   geodetic parameter

    The level-ellipsoid zonal coefficients J2n follow from (a, f, GM, ω) via
    Heiskanen & Moritz (1967) eq. 2-92 / NIMA TR8350.2 eq. 3-?:

    J2  = e²/3 · (1 - 2 m e' / (15 q0))
    J2n = (-1)^(n+1) · 3 e^(2n) / ((2n+1)(2n+3)) · (1 - n + 5 n J2 / e²)

    q0  = ½[(1 + 3/e'²) arctan e' - 3/e']

LIMITATIONS
    Describes the *normal* (level-ellipsoid) Earth only. Real-Earth departures
    (geoid undulations, ~±100 m; gravity anomalies, ~±100s mGal) are not part of
    the ellipsoid; see :mod:`gravitas.earth.geoid` and :mod:`gravitas.physics.anomalies`.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field

from gravitas.constants import physical as pc


@dataclass(frozen=True)
class Ellipsoid:
    """Rotating reference ellipsoid. All quantities SI."""

    name: str
    a: float  #: semi-major axis [m]
    f: float  #: flattening [-]
    gm: float  #: gravitational parameter [m^3/s^2]
    omega: float  #: angular velocity [rad/s]
    _derived: dict = field(default_factory=dict, init=False, repr=False, compare=False)

    def __post_init__(self) -> None:
        if not (self.a > 0 and math.isfinite(self.a)):
            raise ValueError(f"semi-major axis must be positive and finite, got {self.a}")
        if not (0.0 <= self.f < 1.0):
            raise ValueError(f"flattening must be in [0, 1), got {self.f}")
        if not (self.gm > 0 and math.isfinite(self.gm)):
            raise ValueError(f"GM must be positive and finite, got {self.gm}")
        if not (self.omega >= 0 and math.isfinite(self.omega)):
            raise ValueError(f"omega must be non-negative and finite, got {self.omega}")

    # ---- geometry -------------------------------------------------------
    @property
    def b(self) -> float:
        return self.a * (1.0 - self.f)

    @property
    def e2(self) -> float:
        return self.f * (2.0 - self.f)

    @property
    def e(self) -> float:
        return math.sqrt(self.e2)

    @property
    def ep2(self) -> float:
        return self.e2 / (1.0 - self.e2)

    @property
    def ep(self) -> float:
        return math.sqrt(self.ep2)

    @property
    def linear_eccentricity(self) -> float:
        return math.sqrt(self.a * self.a - self.b * self.b)

    @property
    def m(self) -> float:
        return self.omega**2 * self.a**2 * self.b / self.gm

    @property
    def is_sphere(self) -> bool:
        return self.f == 0.0

    @property
    def mean_radius(self) -> float:
        """IUGG mean radius R1 = (2a + b) / 3."""
        return (2.0 * self.a + self.b) / 3.0

    # ---- level-ellipsoid gravity field ----------------------------------
    def _q0(self) -> float:
        ep = self.ep
        return 0.5 * ((1.0 + 3.0 / ep**2) * math.atan(ep) - 3.0 / ep)

    def j2n(self, n: int) -> float:
        """Zonal coefficient J_{2n} of the level ellipsoid's external potential."""
        if n < 1:
            raise ValueError("n must be >= 1")
        if self.is_sphere:
            return 0.0
        e2 = self.e2
        j2 = e2 / 3.0 * (1.0 - 2.0 * self.m * self.ep / (15.0 * self._q0()))
        if n == 1:
            return j2
        return (-1) ** (n + 1) * 3.0 * e2**n / ((2 * n + 1) * (2 * n + 3)) * (1.0 - n + 5.0 * n * j2 / e2)

    def zonal_coefficients(self, n_max: int = 5) -> tuple[float, ...]:
        """(J2, J4, ..., J_{2 n_max}). Series truncation error at the surface for
        n_max=5 is below 1e-15 relative (|J12| ~ 1e-15)."""
        return tuple(self.j2n(n) for n in range(1, n_max + 1))

    # ---- Somigliana closed form on the ellipsoid ------------------------
    def _surface_gravity(self) -> tuple[float, float]:
        """Exact normal gravity at equator and pole (Heiskanen & Moritz 2-141)."""
        if self.is_sphere:
            g = self.gm / self.a**2
            return g - self.omega**2 * self.a, g
        a, b, gm, m, ep = self.a, self.b, self.gm, self.m, self.ep
        q0 = self._q0()
        q0p = 3.0 * (1.0 + 1.0 / ep**2) * (1.0 - math.atan(ep) / ep) - 1.0
        gamma_e = gm / (a * b) * (1.0 - m - m * ep * q0p / (6.0 * q0))
        gamma_p = gm / (a * a) * (1.0 + m * ep * q0p / (3.0 * q0))
        return gamma_e, gamma_p

    @property
    def gamma_e(self) -> float:
        return self._surface_gravity()[0]

    @property
    def gamma_p(self) -> float:
        return self._surface_gravity()[1]

    @property
    def k_somigliana(self) -> float:
        ge, gp = self._surface_gravity()
        return self.b * gp / (self.a * ge) - 1.0

    def describe(self) -> dict:
        return {
            "name": self.name, "a_m": self.a, "f": self.f, "inverse_f": (1.0 / self.f) if self.f else None,
            "gm_m3ps2": self.gm, "omega_radps": self.omega, "b_m": self.b, "e2": self.e2,
            "J2": self.j2n(1), "gamma_e_mps2": self.gamma_e, "gamma_p_mps2": self.gamma_p,
        }


#: WGS84 reference ellipsoid (NIMA TR8350.2).
WGS84 = Ellipsoid("WGS84", pc.WGS84_A, pc.WGS84_F, pc.WGS84_GM, pc.WGS84_OMEGA)

#: Non-rotating sphere with the WGS84 GM and IUGG mean radius — the spherical reference model.
SPHERE = Ellipsoid("SPHERE-R1", pc.EARTH_MEAN_RADIUS, 0.0, pc.WGS84_GM, 0.0)


def get_ellipsoid(name: str) -> Ellipsoid:
    key = name.upper()
    if key == "WGS84":
        return WGS84
    if key in ("SPHERE", "SPHERE-R1"):
        return SPHERE
    raise ValueError(f"unknown ellipsoid {name!r}")


__all__ = ["Ellipsoid", "WGS84", "SPHERE", "get_ellipsoid"]
