"""Geographic coordinate handling: geodetic, ECEF and local ENU frames.

UNITS (internal convention)
    * Angles are stored in **radians** inside computations. Public constructors
      take explicitly-named degree or radian arguments (``latitude_deg``,
      ``latitude_rad``); there is no implicit angular unit anywhere.
    * Lengths are **metres**.
    * Heights are **ellipsoidal heights** above the reference ellipsoid
      (orthometric ↔ ellipsoidal conversion lives in :mod:`gravitas.earth.geoid`).

FRAMES
    ECEF  Earth-centred, Earth-fixed; Z along the rotation axis, X through the
          prime meridian at the equator.
    ENU   Local East-North-Up tangent frame at a geodetic origin; "Up" is the
          ellipsoidal normal (not the plumb line; their difference is the
          deflection of the vertical, < 1e-3 rad).

VALIDATION
    Invalid coordinates (NaN, |lat| > 90°, lon outside [-180°, 180°], heights
    outside a physically meaningful range) raise :class:`CoordinateError`. They
    are never wrapped or clipped silently. Use :func:`normalize_longitude_deg`
    explicitly if wrapping is wanted.
"""

from __future__ import annotations

import math
from dataclasses import dataclass

import numpy as np

from gravitas.earth.ellipsoid import WGS84, Ellipsoid

#: Physically meaningful ellipsoidal-height range [m]: Challenger Deep to
#: beyond geostationary orbit. Outside this range the near-Earth models used in
#: GRAVITAS are not intended to be applied.
MIN_HEIGHT_M = -12_000.0
MAX_HEIGHT_M = 5.0e7


class CoordinateError(ValueError):
    """Raised for invalid or non-physical coordinates."""


def deg_to_rad(x):
    return np.deg2rad(x)


def rad_to_deg(x):
    return np.rad2deg(x)


def normalize_longitude_deg(lon_deg: float) -> float:
    """Explicit wrap of a longitude into [-180, 180). Never called implicitly."""
    return ((lon_deg + 180.0) % 360.0) - 180.0


def _check_finite(name: str, value) -> None:
    arr = np.asarray(value, dtype=float)
    if not np.all(np.isfinite(arr)):
        raise CoordinateError(f"{name} must be finite, got {value!r}")


def validate_geodetic(latitude_deg, longitude_deg, height_m) -> None:
    """Raise :class:`CoordinateError` unless all inputs are valid geodetic coordinates."""
    _check_finite("latitude_deg", latitude_deg)
    _check_finite("longitude_deg", longitude_deg)
    _check_finite("height_m", height_m)
    lat = np.asarray(latitude_deg, dtype=float)
    lon = np.asarray(longitude_deg, dtype=float)
    h = np.asarray(height_m, dtype=float)
    if np.any(np.abs(lat) > 90.0):
        raise CoordinateError(f"latitude must be within [-90, 90] degrees, got {latitude_deg!r}")
    if np.any((lon < -180.0) | (lon > 180.0)):
        raise CoordinateError(f"longitude must be within [-180, 180] degrees, got {longitude_deg!r}")
    if np.any((h < MIN_HEIGHT_M) | (h > MAX_HEIGHT_M)):
        raise CoordinateError(f"height must be within [{MIN_HEIGHT_M}, {MAX_HEIGHT_M}] m, got {height_m!r}")


@dataclass(frozen=True)
class GeodeticPosition:
    """A validated geodetic position. Internally radians + metres."""

    latitude_rad: float
    longitude_rad: float
    height_m: float

    def __post_init__(self) -> None:
        validate_geodetic(math.degrees(self.latitude_rad), math.degrees(self.longitude_rad), self.height_m)

    @classmethod
    def from_degrees(cls, latitude_deg: float, longitude_deg: float, height_m: float = 0.0) -> "GeodeticPosition":
        validate_geodetic(latitude_deg, longitude_deg, height_m)
        return cls(math.radians(latitude_deg), math.radians(longitude_deg), float(height_m))

    @classmethod
    def from_radians(cls, latitude_rad: float, longitude_rad: float, height_m: float = 0.0) -> "GeodeticPosition":
        return cls(float(latitude_rad), float(longitude_rad), float(height_m))

    @property
    def latitude_deg(self) -> float:
        return math.degrees(self.latitude_rad)

    @property
    def longitude_deg(self) -> float:
        return math.degrees(self.longitude_rad)

    def to_ecef(self, ellipsoid: Ellipsoid = WGS84) -> np.ndarray:
        return geodetic_to_ecef(self.latitude_rad, self.longitude_rad, self.height_m, ellipsoid)

    def as_dict(self) -> dict:
        return {"latitude_deg": self.latitude_deg, "longitude_deg": self.longitude_deg, "altitude_m": self.height_m}


# ---------------------------------------------------------------------------
# Geodetic <-> ECEF
# ---------------------------------------------------------------------------
def prime_vertical_radius(latitude_rad, ellipsoid: Ellipsoid = WGS84):
    """N(φ) = a / sqrt(1 - e² sin² φ)."""
    s = np.sin(latitude_rad)
    return ellipsoid.a / np.sqrt(1.0 - ellipsoid.e2 * s * s)


def meridian_radius(latitude_rad, ellipsoid: Ellipsoid = WGS84):
    """M(φ) = a (1 - e²) / (1 - e² sin² φ)^{3/2}."""
    s = np.sin(latitude_rad)
    return ellipsoid.a * (1.0 - ellipsoid.e2) / (1.0 - ellipsoid.e2 * s * s) ** 1.5


def geodetic_to_ecef(latitude_rad, longitude_rad, height_m, ellipsoid: Ellipsoid = WGS84) -> np.ndarray:
    """Geodetic (radians, metres) → ECEF [m]. Vectorised; returns shape (..., 3).

    x = (N + h) cos φ cos λ
    y = (N + h) cos φ sin λ
    z = (N (1 - e²) + h) sin φ
    """
    lat = np.asarray(latitude_rad, dtype=float)
    lon = np.asarray(longitude_rad, dtype=float)
    h = np.asarray(height_m, dtype=float)
    n = prime_vertical_radius(lat, ellipsoid)
    cl = np.cos(lat)
    x = (n + h) * cl * np.cos(lon)
    y = (n + h) * cl * np.sin(lon)
    z = (n * (1.0 - ellipsoid.e2) + h) * np.sin(lat)
    return np.stack(np.broadcast_arrays(x, y, z), axis=-1)


def ecef_to_geodetic(xyz, ellipsoid: Ellipsoid = WGS84, tol_rad: float = 1e-14, max_iter: int = 30):
    """ECEF [m] → (latitude_rad, longitude_rad, height_m).

    Bowring's initial estimate followed by Newton-style fixed-point iteration on
    latitude. Converges to < 1e-14 rad (~0.06 nm) in ≤ 5 iterations for all
    heights in [MIN_HEIGHT_M, MAX_HEIGHT_M]. Raises ``RuntimeError`` if the
    iteration fails to converge (never returns an unconverged value silently).
    """
    p_xyz = np.asarray(xyz, dtype=float)
    if p_xyz.shape[-1] != 3:
        raise CoordinateError("ECEF input must have a trailing dimension of size 3")
    _check_finite("ecef", p_xyz)
    x, y, z = p_xyz[..., 0], p_xyz[..., 1], p_xyz[..., 2]
    a, b, e2, ep2 = ellipsoid.a, ellipsoid.b, ellipsoid.e2, ellipsoid.ep2
    lon = np.arctan2(y, x)
    p = np.hypot(x, y)
    if np.any((p == 0) & (z == 0)):
        raise CoordinateError("geodetic coordinates are undefined at the Earth's centre")
    if ellipsoid.is_sphere:
        lat = np.arctan2(z, p)
        h = np.hypot(p, z) - a
        return lat, lon, h
    # Bowring initial guess
    theta = np.arctan2(z * a, p * b)
    lat = np.arctan2(z + ep2 * b * np.sin(theta) ** 3, p - e2 * a * np.cos(theta) ** 3)
    for _ in range(max_iter):
        n = prime_vertical_radius(lat, ellipsoid)
        cl = np.cos(lat)
        # h via the numerically stable form for all latitudes
        h = np.where(np.abs(cl) > 1e-10, p / np.where(cl == 0, 1.0, cl) - n, np.abs(z) - b)
        lat_new = np.arctan2(z, p * (1.0 - e2 * n / (n + h)))
        if np.all(np.abs(lat_new - lat) < tol_rad):
            lat = lat_new
            break
        lat = lat_new
    else:  # pragma: no cover - defensive
        raise RuntimeError("ecef_to_geodetic failed to converge")
    n = prime_vertical_radius(lat, ellipsoid)
    sl, cl = np.sin(lat), np.cos(lat)
    # Height from the projection onto the normal: robust at all latitudes.
    h = p * cl + z * sl - a * a / n
    return lat, lon, h


# ---------------------------------------------------------------------------
# ENU
# ---------------------------------------------------------------------------
def enu_rotation_matrix(latitude_rad: float, longitude_rad: float) -> np.ndarray:
    """Rotation matrix R such that v_enu = R @ v_ecef (rows are E, N, U unit vectors)."""
    sl, cl = math.sin(latitude_rad), math.cos(latitude_rad)
    so, co = math.sin(longitude_rad), math.cos(longitude_rad)
    return np.array(
        [
            [-so, co, 0.0],
            [-sl * co, -sl * so, cl],
            [cl * co, cl * so, sl],
        ]
    )


def ecef_to_enu(xyz, origin: GeodeticPosition, ellipsoid: Ellipsoid = WGS84) -> np.ndarray:
    """ECEF point(s) → ENU offsets [m] relative to ``origin``."""
    r = enu_rotation_matrix(origin.latitude_rad, origin.longitude_rad)
    d = np.asarray(xyz, dtype=float) - origin.to_ecef(ellipsoid)
    return d @ r.T


def enu_to_ecef(enu, origin: GeodeticPosition, ellipsoid: Ellipsoid = WGS84) -> np.ndarray:
    """ENU offsets [m] relative to ``origin`` → ECEF point(s)."""
    r = enu_rotation_matrix(origin.latitude_rad, origin.longitude_rad)
    return np.asarray(enu, dtype=float) @ r + origin.to_ecef(ellipsoid)


def vector_ecef_to_enu(v_ecef, latitude_rad: float, longitude_rad: float) -> np.ndarray:
    """Rotate a free vector (e.g. acceleration) from ECEF axes to local ENU axes."""
    return np.asarray(v_ecef, dtype=float) @ enu_rotation_matrix(latitude_rad, longitude_rad).T


def enu_to_geodetic(enu, origin: GeodeticPosition, ellipsoid: Ellipsoid = WGS84):
    """ENU offsets → (lat_rad, lon_rad, h_m)."""
    return ecef_to_geodetic(enu_to_ecef(enu, origin, ellipsoid), ellipsoid)


__all__ = [
    "CoordinateError", "GeodeticPosition", "validate_geodetic", "normalize_longitude_deg",
    "deg_to_rad", "rad_to_deg", "prime_vertical_radius", "meridian_radius",
    "geodetic_to_ecef", "ecef_to_geodetic", "enu_rotation_matrix", "ecef_to_enu", "enu_to_ecef",
    "vector_ecef_to_enu", "enu_to_geodetic", "MIN_HEIGHT_M", "MAX_HEIGHT_M",
]
