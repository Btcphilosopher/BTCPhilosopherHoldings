"""Closed-form reference gravity formulas.

These formulas are *independent* of the harmonic-series model in
:mod:`gravitas.earth.gravity`, which lets the two be cross-validated.

MODEL 1 — spherical, non-rotating Earth
    g(h) = GM / (R + h)²
    ASSUMPTIONS: point-mass Earth, no rotation, no flattening.
    LIMITATIONS: ignores the ≈ 5.2 Gal equator-to-pole variation.

MODEL 2 — Somigliana closed formula (normal gravity *on* the ellipsoid)
    γ(φ) = γ_e (1 + k sin²φ) / sqrt(1 − e² sin²φ)
    EXPECTED VALIDITY: exact for the level ellipsoid at h = 0.

MODEL 3 — second-order free-air extension (NIMA TR8350.2 eq. 4-3)
    γ_h = γ(φ) [1 − (2/a)(1 + f + m − 2 f sin²φ) h + (3/a²) h²]
    EXPECTED VALIDITY: the coefficients are truncated at first order in (f, m),
    so the linear term carries a relative error O(f²) ≈ 1e-5: ≈ 0.3 µGal per
    100 m of height (verified against the zonal-series model in the tests).
    Use :class:`gravitas.earth.gravity.EarthGravityModel` for precise work.
"""

from __future__ import annotations

import numpy as np

from gravitas.constants import physical as pc
from gravitas.earth.ellipsoid import WGS84, Ellipsoid


def spherical_gravity(height_m, gm: float = pc.WGS84_GM, radius_m: float = pc.EARTH_MEAN_RADIUS):
    """Spherical-Earth gravity GM/(R+h)² [m/s²]."""
    r = radius_m + np.asarray(height_m, dtype=float)
    if np.any(r <= 0):
        raise ValueError("radius + height must be positive")
    return gm / r**2


def spherical_gravity_at_radius(r_m, gm: float = pc.WGS84_GM):
    r = np.asarray(r_m, dtype=float)
    if np.any(r <= 0):
        raise ValueError("radius must be positive")
    return gm / r**2


def somigliana(latitude_rad, ellipsoid: Ellipsoid = WGS84):
    """Normal gravity on the ellipsoid surface [m/s²]."""
    s2 = np.sin(np.asarray(latitude_rad, dtype=float)) ** 2
    return ellipsoid.gamma_e * (1.0 + ellipsoid.k_somigliana * s2) / np.sqrt(1.0 - ellipsoid.e2 * s2)


def normal_gravity_free_air(latitude_rad, height_m, ellipsoid: Ellipsoid = WGS84):
    """Normal gravity at ellipsoidal height h via the 2nd-order Taylor series [m/s²]."""
    lat = np.asarray(latitude_rad, dtype=float)
    h = np.asarray(height_m, dtype=float)
    g0 = somigliana(lat, ellipsoid)
    a, f, m = ellipsoid.a, ellipsoid.f, ellipsoid.m
    s2 = np.sin(lat) ** 2
    return g0 * (1.0 - 2.0 / a * (1.0 + f + m - 2.0 * f * s2) * h + 3.0 / a**2 * h * h)


def free_air_gradient(latitude_rad, ellipsoid: Ellipsoid = WGS84):
    """Linear free-air gradient ∂γ/∂h at h = 0 [m/s² per m] (≈ −3.086e-6)."""
    lat = np.asarray(latitude_rad, dtype=float)
    a, f, m = ellipsoid.a, ellipsoid.f, ellipsoid.m
    return -somigliana(lat, ellipsoid) * 2.0 / a * (1.0 + f + m - 2.0 * f * np.sin(lat) ** 2)


def international_gravity_formula_1980(latitude_rad):
    """GRS80 series form (informational comparison; Moritz 1980)."""
    s = np.sin(np.asarray(latitude_rad, dtype=float))
    s2 = s * s
    return 9.780_327 * (1.0 + 0.005_302_4 * s2 - 0.000_005_8 * (2.0 * s * np.cos(latitude_rad)) ** 2)


__all__ = [
    "spherical_gravity", "spherical_gravity_at_radius", "somigliana", "normal_gravity_free_air",
    "free_air_gradient", "international_gravity_formula_1980",
]
