"""Earth rotation: angular velocity, sidereal time and celestial → terrestrial rotation.

MODEL
    Uniform rotation about the ECEF Z axis with ω = 7.292115e-5 rad/s (WGS84).
    Orientation is given by Greenwich Mean Sidereal Time (IAU 1982 expression,
    Meeus 1998 eq. 12.4). Celestial positions referred to the *mean equinox of
    date* are rotated into ECEF by R_z(GMST).

ASSUMPTIONS
    * UT1 ≈ UTC (|UT1 − UTC| < 0.9 s ⇒ < 4″ of rotation).
    * Nutation (≤ 17″), polar motion (≤ 0.5″) and frame bias are ignored.

LIMITATIONS / EXPECTED VALIDITY
    Body directions are good to ≈ 20″ — far below the ≈ 0.01°–0.05° error of the
    reduced-order lunar ephemeris, so this is never the limiting term for tides.
"""

from __future__ import annotations

import math
from datetime import datetime, timezone

import numpy as np

from gravitas.constants import physical as pc

EARTH_ANGULAR_VELOCITY = pc.WGS84_OMEGA


def angular_velocity_vector(omega: float = EARTH_ANGULAR_VELOCITY) -> np.ndarray:
    return np.array([0.0, 0.0, omega])


def datetime_to_julian_date(dt: datetime) -> float:
    """UTC datetime → Julian date. Naive datetimes are rejected (no implicit timezone)."""
    if dt.tzinfo is None:
        raise ValueError("datetime must be timezone-aware (UTC)")
    dt = dt.astimezone(timezone.utc)
    unix = dt.timestamp()
    return unix / pc.SECONDS_PER_DAY + 2_440_587.5


def julian_centuries_since_j2000(jd) -> np.ndarray:
    return (np.asarray(jd, dtype=float) - pc.JD_J2000) / pc.DAYS_PER_JULIAN_CENTURY


def gmst_rad(jd_ut1) -> np.ndarray:
    """Greenwich mean sidereal time [rad] (Meeus eq. 12.4)."""
    jd = np.asarray(jd_ut1, dtype=float)
    t = julian_centuries_since_j2000(jd)
    deg = (280.460_618_37 + 360.985_647_366_29 * (jd - pc.JD_J2000)
           + 0.000_387_933 * t * t - t**3 / 38_710_000.0)
    return np.deg2rad(np.mod(deg, 360.0))


def earth_rotation_angle_rad(jd_ut1) -> np.ndarray:
    """IERS 2010 Earth rotation angle (CIO based) [rad]; informational."""
    du = np.asarray(jd_ut1, dtype=float) - pc.JD_J2000
    return 2.0 * math.pi * np.mod(0.779_057_273_264_0 + 1.002_737_811_911_354_48 * du, 1.0)


def celestial_to_ecef(vec_eq, gmst) -> np.ndarray:
    """Rotate equatorial (mean equinox of date) vectors to ECEF: R_z(GMST) · v.

    ``vec_eq`` shape (N, 3); ``gmst`` shape (N,).
    """
    v = np.atleast_2d(np.asarray(vec_eq, dtype=float))
    th = np.asarray(gmst, dtype=float)
    c, s = np.cos(th), np.sin(th)
    out = np.empty_like(v)
    out[:, 0] = c * v[:, 0] + s * v[:, 1]
    out[:, 1] = -s * v[:, 0] + c * v[:, 1]
    out[:, 2] = v[:, 2]
    return out


__all__ = [
    "EARTH_ANGULAR_VELOCITY", "angular_velocity_vector", "datetime_to_julian_date",
    "julian_centuries_since_j2000", "gmst_rad", "earth_rotation_angle_rad", "celestial_to_ecef",
]
