"""Earth gravity field model with explicit, separately-exposed components.

MODEL
    Newtonian attraction
        * spherical:  point mass GM at the geocentre, a = −GM r̂ / r²
        * oblate:     level-ellipsoid zonal series J2..J10 (see
                      :func:`gravitas.physics.acceleration.zonal_acceleration`)
    Centrifugal acceleration  a_c = ω² (x, y, 0)
    Effective gravity         g = a_N + a_c

    The instrument location is always placed on the WGS84 ellipsoid geometry
    (geodetic latitude, longitude, ellipsoidal height). The ``spherical``
    reference model additionally offers the textbook g = GM/(R₁+h)² with R₁ the
    mean radius, which ignores where on the ellipsoid the station is.

PHYSICS SWITCHES (affect the simulation, not only the display)
    earth_gravity     False ⇒ no Earth attraction or rotation (g_earth = 0)
    earth_oblateness  False ⇒ point-mass attraction at the true geocentric radius
    earth_rotation    False ⇒ no centrifugal term
    altitude          False ⇒ evaluated at h = 0 on the ellipsoid
    latitude          False ⇒ evaluated at the reference latitude (default 45°)

EXPECTED VALIDITY
    With oblateness+rotation the series reproduces Somigliana's closed formula
    at h = 0 to < 1e-9 m/s² (0.1 µGal) — verified in tests/test_gravity.py.
"""

from __future__ import annotations

import math
from dataclasses import asdict, dataclass, field

import numpy as np

from gravitas.earth.coordinates import (
    GeodeticPosition,
    enu_rotation_matrix,
    geodetic_to_ecef,
)
from gravitas.earth.ellipsoid import SPHERE, WGS84, Ellipsoid
from gravitas.earth.normal_gravity import normal_gravity_free_air, somigliana, spherical_gravity
from gravitas.physics.acceleration import point_mass_acceleration, zonal_acceleration
from gravitas.physics.centrifugal import centrifugal_acceleration


@dataclass
class EarthModelSwitches:
    earth_gravity: bool = True
    earth_oblateness: bool = True
    earth_rotation: bool = True
    altitude: bool = True
    latitude: bool = True
    reference_latitude_deg: float = 45.0


@dataclass(frozen=True)
class GravityBreakdown:
    """Separately exposed Earth-gravity components at one station (ENU axes)."""

    latitude_rad: float
    longitude_rad: float
    height_m: float
    newtonian_enu_mps2: np.ndarray
    centrifugal_enu_mps2: np.ndarray
    effective_enu_mps2: np.ndarray

    @property
    def newtonian_mps2(self) -> float:
        return float(np.linalg.norm(self.newtonian_enu_mps2))

    @property
    def centrifugal_mps2(self) -> float:
        return float(np.linalg.norm(self.centrifugal_enu_mps2))

    @property
    def effective_mps2(self) -> float:
        """|g| — what a levelled gravimeter measures from the Earth field alone."""
        return float(np.linalg.norm(self.effective_enu_mps2))

    @property
    def plumb_down_enu(self) -> np.ndarray:
        """Unit vector along the plumb line (direction of g), ENU axes."""
        n = np.linalg.norm(self.effective_enu_mps2)
        if n == 0:
            return np.array([0.0, 0.0, -1.0])
        return self.effective_enu_mps2 / n

    @property
    def deflection_from_normal_rad(self) -> float:
        """Angle between the plumb line and the ellipsoidal normal."""
        d = self.plumb_down_enu
        return float(math.acos(max(-1.0, min(1.0, -d[2]))))

    def as_dict(self) -> dict:
        return {
            "latitude_deg": math.degrees(self.latitude_rad), "longitude_deg": math.degrees(self.longitude_rad),
            "altitude_m": self.height_m,
            "newtonian_mps2": self.newtonian_mps2, "newtonian_enu_mps2": self.newtonian_enu_mps2.tolist(),
            "centrifugal_mps2": self.centrifugal_mps2, "centrifugal_enu_mps2": self.centrifugal_enu_mps2.tolist(),
            "effective_mps2": self.effective_mps2, "effective_enu_mps2": self.effective_enu_mps2.tolist(),
            "deflection_from_normal_rad": self.deflection_from_normal_rad,
        }


@dataclass
class EarthGravityModel:
    """Configurable Earth gravity field.

    ``ellipsoid`` provides geometry and the normal field; ``n_zonal`` is the
    number of zonal terms (J2..J_{2n}).
    """

    ellipsoid: Ellipsoid = WGS84
    n_zonal: int = 5
    switches: EarthModelSwitches = field(default_factory=EarthModelSwitches)

    def effective_position(self, latitude_rad: float, longitude_rad: float, height_m: float) -> tuple[float, float, float]:
        """Apply the latitude/altitude switches to the evaluation position."""
        lat = latitude_rad if self.switches.latitude else math.radians(self.switches.reference_latitude_deg)
        h = height_m if self.switches.altitude else 0.0
        return lat, longitude_rad, h

    def evaluate_ecef(self, r_ecef: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
        """(Newtonian, centrifugal) acceleration vectors in ECEF [m/s²]."""
        r = np.asarray(r_ecef, dtype=float)
        if not self.switches.earth_gravity:
            z = np.zeros_like(r)
            return z, z.copy()
        if self.switches.earth_oblateness and not self.ellipsoid.is_sphere:
            a_n = zonal_acceleration(r, self.ellipsoid, self.n_zonal)
        else:
            a_n = point_mass_acceleration(r, self.ellipsoid.gm)
        if self.switches.earth_rotation:
            a_c = centrifugal_acceleration(r, self.ellipsoid.omega)
        else:
            a_c = np.zeros_like(r)
        return a_n, a_c

    def evaluate(self, latitude_rad: float, longitude_rad: float, height_m: float) -> GravityBreakdown:
        lat, lon, h = self.effective_position(latitude_rad, longitude_rad, height_m)
        r = geodetic_to_ecef(lat, lon, h, self.ellipsoid)
        a_n, a_c = self.evaluate_ecef(r)
        rot = enu_rotation_matrix(lat, lon)
        n_enu = rot @ a_n
        c_enu = rot @ a_c
        return GravityBreakdown(lat, lon, h, n_enu, c_enu, n_enu + c_enu)

    def evaluate_position(self, pos: GeodeticPosition) -> GravityBreakdown:
        return self.evaluate(pos.latitude_rad, pos.longitude_rad, pos.height_m)

    def magnitude(self, latitude_rad, longitude_rad, height_m) -> np.ndarray:
        """Vectorised |g_eff| for arrays of positions [m/s²]."""
        lat = np.atleast_1d(np.asarray(latitude_rad, dtype=float))
        lon = np.broadcast_to(np.asarray(longitude_rad, dtype=float), lat.shape)
        h = np.broadcast_to(np.asarray(height_m, dtype=float), lat.shape)
        if not self.switches.latitude:
            lat = np.full_like(lat, math.radians(self.switches.reference_latitude_deg))
        if not self.switches.altitude:
            h = np.zeros_like(lat)
        r = geodetic_to_ecef(lat, lon, h, self.ellipsoid)
        a_n, a_c = self.evaluate_ecef(r)
        return np.linalg.norm(a_n + a_c, axis=-1)

    def components(self, latitude_rad, longitude_rad, height_m) -> dict[str, np.ndarray]:
        """Vectorised component magnitudes [m/s²] for arrays of positions.

        Returns |a_N|, |a_c|, the centrifugal component along the plumb line
        (negative: it reduces gravity) and |g_eff|.
        """
        lat = np.atleast_1d(np.asarray(latitude_rad, dtype=float))
        lon = np.broadcast_to(np.asarray(longitude_rad, dtype=float), lat.shape)
        h = np.broadcast_to(np.asarray(height_m, dtype=float), lat.shape)
        if not self.switches.latitude:
            lat = np.full_like(lat, math.radians(self.switches.reference_latitude_deg))
        if not self.switches.altitude:
            h = np.zeros_like(lat)
        r = geodetic_to_ecef(lat, lon, h, self.ellipsoid)
        a_n, a_c = self.evaluate_ecef(r)
        g = a_n + a_c
        gm = np.linalg.norm(g, axis=-1)
        down = g / np.where(gm == 0, 1.0, gm)[..., None]
        return {"newtonian_mps2": np.linalg.norm(a_n, axis=-1), "centrifugal_mps2": np.linalg.norm(a_c, axis=-1),
                "centrifugal_vertical_mps2": np.einsum("...i,...i->...", a_c, down), "effective_mps2": gm}

    def vertical_gradient(self, latitude_rad: float, longitude_rad: float, height_m: float, step_m: float = 1.0) -> float:
        """∂|g|/∂h by central difference [m/s² per m]."""
        up = self.magnitude(latitude_rad, longitude_rad, height_m + step_m)[0]
        dn = self.magnitude(latitude_rad, longitude_rad, height_m - step_m)[0]
        return float((up - dn) / (2.0 * step_m))

    def horizontal_gradient(self, latitude_rad: float, longitude_rad: float, height_m: float, step_m: float = 10.0) -> float:
        """∂|g|/∂(north distance) [m/s² per m] (numerical)."""
        from gravitas.earth.coordinates import meridian_radius

        dlat = step_m / float(meridian_radius(latitude_rad, self.ellipsoid))
        up = self.magnitude(latitude_rad + dlat, longitude_rad, height_m)[0]
        dn = self.magnitude(latitude_rad - dlat, longitude_rad, height_m)[0]
        return float((up - dn) / (2.0 * step_m))

    def describe(self) -> dict:
        return {"ellipsoid": self.ellipsoid.describe(), "n_zonal": self.n_zonal, "switches": asdict(self.switches)}


def compare_models(latitude_rad: float, longitude_rad: float, height_m: float) -> dict:
    """Spherical vs rotating-oblate comparison at one station (all m/s²)."""
    full = EarthGravityModel()
    no_rot = EarthGravityModel(switches=EarthModelSwitches(earth_rotation=False))
    point = EarthGravityModel(switches=EarthModelSwitches(earth_oblateness=False, earth_rotation=False))
    b = full.evaluate(latitude_rad, longitude_rad, height_m)
    return {
        "spherical_mps2": float(spherical_gravity(height_m)),
        "point_mass_true_radius_mps2": point.evaluate(latitude_rad, longitude_rad, height_m).effective_mps2,
        "oblate_no_rotation_mps2": no_rot.evaluate(latitude_rad, longitude_rad, height_m).effective_mps2,
        "rotating_oblate_mps2": b.effective_mps2,
        "newtonian_mps2": b.newtonian_mps2,
        "centrifugal_mps2": b.centrifugal_mps2,
        "somigliana_mps2": float(somigliana(latitude_rad)),
        "somigliana_free_air_mps2": float(normal_gravity_free_air(latitude_rad, height_m)),
    }


__all__ = ["EarthModelSwitches", "GravityBreakdown", "EarthGravityModel", "compare_models", "SPHERE", "WGS84"]
