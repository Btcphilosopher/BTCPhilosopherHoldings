"""Terrain gravity: Bouguer plate and prism-based terrain effect from a height grid.

MODEL
    Bouguer plate            δg_B = 2π G ρ H
    Terrain (prism sum)      each DEM cell is a vertical right prism from the
                             reference datum (z = 0) to its height; its vertical
                             attraction is evaluated with the closed-form Nagy
                             prism formula and summed at the station.

ASSUMPTIONS
    Flat-Earth (planar) geometry: valid for terrain within ≈ 20 km of the
    station (curvature error ≈ d²/(2R) ≈ 31 m of drop at 20 km). Uniform
    terrain density ρ (default 2670 kg/m³, the conventional crustal density).

LIMITATIONS
    The synthetic DEM helpers (:func:`synthetic_gaussian_hill`) produce
    SYNTHETIC terrain only. No real DEM is bundled.
"""

from __future__ import annotations

import math

import numpy as np

from gravitas.constants.physical import G
from gravitas.physics.anomalies import Slab

CRUSTAL_DENSITY_KGPM3 = 2670.0


def bouguer_plate(height_m, density_kgpm3: float = CRUSTAL_DENSITY_KGPM3):
    """Attraction of an infinite horizontal slab of thickness ``height_m`` [m/s²]."""
    return 2.0 * math.pi * G * density_kgpm3 * np.asarray(height_m, dtype=float)


def bouguer_gradient(density_kgpm3: float = CRUSTAL_DENSITY_KGPM3) -> float:
    """2πGρ [m/s² per m] (≈ 1.119e-6 for ρ = 2670 kg/m³)."""
    return 2.0 * math.pi * G * density_kgpm3


class TerrainModel:
    """Gridded synthetic terrain in a local ENU frame (heights above datum z = 0)."""

    def __init__(self, east_m: np.ndarray, north_m: np.ndarray, height_m: np.ndarray,
                 density_kgpm3: float = CRUSTAL_DENSITY_KGPM3):
        east_m = np.asarray(east_m, dtype=float)
        north_m = np.asarray(north_m, dtype=float)
        height_m = np.asarray(height_m, dtype=float)
        if height_m.shape != (north_m.size, east_m.size):
            raise ValueError("height grid must have shape (len(north), len(east))")
        if not np.all(np.isfinite(height_m)):
            raise ValueError("terrain heights must be finite")
        if east_m.size < 2 or north_m.size < 2:
            raise ValueError("terrain grid needs at least 2×2 nodes")
        self.east_m, self.north_m, self.height_m = east_m, north_m, height_m
        self.density_kgpm3 = float(density_kgpm3)
        self.de = float(np.mean(np.diff(east_m)))
        self.dn = float(np.mean(np.diff(north_m)))

    def gravity_effect(self, station_enu_m) -> float:
        """Vertical attraction of all terrain prisms at the station (δg, m/s²)."""
        st = np.asarray(station_enu_m, dtype=float).reshape(1, 3)
        total = 0.0
        for j, n in enumerate(self.north_m):
            for i, e in enumerate(self.east_m):
                h = self.height_m[j, i]
                if h == 0.0:
                    continue
                top, bot = max(h, 0.0), min(h, 0.0)
                rho = self.density_kgpm3 if h > 0 else -self.density_kgpm3
                prism = Slab(center_enu_m=[e, n, 0.5 * (top + bot)], size_enu_m=[self.de, self.dn, top - bot],
                             density_contrast_kgpm3=rho)
                total += float(prism.delta_g(st)[0])
        return total


def synthetic_gaussian_hill(extent_m: float = 2000.0, n: int = 41, peak_m: float = 50.0, width_m: float = 300.0):
    """SYNTHETIC terrain: a Gaussian hill centred at the origin."""
    e = np.linspace(-extent_m / 2, extent_m / 2, n)
    ee, nn = np.meshgrid(e, e)
    return e, e.copy(), peak_m * np.exp(-(ee**2 + nn**2) / (2 * width_m**2))


__all__ = ["bouguer_plate", "bouguer_gradient", "TerrainModel", "synthetic_gaussian_hill", "CRUSTAL_DENSITY_KGPM3"]
