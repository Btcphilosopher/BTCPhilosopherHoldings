"""Reduced-order lunar and solar body-tide model.

MODEL
    1. Reduced-order ephemerides (Meeus, *Astronomical Algorithms*, 2nd ed.):
       * Sun: ch. 25 low-accuracy theory (geometric longitude, radius vector).
       * Moon: ch. 47 with the 19 largest longitude/distance terms and the 13
         largest latitude terms of Tables 47.A/47.B.
       Positions are referred to the mean equinox of date and rotated to ECEF
       with GMST (:mod:`gravitas.earth.rotation`).
    2. Exact Newtonian differential acceleration at the station
       (:func:`gravitas.physics.tidal.tidal_acceleration`).
    3. Projection on the local plumb line, giving the change of measured
       gravity δg (positive = gravity increases).
    4. Elastic-Earth response: δg_elastic = δ · δg_rigid with the degree-2
       gravimetric factor δ = 1 + h₂ − 3/2 k₂ ≈ 1.156.

ASSUMPTIONS
    TT ≈ UTC and UT1 ≈ UTC (69 s offset ⇒ lunar position error ≈ 0.01°).
    Frequency-independent δ (real δ varies by ~1 % near the diurnal FCN resonance).
    No ocean loading, no atmospheric loading, no polar-motion tide.

LIMITATIONS / EXPECTED VALIDITY
    Lunar longitude ≈ 0.02°, distance ≈ 100 km ⇒ tidal amplitude error ≲ 0.3 %
    (≲ 0.5 µGal of a ~±150 µGal signal). Not a replacement for ETERNA/Tamura
    tidal catalogues at the 0.1 µGal level.

SIGN CONVENTION
    δg > 0 means the instrument sees *more* gravity. With the Moon at the zenith
    the rigid-Earth tide is ≈ −110 µGal.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime

import numpy as np

from gravitas.constants import physical as pc
from gravitas.earth.coordinates import enu_rotation_matrix, geodetic_to_ecef
from gravitas.earth.ellipsoid import WGS84, Ellipsoid
from gravitas.earth.rotation import (
    celestial_to_ecef,
    datetime_to_julian_date,
    gmst_rad,
    julian_centuries_since_j2000,
)
from gravitas.physics.tidal import tidal_acceleration

_D2R = np.pi / 180.0

# Meeus Table 47.A: (D, M, M', F, Σl [1e-6 deg], Σr [1e-3 km])
_MOON_LR = np.array([
    (0, 0, 1, 0, 6288774, -20905355),
    (2, 0, -1, 0, 1274027, -3699111),
    (2, 0, 0, 0, 658314, -2955968),
    (0, 0, 2, 0, 213618, -569925),
    (0, 1, 0, 0, -185116, 48888),
    (0, 0, 0, 2, -114332, -3149),
    (2, 0, -2, 0, 58793, 246158),
    (2, -1, -1, 0, 57066, -152138),
    (2, 0, 1, 0, 53322, -170733),
    (2, -1, 0, 0, 45758, -204586),
    (0, 1, -1, 0, -40923, -129620),
    (1, 0, 0, 0, -34720, 108743),
    (0, 1, 1, 0, -30383, 104755),
    (2, 0, 0, -2, 15327, 10321),
    (0, 0, 1, 2, -12528, 0),
    (0, 0, 1, -2, 10980, 79661),
    (4, 0, -1, 0, 10675, -34782),
    (0, 0, 3, 0, 10034, -23210),
    (4, 0, -2, 0, 8548, -21636),
], dtype=float)

# Meeus Table 47.B: (D, M, M', F, Σb [1e-6 deg])
_MOON_B = np.array([
    (0, 0, 0, 1, 5128122),
    (0, 0, 1, 1, 280602),
    (0, 0, 1, -1, 277693),
    (2, 0, 0, -1, 173237),
    (2, 0, -1, 1, 55413),
    (2, 0, -1, -1, 46271),
    (2, 0, 0, 1, 32573),
    (0, 0, 2, 1, 17198),
    (2, 0, 1, -1, 9266),
    (0, 0, 2, -1, 8822),
    (2, -1, 0, -1, 8216),
    (2, 0, -2, -1, 4324),
    (2, 0, 1, 1, 4200),
], dtype=float)


def mean_obliquity_rad(t_centuries) -> np.ndarray:
    """Mean obliquity of the ecliptic (Meeus 22.2, truncated) [rad]."""
    t = np.asarray(t_centuries, dtype=float)
    return (23.439_291_111 - 0.013_004_167 * t - 1.639e-7 * t * t + 5.036e-7 * t**3) * _D2R


def sun_ecliptic(jd) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Sun geometric ecliptic longitude [rad], latitude [rad] (=0), distance [m]."""
    t = julian_centuries_since_j2000(jd)
    l0 = 280.466_46 + 36_000.769_83 * t + 0.000_303_2 * t * t
    m = (357.529_11 + 35_999.050_29 * t - 0.000_153_7 * t * t) * _D2R
    e = 0.016_708_634 - 0.000_042_037 * t - 0.000_000_126_7 * t * t
    c = ((1.914_602 - 0.004_817 * t - 0.000_014 * t * t) * np.sin(m)
         + (0.019_993 - 0.000_101 * t) * np.sin(2 * m) + 0.000_289 * np.sin(3 * m))
    lon = np.mod(l0 + c, 360.0) * _D2R
    nu = m + c * _D2R
    r_au = 1.000_001_018 * (1 - e * e) / (1 + e * np.cos(nu))
    return lon, np.zeros_like(lon), r_au * pc.ASTRONOMICAL_UNIT


def moon_ecliptic(jd) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Moon geocentric ecliptic longitude [rad], latitude [rad], distance [m]."""
    t = julian_centuries_since_j2000(jd)
    lp = 218.316_447_7 + 481_267.881_234_21 * t - 0.001_578_6 * t * t
    d = (297.850_192_1 + 445_267.111_403_4 * t - 0.001_881_9 * t * t) * _D2R
    m = (357.529_109_2 + 35_999.050_290_9 * t - 0.000_153_6 * t * t) * _D2R
    mp = (134.963_396_4 + 477_198.867_505_5 * t + 0.008_741_4 * t * t) * _D2R
    f = (93.272_095_0 + 483_202.017_523_3 * t - 0.003_653_9 * t * t) * _D2R
    ecc = 1.0 - 0.002_516 * t - 0.000_007_4 * t * t
    a1 = (119.75 + 131.849 * t) * _D2R
    a2 = (53.09 + 479_264.290 * t) * _D2R
    a3 = (313.45 + 481_266.484 * t) * _D2R

    sl = np.zeros_like(t)
    sr = np.zeros_like(t)
    for cd, cm, cmp_, cf, cl, cr in _MOON_LR:
        arg = cd * d + cm * m + cmp_ * mp + cf * f
        efac = ecc ** abs(cm)
        sl = sl + cl * efac * np.sin(arg)
        sr = sr + cr * efac * np.cos(arg)
    sb = np.zeros_like(t)
    for cd, cm, cmp_, cf, cb in _MOON_B:
        arg = cd * d + cm * m + cmp_ * mp + cf * f
        sb = sb + cb * ecc ** abs(cm) * np.sin(arg)
    lp_rad = lp * _D2R
    # additive terms (Meeus p. 338)
    sl = sl + 3958 * np.sin(a1) + 1962 * np.sin(lp_rad - f) + 318 * np.sin(a2)
    sb = (sb - 2235 * np.sin(lp_rad) + 382 * np.sin(a3) + 175 * np.sin(a1 - f) + 175 * np.sin(a1 + f)
          + 127 * np.sin(lp_rad - mp) - 115 * np.sin(lp_rad + mp))
    lon = np.mod(lp + sl * 1e-6, 360.0) * _D2R
    lat = sb * 1e-6 * _D2R
    dist = (385_000.56 + sr * 1e-3) * 1e3
    return lon, lat, dist


def ecliptic_to_equatorial(lon, lat, dist, obliquity) -> np.ndarray:
    lon, lat, dist, eps = (np.asarray(v, dtype=float) for v in (lon, lat, dist, obliquity))
    cb = np.cos(lat)
    x = dist * cb * np.cos(lon)
    y = dist * (np.cos(eps) * cb * np.sin(lon) - np.sin(eps) * np.sin(lat))
    z = dist * (np.sin(eps) * cb * np.sin(lon) + np.cos(eps) * np.sin(lat))
    return np.stack([x, y, z], axis=-1)


def body_positions_ecef(jd) -> tuple[np.ndarray, np.ndarray]:
    """(Moon, Sun) ECEF positions [m] for Julian date(s) ``jd``; shapes (N, 3)."""
    jd = np.atleast_1d(np.asarray(jd, dtype=float))
    t = julian_centuries_since_j2000(jd)
    eps = mean_obliquity_rad(t)
    th = gmst_rad(jd)
    moon = celestial_to_ecef(ecliptic_to_equatorial(*moon_ecliptic(jd), eps), th)
    sun = celestial_to_ecef(ecliptic_to_equatorial(*sun_ecliptic(jd), eps), th)
    return moon, sun


@dataclass
class TideComponents:
    """Tidal gravity changes along the plumb line [m/s²] (positive = more gravity)."""

    lunar_mps2: np.ndarray
    solar_mps2: np.ndarray

    @property
    def combined_mps2(self) -> np.ndarray:
        return self.lunar_mps2 + self.solar_mps2


@dataclass
class TideModel:
    """Body-tide model. ``gravimetric_factor`` = 1 gives the rigid-Earth tide."""

    include_moon: bool = True
    include_sun: bool = True
    gravimetric_factor: float = pc.GRAVIMETRIC_FACTOR
    ellipsoid: Ellipsoid = WGS84

    def compute(self, jd, latitude_rad, longitude_rad, height_m, plumb_down_enu=None) -> TideComponents:
        """Tidal gravity at station(s) for Julian date(s) ``jd``.

        ``latitude_rad`` etc. may be scalars or arrays matching ``jd``.
        ``plumb_down_enu`` is the unit plumb vector; default is −Up (ellipsoidal
        normal), which differs from the true plumb line by < 1e-3 rad ⇒ relative
        error < 5e-7 of the tide.
        """
        jd = np.atleast_1d(np.asarray(jd, dtype=float))
        n = jd.size
        lat = np.broadcast_to(np.asarray(latitude_rad, dtype=float), (n,))
        lon = np.broadcast_to(np.asarray(longitude_rad, dtype=float), (n,))
        h = np.broadcast_to(np.asarray(height_m, dtype=float), (n,))
        r_obs = geodetic_to_ecef(lat, lon, h, self.ellipsoid)
        moon, sun = body_positions_ecef(jd)
        # ECEF "down" vectors at each sample
        if np.all(lat == lat[0]) and np.all(lon == lon[0]):
            rot = enu_rotation_matrix(float(lat[0]), float(lon[0]))
            down_enu = np.array([0.0, 0.0, -1.0]) if plumb_down_enu is None else np.asarray(plumb_down_enu, float)
            down = np.broadcast_to(down_enu @ rot, (n, 3))
        else:
            sl, cl, so, co = np.sin(lat), np.cos(lat), np.sin(lon), np.cos(lon)
            down = -np.stack([cl * co, cl * so, sl], axis=-1)
        lunar = np.zeros(n)
        solar = np.zeros(n)
        if self.include_moon:
            lunar = self.gravimetric_factor * np.einsum("ij,ij->i", tidal_acceleration(r_obs, moon, pc.GM_MOON), down)
        if self.include_sun:
            solar = self.gravimetric_factor * np.einsum("ij,ij->i", tidal_acceleration(r_obs, sun, pc.GM_SUN), down)
        return TideComponents(lunar, solar)

    def compute_datetime(self, times: list[datetime], latitude_rad, longitude_rad, height_m) -> TideComponents:
        jd = np.array([datetime_to_julian_date(t) for t in times])
        return self.compute(jd, latitude_rad, longitude_rad, height_m)

    def describe(self) -> dict:
        return {"include_moon": self.include_moon, "include_sun": self.include_sun,
                "gravimetric_factor": self.gravimetric_factor,
                "ephemeris": "Meeus reduced-order (Sun ch.25, Moon ch.47 truncated)",
                "model": "exact differential point-mass tide × degree-2 gravimetric factor"}


__all__ = [
    "TideModel", "TideComponents", "sun_ecliptic", "moon_ecliptic", "body_positions_ecef",
    "mean_obliquity_rad", "ecliptic_to_equatorial",
]
