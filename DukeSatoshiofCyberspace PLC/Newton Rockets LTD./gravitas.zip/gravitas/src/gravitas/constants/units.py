"""Explicit gravity-unit conversions.

Internal convention: **all accelerations are stored as SI m/s² in float64**.
Conversions happen only at the presentation boundary, through these functions,
and never silently: every conversion names both units.

Exact definitions
-----------------
* 1 Gal  = 1 cm/s²  = 1e-2 m/s²   (exact, CGS definition)
* 1 mGal = 1e-3 Gal = 1e-5 m/s²
* 1 µGal = 1e-6 Gal = 1e-8 m/s²
* 1 nm/s² = 1e-9 m/s² = 0.1 µGal

The factors are exact decimal powers. Converting by multiplication with a
power of ten in binary floating point is accurate to ≤ 0.5 ulp, i.e. a relative
error of ~1e-16, nine orders of magnitude below the µGal/g ratio (~1e-9).
"""

from __future__ import annotations

from enum import Enum
from typing import Union

import numpy as np

ArrayLike = Union[float, np.ndarray]


class GravityUnit(str, Enum):
    """Supported acceleration units."""

    MPS2 = "m/s^2"
    GAL = "Gal"
    MGAL = "mGal"
    UGAL = "uGal"
    NMPS2 = "nm/s^2"

    @property
    def to_si(self) -> float:
        """Multiplicative factor converting one of this unit to m/s²."""
        return _TO_SI[self]

    @property
    def symbol(self) -> str:
        return {GravityUnit.UGAL: "µGal"}.get(self, self.value)


_TO_SI: dict[GravityUnit, float] = {
    GravityUnit.MPS2: 1.0,
    GravityUnit.GAL: 1e-2,
    GravityUnit.MGAL: 1e-5,
    GravityUnit.UGAL: 1e-8,
    GravityUnit.NMPS2: 1e-9,
}

# Inverse factors written as exact powers of ten rather than 1/x so that the
# reverse conversion is itself correctly rounded.
_FROM_SI: dict[GravityUnit, float] = {
    GravityUnit.MPS2: 1.0,
    GravityUnit.GAL: 1e2,
    GravityUnit.MGAL: 1e5,
    GravityUnit.UGAL: 1e8,
    GravityUnit.NMPS2: 1e9,
}

_ALIASES = {
    "m/s2": GravityUnit.MPS2, "m/s^2": GravityUnit.MPS2, "mps2": GravityUnit.MPS2, "m s-2": GravityUnit.MPS2,
    "gal": GravityUnit.GAL,
    "mgal": GravityUnit.MGAL,
    "ugal": GravityUnit.UGAL, "µgal": GravityUnit.UGAL, "μgal": GravityUnit.UGAL, "microgal": GravityUnit.UGAL,
    "nm/s2": GravityUnit.NMPS2, "nm/s^2": GravityUnit.NMPS2,
}


def parse_unit(unit: Union[str, GravityUnit]) -> GravityUnit:
    """Parse a unit name. Raises ``ValueError`` for unknown names (never guesses)."""
    if isinstance(unit, GravityUnit):
        return unit
    key = unit.strip().lower()
    if key not in _ALIASES:
        raise ValueError(f"unknown gravity unit {unit!r}; expected one of {sorted(set(_ALIASES))}")
    return _ALIASES[key]


def convert(value: ArrayLike, from_unit: Union[str, GravityUnit], to_unit: Union[str, GravityUnit]) -> ArrayLike:
    """Convert ``value`` from ``from_unit`` to ``to_unit``."""
    f = parse_unit(from_unit)
    t = parse_unit(to_unit)
    if f is t:
        return value
    if f is GravityUnit.MPS2:
        return value * _FROM_SI[t]
    si = value * _TO_SI[f]
    return si if t is GravityUnit.MPS2 else si * _FROM_SI[t]


def mps2_to_gal(x: ArrayLike) -> ArrayLike:
    return x * 1e2


def mps2_to_mgal(x: ArrayLike) -> ArrayLike:
    return x * 1e5


def mps2_to_ugal(x: ArrayLike) -> ArrayLike:
    return x * 1e8


def gal_to_mps2(x: ArrayLike) -> ArrayLike:
    return x * 1e-2


def mgal_to_mps2(x: ArrayLike) -> ArrayLike:
    return x * 1e-5


def ugal_to_mps2(x: ArrayLike) -> ArrayLike:
    return x * 1e-8


def format_gravity(value_mps2: float, unit: Union[str, GravityUnit] = GravityUnit.UGAL, decimals: int = 1) -> str:
    """Presentation-only formatting. Rounding happens here and nowhere else."""
    u = parse_unit(unit)
    v = convert(value_mps2, GravityUnit.MPS2, u)
    return f"{v:.{decimals}f} {u.symbol}"


__all__ = [
    "GravityUnit", "parse_unit", "convert", "format_gravity",
    "mps2_to_gal", "mps2_to_mgal", "mps2_to_ugal", "gal_to_mps2", "mgal_to_mps2", "ugal_to_mps2",
]
