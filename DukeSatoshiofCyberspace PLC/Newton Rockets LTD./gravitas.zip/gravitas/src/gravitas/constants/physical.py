"""Physical and geodetic constants used throughout GRAVITAS.

Every constant is SI unless the name says otherwise. Sources are cited so that
each number entering the simulation is traceable.

* CODATA 2018 recommended values (G).
* NIMA TR8350.2 (3rd ed., 2000) — World Geodetic System 1984 defining and
  derived parameters (a, 1/f, GM, ω, normal gravity on the ellipsoid).
* IERS Conventions (2010), Technical Note 36 — Love numbers, Earth rotation
  angle, GM of Moon and Sun.
* IAU 2012 Resolution B2 — astronomical unit.
"""

from __future__ import annotations

import math

# --------------------------------------------------------------------------
# Fundamental
# --------------------------------------------------------------------------
#: Newtonian constant of gravitation [m^3 kg^-1 s^-2] (CODATA 2018).
G: float = 6.674_30e-11
#: Standard uncertainty of G [m^3 kg^-1 s^-2] (CODATA 2018).
G_UNCERTAINTY: float = 0.000_15e-11

#: Speed of light in vacuum [m/s] (exact).
SPEED_OF_LIGHT: float = 299_792_458.0

#: Seconds per SI day [s].
SECONDS_PER_DAY: float = 86_400.0
#: Julian date of the J2000.0 epoch (2000-01-01T12:00:00 TT) [d].
JD_J2000: float = 2_451_545.0
#: Days per Julian century [d].
DAYS_PER_JULIAN_CENTURY: float = 36_525.0

# --------------------------------------------------------------------------
# WGS84 defining parameters (NIMA TR8350.2, Table 3.1)
# --------------------------------------------------------------------------
#: Semi-major axis [m].
WGS84_A: float = 6_378_137.0
#: Inverse flattening [-].
WGS84_INV_F: float = 298.257_223_563
#: Flattening [-].
WGS84_F: float = 1.0 / WGS84_INV_F
#: Geocentric gravitational constant including the atmosphere [m^3/s^2].
WGS84_GM: float = 3.986_004_418e14
#: Nominal mean angular velocity of the Earth [rad/s].
WGS84_OMEGA: float = 7.292_115e-5

# WGS84 derived normal-gravity parameters (NIMA TR8350.2, Table 3.3) -------
#: Normal gravity at the equator on the ellipsoid [m/s^2].
WGS84_GAMMA_E: float = 9.780_325_335_9
#: Normal gravity at the poles on the ellipsoid [m/s^2].
WGS84_GAMMA_P: float = 9.832_184_937_8
#: Somigliana constant k = (b*gamma_p)/(a*gamma_e) - 1 [-].
WGS84_K_SOMIGLIANA: float = 0.001_931_852_652_41
#: m = omega^2 a^2 b / GM [-].
WGS84_M: float = 0.003_449_786_506_841
#: Mean gravity on the ellipsoid [m/s^2] (informational).
WGS84_GAMMA_MEAN: float = 9.797_643_222_4

#: Mean Earth radius R1 = (2a + b)/3 [m] (used by the spherical reference model).
EARTH_MEAN_RADIUS: float = 6_371_008.771_4

# --------------------------------------------------------------------------
# Third bodies (IERS Conventions 2010, Table 1.1)
# --------------------------------------------------------------------------
#: Lunar gravitational parameter [m^3/s^2].
GM_MOON: float = 4.902_800_1e12
#: Heliocentric gravitational constant [m^3/s^2].
GM_SUN: float = 1.327_124_400_42e20
#: Astronomical unit [m] (IAU 2012, exact).
ASTRONOMICAL_UNIT: float = 1.495_978_707e11
#: Mean Earth–Moon distance [m].
MEAN_EARTH_MOON_DISTANCE: float = 3.844e8

# --------------------------------------------------------------------------
# Elastic Earth response (IERS Conventions 2010, §6.2, nominal degree-2)
# --------------------------------------------------------------------------
#: Degree-2 radial displacement Love number h2 [-].
LOVE_H2: float = 0.6078
#: Degree-2 potential Love number k2 [-].
LOVE_K2: float = 0.3010
#: Degree-2 gravimetric factor delta = 1 + h2 - 3/2 k2 [-].
GRAVIMETRIC_FACTOR: float = 1.0 + LOVE_H2 - 1.5 * LOVE_K2

# --------------------------------------------------------------------------
# Convenience
# --------------------------------------------------------------------------
#: Conventional standard gravity [m/s^2] (CGPM 1901, exact). Not used for physics.
STANDARD_GRAVITY: float = 9.806_65
#: Theoretical free-air gradient near the surface [m/s^2 per m] (mid-latitude).
NOMINAL_FREE_AIR_GRADIENT: float = -3.086e-6
#: Absolute zero offset [K].
ZERO_CELSIUS_K: float = 273.15

DEG2RAD: float = math.pi / 180.0
RAD2DEG: float = 180.0 / math.pi
ARCSEC2RAD: float = DEG2RAD / 3600.0

__all__ = [name for name in dir() if name.isupper()]
