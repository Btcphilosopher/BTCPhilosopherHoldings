"""Residual diagnostics (measured − truth).

Provides the statistics used to judge whether a processing chain leaves
white, unbiased, stationary residuals:
    mean, standard deviation, RMS, linear trend (with OLS standard error),
    lag-k autocorrelation, Ljung–Box Q statistic and p-value,
    D'Agostino–Pearson normality test, Durbin–Watson statistic.
"""

from __future__ import annotations

import math

import numpy as np
from scipy import stats


def autocorrelation(x: np.ndarray, max_lag: int = 20) -> np.ndarray:
    x = np.asarray(x, float) - np.mean(x)
    d = float(np.sum(x * x))
    if d == 0:
        return np.zeros(max_lag + 1)
    return np.array([1.0] + [float(np.sum(x[k:] * x[:-k]) / d) for k in range(1, max_lag + 1)])


def ljung_box(x: np.ndarray, lags: int = 20) -> tuple[float, float]:
    n = len(x)
    r = autocorrelation(x, lags)[1:]
    q = n * (n + 2) * float(np.sum(r**2 / (n - np.arange(1, lags + 1))))
    return q, float(stats.chi2.sf(q, lags))


def durbin_watson(x: np.ndarray) -> float:
    x = np.asarray(x, float)
    return float(np.sum(np.diff(x) ** 2) / np.sum((x - x.mean()) ** 2))


def residual_report(residual: np.ndarray, t_s: np.ndarray | None = None, lags: int = 20) -> dict:
    r = np.asarray(residual, float)
    if r.size < 10:
        raise ValueError("need at least 10 residuals")
    t = np.arange(r.size, dtype=float) if t_s is None else np.asarray(t_s, float)
    a = np.column_stack([np.ones_like(t), t - t[0]])
    theta, *_ = np.linalg.lstsq(a, r, rcond=None)
    res = r - a @ theta
    s2 = float(res @ res) / max(1, r.size - 2)
    cov = s2 * np.linalg.inv(a.T @ a)
    q, p = ljung_box(r, min(lags, r.size // 4))
    out = {
        "n": int(r.size), "mean": float(r.mean()), "std": float(r.std(ddof=1)), "rms": float(math.sqrt(np.mean(r * r))),
        "standard_error_of_mean": float(r.std(ddof=1) / math.sqrt(r.size)),
        "trend_per_s": float(theta[1]), "trend_standard_error_per_s": float(math.sqrt(cov[1, 1])),
        "lag1_autocorrelation": float(autocorrelation(r, 1)[1]),
        "ljung_box_q": q, "ljung_box_pvalue": p, "durbin_watson": durbin_watson(r),
    }
    if r.size >= 20:
        out["normality_pvalue"] = float(stats.normaltest(r).pvalue)
    return out


__all__ = ["autocorrelation", "ljung_box", "durbin_watson", "residual_report"]
