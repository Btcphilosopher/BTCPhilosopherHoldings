"""Analytical validation suite (also exposed as ``gravitas analyse --validate``).

Each check returns ``{"name", "passed", "value", "expected", "tolerance", "detail"}``.
The same physics is exercised in far more depth by the pytest suite; this
module provides a fast self-test that can be run on any installation.
"""

from __future__ import annotations

import math

import numpy as np

from gravitas.constants import physical as pc


def _check(name, value, expected, tol, detail="", rel=False) -> dict:
    err = abs(value - expected) / (abs(expected) if rel and expected else 1.0)
    return {"name": name, "passed": bool(err <= tol), "value": float(value), "expected": float(expected),
            "tolerance": float(tol), "relative": rel, "detail": detail}


def check_inverse_square() -> dict:
    from gravitas.earth.normal_gravity import spherical_gravity_at_radius

    r = np.array([1.0, 2.0, 4.0]) * pc.EARTH_MEAN_RADIUS
    g = spherical_gravity_at_radius(r)
    return _check("newtonian_inverse_square", g[0] / g[1], 4.0, 1e-12, "g(R)/g(2R) = 4")


def check_altitude_monotonic() -> dict:
    from gravitas.earth.gravity import EarthGravityModel

    m = EarthGravityModel()
    h = np.linspace(-100, 20_000, 50)
    g = m.magnitude(np.full(h.size, math.radians(45)), 0.0, h)
    return {"name": "altitude_decrease", "passed": bool(np.all(np.diff(g) < 0)), "value": float(g[-1] - g[0]),
            "expected": -6.2e-2, "tolerance": 5e-3, "relative": False, "detail": "g strictly decreasing with h"}


def check_rotation_latitude() -> dict:
    from gravitas.earth.gravity import EarthGravityModel, EarthModelSwitches

    on = EarthGravityModel().evaluate(0.0, 0.0, 0.0).effective_mps2
    off = EarthGravityModel(switches=EarthModelSwitches(earth_rotation=False)).evaluate(0.0, 0.0, 0.0).effective_mps2
    return _check("rotation_effect_equator", off - on, pc.WGS84_OMEGA**2 * pc.WGS84_A, 1e-12,
                  "rotation reduces equatorial g by ω²a")


def check_somigliana() -> dict:
    from gravitas.earth.gravity import EarthGravityModel
    from gravitas.earth.normal_gravity import somigliana

    lat = np.radians(np.linspace(-90, 90, 37))
    g = EarthGravityModel().magnitude(lat, 0.0, 0.0)
    return _check("series_vs_somigliana_max_abs", float(np.max(np.abs(g - somigliana(lat)))), 0.0, 1e-9,
                  "zonal series vs closed formula on the ellipsoid")


def check_instrument_response() -> dict:
    from gravitas.instrument.gravimeter import Gravimeter, GravimeterConfig

    gm = Gravimeter(GravimeterConfig(), 10.0, 9.81)
    n = 3000 * gm.cfg.oversample
    a = np.full(n, 9.81 + 1e-6)
    gm.initialise_equilibrium(9.81 + 1e-6)
    out = gm.run(a, np.zeros(n), np.zeros(n))
    return _check("instrument_static_response", float(out.raw_gravity_mps2[-100:].mean() - 9.81), 1e-6, 1e-9,
                  "100 µGal input step read back")


def check_bias_and_calibration() -> dict:
    from gravitas.simulation.engine import SimulationEngine
    from gravitas.simulation.scenario import CalibrationConfig, SimulationConfig

    cfg = SimulationConfig(duration_s=300, calibration=CalibrationConfig(bias_mps2=0.0, scale_factor=1.0,
                                                                          temperature_coefficient_mps2_per_k=0.0,
                                                                          drift_rate_mps2_per_s=0.0))
    r = SimulationEngine(cfg).run()
    t = r.t_s >= 60
    uncal = float(np.mean(r["correction.gravity_mps2"][t] - r["truth.static_gravity_mps2"][t]))
    return _check("injected_bias_appears", uncal, cfg.sensor.bias_mps2, 2e-7, "uncalibrated offset ≈ injected bias")


def check_noise_statistics() -> dict:
    from gravitas.sensors.noise import WhiteNoise

    w = WhiteNoise(3e-8, 10.0, np.random.default_rng(1))
    x = w.step(200_000)
    return _check("white_noise_sigma", float(x.std()), w.sigma, 0.01, "σ = n √(fs/2)", rel=True)


def check_reproducibility() -> dict:
    from gravitas.simulation.engine import SimulationEngine
    from gravitas.simulation.scenario import SimulationConfig

    a = SimulationEngine(SimulationConfig(duration_s=60, seed=5)).run()["raw.gravity_mps2"]
    b = SimulationEngine(SimulationConfig(duration_s=60, seed=5)).run()["raw.gravity_mps2"]
    return {"name": "reproducibility", "passed": bool(np.array_equal(a, b)), "value": float(np.max(np.abs(a - b))),
            "expected": 0.0, "tolerance": 0.0, "relative": False, "detail": "identical seeds ⇒ identical output"}


ALL_CHECKS = (check_inverse_square, check_altitude_monotonic, check_rotation_latitude, check_somigliana,
              check_instrument_response, check_bias_and_calibration, check_noise_statistics, check_reproducibility)


def run_all() -> dict:
    results = [c() for c in ALL_CHECKS]
    return {"passed": all(r["passed"] for r in results), "checks": results}


__all__ = ["run_all", "ALL_CHECKS"]
