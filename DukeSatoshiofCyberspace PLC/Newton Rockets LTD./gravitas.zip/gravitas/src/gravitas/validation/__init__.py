"""Validation: analytical checks, published reference values, residual diagnostics."""

from gravitas.validation.analytical import run_all
from gravitas.validation.reference import REFERENCE_VALUES
from gravitas.validation.residuals import residual_report

__all__ = ["run_all", "REFERENCE_VALUES", "residual_report"]
