"""Published reference values used to validate GRAVITAS.

Every entry cites its source. Tolerances express what the *implemented model*
is expected to reproduce, not the precision of the source.
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class ReferenceValue:
    name: str
    value: float
    unit: str
    tolerance: float
    source: str


REFERENCE_VALUES: tuple[ReferenceValue, ...] = (
    ReferenceValue("wgs84_gamma_equator", 9.780_325_335_9, "m/s^2", 1e-10, "NIMA TR8350.2 Table 3.3"),
    ReferenceValue("wgs84_gamma_pole", 9.832_184_937_8, "m/s^2", 1e-10, "NIMA TR8350.2 Table 3.3"),
    ReferenceValue("wgs84_somigliana_k", 0.001_931_852_652_41, "1", 1e-12, "NIMA TR8350.2 Table 3.3"),
    ReferenceValue("wgs84_m", 0.003_449_786_506_841, "1", 1e-13, "NIMA TR8350.2 Table 3.3"),
    ReferenceValue("wgs84_J2", 1.082_629_821_313_8e-3, "1", 1e-12, "NIMA TR8350.2 (C̄20 = −0.484166774985e-3 ⇒ J2)"),
    ReferenceValue("wgs84_b", 6_356_752.314_2, "m", 1e-3, "NIMA TR8350.2 Table 3.3"),
    ReferenceValue("moon_longitude_1992_04_12", 133.162_655, "deg", 0.02, "Meeus (1998) Example 47.a"),
    ReferenceValue("moon_latitude_1992_04_12", -3.229_126, "deg", 0.01, "Meeus (1998) Example 47.a"),
    ReferenceValue("moon_distance_1992_04_12", 368_409.7, "km", 60.0, "Meeus (1998) Example 47.a"),
    ReferenceValue("sun_longitude_1992_10_13", 199.909_87, "deg", 0.001, "Meeus (1998) Example 25.a (geometric)"),
    ReferenceValue("sun_distance_1992_10_13", 0.997_66, "AU", 1e-5, "Meeus (1998) Example 25.a"),
    ReferenceValue("gmst_1987_04_10_0h", 197.693_195, "deg", 1e-5, "Meeus (1998) Example 12.a"),
    ReferenceValue("free_air_gradient_45deg", -3.0855e-6, "m/s^2/m", 1e-8, "Heiskanen & Moritz (1967) §2-17 (≈ 0.3086 mGal/m)"),
    ReferenceValue("bouguer_gradient_2670", 1.1195e-6, "m/s^2/m", 1e-9,
                   "Telford et al. (1990) §2.5: 0.04193 ρ mGal/m (ρ in g/cm³) = 0.11195 mGal/m for 2.67 g/cm³"),
)


def get(name: str) -> ReferenceValue:
    for r in REFERENCE_VALUES:
        if r.name == name:
            return r
    raise KeyError(name)


__all__ = ["ReferenceValue", "REFERENCE_VALUES", "get"]
