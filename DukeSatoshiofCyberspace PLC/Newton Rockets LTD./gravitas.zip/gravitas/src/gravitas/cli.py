"""GRAVITAS command-line interface.

    gravitas simulate     run a configured simulation and record the full chain
    gravitas static       STATIC experiment
    gravitas altitude     ALTITUDE experiment
    gravitas latitude     LATITUDE experiment
    gravitas tides        TIDES experiment
    gravitas anomaly      GRAVITY ANOMALY experiment (synthetic geophysical model)
    gravitas vibration    VIBRATION experiment
    gravitas calibrate    calibration campaign (inject → calibrate → validate)
    gravitas analyse      analyse a recording (stats, residuals, Allan) or run --validate
    gravitas allan        Allan deviation of a recording or a fresh static run
    gravitas monte-carlo  Monte Carlo validation of the uncertainty model
    gravitas replay       replay a recording (play / seek / filter / correct / export)
    gravitas export       convert a recording between CSV / Parquet / HDF5 / JSON
    gravitas serve        start the engine API for the Kotlin console
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np

from gravitas import SOFTWARE_VERSION


def _print_json(obj) -> None:
    from gravitas.api.server import sanitize

    print(json.dumps(sanitize(obj), indent=2))


def _load_config(path: str | None):
    from gravitas.simulation.scenario import SimulationConfig

    return SimulationConfig.from_file(path) if path else None


def _experiment(name: str, args) -> int:
    from gravitas.experiments import run_experiment

    kw = {"duration_s": args.duration, "sample_rate_hz": args.sample_rate, "seed": args.seed}
    kw = {k: v for k, v in kw.items() if v is not None}
    cfg = _load_config(args.config)
    if cfg is not None:
        kw["config"] = cfg
    res = run_experiment(name, **kw)
    out = Path(args.out) / name
    files = res.save(out, formats=tuple(args.formats.split(",")), plots=not args.no_plots)
    if args.record:
        from gravitas.telemetry.recorder import record

        for i, sim in enumerate(res.simulation_results):
            for fmt in args.formats.split(","):
                if fmt in ("csv", "parquet", "hdf5", "json"):
                    files.append(record(sim, out / f"{name}_chain_{i}.{ 'h5' if fmt == 'hdf5' else fmt}", fmt))
    _print_json({"experiment": name, "summary": res.summary, "files": [str(f) for f in files]})
    return 0


def cmd_simulate(args) -> int:
    from gravitas.simulation.engine import SimulationEngine
    from gravitas.simulation.scenario import SimulationConfig
    from gravitas.telemetry.recorder import record

    cfg = _load_config(args.config) or SimulationConfig()
    upd = {}
    if args.duration is not None:
        upd["duration_s"] = args.duration
    if args.sample_rate is not None:
        upd["sample_rate_hz"] = args.sample_rate
    if args.seed is not None:
        upd["seed"] = args.seed
    cfg = cfg.model_copy(update=upd)
    res = SimulationEngine(cfg).run()
    est = res.final_estimate()
    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    files = []
    for fmt in args.formats.split(","):
        ext = "h5" if fmt == "hdf5" else fmt
        files.append(str(record(res, out / f"{cfg.name}.{ext}", fmt, content=args.content)))
    (out / f"{cfg.name}_manifest.json").write_text(json.dumps(res.manifest, indent=2, default=str))
    (out / f"{cfg.name}_estimate.json").write_text(json.dumps(est.to_dict(), indent=2))
    _print_json({"estimate": est.to_dict(), "true_static_gravity_mps2": float(res["truth.static_gravity_mps2"][-1]),
                 "files": files + [str(out / f"{cfg.name}_manifest.json")]})
    return 0


def cmd_calibrate(args) -> int:
    return _experiment("calibration", args)


def cmd_analyse(args) -> int:
    if args.validate:
        from gravitas.validation.analytical import run_all

        rep = run_all()
        _print_json(rep)
        return 0 if rep["passed"] else 1
    if not args.input:
        print("analyse: provide a recording path or --validate", file=sys.stderr)
        return 2
    from gravitas.telemetry.replay import ReplaySession
    from gravitas.validation.residuals import residual_report

    rs = ReplaySession.load(args.input)
    rs.filter(kind=args.filter, cutoff_hz=args.cutoff) if args.filter != "none" else rs.filter(kind="none")
    corrected = rs.correct()
    stats = rs.analyse()
    stats.pop("allan", None)
    truth_key = "truth.static_gravity_mps2" if "truth.static_gravity_mps2" in rs.table else "static_gravity_mps2"
    if truth_key in rs.table:
        sel = rs.t >= rs.t[0] + 120.0
        stats["residuals"] = residual_report((corrected - np.asarray(rs.table[truth_key], float))[sel], rs.t[sel])
    _print_json(stats)
    return 0


def cmd_allan(args) -> int:
    from gravitas.estimation.allan import export_allan, overlapping_adev

    if args.input:
        from gravitas.telemetry.replay import ReplaySession

        rs = ReplaySession.load(args.input)
        y = np.asarray(rs.table[args.column or rs.raw_key], float)
        dt = rs.dt
    else:
        from gravitas.simulation.engine import SimulationEngine
        from gravitas.simulation.scenario import SimulationConfig

        cfg = _load_config(args.config) or SimulationConfig()
        cfg = cfg.model_copy(update={"duration_s": args.duration or 7200.0, "sample_rate_hz": args.sample_rate or 10.0,
                                     "seed": args.seed if args.seed is not None else cfg.seed})
        res = SimulationEngine(cfg).run()
        y = res[args.column or "raw.gravity_mps2"]
        dt = 1.0 / cfg.sample_rate_hz
    res = overlapping_adev(y - y.mean(), dt)
    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    export_allan(res, str(out / "allan.csv"))
    export_allan(res, str(out / "allan.json"))
    if not args.no_plots:
        import matplotlib

        matplotlib.use("Agg")
        import matplotlib.pyplot as plt

        fig, ax = plt.subplots(figsize=(7, 5), dpi=110)
        ax.loglog(res.tau_s, res.adev, "o-", ms=3, label="overlapping ADEV")
        ax.fill_between(res.tau_s, res.adev_lo, res.adev_hi, alpha=0.25, label="68 % CI")
        ax.set_xlabel("averaging time τ [s]")
        ax.set_ylabel("Allan deviation [m/s²]")
        ax.grid(True, which="both", lw=0.3)
        ax.legend()
        fig.tight_layout()
        fig.savefig(out / "allan.png")
        plt.close(fig)
    _print_json({"identification": res.identification, "files": [str(out / "allan.csv"), str(out / "allan.json")]})
    return 0


def cmd_monte_carlo(args) -> int:
    from gravitas.simulation.monte_carlo import run_monte_carlo
    from gravitas.simulation.scenario import SimulationConfig

    cfg = _load_config(args.config) or SimulationConfig()
    if args.sample_rate:
        cfg = cfg.model_copy(update={"sample_rate_hz": args.sample_rate})
    r = run_monte_carlo(cfg, trials=args.trials, duration_s=args.duration or 300.0, mc_seed=args.seed or 12345,
                        progress=(lambda i, n: print(f"trial {i}/{n}", file=sys.stderr)) if args.verbose else None)
    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    import pandas as pd

    pd.DataFrame(r.draws).to_csv(out / "monte_carlo_trials.csv", index=False, float_format="%.17g")
    (out / "monte_carlo_summary.json").write_text(json.dumps(r.to_dict(include_samples=False), indent=2, default=float))
    _print_json({**r.summary, "contributions_rms_mps2": r.contributions_rms,
                 "files": [str(out / "monte_carlo_trials.csv"), str(out / "monte_carlo_summary.json")]})
    return 0


def cmd_replay(args) -> int:
    from gravitas.telemetry.replay import ReplaySession

    rs = ReplaySession.load(args.input)
    if args.seek is not None:
        rs.seek(args.seek)
    rs.play()
    emitted = 0
    while rs.playing and (args.samples is None or emitted < args.samples):
        rows = rs.tick(min(args.step, (args.samples - emitted) if args.samples else args.step))
        if not rows:
            break
        emitted += len(rows["sim_time_s"])
        if args.print_every and emitted % args.print_every < args.step:
            cur = {k: rows[k][-1].item() if hasattr(rows[k][-1], "item") else rows[k][-1]
                   for k in ("sim_time_s", rs.raw_key) if k in rows}
            print(json.dumps(cur))
    rs.pause()
    if args.filter:
        rs.filter(kind=args.filter, zero_phase=args.zero_phase)
        rs.correct()
    info = {"samples_played": emitted, "cursor": rs.cursor, "duration_s": float(rs.t[-1] - rs.t[0]),
            "sample_rate_hz": rs.sample_rate_hz}
    if args.analyse:
        a = rs.analyse()
        a.pop("allan", None)
        info["analysis"] = a
    if args.export:
        info["exported"] = str(rs.export(args.export))
    _print_json(info)
    return 0


def cmd_export(args) -> int:
    from gravitas.telemetry.recorder import read_table, write_table

    table, manifest = read_table(args.input)
    p = write_table(table, args.output, manifest, args.format)
    _print_json({"input": args.input, "output": str(p), "columns": len(table), "rows": int(len(next(iter(table.values()))))})
    return 0


def cmd_serve(args) -> int:
    from gravitas.api.live import LiveSimulation, live_default_config
    from gravitas.api.server import serve

    cfg = _load_config(args.config) or live_default_config()
    live = LiveSimulation(cfg, speed=args.speed)
    print(f"GRAVITAS engine API on http://{args.host}:{args.port}/api/v1  (speed ×{args.speed})", file=sys.stderr)
    serve(args.host, args.port, live, block=True)
    return 0


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="gravitas", description="GRAVITAS precision gravity digital twin")
    p.add_argument("--version", action="version", version=f"gravitas {SOFTWARE_VERSION}")
    sub = p.add_subparsers(dest="command", required=True)

    def common(sp, duration=True):
        if duration:
            sp.add_argument("--duration", type=float, default=None, help="duration [s]")
            sp.add_argument("--sample-rate", type=float, default=None, help="output sample rate [Hz]")
        sp.add_argument("--seed", type=int, default=None, help="random seed")
        sp.add_argument("--config", default=None, help="SimulationConfig JSON file")
        sp.add_argument("--out", default="output", help="output directory")

    sp = sub.add_parser("simulate", help="run a configured simulation and record the chain")
    common(sp)
    sp.add_argument("--formats", default="csv,parquet,hdf5,json")
    sp.add_argument("--content", choices=("chain", "telemetry"), default="chain")
    sp.set_defaults(func=cmd_simulate)

    for name in ("static", "altitude", "latitude", "tides", "anomaly", "vibration"):
        sp = sub.add_parser(name, help=f"{name.upper()} experiment")
        common(sp)
        sp.add_argument("--formats", default="csv,json")
        sp.add_argument("--no-plots", action="store_true")
        sp.add_argument("--record", action="store_true", help="also record every full simulation chain")
        sp.set_defaults(func=lambda a, n=name: _experiment(n, a))

    sp = sub.add_parser("calibrate", help="calibration campaign: inject errors, calibrate, validate")
    common(sp)
    sp.add_argument("--formats", default="csv,json")
    sp.add_argument("--no-plots", action="store_true")
    sp.add_argument("--record", action="store_true")
    sp.set_defaults(func=cmd_calibrate)

    sp = sub.add_parser("analyse", help="analyse a recording, or --validate the installation")
    sp.add_argument("input", nargs="?")
    sp.add_argument("--validate", action="store_true")
    sp.add_argument("--filter", default="butterworth")
    sp.add_argument("--cutoff", type=float, default=0.05)
    sp.set_defaults(func=cmd_analyse)

    sp = sub.add_parser("allan", help="Allan deviation of a recording or a fresh static run")
    common(sp)
    sp.add_argument("--input", default=None)
    sp.add_argument("--column", default=None)
    sp.add_argument("--no-plots", action="store_true")
    sp.set_defaults(func=cmd_allan)

    sp = sub.add_parser("monte-carlo", help="Monte Carlo validation of the uncertainty budget")
    common(sp)
    sp.add_argument("--trials", type=int, default=100)
    sp.add_argument("--verbose", action="store_true")
    sp.set_defaults(func=cmd_monte_carlo)

    sp = sub.add_parser("replay", help="replay a recording")
    sp.add_argument("input")
    sp.add_argument("--seek", type=float, default=None)
    sp.add_argument("--samples", type=int, default=None)
    sp.add_argument("--step", type=int, default=100)
    sp.add_argument("--print-every", type=int, default=0)
    sp.add_argument("--filter", default=None)
    sp.add_argument("--zero-phase", action="store_true")
    sp.add_argument("--analyse", action="store_true")
    sp.add_argument("--export", default=None)
    sp.set_defaults(func=cmd_replay)

    sp = sub.add_parser("export", help="convert a recording between formats")
    sp.add_argument("input")
    sp.add_argument("output")
    sp.add_argument("--format", default=None, choices=(None, "csv", "parquet", "hdf5", "json"))
    sp.set_defaults(func=cmd_export)

    sp = sub.add_parser("serve", help="start the engine API for the Kotlin console")
    sp.add_argument("--host", default="127.0.0.1")
    sp.add_argument("--port", type=int, default=8765)
    sp.add_argument("--speed", type=float, default=1.0)
    sp.add_argument("--config", default=None)
    sp.set_defaults(func=cmd_serve)
    return p


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    return int(args.func(args) or 0)


if __name__ == "__main__":  # pragma: no cover
    sys.exit(main())
