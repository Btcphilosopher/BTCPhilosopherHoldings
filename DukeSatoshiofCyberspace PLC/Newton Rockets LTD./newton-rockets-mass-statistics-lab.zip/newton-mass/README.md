# NewtonMass: Rocket Mass and Weight Statistical Properties Laboratory

NewtonMass is a production-grade R statistical analysis package developed for **Newton Rockets Ltd.** It is designed to rigorously analyze rocket dry and wet masses, track propellant states, determine centre of gravity vs. centre of mass, compute moments of inertia using the parallel-axis theorem, analyze manufacturing variation across batches using mixed-effects models, and perform high-resolution Monte Carlo uncertainty propagation.

## Core Engineering Features

1. **Mass vs. Weight Rigor**: Explicitly distinguishes between mass ($M$ in kg) and weight ($W = M \cdot g$ in N) across dynamic local gravitational fields.
2. **Hierarchical Rollup**: Aggregates from individual sensors and parts to subsystems, stages, and total vehicle dry/wet states.
3. **Mass Closure Balance**: Quantifies and flags `mass_balance_error` down to the gram.
4. **Physical Properties**: Calculates three-dimensional Centre of Mass (COM) and the full Moments of Inertia tensor ($I_{xx}$, $I_{yy}$, $I_{zz}$, $I_{xy}$, etc.) at arbitrary tank fill percentages.
5. **Statistical Process Control (SPC)**: Builds X-bar/S charts, I-MR control charts, and calculates process capability indices ($C_p, C_{pk}$) for manufacturing quality tracking.
6. **Monte Carlo Engine**: Simulates $1,000$ to $100,000$ missions propagating Normal, Lognormal, Uniform, and Triangular component distributions to find $P_5, P_{50}, P_{95}$ vehicle properties.
7. **Mixed-Effects Regression**: Employs mixed-effects models (`lme4`) to quantify within-batch and between-batch variation:
   $$\text{mass} \sim \text{vehicle\_generation} + \text{manufacturing\_batch} + (1 \mid \text{component\_type})$$

## Installation

```r
# Install from source
devtools::install("newton-mass")
```

## Quick Start in R

```r
library(NewtonMass)

# 1. Generate standard synthetic Newton Rockets dataset
db <- create_synthetic_database()

# 2. Perform vehicle mass closure accounting
balance <- calculate_mass_balance(db, vehicle_id = "NR-020")
print(balance)

# 3. Compute dynamic Centre of Mass profile
com_profile <- calculate_centre_of_mass(db, vehicle_id = "NR-020", fill_ratio = 0.5)
print(com_profile)

# 4. Run Monte Carlo simulation for Dry Mass uncertainty
mc_results <- run_monte_carlo_engine(db, vehicle_id = "NR-020", n_samples = 10000)
summary(mc_results)
```

## Workstation Shiny App

Launch the Newton Rockets scientific instrumentation dashboard from R:

```r
shiny::runApp(system.file("app", package = "NewtonMass"))
```
