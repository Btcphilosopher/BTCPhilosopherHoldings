#' Mass Models and Database Ingestion System
#' @import dplyr
#' @import tidyr
#' @import purrr
#' @import readr
#' @export

# Validation rules for datasets
validate_mass_data <- function(df) {
  errors <- character()
  
  # 1. Missing columns
  required_cols <- c("component_id", "component_name", "component_type", "stage", 
                     "subsystem", "vehicle", "nominal_mass", "measured_mass", 
                     "measurement_uncertainty")
  missing_cols <- setdiff(required_cols, colnames(df))
  if (length(missing_cols) > 0) {
    errors <- c(errors, paste("Missing required columns:", paste(missing_cols, collapse = ", ")))
  }
  
  if (length(errors) > 0) {
    return(list(valid = FALSE, errors = errors))
  }
  
  # 2. Check for negative masses
  if (any(df$nominal_mass < 0, na.rm = TRUE) || any(df$measured_mass < 0, na.rm = TRUE)) {
    errors <- c(errors, "Detected negative mass values which are physically impossible.")
  }
  
  # 3. Check duplicate IDs
  if (any(duplicated(df$component_id))) {
    errors <- c(errors, "Duplicate component_id values detected.")
  }
  
  # 4. Inconsistent vehicle boundaries
  if (any(is.na(df$vehicle)) || any(df$vehicle == "")) {
    errors <- c(errors, "Components must be mapped to a valid vehicle.")
  }
  
  valid <- length(errors) == 0
  return(list(valid = valid, errors = errors))
}

# Create standard synthetic database for 20 vehicles, 3 generations
create_synthetic_database <- function() {
  set.seed(42)
  
  generations <- c("Gen_1", "Gen_2", "Gen_3")
  subsystems <- c("STRUCTURE", "TANK", "ENGINE", "PLUMBING", "AVIONICS", 
                  "THERMAL_PROTECTION", "LANDING_GEAR", "PAYLOAD_ADAPTER")
  
  # Generate 20 vehicles
  vehicles <- paste0("NR-", sprintf("%03d", 1:20))
  vehicle_gens <- rep(generations, length.out = length(vehicles))
  names(vehicle_gens) <- vehicles
  
  # Base design specifications (nominal values in kg)
  base_masses <- list(
    STRUCTURE = list(Stage1 = 45000, Stage2 = 8000),
    TANK = list(Stage1 = 28000, Stage2 = 5000),
    ENGINE = list(Stage1 = 2400, Stage2 = 1200), # S1 has 9 engines, S2 has 1
    PLUMBING = list(Stage1 = 4500, Stage2 = 1100),
    AVIONICS = list(Stage1 = 800, Stage2 = 600),
    THERMAL_PROTECTION = list(Stage1 = 2500, Stage2 = 900),
    LANDING_GEAR = list(Stage1 = 6500, Stage2 = 0),
    PAYLOAD_ADAPTER = list(Stage1 = 0, Stage2 = 1500)
  )
  
  components <- list()
  idx <- 1
  
  for (veh in vehicles) {
    gen <- vehicle_gens[veh]
    # Generation scaling multiplier (newer is lighter/more efficient)
    gen_mult <- if (gen == "Gen_1") 1.05 else if (gen == "Gen_2") 1.00 else 0.94
    
    # Batch code for manufacturing
    batch_num <- if (gen == "Gen_1") "B-Alpha" else if (gen == "Gen_2") "B-Beta" else "B-Gamma"
    
    # 1. Stage 1 Components
    for (sub in subsystems) {
      base_val <- base_masses[[sub]][["Stage1"]]
      if (base_val == 0) next
      
      # For Stage 1 engines, we have 9 individual units
      n_units <- if (sub == "ENGINE") 9 else 1
      for (unit in 1:n_units) {
        comp_name <- if (n_units > 1) paste("S1", sub, "Unit", unit) else paste("S1", sub)
        comp_id <- paste0(veh, "-S1-", sub, "-", unit)
        
        # Add random manufacturing variation (SD is ~1.5% of nominal)
        nom <- base_val * gen_mult / n_units
        meas <- rnorm(1, mean = nom, sd = nom * 0.012)
        unc <- nom * 0.005 # 0.5% measurement uncertainty
        
        # Spatial positions (m)
        x_pos <- rnorm(1, 0, 0.2)
        y_pos <- rnorm(1, 0, 0.2)
        # S1 is 40m long, engines at z=0, tanks at z=15, structure distributed
        z_pos <- if (sub == "ENGINE") rnorm(1, 0.5, 0.1)
                 else if (sub == "TANK") rnorm(1, 18, 2.0)
                 else rnorm(1, 15, 6.0)
                 
        components[[idx]] <- data.frame(
          component_id = comp_id,
          component_name = comp_name,
          component_type = sub,
          stage = "Stage_1",
          subsystem = sub,
          vehicle = veh,
          generation = gen,
          nominal_mass = nom,
          measured_mass = meas,
          measurement_uncertainty = unc,
          lower_bound = meas - 2 * unc,
          upper_bound = meas + 2 * unc,
          x = x_pos,
          y = y_pos,
          z = z_pos,
          manufacturing_batch = batch_num,
          stringsAsFactors = FALSE
        )
        idx <- idx + 1
      }
    }
    
    # 2. Stage 2 Components
    for (sub in subsystems) {
      base_val <- base_masses[[sub]][["Stage2"]]
      if (base_val == 0) next
      
      comp_name <- paste("S2", sub)
      comp_id <- paste0(veh, "-S2-", sub)
      
      nom <- base_val * gen_mult
      meas <- rnorm(1, mean = nom, sd = nom * 0.012)
      unc <- nom * 0.005
      
      # S2 sits from z=40 to z=55
      x_pos <- rnorm(1, 0, 0.1)
      y_pos <- rnorm(1, 0, 0.1)
      z_pos <- if (sub == "ENGINE") rnorm(1, 41, 0.2)
               else if (sub == "TANK") rnorm(1, 47, 1.5)
               else rnorm(1, 48, 3.0)
               
      components[[idx]] <- data.frame(
        component_id = comp_id,
        component_name = comp_name,
        component_type = sub,
        stage = "Stage_2",
        subsystem = sub,
        vehicle = veh,
        generation = gen,
        nominal_mass = nom,
        measured_mass = meas,
        measurement_uncertainty = unc,
        lower_bound = meas - 2 * unc,
        upper_bound = meas + 2 * unc,
        x = x_pos,
        y = y_pos,
        z = z_pos,
        manufacturing_batch = batch_num,
        stringsAsFactors = FALSE
      )
      idx <- idx + 1
    }
    
    # 3. Payload Component
    comp_id <- paste0(veh, "-PAYLOAD")
    # Generational payload capacity increments
    pay_nom <- if (gen == "Gen_1") 12000 else if (gen == "Gen_2") 15000 else 18500
    pay_meas <- rnorm(1, pay_nom, pay_nom * 0.001) # payloads measured extremely precisely
    pay_unc <- pay_nom * 0.0005
    
    components[[idx]] <- data.frame(
      component_id = comp_id,
      component_name = "Payload Satellite Deck",
      component_type = "PAYLOAD",
      stage = "Payload",
      subsystem = "PAYLOAD",
      vehicle = veh,
      generation = gen,
      nominal_mass = pay_nom,
      measured_mass = pay_meas,
      measurement_uncertainty = pay_unc,
      lower_bound = pay_meas - 2 * pay_unc,
      upper_bound = pay_meas + 2 * pay_unc,
      x = 0,
      y = 0,
      z = 57, # Top of the stack
      manufacturing_batch = "P-Commercial",
      stringsAsFactors = FALSE
    )
    idx <- idx + 1
  }
  
  df_result <- do.call(rbind, components)
  return(df_result)
}

calculate_total_mass <- function(df, vehicle_id) {
  veh_data <- df[df$vehicle == vehicle_id, ]
  sum(veh_data$measured_mass, na.rm = TRUE)
}
