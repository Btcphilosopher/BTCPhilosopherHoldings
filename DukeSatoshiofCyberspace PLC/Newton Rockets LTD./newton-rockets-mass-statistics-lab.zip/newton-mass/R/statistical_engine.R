#' Statistical Calculation Engine for NewtonMass Package
#' @importFrom stats rnorm rlnorm runif sd qnorm lm
#' @export

# Monte Carlo mass propagation engine
run_monte_carlo_engine <- function(df, vehicle_id, n_samples = 10000) {
  set.seed(12345)
  veh_data <- df[df$vehicle == vehicle_id, ]
  
  n_comps <- nrow(veh_data)
  sim_results <- numeric(n_samples)
  
  # For each component, retrieve nominal/measured mass and uncertainty
  means <- veh_data$measured_mass
  sds <- veh_data$measurement_uncertainty
  types <- veh_data$component_type
  
  # We will simulate correlated tank/structure variation
  # Draw a global manufacturing/material quality factor for each iteration
  for (i in 1:n_samples) {
    # Let's introduce a correlated noise term (e.g. material density factor)
    material_drift <- rnorm(1, mean = 0, sd = 0.003) 
    
    # Draw individual sample masses
    draws <- rnorm(n_comps, mean = means, sd = sds)
    
    # Apply correlated factor to TANK and STRUCTURE subsystems
    tank_struct_indices <- which(types %in% c("TANK", "STRUCTURE"))
    draws[tank_struct_indices] <- draws[tank_struct_indices] * (1 + material_drift)
    
    sim_results[i] <- sum(draws)
  }
  
  # Quantiles
  p5 <- quantile(sim_results, 0.05)
  p50 <- quantile(sim_results, 0.50)
  p95 <- quantile(sim_results, 0.95)
  
  return(list(
    vehicle_id = vehicle_id,
    samples_count = n_samples,
    mean = mean(sim_results),
    median = median(sim_results),
    sd = sd(sim_results),
    min = min(sim_results),
    max = max(sim_results),
    P5 = p5,
    P50 = p50,
    P95 = p95,
    samples = sim_results
  ))
}

# Propagate mass uncertainty analytically
propagate_mass_uncertainty <- function(df, vehicle_id, correlation = 0.15) {
  veh_data <- df[df$vehicle == vehicle_id, ]
  
  # Independent error sum-of-squares: Sigma = sqrt(sum(sigma_i^2))
  sds <- veh_data$measurement_uncertainty
  unc_independent <- sqrt(sum(sds^2))
  
  # Correlated error propagation:
  # Var(sum(X_i)) = Sum(Var(X_i)) + 2 * Sum_over_pairs(Cov(X_i, X_j))
  # Assuming standard correlation factor among similar component types (e.g. engines)
  tot_var <- sum(sds^2)
  for (i in 1:(length(sds)-1)) {
    for (j in (i+1):length(sds)) {
      if (veh_data$component_type[i] == veh_data$component_type[j]) {
        cov_val <- correlation * sds[i] * sds[j]
        tot_var <- tot_var + 2 * cov_val
      }
    }
  }
  unc_correlated <- sqrt(tot_var)
  
  return(list(
    vehicle_id = vehicle_id,
    sum_measured_mass = sum(veh_data$measured_mass),
    unc_independent = unc_independent,
    unc_correlated = unc_correlated,
    confidence_interval_95 = c(
      sum(veh_data$measured_mass) - 1.96 * unc_correlated,
      sum(veh_data$measured_mass) + 1.96 * unc_correlated
    )
  ))
}

# SPC Metrics & Quality Control indices
calculate_spc_metrics <- function(values, spec_nominal, spec_lsl, spec_usl) {
  n <- length(values)
  if (n < 3) {
    return(list(error = "At least 3 measurements required for SPC indices."))
  }
  
  mean_val <- mean(values)
  sd_val <- sd(values)
  
  # Standard limits
  lcl <- mean_val - 3 * sd_val
  ucl <- mean_val + 3 * sd_val
  
  # Process capability ratios
  # Cp = (USL - LSL) / (6 * Sigma)
  cp <- (spec_usl - spec_lsl) / (6 * sd_val)
  
  # Cpk = min( (USL - Mean)/(3*Sigma), (Mean - LSL)/(3*Sigma) )
  cpk_upper <- (spec_usl - mean_val) / (3 * sd_val)
  cpk_lower <- (mean_val - spec_lsl) / (3 * sd_val)
  cpk <- min(cpk_upper, cpk_lower)
  
  # Process performance metrics (Pp, Ppk)
  # For synthetic sample, we assume Pp/Ppk equal Cp/Cpk for now
  pp <- cp
  ppk <- cpk
  
  # Outliers / process violations check (Nelson rules / standard deviations)
  out_of_limits <- sum(values < lcl | values > ucl)
  
  return(list(
    n = n,
    mean = mean_val,
    sd = sd_val,
    lcl = lcl,
    ucl = ucl,
    Cp = cp,
    Cpk = cpk,
    Pp = pp,
    Ppk = ppk,
    outliers_count = out_of_limits,
    drift_detected = abs(mean_val - spec_nominal) > (0.5 * sd_val)
  ))
}

# Mass regression helper
fit_mass_regression <- function(df, x_var = "nominal_mass", y_var = "measured_mass") {
  formula_str <- paste(y_var, "~", x_var)
  model <- lm(as.formula(formula_str), data = df)
  summary_model <- summary(model)
  
  return(list(
    coefficients = summary_model$coefficients,
    r_squared = summary_model$r.squared,
    adj_r_squared = summary_model$adj.r.squared,
    f_statistic = summary_model$fstatistic,
    sigma = summary_model$sigma
  ))
}

# Mixed Effects Regression model simulation (fits mass ~ generation + (1 | component_type))
fit_mixed_effects_mass <- function(df) {
  # In production, we'd load lme4:
  # lmer(measured_mass ~ generation + (1 | component_type), data = df)
  # Here we perform a robust multi-level model approximation:
  grand_mean <- mean(df$measured_mass)
  
  # Fixed effects (Generation deviations)
  gen_effects <- df %>%
    group_by(generation) %>%
    summarise(mean_m = mean(measured_mass)) %>%
    mutate(deviation = mean_m - grand_mean)
  
  # Random effects variances (between components)
  comp_random <- df %>%
    group_by(component_type) %>%
    summarise(mean_sub = mean(measured_mass)) %>%
    mutate(random_intercept = mean_sub - grand_mean)
  
  within_variance <- var(df$measured_mass - grand_mean)
  between_variance <- var(comp_random$random_intercept)
  
  return(list(
    grand_mean = grand_mean,
    fixed_effects_generation = gen_effects,
    random_effects_component = comp_random,
    variance_components = list(
      between_component_variance = between_variance,
      within_residual_variance = within_variance,
      icc = between_variance / (between_variance + within_variance)
    )
  ))
}
