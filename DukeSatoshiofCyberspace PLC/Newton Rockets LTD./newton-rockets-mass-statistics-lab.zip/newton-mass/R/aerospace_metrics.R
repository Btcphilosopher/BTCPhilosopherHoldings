#' Aerospace Engineering Metrics: Stages, Propellants, and Mass Balancing
#' @import dplyr
#' @export

# Compute Stage dry/wet/structural coefficient/mass fraction
calculate_stage_statistics <- function(df, vehicle_id) {
  veh_data <- df[df$vehicle == vehicle_id, ]
  
  # Stage 1
  s1_components <- veh_data[veh_data$stage == "Stage_1", ]
  s1_dry_mass <- sum(s1_components$measured_mass, na.rm = TRUE)
  s1_propellant_loaded <- 320000 # kg standard loaded
  s1_wet_mass <- s1_dry_mass + s1_propellant_loaded
  
  # Propellant fraction (zeta) = propellant_mass / initial_stage_mass
  s1_zeta <- s1_propellant_loaded / s1_wet_mass
  # Structural coefficient (epsilon) = dry_mass / (dry_mass + propellant_mass)
  s1_epsilon <- s1_dry_mass / s1_wet_mass
  
  # Stage 2
  s2_components <- veh_data[veh_data$stage == "Stage_2", ]
  s2_dry_mass <- sum(s2_components$measured_mass, na.rm = TRUE)
  s2_propellant_loaded <- 90000 # kg standard loaded
  s2_wet_mass <- s2_dry_mass + s2_propellant_loaded
  
  s2_zeta <- s2_propellant_loaded / s2_wet_mass
  s2_epsilon <- s2_dry_mass / s2_wet_mass
  
  return(list(
    vehicle_id = vehicle_id,
    Stage1 = list(
      dry_mass_kg = s1_dry_mass,
      propellant_mass_kg = s1_propellant_loaded,
      wet_mass_kg = s1_wet_mass,
      mass_fraction_zeta = s1_zeta,
      structural_coefficient_epsilon = s1_epsilon
    ),
    Stage2 = list(
      dry_mass_kg = s2_dry_mass,
      propellant_mass_kg = s2_propellant_loaded,
      wet_mass_kg = s2_wet_mass,
      mass_fraction_zeta = s2_zeta,
      structural_coefficient_epsilon = s2_epsilon
    )
  ))
}

# Propellant bookkeeping statistics
calculate_propellant_bookkeeping <- function(vehicle_id, fill_ratio = 1.0) {
  # Bookkeeping standard ratios for Newton Rocket fuel and oxidizer tanks
  # stage 1: RP-1 Kerosene + Liquid Oxygen (LOX) ratio is 1:2.34
  # stage 2: RP-1 Kerosene + Liquid Oxygen (LOX) ratio is 1:2.5
  
  s1_total <- 320000 * fill_ratio
  s1_fuel <- s1_total * (1 / (1 + 2.34))
  s1_ox <- s1_total * (2.34 / (1 + 2.34))
  # Pressurant (Helium) remains small but tracked (nominal 150 kg)
  s1_pressurant <- 150
  # Residuals / ullage (propellant trapped in lines - 0.7%)
  s1_residuals <- s1_total * 0.007
  
  s2_total <- 90000 * fill_ratio
  s2_fuel <- s2_total * (1 / (1 + 2.5))
  s2_ox <- s2_total * (2.5 / (1 + 2.5))
  s2_pressurant <- 50
  s2_residuals <- s2_total * 0.008
  
  return(list(
    vehicle_id = vehicle_id,
    fill_ratio = fill_ratio,
    Stage1 = list(
      total_loaded_kg = s1_total,
      fuel_rp1_kg = s1_fuel,
      oxidizer_lox_kg = s1_ox,
      pressurant_helium_kg = s1_pressurant,
      residuals_unusable_kg = s1_residuals,
      usable_propellant_kg = s1_total - s1_residuals
    ),
    Stage2 = list(
      total_loaded_kg = s2_total,
      fuel_rp1_kg = s2_fuel,
      oxidizer_lox_kg = s2_ox,
      pressurant_helium_kg = s2_pressurant,
      residuals_unusable_kg = s2_residuals,
      usable_propellant_kg = s2_total - s2_residuals
    )
  ))
}

# Mass Balance: measured vs sum accounting
calculate_mass_balance <- function(df, vehicle_id) {
  veh_data <- df[df$vehicle == vehicle_id, ]
  
  # Calculate exact dry hardware sum
  sum_dry_components <- sum(veh_data$measured_mass, na.rm = TRUE)
  
  # Simulate independent structural load cell weighing of complete physical dry vehicle
  # A load cell error introduces a slight "mass_balance_error"
  measured_vehicle_mass <- rnorm(1, mean = sum_dry_components, sd = sum_dry_components * 0.0004)
  
  # Mass balance error
  mass_balance_error <- measured_vehicle_mass - sum_dry_components
  closure_pct <- (sum_dry_components / measured_vehicle_mass) * 100
  
  return(list(
    vehicle_id = vehicle_id,
    measured_vehicle_mass_kg = measured_vehicle_mass,
    sum_component_mass_kg = sum_dry_components,
    mass_balance_error_kg = mass_balance_error,
    mass_closure_percentage = closure_pct
  ))
}

# Subsystem percentage of dry and gross mass
get_subsystem_summary <- function(df, vehicle_id) {
  veh_data <- df[df$vehicle == vehicle_id, ]
  
  dry_total <- sum(veh_data$measured_mass, na.rm = TRUE)
  prop_total <- 410000 # 320k + 90k standard loaded
  gross_total <- dry_total + prop_total
  
  summary_df <- veh_data %>%
    group_by(subsystem) %>%
    summarise(
      absolute_mass_kg = sum(measured_mass, na.rm = TRUE),
      percentage_of_dry = (absolute_mass_kg / dry_total) * 100,
      percentage_of_gross = (absolute_mass_kg / gross_total) * 100
    )
  
  # Append Propellant row
  prop_row <- data.frame(
    subsystem = "PROPELLANT",
    absolute_mass_kg = prop_total,
    percentage_of_dry = NA,
    percentage_of_gross = (prop_total / gross_total) * 100
  )
  
  result <- rbind(summary_df, prop_row)
  return(result)
}
