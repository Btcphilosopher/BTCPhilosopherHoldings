#' Physical Properties: Centre of Mass, Inertia and Weight Acceleration
#' @export

# Compute Weight at standard or local gravity
calculate_weight_at_gravity <- function(mass_kg, gravity_field = 9.80665) {
  # W = M * g
  # Mass in kg, gravity in m/s^2, Weight in N
  weight_n <- mass_kg * gravity_field
  return(weight_n)
}

# Calculate 3D Centre of Mass
calculate_centre_of_mass <- function(df, vehicle_id, fill_ratio = 1.0) {
  veh_data <- df[df$vehicle == vehicle_id, ]
  
  # Inject propellant mass dynamically depending on fuel-loading ratio
  # Stage 1 has standard 320,000 kg kerosene propellant, Stage 2 has 90,000 kg Lox/Kerosene
  # Fuel tanks are centered at S1(z=18), S2(z=47)
  
  comp_masses <- veh_data$measured_mass
  comp_x <- veh_data$x
  comp_y <- veh_data$y
  comp_z <- veh_data$z
  
  # Create dynamic propellant additions
  p1_mass <- 320000 * fill_ratio
  p2_mass <- 90000 * fill_ratio
  
  total_m <- sum(comp_masses) + p1_mass + p2_mass
  
  # Moments sum: Sum(m_i * position_i)
  sum_mx <- sum(comp_masses * comp_x) + (p1_mass * 0.0) + (p2_mass * 0.0)
  sum_my <- sum(comp_masses * comp_y) + (p1_mass * 0.0) + (p2_mass * 0.0)
  sum_mz <- sum(comp_masses * comp_z) + (p1_mass * 18.0) + (p2_mass * 47.0)
  
  com_x <- sum_mx / total_m
  com_y <- sum_my / total_m
  com_z <- sum_mz / total_m
  
  return(list(
    vehicle_id = vehicle_id,
    fill_ratio = fill_ratio,
    propellant_mass = p1_mass + p2_mass,
    total_mass_kg = total_m,
    total_weight_n = calculate_weight_at_gravity(total_m),
    com_x = com_x,
    com_y = com_y,
    com_z = com_z
  ))
}

# Compute Mass Moments of Inertia
# Uses Parallel Axis Theorem: I_axis = I_centroidal + M * d^2
calculate_inertia_tensor <- function(df, vehicle_id, fill_ratio = 1.0) {
  veh_data <- df[df$vehicle == vehicle_id, ]
  
  # Calculate current Center of Mass
  com <- calculate_centre_of_mass(df, vehicle_id, fill_ratio)
  cx <- com$com_x
  cy <- com$com_y
  cz <- com$com_z
  
  # Sum over all dry hardware components
  # Treat each component as a point mass for system-level parallel-axis calculation
  Ixx <- 0
  Iyy <- 0
  Izz <- 0
  Ixy <- 0
  Ixz <- 0
  Iyz <- 0
  
  for (i in 1:nrow(veh_data)) {
    m <- veh_data$measured_mass[i]
    # Distance of component relative to system Center of Mass
    dx <- veh_data$x[i] - cx
    dy <- veh_data$y[i] - cy
    dz <- veh_data$z[i] - cz
    
    # Formulas for point mass moment of inertia tensor elements
    Ixx <- Ixx + m * (dy^2 + dz^2)
    Iyy <- Iyy + m * (dx^2 + dz^2)
    Izz <- Izz + m * (dx^2 + dy^2)
    
    Ixy <- Ixy - m * (dx * dy)
    Ixz <- Ixz - m * (dx * dz)
    Iyz <- Iyz - m * (dy * dz)
  }
  
  # Include wet propellant columns
  # S1 fuel column treated as a cylinder: radius 1.8m, mass p1_mass, center z=18
  p1_mass <- 320000 * fill_ratio
  if (p1_mass > 0) {
    dz1 <- 18.0 - cz
    # Centroidal inertia of cylinder: I_xx = 1/12 * M * (3r^2 + h^2)
    # Radius = 1.8, Height = 25m
    I_cyl_xx <- (1/12) * p1_mass * (3 * 1.8^2 + 25^2)
    I_cyl_zz <- 0.5 * p1_mass * 1.8^2
    
    Ixx <- Ixx + I_cyl_xx + p1_mass * dz1^2
    Iyy <- Iyy + I_cyl_xx + p1_mass * dz1^2
    Izz <- Izz + I_cyl_zz
  }
  
  # S2 fuel column: radius 1.8m, mass p2_mass, center z=47, height 10m
  p2_mass <- 90000 * fill_ratio
  if (p2_mass > 0) {
    dz2 <- 47.0 - cz
    I_cyl_xx2 <- (1/12) * p2_mass * (3 * 1.8^2 + 10^2)
    I_cyl_zz2 <- 0.5 * p2_mass * 1.8^2
    
    Ixx <- Ixx + I_cyl_xx2 + p2_mass * dz2^2
    Iyy <- Iyy + I_cyl_xx2 + p2_mass * dz2^2
    Izz <- Izz + I_cyl_zz2
  }
  
  return(list(
    vehicle_id = vehicle_id,
    fill_ratio = fill_ratio,
    centre_of_mass = c(cx, cy, cz),
    Ixx = Ixx,
    Iyy = Iyy,
    Izz = Izz,
    Ixy = Ixy,
    Ixz = Ixz,
    Iyz = Iyz
  ))
}
