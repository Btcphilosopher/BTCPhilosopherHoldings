import { ChangeDetectionStrategy, Component, signal, computed, inject, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { ReactiveFormsModule, FormGroup, FormControl, Validators } from '@angular/forms';
import { MatIconModule } from '@angular/material/icon';

export interface ComponentItem {
  component_id: string;
  component_name: string;
  component_type: string;
  stage: 'Stage_1' | 'Stage_2' | 'Payload';
  subsystem: string;
  vehicle: string;
  generation: string;
  nominal_mass: number;
  measured_mass: number;
  measurement_uncertainty: number;
  lower_bound: number;
  upper_bound: number;
  x: number;
  y: number;
  z: number;
  manufacturing_batch: string;
}

export interface VehicleSummary {
  vehicle_id: string;
  generation: string;
  dry_mass_kg: number;
  propellant_mass_kg: number;
  gross_mass_kg: number;
  mass_fraction_zeta: number;
  mass_balance_error_kg: number;
  closure_percentage: number;
}

export interface VehicleDetail {
  vehicle_id: string;
  generation: string;
  components: ComponentItem[];
  balance: {
    measured_vehicle_mass_kg: number;
    sum_component_mass_kg: number;
    mass_balance_error_kg: number;
    mass_closure_percentage: number;
  };
  stageStats: {
    Stage1: {
      dry_mass_kg: number;
      propellant_mass_kg: number;
      wet_mass_kg: number;
      mass_fraction_zeta: number;
      structural_coefficient_epsilon: number;
    };
    Stage2: {
      dry_mass_kg: number;
      propellant_mass_kg: number;
      wet_mass_kg: number;
      mass_fraction_zeta: number;
      structural_coefficient_epsilon: number;
    };
  };
  propellantStats: {
    Stage1: {
      total_loaded_kg: number;
      fuel_rp1_kg: number;
      oxidizer_lox_kg: number;
      pressurant_helium_kg: number;
      residuals_unusable_kg: number;
      usable_propellant_kg: number;
    };
    Stage2: {
      total_loaded_kg: number;
      fuel_rp1_kg: number;
      oxidizer_lox_kg: number;
      pressurant_helium_kg: number;
      residuals_unusable_kg: number;
      usable_propellant_kg: number;
    };
  };
  comStats: {
    total_mass_kg: number;
    total_weight_n: number;
    com_x: number;
    com_y: number;
    com_z: number;
  };
  inertiaStats: {
    Ixx: number;
    Iyy: number;
    Izz: number;
    Ixy: number;
    Ixz: number;
    Iyz: number;
  };
  uncertaintyStats: {
    unc_independent: number;
    unc_correlated: number;
    confidence_interval_95: [number, number];
  };
}

export interface MonteCarloResult {
  vehicle_id: string;
  samples_count: number;
  mean: number;
  median: number;
  sd: number;
  min: number;
  max: number;
  P5: number;
  P50: number;
  P95: number;
  bins: number[];
  binEdges: number[];
}

export interface ComProfilePoint {
  fill_ratio: number;
  total_mass_kg: number;
  propellant_mass_kg: number;
  total_weight_n: number;
  com_z: number;
  Ixx: number;
  Iyy: number;
  Izz: number;
}

export interface SPCBatch {
  batch: string;
  n: number;
  mean: number;
  sd: number;
  nominal_spec: number;
  lsl: number;
  usl: number;
  Cp: number;
  Cpk: number;
  lcl: number;
  ucl: number;
  masses: number[];
  drift: number;
}

export interface MixedEffectsResult {
  grand_mean: number;
  fixed_effects_generation: Record<string, number>;
  random_effects_component_intercepts: Record<string, number>;
  variances: {
    between_subsystems: number;
    within_subsystems_residual: number;
    icc_index: number;
  };
}

@Component({
  changeDetection: ChangeDetectionStrategy.OnPush,
  selector: 'app-root',
  imports: [CommonModule, ReactiveFormsModule, MatIconModule],
  templateUrl: './app.html',
  styleUrl: './app.css',
})
export class App implements OnInit {
  private http = inject(HttpClient);

  // Global Workspace states with strictly defined TypeScript structures
  vehicles = signal<VehicleSummary[]>([]);
  selectedVehicleId = signal<string>('NR-001');
  selectedVehicle = signal<VehicleDetail | null>(null);
  comProfile = signal<ComProfilePoint[]>([]);
  monteCarlo = signal<MonteCarloResult | null>(null);
  spcData = signal<Record<string, SPCBatch> | null>(null);
  mixedEffects = signal<MixedEffectsResult | null>(null);
  
  activeTab = signal<string>('OVERVIEW');
  searchQuery = signal<string>('');
  mcSampleCount = signal<number>(5000);
  localGravity = signal<number>(9.80665);
  propellantFillRatio = signal<number>(1.0); // interactive COM/Inertia propellant loader

  // Editing component states
  editingComponent = signal<ComponentItem | null>(null);
  editForm = new FormGroup({
    measured_mass: new FormControl<number>(0, { nonNullable: true, validators: [Validators.required, Validators.min(0.1)] }),
    measurement_uncertainty: new FormControl<number>(0, { nonNullable: true, validators: [Validators.required, Validators.min(0.01)] })
  });

  // AI report states
  reportText = signal<string>('');
  generatingReport = signal<boolean>(false);

  // Computed properties
  filteredComponents = computed(() => {
    const detail = this.selectedVehicle();
    if (!detail) return [];
    const query = this.searchQuery().toLowerCase().trim();
    if (!query) return detail.components;
    return detail.components.filter(c => 
      c.component_name.toLowerCase().includes(query) || 
      c.component_id.toLowerCase().includes(query) || 
      c.component_type.toLowerCase().includes(query) ||
      c.subsystem.toLowerCase().includes(query)
    );
  });

  // Subsystem breakdown calculations based on active propellant fill ratio
  subsystemSummary = computed(() => {
    const detail = this.selectedVehicle();
    if (!detail) return [];
    
    // Dynamic fuel additions
    const ratio = this.propellantFillRatio();
    const s1Prop = 320000 * ratio;
    const s2Prop = 90000 * ratio;
    const totalProp = s1Prop + s2Prop;
    
    const dryMass = detail.components.reduce((sum, c) => sum + c.measured_mass, 0);
    const totalMass = dryMass + totalProp;
    
    // Subsystem mapping
    const subsystems: Record<string, number> = {};
    detail.components.forEach(c => {
      subsystems[c.subsystem] = (subsystems[c.subsystem] || 0) + c.measured_mass;
    });
    
    const summary = Object.keys(subsystems).map(sub => {
      const mass = subsystems[sub];
      return {
        subsystem: sub,
        mass_kg: mass,
        percentage_dry: (mass / dryMass) * 100,
        percentage_gross: (mass / totalMass) * 100
      };
    });
    
    // Push propellant row
    summary.push({
      subsystem: 'PROPELLANT',
      mass_kg: totalProp,
      percentage_dry: 0,
      percentage_gross: (totalProp / totalMass) * 100
    });
    
    return summary.sort((a, b) => b.mass_kg - a.mass_kg);
  });

  // Inertia values computed dynamically based on the local gravity and fill ratio
  dynamicInertiaAndWeight = computed(() => {
    const detail = this.selectedVehicle();
    if (!detail) return null;
    
    const ratio = this.propellantFillRatio();
    const g = this.localGravity();
    
    // Propellant mass additions
    const s1Prop = 320000 * ratio;
    const s2Prop = 90000 * ratio;
    const dryMass = detail.components.reduce((sum, c) => sum + c.measured_mass, 0);
    const totalMass = dryMass + s1Prop + s2Prop;
    const weightN = totalMass * g;
    
    // We adjust moments of inertia relative to fill level
    const baseInertia = detail.inertiaStats;
    // Simple scaling factor for inertias relative to fuel state
    const ratioScale = (dryMass + (s1Prop + s2Prop) * 1.5) / (dryMass + 410000 * 1.5);
    
    return {
      total_mass_kg: totalMass,
      weight_n: weightN,
      Ixx: baseInertia.Ixx * ratioScale,
      Iyy: baseInertia.Iyy * ratioScale,
      Izz: baseInertia.Izz * ratioScale,
      Ixy: baseInertia.Ixy * ratioScale,
      Ixz: baseInertia.Ixz * ratioScale,
      Iyz: baseInertia.Iyz * ratioScale
    };
  });

  ngOnInit() {
    this.loadGlobalData();
  }

  loadGlobalData() {
    // 1. Fetch vehicles list
    this.http.get<VehicleSummary[]>('/api/vehicles').subscribe({
      next: (data) => {
        this.vehicles.set(data);
        if (data.length > 0) {
          this.selectVehicle(data[0].vehicle_id);
        }
      },
      error: (err) => console.error('Error fetching vehicles:', err)
    });

    // 2. Fetch SPC database statistics
    this.http.get<Record<string, SPCBatch>>('/api/spc').subscribe({
      next: (data) => this.spcData.set(data),
      error: (err) => console.error('Error fetching SPC data:', err)
    });

    // 3. Fetch Mixed Effects variance parameters
    this.http.get<MixedEffectsResult>('/api/mixed-effects').subscribe({
      next: (data) => this.mixedEffects.set(data),
      error: (err) => console.error('Error fetching Mixed Effects:', err)
    });
  }

  selectVehicle(vehicleId: string) {
    this.selectedVehicleId.set(vehicleId);
    this.reportText.set(''); // Clear stale reports
    
    // Fetch active vehicle specifications
    this.http.get<VehicleDetail>(`/api/vehicles/${vehicleId}`).subscribe({
      next: (data) => {
        this.selectedVehicle.set(data);
        // Load dynamic properties
        this.loadComProfile(vehicleId);
        this.triggerMonteCarlo(vehicleId);
      },
      error: (err) => console.error(`Error fetching vehicle ${vehicleId}:`, err)
    });
  }

  loadComProfile(vehicleId: string) {
    this.http.get<ComProfilePoint[]>(`/api/vehicles/${vehicleId}/com-profile`).subscribe({
      next: (data) => this.comProfile.set(data),
      error: (err) => console.error('Error loading COM profile:', err)
    });
  }

  triggerMonteCarlo(vehicleId: string) {
    this.http.get<MonteCarloResult>(`/api/monte-carlo/${vehicleId}?samples=${this.mcSampleCount()}`).subscribe({
      next: (data) => this.monteCarlo.set(data),
      error: (err) => console.error('Error running Monte Carlo:', err)
    });
  }

  onTabChange(tabName: string) {
    this.activeTab.set(tabName);
    this.searchQuery.set('');
    this.editingComponent.set(null);
  }

  onTabChangeFromEvent(event: Event) {
    const target = event.target as HTMLSelectElement;
    this.onTabChange(target.value);
  }

  onSearch(event: Event) {
    const val = (event.target as HTMLInputElement).value;
    this.searchQuery.set(val);
  }

  onSampleCountChange(event: Event) {
    const val = parseInt((event.target as HTMLSelectElement).value) || 5000;
    this.mcSampleCount.set(val);
    const currentVeh = this.selectedVehicleId();
    if (currentVeh) {
      this.triggerMonteCarlo(currentVeh);
    }
  }

  onPropellantSliderChange(event: Event) {
    const val = parseFloat((event.target as HTMLInputElement).value);
    this.propellantFillRatio.set(val);
  }

  onGravityChange(event: Event) {
    const val = parseFloat((event.target as HTMLInputElement).value);
    this.localGravity.set(isNaN(val) ? 9.80665 : val);
  }

  // Component edit action handlers
  startEditComponent(comp: ComponentItem) {
    this.editingComponent.set(comp);
    this.editForm.setValue({
      measured_mass: comp.measured_mass,
      measurement_uncertainty: comp.measurement_uncertainty
    });
  }

  cancelEditComponent() {
    this.editingComponent.set(null);
  }

  submitComponentUpdate() {
    const activeComp = this.editingComponent();
    if (!activeComp || this.editForm.invalid) return;

    const values = this.editForm.getRawValue();
    const payload = {
      ...activeComp,
      measured_mass: values.measured_mass,
      measurement_uncertainty: values.measurement_uncertainty
    };

    this.http.post<Record<string, unknown>>('/api/components/update', payload).subscribe({
      next: () => {
        this.editingComponent.set(null);
        // Reload details to trigger dynamic updates in signals
        const activeId = this.selectedVehicleId();
        this.loadGlobalData();
        this.selectVehicle(activeId);
      },
      error: (err) => console.error('Error updating component:', err)
    });
  }

  // AI report generation
  generateAiReport() {
    const activeId = this.selectedVehicleId();
    if (!activeId) return;

    this.generatingReport.set(true);
    this.reportText.set('');

    this.http.post<{ report_text: string }>('/api/generate-report', { vehicle_id: activeId }).subscribe({
      next: (res) => {
        this.reportText.set(res.report_text);
        this.generatingReport.set(false);
      },
      error: (err) => {
        console.error('Error generating AI report:', err);
        this.reportText.set('Error communicating with server for report generation.');
        this.generatingReport.set(false);
      }
    });
  }

  // Export functions (R code reproducibility & CSV configurations)
  exportRCode() {
    const rCodeText = `# ==========================================
# Newton Rockets Reproducibility Manifesto
# R statistical laboratory mass-properties script
# Generated: ${new Date().toISOString()}
# ==========================================

library(NewtonMass)

# Ingest and validate synthetic database
db <- create_synthetic_database()
validated <- validate_mass_data(db)
if (!validated$valid) {
  stop("Inconsistent database bounds detected")
}

# Run vehicle stats
vehicle_id <- "${this.selectedVehicleId()}"
balance <- calculate_mass_balance(db, vehicle_id)
stage_stats <- calculate_stage_statistics(db, vehicle_id)
propellant_stats <- calculate_propellant_bookkeeping(vehicle_id, fill_ratio = 1.0)
com_stats <- calculate_centre_of_mass(db, vehicle_id, fill_ratio = 1.0)
inertia_stats <- calculate_inertia_tensor(db, vehicle_id, fill_ratio = 1.0)

# Uncertainty propagation
unc_prop <- propagate_mass_uncertainty(db, vehicle_id)
mc_prop <- run_monte_carlo_engine(db, vehicle_id, n_samples = ${this.mcSampleCount()})

cat("\\n=======================================================\\n")
cat("VEHICLE:", vehicle_id, "\\n")
cat("Measured Vehicle Mass (Physical Scale):", balance$measured_vehicle_mass_kg, "kg\\n")
cat("Component Sum Dry Mass:", balance$sum_component_mass_kg, "kg\\n")
cat("Mass Balance Closure Error:", balance$mass_balance_error_kg, "kg\\n")
cat("Mass Closure Percentage:", balance$mass_closure_percentage, "%\\n")
cat("Calculated COM Z-Axis:", com_stats$com_z, "m\\n")
cat("Calculated Inertia Moment Ixx:", inertia_stats$Ixx, "kg*m2\\n")
cat("Calculated Inertia Moment Izz:", inertia_stats$Izz, "kg*m2\\n")
cat("Monte Carlo P5 Dry Mass Bound:", mc_prop$P5, "kg\\n")
cat("Monte Carlo P95 Dry Mass Bound:", mc_prop$P95, "kg\\n")
cat("=======================================================\\n")
`;
    const blob = new Blob([rCodeText], { type: 'text/plain' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `newton_reproducibility_${this.selectedVehicleId()}.R`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  }

  exportCSV() {
    const detail = this.selectedVehicle();
    if (!detail) return;

    let csvContent = "data:text/csv;charset=utf-8,";
    csvContent += "component_id,component_name,component_type,stage,subsystem,nominal_mass,measured_mass,measurement_uncertainty,x,y,z,manufacturing_batch\n";

    detail.components.forEach(c => {
      csvContent += `"${c.component_id}","${c.component_name}","${c.component_type}","${c.stage}","${c.subsystem}",${c.nominal_mass},${c.measured_mass},${c.measurement_uncertainty},${c.x},${c.y},${c.z},"${c.manufacturing_batch}"\n`;
    });

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `newton_components_${this.selectedVehicleId()}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  }
}
