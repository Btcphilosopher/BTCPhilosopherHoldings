/**
 * Newton Rockets Mass Properties and Statistical Calculations Engine
 */

export interface Component {
  component_id: string;
  component_name: string;
  component_type: string;
  stage: 'Stage_1' | 'Stage_2' | 'Payload';
  subsystem: string;
  vehicle: string;
  generation: string;
  nominal_mass: number;
  measured_mass: number;
  measurement_uncertainty: number;
  lower_bound: number;
  upper_bound: number;
  x: number; // m
  y: number; // m
  z: number; // m
  manufacturing_batch: string;
}

export interface VehicleMassBalance {
  vehicle_id: string;
  measured_vehicle_mass_kg: number;
  sum_component_mass_kg: number;
  mass_balance_error_kg: number;
  mass_closure_percentage: number;
}

export interface StageStats {
  dry_mass_kg: number;
  propellant_mass_kg: number;
  wet_mass_kg: number;
  mass_fraction_zeta: number;
  structural_coefficient_epsilon: number;
}

export interface PropellantBreakdown {
  total_loaded_kg: number;
  fuel_rp1_kg: number;
  oxidizer_lox_kg: number;
  pressurant_helium_kg: number;
  residuals_unusable_kg: number;
  usable_propellant_kg: number;
}

// Generate the complete synthetic dataset of 20 vehicles
export function generateSyntheticDatabase(): Component[] {
  const generations = ['Gen_1', 'Gen_2', 'Gen_3'];
  const subsystems = [
    'STRUCTURE', 'TANK', 'ENGINE', 'PLUMBING', 'AVIONICS', 
    'THERMAL_PROTECTION', 'LANDING_GEAR', 'PAYLOAD_ADAPTER'
  ];
  
  const vehicles: string[] = [];
  for (let i = 1; i <= 20; i++) {
    vehicles.push(`NR-${String(i).padStart(3, '0')}`);
  }
  
  // Mapping vehicles to generations
  const vehicleGens: Record<string, string> = {};
  vehicles.forEach((veh, idx) => {
    vehicleGens[veh] = generations[idx % generations.length];
  });
  
  // Base design masses (kg)
  const baseMasses: Record<string, { Stage1: number; Stage2: number }> = {
    STRUCTURE: { Stage1: 45000, Stage2: 8000 },
    TANK: { Stage1: 28000, Stage2: 5000 },
    ENGINE: { Stage1: 2400, Stage2: 1200 }, // S1 has 9 engines, S2 has 1
    PLUMBING: { Stage1: 4500, Stage2: 1100 },
    AVIONICS: { Stage1: 800, Stage2: 600 },
    THERMAL_PROTECTION: { Stage1: 2500, Stage2: 900 },
    LANDING_GEAR: { Stage1: 6500, Stage2: 0 },
    PAYLOAD_ADAPTER: { Stage1: 0, Stage2: 1500 }
  };
  
  const db: Component[] = [];
  
  // Simple Box-Muller transform for normal distribution simulation
  function rnorm(mean: number, sd: number): number {
    const u1 = Math.random() || 0.0001;
    const u2 = Math.random() || 0.0001;
    const z = Math.sqrt(-2.0 * Math.log(u1)) * Math.cos(2.0 * Math.PI * u2);
    return z * sd + mean;
  }
  
  vehicles.forEach((veh) => {
    const gen = vehicleGens[veh];
    const genMult = gen === 'Gen_1' ? 1.05 : gen === 'Gen_2' ? 1.00 : 0.94;
    const batchNum = gen === 'Gen_1' ? 'B-Alpha' : gen === 'Gen_2' ? 'B-Beta' : 'B-Gamma';
    
    // Stage 1 Components
    subsystems.forEach((sub) => {
      const baseVal = baseMasses[sub].Stage1;
      if (baseVal === 0) return;
      
      const nUnits = sub === 'ENGINE' ? 9 : 1;
      for (let unit = 1; unit <= nUnits; unit++) {
        const compName = nUnits > 1 ? `S1 ${sub} Unit ${unit}` : `S1 ${sub}`;
        const compId = `${veh}-S1-${sub}-${unit}`;
        
        const nom = (baseVal * genMult) / nUnits;
        const meas = rnorm(nom, nom * 0.012); // ~1.2% variance
        const unc = nom * 0.005; // 0.5% measurement uncertainty
        
        const xPos = rnorm(0, 0.2);
        const yPos = rnorm(0, 0.2);
        let zPos = 0;
        if (sub === 'ENGINE') zPos = rnorm(0.5, 0.1);
        else if (sub === 'TANK') zPos = rnorm(18, 2.0);
        else zPos = rnorm(15, 6.0);
        
        db.push({
          component_id: compId,
          component_name: compName,
          component_type: sub,
          stage: 'Stage_1',
          subsystem: sub,
          vehicle: veh,
          generation: gen,
          nominal_mass: nom,
          measured_mass: meas,
          measurement_uncertainty: unc,
          lower_bound: meas - 2 * unc,
          upper_bound: meas + 2 * unc,
          x: xPos,
          y: yPos,
          z: zPos,
          manufacturing_batch: batchNum
        });
      }
    });
    
    // Stage 2 Components
    subsystems.forEach((sub) => {
      const baseVal = baseMasses[sub].Stage2;
      if (baseVal === 0) return;
      
      const compName = `S2 ${sub}`;
      const compId = `${veh}-S2-${sub}`;
      
      const nom = baseVal * genMult;
      const meas = rnorm(nom, nom * 0.012);
      const unc = nom * 0.005;
      
      const xPos = rnorm(0, 0.1);
      const yPos = rnorm(0, 0.1);
      let zPos = 0;
      if (sub === 'ENGINE') zPos = rnorm(41, 0.2);
      else if (sub === 'TANK') zPos = rnorm(47, 1.5);
      else zPos = rnorm(48, 3.0);
      
      db.push({
        component_id: compId,
        component_name: compName,
        component_type: sub,
        stage: 'Stage_2',
        subsystem: sub,
        vehicle: veh,
        generation: gen,
        nominal_mass: nom,
        measured_mass: meas,
        measurement_uncertainty: unc,
        lower_bound: meas - 2 * unc,
        upper_bound: meas + 2 * unc,
        x: xPos,
        y: yPos,
        z: zPos,
        manufacturing_batch: batchNum
      });
    });
    
    // Payload Component
    const compId = `${veh}-PAYLOAD`;
    const payNom = gen === 'Gen_1' ? 12000 : gen === 'Gen_2' ? 15000 : 18500;
    const payMeas = rnorm(payNom, payNom * 0.001); // highly precise measurements
    const payUnc = payNom * 0.0005;
    
    db.push({
      component_id: compId,
      component_name: 'Payload Satellite Deck',
      component_type: 'PAYLOAD',
      stage: 'Payload',
      subsystem: 'PAYLOAD',
      vehicle: veh,
      generation: gen,
      nominal_mass: payNom,
      measured_mass: payMeas,
      measurement_uncertainty: payUnc,
      lower_bound: payMeas - 2 * payUnc,
      upper_bound: payMeas + 2 * payUnc,
      x: 0,
      y: 0,
      z: 57,
      manufacturing_batch: 'P-Commercial'
    });
  });
  
  return db;
}

// Global cached DB
let currentDB = generateSyntheticDatabase();

export function getDatabase(): Component[] {
  return currentDB;
}

export function updateDatabase(newDB: Component[]) {
  currentDB = newDB;
}

// Retrieve single vehicle metrics
export function calculateMassBalance(df: Component[], vehicleId: string): VehicleMassBalance {
  const vehData = df.filter(c => c.vehicle === vehicleId);
  const sumDryComponents = vehData.reduce((sum, c) => sum + c.measured_mass, 0);
  
  // Seed hash-based value to make weighing consistent per vehicle ID
  let hash = 0;
  for (let i = 0; i < vehicleId.length; i++) {
    hash = (hash << 5) - hash + vehicleId.charCodeAt(i);
  }
  const randomFactor = 1.0002 + ((hash % 100) / 100000); // stable pseudo-random discrepancy
  const measuredVehicleMass = sumDryComponents * randomFactor;
  
  const massBalanceError = measuredVehicleMass - sumDryComponents;
  const closurePct = (sumDryComponents / measuredVehicleMass) * 100;
  
  return {
    vehicle_id: vehicleId,
    measured_vehicle_mass_kg: measuredVehicleMass,
    sum_component_mass_kg: sumDryComponents,
    mass_balance_error_kg: massBalanceError,
    mass_closure_percentage: closurePct
  };
}

export function calculateStageStatistics(df: Component[], vehicleId: string) {
  const vehData = df.filter(c => c.vehicle === vehicleId);
  
  // Stage 1
  const s1Comps = vehData.filter(c => c.stage === 'Stage_1');
  const s1Dry = s1Comps.reduce((sum, c) => sum + c.measured_mass, 0);
  const s1Prop = 320000;
  const s1Wet = s1Dry + s1Prop;
  const s1Zeta = s1Prop / s1Wet;
  const s1Epsilon = s1Dry / s1Wet;
  
  // Stage 2
  const s2Comps = vehData.filter(c => c.stage === 'Stage_2');
  const s2Dry = s2Comps.reduce((sum, c) => sum + c.measured_mass, 0);
  const s2Prop = 90000;
  const s2Wet = s2Dry + s2Prop;
  const s2Zeta = s2Prop / s2Wet;
  const s2Epsilon = s2Dry / s2Wet;
  
  return {
    vehicle_id: vehicleId,
    Stage1: {
      dry_mass_kg: s1Dry,
      propellant_mass_kg: s1Prop,
      wet_mass_kg: s1Wet,
      mass_fraction_zeta: s1Zeta,
      structural_coefficient_epsilon: s1Epsilon
    },
    Stage2: {
      dry_mass_kg: s2Dry,
      propellant_mass_kg: s2Prop,
      wet_mass_kg: s2Wet,
      mass_fraction_zeta: s2Zeta,
      structural_coefficient_epsilon: s2Epsilon
    }
  };
}

export function calculatePropellantBookkeeping(vehicleId: string, fillRatio = 1.0) {
  const s1Total = 320000 * fillRatio;
  const s1Fuel = s1Total * (1 / (1 + 2.34));
  const s1Ox = s1Total * (2.34 / (1 + 2.34));
  const s1Pressurant = 150;
  const s1Residuals = s1Total * 0.007;
  
  const s2Total = 90000 * fillRatio;
  const s2Fuel = s2Total * (1 / (1 + 2.5));
  const s2Ox = s2Total * (2.5 / (1 + 2.5));
  const s2Pressurant = 50;
  const s2Residuals = s2Total * 0.008;
  
  return {
    vehicle_id: vehicleId,
    fill_ratio: fillRatio,
    Stage1: {
      total_loaded_kg: s1Total,
      fuel_rp1_kg: s1Fuel,
      oxidizer_lox_kg: s1Ox,
      pressurant_helium_kg: s1Pressurant,
      residuals_unusable_kg: s1Residuals,
      usable_propellant_kg: s1Total - s1Residuals
    },
    Stage2: {
      total_loaded_kg: s2Total,
      fuel_rp1_kg: s2Fuel,
      oxidizer_lox_kg: s2Ox,
      pressurant_helium_kg: s2Pressurant,
      residuals_unusable_kg: s2Residuals,
      usable_propellant_kg: s2Total - s2Residuals
    }
  };
}

// 3D Centre of Mass at specified fill percentage
export function calculateCentreOfMass(df: Component[], vehicleId: string, fillRatio = 1.0) {
  const vehData = df.filter(c => c.vehicle === vehicleId);
  const dryCompsMass = vehData.reduce((sum, c) => sum + c.measured_mass, 0);
  
  const p1Mass = 320000 * fillRatio;
  const p2Mass = 90000 * fillRatio;
  
  const totalM = dryCompsMass + p1Mass + p2Mass;
  
  const sumMX = vehData.reduce((sum, c) => sum + (c.measured_mass * c.x), 0);
  const sumMY = vehData.reduce((sum, c) => sum + (c.measured_mass * c.y), 0);
  const sumMZ = vehData.reduce((sum, c) => sum + (c.measured_mass * c.z), 0) + (p1Mass * 18.0) + (p2Mass * 47.0);
  
  const comX = sumMX / totalM;
  const comY = sumMY / totalM;
  const comZ = sumMZ / totalM;
  
  const g = 9.80665;
  const totalWeightN = totalM * g;
  
  return {
    vehicle_id: vehicleId,
    fill_ratio: fillRatio,
    propellant_mass_kg: p1Mass + p2Mass,
    total_mass_kg: totalM,
    total_weight_n: totalWeightN,
    com_x: comX,
    com_y: comY,
    com_z: comZ
  };
}

// Moments of Inertia
export function calculateInertiaTensor(df: Component[], vehicleId: string, fillRatio = 1.0) {
  const vehData = df.filter(c => c.vehicle === vehicleId);
  const com = calculateCentreOfMass(df, vehicleId, fillRatio);
  const cx = com.com_x;
  const cy = com.com_y;
  const cz = com.com_z;
  
  let Ixx = 0;
  let Iyy = 0;
  let Izz = 0;
  let Ixy = 0;
  let Ixz = 0;
  let Iyz = 0;
  
  // Point mass components using Parallel Axis Theorem relative to new COM
  vehData.forEach((c) => {
    const m = c.measured_mass;
    const dx = c.x - cx;
    const dy = c.y - cy;
    const dz = c.z - cz;
    
    Ixx += m * (dy * dy + dz * dz);
    Iyy += m * (dx * dx + dz * dz);
    Izz += m * (dx * dx + dy * dy);
    
    Ixy -= m * (dx * dy);
    Ixz -= m * (dx * dz);
    Iyz -= m * (dy * dz);
  });
  
  // S1 cylinder fuel: radius 1.8m, length 25m, center z=18
  const p1Mass = 320000 * fillRatio;
  if (p1Mass > 0) {
    const dz1 = 18.0 - cz;
    const I_cyl_xx = (1/12) * p1Mass * (3 * 1.8 * 1.8 + 25 * 25);
    const I_cyl_zz = 0.5 * p1Mass * 1.8 * 1.8;
    
    Ixx += I_cyl_xx + p1Mass * dz1 * dz1;
    Iyy += I_cyl_xx + p1Mass * dz1 * dz1;
    Izz += I_cyl_zz;
  }
  
  // S2 cylinder fuel: radius 1.8m, length 10m, center z=47
  const p2Mass = 90000 * fillRatio;
  if (p2Mass > 0) {
    const dz2 = 47.0 - cz;
    const I_cyl_xx2 = (1/12) * p2Mass * (3 * 1.8 * 1.8 + 10 * 10);
    const I_cyl_zz2 = 0.5 * p2Mass * 1.8 * 1.8;
    
    Ixx += I_cyl_xx2 + p2Mass * dz2 * dz2;
    Iyy += I_cyl_xx2 + p2Mass * dz2 * dz2;
    Izz += I_cyl_zz2;
  }
  
  return {
    vehicle_id: vehicleId,
    fill_ratio: fillRatio,
    centre_of_mass: [cx, cy, cz],
    Ixx,
    Iyy,
    Izz,
    Ixy,
    Ixz,
    Iyz
  };
}

// Monte Carlo simulation with full precision
export function runMonteCarlo(df: Component[], vehicleId: string, nSamples = 10000) {
  const vehData = df.filter(c => c.vehicle === vehicleId);
  const nComps = vehData.length;
  
  const means = vehData.map(c => c.measured_mass);
  const sds = vehData.map(c => c.measurement_uncertainty);
  const types = vehData.map(c => c.component_type);
  
  const simResults: number[] = new Array(nSamples);
  
  // Simple Box-Muller transform
  function boxMuller(mean: number, sd: number): number {
    const u1 = Math.random() || 0.0001;
    const u2 = Math.random() || 0.0001;
    const z = Math.sqrt(-2.0 * Math.log(u1)) * Math.cos(2.0 * Math.PI * u2);
    return z * sd + mean;
  }
  
  for (let s = 0; s < nSamples; s++) {
    // Generate correlated material density factor
    const materialDrift = boxMuller(0, 0.0025); // global correlation noise
    
    let sum = 0;
    for (let c = 0; c < nComps; c++) {
      let draw = boxMuller(means[c], sds[c]);
      // apply correlation to heavy structural parts
      if (types[c] === 'TANK' || types[c] === 'STRUCTURE') {
        draw *= (1 + materialDrift);
      }
      sum += draw;
    }
    simResults[s] = sum;
  }
  
  // Sort for exact quantiles
  simResults.sort((a, b) => a - b);
  const sumMass = simResults.reduce((s, val) => s + val, 0);
  const mean = sumMass / nSamples;
  
  const median = simResults[Math.floor(nSamples * 0.5)];
  const p5 = simResults[Math.floor(nSamples * 0.05)];
  const p95 = simResults[Math.floor(nSamples * 0.95)];
  
  // Variance
  let sumSqDiff = 0;
  for (let s = 0; s < nSamples; s++) {
    const diff = simResults[s] - mean;
    sumSqDiff += diff * diff;
  }
  const variance = sumSqDiff / (nSamples - 1);
  const stdDev = Math.sqrt(variance);
  
  // Bin samples for histogram output
  const binCount = 30;
  const min = simResults[0];
  const max = simResults[nSamples - 1];
  const binWidth = (max - min) / binCount;
  const bins = new Array(binCount).fill(0);
  
  for (let s = 0; s < nSamples; s++) {
    const val = simResults[s];
    let bIdx = Math.floor((val - min) / binWidth);
    if (bIdx >= binCount) bIdx = binCount - 1;
    if (bIdx < 0) bIdx = 0;
    bins[bIdx]++;
  }
  
  const binEdges = [];
  for (let b = 0; b <= binCount; b++) {
    binEdges.push(min + b * binWidth);
  }
  
  return {
    vehicle_id: vehicleId,
    samples_count: nSamples,
    mean,
    median,
    sd: stdDev,
    min,
    max,
    P5: p5,
    P50: median,
    P95: p95,
    bins,
    binEdges,
    // Return sample stats instead of complete array for API efficiency
    total_dry_com_mass: vehData.reduce((sum, c) => sum + c.measured_mass, 0)
  };
}

// SPC control values for Engine manufactured units (e.g., Engine unit masses)
export function runEngineSPCOverview(df: Component[]) {
  // Pull all engines
  const engines = df.filter(c => c.component_type === 'ENGINE');
  // Subdivide by batch
  const batches = Array.from(new Set(engines.map(e => e.manufacturing_batch)));
  
  const spcResults: Record<string, unknown> = {};
  
  batches.forEach((batch) => {
    const batchEngines = engines.filter(e => e.manufacturing_batch === batch);
    const masses = batchEngines.map(e => e.measured_mass);
    const n = masses.length;
    
    if (n < 3) return;
    
    const sum = masses.reduce((a, b) => a + b, 0);
    const mean = sum / n;
    
    const sqDiffSum = masses.reduce((acc, m) => acc + (m - mean) * (m - mean), 0);
    const sd = Math.sqrt(sqDiffSum / (n - 1));
    
    // Engineering Design Specification for Kestrel Engines:
    // Nominal: 2400 kg (Stage 1) or 1200 kg (Stage 2)
    // Limits: LSL = -4% LSL, USL = +4% USL
    const specNom = batch === 'B-Alpha' ? 2450 : batch === 'B-Beta' ? 2400 : 2250;
    const lsl = specNom * 0.96;
    const usl = specNom * 1.04;
    
    const cp = (usl - lsl) / (6 * sd);
    const cpkUpper = (usl - mean) / (3 * sd);
    const cpkLower = (mean - lsl) / (3 * sd);
    const cpk = Math.min(cpkUpper, cpkLower);
    
    spcResults[batch] = {
      batch,
      n,
      mean,
      sd,
      nominal_spec: specNom,
      lsl,
      usl,
      Cp: cp,
      Cpk: cpk,
      lcl: mean - 3 * sd,
      ucl: mean + 3 * sd,
      masses,
      drift: Math.abs(mean - specNom) / specNom * 100
    };
  });
  
  return spcResults;
}

// Mixed effects simulated results
export function runMixedEffectsModel(df: Component[]) {
  const grandMean = df.reduce((sum, c) => sum + c.measured_mass, 0) / df.length;
  
  // Fixed effects (generational deviations)
  const gens = ['Gen_1', 'Gen_2', 'Gen_3'];
  const genDevs: Record<string, number> = {};
  gens.forEach((gen) => {
    const gData = df.filter(c => c.generation === gen);
    const mean = gData.reduce((s, c) => s + c.measured_mass, 0) / gData.length;
    genDevs[gen] = mean - grandMean;
  });
  
  // Random effects variance (components)
  const compTypes = Array.from(new Set(df.map(c => c.component_type)));
  const randomDevs: Record<string, number> = {};
  compTypes.forEach((type) => {
    const tData = df.filter(c => c.component_type === type);
    const mean = tData.reduce((s, c) => s + c.measured_mass, 0) / tData.length;
    randomDevs[type] = mean - grandMean;
  });
  
  // Variances
  const varianceResidual = 120000; // variance within component classes
  const varianceBetween = 85000000; // variance between different subsystem scales (Structure vs Avionics is massive)
  const icc = varianceBetween / (varianceBetween + varianceResidual);
  
  return {
    grand_mean: grandMean,
    fixed_effects_generation: genDevs,
    random_effects_component_intercepts: randomDevs,
    variances: {
      between_subsystems: varianceBetween,
      within_subsystems_residual: varianceResidual,
      icc_index: icc
    }
  };
}

// Propagate correlated and independent uncertainty analytically
export function analyticalUncertainty(df: Component[], vehicleId: string) {
  const vehData = df.filter(c => c.vehicle === vehicleId);
  const sds = vehData.map(c => c.measurement_uncertainty);
  
  const sumMeasured = vehData.reduce((s, c) => s + c.measured_mass, 0);
  
  const uncIndependent = Math.sqrt(sds.reduce((sum, sd) => sum + sd * sd, 0));
  
  // Correlated: let's assume 12% correlation amongst matching subsystems
  let totalVar = sds.reduce((sum, sd) => sum + sd * sd, 0);
  for (let i = 0; i < sds.length - 1; i++) {
    for (let j = i + 1; j < sds.length; j++) {
      if (vehData[i].component_type === vehData[j].component_type) {
        totalVar += 2 * (0.15 * sds[i] * sds[j]);
      }
    }
  }
  const uncCorrelated = Math.sqrt(totalVar);
  
  return {
    vehicle_id: vehicleId,
    sum_measured_mass: sumMeasured,
    unc_independent: uncIndependent,
    unc_correlated: uncCorrelated,
    confidence_interval_95: [
      sumMeasured - 1.96 * uncCorrelated,
      sumMeasured + 1.96 * uncCorrelated
    ]
  };
}
