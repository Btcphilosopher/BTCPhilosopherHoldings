import {
  AngularNodeAppEngine,
  createNodeRequestHandler,
  isMainModule,
  writeResponseToNodeResponse,
} from '@angular/ssr/node';
import express from 'express';
import { join } from 'node:path';
import { GoogleGenAI } from '@google/genai';
import { 
  getDatabase, 
  updateDatabase, 
  calculateMassBalance, 
  calculateStageStatistics, 
  calculatePropellantBookkeeping, 
  calculateCentreOfMass, 
  calculateInertiaTensor, 
  runMonteCarlo, 
  runEngineSPCOverview, 
  runMixedEffectsModel, 
  analyticalUncertainty,
  Component
} from './mass_engine.js';

const browserDistFolder = join(import.meta.dirname, '../browser');

const app = express();
app.use(express.json());

const angularApp = new AngularNodeAppEngine();

// Instantiate Gemini client
const apiKey = process.env['GEMINI_API_KEY'] || '';
const ai = apiKey 
  ? new GoogleGenAI({ 
      apiKey,
      httpOptions: {
        headers: { 'User-Agent': 'aistudio-build' }
      }
    })
  : null;

/**
 * Newton Mass Properties & Statistical Laboratory REST API
 */

// 1. GET vehicles list
app.get('/api/vehicles', (req, res) => {
  try {
    const db = getDatabase();
    const uniqueVehicles = Array.from(new Set(db.map(c => c.vehicle)));
    
    const summary = uniqueVehicles.map(vId => {
      const vData = db.filter(c => c.vehicle === vId);
      const gen = vData[0]?.generation || 'Gen_2';
      const dryMass = vData.reduce((sum, c) => sum + c.measured_mass, 0);
      const propMass = 410000; // 320k + 90k standard
      const grossMass = dryMass + propMass;
      const zeta = propMass / grossMass;
      
      const balance = calculateMassBalance(db, vId);
      
      return {
        vehicle_id: vId,
        generation: gen,
        dry_mass_kg: dryMass,
        propellant_mass_kg: propMass,
        gross_mass_kg: grossMass,
        mass_fraction_zeta: zeta,
        mass_balance_error_kg: balance.mass_balance_error_kg,
        closure_percentage: balance.mass_closure_percentage
      };
    });
    
    res.json(summary);
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : 'Unknown error';
    res.status(500).json({ error: msg });
  }
});

// 2. GET detailed vehicle information
app.get('/api/vehicles/:id', (req, res) => {
  try {
    const vId = req.params.id;
    const db = getDatabase();
    const vData = db.filter(c => c.vehicle === vId);
    
    if (vData.length === 0) {
       res.status(404).json({ error: `Vehicle ${vId} not found` });
       return;
    }
    
    const balance = calculateMassBalance(db, vId);
    const stageStats = calculateStageStatistics(db, vId);
    const propellantStats = calculatePropellantBookkeeping(vId, 1.0);
    const comStats = calculateCentreOfMass(db, vId, 1.0);
    const inertiaStats = calculateInertiaTensor(db, vId, 1.0);
    const uncertaintyStats = analyticalUncertainty(db, vId);
    
    res.json({
      vehicle_id: vId,
      generation: vData[0].generation,
      components: vData,
      balance,
      stageStats,
      propellantStats,
      comStats,
      inertiaStats,
      uncertaintyStats
    });
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : 'Unknown error';
    res.status(500).json({ error: msg });
  }
});

// 3. GET Centre of Mass profile at different tank propellant fill ratios
app.get('/api/vehicles/:id/com-profile', (req, res) => {
  try {
    const vId = req.params.id;
    const db = getDatabase();
    const ratios = [1.0, 0.8, 0.6, 0.4, 0.2, 0.05, 0.0]; // dynamic states from loaded to dry burnout
    
    const profile = ratios.map(r => {
      const com = calculateCentreOfMass(db, vId, r);
      const inertia = calculateInertiaTensor(db, vId, r);
      return {
        fill_ratio: r,
        total_mass_kg: com.total_mass_kg,
        propellant_mass_kg: com.propellant_mass_kg,
        total_weight_n: com.total_weight_n,
        com_z: com.com_z,
        Ixx: inertia.Ixx,
        Iyy: inertia.Iyy,
        Izz: inertia.Izz
      };
    });
    
    res.json(profile);
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : 'Unknown error';
    res.status(500).json({ error: msg });
  }
});

// 4. GET Manufacturing SPC engine statistics
app.get('/api/spc', (req, res) => {
  try {
    const db = getDatabase();
    const spc = runEngineSPCOverview(db);
    res.json(spc);
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : 'Unknown error';
    res.status(500).json({ error: msg });
  }
});

// 5. GET Mixed-Effects Model statistics
app.get('/api/mixed-effects', (req, res) => {
  try {
    const db = getDatabase();
    const mixed = runMixedEffectsModel(db);
    res.json(mixed);
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : 'Unknown error';
    res.status(500).json({ error: msg });
  }
});

// 6. GET Monte Carlo uncertainty propagation results
app.get('/api/monte-carlo/:id', (req, res) => {
  try {
    const vId = req.params.id;
    const samples = parseInt(req.query['samples'] as string) || 10000;
    const db = getDatabase();
    
    const mc = runMonteCarlo(db, vId, samples);
    res.json(mc);
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : 'Unknown error';
    res.status(500).json({ error: msg });
  }
});

// 7. PUT / POST edit component mass measurements to see real-time updates
app.post('/api/components/update', (req, res) => {
  try {
    const updatedComp = req.body as Component;
    const db = getDatabase();
    
    const idx = db.findIndex(c => c.component_id === updatedComp.component_id);
    if (idx !== -1) {
      db[idx] = {
        ...db[idx],
        measured_mass: Number(updatedComp.measured_mass),
        measurement_uncertainty: Number(updatedComp.measurement_uncertainty),
        lower_bound: Number(updatedComp.measured_mass) - 2 * Number(updatedComp.measurement_uncertainty),
        upper_bound: Number(updatedComp.measured_mass) + 2 * Number(updatedComp.measurement_uncertainty)
      };
      updateDatabase(db);
      res.json({ success: true, component: db[idx] });
    } else {
      res.status(404).json({ error: `Component ${updatedComp.component_id} not found` });
    }
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : 'Unknown error';
    res.status(500).json({ error: msg });
  }
});

// 8. GENERATE scientific report via Gemini AI
app.post('/api/generate-report', async (req, res) => {
  try {
    const { vehicle_id } = req.body;
    if (!vehicle_id) {
       res.status(400).json({ error: 'vehicle_id is required' });
       return;
    }
    
    const db = getDatabase();
    const vData = db.filter(c => c.vehicle === vehicle_id);
    if (vData.length === 0) {
       res.status(404).json({ error: 'Vehicle not found' });
       return;
    }
    
    const balance = calculateMassBalance(db, vehicle_id);
    const stageStats = calculateStageStatistics(db, vehicle_id);
    const comStats = calculateCentreOfMass(db, vehicle_id, 1.0);
    const inertiaStats = calculateInertiaTensor(db, vehicle_id, 1.0);
    const uncertaintyStats = analyticalUncertainty(db, vehicle_id);
    
    if (!ai) {
       res.json({
         generated: false,
         report_text: `# Newton Rockets Mass-Properties Analysis Report\n\n**Vehicle Configuration**: ${vehicle_id} (${vData[0].generation})\n\n*(Telemetry report generation requires setting GEMINI_API_KEY in the Secrets panel of AI Studio. Running fallback analytic review:)*\n\n- **Dry sum**: ${balance.sum_component_mass_kg.toFixed(2)} kg\n- **Independent uncertainty**: ±${uncertaintyStats.unc_independent.toFixed(2)} kg\n- **Correlated uncertainty**: ±${uncertaintyStats.unc_correlated.toFixed(2)} kg\n- **Stage 1 dry**: ${stageStats.Stage1.dry_mass_kg.toFixed(2)} kg\n- **Stage 2 dry**: ${stageStats.Stage2.dry_mass_kg.toFixed(2)} kg\n- **Fully Loaded COM Z**: ${comStats.com_z.toFixed(3)} m\n- **Loaded Moments of Inertia**: Ixx = ${inertiaStats.Ixx.toExponential(3)} kg·m², Izz = ${inertiaStats.Izz.toExponential(3)} kg·m²`
       });
       return;
    }
    
    const prompt = `You are a Principal Aerospace Statistical Engineer at Newton Rockets.
Write an official, high-fidelity, peer-reviewed engineering report analyzing the weight, mass properties, and statistical uncertainties of the Rocket Vehicle ${vehicle_id}.

Here are the precise, calculated mass statistics for ${vehicle_id}:
- Vehicle ID: ${vehicle_id}
- Generation: ${vData[0].generation}
- Total Dry Component Sum: ${balance.sum_component_mass_kg.toFixed(2)} kg
- Measured Vehicle Mass (Physical Load Cells): ${balance.measured_vehicle_mass_kg.toFixed(2)} kg
- Mass Closure Error: ${balance.mass_balance_error_kg.toFixed(2)} kg (${balance.mass_closure_percentage.toFixed(4)}% closure)
- Stage 1 Dry Mass: ${stageStats.Stage1.dry_mass_kg.toFixed(2)} kg (Loaded Propellant: 320,000.00 kg)
- Stage 2 Dry Mass: ${stageStats.Stage2.dry_mass_kg.toFixed(2)} kg (Loaded Propellant: 90,000.00 kg)
- Stage 1 Structural Coefficient: ${stageStats.Stage1.structural_coefficient_epsilon.toFixed(5)}
- Stage 2 Structural Coefficient: ${stageStats.Stage2.structural_coefficient_epsilon.toFixed(5)}
- Stage 1 Mass Fraction: ${stageStats.Stage1.mass_fraction_zeta.toFixed(5)}
- Stage 2 Mass Fraction: ${stageStats.Stage2.mass_fraction_zeta.toFixed(5)}
- Full Loaded COM (x, y, z): (${comStats.com_x.toFixed(3)}, ${comStats.com_y.toFixed(3)}, ${comStats.com_z.toFixed(3)}) m
- Fully Loaded Weight (at local gravity 9.80665 m/s²): ${comStats.total_weight_n.toFixed(2)} N
- Inertia Tensor Elements (Fully Loaded): Ixx = ${inertiaStats.Ixx.toFixed(1)}, Iyy = ${inertiaStats.Iyy.toFixed(1)}, Izz = ${inertiaStats.Izz.toFixed(1)} kg·m²
- Analytical Uncorrelated Uncertainty: ±${uncertaintyStats.unc_independent.toFixed(2)} kg
- Analytical Correlated Uncertainty: ±${uncertaintyStats.unc_correlated.toFixed(2)} kg
- 95% Confidence Dry Interval: [${uncertaintyStats.confidence_interval_95[0].toFixed(2)} to ${uncertaintyStats.confidence_interval_95[1].toFixed(2)}] kg

Please output a comprehensive, structured technical paper formatted in clean Markdown.
Use formal scientific prose, proper equations where helpful, and ensure that you address:
1. Executive Summary & Vehicle Architecture
2. Mass vs. Weight acceleration properties (Standard Earth vs User defined fields)
3. Component Hierarchical Mass Balance & Closure Verification
4. Dynamic propellant loading states and 3D Centre of Gravity / Centre of Mass trajectory analysis
5. Parallel-Axis moments of inertia calculations and gyroscopic angular coefficients
6. Quality Assurance & Statistical Process Control (outlining the effect of correlated manufacturing variations)
7. Engineering conclusions, safety margin recommendations, and limitations.

Never make up data outside the provided numbers. Address the distinction between mass and weight explicitly.`;
    
    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: prompt,
    });
    
    res.json({
      generated: true,
      report_text: response.text || ''
    });
    
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : 'Unknown error';
    res.status(500).json({ error: msg });
  }
});

/**
 * Serve static files from /browser
 */
app.use(
  express.static(browserDistFolder, {
    maxAge: '1y',
    index: false,
    redirect: false,
  }),
);

/**
 * Handle all other requests by rendering the Angular application.
 */
app.use((req, res, next) => {
  angularApp
    .handle(req)
    .then((response) =>
      response ? writeResponseToNodeResponse(response, res) : next(),
    )
    .catch(next);
});

/**
 * Start the server if this module is the main entry point, or it is ran via PM2.
 * The server listens on the port defined by the `PORT` environment variable, or defaults to 4000.
 */
if (isMainModule(import.meta.url) || process.env['pm_id']) {
  const port = process.env['PORT'] || 3000;
  app.listen(port, () => {
    console.log(`Node Express server listening on http://localhost:${port}`);
  });
}

/**
 * Request handler used by the Angular CLI (for dev-server and during build) or Firebase Cloud Functions.
 */
export const reqHandler = createNodeRequestHandler(app);
