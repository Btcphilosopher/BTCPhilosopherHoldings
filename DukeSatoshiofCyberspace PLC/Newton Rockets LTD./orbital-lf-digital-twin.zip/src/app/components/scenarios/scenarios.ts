import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { SimulationEngine } from '../../services/simulation-engine';

@Component({
  selector: 'app-scenarios',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, MatIconModule],
  template: `
    <div class="space-y-6 font-mono text-xs">
      
      <!-- Section Header -->
      <div class="bg-[#0f172a] border border-slate-800 rounded-xl p-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h3 class="text-sm font-bold tracking-wider text-slate-100 uppercase flex items-center gap-2">
            <mat-icon class="text-cyan-400 text-lg">tune</mat-icon>
            Simulation Scenarios & Operational Stress Testing Matrix
          </h3>
          <p class="text-slate-400 mt-0.5">
            Pre-calibrated edge cases, solar disturbance events & constellation handover trials
          </p>
        </div>

        <span class="px-3 py-1 rounded bg-slate-900 border border-slate-700 text-slate-300">
          ACTIVE: <strong class="text-cyan-300">{{ getActiveScenarioName() }}</strong>
        </span>
      </div>

      <!-- Scenarios Cards Grid -->
      <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        @for (sc of engine.scenarios; track sc.id) {
          <div
            class="bg-[#0f172a] border rounded-xl p-5 space-y-3 flex flex-col justify-between transition-all"
            [class.border-cyan-500]="engine.currentScenarioId() === sc.id"
            [class.shadow-lg]="engine.currentScenarioId() === sc.id"
            [class.shadow-cyan-950/40]="engine.currentScenarioId() === sc.id"
            [class.border-slate-800]="engine.currentScenarioId() !== sc.id">
            
            <div class="space-y-2">
              <div class="flex items-center justify-between">
                <span class="px-2 py-0.5 rounded text-[10px] font-bold bg-slate-800 text-slate-300">
                  {{ sc.badge }}
                </span>
                <span class="text-[10px] text-slate-500">{{ sc.category }}</span>
              </div>

              <h4 class="text-sm font-bold text-slate-100">
                {{ sc.name }}
              </h4>

              <p class="text-slate-400 text-[11px] leading-relaxed">
                {{ sc.description }}
              </p>

              <!-- Scenario Parameter Snapshot -->
              <div class="p-2.5 bg-[#070b14] border border-slate-800/80 rounded-lg space-y-1 text-[10px] text-slate-300">
                <div class="flex justify-between">
                  <span>Satellite / Station:</span>
                  <span class="text-slate-100 font-semibold">{{ sc.satelliteId }} ↔ {{ sc.groundStationId.replace('GS-', '') }}</span>
                </div>
                <div class="flex justify-between">
                  <span>Solar Flux / SSN:</span>
                  <span class="text-cyan-300">{{ sc.solarActivitySfu }} SFU / SSN {{ sc.sunspotNumber }}</span>
                </div>
                <div class="flex justify-between">
                  <span>Noise Excess:</span>
                  <span class="text-amber-300">+{{ sc.manMadeNoiseExcessDb }} dB</span>
                </div>
              </div>

              <div class="text-[10px] text-slate-500 italic pt-1">
                "{{ sc.notes }}"
              </div>
            </div>

            <button
              (click)="engine.loadScenario(sc.id)"
              class="w-full py-2 rounded-lg border font-bold transition-all cursor-pointer flex items-center justify-center gap-1.5 mt-2"
              [class.bg-cyan-500]="engine.currentScenarioId() === sc.id"
              [class.text-slate-950]="engine.currentScenarioId() === sc.id"
              [class.border-cyan-400]="engine.currentScenarioId() === sc.id"
              [class.bg-slate-900]="engine.currentScenarioId() !== sc.id"
              [class.border-slate-700]="engine.currentScenarioId() !== sc.id"
              [class.text-slate-300]="engine.currentScenarioId() !== sc.id"
              [class.hover:border-cyan-500]="engine.currentScenarioId() !== sc.id">
              <mat-icon class="text-xs scale-75">{{ engine.currentScenarioId() === sc.id ? 'check' : 'play_arrow' }}</mat-icon>
              <span>{{ engine.currentScenarioId() === sc.id ? 'CURRENTLY ACTIVE' : 'ENGAGE SCENARIO' }}</span>
            </button>
          </div>
        }
      </div>

    </div>
  `
})
export class ScenariosComponent {
  public engine = inject(SimulationEngine);

  public getActiveScenarioName(): string {
    return this.engine.scenarios.find(s => s.id === this.engine.currentScenarioId())?.name ?? 'Custom';
  }
}
