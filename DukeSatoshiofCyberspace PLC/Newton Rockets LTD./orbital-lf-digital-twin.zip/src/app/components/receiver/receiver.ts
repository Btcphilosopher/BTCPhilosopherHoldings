import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { SimulationEngine } from '../../services/simulation-engine';

@Component({
  selector: 'app-receiver',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, MatIconModule],
  template: `
    <div class="space-y-6">
      
      <!-- Realistic Ground Receiver Instrument Front Panel -->
      <div class="bg-[#0b111e] border-2 border-slate-700 rounded-2xl p-6 shadow-2xl space-y-6 font-mono">
        
        <!-- Instrument Top Brand Plate -->
        <div class="flex items-center justify-between border-b-2 border-slate-800 pb-4">
          <div class="flex items-center gap-3">
            <div class="w-3.5 h-3.5 rounded-full bg-cyan-400 ring-4 ring-cyan-500/20 animate-pulse"></div>
            <div>
              <h2 class="text-base font-bold tracking-widest text-slate-100 uppercase">
                ORBITAL-LF GROUND RECEIVER UNIT
              </h2>
              <p class="text-[11px] text-slate-400">MODEL RX-8400 · LOW-FREQUENCY DIGITAL BROADCAST TERMINAL</p>
            </div>
          </div>

          <div class="flex items-center gap-2">
            <span class="text-xs px-3 py-1 rounded bg-slate-900 border border-slate-700 text-slate-300">
              STATION: <strong class="text-cyan-300">{{ engine.activeGroundStation().name }}</strong>
            </span>
          </div>
        </div>

        <!-- Central Digital Phosphor Readout Cluster -->
        <div class="grid grid-cols-2 md:grid-cols-4 gap-4 bg-[#060a12] border-2 border-slate-800/80 rounded-xl p-5 shadow-inner">
          
          <!-- Readout 1: Frequency -->
          <div class="space-y-1">
            <div class="text-[10px] text-slate-500 uppercase tracking-wider">TUNED FREQUENCY</div>
            <div class="text-2xl sm:text-3xl font-bold text-cyan-300">
              {{ (engine.activeSatellite().transmitter.rfFrequencyHz / 1000) | number:'1.3-3' }}
              <span class="text-xs font-normal text-slate-500">kHz</span>
            </div>
            <div class="text-[10px] text-slate-400">IF: 0.000 kHz (Direct Conv)</div>
          </div>

          <!-- Readout 2: Signal State & RSSI -->
          <div class="space-y-1">
            <div class="text-[10px] text-slate-500 uppercase tracking-wider">SIGNAL RSSI / LOCK</div>
            <div class="text-2xl sm:text-3xl font-bold text-emerald-400 flex items-center gap-2">
              <span>{{ engine.activeLinkBudget().rxPowerDbm }}</span>
              <span class="text-xs font-normal text-slate-500">dBm</span>
            </div>
            <div class="text-[10px] font-bold flex items-center gap-1.5"
                 [class.text-emerald-400]="engine.receiverLockState() === 'DECODE'"
                 [class.text-cyan-300]="engine.receiverLockState() === 'LOCK'"
                 [class.text-amber-400]="engine.receiverLockState() === 'ACQUIRE'"
                 [class.text-slate-500]="engine.receiverLockState() === 'SEARCH'">
              <span>● {{ engine.receiverLockState() }}</span>
              <span class="text-slate-500 font-normal">| S9+20dB</span>
            </div>
          </div>

          <!-- Readout 3: C/N & Doppler -->
          <div class="space-y-1">
            <div class="text-[10px] text-slate-500 uppercase tracking-wider">CARRIER/NOISE (C/N)</div>
            <div class="text-2xl sm:text-3xl font-bold text-cyan-300">
              {{ engine.activeLinkBudget().carrierToNoiseRatioDb }}
              <span class="text-xs font-normal text-slate-500">dB</span>
            </div>
            <div class="text-[10px] text-slate-400">
              Doppler: <strong class="text-slate-200">{{ engine.activeGeometry().dopplerShiftHz > 0 ? '+' : '' }}{{ engine.activeGeometry().dopplerShiftHz | number:'1.2-2' }} Hz</strong>
            </div>
          </div>

          <!-- Readout 4: Bit Error Rate & CRC -->
          <div class="space-y-1">
            <div class="text-[10px] text-slate-500 uppercase tracking-wider">CODED BER & INTEGRITY</div>
            <div class="text-2xl sm:text-3xl font-bold text-emerald-400">
              {{ engine.activeLinkBudget().codedBer < 1e-6 ? '< 1×10⁻⁶' : (engine.activeLinkBudget().codedBer.toExponential(1)) }}
            </div>
            <div class="text-[10px] text-emerald-400 flex items-center gap-2 font-bold">
              <span>FEC: PASS</span>
              <span>CRC: PASS</span>
            </div>
          </div>

        </div>

        <!-- S-Meter & Signal Quality Analog Bars -->
        <div class="bg-[#070b14] border border-slate-800 rounded-lg p-3 space-y-2 text-xs">
          <div class="flex items-center justify-between text-[11px] text-slate-400">
            <span>RF SIGNAL STRENGTH INDICATOR (RSSI S-METER)</span>
            <span>-140 dBm ———————————————— -60 dBm</span>
          </div>
          <div class="w-full bg-slate-900 rounded-full h-3.5 p-0.5 border border-slate-700 overflow-hidden flex items-center">
            <div
              class="h-full rounded-full transition-all duration-150 bg-gradient-to-r from-cyan-600 via-emerald-500 to-amber-400"
              [style.width.%]="getSmeterPercent()">
            </div>
          </div>
        </div>

        <!-- SDR Front-End Controls & Tuning Knobs -->
        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 text-xs pt-2">
          
          <!-- Control 1: LNA Gain -->
          <div class="p-3.5 bg-slate-900/90 border border-slate-700/80 rounded-xl space-y-2">
            <div class="flex items-center justify-between">
              <span class="text-slate-400 font-bold">LNA FRONT GAIN</span>
              <span class="text-cyan-300 font-bold">+{{ engine.activeGroundStation().lnaGainDb }} dB</span>
            </div>
            <input
              type="range"
              min="10"
              max="40"
              step="1"
              [value]="engine.activeGroundStation().lnaGainDb"
              (input)="onLnaInput($event)"
              class="w-full cursor-pointer">
            <div class="text-[10px] text-slate-500 flex justify-between">
              <span>Min (+10dB)</span>
              <span>Max (+40dB)</span>
            </div>
          </div>

          <!-- Control 2: Filter Bandwidth -->
          <div class="p-3.5 bg-slate-900/90 border border-slate-700/80 rounded-xl space-y-2">
            <div class="flex items-center justify-between">
              <span class="text-slate-400 font-bold">IF BANDWIDTH</span>
              <span class="text-cyan-300 font-bold">{{ engine.activeGroundStation().filterBandwidthHz }} Hz</span>
            </div>
            <select
              [value]="engine.activeGroundStation().filterBandwidthHz"
              (change)="onFilterChange($event)"
              class="w-full bg-slate-800 border border-slate-600 text-slate-200 text-xs rounded p-1.5 focus:border-cyan-500 focus:outline-none cursor-pointer">
              <option value="1200">1.2 kHz (CW / Narrow)</option>
              <option value="2400">2.4 kHz (Standard Broadcast)</option>
              <option value="4800">4.8 kHz (Wideband High-Rate)</option>
              <option value="9600">9.6 kHz (Full Channel)</option>
            </select>
          </div>

          <!-- Control 3: AGC Mode -->
          <div class="p-3.5 bg-slate-900/90 border border-slate-700/80 rounded-xl space-y-2">
            <div class="flex items-center justify-between">
              <span class="text-slate-400 font-bold">DIGITAL AGC</span>
              <span class="text-emerald-400 font-bold">FAST (15ms)</span>
            </div>
            <div class="grid grid-cols-3 gap-1">
              @for (m of ['FAST', 'SLOW', 'OFF']; track m) {
                <button
                  (click)="agcMode.set(m)"
                  class="py-1 rounded text-center border cursor-pointer transition-colors"
                  [class.bg-cyan-950]="agcMode() === m"
                  [class.border-cyan-700]="agcMode() === m"
                  [class.text-cyan-300]="agcMode() === m"
                  [class.border-slate-700]="agcMode() !== m"
                  [class.text-slate-400]="agcMode() !== m">
                  {{ m }}
                </button>
              }
            </div>
          </div>

          <!-- Control 4: ADC & DSP -->
          <div class="p-3.5 bg-slate-900/90 border border-slate-700/80 rounded-xl space-y-1">
            <span class="text-slate-400 font-bold block mb-1">ADC HARDWARE SPECS</span>
            <div class="text-[11px] text-slate-300">Sample Rate: <strong>48.0 kSps</strong></div>
            <div class="text-[11px] text-slate-300">Resolution: <strong>24-bit Delta-Sigma</strong></div>
            <div class="text-[11px] text-slate-300">Dynamic Range: <strong>132 dBFS</strong></div>
          </div>

        </div>

      </div>

      <!-- Live CCSDS Ground Receiver Decoded Packet Terminal -->
      <div class="bg-[#0f172a] border border-slate-800 rounded-xl p-5 space-y-4 font-mono text-xs">
        <div class="flex items-center justify-between border-b border-slate-800 pb-3">
          <div class="flex items-center gap-2">
            <mat-icon class="text-emerald-400 text-lg">terminal</mat-icon>
            <h3 class="text-sm font-bold tracking-wide text-slate-200 uppercase">
              Decoded Satellite Broadcast Packet Stream
            </h3>
          </div>
          <span class="text-slate-400 text-[11px]">{{ engine.decodedPackets().length }} PACKETS BUFFERED</span>
        </div>

        <div class="space-y-2 max-h-80 overflow-y-auto pr-1">
          @for (pkt of engine.decodedPackets(); track pkt.id) {
            <div class="p-3 bg-[#070b14] border border-slate-800/80 rounded-lg hover:border-slate-700 transition-colors space-y-1.5">
              <div class="flex flex-wrap items-center justify-between gap-2 text-[11px]">
                <div class="flex items-center gap-2 font-bold text-cyan-300">
                  <span>[{{ pkt.satelliteId }}]</span>
                  <span>FRAME #{{ pkt.frameNumber }}</span>
                  <span class="text-slate-400 font-normal">({{ pkt.payloadType }})</span>
                </div>
                <div class="text-slate-400 text-[10px]">
                  {{ pkt.timestampUtc }}
                </div>
                <div class="flex items-center gap-2 text-[10px]">
                  <span class="text-emerald-400 font-semibold">FEC: {{ pkt.fecStatus }}</span>
                  <span class="text-emerald-400 font-semibold">CRC: {{ pkt.crcStatus }}</span>
                  <span class="text-slate-400">RSSI: {{ pkt.rssiDbm }} dBm</span>
                </div>
              </div>

              <!-- Hex Payload Preview -->
              <div class="bg-black/40 p-1.5 rounded text-[10px] text-slate-400 break-all font-mono">
                RAW: {{ pkt.rawBitsHex }}
              </div>

              <!-- Decoded JSON Payload -->
              <div class="text-[11px] text-slate-300 pl-2 border-l-2 border-cyan-800">
                PAYLOAD: <code class="text-cyan-200">{{ formatPayload(pkt.payloadContent) }}</code>
              </div>
            </div>
          }
        </div>

      </div>

    </div>
  `
})
export class ReceiverComponent {
  public engine = inject(SimulationEngine);
  public agcMode = signal<string>('FAST');

  public onLnaInput(event: Event): void {
    const input = event.target as HTMLInputElement;
    if (input) {
      this.engine.updateGroundStationSettings({ lnaGainDb: Number(input.value) });
    }
  }

  public onFilterChange(event: Event): void {
    const select = event.target as HTMLSelectElement;
    if (select) {
      this.engine.updateGroundStationSettings({ filterBandwidthHz: Number(select.value) });
    }
  }

  public getSmeterPercent(): number {
    const p = this.engine.activeLinkBudget().rxPowerDbm;
    const pct = ((p - (-140)) / 80) * 100;
    return Math.max(2, Math.min(100, pct));
  }

  public formatPayload(content: Record<string, unknown>): string {
    return JSON.stringify(content).replace(/"/g, '').replace(/,/g, ' | ').replace(/\{|\}/g, '');
  }
}
