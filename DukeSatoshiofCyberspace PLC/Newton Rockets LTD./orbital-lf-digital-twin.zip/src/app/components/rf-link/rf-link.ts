import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { SimulationEngine } from '../../services/simulation-engine';
import { TransmitterSpec } from '../../models/satellite.model';

@Component({
  selector: 'app-rf-link',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, MatIconModule],
  template: `
    <div class="space-y-6">
      
      <!-- Section Header -->
      <div class="bg-[#0f172a] border border-slate-800 rounded-xl p-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h3 class="text-sm font-bold tracking-wider text-slate-100 uppercase font-mono flex items-center gap-2">
            <mat-icon class="text-cyan-400 text-lg">calculate</mat-icon>
            Detailed RF Link Budget Engine & Loss Decomposition
          </h3>
          <p class="text-xs text-slate-400 font-mono mt-0.5">
            Empirical Friis power balance, Nyquist-Johnson noise floor & Shannon capacity limits
          </p>
        </div>

        <!-- Power Unit Selector -->
        <div class="flex items-center bg-slate-900 border border-slate-700 rounded-lg p-0.5 text-xs font-mono">
          <button
            (click)="unitMode.set('DBM')"
            class="px-2.5 py-1 rounded transition-colors cursor-pointer"
            [class.bg-cyan-500]="unitMode() === 'DBM'"
            [class.text-slate-950]="unitMode() === 'DBM'"
            [class.font-bold]="unitMode() === 'DBM'"
            [class.text-slate-400]="unitMode() !== 'DBM'">
            dBm
          </button>
          <button
            (click)="unitMode.set('DBW')"
            class="px-2.5 py-1 rounded transition-colors cursor-pointer"
            [class.bg-cyan-500]="unitMode() === 'DBW'"
            [class.text-slate-950]="unitMode() === 'DBW'"
            [class.font-bold]="unitMode() === 'DBW'"
            [class.text-slate-400]="unitMode() !== 'DBW'">
            dBW
          </button>
          <button
            (click)="unitMode.set('WATTS')"
            class="px-2.5 py-1 rounded transition-colors cursor-pointer"
            [class.bg-cyan-500]="unitMode() === 'WATTS'"
            [class.text-slate-950]="unitMode() === 'WATTS'"
            [class.font-bold]="unitMode() === 'WATTS'"
            [class.text-slate-400]="unitMode() !== 'WATTS'">
            Watts
          </button>
        </div>
      </div>

      <!-- Main Link Budget Table & Interactive Parameter Sliders -->
      <div class="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        <!-- Left 8 cols: Step-by-Step Computational Waterfall -->
        <div class="lg:col-span-8 bg-[#0f172a] border border-slate-800 rounded-xl p-5 space-y-4 font-mono text-xs">
          <div class="flex items-center justify-between border-b border-slate-800 pb-2">
            <span class="text-slate-300 font-bold uppercase text-xs">Friis Power Balance Decomposition</span>
            <span class="text-slate-500 text-[11px]">R = {{ engine.activeGeometry().slantRangeKm | number:'1.0-0' }} km | f = {{ engine.activeSatellite().transmitter.rfFrequencyHz / 1000 }} kHz</span>
          </div>

          <div class="space-y-1.5 divide-y divide-slate-800/50">
            
            <!-- 1. Transmit Power -->
            <div class="pt-2 flex items-center justify-between hover:bg-slate-800/30 px-2 py-1.5 rounded">
              <div class="flex items-center gap-2">
                <span class="text-cyan-400 font-bold">+</span>
                <span class="text-slate-200">Transmitter Output Power (P_tx)</span>
              </div>
              <div class="text-slate-100 font-semibold text-right">
                @if (unitMode() === 'DBM') {
                  <span>+{{ engine.activeLinkBudget().txPowerDbm }} dBm</span>
                } @else if (unitMode() === 'DBW') {
                  <span>+{{ engine.activeLinkBudget().txPowerDbw }} dBW</span>
                } @else {
                  <span>{{ engine.activeLinkBudget().txPowerWatts }} W</span>
                }
              </div>
            </div>

            <!-- 2. Satellite Antenna Gain -->
            <div class="pt-2 flex items-center justify-between hover:bg-slate-800/30 px-2 py-1.5 rounded">
              <div class="flex items-center gap-2">
                <span class="text-cyan-400 font-bold">+</span>
                <span class="text-slate-200">Satellite Antenna Gain (G_tx)</span>
                <span class="text-[10px] text-slate-500">({{ engine.activeSatellite().antenna.type }})</span>
              </div>
              <div class="text-cyan-300 font-semibold text-right">
                +{{ engine.activeLinkBudget().txAntennaGainDbi }} dBi
              </div>
            </div>

            <!-- 3. Satellite Feed Losses -->
            <div class="pt-2 flex items-center justify-between hover:bg-slate-800/30 px-2 py-1.5 rounded">
              <div class="flex items-center gap-2">
                <span class="text-rose-400 font-bold">-</span>
                <span class="text-slate-200">Satellite Feed & Filter Losses (L_feed)</span>
              </div>
              <div class="text-rose-400 font-semibold text-right">
                -{{ engine.activeLinkBudget().txFeedLossDb }} dB
              </div>
            </div>

            <!-- Intermediate: EIRP -->
            <div class="pt-2 flex items-center justify-between bg-cyan-950/20 border border-cyan-900/30 px-2.5 py-2 rounded my-1">
              <div class="flex items-center gap-2 font-bold text-cyan-300">
                <span>=</span>
                <span>Equivalent Isotropically Radiated Power (EIRP)</span>
              </div>
              <div class="text-cyan-200 font-bold text-sm text-right">
                {{ engine.activeLinkBudget().eirpDbm }} dBm
              </div>
            </div>

            <!-- 4. Free Space Path Loss -->
            <div class="pt-2 flex items-center justify-between hover:bg-slate-800/30 px-2 py-1.5 rounded">
              <div class="flex items-center gap-2">
                <span class="text-rose-400 font-bold">-</span>
                <span class="text-slate-200">Free-Space Path Loss (FSPL)</span>
                <span class="text-[10px] text-slate-500">20 log₁₀(4πR/λ)</span>
              </div>
              <div class="text-rose-400 font-semibold text-right">
                -{{ engine.activeLinkBudget().freeSpacePathLossDb }} dB
              </div>
            </div>

            <!-- 5. Ionospheric Absorption -->
            <div class="pt-2 flex items-center justify-between hover:bg-slate-800/30 px-2 py-1.5 rounded">
              <div class="flex items-center gap-2">
                <span class="text-rose-400 font-bold">-</span>
                <span class="text-slate-200">Ionospheric D-Region Absorption</span>
                <span class="text-[10px] text-slate-500">(TEC: {{ engine.activeChannel().tecTotalElectronContentU }} TECU)</span>
              </div>
              <div class="text-rose-400 font-semibold text-right">
                -{{ engine.activeLinkBudget().ionosphericLossDb }} dB
              </div>
            </div>

            <!-- 6. Polarisation & Faraday Rotation Loss -->
            <div class="pt-2 flex items-center justify-between hover:bg-slate-800/30 px-2 py-1.5 rounded">
              <div class="flex items-center gap-2">
                <span class="text-rose-400 font-bold">-</span>
                <span class="text-slate-200">Faraday Polarisation Mismatch Loss</span>
              </div>
              <div class="text-rose-400 font-semibold text-right">
                -{{ engine.activeLinkBudget().polarisationLossDb }} dB
              </div>
            </div>

            <!-- 7. Atmospheric Absorption & Pointing Loss -->
            <div class="pt-2 flex items-center justify-between hover:bg-slate-800/30 px-2 py-1.5 rounded">
              <div class="flex items-center gap-2">
                <span class="text-rose-400 font-bold">-</span>
                <span class="text-slate-200">Atmospheric & Mispointing Loss</span>
              </div>
              <div class="text-rose-400 font-semibold text-right">
                -{{ (engine.activeLinkBudget().atmosphericLossDb + engine.activeLinkBudget().pointingLossDb) | number:'1.2-2' }} dB
              </div>
            </div>

            <!-- 8. Ground Station Antenna Gain -->
            <div class="pt-2 flex items-center justify-between hover:bg-slate-800/30 px-2 py-1.5 rounded">
              <div class="flex items-center gap-2">
                <span class="text-cyan-400 font-bold">+</span>
                <span class="text-slate-200">Ground Station Antenna Gain (G_rx)</span>
              </div>
              <div class="text-cyan-300 font-semibold text-right">
                +{{ engine.activeLinkBudget().rxAntennaGainDbi }} dBi
              </div>
            </div>

            <!-- 9. Ground Feed & Cable Loss -->
            <div class="pt-2 flex items-center justify-between hover:bg-slate-800/30 px-2 py-1.5 rounded">
              <div class="flex items-center gap-2">
                <span class="text-rose-400 font-bold">-</span>
                <span class="text-slate-200">Ground Transmission Line / Cable Loss</span>
              </div>
              <div class="text-rose-400 font-semibold text-right">
                -{{ engine.activeLinkBudget().rxFeedLossDb }} dB
              </div>
            </div>

            <!-- Final Received Power Result -->
            <div class="pt-2 flex items-center justify-between bg-emerald-950/20 border border-emerald-900/40 px-2.5 py-2.5 rounded my-1">
              <div class="flex items-center gap-2 font-bold text-emerald-400">
                <span>=</span>
                <span>TOTAL RECEIVED RF POWER (P_rx)</span>
              </div>
              <div class="text-emerald-300 font-bold text-base text-right">
                @if (unitMode() === 'DBM') {
                  <span>{{ engine.activeLinkBudget().rxPowerDbm }} dBm</span>
                } @else if (unitMode() === 'DBW') {
                  <span>{{ engine.activeLinkBudget().rxPowerDbw }} dBW</span>
                } @else {
                  <span>{{ engine.activeLinkBudget().rxPowerWatts.toExponential(3) }} W</span>
                }
              </div>
            </div>

          </div>

          <!-- Noise & SNR Derivation Section -->
          <div class="pt-4 border-t border-slate-800 space-y-2">
            <div class="text-slate-300 font-bold uppercase text-xs">Noise Floor & Signal-to-Noise Analysis</div>
            
            <div class="grid grid-cols-1 sm:grid-cols-2 gap-3 text-[11px] pt-1">
              <div class="p-3 bg-[#070b14] border border-slate-800/80 rounded-lg space-y-1">
                <div class="text-slate-400">System Noise Temperature (T_sys):</div>
                <div class="text-sm font-bold text-slate-100">{{ engine.activeLinkBudget().systemNoiseTempK }} K</div>
                <div class="text-[10px] text-slate-500">Antenna: {{ engine.activeLinkBudget().antennaNoiseTempK }} K | LNA NF: {{ engine.activeLinkBudget().receiverNoiseFigureDb }} dB</div>
              </div>

              <div class="p-3 bg-[#070b14] border border-slate-800/80 rounded-lg space-y-1">
                <div class="text-slate-400">Thermal Noise Power (N = kTB):</div>
                <div class="text-sm font-bold text-rose-400">{{ engine.activeLinkBudget().thermalNoisePowerDbm }} dBm</div>
                <div class="text-[10px] text-slate-500">B = {{ engine.activeLinkBudget().noiseBandwidthHz }} Hz ({{ engine.activeLinkBudget().noiseBandwidthHz / 1000 }} kHz)</div>
              </div>

              <div class="p-3 bg-[#070b14] border border-slate-800/80 rounded-lg space-y-1">
                <div class="text-slate-400">Carrier-to-Noise Ratio (C/N):</div>
                <div class="text-sm font-bold text-cyan-300">{{ engine.activeLinkBudget().carrierToNoiseRatioDb }} dB</div>
                <div class="text-[10px] text-slate-500">C/N₀: {{ engine.activeLinkBudget().carrierToNoiseDensityDbHz }} dB-Hz</div>
              </div>

              <div class="p-3 bg-[#070b14] border border-slate-800/80 rounded-lg space-y-1">
                <div class="text-slate-400">Energy Per Bit / Noise (Eb/N0):</div>
                <div class="text-sm font-bold text-emerald-400">{{ engine.activeLinkBudget().energyPerBitToNoiseDensityDb }} dB</div>
                <div class="text-[10px] text-slate-500">Req: {{ engine.activeLinkBudget().requiredEbN0Db }} dB | Margin: +{{ engine.activeLinkBudget().linkMarginDb }} dB</div>
              </div>
            </div>
          </div>

        </div>

        <!-- Right 4 cols: Parameter Tuning & Capacity Panel -->
        <div class="lg:col-span-4 space-y-6">
          
          <!-- Shannon Capacity Card -->
          <div class="bg-[#0f172a] border border-slate-800 rounded-xl p-4 space-y-3 font-mono">
            <div class="flex items-center justify-between border-b border-slate-800 pb-2">
              <h4 class="text-xs font-bold uppercase text-slate-300">Shannon Channel Capacity</h4>
              <mat-icon class="text-xs text-cyan-400">speed</mat-icon>
            </div>
            
            <div class="p-3 bg-[#070b14] border border-slate-800/80 rounded-lg space-y-1.5">
              <div class="text-[10px] text-slate-400">Theoretical Limit: C = B · log₂(1 + S/N)</div>
              <div class="text-xl font-bold text-cyan-300">
                {{ engine.activeLinkBudget().channelCapacityBps | number:'1.0-0' }}
                <span class="text-xs font-normal text-slate-400">bps</span>
              </div>
              <div class="text-[11px] text-slate-300">
                Operating Bit Rate: <span class="text-slate-100 font-bold">{{ engine.activeLinkBudget().rawBitRateBps }} bps</span>
              </div>
              <div class="text-[11px] text-slate-300">
                Information Throughput: <span class="text-emerald-400 font-bold">{{ engine.activeLinkBudget().informationBitRateBps }} bps</span>
              </div>
            </div>
          </div>

          <!-- Interactive Parameter Tuner -->
          <div class="bg-[#0f172a] border border-slate-800 rounded-xl p-4 space-y-4 font-mono text-xs">
            <h4 class="text-xs font-bold uppercase text-slate-300 border-b border-slate-800 pb-2">
              Interactive Transmitter Control
            </h4>

            <!-- TX Power Slider -->
            <div class="space-y-1.5">
              <div class="flex items-center justify-between text-[11px]">
                <span class="text-slate-400">TX Power (Watts)</span>
                <span class="text-cyan-300 font-bold">{{ engine.activeSatellite().transmitter.outputPowerWatts }} W</span>
              </div>
              <input
                type="range"
                min="10"
                max="1000"
                step="10"
                [value]="engine.activeSatellite().transmitter.outputPowerWatts"
                (input)="onTxPowerInput($event)"
                class="w-full cursor-pointer">
            </div>

            <!-- Modulation Selector -->
            <div class="space-y-1.5">
              <div class="text-[11px] text-slate-400">Digital Modulation</div>
              <select
                [value]="engine.activeSatellite().transmitter.modulation"
                (change)="onModulationChange($event)"
                class="w-full bg-slate-900 border border-slate-700 text-slate-200 text-xs rounded-lg px-2.5 py-1.5 font-mono focus:border-cyan-500 focus:outline-none cursor-pointer">
                <option value="BPSK">BPSK (1 bit/sym - High Robustness)</option>
                <option value="QPSK">QPSK (2 bits/sym - Standard)</option>
                <option value="8PSK">8PSK (3 bits/sym - High Spectral Efficiency)</option>
                <option value="2FSK">2-FSK (Continuous Phase)</option>
                <option value="4FSK">4-FSK (Multi-tone)</option>
                <option value="GMSK">GMSK (BT=0.3 Gaussian MSK)</option>
                <option value="OFDM">OFDM (16-subcarrier LF Multi-carrier)</option>
              </select>
            </div>

            <!-- FEC Scheme Selector -->
            <div class="space-y-1.5">
              <div class="text-[11px] text-slate-400">Forward Error Correction (FEC)</div>
              <select
                [value]="engine.activeSatellite().transmitter.fecScheme"
                (change)="onFecChange($event)"
                class="w-full bg-slate-900 border border-slate-700 text-slate-200 text-xs rounded-lg px-2.5 py-1.5 font-mono focus:border-cyan-500 focus:outline-none cursor-pointer">
                <option value="NONE">None (Uncoded Raw Channel)</option>
                <option value="CONV_K7_R1_2">Convolutional (K=7, Rate 1/2 Viterbi)</option>
                <option value="REED_SOLOMON_255_223">Reed-Solomon RS(255, 223)</option>
                <option value="LDPC_R1_2">LDPC (Rate 1/2)</option>
                <option value="TURBO_R1_3">Turbo Code (Rate 1/3)</option>
              </select>
            </div>

            <!-- Bandwidth Slider -->
            <div class="space-y-1.5">
              <div class="flex items-center justify-between text-[11px]">
                <span class="text-slate-400">Channel Bandwidth (Hz)</span>
                <span class="text-cyan-300 font-bold">{{ engine.activeSatellite().transmitter.channelBandwidthHz }} Hz</span>
              </div>
              <input
                type="range"
                min="500"
                max="10000"
                step="500"
                [value]="engine.activeSatellite().transmitter.channelBandwidthHz"
                (input)="onBwInput($event)"
                class="w-full cursor-pointer">
            </div>

          </div>

        </div>

      </div>

    </div>
  `
})
export class RfLinkComponent {
  public engine = inject(SimulationEngine);
  public unitMode = signal<'DBM' | 'DBW' | 'WATTS'>('DBM');

  public onTxPowerInput(event: Event): void {
    const input = event.target as HTMLInputElement;
    if (input) {
      this.engine.updateTransmitterSettings({ outputPowerWatts: Number(input.value) });
    }
  }

  public onModulationChange(event: Event): void {
    const select = event.target as HTMLSelectElement;
    if (select) {
      this.engine.updateTransmitterSettings({ modulation: select.value as TransmitterSpec['modulation'] });
    }
  }

  public onFecChange(event: Event): void {
    const select = event.target as HTMLSelectElement;
    if (select) {
      this.engine.updateTransmitterSettings({ fecScheme: select.value as TransmitterSpec['fecScheme'] });
    }
  }

  public onBwInput(event: Event): void {
    const input = event.target as HTMLInputElement;
    if (input) {
      this.engine.updateTransmitterSettings({ channelBandwidthHz: Number(input.value) });
    }
  }
}
