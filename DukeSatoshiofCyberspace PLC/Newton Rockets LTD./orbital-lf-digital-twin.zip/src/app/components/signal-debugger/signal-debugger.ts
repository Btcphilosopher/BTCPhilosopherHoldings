import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { SimulationEngine } from '../../services/simulation-engine';
import { ChainDebugStage } from '../../models/signal.model';

@Component({
  selector: 'app-signal-debugger',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, MatIconModule],
  template: `
    <div class="space-y-6">
      
      <!-- Section Header -->
      <div class="bg-[#0f172a] border border-slate-800 rounded-xl p-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 font-mono">
        <div>
          <h3 class="text-sm font-bold tracking-wider text-slate-100 uppercase flex items-center gap-2">
            <mat-icon class="text-cyan-400 text-lg">bug_report</mat-icon>
            Signal Chain Multi-Stage Diagnostics & Intermediate Data Inspector
          </h3>
          <p class="text-xs text-slate-400 mt-0.5">
            Probe intermediate signals from spacecraft baseband to receiver deframer
          </p>
        </div>

        <div class="flex items-center gap-2 text-xs">
          <span class="text-slate-400">Target:</span>
          <span class="text-cyan-300 font-bold">{{ engine.activeSatellite().name }}</span>
          <span class="text-slate-600">→</span>
          <span class="text-indigo-300 font-bold">{{ engine.activeGroundStation().name }}</span>
        </div>
      </div>

      <!-- Stage Selector & Pipeline Overview Grid -->
      <div class="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        <!-- Left 5 cols: 13-Stage Linear Pipeline List -->
        <div class="lg:col-span-5 bg-[#0f172a] border border-slate-800 rounded-xl p-4 space-y-2 font-mono text-xs">
          <div class="flex items-center justify-between border-b border-slate-800 pb-2 text-[11px] text-slate-400 font-semibold">
            <span>COMMUNICATIONS PIPELINE</span>
            <span>13 NODES</span>
          </div>

          <div class="space-y-1.5 max-h-[560px] overflow-y-auto pr-1">
            @for (stage of engine.debugChainStages(); track stage.id) {
              <button
                (click)="selectedStageId.set(stage.id)"
                class="w-full text-left p-2.5 rounded-lg border transition-all cursor-pointer flex items-center justify-between"
                [class.bg-cyan-950]="selectedStageId() === stage.id"
                [class.border-cyan-600]="selectedStageId() === stage.id"
                [class.text-cyan-200]="selectedStageId() === stage.id"
                [class.bg-[#070b14]]="selectedStageId() !== stage.id"
                [class.border-slate-800]="selectedStageId() !== stage.id"
                [class.text-slate-300]="selectedStageId() !== stage.id"
                [class.hover:border-slate-700]="selectedStageId() !== stage.id">
                
                <div class="flex items-center gap-2.5">
                  <span class="w-5 h-5 rounded flex items-center justify-center text-[10px] font-bold"
                        [class.bg-cyan-900]="selectedStageId() === stage.id"
                        [class.text-cyan-300]="selectedStageId() === stage.id"
                        [class.bg-slate-800]="selectedStageId() !== stage.id"
                        [class.text-slate-400]="selectedStageId() !== stage.id">
                    {{ stage.id }}
                  </span>
                  <div>
                    <div class="font-bold text-[11px]">{{ stage.name }}</div>
                    <div class="text-[10px] text-slate-500">{{ stage.domain }}</div>
                  </div>
                </div>

                <!-- Status Dot -->
                <div class="flex items-center gap-1.5 text-[10px] font-semibold"
                     [class.text-emerald-400]="stage.status === 'NOMINAL'"
                     [class.text-amber-400]="stage.status === 'WARNING'"
                     [class.text-slate-500]="stage.status === 'BYPASSED'"
                     [class.text-rose-400]="stage.status === 'ERROR'">
                  <span>● {{ stage.status }}</span>
                </div>
              </button>
            }
          </div>
        </div>

        <!-- Right 7 cols: Deep Drill-Down on Selected Stage -->
        <div class="lg:col-span-7 bg-[#0f172a] border border-slate-800 rounded-xl p-5 space-y-4 font-mono text-xs">
          
          @if (getActiveStage(); as stage) {
            <div class="space-y-4">
              
              <!-- Stage Title & Domain Banner -->
              <div class="flex items-center justify-between border-b border-slate-800 pb-3">
                <div>
                  <span class="text-[10px] uppercase tracking-wider text-slate-500">STAGE #{{ stage.id }} · {{ stage.domain }}</span>
                  <h4 class="text-base font-bold text-slate-100">{{ stage.name }}</h4>
                </div>
                <span class="px-2.5 py-1 rounded text-xs font-bold"
                      [class.bg-emerald-950]="stage.status === 'NOMINAL'"
                      [class.text-emerald-400]="stage.status === 'NOMINAL'"
                      [class.border]="stage.status === 'NOMINAL'"
                      [class.border-emerald-800]="stage.status === 'NOMINAL'">
                  {{ stage.status }}
                </span>
              </div>

              <!-- Description -->
              <div class="p-3 bg-[#070b14] border border-slate-800/80 rounded-lg text-slate-300 text-xs">
                <span class="text-slate-500 font-bold block mb-0.5">FUNCTIONAL DESCRIPTION:</span>
                {{ stage.description }}
              </div>

              <!-- Input Data Stream Block -->
              <div class="p-3 bg-[#070b14] border border-slate-800/80 rounded-lg space-y-1">
                <div class="text-slate-500 font-bold text-[10px] uppercase">INPUT SIGNAL / STREAM:</div>
                <div class="p-2 bg-black/40 rounded text-cyan-300 text-[11px] font-mono break-all">
                  {{ stage.inputData }}
                </div>
              </div>

              <!-- Output Data Stream Block -->
              <div class="p-3 bg-[#070b14] border border-slate-800/80 rounded-lg space-y-1">
                <div class="text-slate-500 font-bold text-[10px] uppercase">TRANSFORMED OUTPUT STREAM:</div>
                <div class="p-2 bg-black/40 rounded text-emerald-300 text-[11px] font-mono break-all">
                  {{ stage.outputData }}
                </div>
              </div>

              <!-- Stage Specific Metrics -->
              <div class="p-3 bg-[#070b14] border border-slate-800/80 rounded-lg space-y-2">
                <div class="text-slate-500 font-bold text-[10px] uppercase">STAGE PERFORMANCE METRICS:</div>
                <div class="grid grid-cols-2 sm:grid-cols-3 gap-3">
                  @for (entry of getMetricEntries(stage.metrics); track entry.key) {
                    <div class="space-y-0.5">
                      <div class="text-[10px] text-slate-400">{{ entry.key }}</div>
                      <div class="text-xs font-bold text-slate-100">{{ entry.value }}</div>
                    </div>
                  }
                </div>
              </div>

            </div>
          }

        </div>

      </div>

    </div>
  `
})
export class SignalDebuggerComponent {
  public engine = inject(SimulationEngine);
  public selectedStageId = signal<number>(1);

  public getActiveStage(): ChainDebugStage | undefined {
    return this.engine.debugChainStages().find(s => s.id === this.selectedStageId());
  }

  public getMetricEntries(metrics: Record<string, string | number>): { key: string; value: string | number }[] {
    return Object.entries(metrics).map(([key, value]) => ({ key, value }));
  }
}
