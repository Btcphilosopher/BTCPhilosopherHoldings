import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { SimulationEngine } from '../../services/simulation-engine';

@Component({
  selector: 'app-propagation',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, MatIconModule],
  template: `
    <div class="space-y-6">
      
      <!-- Section Header -->
      <div class="bg-[#0f172a] border border-slate-800 rounded-xl p-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 font-mono">
        <div>
          <h3 class="text-sm font-bold tracking-wider text-slate-100 uppercase flex items-center gap-2">
            <mat-icon class="text-cyan-400 text-lg">public</mat-icon>
            Low-Frequency Ionospheric & Atmospheric Physics Model
          </h3>
          <p class="text-xs text-slate-400 mt-0.5">
            D-region absorption, Earth-ionosphere waveguide, electron density & diurnal variation
          </p>
        </div>

        <div class="flex items-center gap-2 text-xs">
          <span class="text-slate-400">Mode:</span>
          <span class="px-2.5 py-1 rounded bg-cyan-950 border border-cyan-800 text-cyan-300 font-bold">
            {{ engine.propagationMode() }}
          </span>
        </div>
      </div>

      <!-- Live Ionospheric Parameters & Solar Flux Dashboard -->
      <div class="grid grid-cols-2 sm:grid-cols-4 gap-4 font-mono text-xs">
        
        <div class="bg-[#0f172a] border border-slate-800 rounded-xl p-4 space-y-1">
          <div class="text-[10px] text-slate-400 uppercase">Total Electron Content (TEC)</div>
          <div class="text-2xl font-bold text-cyan-300">
            {{ engine.activeChannel().tecTotalElectronContentU }}
            <span class="text-xs font-normal text-slate-500">TECU</span>
          </div>
          <div class="text-[10px] text-slate-500">1 TECU = 10¹⁶ e⁻/m²</div>
        </div>

        <div class="bg-[#0f172a] border border-slate-800 rounded-xl p-4 space-y-1">
          <div class="text-[10px] text-slate-400 uppercase">D-Region Absorption</div>
          <div class="text-2xl font-bold text-rose-400">
            {{ engine.activeChannel().ionosphericAbsorptionDb }}
            <span class="text-xs font-normal text-slate-500">dB</span>
          </div>
          <div class="text-[10px] text-slate-500">Collision Freq ν = 10⁶ s⁻¹</div>
        </div>

        <div class="bg-[#0f172a] border border-slate-800 rounded-xl p-4 space-y-1">
          <div class="text-[10px] text-slate-400 uppercase">Faraday Rotation</div>
          <div class="text-2xl font-bold text-slate-200">
            {{ engine.activeChannel().faradayRotationDeg }}°
          </div>
          <div class="text-[10px] text-slate-500">Polarisation Loss: {{ engine.activeChannel().polarisationLossDb }} dB</div>
        </div>

        <div class="bg-[#0f172a] border border-slate-800 rounded-xl p-4 space-y-1">
          <div class="text-[10px] text-slate-400 uppercase">Group Delay (Dispersion)</div>
          <div class="text-2xl font-bold text-amber-300">
            {{ engine.activeChannel().ionosphericGroupDelayMicrosec }}
            <span class="text-xs font-normal text-slate-500">μs</span>
          </div>
          <div class="text-[10px] text-slate-500">Phase Shift: {{ engine.activeChannel().ionosphericPhaseShiftDeg }}°</div>
        </div>

      </div>

      <!-- Space Weather Sliders & Layer Stratification -->
      <div class="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        <!-- Left 6 cols: Space Weather Controls -->
        <div class="lg:col-span-6 bg-[#0f172a] border border-slate-800 rounded-xl p-5 space-y-4 font-mono text-xs">
          <h4 class="text-xs font-bold uppercase text-slate-300 border-b border-slate-800 pb-2">
            Space Weather & Environmental Inputs
          </h4>

          <!-- Solar Flux F10.7 Slider -->
          <div class="space-y-1.5">
            <div class="flex items-center justify-between text-[11px]">
              <span class="text-slate-400">Solar 10.7 cm Radio Flux (SFU)</span>
              <span class="text-cyan-300 font-bold">{{ engine.solarActivitySfu() }} SFU</span>
            </div>
            <input
              type="range"
              min="65"
              max="300"
              step="5"
              [value]="engine.solarActivitySfu()"
              (input)="onSfuInput($event)"
              class="w-full cursor-pointer">
            <div class="text-[10px] text-slate-500 flex justify-between">
              <span>Quiet (70 SFU)</span>
              <span>Moderate (150 SFU)</span>
              <span>Severe Flare (300 SFU)</span>
            </div>
          </div>

          <!-- Sunspot Number Slider -->
          <div class="space-y-1.5">
            <div class="flex items-center justify-between text-[11px]">
              <span class="text-slate-400">International Sunspot Number (SSN)</span>
              <span class="text-cyan-300 font-bold">{{ engine.sunspotNumber() }}</span>
            </div>
            <input
              type="range"
              min="0"
              max="250"
              step="5"
              [value]="engine.sunspotNumber()"
              (input)="onSsnInput($event)"
              class="w-full cursor-pointer">
          </div>

          <!-- Man-Made Noise Excess Slider -->
          <div class="space-y-1.5">
            <div class="flex items-center justify-between text-[11px]">
              <span class="text-slate-400">Man-Made Noise Excess above ITU-R P.372 (dB)</span>
              <span class="text-rose-400 font-bold">+{{ engine.manMadeNoiseExcessDb() }} dB</span>
            </div>
            <input
              type="range"
              min="0"
              max="30"
              step="1"
              [value]="engine.manMadeNoiseExcessDb()"
              (input)="onNoiseInput($event)"
              class="w-full cursor-pointer">
          </div>
        </div>

        <!-- Right 6 cols: Atmospheric Layer Stratification Table -->
        <div class="lg:col-span-6 bg-[#0f172a] border border-slate-800 rounded-xl p-5 space-y-3 font-mono text-xs">
          <h4 class="text-xs font-bold uppercase text-slate-300 border-b border-slate-800 pb-2">
            Ionospheric Layer Stratification (60 km - 1000 km)
          </h4>

          <div class="space-y-2">
            <!-- D Layer -->
            <div class="p-2.5 bg-[#070b14] border border-slate-800/80 rounded-lg flex items-center justify-between">
              <div>
                <span class="font-bold text-rose-400">D LAYER (60 - 90 km)</span>
                <p class="text-[10px] text-slate-400">Primary low-frequency collisional absorption zone (Day only)</p>
              </div>
              <span class="text-slate-200 font-semibold text-right">Ne: 10³ - 10⁴ cm⁻³</span>
            </div>

            <!-- E Layer -->
            <div class="p-2.5 bg-[#070b14] border border-slate-800/80 rounded-lg flex items-center justify-between">
              <div>
                <span class="font-bold text-amber-400">E LAYER (90 - 150 km)</span>
                <p class="text-[10px] text-slate-400">Nighttime conductive upper waveguide boundary</p>
              </div>
              <span class="text-slate-200 font-semibold text-right">Ne: 10⁵ cm⁻³</span>
            </div>

            <!-- F Layer -->
            <div class="p-2.5 bg-[#070b14] border border-slate-800/80 rounded-lg flex items-center justify-between">
              <div>
                <span class="font-bold text-cyan-400">F LAYER (150 - 600 km)</span>
                <p class="text-[10px] text-slate-400">Peak electron density & Faraday polarization rotation</p>
              </div>
              <span class="text-slate-200 font-semibold text-right">Ne: 10⁶ cm⁻³</span>
            </div>
          </div>
        </div>

      </div>

    </div>
  `
})
export class PropagationComponent {
  public engine = inject(SimulationEngine);

  public onSfuInput(event: Event): void {
    const input = event.target as HTMLInputElement;
    if (input) {
      this.engine.solarActivitySfu.set(Number(input.value));
    }
  }

  public onSsnInput(event: Event): void {
    const input = event.target as HTMLInputElement;
    if (input) {
      this.engine.sunspotNumber.set(Number(input.value));
    }
  }

  public onNoiseInput(event: Event): void {
    const input = event.target as HTMLInputElement;
    if (input) {
      this.engine.manMadeNoiseExcessDb.set(Number(input.value));
    }
  }
}
