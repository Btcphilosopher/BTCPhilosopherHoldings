import { ChangeDetectionStrategy, Component, ElementRef, OnDestroy, OnInit, ViewChild, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { SimulationEngine } from '../../services/simulation-engine';

@Component({
  selector: 'app-constellation-iq',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, MatIconModule],
  template: `
    <div class="space-y-6">
      
      <!-- Section Header -->
      <div class="bg-[#0f172a] border border-slate-800 rounded-xl p-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 font-mono">
        <div>
          <h3 class="text-sm font-bold tracking-wider text-slate-100 uppercase flex items-center gap-2">
            <mat-icon class="text-cyan-400 text-lg">grain</mat-icon>
            Complex Baseband I/Q Constellation & Vector Signal Analyzer
          </h3>
          <p class="text-xs text-slate-400 mt-0.5">
            Phase trajectory, Error Vector Magnitude (EVM), and real-time quadrature waveforms
          </p>
        </div>

        <div class="flex items-center gap-3 text-xs">
          <span class="text-slate-400">Modulation:</span>
          <span class="px-2.5 py-1 rounded bg-cyan-950 border border-cyan-800 text-cyan-300 font-bold">
            {{ engine.activeSatellite().transmitter.modulation }}
          </span>
          <span class="text-slate-400">Rate:</span>
          <span class="text-slate-200 font-bold">
            {{ engine.activeSatellite().transmitter.symbolRateBaud }} Baud
          </span>
        </div>
      </div>

      <!-- Main Stage Split: Constellation Polar Scope & Time Domain Scope -->
      <div class="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        <!-- Left 6 cols: I/Q Constellation Diagram -->
        <div class="lg:col-span-6 bg-[#0f172a] border border-slate-800 rounded-xl p-5 space-y-4">
          <div class="flex items-center justify-between border-b border-slate-800 pb-2 text-xs font-mono">
            <span class="text-slate-300 font-bold uppercase">Quadrature Constellation (I vs Q)</span>
            <span class="text-cyan-400">128 SYMBOLS PERSISTENCE</span>
          </div>

          <div class="relative w-full aspect-square max-h-[380px] mx-auto bg-[#070b14] border border-slate-800/80 rounded-xl overflow-hidden">
            <canvas #constellationCanvas class="w-full h-full block"></canvas>
          </div>

          <!-- EVM Metrics Grid -->
          <div class="grid grid-cols-3 sm:grid-cols-5 gap-2 text-xs font-mono pt-1">
            <div class="p-2.5 bg-[#070b14] border border-slate-800/80 rounded-lg space-y-0.5">
              <div class="text-[10px] text-slate-400 uppercase">EVM RMS</div>
              <div class="text-sm font-bold text-cyan-300">{{ engine.evmMetrics().evmRmsPercent }}%</div>
            </div>

            <div class="p-2.5 bg-[#070b14] border border-slate-800/80 rounded-lg space-y-0.5">
              <div class="text-[10px] text-slate-400 uppercase">EVM Peak</div>
              <div class="text-sm font-bold text-amber-300">{{ engine.evmMetrics().evmPeakPercent }}%</div>
            </div>

            <div class="p-2.5 bg-[#070b14] border border-slate-800/80 rounded-lg space-y-0.5">
              <div class="text-[10px] text-slate-400 uppercase">Phase Jitter</div>
              <div class="text-sm font-bold text-slate-200">{{ engine.evmMetrics().phaseErrorDeg }}°</div>
            </div>

            <div class="p-2.5 bg-[#070b14] border border-slate-800/80 rounded-lg space-y-0.5">
              <div class="text-[10px] text-slate-400 uppercase">Freq Offset</div>
              <div class="text-sm font-bold text-slate-200">{{ engine.evmMetrics().frequencyOffsetHz }} Hz</div>
            </div>

            <div class="p-2.5 bg-[#070b14] border border-slate-800/80 rounded-lg space-y-0.5 col-span-2 sm:col-span-1">
              <div class="text-[10px] text-slate-400 uppercase">Demod SNR</div>
              <div class="text-sm font-bold text-emerald-400">{{ engine.evmMetrics().snrDb }} dB</div>
            </div>
          </div>
        </div>

        <!-- Right 6 cols: Time-Domain In-Phase / Quadrature Oscilloscope -->
        <div class="lg:col-span-6 bg-[#0f172a] border border-slate-800 rounded-xl p-5 space-y-4">
          <div class="flex items-center justify-between border-b border-slate-800 pb-2 text-xs font-mono">
            <span class="text-slate-300 font-bold uppercase">Time-Domain Baseband Signals</span>
            <div class="flex items-center gap-3 text-[11px]">
              <span class="text-cyan-400 font-semibold">— In-Phase I(t)</span>
              <span class="text-pink-400 font-semibold">— Quadrature Q(t)</span>
            </div>
          </div>

          <div class="relative w-full h-[280px] bg-[#070b14] border border-slate-800/80 rounded-xl overflow-hidden">
            <canvas #timeCanvas class="w-full h-full block"></canvas>
          </div>

          <!-- DSP Demodulator State Cards -->
          <div class="space-y-2 text-xs font-mono">
            <div class="p-3 bg-[#070b14] border border-slate-800/80 rounded-lg flex items-center justify-between">
              <div>
                <span class="text-slate-400">Carrier Recovery PLL:</span>
                <span class="text-slate-200 font-semibold ml-2">Costas Loop (2nd Order, BW=15 Hz)</span>
              </div>
              <span class="text-emerald-400 font-bold">● LOCKED</span>
            </div>

            <div class="p-3 bg-[#070b14] border border-slate-800/80 rounded-lg flex items-center justify-between">
              <div>
                <span class="text-slate-400">Symbol Timing Sync:</span>
                <span class="text-slate-200 font-semibold ml-2">Gardner Timing Error Detector</span>
              </div>
              <span class="text-emerald-400 font-bold">● TRACKING</span>
            </div>

            <div class="p-3 bg-[#070b14] border border-slate-800/80 rounded-lg flex items-center justify-between">
              <div>
                <span class="text-slate-400">Pulse Shaping:</span>
                <span class="text-slate-200 font-semibold ml-2">Root Raised Cosine (α = 0.35)</span>
              </div>
              <span class="text-slate-400 font-semibold">Matched Filter</span>
            </div>
          </div>
        </div>

      </div>

    </div>
  `
})
export class ConstellationIqComponent implements OnInit, OnDestroy {
  @ViewChild('constellationCanvas', { static: true }) constCanvasRef!: ElementRef<HTMLCanvasElement>;
  @ViewChild('timeCanvas', { static: true }) timeCanvasRef!: ElementRef<HTMLCanvasElement>;

  public engine = inject(SimulationEngine);
  private animFrameId: number | null = null;

  ngOnInit(): void {
    if (typeof window !== 'undefined') {
      this.startRenderLoop();
    }
  }

  ngOnDestroy(): void {
    if (this.animFrameId !== null) {
      cancelAnimationFrame(this.animFrameId);
    }
  }

  private startRenderLoop = (): void => {
    this.drawConstellation();
    this.drawTimeDomain();
    this.animFrameId = requestAnimationFrame(this.startRenderLoop);
  };

  private drawConstellation(): void {
    const canvas = this.constCanvasRef.nativeElement;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const size = Math.min(canvas.clientWidth || 350, canvas.clientHeight || 350);
    if (canvas.width !== size || canvas.height !== size) {
      canvas.width = size;
      canvas.height = size;
    }

    const half = size / 2;
    const scale = half * 0.65; // scale factor for normalized +/-1.5 I/Q

    // Background
    ctx.fillStyle = '#070b14';
    ctx.fillRect(0, 0, size, size);

    // Crosshairs
    ctx.strokeStyle = '#1e293b';
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(0, half);
    ctx.lineTo(size, half);
    ctx.moveTo(half, 0);
    ctx.lineTo(half, size);
    ctx.stroke();

    // Concentric Unit Circles
    ctx.strokeStyle = '#1e293b';
    ctx.setLineDash([3, 3]);
    ctx.beginPath();
    ctx.arc(half, half, scale * 1.0, 0, Math.PI * 2);
    ctx.arc(half, half, scale * 0.5, 0, Math.PI * 2);
    ctx.stroke();
    ctx.setLineDash([]);

    // Axes Labels
    ctx.font = '10px JetBrains Mono, monospace';
    ctx.fillStyle = '#64748b';
    ctx.fillText('+Q', half + 6, 14);
    ctx.fillText('-Q', half + 6, size - 6);
    ctx.fillText('+I', size - 20, half - 6);
    ctx.fillText('-I', 6, half - 6);

    const points = this.engine.constellationPoints();
    if (!points.length) return;

    // Draw Ideal Reference Target Crosses
    const mod = this.engine.activeSatellite().transmitter.modulation;
    ctx.strokeStyle = '#38bdf8';
    ctx.lineWidth = 1.5;

    const drawTarget = (ix: number, qy: number) => {
      const cx = half + ix * scale;
      const cy = half - qy * scale;
      ctx.beginPath();
      ctx.moveTo(cx - 6, cy);
      ctx.lineTo(cx + 6, cy);
      ctx.moveTo(cx, cy - 6);
      ctx.lineTo(cx, cy + 6);
      ctx.stroke();
    };

    if (mod === 'BPSK') {
      drawTarget(1, 0);
      drawTarget(-1, 0);
    } else if (mod === 'QPSK' || mod === 'OFDM') {
      drawTarget(0.707, 0.707);
      drawTarget(-0.707, 0.707);
      drawTarget(-0.707, -0.707);
      drawTarget(0.707, -0.707);
    } else if (mod === '8PSK') {
      for (let k = 0; k < 8; k++) {
        const th = (k * Math.PI) / 4;
        drawTarget(Math.cos(th), Math.sin(th));
      }
    }

    // Draw Demodulated Scatter Points with Phosphor Glow
    for (let i = 0; i < points.length; i++) {
      const pt = points[i];
      const px = half + pt.i * scale;
      const py = half - pt.q * scale;

      const alpha = 0.4 + (i / points.length) * 0.6;
      ctx.fillStyle = `rgba(6, 182, 212, ${alpha})`;

      ctx.beginPath();
      ctx.arc(px, py, 2.5, 0, Math.PI * 2);
      ctx.fill();
    }
  }

  private drawTimeDomain(): void {
    const canvas = this.timeCanvasRef.nativeElement;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const width = canvas.clientWidth || 500;
    const height = canvas.clientHeight || 280;

    if (canvas.width !== width || canvas.height !== height) {
      canvas.width = width;
      canvas.height = height;
    }

    const halfH = height / 2;
    const samples = this.engine.iqSamples();
    if (!samples.length) return;

    ctx.fillStyle = '#070b14';
    ctx.fillRect(0, 0, width, height);

    // Center Baseline
    ctx.strokeStyle = '#1e293b';
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(0, halfH);
    ctx.lineTo(width, halfH);
    ctx.stroke();

    const numSamples = Math.min(128, samples.length);

    // In-Phase I(t) Trace (Cyan)
    ctx.strokeStyle = '#06b6d4';
    ctx.lineWidth = 2;
    ctx.beginPath();
    for (let i = 0; i < numSamples; i++) {
      const x = (i / (numSamples - 1)) * width;
      const y = halfH - samples[i].i * (halfH * 0.7);
      if (i === 0) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
    }
    ctx.stroke();

    // Quadrature Q(t) Trace (Pink)
    ctx.strokeStyle = '#ec4899';
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    for (let i = 0; i < numSamples; i++) {
      const x = (i / (numSamples - 1)) * width;
      const y = halfH - samples[i].q * (halfH * 0.7);
      if (i === 0) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
    }
    ctx.stroke();
  }
}
