import { ChangeDetectionStrategy, Component, ElementRef, OnDestroy, OnInit, ViewChild, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { SimulationEngine } from '../../services/simulation-engine';
import { OrbitPropagator } from '../../services/orbit-propagator';
import * as THREE from 'three';

@Component({
  selector: 'app-constellation-3d',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, MatIconModule],
  template: `
    <div class="space-y-4">
      
      <!-- Top Control Bar -->
      <div class="bg-[#0f172a] border border-slate-800 rounded-xl p-4 flex flex-wrap items-center justify-between gap-4">
        <div>
          <h3 class="text-sm font-bold tracking-wider text-slate-100 uppercase font-mono flex items-center gap-2">
            <mat-icon class="text-cyan-400 text-lg">public</mat-icon>
            3D Constellation & Orbital Footprint Visualizer
          </h3>
          <p class="text-xs text-slate-400 font-mono mt-0.5">
            Real-time orbital mechanics, RF radiation footprints & line-of-sight vectors
          </p>
        </div>

        <div class="flex items-center gap-2 flex-wrap text-xs font-mono">
          <!-- Follow Sat Toggle -->
          <button
            (click)="toggleFollowSat()"
            class="px-3 py-1.5 rounded-lg border transition-colors cursor-pointer flex items-center gap-1.5"
            [class.bg-cyan-950]="followSat()"
            [class.border-cyan-700]="followSat()"
            [class.text-cyan-300]="followSat()"
            [class.bg-slate-900]="!followSat()"
            [class.border-slate-700]="!followSat()"
            [class.text-slate-300]="!followSat()">
            <mat-icon class="text-xs scale-75">center_focus_strong</mat-icon>
            <span>{{ followSat() ? 'Tracking Sat' : 'Free Camera' }}</span>
          </button>

          <!-- Toggle Beams -->
          <button
            (click)="showBeams.set(!showBeams())"
            class="px-3 py-1.5 rounded-lg border transition-colors cursor-pointer flex items-center gap-1.5"
            [class.bg-cyan-950]="showBeams()"
            [class.border-cyan-700]="showBeams()"
            [class.text-cyan-300]="showBeams()"
            [class.bg-slate-900]="!showBeams()"
            [class.border-slate-700]="!showBeams()"
            [class.text-slate-300]="!showBeams()">
            <mat-icon class="text-xs scale-75">radar</mat-icon>
            <span>RF Footprints</span>
          </button>

          <!-- Reset Camera -->
          <button
            (click)="resetCamera()"
            class="px-3 py-1.5 rounded-lg border border-slate-700 bg-slate-900 text-slate-300 hover:text-cyan-300 hover:border-slate-600 transition-colors cursor-pointer flex items-center gap-1.5">
            <mat-icon class="text-xs scale-75">restart_alt</mat-icon>
            <span>Reset View</span>
          </button>
        </div>
      </div>

      <!-- 3D Canvas Stage Container -->
      <div class="relative w-full h-[600px] bg-[#070b14] border border-slate-800 rounded-xl overflow-hidden select-none">
        
        <!-- Canvas Element -->
        <canvas #globeCanvas class="w-full h-full cursor-grab active:cursor-grabbing block"></canvas>

        <!-- Top Left Telemetry HUD Overlay -->
        <div class="absolute top-4 left-4 bg-[#0b111e]/85 backdrop-blur-md border border-slate-800/80 rounded-lg p-3 text-xs font-mono space-y-1.5 pointer-events-none max-w-xs">
          <div class="text-[11px] text-cyan-400 font-bold border-b border-slate-800 pb-1 flex items-center justify-between">
            <span>{{ engine.activeSatellite().name }}</span>
            <span class="text-[10px] text-slate-400">{{ engine.activeSatellite().id }}</span>
          </div>
          <div class="text-slate-300 grid grid-cols-2 gap-x-3 gap-y-1 text-[11px]">
            <div>Lat: <span class="text-slate-100 font-semibold">{{ engine.activePosition().latitudeDeg | number:'1.2-2' }}°</span></div>
            <div>Lon: <span class="text-slate-100 font-semibold">{{ engine.activePosition().longitudeDeg | number:'1.2-2' }}°</span></div>
            <div>Alt: <span class="text-slate-100 font-semibold">{{ engine.activePosition().altitudeKm | number:'1.0-0' }} km</span></div>
            <div>Speed: <span class="text-slate-100 font-semibold">{{ engine.activePosition().speedKms | number:'1.2-2' }} km/s</span></div>
            <div>Period: <span class="text-slate-100 font-semibold">{{ engine.activePosition().orbitPeriodMin | number:'1.1-1' }} m</span></div>
            <div>Inc: <span class="text-slate-100 font-semibold">{{ engine.activeSatellite().orbit.inclinationDeg | number:'1.1-1' }}°</span></div>
          </div>
        </div>

        <!-- Top Right Ground Station Line of Sight HUD -->
        <div class="absolute top-4 right-4 bg-[#0b111e]/85 backdrop-blur-md border border-slate-800/80 rounded-lg p-3 text-xs font-mono space-y-1.5 pointer-events-none max-w-xs">
          <div class="text-[11px] text-indigo-300 font-bold border-b border-slate-800 pb-1 flex items-center justify-between">
            <span>{{ engine.activeGroundStation().name }}</span>
            <span [class.text-emerald-400]="engine.activeGeometry().isReceivable" [class.text-slate-500]="!engine.activeGeometry().isReceivable">
              {{ engine.activeGeometry().isReceivable ? '● IN VIEW' : '○ OCCULTED' }}
            </span>
          </div>
          <div class="text-slate-300 grid grid-cols-2 gap-x-3 gap-y-1 text-[11px]">
            <div>Slant Range: <span class="text-slate-100 font-semibold">{{ engine.activeGeometry().slantRangeKm | number:'1.0-0' }} km</span></div>
            <div>Elevation: <span class="text-slate-100 font-semibold">{{ engine.activeGeometry().elevationDeg | number:'1.1-1' }}°</span></div>
            <div>Azimuth: <span class="text-slate-100 font-semibold">{{ engine.activeGeometry().azimuthDeg | number:'1.1-1' }}°</span></div>
            <div>Doppler: <span class="text-slate-100 font-semibold">{{ engine.activeGeometry().dopplerShiftHz | number:'1.2-2' }} Hz</span></div>
          </div>
        </div>

        <!-- Bottom Controls Legend -->
        <div class="absolute bottom-4 left-4 right-4 flex items-center justify-between pointer-events-none text-[11px] font-mono text-slate-400">
          <div class="bg-[#0b111e]/80 backdrop-blur-md border border-slate-800/60 rounded px-2.5 py-1">
            <span class="text-slate-500">Rotate: Left-Click + Drag | Pan: Right-Click + Drag | Zoom: Mouse Wheel</span>
          </div>
          <div class="bg-[#0b111e]/80 backdrop-blur-md border border-slate-800/60 rounded px-2.5 py-1 flex items-center gap-3">
            <span class="flex items-center gap-1"><span class="w-2 h-2 rounded-full bg-cyan-400 inline-block"></span> Active Sat</span>
            <span class="flex items-center gap-1"><span class="w-2 h-2 rounded-full bg-indigo-400 inline-block"></span> Ground Station</span>
            <span class="flex items-center gap-1"><span class="w-2 h-2 rounded-full bg-emerald-400 inline-block"></span> LOS Vector</span>
          </div>
        </div>

      </div>

    </div>
  `
})
export class Constellation3dComponent implements OnInit, OnDestroy {
  @ViewChild('globeCanvas', { static: true }) canvasRef!: ElementRef<HTMLCanvasElement>;
  public engine = inject(SimulationEngine);
  private orbitPropagator = inject(OrbitPropagator);

  public followSat = signal<boolean>(false);
  public showBeams = signal<boolean>(true);

  private renderer!: THREE.WebGLRenderer;
  private scene!: THREE.Scene;
  private camera!: THREE.PerspectiveCamera;
  private animFrameId: number | null = null;

  // 3D Objects
  private earthMesh!: THREE.Mesh;
  private atmosphereMesh!: THREE.Mesh;
  private satMarkers = new Map<string, THREE.Group>();
  private satOrbitLines = new Map<string, THREE.Line>();
  private beamCones = new Map<string, THREE.Mesh>();
  private groundStationMarkers = new Map<string, THREE.Group>();
  private losLine!: THREE.Line;

  // Interaction
  private isDragging = false;
  private previousMousePosition = { x: 0, y: 0 };
  private cameraDistance = 2.8;
  private cameraRotation = { theta: 0.8, phi: 1.2 };

  ngOnInit(): void {
    if (typeof window !== 'undefined') {
      this.initThree();
    }
  }

  ngOnDestroy(): void {
    if (this.animFrameId !== null) {
      cancelAnimationFrame(this.animFrameId);
    }
    if (this.renderer) {
      this.renderer.dispose();
    }
  }

  public toggleFollowSat(): void {
    this.followSat.update(f => !f);
  }

  public resetCamera(): void {
    this.cameraDistance = 2.8;
    this.cameraRotation = { theta: 0.8, phi: 1.2 };
    this.followSat.set(false);
  }

  private initThree(): void {
    const canvas = this.canvasRef.nativeElement;
    const width = canvas.clientWidth || 800;
    const height = canvas.clientHeight || 600;

    // Scene
    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(0x070b14);

    // Camera
    this.camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 100);
    this.updateCameraPosition();

    // Renderer
    this.renderer = new THREE.WebGLRenderer({ canvas, antialias: true });
    this.renderer.setSize(width, height);
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));

    // Lights
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.7);
    this.scene.add(ambientLight);

    const sunLight = new THREE.DirectionalLight(0xfff5e6, 1.8);
    sunLight.position.set(5, 3, 5);
    this.scene.add(sunLight);

    // Build Earth Sphere
    this.buildEarth();

    // Build Ground Stations
    this.buildGroundStations();

    // Build Satellites & Orbits
    this.buildSatellites();

    // Build LOS Line
    const losGeo = new THREE.BufferGeometry().setFromPoints([new THREE.Vector3(), new THREE.Vector3()]);
    const losMat = new THREE.LineBasicMaterial({ color: 0x10b981, linewidth: 2, transparent: true, opacity: 0.85 });
    this.losLine = new THREE.Line(losGeo, losMat);
    this.scene.add(this.losLine);

    // Mouse Listeners
    this.setupInteraction(canvas);

    // Render loop
    this.animate();
  }

  private buildEarth(): void {
    const radius = 1.0;
    const earthGeo = new THREE.SphereGeometry(radius, 48, 48);

    const earthMat = new THREE.MeshStandardMaterial({
      color: 0x0c1e38,
      roughness: 0.7,
      metalness: 0.1,
      wireframe: false
    });

    this.earthMesh = new THREE.Mesh(earthGeo, earthMat);
    this.scene.add(this.earthMesh);

    // Latitude & Longitude Coordinate Lines
    const gridGeo = new THREE.WireframeGeometry(new THREE.SphereGeometry(radius * 1.002, 24, 16));
    const gridMat = new THREE.LineBasicMaterial({ color: 0x1e3a5f, transparent: true, opacity: 0.35 });
    const gridMesh = new THREE.LineSegments(gridGeo, gridMat);
    this.earthMesh.add(gridMesh);

    // Atmosphere Glow Layer
    const atmosGeo = new THREE.SphereGeometry(radius * 1.03, 32, 32);
    const atmosMat = new THREE.MeshBasicMaterial({
      color: 0x38bdf8,
      transparent: true,
      opacity: 0.12,
      side: THREE.BackSide
    });
    this.atmosphereMesh = new THREE.Mesh(atmosGeo, atmosMat);
    this.scene.add(this.atmosphereMesh);
  }

  private buildGroundStations(): void {
    const stations = this.engine.groundStations();
    stations.forEach(gs => {
      const group = new THREE.Group();

      const dotGeo = new THREE.SphereGeometry(0.015, 12, 12);
      const dotMat = new THREE.MeshBasicMaterial({ color: 0x6366f1 });
      const dotMesh = new THREE.Mesh(dotGeo, dotMat);
      group.add(dotMesh);

      const ringGeo = new THREE.RingGeometry(0.03, 0.035, 24);
      const ringMat = new THREE.MeshBasicMaterial({ color: 0x818cf8, side: THREE.DoubleSide, transparent: true, opacity: 0.4 });
      const ringMesh = new THREE.Mesh(ringGeo, ringMat);
      ringMesh.rotation.x = Math.PI / 2;
      group.add(ringMesh);

      const pos = this.latLonToVector3(gs.latitudeDeg, gs.longitudeDeg, 1.005);
      group.position.copy(pos);
      group.lookAt(0, 0, 0);

      this.scene.add(group);
      this.groundStationMarkers.set(gs.id, group);
    });
  }

  private buildSatellites(): void {
    const sats = this.engine.satellites();
    sats.forEach(sat => {
      const orbitPoints: THREE.Vector3[] = [];
      const numPoints = 120;
      const periodSec = 6000;
      const t0 = this.engine.simulationEpochMs();

      for (let i = 0; i <= numPoints; i++) {
        const t = t0 + (i / numPoints) * periodSec * 1000;
        const pos = this.orbitPropagator.propagate(sat.orbit, t);
        const v = this.ecefKmToVector3(pos.xKm, pos.yKm, pos.zKm);
        orbitPoints.push(v);
      }

      const orbitGeo = new THREE.BufferGeometry().setFromPoints(orbitPoints);
      const orbitMat = new THREE.LineBasicMaterial({
        color: sat.id === 'SAT-01' ? 0x06b6d4 : 0x475569,
        transparent: true,
        opacity: sat.id === 'SAT-01' ? 0.8 : 0.4,
        linewidth: 1
      });
      const orbitLine = new THREE.Line(orbitGeo, orbitMat);
      this.scene.add(orbitLine);
      this.satOrbitLines.set(sat.id, orbitLine);

      const satGroup = new THREE.Group();

      const busGeo = new THREE.BoxGeometry(0.025, 0.025, 0.04);
      const busMat = new THREE.MeshStandardMaterial({ color: 0xe2e8f0, metalness: 0.8, roughness: 0.2 });
      const busMesh = new THREE.Mesh(busGeo, busMat);
      satGroup.add(busMesh);

      const panelGeo = new THREE.BoxGeometry(0.1, 0.005, 0.03);
      const panelMat = new THREE.MeshStandardMaterial({ color: 0x0284c7, metalness: 0.9, roughness: 0.1 });
      const panelMesh = new THREE.Mesh(panelGeo, panelMat);
      satGroup.add(panelMesh);

      const boomGeo = new THREE.CylinderGeometry(0.002, 0.002, 0.08);
      const boomMat = new THREE.MeshBasicMaterial({ color: 0xf59e0b });
      const boomMesh = new THREE.Mesh(boomGeo, boomMat);
      boomMesh.position.y = -0.04;
      satGroup.add(boomMesh);

      this.scene.add(satGroup);
      this.satMarkers.set(sat.id, satGroup);

      const coneGeo = new THREE.ConeGeometry(0.35, 0.45, 24, 1, true);
      const coneMat = new THREE.MeshBasicMaterial({
        color: 0x06b6d4,
        transparent: true,
        opacity: 0.15,
        side: THREE.DoubleSide
      });
      const coneMesh = new THREE.Mesh(coneGeo, coneMat);
      this.scene.add(coneMesh);
      this.beamCones.set(sat.id, coneMesh);
    });
  }

  private animate = (): void => {
    this.animFrameId = requestAnimationFrame(this.animate);

    const t = this.engine.simulationEpochMs();
    const activeSat = this.engine.activeSatellite();
    const activeGs = this.engine.activeGroundStation();

    this.engine.satellites().forEach(sat => {
      const pos = this.orbitPropagator.propagate(sat.orbit, t);
      const satPosVec = this.ecefKmToVector3(pos.xKm, pos.yKm, pos.zKm);

      const marker = this.satMarkers.get(sat.id);
      if (marker) {
        marker.position.copy(satPosVec);
        marker.lookAt(0, 0, 0);
      }

      const cone = this.beamCones.get(sat.id);
      if (cone) {
        cone.visible = this.showBeams();
        if (cone.visible) {
          const earthCenter = new THREE.Vector3(0, 0, 0);
          const dir = earthCenter.clone().sub(satPosVec).normalize();
          cone.position.copy(satPosVec).add(dir.clone().multiplyScalar(0.22));
          cone.quaternion.setFromUnitVectors(new THREE.Vector3(0, -1, 0), dir);
        }
      }
    });

    const activeSatPos = this.orbitPropagator.propagate(activeSat.orbit, t);
    const satVec = this.ecefKmToVector3(activeSatPos.xKm, activeSatPos.yKm, activeSatPos.zKm);
    const gsVec = this.latLonToVector3(activeGs.latitudeDeg, activeGs.longitudeDeg, 1.005);

    const positions = this.losLine.geometry.attributes['position'] as THREE.BufferAttribute;
    positions.setXYZ(0, satVec.x, satVec.y, satVec.z);
    positions.setXYZ(1, gsVec.x, gsVec.y, gsVec.z);
    positions.needsUpdate = true;

    const isReceivable = this.engine.activeGeometry().isReceivable;
    (this.losLine.material as THREE.LineBasicMaterial).color.setHex(isReceivable ? 0x10b981 : 0xf43f5e);

    if (this.followSat()) {
      this.camera.position.set(satVec.x * 1.8, satVec.y * 1.8 + 0.3, satVec.z * 1.8);
      this.camera.lookAt(satVec);
    } else {
      this.updateCameraPosition();
    }

    this.renderer.render(this.scene, this.camera);
  };

  private updateCameraPosition(): void {
    const x = this.cameraDistance * Math.sin(this.cameraRotation.phi) * Math.sin(this.cameraRotation.theta);
    const y = this.cameraDistance * Math.cos(this.cameraRotation.phi);
    const z = this.cameraDistance * Math.sin(this.cameraRotation.phi) * Math.cos(this.cameraRotation.theta);
    this.camera.position.set(x, y, z);
    this.camera.lookAt(0, 0, 0);
  }

  private latLonToVector3(latDeg: number, lonDeg: number, radius: number): THREE.Vector3 {
    const phi = (90.0 - latDeg) * (Math.PI / 180.0);
    const theta = (lonDeg + 180.0) * (Math.PI / 180.0);
    const x = -(radius * Math.sin(phi) * Math.cos(theta));
    const z = radius * Math.sin(phi) * Math.sin(theta);
    const y = radius * Math.cos(phi);
    return new THREE.Vector3(x, y, z);
  }

  private ecefKmToVector3(xKm: number, yKm: number, zKm: number): THREE.Vector3 {
    const scale = 1.0 / 6378.137;
    return new THREE.Vector3(xKm * scale, zKm * scale, yKm * scale);
  }

  private setupInteraction(canvas: HTMLCanvasElement): void {
    canvas.addEventListener('mousedown', (e) => {
      this.isDragging = true;
      this.previousMousePosition = { x: e.clientX, y: e.clientY };
    });

    window.addEventListener('mouseup', () => {
      this.isDragging = false;
    });

    canvas.addEventListener('mousemove', (e) => {
      if (!this.isDragging || this.followSat()) return;

      const deltaX = e.clientX - this.previousMousePosition.x;
      const deltaY = e.clientY - this.previousMousePosition.y;

      this.cameraRotation.theta -= deltaX * 0.005;
      this.cameraRotation.phi = Math.max(0.1, Math.min(Math.PI - 0.1, this.cameraRotation.phi + deltaY * 0.005));

      this.previousMousePosition = { x: e.clientX, y: e.clientY };
    });

    canvas.addEventListener('wheel', (e) => {
      e.preventDefault();
      this.cameraDistance = Math.max(1.3, Math.min(6.0, this.cameraDistance + e.deltaY * 0.002));
      if (!this.followSat()) {
        this.updateCameraPosition();
      }
    }, { passive: false });

    window.addEventListener('resize', () => {
      const width = canvas.clientWidth || 800;
      const height = canvas.clientHeight || 600;
      this.camera.aspect = width / height;
      this.camera.updateProjectionMatrix();
      this.renderer.setSize(width, height);
    });
  }
}
