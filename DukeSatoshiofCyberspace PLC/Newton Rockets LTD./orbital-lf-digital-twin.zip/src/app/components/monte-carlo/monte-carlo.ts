import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { SimulationEngine } from '../../services/simulation-engine';
import { MonteCarloService, MonteCarloResult } from '../../services/monte-carlo';

@Component({
  selector: 'app-monte-carlo',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, MatIconModule],
  template: `
    <div class="space-y-6 font-mono text-xs">
      
      <!-- Section Header -->
      <div class="bg-[#0f172a] border border-slate-800 rounded-xl p-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h3 class="text-sm font-bold tracking-wider text-slate-100 uppercase flex items-center gap-2">
            <mat-icon class="text-cyan-400 text-lg">casino</mat-icon>
            Stochastic Monte Carlo Link Availability & Outage Engine
          </h3>
          <p class="text-slate-400 mt-0.5">
            Statistical link margin variance across random space weather, thermal noise & attitude fluctuations
          </p>
        </div>

        <button
          (click)="runTrials()"
          [disabled]="isComputing()"
          class="px-4 py-2 rounded-lg bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold transition-all cursor-pointer flex items-center gap-2 shadow-lg shadow-cyan-950/50 disabled:opacity-50">
          <mat-icon class="text-sm scale-75">{{ isComputing() ? 'hourglass_top' : 'play_arrow' }}</mat-icon>
          <span>{{ isComputing() ? 'RUNNING TRIALS...' : 'RUN MONTE CARLO' }}</span>
        </button>
      </div>

      <!-- Config Inputs & Summary Cards Grid -->
      <div class="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        <!-- Left 4 cols: Parameter Controls -->
        <div class="lg:col-span-4 bg-[#0f172a] border border-slate-800 rounded-xl p-5 space-y-4">
          <h4 class="text-xs font-bold uppercase text-slate-300 border-b border-slate-800 pb-2">
            Stochastic Simulation Inputs
          </h4>

          <div class="space-y-1.5">
            <div class="flex justify-between text-[11px]">
              <span class="text-slate-400">Number of Trials</span>
              <span class="text-cyan-300 font-bold">{{ trialCount() }}</span>
            </div>
            <select
              [value]="trialCount()"
              (change)="trialCount.set(+($any($event.target).value))"
              class="w-full bg-slate-900 border border-slate-700 text-slate-200 text-xs rounded-lg px-2.5 py-1.5 focus:border-cyan-500 focus:outline-none cursor-pointer">
              <option value="200">200 Trials (Fast)</option>
              <option value="1000">1,000 Trials (Standard)</option>
              <option value="3000">3,000 Trials (High Precision)</option>
            </select>
          </div>

          <div class="space-y-1.5">
            <div class="flex justify-between text-[11px]">
              <span class="text-slate-400">Mean Solar Activity (SFU)</span>
              <span class="text-cyan-300 font-bold">{{ sfuMean() }} SFU (σ=25)</span>
            </div>
            <input
              type="range"
              min="70"
              max="240"
              step="5"
              [value]="sfuMean()"
              (input)="sfuMean.set(+($any($event.target).value))"
              class="w-full cursor-pointer">
          </div>

          <div class="space-y-1.5">
            <div class="flex justify-between text-[11px]">
              <span class="text-slate-400">Mean Noise Excess (dB)</span>
              <span class="text-amber-300 font-bold">+{{ noiseMean() }} dB (σ=4)</span>
            </div>
            <input
              type="range"
              min="0"
              max="20"
              step="1"
              [value]="noiseMean()"
              (input)="noiseMean.set(+($any($event.target).value))"
              class="w-full cursor-pointer">
          </div>

          <div class="p-3 bg-[#070b14] border border-slate-800/80 rounded-lg text-slate-400 text-[10px] space-y-1">
            <span class="text-slate-300 font-bold">VARIED PARAMETERS:</span>
            <ul class="list-disc pl-4 space-y-0.5">
              <li>Solar 10.7cm flux (Gaussian σ=25)</li>
              <li>Atmospheric/QRN noise (Gaussian σ=4 dB)</li>
              <li>Spacecraft PA output (Gaussian σ=5%)</li>
              <li>Antenna mispointing (Rayleigh σ=1.5°)</li>
              <li>Slant range drift (Gaussian σ=1%)</li>
            </ul>
          </div>
        </div>

        <!-- Right 8 cols: Results & Distribution Histograms -->
        <div class="lg:col-span-8 bg-[#0f172a] border border-slate-800 rounded-xl p-5 space-y-5">
          
          @if (result(); as res) {
            <div class="space-y-5">
              
              <!-- Result KPI Banners -->
              <div class="grid grid-cols-2 sm:grid-cols-4 gap-3">
                <div class="p-3 bg-[#070b14] border border-slate-800/80 rounded-lg space-y-0.5">
                  <div class="text-[10px] text-slate-400 uppercase">Link Availability</div>
                  <div class="text-2xl font-bold text-emerald-400">
                    {{ res.availabilityPercent }}%
                  </div>
                  <div class="text-[10px] text-slate-500">Outage: {{ res.outagePercent }}%</div>
                </div>

                <div class="p-3 bg-[#070b14] border border-slate-800/80 rounded-lg space-y-0.5">
                  <div class="text-[10px] text-slate-400 uppercase">Mean C/N Ratio</div>
                  <div class="text-2xl font-bold text-cyan-300">
                    {{ res.meanCnDb }} dB
                  </div>
                  <div class="text-[10px] text-slate-500">[{{ res.minCnDb }} to {{ res.maxCnDb }} dB]</div>
                </div>

                <div class="p-3 bg-[#070b14] border border-slate-800/80 rounded-lg space-y-0.5">
                  <div class="text-[10px] text-slate-400 uppercase">Mean Link Margin</div>
                  <div class="text-2xl font-bold text-slate-100">
                    +{{ res.meanLinkMarginDb }} dB
                  </div>
                  <div class="text-[10px] text-slate-500">Above target BER</div>
                </div>

                <div class="p-3 bg-[#070b14] border border-slate-800/80 rounded-lg space-y-0.5">
                  <div class="text-[10px] text-slate-400 uppercase">Mean Coded BER</div>
                  <div class="text-2xl font-bold text-emerald-400">
                    {{ res.meanBer < 1e-6 ? '< 1×10⁻⁶' : (res.meanBer.toExponential(1)) }}
                  </div>
                  <div class="text-[10px] text-slate-500">{{ res.trials }} Total Samples</div>
                </div>
              </div>

              <!-- C/N Distribution Histogram -->
              <div class="space-y-2">
                <div class="flex justify-between text-[11px] text-slate-300 font-bold border-b border-slate-800 pb-1">
                  <span>Carrier-to-Noise Ratio (C/N) Probability Density</span>
                  <span class="text-slate-500">{{ res.trials }} TRIALS</span>
                </div>

                <div class="space-y-1.5 pt-1">
                  @for (bin of res.cnHistogram; track bin.binLabel) {
                    <div class="flex items-center gap-3 text-[11px]">
                      <span class="w-20 text-slate-400 shrink-0 text-right">{{ bin.binLabel }}</span>
                      <div class="w-full bg-slate-900 rounded-full h-3 overflow-hidden flex items-center">
                        <div class="bg-cyan-500 h-full rounded-full transition-all duration-300" [style.width.%]="bin.percentage"></div>
                      </div>
                      <span class="w-16 text-slate-200 font-bold shrink-0">{{ bin.percentage }}%</span>
                    </div>
                  }
                </div>
              </div>

              <!-- BER Quality Distribution -->
              <div class="space-y-2 pt-2 border-t border-slate-800">
                <div class="flex justify-between text-[11px] text-slate-300 font-bold border-b border-slate-800 pb-1">
                  <span>Bit Error Rate (BER) Integrity Categories</span>
                  <span class="text-emerald-400 font-normal">FEC Viterbi Active</span>
                </div>

                <div class="space-y-1.5 pt-1">
                  @for (bin of res.berHistogram; track bin.binLabel) {
                    <div class="flex items-center gap-3 text-[11px]">
                      <span class="w-44 text-slate-400 shrink-0 text-right">{{ bin.binLabel }}</span>
                      <div class="w-full bg-slate-900 rounded-full h-3 overflow-hidden flex items-center">
                        <div class="h-full rounded-full transition-all duration-300"
                             [class.bg-emerald-500]="bin.binLabel.includes('Clean')"
                             [class.bg-teal-400]="bin.binLabel.includes('Good')"
                             [class.bg-amber-400]="bin.binLabel.includes('Fair')"
                             [class.bg-rose-500]="bin.binLabel.includes('Degraded') || bin.binLabel.includes('Loss')"
                             [style.width.%]="bin.percentage"></div>
                      </div>
                      <span class="w-16 text-slate-200 font-bold shrink-0">{{ bin.percentage }}%</span>
                    </div>
                  }
                </div>
              </div>

            </div>
          }

        </div>

      </div>

    </div>
  `
})
export class MonteCarloComponent {
  public engine = inject(SimulationEngine);
  private mcService = inject(MonteCarloService);

  public trialCount = signal<number>(1000);
  public sfuMean = signal<number>(130);
  public noiseMean = signal<number>(4);
  public isComputing = signal<boolean>(false);
  public result = signal<MonteCarloResult | null>(null);

  constructor() {
    this.runTrials();
  }

  public runTrials(): void {
    this.isComputing.set(true);
    setTimeout(() => {
      const res = this.mcService.runSimulation(
        this.engine.activeSatellite(),
        this.engine.activeGroundStation(),
        this.engine.activeGeometry(),
        this.engine.propagationMode(),
        this.trialCount(),
        this.sfuMean(),
        this.noiseMean()
      );
      this.result.set(res);
      this.isComputing.set(false);
    }, 50);
  }
}
