import { ChangeDetectionStrategy, Component, inject, output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { SimulationEngine } from '../../services/simulation-engine';
import { OrbitPropagator } from '../../services/orbit-propagator';
import { Satellite } from '../../models/satellite.model';
import { NavTab } from '../navbar/navbar';

@Component({
  selector: 'app-overview',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, MatIconModule],
  template: `
    <div class="space-y-6">
      
      <!-- Top Station & Satellite Selector Bar -->
      <div class="bg-[#0f172a] border border-slate-800 rounded-xl p-4 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <!-- Target Satellite Selector -->
        <div class="flex items-center gap-3 w-full md:w-auto">
          <div class="p-2 rounded-lg bg-cyan-950 border border-cyan-800 text-cyan-400 shrink-0">
            <mat-icon class="text-xl">satellite_alt</mat-icon>
          </div>
          <div>
            <div class="text-[11px] uppercase tracking-wider text-slate-400 font-mono">Active Satellite</div>
            <select
              [value]="engine.activeSatelliteId()"
              (change)="onSatChange($event)"
              class="bg-slate-900 border border-slate-700 text-slate-100 text-sm font-semibold rounded-lg px-2.5 py-1 mt-0.5 focus:border-cyan-500 focus:outline-none cursor-pointer font-mono">
              @for (s of engine.satellites(); track s.id) {
                <option [value]="s.id">
                  {{ s.name }} ({{ s.transmitter.rfFrequencyHz / 1000 }} kHz)
                </option>
              }
            </select>
          </div>
        </div>

        <!-- Target Ground Station Selector -->
        <div class="flex items-center gap-3 w-full md:w-auto">
          <div class="p-2 rounded-lg bg-indigo-950 border border-indigo-800 text-indigo-400 shrink-0">
            <mat-icon class="text-xl">podcasts</mat-icon>
          </div>
          <div>
            <div class="text-[11px] uppercase tracking-wider text-slate-400 font-mono">Ground Station</div>
            <select
              [value]="engine.activeStationId()"
              (change)="onStationChange($event)"
              class="bg-slate-900 border border-slate-700 text-slate-100 text-sm font-semibold rounded-lg px-2.5 py-1 mt-0.5 focus:border-indigo-500 focus:outline-none cursor-pointer font-mono">
              @for (g of engine.groundStations(); track g.id) {
                <option [value]="g.id">
                  {{ g.name }} ({{ g.country }})
                </option>
              }
            </select>
          </div>
        </div>

        <!-- Propagation Channel Mode Selector -->
        <div class="flex items-center gap-3 w-full md:w-auto">
          <div class="p-2 rounded-lg bg-slate-900 border border-slate-800 text-slate-300 shrink-0">
            <mat-icon class="text-xl">hub</mat-icon>
          </div>
          <div>
            <div class="text-[11px] uppercase tracking-wider text-slate-400 font-mono">Channel Model</div>
            <div class="flex items-center gap-1 mt-0.5">
              @for (m of propModes; track m.id) {
                <button
                  (click)="engine.setPropagationMode(m.id)"
                  class="px-2 py-0.5 text-xs rounded border transition-colors cursor-pointer font-mono"
                  [class.bg-cyan-500]="engine.propagationMode() === m.id"
                  [class.text-slate-950]="engine.propagationMode() === m.id"
                  [class.border-cyan-400]="engine.propagationMode() === m.id"
                  [class.font-bold]="engine.propagationMode() === m.id"
                  [class.bg-slate-900]="engine.propagationMode() !== m.id"
                  [class.text-slate-400]="engine.propagationMode() !== m.id"
                  [class.border-slate-800]="engine.propagationMode() !== m.id">
                  {{ m.label }}
                </button>
              }
            </div>
          </div>
        </div>
      </div>

      <!-- Core Telemetry Metric Cards Grid -->
      <div class="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
        
        <!-- Metric 1: Frequency -->
        <div class="bg-[#0f172a] border border-slate-800 rounded-xl p-3.5 space-y-1">
          <div class="text-[11px] font-mono text-slate-400 uppercase tracking-wider">RF Frequency</div>
          <div class="text-xl font-mono font-bold text-cyan-300">
            {{ (engine.activeSatellite().transmitter.rfFrequencyHz / 1000) | number:'1.2-2' }}
            <span class="text-xs font-normal text-slate-400 uppercase ml-1">kHz</span>
          </div>
          <div class="text-[10px] font-mono text-slate-500">
            λ = {{ (299792458 / engine.activeSatellite().transmitter.rfFrequencyHz) | number:'1.0-0' }} m
          </div>
        </div>

        <!-- Metric 2: Elevation & Range -->
        <div class="bg-[#0f172a] border border-slate-800 rounded-xl p-3.5 space-y-1">
          <div class="text-[11px] font-mono text-slate-400 uppercase tracking-wider">Slant Range / Elev</div>
          <div class="text-xl font-mono font-bold text-slate-100">
            {{ engine.activeGeometry().slantRangeKm | number:'1.0-0' }}
            <span class="text-xs font-normal text-slate-400 uppercase ml-1">km</span>
          </div>
          <div class="text-[10px] font-mono text-slate-400 flex items-center justify-between">
            <span>Elev: {{ engine.activeGeometry().elevationDeg | number:'1.1-1' }}°</span>
            <span [class.text-emerald-400]="engine.activeGeometry().isReceivable" [class.text-slate-500]="!engine.activeGeometry().isReceivable">
              {{ engine.activeGeometry().isReceivable ? 'ABOVE HORIZON' : 'OCCULTED' }}
            </span>
          </div>
        </div>

        <!-- Metric 3: Received Power -->
        <div class="bg-[#0f172a] border border-slate-800 rounded-xl p-3.5 space-y-1">
          <div class="text-[11px] font-mono text-slate-400 uppercase tracking-wider">Received Power (P_rx)</div>
          <div class="text-xl font-mono font-bold"
               [class.text-emerald-400]="engine.activeLinkBudget().rxPowerDbm > -105"
               [class.text-amber-400]="engine.activeLinkBudget().rxPowerDbm <= -105 && engine.activeLinkBudget().rxPowerDbm > -120"
               [class.text-rose-400]="engine.activeLinkBudget().rxPowerDbm <= -120">
            {{ engine.activeLinkBudget().rxPowerDbm }}
            <span class="text-xs font-normal text-slate-400 uppercase ml-1">dBm</span>
          </div>
          <div class="text-[10px] font-mono text-slate-500">
            Tx: {{ engine.activeSatellite().transmitter.outputPowerWatts }} W ({{ engine.activeLinkBudget().txPowerDbm }} dBm)
          </div>
        </div>

        <!-- Metric 4: Carrier-to-Noise (C/N) -->
        <div class="bg-[#0f172a] border border-slate-800 rounded-xl p-3.5 space-y-1">
          <div class="text-[11px] font-mono text-slate-400 uppercase tracking-wider">Carrier / Noise (C/N)</div>
          <div class="text-xl font-mono font-bold text-cyan-300">
            {{ engine.activeLinkBudget().carrierToNoiseRatioDb }}
            <span class="text-xs font-normal text-slate-400 uppercase ml-1">dB</span>
          </div>
          <div class="text-[10px] font-mono text-slate-400 flex items-center justify-between">
            <span>Margin: {{ engine.activeLinkBudget().linkMarginDb }} dB</span>
            <span class="text-slate-500">NF: {{ engine.activeLinkBudget().receiverNoiseFigureDb }} dB</span>
          </div>
        </div>

        <!-- Metric 5: Doppler Shift -->
        <div class="bg-[#0f172a] border border-slate-800 rounded-xl p-3.5 space-y-1">
          <div class="text-[11px] font-mono text-slate-400 uppercase tracking-wider">Doppler Shift</div>
          <div class="text-xl font-mono font-bold"
               [class.text-emerald-400]="engine.activeGeometry().dopplerShiftHz >= 0"
               [class.text-cyan-400]="engine.activeGeometry().dopplerShiftHz < 0">
            {{ engine.activeGeometry().dopplerShiftHz > 0 ? '+' : '' }}{{ engine.activeGeometry().dopplerShiftHz | number:'1.2-2' }}
            <span class="text-xs font-normal text-slate-400 uppercase ml-1">Hz</span>
          </div>
          <div class="text-[10px] font-mono text-slate-500">
            v_rad: {{ engine.activeGeometry().radialVelocityKms | number:'1.2-2' }} km/s
          </div>
        </div>

        <!-- Metric 6: Receiver Lock State -->
        <div class="bg-[#0f172a] border border-slate-800 rounded-xl p-3.5 space-y-1">
          <div class="text-[11px] font-mono text-slate-400 uppercase tracking-wider">Receiver State</div>
          <div class="text-xl font-mono font-bold tracking-wide"
               [class.text-emerald-400]="engine.receiverLockState() === 'DECODE'"
               [class.text-cyan-300]="engine.receiverLockState() === 'LOCK'"
               [class.text-amber-400]="engine.receiverLockState() === 'ACQUIRE'"
               [class.text-slate-500]="engine.receiverLockState() === 'SEARCH'">
            ● {{ engine.receiverLockState() }}
          </div>
          <div class="text-[10px] font-mono text-slate-400">
            BER: {{ engine.activeLinkBudget().codedBer < 1e-6 ? '< 1×10⁻⁶' : (engine.activeLinkBudget().codedBer | number:'1.1-2') }}
          </div>
        </div>
      </div>

      <!-- Main Stage Split: Physical End-to-End Chain Schematic & Constellation Summary -->
      <div class="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        <!-- Left 7 cols: End-to-End Computational Chain Visualizer -->
        <div class="lg:col-span-7 bg-[#0f172a] border border-slate-800 rounded-xl p-5 space-y-4">
          <div class="flex items-center justify-between border-b border-slate-800 pb-3">
            <div class="flex items-center gap-2">
              <mat-icon class="text-cyan-400 text-lg">schema</mat-icon>
              <h3 class="text-sm font-bold tracking-wide text-slate-200 uppercase font-mono">
                End-to-End Radio Communications Chain
              </h3>
            </div>
            <button
              (click)="navigateTo('SIGNAL_DEBUGGER')"
              class="text-xs font-mono text-cyan-400 hover:text-cyan-300 flex items-center gap-1 cursor-pointer">
              <span>Inspect All 13 Stages</span>
              <mat-icon class="text-xs scale-75">arrow_forward</mat-icon>
            </button>
          </div>

          <!-- Interactive Schematic Flow Diagram -->
          <div class="bg-[#070b14] border border-slate-800/80 rounded-lg p-4 font-mono text-xs space-y-3">
            
            <!-- Satellite Block -->
            <div class="p-3 bg-slate-900/80 border border-cyan-900/50 rounded-md">
              <div class="flex items-center justify-between text-cyan-400 font-semibold mb-1">
                <span>[1] SATELLITE BROADCAST PAYLOAD ({{ engine.activeSatellite().name }})</span>
                <span class="text-[10px] text-slate-400">ALT: {{ engine.activePosition().altitudeKm | number:'1.0-0' }} km</span>
              </div>
              <div class="grid grid-cols-3 gap-2 text-[11px] text-slate-300 mt-2">
                <div>• Mod: <span class="text-cyan-300">{{ engine.activeSatellite().transmitter.modulation }}</span></div>
                <div>• Rate: <span class="text-cyan-300">{{ engine.activeSatellite().transmitter.symbolRateBaud }} Baud</span></div>
                <div>• FEC: <span class="text-cyan-300">{{ engine.activeSatellite().transmitter.fecScheme }}</span></div>
                <div>• P_TX: <span class="text-slate-100 font-bold">{{ engine.activeSatellite().transmitter.outputPowerWatts }} W</span></div>
                <div>• EIRP: <span class="text-slate-100">{{ engine.activeLinkBudget().eirpDbm }} dBm</span></div>
                <div>• G_TX: <span class="text-slate-100">+{{ engine.activeSatellite().antenna.gainDbi }} dBi</span></div>
              </div>
            </div>

            <!-- Downlink Propagation Vector -->
            <div class="flex items-center justify-center py-1">
              <div class="flex items-center gap-2 text-slate-500 text-[11px]">
                <span>▼</span>
                <span class="text-amber-400/90 font-semibold">
                  PROPAGATION CHANNEL (FSPL: -{{ engine.activeLinkBudget().freeSpacePathLossDb }} dB | Iono: -{{ engine.activeLinkBudget().ionosphericLossDb }} dB)
                </span>
                <span>▼</span>
              </div>
            </div>

            <!-- Ground Receiving Front-End Block -->
            <div class="p-3 bg-slate-900/80 border border-indigo-900/50 rounded-md">
              <div class="flex items-center justify-between text-indigo-300 font-semibold mb-1">
                <span>[2] GROUND RECEIVER FRONT-END ({{ engine.activeGroundStation().name }})</span>
                <span class="text-[10px] text-slate-400">T_sys: {{ engine.activeLinkBudget().systemNoiseTempK }} K</span>
              </div>
              <div class="grid grid-cols-3 gap-2 text-[11px] text-slate-300 mt-2">
                <div>• G_RX: <span class="text-indigo-200">+{{ engine.activeGroundStation().antenna.gainDbi }} dBi</span></div>
                <div>• LNA Gain: <span class="text-indigo-200">+{{ engine.activeGroundStation().lnaGainDb }} dB</span></div>
                <div>• Noise Floor: <span class="text-indigo-200">{{ engine.activeLinkBudget().thermalNoisePowerDbm }} dBm</span></div>
                <div>• P_RX: <span class="text-slate-100 font-bold">{{ engine.activeLinkBudget().rxPowerDbm }} dBm</span></div>
                <div>• C/N: <span class="text-cyan-300 font-bold">{{ engine.activeLinkBudget().carrierToNoiseRatioDb }} dB</span></div>
                <div>• Eb/N0: <span class="text-cyan-300">{{ engine.activeLinkBudget().energyPerBitToNoiseDensityDb }} dB</span></div>
              </div>
            </div>

            <!-- Demodulator & Decoder Sink Block -->
            <div class="flex items-center justify-center py-1">
              <div class="flex items-center gap-2 text-slate-500 text-[11px]">
                <span>▼</span>
                <span class="text-emerald-400 font-semibold">
                  DIGITAL DEMODULATION & FORWARD ERROR CORRECTION
                </span>
                <span>▼</span>
              </div>
            </div>

            <div class="p-3 bg-emerald-950/30 border border-emerald-900/60 rounded-md">
              <div class="flex items-center justify-between text-emerald-400 font-semibold mb-1">
                <span>[3] GROUND SINK · PACKET DECODER</span>
                <span class="text-[10px] font-bold text-emerald-300">STATUS: {{ engine.receiverLockState() }}</span>
              </div>
              <div class="grid grid-cols-3 gap-2 text-[11px] text-slate-300 mt-2">
                <div>• Coded BER: <span class="text-emerald-300">{{ engine.activeLinkBudget().codedBer < 1e-6 ? '< 1e-6' : (engine.activeLinkBudget().codedBer | number:'1.1-2') }}</span></div>
                <div>• FER: <span class="text-emerald-300">{{ engine.activeLinkBudget().frameErrorRate }}</span></div>
                <div>• CRC: <span class="text-emerald-300 font-bold">PASS (32-bit)</span></div>
              </div>
            </div>

          </div>

          <!-- Quick Access Navigation Button Row -->
          <div class="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-2 font-mono text-xs">
            <button
              (click)="navigateTo('CONSTELLATION')"
              class="p-2.5 bg-slate-900 border border-slate-700 hover:border-cyan-500 text-slate-200 rounded-lg flex items-center justify-center gap-1.5 transition-colors cursor-pointer">
              <mat-icon class="text-sm text-cyan-400">public</mat-icon>
              <span>3D Orbit Globe</span>
            </button>
            <button
              (click)="navigateTo('SPECTRUM')"
              class="p-2.5 bg-slate-900 border border-slate-700 hover:border-cyan-500 text-slate-200 rounded-lg flex items-center justify-center gap-1.5 transition-colors cursor-pointer">
              <mat-icon class="text-sm text-amber-400">waterfall_chart</mat-icon>
              <span>FFT Spectrum</span>
            </button>
            <button
              (click)="navigateTo('IQ_CONSTELLATION')"
              class="p-2.5 bg-slate-900 border border-slate-700 hover:border-cyan-500 text-slate-200 rounded-lg flex items-center justify-center gap-1.5 transition-colors cursor-pointer">
              <mat-icon class="text-sm text-indigo-400">grain</mat-icon>
              <span>I/Q Constellation</span>
            </button>
            <button
              (click)="navigateTo('RECEIVER')"
              class="p-2.5 bg-slate-900 border border-slate-700 hover:border-cyan-500 text-slate-200 rounded-lg flex items-center justify-center gap-1.5 transition-colors cursor-pointer">
              <mat-icon class="text-sm text-emerald-400">radio</mat-icon>
              <span>Ground SDR</span>
            </button>
          </div>
        </div>

        <!-- Right 5 cols: Constellation Status Table & Live Packet Feed -->
        <div class="lg:col-span-5 space-y-6">
          
          <!-- Constellation Multi-Satellite Table -->
          <div class="bg-[#0f172a] border border-slate-800 rounded-xl p-4 space-y-3">
            <div class="flex items-center justify-between border-b border-slate-800 pb-2">
              <h4 class="text-xs font-bold uppercase font-mono text-slate-300">
                Constellation Fleet Telemetry
              </h4>
              <span class="text-[10px] font-mono text-cyan-400">{{ engine.satellites().length }} SATELLITES ACTIVE</span>
            </div>

            <div class="overflow-x-auto">
              <table class="w-full text-left font-mono text-xs">
                <thead>
                  <tr class="text-[10px] uppercase text-slate-500 border-b border-slate-800">
                    <th class="py-1.5 font-medium">Sat ID</th>
                    <th class="py-1.5 font-medium">Freq</th>
                    <th class="py-1.5 font-medium">Elev</th>
                    <th class="py-1.5 font-medium">C/N</th>
                    <th class="py-1.5 font-medium text-right">Action</th>
                  </tr>
                </thead>
                <tbody class="divide-y divide-slate-800/60">
                  @for (s of engine.satellites(); track s.id) {
                    <tr class="hover:bg-slate-800/40">
                      <td class="py-2 font-semibold" [class.text-cyan-300]="s.id === engine.activeSatelliteId()">
                        {{ s.id }}
                      </td>
                      <td class="py-2 text-slate-300">
                        {{ (s.transmitter.rfFrequencyHz / 1000) | number:'1.1-1' }} kHz
                      </td>
                      <td class="py-2 text-slate-300">
                        {{ getSatelliteElev(s) | number:'1.1-1' }}°
                      </td>
                      <td class="py-2" [class.text-emerald-400]="s.id === engine.activeSatelliteId() && engine.activeLinkBudget().carrierToNoiseRatioDb > 10"
                                      [class.text-slate-500]="s.id !== engine.activeSatelliteId()">
                        {{ s.id === engine.activeSatelliteId() ? (engine.activeLinkBudget().carrierToNoiseRatioDb + ' dB') : '--' }}
                      </td>
                      <td class="py-2 text-right">
                        <button
                          (click)="engine.selectSatellite(s.id)"
                          class="px-2 py-0.5 text-[10px] rounded border transition-colors cursor-pointer"
                          [class.bg-cyan-950]="s.id === engine.activeSatelliteId()"
                          [class.border-cyan-700]="s.id === engine.activeSatelliteId()"
                          [class.text-cyan-300]="s.id === engine.activeSatelliteId()"
                          [class.border-slate-700]="s.id !== engine.activeSatelliteId()"
                          [class.text-slate-400]="s.id !== engine.activeSatelliteId()">
                          {{ s.id === engine.activeSatelliteId() ? 'ACTIVE' : 'SELECT' }}
                        </button>
                      </td>
                    </tr>
                  }
                </tbody>
              </table>
            </div>
          </div>

          <!-- Live CCSDS Broadcast Packets Preview -->
          <div class="bg-[#0f172a] border border-slate-800 rounded-xl p-4 space-y-3">
            <div class="flex items-center justify-between border-b border-slate-800 pb-2">
              <div class="flex items-center gap-1.5">
                <span class="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
                <h4 class="text-xs font-bold uppercase font-mono text-slate-300">
                  Live Decoded Broadcast Frames
                </h4>
              </div>
              <span class="text-[10px] font-mono text-slate-400">CRC-32 PASS</span>
            </div>

            <div class="space-y-2 max-h-56 overflow-y-auto font-mono text-xs">
              @for (pkt of engine.decodedPackets().slice(0, 4); track pkt.id) {
                <div class="p-2.5 bg-[#070b14] border border-slate-800/80 rounded-lg space-y-1">
                  <div class="flex items-center justify-between text-[11px]">
                    <span class="font-bold text-cyan-300">FRAME #{{ pkt.frameNumber }}</span>
                    <span class="text-slate-400 text-[10px]">{{ pkt.payloadType }}</span>
                    <span class="text-emerald-400 text-[10px] font-semibold">CRC PASS</span>
                  </div>
                  <div class="text-[10px] text-slate-400 truncate">
                    HEX: {{ pkt.rawBitsHex }}
                  </div>
                  <div class="flex items-center justify-between text-[10px] text-slate-500 pt-0.5">
                    <span>RSSI: {{ pkt.rssiDbm }} dBm</span>
                    <span>C/N: {{ pkt.cnDb }} dB</span>
                    <span>BER: {{ pkt.estimatedBer.toExponential(1) }}</span>
                  </div>
                </div>
              }
            </div>
          </div>

        </div>

      </div>

    </div>
  `
})
export class OverviewComponent {
  public engine = inject(SimulationEngine);
  private orbitPropagator = inject(OrbitPropagator);
  public tabChange = output<NavTab>();

  public propModes = [
    { id: 'IDEAL', label: 'Ideal' },
    { id: 'FREE_SPACE', label: 'Free Space' },
    { id: 'IONOSPHERIC', label: 'Ionospheric' },
    { id: 'FULL_CHANNEL', label: 'Full Channel' }
  ] as const;

  public onSatChange(event: Event): void {
    const sel = event.target as HTMLSelectElement;
    if (sel) {
      this.engine.selectSatellite(sel.value);
    }
  }

  public onStationChange(event: Event): void {
    const sel = event.target as HTMLSelectElement;
    if (sel) {
      this.engine.selectGroundStation(sel.value);
    }
  }

  public navigateTo(tab: NavTab): void {
    this.tabChange.emit(tab);
  }

  public getSatelliteElev(sat: Satellite): number {
    const gs = this.engine.activeGroundStation();
    const pos = this.orbitPropagator.propagate(sat.orbit, this.engine.simulationEpochMs());
    const geom = this.orbitPropagator.calculateGeometry(pos, gs, sat.transmitter.rfFrequencyHz);
    return geom.elevationDeg;
  }
}
