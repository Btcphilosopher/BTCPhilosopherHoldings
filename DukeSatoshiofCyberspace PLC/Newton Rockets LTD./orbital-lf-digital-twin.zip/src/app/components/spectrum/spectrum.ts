import { ChangeDetectionStrategy, Component, ElementRef, OnDestroy, OnInit, ViewChild, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { SimulationEngine } from '../../services/simulation-engine';

@Component({
  selector: 'app-spectrum',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, MatIconModule],
  template: `
    <div class="space-y-4">
      
      <!-- Top Spectrum Control Header -->
      <div class="bg-[#0f172a] border border-slate-800 rounded-xl p-4 flex flex-wrap items-center justify-between gap-4 font-mono">
        <div>
          <h3 class="text-sm font-bold tracking-wider text-slate-100 uppercase flex items-center gap-2">
            <mat-icon class="text-cyan-400 text-lg">waterfall_chart</mat-icon>
            Digital Spectrum Analyzer & Real-Time Waterfall
          </h3>
          <p class="text-xs text-slate-400 mt-0.5">
            Real-time FFT baseband spectral density & continuous IQ spectrogram
          </p>
        </div>

        <!-- Controls: FFT Size, Window, Palette -->
        <div class="flex items-center gap-3 flex-wrap text-xs">
          <!-- FFT Size -->
          <div class="flex items-center gap-1">
            <span class="text-slate-400">FFT:</span>
            <select
              [value]="fftSize()"
              (change)="fftSize.set(+($any($event.target).value))"
              class="bg-slate-900 border border-slate-700 text-slate-200 rounded px-2 py-1 focus:border-cyan-500 focus:outline-none cursor-pointer">
              <option value="256">256</option>
              <option value="512">512</option>
              <option value="1024">1024</option>
            </select>
          </div>

          <!-- Window Function -->
          <div class="flex items-center gap-1">
            <span class="text-slate-400">Window:</span>
            <select
              [value]="windowFunction()"
              (change)="windowFunction.set($any($event.target).value)"
              class="bg-slate-900 border border-slate-700 text-slate-200 rounded px-2 py-1 focus:border-cyan-500 focus:outline-none cursor-pointer">
              <option value="Hanning">Hanning</option>
              <option value="Hamming">Hamming</option>
              <option value="Blackman">Blackman</option>
              <option value="Rectangular">Rectangular</option>
            </select>
          </div>

          <!-- Color Palette -->
          <div class="flex items-center gap-1">
            <span class="text-slate-400">Palette:</span>
            <select
              [value]="colorPalette()"
              (change)="colorPalette.set($any($event.target).value)"
              class="bg-slate-900 border border-slate-700 text-slate-200 rounded px-2 py-1 focus:border-cyan-500 focus:outline-none cursor-pointer">
              <option value="VIRIDIS">Viridis</option>
              <option value="TURBO">Turbo</option>
              <option value="PHOSPHOR">Phosphor Green</option>
              <option value="ICE">Ice Blue</option>
              <option value="AMBER">Classic Amber</option>
            </select>
          </div>

          <!-- Peak Hold Toggle -->
          <button
            (click)="peakHold.set(!peakHold())"
            class="px-2.5 py-1 rounded border transition-colors cursor-pointer"
            [class.bg-cyan-950]="peakHold()"
            [class.border-cyan-700]="peakHold()"
            [class.text-cyan-300]="peakHold()"
            [class.bg-slate-900]="!peakHold()"
            [class.border-slate-700]="!peakHold()"
            [class.text-slate-400]="!peakHold()">
            Peak Hold
          </button>
        </div>
      </div>

      <!-- Live Spectrum Scope Display -->
      <div class="bg-[#0b111e] border border-slate-800 rounded-xl p-4 space-y-2">
        <div class="flex items-center justify-between text-xs font-mono text-slate-400 pb-1 border-b border-slate-800/80">
          <div class="flex items-center gap-4">
            <span>CENTER: <strong class="text-slate-100">{{ (engine.activeSatellite().transmitter.rfFrequencyHz / 1000) | number:'1.2-2' }} kHz</strong></span>
            <span>SPAN: <strong class="text-slate-100">24.0 kHz</strong></span>
            <span>RBW: <strong class="text-slate-100">{{ (24000 / fftSize()) | number:'1.1-1' }} Hz</strong></span>
          </div>
          <div class="flex items-center gap-3">
            <span class="text-cyan-400">● LIVE TRACE</span>
            @if (peakHold()) {
              <span class="text-amber-400">● MAX PEAK</span>
            }
            <span class="text-rose-400/80">--- NOISE FLOOR</span>
          </div>
        </div>

        <div class="relative h-64 w-full bg-[#070b14] border border-slate-800/80 rounded-lg overflow-hidden">
          <canvas #spectrumCanvas class="w-full h-full block"></canvas>
        </div>
      </div>

      <!-- Continuous Waterfall Display -->
      <div class="bg-[#0b111e] border border-slate-800 rounded-xl p-4 space-y-2">
        <div class="flex items-center justify-between text-xs font-mono text-slate-400 pb-1 border-b border-slate-800/80">
          <div class="flex items-center gap-2">
            <mat-icon class="text-xs text-amber-400">history</mat-icon>
            <span>WATERFALL TIME HISTORY (-30s to NOW)</span>
          </div>
          <div class="text-[11px] text-slate-500">
            DYNAMIC RANGE: -135 dBm TO -65 dBm
          </div>
        </div>

        <div class="relative h-56 w-full bg-[#070b14] border border-slate-800/80 rounded-lg overflow-hidden">
          <canvas #waterfallCanvas class="w-full h-full block"></canvas>
        </div>
      </div>

    </div>
  `
})
export class SpectrumComponent implements OnInit, OnDestroy {
  @ViewChild('spectrumCanvas', { static: true }) specCanvasRef!: ElementRef<HTMLCanvasElement>;
  @ViewChild('waterfallCanvas', { static: true }) wfCanvasRef!: ElementRef<HTMLCanvasElement>;

  public engine = inject(SimulationEngine);

  public fftSize = signal<number>(512);
  public windowFunction = signal<'Hanning' | 'Hamming' | 'Blackman' | 'Rectangular'>('Hanning');
  public colorPalette = signal<'VIRIDIS' | 'TURBO' | 'PHOSPHOR' | 'ICE' | 'AMBER'>('TURBO');
  public peakHold = signal<boolean>(true);

  private animFrameId: number | null = null;
  private maxPeakBuffer: number[] = [];

  ngOnInit(): void {
    if (typeof window !== 'undefined') {
      this.startRenderLoop();
    }
  }

  ngOnDestroy(): void {
    if (this.animFrameId !== null) {
      cancelAnimationFrame(this.animFrameId);
    }
  }

  private startRenderLoop = (): void => {
    this.drawSpectrum();
    this.drawWaterfall();
    this.animFrameId = requestAnimationFrame(this.startRenderLoop);
  };

  private drawSpectrum(): void {
    const canvas = this.specCanvasRef.nativeElement;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const width = canvas.clientWidth || 800;
    const height = canvas.clientHeight || 250;

    if (canvas.width !== width || canvas.height !== height) {
      canvas.width = width;
      canvas.height = height;
    }

    const fft = this.engine.fftFrame();
    if (!fft || !fft.magnitudesDbm.length) return;

    ctx.fillStyle = '#070b14';
    ctx.fillRect(0, 0, width, height);

    // Draw Grid Lines (dBm on Y-axis, Frequency on X-axis)
    const minDbm = -140;
    const maxDbm = -60;
    const dbmRange = maxDbm - minDbm;

    ctx.strokeStyle = '#1e293b';
    ctx.lineWidth = 1;
    ctx.font = '10px JetBrains Mono, monospace';
    ctx.fillStyle = '#64748b';

    // Horizontal dBm grid lines
    for (let dbm = -130; dbm <= -70; dbm += 15) {
      const y = height - ((dbm - minDbm) / dbmRange) * height;
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(width, y);
      ctx.stroke();
      ctx.fillText(`${dbm} dBm`, 8, y - 4);
    }

    // Vertical Frequency grid lines
    const numFreqTicks = 6;
    for (let i = 0; i <= numFreqTicks; i++) {
      const x = (i / numFreqTicks) * width;
      const freq = fft.centerFreqHz - fft.spanHz / 2 + (i / numFreqTicks) * fft.spanHz;
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x, height);
      ctx.stroke();
      if (i > 0 && i < numFreqTicks) {
        ctx.fillText(`${(freq / 1000).toFixed(1)} kHz`, x - 20, height - 6);
      }
    }

    // Draw Noise Floor Dotted Line
    const noiseY = height - ((fft.noiseFloorDbm - minDbm) / dbmRange) * height;
    ctx.strokeStyle = '#f43f5e';
    ctx.setLineDash([4, 4]);
    ctx.beginPath();
    ctx.moveTo(0, noiseY);
    ctx.lineTo(width, noiseY);
    ctx.stroke();
    ctx.setLineDash([]);

    // Peak Hold Line
    const mags = fft.magnitudesDbm;
    if (this.maxPeakBuffer.length !== mags.length) {
      this.maxPeakBuffer = [...mags];
    } else if (this.peakHold()) {
      for (let i = 0; i < mags.length; i++) {
        if (mags[i] > this.maxPeakBuffer[i]) {
          this.maxPeakBuffer[i] = mags[i];
        } else {
          this.maxPeakBuffer[i] -= 0.08; // slow decay
        }
      }

      ctx.strokeStyle = '#f59e0b';
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      for (let i = 0; i < this.maxPeakBuffer.length; i++) {
        const x = (i / (this.maxPeakBuffer.length - 1)) * width;
        const y = height - ((this.maxPeakBuffer[i] - minDbm) / dbmRange) * height;
        if (i === 0) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
      }
      ctx.stroke();
    }

    // Live Signal Trace
    ctx.strokeStyle = '#06b6d4';
    ctx.lineWidth = 2;
    ctx.beginPath();

    for (let i = 0; i < mags.length; i++) {
      const x = (i / (mags.length - 1)) * width;
      const y = height - ((mags[i] - minDbm) / dbmRange) * height;
      if (i === 0) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
    }
    ctx.stroke();

    // Fill under curve
    ctx.lineTo(width, height);
    ctx.lineTo(0, height);
    ctx.closePath();
    const grad = ctx.createLinearGradient(0, 0, 0, height);
    grad.addColorStop(0, 'rgba(6, 182, 212, 0.25)');
    grad.addColorStop(1, 'rgba(6, 182, 212, 0.0)');
    ctx.fillStyle = grad;
    ctx.fill();
  }

  private drawWaterfall(): void {
    const canvas = this.wfCanvasRef.nativeElement;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const width = canvas.clientWidth || 800;
    const height = canvas.clientHeight || 200;

    if (canvas.width !== width || canvas.height !== height) {
      canvas.width = width;
      canvas.height = height;
    }

    const history = this.engine.waterfallHistory();
    if (!history.length) return;

    const imgData = ctx.createImageData(width, height);
    const data = imgData.data;

    const numSlices = Math.min(height, history.length);
    const palette = this.colorPalette();

    for (let y = 0; y < height; y++) {
      const sliceIdx = Math.floor((y / height) * numSlices);
      const slice = history[sliceIdx];
      if (!slice) continue;

      const mags = slice.magnitudesNormalized;
      const numMags = mags.length;

      for (let x = 0; x < width; x++) {
        const magIdx = Math.floor((x / width) * numMags);
        const val = mags[magIdx] ?? 0;

        const [r, g, b] = this.getColor(val, palette);
        const pIdx = (y * width + x) * 4;
        data[pIdx] = r;
        data[pIdx + 1] = g;
        data[pIdx + 2] = b;
        data[pIdx + 3] = 255;
      }
    }

    ctx.putImageData(imgData, 0, 0);
  }

  private getColor(val: number, palette: string): [number, number, number] {
    const v = Math.max(0, Math.min(1, val));

    switch (palette) {
      case 'TURBO': {
        const r = Math.sin(v * Math.PI - Math.PI / 2) * 127 + 128;
        const g = Math.sin(v * Math.PI * 1.5) * 127 + 128;
        const b = Math.cos(v * Math.PI) * 127 + 128;
        return [Math.round(r), Math.round(g), Math.round(b)];
      }
      case 'PHOSPHOR': {
        return [Math.round(v * 40), Math.round(v * 255), Math.round(v * 80)];
      }
      case 'ICE': {
        return [Math.round(v * 80), Math.round(v * 200), Math.round(v * 255)];
      }
      case 'AMBER': {
        return [Math.round(v * 255), Math.round(v * 160), Math.round(v * 20)];
      }
      case 'VIRIDIS':
      default: {
        const r = Math.floor(v * 240);
        const g = Math.floor(Math.sin(v * Math.PI) * 220);
        const b = Math.floor((1 - v) * 200 + 40);
        return [r, g, b];
      }
    }
  }
}
