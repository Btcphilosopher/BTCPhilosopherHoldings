import { ChangeDetectionStrategy, Component, inject, input, output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { SimulationEngine } from '../../services/simulation-engine';

export type NavTab = 
  | 'OVERVIEW'
  | 'CONSTELLATION'
  | 'RF_LINK'
  | 'SPECTRUM'
  | 'IQ_CONSTELLATION'
  | 'RECEIVER'
  | 'SIGNAL_DEBUGGER'
  | 'PROPAGATION'
  | 'COVERAGE'
  | 'POWER_THERMAL'
  | 'PASS_ANALYSIS'
  | 'SCENARIOS'
  | 'MONTE_CARLO'
  | 'VALIDATION';

@Component({
  selector: 'app-navbar',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, MatIconModule],
  template: `
    <header class="bg-[#0b111e]/90 backdrop-blur-md border-b border-slate-800/80 sticky top-0 z-50">
      <!-- Zone 1: Top Bar Contract (Wordmark, Nav Links, Primary Controls) -->
      <div class="max-w-7xl mx-auto px-4 sm:px-6 h-14 flex items-center justify-between gap-4">
        
        <!-- Zone 1: Brand title, single element wordmark in display style -->
        <div class="flex items-center gap-3 shrink-0">
          <div class="flex items-center gap-2">
            <span class="w-2.5 h-2.5 rounded-full bg-cyan-400 animate-pulse"></span>
            <span class="text-base font-bold tracking-wider text-slate-100 uppercase font-mono">
              ORBITAL-LF
            </span>
          </div>
          <span class="text-xs text-slate-500 hidden sm:inline font-mono">/ LF Broadcast Digital Twin</span>
        </div>

        <!-- Zone 2: Navigation Links -->
        <nav class="hidden lg:flex items-center gap-1 xl:gap-2 overflow-x-auto text-xs font-medium text-slate-400">
          @for (tab of primaryTabs; track tab.id) {
            <button
              (click)="selectTab(tab.id)"
              class="px-2.5 py-1.5 rounded-md transition-colors whitespace-nowrap cursor-pointer"
              [class.bg-cyan-950]="currentTab() === tab.id"
              [class.text-cyan-300]="currentTab() === tab.id"
              [class.border]="currentTab() === tab.id"
              [class.border-cyan-800]="currentTab() === tab.id"
              [class.hover:text-slate-200]="currentTab() !== tab.id">
              {{ tab.label }}
            </button>
          }

          <!-- More Dropdown for additional analysis tools -->
          <div class="relative group">
            <button 
              class="px-2.5 py-1.5 rounded-md transition-colors whitespace-nowrap cursor-pointer flex items-center gap-1 hover:text-slate-200"
              [class.text-cyan-300]="isSecondaryActive()">
              <span>Tools & Labs</span>
              <mat-icon class="text-sm scale-75">expand_more</mat-icon>
            </button>
            <div class="absolute left-0 top-full mt-1 w-48 bg-[#0f172a] border border-slate-800 rounded-lg shadow-xl py-1 hidden group-hover:block z-50">
              @for (tab of secondaryTabs; track tab.id) {
                <button
                  (click)="selectTab(tab.id)"
                  class="w-full text-left px-3 py-2 text-xs text-slate-300 hover:bg-slate-800 hover:text-cyan-300 flex items-center gap-2">
                  <mat-icon class="text-sm scale-75 text-slate-400">{{ tab.icon }}</mat-icon>
                  <span>{{ tab.label }}</span>
                </button>
              }
            </div>
          </div>
        </nav>

        <!-- Zone 3: Primary Actions & Simulation Time Controls -->
        <div class="flex items-center gap-2 shrink-0">
          <!-- Play / Pause Button -->
          <button
            (click)="engine.togglePlayPause()"
            class="p-1.5 rounded-lg border border-slate-700 bg-slate-900 text-slate-200 hover:bg-slate-800 hover:border-slate-600 transition-colors cursor-pointer flex items-center justify-center"
            [title]="engine.isRunning() ? 'Pause Simulation' : 'Resume Simulation'">
            <mat-icon class="text-sm">{{ engine.isRunning() ? 'pause' : 'play_arrow' }}</mat-icon>
          </button>

          <!-- Speed Multiplier -->
          <div class="flex items-center bg-slate-900 border border-slate-700 rounded-lg p-0.5 text-xs font-mono">
            @for (spd of [1, 5, 20, 60]; track spd) {
              <button
                (click)="engine.setTimeSpeed(spd)"
                class="px-1.5 py-0.5 rounded transition-colors cursor-pointer"
                [class.bg-cyan-500]="engine.timeSpeed() === spd"
                [class.text-slate-950]="engine.timeSpeed() === spd"
                [class.font-bold]="engine.timeSpeed() === spd"
                [class.text-slate-400]="engine.timeSpeed() !== spd">
                {{ spd }}x
              </button>
            }
          </div>

          <!-- Quick Scenario Selector -->
          <select
            [value]="engine.currentScenarioId()"
            (change)="onScenarioChange($event)"
            class="hidden sm:block bg-slate-900 border border-slate-700 text-slate-200 text-xs rounded-lg px-2 py-1.5 font-mono focus:outline-none focus:border-cyan-500 cursor-pointer max-w-[140px] truncate">
            @for (sc of engine.scenarios; track sc.id) {
              <option [value]="sc.id">
                {{ sc.name }}
              </option>
            }
          </select>
        </div>
      </div>

      <!-- Regulatory Boundary Notice Banner -->
      <div class="bg-amber-950/40 border-t border-b border-amber-800/40 px-4 py-1 text-[11px] text-amber-300/90 flex items-center justify-between overflow-hidden">
        <div class="max-w-7xl mx-auto w-full flex items-center justify-between gap-2">
          <div class="flex items-center gap-1.5 truncate">
            <mat-icon class="text-amber-400 text-xs scale-75">gavel</mat-icon>
            <span class="font-semibold tracking-wide uppercase font-mono">Simulation Environment:</span>
            <span class="truncate">Real RF transmission requires appropriate spectrum authorization, licensing and local regulatory compliance.</span>
          </div>
          <div class="hidden md:flex items-center gap-3 shrink-0 font-mono text-[10px] text-slate-400">
            <span>EPOCH: {{ formatSimTime(engine.simulationEpochMs()) }}</span>
            <span class="text-slate-600">|</span>
            <span [class.text-emerald-400]="engine.activeLinkBudget().linkStatus === 'LOCKED'"
                  [class.text-amber-400]="engine.activeLinkBudget().linkStatus === 'DEGRADED'"
                  [class.text-rose-400]="engine.activeLinkBudget().linkStatus === 'OUT_OF_VIEW'">
              ● {{ engine.activeLinkBudget().linkStatus }}
            </span>
          </div>
        </div>
      </div>

      <!-- Mobile navigation pills horizontal scroll -->
      <div class="lg:hidden flex items-center gap-1 px-4 py-1.5 overflow-x-auto bg-[#080d17] border-b border-slate-800/60 text-xs">
        @for (tab of allTabs; track tab.id) {
          <button
            (click)="selectTab(tab.id)"
            class="px-2.5 py-1 rounded-md transition-colors whitespace-nowrap cursor-pointer"
            [class.bg-cyan-950]="currentTab() === tab.id"
            [class.text-cyan-300]="currentTab() === tab.id"
            [class.text-slate-400]="currentTab() !== tab.id">
            {{ tab.label }}
          </button>
        }
      </div>
    </header>
  `
})
export class NavbarComponent {
  public engine = inject(SimulationEngine);

  public currentTab = input<NavTab>('OVERVIEW');
  public tabChange = output<NavTab>();

  public primaryTabs: { id: NavTab; label: string }[] = [
    { id: 'OVERVIEW', label: 'Overview' },
    { id: 'CONSTELLATION', label: '3D Constellation' },
    { id: 'RF_LINK', label: 'RF Link Budget' },
    { id: 'SPECTRUM', label: 'Spectrum & Waterfall' },
    { id: 'IQ_CONSTELLATION', label: 'I/Q Constellation' },
    { id: 'RECEIVER', label: 'Ground Receiver' },
    { id: 'SIGNAL_DEBUGGER', label: 'Signal Debugger' }
  ];

  public secondaryTabs: { id: NavTab; label: string; icon: string }[] = [
    { id: 'PROPAGATION', label: 'Propagation & Iono', icon: 'public' },
    { id: 'COVERAGE', label: 'Coverage Footprint', icon: 'radar' },
    { id: 'POWER_THERMAL', label: 'Power & Thermal', icon: 'solar_power' },
    { id: 'PASS_ANALYSIS', label: 'Pass Analysis', icon: 'timeline' },
    { id: 'SCENARIOS', label: 'Scenarios Matrix', icon: 'tune' },
    { id: 'MONTE_CARLO', label: 'Monte Carlo Trials', icon: 'casino' },
    { id: 'VALIDATION', label: 'Validation Suite', icon: 'verified' }
  ];

  public allTabs: { id: NavTab; label: string }[] = [
    ...this.primaryTabs,
    ...this.secondaryTabs
  ];

  public selectTab(tab: NavTab): void {
    this.tabChange.emit(tab);
  }

  public isSecondaryActive(): boolean {
    const cur = this.currentTab();
    return this.secondaryTabs.some(t => t.id === cur);
  }

  public onScenarioChange(event: Event): void {
    const select = event.target as HTMLSelectElement;
    if (select) {
      this.engine.loadScenario(select.value);
    }
  }

  public formatSimTime(epochMs: number): string {
    const d = new Date(epochMs);
    return d.toISOString().replace('T', ' ').substring(0, 19) + ' UTC';
  }
}
