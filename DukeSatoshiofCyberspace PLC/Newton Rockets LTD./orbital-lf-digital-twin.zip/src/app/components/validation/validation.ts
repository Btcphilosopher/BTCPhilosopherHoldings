import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { ValidationSuite, ValidationCase } from '../../services/validation';

@Component({
  selector: 'app-validation',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, MatIconModule],
  template: `
    <div class="space-y-6 font-mono text-xs">
      
      <!-- Section Header -->
      <div class="bg-[#0f172a] border border-slate-800 rounded-xl p-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h3 class="text-sm font-bold tracking-wider text-slate-100 uppercase flex items-center gap-2">
            <mat-icon class="text-cyan-400 text-lg">verified</mat-icon>
            Analytical Verification & Standard Equation Compliance Suite
          </h3>
          <p class="text-slate-400 mt-0.5">
            Validation of RF path loss, orbital dynamics, thermal noise & Shannon capacity against standard formulations
          </p>
        </div>

        <div class="flex items-center gap-3">
          <span class="px-3 py-1 rounded bg-emerald-950 border border-emerald-800 text-emerald-300 font-bold">
            {{ getPassCount() }} / {{ cases().length }} CASES PASS
          </span>
          <button
            (click)="runTests()"
            class="px-3 py-1.5 rounded-lg border border-slate-700 bg-slate-900 text-slate-200 hover:border-cyan-500 hover:text-cyan-300 transition-colors cursor-pointer flex items-center gap-1.5">
            <mat-icon class="text-xs scale-75">replay</mat-icon>
            <span>Re-evaluate</span>
          </button>
        </div>
      </div>

      <!-- Test Cases List Cards -->
      <div class="space-y-3">
        @for (c of cases(); track c.id) {
          <div class="bg-[#0f172a] border border-slate-800 rounded-xl p-5 space-y-3">
            
            <div class="flex flex-wrap items-center justify-between gap-2 border-b border-slate-800 pb-2">
              <div class="flex items-center gap-3">
                <span class="px-2 py-0.5 rounded text-[10px] font-bold bg-slate-800 text-cyan-300">
                  {{ c.id }}
                </span>
                <h4 class="text-sm font-bold text-slate-100">{{ c.name }}</h4>
                <span class="text-[10px] text-slate-500">({{ c.referenceStandard }})</span>
              </div>

              <span class="px-2.5 py-0.5 rounded text-xs font-bold"
                    [class.bg-emerald-950]="c.status === 'PASS'"
                    [class.text-emerald-400]="c.status === 'PASS'"
                    [class.border]="c.status === 'PASS'"
                    [class.border-emerald-800]="c.status === 'PASS'"
                    [class.bg-rose-950]="c.status === 'FAIL'"
                    [class.text-rose-400]="c.status === 'FAIL'">
                ● {{ c.status }} (Error: {{ c.relativeErrorPercent }}%)
              </span>
            </div>

            <!-- Formula & Math Readout -->
            <div class="grid grid-cols-1 md:grid-cols-3 gap-3 text-[11px]">
              <div class="p-2.5 bg-[#070b14] border border-slate-800/80 rounded-lg">
                <span class="text-slate-500 font-bold block text-[10px] uppercase">FORMULA:</span>
                <code class="text-amber-300 text-xs font-semibold">{{ c.formula }}</code>
              </div>

              <div class="p-2.5 bg-[#070b14] border border-slate-800/80 rounded-lg">
                <span class="text-slate-500 font-bold block text-[10px] uppercase">ANALYTICAL REFERENCE:</span>
                <span class="text-slate-100 font-bold">{{ c.expectedOutput }}</span>
              </div>

              <div class="p-2.5 bg-[#070b14] border border-slate-800/80 rounded-lg">
                <span class="text-slate-500 font-bold block text-[10px] uppercase">SIMULATED VALUE:</span>
                <span class="text-cyan-300 font-bold">{{ c.simulatedOutput }}</span>
              </div>
            </div>

            <!-- Notes -->
            <div class="text-[11px] text-slate-400 italic">
              {{ c.notes }}
            </div>
          </div>
        }
      </div>

    </div>
  `
})
export class ValidationComponent {
  private validationService = inject(ValidationSuite);
  public cases = signal<ValidationCase[]>([]);

  constructor() {
    this.runTests();
  }

  public runTests(): void {
    this.cases.set(this.validationService.runAllValidations());
  }

  public getPassCount(): number {
    return this.cases().filter(c => c.status === 'PASS').length;
  }
}
