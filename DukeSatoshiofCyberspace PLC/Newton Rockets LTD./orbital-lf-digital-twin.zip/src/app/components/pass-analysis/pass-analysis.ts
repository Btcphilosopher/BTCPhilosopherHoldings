import { ChangeDetectionStrategy, Component, ElementRef, OnDestroy, OnInit, ViewChild, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { SimulationEngine } from '../../services/simulation-engine';

@Component({
  selector: 'app-pass-analysis',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, MatIconModule],
  template: `
    <div class="space-y-6 font-mono text-xs">
      
      <!-- Section Header -->
      <div class="bg-[#0f172a] border border-slate-800 rounded-xl p-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h3 class="text-sm font-bold tracking-wider text-slate-100 uppercase flex items-center gap-2">
            <mat-icon class="text-cyan-400 text-lg">timeline</mat-icon>
            Orbital Pass Prediction & Dynamic Link Tracking Curves
          </h3>
          <p class="text-slate-400 mt-0.5">
            AOS / TCA / LOS trajectory, Doppler S-curves, C/N profile & receiver lock transitions
          </p>
        </div>

        <button
          (click)="engine.refreshPasses()"
          class="px-3 py-1.5 rounded-lg border border-slate-700 bg-slate-900 text-slate-200 hover:border-cyan-500 hover:text-cyan-300 transition-colors cursor-pointer flex items-center gap-1.5">
          <mat-icon class="text-xs scale-75">refresh</mat-icon>
          <span>Recalculate Passes</span>
        </button>
      </div>

      <!-- Upcoming 24-Hour Pass Schedule Table -->
      <div class="bg-[#0f172a] border border-slate-800 rounded-xl p-4 space-y-3">
        <div class="flex items-center justify-between border-b border-slate-800 pb-2">
          <h4 class="text-xs font-bold uppercase text-slate-300">
            24-Hour Pass Schedule ({{ engine.activeGroundStation().name }} ↔ {{ engine.activeSatellite().name }})
          </h4>
          <span class="text-[10px] text-cyan-400">MIN ELEVATION MASK: {{ engine.activeGroundStation().minElevationDeg }}°</span>
        </div>

        <div class="overflow-x-auto">
          <table class="w-full text-left">
            <thead>
              <tr class="text-[10px] uppercase text-slate-500 border-b border-slate-800">
                <th class="py-2 font-medium">AOS (UTC)</th>
                <th class="py-2 font-medium">TCA (UTC)</th>
                <th class="py-2 font-medium">LOS (UTC)</th>
                <th class="py-2 font-medium">Duration</th>
                <th class="py-2 font-medium">Max Elev</th>
                <th class="py-2 font-medium">Min Range</th>
                <th class="py-2 font-medium">Doppler Slew</th>
                <th class="py-2 font-medium">Peak C/N</th>
                <th class="py-2 font-medium text-right">Status</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-slate-800/60">
              @for (pass of engine.upcomingPasses(); track pass.aosEpochMs) {
                <tr class="hover:bg-slate-800/40">
                  <td class="py-2.5 font-semibold text-slate-200">
                    {{ formatUtcTime(pass.aosEpochMs) }}
                  </td>
                  <td class="py-2.5 text-slate-300">
                    {{ formatUtcTime(pass.tcaEpochMs) }}
                  </td>
                  <td class="py-2.5 text-slate-300">
                    {{ formatUtcTime(pass.losEpochMs) }}
                  </td>
                  <td class="py-2.5 text-cyan-300">
                    {{ (pass.durationSeconds / 60) | number:'1.1-1' }} min
                  </td>
                  <td class="py-2.5 font-bold text-slate-100">
                    {{ pass.maxElevationDeg }}°
                  </td>
                  <td class="py-2.5 text-slate-300">
                    {{ pass.minSlantRangeKm | number:'1.0-0' }} km
                  </td>
                  <td class="py-2.5 text-slate-300">
                    ±{{ pass.maxDopplerShiftHz }} Hz
                  </td>
                  <td class="py-2.5 font-bold text-emerald-400">
                    {{ pass.peakCnDb }} dB
                  </td>
                  <td class="py-2.5 text-right">
                    @if (pass.isCurrent) {
                      <span class="px-2 py-0.5 rounded bg-emerald-950 border border-emerald-800 text-emerald-300 font-bold">
                        IN PROGRESS
                      </span>
                    } @else {
                      <span class="text-slate-500">
                        UPCOMING
                      </span>
                    }
                  </td>
                </tr>
              }
            </tbody>
          </table>
        </div>
      </div>

      <!-- Live Dynamic Pass Curves Chart (Elevation, Doppler, RSSI, C/N, BER) -->
      <div class="bg-[#0f172a] border border-slate-800 rounded-xl p-5 space-y-4">
        <div class="flex flex-wrap items-center justify-between border-b border-slate-800 pb-3 gap-2">
          <div class="flex items-center gap-3">
            <span class="text-xs font-bold uppercase text-slate-300">Pass Overflight Trajectory Profiles</span>
            <div class="flex items-center gap-4 text-[11px]">
              <span class="text-cyan-400 font-bold">— Elevation (0°-90°)</span>
              <span class="text-emerald-400 font-bold">— C/N (0-25 dB)</span>
              <span class="text-amber-400 font-bold">— Doppler S-Curve</span>
            </div>
          </div>
          <span class="text-slate-500 text-[10px]">AOS TO LOS TIME WINDOW (10 MINUTES OVERHEAD)</span>
        </div>

        <div class="relative h-72 bg-[#070b14] border border-slate-800/80 rounded-xl overflow-hidden">
          <canvas #passCurveCanvas class="w-full h-full block"></canvas>
        </div>

        <!-- Explanation Footer -->
        <div class="p-3 bg-[#070b14] border border-slate-800/80 rounded-lg text-slate-400 space-y-1">
          <div class="text-slate-300 font-bold">RECEIVER ACQUISITION / LOSS OF LOCK THRESHOLD:</div>
          <p>
            The receiver executes carrier synchronization search at AOS (elevation > {{ engine.activeGroundStation().minElevationDeg }}°). 
            As slant range drops towards TCA, received power peaks at minimum path loss, establishing Costas loop PLL lock with coded BER < 10⁻⁶. 
            At LOS, as the satellite dips below the horizon mask, ionospheric obliquity and path loss cause the link margin to collapse, triggering loss of lock.
          </p>
        </div>
      </div>

    </div>
  `
})
export class PassAnalysisComponent implements OnInit, OnDestroy {
  @ViewChild('passCurveCanvas', { static: true }) canvasRef!: ElementRef<HTMLCanvasElement>;
  public engine = inject(SimulationEngine);

  private animFrameId: number | null = null;

  ngOnInit(): void {
    if (typeof window !== 'undefined') {
      this.startRenderLoop();
    }
  }

  ngOnDestroy(): void {
    if (this.animFrameId !== null) {
      cancelAnimationFrame(this.animFrameId);
    }
  }

  private startRenderLoop = (): void => {
    this.drawPassCurves();
    this.animFrameId = requestAnimationFrame(this.startRenderLoop);
  };

  private drawPassCurves(): void {
    const canvas = this.canvasRef.nativeElement;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const width = canvas.clientWidth || 800;
    const height = canvas.clientHeight || 280;

    if (canvas.width !== width || canvas.height !== height) {
      canvas.width = width;
      canvas.height = height;
    }

    ctx.fillStyle = '#070b14';
    ctx.fillRect(0, 0, width, height);

    // Grid lines
    ctx.strokeStyle = '#1e293b';
    ctx.lineWidth = 1;

    // Horizontal levels
    for (let i = 1; i <= 4; i++) {
      const y = (i / 5) * height;
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(width, y);
      ctx.stroke();
    }

    // Time ticks
    for (let i = 0; i <= 10; i++) {
      const x = (i / 10) * width;
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x, height);
      ctx.stroke();
      if (i > 0 && i < 10) {
        ctx.font = '9px JetBrains Mono, monospace';
        ctx.fillStyle = '#64748b';
        ctx.fillText(`T+${i}m`, x - 10, height - 6);
      }
    }

    // Draw Simulated Elevation Curve
    ctx.strokeStyle = '#06b6d4';
    ctx.lineWidth = 2.5;
    ctx.beginPath();
    for (let x = 0; x <= width; x++) {
      const tNorm = (x / width) * 2 - 1;
      const elevNorm = Math.max(0, 1 - tNorm * tNorm);
      const y = height - (elevNorm * 0.85 * height) - 20;
      if (x === 0) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
    }
    ctx.stroke();

    // Draw C/N Curve (Emerald)
    ctx.strokeStyle = '#10b981';
    ctx.lineWidth = 2;
    ctx.beginPath();
    for (let x = 0; x <= width; x++) {
      const tNorm = (x / width) * 2 - 1;
      const cnNorm = Math.max(0, 0.85 * (1 - tNorm * tNorm) + (Math.sin(x * 0.05) * 0.03));
      const y = height - (cnNorm * 0.8 * height) - 15;
      if (x === 0) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
    }
    ctx.stroke();

    // Draw Doppler S-Curve (Amber)
    ctx.strokeStyle = '#f59e0b';
    ctx.lineWidth = 2;
    ctx.beginPath();
    for (let x = 0; x <= width; x++) {
      const tNorm = (x / width) * 2 - 1;
      const dopplerNorm = -Math.atan(tNorm * 3.5) / (Math.PI / 2);
      const y = (height / 2) + (dopplerNorm * (height * 0.35));
      if (x === 0) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
    }
    ctx.stroke();

    // Current Time Progress Cursor Indicator
    const progressX = (width * 0.45);
    ctx.strokeStyle = '#f43f5e';
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.moveTo(progressX, 0);
    ctx.lineTo(progressX, height);
    ctx.stroke();

    ctx.font = '10px JetBrains Mono, monospace';
    ctx.fillStyle = '#f43f5e';
    ctx.fillText('CURRENT TIME (TCA - 30s)', progressX + 6, 20);
  }

  public formatUtcTime(epochMs: number): string {
    return new Date(epochMs).toISOString().substring(11, 19) + ' UTC';
  }
}
