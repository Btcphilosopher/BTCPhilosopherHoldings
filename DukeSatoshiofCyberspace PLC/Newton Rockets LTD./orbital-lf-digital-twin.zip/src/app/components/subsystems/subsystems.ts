import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { SimulationEngine } from '../../services/simulation-engine';

@Component({
  selector: 'app-subsystems',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, MatIconModule],
  template: `
    <div class="space-y-6">
      
      <!-- Section Header -->
      <div class="bg-[#0f172a] border border-slate-800 rounded-xl p-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 font-mono">
        <div>
          <h3 class="text-sm font-bold tracking-wider text-slate-100 uppercase flex items-center gap-2">
            <mat-icon class="text-cyan-400 text-lg">solar_power</mat-icon>
            Satellite Power Architecture & Thermal Subsystems
          </h3>
          <p class="text-xs text-slate-400 mt-0.5">
            Photovoltaic generation, DC bus regulation, PA dissipation & deep space radiative cooling
          </p>
        </div>

        <div class="flex items-center gap-2 text-xs">
          <span class="text-slate-400">Status:</span>
          <span class="px-2.5 py-1 rounded bg-emerald-950 border border-emerald-800 text-emerald-300 font-bold">
            ● {{ engine.activeSatellite().thermal.status }}
          </span>
        </div>
      </div>

      <!-- Main Two Column Grid: Power Subsystem vs Thermal Subsystem -->
      <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        <!-- Power Subsystem Card -->
        <div class="bg-[#0f172a] border border-slate-800 rounded-xl p-5 space-y-4 font-mono text-xs">
          <div class="flex items-center justify-between border-b border-slate-800 pb-2">
            <h4 class="text-xs font-bold uppercase text-slate-300 flex items-center gap-2">
              <mat-icon class="text-amber-400 text-sm">battery_charging_full</mat-icon>
              Electrical Power Subsystem (EPS)
            </h4>
            <span class="text-emerald-400 font-bold">28.2 V REGULATED BUS</span>
          </div>

          <!-- Generation vs Consumption Metrics -->
          <div class="grid grid-cols-2 gap-3">
            <div class="p-3 bg-[#070b14] border border-slate-800/80 rounded-lg space-y-1">
              <div class="text-[10px] text-slate-400 uppercase">Solar Array Generation</div>
              <div class="text-xl font-bold text-amber-300">
                {{ engine.activeSatellite().power.solarGenerationWatts }} W
              </div>
              <div class="text-[10px] text-slate-500">Area: {{ engine.activeSatellite().power.solarArrayAreaM2 }} m² (GaAs 30%)</div>
            </div>

            <div class="p-3 bg-[#070b14] border border-slate-800/80 rounded-lg space-y-1">
              <div class="text-[10px] text-slate-400 uppercase">Total DC Consumption</div>
              <div class="text-xl font-bold text-rose-400">
                {{ engine.activeSatellite().power.totalPowerDrawWatts | number:'1.1-1' }} W
              </div>
              <div class="text-[10px] text-slate-500">Net Surplus: +{{ (engine.activeSatellite().power.solarGenerationWatts - engine.activeSatellite().power.totalPowerDrawWatts) | number:'1.0-0' }} W</div>
            </div>
          </div>

          <!-- Power Breakdown Table -->
          <div class="space-y-2 pt-2 border-t border-slate-800/80">
            <div class="text-slate-400 font-bold uppercase text-[11px]">Subsystem DC Load Distribution</div>
            
            <div class="space-y-1.5 divide-y divide-slate-800/40">
              <div class="pt-1.5 flex items-center justify-between text-slate-300">
                <span>• RF Power Amplifier (P_DC = P_RF / η_PA)</span>
                <span class="font-bold text-slate-100">{{ engine.activeSatellite().power.paPowerDrawWatts | number:'1.1-1' }} W</span>
              </div>
              <div class="pt-1.5 flex items-center justify-between text-slate-300">
                <span>• High-Speed DSP / FPGA Engine</span>
                <span class="font-bold text-slate-100">{{ engine.activeSatellite().power.dspPowerDrawWatts }} W</span>
              </div>
              <div class="pt-1.5 flex items-center justify-between text-slate-300">
                <span>• Flight Computer & Attitude Control</span>
                <span class="font-bold text-slate-100">{{ engine.activeSatellite().power.avionicsPowerDrawWatts }} W</span>
              </div>
            </div>
          </div>

          <!-- Battery State of Charge Bar -->
          <div class="p-3 bg-[#070b14] border border-slate-800/80 rounded-lg space-y-1.5">
            <div class="flex items-center justify-between text-[11px]">
              <span class="text-slate-400">Battery State of Charge (LiFePO4)</span>
              <span class="text-emerald-400 font-bold">{{ engine.activeSatellite().power.batteryChargePercent }}% ({{ engine.activeSatellite().power.batteryCapacityWh }} Wh)</span>
            </div>
            <div class="w-full bg-slate-900 rounded-full h-2.5 overflow-hidden">
              <div class="bg-emerald-500 h-full rounded-full" [style.width.%]="engine.activeSatellite().power.batteryChargePercent"></div>
            </div>
          </div>
        </div>

        <!-- Thermal Subsystem Card -->
        <div class="bg-[#0f172a] border border-slate-800 rounded-xl p-5 space-y-4 font-mono text-xs">
          <div class="flex items-center justify-between border-b border-slate-800 pb-2">
            <h4 class="text-xs font-bold uppercase text-slate-300 flex items-center gap-2">
              <mat-icon class="text-rose-400 text-sm">thermostat</mat-icon>
              Thermal Control & Heat Dissipation
            </h4>
            <span class="text-cyan-400 font-bold">PASSIVE RADIATOR</span>
          </div>

          <!-- Thermal Metrics -->
          <div class="grid grid-cols-2 gap-3">
            <div class="p-3 bg-[#070b14] border border-slate-800/80 rounded-lg space-y-1">
              <div class="text-[10px] text-slate-400 uppercase">RF PA Baseplate Temp</div>
              <div class="text-xl font-bold"
                   [class.text-emerald-400]="engine.activeSatellite().thermal.paTemperatureC < 50"
                   [class.text-amber-400]="engine.activeSatellite().thermal.paTemperatureC >= 50 && engine.activeSatellite().thermal.paTemperatureC < 65"
                   [class.text-rose-400]="engine.activeSatellite().thermal.paTemperatureC >= 65">
                {{ engine.activeSatellite().thermal.paTemperatureC }} °C
              </div>
              <div class="text-[10px] text-slate-500">Max Limit: 75.0 °C</div>
            </div>

            <div class="p-3 bg-[#070b14] border border-slate-800/80 rounded-lg space-y-1">
              <div class="text-[10px] text-slate-400 uppercase">Thermal Margin</div>
              <div class="text-xl font-bold text-cyan-300">
                +{{ engine.activeSatellite().thermal.thermalMarginC }} °C
              </div>
              <div class="text-[10px] text-slate-500">Heat: {{ engine.activeSatellite().thermal.heatDissipationWatts | number:'1.1-1' }} W</div>
            </div>
          </div>

          <!-- Temperatures Breakdown Table -->
          <div class="space-y-2 pt-2 border-t border-slate-800/80">
            <div class="text-slate-400 font-bold uppercase text-[11px]">Sensor Node Temperatures</div>
            
            <div class="space-y-1.5 divide-y divide-slate-800/40">
              <div class="pt-1.5 flex items-center justify-between text-slate-300">
                <span>• Power Amplifier Core (Class-D FETs)</span>
                <span class="font-bold text-slate-100">{{ engine.activeSatellite().thermal.paTemperatureC }} °C</span>
              </div>
              <div class="pt-1.5 flex items-center justify-between text-slate-300">
                <span>• DSP / Digital Baseband Enclosure</span>
                <span class="font-bold text-slate-100">{{ engine.activeSatellite().thermal.dspTemperatureC }} °C</span>
              </div>
              <div class="pt-1.5 flex items-center justify-between text-slate-300">
                <span>• Deep-Space Zenith Optical Radiator</span>
                <span class="font-bold text-cyan-300">{{ engine.activeSatellite().thermal.radiatorTemperatureC }} °C</span>
              </div>
            </div>
          </div>

          <!-- Heat Dissipation Physics Formula Callout -->
          <div class="p-3 bg-[#070b14] border border-slate-800/80 rounded-lg space-y-1 text-slate-400 text-[11px]">
            <div class="text-slate-300 font-bold">THERMODYNAMIC EQUATION:</div>
            <div>P_heat = P_DC - P_RF = ({{ engine.activeSatellite().power.paPowerDrawWatts | number:'1.0-0' }} W - {{ engine.activeSatellite().transmitter.outputPowerWatts }} W) = <strong class="text-slate-100">{{ engine.activeSatellite().thermal.heatDissipationWatts | number:'1.1-1' }} W</strong></div>
          </div>
        </div>

      </div>

    </div>
  `
})
export class SubsystemsComponent {
  public engine = inject(SimulationEngine);
}
