import { ChangeDetectionStrategy, Component, ElementRef, OnDestroy, OnInit, ViewChild, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { SimulationEngine } from '../../services/simulation-engine';

@Component({
  selector: 'app-coverage',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, MatIconModule],
  template: `
    <div class="space-y-6">
      
      <!-- Section Header -->
      <div class="bg-[#0f172a] border border-slate-800 rounded-xl p-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 font-mono">
        <div>
          <h3 class="text-sm font-bold tracking-wider text-slate-100 uppercase flex items-center gap-2">
            <mat-icon class="text-cyan-400 text-lg">radar</mat-icon>
            RF Ground Footprint & Link-Budget Iso-Power Coverage Map
          </h3>
          <p class="text-xs text-slate-400 mt-0.5">
            Derived from orbital altitude, slant path geometry, antenna radiation pattern & receiver sensitivity
          </p>
        </div>

        <div class="flex items-center gap-3 text-xs">
          <span class="flex items-center gap-1.5"><span class="w-2.5 h-2.5 rounded-full bg-cyan-400"></span> Strong (C/N > 14dB)</span>
          <span class="flex items-center gap-1.5"><span class="w-2.5 h-2.5 rounded-full bg-emerald-500"></span> Receivable (> 6dB)</span>
          <span class="flex items-center gap-1.5"><span class="w-2.5 h-2.5 rounded-full bg-slate-600"></span> Geometric Horizon</span>
        </div>
      </div>

      <!-- 2D Equirectangular World Map Canvas -->
      <div class="bg-[#0b111e] border border-slate-800 rounded-xl p-4 space-y-3 font-mono">
        <div class="relative w-full h-[450px] bg-[#070b14] border border-slate-800/80 rounded-lg overflow-hidden">
          <canvas #coverageCanvas class="w-full h-full block"></canvas>
        </div>

        <!-- Footprint Geometry Metrics -->
        <div class="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs pt-1">
          <div class="p-3 bg-[#070b14] border border-slate-800/80 rounded-lg space-y-0.5">
            <div class="text-[10px] text-slate-400 uppercase">Sub-Satellite Lat/Lon</div>
            <div class="text-sm font-bold text-slate-100">
              {{ engine.activePosition().latitudeDeg | number:'1.2-2' }}°, {{ engine.activePosition().longitudeDeg | number:'1.2-2' }}°
            </div>
          </div>

          <div class="p-3 bg-[#070b14] border border-slate-800/80 rounded-lg space-y-0.5">
            <div class="text-[10px] text-slate-400 uppercase">Footprint Diameter</div>
            <div class="text-sm font-bold text-cyan-300">
              {{ (engine.activePosition().altitudeKm * 4.2) | number:'1.0-0' }} km
            </div>
          </div>

          <div class="p-3 bg-[#070b14] border border-slate-800/80 rounded-lg space-y-0.5">
            <div class="text-[10px] text-slate-400 uppercase">Horizon Mask Angle</div>
            <div class="text-sm font-bold text-slate-100">
              {{ engine.activeGeometry().earthHorizonAngleDeg | number:'1.1-1' }}°
            </div>
          </div>

          <div class="p-3 bg-[#070b14] border border-slate-800/80 rounded-lg space-y-0.5">
            <div class="text-[10px] text-slate-400 uppercase">Global Surface Coverage</div>
            <div class="text-sm font-bold text-emerald-400">
              {{ (1 - Math.cos((engine.activeGeometry().earthHorizonAngleDeg * Math.PI) / 180)) * 50 | number:'1.1-1' }}%
            </div>
          </div>
        </div>
      </div>

    </div>
  `
})
export class CoverageComponent implements OnInit, OnDestroy {
  @ViewChild('coverageCanvas', { static: true }) canvasRef!: ElementRef<HTMLCanvasElement>;
  public engine = inject(SimulationEngine);
  public Math = Math;

  private animFrameId: number | null = null;

  ngOnInit(): void {
    if (typeof window !== 'undefined') {
      this.startRenderLoop();
    }
  }

  ngOnDestroy(): void {
    if (this.animFrameId !== null) {
      cancelAnimationFrame(this.animFrameId);
    }
  }

  private startRenderLoop = (): void => {
    this.drawCoverageMap();
    this.animFrameId = requestAnimationFrame(this.startRenderLoop);
  };

  private drawCoverageMap(): void {
    const canvas = this.canvasRef.nativeElement;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const width = canvas.clientWidth || 800;
    const height = canvas.clientHeight || 450;

    if (canvas.width !== width || canvas.height !== height) {
      canvas.width = width;
      canvas.height = height;
    }

    // Clear background
    ctx.fillStyle = '#070b14';
    ctx.fillRect(0, 0, width, height);

    // Coordinate Grid Lines (Equirectangular projection: -180 to +180 Lon, +90 to -90 Lat)
    ctx.strokeStyle = '#1e293b';
    ctx.lineWidth = 1;

    // Latitudes (-60, -30, 0, 30, 60)
    for (let lat = -60; lat <= 60; lat += 30) {
      const y = ((90 - lat) / 180) * height;
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(width, y);
      ctx.stroke();
    }

    // Longitudes (-150, -100, -50, 0, 50, 100, 150)
    for (let lon = -150; lon <= 150; lon += 50) {
      const x = ((lon + 180) / 360) * width;
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x, height);
      ctx.stroke();
    }

    // Draw Continents Silhouette / Map Shapes
    ctx.strokeStyle = '#334155';
    ctx.fillStyle = '#0f1d33';
    this.drawSimpleContinents(ctx, width, height);

    // Draw Ground Stations
    this.engine.groundStations().forEach(gs => {
      const x = ((gs.longitudeDeg + 180) / 360) * width;
      const y = ((90 - gs.latitudeDeg) / 180) * height;

      ctx.fillStyle = gs.id === this.engine.activeStationId() ? '#818cf8' : '#64748b';
      ctx.beginPath();
      ctx.arc(x, y, 4, 0, Math.PI * 2);
      ctx.fill();

      ctx.font = '9px JetBrains Mono, monospace';
      ctx.fillStyle = gs.id === this.engine.activeStationId() ? '#c7d2fe' : '#94a3b8';
      ctx.fillText(gs.name.split(' ')[0], x + 6, y + 3);
    });

    // Draw Active Satellite & Footprint Contours
    const satPos = this.engine.activePosition();
    const satX = ((satPos.longitudeDeg + 180) / 360) * width;
    const satY = ((90 - satPos.latitudeDeg) / 180) * height;

    // Footprint radii in pixels (rough equirectangular map projection)
    const horizonRadiusDeg = Math.acos(6378.137 / (6378.137 + satPos.altitudeKm)) * (180 / Math.PI);
    const radiusPx = (horizonRadiusDeg / 360) * width;

    // 1. Geometric Horizon Footprint
    ctx.strokeStyle = '#38bdf8';
    ctx.setLineDash([4, 4]);
    ctx.beginPath();
    ctx.arc(satX, satY, Math.max(10, radiusPx), 0, Math.PI * 2);
    ctx.stroke();
    ctx.setLineDash([]);

    // 2. Receivable Footprint (C/N > 6 dB)
    ctx.fillStyle = 'rgba(16, 185, 129, 0.12)';
    ctx.strokeStyle = '#10b981';
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.arc(satX, satY, Math.max(8, radiusPx * 0.75), 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();

    // 3. Strong Signal Footprint (C/N > 14 dB)
    ctx.fillStyle = 'rgba(6, 182, 212, 0.25)';
    ctx.strokeStyle = '#06b6d4';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.arc(satX, satY, Math.max(5, radiusPx * 0.45), 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();

    // Sub-satellite Point Marker
    ctx.fillStyle = '#06b6d4';
    ctx.beginPath();
    ctx.arc(satX, satY, 5, 0, Math.PI * 2);
    ctx.fill();
  }

  private drawSimpleContinents(ctx: CanvasRenderingContext2D, w: number, h: number): void {
    // Simplified landmass polygonal representation for global radar map
    const toX = (lon: number) => ((lon + 180) / 360) * w;
    const toY = (lat: number) => ((90 - lat) / 180) * h;

    const shapes = [
      // North America
      [[-160, 70], [-130, 60], [-120, 35], [-105, 20], [-80, 25], [-75, 45], [-60, 50], [-80, 70]],
      // South America
      [[-80, 10], [-75, -20], [-65, -55], [-50, -35], [-35, -5], [-50, 5]],
      // Europe
      [[-10, 36], [0, 50], [15, 60], [30, 70], [45, 60], [30, 40], [10, 38]],
      // Africa
      [[-15, 35], [-15, 10], [10, 5], [15, -35], [35, -30], [50, 10], [35, 30], [0, 35]],
      // Asia
      [[40, 40], [60, 65], [120, 70], [140, 55], [120, 30], [100, 15], [80, 20], [55, 25]],
      // Australia
      [[115, -20], [115, -35], [145, -38], [150, -20], [130, -12]]
    ];

    shapes.forEach(shape => {
      ctx.beginPath();
      shape.forEach((pt, idx) => {
        const x = toX(pt[0]);
        const y = toY(pt[1]);
        if (idx === 0) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
      });
      ctx.closePath();
      ctx.fill();
      ctx.stroke();
    });
  }
}
