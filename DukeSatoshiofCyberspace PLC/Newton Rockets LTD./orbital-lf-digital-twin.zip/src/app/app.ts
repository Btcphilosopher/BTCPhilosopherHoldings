import { ChangeDetectionStrategy, Component, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NavbarComponent, NavTab } from './components/navbar/navbar';
import { OverviewComponent } from './components/overview/overview';
import { Constellation3dComponent } from './components/constellation-3d/constellation-3d';
import { RfLinkComponent } from './components/rf-link/rf-link';
import { SpectrumComponent } from './components/spectrum/spectrum';
import { ConstellationIqComponent } from './components/constellation-iq/constellation-iq';
import { ReceiverComponent } from './components/receiver/receiver';
import { SignalDebuggerComponent } from './components/signal-debugger/signal-debugger';
import { PropagationComponent } from './components/propagation/propagation';
import { CoverageComponent } from './components/coverage/coverage';
import { SubsystemsComponent } from './components/subsystems/subsystems';
import { PassAnalysisComponent } from './components/pass-analysis/pass-analysis';
import { ScenariosComponent } from './components/scenarios/scenarios';
import { MonteCarloComponent } from './components/monte-carlo/monte-carlo';
import { ValidationComponent } from './components/validation/validation';

@Component({
  selector: 'app-root',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [
    CommonModule,
    NavbarComponent,
    OverviewComponent,
    Constellation3dComponent,
    RfLinkComponent,
    SpectrumComponent,
    ConstellationIqComponent,
    ReceiverComponent,
    SignalDebuggerComponent,
    PropagationComponent,
    CoverageComponent,
    SubsystemsComponent,
    PassAnalysisComponent,
    ScenariosComponent,
    MonteCarloComponent,
    ValidationComponent
  ],
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class App {
  public activeTab = signal<NavTab>('OVERVIEW');

  public onTabChange(tab: NavTab): void {
    this.activeTab.set(tab);
    if (typeof window !== 'undefined') {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  }
}
