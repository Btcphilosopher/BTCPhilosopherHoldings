import { Injectable } from '@angular/core';
import { ChannelState, PropagationModelMode } from '../models/rf-link.model';

@Injectable({
  providedIn: 'root'
})
export class IonosphereService {

  /**
   * Evaluates complete low-frequency propagation channel physics.
   */
  public evaluateChannel(
    mode: PropagationModelMode,
    rfFrequencyHz: number,
    slantRangeKm: number,
    elevationDeg: number,
    subSatLatDeg: number,
    subSatLonDeg: number,
    stationLatDeg: number,
    stationLonDeg: number,
    solarActivitySfu = 130, // Solar Flux Units (e.g. 70 quiet, 150 active, 250 storm)
    sunspotNumber = 85,
    manMadeNoiseExcessDb = 0,
    timestampEpochMs = Date.now()
  ): ChannelState {

    // 1. Free Space Path Loss (FSPL): 20 log10(4*pi*R / lambda)
    const fKhz = rfFrequencyHz / 1000.0;
    const fMhz = rfFrequencyHz / 1e6;
    const safeRangeKm = Math.max(50.0, slantRangeKm);
    const freeSpaceLossDb = 20.0 * Math.log10(safeRangeKm) + 20.0 * Math.log10(fMhz) + 32.45;

    if (mode === 'IDEAL') {
      return {
        mode,
        slantRangeKm: safeRangeKm,
        freeSpaceLossDb: 0,
        ionosphericAbsorptionDb: 0,
        ionosphericPhaseShiftDeg: 0,
        ionosphericGroupDelayMicrosec: 0,
        faradayRotationDeg: 0,
        polarisationLossDb: 0,
        atmosphericAbsorptionDb: 0,
        groundConductivityLossDb: 0,
        manMadeNoiseExcessDb: 0,
        totalPathLossDb: 0,
        dopplerShiftHz: 0,
        multipathFactorDb: 0,
        solarActivitySfu,
        sunspotNumber,
        tecTotalElectronContentU: 5.0
      };
    }

    if (mode === 'FREE_SPACE') {
      return {
        mode,
        slantRangeKm: safeRangeKm,
        freeSpaceLossDb: Math.round(freeSpaceLossDb * 100) / 100,
        ionosphericAbsorptionDb: 0,
        ionosphericPhaseShiftDeg: 0,
        ionosphericGroupDelayMicrosec: 0,
        faradayRotationDeg: 0,
        polarisationLossDb: 0.5,
        atmosphericAbsorptionDb: 0,
        groundConductivityLossDb: 0,
        manMadeNoiseExcessDb: 0,
        totalPathLossDb: Math.round((freeSpaceLossDb + 0.5) * 100) / 100,
        dopplerShiftHz: 0,
        multipathFactorDb: 0,
        solarActivitySfu,
        sunspotNumber,
        tecTotalElectronContentU: 10.0
      };
    }

    // 2. Solar Zenith Angle & Diurnal Day/Night Cycle calculation
    const utcHours = new Date(timestampEpochMs).getUTCHours() + new Date(timestampEpochMs).getUTCMinutes() / 60.0;
    const subSolarLon = (12.0 - utcHours) * 15.0; // Approximate sub-solar longitude
    const subSolarLat = 5.0 * Math.sin((utcHours / 24.0) * 2 * Math.PI);

    // Mid-point latitude & longitude of ground-to-sat path
    const midLat = (stationLatDeg + subSatLatDeg) / 2.0;
    const midLon = (stationLonDeg + subSatLonDeg) / 2.0;

    // Solar zenith angle chi at midpoint
    const midLatRad = (midLat * Math.PI) / 180.0;
    const subSolarLatRad = (subSolarLat * Math.PI) / 180.0;
    const dLonRad = ((midLon - subSolarLon) * Math.PI) / 180.0;
    const cosChi = Math.sin(midLatRad) * Math.sin(subSolarLatRad) + Math.cos(midLatRad) * Math.cos(subSolarLatRad) * Math.cos(dLonRad);
    const isDay = cosChi > 0.0;
    const solarIllumination = Math.max(0.0, cosChi);

    // 3. Ionospheric Total Electron Content (TEC) in TECU (10^16 electrons/m^2)
    const baseTec = isDay ? (20.0 + 40.0 * solarIllumination * (solarActivitySfu / 100.0)) : (5.0 + 8.0 * (solarActivitySfu / 150.0));
    const safeElev = Math.max(5.0, elevationDeg);
    const obliquityFactor = 1.0 / Math.sin((safeElev * Math.PI) / 180.0);
    const tecTotalElectronContentU = baseTec * Math.min(3.5, obliquityFactor);

    // 4. Low-Frequency Ionospheric Absorption (D-region attenuation)
    const freqFactor = Math.pow(100.0 / Math.max(10.0, fKhz), 0.7);
    const dayAbsorptionBase = isDay ? (3.5 * solarIllumination * (solarActivitySfu / 100.0)) : 0.8;
    const ionosphericAbsorptionDb = Math.min(28.0, (dayAbsorptionBase * freqFactor * Math.sqrt(obliquityFactor)));

    // 5. Faraday Rotation & Polarisation Loss
    const faradayRotationDeg = (2.36e4 / Math.pow(rfFrequencyHz / 1e6, 2)) * (tecTotalElectronContentU * 0.05) % 360.0;
    const polarisationLossDb = 1.5 + 1.5 * Math.abs(Math.sin((faradayRotationDeg * Math.PI) / 180.0));

    // 6. Group Delay (dispersion): dt = 40.3 * TEC / (c * f^2)
    const c = 2.99792458e8;
    const ionosphericGroupDelayMicrosec = (40.3 * (tecTotalElectronContentU * 1e16)) / (c * Math.pow(rfFrequencyHz, 2)) * 1e6;
    const ionosphericPhaseShiftDeg = (360.0 * (rfFrequencyHz * ionosphericGroupDelayMicrosec * 1e-6)) % 360.0;

    // 7. Atmospheric Absorption
    const atmosphericAbsorptionDb = 0.15 * obliquityFactor;

    // 8. Ground Conductivity Loss
    const groundConductivityLossDb = 0.4 + (fKhz < 50 ? 0.8 : 0.2);

    // 9. Multipath & Fading
    const multipathFactorDb = mode === 'FULL_CHANNEL' ? (0.5 * Math.sin(timestampEpochMs / 3200.0) + 0.3 * Math.cos(timestampEpochMs / 1400.0)) : 0.0;

    let totalPathLossDb = freeSpaceLossDb;

    if (mode === 'IONOSPHERIC' || mode === 'REALISTIC_NOISE' || mode === 'FULL_CHANNEL') {
      totalPathLossDb += ionosphericAbsorptionDb + polarisationLossDb + atmosphericAbsorptionDb;
    }

    if (mode === 'FULL_CHANNEL') {
      totalPathLossDb += groundConductivityLossDb + Math.abs(multipathFactorDb);
    }

    return {
      mode,
      slantRangeKm: safeRangeKm,
      freeSpaceLossDb: Math.round(freeSpaceLossDb * 100) / 100,
      ionosphericAbsorptionDb: Math.round(ionosphericAbsorptionDb * 100) / 100,
      ionosphericPhaseShiftDeg: Math.round(ionosphericPhaseShiftDeg * 10) / 10,
      ionosphericGroupDelayMicrosec: Math.round(ionosphericGroupDelayMicrosec * 100) / 100,
      faradayRotationDeg: Math.round(faradayRotationDeg * 10) / 10,
      polarisationLossDb: Math.round(polarisationLossDb * 100) / 100,
      atmosphericAbsorptionDb: Math.round(atmosphericAbsorptionDb * 100) / 100,
      groundConductivityLossDb: Math.round(groundConductivityLossDb * 100) / 100,
      manMadeNoiseExcessDb: Math.round(manMadeNoiseExcessDb * 10) / 10,
      totalPathLossDb: Math.round(totalPathLossDb * 100) / 100,
      dopplerShiftHz: 0,
      multipathFactorDb: Math.round(multipathFactorDb * 100) / 100,
      solarActivitySfu,
      sunspotNumber,
      tecTotalElectronContentU: Math.round(tecTotalElectronContentU * 10) / 10
    };
  }

  /**
   * Atmospheric & Man-made noise figure according to ITU-R P.372 for low frequencies.
   */
  public calculateAtmosphericNoiseTempK(
    rfFrequencyHz: number,
    latitudeDeg: number,
    mode: PropagationModelMode,
    manMadeNoiseExcessDb = 0
  ): number {
    const fKhz = rfFrequencyHz / 1000.0;

    if (mode === 'IDEAL' || mode === 'FREE_SPACE') {
      return 290.0;
    }

    let famDb = 135.0 - 32.0 * Math.log10(Math.max(10.0, fKhz));

    const isTropical = Math.abs(latitudeDeg) < 30.0;
    if (isTropical) {
      famDb += 6.0;
    }

    if (mode === 'REALISTIC_NOISE' || mode === 'FULL_CHANNEL') {
      famDb += manMadeNoiseExcessDb;
    }

    const t0 = 290.0;
    const noiseTempK = t0 * Math.pow(10, famDb / 10.0);

    return Math.max(290.0, Math.min(1e8, noiseTempK));
  }
}
