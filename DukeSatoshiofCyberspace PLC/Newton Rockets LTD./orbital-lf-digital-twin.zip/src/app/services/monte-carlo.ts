import { Injectable, inject } from '@angular/core';
import { Satellite } from '../models/satellite.model';
import { GroundStation, GeometryObservation } from '../models/ground-station.model';
import { PropagationModelMode } from '../models/rf-link.model';
import { IonosphereService } from './ionosphere';
import { LinkBudgetService } from './link-budget';

export interface MonteCarloResult {
  trials: number;
  availableCount: number;
  availabilityPercent: number;
  outagePercent: number;
  meanCnDb: number;
  minCnDb: number;
  maxCnDb: number;
  meanBer: number;
  meanLinkMarginDb: number;
  cnHistogram: { binLabel: string; count: number; percentage: number }[];
  berHistogram: { binLabel: string; count: number; percentage: number }[];
}

@Injectable({
  providedIn: 'root'
})
export class MonteCarloService {

  private ionoService = inject(IonosphereService);
  private linkBudgetService = inject(LinkBudgetService);

  public runSimulation(
    satellite: Satellite,
    station: GroundStation,
    geometry: GeometryObservation,
    mode: PropagationModelMode,
    numTrials = 1000,
    solarActivityMean = 130,
    manMadeNoiseMeanDb = 5
  ): MonteCarloResult {
    let availableCount = 0;
    let sumCn = 0;
    let minCn = 999;
    let maxCn = -999;
    let sumBer = 0;
    let sumMargin = 0;

    // C/N Bins: < 0, 0-5, 5-10, 10-15, 15-20, 20-25, > 25
    const cnBins = [0, 0, 0, 0, 0, 0, 0];
    // BER Bins: < 1e-6, 1e-6 to 1e-4, 1e-4 to 1e-2, 1e-2 to 1e-1, > 1e-1
    const berBins = [0, 0, 0, 0, 0];

    for (let i = 0; i < numTrials; i++) {
      const solarSfu = Math.max(50, solarActivityMean + this.gaussianRandom(0, 25));
      const manMadeNoise = Math.max(0, manMadeNoiseMeanDb + this.gaussianRandom(0, 4));
      const txPowerVariation = satellite.transmitter.outputPowerWatts * (1.0 + this.gaussianRandom(0, 0.05));
      const pointingErrorDeg = Math.abs(this.gaussianRandom(0, 1.5));
      const rangeVariationKm = geometry.slantRangeKm * (1.0 + this.gaussianRandom(0, 0.01));

      const trialSat: Satellite = {
        ...satellite,
        transmitter: {
          ...satellite.transmitter,
          outputPowerWatts: Math.max(10, txPowerVariation)
        },
        antenna: {
          ...satellite.antenna,
          pointingLossDb: Math.max(0, pointingErrorDeg * 0.4)
        }
      };

      const trialGeom: GeometryObservation = {
        ...geometry,
        slantRangeKm: rangeVariationKm
      };

      const trialChannel = this.ionoService.evaluateChannel(
        mode,
        satellite.transmitter.rfFrequencyHz,
        trialGeom.slantRangeKm,
        trialGeom.elevationDeg,
        0, 0,
        station.latitudeDeg,
        station.longitudeDeg,
        solarSfu,
        80,
        manMadeNoise
      );

      const trialAntennaNoiseTempK = this.ionoService.calculateAtmosphericNoiseTempK(
        satellite.transmitter.rfFrequencyHz,
        station.latitudeDeg,
        mode,
        manMadeNoise
      );

      const link = this.linkBudgetService.calculateLinkBudget(
        trialSat,
        station,
        trialGeom,
        trialChannel,
        trialAntennaNoiseTempK
      );

      const cn = link.carrierToNoiseRatioDb;
      const ber = link.codedBer;
      const margin = link.linkMarginDb;

      sumCn += cn;
      if (cn < minCn) minCn = cn;
      if (cn > maxCn) maxCn = cn;
      sumBer += ber;
      sumMargin += margin;

      if (link.linkStatus === 'LOCKED') {
        availableCount++;
      }

      if (cn < 0) cnBins[0]++;
      else if (cn < 5) cnBins[1]++;
      else if (cn < 10) cnBins[2]++;
      else if (cn < 15) cnBins[3]++;
      else if (cn < 20) cnBins[4]++;
      else if (cn < 25) cnBins[5]++;
      else cnBins[6]++;

      if (ber < 1e-6) berBins[0]++;
      else if (ber < 1e-4) berBins[1]++;
      else if (ber < 1e-2) berBins[2]++;
      else if (ber < 1e-1) berBins[3]++;
      else berBins[4]++;
    }

    const availabilityPercent = (availableCount / numTrials) * 100.0;
    const outagePercent = 100.0 - availabilityPercent;

    const cnLabels = ['< 0 dB', '0 - 5 dB', '5 - 10 dB', '10 - 15 dB', '15 - 20 dB', '20 - 25 dB', '> 25 dB'];
    const berLabels = ['< 10⁻⁶ (Clean)', '10⁻⁶ - 10⁻⁴ (Good)', '10⁻⁴ - 10⁻² (Fair)', '10⁻² - 10⁻¹ (Degraded)', '> 10⁻¹ (Loss of Lock)'];

    const cnHistogram = cnBins.map((count, idx) => ({
      binLabel: cnLabels[idx],
      count,
      percentage: Math.round((count / numTrials) * 1000) / 10
    }));

    const berHistogram = berBins.map((count, idx) => ({
      binLabel: berLabels[idx],
      count,
      percentage: Math.round((count / numTrials) * 1000) / 10
    }));

    return {
      trials: numTrials,
      availableCount,
      availabilityPercent: Math.round(availabilityPercent * 10) / 10,
      outagePercent: Math.round(outagePercent * 10) / 10,
      meanCnDb: Math.round((sumCn / numTrials) * 10) / 10,
      minCnDb: Math.round(minCn * 10) / 10,
      maxCnDb: Math.round(maxCn * 10) / 10,
      meanBer: sumBer / numTrials,
      meanLinkMarginDb: Math.round((sumMargin / numTrials) * 10) / 10,
      cnHistogram,
      berHistogram
    };
  }

  private gaussianRandom(mean: number, stdev: number): number {
    const u1 = Math.max(1e-7, Math.random());
    const u2 = Math.random();
    const z0 = Math.sqrt(-2.0 * Math.log(u1)) * Math.cos(2.0 * Math.PI * u2);
    return mean + z0 * stdev;
  }
}
