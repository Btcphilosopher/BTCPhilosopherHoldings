import { Injectable, signal, computed, inject } from '@angular/core';
import { Satellite, TransmitterSpec } from '../models/satellite.model';
import { GroundStation, PassEvent } from '../models/ground-station.model';
import { LinkBudgetBreakdown, PropagationModelMode } from '../models/rf-link.model';
import { ComplexSample, FftFrame, WaterfallSlice, ConstellationPoint, EvmMetrics, ReceiverLockState, DecodedPacket, ChainDebugStage } from '../models/signal.model';
import { SimulationScenario } from '../models/scenario.model';
import { OrbitPropagator } from './orbit-propagator';
import { IonosphereService } from './ionosphere';
import { LinkBudgetService } from './link-budget';
import { DspEngineService } from './dsp-engine';

@Injectable({
  providedIn: 'root'
})
export class SimulationEngine {

  private orbitPropagator = inject(OrbitPropagator);
  private ionoService = inject(IonosphereService);
  private linkBudgetService = inject(LinkBudgetService);
  private dspEngine = inject(DspEngineService);

  // Default Constellation Satellites
  private readonly defaultSatellites: Satellite[] = [
    {
      id: 'SAT-01',
      name: 'ORBITAL-LF-1 (VLF Alpha)',
      noradId: 58921,
      massKg: 420,
      orbit: {
        semiMajorAxisKm: 7178.137,
        eccentricity: 0.0012,
        inclinationDeg: 98.6,
        raanDeg: 45.0,
        argOfPerigeeDeg: 30.0,
        meanAnomalyDeg: 120.0,
        epochEpochMs: Date.now() - 3600000
      },
      transmitter: {
        rfFrequencyHz: 18200,
        channelBandwidthHz: 2000,
        outputPowerWatts: 250,
        powerAmplifierEfficiency: 0.74,
        feedLossDb: 1.2,
        harmonicSuppressionDbc: -62,
        modulation: 'BPSK',
        symbolRateBaud: 1200,
        fecScheme: 'CONV_K7_R1_2',
        interleaving: true,
        active: true
      },
      antenna: {
        type: 'dipole',
        gainDbi: 2.15,
        beamwidthDeg: 110,
        efficiency: 0.22,
        physicalDimensionMeters: 40.0,
        polarisation: 'linear-vertical',
        pointingLossDb: 0.5
      },
      power: {
        solarArrayAreaM2: 6.4,
        solarCellEfficiency: 0.295,
        batteryCapacityWh: 2400,
        batteryChargePercent: 94.5,
        busVoltageVolts: 28.2,
        solarGenerationWatts: 1450,
        paPowerDrawWatts: 337.8,
        dspPowerDrawWatts: 42.0,
        avionicsPowerDrawWatts: 65.0,
        totalPowerDrawWatts: 444.8,
        inEclipse: false
      },
      thermal: {
        paTemperatureC: 38.4,
        dspTemperatureC: 32.1,
        radiatorTemperatureC: 18.5,
        heatDissipationWatts: 87.8,
        maxOperatingTempC: 75.0,
        thermalMarginC: 36.6,
        status: 'NOMINAL'
      },
      telemetrySequence: 18429,
      lastUpdateEpochMs: Date.now(),
      description: 'Primary low-frequency global broadcast satellite providing UTC time standard, ephemeris beacons, and space weather alerts.'
    },
    {
      id: 'SAT-02',
      name: 'ORBITAL-LF-2 (Sub-Iono Beta)',
      noradId: 58922,
      massKg: 380,
      orbit: {
        semiMajorAxisKm: 7028.137,
        eccentricity: 0.002,
        inclinationDeg: 82.5,
        raanDeg: 105.0,
        argOfPerigeeDeg: 60.0,
        meanAnomalyDeg: 280.0,
        epochEpochMs: Date.now() - 3600000
      },
      transmitter: {
        rfFrequencyHz: 40000,
        channelBandwidthHz: 4000,
        outputPowerWatts: 180,
        powerAmplifierEfficiency: 0.76,
        feedLossDb: 0.9,
        harmonicSuppressionDbc: -65,
        modulation: 'QPSK',
        symbolRateBaud: 2400,
        fecScheme: 'LDPC_R1_2',
        interleaving: true,
        active: true
      },
      antenna: {
        type: 'magnetic-loop',
        gainDbi: 1.8,
        beamwidthDeg: 120,
        efficiency: 0.35,
        physicalDimensionMeters: 25.0,
        polarisation: 'circular-rhcp',
        pointingLossDb: 0.4
      },
      power: {
        solarArrayAreaM2: 5.2,
        solarCellEfficiency: 0.30,
        batteryCapacityWh: 2000,
        batteryChargePercent: 91.2,
        busVoltageVolts: 28.0,
        solarGenerationWatts: 1280,
        paPowerDrawWatts: 236.8,
        dspPowerDrawWatts: 48.0,
        avionicsPowerDrawWatts: 60.0,
        totalPowerDrawWatts: 344.8,
        inEclipse: false
      },
      thermal: {
        paTemperatureC: 34.2,
        dspTemperatureC: 30.5,
        radiatorTemperatureC: 15.2,
        heatDissipationWatts: 56.8,
        maxOperatingTempC: 75.0,
        thermalMarginC: 40.8,
        status: 'NOMINAL'
      },
      telemetrySequence: 9241,
      lastUpdateEpochMs: Date.now(),
      description: 'High-throughput sub-ionospheric radio research platform with dual-polarised active magnetic loop transmitter.'
    },
    {
      id: 'SAT-03',
      name: 'ORBITAL-LF-3 (LF Gamma)',
      noradId: 58923,
      massKg: 450,
      orbit: {
        semiMajorAxisKm: 7578.137,
        eccentricity: 0.0008,
        inclinationDeg: 55.0,
        raanDeg: 195.0,
        argOfPerigeeDeg: 120.0,
        meanAnomalyDeg: 45.0,
        epochEpochMs: Date.now() - 3600000
      },
      transmitter: {
        rfFrequencyHz: 77500,
        channelBandwidthHz: 6000,
        outputPowerWatts: 300,
        powerAmplifierEfficiency: 0.78,
        feedLossDb: 1.0,
        harmonicSuppressionDbc: -68,
        modulation: 'GMSK',
        symbolRateBaud: 4800,
        fecScheme: 'REED_SOLOMON_255_223',
        interleaving: true,
        active: true
      },
      antenna: {
        type: 'helical',
        gainDbi: 3.5,
        beamwidthDeg: 95,
        efficiency: 0.48,
        physicalDimensionMeters: 18.0,
        polarisation: 'circular-rhcp',
        pointingLossDb: 0.3
      },
      power: {
        solarArrayAreaM2: 7.0,
        solarCellEfficiency: 0.30,
        batteryCapacityWh: 2800,
        batteryChargePercent: 97.0,
        busVoltageVolts: 28.4,
        solarGenerationWatts: 1650,
        paPowerDrawWatts: 384.6,
        dspPowerDrawWatts: 52.0,
        avionicsPowerDrawWatts: 70.0,
        totalPowerDrawWatts: 506.6,
        inEclipse: false
      },
      thermal: {
        paTemperatureC: 41.2,
        dspTemperatureC: 35.8,
        radiatorTemperatureC: 22.0,
        heatDissipationWatts: 84.6,
        maxOperatingTempC: 75.0,
        thermalMarginC: 33.8,
        status: 'NOMINAL'
      },
      telemetrySequence: 34102,
      lastUpdateEpochMs: Date.now(),
      description: 'Mid-inclination wide-area broadcast station transmitting high-precision longwave synchronization and scientific radar soundings.'
    },
    {
      id: 'SAT-04',
      name: 'ORBITAL-LF-4 (Equatorial Beacon)',
      noradId: 58924,
      massKg: 350,
      orbit: {
        semiMajorAxisKm: 7278.137,
        eccentricity: 0.001,
        inclinationDeg: 12.0,
        raanDeg: 280.0,
        argOfPerigeeDeg: 0.0,
        meanAnomalyDeg: 180.0,
        epochEpochMs: Date.now() - 3600000
      },
      transmitter: {
        rfFrequencyHz: 137500,
        channelBandwidthHz: 8000,
        outputPowerWatts: 150,
        powerAmplifierEfficiency: 0.80,
        feedLossDb: 0.8,
        harmonicSuppressionDbc: -70,
        modulation: 'OFDM',
        symbolRateBaud: 3200,
        fecScheme: 'TURBO_R1_3',
        interleaving: true,
        active: true
      },
      antenna: {
        type: 'dipole',
        gainDbi: 2.15,
        beamwidthDeg: 110,
        efficiency: 0.62,
        physicalDimensionMeters: 12.0,
        polarisation: 'linear-horizontal',
        pointingLossDb: 0.4
      },
      power: {
        solarArrayAreaM2: 4.8,
        solarCellEfficiency: 0.31,
        batteryCapacityWh: 1800,
        batteryChargePercent: 88.0,
        busVoltageVolts: 28.0,
        solarGenerationWatts: 1150,
        paPowerDrawWatts: 187.5,
        dspPowerDrawWatts: 55.0,
        avionicsPowerDrawWatts: 55.0,
        totalPowerDrawWatts: 297.5,
        inEclipse: false
      },
      thermal: {
        paTemperatureC: 31.0,
        dspTemperatureC: 28.4,
        radiatorTemperatureC: 12.0,
        heatDissipationWatts: 37.5,
        maxOperatingTempC: 75.0,
        thermalMarginC: 44.0,
        status: 'NOMINAL'
      },
      telemetrySequence: 14820,
      lastUpdateEpochMs: Date.now(),
      description: 'Tropical and equatorial ionospheric monitor transmitting multi-carrier OFDM test frames across the magnetic equator.'
    }
  ];

  // Default Ground Stations
  private readonly defaultStations: GroundStation[] = [
    {
      id: 'GS-SHEFFIELD',
      name: 'Sheffield Radio Lab',
      country: 'United Kingdom',
      latitudeDeg: 53.3811,
      longitudeDeg: -1.4701,
      altitudeMeters: 140,
      antenna: {
        type: 'magnetic-loop',
        gainDbi: 3.2,
        beamwidthDeg: 100,
        efficiency: 0.75,
        physicalDimensionMeters: 3.0,
        polarisation: 'linear-vertical',
        pointingLossDb: 0.2
      },
      lnaGainDb: 26.0,
      lnaNoiseFigureDb: 1.8,
      cableLossDb: 0.6,
      receiverNoiseTempK: 85,
      minElevationDeg: 5.0,
      filterBandwidthHz: 2400,
      adcSampleRateHz: 48000,
      adcBits: 24,
      active: true
    },
    {
      id: 'GS-LONDON',
      name: 'Chilbolton / London Observ.',
      country: 'United Kingdom',
      latitudeDeg: 51.1444,
      longitudeDeg: -1.4383,
      altitudeMeters: 90,
      antenna: {
        type: 'dipole',
        gainDbi: 2.15,
        beamwidthDeg: 120,
        efficiency: 0.70,
        physicalDimensionMeters: 15.0,
        polarisation: 'linear-vertical',
        pointingLossDb: 0.3
      },
      lnaGainDb: 24.0,
      lnaNoiseFigureDb: 2.1,
      cableLossDb: 0.8,
      receiverNoiseTempK: 95,
      minElevationDeg: 5.0,
      filterBandwidthHz: 2400,
      adcSampleRateHz: 48000,
      adcBits: 24,
      active: true
    },
    {
      id: 'GS-REYKJAVIK',
      name: 'Reykjavik Arctic Station',
      country: 'Iceland',
      latitudeDeg: 64.1466,
      longitudeDeg: -21.9426,
      altitudeMeters: 45,
      antenna: {
        type: 'helical',
        gainDbi: 4.5,
        beamwidthDeg: 80,
        efficiency: 0.82,
        physicalDimensionMeters: 6.0,
        polarisation: 'circular-rhcp',
        pointingLossDb: 0.1
      },
      lnaGainDb: 28.0,
      lnaNoiseFigureDb: 1.5,
      cableLossDb: 0.5,
      receiverNoiseTempK: 70,
      minElevationDeg: 3.0,
      filterBandwidthHz: 2400,
      adcSampleRateHz: 48000,
      adcBits: 24,
      active: true
    },
    {
      id: 'GS-NEWYORK',
      name: 'Brookhaven / Long Island',
      country: 'United States',
      latitudeDeg: 40.8687,
      longitudeDeg: -72.8778,
      altitudeMeters: 25,
      antenna: {
        type: 'magnetic-loop',
        gainDbi: 3.0,
        beamwidthDeg: 95,
        efficiency: 0.72,
        physicalDimensionMeters: 2.5,
        polarisation: 'linear-vertical',
        pointingLossDb: 0.2
      },
      lnaGainDb: 25.0,
      lnaNoiseFigureDb: 2.2,
      cableLossDb: 0.7,
      receiverNoiseTempK: 110,
      minElevationDeg: 5.0,
      filterBandwidthHz: 2400,
      adcSampleRateHz: 48000,
      adcBits: 24,
      active: true
    },
    {
      id: 'GS-SINGAPORE',
      name: 'Nanyang Equatorial Facility',
      country: 'Singapore',
      latitudeDeg: 1.3483,
      longitudeDeg: 103.6831,
      altitudeMeters: 18,
      antenna: {
        type: 'magnetic-loop',
        gainDbi: 3.4,
        beamwidthDeg: 90,
        efficiency: 0.78,
        physicalDimensionMeters: 3.5,
        polarisation: 'circular-rhcp',
        pointingLossDb: 0.2
      },
      lnaGainDb: 27.0,
      lnaNoiseFigureDb: 1.9,
      cableLossDb: 0.6,
      receiverNoiseTempK: 120,
      minElevationDeg: 5.0,
      filterBandwidthHz: 2400,
      adcSampleRateHz: 48000,
      adcBits: 24,
      active: true
    },
    {
      id: 'GS-TOKYO',
      name: 'Koganei Space Communications',
      country: 'Japan',
      latitudeDeg: 35.7056,
      longitudeDeg: 139.4903,
      altitudeMeters: 75,
      antenna: {
        type: 'phased-array',
        gainDbi: 5.0,
        beamwidthDeg: 65,
        efficiency: 0.85,
        physicalDimensionMeters: 8.0,
        polarisation: 'circular-rhcp',
        pointingLossDb: 0.1
      },
      lnaGainDb: 30.0,
      lnaNoiseFigureDb: 1.4,
      cableLossDb: 0.4,
      receiverNoiseTempK: 75,
      minElevationDeg: 4.0,
      filterBandwidthHz: 2400,
      adcSampleRateHz: 48000,
      adcBits: 24,
      active: true
    },
    {
      id: 'GS-SYDNEY',
      name: 'Mount Stromlo / Canberra',
      country: 'Australia',
      latitudeDeg: -35.3183,
      longitudeDeg: 149.0100,
      altitudeMeters: 770,
      antenna: {
        type: 'helical',
        gainDbi: 4.2,
        beamwidthDeg: 85,
        efficiency: 0.80,
        physicalDimensionMeters: 5.0,
        polarisation: 'circular-rhcp',
        pointingLossDb: 0.2
      },
      lnaGainDb: 26.0,
      lnaNoiseFigureDb: 1.7,
      cableLossDb: 0.5,
      receiverNoiseTempK: 80,
      minElevationDeg: 3.0,
      filterBandwidthHz: 2400,
      adcSampleRateHz: 48000,
      adcBits: 24,
      active: true
    },
    {
      id: 'GS-CAPETOWN',
      name: 'Hartebeesthoek / Hermanus',
      country: 'South Africa',
      latitudeDeg: -34.4258,
      longitudeDeg: 19.2244,
      altitudeMeters: 130,
      antenna: {
        type: 'magnetic-loop',
        gainDbi: 3.1,
        beamwidthDeg: 95,
        efficiency: 0.74,
        physicalDimensionMeters: 3.0,
        polarisation: 'linear-vertical',
        pointingLossDb: 0.2
      },
      lnaGainDb: 25.0,
      lnaNoiseFigureDb: 2.0,
      cableLossDb: 0.7,
      receiverNoiseTempK: 90,
      minElevationDeg: 5.0,
      filterBandwidthHz: 2400,
      adcSampleRateHz: 48000,
      adcBits: 24,
      active: true
    }
  ];

  // Predefined Scenarios
  public readonly scenarios: SimulationScenario[] = [
    {
      id: 'IDEAL_ORBIT',
      name: 'Nominal High-Elevation Pass',
      description: 'Standard orbital pass with clear line-of-sight and nominal ionospheric transparency.',
      category: 'NOMINAL',
      badge: 'Benchmark',
      satelliteId: 'SAT-01',
      groundStationId: 'GS-SHEFFIELD',
      propagationMode: 'FULL_CHANNEL',
      solarActivitySfu: 110,
      sunspotNumber: 70,
      txPowerScale: 1.0,
      manMadeNoiseExcessDb: 0,
      antennaMispointingDeg: 0,
      simulatedTimeSpeed: 1,
      notes: 'Clear signal lock with C/N > 17 dB and BER < 10⁻⁶ throughout peak elevation.'
    },
    {
      id: 'LOW_ELEVATION_PASS',
      name: 'Grazing Horizon Low-Elevation',
      description: 'Satellite passes below 12° elevation, increasing oblique ionospheric path length and ground multipath.',
      category: 'GEOMETRY',
      badge: 'Geometric Stress',
      satelliteId: 'SAT-01',
      groundStationId: 'GS-SHEFFIELD',
      propagationMode: 'FULL_CHANNEL',
      solarActivitySfu: 130,
      sunspotNumber: 85,
      txPowerScale: 1.0,
      manMadeNoiseExcessDb: 3,
      antennaMispointingDeg: 2,
      simulatedTimeSpeed: 5,
      notes: 'Tests receiver acquisition at low elevation limit (5° threshold).'
    },
    {
      id: 'IONOSPHERIC_DISTURBANCE',
      name: 'Solar Flare Sudden Ionospheric Disturbance',
      description: 'Class-M solar flare causes intense D-region electron density surge, spiking absorption by +18 dB.',
      category: 'ATMOSPHERIC',
      badge: 'Space Weather',
      satelliteId: 'SAT-01',
      groundStationId: 'GS-SHEFFIELD',
      propagationMode: 'FULL_CHANNEL',
      solarActivitySfu: 240,
      sunspotNumber: 180,
      txPowerScale: 1.0,
      manMadeNoiseExcessDb: 8,
      antennaMispointingDeg: 0,
      simulatedTimeSpeed: 1,
      notes: 'Simulates trans-ionospheric attenuation blackout and recovery.'
    },
    {
      id: 'HIGH_NOISE',
      name: 'Tropical Thunderstorm Atmospheric Noise',
      description: 'Severe lightning storm belt creates broadband VLF impulse noise floor elevation (+24 dB above kTB).',
      category: 'ATMOSPHERIC',
      badge: 'High QRN',
      satelliteId: 'SAT-01',
      groundStationId: 'GS-SINGAPORE',
      propagationMode: 'REALISTIC_NOISE',
      solarActivitySfu: 120,
      sunspotNumber: 75,
      txPowerScale: 1.0,
      manMadeNoiseExcessDb: 22,
      antennaMispointingDeg: 0,
      simulatedTimeSpeed: 1,
      notes: 'Demonstrates FEC coding gain resilience under degraded C/N.'
    },
    {
      id: 'DOPPLER_STRESS',
      name: 'Rapid Low-Earth Orbit Doppler Excursion',
      description: 'Fast 650 km LEO trajectory producing maximum radial velocity and steep Doppler S-curve slope.',
      category: 'HARDWARE_STRESS',
      badge: 'Costas Stress',
      satelliteId: 'SAT-02',
      groundStationId: 'GS-REYKJAVIK',
      propagationMode: 'FULL_CHANNEL',
      solarActivitySfu: 120,
      sunspotNumber: 80,
      txPowerScale: 1.0,
      manMadeNoiseExcessDb: 0,
      antennaMispointingDeg: 0,
      simulatedTimeSpeed: 5,
      notes: 'Tests Costas carrier recovery loop bandwidth and tracking slew rate.'
    },
    {
      id: 'LOW_TX_POWER',
      name: 'Eclipse Battery Conservation Mode',
      description: 'Satellite enters Earth penumbra; transmitter is throttled to 20% power (50 W) to conserve bus power.',
      category: 'HARDWARE_STRESS',
      badge: 'Low Power',
      satelliteId: 'SAT-01',
      groundStationId: 'GS-SHEFFIELD',
      propagationMode: 'FULL_CHANNEL',
      solarActivitySfu: 100,
      sunspotNumber: 60,
      txPowerScale: 0.2,
      manMadeNoiseExcessDb: 0,
      antennaMispointingDeg: 0,
      simulatedTimeSpeed: 1,
      notes: 'Link margin approaches threshold (0 dB margin test).'
    },
    {
      id: 'SATELLITE_HANDOVER',
      name: 'Constellation Intersatellite Handover',
      description: 'Demonstrates seamless ground receiver transition as SAT-01 sets below 5° and SAT-02 ascends above horizon.',
      category: 'NETWORK',
      badge: 'Multi-Sat',
      satelliteId: 'SAT-01',
      groundStationId: 'GS-LONDON',
      propagationMode: 'FULL_CHANNEL',
      solarActivitySfu: 120,
      sunspotNumber: 80,
      txPowerScale: 1.0,
      manMadeNoiseExcessDb: 2,
      antennaMispointingDeg: 0,
      simulatedTimeSpeed: 10,
      notes: 'Evaluates constellation visibility overlap and packet sequence continuity.'
    }
  ];

  // Core Reactive Signals
  public satellites = signal<Satellite[]>(this.defaultSatellites);
  public groundStations = signal<GroundStation[]>(this.defaultStations);
  public activeSatelliteId = signal<string>('SAT-01');
  public activeStationId = signal<string>('GS-SHEFFIELD');
  
  // Time and Execution Controls
  public isRunning = signal<boolean>(true);
  public timeSpeed = signal<number>(1);
  public simulationEpochMs = signal<number>(Date.now());
  public propagationMode = signal<PropagationModelMode>('FULL_CHANNEL');
  public currentScenarioId = signal<string>('IDEAL_ORBIT');

  // Space Weather Parameters
  public solarActivitySfu = signal<number>(125);
  public sunspotNumber = signal<number>(80);
  public manMadeNoiseExcessDb = signal<number>(0);
  public antennaMispointingDeg = signal<number>(0);

  // Computed Active Objects
  public activeSatellite = computed(() => {
    const list = this.satellites();
    const id = this.activeSatelliteId();
    return list.find(s => s.id === id) ?? list[0];
  });

  public activeGroundStation = computed(() => {
    const list = this.groundStations();
    const id = this.activeStationId();
    return list.find(g => g.id === id) ?? list[0];
  });

  // Orbital Observation and Dynamics Computed
  public activePosition = computed(() => {
    const sat = this.activeSatellite();
    const t = this.simulationEpochMs();
    return this.orbitPropagator.propagate(sat.orbit, t);
  });

  public activeGeometry = computed(() => {
    const pos = this.activePosition();
    const station = this.activeGroundStation();
    const sat = this.activeSatellite();
    return this.orbitPropagator.calculateGeometry(pos, station, sat.transmitter.rfFrequencyHz);
  });

  // Channel and Link Budget Computed
  public activeChannel = computed(() => {
    const sat = this.activeSatellite();
    const station = this.activeGroundStation();
    const geom = this.activeGeometry();
    const pos = this.activePosition();
    const mode = this.propagationMode();
    const sfu = this.solarActivitySfu();
    const ssn = this.sunspotNumber();
    const noiseExcess = this.manMadeNoiseExcessDb();
    const t = this.simulationEpochMs();

    return this.ionoService.evaluateChannel(
      mode,
      sat.transmitter.rfFrequencyHz,
      geom.slantRangeKm,
      geom.elevationDeg,
      pos.latitudeDeg,
      pos.longitudeDeg,
      station.latitudeDeg,
      station.longitudeDeg,
      sfu,
      ssn,
      noiseExcess,
      t
    );
  });

  public activeLinkBudget = computed(() => {
    const sat = this.activeSatellite();
    const station = this.activeGroundStation();
    const geom = this.activeGeometry();
    const channel = this.activeChannel();
    const mode = this.propagationMode();
    const noiseExcess = this.manMadeNoiseExcessDb();

    const antennaNoiseTempK = this.ionoService.calculateAtmosphericNoiseTempK(
      sat.transmitter.rfFrequencyHz,
      station.latitudeDeg,
      mode,
      noiseExcess
    );

    return this.linkBudgetService.calculateLinkBudget(
      sat,
      station,
      geom,
      channel,
      antennaNoiseTempK
    );
  });

  // DSP and Signal Outputs
  public iqSamples = signal<ComplexSample[]>([]);
  public fftFrame = signal<FftFrame | null>(null);
  public waterfallHistory = signal<WaterfallSlice[]>([]);
  public constellationPoints = signal<ConstellationPoint[]>([]);
  public evmMetrics = signal<EvmMetrics>({
    evmRmsPercent: 3.4,
    evmPeakPercent: 7.2,
    phaseErrorDeg: 1.8,
    frequencyOffsetHz: 0.12,
    snrDb: 17.8
  });
  public receiverLockState = signal<ReceiverLockState>('LOCK');
  public decodedPackets = signal<DecodedPacket[]>([]);
  public debugChainStages = signal<ChainDebugStage[]>([]);
  public upcomingPasses = signal<PassEvent[]>([]);

  // Simulation Interval Timer
  private sampleCounter = 0;

  constructor() {
    this.initSimulationLoop();
    this.refreshPasses();
    this.seedInitialPackets();
  }

  private initSimulationLoop(): void {
    if (typeof window !== 'undefined') {
      window.setInterval(() => {
        if (this.isRunning()) {
          const stepMs = 50 * this.timeSpeed();
          this.simulationEpochMs.update(t => t + stepMs);
          this.tickDsp();
        }
      }, 50);
    }
  }

  private tickDsp(): void {
    const sat = this.activeSatellite();
    const link = this.activeLinkBudget();
    const geom = this.activeGeometry();

    // 1. Generate IQ Samples
    const samples = this.dspEngine.generateIqStream(
      sat.transmitter,
      link,
      geom.dopplerShiftHz,
      256,
      48000
    );
    this.iqSamples.set(samples);

    // 2. Compute FFT
    const fft = this.dspEngine.computeFft(
      samples,
      512,
      'Hanning',
      sat.transmitter.rfFrequencyHz,
      24000,
      link.rxPowerDbm,
      link.thermalNoisePowerDbm
    );
    this.fftFrame.set(fft);

    // 3. Waterfall update (keep last 80 slices)
    const slice = this.dspEngine.generateWaterfallSlice(fft, -135, -65);
    this.waterfallHistory.update(history => {
      const updated = [slice, ...history];
      return updated.slice(0, 80);
    });

    // 4. Constellation extraction
    const { points, evm } = this.dspEngine.extractConstellation(
      samples,
      sat.transmitter.modulation,
      link.carrierToNoiseRatioDb,
      geom.dopplerShiftHz
    );
    this.constellationPoints.set(points);
    this.evmMetrics.set(evm);

    // 5. Update receiver lock state machine
    const lockState = this.dspEngine.updateReceiverState(link, geom.isReceivable);
    this.receiverLockState.set(lockState);

    // 6. Build debug chain
    const chain = this.dspEngine.buildDebugChain(
      sat.transmitter,
      link,
      geom.dopplerShiftHz,
      lockState
    );
    this.debugChainStages.set(chain);

    // 7. Periodic packet decoding
    this.sampleCounter++;
    if (this.sampleCounter % 20 === 0 && lockState === 'DECODE') {
      this.emitBroadcastPacket(sat, link);
    }
  }

  private seedInitialPackets(): void {
    const sat = this.activeSatellite();
    const now = Date.now();
    const packets: DecodedPacket[] = [
      {
        id: 'PKT-18429',
        frameNumber: 18429,
        satelliteId: sat.id,
        timestampUtc: new Date(now - 4000).toISOString(),
        payloadType: 'TIME_SYNC',
        rssiDbm: -91.4,
        cnDb: 17.8,
        ebN0Db: 14.6,
        estimatedBer: 1e-7,
        rawBitsHex: '1ACFFC1D 53415430 310047FE 00018429 66FA8211 9B4C',
        payloadContent: {
          utcEpochMs: now - 4000,
          ppsOffsetNanoseconds: 14,
          leapSeconds: 18,
          masterClockId: 'CESIUM-BEAM-04'
        },
        fecStatus: 'PASS',
        crcStatus: 'PASS',
        decodedAtEpochMs: now - 4000
      },
      {
        id: 'PKT-18428',
        frameNumber: 18428,
        satelliteId: sat.id,
        timestampUtc: new Date(now - 8000).toISOString(),
        payloadType: 'EPHEMERIS',
        rssiDbm: -92.1,
        cnDb: 17.2,
        ebN0Db: 14.1,
        estimatedBer: 1e-7,
        rawBitsHex: '1ACFFC1D 53415430 310047FD 00018428 1278C002 44EA',
        payloadContent: {
          semiMajorAxisKm: sat.orbit.semiMajorAxisKm,
          eccentricity: sat.orbit.eccentricity,
          inclinationDeg: sat.orbit.inclinationDeg,
          trueAnomalyDeg: 124.5,
          subSatLat: 54.12,
          subSatLon: -2.34
        },
        fecStatus: 'PASS',
        crcStatus: 'PASS',
        decodedAtEpochMs: now - 8000
      },
      {
        id: 'PKT-18427',
        frameNumber: 18427,
        satelliteId: sat.id,
        timestampUtc: new Date(now - 12000).toISOString(),
        payloadType: 'SPACE_WEATHER',
        rssiDbm: -92.8,
        cnDb: 16.5,
        ebN0Db: 13.5,
        estimatedBer: 2e-7,
        rawBitsHex: '1ACFFC1D 53415430 310047FC 00018427 889104AC 3321',
        payloadContent: {
          solarFlux107: 125,
          sunspotCount: 80,
          geomagneticKpIndex: 2.3,
          f2LayerCritFreqMhz: 4.8
        },
        fecStatus: 'PASS',
        crcStatus: 'PASS',
        decodedAtEpochMs: now - 12000
      }
    ];
    this.decodedPackets.set(packets);
  }

  private emitBroadcastPacket(sat: Satellite, link: LinkBudgetBreakdown): void {
    const seq = sat.telemetrySequence + 1;
    sat.telemetrySequence = seq;

    const payloadTypes: DecodedPacket['payloadType'][] = ['TIME_SYNC', 'EPHEMERIS', 'SPACE_WEATHER', 'NAV_ALERT', 'SCIENCE_TELEMETRY', 'PUBLIC_BROADCAST'];
    const type = payloadTypes[seq % payloadTypes.length];
    const now = Date.now();

    const newPacket: DecodedPacket = {
      id: `PKT-${seq}`,
      frameNumber: seq,
      satelliteId: sat.id,
      timestampUtc: new Date(now).toISOString(),
      payloadType: type,
      rssiDbm: link.rxPowerDbm,
      cnDb: link.carrierToNoiseRatioDb,
      ebN0Db: link.energyPerBitToNoiseDensityDb,
      estimatedBer: link.codedBer,
      rawBitsHex: `1ACFFC1D ${sat.id.replace('-', '')} ${seq.toString(16).toUpperCase().padStart(8, '0')} ${Math.floor(Math.random() * 0xFFFFFFFF).toString(16).toUpperCase()}`,
      payloadContent: {
        sequence: seq,
        broadcastTime: new Date(now).toUTCString(),
        transmitterPowerWatts: sat.transmitter.outputPowerWatts,
        frequencyKhz: sat.transmitter.rfFrequencyHz / 1000,
        modulation: sat.transmitter.modulation,
        fec: sat.transmitter.fecScheme,
        linkStatus: link.linkStatus
      },
      fecStatus: link.codedBer < 1e-4 ? 'PASS' : (link.codedBer < 1e-2 ? 'CORRECTED' : 'FAILED'),
      crcStatus: link.codedBer < 1e-3 ? 'PASS' : 'FAIL',
      decodedAtEpochMs: now
    };

    this.decodedPackets.update(pkts => [newPacket, ...pkts.slice(0, 40)]);
  }

  public selectSatellite(id: string): void {
    this.activeSatelliteId.set(id);
    this.refreshPasses();
  }

  public selectGroundStation(id: string): void {
    this.activeStationId.set(id);
    this.refreshPasses();
  }

  public setTimeSpeed(speed: number): void {
    this.timeSpeed.set(speed);
  }

  public togglePlayPause(): void {
    this.isRunning.update(r => !r);
  }

  public setPropagationMode(mode: PropagationModelMode): void {
    this.propagationMode.set(mode);
  }

  public loadScenario(scenarioId: string): void {
    const sc = this.scenarios.find(s => s.id === scenarioId);
    if (!sc) return;

    this.currentScenarioId.set(scenarioId);
    this.activeSatelliteId.set(sc.satelliteId);
    this.activeStationId.set(sc.groundStationId);
    this.propagationMode.set(sc.propagationMode);
    this.solarActivitySfu.set(sc.solarActivitySfu);
    this.sunspotNumber.set(sc.sunspotNumber);
    this.manMadeNoiseExcessDb.set(sc.manMadeNoiseExcessDb);
    this.antennaMispointingDeg.set(sc.antennaMispointingDeg);
    this.timeSpeed.set(sc.simulatedTimeSpeed);

    this.satellites.update(list => {
      return list.map(s => {
        if (s.id === sc.satelliteId) {
          const origPower = this.defaultSatellites.find(d => d.id === s.id)?.transmitter.outputPowerWatts ?? 250;
          return {
            ...s,
            transmitter: {
              ...s.transmitter,
              outputPowerWatts: Math.round(origPower * sc.txPowerScale)
            }
          };
        }
        return s;
      });
    });

    this.refreshPasses();
  }

  public refreshPasses(): void {
    const sat = this.activeSatellite();
    const station = this.activeGroundStation();
    const t = this.simulationEpochMs();
    const passes = this.orbitPropagator.predictPasses(
      sat.orbit,
      station,
      sat.transmitter.rfFrequencyHz,
      t,
      24
    );
    this.upcomingPasses.set(passes);
  }

  public updateTransmitterSettings(updates: Partial<TransmitterSpec>): void {
    const currentId = this.activeSatelliteId();
    this.satellites.update(list => {
      return list.map(sat => {
        if (sat.id === currentId) {
          return {
            ...sat,
            transmitter: {
              ...sat.transmitter,
              ...updates
            }
          };
        }
        return sat;
      });
    });
  }

  public updateGroundStationSettings(updates: Partial<GroundStation>): void {
    const currentId = this.activeStationId();
    this.groundStations.update(list => {
      return list.map(gs => {
        if (gs.id === currentId) {
          return {
            ...gs,
            ...updates
          };
        }
        return gs;
      });
    });
  }

  public addCustomSatellite(newSat: Satellite): void {
    this.satellites.update(list => [...list, newSat]);
    this.selectSatellite(newSat.id);
  }

  public addCustomGroundStation(newGs: GroundStation): void {
    this.groundStations.update(list => [...list, newGs]);
    this.selectGroundStation(newGs.id);
  }
}
