import { Injectable } from '@angular/core';
import { Satellite } from '../models/satellite.model';
import { GroundStation, GeometryObservation } from '../models/ground-station.model';
import { ChannelState, LinkBudgetBreakdown } from '../models/rf-link.model';

const BOLTZMANN_K = 1.380649e-23; // Joules / Kelvin

@Injectable({
  providedIn: 'root'
})
export class LinkBudgetService {

  /**
   * Calculates the complete end-to-end RF link budget with noise, SNR, BER, and link margin.
   */
  public calculateLinkBudget(
    satellite: Satellite,
    station: GroundStation,
    geometry: GeometryObservation,
    channel: ChannelState,
    antennaNoiseTempK: number
  ): LinkBudgetBreakdown {
    const tx = satellite.transmitter;
    const txPowerWatts = tx.outputPowerWatts;
    const txPowerDbw = 10.0 * Math.log10(Math.max(0.001, txPowerWatts));
    const txPowerDbm = txPowerDbw + 30.0;

    // Transmit antenna gain & EIRP
    const txAntennaGainDbi = satellite.antenna.gainDbi;
    const txFeedLossDb = tx.feedLossDb;
    const eirpDbm = txPowerDbm + txAntennaGainDbi - txFeedLossDb;

    // Pointing loss from satellite and ground antenna
    const pointingLossDb = satellite.antenna.pointingLossDb + (geometry.elevationDeg < 10 ? 1.0 : 0.2);

    // Ground station reception
    const rxAntennaGainDbi = station.antenna.gainDbi;
    const rxFeedLossDb = station.cableLossDb;

    // Total propagation path loss
    const totalPathLossDb = channel.totalPathLossDb;

    // Received Power P_rx
    const rxPowerDbm = eirpDbm - totalPathLossDb - pointingLossDb + rxAntennaGainDbi - rxFeedLossDb;
    const rxPowerDbw = rxPowerDbm - 30.0;
    const rxPowerWatts = Math.pow(10.0, rxPowerDbw / 10.0);

    // Receiver System Noise Temperature T_sys
    // T_sys = T_A / L_line + T_line * (1 - 1/L_line) + T_LNA + T_rx / G_LNA
    const lnaLinearGain = Math.pow(10.0, station.lnaGainDb / 10.0);
    const lineLinearLoss = Math.pow(10.0, rxFeedLossDb / 10.0);
    const lnaNoiseTempK = 290.0 * (Math.pow(10.0, station.lnaNoiseFigureDb / 10.0) - 1.0);
    const lineNoiseTempK = 290.0 * (1.0 - 1.0 / lineLinearLoss);
    const receiverNoiseTempK = station.receiverNoiseTempK;

    const systemNoiseTempK = (antennaNoiseTempK / lineLinearLoss) + lineNoiseTempK + lnaNoiseTempK + (receiverNoiseTempK / lnaLinearGain);
    const receiverNoiseFigureDb = station.lnaNoiseFigureDb + rxFeedLossDb;

    // Receiver Noise Power N = k * T_sys * B
    const noiseBandwidthHz = tx.channelBandwidthHz;
    const thermalNoisePowerWatts = BOLTZMANN_K * systemNoiseTempK * noiseBandwidthHz;
    const thermalNoisePowerDbm = 10.0 * Math.log10(Math.max(1e-30, thermalNoisePowerWatts)) + 30.0;

    // Carrier-to-Noise Ratio (C/N)
    const carrierToNoiseRatioDb = rxPowerDbm - thermalNoisePowerDbm;

    // Carrier-to-Noise Density Ratio (C/N0)
    const carrierToNoiseDensityDbHz = carrierToNoiseRatioDb + 10.0 * Math.log10(Math.max(1.0, noiseBandwidthHz));

    // Modulation and Data Rates
    const bitsPerSymbol = this.getBitsPerSymbol(tx.modulation);
    const rawBitRateBps = tx.symbolRateBaud * bitsPerSymbol;
    const codeRate = this.getCodeRate(tx.fecScheme);
    const informationBitRateBps = rawBitRateBps * codeRate;

    // Energy per bit to noise density (Eb/N0)
    // Eb/N0 = C/N0 - 10 log10(R_bit)
    const energyPerBitToNoiseDensityDb = carrierToNoiseDensityDbHz - 10.0 * Math.log10(Math.max(1.0, rawBitRateBps));

    // Required Eb/N0 for 1e-5 BER with current modulation
    const requiredEbN0Db = this.getRequiredEbN0(tx.modulation, tx.fecScheme);
    const linkMarginDb = energyPerBitToNoiseDensityDb - requiredEbN0Db;

    // Shannon Channel Capacity Limit: C = B * log2(1 + S/N)
    const snrLinear = Math.pow(10.0, carrierToNoiseRatioDb / 10.0);
    const channelCapacityBps = noiseBandwidthHz * (Math.log(1.0 + Math.max(0, snrLinear)) / Math.LN2);

    // Bit Error Rates (Raw vs Coded)
    const rawBer = this.calculateRawBer(tx.modulation, energyPerBitToNoiseDensityDb);
    const codedBer = this.calculateCodedBer(rawBer, tx.fecScheme, energyPerBitToNoiseDensityDb);

    // Packet & Frame Error Rates (1024-bit frame payload)
    const frameBits = 1024;
    const frameErrorRate = 1.0 - Math.pow(1.0 - Math.min(1.0, codedBer), frameBits);
    const packetErrorRate = Math.min(1.0, Math.max(0.0, frameErrorRate));

    // Link lock state assessment
    let linkStatus: 'LOCKED' | 'DEGRADED' | 'SEARCHING' | 'OUT_OF_VIEW' = 'SEARCHING';
    if (!geometry.isVisible || geometry.elevationDeg < 0) {
      linkStatus = 'OUT_OF_VIEW';
    } else if (carrierToNoiseRatioDb >= 6.0 && linkMarginDb >= 0.0 && codedBer < 1e-3) {
      linkStatus = 'LOCKED';
    } else if (carrierToNoiseRatioDb >= 1.0) {
      linkStatus = 'DEGRADED';
    } else {
      linkStatus = 'SEARCHING';
    }

    return {
      txPowerWatts,
      txPowerDbm: Math.round(txPowerDbm * 10) / 10,
      txPowerDbw: Math.round(txPowerDbw * 10) / 10,
      txAntennaGainDbi,
      txFeedLossDb,
      eirpDbm: Math.round(eirpDbm * 10) / 10,
      freeSpacePathLossDb: channel.freeSpaceLossDb,
      ionosphericLossDb: channel.ionosphericAbsorptionDb,
      polarisationLossDb: channel.polarisationLossDb,
      atmosphericLossDb: channel.atmosphericAbsorptionDb,
      pointingLossDb: Math.round(pointingLossDb * 10) / 10,
      rxAntennaGainDbi,
      rxFeedLossDb,
      rxPowerDbm: Math.round(rxPowerDbm * 10) / 10,
      rxPowerDbw: Math.round(rxPowerDbw * 10) / 10,
      rxPowerWatts,

      antennaNoiseTempK: Math.round(antennaNoiseTempK),
      systemNoiseTempK: Math.round(systemNoiseTempK),
      receiverNoiseFigureDb: Math.round(receiverNoiseFigureDb * 10) / 10,
      noiseBandwidthHz,
      thermalNoisePowerDbm: Math.round(thermalNoisePowerDbm * 10) / 10,
      thermalNoisePowerWatts,

      carrierToNoiseRatioDb: Math.round(carrierToNoiseRatioDb * 10) / 10,
      carrierToNoiseDensityDbHz: Math.round(carrierToNoiseDensityDbHz * 10) / 10,
      energyPerBitToNoiseDensityDb: Math.round(energyPerBitToNoiseDensityDb * 10) / 10,
      requiredEbN0Db,
      linkMarginDb: Math.round(linkMarginDb * 10) / 10,

      channelCapacityBps: Math.round(channelCapacityBps),
      rawBitRateBps,
      informationBitRateBps: Math.round(informationBitRateBps),
      rawBer,
      codedBer,
      packetErrorRate: Math.round(packetErrorRate * 1000) / 1000,
      frameErrorRate: Math.round(frameErrorRate * 1000) / 1000,
      linkStatus
    };
  }

  public getBitsPerSymbol(mod: string): number {
    switch (mod) {
      case 'BPSK': return 1;
      case 'QPSK': return 2;
      case '8PSK': return 3;
      case '2FSK': return 1;
      case '4FSK': return 2;
      case 'GMSK': return 1;
      case 'OFDM': return 2; // QPSK per subcarrier
      default: return 1;
    }
  }

  public getCodeRate(fec: string): number {
    switch (fec) {
      case 'CONV_K7_R1_2': return 0.5;
      case 'REED_SOLOMON_255_223': return 223.0 / 255.0; // 0.8745
      case 'LDPC_R1_2': return 0.5;
      case 'TURBO_R1_3': return 0.3333;
      case 'NONE':
      default: return 1.0;
    }
  }

  public getRequiredEbN0(mod: string, fec: string): number {
    let baseEbN0 = 9.6; // BPSK at 1e-5 BER theoretical
    switch (mod) {
      case 'BPSK': baseEbN0 = 9.6; break;
      case 'QPSK': baseEbN0 = 9.6; break;
      case '8PSK': baseEbN0 = 13.5; break;
      case '2FSK': baseEbN0 = 13.4; break;
      case '4FSK': baseEbN0 = 11.8; break;
      case 'GMSK': baseEbN0 = 10.2; break;
      case 'OFDM': baseEbN0 = 10.5; break;
    }

    // Apply FEC coding gain
    let codingGain = 0.0;
    switch (fec) {
      case 'CONV_K7_R1_2': codingGain = 5.2; break;
      case 'REED_SOLOMON_255_223': codingGain = 4.2; break;
      case 'LDPC_R1_2': codingGain = 7.1; break;
      case 'TURBO_R1_3': codingGain = 7.8; break;
    }

    return Math.max(1.5, baseEbN0 - codingGain);
  }

  private calculateRawBer(mod: string, ebN0Db: number): number {
    const ebN0Linear = Math.pow(10.0, ebN0Db / 10.0);
    if (ebN0Linear <= 0.01) return 0.5;

    switch (mod) {
      case 'BPSK':
      case 'QPSK':
        // Pb = 0.5 * erfc(sqrt(Eb/N0))
        return 0.5 * this.erfc(Math.sqrt(ebN0Linear));
      case '8PSK':
        // Approx 2/3 * Q(sqrt(2 * Eb/N0 * sin^2(pi/8)))
        return Math.min(0.5, (2.0 / 3.0) * 0.5 * this.erfc(Math.sqrt(ebN0Linear * Math.pow(Math.sin(Math.PI / 8), 2))));
      case '2FSK':
        // Non-coherent FSK: 0.5 * exp(-Eb/(2*N0))
        return Math.min(0.5, 0.5 * Math.exp(-ebN0Linear / 2.0));
      case '4FSK':
        return Math.min(0.5, 0.75 * Math.exp(-ebN0Linear / 2.5));
      case 'GMSK':
        return Math.min(0.5, 0.5 * this.erfc(Math.sqrt(0.85 * ebN0Linear)));
      case 'OFDM':
        return Math.min(0.5, 0.55 * this.erfc(Math.sqrt(0.95 * ebN0Linear)));
      default:
        return 0.5 * this.erfc(Math.sqrt(ebN0Linear));
    }
  }

  private calculateCodedBer(rawBer: number, fec: string, ebN0Db: number): number {
    if (fec === 'NONE' || rawBer >= 0.35) return rawBer;

    switch (fec) {
      case 'CONV_K7_R1_2': {
        // Viterbi upper bound approximation
        // P_coded ~ 36 * P_raw^5
        const coded = 36.0 * Math.pow(Math.max(1e-12, rawBer), 5);
        return Math.min(rawBer, Math.max(1e-9, coded));
      }
      case 'REED_SOLOMON_255_223': {
        // RS(255, 223) t=16 symbol error corrector
        const symbolError = 1.0 - Math.pow(1.0 - rawBer, 8);
        if (symbolError < 0.05) return Math.max(1e-10, rawBer * 1e-4);
        return Math.min(rawBer, symbolError);
      }
      case 'LDPC_R1_2': {
        // LDPC steep cliff threshold
        if (ebN0Db > 3.0) return 1e-9;
        if (ebN0Db > 2.0) return 1e-6;
        if (ebN0Db > 1.2) return 1e-3;
        return rawBer;
      }
      case 'TURBO_R1_3': {
        if (ebN0Db > 2.0) return 1e-9;
        if (ebN0Db > 1.0) return 1e-5;
        return rawBer;
      }
      default:
        return rawBer;
    }
  }

  /**
   * Complementary Error Function (erfc) approximation with high numerical accuracy.
   */
  public erfc(x: number): number {
    if (x >= 8.0) return 0;
    if (x <= -8.0) return 2.0;

    // Abramowitz and Stegun approximation 7.1.26
    const z = Math.abs(x);
    const t = 1.0 / (1.0 + 0.5 * z);
    const ans = t * Math.exp(-z * z - 1.26551223 +
      t * (1.00002368 +
      t * (0.37409196 +
      t * (0.09678418 +
      t * (-0.18628806 +
      t * (0.27886807 +
      t * (-1.13520398 +
      t * (1.48851587 +
      t * (-0.82215223 +
      t * 0.17087277)))))))));

    return x >= 0 ? ans : 2.0 - ans;
  }
}
