import { Injectable } from '@angular/core';
import { OrbitalElements, SatellitePosition } from '../models/satellite.model';
import { GroundStation, GeometryObservation, PassEvent } from '../models/ground-station.model';

const EARTH_RADIUS_KM = 6378.137;
const EARTH_MU = 398600.4418;
const EARTH_ROTATION_RATE_RAD_PER_SEC = 7.2921159e-5;
const SPEED_OF_LIGHT_KM_PER_S = 299792.458;

@Injectable({
  providedIn: 'root'
})
export class OrbitPropagator {

  public propagate(orbit: OrbitalElements, timestampEpochMs: number): SatellitePosition {
    const elapsedSeconds = (timestampEpochMs - orbit.epochEpochMs) / 1000.0;
    const a = orbit.semiMajorAxisKm;
    const e = orbit.eccentricity;
    const incRad = (orbit.inclinationDeg * Math.PI) / 180.0;
    const raanRad0 = (orbit.raanDeg * Math.PI) / 180.0;
    const argPerigeeRad = (orbit.argOfPerigeeDeg * Math.PI) / 180.0;
    const meanAnomaly0Rad = (orbit.meanAnomalyDeg * Math.PI) / 180.0;

    const meanMotion = Math.sqrt(EARTH_MU / Math.pow(a, 3));
    const orbitPeriodMin = (2.0 * Math.PI / meanMotion) / 60.0;

    const p = a * (1 - e * e);
    const j2 = 1.08263e-3;
    const raanPrecessionRate = -1.5 * j2 * Math.pow(EARTH_RADIUS_KM / p, 2) * meanMotion * Math.cos(incRad);
    const raanRad = raanRad0 + raanPrecessionRate * elapsedSeconds;

    let M = (meanAnomaly0Rad + meanMotion * elapsedSeconds) % (2.0 * Math.PI);
    if (M < 0) M += 2.0 * Math.PI;

    let E = M;
    for (let i = 0; i < 15; i++) {
      const f = E - e * Math.sin(E) - M;
      const fPrime = 1.0 - e * Math.cos(E);
      const delta = f / fPrime;
      E -= delta;
      if (Math.abs(delta) < 1e-8) break;
    }

    const sinNu = (Math.sqrt(1.0 - e * e) * Math.sin(E)) / (1.0 - e * Math.cos(E));
    const cosNu = (Math.cos(E) - e) / (1.0 - e * Math.cos(E));
    let nu = Math.atan2(sinNu, cosNu);
    if (nu < 0) nu += 2.0 * Math.PI;

    const r = a * (1.0 - e * Math.cos(E));
    const h = Math.sqrt(EARTH_MU * p);

    const u = nu + argPerigeeRad;
    const cosU = Math.cos(u);
    const sinU = Math.sin(u);
    const cosInc = Math.cos(incRad);
    const sinInc = Math.sin(incRad);
    const cosRaan = Math.cos(raanRad);
    const sinRaan = Math.sin(raanRad);

    const xEci = r * (cosRaan * cosU - sinRaan * sinU * cosInc);
    const yEci = r * (sinRaan * cosU + cosRaan * sinU * cosInc);
    const zEci = r * (sinU * sinInc);

    const rDot = (EARTH_MU / h) * e * Math.sin(nu);
    const rUdot = (EARTH_MU / h) * (1.0 + e * Math.cos(nu));
    const vxEci = (rDot * cosU - rUdot * sinU) * cosRaan - (rDot * sinU + rUdot * cosU) * sinRaan * cosInc;
    const vyEci = (rDot * cosU - rUdot * sinU) * sinRaan + (rDot * sinU + rUdot * cosU) * cosRaan * cosInc;
    const vzEci = (rDot * sinU + rUdot * cosU) * sinInc;

    const gmstRad = (EARTH_ROTATION_RATE_RAD_PER_SEC * elapsedSeconds) % (2.0 * Math.PI);
    const cosGmst = Math.cos(gmstRad);
    const sinGmst = Math.sin(gmstRad);

    const xEcef = cosGmst * xEci + sinGmst * yEci;
    const yEcef = -sinGmst * xEci + cosGmst * yEci;
    const zEcef = zEci;

    const vxEcef = cosGmst * vxEci + sinGmst * vyEci + EARTH_ROTATION_RATE_RAD_PER_SEC * yEcef;
    const vyEcef = -sinGmst * vxEci + cosGmst * vyEci - EARTH_ROTATION_RATE_RAD_PER_SEC * xEcef;
    const vzEcef = vzEci;

    const latRad = Math.atan2(zEcef, Math.sqrt(xEcef * xEcef + yEcef * yEcef));
    const lonRad = Math.atan2(yEcef, xEcef);

    const latitudeDeg = (latRad * 180.0) / Math.PI;
    let longitudeDeg = (lonRad * 180.0) / Math.PI;
    if (longitudeDeg > 180) longitudeDeg -= 360;
    if (longitudeDeg < -180) longitudeDeg += 360;

    const altitudeKm = Math.sqrt(xEcef * xEcef + yEcef * yEcef + zEcef * zEcef) - EARTH_RADIUS_KM;
    const speedKms = Math.sqrt(vxEcef * vxEcef + vyEcef * vyEcef + vzEcef * vzEcef);

    return {
      latitudeDeg,
      longitudeDeg,
      altitudeKm: Math.max(100, altitudeKm),
      xKm: xEcef,
      yKm: yEcef,
      zKm: zEcef,
      vxKms: vxEcef,
      vyKms: vyEcef,
      vzKms: vzEcef,
      speedKms,
      trueAnomalyDeg: (nu * 180.0) / Math.PI,
      orbitPeriodMin
    };
  }

  public calculateGeometry(
    satPos: SatellitePosition,
    station: GroundStation,
    carrierFreqHz: number
  ): GeometryObservation {
    const latRad = (station.latitudeDeg * Math.PI) / 180.0;
    const lonRad = (station.longitudeDeg * Math.PI) / 180.0;
    const altKm = station.altitudeMeters / 1000.0;

    const rStation = EARTH_RADIUS_KM + altKm;
    const gsX = rStation * Math.cos(latRad) * Math.cos(lonRad);
    const gsY = rStation * Math.cos(latRad) * Math.sin(lonRad);
    const gsZ = rStation * Math.sin(latRad);

    const dx = satPos.xKm - gsX;
    const dy = satPos.yKm - gsY;
    const dz = satPos.zKm - gsZ;
    const slantRangeKm = Math.sqrt(dx * dx + dy * dy + dz * dz);

    const sinLat = Math.sin(latRad);
    const cosLat = Math.cos(latRad);
    const sinLon = Math.sin(lonRad);
    const cosLon = Math.cos(lonRad);

    const south = sinLat * cosLon * dx + sinLat * sinLon * dy - cosLat * dz;
    const east = -sinLon * dx + cosLon * dy;
    const zenith = cosLat * cosLon * dx + cosLat * sinLon * dy + sinLat * dz;

    const horizDist = Math.sqrt(south * south + east * east);
    const elevationRad = Math.atan2(zenith, horizDist);
    const elevationDeg = (elevationRad * 180.0) / Math.PI;

    let azRad = Math.atan2(east, -south);
    if (azRad < 0) azRad += 2.0 * Math.PI;
    const azimuthDeg = (azRad * 180.0) / Math.PI;

    const radialVelocityKms = (dx * satPos.vxKms + dy * satPos.vyKms + dz * satPos.vzKms) / Math.max(1.0, slantRangeKm);
    const dopplerShiftHz = -(radialVelocityKms / SPEED_OF_LIGHT_KM_PER_S) * carrierFreqHz;
    const dopplerRateHzPerSec = -((satPos.speedKms * satPos.speedKms) / (slantRangeKm * SPEED_OF_LIGHT_KM_PER_S)) * carrierFreqHz * 0.001;

    const isVisible = elevationDeg >= 0.0;
    const isReceivable = elevationDeg >= station.minElevationDeg;

    return {
      slantRangeKm,
      elevationDeg,
      azimuthDeg,
      isVisible,
      isReceivable,
      radialVelocityKms,
      dopplerShiftHz,
      dopplerRateHzPerSec,
      earthHorizonAngleDeg: (Math.asin(EARTH_RADIUS_KM / (EARTH_RADIUS_KM + satPos.altitudeKm)) * 180.0) / Math.PI
    };
  }

  public predictPasses(
    orbit: OrbitalElements,
    station: GroundStation,
    carrierFreqHz: number,
    startEpochMs: number,
    horizonHours = 24
  ): PassEvent[] {
    const passes: PassEvent[] = [];
    const stepSeconds = 20;
    const endEpochMs = startEpochMs + horizonHours * 3600 * 1000;

    let inPass = false;
    let currentAosMs = 0;
    let maxElev = -90;
    let tcaMs = 0;
    let minRange = 999999;
    let maxDoppler = 0;

    for (let t = startEpochMs; t < endEpochMs; t += stepSeconds * 1000) {
      const satPos = this.propagate(orbit, t);
      const obs = this.calculateGeometry(satPos, station, carrierFreqHz);

      if (obs.elevationDeg >= station.minElevationDeg) {
        if (!inPass) {
          inPass = true;
          currentAosMs = t;
          maxElev = obs.elevationDeg;
          tcaMs = t;
          minRange = obs.slantRangeKm;
          maxDoppler = Math.abs(obs.dopplerShiftHz);
        } else {
          if (obs.elevationDeg > maxElev) {
            maxElev = obs.elevationDeg;
            tcaMs = t;
            minRange = obs.slantRangeKm;
          }
          if (Math.abs(obs.dopplerShiftHz) > maxDoppler) {
            maxDoppler = Math.abs(obs.dopplerShiftHz);
          }
        }
      } else {
        if (inPass) {
          inPass = false;
          const losMs = t;
          const duration = Math.round((losMs - currentAosMs) / 1000);
          if (duration > 60) {
            passes.push({
              satelliteId: 'SAT',
              stationId: station.id,
              aosEpochMs: currentAosMs,
              tcaEpochMs: tcaMs,
              losEpochMs: losMs,
              durationSeconds: duration,
              maxElevationDeg: Math.round(maxElev * 10) / 10,
              minSlantRangeKm: Math.round(minRange),
              maxDopplerShiftHz: Math.round(maxDoppler * 100) / 100,
              peakCnDb: Math.round((14.0 + (maxElev / 90.0) * 12.0) * 10) / 10,
              isCurrent: startEpochMs >= currentAosMs && startEpochMs <= losMs
            });
          }
          maxElev = -90;
        }
      }
    }

    return passes;
  }
}
