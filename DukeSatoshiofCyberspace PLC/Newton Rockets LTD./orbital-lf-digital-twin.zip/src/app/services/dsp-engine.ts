import { Injectable } from '@angular/core';
import { ComplexSample, FftFrame, WaterfallSlice, ConstellationPoint, EvmMetrics, ReceiverLockState, ChainDebugStage } from '../models/signal.model';
import { TransmitterSpec } from '../models/satellite.model';
import { LinkBudgetBreakdown } from '../models/rf-link.model';

@Injectable({
  providedIn: 'root'
})
export class DspEngineService {

  private phaseAcc = 0;
  private costasPhase = 0;
  private timingAcc = 0;
  private currentLockState: ReceiverLockState = 'SEARCH';
  private lockDwellCounter = 0;

  /**
   * Generates a burst of complex baseband IQ samples based on modulation, SNR, and Doppler.
   */
  public generateIqStream(
    tx: TransmitterSpec,
    link: LinkBudgetBreakdown,
    dopplerHz: number,
    numSamples = 256,
    sampleRateHz = 48000
  ): ComplexSample[] {
    const samples: ComplexSample[] = [];
    const samplesPerSymbol = Math.max(2, Math.floor(sampleRateHz / tx.symbolRateBaud));
    
    // Signal amplitude based on received power in dBm
    const sigPowerWatts = link.rxPowerWatts;
    const noisePowerWatts = link.thermalNoisePowerWatts;
    const snrLinear = Math.max(1e-6, sigPowerWatts / Math.max(1e-30, noisePowerWatts));
    const sigAmp = Math.min(2.0, Math.max(0.01, Math.sqrt(snrLinear / (1.0 + snrLinear))));
    const noiseAmp = Math.min(2.0, Math.max(0.01, Math.sqrt(1.0 / (1.0 + snrLinear))));

    // Doppler phase increment per sample
    const freqOffsetRadPerSample = (2.0 * Math.PI * dopplerHz) / sampleRateHz;

    for (let i = 0; i < numSamples; i++) {
      const symIndex = Math.floor((i + this.timingAcc) / samplesPerSymbol) % 16;
      let rawI = 1.0;
      let rawQ = 0.0;

      switch (tx.modulation) {
        case 'BPSK': {
          const bit = (symIndex % 2 === 0) ? 1.0 : -1.0;
          rawI = bit;
          rawQ = 0.0;
          break;
        }
        case 'QPSK': {
          const quad = symIndex % 4;
          rawI = (quad === 0 || quad === 1) ? 0.707 : -0.707;
          rawQ = (quad === 0 || quad === 3) ? 0.707 : -0.707;
          break;
        }
        case '8PSK': {
          const oct = symIndex % 8;
          const theta = (oct * Math.PI) / 4.0;
          rawI = Math.cos(theta);
          rawQ = Math.sin(theta);
          break;
        }
        case '2FSK': {
          const fskOffset = (symIndex % 2 === 0) ? 0.2 : -0.2;
          this.phaseAcc += fskOffset;
          rawI = Math.cos(this.phaseAcc);
          rawQ = Math.sin(this.phaseAcc);
          break;
        }
        case '4FSK': {
          const tone = (symIndex % 4) - 1.5;
          this.phaseAcc += tone * 0.15;
          rawI = Math.cos(this.phaseAcc);
          rawQ = Math.sin(this.phaseAcc);
          break;
        }
        case 'GMSK': {
          const bit = (symIndex % 2 === 0) ? 1 : -1;
          this.phaseAcc += bit * (Math.PI / (2.0 * samplesPerSymbol));
          rawI = Math.cos(this.phaseAcc);
          rawQ = Math.sin(this.phaseAcc);
          break;
        }
        case 'OFDM': {
          let sumI = 0;
          let sumQ = 0;
          for (let sc = -4; sc <= 4; sc++) {
            if (sc === 0) continue;
            const scPhase = (2.0 * Math.PI * sc * i) / samplesPerSymbol;
            sumI += Math.cos(scPhase);
            sumQ += Math.sin(scPhase);
          }
          rawI = sumI / 8.0;
          rawQ = sumQ / 8.0;
          break;
        }
      }

      // Apply Doppler and phase rotation
      this.costasPhase += freqOffsetRadPerSample;
      const rotI = rawI * Math.cos(this.costasPhase) - rawQ * Math.sin(this.costasPhase);
      const rotQ = rawI * Math.sin(this.costasPhase) + rawQ * Math.cos(this.costasPhase);

      // Add AWGN using Box-Muller transform
      const u1 = Math.max(1e-7, Math.random());
      const u2 = Math.random();
      const nI = Math.sqrt(-2.0 * Math.log(u1)) * Math.cos(2.0 * Math.PI * u2) * noiseAmp * 0.4;
      const nQ = Math.sqrt(-2.0 * Math.log(u1)) * Math.sin(2.0 * Math.PI * u2) * noiseAmp * 0.4;

      samples.push({
        i: sigAmp * rotI + nI,
        q: sigAmp * rotQ + nQ
      });
    }

    this.timingAcc = (this.timingAcc + numSamples) % 100000;
    return samples;
  }

  /**
   * Computes Fast Fourier Transform (FFT) on IQ samples for spectrum and waterfall displays.
   */
  public computeFft(
    samples: ComplexSample[],
    fftSize = 512,
    windowType: 'Hanning' | 'Hamming' | 'Blackman' | 'Rectangular' = 'Hanning',
    centerFreqHz = 18200,
    spanHz = 24000,
    rxPowerDbm = -91.4,
    noiseFloorDbm = -118.5
  ): FftFrame {
    const N = Math.min(fftSize, samples.length);
    const real = new Float32Array(N);
    const imag = new Float32Array(N);

    // Apply Window function
    for (let i = 0; i < N; i++) {
      let win = 1.0;
      const nRatio = i / (N - 1);
      if (windowType === 'Hanning') {
        win = 0.5 * (1.0 - Math.cos(2.0 * Math.PI * nRatio));
      } else if (windowType === 'Hamming') {
        win = 0.54 - 0.46 * Math.cos(2.0 * Math.PI * nRatio);
      } else if (windowType === 'Blackman') {
        win = 0.42 - 0.5 * Math.cos(2.0 * Math.PI * nRatio) + 0.08 * Math.cos(4.0 * Math.PI * nRatio);
      }
      real[i] = (samples[i]?.i ?? 0) * win;
      imag[i] = (samples[i]?.q ?? 0) * win;
    }

    // In-place Radix-2 FFT
    this.radix2Fft(real, imag, N);

    const frequenciesHz: number[] = [];
    const magnitudesDbm: number[] = [];
    const rbwHz = spanHz / N;
    let peakPowerDbm = -150.0;
    let peakFreqHz = centerFreqHz;

    // Shift zero-frequency to center (FFT shift)
    for (let i = 0; i < N; i++) {
      const shiftedIdx = (i + N / 2) % N;
      const freq = centerFreqHz - spanHz / 2.0 + (i / N) * spanHz;
      frequenciesHz.push(Math.round(freq));

      // Calculate magnitude in dB
      const magLinear = Math.sqrt(real[shiftedIdx] * real[shiftedIdx] + imag[shiftedIdx] * imag[shiftedIdx]) / N;
      const magDb = 20.0 * Math.log10(Math.max(1e-7, magLinear));
      
      const distFromCenter = Math.abs(freq - centerFreqHz);
      const isSignalRegion = distFromCenter < 2500;
      
      let calibratedDbm = noiseFloorDbm + (magDb + 40.0);
      if (isSignalRegion) {
        calibratedDbm = Math.max(calibratedDbm, rxPowerDbm - (distFromCenter / 2500.0) * 8.0 + (Math.random() * 2.0 - 1.0));
      } else {
        calibratedDbm = noiseFloorDbm + (Math.random() * 3.0 - 1.5);
      }

      magnitudesDbm.push(Math.round(calibratedDbm * 10) / 10);

      if (calibratedDbm > peakPowerDbm) {
        peakPowerDbm = calibratedDbm;
        peakFreqHz = Math.round(freq);
      }
    }

    return {
      timestampEpochMs: Date.now(),
      frequenciesHz,
      magnitudesDbm,
      centerFreqHz,
      spanHz,
      rbwHz: Math.round(rbwHz),
      noiseFloorDbm,
      peakFreqHz,
      peakPowerDbm: Math.round(peakPowerDbm * 10) / 10
    };
  }

  /**
   * Generates waterfall slice normalized from 0.0 to 1.0
   */
  public generateWaterfallSlice(fft: FftFrame, minDbm = -130, maxDbm = -70): WaterfallSlice {
    const range = maxDbm - minDbm;
    const magnitudesNormalized = fft.magnitudesDbm.map(dbm => {
      const norm = (dbm - minDbm) / range;
      return Math.max(0.0, Math.min(1.0, norm));
    });

    return {
      timestampEpochMs: fft.timestampEpochMs,
      magnitudesNormalized
    };
  }

  /**
   * Demodulates IQ samples to extract constellation points and EVM metrics.
   */
  public extractConstellation(
    samples: ComplexSample[],
    mod: string,
    snrDb: number,
    dopplerHz: number
  ): { points: ConstellationPoint[]; evm: EvmMetrics } {
    const points: ConstellationPoint[] = [];
    let sumEvmSq = 0;
    let maxEvm = 0;
    let sumPhaseErr = 0;

    const numPoints = Math.min(128, samples.length);

    for (let i = 0; i < numPoints; i++) {
      const sample = samples[i];
      let idealI = 0.707;
      let idealQ = 0.707;

      if (mod === 'BPSK') {
        idealI = sample.i >= 0 ? 1.0 : -1.0;
        idealQ = 0.0;
      } else if (mod === 'QPSK' || mod === 'OFDM') {
        idealI = sample.i >= 0 ? 0.707 : -0.707;
        idealQ = sample.q >= 0 ? 0.707 : -0.707;
      } else if (mod === '8PSK') {
        const theta = Math.atan2(sample.q, sample.i);
        const oct = Math.round((theta * 4.0) / Math.PI);
        const targetTheta = (oct * Math.PI) / 4.0;
        idealI = Math.cos(targetTheta);
        idealQ = Math.sin(targetTheta);
      } else {
        const angle = Math.atan2(sample.q, sample.i);
        idealI = Math.cos(angle);
        idealQ = Math.sin(angle);
      }

      // Calculate error vector
      const dI = sample.i - idealI;
      const dQ = sample.q - idealQ;
      const errorMag = Math.sqrt(dI * dI + dQ * dQ);
      const idealMag = Math.sqrt(idealI * idealI + idealQ * idealQ);
      const evm = (errorMag / Math.max(0.1, idealMag)) * 100.0;

      sumEvmSq += evm * evm;
      if (evm > maxEvm) maxEvm = evm;

      const actAngle = (Math.atan2(sample.q, sample.i) * 180.0) / Math.PI;
      const idAngle = (Math.atan2(idealQ, idealI) * 180.0) / Math.PI;
      let phaseErr = Math.abs(actAngle - idAngle);
      if (phaseErr > 180) phaseErr = 360 - phaseErr;
      sumPhaseErr += phaseErr;

      points.push({
        i: Math.round(sample.i * 1000) / 1000,
        q: Math.round(sample.q * 1000) / 1000,
        idealI: Math.round(idealI * 1000) / 1000,
        idealQ: Math.round(idealQ * 1000) / 1000,
        phaseErrorDeg: Math.round(phaseErr * 10) / 10,
        symbolIndex: i
      });
    }

    const evmRmsPercent = Math.sqrt(sumEvmSq / numPoints);
    const avgPhaseErr = sumPhaseErr / numPoints;

    return {
      points,
      evm: {
        evmRmsPercent: Math.round(evmRmsPercent * 10) / 10,
        evmPeakPercent: Math.round(maxEvm * 10) / 10,
        phaseErrorDeg: Math.round(avgPhaseErr * 10) / 10,
        frequencyOffsetHz: Math.round(dopplerHz * 100) / 100,
        snrDb: Math.round(snrDb * 10) / 10
      }
    };
  }

  /**
   * Advances digital receiver synchronization state machine (SEARCH -> ACQUIRE -> LOCK -> DECODE).
   */
  public updateReceiverState(link: LinkBudgetBreakdown, isReceivable: boolean): ReceiverLockState {
    if (!isReceivable || link.linkStatus === 'OUT_OF_VIEW') {
      this.currentLockState = 'SEARCH';
      this.lockDwellCounter = 0;
      return this.currentLockState;
    }

    if (link.carrierToNoiseRatioDb < 2.0) {
      this.currentLockState = 'SEARCH';
      this.lockDwellCounter = 0;
      return this.currentLockState;
    }

    this.lockDwellCounter++;

    if (this.currentLockState === 'SEARCH') {
      if (this.lockDwellCounter > 2) {
        this.currentLockState = 'ACQUIRE';
      }
    } else if (this.currentLockState === 'ACQUIRE') {
      if (this.lockDwellCounter > 5 && link.carrierToNoiseRatioDb >= 4.0) {
        this.currentLockState = 'LOCK';
      }
    } else if (this.currentLockState === 'LOCK') {
      if (this.lockDwellCounter > 8 && link.codedBer < 1e-2) {
        this.currentLockState = 'DECODE';
      }
    }

    return this.currentLockState;
  }

  /**
   * Builds the 13-stage end-to-end signal debugging chain representation.
   */
  public buildDebugChain(
    tx: TransmitterSpec,
    link: LinkBudgetBreakdown,
    dopplerHz: number,
    state: ReceiverLockState
  ): ChainDebugStage[] {
    const isLocked = state === 'LOCK' || state === 'DECODE';
    const isDecoding = state === 'DECODE';

    return [
      {
        id: 1,
        name: 'GROUND DATA SOURCE',
        domain: 'SATELLITE',
        status: 'NOMINAL',
        description: 'Telemetry frame generator & scientific packet dispatcher',
        inputData: 'TIME_UTC, EPHEMERIS_VECTORS, SPACE_WX_INDICES, NAV_MESSAGES',
        outputData: 'BINARY_STREAM: 0x53415430315F54454C454D45545259',
        metrics: { 'Source Rate': '2.4 kbps', 'Encoding': 'UTF-8 / CCSDS', 'Frame Size': '128 Bytes' }
      },
      {
        id: 2,
        name: 'SOURCE CODING & PACKETISATION',
        domain: 'SATELLITE',
        status: 'NOMINAL',
        description: 'CCSDS Space Packet Protocol header & payload assembly',
        inputData: 'Raw Telemetry & Broadcast Text',
        outputData: 'PACKET: Sync=0x1ACFFC1D | Seq=18429 | Len=1024b',
        metrics: { 'Header': '32 bits', 'Sync Word': '0x1ACFFC1D', 'Efficiency': '94.2%' }
      },
      {
        id: 3,
        name: 'FORWARD ERROR-CORRECTION ENCODER',
        domain: 'SATELLITE',
        status: 'NOMINAL',
        description: `FEC Generator: ${tx.fecScheme} with Convolutional / RS Interleaving`,
        inputData: '1024 Information bits',
        outputData: '2048 Channel encoded symbols (Rate 1/2, K=7)',
        metrics: { 'FEC Type': tx.fecScheme, 'Code Rate': tx.fecScheme === 'NONE' ? '1.0' : '0.50', 'Constraint K': 7 }
      },
      {
        id: 4,
        name: 'DIGITAL MODULATOR & DAC',
        domain: 'SATELLITE',
        status: 'NOMINAL',
        description: `Baseband ${tx.modulation} mapper with Root Raised Cosine (RRC) pulse shaping`,
        inputData: 'Channel symbols',
        outputData: `Complex I/Q samples @ ${tx.symbolRateBaud} Baud`,
        metrics: { 'Modulation': tx.modulation, 'Symbol Rate': `${tx.symbolRateBaud} Baud`, 'RRC Roll-off': '0.35' }
      },
      {
        id: 5,
        name: 'POWER AMPLIFIER & TX ANTENNA',
        domain: 'SATELLITE',
        status: 'NOMINAL',
        description: 'Class-D/E switching PA + Deployable VLF/LF magnetic dipole array',
        inputData: 'RF carrier @ 18.2 kHz',
        outputData: `Radiated RF Power: ${tx.outputPowerWatts} W (${link.txPowerDbm} dBm)`,
        metrics: { 'PA Efficiency': '74.5%', 'EIRP': `${link.eirpDbm} dBm`, 'Gain': `${satelliteGainDbi(link)} dBi` }
      },
      {
        id: 6,
        name: 'ORBITAL CHANNEL & IONOSPHERE',
        domain: 'CHANNEL',
        status: link.freeSpacePathLossDb > 0 ? 'NOMINAL' : 'BYPASSED',
        description: 'Free-space path loss, D-region absorption, Faraday rotation & AWGN',
        inputData: `Radiated signal @ R=${link.freeSpacePathLossDb > 0 ? 'Slant Range' : 'Ideal'}`,
        outputData: `Impaired signal: Attenuation = -${link.freeSpacePathLossDb + link.ionosphericLossDb} dB`,
        metrics: { 'FSPL': `${link.freeSpacePathLossDb} dB`, 'Iono Loss': `${link.ionosphericLossDb} dB`, 'Polarisation': `${link.polarisationLossDb} dB` }
      },
      {
        id: 7,
        name: 'GROUND RECEIVING ANTENNA',
        domain: 'GROUND_RECEIVER',
        status: 'NOMINAL',
        description: 'Ground low-frequency tuned active magnetic loop with preselection',
        inputData: 'Incident electromagnetic wave',
        outputData: `RF terminal voltage: P_rx = ${link.rxPowerDbm} dBm`,
        metrics: { 'Rx Gain': `${link.rxAntennaGainDbi} dBi`, 'Antenna Temp': `${link.antennaNoiseTempK} K`, 'Cable Loss': `${link.rxFeedLossDb} dB` }
      },
      {
        id: 8,
        name: 'LOW-NOISE AMPLIFIER (LNA)',
        domain: 'GROUND_RECEIVER',
        status: 'NOMINAL',
        description: 'Ultra-low noise JFET front-end amplifier',
        inputData: `Weak RF signal: ${link.rxPowerDbm} dBm`,
        outputData: `Amplified RF: ${Math.round((link.rxPowerDbm + 24.0) * 10) / 10} dBm`,
        metrics: { 'LNA Gain': '+24.0 dB', 'Noise Figure': `${link.receiverNoiseFigureDb} dB`, 'T_sys': `${link.systemNoiseTempK} K` }
      },
      {
        id: 9,
        name: 'MIXER & DOWNCONVERTER',
        domain: 'GROUND_RECEIVER',
        status: 'NOMINAL',
        description: 'Direct conversion IQ quadrature demodulator with Local Oscillator',
        inputData: 'Amplified RF carrier',
        outputData: 'Complex baseband (I / Q) centered at 0 Hz IF',
        metrics: { 'LO Frequency': '18.200 kHz', 'Image Rejection': '> 65 dB', 'IF Bandwidth': '2.4 kHz' }
      },
      {
        id: 10,
        name: 'ADC & AUTOMATIC GAIN CONTROL (AGC)',
        domain: 'GROUND_RECEIVER',
        status: 'NOMINAL',
        description: '24-bit delta-sigma ADC @ 48 kSps with digital AGC level stabilization',
        inputData: 'Analog baseband I/Q',
        outputData: 'Quantized digital IQ sample stream @ 48 kHz',
        metrics: { 'Resolution': '24-bit', 'Sample Rate': '48.0 kSps', 'AGC Backoff': '-12.0 dBFS' }
      },
      {
        id: 11,
        name: 'CARRIER & TIMING RECOVERY DSP',
        domain: 'GROUND_RECEIVER',
        status: isLocked ? 'NOMINAL' : (state === 'ACQUIRE' ? 'WARNING' : 'ERROR'),
        description: 'Costas loop phase tracker + Gardner timing error detector',
        inputData: 'Noisy IQ with Doppler shift',
        outputData: `Phase-synchronized symbols (Doppler: ${Math.round(dopplerHz * 100) / 100} Hz)`,
        metrics: { 'Lock State': state, 'Costas Loop BW': '15 Hz', 'Doppler Residual': '< 0.05 Hz' }
      },
      {
        id: 12,
        name: 'FORWARD ERROR-CORRECTION DECODER',
        domain: 'GROUND_RECEIVER',
        status: isDecoding && link.codedBer < 1e-3 ? 'NOMINAL' : 'WARNING',
        description: 'Soft-decision Viterbi decoder (K=7) & Reed-Solomon t=16 corrector',
        inputData: 'Soft symbol decisions',
        outputData: `Corrected bit stream (BER: ${link.codedBer.toExponential(2)})`,
        metrics: { 'Raw BER': link.rawBer.toExponential(2), 'Coded BER': link.codedBer.toExponential(2), 'Coding Gain': '5.2 dB' }
      },
      {
        id: 13,
        name: 'CRC VERIFIER & PACKET SINK',
        domain: 'GROUND_RECEIVER',
        status: isDecoding && link.codedBer < 1e-4 ? 'NOMINAL' : 'ERROR',
        description: 'CRC-32 verification & CCSDS frame deframer to ground receiver buffer',
        inputData: 'Decoded packet frames',
        outputData: isDecoding ? 'FRAME VALIDATED: CRC PASS -> BROADCAST SINK' : 'AWAITING SYNC WORD LOCK',
        metrics: { 'CRC Status': isDecoding ? 'PASS (0x92FA710C)' : 'CHECKSUM MISMATCH', 'Packets Received': '18,429', 'PER': `${link.packetErrorRate}` }
      }
    ];
  }

  /**
   * Helper in-place Radix-2 FFT computation
   */
  private radix2Fft(real: Float32Array, imag: Float32Array, n: number): void {
    let j = 0;
    for (let i = 0; i < n - 1; i++) {
      if (i < j) {
        const tr = real[i]; real[i] = real[j]; real[j] = tr;
        const ti = imag[i]; imag[i] = imag[j]; imag[j] = ti;
      }
      let k = n >> 1;
      while (k <= j) {
        j -= k;
        k >>= 1;
      }
      j += k;
    }

    for (let l = 2; l <= n; l <<= 1) {
      const halfL = l >> 1;
      const angle = (-2.0 * Math.PI) / l;
      const wStepR = Math.cos(angle);
      const wStepI = Math.sin(angle);

      for (let i = 0; i < n; i += l) {
        let wr = 1.0;
        let wi = 0.0;
        for (let k = 0; k < halfL; k++) {
          const uR = real[i + k];
          const uI = imag[i + k];
          const vR = real[i + k + halfL] * wr - imag[i + k + halfL] * wi;
          const vI = real[i + k + halfL] * wi + imag[i + k + halfL] * wr;

          real[i + k] = uR + vR;
          imag[i + k] = uI + vI;
          real[i + k + halfL] = uR - vR;
          imag[i + k + halfL] = uI - vI;

          const nWr = wr * wStepR - wi * wStepI;
          wi = wr * wStepI + wi * wStepR;
          wr = nWr;
        }
      }
    }
  }
}

function satelliteGainDbi(link: LinkBudgetBreakdown): number {
  return link.txAntennaGainDbi;
}
