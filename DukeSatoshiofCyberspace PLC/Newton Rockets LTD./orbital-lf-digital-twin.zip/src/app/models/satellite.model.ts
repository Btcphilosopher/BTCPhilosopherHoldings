export interface OrbitalElements {
  semiMajorAxisKm: number;      // e.g. 7178 km (800 km altitude)
  eccentricity: number;          // 0 for circular, 0.001 - 0.2 for elliptical
  inclinationDeg: number;        // e.g. 98.6 deg (SSO) or 55 deg
  raanDeg: number;               // Right Ascension of Ascending Node
  argOfPerigeeDeg: number;       // Argument of perigee
  meanAnomalyDeg: number;        // Mean anomaly at epoch
  epochEpochMs: number;          // Epoch timestamp
}

export interface SatellitePosition {
  latitudeDeg: number;
  longitudeDeg: number;
  altitudeKm: number;
  xKm: number;                  // ECEF X
  yKm: number;                  // ECEF Y
  zKm: number;                  // ECEF Z
  vxKms: number;                // Velocity vector km/s
  vyKms: number;
  vzKms: number;
  speedKms: number;
  trueAnomalyDeg: number;
  orbitPeriodMin: number;
}

export interface AntennaSpec {
  type: 'dipole' | 'monopole' | 'magnetic-loop' | 'helical' | 'phased-array';
  gainDbi: number;
  beamwidthDeg: number;
  efficiency: number;           // 0.0 - 1.0 (Low-frequency antennas have low efficiency due to physical size)
  physicalDimensionMeters: number;
  polarisation: 'linear-vertical' | 'linear-horizontal' | 'circular-rhcp' | 'circular-lhcp';
  pointingLossDb: number;
}

export interface TransmitterSpec {
  rfFrequencyHz: number;        // e.g. 18200 Hz (18.2 kHz)
  channelBandwidthHz: number;   // e.g. 2000 Hz
  outputPowerWatts: number;     // e.g. 250 W
  powerAmplifierEfficiency: number; // e.g. 0.72 (Class D/E switching PA)
  feedLossDb: number;           // e.g. 1.2 dB
  harmonicSuppressionDbc: number; // e.g. -60 dBc
  modulation: 'BPSK' | 'QPSK' | '8PSK' | '2FSK' | '4FSK' | 'GMSK' | 'OFDM';
  symbolRateBaud: number;       // e.g. 1200 baud
  fecScheme: 'NONE' | 'CONV_K7_R1_2' | 'REED_SOLOMON_255_223' | 'LDPC_R1_2' | 'TURBO_R1_3';
  interleaving: boolean;
  active: boolean;
}

export interface PowerSubsystem {
  solarArrayAreaM2: number;
  solarCellEfficiency: number;
  batteryCapacityWh: number;
  batteryChargePercent: number;
  busVoltageVolts: number;
  solarGenerationWatts: number;
  paPowerDrawWatts: number;
  dspPowerDrawWatts: number;
  avionicsPowerDrawWatts: number;
  totalPowerDrawWatts: number;
  inEclipse: boolean;
}

export interface ThermalSubsystem {
  paTemperatureC: number;
  dspTemperatureC: number;
  radiatorTemperatureC: number;
  heatDissipationWatts: number;
  maxOperatingTempC: number;
  thermalMarginC: number;
  status: 'NOMINAL' | 'WARMING' | 'THROTTLED' | 'CRITICAL';
}

export interface Satellite {
  id: string;
  name: string;
  noradId: number;
  massKg: number;
  orbit: OrbitalElements;
  transmitter: TransmitterSpec;
  antenna: AntennaSpec;
  power: PowerSubsystem;
  thermal: ThermalSubsystem;
  telemetrySequence: number;
  lastUpdateEpochMs: number;
  description: string;
}
