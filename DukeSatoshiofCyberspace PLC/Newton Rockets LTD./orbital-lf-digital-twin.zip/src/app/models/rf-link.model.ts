export type PropagationModelMode = 'IDEAL' | 'FREE_SPACE' | 'IONOSPHERIC' | 'REALISTIC_NOISE' | 'FULL_CHANNEL';

export interface ChannelState {
  mode: PropagationModelMode;
  slantRangeKm: number;
  freeSpaceLossDb: number;
  ionosphericAbsorptionDb: number;
  ionosphericPhaseShiftDeg: number;
  ionosphericGroupDelayMicrosec: number;
  faradayRotationDeg: number;
  polarisationLossDb: number;
  atmosphericAbsorptionDb: number;
  groundConductivityLossDb: number;
  manMadeNoiseExcessDb: number;
  totalPathLossDb: number;
  dopplerShiftHz: number;
  multipathFactorDb: number;
  solarActivitySfu: number;     // Solar Flux Units (e.g. 150 SFU)
  sunspotNumber: number;        // e.g. 110
  tecTotalElectronContentU: number; // TECU (10^16 e/m2)
}

export interface LinkBudgetBreakdown {
  txPowerWatts: number;
  txPowerDbm: number;
  txPowerDbw: number;
  txAntennaGainDbi: number;
  txFeedLossDb: number;
  eirpDbm: number;              // Equivalent Isotropically Radiated Power
  freeSpacePathLossDb: number;
  ionosphericLossDb: number;
  polarisationLossDb: number;
  atmosphericLossDb: number;
  pointingLossDb: number;
  rxAntennaGainDbi: number;
  rxFeedLossDb: number;
  rxPowerDbm: number;
  rxPowerDbw: number;
  rxPowerWatts: number;
  
  // Noise analysis
  antennaNoiseTempK: number;
  systemNoiseTempK: number;
  receiverNoiseFigureDb: number;
  noiseBandwidthHz: number;
  thermalNoisePowerDbm: number;
  thermalNoisePowerWatts: number;
  
  // Signal-to-noise metrics
  carrierToNoiseRatioDb: number;        // C/N
  carrierToNoiseDensityDbHz: number;    // C/N0
  energyPerBitToNoiseDensityDb: number; // Eb/N0
  requiredEbN0Db: number;
  linkMarginDb: number;
  
  // Data capacity & errors
  channelCapacityBps: number;           // Shannon limit B * log2(1 + S/N)
  rawBitRateBps: number;
  informationBitRateBps: number;
  rawBer: number;
  codedBer: number;
  packetErrorRate: number;
  frameErrorRate: number;
  linkStatus: 'LOCKED' | 'DEGRADED' | 'SEARCHING' | 'OUT_OF_VIEW';
}
