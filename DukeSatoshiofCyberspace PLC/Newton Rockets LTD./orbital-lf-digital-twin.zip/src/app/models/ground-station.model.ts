import { AntennaSpec } from './satellite.model';

export interface GroundStation {
  id: string;
  name: string;
  country: string;
  latitudeDeg: number;
  longitudeDeg: number;
  altitudeMeters: number;
  antenna: AntennaSpec;
  lnaGainDb: number;
  lnaNoiseFigureDb: number;
  cableLossDb: number;
  receiverNoiseTempK: number;
  minElevationDeg: number;
  filterBandwidthHz: number;
  adcSampleRateHz: number;
  adcBits: number;
  active: boolean;
}

export interface PassEvent {
  satelliteId: string;
  stationId: string;
  aosEpochMs: number;          // Acquisition of Signal
  tcaEpochMs: number;          // Time of Closest Approach
  losEpochMs: number;          // Loss of Signal
  durationSeconds: number;
  maxElevationDeg: number;
  minSlantRangeKm: number;
  maxDopplerShiftHz: number;
  peakCnDb: number;
  isCurrent: boolean;
}

export interface GeometryObservation {
  slantRangeKm: number;
  elevationDeg: number;
  azimuthDeg: number;
  isVisible: boolean;
  isReceivable: boolean;
  radialVelocityKms: number;
  dopplerShiftHz: number;
  dopplerRateHzPerSec: number;
  earthHorizonAngleDeg: number;
}
