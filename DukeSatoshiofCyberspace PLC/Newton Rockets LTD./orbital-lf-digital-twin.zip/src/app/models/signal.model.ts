export interface ComplexSample {
  i: number; // In-phase
  q: number; // Quadrature
}

export interface FftFrame {
  timestampEpochMs: number;
  frequenciesHz: number[];
  magnitudesDbm: number[];
  centerFreqHz: number;
  spanHz: number;
  rbwHz: number;
  noiseFloorDbm: number;
  peakFreqHz: number;
  peakPowerDbm: number;
}

export interface WaterfallSlice {
  timestampEpochMs: number;
  magnitudesNormalized: number[]; // 0.0 to 1.0 for canvas drawing
}

export interface ConstellationPoint {
  i: number;
  q: number;
  idealI: number;
  idealQ: number;
  phaseErrorDeg: number;
  symbolIndex: number;
}

export interface EvmMetrics {
  evmRmsPercent: number;
  evmPeakPercent: number;
  phaseErrorDeg: number;
  frequencyOffsetHz: number;
  snrDb: number;
}

export type ReceiverLockState = 'SEARCH' | 'ACQUIRE' | 'LOCK' | 'DECODE';

export interface DecodedPacket {
  id: string;
  frameNumber: number;
  satelliteId: string;
  timestampUtc: string;
  payloadType: 'EPHEMERIS' | 'TIME_SYNC' | 'SPACE_WEATHER' | 'NAV_ALERT' | 'SCIENCE_TELEMETRY' | 'PUBLIC_BROADCAST';
  rssiDbm: number;
  cnDb: number;
  ebN0Db: number;
  estimatedBer: number;
  rawBitsHex: string;
  payloadContent: Record<string, unknown>;
  fecStatus: 'PASS' | 'CORRECTED' | 'FAILED';
  crcStatus: 'PASS' | 'FAIL';
  decodedAtEpochMs: number;
}

export interface ChainDebugStage {
  id: number;
  name: string;
  domain: 'SATELLITE' | 'CHANNEL' | 'GROUND_RECEIVER';
  status: 'NOMINAL' | 'WARNING' | 'BYPASSED' | 'ERROR';
  description: string;
  inputData: string;
  outputData: string;
  metrics: Record<string, string | number>;
}
