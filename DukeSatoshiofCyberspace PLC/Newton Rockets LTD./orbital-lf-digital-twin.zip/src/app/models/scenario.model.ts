export interface SimulationScenario {
  id: string;
  name: string;
  description: string;
  category: 'NOMINAL' | 'ATMOSPHERIC' | 'GEOMETRY' | 'HARDWARE_STRESS' | 'NETWORK';
  badge: string;
  satelliteId: string;
  groundStationId: string;
  propagationMode: 'IDEAL' | 'FREE_SPACE' | 'IONOSPHERIC' | 'REALISTIC_NOISE' | 'FULL_CHANNEL';
  solarActivitySfu: number;
  sunspotNumber: number;
  txPowerScale: number;          // 0.1 to 2.0
  manMadeNoiseExcessDb: number;  // 0 to 40 dB
  antennaMispointingDeg: number; // 0 to 45 deg
  simulatedTimeSpeed: number;    // 1x, 5x, 20x, 60x
  notes: string;
}
