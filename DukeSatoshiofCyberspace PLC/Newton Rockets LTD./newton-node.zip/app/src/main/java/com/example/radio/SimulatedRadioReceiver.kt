package com.example.radio

import com.example.domain.RadioTelemetry
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import kotlin.random.Random

class SimulatedRadioReceiver : RadioReceiver {
    private val _telemetry = MutableStateFlow(
        RadioTelemetry(
            2400000000, 20000000, 10000000, -61.2, 18.7, -91.4, 1842, 12500000, "LOCKED"
        )
    )
    override val telemetry: StateFlow<RadioTelemetry> = _telemetry

    private val scope = CoroutineScope(Dispatchers.Default)
    private var running = false

    override fun start() {
        running = true
        scope.launch {
            while (running) {
                delay(1000)
                // Simulate telemetry fluctuations
                val current = _telemetry.value
                _telemetry.value = current.copy(
                    rssiDbm = current.rssiDbm + Random.nextDouble(-1.0, 1.0),
                    snrDb = current.snrDb + Random.nextDouble(-0.5, 0.5)
                )
            }
        }
    }

    override fun stop() {
        running = false
    }

    override fun configure(config: RadioConfig) {
        // Handle reconfiguration
    }
}
