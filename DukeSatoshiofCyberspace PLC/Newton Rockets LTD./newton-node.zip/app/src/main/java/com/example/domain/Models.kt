package com.example.domain

data class NodeIdentity(
    val nodeId: String,
    val publicKey: String,
    val softwareVersion: String,
    val hardwareClass: String
)

data class RadioTelemetry(
    val frequencyHz: Long,
    val sampleRate: Long,
    val bandwidthHz: Long,
    val rssiDbm: Double,
    val snrDb: Double,
    val noiseFloorDbm: Double,
    val packetRate: Int,
    val bitRate: Long,
    val status: String
)

data class Packet(
    val version: Int,
    val type: String,
    val source: String,
    val dest: String,
    val length: Int,
    val payload: String,
    val crc: Int
)
