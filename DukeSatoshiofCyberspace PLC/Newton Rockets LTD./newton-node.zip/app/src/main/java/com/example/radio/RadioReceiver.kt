package com.example.radio

import com.example.domain.RadioTelemetry
import kotlinx.coroutines.flow.StateFlow

data class RadioConfig(
    val frequencyHz: Long,
    val sampleRate: Long,
    val bandwidthHz: Long,
    val gainDb: Double,
    val modulation: String
)

interface RadioReceiver {
    fun start()
    fun stop()
    fun configure(config: RadioConfig)
    val telemetry: StateFlow<RadioTelemetry>
}
