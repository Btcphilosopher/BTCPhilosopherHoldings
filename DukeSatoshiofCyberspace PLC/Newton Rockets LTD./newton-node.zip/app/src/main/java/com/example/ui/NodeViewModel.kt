package com.example.ui

import androidx.lifecycle.ViewModel
import com.example.radio.RadioReceiver
import com.example.radio.SimulatedRadioReceiver
import kotlinx.coroutines.flow.asStateFlow

class NodeViewModel(
    private val radioReceiver: RadioReceiver = SimulatedRadioReceiver()
) : ViewModel() {
    init {
        radioReceiver.start()
    }

    val telemetry = radioReceiver.telemetry
}
