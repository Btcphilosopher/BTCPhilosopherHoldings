package com.example.ui

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.domain.RadioTelemetry

@Composable
fun NewtonDashboard(viewModel: NodeViewModel) {
    val telemetry by viewModel.telemetry.collectAsStateWithLifecycle()

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Text("NEWTON ROCKET LTD.", style = MaterialTheme.typography.titleLarge)
        Text("INTERNET 4.0 | NODE 0042", style = MaterialTheme.typography.titleMedium)
        
        Spacer(modifier = Modifier.height(16.dp))
        
        Card(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("RADIO STATUS", style = MaterialTheme.typography.labelLarge)
                Text("Status: ${telemetry.status}", style = MaterialTheme.typography.bodyMedium)
                Text("RSSI: ${telemetry.rssiDbm} dBm", style = MaterialTheme.typography.bodyMedium)
                Text("SNR: ${telemetry.snrDb} dB", style = MaterialTheme.typography.bodyMedium)
            }
        }
    }
}
