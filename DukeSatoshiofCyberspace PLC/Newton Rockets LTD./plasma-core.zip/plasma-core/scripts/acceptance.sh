#!/usr/bin/env bash
# Final acceptance workflow (specification item 99).  Run from the repository root.
set -euo pipefail
PY=${PYTHON:-python3}
step() { echo; echo "=================== $* ==================="; }

step "1. install package"
$PY -m pip install -q -e ".[test]"

step "2. unit tests (including slow physics tests)"
$PY -m pytest -q

step "3. validation suite (regenerates docs/VALIDATION.md from measured results)"
plasma-core validation-suite --report docs/VALIDATION.md --json docs/validation_results.json

cd examples
for ex in cold_plasma gyro_motion exb_drift plasma_wave two_stream magnetised_plasma; do
  step "4. example: $ex"
  $PY "$ex.py"
done

step "5. HDF5 output -> read diagnostics -> checkpoint -> restart -> compare -> plots"
$PY acceptance_workflow.py

step "6. CLI round trip"
plasma-core run configs/cold_plasma.yaml --quiet
plasma-core diagnostics output/cold_plasma_cli/cold_plasma_cli.h5 --max-rows 5
plasma-core inspect output/cold_plasma_cli/cold_plasma_cli_checkpoint_00000500.h5 | head -20
plasma-core restart output/cold_plasma_cli/cold_plasma_cli_checkpoint_00000500.h5 --steps 50

echo; echo "ACCEPTANCE: all steps completed successfully"
