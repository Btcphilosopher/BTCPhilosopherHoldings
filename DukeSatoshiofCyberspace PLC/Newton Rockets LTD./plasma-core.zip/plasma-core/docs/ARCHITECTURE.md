# Architecture

## Dependency direction

```
Physics            constants, units, species, physics/ (formulas, dispersion theory, closures, collisions)
   ↓
Numerical kernels  grid/, pic/ (shapes, deposition, interpolation), particles/ (state, Boris, boundaries),
                   backends/ (CPU reference, Numba)
   ↓
Solvers            solvers/ (Poisson, Yee, fluid, Vlasov), fields/, pic/pic_solver.py (PIC models)
   ↓
Simulation state   state.PlasmaState (observed), simulation/ (driver, time-step control, checkpoint, restart)
   ↓
Diagnostics        diagnostics/ (energy, charge, momentum, temperature, density, distribution,
                   conservation monitor, manager, analysis/fitting)
   ↓
I/O                io/ (HDF5, Parquet, xarray, metadata)
   ↓
Visualisation      visualization/ (Matplotlib; imported only by user code and examples)
```

Rules enforced in code and tests:

* No module above `visualization/` imports Matplotlib
  (`tests/test_visualization_interfaces.py::test_numerical_core_does_not_import_matplotlib`).
* Diagnostics read a `PlasmaState` produced by `model.observe()`; observing
  never modifies the numerical state (trial pushes operate on copies).
* The configuration is the single source of input; every output carries its
  canonical JSON and SHA-256 hash.
* Physics modules contain no backend- or hardware-specific code.

## Observation model

```
Physics solver (model.step)  →  numerical state (particles, fields, f, U)
        → model.observe() → PlasmaState  → DiagnosticsManager  → HDF5 / Parquet / xarray  → plots
```

Visual output is computed from stored or observed state only; field lines are
traced from computed field arrays (`visualization.trace_field_line`), never
drawn analytically.

## Main abstractions

| abstraction | module | role |
|---|---|---|
| `SimulationConfig` | `configuration.py` | validated, hashable description of a run |
| `Species` | `species.py` | charge, mass, weight, T, n, drift, mobility |
| `SpatialGrid`, `VelocityGrid`, `FieldGrid` | `grid/` | geometry and field-component layout |
| `ParticleState` | `particles/particle_state.py` | structure-of-arrays particle storage |
| `ShapeFunction` | `pic/shapes.py` | shared deposition/interpolation stencil |
| `PoissonSolver`, `Yee1DMaxwellSolver` | `solvers/` | field solvers |
| `SimulationModel` | `simulation/model.py` | interface: initialize / step / observe / state_arrays |
| `ElectrostaticPICModel`, `ElectromagneticPIC1DModel`, `TestParticleModel` | `pic/pic_solver.py` | kinetic particle models |
| `FluidModel1D` | `solvers/fluid.py` | Euler–Poisson model (architecturally separate) |
| `VlasovModel1D1V` | `solvers/vlasov.py` | grid kinetic model |
| `PressureClosure` | `physics/pressure.py` | EOS closures |
| `CollisionModel` | `physics/collisions.py` | collision operators |
| `PlasmaState` | `state.py` | observed state with documented shapes |
| `DiagnosticsManager`, `StabilityMonitor` | `diagnostics/` | time series, conservation, stop conditions |
| `TimestepController`, `AdaptiveTimestepController` | `simulation/timestep_controller.py` | stability policy |
| `Backend` | `backends/base.py` | numerical-kernel boundary |
| `PlasmaSimulation` | `simulation/simulation.py` | public driver |

Public API:

```python
from plasma_core import PlasmaSimulation, SimulationConfig
sim = PlasmaSimulation(SimulationConfig.from_file("config.yaml"))
sim.initialize()
sim.run()
state = sim.state
diagnostics = sim.diagnostics
```

## Backends and the kernel boundary

`Backend` defines three kernels (Boris push, deposition, interpolation) with
an explicit array contract (float64, C-contiguous, SI).  `CPUReferenceBackend`
(NumPy) is authoritative.  `NumbaBackend` compiles the 1D kernels (serial,
deterministic) and falls back to the reference for 2D.  `CuPyBackend` and
`JAXBackend` are declared but raise `BackendUnavailableError` — they have not
been implemented or validated, and plasma_core never substitutes another
backend silently.

External kernels (Rust via PyO3, CUDA, a future Silica Flux device) plug in
by subclassing `Backend` and passing `interfaces.validate_backend()`, which
compares every kernel with the reference on randomised inputs.  MPI/domain
decomposition would wrap the models at the `SimulationModel` level (particle
exchange in `_apply_boundaries`, halo exchange in the field solve) without
changing the physics modules.

## Aerospace interface (Newton Rockets / Newton Orbital)

`interfaces/aerospace.py` defines data contracts: `PlasmaEnvironment`
(species, fields), `SpacecraftGeometry`, `PlasmaInteractionResult` (particle
flux, energy flux, charge accumulation, field interaction, diagnostics) and an
abstract `SpacecraftInteractionModel`.  **No spacecraft interaction is
implemented.**  The only concrete adapter, `wall_flux_from_simulation`, turns
the absorbing-wall loss ledger of a 1D run into time-averaged wall fluxes.

## Reproducibility and provenance

Every HDF5/Parquet output and checkpoint records: simulation ID, UTC
timestamp, configuration JSON and hash, software version, git commit and
dirty flag, Python/NumPy/SciPy versions, OS, CPU, backend, solver, grid,
particle count, time step, boundaries, collision model, random seed,
physical-constants version, pre-run warnings and stability events.
Diagnostics tables document their column definitions in
`diagnostics/manager.py`; each plotted quantity can be traced to the
configuration, the initial condition, the solver and the diagnostic function
that produced it.

## Implementation status (honest matrix)

| level | capability | status |
|---|---|---|
| 1 | single-species fluid | implemented, validated (Bohm–Gross) |
| 2 | multi-species fluid | implemented (shared Poisson field); validated only with one mobile species |
| 3 | electrostatic PIC | implemented 1D3V and 2D3V; 1D validated extensively, 2D tested for conservation |
| 4 | electromagnetic PIC | **foundation**: 1D periodic Yee + Poisson E_x; validated vs cold-plasma EM dispersion |
| 5 | kinetic distribution diagnostics | implemented (histograms, moments, anisotropy) |
| 6 | Vlasov | **foundation**: 1D1V, B = 0; validated vs Landau damping |
| 7 | magnetised plasma | uniform external B in PIC/fluid; validated (gyro, E×B, upper hybrid); no self-consistent B in ES |
| 8 | collisional plasma | effective-frequency (Langevin/BGK) only; Coulomb/MCC/neutral = extension points |
| 9 | reproducible experiments | seeds, metadata, checkpoint/restart bitwise, regression references |

Not implemented: relativistic pushers, 2D/3D Maxwell, charge-conserving
current deposition, absorbing EM boundaries, guiding-centre models,
radiation, nuclear/fusion physics, spacecraft charging.

## Repository layout

```
plasma_core/          package (see table above)
tests/                pytest suite (unit, property-based, physics validation, regression)
tests/regression/     stored reference measurements + regression tests
examples/             executable scientific examples (+ configs/ for the CLI)
benchmarks/           benchmark and profiling scripts
docs/                 PHYSICS, NUMERICS, PIC, VALIDATION (generated), ARCHITECTURE
scripts/acceptance.sh final acceptance workflow
```
