# Numerical methods

## Discretisation

**Spatial grid** (`grid/spatial_grid.py`).  Uniform Cartesian grid in 1D or 2D
(3D reserved).  Cell *i* spans [x_lo + iΔx, x_lo + (i+1)Δx); centres
x_i = x_lo + (i + ½)Δx.  Multi-dimensional arrays use C ordering with x as
the first (slowest) axis: scalar fields have shape `(nx[, ny])`, vector
fields `(nx[, ny], 3)`.  `PlasmaState` stores fields flattened to
`(N_cells, 3)` (C order) and `field_on_grid()` returns the reshaped view.

**Field layout** (`grid/field_grid.py`).  `COLLOCATED`: all quantities at cell
centres (ES-PIC, fluid, Vlasov).  `YEE_1D`: E_y, E_z, ρ, J at centres; B_y,
B_z at cell edges x_i = x_lo + iΔx; B_x uniform.  A full 2D/3D Yee lattice is
not implemented and requesting it raises `SolverConfigurationError`.

**Velocity grid** (`grid/velocity_grid.py`).  Uniform, cell-centred; moments
by the midpoint rule, which is spectrally accurate for smooth f vanishing at
±v_max.  Default extent u ± 6 v_th per species.

## Particle shape, deposition and interpolation (`pic/shapes.py`)

| shape | weights | S(k) |
|---|---|---|
| NGP | 1 at nearest node | sinc(kΔx/2) |
| CIC | linear on 2 nodes (bilinear in 2D) | sinc²(kΔx/2) |

* ρ_j = Σ_p q_p w_p W(x_j − x_p)/V_cell, implemented with `numpy.bincount`
  (no Python loops).  Σ_j ρ_j V_cell = Σ_p q_p w_p to round-off.
* Interpolation F(x_p) = Σ_j F_j W(x_j − x_p) uses the *same* shape
  (adjoint of deposition), which removes the self-force.  A mismatched
  deposition/interpolation pair is allowed but produces a startup warning.
* Edge-centred quantities (Yee B) use offset 0 instead of ½.
* Non-periodic axes: stencil indices are clamped to [0, n−1] — the charge in
  the half cell next to a wall is assigned to the boundary node (exact
  conservation; first-order accurate within Δx/2 of the wall).
* Current deposition: direct J = Σ q w v W/V with v^{n+1/2} at
  x^{n+1/2} = x^{n+1} − v^{n+1/2}Δt/2.  **Not charge-conserving**; harmless in
  the 1D EM solver because only J_y, J_z are used and E_x is solved from
  Poisson.  Esirkepov deposition is a declared extension point.

## Field solvers

**Poisson** (`solvers/poisson.py`):

* `fft_fd`: exact FFT solution of the 3-point (5-point in 2D) FD Laplacian
  via K² = Σ_a (2 sin(k_aΔx_a/2)/Δx_a)²; E by centred differences.  Discrete
  residual ~1e-14.  2nd-order accurate.
* `fft_spectral`: φ_k = ρ_k/(ε₀k²), E_k = −ikφ_k.  Exact for band-limited data.
* `fd`: sparse LU (`scipy.sparse.linalg.splu`), periodic (gauge row), Dirichlet
  (ghost cell φ_g = 2φ_wall − φ₀, wall on the domain face), Neumann (1D;
  φ_g = φ₀, zero-mean gauge).  2nd-order accurate.

Solver "tolerance": all Poisson solvers are direct, so there is no iteration
tolerance; the discrete residual is reported in every diagnostics row
(`poisson_residual`).  For `fft_spectral` that residual measures the FD
operator applied to the spectral solution and is O((kΔx)²) by design.

**Maxwell** (`solvers/maxwell.py`): Yee leapfrog written as
B half-step / E full step / B half-step so that B is available at integer
times.  Courant c Δt/Δx ≤ 1 (enforced).  Dispersion
sin(ωΔt/2)/(cΔt) = sin(kΔx/2)/Δx; dispersion-free at c Δt = Δx.

## Time integration

| model | scheme | order | stability |
|---|---|---|---|
| particles | leapfrog + Boris (v at half steps) | 2 | ω_pΔt < 2; Boris rotation unconditionally stable |
| 1D EM fields | Yee | 2 | c Δt/Δx ≤ 1 |
| fluid | MUSCL (MC/minmod) + Rusanov flux + SSP-RK3 (Shu–Osher) | 2 (smooth) | CFL (|u|+c_s)Δt/Δx ≤ 1; ω_pΔt < √3 |
| Vlasov | Strang splitting: Fourier shift in x, cubic B-spline in v | 2 | unconditionally stable |

Initialisation of the leapfrog: v^{−1/2} = Boris(v⁰, −Δt/2) with E⁰, B⁰.
Diagnostics at integer time t^n use a non-mutating trial push to obtain
v^{n+1/2}; K^n = Σ m w (|v^{n−1/2}|² + |v^{n+1/2}|²)/4 and the
time-synchronised velocity (v^{n−1/2} + v^{n+1/2})/2.  (For gyrating particles
the latter has magnitude |v| cos(ω_cΔt/2); the stored half-step speeds are
exact.)

Collisions are operator-split after the Boris push (first order in Δt for
the coupling; the O-U sub-step itself is exact).

## Stability constraints and pre-run assessment (`solvers/timestep.py`)

| criterion | number | required | recommended |
|---|---|---|---|
| plasma_oscillation | ω_p Δt | < 2 (leapfrog), < √3 (RK3); none for Vlasov | ≤ 0.2 |
| gyration | ω_c Δt | — | ≤ 0.2 |
| particle_cfl | v_max Δt/Δx, v_max = \|u\| + 5 v_th | < 1 | ≤ 0.5 |
| courant_em | c Δt/Δx | ≤ 1 | ≤ 0.95 |
| fluid_cfl | (\|u\| + c_s) Δt/Δx | ≤ 1 | ≤ `cfl` (0.4) |

Violating a *required* limit raises `StabilityCriterionViolation` before the
run unless `time.stability_policy: warn` is set explicitly, in which case the
run is flagged "UNSTABLE" in the summary, warnings and output metadata.
Additional physical warnings: Δx/λ_D > π (finite-grid heating), fewer than
10 particles per cell, domain shorter than 10 λ_D, Vlasov run longer than the
recurrence time T_R = 2π/(k₁Δv), mismatched deposition/interpolation.

During the run the stability monitor stops on NaN/Inf, |v| ≥ c, energy
divergence (default 100%) and charge divergence (default 1e-6) — see
`diagnostics/conservation.py`.  The fluid solver additionally stops if the
CFL number exceeds 1 or density/pressure become non-positive (no floors).

**Adaptive time stepping**: an interface (`AdaptiveTimestepController`) and a
proposal-only controller exist; no solver applies a variable Δt (the leapfrog
would need re-centring), which keeps every run reproducible.

## Boundary conditions

| type | particles | fields (default partner) | supported solvers |
|---|---|---|---|
| periodic | wrap | periodic | ES-PIC, EM-PIC, fluid, Vlasov, test particles |
| reflecting | specular (x → 2x_w − x, v_n → −v_n) | Neumann (E_n = 0) | ES-PIC (1D), fluid (mirror ghosts) |
| absorbing | removed + loss ledger | Dirichlet (grounded walls, optional wall potentials) | ES-PIC |
| open | outflow removal + ledger, no injection | Dirichlet φ = 0 (approximation) | ES-PIC |

The FFT Poisson methods require periodic fields; wall-bounded runs must use
`poisson: fd`.  Incompatible combinations are rejected at configuration time.

## Convergence

`plasma_core/validation/convergence.py` provides `run_study()` (error
functional evaluated over a resolution sequence, observed order
p = log(e_i/e_{i+1})/log(h_i/h_{i+1})).  Measured results (docs/VALIDATION.md):
Poisson 2.000, Yee dispersion 2.001, Boris Δt 1.998, deposited-density noise
vs particles per cell 0.497 (expected ½).

## Floating-point behaviour and determinism

* float64 throughout; float32 is rejected by configuration validation until
  validated for a backend.
* All runs are deterministic given (configuration, seed, software version,
  platform, backend): randomness only through `numpy.random.Generator`
  objects spawned from `SeedSequence(random_seed)`; time is derived from the
  integer step counter (t = nΔt), not accumulated.
* `numpy.bincount` sums in particle order; the Numba kernels also sum
  serially in particle order but with different intermediate rounding, so
  Numba vs reference agree to ~1e-15 relative per kernel call, not bitwise.
  Over a chaotic PIC run such differences grow; cross-backend comparisons
  therefore use statistical/physical quantities with documented tolerances.
* Checkpoint → restart reproduces the continuous run bitwise on the same
  platform/backend (tested for ES-PIC with stochastic collisions, absorbing
  walls, EM-PIC, fluid, Vlasov).

## Memory scaling

Per macro-particle: 68 bytes of state (positions, velocities, weight, ids,
species) plus O(N·3·8) bytes of temporaries during push/interpolation
(roughly 3–5 particle-state-sized temporaries in the NumPy reference backend;
the Numba backend allocates only the output).  Grids: 8 bytes per scalar
cell, 24 per vector cell.  Vlasov: 8 n_x n_v bytes per species plus FFT
workspace.  Measured peaks are printed by `plasma-core benchmark`.
