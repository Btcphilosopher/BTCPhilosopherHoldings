# Particle-in-cell

## The loop

The electrostatic PIC step (`pic/pic_solver.py::ElectrostaticPICModel.step`)
is short enough to read in full; it is the computational core of the package:

```
initialise particles            x⁰, v⁰                       initial_conditions/build_particles
        ↓                       (apply boundaries)
deposit charge                  ρ⁰ = Σ q w W(x_j − x⁰)/V      pic/charge_deposition.py
        ↓
solve fields                    ∇²φ⁰ = −ρ⁰/ε₀, E⁰ = −∇φ⁰      solvers/poisson.py
        ↓
half step back                  v^{−1/2} = Boris(v⁰, −Δt/2)   pic/particle_push.py
        ↓
┌──────────── step n → n+1 ─────────────────────────────────────────────┐
│ [diagnostics at tⁿ]       observe(): trial push → v^{n+1/2}, energies  │
│ interpolate fields        Eⁿ(x_p) = Σ_j E_j W(x_j − xⁿ_p)  (+ E_ext)   │
│ push particles            v^{n+1/2} = Boris(v^{n−1/2}, Eⁿ(x_p), B_ext) │
│ [collision operator]      only if configured                           │
│ advance positions         x^{n+1} = xⁿ + v^{n+1/2} Δt                  │
│ apply boundaries          periodic / reflecting / absorbing / open     │
│ deposit charge            ρ^{n+1}                                      │
│ solve fields              E^{n+1}                                      │
│ advance time              n ← n + 1   (t = nΔt from the integer)       │
└────────────────────────────────────────────────────────────────────────┘
```

## Particle → grid

Charge assignment with the NGP or CIC shape (`pic/shapes.py`), vectorised
with `numpy.bincount` over the flattened stencil.  Each macro-particle
represents w = n V_domain / N physical particles (V per unit transverse area
in 1D).  Immobile species are represented by a uniform background charge
density q n added to ρ (not by particles).

## Grid → field

Poisson's equation with the configured method (`fft_fd` default).  The
`fft_fd` choice solves exactly the same discrete equations as a
finite-difference solver, so the "solver error" is zero and the scheme error
is the O(Δx²) truncation of the Laplacian; the centred gradient then makes the
force spatially symmetric, which together with matched shapes makes total
momentum an exact invariant (measured: |ΔP|/P_scale ≈ 1e-16 over 20 plasma
periods).

## Field → particle

Interpolation with the same shape as deposition.  External uniform E and B
are added at the particle (E) and passed directly to the pusher (B).

## Push

The Boris scheme (`particles/particle_push.py`): half electric kick,
magnetic rotation by angle 2 arctan(ω_cΔt/2), half electric kick.  Exact
|v| conservation in a pure magnetic field, exact E × B drift in uniform
crossed fields, time-reversible.

## Electromagnetic variant (1D, foundation)

`ElectromagneticPIC1DModel.step`:

```
gather Eⁿ (centres) and Bⁿ (edges, offset 0) → Boris → v^{n+1/2}
x^{n+1} = xⁿ + v^{n+1/2}Δt, boundaries (periodic only)
J^{n+1/2}_{y,z} = Σ q w v^{n+1/2}_{y,z} W(x_j − x^{n+1/2})/V     (direct, not charge-conserving)
Yee: B^{n+1/2} = Bⁿ − ½Δt ∇×Eⁿ;  E^{n+1} = Eⁿ + Δt(c²∇×B^{n+1/2} − J/ε₀);  B^{n+1} = B^{n+1/2} − ½Δt ∇×E^{n+1}
E_x^{n+1} from Poisson(ρ^{n+1})
```

Gauss's law therefore holds to Poisson-solver precision every step.  This is
deliberately labelled a *foundation*: 1D only, periodic only, no absorbing
field boundaries, no charge-conserving current deposition, non-relativistic
particles.  It is validated against the cold-plasma EM dispersion relation
ω² = ω_p² + c²k² (error 1.0e-4).

## Conservation properties (measured, see docs/VALIDATION.md)

| property | ES-PIC (CIC, fft_fd, periodic) | status |
|---|---|---|
| charge | exact (deposition conserves charge; no particles lost) | measured 0 |
| momentum | exact to round-off (matched shapes + symmetric solve) | measured ~1e-16 |
| energy | not an exact invariant; secular numerical heating | measured 1.4e-4 over 20 periods (Δx = 0.5λ_D, ω_pΔt = 0.05, 100 ppc) |
| charge with absorbing walls | Q + Q_lost = Q₀ exactly | measured 8e-16 |

## Known numerical artefacts

* **Finite-grid instability / heating** when Δx ≫ λ_D (warning issued for
  Δx > πλ_D).
* **Statistical noise** ∝ (particles per cell)^{−1/2} (measured order 0.497).
  Quiet starts (`position_loading: quiet`, `velocity_loading: quiet`) reduce
  initial noise for wave studies; they are documented in the configuration.
* **Grid dispersion**: e.g. cold oscillation frequency is reduced by
  S(k)²κk/K² (1.1e-3 at kΔx = 0.098); the discrete theory matches the
  measurement to 1.1e-5.
* **Leapfrog phase error** sin(ωΔt/2) = ω₀Δt/2.

## Extending

New deposition shapes: add a `ShapeFunction` (TSC: order 2).  Charge-
conserving current deposition: implement `CurrentDepositionScheme` with
`charge_conserving = True`.  New pushers (relativistic Boris, Vay, Higuera–
Cary) belong next to `boris_push` with their own validation case.  New
kernels for accelerators: implement `backends.base.Backend` and pass
`interfaces.validate_backend`.
