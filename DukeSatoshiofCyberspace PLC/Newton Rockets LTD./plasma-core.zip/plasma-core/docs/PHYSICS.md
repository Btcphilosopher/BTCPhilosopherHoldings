# Physics reference

All equations are in SI units.  This document defines every symbol used by the
code; the implementing function is named next to each equation.

## Symbols and units

| symbol | meaning | unit |
|---|---|---|
| `q_s`, `m_s` | charge and mass of species *s* | C, kg |
| `n_s` | number density | m⁻³ |
| `T_s` | temperature (k_B T in energy units where noted) | K |
| `u_s` | bulk (drift) velocity | m s⁻¹ |
| `v`, `x` | particle velocity, position | m s⁻¹, m |
| `E`, `B` | electric field, magnetic flux density | V m⁻¹, T |
| `φ` | electrostatic potential | V |
| `ρ` | charge density | C m⁻³ |
| `J` | current density | A m⁻² |
| `p` | scalar pressure | Pa |
| `ε` | fluid total energy density | J m⁻³ |
| `f(x, v, t)` | distribution function (1D1V) | s m⁻⁴ (number per m³ per m s⁻¹) |
| `ε₀`, `μ₀`, `c`, `k_B`, `e`, `m_e`, `m_p` | constants, see `plasma_core/constants.py` (CODATA 2018) | SI |

Reduced dimensionality: a 1D (2D) simulation is homogeneous along the missing
axes; extensive quantities (energy, charge, particle number) are reported per
unit transverse area (1D) or per unit length (2D).  Densities remain per m³.

## Particle dynamics

**Lorentz force** (`physics/lorentz.py`)

    F = q (E + v × B),        dv/dt = (q/m)(E + v × B),        dx/dt = v

Non-relativistic.  The pusher stops a run if any |v| ≥ c; species with
sqrt(k_B T/m) > 0.1 c are rejected at configuration time.

## Fundamental plasma parameters

| quantity | equation | function |
|---|---|---|
| plasma frequency | ω_p,s = sqrt(n_s q_s² / (m_s ε₀));  ω_p² = Σ_s ω_p,s² | `plasma_frequency`, `total_plasma_frequency` |
| plasma period | T_p = 2π / ω_p | `plasma_period` |
| Debye length | λ_D,s = sqrt(ε₀ k_B T_s / (n_s q_s²));  λ_D⁻² = Σ_s λ_D,s⁻² (T_s > 0) | `debye_length`, `total_debye_length` |
| particles per Debye sphere | N_D = (4/3) π n λ_D³ | `debye_number` |
| cyclotron frequency | ω_c = \|q\| B / m (angular) | `cyclotron_frequency` |
| gyroperiod | T_c = 2π / ω_c | `gyroperiod` |
| Larmor radius | r_L = m v_⊥ / (\|q\| B) | `larmor_radius` |
| skin depth | d = c / ω_p | `physics/scales.py` |
| plasma beta | β = Σ_s n_s k_B T_s / (B² / 2μ₀) | `plasma_beta` |
| Alfvén speed | v_A = B / sqrt(μ₀ ρ_m),  ρ_m = Σ_s m_s n_s | `alfven_speed` |

**Thermal velocity — two conventions, never mixed** (`physics/thermal_velocity.py`).
Every call states the convention explicitly:

* `RMS_1D`: v_th = sqrt(k_B T / m) — standard deviation of one velocity
  component of a Maxwellian.  Used everywhere internally (loading,
  λ_D = v_th / ω_p, Bohm–Gross).
* `MOST_PROBABLE`: v_th = sqrt(2 k_B T / m) — appears in the argument of the
  plasma dispersion function, ζ = ω / (k · sqrt(2) · v_th,RMS).

Rotation sense: positive charges gyrate left-handed about B, negative charges
(electrons) right-handed.  This is checked in the gyro-motion validation.

## Electrostatics

**Poisson equation** (`solvers/poisson.py`)

    ∇²φ = −ρ / ε₀,        E = −∇φ,        ρ = Σ_s q_s n_s (+ immobile backgrounds)

Periodic and Neumann problems are solvable only for zero net charge; the mean
charge density is removed explicitly and reported
(`removed_mean_charge_density`).  Configurations whose species are not
quasi-neutral are rejected unless `solver.allow_non_neutral: true`.

## Electrodynamics

**Maxwell's equations** (`solvers/maxwell.py`)

    ∂B/∂t = −∇ × E,        ∂E/∂t = c² ∇ × B − J / ε₀,        ∇·E = ρ/ε₀,        ∇·B = 0

Supported geometry: **1D (x), periodic**, all three components.  With
∂/∂y = ∂/∂z = 0 the transverse fields decouple into two polarisations

    ∂B_y/∂t =  ∂E_z/∂x,     ∂E_z/∂t =  c² ∂B_y/∂x − J_z/ε₀
    ∂B_z/∂t = −∂E_y/∂x,     ∂E_y/∂t = −c² ∂B_z/∂x − J_y/ε₀

E_x is obtained from Gauss's law (Poisson) each step; B_x is uniform and
constant.  No 2D/3D Maxwell solver exists in plasma_core.

## Fluid model (`solvers/fluid.py`)

For each mobile species (1D in space, 3 velocity components):

    ∂n/∂t + ∇·(n v) = 0
    m n [∂v/∂t + (v·∇)v] = q n (E + v × B) − ∇p
    ∂ε/∂t + ∇·[(ε + p) v] = J·E + Q,      ε = p/(γ−1) + ½ m n |v|²,  J·E = q n v·E

The momentum equation is solved in conservative form
∂(nv)/∂t + ∇·(n v v + (p/m) I) = (q/m) n (E + v × B).  Q (external heating) is
zero; no source term is introduced implicitly.

**Equation-of-state closures** (`physics/pressure.py`)

| closure | pressure | c_s² | energy equation |
|---|---|---|---|
| isothermal | p = n k_B T₀ | k_B T₀ / m | not evolved (heat bath; energy not conserved) |
| polytropic | p = p₀ (n/n₀)^γ | γ p / (m n) | not evolved |
| adiabatic | polytropic with p₀ = n₀ k_B T₀ of the initial state | γ p/(m n) | not evolved (isentropic) |
| ideal gas | p = (γ−1)(ε − ½ m n \|v\|²) | γ p/(m n) | evolved |
| custom | user p(n), dp/dn | dp/dn / m | not evolved |

Assumptions: isotropic scalar pressure, no heat flux, no viscosity, local
closure.  For 1D Langmuir waves the kinetic small-kλ_D limit corresponds to
γ = 3 (one translational degree of freedom).

## Kinetic model (`solvers/vlasov.py`)

    ∂f/∂t + v·∇_x f + (q/m)(E + v × B)·∇_v f = C[f]

Implemented: 1D1V (x, v_x), periodic, B = 0 (a v × B term requires ≥ 2
velocity dimensions; configurations with B ≠ 0 are rejected).
Normalisation: n(x) = ∫ f dv_x; f has units s m⁻⁴.  The initial Maxwellian is
renormalised on the discrete velocity grid so that Σ_j f_j Δv = n exactly.

## Distribution moments

    n = ∫ f dv,     n u = ∫ v f dv,     k_B T_1V = (m/n) ∫ (v−u)² f dv

Particle estimators (`diagnostics/temperature.py`): with weighted averages
⟨g⟩ = Σ w g / Σ w,

    (3/2) k_B T = ½ m ⟨|v − u|²⟩,  u = ⟨v⟩                      (isotropic 3V)
    k_B T_∥ = m ⟨(v_∥ − u_∥)²⟩,   k_B T_⊥ = m ⟨|v_⊥ − u_⊥|²⟩/2      (relative to b = B/|B|)

Skewness E[(v−u)³]/σ³, Pearson kurtosis E[(v−u)⁴]/σ⁴ (= 3 for a Maxwellian).

## Energy and momentum

    K   = Σ_p ½ m_p w_p |v_p|²                   (particles)   or  ∫ ½ m n|v|² + p/(γ−1) dV (fluid)
    W_E = ∫ ½ ε₀ |E|² dV,        W_B = ∫ |B|²/(2μ₀) dV         (self-consistent fields only)
    energy_error = (E_tot(t) − E_tot(0)) / E_tot(0)
    P_JE = ∫ J·E dV = Σ_p q_p w_p v_p·E(x_p)       (field → particle power)

For a closed electrostatic system dK/dt = P_JE = −dW_E/dt (verified in
`tests/test_diagnostics.py`).  Particle momentum P = Σ m w v; EM field
momentum ε₀ ∫ E × B dV is reported for the electromagnetic solver.
External fields are not part of the energy budget: with an external E field,
or a collision operator, or an isothermal closure the system is open and the
energy-divergence monitor is disabled (and the reason recorded).

## Collisions (`physics/collisions.py`)

Collisions are never applied unless selected.  Implemented:

* `collisionless`: C[f] = 0.
* `effective_frequency` (ν, T_b, u_b): relaxation to a fixed background
  Maxwellian.  Particles: exact Ornstein–Uhlenbeck step
  v ← u_b + (v − u_b) e^{−νΔt} + sqrt(k_B T_b/m (1 − e^{−2νΔt})) ξ  (the
  temperature relaxes at rate 2ν — verified in `tests/test_fluid_vlasov.py`).
  Distribution functions: BGK, f ← f_M + (f − f_M) e^{−νΔt}, with f_M built
  from the local moments of f and corrected so its discrete moments 0–2 match
  f exactly.

Diagnostic-only estimates: ln Λ = ln(12π n λ_De³) and the Braginskii
electron collision rate 1/τ_e = √2 n_e Z e⁴ lnΛ / (12 π^{3/2} ε₀² √m_e (k_B T_e)^{3/2}).
Extension points (not implemented): Coulomb (binary), Monte-Carlo, neutral collisions.

## Dispersion relations used for validation (`physics/dispersion.py`)

* Electrostatic kinetic (drifting Maxwellians):
  1 + Σ_s (ω_ps²/(k² v_s²)) [1 + ζ_s Z(ζ_s)] = 0,  ζ_s = (ω − k u_s)/(√2 k v_s),
  Z(ζ) = i√π w(ζ) (Faddeeva function, `scipy.special.wofz`; entire, so
  Landau-continued for all Im ζ).  Solved by Newton iteration.  At kλ_D = 0.5
  the code returns ω/ω_p = 1.41566 − 0.15336 i.
* Bohm–Gross: ω² = ω_p² + 3 k² v_th² (v_th = sqrt(k_B T/m)).
* Upper hybrid (cold, k ⊥ B): ω² = ω_pe² + ω_ce².
* Cold two-species oscillation: ω² = ω_pe² + ω_pi².
* EM wave in cold plasma: ω² = ω_p² + c² k².
* Cold symmetric two-stream: ω² = a² + ω_b² − ω_b sqrt(ω_b² + 4a²), a = k v₀,
  ω_b² = ω_p²/2;  γ_max = ω_p/(2√2) at k v₀ = sqrt(3/8) ω_p.
* Discrete-scheme relations: Boris gyrofrequency (2/Δt) arctan(ω_cΔt/2),
  Boris orbit radius r_L sqrt(1 + (ω_cΔt/2)²), leapfrog oscillator
  sin(ωΔt/2) = ω₀Δt/2, ES-PIC cold dispersion
  ω_grid² = ω_p² S(k)² κ(k) k / K(k)² (principal alias), Yee vacuum
  dispersion sin(ωΔt/2)/(cΔt) = sin(kΔx/2)/Δx.

## Guiding-centre drifts (`physics/drifts.py`)

Analytical references and extension points only — the full-orbit solver
never uses them:

    v_E = E × B / B²,   v_∇B = (m v_⊥²/(2qB³)) B × ∇B,   v_c = (m v_∥²/(qB²)) (R_c × B)/R_c²,
    F_mirror = −μ ∇_∥ B,  μ = m v_⊥²/(2B)

## Scope and limitations

Implemented and validated: 1D/2D electrostatic PIC, 1D electromagnetic PIC
(foundation), test particles, 1D multi-species fluid, 1D1V Vlasov.  Not
implemented: relativistic dynamics, 2D/3D electromagnetics, charge-conserving
current deposition, Coulomb/MCC collisions, guiding-centre models, radiation,
spacecraft interaction.  See `docs/ARCHITECTURE.md` for the status matrix.

## References

* C. K. Birdsall, A. B. Langdon, *Plasma Physics via Computer Simulation* (IOP, 1991).
* R. W. Hockney, J. W. Eastwood, *Computer Simulation Using Particles* (IOP, 1988).
* J. P. Boris, "Relativistic plasma simulation — optimization of a hybrid code", Proc. 4th Conf. Num. Sim. Plasmas (1970).
* K. S. Yee, IEEE Trans. Antennas Propag. 14, 302 (1966).
* C. Z. Cheng, G. Knorr, J. Comput. Phys. 22, 330 (1976).
* B. D. Fried, S. D. Conte, *The Plasma Dispersion Function* (Academic Press, 1961).
* P. L. Bhatnagar, E. P. Gross, M. Krook, Phys. Rev. 94, 511 (1954).
* C.-W. Shu, S. Osher, J. Comput. Phys. 77, 439 (1988).
* S. I. Braginskii, in *Reviews of Plasma Physics* Vol. 1 (1965).
* T. Zh. Esirkepov, Comput. Phys. Commun. 135, 144 (2001) (extension point only).
* E. Tiesinga et al., Rev. Mod. Phys. 93, 025010 (2021) (CODATA 2018).
