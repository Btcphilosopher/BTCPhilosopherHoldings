# Validation report

This file is **generated** by `plasma-core validation-suite --report docs/VALIDATION.md`
(`plasma_core/validation/report.py`).  Every number below was measured by running the
listed simulation; nothing is typed by hand.  A case passes only if *every* error listed
under "tolerances" is within its tolerance; tolerances are fixed in
`plasma_core/validation/cases.py` from the known truncation error of each method.

Interpretation rules used throughout:

* "analytical" values come from closed-form or semi-analytical theory
  (`plasma_core/physics/dispersion.py`), never from simulation output;
* "numerical" values are measurements from simulated time series with the
  estimators in `plasma_core/diagnostics/analysis.py`;
* where the discrete dispersion relation of the scheme is known, both the
  continuum error and the error relative to the discrete theory are given; the
  latter isolates implementation errors from expected truncation error;
* a pass means agreement within the stated tolerance for the stated configuration
  only.  It is not a claim of validity for other parameters.

Generated 2026-11-28T08:27:59+00:00 with plasma_core 0.1.0 (git 600292675d02 + local changes), Python 3.13.18, NumPy 2.5.3, Linux x86_64.

## Summary

| case | result | runtime [s] |
|---|---|---|
| gyro_motion | PASS | 1.5 |
| exb_drift | PASS | 1.6 |
| poisson_equation | PASS | 0.0 |
| electromagnetic_wave | PASS | 0.1 |
| plasma_oscillation | PASS | 3.3 |
| langmuir_wave | PASS | 21.6 |
| upper_hybrid_oscillation | PASS | 7.5 |
| two_stream_instability | PASS | 16.9 |
| landau_damping | PASS | 1.5 |
| fluid_langmuir_wave | PASS | 1.4 |
| electromagnetic_plasma_wave | PASS | 6.3 |
| energy_momentum_conservation | PASS | 3.3 |
| charge_conservation_absorbing | PASS | 4.4 |
| checkpoint_restart | PASS | 0.5 |
| reproducibility | PASS | 0.0 |
| convergence: poisson_grid_refinement | PASS | 0.0 |
| convergence: yee_dispersion_grid_refinement | PASS | 0.0 |
| convergence: boris_timestep_refinement | PASS | 0.7 |
| convergence: pic_particle_number_refinement | PASS | 0.5 |

## gyro_motion

**Problem.** Electron (q=-e) with v_perp=1e5 m/s, v_par=2e4 m/s in uniform B=1e-3 T along z: helical orbit.

**Equations.** m dv/dt = q v x B;  omega_c = |q|B/m;  r_L = m v_perp/(|q|B); rotation right-handed about B for q<0. Boris discrete theory: omega_B = (2/dt) arctan(omega_c dt/2), r_B = r_L sqrt(1+(omega_c dt/2)^2).

**Numerical method.** test_particle model, Boris pusher, omega_c dt = 0.05, 20 gyro-periods; frequency from the slope of the unwrapped velocity phase, radius from a least-squares circle fit of (x, y).

**Configuration.** {B_t: 0.001, dt_s: 2.84282e-10, omega_c_dt: 0.05, periods: 20}

**Analytical result.**

- `omega_c_rad_s` = 1.75882e+08
- `omega_boris_rad_s` = 1.75845e+08
- `larmor_radius_m` = 0.000568563
- `boris_radius_m` = 0.000568741
- `v_perp_m_s` = 100000
- `v_par_m_s` = 20000

**Numerical result.**

- `omega_rad_s` = 1.75845e+08
- `radius_m` = 0.000568741
- `v_perp_m_s` = 100000
- `v_par_m_s` = 20000
- `rotation_sense` = right-handed
- `kinetic_energy_rel_variation` = 3.81171e-15

**Error** (tolerance in brackets where it is a pass criterion).

- `omega_rel_vs_boris` = 1.01688e-15  [<= 1e-09]
- `omega_rel_vs_continuum` = 0.000208255  [<= 0.0003]
- `radius_rel_vs_boris` = 2.41436e-10  [<= 1e-09]
- `radius_rel_vs_continuum` = 0.000312451  [<= 0.0005]
- `v_perp_rel` = 5.82077e-16  [<= 1e-12]
- `v_par_rel` = 6.16637e-14  [<= 1e-12]
- `energy_rel_variation` = 3.81171e-15  [<= 1e-12]

**Conclusion.** PASS: the orbit matches the Boris discrete theory to round-off; the continuum error is the known O((omega_c dt)^2/12) phase error and O((omega_c dt)^2/8) radius error; |v| is conserved exactly.

## exb_drift

**Problem.** Electron and proton starting at rest in E = 100 V/m x-hat, B = 1e-3 T z-hat.

**Equations.** v_E = E x B / B^2 = (0, -E/B, 0) = (0, -1e5, 0) m/s, independent of charge and mass.

**Numerical method.** test_particle model, Boris, omega_c dt = 0.05, 10 gyro-periods; guiding-centre drift from a linear least-squares fit y(t) = v t + a cos(omega_B t) + b sin(omega_B t) + c.

**Configuration.** {electron: {dt_s: 2.84282e-10, omega_c_dt: 0.05, periods: 10}, proton: {dt_s: 5.21984e-07, omega_c_dt: 0.05, periods: 10}}

**Analytical result.**

- `v_E_m_s` = [0, -100000, 0]

**Numerical result.**

- `electron_drift_m_s` = [-1.7031e-09, -100000, 0]
- `proton_drift_m_s` = [7.7651e-10, -100000, 0]

**Error** (tolerance in brackets where it is a pass criterion).

- `electron_drift_rel` = 1.70533e-14  [<= 1e-09]
- `proton_drift_rel` = 8.06606e-15  [<= 1e-09]

**Conclusion.** PASS: the Boris scheme reproduces the E x B drift to round-off for both species (charge and mass independence verified).

## poisson_equation

**Problem.** Poisson equation for sinusoidal densities (periodic and grounded walls), a uniform neutral plasma and a single-cell point-like source.

**Equations.** d^2 phi/dx^2 = -rho/eps0,  E = -d phi/dx

**Numerical method.** fft_fd, fft_spectral, sparse fd (periodic & Dirichlet ghost-cell); grids 32-256 cells.

**Configuration.** {L_m: 1, cells: [32, 64, 128, 256]}

**Analytical result.**

- `point_source` = phi(s) = (q/eps0)[s^2/(2L) - |s|/2 + L/12] (periodic Green's function, zero mean); the 3-point Laplacian of this piecewise quadratic is exact at the nodes.
- `sinusoid` = rho = A sin(kx): phi = A sin(kx)/(eps0 k^2), E = -A cos(kx)/(eps0 k)
- `dirichlet` = k = pi/L so that phi(0) = phi(L) = 0

**Numerical result.**

- `fft_fd_periodic_phi_rel_err_n32_to_256` = [0.00321896, 0.000803578, 0.000200822, 5.02009e-05]
- `fft_fd_periodic_E_rel_err_n32_to_256` = [0.00321483, 0.00080332, 0.000200806, 5.01999e-05]
- `fft_spectral_periodic_phi_rel_err_n32_to_256` = [3.19452e-16, 4.57551e-16, 4.77014e-16, 5.1168e-16]
- `fft_spectral_periodic_E_rel_err_n32_to_256` = [4.06738e-16, 4.05268e-16, 5.06127e-16, 5.17082e-16]
- `fd_periodic_phi_rel_err_n32_to_256` = [0.00321896, 0.000803578, 0.000200822, 5.02009e-05]
- `fd_periodic_E_rel_err_n32_to_256` = [0.00321483, 0.00080332, 0.000200806, 5.01999e-05]
- `fd_dirichlet_phi_rel_err_n32_to_256` = [0.000803578, 0.000200822, 5.02009e-05, 1.25499e-05]
- `fd_dirichlet_E_rel_err_n32_to_256` = [0.00080332, 0.000200806, 5.01999e-05, 1.25499e-05]
- `observed_order_phi` = {fft_fd_periodic: 2.00013, fd_periodic: 2.00013, fd_dirichlet: 2.00003}

**Error** (tolerance in brackets where it is a pass criterion).

- `fft_fd_periodic_order_deviation` = 0.000130366  [<= 0.05]
- `fft_spectral_phi_rel_err` = 5.1168e-16  [<= 1e-12]
- `fd_periodic_order_deviation` = 0.000130366  [<= 0.05]
- `fd_dirichlet_order_deviation` = 3.26009e-05  [<= 0.05]
- `uniform_neutral_max_E_v_m` = 0  [<= 1e-20]
- `point_source_phi_rel_err` = 1.84326e-16  [<= 1e-10]
- `point_source_E_rel_err` = 2.7774e-15  [<= 1e-10]
- `point_source_residual` = 4.95376e-15  [<= 1e-10]

**Conclusion.** PASS: finite-difference solvers converge at second order; the spectral solver is exact for band-limited data; the point-source solution equals the discrete Green's function to round-off.

## electromagnetic_wave

**Problem.** Vacuum transverse wave (E_y, B_z), mode 4 on a 1 m periodic domain with 128 cells, standing and travelling initial conditions, Courant numbers 0.5 and 1.0.

**Equations.** dB_z/dt = -dE_y/dx, dE_y/dt = -c^2 dB_z/dx; omega = c k with c = 1/sqrt(mu0 eps0); Yee discrete dispersion sin(omega dt/2)/(c dt) = sin(k dx/2)/dx.

**Numerical method.** Yee1DMaxwellSolver; standing-wave frequency by nonlinear least squares; travelling-wave phase velocity from the unwrapped phase of the Fourier mode; wavelength from the spectral peak.

**Configuration.** {L_m: 1, cells: 128, mode: 4, k_dx: 0.19635, courant: [0.5, 1]}

**Analytical result.**

- `yee_omega_courant0.5` = 7.52552e+09
- `yee_omega_courant1.0` = 7.53461e+09
- `c_from_mu0_eps0_m_s` = 2.99792e+08
- `omega_ck_rad_s` = 7.53461e+09

**Numerical result.**

- `standing_omega_courant0.5` = 7.52552e+09
- `standing_amplitude_decay_rate_courant0.5` = 0
- `phase_velocity_m_s_courant0.5` = 2.9943e+08
- `wavelength_m_courant0.5` = 0.25
- `numerical_dispersion_omega_over_ck_courant0.5` = 0.998794
- `standing_omega_courant1.0` = 7.53461e+09
- `standing_amplitude_decay_rate_courant1.0` = 0
- `phase_velocity_m_s_courant1.0` = 2.99789e+08
- `wavelength_m_courant1.0` = 0.25
- `numerical_dispersion_omega_over_ck_courant1.0` = 1

**Error** (tolerance in brackets where it is a pass criterion).

- `standing_omega_rel_vs_yee_courant0.5` = 2.22585e-09  [<= 1e-08]
- `phase_velocity_rel_vs_yee_courant0.5` = 2.52577e-06  [<= 5e-05]
- `phase_velocity_rel_vs_c_courant0.5` = 0.00120803  [<= 0.002]
- `wavelength_rel_courant0.5` = 0  [<= 0]
- `standing_omega_rel_vs_yee_courant1.0` = 0  [<= 1e-08]
- `phase_velocity_rel_vs_yee_courant1.0` = 9.9081e-06  [<= 5e-05]
- `phase_velocity_rel_vs_c_courant1.0` = 9.9081e-06  [<= 5e-05]
- `wavelength_rel_courant1.0` = 0  [<= 0]

**Conclusion.** PASS: frequencies match the Yee dispersion relation to round-off; at Courant 0.5 the numerical phase velocity is below c by the predicted O((k dx)^2 (1-C^2)/24) = 1.20e-03; at Courant 1 the scheme is dispersion-free. The travelling initialisation (B_z = E_y/c sampled at edges, same time level) contains a small backward wave that limits the phase-velocity measurement to ~1e-5; the standing-wave frequency is the precise dispersion measurement (fit precision ~1e-9).

## plasma_oscillation

**Problem.** Cold electron plasma (n = 1e12 m^-3) over immobile protons; 1% density perturbation at mode 1.

**Equations.** omega = omega_pe = sqrt(n e^2/(m_e eps0)); discrete ES-PIC (CIC, FD Poisson, centred gradient, leapfrog): omega^2 = omega_p^2 S(k)^2 kappa(k) k / K(k)^2, sin(omega dt/2) = omega_grid dt/2.

**Numerical method.** electrostatic_pic, 64 cells, 100 particles/cell (quiet start), omega_p dt = 0.05, 10 periods; frequency from a least-squares fit of the mode-1 Fourier amplitude of E_x.

**Configuration.** {cells: 64, ppc: 100, omega_p_dt: 0.05, amplitude: 0.01, k_dx: 0.0981748}

**Analytical result.**

- `omega_p_rad_s` = 5.64146e+07
- `omega_discrete_theory_rad_s` = 5.63525e+07

**Numerical result.**

- `omega_rad_s` = 5.63532e+07
- `omega_std_err` = 10.8437
- `fit_r2` = 1
- `amplitude_rate_s` = 66.7269
- `max_abs_energy_error` = 0.00044352

**Error** (tolerance in brackets where it is a pass criterion).

- `omega_rel_vs_omega_p` = 0.00108909  [<= 0.003]
- `omega_rel_vs_discrete_theory` = 1.14574e-05  [<= 0.0003]
- `max_abs_energy_error` = 0.00044352  [<= 0.005]

**Conclusion.** PASS: the oscillation frequency emerges from deposition + Poisson + push and agrees with omega_pe within the predicted O((k dx)^2, (omega dt)^2) discretisation error; the residual relative to the discrete theory is set by the nonlinear (1% amplitude) and alias terms neglected in it.

## langmuir_wave

**Problem.** Warm electron plasma, k lambda_D = 0.2, 5% density perturbation (T = 2.1276e+05 K).

**Equations.** kinetic: 1 + (1/(k lambda_D)^2)[1 + zeta Z(zeta)] = 0, zeta = omega/(sqrt2 k v_th); fluid limit (Bohm-Gross): omega^2 = omega_p^2 + 3 k^2 v_th^2, v_th = sqrt(kT/m).

**Numerical method.** electrostatic_pic, 64 cells (dx = 0.49 lambda_D), 1000 particles/cell, quiet start in x and v, omega_p dt = 0.05, 8 periods; frequency by least squares on the E_x mode-1 amplitude.

**Configuration.** {k_lambda_D: 0.2, temperature_k: 212760, cells: 64, ppc: 1000}

**Analytical result.**

- `omega_kinetic_rad_s` = 6.00243e+07
- `gamma_kinetic_s` = -3108.86
- `omega_bohm_gross_rad_s` = 5.97036e+07

**Numerical result.**

- `omega_rad_s` = 6.00207e+07
- `omega_std_err` = 5434.46
- `amplitude_rate_s` = -10752.9
- `fit_r2` = 0.999039

**Error** (tolerance in brackets where it is a pass criterion).

- `omega_rel_vs_kinetic` = 5.87375e-05  [<= 0.005]
- `omega_rel_vs_bohm_gross` = 0.00531165  [reported only]

**Conclusion.** PASS: the thermal frequency shift emerges from the particle dynamics and agrees with the kinetic (Landau) dispersion root; Bohm-Gross is shown for reference (it is the small-k lambda_D limit).

## upper_hybrid_oscillation

**Problem.** Cold electron plasma in B = 0.8 m_e omega_pe / e along z, perturbation with k along x (k perp B).

**Equations.** omega_UH^2 = omega_pe^2 + omega_ce^2

**Numerical method.** electrostatic_pic with uniform external B, Boris, omega_p dt = 0.02, 64 cells x 100 ppc, 8 periods.

**Configuration.** {B_t: 0.000256602, omega_c_over_omega_p: 0.8, omega_p_dt: 0.02}

**Analytical result.**

- `omega_uh_rad_s` = 7.22459e+07

**Numerical result.**

- `omega_rad_s` = 7.21926e+07
- `fit_r2` = 1

**Error** (tolerance in brackets where it is a pass criterion).

- `omega_rel_vs_upper_hybrid` = 0.000738978  [<= 0.003]

**Conclusion.** PASS: magnetised oscillation frequency agrees with the cold upper-hybrid frequency within the grid-shape correction (~(k dx)^2/12 on the omega_p^2 term).

## two_stream_instability

**Problem.** Two counter-streaming electron beams (+-v0, each n0/2, v_th = 0.05 v0) over immobile ions; mode 1 at the cold-beam fastest-growing wavenumber k v0 = sqrt(3/8) omega_p; seed 1e-3.

**Equations.** 1 + sum_s (omega_ps^2/(k^2 v_s^2)) [1 + zeta_s Z(zeta_s)] = 0, zeta_s = (omega - k u_s)/(sqrt2 k v_s); cold limit gamma = omega_p/(2 sqrt2).

**Numerical method.** electrostatic_pic, 128 cells, 200 particles/cell/beam, omega_p dt = 0.04; growth rate from a linear fit of log|E_1(t)| over the automatically selected linear phase (see fit_growth_rate).

**Configuration.** {v0_m_s: 5.49829e+06, v_th_m_s: 274914, temperature_k: 4986.55, k_v0_over_omega_p: 0.612372, cells: 128, ppc_per_beam: 200, seed: 7}

**Analytical result.**

- `gamma_kinetic_s` = 1.98888e+07
- `omega_r_kinetic_rad_s` = 0
- `gamma_cold_s` = 1.99456e+07

**Numerical result.**

- `gamma_s` = 1.9586e+07
- `gamma_std_err_s` = 107654
- `fit_interval_s` = [1.33299e-07, 3.65863e-07]
- `fit_r2` = 0.9951
- `n_fit_points` = 165
- `saturation_amplitude_v_m` = 1413.54
- `gamma_over_omega_p` = 0.34718

**Error** (tolerance in brackets where it is a pass criterion).

- `gamma_rel_vs_kinetic` = 0.0152234  [<= 0.05]
- `gamma_rel_vs_cold` = 0.0180267  [reported only]
- `fit_r2_deficit` = 0.0049003  [<= 0.01]

**Conclusion.** PASS: exponential growth emerges from the seeded perturbation; the measured growth rate (a numerical measurement) agrees with the kinetic linear theory within the tolerance set by finite particle number, the seed's mixture of normal modes and grid effects.

## landau_damping

**Problem.** Maxwellian electrons (10 eV), 1% density perturbation at k lambda_D = 0.5, immobile ions.

**Equations.** df/dt + v df/dx - (e/m) E df/dv = 0, dE/dx = rho/eps0; linear theory: root of 1 + (1/(k lambda_D)^2)[1 + zeta Z(zeta)] = 0.

**Numerical method.** vlasov (1D1V semi-Lagrangian, Strang), 32 x 256 phase-space cells, v in +-6 v_th, omega_p dt = 0.05, t <= 30/omega_p (recurrence time 268/omega_p); damping from log of |E_1| peaks, frequency from peak spacing.

**Configuration.** {k_lambda_D: 0.5, nx: 32, nv: 256, omega_p_dt: 0.05}

**Analytical result.**

- `omega_rad_s` = 7.9864e+07
- `gamma_s` = -8.65171e+06
- `omega_over_omega_p` = 1.41566
- `gamma_over_omega_p` = -0.153359

**Numerical result.**

- `omega_rad_s` = 7.98995e+07
- `gamma_s` = -8.67134e+06
- `gamma_std_err_s` = 912.636
- `fit_r2` = 1
- `omega_over_omega_p` = 1.41629
- `gamma_over_omega_p` = -0.153707
- `final_relative_mass_error` = -4.5229e-12
- `max_abs_energy_error` = 1.30701e-07

**Error** (tolerance in brackets where it is a pass criterion).

- `gamma_rel` = 0.00226855  [<= 0.02]
- `omega_rel` = 0.000444938  [<= 0.01]
- `mass_error` = 4.5229e-12  [<= 1e-08]
- `energy_error` = 1.30701e-07  [<= 0.0001]

**Conclusion.** PASS: collisionless damping emerges from phase mixing and matches the Landau root; the frequency estimate from peak spacing has an O(1e-3) bias from the transient of the initial perturbation.

## fluid_langmuir_wave

**Problem.** Electron fluid (adiabatic gamma = 3, T = 10 eV) over immobile ions, 1% perturbation at mode 1.

**Equations.** omega^2 = omega_p^2 + gamma k^2 k_B T/m (linearised Euler-Poisson).

**Numerical method.** fluid model, MUSCL-MC + Rusanov + SSP-RK3, 64 cells, omega_p dt = 0.05, 10 periods.

**Configuration.** {gamma: 3, T_ev: 10, cells: 64}

**Analytical result.**

- `omega_bohm_gross_rad_s` = 5.82316e+07

**Numerical result.**

- `omega_rad_s` = 5.82344e+07
- `amplitude_rate_s` = -2411.52
- `fit_r2` = 1
- `max_abs_energy_error` = 1.30514e-05

**Error** (tolerance in brackets where it is a pass criterion).

- `omega_rel` = 4.90217e-05  [<= 0.001]
- `max_abs_energy_error` = 1.30514e-05  [<= 0.001]
- `mass_error` = 5.17578e-14  [<= 1e-12]

**Conclusion.** PASS: the fluid model reproduces the Bohm-Gross frequency; mass is conserved to round-off by the finite-volume form; the small energy error is numerical dissipation of the limiter/Rusanov flux.

## electromagnetic_plasma_wave

**Problem.** Standing E_y wave (mode 1, k c = omega_p) in a cold electron plasma with immobile ions.

**Equations.** omega^2 = omega_p^2 + c^2 k^2 (cold unmagnetised plasma, transverse mode).

**Numerical method.** electromagnetic_pic (1D Yee + direct J_y,J_z deposition, E_x from Poisson), 128 cells, 50 ppc, c dt/dx = 0.5, 6 plasma periods.

**Configuration.** {L_m: 33.3894, cells: 128, courant: 0.5, k_c_over_omega_p: 1}

**Analytical result.**

- `omega_rad_s` = 7.97823e+07
- `omega_over_omega_p` = 1.41421

**Numerical result.**

- `omega_rad_s` = 7.97743e+07
- `fit_r2` = 1
- `max_abs_energy_error` = 0.000451575
- `max_gauss_residual` = 0.698309

**Error** (tolerance in brackets where it is a pass criterion).

- `omega_rel` = 0.000100423  [<= 0.001]
- `max_abs_energy_error` = 0.000451575  [<= 0.005]

**Conclusion.** PASS: the coupled particle-field system reproduces the cold-plasma EM dispersion relation. This validates the 1D EM-PIC foundation only (1D, periodic, non-charge-conserving current deposition made harmless by solving E_x from Poisson).

## energy_momentum_conservation

**Problem.** Thermal electron plasma (10 eV, random loading), periodic, 20 plasma periods, dx = 0.5 lambda_D.

**Equations.** d/dt [sum m v^2/2 + integral eps0 E^2/2] = 0;  d/dt sum m v = 0 (closed periodic system).

**Numerical method.** electrostatic_pic, CIC deposition = CIC interpolation, FD Poisson via FFT, centred gradient (momentum-conserving scheme), omega_p dt = 0.05, 100 ppc.

**Configuration.** {cells: 64, ppc: 100, dx_over_lambda_D: 0.5, omega_p_dt: 0.05, seed: 11}

**Analytical result.**

- `energy_error` = 0
- `momentum_error` = 0
- `charge_error` = 0

**Numerical result.**

- `max_abs_energy_error` = 0.000136775
- `final_energy_error` = 0.000124893
- `max_momentum_error` = 7.20326e-17
- `max_charge_error` = 0

**Error** (tolerance in brackets where it is a pass criterion).

- `max_abs_energy_error` = 0.000136775  [<= 0.01]
- `max_momentum_error` = 7.20326e-17  [<= 1e-10]
- `max_charge_error` = 0  [<= 1e-14]

**Conclusion.** PASS: momentum is conserved to round-off (the scheme is momentum-conserving by construction); total energy is not an exact invariant of momentum-conserving PIC and shows a small measured drift (numerical heating); charge is exactly conserved.

## charge_conservation_absorbing

**Problem.** Thermal electrons between grounded absorbing walls (sheath formation); immobile ions.

**Equations.** Q(t) + Q_lost(t) = Q(0);  W(t) + W_lost(t) = W(0) for the particle weight (mass).

**Numerical method.** electrostatic_pic with absorbing particle boundaries and Dirichlet (phi = 0) walls, fd Poisson.

**Configuration.** {L_m: 0.2, cells: 32, particles: 20000, omega_p_dt: 0.04}

**Analytical result.**

- `accounted_charge_residual` = 0
- `accounted_mass_residual` = 0

**Numerical result.**

- `particles_initial` = 20000
- `particles_remaining` = 14295
- `particles_lost` = 5705
- `charge_lost_c` = -9.14042e-09
- `energy_lost_j` = 1.63033e-07
- `max_accounted_charge_error` = 8.26057e-16
- `max_accounted_mass_error` = 0
- `grid_vs_particle_charge_rel` = 1.03257e-16
- `final_accounted_energy_error` = 0.000446418

**Error** (tolerance in brackets where it is a pass criterion).

- `max_accounted_charge_error` = 8.26057e-16  [<= 1e-13]
- `max_accounted_mass_error` = 0  [<= 1e-13]
- `grid_vs_particle_charge_rel` = 1.03257e-16  [<= 1e-13]

**Conclusion.** PASS: every particle, coulomb and joule leaving the domain is accounted for in the loss ledger; deposited grid charge equals the particle charge (deposition is charge-conserving). The accounted energy error is reported but not a pass criterion: with grounded walls the wall potential does work (image charges) that is not part of the closed-system budget.

## checkpoint_restart

**Problem.** Warm plasma wave with stochastic (Langevin) collisions: 200 steps continuous vs 100 steps, checkpoint, restart from file, 100 steps.

**Equations.** bitwise identity of the final state and diagnostic history

**Numerical method.** HDF5 checkpoint of particles, fields, step counter, random-generator state and diagnostics.

**Configuration.** {steps: 200, checkpoint_step: 100, collision_frequency_hz: 564146}

**Analytical result.**

- `max_position_difference_m` = 0
- `max_velocity_difference_m_s` = 0

**Numerical result.**

- `max_position_difference_m` = 0
- `max_velocity_difference_m_s` = 0
- `max_diagnostic_difference` = 0
- `rows_continuous` = 21
- `rows_restarted` = 21

**Error** (tolerance in brackets where it is a pass criterion).

- `max_position_difference_m` = 0  [<= 0]
- `max_velocity_difference_m_s` = 0  [<= 0]
- `max_diagnostic_difference` = 0  [<= 0]
- `row_count_mismatch` = 0  [<= 0]

**Conclusion.** PASS: the restarted trajectory, including the random collision stream, is bitwise identical to the continuous run on the same platform/backend.

## reproducibility

**Problem.** Initial particle populations for identical and different seeds.

**Equations.** population = F(configuration, seed, software version)

**Numerical method.** numpy PCG64 Generators spawned from SeedSequence(random_seed), one per species.

**Configuration.** {seed: 42, particles: 1000}

**Analytical result.**

- `identical_difference` = 0

**Numerical result.**

- `identical_seed_max_difference` = 0
- `different_seed_max_difference` = 2.09562e+06

**Error** (tolerance in brackets where it is a pass criterion).

- `identical_seed_max_difference` = 0  [<= 0]
- `different_seed_is_different` = 0  [<= 0]

**Conclusion.** PASS: initial populations are deterministic functions of the recorded seed.

## Convergence studies

### poisson_grid_refinement

max relative error of E for rho = sin(2 pi x / L), fft_fd solver.  Expected order 2.0 (tolerance +-0.1).

| dx [m] | error | observed order |
|---|---|---|
| 0.0625 | 1.2884e-02 |  |
| 0.03125 | 3.2148e-03 | 2.003 |
| 0.01562 | 8.0332e-04 | 2.001 |
| 0.007812 | 2.0081e-04 | 2.000 |
| 0.003906 | 5.0200e-05 | 2.000 |

Result: PASS (final observed order 2.000).

### yee_dispersion_grid_refinement

relative phase-velocity error of the Yee scheme at Courant 0.5 (discrete dispersion relation).  Expected order 2.0 (tolerance +-0.1).

| dx [m] | error | observed order |
|---|---|---|
| 0.03125 | 1.9458e-02 |  |
| 0.01562 | 4.8307e-03 | 2.010 |
| 0.007812 | 1.2055e-03 | 2.003 |
| 0.003906 | 3.0124e-04 | 2.001 |

Result: PASS (final observed order 2.001).

### boris_timestep_refinement

relative gyrofrequency error of the Boris pusher (5 gyro-periods).  Expected order 2.0 (tolerance +-0.1).

| dt [s] | error | observed order |
|---|---|---|
| 2.274e-09 | 1.3022e-02 |  |
| 1.137e-09 | 3.3135e-03 | 1.975 |
| 5.686e-10 | 8.3209e-04 | 1.994 |
| 2.843e-10 | 2.0826e-04 | 1.998 |

Result: PASS (final observed order 1.998).

### pic_particle_number_refinement

RMS relative fluctuation of the CIC-deposited electron density at load time (random positions, mean of 8 seeds); statistical convergence ~ ppc^(-1/2), not truncation convergence.  Expected order 0.5 (tolerance +-0.05).

| 1/ppc | error | observed order |
|---|---|---|
| 0.1 | 2.6357e-01 |  |
| 0.025 | 1.2821e-01 | 0.520 |
| 0.00625 | 6.3209e-02 | 0.510 |
| 0.001563 | 3.1755e-02 | 0.497 |

Result: PASS (final observed order 0.497).
