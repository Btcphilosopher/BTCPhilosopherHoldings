import math

import pytest
from conftest import es_config

from plasma_core import InvalidPhysicalConfiguration, SimulationConfig, Species, electron, ion, positron, proton
from plasma_core.constants import ATOMIC_MASS_CONSTANT, ELECTRON_MASS, ELEMENTARY_CHARGE, PROTON_MASS
from plasma_core.species import custom_species, neutralizing_background


def test_presets_and_factories():
    e = Species(preset="electron", density_m3=1e12, temperature_ev=2.0)
    assert e.charge_c == -ELEMENTARY_CHARGE and e.mass_kg == ELECTRON_MASS and e.name == "electron"
    assert math.isclose(e.temperature_k, 2 * 11604.518, rel_tol=1e-6)
    assert proton(1e10).mass_kg == PROTON_MASS
    assert positron(1).charge_c == ELEMENTARY_CHARGE
    o = ion(1e10, charge_state=2, mass_amu=16.0, name="O2+")
    assert o.charge_c == 2 * ELEMENTARY_CHARGE and o.mass_kg == 16 * ATOMIC_MASS_CONSTANT
    c = custom_species("dust", charge_c=-100 * ELEMENTARY_CHARGE, mass_kg=1e-15, density_m3=1e8)
    assert c.charge_to_mass_c_kg < 0
    s = Species(name="x", charge_e=1, mass_amu=4, density_cm3=1.0)
    assert s.density_m3 == 1e6


@pytest.mark.parametrize("bad", [
    {"name": "n", "charge_c": 0.0, "mass_kg": 1.0, "density_m3": 1.0},
    {"name": "n", "charge_c": 1.0, "mass_kg": -1.0, "density_m3": 1.0},
    {"name": "n", "charge_c": 1.0, "mass_kg": 1.0, "density_m3": 0.0},
    {"name": "n", "charge_c": 1.0, "mass_kg": 1.0, "density_m3": 1.0, "temperature_k": -1},
    {"preset": "electron", "density_m3": 1.0, "bulk_velocity_m_s": [3e8, 0, 0]},
    {"preset": "electron", "density_m3": 1.0, "temperature_ev": 1e5},
])
def test_species_rejects_unphysical(bad):
    with pytest.raises(Exception):
        Species(**bad)


def test_multi_species_and_background():
    sp = [electron(2e12), ion(1e12, charge_state=1, mass_amu=1.007), ion(5e11, charge_state=2, mass_amu=4.0, name="He2+")]
    net = sum(s.charge_density_c_m3 for s in sp)
    assert abs(net) < 1e-12 * ELEMENTARY_CHARGE * 2e12
    bg = neutralizing_background([electron(1e12)])
    assert not bg.mobile and bg.charge_density_c_m3 == pytest.approx(ELEMENTARY_CHARGE * 1e12)


def test_valid_config_and_hash_stability():
    a = SimulationConfig.from_dict(es_config())
    b = SimulationConfig.from_dict(es_config())
    assert a.config_hash() == b.config_hash()
    assert a.boundaries.fields == "periodic" and a.solver.interpolation == "cic"
    assert a.n_steps == 100 and a.dimension == 1 and a.particle_count == 3200
    assert a.with_updates(random_seed=2).config_hash() != a.config_hash()


@pytest.mark.parametrize("change", [
    {"species": [{"preset": "electron", "density_m3": 1e12}]},                       # non-neutral periodic
    {"grid": {"cells": [32, 32]}},                                                   # dimension mismatch
    {"boundaries": {"particles": "periodic", "fields": "dirichlet"}},                # incompatible boundaries
    {"boundaries": {"particles": "absorbing"}},                                      # fft poisson with walls
    {"initial_condition": {"type": "cold"}},                                         # cold with T>0
    {"initial_condition": {"type": "two_stream"}},                                   # no beams
    {"initial_condition": {"type": "magnetised"}},                                   # no B
    {"solver": {"type": "electrostatic_pic", "precision": "float32"}},               # float32 unvalidated
    {"solver": {"type": "fluid"}, "domain": {"dimension": 2, "length_m": [1, 1]}, "grid": {"cells": [8, 8]}},
    {"time": {"dt_s": 1.0, "duration_s": 0.5}},
    {"particles": {"count": 0}},
    {"solver": {"type": "electrostatic_pic", "collisions": {"model": "collisionless", "frequency_hz": 1.0}}},
    {"initial_condition": {"type": "plasma_wave", "perturbation": {"mode": 40, "amplitude": 0.1}}},
])
def test_config_rejects_nonsense(change):
    with pytest.raises(InvalidPhysicalConfiguration) as exc:
        SimulationConfig.from_dict(es_config(**change))
    assert "why" in str(exc.value)


def test_vlasov_rejects_magnetic_field():
    with pytest.raises(InvalidPhysicalConfiguration):
        SimulationConfig.from_dict(es_config(solver={"type": "vlasov", "external_magnetic_field_t": [0, 0, 1]},
                                             particles={"count": 0}))


def test_yaml_and_toml_round_trip(tmp_path):
    cfg = SimulationConfig.from_dict(es_config())
    p = tmp_path / "c.yaml"
    cfg.to_file(p)
    assert SimulationConfig.from_file(p).config_hash() == cfg.config_hash()
    t = tmp_path / "c.toml"
    t.write_text("""
random_seed = 3
[solver]
type = "electrostatic_pic"
[domain]
length_m = 1.0
[grid]
cells = 16
[[species]]
preset = "electron"
density_m3 = 1e12
[[species]]
preset = "proton"
density_m3 = 1e12
mobile = false
[particles]
count = 100
[time]
dt_s = 1e-10
duration_s = 1e-9
""")
    c = SimulationConfig.from_file(t)
    assert c.grid.cells == (16,) and c.random_seed == 3
