"""The analytical validation cases, run as tests (see docs/VALIDATION.md for the full report)."""

import pytest

from plasma_core.validation import cases, convergence

FAST = ["gyro_motion", "exb_drift", "poisson_equation", "electromagnetic_wave", "plasma_oscillation",
        "landau_damping", "fluid_langmuir_wave", "energy_momentum_conservation", "charge_conservation_absorbing",
        "checkpoint_restart", "reproducibility"]
SLOW = ["upper_hybrid_oscillation", "two_stream_instability", "langmuir_wave", "electromagnetic_plasma_wave"]


@pytest.mark.parametrize("name", FAST)
def test_validation_case(name):
    r = getattr(cases, name)()
    assert r.passed, r.conclusion


@pytest.mark.slow
@pytest.mark.parametrize("name", SLOW)
def test_validation_case_slow(name):
    r = getattr(cases, name)()
    assert r.passed, r.conclusion


@pytest.mark.parametrize("study", [s.__name__ for s in convergence.ALL_STUDIES])
def test_convergence_study(study):
    s = getattr(convergence, study)()
    assert s.passed, (s.errors, s.observed_orders)
