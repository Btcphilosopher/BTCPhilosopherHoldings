import math

import matplotlib
import numpy as np
import pytest

matplotlib.use("Agg")

from plasma_core.constants import ELECTRON_MASS, ELEMENTARY_CHARGE, VACUUM_PERMITTIVITY  # noqa: E402

N0 = 1e12
WPE = math.sqrt(N0 * ELEMENTARY_CHARGE**2 / (ELECTRON_MASS * VACUUM_PERMITTIVITY))


def es_config(**over):
    cfg = {
        "name": "test_es",
        "solver": {"type": "electrostatic_pic"},
        "domain": {"length_m": 1.0},
        "grid": {"cells": 32},
        "species": [{"preset": "electron", "density_m3": N0, "temperature_ev": 1.0},
                    {"preset": "proton", "density_m3": N0, "mobile": False}],
        "particles": {"count": 3200},
        "time": {"dt_s": 0.05 / WPE, "duration_s": 100 * 0.05 / WPE},
        "random_seed": 1,
        "diagnostics": {"interval": 5},
    }
    for k, v in over.items():
        if isinstance(v, dict) and isinstance(cfg.get(k), dict):
            cfg[k] = {**cfg[k], **v}
        else:
            cfg[k] = v
    return cfg


@pytest.fixture
def rng():
    return np.random.Generator(np.random.PCG64(1234))
