import math

import h5py
import numpy as np
import pytest
from conftest import N0, WPE, es_config

from plasma_core import CheckpointError, PlasmaSimulation
from plasma_core.constants import SPEED_OF_LIGHT


def _compare(cfg, split, tmp_path):
    a = PlasmaSimulation(cfg)
    a.initialize()
    a.run()
    b = PlasmaSimulation(cfg)
    b.initialize()
    b.run(until_step=split)
    path = b.checkpoint(tmp_path / "ck.h5")
    c = PlasmaSimulation.restart(path)
    assert c.step_index == split
    c.run()
    for k, v in a.model.state_arrays().items():
        np.testing.assert_array_equal(v, c.model.state_arrays()[k], err_msg=k)
    ta, tc = a.diagnostics.table(), c.diagnostics.table()
    assert ta.keys() == tc.keys()
    for k in ta:
        np.testing.assert_array_equal(ta[k], tc[k], err_msg=k)


def test_restart_es_pic_with_stochastic_collisions(tmp_path):
    cfg = es_config(solver={"type": "electrostatic_pic", "collisions": {"model": "effective_frequency",
                                                                        "frequency_hz": 0.05 * WPE,
                                                                        "background_temperature_k": 2e4}})
    _compare(cfg, 37, tmp_path)


def test_restart_absorbing(tmp_path):
    cfg = es_config(boundaries={"particles": "absorbing"}, solver={"type": "electrostatic_pic", "poisson": "fd"},
                    domain={"length_m": 0.1}, grid={"cells": 16},
                    species=[{"preset": "electron", "density_m3": N0, "temperature_ev": 10.0},
                             {"preset": "proton", "density_m3": N0, "mobile": False}])
    _compare(cfg, 50, tmp_path)


def test_restart_em_pic(tmp_path):
    L = 2 * math.pi * SPEED_OF_LIGHT / WPE
    cfg = es_config(solver={"type": "electromagnetic_pic"}, domain={"length_m": L}, grid={"cells": 32},
                    particles={"count": 640, "position_loading": "quiet"},
                    species=[{"preset": "electron", "density_m3": N0}, {"preset": "proton", "density_m3": N0, "mobile": False}],
                    initial_condition={"type": "cold", "em_wave": {"mode": 1, "amplitude_v_m": 1.0}},
                    time={"dt_s": 0.5 * L / 32 / SPEED_OF_LIGHT, "duration_s": 60 * 0.5 * L / 32 / SPEED_OF_LIGHT})
    _compare(cfg, 23, tmp_path)


def test_restart_fluid_and_vlasov(tmp_path):
    fl = es_config(solver={"type": "fluid"}, particles={"count": 0},
                   species=[{"preset": "electron", "density_m3": N0, "temperature_ev": 5.0},
                            {"preset": "proton", "density_m3": N0, "mobile": False}],
                   initial_condition={"type": "plasma_wave", "perturbation": {"mode": 1, "amplitude": 0.01}})
    _compare(fl, 40, tmp_path)
    vl = dict(fl, solver={"type": "vlasov", "vlasov": {"velocity_cells": 64}})
    _compare(vl, 40, tmp_path)


def test_checkpoint_contents_and_errors(tmp_path):
    sim = PlasmaSimulation(es_config())
    sim.initialize()
    sim.run(n_steps=10)
    p = sim.checkpoint(tmp_path / "c.h5")
    with h5py.File(p) as f:
        assert "state/particles/positions_m" in f and "state/fields/E_self_v_m" in f
        assert f["rng"].attrs["random_seed"] == 1 and "git_commit" in f["metadata"].attrs
    with pytest.raises(CheckpointError):
        PlasmaSimulation.restart(tmp_path / "missing.h5")
    other = tmp_path / "other.h5"
    with h5py.File(other, "w") as f:
        f.attrs["x"] = 1
    with pytest.raises(CheckpointError):
        PlasmaSimulation.restart(other)
