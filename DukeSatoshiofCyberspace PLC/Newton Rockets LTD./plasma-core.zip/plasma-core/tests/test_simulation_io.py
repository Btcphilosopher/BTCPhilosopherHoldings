import warnings

import h5py
import numpy as np
import pytest
from conftest import N0, WPE, es_config

from plasma_core import NumericalInstabilityError, PlasmaSimulation, SimulationConfig, StabilityCriterionViolation
from plasma_core.cli import main
from plasma_core.io import (
    fields_dataset_from_hdf5,
    read_diagnostics,
    read_diagnostics_parquet,
    read_metadata,
    state_to_dataset,
)


def test_summary_and_state_shapes():
    sim = PlasmaSimulation(es_config())
    sim.initialize()
    s = sim.summary()
    for key in ("PLASMA CORE", "Electrostatic PIC", "1D3V", "Debye length", "Plasma frequency", "Recommended timestep",
                "Periodic".lower()):
        assert key.lower() in s.lower()
    st = sim.state
    nc = 32
    assert st.electric_field_v_m.shape == (nc, 3) and st.magnetic_field_t.shape == (nc, 3)
    assert st.number_density_m3.shape == (2, nc) and st.current_density_a_m2.shape == (nc, 3)
    assert st.particle_positions_m.shape == (3200, 3) and st.unit_system.value == "SI"
    assert st.total_energy_j == pytest.approx(st.kinetic_energy_j + st.field_energy_j)


def test_unstable_timestep_rejected_or_flagged():
    cfg = es_config(time={"dt_s": 3.0 / WPE, "duration_s": 30 / WPE})
    with pytest.raises(StabilityCriterionViolation) as exc:
        PlasmaSimulation(cfg).initialize()
    assert "plasma_oscillation" in str(exc.value)
    cfg["time"]["stability_policy"] = "warn"
    sim = PlasmaSimulation(cfg)
    with pytest.warns(RuntimeWarning, match="UNSTABLE"):
        sim.initialize()
    assert any("UNSTABLE" in w for w in sim.warnings)


def test_nan_detection_stops_run():
    sim = PlasmaSimulation(es_config(diagnostics={"interval": 5, "stability": {"check_interval": 1}}))
    sim.initialize()
    sim.run(n_steps=3)
    sim.model.particles.velocities[5, 0] = np.nan
    with pytest.raises(NumericalInstabilityError, match="non-finite"):
        sim.run(n_steps=5)


def test_energy_divergence_stop():
    cfg = es_config(time={"dt_s": 1.9 / WPE, "duration_s": 200 / WPE, "stability_policy": "warn"},
                    diagnostics={"interval": 1, "stability": {"max_relative_energy_error": 0.05}})
    sim = PlasmaSimulation(cfg)
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        sim.initialize()
        with pytest.raises(NumericalInstabilityError):
            sim.run()
    assert sim.monitor.events


def test_two_dimensional_es_pic():
    cfg = es_config(domain={"dimension": 2, "length_m": [1.0, 0.5]}, grid={"cells": [16, 8]},
                    particles={"count": 12800, "position_loading": "quiet"},
                    initial_condition={"type": "plasma_wave", "perturbation": {"mode": 1, "amplitude": 0.05}})
    sim = PlasmaSimulation(cfg)
    sim.initialize()
    sim.run()
    _, qe = sim.diagnostics.history("relative_charge_error")
    _, pe = sim.diagnostics.history("momentum_error")
    assert np.max(qe) < 1e-15 and np.max(pe) < 1e-11
    assert sim.state.field_on_grid("electric_field_v_m").shape == (16, 8, 3)
    ds = state_to_dataset(sim.state)
    assert ds["electric_field_v_m"].dims == ("x", "y", "component")


def test_outputs_hdf5_parquet_xarray(tmp_path):
    cfg = es_config(output={"directory": str(tmp_path), "output_interval": 50})
    sim = PlasmaSimulation(cfg)
    sim.initialize()
    sim.run(write_output=True)
    h5 = tmp_path / "test_es.h5"
    with h5py.File(h5) as f:
        for g in ("metadata", "configuration", "grid", "particles", "fields", "diagnostics", "checkpoints"):
            assert g in f
        assert f["fields/electric_field_v_m"].shape == (3, 32, 3)
    md = read_metadata(h5)
    for k in ("simulation_id", "timestamp_utc", "configuration_hash", "solver", "random_seed", "software_version",
              "git_commit", "python_version", "physical_constants_version", "backend", "grid_resolution"):
        assert k in md
    tab = read_diagnostics(h5)
    ptab, pmd = read_diagnostics_parquet(tmp_path / "test_es_diagnostics.parquet")
    np.testing.assert_array_equal(tab["total_energy_j"], ptab["total_energy_j"])
    assert pmd["configuration_hash"] == md["configuration_hash"]
    ds = fields_dataset_from_hdf5(h5)
    assert set(ds["electric_field_v_m"].dims) == {"time", "x", "component"} and ds.sizes["time"] == 3


def test_cli_commands(tmp_path, capsys):
    cfg = SimulationConfig.from_dict(es_config(output={"directory": str(tmp_path), "checkpoint_interval": 50}))
    p = tmp_path / "cfg.yaml"
    cfg.to_file(p)
    assert main(["validate", str(p)]) == 0
    assert main(["run", str(p), "--quiet"]) == 0
    assert main(["diagnostics", str(tmp_path / "test_es.h5"), "--max-rows", "3"]) == 0
    assert main(["inspect", str(tmp_path / "test_es.h5")]) == 0
    ck = tmp_path / "test_es_checkpoint_00000050.h5"
    assert ck.exists()
    assert main(["restart", str(ck), "--steps", "10"]) == 0
    out = capsys.readouterr().out
    assert "configuration is valid" in out and "finished" in out
    bad = tmp_path / "bad.yaml"
    bad.write_text("solver: {type: electrostatic_pic}\ndomain: {length_m: -1}\ngrid: {cells: 8}\n"
                   "species: []\ntime: {dt_s: 1, duration_s: 1}\nrandom_seed: 1\n")
    assert main(["validate", str(bad)]) == 2


def test_absorbing_wall_flux_interface():
    from plasma_core.interfaces import wall_flux_from_simulation

    cfg = es_config(boundaries={"particles": "absorbing"}, solver={"type": "electrostatic_pic", "poisson": "fd"},
                    domain={"length_m": 0.1}, grid={"cells": 16},
                    time={"dt_s": 0.05 / WPE, "duration_s": 200 * 0.05 / WPE},
                    species=[{"preset": "electron", "density_m3": N0, "temperature_ev": 10.0},
                             {"preset": "proton", "density_m3": N0, "mobile": False}])
    sim = PlasmaSimulation(cfg)
    sim.initialize()
    sim.run()
    r = wall_flux_from_simulation(sim)
    assert r.particle_flux_m2_s["electron"] > 0 and r.charge_accumulated_c_m2["electron"] < 0
    _, n = sim.diagnostics.history("particles__electron")
    assert n[-1] < n[0]
