import numpy as np
import pytest
from hypothesis import given, settings
from hypothesis import strategies as st

from plasma_core.backends import CPUReferenceBackend, NumbaBackend
from plasma_core.exceptions import BackendUnavailableError
from plasma_core.grid import SpatialGrid
from plasma_core.interfaces import validate_backend
from plasma_core.particles.particle_push import boris_push
from plasma_core.physics import lorentz_acceleration, lorentz_force
from plasma_core.physics.dispersion import boris_gyrofrequency
from plasma_core.pic import deposit_charge, deposit_current, deposit_scalar, interpolate_field


def test_lorentz_force_vectorised(rng):
    v = rng.standard_normal((5, 3))
    E = rng.standard_normal((5, 3))
    B = rng.standard_normal(3)
    q = np.arange(1, 6, dtype=float)
    F = lorentz_force(q, v, E, B)
    for i in range(5):
        np.testing.assert_allclose(F[i], q[i] * (E[i] + np.cross(v[i], B)))
    np.testing.assert_allclose(lorentz_acceleration(q / 2.0, v, E, B), F / 2.0)


def test_boris_pure_electric_exact():
    v = np.zeros((1, 3))
    for _ in range(10):
        v = boris_push(v, [[1.0, 2.0, 0]], [0, 0, 0], 3.0, 0.1)
    np.testing.assert_allclose(v[0], [3.0, 6.0, 0.0], rtol=1e-14)


def test_boris_pure_magnetic_conserves_speed_and_frequency():
    v = np.array([[1.0, 0.0, 0.5]])
    qm, B, dt = 2.0, np.array([0, 0, 1.5]), 0.05
    angles = []
    for _ in range(400):
        v = boris_push(v, [0, 0, 0], B, qm, dt)
        angles.append(np.arctan2(v[0, 1], v[0, 0]))
        assert np.hypot(v[0, 0], v[0, 1]) == pytest.approx(1.0, rel=1e-14)
        assert v[0, 2] == 0.5
    w = np.polyfit(np.arange(400) * dt, np.unwrap(angles), 1)[0]
    # positive charge rotates clockwise (negative angular velocity) about +B
    assert w == pytest.approx(-boris_gyrofrequency(qm * 1.5, dt), rel=1e-12)


def test_boris_exb_and_reversibility(rng):
    v0 = rng.standard_normal((100, 3))
    E = rng.standard_normal((100, 3))
    B = rng.standard_normal((100, 3))
    v1 = boris_push(v0, E, B, 1.0, 0.1)
    back = boris_push(v1, E, B, 1.0, -0.1)
    np.testing.assert_allclose(back, v0, atol=1e-13)
    # E x B frame: a particle moving at v_E with E perpendicular to B is stationary
    Bz = np.array([0, 0, 2.0])
    Ex = np.array([[3.0, 0, 0]])
    vE = np.cross(Ex[0], Bz) / 4.0
    v = boris_push(vE[None, :], Ex, Bz, 1.7, 0.3)
    np.testing.assert_allclose(v[0], vE, atol=1e-14)


def test_single_particle_cic_and_ngp_weights():
    g = SpatialGrid.uniform(10, 1.0)
    x = np.array([[0.27, 0, 0]])  # s = 2.7 - 0.5 = 2.2 -> nodes 2 (0.8), 3 (0.2)
    rho = deposit_scalar(x, np.array([1.0]), g, "cic")
    np.testing.assert_allclose(rho[[2, 3]], [0.8, 0.2])
    assert rho.sum() == pytest.approx(1.0)
    ngp = deposit_scalar(x, np.array([1.0]), g, "ngp")
    assert ngp[2] == 1.0 and ngp.sum() == 1.0
    wall = SpatialGrid.uniform(10, 1.0, periodic=False)
    r = deposit_scalar(np.array([[0.01, 0, 0]]), np.array([1.0]), wall, "cic")
    assert r[0] == pytest.approx(1.0)  # half-cell next to the wall folds onto the boundary node


@settings(max_examples=40, deadline=None)
@given(st.integers(min_value=1, max_value=500), st.integers(min_value=0, max_value=10_000), st.booleans())
def test_charge_conservation_property(n, seed, periodic):
    rng = np.random.Generator(np.random.PCG64(seed))
    g = SpatialGrid.uniform(16, 2.0, periodic=periodic)
    x = np.zeros((n, 3))
    x[:, 0] = rng.random(n) * 2.0
    q = rng.standard_normal(n)
    for shape in ("ngp", "cic"):
        rho = deposit_charge(x, q, g, shape)
        assert rho.sum() * g.cell_volume_m3 == pytest.approx(q.sum(), abs=1e-12 * np.abs(q).sum())


@settings(max_examples=30, deadline=None)
@given(st.integers(min_value=1, max_value=200), st.integers(min_value=0, max_value=10_000))
def test_charge_symmetry_property(n, seed):
    """Mirroring positions about the domain centre mirrors the deposited density; flipping q flips rho."""
    rng = np.random.Generator(np.random.PCG64(seed))
    g = SpatialGrid.uniform(16, 1.0)
    x = np.zeros((n, 3))
    x[:, 0] = rng.random(n) * 0.98 + 0.01
    q = rng.random(n)
    r = deposit_scalar(x, q, g, "cic")
    xm = x.copy()
    xm[:, 0] = 1.0 - x[:, 0]
    rm = deposit_scalar(xm, q, g, "cic")
    np.testing.assert_allclose(rm, r[::-1], atol=1e-12)
    np.testing.assert_allclose(deposit_scalar(x, -q, g, "cic"), -r, atol=1e-15)


def test_uniform_distribution_and_2d():
    g = SpatialGrid.uniform(8, 1.0)
    x = np.zeros((800, 3))
    x[:, 0] = (np.arange(800) + 0.5) / 800
    np.testing.assert_allclose(deposit_scalar(x, np.ones(800), g, "cic"), 100.0, rtol=1e-12)
    g2 = SpatialGrid.uniform((4, 4), 1.0)
    p = np.array([[0.375, 0.625, 0]])  # exactly at centre of cell (1, 2)
    r2 = deposit_scalar(p, np.array([1.0]), g2, "cic")
    assert r2[1, 2] == pytest.approx(1.0) and r2.sum() == pytest.approx(1.0)


def test_interpolation_linear_exact_and_adjoint(rng):
    g = SpatialGrid.uniform(32, 1.0)
    xc = g.centres(0)
    F = np.stack([2 * xc + 1, -xc, np.ones_like(xc)], axis=1)
    x = np.zeros((50, 3))
    x[:, 0] = 0.1 + 0.8 * rng.random(50)
    Fp = interpolate_field(F, x, g, "cic")
    np.testing.assert_allclose(Fp[:, 0], 2 * x[:, 0] + 1, rtol=1e-12)
    # adjointness: sum_j rho_j F_j = sum_p q_p F(x_p)
    q = rng.random(50)
    rho = deposit_scalar(x, q, g, "cic")
    assert np.dot(rho, F[:, 1]) == pytest.approx(np.dot(q, Fp[:, 1]), rel=1e-12)


def test_current_deposition():
    g = SpatialGrid.uniform(10, 1.0)
    x = np.array([[0.25, 0, 0]])
    v = np.array([[1.0, 2.0, 3.0]])
    J = deposit_current(x, v, np.array([2.0]), g)
    np.testing.assert_allclose(J.sum(axis=0) * g.cell_volume_m3, [2.0, 4.0, 6.0])


def test_numba_backend_matches_reference():
    out = validate_backend(NumbaBackend())
    assert all(v <= 1e-12 for v in out.values())
    validate_backend(CPUReferenceBackend())


def test_unvalidated_backends_refuse():
    from plasma_core.backends import CuPyBackend, JAXBackend

    for cls in (CuPyBackend, JAXBackend):
        with pytest.raises(BackendUnavailableError):
            cls()
