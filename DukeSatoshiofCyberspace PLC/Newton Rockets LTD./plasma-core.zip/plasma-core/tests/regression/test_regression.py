"""Regression against stored reference results (tests/regression/reference_results.json).

The reference file is produced by `plasma-core validation-suite --write-reference ...` and
stores measured values (not theory).  Tolerances are documented per quantity: deterministic
single-particle results must agree to 1e-10; PIC/Vlasov/fluid measurements (deterministic on
the same platform, but sensitive to summation order across platforms/backends) to 1e-6 relative;
the two-stream growth rate to 1e-3.  Exact bitwise identity across different accelerator
backends is NOT required.
"""

import json
from pathlib import Path

import numpy as np
import pytest

from plasma_core.validation import cases

REF = json.loads((Path(__file__).parent / "reference_results.json").read_text())["values"]
TOL = {"gyro_motion": 1e-10, "exb_drift": 1e-10, "two_stream_instability": 1e-3}
FAST = ["gyro_motion", "exb_drift", "plasma_oscillation", "landau_damping", "fluid_langmuir_wave",
        "electromagnetic_wave", "energy_momentum_conservation", "charge_conservation_absorbing"]
SLOW = ["upper_hybrid_oscillation", "two_stream_instability"]


def _check(name):
    r = getattr(cases, name)()
    keys = [k for k in REF if k.startswith(name + ".")]
    assert keys
    for k in keys:
        ref = np.asarray(REF[k], dtype=float)
        got = np.asarray(r.numerical[k.split(".", 1)[1]], dtype=float)
        tol = TOL.get(name, 1e-6)
        np.testing.assert_allclose(got, ref, rtol=tol, atol=tol * np.max(np.abs(ref)) + 1e-300, err_msg=k)


@pytest.mark.parametrize("name", FAST)
def test_regression(name):
    _check(name)


@pytest.mark.slow
@pytest.mark.parametrize("name", SLOW)
def test_regression_slow(name):
    _check(name)
