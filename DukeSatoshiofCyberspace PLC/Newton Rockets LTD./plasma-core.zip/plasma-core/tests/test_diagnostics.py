import math

import numpy as np
import pytest
from conftest import es_config

from plasma_core import PlasmaSimulation
from plasma_core.constants import BOLTZMANN_CONSTANT, ELECTRON_MASS
from plasma_core.diagnostics import fit_damped_oscillation, fit_growth_rate, peak_envelope_rate
from plasma_core.diagnostics.distribution import velocity_distribution, weighted_moments
from plasma_core.diagnostics.temperature import anisotropic_temperature, isotropic_temperature
from plasma_core.physics.scales import compute_scales
from plasma_core.species import electron, proton


def test_temperature_estimator(rng):
    T = 2e4
    vt = math.sqrt(BOLTZMANN_CONSTANT * T / ELECTRON_MASS)
    v = rng.standard_normal((400000, 3)) * vt + [1e5, 0, 0]
    w = np.ones(len(v))
    assert isotropic_temperature(v, w, ELECTRON_MASS) == pytest.approx(T, rel=5e-3)
    tpar, tperp = anisotropic_temperature(v, w, ELECTRON_MASS, [0, 0, 1])
    assert tpar == pytest.approx(T, rel=1e-2) and tperp == pytest.approx(T, rel=1e-2)
    d = velocity_distribution(v, w, ELECTRON_MASS, B=[0, 0, 1])
    assert abs(d["components"]["vx"]["skewness"]) < 0.02
    assert d["components"]["vx"]["kurtosis"] == pytest.approx(3.0, abs=0.03)
    assert d["anisotropy"] == pytest.approx(1.0, abs=0.02)
    hist = d["components"]["vy"]["histogram"]
    edges = d["components"]["vy"]["edges_m_s"]
    assert np.sum(hist * np.diff(edges)) == pytest.approx(1.0)
    m = weighted_moments(np.array([0.0, 1.0, 2.0]), np.array([1.0, 2.0, 1.0]))
    assert m["mean"] == 1.0 and m["variance"] == 0.5


def test_frequency_and_growth_fits(rng):
    t = np.linspace(0, 50, 2000)
    y = 2.0 * np.cos(1.3 * t + 0.4) * np.exp(-0.02 * t)
    f = fit_damped_oscillation(t, y)
    assert f.omega_rad_s == pytest.approx(1.3, rel=1e-9) and f.gamma_s == pytest.approx(-0.02, rel=1e-7)
    # exponential growth from noise floor to saturation
    a = 1e-4 * np.exp(0.35 * t)
    a = np.minimum(a, 1.0) * (1 + 0.01 * rng.standard_normal(len(t)))
    g = fit_growth_rate(t, a)
    assert g.growth_rate_s == pytest.approx(0.35, rel=0.01) and g.r_squared > 0.99
    lo, hi = g.fit_interval_s
    assert hi <= np.log(0.3 / 1e-4) / 0.35 + 0.1
    env = peak_envelope_rate(t, np.cos(2 * t) * np.exp(-0.1 * t))
    assert env.growth_rate_s == pytest.approx(-0.1, rel=1e-3)


def test_characteristic_scales():
    sc = compute_scales([electron(1e12, 11604.518), proton(1e12, 0.0)], 1e-3, 1e-3)
    s = sc.species[0]
    assert s.plasma_frequency_rad_s == pytest.approx(5.6415e7, rel=1e-4)
    assert s.debye_length_m == pytest.approx(7.434e-3, rel=1e-3)
    assert s.cyclotron_frequency_rad_s == pytest.approx(1.7588e8, rel=1e-4)
    assert s.skin_depth_m == pytest.approx(299792458.0 / s.plasma_frequency_rad_s)
    assert sc.alfven_speed_m_s > 0 and sc.plasma_beta > 0 and sc.particle_crossing_time_s > 0


def test_conservation_es_pic_and_energy_transfer():
    sim = PlasmaSimulation(es_config(particles={"count": 6400}, diagnostics={"interval": 1},
                                     initial_condition={"type": "plasma_wave",
                                                        "perturbation": {"mode": 1, "amplitude": 0.1}}))
    sim.initialize()
    sim.run()
    d = sim.diagnostics
    _, pe = d.history("momentum_error")
    _, qe = d.history("relative_charge_error")
    assert np.max(pe) < 1e-12 and np.max(qe) < 1e-15
    t, P = d.history("power_j_dot_e_w")
    _, K = d.history("kinetic_energy_j")
    _, W = d.history("electric_field_energy_j")
    # dK/dt = sum q w v.E and dW/dt = -sum q w v.E (trapezoid integration of the measured power)
    work = np.concatenate([[0], np.cumsum(0.5 * (P[1:] + P[:-1]) * np.diff(t))])
    scale = np.max(np.abs(W - W[0]))
    assert np.max(np.abs((K - K[0]) - work)) / scale < 0.02
    assert np.max(np.abs((W - W[0]) + work)) / scale < 0.02
    cols = d.columns()
    for c in ("density_mean_m3__electron", "e_max_v_m", "temperature_k__electron", "particles__electron",
              "mode_amp_Ex_m1", "gauss_residual", "poisson_residual"):
        assert c in cols


def test_velocity_distribution_diagnostic_and_trajectories():
    sim = PlasmaSimulation(es_config(diagnostics={"interval": 5, "velocity_distribution": 50,
                                                  "record_trajectories": [0, 7]}))
    sim.initialize()
    sim.run()
    d = sim.diagnostics
    assert len(d.distributions) == 3  # steps 0, 50, 100
    assert "vx_kurtosis__electron" in d.columns()
    assert d.trajectory(7).shape[1] == 7 and d.trajectory(7).shape[0] == len(d.rows)
