import numpy as np
import pytest
from conftest import es_config

from plasma_core import PlasmaSimulation
from plasma_core import visualization as viz
from plasma_core.grid import SpatialGrid
from plasma_core.interfaces import SpacecraftInteractionModel


def test_plots_written(tmp_path):
    sim = PlasmaSimulation(es_config(solver={"type": "electrostatic_pic", "external_magnetic_field_t": [0, 0, 1e-4]},
                                     initial_condition={"type": "plasma_wave",
                                                        "perturbation": {"mode": 1, "amplitude": 0.05}}))
    sim.initialize()
    sim.run()
    st, md, d = sim.state, sim.metadata, sim.diagnostics
    files = [
        viz.phase_space(st, metadata=md, path=tmp_path / "ps.png", max_points=500),
        viz.phase_space(st, x_axis="vx", v_axis="vy", metadata=md, path=tmp_path / "vv.png"),
        viz.velocity_distribution(st, metadata=md, path=tmp_path / "vd.png"),
        viz.density_profile(st, metadata=md, path=tmp_path / "n.png"),
        viz.field_profile(st, metadata=md, path=tmp_path / "e.png"),
        viz.field_profile(st, field="B", metadata=md, path=tmp_path / "b.png"),
        viz.potential_profile(st, metadata=md, path=tmp_path / "phi.png"),
        viz.energy_history(d, metadata=md, path=tmp_path / "en.png"),
        viz.charge_error_history(d, metadata=md, path=tmp_path / "q.png"),
        viz.temperature_history(d, st.species_names, metadata=md, path=tmp_path / "T.png"),
        viz.mode_history(d, metadata=md, path=tmp_path / "m.png"),
    ]
    for f in files:
        assert f.exists() and f.stat().st_size > 1000


def test_field_lines_follow_computed_field(tmp_path):
    g = SpatialGrid.uniform((32, 32), 2.0, lower_m=-1.0)
    X, Y = g.mesh_centres()
    Bx, By = -Y, X  # circular field lines about the origin (computed array, not hard-coded lines)
    line = viz.trace_field_line(Bx, By, g, (0.5, 0.0), step_m=0.01, n_steps=300)
    r = np.hypot(line[:, 0], line[:, 1])
    assert np.max(np.abs(r - 0.5)) < 2e-3


def test_spacecraft_interface_is_abstract():
    with pytest.raises(TypeError):
        SpacecraftInteractionModel()


def test_numerical_core_does_not_import_matplotlib():
    import subprocess
    import sys

    code = ("import sys\nfrom plasma_core import PlasmaSimulation\n"
            "s = PlasmaSimulation(dict(solver={'type': 'electrostatic_pic'}, domain={'length_m': 1.0}, grid={'cells': 16},"
            "species=[{'preset': 'electron', 'density_m3': 1e12}, {'preset': 'proton', 'density_m3': 1e12, 'mobile': False}],"
            "particles={'count': 160}, time={'dt_s': 1e-10, 'duration_s': 1e-9}, random_seed=0))\n"
            "s.initialize(); s.run()\n"
            "assert not any(m.startswith('matplotlib') for m in sys.modules), 'core imported matplotlib'\n")
    subprocess.run([sys.executable, "-c", code], check=True)
