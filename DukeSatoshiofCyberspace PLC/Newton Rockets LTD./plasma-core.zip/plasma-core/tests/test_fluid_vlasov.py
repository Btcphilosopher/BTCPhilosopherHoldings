import math

import numpy as np
import pytest
from conftest import N0, WPE, es_config

from plasma_core import NumericalInstabilityError, PlasmaSimulation
from plasma_core.constants import ELECTRON_MASS, ELEMENTARY_CHARGE
from plasma_core.diagnostics import fit_damped_oscillation
from plasma_core.diagnostics.distribution import grid_distribution_moments
from plasma_core.physics.collisions import EffectiveCollisionFrequency
from plasma_core.physics.dispersion import bohm_gross_frequency


def fluid_cfg(**kw):
    c = es_config(solver={"type": "fluid", "fluid": {"closure": "adiabatic", "gamma": 3.0}},
                  particles={"count": 0}, grid={"cells": 64},
                  species=[{"preset": "electron", "density_m3": N0, "temperature_ev": 10.0},
                           {"preset": "proton", "density_m3": N0, "mobile": False}],
                  initial_condition={"type": "plasma_wave", "perturbation": {"mode": 1, "amplitude": 0.01}},
                  time={"dt_s": 0.05 / WPE, "duration_s": 4 * 2 * math.pi / WPE}, diagnostics={"interval": 2})
    c.update(kw)
    return c


def test_fluid_bohm_gross_and_mass():
    sim = PlasmaSimulation(fluid_cfg())
    sim.initialize()
    sim.run()
    t, y = sim.diagnostics.history("mode_im_Ex_m1")
    f = fit_damped_oscillation(t, y)
    w = bohm_gross_frequency(WPE, 2 * np.pi, math.sqrt(10 * ELEMENTARY_CHARGE / ELECTRON_MASS))
    assert f.omega_rad_s == pytest.approx(w, rel=1e-3)
    _, me = sim.diagnostics.history("relative_mass_error__electron")
    assert np.max(np.abs(me)) < 1e-12


@pytest.mark.parametrize("closure", ["isothermal", "ideal_gas", "polytropic"])
def test_fluid_closures_run(closure):
    gamma = 5 / 3 if closure == "ideal_gas" else 3.0
    sim = PlasmaSimulation(fluid_cfg(solver={"type": "fluid", "fluid": {"closure": closure, "gamma": gamma}}))
    sim.initialize()
    sim.run(n_steps=50)
    assert np.all(np.isfinite(sim.model.U))


def test_fluid_reflecting_walls_conserve_mass():
    c = fluid_cfg(boundaries={"particles": "reflecting"}, solver={"type": "fluid", "poisson": "fd"})
    sim = PlasmaSimulation(c)
    sim.initialize()
    sim.run(n_steps=100)
    _, me = sim.diagnostics.history("relative_mass_error__electron")
    assert np.max(np.abs(me)) < 1e-12


def test_fluid_stops_on_cfl_violation():
    c = fluid_cfg(time={"dt_s": 50.0 / WPE, "duration_s": 500.0 / WPE, "stability_policy": "warn"})
    sim = PlasmaSimulation(c)
    with pytest.warns(RuntimeWarning):
        sim.initialize()
    with pytest.raises(NumericalInstabilityError):
        sim.run()


def vlasov_cfg(**kw):
    T = 10 * ELEMENTARY_CHARGE / 1.380649e-23
    lam = math.sqrt(8.8541878128e-12 * 10 * ELEMENTARY_CHARGE / (N0 * ELEMENTARY_CHARGE**2))
    c = es_config(solver={"type": "vlasov", "poisson": "fft_spectral", "vlasov": {"velocity_cells": 128}},
                  particles={"count": 0}, domain={"length_m": 2 * math.pi * lam / 0.5},
                  species=[{"preset": "electron", "density_m3": N0, "temperature_k": T},
                           {"preset": "proton", "density_m3": N0, "mobile": False}],
                  initial_condition={"type": "plasma_wave", "perturbation": {"mode": 1, "amplitude": 0.01}},
                  time={"dt_s": 0.1 / WPE, "duration_s": 5 / WPE}, diagnostics={"interval": 1})
    c.update(kw)
    return c


def test_vlasov_density_moment_and_conservation():
    sim = PlasmaSimulation(vlasov_cfg())
    sim.initialize()
    f = sim.model.f[0]
    v = sim.model.vgrids[0].centres(0)
    dv = sim.model.vgrids[0].spacing_m_s[0]
    n = grid_distribution_moments(f, v, dv, ELECTRON_MASS)["density_m3"]
    x = sim.grid.centres(0)
    np.testing.assert_allclose(n, N0 * (1 + 0.01 * np.cos(sim.grid.mode_wavenumber(1) * x)), rtol=1e-12)
    sim.run()
    _, me = sim.diagnostics.history("relative_mass_error__electron")
    _, ee = sim.diagnostics.history("energy_error")
    assert np.max(np.abs(me)) < 1e-9 and np.max(np.abs(ee)) < 1e-5


def test_bgk_conserves_moments():
    v = np.linspace(-5, 5, 201)
    dv = v[1] - v[0]
    f = np.exp(-((v - 1) ** 2) / 0.5)[None, :] + 0.3 * np.exp(-((v + 2) ** 2))[None, :]
    c = EffectiveCollisionFrequency(1.0)
    g = c.apply_distribution(f, v, dv, 1.0, 10.0)
    for p in (0, 1, 2):
        assert (g * v**p).sum() == pytest.approx((f * v**p).sum(), rel=1e-6)


def test_langevin_collisions_relax_temperature():
    T0, Tb = 1e4, 4e4
    nu = 0.2 * WPE
    c = es_config(solver={"type": "electrostatic_pic", "collisions": {"model": "effective_frequency",
                                                                      "frequency_hz": nu,
                                                                      "background_temperature_k": Tb}},
                  species=[{"preset": "electron", "density_m3": N0, "temperature_k": T0},
                           {"preset": "proton", "density_m3": N0, "mobile": False}],
                  particles={"count": 20000}, time={"dt_s": 0.05 / WPE, "duration_s": 40 / WPE})
    sim = PlasmaSimulation(c)
    sim.initialize()
    sim.run()
    t, T = sim.diagnostics.history("temperature_k__electron")
    expected = Tb + (T0 - Tb) * np.exp(-2 * nu * t)  # O-U variance relaxes at rate 2 nu
    assert T[-1] == pytest.approx(expected[-1], rel=0.03)
    assert any(e["type"] == "energy_check_disabled" for e in sim.monitor.events)


def test_two_fluid_electron_ion_oscillation():
    """Electron and proton fluids (both mobile, gamma = 3, T = 1 eV): the high-frequency branch of
    1 = sum_s omega_ps^2 / (omega^2 - 3 k^2 v_ts^2), i.e. the larger root of a quadratic in omega^2."""
    from plasma_core.constants import PROTON_MASS

    T_ev = 1.0
    c = fluid_cfg(species=[{"preset": "electron", "density_m3": N0, "temperature_ev": T_ev},
                           {"preset": "proton", "density_m3": N0, "temperature_ev": T_ev}],
                  initial_condition={"type": "plasma_wave",
                                     "perturbation": {"mode": 1, "amplitude": 0.01, "species": ["electron"]}})
    sim = PlasmaSimulation(c)
    sim.initialize()
    sim.run()
    t, y = sim.diagnostics.history("mode_im_Ex_m1")
    f = fit_damped_oscillation(t, y)
    k = 2 * np.pi
    wpi = WPE * math.sqrt(ELECTRON_MASS / PROTON_MASS)
    a = 3 * k**2 * T_ev * ELEMENTARY_CHARGE / ELECTRON_MASS
    b = 3 * k**2 * T_ev * ELEMENTARY_CHARGE / PROTON_MASS
    s = a + b + WPE**2 + wpi**2
    p = a * b + WPE**2 * b + wpi**2 * a
    w = math.sqrt((s + math.sqrt(s * s - 4 * p)) / 2)
    assert f.omega_rad_s == pytest.approx(w, rel=2e-4)
    for name in ("electron", "proton"):
        _, me = sim.diagnostics.history(f"relative_mass_error__{name}")
        assert np.max(np.abs(me)) < 1e-12
