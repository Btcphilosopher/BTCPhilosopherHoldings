import math

import numpy as np
import pytest
from hypothesis import given
from hypothesis import strategies as st

from plasma_core import constants as C
from plasma_core import units as U


def test_constants_registry_complete():
    for name in ("ELEMENTARY_CHARGE", "ELECTRON_MASS", "PROTON_MASS", "VACUUM_PERMITTIVITY", "VACUUM_PERMEABILITY",
                 "BOLTZMANN_CONSTANT", "SPEED_OF_LIGHT", "PLANCK_CONSTANT"):
        c = C.CONSTANTS[name]
        assert c.unit and c.source and c.description and c.value > 0
        assert getattr(C, name) == c.value


def test_exact_si_constants():
    assert C.ELEMENTARY_CHARGE == 1.602176634e-19
    assert C.BOLTZMANN_CONSTANT == 1.380649e-23
    assert C.SPEED_OF_LIGHT == 299792458.0
    assert C.PLANCK_CONSTANT == 6.62607015e-34
    assert C.CONSTANTS["SPEED_OF_LIGHT"].exact and not C.CONSTANTS["ELECTRON_MASS"].exact


def test_maxwell_consistency_of_constants():
    c = 1.0 / math.sqrt(C.VACUUM_PERMEABILITY * C.VACUUM_PERMITTIVITY)
    assert abs(c - C.SPEED_OF_LIGHT) / C.SPEED_OF_LIGHT < 1e-9


def test_unit_conversions():
    assert U.ev_to_joule(1.0) == C.ELEMENTARY_CHARGE
    assert math.isclose(U.ev_to_kelvin(1.0), 11604.518, rel_tol=1e-7)
    assert U.per_cm3_to_per_m3(1.0) == 1e6
    assert U.gauss_to_tesla(1e4) == 1.0
    assert U.kev_to_joule(1.0) == pytest.approx(1e3 * C.ELEMENTARY_CHARGE)
    assert U.mev_to_joule(2.0) == pytest.approx(2e6 * C.ELEMENTARY_CHARGE)
    arr = U.ev_to_kelvin(np.array([1.0, 2.0]))
    assert isinstance(arr, np.ndarray) and arr.shape == (2,)


@given(st.floats(min_value=1e-6, max_value=1e9, allow_nan=False))
def test_round_trip_properties(x):
    assert math.isclose(U.kelvin_to_ev(U.ev_to_kelvin(x)), x, rel_tol=1e-12)
    assert math.isclose(U.joule_to_ev(U.ev_to_joule(x)), x, rel_tol=1e-12)
    assert math.isclose(U.tesla_to_gauss(U.gauss_to_tesla(x)), x, rel_tol=1e-12)
    assert math.isclose(U.per_m3_to_per_cm3(U.per_cm3_to_per_m3(x)), x, rel_tol=1e-12)


def test_normalisation_consistency_and_round_trip():
    n = U.Normalisation.electron_plasma(1e12, 1e4)
    assert n.to_si(n.to_normalised(3.0, "velocity"), "velocity") == pytest.approx(3.0)
    with pytest.raises(ValueError):
        U.Normalisation(length_m=1, time_s=1, velocity_m_s=2, density_m3=1, electric_field_v_m=1, magnetic_field_t=1)
    with pytest.raises(KeyError):
        n.scale("pressure")  # type: ignore[arg-type]


@given(st.floats(min_value=1e6, max_value=1e24), st.floats(min_value=1.0, max_value=1e8),
       st.floats(min_value=0.1, max_value=100.0))
def test_species_scaling_properties(n, T, a):
    """omega_p ~ sqrt(n/m) q, lambda_D ~ sqrt(T/n)/q, omega_c ~ |q| B/m: exact scaling laws."""
    from plasma_core.physics import cyclotron_frequency, debye_length, plasma_frequency

    q, m = C.ELEMENTARY_CHARGE, C.PROTON_MASS
    assert math.isclose(float(plasma_frequency(a * n, q, m)), math.sqrt(a) * float(plasma_frequency(n, q, m)), rel_tol=1e-12)
    assert math.isclose(float(plasma_frequency(n, q, a * m)), float(plasma_frequency(n, q, m)) / math.sqrt(a), rel_tol=1e-12)
    assert math.isclose(float(plasma_frequency(n, -a * q, m)), a * float(plasma_frequency(n, q, m)), rel_tol=1e-12)
    assert math.isclose(float(debye_length(a * T, n, q)), math.sqrt(a) * float(debye_length(T, n, q)), rel_tol=1e-12)
    assert math.isclose(float(debye_length(T, a * n, q)), float(debye_length(T, n, q)) / math.sqrt(a), rel_tol=1e-12)
    assert math.isclose(float(cyclotron_frequency(-q, a, m)), a * float(cyclotron_frequency(q, 1.0, m)), rel_tol=1e-12)
