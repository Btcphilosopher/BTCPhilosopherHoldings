import numpy as np
import pytest
from conftest import N0, es_config
from hypothesis import given, settings
from hypothesis import strategies as st

from plasma_core import PlasmaSimulation, SimulationConfig
from plasma_core.constants import BOLTZMANN_CONSTANT, ELECTRON_MASS
from plasma_core.exceptions import SolverConfigurationError
from plasma_core.grid import FieldGrid, FieldLayout, SpatialGrid, VelocityGrid
from plasma_core.initial_conditions import cold_plasma, gyrating_particle, magnetised, maxwellian, plasma_wave, two_stream
from plasma_core.particles import ParticleLossLedger, PeriodicParticleBoundary, ReflectingParticleBoundary
from plasma_core.particles.particle_boundary import AbsorbingParticleBoundary
from plasma_core.particles.particle_initializer import make_generator
from plasma_core.pic.charge_deposition import deposit_scalar


def test_spatial_grid_conventions():
    g = SpatialGrid.uniform((4, 8), (2.0, 4.0), lower_m=(-1.0, 0.0))
    assert g.shape == (4, 8) and g.n_cells == 32 and g.dimension == 2
    np.testing.assert_allclose(g.spacing_m, [0.5, 0.5])
    np.testing.assert_allclose(g.centres(0), [-0.75, -0.25, 0.25, 0.75])
    np.testing.assert_allclose(g.edges(0), [-1, -0.5, 0, 0.5, 1])
    assert g.cell_volume_m3 == 0.25 and g.flat_index(1, 2) == 10
    assert np.allclose(g.widths(1), 0.5)
    assert g.mode_wavenumber(2) == pytest.approx(2 * np.pi)
    assert SpatialGrid.from_dict(g.to_dict()) == g


def test_velocity_and_field_grid():
    v = VelocityGrid.uniform_1d(10, -5.0, 5.0)
    assert v.spacing_m_s[0] == 1.0 and v.centres(0)[0] == -4.5 and v.edges(0).shape == (11,)
    fg = FieldGrid(SpatialGrid.uniform(8, 1.0), FieldLayout.YEE_1D)
    assert fg.location("Bz") == 0.0 and fg.location("Ey") == 0.5 and fg.location("Bx") is None
    with pytest.raises(SolverConfigurationError):
        FieldGrid(SpatialGrid.uniform((8, 8), 1.0), FieldLayout.YEE_1D)


def test_reproducible_initial_population():
    cfg = SimulationConfig.from_dict(es_config())
    a = PlasmaSimulation(cfg).initialize().model.particles
    b = PlasmaSimulation(cfg).initialize().model.particles
    assert np.array_equal(a.positions, b.positions) and np.array_equal(a.velocities, b.velocities)


def test_maxwellian_moments_quiet_start():
    g = SpatialGrid.uniform(16, 1.0)
    T = 1e5
    ps = maxwellian(g, temperature_k=T, density_m3=N0, bulk_velocity_m_s=(1e4, 0, 0), particle_count=20000,
                    mass_kg=ELECTRON_MASS, random_seed=0, position_loading="quiet", velocity_loading="quiet")
    vt2 = BOLTZMANN_CONSTANT * T / ELECTRON_MASS
    np.testing.assert_allclose(ps.velocities.mean(axis=0), [1e4, 0, 0], atol=1e-6 * np.sqrt(vt2))
    np.testing.assert_allclose(ps.velocities.var(axis=0), vt2, rtol=2e-3)
    assert ps.weights.sum() == pytest.approx(N0 * g.domain_volume_m3)
    dens = deposit_scalar(ps.positions, ps.weights, g, "cic") / g.cell_volume_m3
    np.testing.assert_allclose(dens, N0, rtol=1e-12)


def test_cold_and_perturbation():
    g = SpatialGrid.uniform(64, 1.0)
    with pytest.raises(ValueError):
        cold_plasma(g, temperature_k=1.0, density_m3=1.0, particle_count=10, mass_kg=1.0, random_seed=0)
    ps = plasma_wave(g, temperature_k=0.0, density_m3=N0, particle_count=64000, mass_kg=ELECTRON_MASS, mode=2,
                     amplitude=0.01, phase_rad=0.3, random_seed=0)
    n = deposit_scalar(ps.positions, ps.weights, g, "cic") / g.cell_volume_m3
    x = g.centres(0)
    expected = N0 * (1 + 0.01 * np.cos(2 * 2 * np.pi * x + 0.3))
    # CIC smoothing reduces the mode by S(k)^... ~ 1e-3; first-order displacement error O(A^2)
    assert np.max(np.abs(n - expected)) / N0 < 2e-4


def test_two_stream_and_magnetised_initializers():
    g = SpatialGrid.uniform(32, 1.0)
    ps = two_stream(g, temperature_k=0.0, density_m3=N0, bulk_velocity_m_s=1e6, particle_count=1000, random_seed=1)
    assert ps.n == 2000
    np.testing.assert_allclose(ps.velocities[ps.species_id == 0, 0], 1e6)
    np.testing.assert_allclose(ps.velocities[ps.species_id == 1, 0], -1e6)
    rng = make_generator(5)
    m = magnetised(g, temperature_k=1e4, density_m3=N0, particle_count=200000, mass_kg=ELECTRON_MASS,
                   magnetic_field_t=(0, 0, 1e-3), rng=rng, temperature_parallel_k=1e4, temperature_perpendicular_k=4e4)
    vt2 = BOLTZMANN_CONSTANT / ELECTRON_MASS
    assert m.velocities[:, 2].var() == pytest.approx(1e4 * vt2, rel=0.02)
    assert m.velocities[:, 0].var() == pytest.approx(4e4 * vt2, rel=0.02)
    gp = gyrating_particle((0, 0, 0), 1.0, 2.0, (0, 0, 1))
    np.testing.assert_allclose(gp.velocities[0], [2.0, 0, 1.0])


@settings(max_examples=50, deadline=None)
@given(st.lists(st.floats(min_value=-50.0, max_value=50.0, allow_nan=False), min_size=1, max_size=50))
def test_periodic_wrap_property(xs):
    from plasma_core.particles import ParticleState

    n = len(xs)
    pos = np.zeros((n, 3))
    pos[:, 0] = xs
    ps = ParticleState(pos, np.zeros((n, 3)), np.zeros(n, np.int32), np.ones(n), np.arange(n))
    led = ParticleLossLedger(1)
    PeriodicParticleBoundary().apply(ps, 0, -1.0, 2.0, led, np.array([1.0]), np.array([1.0]))
    assert ps.n == n  # particle number conserved
    assert np.all(ps.positions[:, 0] >= -1.0) and np.all(ps.positions[:, 0] < 2.0)
    shift = (ps.positions[:, 0] - np.asarray(xs)) / 3.0
    assert np.allclose(shift, np.round(shift), atol=1e-9)


def test_reflecting_and_absorbing_boundaries():
    from plasma_core.particles import ParticleState

    pos = np.array([[-0.1, 0, 0], [0.5, 0, 0], [1.2, 0, 0]])
    vel = np.array([[-1.0, 1, 0], [1.0, 0, 0], [2.0, 0, 0]])
    ps = ParticleState(pos.copy(), vel.copy(), np.zeros(3, np.int32), np.array([1.0, 2.0, 3.0]), np.arange(3))
    led = ParticleLossLedger(1)
    ReflectingParticleBoundary().apply(ps, 0, 0.0, 1.0, led, np.array([-1.0]), np.array([2.0]))
    np.testing.assert_allclose(ps.positions[:, 0], [0.1, 0.5, 0.8])
    np.testing.assert_allclose(ps.velocities[:, 0], [1.0, 1.0, -2.0])
    ps = ParticleState(pos.copy(), vel.copy(), np.zeros(3, np.int32), np.array([1.0, 2.0, 3.0]), np.arange(3))
    AbsorbingParticleBoundary().apply(ps, 0, 0.0, 1.0, led, np.array([-1.0]), np.array([2.0]))
    assert ps.n == 1 and led.particles_lost[0] == 2 and led.lost_low_wall[0] == 1 and led.lost_high_wall[0] == 1
    assert led.weight_lost[0] == 4.0 and led.charge_lost_c[0] == -4.0
    assert led.energy_lost_j[0] == pytest.approx(0.5 * 2 * (1 * 2 + 3 * 4))
