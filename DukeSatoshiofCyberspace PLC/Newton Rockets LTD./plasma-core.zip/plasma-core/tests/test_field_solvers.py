import math

import numpy as np
import pytest

from plasma_core.constants import SPEED_OF_LIGHT, VACUUM_PERMITTIVITY
from plasma_core.exceptions import BoundaryConditionError, StabilityCriterionViolation
from plasma_core.fields import check_compatibility
from plasma_core.grid import SpatialGrid
from plasma_core.physics.dispersion import yee_vacuum_frequency
from plasma_core.solvers import PoissonSolver, Yee1DMaxwellSolver

E0 = VACUUM_PERMITTIVITY


@pytest.mark.parametrize("method", ["fft_fd", "fft_spectral", "fd"])
def test_periodic_sinusoid(method):
    errs = []
    for n in (32, 64):
        g = SpatialGrid.uniform(n, 1.0)
        x = g.centres(0)
        k = 2 * np.pi
        r = PoissonSolver(g, method).solve(np.sin(k * x))
        errs.append(np.max(np.abs(r.phi_v - np.sin(k * x) / (E0 * k * k))) / (1 / (E0 * k * k)))
        Ea = -np.cos(k * x) / (E0 * k)
        assert np.max(np.abs(r.electric_field_v_m[:, 0] - Ea)) / np.max(np.abs(Ea)) < 5e-3
    if method == "fft_spectral":
        assert max(errs) < 1e-12
    else:
        assert math.log2(errs[0] / errs[1]) == pytest.approx(2.0, abs=0.02)
        assert r.residual < 1e-10


def test_dirichlet_wall_potentials_exact_linear():
    g = SpatialGrid.uniform(20, 2.0, periodic=False)
    r = PoissonSolver(g, "fd", "dirichlet", potential_low_v=-1.0, potential_high_v=3.0).solve(np.zeros(20))
    x = g.centres(0)
    np.testing.assert_allclose(r.phi_v, -1.0 + 4.0 * x / 2.0, atol=1e-12)
    np.testing.assert_allclose(r.electric_field_v_m[:, 0], -2.0, rtol=1e-10)


def test_neumann_and_mean_removal():
    g = SpatialGrid.uniform(64, 1.0, periodic=False)
    x = g.centres(0)
    rho = np.cos(np.pi * x)  # zero mean, dphi/dx = 0 at the walls
    r = PoissonSolver(g, "fd", "neumann").solve(rho)
    phi_a = np.cos(np.pi * x) / (E0 * np.pi**2)
    assert np.max(np.abs(r.phi_v - phi_a)) / np.max(np.abs(phi_a)) < 1e-3
    gp = SpatialGrid.uniform(16, 1.0)
    r2 = PoissonSolver(gp).solve(np.full(16, 2.0))
    assert r2.removed_mean_charge_density == 2.0 and np.max(np.abs(r2.electric_field_v_m)) < 1e-20


def test_2d_poisson_sinusoid():
    g = SpatialGrid.uniform((32, 32), (1.0, 2.0))
    X, Y = g.mesh_centres()
    kx, ky = 2 * np.pi, 2 * np.pi / 2.0
    rho = np.sin(kx * X) * np.cos(ky * Y)
    r = PoissonSolver(g, "fft_spectral").solve(rho)
    phi_a = rho / (E0 * (kx**2 + ky**2))
    assert np.max(np.abs(r.phi_v - phi_a)) / np.max(np.abs(phi_a)) < 1e-12
    gd = SpatialGrid.uniform((32, 32), 1.0, periodic=False)
    Xd, Yd = gd.mesh_centres()
    rho_d = np.sin(np.pi * Xd) * np.sin(np.pi * Yd)
    rd = PoissonSolver(gd, "fd", "dirichlet").solve(rho_d)
    assert np.max(np.abs(rd.phi_v - rho_d / (E0 * 2 * np.pi**2))) / np.max(rho_d / (E0 * 2 * np.pi**2)) < 2e-3


def test_boundary_compatibility_errors():
    g = SpatialGrid.uniform(16, 1.0, periodic=False)
    with pytest.raises(BoundaryConditionError):
        PoissonSolver(g, "fft_fd", "dirichlet")
    with pytest.raises(BoundaryConditionError):
        check_compatibility("electromagnetic_pic", "dirichlet")
    with pytest.raises(BoundaryConditionError):
        Yee1DMaxwellSolver(g, 1e-12)


def test_yee_courant_and_dispersion():
    g = SpatialGrid.uniform(64, 1.0)
    dx = 1.0 / 64
    with pytest.raises(StabilityCriterionViolation):
        Yee1DMaxwellSolver(g, 1.01 * dx / SPEED_OF_LIGHT)
    dt = 0.7 * dx / SPEED_OF_LIGHT
    s = Yee1DMaxwellSolver(g, dt)
    k = 2 * np.pi * 3
    xc = g.centres(0)
    s.Ey[:] = np.sin(k * xc)
    w = yee_vacuum_frequency(k, dx, dt)
    n = 400
    for _ in range(n):
        s.step()
    # standing mode amplitude follows cos(w t) of the discrete dispersion relation exactly
    amp = 2 / 64 * np.sum(s.Ey * np.sin(k * xc))
    assert amp == pytest.approx(math.cos(w * n * dt), abs=1e-10)
    we, wb = s.transverse_energy()
    assert we + wb == pytest.approx(0.5 * E0 * 0.5, rel=0.05)  # energy bounded (Yee conserves a modified energy)
