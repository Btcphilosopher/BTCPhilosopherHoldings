"""Charge diagnostics.

    Q_particles = sum_p q_p w_p + sum_backgrounds q_b n_b V_domain      [C]
    Q_grid      = sum_j rho_j V_cell                                     [C]
    charge_residual        = Q(t) - Q(0)
    relative_charge_error  = |Q(t) + Q_lost(t) - Q(0)| / Q_abs,
    Q_abs = sum_s |q_s| n_s V_domain (total absolute charge; Q(0) itself is ~0
    for a neutral plasma and cannot be used as the normalisation).
Q_lost is the charge removed through absorbing/open boundaries.
"""

from __future__ import annotations

import numpy as np


def particle_charge(charges_per_particle: np.ndarray, weights: np.ndarray) -> float:
    return float(np.sum(charges_per_particle * weights))


def grid_charge(rho: np.ndarray, cell_volume_m3: float) -> float:
    return float(np.sum(rho)) * cell_volume_m3


def absolute_charge_scale(species, domain_volume_m3: float) -> float:
    return float(sum(abs(s.charge_c) * s.density_m3 for s in species)) * domain_volume_m3
