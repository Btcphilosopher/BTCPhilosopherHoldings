"""Velocity-distribution diagnostics (per species).

For each velocity component: weighted histogram (probability density,
integrates to 1 over the bins), mean, variance, skewness
(E[(v-u)^3]/sigma^3) and *Pearson* kurtosis (E[(v-u)^4]/sigma^4; = 3 for a
Maxwellian; excess kurtosis = kurtosis - 3).  Anisotropy = T_perp/T_par when
a magnetic field direction is given, otherwise T_x / mean(T_y, T_z).

For a gridded distribution f(x, v): :func:`grid_distribution_moments`
returns n(x) = integral f dv, u(x), and the 1V temperature, so that
integral f dv = n can be verified cell by cell.
"""

from __future__ import annotations

import numpy as np

from ..constants import BOLTZMANN_CONSTANT
from .temperature import anisotropic_temperature, component_temperatures


def weighted_moments(x: np.ndarray, w: np.ndarray) -> dict[str, float]:
    W = w.sum()
    mean = float((w * x).sum() / W)
    d = x - mean
    var = float((w * d * d).sum() / W)
    if var <= 0:
        return {"mean": mean, "variance": var, "skewness": float("nan"), "kurtosis": float("nan")}
    sd = np.sqrt(var)
    return {"mean": mean, "variance": var, "skewness": float((w * d**3).sum() / W / sd**3),
            "kurtosis": float((w * d**4).sum() / W / var**2)}


def velocity_distribution(v: np.ndarray, w: np.ndarray, mass_kg: float, bins: int = 64,
                          v_range: tuple[float, float] | None = None, B=None) -> dict:
    out: dict = {"components": {}}
    for c, name in enumerate(("vx", "vy", "vz")):
        x = v[:, c]
        rng = v_range if v_range is not None else (float(x.min()), float(x.max()) if x.max() > x.min() else float(x.min()) + 1.0)
        hist, edges = np.histogram(x, bins=bins, range=rng, weights=w, density=True)
        out["components"][name] = {"histogram": hist, "edges_m_s": edges, **weighted_moments(x, w)}
    T = component_temperatures(v, w, mass_kg)
    out["temperature_components_k"] = T
    out["temperature_k"] = float(T.mean())
    if B is not None and np.any(np.asarray(B) != 0):
        tpar, tperp = anisotropic_temperature(v, w, mass_kg, B)
        out["temperature_parallel_k"] = tpar
        out["temperature_perpendicular_k"] = tperp
        out["anisotropy"] = tperp / tpar if tpar > 0 else float("nan")
    else:
        tperp = 0.5 * (T[1] + T[2])
        out["anisotropy"] = float(T[0] / tperp) if tperp > 0 else float("nan")
    return out


def grid_distribution_moments(f: np.ndarray, v: np.ndarray, dv: float, mass_kg: float) -> dict[str, np.ndarray]:
    """Moments of f[x, v] (units s m^-4): n [m^-3], u [m/s], T (1V) [K]."""
    n = f.sum(axis=1) * dv
    safe = np.where(n > 0, n, 1.0)
    u = (f * v[None, :]).sum(axis=1) * dv / safe
    var = (f * (v[None, :] - u[:, None]) ** 2).sum(axis=1) * dv / safe
    return {"density_m3": n, "mean_velocity_m_s": u, "temperature_k": mass_kg * var / BOLTZMANN_CONSTANT}
