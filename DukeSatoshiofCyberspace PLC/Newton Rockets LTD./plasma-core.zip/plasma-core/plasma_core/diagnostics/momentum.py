"""Momentum diagnostics.

    P_particles = sum_p m_p w_p v_p                     [kg m/s] (time-centred v)
    P_field     = eps0 sum_j (E_j x B_j) V_cell         [kg m/s] (EM solver only;
                                                          self-consistent fields, cell-centred)
    momentum_error = |P(t) - P(0)| / P_scale,
    P_scale = sqrt(2 M E_tot(0)),  M = total mobile mass in the domain,
    i.e. the momentum the whole plasma would carry if all its initial energy
    were bulk kinetic energy.  It is non-zero even for a cold plasma at rest
    (where P(0) = 0 and sum m|v| = 0 cannot be used).

Momentum conservation is exact (to round-off) for a periodic electrostatic
PIC run only if deposition and interpolation use the same shape and the
field solve is spatially symmetric; ``fft_fd`` and ``fft_spectral`` satisfy
this.  It is *measured*, never assumed.
"""

from __future__ import annotations

import numpy as np

from ..constants import VACUUM_PERMITTIVITY


def particle_momentum(velocities, masses_per_particle, weights) -> np.ndarray:
    return np.sum((masses_per_particle * weights)[:, None] * velocities, axis=0)


def particle_momentum_scale(velocities, masses_per_particle, weights) -> float:
    return float(np.sum(masses_per_particle * weights * np.linalg.norm(velocities, axis=1)))


def field_momentum(E: np.ndarray, B: np.ndarray, cell_volume_m3: float) -> np.ndarray:
    return VACUUM_PERMITTIVITY * np.sum(np.cross(E, B), axis=0) * cell_volume_m3
