"""Diagnostics: observers of the simulation state (never inputs to the physics)."""

from .analysis import (
    FrequencyFit,
    GrowthFit,
    fft_peak_frequency,
    fit_damped_oscillation,
    fit_growth_rate,
    peak_envelope_rate,
    peak_period_frequency,
    phase_velocity_from_mode,
)
from .conservation import StabilityMonitor
from .manager import DiagnosticsManager, fourier_mode

__all__ = [
    "DiagnosticsManager", "StabilityMonitor", "fourier_mode", "FrequencyFit", "GrowthFit",
    "fft_peak_frequency", "fit_damped_oscillation", "fit_growth_rate", "peak_envelope_rate",
    "peak_period_frequency", "phase_velocity_from_mode",
]
