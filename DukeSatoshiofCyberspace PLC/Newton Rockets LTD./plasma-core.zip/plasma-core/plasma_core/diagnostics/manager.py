"""Diagnostics manager: samples the :class:`PlasmaState` at configured intervals.

Each diagnostic group has its own interval (``DiagnosticsConfig``).  At every
step where at least one group is due, a row is appended to the time-series
table with the columns of the due groups (absent groups are NaN when the
table is exported).  All reference values (initial energy, charge,
momentum, species weight) are taken at the *first* sample and stored so that
restarted runs continue the same error definitions.

Columns (SI units, per unit transverse area in 1D):

energy               kinetic_energy_j, electric_field_energy_j, magnetic_field_energy_j,
                     field_energy_j, total_energy_j, energy_error, energy_lost_j,
                     energy_error_accounted, power_j_dot_e_w
charge               total_charge_c, grid_charge_c, charge_residual_c, charge_lost_c,
                     relative_charge_error
momentum             momentum_{x,y,z}_kg_m_s, momentum_error [, field_momentum_{x,y,z}_kg_m_s]
temperature          temperature_k__<species>, electron_temperature_k, ion_temperature_k
density              density_{mean,min,max,std}_m3__<species>, charge_density_{min,max}_c_m3
field_statistics     e_max_v_m, e_rms_{x,y,z}_v_m, b_max_t, mode_{amp,re,im}_E{x|y}_m<m>,
                     poisson_residual, gauss_residual
particle_statistics  particles__<s>, weight__<s>, relative_mass_error__<s>,
                     mass_error_accounted__<s>, particles_lost__<s>
velocity_distribution  vx_{skewness,kurtosis}__<s>, anisotropy__<s> (+ histograms in ``distributions``)
"""

from __future__ import annotations

import math

import numpy as np

from ..state import PlasmaState
from .distribution import velocity_distribution
from .density import spatial_statistics

GROUPS = ("energy", "charge", "momentum", "temperature", "density", "field_statistics", "particle_statistics",
          "velocity_distribution")


def fourier_mode(field_1d: np.ndarray, x_rel: np.ndarray, k: float) -> complex:
    """(2/N) sum_j F_j exp(-i k x_j): complex amplitude of cos/sin mode k (x_rel = x - x_lo)."""
    return complex(2.0 / field_1d.shape[0] * np.sum(field_1d * np.exp(-1j * k * x_rel)))


class DiagnosticsManager:
    def __init__(self, config, species, grid) -> None:
        self.cfg = config.diagnostics
        self.species = species
        self.grid = grid
        self.solver = config.solver.type
        self.B0 = np.asarray(config.solver.external_magnetic_field_t, dtype=float)
        self.intervals = {g: self.cfg.interval_for(g) for g in GROUPS}
        self.rows: list[dict] = []
        self.distributions: list[dict] = []
        self.trajectories: dict[int, list[list[float]]] = {int(i): [] for i in self.cfg.record_trajectories}
        self.reference: dict = {}
        self.last_step: int | None = None
        from .charge import absolute_charge_scale

        self.q_abs = absolute_charge_scale(species, grid.domain_volume_m3)
        self.total_mass = float(sum(s.mass_kg * s.density_m3 for s in species if s.mobile)) * grid.domain_volume_m3

    # ------------------------------------------------------------------
    def due_groups(self, step: int) -> list[str]:
        return [g for g in GROUPS if self.intervals[g] > 0 and step % self.intervals[g] == 0]

    def is_due(self, step: int) -> bool:
        return bool(self.due_groups(step)) or (bool(self.trajectories) and step % self.intervals["energy"] == 0)

    def record(self, state: PlasmaState, force: bool = False) -> dict | None:
        step = state.step
        groups = [g for g in GROUPS if self.intervals[g] > 0] if force else self.due_groups(step)
        if not groups and not self.trajectories:
            return None
        row: dict = {"step": step, "time_s": state.time_s}
        ex = state.extras
        names = state.species_names
        if "energy" in groups:
            tot = state.total_energy_j
            self.reference.setdefault("total_energy_j", tot)
            E0 = self.reference["total_energy_j"]
            lost = float(np.sum(ex.get("loss_ledger", {}).get("energy_lost_j", [0.0])))
            row.update(kinetic_energy_j=state.kinetic_energy_j, electric_field_energy_j=state.electric_field_energy_j,
                       magnetic_field_energy_j=state.magnetic_field_energy_j, field_energy_j=state.field_energy_j,
                       total_energy_j=tot, energy_error=(tot - E0) / E0 if E0 else math.nan, energy_lost_j=lost,
                       energy_error_accounted=(tot + lost - E0) / E0 if E0 else math.nan,
                       power_j_dot_e_w=ex.get("power_j_dot_e_w", math.nan))
            if "kinetic_energy_by_species_j" in ex:
                for n, k in zip(names, ex["kinetic_energy_by_species_j"]):
                    row[f"kinetic_energy_j__{n}"] = float(k)
        if "charge" in groups:
            Q = state.total_charge_c
            self.reference.setdefault("total_charge_c", Q)
            Q0 = self.reference["total_charge_c"]
            qlost = float(np.sum(ex.get("loss_ledger", {}).get("charge_lost_c", [0.0])))
            row.update(total_charge_c=Q, grid_charge_c=ex.get("grid_charge_c", math.nan), charge_residual_c=Q - Q0,
                       charge_lost_c=qlost, relative_charge_error=abs(Q + qlost - Q0) / self.q_abs)
        if "momentum" in groups:
            P = np.asarray(state.total_momentum_kg_m_s)
            if "momentum_kg_m_s" not in self.reference:
                self.reference["momentum_kg_m_s"] = P.tolist()
                # P_scale = sqrt(2 M E_tot(0)): momentum of the total mass carrying the total energy
                self.reference["momentum_scale_kg_m_s"] = math.sqrt(2.0 * self.total_mass * max(state.total_energy_j, 0.0))
            P0 = np.asarray(self.reference["momentum_kg_m_s"])
            sc = self.reference["momentum_scale_kg_m_s"]
            row.update(momentum_x_kg_m_s=P[0], momentum_y_kg_m_s=P[1], momentum_z_kg_m_s=P[2],
                       momentum_error=float(np.linalg.norm(P - P0) / sc) if sc > 0 else math.nan)
            if "field_momentum_kg_m_s" in ex:
                fp = ex["field_momentum_kg_m_s"]
                row.update(field_momentum_x_kg_m_s=fp[0], field_momentum_y_kg_m_s=fp[1], field_momentum_z_kg_m_s=fp[2])
        if "temperature" in groups:
            for n, T in zip(names, state.species_temperature_k):
                row[f"temperature_k__{n}"] = float(T)
            row.update(electron_temperature_k=state.electron_temperature_k, ion_temperature_k=state.ion_temperature_k)
            for key in ("temperature_parallel_k", "temperature_perpendicular_k"):
                if key in ex:
                    for n, T in zip(names, ex[key]):
                        row[f"{key}__{n}"] = float(T)
        if "density" in groups:
            for i, n in enumerate(names):
                st = spatial_statistics(state.number_density_m3[i])
                for k, v in st.items():
                    row[f"density_{k}_m3__{n}"] = v
            row["charge_density_min_c_m3"] = float(state.charge_density_c_m3.min())
            row["charge_density_max_c_m3"] = float(state.charge_density_c_m3.max())
        if "field_statistics" in groups:
            E = state.electric_field_v_m
            B = state.magnetic_field_t
            row["e_max_v_m"] = float(np.sqrt(np.max(np.einsum("ij,ij->i", E, E))))
            for c, ax in enumerate("xyz"):
                row[f"e_rms_{ax}_v_m"] = float(np.sqrt(np.mean(E[:, c] ** 2)))
            row["b_max_t"] = float(np.sqrt(np.max(np.einsum("ij,ij->i", B, B))))
            Eg = state.field_on_grid("electric_field_v_m")
            if self.grid.dimension == 2:
                Eg = Eg.mean(axis=1)
            x_rel = self.grid.centres(0) - self.grid.lower_m[0]
            comps = ("x", "y") if self.solver == "electromagnetic_pic" else ("x",)
            for m in self.cfg.field_modes:
                if m > self.grid.cells[0] // 2:
                    continue
                k = self.grid.mode_wavenumber(m)
                for comp in comps:
                    c = "xyz".index(comp)
                    a = fourier_mode(Eg[:, c], x_rel, k)
                    row[f"mode_amp_E{comp}_m{m}"] = abs(a)
                    row[f"mode_re_E{comp}_m{m}"] = a.real
                    row[f"mode_im_E{comp}_m{m}"] = a.imag
            row["poisson_residual"] = ex.get("poisson_residual", math.nan)
            row["gauss_residual"] = ex.get("gauss_residual", math.nan)
        if "particle_statistics" in groups:
            counts = ex.get("particles_by_species")
            weights = ex.get("weight_by_species")
            ledger = ex.get("loss_ledger", {})
            if weights is not None:
                if "weight_by_species" not in self.reference:
                    self.reference["weight_by_species"] = [float(w) for w in weights]
                    self.reference["particles_by_species"] = [int(c) for c in counts]
                W0 = self.reference["weight_by_species"]
                wl = ledger.get("weight_lost", [0.0] * len(names))
                pl = ledger.get("particles_lost", [0] * len(names))
                for i, n in enumerate(names):
                    if not self.species[i].mobile:
                        continue
                    row[f"particles__{n}"] = int(counts[i])
                    row[f"weight__{n}"] = float(weights[i])
                    row[f"particles_lost__{n}"] = int(pl[i])
                    if W0[i] > 0:
                        row[f"relative_mass_error__{n}"] = (weights[i] - W0[i]) / W0[i]
                        row[f"mass_error_accounted__{n}"] = (weights[i] + wl[i] - W0[i]) / W0[i]
        if "velocity_distribution" in groups and state.particle_velocities_m_s is not None:
            rec = {"step": step, "time_s": state.time_s, "species": {}}
            for i, n in enumerate(names):
                if not self.species[i].mobile:
                    continue
                m = state.particle_species_id == i
                if not m.any():
                    continue
                d = velocity_distribution(state.particle_velocities_m_s[m], state.particle_weights[m],
                                          self.species[i].mass_kg, self.cfg.distribution_bins,
                                          B=self.B0 if np.any(self.B0) else None)
                rec["species"][n] = d
                row[f"vx_skewness__{n}"] = d["components"]["vx"]["skewness"]
                row[f"vx_kurtosis__{n}"] = d["components"]["vx"]["kurtosis"]
                row[f"anisotropy__{n}"] = d["anisotropy"]
            self.distributions.append(rec)
        if self.trajectories and state.particle_ids is not None and step % self.intervals["energy"] == 0:
            for pid in self.trajectories:
                j = np.nonzero(state.particle_ids == pid)[0]
                if len(j):
                    j = int(j[0])
                    self.trajectories[pid].append([state.time_s, *state.particle_positions_m[j].tolist(),
                                                   *state.particle_velocities_m_s[j].tolist()])
        self.rows.append(row)
        self.last_step = step
        return row

    # ------------------------------------------------------------------
    def columns(self) -> list[str]:
        cols: list[str] = []
        seen = set()
        for r in self.rows:
            for k in r:
                if k not in seen:
                    seen.add(k)
                    cols.append(k)
        return cols

    def table(self) -> dict[str, np.ndarray]:
        """Column-oriented table: name -> array (NaN where a group was not sampled)."""
        cols = self.columns()
        out = {}
        for c in cols:
            vals = [r.get(c, math.nan) for r in self.rows]
            out[c] = np.asarray(vals, dtype=np.int64 if c == "step" else float)
        return out

    def to_dataframe(self):
        import pandas as pd

        return pd.DataFrame(self.table())

    def history(self, name: str) -> tuple[np.ndarray, np.ndarray]:
        """(time_s, values) for the samples where ``name`` was recorded."""
        t, v = [], []
        for r in self.rows:
            if name in r:
                t.append(r["time_s"])
                v.append(r[name])
        return np.asarray(t), np.asarray(v)

    def trajectory(self, particle_id: int) -> np.ndarray:
        """(n_samples, 7): t, x, y, z, vx, vy, vz."""
        return np.asarray(self.trajectories.get(int(particle_id), []))

    def to_dict(self) -> dict:
        return {"rows": self.rows, "reference": self.reference, "last_step": self.last_step,
                "trajectories": {str(k): v for k, v in self.trajectories.items()}}

    def load_dict(self, d: dict) -> None:
        self.rows = [dict(r) for r in d["rows"]]
        self.reference = dict(d["reference"])
        self.last_step = d["last_step"]
        self.trajectories = {int(k): [list(x) for x in v] for k, v in d.get("trajectories", {}).items()}
