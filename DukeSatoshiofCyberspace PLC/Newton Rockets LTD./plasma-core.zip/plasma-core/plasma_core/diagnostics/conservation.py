"""Conservation and numerical-stability monitoring.

:class:`StabilityMonitor` stops a run (raises) when the numerical state is
corrupted or a conservation law diverges beyond a configured threshold:

* non-finite values (NaN/Inf) in particle or field arrays - always fatal;
* particle speed >= c (the non-relativistic pusher is invalid) - always fatal;
* |energy_error_accounted| > ``max_relative_energy_error`` - fatal unless
  ``action: warn`` was configured explicitly.  The check is disabled (and the
  reason recorded as an event) for open / non-conservative systems, where the
  total energy is not an invariant: external electric field, collision
  operator, isothermal fluid closure;
* relative_charge_error > ``max_relative_charge_error`` - idem.

Every warning or stop is recorded in ``events`` (and in the output files).
"""

from __future__ import annotations

import warnings

import numpy as np

from ..constants import SPEED_OF_LIGHT
from ..exceptions import ConservationError, NumericalInstabilityError


class StabilityMonitor:
    def __init__(self, config, energy_conserving: bool = True, reason: str = "") -> None:
        self.cfg = config
        self.events: list[dict] = []
        self.energy_conserving = energy_conserving
        if not energy_conserving:
            self.events.append({"step": 0, "type": "energy_check_disabled", "reason": reason})

    def check_arrays(self, step: int, arrays: dict[str, np.ndarray]) -> None:
        for name, a in arrays.items():
            if a is None or a.size == 0:
                continue
            if not np.all(np.isfinite(a)):
                bad = int(np.size(a) - np.count_nonzero(np.isfinite(a)))
                self.events.append({"step": step, "type": "non_finite", "array": name, "count": bad})
                raise NumericalInstabilityError(
                    f"non-finite values detected in '{name}' at step {step}",
                    why=f"{bad} NaN/Inf entries; the numerical state is corrupted and cannot be continued",
                    parameter="time.dt_s / grid.cells",
                    investigate="inspect the diagnostics history before this step (energy growth, max |E|); "
                                "check the pre-run stability assessment (plasma_core validate config)")

    def check_speed(self, step: int, velocities: np.ndarray) -> None:
        if velocities is None or velocities.size == 0:
            return
        vmax = float(np.sqrt(np.max(np.einsum("ij,ij->i", velocities, velocities))))
        if vmax >= SPEED_OF_LIGHT:
            self.events.append({"step": step, "type": "superluminal", "max_speed_m_s": vmax})
            raise NumericalInstabilityError(
                f"particle speed {vmax:.4e} m/s >= c at step {step}",
                why="the non-relativistic Boris pusher is invalid at |v| >= c; this indicates exploding fields",
                parameter="time.dt_s",
                investigate="reduce dt, check omega_p dt and the particle CFL number")

    def check_row(self, row: dict) -> None:
        cfg = self.cfg
        checks = []
        ee = row.get("energy_error_accounted")
        if self.energy_conserving and cfg.max_relative_energy_error is not None and ee is not None and np.isfinite(ee):
            if abs(ee) > cfg.max_relative_energy_error:
                checks.append(("energy_divergence", abs(ee), cfg.max_relative_energy_error,
                               "diagnostics.stability.max_relative_energy_error", NumericalInstabilityError))
        ce = row.get("relative_charge_error")
        if cfg.max_relative_charge_error is not None and ce is not None and np.isfinite(ce):
            if ce > cfg.max_relative_charge_error:
                checks.append(("charge_divergence", ce, cfg.max_relative_charge_error,
                               "diagnostics.stability.max_relative_charge_error", ConservationError))
        for kind, value, limit, param, exc in checks:
            ev = {"step": row.get("step"), "time_s": row.get("time_s"), "type": kind, "value": value, "limit": limit}
            self.events.append(ev)
            msg = f"{kind}: {value:.3e} exceeds {limit:.3e} at step {row.get('step')}"
            if cfg.action == "stop":
                raise exc(msg, why="a conservation diagnostic exceeded its configured tolerance",
                          parameter=param, investigate="examine the diagnostics table; reduce dt or refine the grid")
            warnings.warn(msg + " (continuing because diagnostics.stability.action = 'warn')", RuntimeWarning,
                          stacklevel=2)
