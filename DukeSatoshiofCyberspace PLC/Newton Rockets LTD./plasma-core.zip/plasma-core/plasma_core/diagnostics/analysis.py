"""Post-processing analysis: frequencies, growth/damping rates, phase velocity.

These functions *measure* quantities from simulated time series.  They never
use theory as input except for optional initial guesses, and they report fit
quality (R^2) and standard errors so that a measurement can be judged.
"""

from __future__ import annotations

from dataclasses import asdict, dataclass

import warnings

import numpy as np
from scipy.optimize import OptimizeWarning, curve_fit


@dataclass
class FrequencyFit:
    omega_rad_s: float
    omega_std_err: float
    gamma_s: float  # amplitude growth (+) / damping (-) rate
    gamma_std_err: float
    amplitude: float
    phase_rad: float
    r_squared: float
    n_points: int
    method: str

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass
class GrowthFit:
    growth_rate_s: float
    growth_rate_std_err: float
    fit_interval_s: tuple[float, float]
    r_squared: float
    n_points: int
    method: str

    def to_dict(self) -> dict:
        return asdict(self)


def fft_peak_frequency(t: np.ndarray, y: np.ndarray, pad: int = 8) -> float:
    """Angular frequency of the largest spectral peak (Hann window, parabolic refinement)."""
    t = np.asarray(t, float)
    y = np.asarray(y, float) - np.mean(y)
    dt = float(np.mean(np.diff(t)))
    n = len(y) * pad
    spec = np.abs(np.fft.rfft(y * np.hanning(len(y)), n))
    freqs = np.fft.rfftfreq(n, dt)
    i = int(np.argmax(spec[1:]) + 1)
    if 1 <= i < len(spec) - 1:
        a, b, c = np.log(spec[i - 1] + 1e-300), np.log(spec[i] + 1e-300), np.log(spec[i + 1] + 1e-300)
        denom = a - 2 * b + c
        shift = 0.5 * (a - c) / denom if denom != 0 else 0.0
    else:
        shift = 0.0
    return 2 * np.pi * (freqs[i] + shift * (freqs[1] - freqs[0]))


def _r2(y, yfit) -> float:
    ss_res = float(np.sum((y - yfit) ** 2))
    ss_tot = float(np.sum((y - np.mean(y)) ** 2))
    return 1.0 - ss_res / ss_tot if ss_tot > 0 else float("nan")


def fit_damped_oscillation(t, y, omega_guess: float | None = None, fit_offset: bool = True) -> FrequencyFit:
    """Least-squares fit y = A cos(omega t + phi) exp(gamma t) [+ c]."""
    t = np.asarray(t, float)
    y = np.asarray(y, float)
    w0 = omega_guess if omega_guess is not None else fft_peak_frequency(t, y)
    t0 = t[0]
    tt = t - t0
    A0 = float(np.max(np.abs(y - y.mean())))
    # linear least squares for phase at fixed omega
    M = np.stack([np.cos(w0 * tt), np.sin(w0 * tt), np.ones_like(tt)], axis=1)
    coef, *_ = np.linalg.lstsq(M, y, rcond=None)
    phi0 = float(np.arctan2(-coef[1], coef[0]))
    A0 = float(np.hypot(coef[0], coef[1])) or A0

    if fit_offset:
        def model(tt, A, w, phi, g, c):
            return A * np.cos(w * tt + phi) * np.exp(g * tt) + c
        p0 = [A0, w0, phi0, 0.0, coef[2]]
    else:
        def model(tt, A, w, phi, g):
            return A * np.cos(w * tt + phi) * np.exp(g * tt)
        p0 = [A0, w0, phi0, 0.0]
    with warnings.catch_warnings():
        # an exact fit (e.g. a dispersion-free scheme) leaves the covariance undefined: report NaN errors
        warnings.simplefilter("ignore", OptimizeWarning)
        popt, pcov = curve_fit(model, tt, y, p0=p0, maxfev=20000)
    perr = np.sqrt(np.abs(np.diag(pcov)))
    A, w, phi, g = popt[:4]
    if A < 0:
        A, phi = -A, phi + np.pi
    if w < 0:
        w, phi = -w, -phi
    phi = float(phi % (2 * np.pi))
    return FrequencyFit(float(w), float(perr[1]), float(g), float(perr[3]), float(A), phi,
                        _r2(y, model(tt, *popt)), len(t), "nonlinear least squares A cos(wt+phi) e^{gt} (+c)")


def _linear_fit(x, y):
    n = len(x)
    A = np.stack([x, np.ones_like(x)], axis=1)
    coef, *_ = np.linalg.lstsq(A, y, rcond=None)
    yfit = A @ coef
    r2 = _r2(y, yfit)
    if n > 2:
        s2 = float(np.sum((y - yfit) ** 2)) / (n - 2)
        se = float(np.sqrt(s2 / np.sum((x - x.mean()) ** 2)))
    else:
        se = float("nan")
    return float(coef[0]), se, r2


def fit_growth_rate(t, amplitude, interval: tuple[float, float] | None = None, *,
                    saturation_fraction: float = 0.3, min_points: int = 8, min_r2: float = 0.98) -> GrowthFit:
    """Fit log|A| = gamma t + c in the linear-growth regime.

    If ``interval`` is None it is selected automatically and reproducibly:
    the end is the first sample where |A| reaches ``saturation_fraction`` of its
    maximum (before saturation); among all start indices leaving at least
    ``min_points`` samples, the earliest start whose fit has R^2 >= ``min_r2``
    is used (longest acceptable window); if none qualifies, the window with the
    highest R^2 is returned (and its R^2 reported).
    """
    t = np.asarray(t, float)
    a = np.abs(np.asarray(amplitude, float))
    keep = a > 0
    t, a = t[keep], a[keep]
    la = np.log(a)
    if interval is not None:
        m = (t >= interval[0]) & (t <= interval[1])
        g, se, r2 = _linear_fit(t[m], la[m])
        return GrowthFit(g, se, (float(t[m][0]), float(t[m][-1])), r2, int(m.sum()), "explicit interval")
    imax = int(np.argmax(a))
    above = np.nonzero(a[: imax + 1] >= saturation_fraction * a[imax])[0]
    end = int(above[0]) if len(above) else imax
    best = None
    for start in range(0, max(0, end - min_points + 1)):
        g, se, r2 = _linear_fit(t[start:end + 1], la[start:end + 1])
        if g <= 0:
            continue
        cand = (start, g, se, r2)
        if r2 >= min_r2:
            best = cand
            break
        if best is None or r2 > best[3]:
            best = cand
    if best is None:
        raise ValueError("no growing linear regime found")
    s, g, se, r2 = best
    return GrowthFit(g, se, (float(t[s]), float(t[end])), r2, end - s + 1,
                     f"automatic: end at {saturation_fraction:.0%} of max, earliest start with R^2>={min_r2}")


def peak_envelope_rate(t, y, t_range: tuple[float, float] | None = None) -> GrowthFit:
    """Damping/growth rate from a linear fit to log of the local maxima of |y|.

    Appropriate for Landau damping where |E_k| oscillates at 2 omega.
    """
    t = np.asarray(t, float)
    a = np.abs(np.asarray(y, float))
    idx = np.nonzero((a[1:-1] > a[:-2]) & (a[1:-1] >= a[2:]))[0] + 1
    if t_range is not None:
        idx = idx[(t[idx] >= t_range[0]) & (t[idx] <= t_range[1])]
    if len(idx) < 3:
        raise ValueError("fewer than three envelope peaks in the fit range")
    # refine each peak by parabolic interpolation in log space
    tp, lp = [], []
    dt = t[1] - t[0]
    for i in idx:
        y0, y1, y2 = np.log(a[i - 1]), np.log(a[i]), np.log(a[i + 1])
        den = y0 - 2 * y1 + y2
        s = 0.5 * (y0 - y2) / den if den != 0 else 0.0
        tp.append(t[i] + s * dt)
        lp.append(y1 - 0.25 * (y0 - y2) * s)
    tp, lp = np.array(tp), np.array(lp)
    g, se, r2 = _linear_fit(tp, lp)
    return GrowthFit(g, se, (float(tp[0]), float(tp[-1])), r2, len(tp), "linear fit to log of |y| peaks")


def peak_period_frequency(t, y, t_range=None) -> float:
    """omega from the mean spacing of peaks of |y| (|y| peaks twice per period)."""
    t = np.asarray(t, float)
    a = np.abs(np.asarray(y, float))
    idx = np.nonzero((a[1:-1] > a[:-2]) & (a[1:-1] >= a[2:]))[0] + 1
    if t_range is not None:
        idx = idx[(t[idx] >= t_range[0]) & (t[idx] <= t_range[1])]
    spacing = np.mean(np.diff(t[idx]))
    return float(np.pi / spacing)


def phase_velocity_from_mode(t, complex_mode, k: float) -> tuple[float, float]:
    """(omega, v_phase) from the unwrapped phase slope of a travelling mode exp(i(kx - omega t))."""
    ph = np.unwrap(np.angle(np.asarray(complex_mode)))
    t = np.asarray(t, float)
    slope, se, _ = _linear_fit(t, ph)
    omega = -slope
    return omega, omega / k
