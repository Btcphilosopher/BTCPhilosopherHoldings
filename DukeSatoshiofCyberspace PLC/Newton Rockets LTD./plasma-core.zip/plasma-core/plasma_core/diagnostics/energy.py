"""Energy diagnostics.

    K   = sum_p (1/2) m_p w_p |v_p|^2                         particle kinetic energy
    W_E = sum_j (eps0/2) |E_j|^2 V_cell                       electric field energy
    W_B = sum_j |B_j|^2 / (2 mu0) V_cell                      magnetic field energy
                                                              (self-consistent part only)
    energy_error = (E_tot(t) - E_tot(0)) / E_tot(0)

Energy transfer:  P_JE = integral J . E dV = sum_p q_p w_p v_p . E(x_p)  [W]
(the particle form is used; for the deposited-current form see
:func:`grid_power`).  For a closed electrostatic system dK/dt = P_JE and
dW_E/dt = -P_JE.  In 1D all energies are per unit transverse area [J/m^2].
"""

from __future__ import annotations

import numpy as np

from ..fields.electric_field import electric_field_energy
from ..fields.magnetic_field import magnetic_field_energy


def kinetic_energy(velocities: np.ndarray, masses_per_particle: np.ndarray, weights: np.ndarray) -> float:
    return 0.5 * float(np.sum(masses_per_particle * weights * np.einsum("ij,ij->i", velocities, velocities)))


def leapfrog_kinetic_energy(v_old: np.ndarray, v_new: np.ndarray, masses_per_particle: np.ndarray,
                            weights: np.ndarray) -> float:
    """Time-centred K^n = sum m w (|v^{n-1/2}|^2 + |v^{n+1/2}|^2) / 4."""
    s = np.einsum("ij,ij->i", v_old, v_old) + np.einsum("ij,ij->i", v_new, v_new)
    return 0.25 * float(np.sum(masses_per_particle * weights * s))


def kinetic_energy_by_species(velocities, masses_per_particle, weights, species_id, n_species) -> np.ndarray:
    e = 0.5 * masses_per_particle * weights * np.einsum("ij,ij->i", velocities, velocities)
    return np.bincount(species_id, weights=e, minlength=n_species)


def field_energy(E: np.ndarray, B: np.ndarray | None, cell_volume_m3: float) -> tuple[float, float]:
    we = electric_field_energy(E, cell_volume_m3)
    wb = magnetic_field_energy(B, cell_volume_m3) if B is not None else 0.0
    return we, wb


def relative_energy_error(total: float, initial: float) -> float:
    return (total - initial) / initial if initial != 0 else float("nan")


def particle_power(velocities: np.ndarray, E_at_particles: np.ndarray, charge_weights: np.ndarray) -> float:
    """sum_p q_p w_p v_p . E_p [W] (per unit area in 1D)."""
    return float(np.sum(charge_weights * np.einsum("ij,ij->i", velocities, E_at_particles)))


def grid_power(J: np.ndarray, E: np.ndarray, cell_volume_m3: float) -> float:
    return float(np.sum(J * E)) * cell_volume_m3
