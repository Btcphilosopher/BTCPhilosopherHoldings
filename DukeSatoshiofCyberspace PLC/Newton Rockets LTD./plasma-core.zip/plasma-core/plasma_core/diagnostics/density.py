"""Density diagnostics on the grid.

    n_s(x_j)   = sum_{p in s} w_p W(x_j - x_p) / V_cell      [m^-3]
    rho(x_j)   = sum_s q_s n_s(x_j)  (+ backgrounds)        [C m^-3]
    rho_m(x_j) = sum_s m_s n_s(x_j)                         [kg m^-3]
Spatial statistics: mean, min, max, standard deviation over cells.
"""

from __future__ import annotations

import numpy as np

from ..pic.charge_deposition import deposit_scalar


def species_number_density(positions, weights, species_id, species, grid, shape="cic", backend=None) -> np.ndarray:
    """(N_s, grid.shape) number densities; immobile species are uniform."""
    out = np.zeros((len(species),) + grid.shape)
    for i, s in enumerate(species):
        if not s.mobile:
            out[i] = s.density_m3
            continue
        m = species_id == i
        if m.any():
            dep = backend.deposit if backend is not None else deposit_scalar
            out[i] = dep(positions[m], weights[m], grid, shape, 0.5) / grid.cell_volume_m3
    return out


def charge_and_mass_density(number_density: np.ndarray, species) -> tuple[np.ndarray, np.ndarray]:
    q = np.array([s.charge_c for s in species]).reshape((-1,) + (1,) * (number_density.ndim - 1))
    m = np.array([s.mass_kg for s in species]).reshape(q.shape)
    return (q * number_density).sum(axis=0), (m * number_density).sum(axis=0)


def spatial_statistics(field: np.ndarray) -> dict[str, float]:
    f = np.asarray(field, dtype=float)
    return {"mean": float(f.mean()), "min": float(f.min()), "max": float(f.max()), "std": float(f.std())}
