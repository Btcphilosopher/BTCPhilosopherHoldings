"""Temperature estimators.

Isotropic 3V estimator (particles):
    (3/2) k_B T = (1/2) m <|v - u|^2>,    u = <v>,
with weighted population averages <g> = sum w g / sum w (biased, 1/N
normalisation; the N/(N-1) correction is < 1e-4 for N > 1e4 and is not applied).

Per-component:  k_B T_i = m <(v_i - u_i)^2>.
Magnetised anisotropy (b = B/|B|):
    k_B T_par  = m <(v_par - u_par)^2>,  k_B T_perp = m <|v_perp - u_perp|^2> / 2,
    anisotropy = T_perp / T_par.
Vlasov 1V estimator:  k_B T = m <(v_x - u_x)^2>  (one degree of freedom).
"""

from __future__ import annotations

import numpy as np

from ..constants import BOLTZMANN_CONSTANT


def weighted_mean_velocity(v: np.ndarray, w: np.ndarray) -> np.ndarray:
    return (w[:, None] * v).sum(axis=0) / w.sum()


def component_temperatures(v: np.ndarray, w: np.ndarray, mass_kg: float) -> np.ndarray:
    if v.shape[0] == 0:
        return np.full(3, np.nan)
    u = weighted_mean_velocity(v, w)
    var = (w[:, None] * (v - u) ** 2).sum(axis=0) / w.sum()
    return mass_kg * var / BOLTZMANN_CONSTANT


def isotropic_temperature(v: np.ndarray, w: np.ndarray, mass_kg: float) -> float:
    return float(np.mean(component_temperatures(v, w, mass_kg)))


def anisotropic_temperature(v: np.ndarray, w: np.ndarray, mass_kg: float, B) -> tuple[float, float]:
    """(T_par, T_perp) relative to the direction of B."""
    b = np.asarray(B, dtype=float)
    b = b / np.linalg.norm(b)
    u = weighted_mean_velocity(v, w)
    dv = v - u
    vpar = dv @ b
    vperp2 = np.einsum("ij,ij->i", dv, dv) - vpar**2
    W = w.sum()
    tpar = mass_kg * float((w * vpar**2).sum() / W) / BOLTZMANN_CONSTANT
    tperp = mass_kg * float((w * vperp2).sum() / W) / (2.0 * BOLTZMANN_CONSTANT)
    return tpar, tperp


def species_temperatures(v, w, species_id, species) -> np.ndarray:
    out = np.full(len(species), np.nan)
    for i, s in enumerate(species):
        if not s.mobile:
            out[i] = s.temperature_k
            continue
        m = species_id == i
        if m.any():
            out[i] = isotropic_temperature(v[m], w[m], s.mass_kg)
    return out


def electron_ion_temperatures(temps: np.ndarray, species, weights_by_species: np.ndarray) -> tuple[float, float]:
    """Weight-averaged temperature of negative (electron-like) and positive mobile species."""
    def avg(sel):
        idx = [i for i, s in enumerate(species) if sel(s) and s.mobile and np.isfinite(temps[i])]
        if not idx:
            return float("nan")
        ww = np.array([weights_by_species[i] for i in idx])
        if ww.sum() == 0:
            return float("nan")
        return float(np.sum(ww * temps[idx]) / ww.sum())
    return avg(lambda s: s.charge_c < 0), avg(lambda s: s.charge_c > 0)
