"""Field-grid layouts: where each field component lives on the spatial grid.

Two layouts are implemented and they are *not* interchangeable:

``COLLOCATED``
    All components of E and B (and rho, phi, J) are stored at cell centres.
    Used by the electrostatic PIC, fluid and Vlasov solvers.

``YEE_1D``
    One-dimensional Yee staggering used by the 1D electromagnetic solver
    (see :mod:`plasma_core.solvers.maxwell`):

    ============  ============  ======================
    component     location      time level
    ============  ============  ======================
    E_x           cell centre   integer (from Poisson)
    E_y, E_z      cell centre   integer
    B_x           uniform       constant (div B = 0 in 1D)
    B_y, B_z      cell edge     integer (two half-step updates)
    J_y, J_z      cell centre   half-integer
    ============  ============  ======================

    Cell edge ``i`` is at ``x_lo + i dx`` (periodic: edge n == edge 0).

A full 2D/3D Yee lattice is *not* implemented.  Requesting an
electromagnetic solve on a 2D grid raises :class:`SolverConfigurationError`.
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum

from ..exceptions import SolverConfigurationError
from .spatial_grid import SpatialGrid


class FieldLayout(str, Enum):
    COLLOCATED = "collocated"
    YEE_1D = "yee_1d"


#: Location of each component as an offset in units of dx from the cell's
#: lower edge: 0.5 = cell centre, 0.0 = cell edge, None = spatially uniform.
_LOCATIONS: dict[FieldLayout, dict[str, float | None]] = {
    FieldLayout.COLLOCATED: {
        "Ex": 0.5, "Ey": 0.5, "Ez": 0.5, "Bx": 0.5, "By": 0.5, "Bz": 0.5,
        "rho": 0.5, "phi": 0.5, "Jx": 0.5, "Jy": 0.5, "Jz": 0.5,
    },
    FieldLayout.YEE_1D: {
        "Ex": 0.5, "Ey": 0.5, "Ez": 0.5, "Bx": None, "By": 0.0, "Bz": 0.0,
        "rho": 0.5, "phi": 0.5, "Jx": 0.5, "Jy": 0.5, "Jz": 0.5,
    },
}


@dataclass(frozen=True)
class FieldGrid:
    """A spatial grid together with a field-component layout."""

    grid: SpatialGrid
    layout: FieldLayout = FieldLayout.COLLOCATED

    def __post_init__(self) -> None:
        if self.layout is FieldLayout.YEE_1D and self.grid.dimension != 1:
            raise SolverConfigurationError(
                "YEE_1D layout requested on a non-1D grid",
                why="only the 1D Yee lattice is implemented",
                parameter="domain.dimension",
                investigate="use dimension: 1 for electromagnetic_pic",
            )

    def location(self, component: str) -> float | None:
        """Offset (in cells) of ``component`` from the lower cell edge."""
        return _LOCATIONS[self.layout][component]

    def is_staggered(self) -> bool:
        return self.layout is not FieldLayout.COLLOCATED
