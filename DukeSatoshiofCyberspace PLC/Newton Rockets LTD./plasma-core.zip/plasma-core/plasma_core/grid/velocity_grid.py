"""Uniform velocity-space grid for kinetic (Vlasov) models.

The velocity grid is cell-centred: ``centres[j] = v_min + (j + 1/2) dv``.
Velocity moments are evaluated with the midpoint rule
``integral g(v) dv ~= sum_j g(v_j) dv``, which is spectrally accurate for
smooth functions that vanish at the grid boundaries (e.g. Maxwellians spanning
several thermal speeds).

1D velocity grids are implemented.  2D/3D velocity grids are represented by
a tuple of 1D axes (tensor-product grid); only 1V is used by the current
Vlasov solver (see docs/NUMERICS.md).
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np


@dataclass(frozen=True)
class VelocityAxis:
    """One uniform velocity axis [m/s]."""

    cells: int
    v_min_m_s: float
    v_max_m_s: float

    def __post_init__(self) -> None:
        if self.cells < 4:
            raise ValueError("velocity axis needs at least 4 cells")
        if not self.v_max_m_s > self.v_min_m_s:
            raise ValueError("v_max must exceed v_min")

    @property
    def spacing_m_s(self) -> float:
        return (self.v_max_m_s - self.v_min_m_s) / self.cells

    @property
    def centres(self) -> np.ndarray:
        return self.v_min_m_s + (np.arange(self.cells) + 0.5) * self.spacing_m_s

    @property
    def edges(self) -> np.ndarray:
        return np.linspace(self.v_min_m_s, self.v_max_m_s, self.cells + 1)


@dataclass(frozen=True)
class VelocityGrid:
    """Tensor-product velocity grid with 1-3 axes (vx[, vy[, vz]])."""

    axes: tuple[VelocityAxis, ...]

    @classmethod
    def uniform_1d(cls, cells: int, v_min_m_s: float, v_max_m_s: float) -> "VelocityGrid":
        return cls((VelocityAxis(cells, v_min_m_s, v_max_m_s),))

    @property
    def dimension(self) -> int:
        return len(self.axes)

    @property
    def shape(self) -> tuple[int, ...]:
        return tuple(a.cells for a in self.axes)

    @property
    def spacing_m_s(self) -> np.ndarray:
        return np.array([a.spacing_m_s for a in self.axes])

    @property
    def cell_volume(self) -> float:
        """Velocity-space cell volume [(m/s)^dimension]."""
        return float(np.prod(self.spacing_m_s))

    def centres(self, axis: int = 0) -> np.ndarray:
        return self.axes[axis].centres

    def edges(self, axis: int = 0) -> np.ndarray:
        return self.axes[axis].edges

    def to_dict(self) -> dict:
        return {"axes": [[a.cells, a.v_min_m_s, a.v_max_m_s] for a in self.axes]}

    @classmethod
    def from_dict(cls, d: dict) -> "VelocityGrid":
        return cls(tuple(VelocityAxis(int(c), float(a), float(b)) for c, a, b in d["axes"]))
