"""Uniform Cartesian spatial grid.

Conventions
-----------
* Axis order is (x, y, z); a 1D grid has only x, a 2D grid x and y.
* Cell ``i`` along an axis spans ``[edges[i], edges[i+1])`` and has centre
  ``centres[i] = lower + (i + 1/2) * dx``.
* Multi-dimensional grid arrays use C ordering with x as the *first* axis:
  a 2D scalar field has shape ``(nx, ny)``; a vector field ``(nx, ny, 3)``.
  The flat cell index is ``flat = i * ny + j``.
* The grid is uniform along each axis.  Non-uniform grids are a future
  extension and are deliberately not emulated.

Reduced dimensionality
----------------------
A 1D (2D) grid represents a system that is homogeneous along the missing
axes.  Cell "volumes" are therefore ``dx * (1 m)^2`` in 1D and
``dx * dy * (1 m)`` in 2D: every extensive quantity (energy, charge,
particle number) is *per unit transverse area* (1D) or *per unit length*
(2D).  Densities remain in m^-3.
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np


@dataclass(frozen=True)
class SpatialGrid:
    """Uniform 1D/2D (future 3D) Cartesian grid.

    Parameters
    ----------
    cells:
        Number of cells along each axis, e.g. ``(256,)`` or ``(64, 64)``.
    lower_m, upper_m:
        Domain limits along each axis [m].
    periodic:
        Periodicity flag along each axis.
    """

    cells: tuple[int, ...]
    lower_m: tuple[float, ...]
    upper_m: tuple[float, ...]
    periodic: tuple[bool, ...]

    def __post_init__(self) -> None:
        d = len(self.cells)
        if d not in (1, 2, 3):
            raise ValueError("SpatialGrid supports 1, 2 or 3 dimensions")
        if not (len(self.lower_m) == len(self.upper_m) == len(self.periodic) == d):
            raise ValueError("cells, lower_m, upper_m and periodic must have equal length")
        for n, lo, hi in zip(self.cells, self.lower_m, self.upper_m):
            if int(n) < 2:
                raise ValueError("each axis needs at least 2 cells")
            if not hi > lo:
                raise ValueError("upper_m must exceed lower_m on every axis")

    @classmethod
    def uniform(cls, cells, length_m, *, lower_m=None, periodic=True) -> "SpatialGrid":
        """Construct from cell counts and domain lengths."""
        cells = tuple(int(c) for c in np.atleast_1d(cells))
        length = tuple(float(x) for x in np.atleast_1d(length_m))
        if len(length) == 1 and len(cells) > 1:
            length = length * len(cells)
        lower = tuple(float(x) for x in np.atleast_1d(lower_m if lower_m is not None else 0.0))
        if len(lower) == 1 and len(cells) > 1:
            lower = lower * len(cells)
        per = tuple(bool(p) for p in np.atleast_1d(periodic))
        if len(per) == 1 and len(cells) > 1:
            per = per * len(cells)
        upper = tuple(lo + L for lo, L in zip(lower, length))
        return cls(cells=cells, lower_m=lower, upper_m=upper, periodic=per)

    # ------------------------------------------------------------------
    @property
    def dimension(self) -> int:
        return len(self.cells)

    @property
    def shape(self) -> tuple[int, ...]:
        """Shape of a scalar field on cell centres."""
        return tuple(int(c) for c in self.cells)

    @property
    def n_cells(self) -> int:
        return int(np.prod(self.cells))

    @property
    def lengths_m(self) -> np.ndarray:
        return np.asarray(self.upper_m) - np.asarray(self.lower_m)

    @property
    def spacing_m(self) -> np.ndarray:
        """Cell widths along each axis, shape (dimension,) [m]."""
        return self.lengths_m / np.asarray(self.cells)

    @property
    def cell_volume_m3(self) -> float:
        """Cell volume [m^3] including unit transverse extent (see module doc)."""
        return float(np.prod(self.spacing_m))

    @property
    def domain_volume_m3(self) -> float:
        return float(np.prod(self.lengths_m))

    def edges(self, axis: int = 0) -> np.ndarray:
        """Cell edges along ``axis``, shape (n+1,) [m]."""
        return np.linspace(self.lower_m[axis], self.upper_m[axis], self.cells[axis] + 1)

    def centres(self, axis: int = 0) -> np.ndarray:
        """Cell centres along ``axis``, shape (n,) [m]."""
        dx = self.spacing_m[axis]
        return self.lower_m[axis] + (np.arange(self.cells[axis]) + 0.5) * dx

    def widths(self, axis: int = 0) -> np.ndarray:
        """Cell widths along ``axis``, shape (n,) [m] (uniform)."""
        return np.full(self.cells[axis], self.spacing_m[axis])

    def mesh_centres(self) -> tuple[np.ndarray, ...]:
        """Meshgrid of cell centres with ``indexing='ij'``."""
        return tuple(np.meshgrid(*[self.centres(a) for a in range(self.dimension)], indexing="ij"))

    def flat_index(self, *index: int) -> int:
        """C-order flat index of a cell."""
        return int(np.ravel_multi_index(tuple(int(i) for i in index), self.shape))

    def wavenumbers(self, axis: int = 0) -> np.ndarray:
        """Angular wavenumbers of the discrete Fourier modes along ``axis`` [rad/m]."""
        return 2.0 * np.pi * np.fft.fftfreq(self.cells[axis], d=self.spacing_m[axis])

    def mode_wavenumber(self, mode: int, axis: int = 0) -> float:
        """k = 2 pi m / L for integer mode number m [rad/m]."""
        return 2.0 * np.pi * mode / self.lengths_m[axis]

    def to_dict(self) -> dict:
        return {
            "cells": list(self.cells),
            "lower_m": list(self.lower_m),
            "upper_m": list(self.upper_m),
            "periodic": list(self.periodic),
        }

    @classmethod
    def from_dict(cls, d: dict) -> "SpatialGrid":
        return cls(tuple(int(c) for c in d["cells"]), tuple(float(x) for x in d["lower_m"]),
                   tuple(float(x) for x in d["upper_m"]), tuple(bool(p) for p in d["periodic"]))
