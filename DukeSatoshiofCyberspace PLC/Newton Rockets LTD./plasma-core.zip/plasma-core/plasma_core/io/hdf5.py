"""HDF5 trajectory output and readers.

File layout::

    /metadata        attributes: reproducibility metadata (JSON for nested values)
    /configuration   attribute 'json': canonical configuration; 'hash'
    /grid            centres_<axis>, edges_<axis>, attributes cells/lower/upper/periodic
    /fields          time_s (n_out,), step (n_out,), electric_field_v_m (n_out, N_c, 3),
                     magnetic_field_t (n_out, N_c, 3), charge_density_c_m3 (n_out, N_c),
                     number_density_m3 (n_out, N_s, N_c), potential_v (n_out, N_c) [if available]
    /particles       step_<NNNNNNNN>/{positions_m, velocities_m_s, species_id, weights, particle_ids}
                     (deterministic subsample: particles with id % stride == 0 when N > particle_snapshot_max)
    /distribution    step_<NNNNNNNN>/<species>  Vlasov f(x, v) snapshots, velocity grids
    /diagnostics     one dataset per time-series column; attribute 'events' (JSON)
    /checkpoints     attribute 'index' (JSON list of {step, time_s, path})

Large arrays are gzip-compressed (level 4) and chunked along time.
"""

from __future__ import annotations

import json
from pathlib import Path

import h5py
import numpy as np

COMPRESSION = {"compression": "gzip", "compression_opts": 4}


def _set_attrs(group, d: dict) -> None:
    for k, v in d.items():
        if isinstance(v, (dict, list, tuple)) or v is None:
            group.attrs[k] = json.dumps(v, default=str)
        else:
            group.attrs[k] = v


def write_grid(h5, grid) -> None:
    g = h5.require_group("grid")
    for a, ax in enumerate("xyz"[: grid.dimension]):
        g.create_dataset(f"centres_{ax}_m", data=grid.centres(a))
        g.create_dataset(f"edges_{ax}_m", data=grid.edges(a))
    _set_attrs(g, grid.to_dict())


class HDF5OutputWriter:
    def __init__(self, path: str | Path, config, grid, metadata: dict) -> None:
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.h5 = h5py.File(self.path, "w")
        self.config = config
        self.grid = grid
        _set_attrs(self.h5.create_group("metadata"), metadata)
        c = self.h5.create_group("configuration")
        c.attrs["json"] = config.canonical_json()
        c.attrs["hash"] = config.config_hash()
        write_grid(self.h5, grid)
        self.h5.create_group("fields")
        self.h5.create_group("particles")
        self.h5.create_group("diagnostics")
        self.h5.create_group("checkpoints").attrs["index"] = "[]"
        self._n_out = 0

    def _append(self, name: str, arr: np.ndarray) -> None:
        f = self.h5["fields"]
        arr = np.asarray(arr)
        if name not in f:
            f.create_dataset(name, data=arr[None], maxshape=(None,) + arr.shape,
                             chunks=(1,) + arr.shape, **(COMPRESSION if arr.size > 64 else {}))
        else:
            d = f[name]
            d.resize(d.shape[0] + 1, axis=0)
            d[-1] = arr

    def write_snapshot(self, state) -> None:
        self._append("time_s", np.array(state.time_s))
        self._append("step", np.array(state.step))
        self._append("electric_field_v_m", state.electric_field_v_m)
        self._append("magnetic_field_t", state.magnetic_field_t)
        self._append("charge_density_c_m3", state.charge_density_c_m3)
        self._append("current_density_a_m2", state.current_density_a_m2)
        self._append("number_density_m3", state.number_density_m3)
        if state.potential_v is not None:
            self._append("potential_v", state.potential_v)
        if state.particle_positions_m is not None:
            n = state.particle_positions_m.shape[0]
            maxp = self.config.output.particle_snapshot_max
            if maxp > 0:
                stride = max(1, int(np.ceil(n / maxp)))
                sel = state.particle_ids % stride == 0
                g = self.h5["particles"].create_group(f"step_{state.step:08d}")
                g.attrs["time_s"] = state.time_s
                g.attrs["sampling"] = f"particles with id % {stride} == 0 (deterministic stride subsample)"
                g.attrs["velocity_time_centring"] = "time-synchronised (v^{n-1/2}+v^{n+1/2})/2"
                for k, arr in (("positions_m", state.particle_positions_m), ("velocities_m_s", state.particle_velocities_m_s),
                               ("species_id", state.particle_species_id), ("weights", state.particle_weights),
                               ("particle_ids", state.particle_ids)):
                    g.create_dataset(k, data=arr[sel], **(COMPRESSION if arr[sel].size > 64 else {}))
        dists = state.extras.get("distribution_functions")
        if dists:
            g = self.h5.require_group("distribution").create_group(f"step_{state.step:08d}")
            g.attrs["time_s"] = state.time_s
            g.attrs["units"] = "s m^-4 (number per m^3 per m/s)"
            for name, f in dists.items():
                g.create_dataset(name, data=f, **COMPRESSION)
                g.create_dataset(f"{name}__v_m_s", data=state.extras["velocity_grids_m_s"][name])
        self._n_out += 1

    def write_diagnostics(self, manager, events: list[dict]) -> None:
        g = self.h5["diagnostics"]
        for k, v in manager.table().items():
            if k in g:
                del g[k]
            g.create_dataset(k, data=v)
        g.attrs["events"] = json.dumps(events, default=str)
        g.attrs["reference_values"] = json.dumps(manager.reference, default=str)
        if manager.trajectories:
            tg = g.require_group("trajectories")
            for pid, rows in manager.trajectories.items():
                if rows:
                    tg.create_dataset(f"particle_{pid}", data=np.asarray(rows))
            tg.attrs["columns"] = "t_s, x_m, y_m, z_m, vx_m_s, vy_m_s, vz_m_s"

    def add_checkpoint(self, step: int, time_s: float, path: str) -> None:
        c = self.h5["checkpoints"]
        idx = json.loads(c.attrs["index"])
        idx.append({"step": step, "time_s": time_s, "path": str(path)})
        c.attrs["index"] = json.dumps(idx)

    def close(self) -> None:
        if self.h5:
            self.h5.close()
            self.h5 = None


def read_diagnostics(path: str | Path) -> dict[str, np.ndarray]:
    with h5py.File(path, "r") as h5:
        g = h5["diagnostics"]
        return {k: g[k][()] for k in g if isinstance(g[k], h5py.Dataset)}


def read_metadata(path: str | Path) -> dict:
    with h5py.File(path, "r") as h5:
        out = {}
        for k, v in h5["metadata"].attrs.items():
            if isinstance(v, str) and v[:1] in "[{n":
                try:
                    v = json.loads(v)
                except json.JSONDecodeError:
                    pass
            out[k] = v.item() if hasattr(v, "item") else v
        return out


def read_fields(path: str | Path) -> dict[str, np.ndarray]:
    with h5py.File(path, "r") as h5:
        return {k: h5["fields"][k][()] for k in h5["fields"]}


def inspect_file(path: str | Path) -> str:
    """Human-readable tree of an HDF5 file (datasets with shapes, top-level attributes)."""
    lines = [str(path)]
    with h5py.File(path, "r") as h5:
        def visit(name, obj):
            depth = name.count("/")
            if isinstance(obj, h5py.Dataset):
                lines.append("  " * (depth + 1) + f"{name.split('/')[-1]}  {obj.shape} {obj.dtype}")
            else:
                lines.append("  " * (depth + 1) + f"{name.split('/')[-1]}/")
        h5.visititems(visit)
        if "metadata" in h5:
            lines.append("metadata:")
            for k, v in h5["metadata"].attrs.items():
                lines.append(f"  {k}: {v}")
    return "\n".join(lines)
