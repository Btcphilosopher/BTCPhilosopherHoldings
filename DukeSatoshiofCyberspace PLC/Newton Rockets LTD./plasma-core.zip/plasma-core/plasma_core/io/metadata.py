"""Reproducibility metadata recorded in every output file."""

from __future__ import annotations

import datetime as _dt
import json
import os
import platform
import subprocess
import sys
import uuid
from pathlib import Path

import numpy as np

from ..constants import CONSTANTS_VERSION


def git_commit() -> dict:
    root = Path(__file__).resolve().parents[2]
    try:
        commit = subprocess.run(["git", "rev-parse", "HEAD"], cwd=root, capture_output=True, text=True,
                                timeout=5).stdout.strip()
        dirty = bool(subprocess.run(["git", "status", "--porcelain", "--", str(root)], cwd=root,
                                    capture_output=True, text=True, timeout=5).stdout.strip())
        return {"git_commit": commit or "unavailable", "git_dirty": dirty}
    except Exception:  # pragma: no cover - git missing
        return {"git_commit": "unavailable", "git_dirty": None}


def collect_metadata(config, backend_name: str, extra: dict | None = None) -> dict:
    from .. import __version__
    import scipy

    md = {
        "simulation_id": str(uuid.uuid4()),
        "timestamp_utc": _dt.datetime.now(_dt.timezone.utc).isoformat(),
        "software": "plasma_core",
        "software_version": __version__,
        **git_commit(),
        "python_version": sys.version.split()[0],
        "numpy_version": np.__version__,
        "scipy_version": scipy.__version__,
        "operating_system": f"{platform.system()} {platform.release()}",
        "machine": platform.machine(),
        "cpu": platform.processor() or platform.machine(),
        "cpu_count": os.cpu_count(),
        "backend": backend_name,
        "solver": config.solver.type,
        "dimension": config.domain.dimension,
        "grid_resolution": list(config.grid.cells),
        "domain_m": list(config.domain.length_m),
        "particle_count_per_species": config.particles.count,
        "species": [s.name for s in config.species],
        "timestep_s": config.time.dt_s,
        "duration_s": config.time.duration_s,
        "n_steps": config.n_steps,
        "boundary_conditions": config.boundaries.model_dump(),
        "collision_model": config.solver.collisions.model,
        "random_seed": config.random_seed,
        "physical_constants_version": CONSTANTS_VERSION,
        "unit_system": config.unit_system,
        "configuration_hash": config.config_hash(),
    }
    if extra:
        md.update(extra)
    return md


def metadata_json(md: dict) -> str:
    return json.dumps(md, sort_keys=True, default=str)
