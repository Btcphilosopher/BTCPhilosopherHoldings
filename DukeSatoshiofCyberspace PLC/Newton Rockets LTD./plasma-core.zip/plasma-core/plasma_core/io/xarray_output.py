"""xarray views of simulation data with named dimensions.

Dimensions: ``time``, ``x``, ``y``, ``component`` (x, y, z), ``species``, ``v``.
"""

from __future__ import annotations

import numpy as np


def state_to_dataset(state):
    import xarray as xr

    g = state.grid
    coords = {"x": g.centres(0), "component": ["x", "y", "z"], "species": state.species_names}
    dims = ["x"]
    if g.dimension == 2:
        coords["y"] = g.centres(1)
        dims = ["x", "y"]
    sh = g.shape
    data = {
        "electric_field_v_m": (dims + ["component"], state.electric_field_v_m.reshape(sh + (3,))),
        "magnetic_field_t": (dims + ["component"], state.magnetic_field_t.reshape(sh + (3,))),
        "current_density_a_m2": (dims + ["component"], state.current_density_a_m2.reshape(sh + (3,))),
        "charge_density_c_m3": (dims, state.charge_density_c_m3.reshape(sh)),
        "number_density_m3": (["species"] + dims, state.number_density_m3.reshape((-1,) + sh)),
    }
    if state.potential_v is not None:
        data["potential_v"] = (dims, state.potential_v.reshape(sh))
    ds = xr.Dataset(data, coords=coords)
    ds.attrs.update(time_s=state.time_s, step=state.step, solver=state.solver, unit_system=str(state.unit_system.value))
    return ds


def fields_dataset_from_hdf5(path):
    """Field snapshots of an HDF5 output file as an xarray Dataset (1D/2D)."""
    import h5py
    import json
    import xarray as xr

    from ..grid.spatial_grid import SpatialGrid

    with h5py.File(path, "r") as h5:
        ga = h5["grid"].attrs
        grid = SpatialGrid.from_dict({k: json.loads(ga[k]) for k in ("cells", "lower_m", "upper_m", "periodic")})
        f = {k: h5["fields"][k][()] for k in h5["fields"]}
        species = json.loads(h5["metadata"].attrs["species"])
    sh = grid.shape
    nt = f["time_s"].shape[0]
    dims = ["x"] if grid.dimension == 1 else ["x", "y"]
    coords = {"time": f["time_s"], "x": grid.centres(0), "component": ["x", "y", "z"], "species": species}
    if grid.dimension == 2:
        coords["y"] = grid.centres(1)
    data = {
        "electric_field_v_m": (["time"] + dims + ["component"], f["electric_field_v_m"].reshape((nt,) + sh + (3,))),
        "magnetic_field_t": (["time"] + dims + ["component"], f["magnetic_field_t"].reshape((nt,) + sh + (3,))),
        "charge_density_c_m3": (["time"] + dims, f["charge_density_c_m3"].reshape((nt,) + sh)),
        "number_density_m3": (["time", "species"] + dims, f["number_density_m3"].reshape((nt, -1) + sh)),
    }
    if "potential_v" in f:
        data["potential_v"] = (["time"] + dims, f["potential_v"].reshape((nt,) + sh))
    return xr.Dataset(data, coords=coords)


def diagnostics_dataset(manager):
    import xarray as xr

    tab = manager.table()
    t = tab.pop("time_s")
    return xr.Dataset({k: ("time", np.asarray(v)) for k, v in tab.items()}, coords={"time": t})
