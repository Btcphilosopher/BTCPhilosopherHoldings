"""Parquet output of tabular diagnostics (pandas / polars / R / Arrow compatible).

The file's schema metadata carries the reproducibility metadata (key
``plasma_core``) so that each table is traceable to its configuration.
"""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
import pyarrow as pa
import pyarrow.parquet as pq


def write_diagnostics_parquet(table: dict[str, np.ndarray], path: str | Path, metadata: dict | None = None) -> Path:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    arrays = {k: pa.array(np.asarray(v)) for k, v in table.items()}
    t = pa.table(arrays)
    md = {b"plasma_core": json.dumps(metadata or {}, default=str).encode()}
    t = t.replace_schema_metadata({**(t.schema.metadata or {}), **md})
    pq.write_table(t, path)
    return path


def read_diagnostics_parquet(path: str | Path) -> tuple[dict[str, np.ndarray], dict]:
    t = pq.read_table(path)
    md = json.loads(t.schema.metadata.get(b"plasma_core", b"{}"))
    return {name: t.column(name).to_numpy() for name in t.column_names}, md
