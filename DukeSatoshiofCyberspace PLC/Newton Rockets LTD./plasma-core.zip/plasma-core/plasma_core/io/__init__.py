"""Scientific output formats: HDF5 (trajectories, checkpoints), Parquet (tables), xarray views."""

from .hdf5 import HDF5OutputWriter, inspect_file, read_diagnostics, read_fields, read_metadata
from .metadata import collect_metadata
from .parquet import read_diagnostics_parquet, write_diagnostics_parquet
from .xarray_output import diagnostics_dataset, fields_dataset_from_hdf5, state_to_dataset

__all__ = [
    "HDF5OutputWriter", "inspect_file", "read_diagnostics", "read_fields", "read_metadata", "collect_metadata",
    "read_diagnostics_parquet", "write_diagnostics_parquet", "diagnostics_dataset", "fields_dataset_from_hdf5",
    "state_to_dataset",
]
