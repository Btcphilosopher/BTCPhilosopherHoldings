"""1D electromagnetic field model: E_x from Poisson + transverse Yee fields.

See :mod:`plasma_core.solvers.maxwell` for the supported geometry (1D,
periodic) and the time staggering.
"""

from __future__ import annotations

import numpy as np

from ..solvers.maxwell import Yee1DMaxwellSolver
from .electrostatic import ElectrostaticField
from .field_boundary import FieldBoundary


class ElectromagneticField1D:
    def __init__(self, grid, dt: float, poisson_method: str, boundary: FieldBoundary,
                 external_e_v_m=(0, 0, 0), external_b_t=(0, 0, 0)) -> None:
        self.grid = grid
        self.longitudinal = ElectrostaticField(grid, poisson_method, boundary)
        self.yee = Yee1DMaxwellSolver(grid, dt)
        self.external_e = np.asarray(external_e_v_m, dtype=float)
        self.external_b = np.asarray(external_b_t, dtype=float)
        self.Ex = np.zeros(grid.cells[0])

    def solve_longitudinal(self, rho: np.ndarray) -> None:
        self.Ex = self.longitudinal.solve(rho)[:, 0].copy()

    def e_centres(self) -> np.ndarray:
        """Total E at cell centres, shape (n, 3)."""
        E = np.stack([self.Ex, self.yee.Ey, self.yee.Ez], axis=1)
        return E + self.external_e

    def b_edges(self) -> np.ndarray:
        """Self-consistent B at cell edges (B_x = 0 self part), shape (n, 3), without external field."""
        return np.stack([np.zeros_like(self.yee.By), self.yee.By, self.yee.Bz], axis=1)

    def b_centres_total(self) -> np.ndarray:
        by, bz = self.yee.b_at_centres()
        return np.stack([np.zeros_like(by), by, bz], axis=1) + self.external_b
