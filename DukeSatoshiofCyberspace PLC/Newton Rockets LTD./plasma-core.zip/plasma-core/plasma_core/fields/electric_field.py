"""Electric-field utilities.

    W_E = integral (eps0/2) |E|^2 dV  ~=  sum_j (eps0/2) |E_j|^2 V_cell     [J]
    Gauss residual: max |div E - rho/eps0| / max |rho/eps0|  (second-order differences)
"""

from __future__ import annotations

import numpy as np

from ..constants import VACUUM_PERMITTIVITY


def electric_field_energy(E: np.ndarray, cell_volume_m3: float) -> float:
    """Electric field energy [J] (per unit transverse area in 1D)."""
    return 0.5 * VACUUM_PERMITTIVITY * float(np.sum(E * E)) * cell_volume_m3


def gauss_law_residual(E: np.ndarray, rho: np.ndarray, grid, periodic: bool = True) -> float:
    """Relative residual of div E = rho/eps0 using centred differences on interior/periodic cells.

    For the ``fft_fd`` / ``fd`` solvers E is a centred difference of phi, so this
    residual measures (Laplacian_centred-2dx - Laplacian_3pt) phi, which is
    O(k^2 dx^2) - it is a consistency check, not a solver error.
    """
    div = np.zeros(grid.shape)
    for a in range(grid.dimension):
        dx = float(grid.spacing_m[a])
        if periodic:
            div += (np.roll(E[..., a], -1, axis=a) - np.roll(E[..., a], 1, axis=a)) / (2 * dx)
        else:
            div += np.gradient(E[..., a], dx, axis=a)
    src = rho / VACUUM_PERMITTIVITY
    src = src - (src.mean() if periodic else 0.0)
    scale = float(np.max(np.abs(src)))
    r = float(np.max(np.abs(div - src)))
    return r / scale if scale > 0 else r
