"""Electrostatic field model: rho -> (phi, E) plus a uniform external field.

E_total = E_self(rho) + E_external.  E_self is obtained from
:class:`~plasma_core.solvers.poisson.PoissonSolver` with the configured
method and boundary.
"""

from __future__ import annotations

import numpy as np

from ..solvers.poisson import PoissonResult, PoissonSolver
from .field_boundary import FieldBoundary


class ElectrostaticField:
    def __init__(self, grid, method: str, boundary: FieldBoundary, external_e_v_m=(0, 0, 0)) -> None:
        self.grid = grid
        self.boundary = boundary
        self.solver = PoissonSolver(grid, method, boundary.name, boundary.potential_low_v, boundary.potential_high_v)
        self.external = np.asarray(external_e_v_m, dtype=float)
        self.last: PoissonResult | None = None

    def solve(self, rho: np.ndarray) -> np.ndarray:
        """Return total E (grid.shape + (3,)); stores the Poisson result in ``last``."""
        self.last = self.solver.solve(rho)
        E = self.last.electric_field_v_m
        if np.any(self.external != 0):
            E = E + self.external
        return E
