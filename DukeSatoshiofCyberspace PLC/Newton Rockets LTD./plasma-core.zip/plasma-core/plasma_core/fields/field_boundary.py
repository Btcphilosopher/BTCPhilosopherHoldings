"""Field boundary conditions and solver compatibility.

Boundary logic is kept out of the numerical kernels: kernels receive a
boundary *name*; this module defines what each name means and which solvers
support it.

=============  =====================================================  ==========================
name           meaning                                                 solvers
=============  =====================================================  ==========================
periodic       all fields periodic                                     ES-PIC (fft/fd), EM-PIC,
                                                                       fluid, Vlasov
dirichlet      phi prescribed on the domain faces (conducting walls)   ES-PIC (fd)
neumann        dphi/dn = 0 (E_normal = 0) on the faces (symmetry)      ES-PIC (fd, 1D), fluid
=============  =====================================================  ==========================

The 1D electromagnetic solver supports periodic boundaries only.  The Vlasov
solver uses spectral x-advection and therefore requires periodicity.
"""

from __future__ import annotations

from dataclasses import dataclass

from ..exceptions import BoundaryConditionError


@dataclass(frozen=True)
class FieldBoundary:
    name: str
    potential_low_v: float = 0.0
    potential_high_v: float = 0.0


class PeriodicFieldBoundary(FieldBoundary):
    def __init__(self) -> None:
        super().__init__("periodic")


class DirichletFieldBoundary(FieldBoundary):
    def __init__(self, potential_low_v: float = 0.0, potential_high_v: float = 0.0) -> None:
        super().__init__("dirichlet", potential_low_v, potential_high_v)


class NeumannFieldBoundary(FieldBoundary):
    def __init__(self) -> None:
        super().__init__("neumann")


COMPATIBILITY: dict[str, set[str]] = {
    "electrostatic_pic": {"periodic", "dirichlet", "neumann"},
    "test_particle": {"periodic", "dirichlet", "neumann"},
    "electromagnetic_pic": {"periodic"},
    "fluid": {"periodic", "neumann"},
    "vlasov": {"periodic"},
}


def check_compatibility(solver_type: str, boundary: FieldBoundary | str) -> None:
    name = boundary if isinstance(boundary, str) else boundary.name
    if name not in COMPATIBILITY.get(solver_type, set()):
        raise BoundaryConditionError(
            f"field boundary '{name}' is not supported by solver '{solver_type}'",
            why=f"supported: {sorted(COMPATIBILITY.get(solver_type, set()))}",
            parameter="boundaries.fields",
            investigate="see docs/NUMERICS.md (boundary compatibility table)")


def build_field_boundary(config) -> FieldBoundary:
    b = config.boundaries
    if b.fields == "periodic":
        return PeriodicFieldBoundary()
    if b.fields == "dirichlet":
        return DirichletFieldBoundary(b.potential_low_v, b.potential_high_v)
    return NeumannFieldBoundary()
