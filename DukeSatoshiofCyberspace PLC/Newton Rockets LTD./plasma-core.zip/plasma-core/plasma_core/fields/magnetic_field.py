"""Magnetic-field utilities.

    W_B = integral |B|^2 / (2 mu0) dV  ~=  sum_j |B_j|^2 / (2 mu0) V_cell    [J]
"""

from __future__ import annotations

import numpy as np

from ..constants import VACUUM_PERMEABILITY


def magnetic_field_energy(B: np.ndarray, cell_volume_m3: float) -> float:
    return float(np.sum(B * B)) * cell_volume_m3 / (2.0 * VACUUM_PERMEABILITY)


def uniform_field(grid, vector) -> np.ndarray:
    """Uniform vector field on cell centres, shape grid.shape + (3,)."""
    return np.broadcast_to(np.asarray(vector, dtype=float), grid.shape + (3,)).copy()


def divergence_2d(B: np.ndarray, grid) -> np.ndarray:
    """Centred-difference div B on a periodic 2D grid (diagnostic)."""
    dx, dy = grid.spacing_m
    return ((np.roll(B[..., 0], -1, 0) - np.roll(B[..., 0], 1, 0)) / (2 * dx)
            + (np.roll(B[..., 1], -1, 1) - np.roll(B[..., 1], 1, 1)) / (2 * dy))
