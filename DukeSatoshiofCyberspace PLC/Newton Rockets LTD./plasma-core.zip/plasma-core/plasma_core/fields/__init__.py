"""Field models, energies and field boundaries."""

from .electric_field import electric_field_energy, gauss_law_residual
from .electromagnetic import ElectromagneticField1D
from .electrostatic import ElectrostaticField
from .field_boundary import (
    COMPATIBILITY,
    DirichletFieldBoundary,
    FieldBoundary,
    NeumannFieldBoundary,
    PeriodicFieldBoundary,
    build_field_boundary,
    check_compatibility,
)
from .magnetic_field import magnetic_field_energy, uniform_field

__all__ = [
    "electric_field_energy", "gauss_law_residual", "ElectromagneticField1D", "ElectrostaticField",
    "FieldBoundary", "PeriodicFieldBoundary", "DirichletFieldBoundary", "NeumannFieldBoundary",
    "COMPATIBILITY", "build_field_boundary", "check_compatibility", "magnetic_field_energy", "uniform_field",
]
