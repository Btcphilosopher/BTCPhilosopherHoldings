"""Common interface of all simulation models (PIC, fluid, Vlasov).

A model owns its numerical state and implements:

* ``initialize(seeds)``   build the initial state from the configuration
* ``step()``              advance one time step dt (t^n -> t^{n+1})
* ``observe()``           return a :class:`PlasmaState` at the current time t^n
                          without modifying the numerical state
* ``state_arrays()`` / ``load_state_arrays()``  complete restartable state
* ``timestep_assessments(scales)``  model-specific stability criteria
"""

from __future__ import annotations

from abc import ABC, abstractmethod

import numpy as np

from ..solvers.timestep import StabilityAssessment
from ..state import PlasmaState


class SimulationModel(ABC):
    solver_name = "abstract"

    def __init__(self, config, grid, backend, collisions, runtime_rng: np.random.Generator) -> None:
        self.config = config
        self.grid = grid
        self.backend = backend
        self.collisions = collisions
        self.rng = runtime_rng
        self.species = config.species
        self.n_species = len(config.species)
        self.dt = config.time.dt_s
        self.step_index = 0

    @property
    def time_s(self) -> float:
        # time is derived from the integer step counter so that it is exactly reproducible
        return self.step_index * self.dt

    @abstractmethod
    def initialize(self, seeds: list[np.random.SeedSequence]) -> None: ...

    @abstractmethod
    def step(self) -> None: ...

    @abstractmethod
    def observe(self) -> PlasmaState: ...

    @abstractmethod
    def state_arrays(self) -> dict[str, np.ndarray]: ...

    @abstractmethod
    def load_state_arrays(self, arrays: dict[str, np.ndarray], scalars: dict) -> None: ...

    def scalars(self) -> dict:
        return {"step_index": self.step_index}

    def stability_arrays(self) -> dict[str, np.ndarray]:
        return self.state_arrays()

    def max_speed_array(self) -> np.ndarray | None:
        return None

    def timestep_assessments(self, scales) -> list[StabilityAssessment]:
        return []

    def configuration_warnings(self, scales) -> list[str]:
        return []
