"""High-level simulation driver.

    sim = PlasmaSimulation(config)
    sim.initialize()        # pre-run physical/numerical assessment + initial state
    sim.run()               # advance to time.duration_s
    state = sim.state       # PlasmaState at the current time
    diag = sim.diagnostics  # DiagnosticsManager (time series)

Execution order of step k (t^k -> t^{k+1})::

    [diagnostics at t^k if due]  ->  [output snapshot if due]  ->  [checkpoint if due]
    -> model.step()  ->  [stability check every check_interval steps]

A final diagnostic sample (all enabled groups) is taken when the run reaches
``config.n_steps``; stopping earlier (``run(until_step=...)``) adds no extra row.
"""

from __future__ import annotations

import math
from pathlib import Path

import numpy as np

from ..backends import get_backend
from ..configuration import SimulationConfig
from ..diagnostics.conservation import StabilityMonitor
from ..diagnostics.manager import DiagnosticsManager
from ..grid.spatial_grid import SpatialGrid
from ..io.metadata import collect_metadata
from ..particles.particle_initializer import make_generator, species_seed_sequences
from ..physics.collisions import build_collision_model
from ..physics.scales import compute_scales
from ..state import PlasmaState
from .timestep_controller import TimestepController


def build_grid(config: SimulationConfig) -> SpatialGrid:
    periodic = config.boundaries.particles == "periodic"
    return SpatialGrid.uniform(config.grid.cells, config.domain.length_m, lower_m=config.domain.origin_m,
                               periodic=periodic)


def build_model(config, grid, backend, collisions, rng):
    t = config.solver.type
    if t == "electrostatic_pic":
        from ..pic.pic_solver import ElectrostaticPICModel as M
    elif t == "electromagnetic_pic":
        from ..pic.pic_solver import ElectromagneticPIC1DModel as M
    elif t == "test_particle":
        from ..pic.pic_solver import TestParticleModel as M
    elif t == "fluid":
        from ..solvers.fluid import FluidModel1D as M
    elif t == "vlasov":
        from ..solvers.vlasov import VlasovModel1D1V as M
    else:  # pragma: no cover - rejected by configuration validation
        raise ValueError(t)
    return M(config, grid, backend, collisions, rng)


_SOLVER_LABEL = {
    "electrostatic_pic": "Electrostatic PIC",
    "electromagnetic_pic": "Electromagnetic PIC (1D Yee foundation)",
    "test_particle": "Test particles in prescribed fields",
    "fluid": "Multi-species fluid (Euler-Poisson)",
    "vlasov": "Vlasov-Poisson (semi-Lagrangian)",
}


class PlasmaSimulation:
    def __init__(self, config: SimulationConfig | dict | str | Path, *, verbose: bool = False) -> None:
        if isinstance(config, (str, Path)):
            config = SimulationConfig.from_file(config)
        elif isinstance(config, dict):
            config = SimulationConfig.from_dict(config)
        self.config = config
        self.verbose = verbose
        self.grid = build_grid(config)
        self.backend = get_backend(config.solver.backend)
        self.collisions = build_collision_model(config.solver.collisions)
        self.seeds = species_seed_sequences(config.random_seed, len(config.species))
        self.runtime_rng = make_generator(self.seeds[-1])
        self.model = build_model(config, self.grid, self.backend, self.collisions, self.runtime_rng)
        B0 = float(np.linalg.norm(config.solver.external_magnetic_field_t))
        self.scales = compute_scales(config.species, B0, float(np.min(self.grid.spacing_m)))
        self.timestep_controller = TimestepController(config, self.model, self.scales)
        self.diagnostics = DiagnosticsManager(config, config.species, self.grid)
        reasons = []
        if any(config.solver.external_electric_field_v_m):
            reasons.append("external electric field does work on the particles")
        if not self.collisions.is_collisionless:
            reasons.append(f"collision operator '{self.collisions.name}' exchanges energy with a reservoir")
        if config.solver.type == "fluid" and config.solver.fluid.closure == "isothermal":
            reasons.append("isothermal closure couples to a heat bath")
        self.monitor = StabilityMonitor(config.diagnostics.stability, not reasons, "; ".join(reasons))
        self.metadata = collect_metadata(config, self.backend.name,
                                         {"collision_model_details": self.collisions.describe()})
        self.warnings: list[str] = []
        self.initialized = False
        self._writer = None
        self._state_cache: tuple[int, PlasmaState] | None = None
        self.checkpoints: list[str] = []

    # ------------------------------------------------------------------
    @property
    def step_index(self) -> int:
        return self.model.step_index

    @property
    def time_s(self) -> float:
        return self.model.time_s

    def assess(self) -> list[str]:
        """Pre-run physical and numerical assessment; raises on violated required criteria."""
        msgs = self.timestep_controller.enforce()
        msgs += self.model.configuration_warnings(self.scales)
        self.warnings = msgs
        return msgs

    def initialize(self) -> "PlasmaSimulation":
        self.assess()
        self.model.initialize(self.seeds)
        self.initialized = True
        self._state_cache = None
        if self.verbose:
            print(self.summary())
        return self

    @property
    def state(self) -> PlasmaState:
        if not self.initialized:
            raise RuntimeError("call initialize() first")
        if self._state_cache is None or self._state_cache[0] != self.step_index:
            self._state_cache = (self.step_index, self.model.observe())
        return self._state_cache[1]

    # ------------------------------------------------------------------
    def _output_dir(self) -> Path:
        return Path(self.config.output.directory)

    def _open_writer(self):
        from ..io.hdf5 import HDF5OutputWriter

        path = self._output_dir() / f"{self.config.name}.h5"
        self._writer = HDF5OutputWriter(path, self.config, self.grid, {**self.metadata, "warnings": self.warnings})
        return self._writer

    def run(self, n_steps: int | None = None, *, until_step: int | None = None, write_output: bool = False):
        """Advance the simulation.  Default target: ``config.n_steps``."""
        if not self.initialized:
            self.initialize()
        target = until_step if until_step is not None else (
            self.step_index + n_steps if n_steps is not None else self.config.n_steps)
        out_int = self.config.output.output_interval
        ck_int = self.config.output.checkpoint_interval
        chk = self.config.diagnostics.stability.check_interval
        if write_output and self._writer is None and self.config.output.hdf5:
            self._open_writer()
        start = self.step_index
        while self.step_index < target:
            k = self.step_index
            self._sample(k)
            if write_output and self._writer is not None and out_int and k % out_int == 0:
                self._writer.write_snapshot(self.state)
            if ck_int and k % ck_int == 0 and k > start:
                self.checkpoint(self._output_dir() / f"{self.config.name}_checkpoint_{k:08d}.h5")
            self.model.step()
            if self.step_index % chk == 0:
                self._check_stability()
        self._check_stability()
        # The forced final sample is taken only at the end of the configured simulation, so that a run
        # interrupted for checkpointing has exactly the same diagnostic history as a continuous run.
        self._sample(self.step_index, final=self.step_index >= self.config.n_steps)
        if write_output:
            if self._writer is not None and out_int and self.step_index % out_int == 0:
                self._writer.write_snapshot(self.state)
            self.write_outputs()
        return self.diagnostics

    def _sample(self, k: int, final: bool = False) -> None:
        if self.diagnostics.last_step == k:
            return
        if final or self.diagnostics.is_due(k):
            row = self.diagnostics.record(self.state, force=final)
            if row is not None:
                self.monitor.check_row(row)

    def _check_stability(self) -> None:
        self.monitor.check_arrays(self.step_index, self.model.stability_arrays())
        v = self.model.max_speed_array()
        if v is not None:
            self.monitor.check_speed(self.step_index, v)

    # ------------------------------------------------------------------
    def write_outputs(self) -> dict[str, str]:
        paths = {}
        if self.config.output.hdf5:
            if self._writer is None:
                self._open_writer()
            self._writer.write_diagnostics(self.diagnostics, self.monitor.events)
            paths["hdf5"] = str(self._writer.path)
            self._writer.close()
            self._writer = None
        if self.config.output.parquet:
            from ..io.parquet import write_diagnostics_parquet

            p = write_diagnostics_parquet(self.diagnostics.table(), self._output_dir() / f"{self.config.name}_diagnostics.parquet",
                                          {**self.metadata, "events": self.monitor.events})
            paths["parquet"] = str(p)
        return paths

    def checkpoint(self, path: str | Path) -> Path:
        from .checkpoint import write_checkpoint

        p = write_checkpoint(self, path)
        self.checkpoints.append(str(p))
        if self._writer is not None:
            self._writer.add_checkpoint(self.step_index, self.time_s, str(p))
        return p

    @classmethod
    def restart(cls, path: str | Path, *, verbose: bool = False) -> "PlasmaSimulation":
        from .restart import restart_from_checkpoint

        return restart_from_checkpoint(path, verbose=verbose)

    # ------------------------------------------------------------------
    def summary(self) -> str:
        c = self.config
        sc = self.scales
        dim = f"{c.domain.dimension}D{1 if c.solver.type == 'vlasov' else 3}V"
        mobile = [s for s in c.species if s.mobile]
        lines = ["PLASMA CORE", "-----------", "",
                 f"Solver:               {_SOLVER_LABEL[c.solver.type]}",
                 f"Dimension:            {dim}",
                 "Species:              " + ", ".join(f"{s.name}{'' if s.mobile else ' (immobile background)'}"
                                                       for s in c.species),
                 f"Grid:                 {' x '.join(str(n) for n in c.grid.cells)} cells, "
                 f"dx = {', '.join(f'{d:.4e}' for d in self.grid.spacing_m)} m",
                 f"Domain:               {', '.join(f'{L:.4e}' for L in c.domain.length_m)} m"]
        if c.solver.type in ("electrostatic_pic", "electromagnetic_pic", "test_particle"):
            n = len(c.initial_condition.positions_m or []) if c.initial_condition.type == "single_particle" \
                else c.particles.count * len(mobile)
            lines.append(f"Particles:            {n:,}")
            lines.append(f"Deposition/interp.:   {c.solver.deposition}/{c.solver.interpolation}")
        if c.solver.type in ("electrostatic_pic", "electromagnetic_pic", "fluid", "vlasov"):
            lines.append(f"Poisson:              {c.solver.poisson}")
        lines += [
            f"Debye length:         {sc.debye_length_m:.4e} m" + ("" if not math.isfinite(sc.debye_length_m) else
                                                                    f"  (dx/lambda_D = {np.min(self.grid.spacing_m) / sc.debye_length_m:.3f})"),
            f"Plasma frequency:     {sc.plasma_frequency_rad_s:.4e} rad/s (period {sc.plasma_period_s:.4e} s)",
        ]
        if sc.max_cyclotron_frequency_rad_s > 0:
            lines.append(f"Cyclotron frequency:  {sc.max_cyclotron_frequency_rad_s:.4e} rad/s (max over species)")
        rec = self.timestep_controller.recommended_dt()
        lines += [f"Timestep:             {c.time.dt_s:.4e} s ({c.n_steps} steps, {c.n_steps * c.time.dt_s:.4e} s)",
                  f"Recommended timestep: {rec:.4e} s" if math.isfinite(rec) else "Recommended timestep: n/a",
                  f"Boundary:             particles={c.boundaries.particles}, fields={c.boundaries.fields}",
                  f"Collisions:           {self.collisions.name}",
                  f"Backend:              {self.backend.name}",
                  f"Random seed:          {c.random_seed}",
                  f"Configuration hash:   {c.config_hash()[:16]}"]
        for a in self.timestep_controller.assessments:
            flag = "OK" if a.required_satisfied and a.recommended_satisfied else (
                "ACCURACY WARNING" if a.required_satisfied else "VIOLATION")
            lines.append(f"  check {a.criterion:<20s} = {a.value:.4g}  [{flag}]")
        for w in self.warnings:
            lines.append(f"  WARNING: {w}")
        return "\n".join(lines)
