"""Time-step control.

:class:`TimestepController` (fixed step - used by all solvers)
    Evaluates the active model's stability criteria (see
    :mod:`plasma_core.solvers.timestep`) for the configured dt, derives a
    recommended dt (the most restrictive *recommended* limit), and enforces
    the policy: a violated *required* criterion raises
    :class:`StabilityCriterionViolation` (``time.stability_policy: error``,
    the default) or produces an explicit warning (``warn``).

:class:`AdaptiveTimestepController` (interface)
    Future controllers may respond to field changes, particle velocities, CFL
    limits, gyrofrequency or solver-specific criteria.  The leapfrog PIC loop
    requires a re-centring of v^{n-1/2} whenever dt changes; this is not
    implemented, so adaptive control is *not* applied by any solver.
    :class:`CriteriaProposalController` only *proposes* a dt from the current
    state (deterministically, for monitoring); applying it would change the
    time discretisation and must be documented per run.
"""

from __future__ import annotations

import math
import warnings
from abc import ABC, abstractmethod

import numpy as np

from ..exceptions import StabilityCriterionViolation
from ..solvers.timestep import StabilityAssessment


class TimestepController:
    def __init__(self, config, model, scales) -> None:
        self.config = config
        self.model = model
        self.scales = scales
        self.dt = config.time.dt_s
        self.assessments: list[StabilityAssessment] = model.timestep_assessments(scales)

    def recommended_dt(self) -> float:
        cands = [a.recommended_dt() for a in self.assessments]
        cands = [c for c in cands if math.isfinite(c)]
        return min(cands) if cands else math.inf

    def violations(self) -> list[StabilityAssessment]:
        return [a for a in self.assessments if not a.required_satisfied]

    def accuracy_warnings(self) -> list[str]:
        return [f"{a.criterion}: {a.value:.3g} exceeds the recommended {a.recommended_limit:.3g} ({a.explanation})"
                for a in self.assessments if a.required_satisfied and not a.recommended_satisfied]

    def enforce(self) -> list[str]:
        """Apply the stability policy; return warning strings."""
        msgs = []
        for a in self.violations():
            text = (f"{a.criterion}: {a.value:.4g} violates the required limit {a.required_limit:.4g}. "
                    f"{a.explanation}. Recommended dt <= {a.recommended_dt():.4e} s")
            if self.config.time.stability_policy == "error":
                raise StabilityCriterionViolation(
                    f"time step {self.dt:.4e} s violates a required stability criterion",
                    why=text, parameter="time.dt_s",
                    investigate="reduce time.dt_s, or set time.stability_policy: warn to run an unstable "
                                "configuration deliberately (it will be flagged in all outputs)")
            msgs.append("UNSTABLE CONFIGURATION (policy=warn): " + text)
            warnings.warn(msgs[-1], RuntimeWarning, stacklevel=2)
        msgs.extend(self.accuracy_warnings())
        return msgs


class AdaptiveTimestepController(ABC):
    """Interface for future adaptive controllers (not applied by current solvers)."""

    applies_dt: bool = False

    @abstractmethod
    def propose(self, state, current_dt: float) -> float:
        """Return the dt this controller would use for the next step."""


class CriteriaProposalController(AdaptiveTimestepController):
    """Proposes dt = safety * min(recommended limits) evaluated on the *current* state.

    Deterministic (depends only on the state), never applied automatically.
    """

    def __init__(self, safety: float = 1.0, omega_p: float = 0.0, omega_c: float = 0.0) -> None:
        self.safety = safety
        self.omega_p = omega_p
        self.omega_c = omega_c

    def propose(self, state, current_dt: float) -> float:
        dts = []
        if self.omega_p > 0:
            dts.append(0.2 / self.omega_p)
        if self.omega_c > 0:
            dts.append(0.2 / self.omega_c)
        if state.particle_velocities_m_s is not None and state.particle_velocities_m_s.size:
            vmax = float(np.max(np.abs(state.particle_velocities_m_s)))
            if vmax > 0:
                dts.append(0.5 * float(np.min(state.grid.spacing_m)) / vmax)
        return self.safety * min(dts) if dts else current_dt
