"""Restart a simulation from a checkpoint.

The configuration is reconstructed from the stored JSON and its hash is
verified.  The model state, runtime random-generator state, diagnostic
history and stability events are restored, so that continuing the restarted
run reproduces the continuous run (bitwise on the same platform, software
version and backend - verified by ``tests/test_checkpoint_restart.py``).
"""

from __future__ import annotations

import json
import warnings
from pathlib import Path

from ..configuration import SimulationConfig
from ..exceptions import CheckpointError
from .checkpoint import read_checkpoint


def restart_from_checkpoint(path: str | Path, *, verbose: bool = False, config_overrides: dict | None = None):
    from .. import __version__
    from .simulation import PlasmaSimulation

    ck = read_checkpoint(path)
    config = SimulationConfig.from_dict(json.loads(ck["config_json"]))
    if config.config_hash() != ck["config_hash"]:
        raise CheckpointError("configuration hash mismatch on restart",
                              why="the stored configuration does not reproduce its recorded hash",
                              parameter="configuration", investigate="the checkpoint may be corrupted or edited")
    if config_overrides:
        config = config.with_updates(**config_overrides)
    stored_version = ck["metadata"].get("software_version")
    if stored_version != __version__:
        warnings.warn(f"checkpoint written by plasma_core {stored_version}, restarting with {__version__}; "
                      "bitwise reproducibility is not guaranteed", RuntimeWarning, stacklevel=2)
    sim = PlasmaSimulation(config, verbose=False)
    sim.assess()
    sim.model.load_state_arrays(ck["arrays"], ck["scalars"])
    sim.runtime_rng.bit_generator.state = ck["rng_state"]
    sim.diagnostics.load_dict(ck["diagnostics"])
    sim.diagnostics.distributions = ck["distributions"]
    sim.monitor.events = list(ck["events"])
    sim.metadata["restarted_from"] = str(path)
    sim.metadata["restart_step"] = sim.model.step_index
    sim.initialized = True
    if verbose:
        print(sim.summary())
        print(f"Restarted from {path} at step {sim.model.step_index} (t = {sim.time_s:.6e} s)")
    return sim
