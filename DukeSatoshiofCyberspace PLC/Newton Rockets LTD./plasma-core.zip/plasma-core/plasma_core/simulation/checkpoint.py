"""HDF5 checkpoints: everything required to continue a run bit-for-bit.

Contents: metadata (software version, git commit, ...), configuration JSON
and hash, grid, species, model state arrays (``/particles/*``, ``/fields/*``,
``/fluid/*``, ``/vlasov/*``), model scalars (step index, time centring, loss
ledger), the runtime random-generator state, the diagnostic history and the
stability-monitor events.
"""

from __future__ import annotations

import json
from pathlib import Path

import h5py
import numpy as np

from ..exceptions import CheckpointError
from ..io.hdf5 import _set_attrs, write_grid

FORMAT_VERSION = 1


class _Encoder(json.JSONEncoder):
    def default(self, o):
        if isinstance(o, np.ndarray):
            return {"__ndarray__": o.tolist(), "dtype": str(o.dtype)}
        if isinstance(o, (np.integer,)):
            return int(o)
        if isinstance(o, (np.floating,)):
            return float(o)
        if isinstance(o, (np.bool_,)):
            return bool(o)
        return super().default(o)


def _decode(d):
    if "__ndarray__" in d:
        return np.asarray(d["__ndarray__"], dtype=d["dtype"])
    return d


def dumps(obj) -> str:
    return json.dumps(obj, cls=_Encoder)


def loads(s: str):
    return json.loads(s, object_hook=_decode)


def write_checkpoint(sim, path: str | Path) -> Path:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    try:
        with h5py.File(path, "w") as h5:
            h5.attrs["format"] = "plasma_core_checkpoint"
            h5.attrs["format_version"] = FORMAT_VERSION
            _set_attrs(h5.create_group("metadata"), sim.metadata)
            c = h5.create_group("configuration")
            c.attrs["json"] = sim.config.canonical_json()
            c.attrs["hash"] = sim.config.config_hash()
            write_grid(h5, sim.grid)
            h5.create_group("species").attrs["json"] = json.dumps([s.model_dump(mode="json") for s in sim.config.species])
            st = h5.create_group("state")
            st.attrs["simulation_time_s"] = sim.time_s
            st.attrs["scalars"] = dumps(sim.model.scalars())
            for key, arr in sim.model.state_arrays().items():
                h5.create_dataset(f"state/{key}", data=arr)
            r = h5.create_group("rng")
            r.attrs["random_seed"] = sim.config.random_seed
            r.attrs["runtime_bit_generator_state"] = dumps(sim.runtime_rng.bit_generator.state)
            d = h5.create_group("diagnostics")
            d.attrs["manager"] = dumps(sim.diagnostics.to_dict())
            d.attrs["distributions"] = dumps(sim.diagnostics.distributions)
            d.attrs["events"] = dumps(sim.monitor.events)
            d.attrs["warnings"] = dumps(sim.warnings)
    except OSError as exc:
        raise CheckpointError(f"could not write checkpoint {path}", why=str(exc), parameter="output.directory",
                              investigate="check disk space and permissions") from exc
    return path


def read_checkpoint(path: str | Path) -> dict:
    path = Path(path)
    if not path.exists():
        raise CheckpointError(f"checkpoint {path} not found", parameter="path")
    with h5py.File(path, "r") as h5:
        if h5.attrs.get("format") != "plasma_core_checkpoint":
            raise CheckpointError(f"{path} is not a plasma_core checkpoint", why="missing format attribute",
                                  investigate="use 'plasma-core inspect' to look at the file")
        arrays = {}

        def visit(name, obj):
            if isinstance(obj, h5py.Dataset):
                arrays[name] = obj[()]
        h5["state"].visititems(visit)
        meta = {k: v for k, v in h5["metadata"].attrs.items()}
        return {
            "config_json": h5["configuration"].attrs["json"],
            "config_hash": h5["configuration"].attrs["hash"],
            "metadata": meta,
            "scalars": loads(h5["state"].attrs["scalars"]),
            "time_s": float(h5["state"].attrs["simulation_time_s"]),
            "arrays": arrays,
            "rng_state": loads(h5["rng"].attrs["runtime_bit_generator_state"]),
            "diagnostics": loads(h5["diagnostics"].attrs["manager"]),
            "distributions": loads(h5["diagnostics"].attrs["distributions"]),
            "events": loads(h5["diagnostics"].attrs["events"]),
            "warnings": loads(h5["diagnostics"].attrs["warnings"]),
        }
