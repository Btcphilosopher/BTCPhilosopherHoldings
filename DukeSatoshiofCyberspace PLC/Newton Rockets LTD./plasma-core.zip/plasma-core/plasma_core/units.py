"""Unit conversion utilities and optional dimensionless normalisation.

The numerical core works exclusively in SI units.  Non-SI quantities (eV,
keV, cm^-3, gauss, ...) may only enter through the explicit conversion
functions in this module, at the API boundary.

Dimensionless normalisation
---------------------------
:class:`Normalisation` defines characteristic scales (length, time, velocity,
density, electric field, magnetic field).  Converting a quantity requires
naming its *kind* explicitly; there is no implicit conversion.  Every
:class:`~plasma_core.state.PlasmaState` carries a ``unit_system`` tag
("SI" or "normalised") so that normalised and SI data cannot be silently mixed.
"""

from __future__ import annotations

import math
from enum import Enum
from typing import Literal

import numpy as np
from pydantic import BaseModel, ConfigDict, Field, model_validator

from .constants import (
    BOLTZMANN_CONSTANT,
    ELECTRON_MASS,
    ELEMENTARY_CHARGE,
    VACUUM_PERMITTIVITY,
)

# --------------------------------------------------------------------------
# Energy / temperature
# --------------------------------------------------------------------------

#: Joules per electron-volt (exact: 1 eV = e * 1 V).
JOULES_PER_EV = ELEMENTARY_CHARGE
#: Kelvin per electron-volt (exact in the 2019 SI): e / k_B.
KELVIN_PER_EV = ELEMENTARY_CHARGE / BOLTZMANN_CONSTANT


def _scale(value, factor: float):
    """Multiply a scalar or array by ``factor``; scalars stay Python floats."""
    if np.ndim(value) == 0:
        return float(value) * factor
    return np.asarray(value, dtype=float) * factor


def ev_to_joule(energy_ev):
    """Convert energy in eV to J."""
    return _scale(energy_ev, JOULES_PER_EV)


def joule_to_ev(energy_j):
    """Convert energy in J to eV."""
    return _scale(energy_j, 1.0 / JOULES_PER_EV)


def kev_to_joule(energy_kev):
    """Convert energy in keV to J."""
    return _scale(energy_kev, 1.0e3 * JOULES_PER_EV)


def mev_to_joule(energy_mev):
    """Convert energy in MeV to J."""
    return _scale(energy_mev, 1.0e6 * JOULES_PER_EV)


def ev_to_kelvin(temperature_ev):
    """Convert a temperature expressed as k_B T in eV to kelvin."""
    return _scale(temperature_ev, KELVIN_PER_EV)


def kelvin_to_ev(temperature_k):
    """Convert a temperature in kelvin to k_B T in eV."""
    return _scale(temperature_k, 1.0 / KELVIN_PER_EV)


# --------------------------------------------------------------------------
# Density, magnetic field, length
# --------------------------------------------------------------------------


def per_cm3_to_per_m3(density_cm3):
    """Convert number density from cm^-3 to m^-3 (factor 1e6)."""
    return _scale(density_cm3, 1.0e6)


def per_m3_to_per_cm3(density_m3):
    """Convert number density from m^-3 to cm^-3 (factor 1e-6)."""
    return _scale(density_m3, 1.0e-6)


def gauss_to_tesla(field_g):
    """Convert magnetic flux density from gauss to tesla (1 G = 1e-4 T)."""
    return _scale(field_g, 1.0e-4)


def tesla_to_gauss(field_t):
    """Convert magnetic flux density from tesla to gauss."""
    return _scale(field_t, 1.0e4)


def cm_to_m(length_cm):
    """Convert centimetres to metres."""
    return _scale(length_cm, 1.0e-2)


# --------------------------------------------------------------------------
# Unit systems and normalisation
# --------------------------------------------------------------------------


class UnitSystem(str, Enum):
    """Unit system tag carried by every simulation state."""

    SI = "SI"
    NORMALISED = "normalised"


QuantityKind = Literal[
    "length", "time", "velocity", "density", "electric_field", "magnetic_field",
    "frequency", "energy", "charge_density", "potential",
]


class Normalisation(BaseModel):
    """Characteristic scales used to non-dimensionalise SI quantities.

    All scales are in SI units.  A normalised quantity ``q_hat`` relates to the
    SI value ``q`` via ``q = q_hat * scale(kind)``.

    Derived scales
    --------------
    * frequency  = 1 / time_s                    [s^-1]
    * energy     = mass_kg * velocity_m_s**2     [J]   (requires mass_kg)
    * potential  = electric_field_v_m * length_m [V]
    * charge_density = epsilon_0 * electric_field / length   [C m^-3]
    """

    model_config = ConfigDict(frozen=True)

    length_m: float = Field(gt=0)
    time_s: float = Field(gt=0)
    velocity_m_s: float = Field(gt=0)
    density_m3: float = Field(gt=0)
    electric_field_v_m: float = Field(gt=0)
    magnetic_field_t: float = Field(gt=0)
    mass_kg: float = Field(default=ELECTRON_MASS, gt=0)
    description: str = "user-defined normalisation"

    @model_validator(mode="after")
    def _check_consistency(self) -> "Normalisation":
        # length / time must equal velocity to within rounding, otherwise the
        # normalised equations would acquire hidden coefficients.
        ratio = self.length_m / (self.time_s * self.velocity_m_s)
        if not math.isclose(ratio, 1.0, rel_tol=1e-9):
            raise ValueError(
                "Normalisation inconsistent: length_m / time_s must equal velocity_m_s "
                f"(got ratio {ratio:.6g}). Choose velocity_m_s = length_m / time_s."
            )
        return self

    def scale(self, kind: QuantityKind) -> float:
        """Return the SI scale of a quantity kind."""
        table = {
            "length": self.length_m,
            "time": self.time_s,
            "velocity": self.velocity_m_s,
            "density": self.density_m3,
            "electric_field": self.electric_field_v_m,
            "magnetic_field": self.magnetic_field_t,
            "frequency": 1.0 / self.time_s,
            "energy": self.mass_kg * self.velocity_m_s**2,
            "potential": self.electric_field_v_m * self.length_m,
            "charge_density": VACUUM_PERMITTIVITY * self.electric_field_v_m / self.length_m,
        }
        if kind not in table:
            raise KeyError(f"unknown quantity kind '{kind}'")
        return table[kind]

    def to_normalised(self, value_si, kind: QuantityKind):
        """Convert an SI value to normalised units."""
        return np.asarray(value_si, dtype=float) / self.scale(kind)

    def to_si(self, value_normalised, kind: QuantityKind):
        """Convert a normalised value back to SI units."""
        return np.asarray(value_normalised, dtype=float) * self.scale(kind)

    @classmethod
    def electron_plasma(cls, density_m3: float, temperature_k: float) -> "Normalisation":
        """Standard electron-plasma normalisation.

        length = lambda_D, time = 1/omega_pe, velocity = lambda_D * omega_pe = sqrt(kT/m_e),
        E = m_e lambda_D omega_pe^2 / e, B = m_e omega_pe / e.
        """
        if temperature_k <= 0:
            raise ValueError("electron_plasma normalisation requires temperature_k > 0")
        omega_pe = math.sqrt(density_m3 * ELEMENTARY_CHARGE**2 / (ELECTRON_MASS * VACUUM_PERMITTIVITY))
        v_th = math.sqrt(BOLTZMANN_CONSTANT * temperature_k / ELECTRON_MASS)
        lam = v_th / omega_pe
        return cls(
            length_m=lam,
            time_s=1.0 / omega_pe,
            velocity_m_s=lam * omega_pe,
            density_m3=density_m3,
            electric_field_v_m=ELECTRON_MASS * lam * omega_pe**2 / ELEMENTARY_CHARGE,
            magnetic_field_t=ELECTRON_MASS * omega_pe / ELEMENTARY_CHARGE,
            mass_kg=ELECTRON_MASS,
            description="electron plasma units: lambda_D, 1/omega_pe, sqrt(kT_e/m_e)",
        )
