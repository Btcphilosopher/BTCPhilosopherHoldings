"""Authoritative NumPy reference backend."""

from __future__ import annotations

from ..particles.particle_push import boris_push
from ..pic.charge_deposition import deposit_scalar
from ..pic.field_interpolation import interpolate_field
from .base import Backend


class CPUReferenceBackend(Backend):
    name = "cpu_reference"
    bitwise_reference = True

    def boris_push(self, v, E, B, q_over_m, dt):
        return boris_push(v, E, B, q_over_m, dt)

    def deposit(self, positions, values, grid, shape, offset=0.5):
        return deposit_scalar(positions, values, grid, shape, offset)

    def interpolate(self, field, positions, grid, shape, offset=0.5):
        return interpolate_field(field, positions, grid, shape, offset)
