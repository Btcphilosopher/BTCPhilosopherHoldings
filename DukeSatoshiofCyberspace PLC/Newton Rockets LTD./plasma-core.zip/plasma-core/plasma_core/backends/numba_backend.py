"""Numba-compiled kernels for 1D grids (serial, deterministic).

Only the 1D NGP/CIC deposition, interpolation and the Boris push are
compiled; other cases fall back to the reference implementation.  Kernels
run serially so that the summation order - and hence the result - is
deterministic; agreement with the reference backend is verified to a
relative tolerance of 1e-12 in ``tests/test_backends.py`` (summation order
differs from ``numpy.bincount``, so bitwise identity is not claimed).
"""

from __future__ import annotations

import math

import numpy as np

from ..exceptions import BackendUnavailableError
from ..pic.charge_deposition import deposit_scalar
from ..pic.field_interpolation import interpolate_field
from ..pic.shapes import get_shape
from .base import Backend

try:
    import numba

    _HAVE_NUMBA = True
except ImportError:  # pragma: no cover
    _HAVE_NUMBA = False


if _HAVE_NUMBA:

    @numba.njit(cache=True)
    def _boris(v, E, B, qm, dt):  # pragma: no cover - compiled
        n = v.shape[0]
        out = np.empty_like(v)
        for i in range(n):
            h = 0.5 * qm[i] * dt
            vx = v[i, 0] + h * E[i, 0]
            vy = v[i, 1] + h * E[i, 1]
            vz = v[i, 2] + h * E[i, 2]
            tx = h * B[i, 0]
            ty = h * B[i, 1]
            tz = h * B[i, 2]
            t2 = tx * tx + ty * ty + tz * tz
            sx = 2.0 * tx / (1.0 + t2)
            sy = 2.0 * ty / (1.0 + t2)
            sz = 2.0 * tz / (1.0 + t2)
            px = vx + (vy * tz - vz * ty)
            py = vy + (vz * tx - vx * tz)
            pz = vz + (vx * ty - vy * tx)
            vx += py * sz - pz * sy
            vy += pz * sx - px * sz
            vz += px * sy - py * sx
            out[i, 0] = vx + h * E[i, 0]
            out[i, 1] = vy + h * E[i, 1]
            out[i, 2] = vz + h * E[i, 2]
        return out

    @numba.njit(cache=True)
    def _deposit_1d(x, val, lower, dx, n, offset, order, periodic):  # pragma: no cover
        rho = np.zeros(n)
        for p in range(x.shape[0]):
            s = (x[p] - lower) / dx - offset
            if order == 0:
                j = int(math.floor(s + 0.5))
                if periodic:
                    j %= n
                else:
                    j = min(max(j, 0), n - 1)
                rho[j] += val[p]
            else:
                j0 = int(math.floor(s))
                f = s - j0
                j1 = j0 + 1
                if periodic:
                    j0 %= n
                    j1 %= n
                else:
                    j0 = min(max(j0, 0), n - 1)
                    j1 = min(max(j1, 0), n - 1)
                rho[j0] += val[p] * (1.0 - f)
                rho[j1] += val[p] * f
        return rho

    @numba.njit(cache=True)
    def _interp_1d(F, x, lower, dx, n, offset, order, periodic):  # pragma: no cover
        out = np.zeros((x.shape[0], 3))
        for p in range(x.shape[0]):
            s = (x[p] - lower) / dx - offset
            if order == 0:
                j = int(math.floor(s + 0.5))
                if periodic:
                    j %= n
                else:
                    j = min(max(j, 0), n - 1)
                for c in range(3):
                    out[p, c] = F[j, c]
            else:
                j0 = int(math.floor(s))
                f = s - j0
                j1 = j0 + 1
                if periodic:
                    j0 %= n
                    j1 %= n
                else:
                    j0 = min(max(j0, 0), n - 1)
                    j1 = min(max(j1, 0), n - 1)
                for c in range(3):
                    out[p, c] = (1.0 - f) * F[j0, c] + f * F[j1, c]
        return out


class NumbaBackend(Backend):
    name = "numba"
    bitwise_reference = False

    def __init__(self) -> None:
        if not _HAVE_NUMBA:
            raise BackendUnavailableError("Numba backend requested but numba is not installed",
                                          parameter="solver.backend", investigate="pip install numba")

    def boris_push(self, v, E, B, q_over_m, dt):
        n = v.shape[0]
        E = np.ascontiguousarray(np.broadcast_to(E, (n, 3)), dtype=np.float64)
        B = np.ascontiguousarray(np.broadcast_to(B, (n, 3)), dtype=np.float64)
        qm = np.ascontiguousarray(np.broadcast_to(np.asarray(q_over_m, dtype=np.float64), (n,)))
        return _boris(np.ascontiguousarray(v), E, B, qm, float(dt))

    def deposit(self, positions, values, grid, shape, offset=0.5):
        shape = get_shape(shape) if isinstance(shape, str) else shape
        if grid.dimension != 1:
            return deposit_scalar(positions, values, grid, shape, offset)
        return _deposit_1d(np.ascontiguousarray(positions[:, 0]), np.ascontiguousarray(values, dtype=np.float64),
                           float(grid.lower_m[0]), float(grid.spacing_m[0]), int(grid.cells[0]), float(offset),
                           int(shape.order), bool(grid.periodic[0]))

    def interpolate(self, field, positions, grid, shape, offset=0.5):
        shape = get_shape(shape) if isinstance(shape, str) else shape
        if grid.dimension != 1 or field.ndim != 2:
            return interpolate_field(field, positions, grid, shape, offset)
        return _interp_1d(np.ascontiguousarray(field, dtype=np.float64), np.ascontiguousarray(positions[:, 0]),
                          float(grid.lower_m[0]), float(grid.spacing_m[0]), int(grid.cells[0]), float(offset),
                          int(shape.order), bool(grid.periodic[0]))
