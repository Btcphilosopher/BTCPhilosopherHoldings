"""Compute-backend abstraction (the numerical-kernel boundary).

The physics model calls a small set of kernels through a :class:`Backend`.
Any accelerator (Numba, CuPy, JAX, CUDA, Rust via PyO3, or dedicated
hardware such as a future Silica Flux device) plugs in here *without*
changing the physics layer, provided it reproduces the reference kernels
within the documented tolerances (``tests/test_backends.py``).

Kernel contract (all arrays float64, C-contiguous, SI units):

* ``boris_push(v, E, B, q_over_m, dt) -> v_new``        v,E,B: (N,3); q_over_m: (N,)
* ``deposit(positions, values, grid, shape, offset) -> grid.shape``   (sum, not density)
* ``interpolate(field, positions, grid, shape, offset) -> (N,3)``

The CPU reference backend is authoritative.
"""

from __future__ import annotations

from abc import ABC, abstractmethod

import numpy as np


class Backend(ABC):
    name = "abstract"
    #: whether results are expected to be bitwise identical to the reference
    bitwise_reference = False

    @abstractmethod
    def boris_push(self, v: np.ndarray, E: np.ndarray, B: np.ndarray, q_over_m: np.ndarray, dt: float) -> np.ndarray: ...

    @abstractmethod
    def deposit(self, positions: np.ndarray, values: np.ndarray, grid, shape, offset: float = 0.5) -> np.ndarray: ...

    @abstractmethod
    def interpolate(self, field: np.ndarray, positions: np.ndarray, grid, shape, offset: float = 0.5) -> np.ndarray: ...

    def describe(self) -> dict:
        return {"backend": self.name}
