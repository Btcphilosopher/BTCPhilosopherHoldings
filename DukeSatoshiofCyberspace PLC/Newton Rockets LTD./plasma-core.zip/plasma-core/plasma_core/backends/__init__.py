"""Compute backends (see docs/ARCHITECTURE.md)."""

from .accelerators import CuPyBackend, JAXBackend
from .base import Backend
from .cpu_reference import CPUReferenceBackend
from .numba_backend import NumbaBackend

_BACKENDS = {"cpu_reference": CPUReferenceBackend, "numba": NumbaBackend, "cupy": CuPyBackend, "jax": JAXBackend}


def get_backend(name: str) -> Backend:
    if name not in _BACKENDS:
        raise ValueError(f"unknown backend '{name}'")
    return _BACKENDS[name]()


__all__ = ["Backend", "CPUReferenceBackend", "NumbaBackend", "CuPyBackend", "JAXBackend", "get_backend"]
