"""Placeholders for GPU / array-library backends.

These backends are *declared* so that the architecture is explicit, but they
are not implemented or validated.  Constructing one raises
:class:`BackendUnavailableError` - plasma_core never silently substitutes a
different backend.
"""

from __future__ import annotations

from ..exceptions import BackendUnavailableError
from .base import Backend


class _Unvalidated(Backend):
    library = ""

    def __init__(self) -> None:
        try:
            __import__(self.library)
            installed = True
        except ImportError:
            installed = False
        raise BackendUnavailableError(
            f"{self.name} backend is not implemented/validated",
            why=f"{self.library} {'is installed' if installed else 'is not installed'}, but no kernels have been "
                "validated against the CPU reference backend",
            parameter="solver.backend",
            investigate="use backend: cpu_reference or numba; see docs/ARCHITECTURE.md for the kernel contract")

    def boris_push(self, *a, **k):  # pragma: no cover
        raise NotImplementedError

    def deposit(self, *a, **k):  # pragma: no cover
        raise NotImplementedError

    def interpolate(self, *a, **k):  # pragma: no cover
        raise NotImplementedError


class CuPyBackend(_Unvalidated):
    name = "cupy"
    library = "cupy"


class JAXBackend(_Unvalidated):
    name = "jax"
    library = "jax"
