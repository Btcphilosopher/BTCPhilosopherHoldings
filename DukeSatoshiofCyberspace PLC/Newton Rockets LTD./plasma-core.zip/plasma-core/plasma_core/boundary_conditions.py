"""Composite boundary conditions: one object per physical boundary type that
states, explicitly, its behaviour for every quantity.

``behaviour`` documents the treatment of every quantity; the particle
models obtain their particle-boundary implementation through
:meth:`BoundaryCondition.particle_boundary`.  The matching field boundary is
selected from ``boundaries.fields`` (see :mod:`plasma_core.fields.field_boundary`).
"""

from __future__ import annotations

from dataclasses import dataclass, field

from .particles.particle_boundary import PARTICLE_BOUNDARIES, ParticleBoundary


@dataclass(frozen=True)
class BoundaryCondition:
    name: str
    behaviour: dict[str, str] = field(default_factory=dict)

    def particle_boundary(self) -> ParticleBoundary:
        return PARTICLE_BOUNDARIES[self.name]()


Periodic = BoundaryCondition("periodic", {
    "particles": "wrapped: x <- x_lo + (x - x_lo) mod L",
    "electric_field": "periodic (FFT or periodic FD Poisson); E_y,E_z periodic Yee",
    "magnetic_field": "periodic",
    "charge": "deposition stencils wrap; total charge conserved exactly",
    "current": "deposition stencils wrap",
    "distribution_function": "periodic in x (spectral advection)",
})

Reflecting = BoundaryCondition("reflecting", {
    "particles": "specular reflection: x <- 2 x_wall - x, v_n <- -v_n",
    "electric_field": "Neumann: dphi/dn = 0 (E_n = 0) at the wall (symmetry plane)",
    "magnetic_field": "not supported by the EM solver",
    "charge": "stencil clamped at the wall; total charge conserved exactly",
    "current": "stencil clamped at the wall",
    "distribution_function": "fluid: mirror ghost cells (v_n reversed); Vlasov: not supported",
})

Absorbing = BoundaryCondition("absorbing", {
    "particles": "removed on exit; count, weight, charge, kinetic energy recorded per species and wall",
    "electric_field": "Dirichlet: grounded (or prescribed potential) conducting wall",
    "magnetic_field": "not supported by the EM solver",
    "charge": "charge of absorbed particles leaves the system and is recorded as charge_lost",
    "current": "stencil clamped at the wall",
    "distribution_function": "not supported",
})

Open = BoundaryCondition("open", {
    "particles": "outflow: removed on exit and recorded (no injection)",
    "electric_field": "Dirichlet phi = 0 at the faces (an APPROXIMATION of an open boundary)",
    "magnetic_field": "not supported by the EM solver",
    "charge": "outflowing charge recorded as charge_lost",
    "current": "stencil clamped at the wall",
    "distribution_function": "not supported",
})

BOUNDARY_CONDITIONS = {bc.name: bc for bc in (Periodic, Reflecting, Absorbing, Open)}
