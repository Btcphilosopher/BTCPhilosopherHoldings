"""Multi-species 1D fluid (Euler-Poisson) plasma model.

Kept architecturally separate from the kinetic models: it shares only the
grid, the Poisson solver, the closure interface and the PlasmaState output.

Equations (each mobile species s; n [m^-3], v [m/s] (3 components),
p [Pa], epsilon = p/(gamma-1) + m n |v|^2/2 [J m^-3]):

    dn/dt     + d(n v_x)/dx                  = 0
    d(n v)/dt + d(n v_x v + (p/m) e_x)/dx    = (q/m) n (E + v x B)
    d(eps)/dt + d((eps + p) v_x)/dx          = q n v . E + Q          (ideal_gas closure only)

with E_x from Poisson, d^2 phi/dx^2 = -rho/eps0, rho = sum_s q_s n_s + rho_background,
and B a uniform external field.  The heating term Q is zero (no source is
introduced silently).

Numerics: finite volume on cell centres, MUSCL reconstruction of the
primitive variables (n, v, p) with the MC or minmod limiter (or first order),
Rusanov (local Lax-Friedrichs) interface flux with signal speed |v_x| + c_s,
and the 3-stage SSP Runge-Kutta scheme of Shu & Osher (1988) for the full
right-hand side (flux divergence + Lorentz source + Poisson solve each stage).
Boundaries: periodic, or reflecting walls (mirror ghost cells with v_x
reversed; Neumann Poisson).

Non-positive density or pressure stops the run (NumericalInstabilityError);
no floors are applied.
"""

from __future__ import annotations

import math

import numpy as np

from ..constants import BOLTZMANN_CONSTANT
from ..exceptions import NumericalInstabilityError, SolverConfigurationError
from ..fields.electric_field import electric_field_energy
from ..fields.field_boundary import build_field_boundary, check_compatibility
from ..physics.pressure import (
    AdiabaticClosure,
    IdealGasClosure,
    IsothermalClosure,
    PolytropicClosure,
    PressureClosure,
)
from ..simulation.model import SimulationModel
from ..solvers import timestep as ts
from ..solvers.poisson import PoissonSolver
from ..state import PlasmaState

NG = 2  # ghost cells


def build_closure(fluid_cfg, species) -> PressureClosure:
    c = fluid_cfg.closure
    if c == "isothermal":
        return IsothermalClosure(species.temperature_k)
    if c == "adiabatic":
        return AdiabaticClosure(fluid_cfg.gamma, species.density_m3, species.temperature_k)
    if c == "polytropic":
        return PolytropicClosure(fluid_cfg.gamma, species.density_m3, species.density_m3 * BOLTZMANN_CONSTANT * species.temperature_k)
    if c == "ideal_gas":
        if fluid_cfg.gamma <= 1.0:
            raise SolverConfigurationError("ideal_gas closure needs gamma > 1", parameter="solver.fluid.gamma")
        return IdealGasClosure(fluid_cfg.gamma)
    raise SolverConfigurationError(f"unknown closure {c}", parameter="solver.fluid.closure")


def _limited_slope(dl: np.ndarray, dr: np.ndarray, kind: str) -> np.ndarray:
    if kind == "first_order":
        return np.zeros_like(dl)
    if kind == "muscl_minmod":
        return np.where(dl * dr > 0, np.sign(dl) * np.minimum(np.abs(dl), np.abs(dr)), 0.0)
    # monotonised central
    return np.where(dl * dr > 0, np.sign(dl) * np.minimum(np.minimum(2 * np.abs(dl), 2 * np.abs(dr)),
                                                         0.5 * np.abs(dl + dr)), 0.0)


class FluidModel1D(SimulationModel):
    solver_name = "fluid"

    def __init__(self, config, grid, backend, collisions, runtime_rng) -> None:
        super().__init__(config, grid, backend, collisions, runtime_rng)
        if not collisions.is_collisionless:
            raise SolverConfigurationError("collision operators are not implemented for the fluid model",
                                           parameter="solver.collisions")
        fb = build_field_boundary(config)
        check_compatibility(self.solver_name, fb)
        self.periodic = config.boundaries.particles == "periodic"
        self.poisson = PoissonSolver(grid, config.solver.poisson, fb.name)
        self.fcfg = config.solver.fluid
        self.mobile_idx = [i for i, s in enumerate(self.species) if s.mobile]
        self.closures = {i: build_closure(self.fcfg, self.species[i]) for i in self.mobile_idx}
        self.energy_eq = self.fcfg.closure == "ideal_gas"
        self.nvar = 5 if self.energy_eq else 4
        self.background_rho = float(sum(s.charge_density_c_m3 for s in self.species if not s.mobile))
        self.E_ext = np.asarray(config.solver.external_electric_field_v_m, dtype=float)
        self.B = np.asarray(config.solver.external_magnetic_field_t, dtype=float)
        self.dx = float(grid.spacing_m[0])
        self.U = np.zeros((len(self.mobile_idx), self.nvar, grid.cells[0]))
        self.E = np.zeros(grid.cells[0])

    # ------------------------------------------------------------------
    def initialize(self, seeds) -> None:
        x = self.grid.centres(0) - self.grid.lower_m[0]
        pert = self.config.initial_condition.perturbation
        k = self.grid.mode_wavenumber(pert.mode)
        for a, i in enumerate(self.mobile_idx):
            s = self.species[i]
            n = np.full_like(x, s.density_m3)
            if pert.amplitude > 0 and (pert.species is None or s.name in pert.species):
                n = s.density_m3 * (1.0 + pert.amplitude * np.cos(k * x + pert.phase_rad))
            v = np.asarray(s.bulk_velocity_m_s)
            self.U[a, 0] = n
            for c in range(3):
                self.U[a, 1 + c] = n * v[c]
            if self.energy_eq:
                p = n * BOLTZMANN_CONSTANT * s.temperature_k
                self.U[a, 4] = p / (self.fcfg.gamma - 1.0) + 0.5 * s.mass_kg * n * float(v @ v)
        self.E = self._electric_field(self.U)
        self.step_index = 0

    def _pressure(self, a: int, n: np.ndarray, mom: np.ndarray, eps: np.ndarray | None) -> np.ndarray:
        i = self.mobile_idx[a]
        m = self.species[i].mass_kg
        cl = self.closures[i]
        if self.energy_eq:
            kin = 0.5 * m * np.sum(mom * mom, axis=0) / n
            return cl.pressure(n, m, eps - kin)
        return cl.pressure(n, m)

    def _electric_field(self, U: np.ndarray) -> np.ndarray:
        rho = np.full(self.grid.cells[0], self.background_rho)
        for a, i in enumerate(self.mobile_idx):
            rho += self.species[i].charge_c * U[a, 0]
        self._rho = rho
        self._last_poisson = self.poisson.solve(rho)
        return self._last_poisson.electric_field_v_m[:, 0] + self.E_ext[0]

    def _ghost(self, W: np.ndarray, flip_rows: list[int]) -> np.ndarray:
        """Pad primitive array W (nvar, nx) with NG ghost cells."""
        if self.periodic:
            return np.concatenate([W[:, -NG:], W, W[:, :NG]], axis=1)
        lo = W[:, NG - 1::-1].copy()
        hi = W[:, :-NG - 1:-1].copy()
        lo[flip_rows] *= -1
        hi[flip_rows] *= -1
        return np.concatenate([lo, W, hi], axis=1)

    def _rhs(self, U: np.ndarray) -> tuple[np.ndarray, float]:
        E = self._electric_field(U)
        dUdt = np.zeros_like(U)
        amax = 0.0
        recon = self.fcfg.reconstruction
        for a, i in enumerate(self.mobile_idx):
            s = self.species[i]
            m, q = s.mass_kg, s.charge_c
            n = U[a, 0]
            if np.any(n <= 0) or not np.all(np.isfinite(U[a])):
                raise NumericalInstabilityError(
                    f"fluid species {s.name}: non-positive or non-finite density at step {self.step_index}",
                    why="the explicit scheme produced an unphysical state (no density floor is applied)",
                    parameter="time.dt_s / solver.fluid.reconstruction",
                    investigate="reduce dt (fluid CFL) or use a more diffusive reconstruction")
            mom = U[a, 1:4]
            eps = U[a, 4] if self.energy_eq else None
            p = self._pressure(a, n, mom, eps)
            if np.any(p < 0):
                raise NumericalInstabilityError(f"fluid species {s.name}: negative pressure",
                                                parameter="time.dt_s")
            v = mom / n
            W = np.vstack([n, v, p[None, :]])  # (5, nx): n, vx, vy, vz, p
            Wg = self._ghost(W, [1])
            dl = Wg[:, 1:-1] - Wg[:, :-2]
            dr = Wg[:, 2:] - Wg[:, 1:-1]
            slope = _limited_slope(dl, dr, recon)  # cells 1..nx+2 of padded (nx+2 cells)
            Wc = Wg[:, 1:-1]
            WL = (Wc + 0.5 * slope)[:, :-1]   # left state at interfaces i+1/2, i = 0..nx (nx+1 faces)
            WR = (Wc - 0.5 * slope)[:, 1:]
            FL, UL, cL = self._flux(WL, m, i)
            FR, UR, cR = self._flux(WR, m, i)
            speed = np.maximum(np.abs(WL[1]) + cL, np.abs(WR[1]) + cR)
            amax = max(amax, float(speed.max()))
            F = 0.5 * (FL + FR) - 0.5 * speed * (UR - UL)  # (nvar, nx+1)
            dUdt[a] = -(F[:, 1:] - F[:, :-1]) / self.dx
            # Lorentz source: (q/m) n (E + v x B)
            Evec = np.zeros((3, n.shape[0]))
            Evec[0] = E
            Evec[1] += self.E_ext[1]
            Evec[2] += self.E_ext[2]
            vxB = np.cross(v.T, self.B).T
            dUdt[a, 1:4] += (q / m) * n * (Evec + vxB)
            if self.energy_eq:
                dUdt[a, 4] += q * n * np.sum(v * Evec, axis=0)
        return dUdt, amax

    def _flux(self, W: np.ndarray, m: float, i: int):
        n, vx, vy, vz, p = W
        cl = self.closures[i]
        if not self.energy_eq:
            p = cl.pressure(n, m)  # barotropic: pressure from reconstructed density
        nv = np.vstack([n * vx, n * vy, n * vz])
        if self.energy_eq:
            eps = p / (self.fcfg.gamma - 1.0) + 0.5 * m * n * (vx * vx + vy * vy + vz * vz)
            U = np.vstack([n, nv, eps[None, :]])
            F = np.vstack([n * vx, n * vx * vx + p / m, n * vx * vy, n * vx * vz, (eps + p) * vx])
        else:
            U = np.vstack([n, nv])
            F = np.vstack([n * vx, n * vx * vx + p / m, n * vx * vy, n * vx * vz])
        c = np.sqrt(np.maximum(cl.sound_speed_sq(n, p, m), 0.0))
        return F, U, c

    def step(self) -> None:
        dt = self.dt
        U0 = self.U
        k1, amax = self._rhs(U0)
        cfl = amax * dt / self.dx
        if cfl > 1.0:
            raise NumericalInstabilityError(
                f"fluid CFL number {cfl:.3f} > 1 at step {self.step_index}",
                why="signal speed |v_x| + c_s grew beyond dx/dt (fixed time step, no silent adaptation)",
                parameter="time.dt_s", investigate="reduce dt")
        U1 = U0 + dt * k1
        k2, _ = self._rhs(U1)
        U2 = 0.75 * U0 + 0.25 * (U1 + dt * k2)
        k3, _ = self._rhs(U2)
        self.U = U0 / 3.0 + 2.0 / 3.0 * (U2 + dt * k3)
        self.last_cfl = cfl
        self.step_index += 1
        self.E = self._electric_field(self.U)

    # ------------------------------------------------------------------
    def observe(self) -> PlasmaState:
        g = self.grid
        nc = g.cells[0]
        E = self._electric_field(self.U)
        dV = g.cell_volume_m3
        dens = np.zeros((self.n_species, nc))
        J = np.zeros((nc, 3))
        temps = np.full(self.n_species, np.nan)
        P = np.zeros(3)
        bulk = 0.0
        internal = 0.0
        pscale = 0.0
        ws = np.zeros(self.n_species)
        for i, s in enumerate(self.species):
            if not s.mobile:
                dens[i] = s.density_m3
                temps[i] = s.temperature_k
                continue
        for a, i in enumerate(self.mobile_idx):
            s = self.species[i]
            n = self.U[a, 0]
            mom = self.U[a, 1:4]
            p = self._pressure(a, n, mom, self.U[a, 4] if self.energy_eq else None)
            dens[i] = n
            J += s.charge_c * mom.T
            v = mom / n
            P += s.mass_kg * mom.sum(axis=1) * dV
            pscale += s.mass_kg * float(np.sum(np.linalg.norm(mom, axis=0))) * dV
            bulk += 0.5 * s.mass_kg * float(np.sum(n * np.sum(v * v, axis=0))) * dV
            gam = self.fcfg.gamma
            if self.fcfg.closure != "isothermal" and gam > 1.0:
                internal += float(np.sum(p)) / (gam - 1.0) * dV
            temps[i] = float(np.sum(p) / (BOLTZMANN_CONSTANT * np.sum(n)))
            ws[i] = float(np.sum(n)) * dV
        Evec = np.zeros((nc, 3))
        Evec[:, 0] = E
        Evec[:, 1:] = self.E_ext[1:]
        we = electric_field_energy(self._last_poisson.electric_field_v_m, dV)
        from ..diagnostics.temperature import electron_ion_temperatures

        te, ti = electron_ion_temperatures(temps, self.species, ws)
        Q = float(np.sum(self._rho)) * dV
        extras = {
            "bulk_kinetic_energy_j": bulk, "internal_energy_j": internal,
            "energy_definition": "kinetic = bulk flow + internal p/(gamma-1); isothermal closure: internal "
                                 "energy excluded (heat bath) and total energy is not conserved",
            "power_j_dot_e_w": float(np.sum(J[:, 0] * (E - self.E_ext[0]))) * dV,
            "poisson_residual": self._last_poisson.residual, "grid_charge_c": Q,
            "momentum_scale_kg_m_s": pscale, "particles_by_species": [0] * self.n_species,
            "weight_by_species": ws.tolist(), "temperature_estimator": "p/(n k_B) density-weighted",
            "cfl_number": getattr(self, "last_cfl", float("nan")),
        }
        return PlasmaState(
            time_s=self.time_s, step=self.step_index, grid=g, species_names=[s.name for s in self.species],
            number_density_m3=dens, charge_density_c_m3=self._rho.copy(), current_density_a_m2=J,
            electric_field_v_m=Evec, magnetic_field_t=np.broadcast_to(self.B, (nc, 3)).copy(),
            species_temperature_k=temps, electron_temperature_k=te, ion_temperature_k=ti,
            kinetic_energy_j=bulk + internal, electric_field_energy_j=we, magnetic_field_energy_j=0.0,
            total_charge_c=Q, total_momentum_kg_m_s=P, potential_v=self._last_poisson.phi_v.copy(),
            solver=self.solver_name, extras=extras)

    def state_arrays(self):
        return {"fluid/U": self.U}

    def load_state_arrays(self, arrays, scalars) -> None:
        self.U = np.array(arrays["fluid/U"])
        self.step_index = int(scalars["step_index"])
        self.E = self._electric_field(self.U)

    def timestep_assessments(self, scales) -> list:
        out = []
        if scales.plasma_frequency_rad_s > 0:
            out.append(ts.plasma_oscillation_criterion(scales.plasma_frequency_rad_s, self.dt, scheme="ssp_rk3"))
        smax = 0.0
        for i in self.mobile_idx:
            s = self.species[i]
            cs = math.sqrt(max(self.fcfg.gamma, 1.0) * BOLTZMANN_CONSTANT * s.temperature_k / s.mass_kg)
            smax = max(smax, abs(s.bulk_velocity_m_s[0]) + cs)
        if smax > 0:
            out.append(ts.fluid_cfl_criterion(smax, self.dt, self.dx, self.fcfg.cfl))
        if scales.max_cyclotron_frequency_rad_s > 0:
            out.append(ts.gyration_criterion(scales.max_cyclotron_frequency_rad_s, self.dt))
        return out
