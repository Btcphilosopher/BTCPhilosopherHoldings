"""1D1V Vlasov-Poisson solver (semi-Lagrangian, Strang splitting).

Equation (each mobile species s; f_s(x, v_x, t) in s m^-4, so that
n_s(x) = integral f_s dv_x):

    df/dt + v df/dx + (q/m) E_x df/dv = C[f],      dE_x/dx = rho/eps0.

Only one velocity dimension is represented.  A uniform magnetic field cannot
be included (v x B needs >= 2 velocity components) and is rejected at
configuration time.  This is a foundation for 1D2V/1D3V solvers, not a
substitute for them.

Splitting (Cheng & Knorr 1976), one step dt:

    1. x-advection  dt/2 : f(x, v) <- f(x - v dt/2, v)     exact Fourier shift (periodic x)
    2. Poisson           : rho = sum_s q_s integral f_s dv + rho_bg -> E_x
    3. v-advection  dt   : f(x, v) <- f(x, v - (q/m) E_x dt)  cubic B-spline interpolation
                           (scipy.ndimage.map_coordinates, f = 0 outside the velocity grid)
    4. collisions   dt   : C[f] (BGK) - only if configured
    5. x-advection  dt/2

Second-order accurate in time; unconditionally stable (no CFL limit).
Known numerical artefacts, which are *measured* and reported:
* recurrence at T_R = 2 pi / (k dv) for a mode k (warned before the run);
* small negative values of f from spline interpolation (``f_min_relative``);
* total-mass drift from interpolation and outflow through +/- v_max.
"""

from __future__ import annotations

import math

import numpy as np
from scipy.ndimage import map_coordinates

from ..constants import BOLTZMANN_CONSTANT
from ..diagnostics.distribution import grid_distribution_moments
from ..fields.electric_field import electric_field_energy
from ..fields.field_boundary import build_field_boundary, check_compatibility
from ..grid.velocity_grid import VelocityGrid
from ..simulation.model import SimulationModel
from ..solvers import timestep as ts
from ..solvers.poisson import PoissonSolver
from ..state import PlasmaState


class VlasovModel1D1V(SimulationModel):
    solver_name = "vlasov"

    def __init__(self, config, grid, backend, collisions, runtime_rng) -> None:
        super().__init__(config, grid, backend, collisions, runtime_rng)
        fb = build_field_boundary(config)
        check_compatibility(self.solver_name, fb)
        self.poisson = PoissonSolver(grid, config.solver.poisson, "periodic")
        self.vcfg = config.solver.vlasov
        self.mobile_idx = [i for i, s in enumerate(self.species) if s.mobile]
        self.background_rho = float(sum(s.charge_density_c_m3 for s in self.species if not s.mobile))
        self.E_ext_x = float(config.solver.external_electric_field_v_m[0])
        self.vgrids: list[VelocityGrid] = []
        for i in self.mobile_idx:
            s = self.species[i]
            if self.vcfg.velocity_min_m_s is not None:
                vmin, vmax = self.vcfg.velocity_min_m_s, self.vcfg.velocity_max_m_s
            else:
                vt = s.thermal_speed_rms_1d_m_s
                u = s.bulk_velocity_m_s[0]
                vmin, vmax = u - self.vcfg.velocity_extent_vth * vt, u + self.vcfg.velocity_extent_vth * vt
            self.vgrids.append(VelocityGrid.uniform_1d(self.vcfg.velocity_cells, vmin, vmax))
        nx = grid.cells[0]
        self.f = [np.zeros((nx, self.vcfg.velocity_cells)) for _ in self.mobile_idx]
        self.kx = grid.wavenumbers(0)
        self.E = np.zeros(nx)

    def initialize(self, seeds) -> None:
        x = self.grid.centres(0) - self.grid.lower_m[0]
        pert = self.config.initial_condition.perturbation
        k = self.grid.mode_wavenumber(pert.mode)
        for a, i in enumerate(self.mobile_idx):
            s = self.species[i]
            v = self.vgrids[a].centres(0)
            vt = s.thermal_speed_rms_1d_m_s
            n = np.full_like(x, s.density_m3)
            if pert.amplitude > 0 and (pert.species is None or s.name in pert.species):
                n = s.density_m3 * (1.0 + pert.amplitude * np.cos(k * x + pert.phase_rad))
            if vt > 0:
                fv = np.exp(-((v - s.bulk_velocity_m_s[0]) ** 2) / (2 * vt * vt)) / (math.sqrt(2 * math.pi) * vt)
            else:
                raise ValueError("cold species need explicit Vlasov treatment (delta function not representable)")
            # renormalise the discrete velocity profile so that sum f dv = n exactly
            fv /= fv.sum() * self.vgrids[a].spacing_m_s[0]
            self.f[a] = n[:, None] * fv[None, :]
        self.E = self._solve_e()
        self.step_index = 0

    # sub-steps -----------------------------------------------------------
    def _advect_x(self, h: float) -> None:
        for a in range(len(self.f)):
            v = self.vgrids[a].centres(0)
            fk = np.fft.fft(self.f[a], axis=0)
            fk *= np.exp(-1j * self.kx[:, None] * v[None, :] * h)
            self.f[a] = np.real(np.fft.ifft(fk, axis=0))

    def _solve_e(self) -> np.ndarray:
        rho = np.full(self.grid.cells[0], self.background_rho)
        for a, i in enumerate(self.mobile_idx):
            rho += self.species[i].charge_c * self.f[a].sum(axis=1) * self.vgrids[a].spacing_m_s[0]
        self._rho = rho
        self._last = self.poisson.solve(rho)
        return self._last.electric_field_v_m[:, 0] + self.E_ext_x

    def _advect_v(self, E: np.ndarray, h: float) -> None:
        for a, i in enumerate(self.mobile_idx):
            s = self.species[i]
            vg = self.vgrids[a]
            dv = vg.spacing_m_s[0]
            f = self.f[a]
            nx, nv = f.shape
            shift = (s.charge_to_mass_c_kg * E * h) / dv  # in cells
            ix = np.repeat(np.arange(nx, dtype=float)[:, None], nv, axis=1)
            iv = np.arange(nv, dtype=float)[None, :] - shift[:, None]
            self.f[a] = map_coordinates(f, [ix, iv], order=3, mode="grid-constant", cval=0.0, prefilter=True)

    def step(self) -> None:
        self._advect_x(0.5 * self.dt)
        E = self._solve_e()
        self._advect_v(E, self.dt)
        if not self.collisions.is_collisionless:
            for a, i in enumerate(self.mobile_idx):
                v = self.vgrids[a].centres(0)
                self.f[a] = self.collisions.apply_distribution(self.f[a], v, self.vgrids[a].spacing_m_s[0],
                                                               self.species[i].mass_kg, self.dt)
        self._advect_x(0.5 * self.dt)
        self.step_index += 1
        self.E = self._solve_e()

    # observation ------------------------------------------------------------
    def observe(self) -> PlasmaState:
        g = self.grid
        nc = g.cells[0]
        dV = g.cell_volume_m3
        E = self._solve_e()
        dens = np.zeros((self.n_species, nc))
        temps = np.full(self.n_species, np.nan)
        ws = np.zeros(self.n_species)
        J = np.zeros((nc, 3))
        P = np.zeros(3)
        ke = 0.0
        pscale = 0.0
        fmin = 0.0
        dists = {}
        ke_sp = np.zeros(self.n_species)
        for i, s in enumerate(self.species):
            if not s.mobile:
                dens[i] = s.density_m3
                temps[i] = s.temperature_k
        for a, i in enumerate(self.mobile_idx):
            s = self.species[i]
            v = self.vgrids[a].centres(0)
            dv = self.vgrids[a].spacing_m_s[0]
            f = self.f[a]
            mom = grid_distribution_moments(f, v, dv, s.mass_kg)
            dens[i] = mom["density_m3"]
            flux = (f * v[None, :]).sum(axis=1) * dv
            J[:, 0] += s.charge_c * flux
            P[0] += s.mass_kg * float(flux.sum()) * dV
            pscale += s.mass_kg * float((f * np.abs(v)[None, :]).sum()) * dv * dV
            e = 0.5 * s.mass_kg * float((f * (v * v)[None, :]).sum()) * dv * dV
            ke += e
            ke_sp[i] = e
            ws[i] = float(mom["density_m3"].sum()) * dV
            u = float(flux.sum() / mom["density_m3"].sum())
            var = float((f * ((v - u) ** 2)[None, :]).sum() * dv / mom["density_m3"].sum())
            temps[i] = s.mass_kg * var / BOLTZMANN_CONSTANT
            fmin = min(fmin, float(f.min() / f.max()))
            dists[s.name] = f.copy()
        from ..diagnostics.temperature import electron_ion_temperatures

        te, ti = electron_ion_temperatures(temps, self.species, ws)
        Evec = np.zeros((nc, 3))
        Evec[:, 0] = E
        we = electric_field_energy(self._last.electric_field_v_m, dV)
        Q = float(np.sum(self._rho)) * dV
        extras = {
            "distribution_functions": dists,
            "velocity_grids_m_s": {self.species[i].name: self.vgrids[a].centres(0) for a, i in enumerate(self.mobile_idx)},
            "f_min_relative": fmin, "poisson_residual": self._last.residual, "grid_charge_c": Q,
            "power_j_dot_e_w": float(np.sum(J[:, 0] * (E - self.E_ext_x))) * dV,
            "kinetic_energy_by_species_j": ke_sp.tolist(),
            "momentum_scale_kg_m_s": pscale, "particles_by_species": [0] * self.n_species,
            "weight_by_species": ws.tolist(),
            "temperature_estimator": "1V: k_B T = m <(v_x-u)^2>; kinetic energy includes v_x only",
        }
        first = self.mobile_idx[0]
        return PlasmaState(
            time_s=self.time_s, step=self.step_index, grid=g, species_names=[s.name for s in self.species],
            number_density_m3=dens, charge_density_c_m3=self._rho.copy(), current_density_a_m2=J,
            electric_field_v_m=Evec, magnetic_field_t=np.zeros((nc, 3)), species_temperature_k=temps,
            electron_temperature_k=te, ion_temperature_k=ti, kinetic_energy_j=ke, electric_field_energy_j=we,
            magnetic_field_energy_j=0.0, total_charge_c=Q, total_momentum_kg_m_s=P,
            potential_v=self._last.phi_v.copy(), distribution_function=dists[self.species[first].name],
            velocity_grid_m_s=self.vgrids[0].centres(0), solver=self.solver_name, extras=extras)

    def state_arrays(self):
        return {f"vlasov/f_{a}": f for a, f in enumerate(self.f)}

    def load_state_arrays(self, arrays, scalars) -> None:
        self.f = [np.array(arrays[f"vlasov/f_{a}"]) for a in range(len(self.mobile_idx))]
        self.step_index = int(scalars["step_index"])
        self.E = self._solve_e()

    def timestep_assessments(self, scales) -> list:
        out = []
        if scales.plasma_frequency_rad_s > 0:
            a = ts.plasma_oscillation_criterion(scales.plasma_frequency_rad_s, self.dt)
            a.required_limit = None  # semi-Lagrangian: unconditionally stable
            a.explanation = "semi-Lagrangian splitting is unconditionally stable; omega_p dt <= 0.2 for accuracy"
            out.append(a)
        return out

    def configuration_warnings(self, scales) -> list[str]:
        w = []
        k1 = self.grid.mode_wavenumber(1)
        for a, i in enumerate(self.mobile_idx):
            dv = self.vgrids[a].spacing_m_s[0]
            TR = 2 * math.pi / (k1 * dv)
            if self.config.time.duration_s > TR:
                w.append(f"species {self.species[i].name}: run duration exceeds the recurrence time "
                         f"T_R = 2 pi/(k_1 dv) = {TR:.3e} s; late-time results contain numerical recurrence")
        return w
