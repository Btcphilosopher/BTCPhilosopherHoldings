"""Time-step stability and accuracy criteria.

Each criterion compares a dimensionless number with a *required* limit (a
violation makes the scheme unstable or invalid) and a *recommended* limit
(accuracy).  Criteria and their sources:

====================  ==================  ========  ===========  ===============================
criterion             number              required  recommended  scheme
====================  ==================  ========  ===========  ===============================
plasma_oscillation    omega_p dt          < 2       <= 0.2       leapfrog PIC (B&L sec. 4-4)
                                          < sqrt 3               SSP-RK3 fluid source terms
gyration              omega_c dt          -         <= 0.2       Boris (phase error)
particle_cfl          v_max dt / dx       < 1       <= 0.5       PIC deposition/boundaries
courant_em            c dt / dx           <= 1      <= 0.95      1D Yee FDTD
fluid_cfl             (|u|+c_s) dt / dx   <= 1      <= cfl       MUSCL-Rusanov + SSP-RK3
====================  ==================  ========  ===========  ===============================
"""

from __future__ import annotations

import math
from dataclasses import asdict, dataclass

from ..constants import SPEED_OF_LIGHT


@dataclass
class StabilityAssessment:
    criterion: str
    value: float
    required_limit: float | None
    recommended_limit: float | None
    rate_per_s: float  # value / dt; used to derive a recommended dt
    explanation: str

    @property
    def required_satisfied(self) -> bool:
        if self.required_limit is None:
            return True
        if self.criterion == "courant_em":  # c dt = dx is the (stable) magic time step
            return self.value <= self.required_limit * (1 + 1e-12)
        return self.value < self.required_limit

    @property
    def recommended_satisfied(self) -> bool:
        return self.recommended_limit is None or self.value <= self.recommended_limit * (1 + 1e-12)

    def recommended_dt(self) -> float:
        if self.recommended_limit is None or self.rate_per_s <= 0:
            return math.inf
        return self.recommended_limit / self.rate_per_s

    def to_dict(self) -> dict:
        d = asdict(self)
        d.update(required_satisfied=self.required_satisfied, recommended_satisfied=self.recommended_satisfied)
        return d


def plasma_oscillation_criterion(omega_p: float, dt: float, scheme: str = "leapfrog") -> StabilityAssessment:
    req = 2.0 if scheme == "leapfrog" else math.sqrt(3.0)
    return StabilityAssessment("plasma_oscillation", omega_p * dt, req, 0.2, omega_p,
                               f"omega_p dt must be < {req:.3g} for {scheme} stability; <= 0.2 keeps the "
                               "phase error below ~0.2%")


def gyration_criterion(omega_c: float, dt: float) -> StabilityAssessment:
    return StabilityAssessment("gyration", omega_c * dt, None, 0.2, omega_c,
                               "Boris is stable for any omega_c dt but the gyro-phase error is "
                               "~(omega_c dt)^2/12; omega_c dt <= 0.2 recommended")


def particle_cfl_criterion(v_max: float, dt: float, dx: float) -> StabilityAssessment:
    return StabilityAssessment("particle_cfl", v_max * dt / dx, 1.0, 0.5, v_max / dx,
                               "particles must not cross more than one cell per step (deposition, "
                               "reflecting walls); v_max estimated as |u| + 5 sqrt(kT/m)")


def courant_em_criterion(dt: float, dx: float) -> StabilityAssessment:
    return StabilityAssessment("courant_em", SPEED_OF_LIGHT * dt / dx, 1.0, 0.95, SPEED_OF_LIGHT / dx,
                               "1D Yee FDTD requires c dt / dx <= 1")


def fluid_cfl_criterion(max_signal_speed: float, dt: float, dx: float, cfl: float) -> StabilityAssessment:
    return StabilityAssessment("fluid_cfl", max_signal_speed * dt / dx, 1.0, cfl, max_signal_speed / dx,
                               "explicit finite-volume CFL condition (|u| + c_s) dt / dx")
