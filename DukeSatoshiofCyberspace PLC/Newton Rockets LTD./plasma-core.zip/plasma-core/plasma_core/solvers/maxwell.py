"""1D electromagnetic field solver (Yee FDTD).

Supported geometry
------------------
**One spatial dimension (x), periodic, all three field components.**
Fields depend only on x and t (d/dy = d/dz = 0).  This is NOT a 2D/3D
Maxwell solver.  Faraday's and Ampere's laws reduce to two decoupled
transverse polarisations:

    dB_y/dt =  dE_z/dx            dE_z/dt =  c^2 dB_y/dx - J_z/eps0
    dB_z/dt = -dE_y/dx            dE_y/dt = -c^2 dB_z/dx - J_y/eps0

plus the longitudinal component, for which plasma_core uses Gauss's law
(Poisson) instead of Ampere's law:  dE_x/dx = rho/eps0.  B_x is uniform and
constant (div B = 0 in 1D).

Discretisation (see :mod:`plasma_core.grid.field_grid`, layout YEE_1D)
-----------------------------------------------------------------------
E_y, E_z at cell centres x_{j+1/2}; B_y, B_z at cell edges x_j.  One step
dt is the standard Yee leapfrog, written with two half-step B updates so that
B is available at integer times for the particle push:

    B^{n+1/2} = B^n       - (dt/2) curl E^n
    E^{n+1}   = E^n       + dt (c^2 curl B^{n+1/2} - J^{n+1/2}/eps0)
    B^{n+1}   = B^{n+1/2} - (dt/2) curl E^{n+1}

Stability (Courant): c dt / dx <= 1.  Numerical dispersion:
sin(omega dt/2) / (c dt) = sin(k dx/2) / dx   (exact at c dt = dx).
"""

from __future__ import annotations

import numpy as np

from ..constants import SPEED_OF_LIGHT, VACUUM_PERMEABILITY, VACUUM_PERMITTIVITY
from ..exceptions import BoundaryConditionError, SolverConfigurationError, StabilityCriterionViolation


class Yee1DMaxwellSolver:
    """Transverse 1D Yee solver; arrays are views that the caller may read."""

    def __init__(self, grid, dt: float, *, enforce_courant: bool = True) -> None:
        if grid.dimension != 1:
            raise SolverConfigurationError("Yee1DMaxwellSolver requires a 1D grid", parameter="domain.dimension")
        if not grid.periodic[0]:
            raise BoundaryConditionError("Yee1DMaxwellSolver supports periodic boundaries only",
                                         why="absorbing (Mur/PML) boundaries are not implemented",
                                         parameter="boundaries")
        self.grid = grid
        self.dt = float(dt)
        self.dx = float(grid.spacing_m[0])
        self.courant = SPEED_OF_LIGHT * self.dt / self.dx
        if enforce_courant and self.courant > 1.0:
            raise StabilityCriterionViolation(
                "Courant condition violated for the 1D Yee solver",
                why=f"c dt / dx = {self.courant:.4f} > 1",
                parameter="time.dt_s",
                investigate=f"reduce dt below dx/c = {self.dx / SPEED_OF_LIGHT:.4e} s or coarsen the grid")
        n = grid.cells[0]
        self.Ey = np.zeros(n)
        self.Ez = np.zeros(n)
        self.By = np.zeros(n)
        self.Bz = np.zeros(n)

    # spatial derivatives -------------------------------------------------
    def _d_centre_to_edge(self, f_centre: np.ndarray) -> np.ndarray:
        """d/dx evaluated at edges j from centres j-1/2, j+1/2."""
        return (f_centre - np.roll(f_centre, 1)) / self.dx

    def _d_edge_to_centre(self, f_edge: np.ndarray) -> np.ndarray:
        """d/dx evaluated at centres j+1/2 from edges j, j+1."""
        return (np.roll(f_edge, -1) - f_edge) / self.dx

    # updates -------------------------------------------------------------
    def half_step_b(self, dt: float | None = None) -> None:
        h = 0.5 * (self.dt if dt is None else dt)
        self.By += h * self._d_centre_to_edge(self.Ez)
        self.Bz -= h * self._d_centre_to_edge(self.Ey)

    def full_step_e(self, Jy: np.ndarray | None = None, Jz: np.ndarray | None = None, dt: float | None = None) -> None:
        dt = self.dt if dt is None else dt
        c2 = SPEED_OF_LIGHT**2
        self.Ey += dt * (-c2 * self._d_edge_to_centre(self.Bz))
        self.Ez += dt * (c2 * self._d_edge_to_centre(self.By))
        if Jy is not None:
            self.Ey -= dt * Jy / VACUUM_PERMITTIVITY
        if Jz is not None:
            self.Ez -= dt * Jz / VACUUM_PERMITTIVITY

    def step(self, Jy: np.ndarray | None = None, Jz: np.ndarray | None = None) -> None:
        """Advance (E, B) from t^n to t^{n+1} given J^{n+1/2} at cell centres."""
        self.half_step_b()
        self.full_step_e(Jy, Jz)
        self.half_step_b()

    # diagnostics ---------------------------------------------------------
    def transverse_energy(self) -> tuple[float, float]:
        """(electric, magnetic) transverse field energy per unit area [J/m^2]."""
        dx = self.dx
        we = 0.5 * VACUUM_PERMITTIVITY * float(np.sum(self.Ey**2 + self.Ez**2)) * dx
        wb = float(np.sum(self.By**2 + self.Bz**2)) * dx / (2.0 * VACUUM_PERMEABILITY)
        return we, wb

    def b_at_centres(self) -> tuple[np.ndarray, np.ndarray]:
        """Linear average of edge B onto cell centres (for collocated output)."""
        return 0.5 * (self.By + np.roll(self.By, -1)), 0.5 * (self.Bz + np.roll(self.Bz, -1))

    def state_arrays(self) -> dict[str, np.ndarray]:
        return {"Ey": self.Ey, "Ez": self.Ez, "By_edges": self.By, "Bz_edges": self.Bz}

    def load_state_arrays(self, d: dict[str, np.ndarray]) -> None:
        self.Ey[:] = d["Ey"]
        self.Ez[:] = d["Ez"]
        self.By[:] = d["By_edges"]
        self.Bz[:] = d["Bz_edges"]
