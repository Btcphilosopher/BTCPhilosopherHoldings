"""Electrostatic Poisson solvers.

    laplacian(phi) = -rho / epsilon_0,      E = -grad(phi)

Unknowns live at cell centres.  Methods:

``fft_fd`` (periodic, 1D/2D)
    Exact solution of the *second-order finite-difference* Poisson equation by
    FFT, using the modified wavenumber K^2 = sum_a (2 sin(k_a dx_a/2)/dx_a)^2.
    E is the centred difference -(phi_{j+1} - phi_{j-1})/(2 dx).
    The discrete residual is zero to round-off.

``fft_spectral`` (periodic, 1D/2D)
    Spectral solution phi_k = rho_k / (eps0 k^2), E_k = -i k phi_k.

``fd`` (periodic, Dirichlet or Neumann; 1D and 2D (no Neumann in 2D))
    Sparse direct solve (scipy.sparse.linalg.splu) of the 3-point (5-point in
    2D) Laplacian.  Dirichlet walls are located on the domain faces (cell
    edges); the boundary value is imposed with a ghost cell
    phi_ghost = 2 phi_wall - phi_boundary_cell.  Neumann walls impose
    dphi/dx = 0 (E_normal = 0 at a symmetry/reflecting wall) with
    phi_ghost = phi_boundary_cell; the solution is defined up to a constant
    which is fixed by zero mean.

Periodic and Neumann problems are only solvable for zero net charge.  The
mean charge density is removed explicitly and returned in the result as
``removed_mean_charge_density`` so the operation is never silent.
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import scipy.sparse as sp
from scipy.sparse.linalg import splu

from ..constants import VACUUM_PERMITTIVITY
from ..exceptions import BoundaryConditionError, SolverConfigurationError


@dataclass
class PoissonResult:
    phi_v: np.ndarray                 # grid.shape [V]
    electric_field_v_m: np.ndarray    # grid.shape + (3,) [V/m]
    residual: float                   # max |L phi + rho/eps0| / max |rho/eps0| (discrete operator)
    removed_mean_charge_density: float  # [C/m^3]


def _laplacian_1d(n: int, dx: float, bc: str) -> sp.csc_matrix:
    main = -2.0 * np.ones(n)
    off = np.ones(n - 1)
    A = sp.diags([off, main, off], [-1, 0, 1], shape=(n, n), format="lil")
    if bc == "periodic":
        A[0, n - 1] = 1.0
        A[n - 1, 0] = 1.0
    elif bc == "dirichlet":
        A[0, 0] = -3.0
        A[n - 1, n - 1] = -3.0
    elif bc == "neumann":
        A[0, 0] = -1.0
        A[n - 1, n - 1] = -1.0
    else:
        raise BoundaryConditionError(f"unknown Poisson boundary '{bc}'")
    return (A / dx**2).tocsc()


class PoissonSolver:
    """Poisson solver on a :class:`SpatialGrid` (1D or 2D)."""

    def __init__(self, grid, method: str = "fft_fd", boundary: str = "periodic",
                 potential_low_v: float = 0.0, potential_high_v: float = 0.0) -> None:
        self.grid = grid
        self.method = method
        self.boundary = boundary
        self.phi_lo = float(potential_low_v)
        self.phi_hi = float(potential_high_v)
        if grid.dimension not in (1, 2):
            raise SolverConfigurationError("Poisson solver supports 1D and 2D grids", parameter="domain.dimension")
        if method in ("fft_fd", "fft_spectral") and boundary != "periodic":
            raise BoundaryConditionError(
                f"Poisson method '{method}' requires periodic boundaries (got '{boundary}')",
                why="the FFT diagonalises the Laplacian only for periodic problems",
                parameter="solver.poisson", investigate="use poisson: fd for wall-bounded domains")
        if boundary == "periodic" and not all(grid.periodic):
            raise BoundaryConditionError("periodic Poisson boundary on a non-periodic grid", parameter="boundaries")
        if boundary == "neumann" and grid.dimension != 1:
            raise BoundaryConditionError("Neumann Poisson boundaries are implemented in 1D only",
                                         parameter="boundaries.fields")
        self._lu = None
        self._rhs_bc = None
        if method == "fd":
            self._build_fd()
        elif method in ("fft_fd", "fft_spectral"):
            self._build_fft()
        else:
            raise SolverConfigurationError(f"unknown Poisson method '{method}'", parameter="solver.poisson")

    # ------------------------------------------------------------------
    def _build_fft(self) -> None:
        g = self.grid
        ks = [g.wavenumbers(a) for a in range(g.dimension)]
        dx = g.spacing_m
        if self.method == "fft_fd":
            Ks2 = [(2.0 * np.sin(k * d / 2.0) / d) ** 2 for k, d in zip(ks, dx)]
        else:
            Ks2 = [k**2 for k in ks]
        if g.dimension == 1:
            K2 = Ks2[0]
            self._k = [ks[0]]
        else:
            K2 = Ks2[0][:, None] + Ks2[1][None, :]
            self._k = [ks[0][:, None] * np.ones_like(ks[1])[None, :], np.ones_like(ks[0])[:, None] * ks[1][None, :]]
        K2 = np.array(K2, dtype=float)
        self._zero = K2 == 0.0
        K2[self._zero] = 1.0
        self._invK2 = 1.0 / K2
        self._invK2[self._zero] = 0.0

    def _build_fd(self) -> None:
        g = self.grid
        bc = self.boundary
        if g.dimension == 1:
            A = _laplacian_1d(g.cells[0], float(g.spacing_m[0]), bc)
        else:
            nx, ny = g.cells
            Ax = _laplacian_1d(nx, float(g.spacing_m[0]), bc)
            Ay = _laplacian_1d(ny, float(g.spacing_m[1]), bc)
            A = (sp.kron(Ax, sp.identity(ny)) + sp.kron(sp.identity(nx), Ay)).tocsc()
        self._A = A
        if bc in ("periodic", "neumann"):
            # singular: replace first equation with the gauge condition sum(phi) = 0
            A = A.tolil()
            A[0, :] = 1.0
            A = A.tocsc()
        self._lu = splu(A)
        # boundary contribution of Dirichlet wall values to the rhs (ghost-cell): 2 phi_wall / dx^2
        rhs = np.zeros(g.shape)
        if bc == "dirichlet":
            if g.dimension == 1:
                dx2 = g.spacing_m[0] ** 2
                rhs[0] -= 2.0 * self.phi_lo / dx2
                rhs[-1] -= 2.0 * self.phi_hi / dx2
            else:
                # wall potentials apply on x faces; y faces grounded (phi = 0)
                dx2 = g.spacing_m[0] ** 2
                rhs[0, :] -= 2.0 * self.phi_lo / dx2
                rhs[-1, :] -= 2.0 * self.phi_hi / dx2
        self._rhs_bc = rhs

    # ------------------------------------------------------------------
    def solve(self, rho: np.ndarray) -> PoissonResult:
        """Solve for phi and E given rho (grid.shape) [C/m^3]."""
        g = self.grid
        rho = np.asarray(rho, dtype=float)
        if rho.shape != g.shape:
            raise ValueError(f"rho shape {rho.shape} != grid shape {g.shape}")
        mean = 0.0
        if self.boundary in ("periodic", "neumann"):
            mean = float(rho.mean())
            rho = rho - mean
        src = -rho / VACUUM_PERMITTIVITY
        if self.method in ("fft_fd", "fft_spectral"):
            src_k = np.fft.fftn(src)
            phi_k = -src_k * self._invK2
            phi = np.real(np.fft.ifftn(phi_k))
            if self.method == "fft_spectral":
                E = np.zeros(g.shape + (3,))
                for a in range(g.dimension):
                    E[..., a] = np.real(np.fft.ifftn(-1j * self._k[a] * phi_k))
            else:
                E = self.gradient_field(phi)
        else:
            # ghost-cell wall terms move to the rhs: A phi = src - 2 phi_wall / dx^2
            b = src.ravel() + self._rhs_bc.ravel()
            if self.boundary in ("periodic", "neumann"):
                b = b.copy()
                b[0] = 0.0
            phi = self._lu.solve(b).reshape(g.shape)
            if self.boundary in ("periodic", "neumann"):
                phi -= phi.mean()
            E = self.gradient_field(phi)
        res = self.residual(phi, rho)
        return PoissonResult(phi, E, res, mean)

    def gradient_field(self, phi: np.ndarray) -> np.ndarray:
        """E = -grad(phi) by second-order differences, consistent with the boundary type."""
        g = self.grid
        E = np.zeros(g.shape + (3,))
        for a in range(g.dimension):
            dx = float(g.spacing_m[a])
            if self.boundary == "periodic":
                E[..., a] = -(np.roll(phi, -1, axis=a) - np.roll(phi, 1, axis=a)) / (2.0 * dx)
            else:
                ghost_lo, ghost_hi = self._ghosts(phi, a)
                padded = np.concatenate([ghost_lo, phi, ghost_hi], axis=a)
                sl_p = [slice(None)] * g.dimension
                sl_m = [slice(None)] * g.dimension
                sl_p[a] = slice(2, None)
                sl_m[a] = slice(0, -2)
                E[..., a] = -(padded[tuple(sl_p)] - padded[tuple(sl_m)]) / (2.0 * dx)
        return E

    def _ghosts(self, phi, axis):
        first = np.take(phi, [0], axis=axis)
        last = np.take(phi, [-1], axis=axis)
        if self.boundary == "neumann":
            return first, last
        lo = self.phi_lo if axis == 0 else 0.0
        hi = self.phi_hi if axis == 0 else 0.0
        return 2.0 * lo - first, 2.0 * hi - last

    def apply_laplacian(self, phi: np.ndarray) -> np.ndarray:
        """Discrete Laplacian including boundary ghost cells (for residual checks)."""
        g = self.grid
        out = np.zeros_like(phi)
        for a in range(g.dimension):
            dx2 = float(g.spacing_m[a]) ** 2
            if self.boundary == "periodic":
                out += (np.roll(phi, -1, axis=a) - 2 * phi + np.roll(phi, 1, axis=a)) / dx2
            else:
                lo, hi = self._ghosts(phi, a)
                padded = np.concatenate([lo, phi, hi], axis=a)
                n = phi.shape[a]
                out += (np.take(padded, range(2, n + 2), axis=a) - 2 * phi
                        + np.take(padded, range(0, n), axis=a)) / dx2
        return out

    def residual(self, phi: np.ndarray, rho_neutral: np.ndarray) -> float:
        """Relative residual of the *finite-difference* equation (non-zero for fft_spectral by design)."""
        src = -rho_neutral / VACUUM_PERMITTIVITY
        scale = float(np.max(np.abs(src)))
        r = self.apply_laplacian(phi) - src
        return float(np.max(np.abs(r)) / scale) if scale > 0 else float(np.max(np.abs(r)))
