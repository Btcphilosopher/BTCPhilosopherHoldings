"""Scientific plots derived from PlasmaState / diagnostics (Matplotlib).

This module is an *observer*: it imports Matplotlib lazily and is never
imported by the numerical core.  Every plot labels axes with units, states
the simulation time, species where relevant, and a provenance footer
(solver, configuration hash, seed).

Particle sampling for phase-space plots is deterministic: when a species has
more than ``max_points`` particles, those with ``particle_id % stride == 0``
are shown (stride = ceil(N / max_points)); the sampling is printed on the plot.
"""

from __future__ import annotations

import math

import numpy as np

_AXIS = {"x": 0, "y": 1, "z": 2}


def _plt():
    import matplotlib

    if matplotlib.get_backend().lower() not in ("agg", "pdf", "svg") and not _has_display():
        matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    return plt


def _has_display() -> bool:
    import os

    return bool(os.environ.get("DISPLAY"))


def _footer(fig, metadata: dict | None, extra: str = "") -> None:
    if not metadata:
        if extra:
            fig.text(0.01, 0.005, extra, fontsize=6, color="0.35")
        return
    txt = (f"plasma_core {metadata.get('software_version', '')} | solver {metadata.get('solver', '')} | "
           f"config {str(metadata.get('configuration_hash', ''))[:12]} | seed {metadata.get('random_seed', '')}")
    if extra:
        txt += " | " + extra
    fig.text(0.01, 0.005, txt, fontsize=6, color="0.35")


def _sample(ids: np.ndarray, max_points: int) -> tuple[np.ndarray, str]:
    n = ids.shape[0]
    if n <= max_points:
        return np.ones(n, bool), f"all {n} particles"
    stride = int(math.ceil(n / max_points))
    return ids % stride == 0, f"particles with id % {stride} == 0 ({n} total)"


def phase_space(state, *, x_axis: str = "x", v_axis: str = "vx", max_points: int = 20000, metadata=None, ax=None,
                path=None):
    """Scatter plot of particle phase space (x-vx, x-vy, vx-vy, ...) for every mobile species."""
    plt = _plt()
    if state.particle_positions_m is None:
        raise ValueError("phase-space plots need particle data (PIC/test-particle solvers)")
    fig, ax = (ax.figure, ax) if ax is not None else plt.subplots(figsize=(7, 4.5))

    def coord(name):
        if name.startswith("v"):
            return state.particle_velocities_m_s[:, _AXIS[name[1]]], f"$v_{name[1]}$ [m/s]"
        return state.particle_positions_m[:, _AXIS[name]], f"${name}$ [m]"

    X, xl = coord(x_axis)
    Y, yl = coord(v_axis)
    notes = []
    for i, name in enumerate(state.species_names):
        m = state.particle_species_id == i
        if not m.any():
            continue
        sel, note = _sample(state.particle_ids[m], max_points)
        notes.append(f"{name}: {note}")
        ax.scatter(X[m][sel], Y[m][sel], s=0.5, alpha=0.6, label=name, rasterized=True)
    ax.set_xlabel(xl)
    ax.set_ylabel(yl)
    ax.set_title(f"Phase space {x_axis}-{v_axis}, t = {state.time_s:.4e} s")
    ax.legend(markerscale=10, fontsize=8)
    _footer(fig, metadata, "; ".join(notes) + "; velocities time-centred")
    return _finish(fig, path)


def velocity_distribution(state, *, component: str = "vx", bins: int = 80, metadata=None, ax=None, path=None):
    """Weighted velocity histograms (probability density) per species."""
    plt = _plt()
    fig, ax = (ax.figure, ax) if ax is not None else plt.subplots(figsize=(7, 4.5))
    c = _AXIS[component[1]]
    if state.particle_velocities_m_s is not None:
        for i, name in enumerate(state.species_names):
            m = state.particle_species_id == i
            if m.any():
                ax.hist(state.particle_velocities_m_s[m, c], bins=bins, weights=state.particle_weights[m],
                        density=True, histtype="step", label=name)
        ax.set_ylabel(f"f($v_{component[1]}$) [s/m] (normalised to 1)")
    elif state.distribution_function is not None:
        for name, f in state.extras["distribution_functions"].items():
            v = state.extras["velocity_grids_m_s"][name]
            dv = v[1] - v[0]
            ax.plot(v, f.sum(axis=0) / (f.sum() * dv), label=name)
        ax.set_ylabel("spatially averaged f(v) [s/m] (normalised to 1)")
    ax.set_xlabel(f"$v_{component[1]}$ [m/s]")
    ax.set_title(f"Velocity distribution, t = {state.time_s:.4e} s")
    ax.legend(fontsize=8)
    _footer(fig, metadata)
    return _finish(fig, path)


def density_profile(state, *, metadata=None, ax=None, path=None):
    plt = _plt()
    fig, ax = (ax.figure, ax) if ax is not None else plt.subplots(figsize=(7, 4.5))
    x = state.grid.centres(0)
    nd = state.number_density_m3.reshape((len(state.species_names),) + state.grid.shape)
    for i, name in enumerate(state.species_names):
        prof = nd[i] if state.grid.dimension == 1 else nd[i].mean(axis=1)
        ax.plot(x, prof, label=name)
    ax.set_xlabel("x [m]")
    ax.set_ylabel("number density [m$^{-3}$]" + (" (y-averaged)" if state.grid.dimension == 2 else ""))
    ax.set_title(f"Density, t = {state.time_s:.4e} s")
    ax.legend(fontsize=8)
    _footer(fig, metadata, "CIC deposition at cell centres")
    return _finish(fig, path)


def field_profile(state, *, field: str = "E", components=("x", "y", "z"), magnitude: bool = True, metadata=None,
                  ax=None, path=None):
    """1D profiles of E_x, E_y, E_z (|E|) or B_x, B_y, B_z (|B|) at cell centres."""
    plt = _plt()
    fig, ax = (ax.figure, ax) if ax is not None else plt.subplots(figsize=(7, 4.5))
    arr = state.field_on_grid("electric_field_v_m" if field == "E" else "magnetic_field_t")
    if state.grid.dimension == 2:
        arr = arr.mean(axis=1)
    unit = "V/m" if field == "E" else "T"
    x = state.grid.centres(0)
    for c in components:
        ax.plot(x, arr[:, _AXIS[c]], label=f"${field}_{c}$")
    if magnitude:
        ax.plot(x, np.linalg.norm(arr, axis=1), "k--", lw=0.8, label=f"$|{field}|$")
    ax.set_xlabel("x [m]")
    ax.set_ylabel(f"{field} [{unit}]")
    ax.set_title(f"{'Electric' if field == 'E' else 'Magnetic'} field, t = {state.time_s:.4e} s")
    ax.legend(fontsize=8)
    _footer(fig, metadata, "total field (self-consistent + external) at cell centres")
    return _finish(fig, path)


def field_map_2d(state, *, field: str = "E", component: str = "x", metadata=None, path=None):
    """2D map of one field component with a symmetric (diverging) scale centred on zero."""
    plt = _plt()
    arr = state.field_on_grid("electric_field_v_m" if field == "E" else "magnetic_field_t")[..., _AXIS[component]]
    g = state.grid
    vmax = float(np.max(np.abs(arr))) or 1.0
    fig, ax = plt.subplots(figsize=(6, 5))
    im = ax.pcolormesh(g.edges(0), g.edges(1), arr.T, cmap="RdBu_r", vmin=-vmax, vmax=vmax, shading="flat")
    fig.colorbar(im, ax=ax, label=f"${field}_{component}$ [{'V/m' if field == 'E' else 'T'}]")
    ax.set_xlabel("x [m]")
    ax.set_ylabel("y [m]")
    ax.set_aspect("equal")
    ax.set_title(f"${field}_{component}$, t = {state.time_s:.4e} s")
    _footer(fig, metadata)
    return _finish(fig, path)


def potential_profile(state, *, metadata=None, ax=None, path=None):
    plt = _plt()
    if state.potential_v is None:
        raise ValueError("no potential stored in this state")
    fig, ax = (ax.figure, ax) if ax is not None else plt.subplots(figsize=(7, 4.5))
    phi = state.potential_v.reshape(state.grid.shape)
    ax.plot(state.grid.centres(0), phi if state.grid.dimension == 1 else phi.mean(axis=1))
    ax.set_xlabel("x [m]")
    ax.set_ylabel(r"$\phi$ [V]")
    ax.set_title(f"Electrostatic potential, t = {state.time_s:.4e} s")
    _footer(fig, metadata)
    return _finish(fig, path)


def energy_history(diagnostics, *, metadata=None, path=None, relative: bool = True):
    plt = _plt()
    fig, (a1, a2) = plt.subplots(2, 1, figsize=(7, 6), sharex=True)
    for key, lab in (("kinetic_energy_j", "kinetic"), ("electric_field_energy_j", "electric field"),
                     ("magnetic_field_energy_j", "magnetic field"), ("total_energy_j", "total")):
        t, v = diagnostics.history(key)
        if len(t) and np.any(v != 0):
            a1.plot(t, v, label=lab)
    a1.set_ylabel("energy [J] (per m$^2$ in 1D)")
    a1.set_yscale("symlog", linthresh=1e-30)
    a1.legend(fontsize=8)
    t, e = diagnostics.history("energy_error")
    a2.plot(t, e)
    a2.set_ylabel(r"$(E_{tot}-E_{tot,0})/E_{tot,0}$")
    a2.set_xlabel("t [s]")
    a1.set_title("Energy history")
    _footer(fig, metadata)
    return _finish(fig, path)


def charge_error_history(diagnostics, *, metadata=None, path=None):
    plt = _plt()
    fig, ax = plt.subplots(figsize=(7, 4))
    t, e = diagnostics.history("relative_charge_error")
    ax.semilogy(t, np.maximum(e, 1e-300))
    ax.set_xlabel("t [s]")
    ax.set_ylabel(r"$|Q+Q_{lost}-Q_0|/Q_{abs}$")
    ax.set_title("Charge conservation (values at 1e-300 are exactly zero)")
    _footer(fig, metadata)
    return _finish(fig, path)


def temperature_history(diagnostics, species_names, *, metadata=None, path=None):
    plt = _plt()
    fig, ax = plt.subplots(figsize=(7, 4))
    for n in species_names:
        t, T = diagnostics.history(f"temperature_k__{n}")
        if len(t):
            ax.plot(t, T, label=n)
    ax.set_xlabel("t [s]")
    ax.set_ylabel("T [K]")
    ax.set_title("Temperature (variance estimator)")
    ax.legend(fontsize=8)
    _footer(fig, metadata)
    return _finish(fig, path)


def mode_history(diagnostics, *, name: str = "mode_amp_Ex_m1", log: bool = True, fit=None, metadata=None, path=None):
    plt = _plt()
    fig, ax = plt.subplots(figsize=(7, 4))
    t, a = diagnostics.history(name)
    (ax.semilogy if log else ax.plot)(t, np.abs(a), label=name)
    if fit is not None:
        t0, t1 = fit.fit_interval_s
        m = (t >= t0) & (t <= t1)
        c = np.mean(np.log(np.abs(a[m])) - fit.growth_rate_s * t[m])
        ax.plot(t[m], np.exp(c + fit.growth_rate_s * t[m]), "r--",
                label=f"fit: gamma = {fit.growth_rate_s:.4e} 1/s, R^2 = {fit.r_squared:.4f}")
    ax.set_xlabel("t [s]")
    ax.set_ylabel("Fourier amplitude [V/m]")
    ax.set_title(f"Field mode history: {name}")
    ax.legend(fontsize=8)
    _footer(fig, metadata, "(2/N) |sum_j E_j exp(-i k x_j)|")
    return _finish(fig, path)


def trace_field_line(Bx: np.ndarray, By: np.ndarray, grid, start, *, step_m: float, n_steps: int) -> np.ndarray:
    """Field line through ``start`` traced with RK4 from a *computed* 2D field (cell-centred arrays).

    The direction field B/|B| is bilinearly interpolated from the grid arrays; the
    line stops where |B| = 0 or it leaves a non-periodic domain.
    """
    from scipy.interpolate import RegularGridInterpolator

    xs, ys = grid.centres(0), grid.centres(1)
    ib = RegularGridInterpolator((xs, ys), Bx, bounds_error=False, fill_value=None)
    jb = RegularGridInterpolator((xs, ys), By, bounds_error=False, fill_value=None)

    def direction(p):
        b = np.array([ib(p)[0], jb(p)[0]])
        n = np.linalg.norm(b)
        return b / n if n > 0 else None

    p = np.asarray(start, float)
    pts = [p.copy()]
    lo, hi = np.asarray(grid.lower_m), np.asarray(grid.upper_m)
    for _ in range(n_steps):
        k1 = direction(p)
        if k1 is None:
            break
        k2 = direction(p + 0.5 * step_m * k1)
        k3 = direction(p + 0.5 * step_m * k2) if k2 is not None else None
        k4 = direction(p + step_m * k3) if k3 is not None else None
        if k4 is None:
            break
        p = p + step_m / 6 * (k1 + 2 * k2 + 2 * k3 + k4)
        if np.any(p < lo) or np.any(p > hi):
            break
        pts.append(p.copy())
    return np.asarray(pts)


def field_lines_2d(state, *, field: str = "B", seeds=None, metadata=None, path=None):
    """Field lines in the x-y plane traced from the computed field of a 2D state."""
    plt = _plt()
    g = state.grid
    if g.dimension != 2:
        raise ValueError("field lines need a 2D grid")
    arr = state.field_on_grid("magnetic_field_t" if field == "B" else "electric_field_v_m")
    fig, ax = plt.subplots(figsize=(6, 5))
    if seeds is None:
        seeds = [(x, y) for x in np.linspace(g.lower_m[0], g.upper_m[0], 6)[1:-1]
                 for y in np.linspace(g.lower_m[1], g.upper_m[1], 6)[1:-1]]
    h = 0.5 * float(np.min(g.spacing_m))
    for s in seeds:
        line = trace_field_line(arr[..., 0], arr[..., 1], g, s, step_m=h, n_steps=2000)
        ax.plot(line[:, 0], line[:, 1], lw=0.8)
    ax.set_xlabel("x [m]")
    ax.set_ylabel("y [m]")
    ax.set_aspect("equal")
    ax.set_title(f"{field} field lines (traced from computed field), t = {state.time_s:.4e} s")
    _footer(fig, metadata, "RK4 tracing of the interpolated computed field")
    return _finish(fig, path)


def _finish(fig, path):
    fig.tight_layout(rect=(0, 0.02, 1, 1))
    if path is not None:
        fig.savefig(path, dpi=130)
        import matplotlib.pyplot as plt

        plt.close(fig)
        return path
    return fig
