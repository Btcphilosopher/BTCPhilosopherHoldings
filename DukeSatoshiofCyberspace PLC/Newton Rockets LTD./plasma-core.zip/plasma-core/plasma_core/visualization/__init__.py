"""Scientific visualisation (observer of the numerical state; never imported by the core)."""

from .plots import (
    charge_error_history,
    density_profile,
    energy_history,
    field_lines_2d,
    field_map_2d,
    field_profile,
    mode_history,
    phase_space,
    potential_profile,
    temperature_history,
    trace_field_line,
    velocity_distribution,
)

__all__ = ["phase_space", "velocity_distribution", "density_profile", "field_profile", "field_map_2d",
           "potential_profile", "energy_history", "charge_error_history", "temperature_history", "mode_history",
           "field_lines_2d", "trace_field_line"]
