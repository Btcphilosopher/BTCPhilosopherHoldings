"""Performance benchmarks of the numerical kernels and a complete time step.

Each benchmark reports wall time per call (median of repeats), throughput
(particles/s or cells/s) and peak Python-heap allocation measured with
tracemalloc during one call.  Results depend on hardware; they are
measurements, not targets.
"""

from __future__ import annotations

import statistics
import time
import tracemalloc

import numpy as np

from .backends import get_backend
from .configuration import SimulationConfig
from .grid.spatial_grid import SpatialGrid
from .solvers.poisson import PoissonSolver


def _time(fn, repeats: int) -> tuple[float, int]:
    fn()  # warm-up (and Numba compilation)
    ts = []
    for _ in range(repeats):
        t0 = time.perf_counter()
        fn()
        ts.append(time.perf_counter() - t0)
    tracemalloc.start()
    fn()
    _, peak = tracemalloc.get_traced_memory()
    tracemalloc.stop()
    return statistics.median(ts), peak


def run_benchmarks(n_particles: int = 200_000, n_cells: int = 1024, repeats: int = 5,
                   backends=("cpu_reference", "numba")) -> list[dict]:
    rng = np.random.Generator(np.random.PCG64(0))
    grid = SpatialGrid.uniform(n_cells, 1.0)
    x = np.zeros((n_particles, 3))
    x[:, 0] = rng.random(n_particles)
    v = rng.standard_normal((n_particles, 3)) * 1e5
    E = rng.standard_normal((n_particles, 3))
    B = np.tile([0.0, 0.0, 1e-3], (n_particles, 1))
    qm = np.full(n_particles, -1.758820e11)
    q = np.full(n_particles, -1.6e-19)
    field = rng.standard_normal((n_cells, 3))
    out = []
    for name in backends:
        try:
            be = get_backend(name)
        except Exception as exc:  # pragma: no cover
            out.append({"benchmark": "backend", "backend": name, "error": str(exc)})
            continue
        for label, fn, n in (
            ("particle_push", lambda: be.boris_push(v, E, B, qm, 1e-11), n_particles),
            ("charge_deposition_cic", lambda: be.deposit(x, q, grid, "cic"), n_particles),
            ("field_interpolation_cic", lambda: be.interpolate(field, x, grid, "cic"), n_particles),
        ):
            t, peak = _time(fn, repeats)
            out.append({"benchmark": label, "backend": name, "n": n, "seconds": t, "particles_per_s": n / t,
                        "peak_alloc_mb": peak / 1e6})
    from .pic.current_deposition import deposit_current

    t, peak = _time(lambda: deposit_current(x, v, q, grid, "cic"), repeats)
    out.append({"benchmark": "current_deposition_cic", "backend": "cpu_reference", "n": n_particles, "seconds": t,
                "particles_per_s": n_particles / t, "peak_alloc_mb": peak / 1e6})
    for method in ("fft_fd", "fd"):
        ps = PoissonSolver(grid, method)
        rho = rng.standard_normal(n_cells)
        t, peak = _time(lambda: ps.solve(rho), repeats)
        out.append({"benchmark": f"poisson_{method}_1d", "backend": "cpu_reference", "n": n_cells, "seconds": t,
                    "cells_per_s": n_cells / t, "peak_alloc_mb": peak / 1e6})
    g2 = SpatialGrid.uniform((256, 256), 1.0)
    ps2 = PoissonSolver(g2, "fft_fd")
    rho2 = rng.standard_normal((256, 256))
    t, peak = _time(lambda: ps2.solve(rho2), repeats)
    out.append({"benchmark": "poisson_fft_fd_2d_256x256", "backend": "cpu_reference", "n": 65536, "seconds": t,
                "cells_per_s": 65536 / t, "peak_alloc_mb": peak / 1e6})
    # complete ES-PIC step and diagnostics
    from .simulation.simulation import PlasmaSimulation

    for name in backends:
        cfg = SimulationConfig.from_dict({
            "solver": {"type": "electrostatic_pic", "backend": name}, "domain": {"length_m": 1.0},
            "grid": {"cells": n_cells},
            "species": [{"preset": "electron", "density_m3": 1e12, "temperature_ev": 1.0},
                        {"preset": "proton", "density_m3": 1e12, "mobile": False}],
            "particles": {"count": n_particles},
            "time": {"dt_s": 1e-10, "duration_s": 1e-8, "stability_policy": "warn"},
            "random_seed": 0})
        sim = PlasmaSimulation(cfg)
        import warnings

        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            sim.initialize()
        t, peak = _time(sim.model.step, repeats)
        out.append({"benchmark": "complete_es_pic_timestep", "backend": name, "n": n_particles, "seconds": t,
                    "particles_per_s": n_particles / t, "timesteps_per_s": 1 / t, "peak_alloc_mb": peak / 1e6})
        t, peak = _time(lambda: sim.diagnostics.record(sim.model.observe(), force=True), max(1, repeats // 2))
        out.append({"benchmark": "diagnostics_full_sample", "backend": name, "n": n_particles, "seconds": t,
                    "particles_per_s": n_particles / t, "peak_alloc_mb": peak / 1e6})
    return out


def format_benchmarks(rows: list[dict]) -> str:
    lines = [f"{'benchmark':<30s} {'backend':<14s} {'n':>9s} {'time [ms]':>10s} {'throughput':>16s} {'peak MB':>8s}"]
    for r in rows:
        if "error" in r:
            lines.append(f"{r['benchmark']:<30s} {r['backend']:<14s} unavailable: {r['error'].splitlines()[0]}")
            continue
        thr = r.get("particles_per_s") or r.get("cells_per_s")
        unit = "part/s" if "particles_per_s" in r else "cells/s"
        lines.append(f"{r['benchmark']:<30s} {r['backend']:<14s} {r['n']:>9d} {1e3 * r['seconds']:>10.3f} "
                     f"{thr:>10.3e} {unit:<6s}{r['peak_alloc_mb']:>8.1f}")
    return "\n".join(lines)
