"""Particle storage as contiguous structure-of-arrays.

Shapes (N = number of macro-particles):

=================  ===========  ======  ==========================================
attribute          shape        dtype   meaning / unit
=================  ===========  ======  ==========================================
positions          (N, 3)       f8      x, y, z [m]
velocities         (N, 3)       f8      vx, vy, vz [m/s]
species_id         (N,)         i4      index into the configuration species list
weights            (N,)         f8      physical particles per macro-particle [-]
particle_ids       (N,)         i8      unique, persistent identifiers
=================  ===========  ======  ==========================================

In a 1D (2D) simulation the y, z (z) positions are ignorable coordinates:
they are advanced (x += v dt) so that full 3D trajectories are available,
but fields do not depend on them and no boundary is applied to them.

Time centring
-------------
In the leapfrog PIC loop velocities are stored at half-integer times.
``velocity_time_offset`` records the offset in units of dt (``-0.5`` means
v^{n-1/2} is stored while positions are at t^n).  It is ``0.0`` only right
after loading and before the initial half-step back-push.

Memory: 8*(3+3+1) + 4 + 8 = 68 bytes per particle (plus temporary arrays of
O(N*3*8) bytes during the push and interpolation).
"""

from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np


@dataclass
class ParticleState:
    positions: np.ndarray
    velocities: np.ndarray
    species_id: np.ndarray
    weights: np.ndarray
    particle_ids: np.ndarray
    velocity_time_offset: float = 0.0
    _next_id: int = field(default=-1, repr=False)

    def __post_init__(self) -> None:
        self.positions = np.ascontiguousarray(self.positions, dtype=np.float64)
        self.velocities = np.ascontiguousarray(self.velocities, dtype=np.float64)
        self.species_id = np.ascontiguousarray(self.species_id, dtype=np.int32)
        self.weights = np.ascontiguousarray(self.weights, dtype=np.float64)
        self.particle_ids = np.ascontiguousarray(self.particle_ids, dtype=np.int64)
        n = self.positions.shape[0]
        if self.positions.shape != (n, 3) or self.velocities.shape != (n, 3):
            raise ValueError("positions and velocities must have shape (N, 3)")
        for name in ("species_id", "weights", "particle_ids"):
            if getattr(self, name).shape != (n,):
                raise ValueError(f"{name} must have shape (N,)")
        if self._next_id < 0:
            self._next_id = int(self.particle_ids.max()) + 1 if n else 0

    @classmethod
    def empty(cls) -> "ParticleState":
        return cls(np.zeros((0, 3)), np.zeros((0, 3)), np.zeros(0, np.int32), np.zeros(0), np.zeros(0, np.int64))

    @classmethod
    def concatenate(cls, parts: list["ParticleState"]) -> "ParticleState":
        """Concatenate populations; particle ids are re-assigned 0..N-1 in order."""
        if not parts:
            return cls.empty()
        pos = np.concatenate([p.positions for p in parts])
        vel = np.concatenate([p.velocities for p in parts])
        sid = np.concatenate([p.species_id for p in parts])
        w = np.concatenate([p.weights for p in parts])
        ids = np.arange(pos.shape[0], dtype=np.int64)
        return cls(pos, vel, sid, w, ids, parts[0].velocity_time_offset)

    @property
    def n(self) -> int:
        return int(self.positions.shape[0])

    def species_mask(self, species_index: int) -> np.ndarray:
        return self.species_id == species_index

    def count_by_species(self, n_species: int) -> np.ndarray:
        return np.bincount(self.species_id, minlength=n_species)

    def weight_by_species(self, n_species: int) -> np.ndarray:
        return np.bincount(self.species_id, weights=self.weights, minlength=n_species)

    def remove(self, mask: np.ndarray) -> None:
        """Remove particles where ``mask`` is True (compacts arrays, preserves order)."""
        keep = ~mask
        self.positions = np.ascontiguousarray(self.positions[keep])
        self.velocities = np.ascontiguousarray(self.velocities[keep])
        self.species_id = np.ascontiguousarray(self.species_id[keep])
        self.weights = np.ascontiguousarray(self.weights[keep])
        self.particle_ids = np.ascontiguousarray(self.particle_ids[keep])

    def copy(self) -> "ParticleState":
        return ParticleState(self.positions.copy(), self.velocities.copy(), self.species_id.copy(),
                             self.weights.copy(), self.particle_ids.copy(), self.velocity_time_offset,
                             self._next_id)

    def memory_bytes(self) -> int:
        return sum(a.nbytes for a in (self.positions, self.velocities, self.species_id, self.weights, self.particle_ids))

    def arrays(self) -> dict[str, np.ndarray]:
        return {"positions_m": self.positions, "velocities_m_s": self.velocities, "species_id": self.species_id,
                "weights": self.weights, "particle_ids": self.particle_ids}
