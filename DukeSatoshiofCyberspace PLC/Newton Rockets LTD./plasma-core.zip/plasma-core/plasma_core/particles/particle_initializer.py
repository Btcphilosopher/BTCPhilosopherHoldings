"""Low-level particle samplers.

All randomness comes from an explicit :class:`numpy.random.Generator`
created from a recorded seed; no global random state is ever used.

Position loading
----------------
``random``  independent uniform positions (Poisson noise in density).
``quiet``   deterministic low-discrepancy positions:
            1D: regular lattice x_i = lo + (i + 1/2) L / N;
            2D: Hammersley set x_i = (i + 1/2)/N, y_i = van der Corput(i) (base 2).

Velocity loading
----------------
``random``  u + v_th * N(0, 1) per component, v_th = sqrt(kT/m).
``quiet``   inverse-CDF ("quiet start") sampling on deterministic quantiles
            u_i = (i + 1/2)/N, v = u + v_th sqrt(2) erfinv(2 u_i - 1); the quantile
            set of each component is independently permuted with the Generator
            to remove position-velocity correlation.  Sample mean and variance
            then equal the target values up to O(1/N) quadrature error.
"""

from __future__ import annotations

import numpy as np
from scipy.special import erfinv

from ..constants import BOLTZMANN_CONSTANT
from ..grid.spatial_grid import SpatialGrid


def make_generator(seed: int | np.random.SeedSequence) -> np.random.Generator:
    """PCG64 generator from an explicit seed (int or SeedSequence)."""
    return np.random.Generator(np.random.PCG64(seed))


def species_seed_sequences(random_seed: int, n_species: int) -> list[np.random.SeedSequence]:
    """Independent seed sequences: one per species plus one (last) for runtime stochastic operators."""
    return np.random.SeedSequence(random_seed).spawn(n_species + 1)


def _van_der_corput(n: int, base: int = 2) -> np.ndarray:
    out = np.zeros(n)
    i = np.arange(n, dtype=np.int64)
    denom = 1.0
    while np.any(i > 0):
        denom *= base
        out += (i % base) / denom
        i //= base
    return out


def sample_positions(grid: SpatialGrid, count: int, rng: np.random.Generator, loading: str = "random") -> np.ndarray:
    """Positions (count, 3) uniformly filling the grid domain; unused axes are zero."""
    pos = np.zeros((count, 3))
    lo = np.asarray(grid.lower_m)
    L = grid.lengths_m
    if loading == "random":
        for a in range(grid.dimension):
            pos[:, a] = lo[a] + L[a] * rng.random(count)
    elif loading == "quiet":
        u = (np.arange(count) + 0.5) / count
        pos[:, 0] = lo[0] + L[0] * u
        if grid.dimension >= 2:
            pos[:, 1] = lo[1] + L[1] * (_van_der_corput(count) + 0.5 / count)
        if grid.dimension == 3:
            pos[:, 2] = lo[2] + L[2] * (_van_der_corput(count, 3) + 0.5 / count)
    else:
        raise ValueError(f"unknown position loading '{loading}'")
    return pos


def sample_maxwellian_velocities(count: int, temperature_k: float, mass_kg: float, bulk_velocity_m_s,
                                 rng: np.random.Generator, loading: str = "random") -> np.ndarray:
    """Isotropic drifting Maxwellian velocities (count, 3) [m/s]."""
    bulk = np.asarray(bulk_velocity_m_s, dtype=float).reshape(3)
    vt = np.sqrt(BOLTZMANN_CONSTANT * temperature_k / mass_kg)
    return bulk + vt * standard_normal_samples(count, 3, rng, loading)


def standard_normal_samples(count: int, components: int, rng: np.random.Generator, loading: str) -> np.ndarray:
    if loading == "random":
        return rng.standard_normal((count, components))
    if loading == "quiet":
        q = (np.arange(count) + 0.5) / count
        base = np.sqrt(2.0) * erfinv(2.0 * q - 1.0)
        return np.stack([rng.permutation(base) for _ in range(components)], axis=1)
    raise ValueError(f"unknown velocity loading '{loading}'")


def macro_particle_weight(density_m3: float, grid: SpatialGrid, count: int) -> float:
    """Physical particles per macro-particle: n * V_domain / N (V per unit transverse extent)."""
    return density_m3 * grid.domain_volume_m3 / count
