"""Non-relativistic Boris particle pusher (vectorised).

Algorithm (Boris 1970; see Birdsall & Langdon 1991, sec. 4-3), advancing
v^{n-1/2} -> v^{n+1/2} with fields E^n, B^n at x^n and q/m:

1. half electric acceleration     v-  = v^{n-1/2} + (q/m) E dt/2
2. magnetic rotation              t   = (q/m) B dt/2
                                  s   = 2 t / (1 + |t|^2)
                                  v'  = v- + v- x t
                                  v+  = v- + v' x s
3. half electric acceleration     v^{n+1/2} = v+ + (q/m) E dt/2

Properties: the rotation conserves |v| exactly (to round-off); it is
time-reversible; the rotation angle per step is 2 arctan(omega_c dt/2), so the
numerical gyrofrequency is (2/dt) arctan(omega_c dt/2) (phase error
~ (omega_c dt)^2/12); the E x B drift is reproduced exactly for uniform
fields.  The pusher is non-relativistic: it is valid only for |v| << c, and
the stability monitor stops a run if |v| >= c.
"""

from __future__ import annotations

import numpy as np


def _as_column(qm) -> np.ndarray | float:
    qm = np.asarray(qm, dtype=np.float64)
    return qm[:, None] if qm.ndim == 1 else qm


def boris_half_electric(v: np.ndarray, E: np.ndarray, q_over_m, dt: float) -> None:
    """In-place v += (q/m) E dt/2."""
    v += _as_column(q_over_m) * E * (0.5 * dt)


def boris_magnetic_rotation(v: np.ndarray, B: np.ndarray, q_over_m, dt: float) -> None:
    """In-place Boris rotation of v about B over dt (|v| preserved)."""
    t = _as_column(q_over_m) * np.broadcast_to(B, v.shape) * (0.5 * dt)
    t2 = np.einsum("ij,ij->i", t, t)[:, None]
    s = 2.0 * t / (1.0 + t2)
    v_prime = v + np.cross(v, t)
    v += np.cross(v_prime, s)


def boris_push(v: np.ndarray, E: np.ndarray, B: np.ndarray, q_over_m, dt: float, *, out: np.ndarray | None = None) -> np.ndarray:
    """Advance velocities one step with the Boris scheme.

    Parameters
    ----------
    v : (N, 3) velocities at t - dt/2 [m/s]
    E, B : (N, 3) or (3,) fields at the particle positions [V/m], [T]
    q_over_m : scalar or (N,) [C/kg]
    dt : time step [s] (negative dt integrates backwards)
    out : optional output array (may be ``v`` itself for an in-place push)
    """
    if out is None:
        out = np.array(v, dtype=np.float64, copy=True)
    elif out is not v:
        out[...] = v
    E = np.broadcast_to(np.asarray(E, dtype=np.float64), out.shape)
    boris_half_electric(out, E, q_over_m, dt)
    if np.any(np.asarray(B) != 0.0):
        boris_magnetic_rotation(out, np.asarray(B, dtype=np.float64), q_over_m, dt)
    boris_half_electric(out, E, q_over_m, dt)
    return out


def advance_positions(x: np.ndarray, v: np.ndarray, dt: float) -> None:
    """In-place x += v dt (all three components)."""
    x += v * dt
