"""Particle boundary conditions.

Each boundary acts on one spatial axis of the grid (x, or x and y in 2D) and
modifies the :class:`ParticleState` in place.  Removed particles are
accounted in a :class:`ParticleLossLedger` (number, physical weight, charge
and kinetic energy, per species and per wall).

=============  ==============================================================
Periodic       x <- lower + (x - lower) mod L
Reflecting     specular: x <- 2 wall - x, v_axis <- -v_axis
Absorbing      particles leaving the domain are removed and recorded as lost
               (physical model: perfectly absorbing / grounded wall)
Open           outflow only: identical removal and accounting to absorbing,
               recorded separately as ``outflow``; no particles are injected.
=============  ==============================================================

A reflecting wall assumes the particle crossed at most one wall per step
(guaranteed by the particle CFL check dx > v dt).
"""

from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np

from .particle_state import ParticleState


@dataclass
class ParticleLossLedger:
    n_species: int
    particles_lost: np.ndarray = field(default=None)  # type: ignore[assignment]
    weight_lost: np.ndarray = field(default=None)  # type: ignore[assignment]
    charge_lost_c: np.ndarray = field(default=None)  # type: ignore[assignment]
    energy_lost_j: np.ndarray = field(default=None)  # type: ignore[assignment]
    lost_low_wall: np.ndarray = field(default=None)  # type: ignore[assignment]
    lost_high_wall: np.ndarray = field(default=None)  # type: ignore[assignment]

    def __post_init__(self) -> None:
        for name in ("particles_lost", "lost_low_wall", "lost_high_wall"):
            if getattr(self, name) is None:
                setattr(self, name, np.zeros(self.n_species, dtype=np.int64))
        for name in ("weight_lost", "charge_lost_c", "energy_lost_j"):
            if getattr(self, name) is None:
                setattr(self, name, np.zeros(self.n_species))

    def record(self, ps: ParticleState, mask: np.ndarray, charges: np.ndarray, masses: np.ndarray,
               low_side: np.ndarray, cell_area_m2: float) -> None:
        """Record removal of ``ps[mask]``.  Extensive quantities are per unit transverse area in 1D
        (multiplying by the cell transverse area, 1 m^2 for 1D)."""
        if not mask.any():
            return
        sid = ps.species_id[mask]
        w = ps.weights[mask]
        v2 = np.einsum("ij,ij->i", ps.velocities[mask], ps.velocities[mask])
        ns = self.n_species
        self.particles_lost += np.bincount(sid, minlength=ns)
        self.lost_low_wall += np.bincount(sid[low_side[mask]], minlength=ns)
        self.lost_high_wall += np.bincount(sid[~low_side[mask]], minlength=ns)
        self.weight_lost += np.bincount(sid, weights=w, minlength=ns)
        self.charge_lost_c += np.bincount(sid, weights=w * charges[sid], minlength=ns)
        self.energy_lost_j += np.bincount(sid, weights=0.5 * masses[sid] * w * v2, minlength=ns)

    def to_dict(self) -> dict:
        return {k: getattr(self, k).tolist() for k in ("particles_lost", "weight_lost", "charge_lost_c",
                                                       "energy_lost_j", "lost_low_wall", "lost_high_wall")}

    @classmethod
    def from_dict(cls, n_species: int, d: dict) -> "ParticleLossLedger":
        led = cls(n_species)
        for k, v in d.items():
            setattr(led, k, np.asarray(v, dtype=getattr(led, k).dtype))
        return led


class ParticleBoundary:
    """Base class.  ``apply`` modifies particles in place along ``axis``."""

    name = "abstract"

    def apply(self, ps: ParticleState, axis: int, lower: float, upper: float, ledger: ParticleLossLedger,
              charges: np.ndarray, masses: np.ndarray) -> int:
        raise NotImplementedError


class PeriodicParticleBoundary(ParticleBoundary):
    name = "periodic"

    def apply(self, ps, axis, lower, upper, ledger, charges, masses) -> int:
        x = ps.positions[:, axis]
        L = upper - lower
        out = (x < lower) | (x >= upper)
        if out.any():
            xo = lower + np.mod(x[out] - lower, L)
            # guard against x == upper after round-off in mod
            xo[xo >= upper] = lower
            x[out] = xo
        return 0


class ReflectingParticleBoundary(ParticleBoundary):
    name = "reflecting"

    def apply(self, ps, axis, lower, upper, ledger, charges, masses) -> int:
        x = ps.positions[:, axis]
        v = ps.velocities[:, axis]
        lo = x < lower
        if lo.any():
            x[lo] = 2.0 * lower - x[lo]
            v[lo] = -v[lo]
        hi = x >= upper
        if hi.any():
            x[hi] = np.nextafter(2.0 * upper - x[hi], lower)
            v[hi] = -v[hi]
        return 0


class AbsorbingParticleBoundary(ParticleBoundary):
    name = "absorbing"

    def apply(self, ps, axis, lower, upper, ledger, charges, masses) -> int:
        x = ps.positions[:, axis]
        lo = x < lower
        out = lo | (x >= upper)
        n_out = int(out.sum())
        if n_out:
            ledger.record(ps, out, charges, masses, lo, 1.0)
            ps.remove(out)
        return n_out


class OpenParticleBoundary(AbsorbingParticleBoundary):
    """Outflow boundary: particles leaving are removed and accounted; nothing is injected."""

    name = "open"


PARTICLE_BOUNDARIES = {
    "periodic": PeriodicParticleBoundary,
    "reflecting": ReflectingParticleBoundary,
    "absorbing": AbsorbingParticleBoundary,
    "open": OpenParticleBoundary,
}
