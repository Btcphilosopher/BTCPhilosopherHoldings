"""Plasma state snapshot: the authoritative, observable state at one instant.

A :class:`PlasmaState` is produced by a model's ``observe()`` method at an
integer time level t^n.  Diagnostics, output and visualisation are computed
*from this object only*.

Shape conventions
-----------------
N_s = number of species (including immobile backgrounds), N_c = number of
grid cells (``grid.n_cells``; multi-dimensional grids flattened in C order,
x slowest), N_p = number of macro-particles.

==========================  ===============  ===============================================
attribute                   shape            unit / meaning
==========================  ===============  ===============================================
time_s                      scalar           [s]
number_density_m3           (N_s, N_c)       [m^-3]  per species (background: uniform)
charge_density_c_m3         (N_c,)           [C m^-3] total, including backgrounds
current_density_a_m2        (N_c, 3)         [A m^-2] (time-centred velocities)
electric_field_v_m          (N_c, 3)         [V/m] at cell centres, total (self + external)
magnetic_field_t            (N_c, 3)         [T]   at cell centres, total (self + external)
potential_v                 (N_c,) or None   [V]   electrostatic potential (if computed)
particle_positions_m        (N_p, 3) / None  [m]
particle_velocities_m_s     (N_p, 3) / None  [m/s] time-synchronised to time_s (see below)
particle_species_id         (N_p,)   / None
particle_weights            (N_p,)   / None
particle_ids                (N_p,)   / None
distribution_function       (N_c, N_v)/None  Vlasov f(x, v) [s m^-4], first mobile species
species_temperature_k       (N_s,)           [K]  3D-isotropic estimator (see diagnostics.temperature)
electron_temperature_k      scalar           [K]  weighted over species with q<0 (nan if none)
ion_temperature_k           scalar           [K]  weighted over mobile species with q>0
kinetic_energy_j            scalar           [J]  (per unit transverse area in 1D, per length in 2D)
electric_field_energy_j     scalar           [J]
magnetic_field_energy_j     scalar           [J]  self-consistent field only (external excluded)
field_energy_j              scalar           [J]  electric + magnetic
total_energy_j              scalar           [J]  kinetic + field
total_charge_c              scalar           [C]  sum over particles + backgrounds
total_momentum_kg_m_s       (3,)             [kg m/s] particle momentum (see diagnostics.momentum)
==========================  ===============  ===============================================

Time synchronisation
--------------------
Leapfrog schemes store v^{n-1/2}.  ``particle_velocities_m_s`` is the
time-centred average (v^{n-1/2} + v^{n+1/2})/2, and the kinetic energy is
sum m w (|v^{n-1/2}|^2 + |v^{n+1/2}|^2)/4 (Birdsall & Langdon); v^{n+1/2} is
obtained from a non-mutating trial push.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

import numpy as np

from .grid.spatial_grid import SpatialGrid
from .units import UnitSystem


@dataclass
class PlasmaState:
    time_s: float
    step: int
    grid: SpatialGrid
    species_names: list[str]
    number_density_m3: np.ndarray
    charge_density_c_m3: np.ndarray
    current_density_a_m2: np.ndarray
    electric_field_v_m: np.ndarray
    magnetic_field_t: np.ndarray
    species_temperature_k: np.ndarray
    electron_temperature_k: float
    ion_temperature_k: float
    kinetic_energy_j: float
    electric_field_energy_j: float
    magnetic_field_energy_j: float
    total_charge_c: float
    total_momentum_kg_m_s: np.ndarray
    potential_v: np.ndarray | None = None
    particle_positions_m: np.ndarray | None = None
    particle_velocities_m_s: np.ndarray | None = None
    particle_species_id: np.ndarray | None = None
    particle_weights: np.ndarray | None = None
    particle_ids: np.ndarray | None = None
    distribution_function: np.ndarray | None = None
    velocity_grid_m_s: np.ndarray | None = None
    unit_system: UnitSystem = UnitSystem.SI
    solver: str = ""
    extras: dict[str, Any] = field(default_factory=dict)

    @property
    def field_energy_j(self) -> float:
        return self.electric_field_energy_j + self.magnetic_field_energy_j

    @property
    def total_energy_j(self) -> float:
        return self.kinetic_energy_j + self.field_energy_j

    def field_on_grid(self, name: str) -> np.ndarray:
        """Reshape a flattened (N_c, ...) field to ``grid.shape + (...)`` (a view)."""
        arr = getattr(self, name)
        return arr.reshape(self.grid.shape + arr.shape[1:])

    def summary(self) -> dict[str, float]:
        return {
            "time_s": self.time_s,
            "kinetic_energy_j": self.kinetic_energy_j,
            "electric_field_energy_j": self.electric_field_energy_j,
            "magnetic_field_energy_j": self.magnetic_field_energy_j,
            "total_energy_j": self.total_energy_j,
            "total_charge_c": self.total_charge_c,
        }
