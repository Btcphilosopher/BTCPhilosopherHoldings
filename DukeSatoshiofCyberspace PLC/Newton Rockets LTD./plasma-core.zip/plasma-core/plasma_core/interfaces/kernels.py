"""Numerical-kernel boundary for external implementations (Rust, CUDA, custom hardware).

The physics layer only requires implementations of
:class:`plasma_core.backends.base.Backend`.  An external library (e.g. a
Rust crate via PyO3, a CUDA module, or a future Silica Flux device driver)
provides a Backend subclass; :func:`validate_backend` checks it against the
CPU reference implementation on randomised inputs before it may be used.
No hardware-specific assumption enters the physics modules.
"""

from __future__ import annotations

import numpy as np

from ..backends.base import Backend
from ..backends.cpu_reference import CPUReferenceBackend
from ..grid.spatial_grid import SpatialGrid


def validate_backend(backend: Backend, *, n_particles: int = 10_000, n_cells: int = 64, rtol: float = 1e-12,
                     seed: int = 0) -> dict[str, float]:
    """Max relative differences between ``backend`` and the reference kernels; raises if > rtol."""
    rng = np.random.Generator(np.random.PCG64(seed))
    ref = CPUReferenceBackend()
    grid = SpatialGrid.uniform(n_cells, 1.0)
    x = np.zeros((n_particles, 3))
    x[:, 0] = rng.random(n_particles)
    v = rng.standard_normal((n_particles, 3))
    E = rng.standard_normal((n_particles, 3))
    B = rng.standard_normal((n_particles, 3))
    qm = rng.standard_normal(n_particles)
    w = rng.random(n_particles)
    F = rng.standard_normal((n_cells, 3))
    out = {}
    for shape in ("ngp", "cic"):
        a, b = ref.deposit(x, w, grid, shape), backend.deposit(x, w, grid, shape)
        out[f"deposit_{shape}"] = float(np.max(np.abs(a - b)) / np.max(np.abs(a)))
        a, b = ref.interpolate(F, x, grid, shape), backend.interpolate(F, x, grid, shape)
        out[f"interpolate_{shape}"] = float(np.max(np.abs(a - b)) / np.max(np.abs(a)))
    a, b = ref.boris_push(v, E, B, qm, 0.1), backend.boris_push(v, E, B, qm, 0.1)
    out["boris_push"] = float(np.max(np.abs(a - b)) / np.max(np.abs(a)))
    bad = {k: val for k, val in out.items() if not val <= rtol}
    if bad:
        raise AssertionError(f"backend {backend.name} disagrees with reference: {bad}")
    return out
