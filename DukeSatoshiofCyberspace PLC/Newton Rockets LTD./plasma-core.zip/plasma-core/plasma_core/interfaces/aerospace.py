"""Interface for future Newton Rockets / Newton Orbital modules.

Inputs a host module may provide: plasma environment (species, densities,
temperatures, drifts), magnetic and electric fields, particle populations
and spacecraft geometry.  Outputs plasma_core can return: particle flux,
energy deposition, charge accumulation, field interaction and plasma
diagnostics.

Status
------
*Spacecraft interaction is not implemented.*  Only the data contracts are
defined.  The single concrete adapter, :func:`wall_flux_from_simulation`,
converts the loss ledger of a 1D run with absorbing walls into wall fluxes -
a well-defined quantity of the current solver, not a spacecraft model.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field

from ..species import Species


@dataclass
class PlasmaEnvironment:
    species: list[Species]
    magnetic_field_t: tuple[float, float, float] = (0.0, 0.0, 0.0)
    electric_field_v_m: tuple[float, float, float] = (0.0, 0.0, 0.0)
    description: str = ""


@dataclass
class SpacecraftGeometry:
    """Placeholder for a surface description (not used by any solver yet)."""

    name: str
    surface_area_m2: float
    description: str = ""


@dataclass
class PlasmaInteractionResult:
    particle_flux_m2_s: dict[str, float] = field(default_factory=dict)      # per species, per wall
    energy_flux_w_m2: dict[str, float] = field(default_factory=dict)
    charge_accumulated_c_m2: dict[str, float] = field(default_factory=dict)
    field_interaction: dict = field(default_factory=dict)
    diagnostics: dict = field(default_factory=dict)
    model: str = ""


class SpacecraftInteractionModel(ABC):
    """Extension point: compute interaction of a plasma environment with a body."""

    @abstractmethod
    def compute(self, environment: PlasmaEnvironment, geometry: SpacecraftGeometry) -> PlasmaInteractionResult:
        raise NotImplementedError("spacecraft-plasma interaction is a planned extension")


def wall_flux_from_simulation(sim) -> PlasmaInteractionResult:
    """Time-averaged fluxes to the absorbing walls of a 1D simulation (per unit wall area).

    flux = (particles lost to the wall x weight) / (elapsed time)   [m^-2 s^-1]
    """
    if sim.config.boundaries.particles not in ("absorbing", "open") or sim.grid.dimension != 1:
        raise ValueError("wall fluxes require a 1D simulation with absorbing/open boundaries")
    led = sim.model.ledger
    T = sim.time_s
    res = PlasmaInteractionResult(model="1D absorbing-wall loss ledger (time average over the run)")
    for i, s in enumerate(sim.config.species):
        if not s.mobile:
            continue
        res.particle_flux_m2_s[s.name] = float(led.weight_lost[i] / T) if T > 0 else 0.0
        res.energy_flux_w_m2[s.name] = float(led.energy_lost_j[i] / T) if T > 0 else 0.0
        res.charge_accumulated_c_m2[s.name] = float(led.charge_lost_c[i])
    res.diagnostics = {"elapsed_s": T, "walls": "both walls combined; per-wall counts in ledger", **led.to_dict()}
    return res
