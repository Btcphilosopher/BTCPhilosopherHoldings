"""Interfaces to future host systems (aerospace modules, external kernels)."""

from .aerospace import (
    PlasmaEnvironment,
    PlasmaInteractionResult,
    SpacecraftGeometry,
    SpacecraftInteractionModel,
    wall_flux_from_simulation,
)
from .kernels import validate_backend

__all__ = ["PlasmaEnvironment", "PlasmaInteractionResult", "SpacecraftGeometry", "SpacecraftInteractionModel",
           "wall_flux_from_simulation", "validate_backend"]
