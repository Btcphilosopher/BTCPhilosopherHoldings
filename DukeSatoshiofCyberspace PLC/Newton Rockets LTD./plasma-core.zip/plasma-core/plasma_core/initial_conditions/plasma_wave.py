"""Small-amplitude plasma-wave perturbation by particle displacement.

A particle loaded at x0 is displaced to

    x = x0 - (A / k) sin(k (x0 - x_lo) + phi),     k = 2 pi m / L,

which produces, to first order in A, the density

    n(x) = n0 [1 + A cos(k (x - x_lo) + phi)].

Velocities are left unperturbed, so the initial state is a superposition of
the +omega and -omega normal modes (a standing wave).  The subsequent
oscillation is computed entirely by the field solver and pusher: no wave is
imposed on the output.
"""

from __future__ import annotations

import numpy as np

from ..grid.spatial_grid import SpatialGrid
from ..particles.particle_state import ParticleState
from .maxwellian import maxwellian


def apply_density_perturbation(positions: np.ndarray, grid: SpatialGrid, *, mode: int, amplitude: float,
                               phase_rad: float = 0.0, axis: int = 0) -> None:
    """Displace ``positions`` in place (periodic wrap must be applied afterwards)."""
    if amplitude == 0.0:
        return
    if not 0.0 <= amplitude < 1.0:
        raise ValueError("amplitude must satisfy 0 <= A < 1 (|delta n / n| < 1)")
    k = grid.mode_wavenumber(mode, axis)
    lo = grid.lower_m[axis]
    x0 = positions[:, axis]
    positions[:, axis] = x0 - (amplitude / k) * np.sin(k * (x0 - lo) + phase_rad)
    L = grid.lengths_m[axis]
    positions[:, axis] = lo + np.mod(positions[:, axis] - lo, L)


def plasma_wave(grid: SpatialGrid, *, temperature_k: float, density_m3: float, bulk_velocity_m_s=(0, 0, 0),
                particle_count: int, mass_kg: float, mode: int = 1, amplitude: float = 0.01,
                phase_rad: float = 0.0, axis: int = 0, rng=None, random_seed=None, species_id: int = 0,
                position_loading: str = "quiet", velocity_loading: str = "random") -> ParticleState:
    """Maxwellian population with a density perturbation of given mode/amplitude/phase."""
    ps = maxwellian(grid, temperature_k=temperature_k, density_m3=density_m3, bulk_velocity_m_s=bulk_velocity_m_s,
                    particle_count=particle_count, mass_kg=mass_kg, rng=rng, random_seed=random_seed,
                    species_id=species_id, position_loading=position_loading, velocity_loading=velocity_loading)
    apply_density_perturbation(ps.positions, grid, mode=mode, amplitude=amplitude, phase_rad=phase_rad, axis=axis)
    return ps
