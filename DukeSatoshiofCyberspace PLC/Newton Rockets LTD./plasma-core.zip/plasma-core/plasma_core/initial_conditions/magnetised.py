"""Magnetised particle populations.

Bi-Maxwellian about the magnetic-field direction b = B/|B|:

    f ~ exp(-m v_par^2 / (2 k T_par) - m v_perp^2 / (2 k T_perp))

with v_par = v . b and v_perp the two components orthogonal to b.
:func:`gyrating_particle` builds the single-particle state used for
gyro-motion validation (helical orbit with prescribed v_par, v_perp).
"""

from __future__ import annotations

import numpy as np

from ..constants import BOLTZMANN_CONSTANT
from ..grid.spatial_grid import SpatialGrid
from ..particles.particle_initializer import (
    macro_particle_weight,
    sample_positions,
    standard_normal_samples,
)
from ..particles.particle_state import ParticleState


def field_aligned_basis(B) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Orthonormal (e1, e2, b) with b = B/|B|."""
    b = np.asarray(B, dtype=float)
    nb = np.linalg.norm(b)
    if nb == 0:
        raise ValueError("magnetic field must be non-zero")
    b = b / nb
    trial = np.array([1.0, 0.0, 0.0]) if abs(b[0]) < 0.9 else np.array([0.0, 1.0, 0.0])
    e1 = trial - np.dot(trial, b) * b
    e1 /= np.linalg.norm(e1)
    e2 = np.cross(b, e1)
    return e1, e2, b


def bi_maxwellian_velocities(count: int, temperature_parallel_k: float, temperature_perpendicular_k: float,
                             mass_kg: float, magnetic_field_t, bulk_velocity_m_s, rng, loading: str = "random") -> np.ndarray:
    e1, e2, b = field_aligned_basis(magnetic_field_t)
    z = standard_normal_samples(count, 3, rng, loading)
    vpar = np.sqrt(BOLTZMANN_CONSTANT * temperature_parallel_k / mass_kg)
    vperp = np.sqrt(BOLTZMANN_CONSTANT * temperature_perpendicular_k / mass_kg)
    v = vperp * (z[:, :1] * e1 + z[:, 1:2] * e2) + vpar * z[:, 2:3] * b
    return v + np.asarray(bulk_velocity_m_s, dtype=float).reshape(3)


def magnetised(grid: SpatialGrid, *, temperature_k: float, density_m3: float, bulk_velocity_m_s=(0, 0, 0),
               particle_count: int, mass_kg: float, magnetic_field_t, rng,
               temperature_parallel_k: float | None = None, temperature_perpendicular_k: float | None = None,
               species_id: int = 0, position_loading: str = "random", velocity_loading: str = "random") -> ParticleState:
    """Uniform bi-Maxwellian population (T_par = T_perp = temperature_k unless overridden)."""
    Tpar = temperature_k if temperature_parallel_k is None else temperature_parallel_k
    Tperp = temperature_k if temperature_perpendicular_k is None else temperature_perpendicular_k
    pos = sample_positions(grid, particle_count, rng, position_loading)
    vel = bi_maxwellian_velocities(particle_count, Tpar, Tperp, mass_kg, magnetic_field_t, bulk_velocity_m_s, rng,
                                   velocity_loading)
    w = np.full(particle_count, macro_particle_weight(density_m3, grid, particle_count))
    return ParticleState(pos, vel, np.full(particle_count, species_id, np.int32), w,
                         np.arange(particle_count, dtype=np.int64))


def gyrating_particle(position_m, v_parallel_m_s: float, v_perpendicular_m_s: float, magnetic_field_t,
                      weight: float = 1.0) -> ParticleState:
    """Single particle with velocity v_par b + v_perp e1."""
    e1, _, b = field_aligned_basis(magnetic_field_t)
    v = v_parallel_m_s * b + v_perpendicular_m_s * e1
    return ParticleState(np.asarray(position_m, dtype=float).reshape(1, 3), v.reshape(1, 3),
                         np.zeros(1, np.int32), np.array([weight]), np.zeros(1, np.int64))
