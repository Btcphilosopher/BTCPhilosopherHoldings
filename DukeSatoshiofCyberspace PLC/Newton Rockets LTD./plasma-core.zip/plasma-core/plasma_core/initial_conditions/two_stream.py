"""Two-stream instability set-up.

Two counter-streaming electron beams with drifts +v0 and -v0 along x, each of
density n0/2 and temperature T, over an immobile neutralising ion background.
A seed perturbation of relative amplitude A at mode m is applied to both beams.

Cold-beam linear theory (validation reference, see
:func:`plasma_core.physics.dispersion.cold_two_stream_growth_rate`):

    gamma_max = omega_p / (2 sqrt 2)   at   k v0 = sqrt(3/8) omega_p,

and modes with k v0 > omega_p are stable.  Finite temperature is included in
the kinetic dispersion solve used by the validation suite.
"""

from __future__ import annotations

import numpy as np

from ..constants import ELECTRON_MASS, ELEMENTARY_CHARGE, PROTON_MASS
from ..grid.spatial_grid import SpatialGrid
from ..particles.particle_initializer import make_generator
from ..particles.particle_state import ParticleState
from ..species import Species
from .maxwellian import maxwellian
from .plasma_wave import apply_density_perturbation


def two_stream_species(density_m3: float, temperature_k: float, drift_velocity_m_s: float) -> list[Species]:
    """[beam +v0, beam -v0, immobile ion background] with total electron density ``density_m3``."""
    return [
        Species(name="beam_plus", charge_c=-ELEMENTARY_CHARGE, mass_kg=ELECTRON_MASS, density_m3=density_m3 / 2,
                temperature_k=temperature_k, bulk_velocity_m_s=(drift_velocity_m_s, 0, 0)),
        Species(name="beam_minus", charge_c=-ELEMENTARY_CHARGE, mass_kg=ELECTRON_MASS, density_m3=density_m3 / 2,
                temperature_k=temperature_k, bulk_velocity_m_s=(-drift_velocity_m_s, 0, 0)),
        Species(name="ions", charge_c=ELEMENTARY_CHARGE, mass_kg=PROTON_MASS, density_m3=density_m3, mobile=False),
    ]


def two_stream(grid: SpatialGrid, *, temperature_k: float, density_m3: float, bulk_velocity_m_s,
               particle_count: int, perturbation_amplitude: float = 1e-3, mode: int = 1,
               rng=None, random_seed=None, position_loading: str = "quiet",
               velocity_loading: str = "random") -> ParticleState:
    """Particles of both beams (species ids 0 and 1), ``particle_count`` per beam.

    ``density_m3`` is the *total* electron density; ``bulk_velocity_m_s`` the drift
    of beam 0 (beam 1 drifts in the opposite direction).
    """
    if rng is None:
        if random_seed is None:
            raise ValueError("explicit rng or random_seed required")
        rng = make_generator(random_seed)
    u = np.asarray(bulk_velocity_m_s, dtype=float).reshape(3) if np.ndim(bulk_velocity_m_s) else np.array([bulk_velocity_m_s, 0.0, 0.0])
    parts = []
    for sid, sign in ((0, 1.0), (1, -1.0)):
        p = maxwellian(grid, temperature_k=temperature_k, density_m3=density_m3 / 2, bulk_velocity_m_s=sign * u,
                       particle_count=particle_count, mass_kg=ELECTRON_MASS, rng=rng, species_id=sid,
                       position_loading=position_loading, velocity_loading=velocity_loading)
        apply_density_perturbation(p.positions, grid, mode=mode, amplitude=perturbation_amplitude)
        parts.append(p)
    return ParticleState.concatenate(parts)
