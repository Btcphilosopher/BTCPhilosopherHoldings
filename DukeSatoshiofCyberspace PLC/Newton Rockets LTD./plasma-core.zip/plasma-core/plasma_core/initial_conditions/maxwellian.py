"""Maxwellian, cold and drifting-Maxwellian particle populations.

    f(v) = n (m / (2 pi k_B T))^{3/2} exp(-m |v - u|^2 / (2 k_B T))

Each population is a :class:`ParticleState` with uniform macro-particle
weight w = n V / N.
"""

from __future__ import annotations

import numpy as np

from ..grid.spatial_grid import SpatialGrid
from ..particles.particle_initializer import (
    macro_particle_weight,
    make_generator,
    sample_maxwellian_velocities,
    sample_positions,
)
from ..particles.particle_state import ParticleState


def _rng(rng, random_seed):
    if rng is not None:
        return rng
    if random_seed is None:
        raise ValueError("an explicit rng or random_seed is required (no global random state is used)")
    return make_generator(random_seed)


def maxwellian(grid: SpatialGrid, *, temperature_k: float, density_m3: float, bulk_velocity_m_s=(0, 0, 0),
               particle_count: int, mass_kg: float, rng: np.random.Generator | None = None,
               random_seed: int | None = None, species_id: int = 0, position_loading: str = "random",
               velocity_loading: str = "random") -> ParticleState:
    """Uniform-density (drifting) Maxwellian population."""
    if particle_count < 1:
        raise ValueError("particle_count must be >= 1")
    g = _rng(rng, random_seed)
    pos = sample_positions(grid, particle_count, g, position_loading)
    vel = sample_maxwellian_velocities(particle_count, temperature_k, mass_kg, bulk_velocity_m_s, g, velocity_loading)
    w = np.full(particle_count, macro_particle_weight(density_m3, grid, particle_count))
    return ParticleState(pos, vel, np.full(particle_count, species_id, np.int32), w,
                         np.arange(particle_count, dtype=np.int64))


def drifting_maxwellian(grid: SpatialGrid, **kw) -> ParticleState:
    """Alias of :func:`maxwellian` emphasising a non-zero ``bulk_velocity_m_s``."""
    return maxwellian(grid, **kw)


def cold_plasma(grid: SpatialGrid, *, temperature_k: float = 0.0, density_m3: float, bulk_velocity_m_s=(0, 0, 0),
                particle_count: int, mass_kg: float, rng=None, random_seed=None, species_id: int = 0,
                position_loading: str = "quiet") -> ParticleState:
    """Cold population: every particle moves with the bulk velocity.  ``temperature_k`` must be 0."""
    if temperature_k != 0.0:
        raise ValueError("cold_plasma requires temperature_k == 0; use maxwellian for warm plasmas")
    return maxwellian(grid, temperature_k=0.0, density_m3=density_m3, bulk_velocity_m_s=bulk_velocity_m_s,
                      particle_count=particle_count, mass_kg=mass_kg, rng=rng, random_seed=random_seed,
                      species_id=species_id, position_loading=position_loading, velocity_loading="random")
