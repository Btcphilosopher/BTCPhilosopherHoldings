"""Physically defined initial conditions.

:func:`build_particles` turns a validated :class:`SimulationConfig` into the
initial :class:`ParticleState`.  Each mobile species is loaded from its own
independent random stream (``SeedSequence(random_seed).spawn``), so the
initial population is a deterministic function of (configuration, seed,
software version).
"""

from __future__ import annotations

import numpy as np

from ..grid.spatial_grid import SpatialGrid
from ..particles.particle_initializer import make_generator, macro_particle_weight, sample_maxwellian_velocities, sample_positions
from ..particles.particle_state import ParticleState
from .magnetised import bi_maxwellian_velocities, gyrating_particle, magnetised
from .maxwellian import cold_plasma, drifting_maxwellian, maxwellian
from .plasma_wave import apply_density_perturbation, plasma_wave
from .two_stream import two_stream, two_stream_species

__all__ = [
    "build_particles", "maxwellian", "drifting_maxwellian", "cold_plasma", "plasma_wave", "two_stream",
    "two_stream_species", "magnetised", "gyrating_particle", "apply_density_perturbation",
]


def particles_for_species(config, species, grid: SpatialGrid) -> int:
    """Macro-particle count of a species (``particle_weight`` overrides ``particles.count``)."""
    if species.particle_weight is not None:
        n = int(round(species.density_m3 * grid.domain_volume_m3 / species.particle_weight))
        if n < 1:
            raise ValueError(f"species {species.name}: particle_weight too large for the domain")
        return n
    return config.particles.count


def build_particles(config, grid: SpatialGrid, seeds: list[np.random.SeedSequence]) -> ParticleState:
    ic = config.initial_condition
    parts: list[ParticleState] = []
    if ic.type == "single_particle":
        idx = next(i for i, s in enumerate(config.species) if s.mobile)
        sp = config.species[idx]
        n = len(ic.positions_m)
        w = sp.particle_weight if sp.particle_weight is not None else 1.0
        return ParticleState(np.asarray(ic.positions_m, dtype=float), np.asarray(ic.velocities_m_s, dtype=float),
                             np.full(n, idx, np.int32), np.full(n, w), np.arange(n, dtype=np.int64))

    B0 = np.asarray(config.solver.external_magnetic_field_t)
    for i, sp in enumerate(config.species):
        if not sp.mobile:
            continue
        rng = make_generator(seeds[i])
        n = particles_for_species(config, sp, grid)
        pos = sample_positions(grid, n, rng, config.particles.position_loading)
        if ic.type == "magnetised":
            tpar = (ic.temperature_parallel_k or {}).get(sp.name, sp.temperature_k)
            tperp = (ic.temperature_perpendicular_k or {}).get(sp.name, sp.temperature_k)
            vel = bi_maxwellian_velocities(n, tpar, tperp, sp.mass_kg, B0, sp.bulk_velocity_m_s, rng,
                                           config.particles.velocity_loading)
        else:
            vel = sample_maxwellian_velocities(n, sp.temperature_k, sp.mass_kg, sp.bulk_velocity_m_s, rng,
                                               config.particles.velocity_loading)
        pert = ic.perturbation
        if pert.amplitude > 0 and (pert.species is None or sp.name in pert.species):
            apply_density_perturbation(pos, grid, mode=pert.mode, amplitude=pert.amplitude,
                                       phase_rad=pert.phase_rad, axis=pert.axis)
        w = np.full(n, macro_particle_weight(sp.density_m3, grid, n))
        parts.append(ParticleState(pos, vel, np.full(n, i, np.int32), w, np.zeros(n, np.int64)))
    return ParticleState.concatenate(parts)
