"""Command-line interface.

    plasma-core run config.yaml [--output DIR] [--quiet]
    plasma-core validate config.yaml            # validate configuration + pre-run assessment (no run)
    plasma-core inspect file.h5                 # tree of an HDF5 output/checkpoint
    plasma-core restart checkpoint.h5 [--steps N]
    plasma-core benchmark [--particles N] [--cells N]
    plasma-core diagnostics output.h5 [--columns a,b] [--parquet out.parquet]
    plasma-core validation-suite [--report docs/VALIDATION.md] [--json results.json] [--cases a,b]
"""

from __future__ import annotations

import argparse
import json
import sys
import warnings

import numpy as np


def _cmd_run(args) -> int:
    from .configuration import SimulationConfig
    from .simulation import PlasmaSimulation

    cfg = SimulationConfig.from_file(args.config)
    if args.output:
        cfg = cfg.with_updates(output={"directory": args.output})
    sim = PlasmaSimulation(cfg, verbose=not args.quiet)
    sim.initialize()
    sim.run(write_output=True)
    paths = {}
    if cfg.output.hdf5:
        paths["hdf5"] = f"{cfg.output.directory}/{cfg.name}.h5"
    if cfg.output.parquet:
        paths["parquet"] = f"{cfg.output.directory}/{cfg.name}_diagnostics.parquet"
    last = sim.diagnostics.rows[-1]
    print(f"\nfinished: step {sim.step_index}, t = {sim.time_s:.6e} s")
    for k in ("energy_error", "relative_charge_error", "momentum_error"):
        if k in last:
            print(f"  {k:<24s} {last[k]:.4e}")
    for k, v in paths.items():
        print(f"  {k}: {v}")
    if sim.monitor.events:
        print(f"  events: {json.dumps(sim.monitor.events, default=str)}")
    return 0


def _cmd_validate(args) -> int:
    from .configuration import SimulationConfig
    from .exceptions import PlasmaCoreError
    from .simulation import PlasmaSimulation

    try:
        cfg = SimulationConfig.from_file(args.config)
        sim = PlasmaSimulation(cfg)
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            sim.assess()
    except PlasmaCoreError as exc:
        print(f"INVALID: {exc}")
        return 2
    print(sim.summary())
    print("\nconfiguration is valid" + (" (with warnings)" if sim.warnings else ""))
    return 0


def _cmd_inspect(args) -> int:
    from .io.hdf5 import inspect_file

    print(inspect_file(args.file))
    return 0


def _cmd_restart(args) -> int:
    from .simulation import PlasmaSimulation

    sim = PlasmaSimulation.restart(args.checkpoint, verbose=True)
    target = sim.step_index + args.steps if args.steps else None
    sim.run(until_step=target, write_output=True)
    print(f"finished: step {sim.step_index}, t = {sim.time_s:.6e} s")
    return 0


def _cmd_benchmark(args) -> int:
    from .benchmarks import format_benchmarks, run_benchmarks

    rows = run_benchmarks(args.particles, args.cells, args.repeats)
    print(format_benchmarks(rows))
    if args.json:
        with open(args.json, "w") as f:
            json.dump(rows, f, indent=1)
    return 0


def _cmd_diagnostics(args) -> int:
    from .io.hdf5 import read_diagnostics, read_metadata

    tab = read_diagnostics(args.file)
    md = read_metadata(args.file)
    print(f"simulation {md.get('simulation_id')}  solver {md.get('solver')}  config {str(md.get('configuration_hash'))[:16]}")
    cols = args.columns.split(",") if args.columns else [c for c in ("step", "time_s", "total_energy_j", "energy_error",
                                                                        "relative_charge_error", "momentum_error")
                                                         if c in tab]
    print("  ".join(f"{c:>16s}" for c in cols))
    n = len(tab["time_s"])
    idx = range(n) if n <= args.max_rows else np.linspace(0, n - 1, args.max_rows).astype(int)
    for i in idx:
        print("  ".join(f"{tab[c][i]:>16.6g}" for c in cols))
    if args.parquet:
        from .io.parquet import write_diagnostics_parquet

        write_diagnostics_parquet(tab, args.parquet, md)
        print(f"wrote {args.parquet}")
    return 0


def _cmd_suite(args) -> int:
    from .validation.report import regression_reference, run_suite, write_report

    sel = args.cases.split(",") if args.cases else None
    data = run_suite(sel, include_convergence=not args.no_convergence)
    write_report(data, args.report, args.json)
    if args.write_reference:
        with open(args.write_reference, "w") as f:
            json.dump(regression_reference(data), f, indent=1, default=float)
    failed = [r["name"] for r in data["cases"] if not r["passed"]] + [s["name"] for s in data["convergence"] if not s["passed"]]
    print(f"\n{len(data['cases']) + len(data['convergence']) - len(failed)} passed, {len(failed)} failed")
    return 1 if failed else 0


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(prog="plasma-core", description="plasma_core reference plasma simulation framework")
    sub = p.add_subparsers(dest="command", required=True)
    r = sub.add_parser("run", help="run a simulation from a YAML/TOML/JSON configuration")
    r.add_argument("config")
    r.add_argument("--output", help="override output.directory")
    r.add_argument("--quiet", action="store_true")
    r.set_defaults(fn=_cmd_run)
    v = sub.add_parser("validate", help="validate a configuration and print the pre-run assessment")
    v.add_argument("config")
    v.set_defaults(fn=_cmd_validate)
    i = sub.add_parser("inspect", help="inspect an HDF5 output or checkpoint")
    i.add_argument("file")
    i.set_defaults(fn=_cmd_inspect)
    rs = sub.add_parser("restart", help="restart from a checkpoint")
    rs.add_argument("checkpoint")
    rs.add_argument("--steps", type=int, default=None, help="number of further steps (default: to the end)")
    rs.set_defaults(fn=_cmd_restart)
    b = sub.add_parser("benchmark", help="benchmark kernels and a full time step")
    b.add_argument("--particles", type=int, default=200_000)
    b.add_argument("--cells", type=int, default=1024)
    b.add_argument("--repeats", type=int, default=5)
    b.add_argument("--json")
    b.set_defaults(fn=_cmd_benchmark)
    d = sub.add_parser("diagnostics", help="print the diagnostics table of an HDF5 output")
    d.add_argument("file")
    d.add_argument("--columns")
    d.add_argument("--max-rows", type=int, default=20)
    d.add_argument("--parquet")
    d.set_defaults(fn=_cmd_diagnostics)
    s = sub.add_parser("validation-suite", help="run the analytical validation suite")
    s.add_argument("--report")
    s.add_argument("--json")
    s.add_argument("--cases")
    s.add_argument("--no-convergence", action="store_true")
    s.add_argument("--write-reference")
    s.set_defaults(fn=_cmd_suite)
    args = p.parse_args(argv)
    return args.fn(args)


if __name__ == "__main__":  # pragma: no cover
    sys.exit(main())
