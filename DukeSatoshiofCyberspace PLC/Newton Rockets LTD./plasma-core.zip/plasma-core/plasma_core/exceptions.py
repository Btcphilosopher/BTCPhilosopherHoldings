"""Domain-specific exceptions.

Every exception carries four pieces of information so that a failure can be
investigated without reading the source code:

* ``what``   - what failed
* ``why``    - why it failed (the violated physical/numerical condition)
* ``parameter`` - the configuration parameter (or state quantity) responsible
* ``investigate`` - how to investigate or fix it
"""

from __future__ import annotations


class PlasmaCoreError(Exception):
    """Base class for all plasma_core errors."""

    def __init__(
        self,
        what: str,
        why: str = "",
        parameter: str | None = None,
        investigate: str | None = None,
    ) -> None:
        self.what = what
        self.why = why
        self.parameter = parameter
        self.investigate = investigate
        lines = [what]
        if why:
            lines.append(f"  why: {why}")
        if parameter:
            lines.append(f"  parameter: {parameter}")
        if investigate:
            lines.append(f"  investigate: {investigate}")
        super().__init__("\n".join(lines))


class InvalidPhysicalConfiguration(PlasmaCoreError, ValueError):
    """The requested configuration is physically or mathematically inconsistent."""


class NumericalInstabilityError(PlasmaCoreError, RuntimeError):
    """The numerical state is (or would become) unstable or corrupted."""


class StabilityCriterionViolation(NumericalInstabilityError):
    """A required stability criterion (e.g. Courant limit) is violated before the run."""


class BoundaryConditionError(PlasmaCoreError, ValueError):
    """A boundary condition is unsupported or incompatible with the selected solver."""


class SolverConfigurationError(PlasmaCoreError, ValueError):
    """The selected solver cannot be configured as requested."""


class CheckpointError(PlasmaCoreError, IOError):
    """A checkpoint could not be written, read or validated."""


class ConservationError(PlasmaCoreError, RuntimeError):
    """A conservation law was violated beyond its documented tolerance."""


class BackendUnavailableError(PlasmaCoreError, RuntimeError):
    """A requested compute backend is not installed or not validated."""
