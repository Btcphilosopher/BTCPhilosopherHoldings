"""Particle -> grid charge deposition.

    rho_j = (1 / V_cell) sum_p q_p w_p W(x_j - x_p)        [C/m^3]

where w_p is the macro-particle weight and W the NGP or CIC shape function
(:mod:`plasma_core.pic.shapes`).  Implemented with ``numpy.bincount`` (no
Python particle loop).  sum_j rho_j V_cell = sum_p q_p w_p holds to round-off
for both periodic and wall-bounded grids (charge conservation of the
deposition step).
"""

from __future__ import annotations

import numpy as np

from .shapes import ShapeFunction, get_shape, grid_stencils


def flat_stencil(positions: np.ndarray, grid, shape: ShapeFunction | str, offset: float = 0.5
                 ) -> tuple[np.ndarray, np.ndarray]:
    """Flattened (C-order) node indices and weights, each of shape (N, S^dim)."""
    shape = get_shape(shape) if isinstance(shape, str) else shape
    st = grid_stencils(positions, grid, shape, [offset] * grid.dimension)
    if grid.dimension == 1:
        return st[0]
    if grid.dimension == 2:
        (ix, wx), (iy, wy) = st
        n = positions.shape[0]
        flat = (ix[:, :, None] * grid.cells[1] + iy[:, None, :]).reshape(n, -1)
        return flat, (wx[:, :, None] * wy[:, None, :]).reshape(n, -1)
    raise NotImplementedError("3D deposition is a future extension")


def deposit_with_stencil(idx: np.ndarray, w: np.ndarray, values: np.ndarray, grid) -> np.ndarray:
    """Deposit ``values`` (N,) using a precomputed stencil; returns grid.shape (sum, not density)."""
    return np.bincount(idx.ravel(), weights=(w * values[:, None]).ravel(),
                       minlength=grid.n_cells).reshape(grid.shape).astype(float)


def deposit_scalar(positions: np.ndarray, values: np.ndarray, grid, shape: ShapeFunction | str,
                   offset: float = 0.5) -> np.ndarray:
    """Deposit per-particle ``values`` (N,) onto grid nodes; returns array of ``grid.shape``.

    The result is a *sum* (not divided by the cell volume).
    """
    shape = get_shape(shape) if isinstance(shape, str) else shape
    st = grid_stencils(positions, grid, shape, [offset] * grid.dimension)
    if grid.dimension == 1:
        idx, w = st[0]
        return np.bincount(idx.ravel(), weights=(w * values[:, None]).ravel(), minlength=grid.cells[0]).astype(float)
    if grid.dimension == 2:
        (ix, wx), (iy, wy) = st
        ny = grid.cells[1]
        flat = (ix[:, :, None] * ny + iy[:, None, :]).ravel()
        ww = (wx[:, :, None] * wy[:, None, :] * values[:, None, None]).ravel()
        return np.bincount(flat, weights=ww, minlength=grid.n_cells).reshape(grid.shape).astype(float)
    raise NotImplementedError("3D deposition is a future extension")


def deposit_charge(positions: np.ndarray, charge_weights: np.ndarray, grid, shape: ShapeFunction | str = "cic",
                   background_charge_density: float = 0.0) -> np.ndarray:
    """Charge density on cell centres [C/m^3].

    ``charge_weights`` = q_p * w_p per particle [C].  A uniform immobile
    background (``background_charge_density`` [C/m^3]) is added explicitly.
    """
    rho = deposit_scalar(positions, charge_weights, grid, shape, 0.5) / grid.cell_volume_m3
    if background_charge_density:
        rho += background_charge_density
    return rho
