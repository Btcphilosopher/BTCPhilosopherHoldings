"""Grid -> particle field interpolation.

    F(x_p) = sum_j F_j W(x_j - x_p)

with the same shape function used for deposition (required for
momentum conservation; a mismatch is reported as a warning by the
simulation set-up).  Fields are arrays of shape ``grid.shape + (3,)``;
the result has shape (N, 3).
"""

from __future__ import annotations

import numpy as np

from .shapes import ShapeFunction, get_shape, grid_stencils


def interpolate_field(field: np.ndarray, positions: np.ndarray, grid, shape: ShapeFunction | str = "cic",
                      offset: float | tuple[float, ...] = 0.5) -> np.ndarray:
    """Interpolate a vector field (grid.shape + (3,)) or scalar field (grid.shape) to particles."""
    shape = get_shape(shape) if isinstance(shape, str) else shape
    offsets = offset if isinstance(offset, tuple) else (offset,) * grid.dimension
    st = grid_stencils(positions, grid, shape, offsets)
    if grid.dimension == 1:
        idx, w = st[0]
        if field.ndim == 1:
            return (field[idx] * w).sum(axis=1)
        return np.einsum("ns,nsc->nc", w, field[idx])
    if grid.dimension == 2:
        (ix, wx), (iy, wy) = st
        ww = wx[:, :, None] * wy[:, None, :]
        vals = field[ix[:, :, None], iy[:, None, :]]
        if field.ndim == 2:
            return (vals * ww).sum(axis=(1, 2))
        return np.einsum("nab,nabc->nc", ww, vals)
    raise NotImplementedError("3D interpolation is a future extension")
