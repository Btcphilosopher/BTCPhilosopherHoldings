"""PIC-level particle advance built on the Boris kernel.

Leapfrog time centring::

    x^n, v^{n-1/2}  --gather E^n,B^n at x^n-->  v^{n+1/2} = Boris(v^{n-1/2})
                    x^{n+1} = x^n + v^{n+1/2} dt

Initialisation pushes v^0 back by half a step: v^{-1/2} = Boris(v^0, -dt/2).
"""

from __future__ import annotations

import numpy as np

from ..particles.particle_push import advance_positions


def initial_half_step_back(backend, v0: np.ndarray, E_p: np.ndarray, B_p: np.ndarray, qm: np.ndarray, dt: float) -> np.ndarray:
    """v^{-1/2} from v^0 using a Boris push over -dt/2 (time-reversible)."""
    return backend.boris_push(v0, E_p, B_p, qm, -0.5 * dt)


def leapfrog_advance(backend, positions: np.ndarray, velocities: np.ndarray, E_p, B_p, qm, dt: float) -> np.ndarray:
    """Return v^{n+1/2} and advance positions in place to x^{n+1}."""
    v_new = backend.boris_push(velocities, E_p, B_p, qm, dt)
    advance_positions(positions, v_new, dt)
    return v_new
