"""Particle -> grid current deposition.

Direct deposition (implemented)
-------------------------------
    J_j = (1 / V_cell) sum_p q_p w_p v_p W(x_j - x_p)      [A/m^2]

evaluated with the time-centred velocity v^{n+1/2} at the time-centred
position x^{n+1/2} = (x^n + x^{n+1})/2.  This scheme does **not** satisfy the
discrete continuity equation d rho/dt + div J = 0 exactly.  In the 1D
electromagnetic solver this is harmless because only the transverse
components J_y, J_z are used (they do not enter Gauss's law) and E_x is
obtained from Poisson's equation every step, so Gauss's law holds to solver
precision by construction.

Charge-conserving schemes (extension point)
-------------------------------------------
:class:`EsirkepovCurrentDeposition` (Esirkepov 2001) and Villasenor-Buneman
are required for a multi-dimensional EM-PIC that advances E_x with Ampere's
law.  They are declared here but not implemented.
"""

from __future__ import annotations

from abc import ABC, abstractmethod

import numpy as np

from .charge_deposition import deposit_with_stencil, flat_stencil
from .shapes import ShapeFunction, get_shape


class CurrentDepositionScheme(ABC):
    name = "abstract"
    #: True only for schemes that satisfy the discrete continuity equation exactly
    charge_conserving = False

    @abstractmethod
    def deposit(self, x_old: np.ndarray, x_new: np.ndarray, v_half: np.ndarray, charge_weights: np.ndarray,
                grid, dt: float) -> np.ndarray:
        """Current density J (grid.shape + (3,)) [A/m^2]."""


class DirectCurrentDeposition(CurrentDepositionScheme):
    name = "direct"
    charge_conserving = False

    def __init__(self, shape: ShapeFunction | str = "cic", offset: float = 0.5) -> None:
        self.shape = get_shape(shape) if isinstance(shape, str) else shape
        self.offset = offset

    def deposit(self, x_old, x_new, v_half, charge_weights, grid, dt):
        # (x_old + x_new)/2 is wrong for a particle wrapped by a periodic boundary; x_new - v dt/2
        # is the same point for unwrapped particles and is correct for wrapped ones.
        x_mid = x_new - 0.5 * dt * v_half
        for a in range(grid.dimension):
            if grid.periodic[a]:
                lo, L = grid.lower_m[a], grid.lengths_m[a]
                x_mid[:, a] = lo + np.mod(x_mid[:, a] - lo, L)
        idx, w = flat_stencil(x_mid, grid, self.shape, self.offset)
        J = np.empty(grid.shape + (3,))
        for c in range(3):
            J[..., c] = deposit_with_stencil(idx, w, charge_weights * v_half[:, c], grid)
        return J / grid.cell_volume_m3


def deposit_current(positions: np.ndarray, velocities: np.ndarray, charge_weights: np.ndarray, grid,
                    shape: ShapeFunction | str = "cic") -> np.ndarray:
    """Instantaneous J = sum q w v W / V at given positions/velocities, shape grid.shape + (3,)."""
    idx, w = flat_stencil(positions, grid, shape, 0.5)
    J = np.empty(grid.shape + (3,))
    for c in range(3):
        J[..., c] = deposit_with_stencil(idx, w, charge_weights * velocities[:, c], grid)
    return J / grid.cell_volume_m3


class EsirkepovCurrentDeposition(CurrentDepositionScheme):
    """Charge-conserving deposition (Esirkepov 2001) - extension point, not implemented."""

    name = "esirkepov"
    charge_conserving = True

    def __init__(self, *a, **k) -> None:
        raise NotImplementedError("Esirkepov charge-conserving deposition is a planned extension")

    def deposit(self, *a, **k):  # pragma: no cover
        raise NotImplementedError
