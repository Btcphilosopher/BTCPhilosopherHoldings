"""Particle shape functions shared by deposition and interpolation.

Using *the same* shape function for charge deposition and field interpolation
removes the self-force of a particle on itself and, combined with a spatially
symmetric field solve, makes the scheme momentum-conserving
(Birdsall & Langdon 1991, ch. 8).

Grid nodes along an axis sit at ``x_j = x_lo + (j + offset) dx`` with
``offset = 0.5`` for cell-centred quantities and ``offset = 0`` for
edge-centred (Yee B) quantities.

``NGP`` (order 0)   W = 1 at the nearest node
``CIC`` (order 1)   linear weights on the two neighbouring nodes

Non-periodic axes: stencil indices outside ``[0, n-1]`` are clamped to the
boundary node, so total deposited charge is conserved exactly and the
interpolated field next to a wall equals the boundary-node value.
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np


@dataclass(frozen=True)
class ShapeFunction:
    name: str
    order: int

    @property
    def support(self) -> int:
        return self.order + 1

    def stencil(self, x: np.ndarray, lower: float, dx: float, n: int, offset: float, periodic: bool
                ) -> tuple[np.ndarray, np.ndarray]:
        """Return node indices (N, S) and weights (N, S) for positions ``x`` (N,)."""
        s = (x - lower) / dx - offset
        if self.order == 0:
            j = np.floor(s + 0.5).astype(np.int64)
            idx = j[:, None]
            w = np.ones((x.shape[0], 1))
        elif self.order == 1:
            j0 = np.floor(s).astype(np.int64)
            f = s - j0
            idx = np.stack((j0, j0 + 1), axis=1)
            w = np.stack((1.0 - f, f), axis=1)
        else:  # pragma: no cover - guarded by get_shape
            raise ValueError("unsupported order")
        if periodic:
            idx = np.mod(idx, n)
        else:
            idx = np.clip(idx, 0, n - 1)
        return idx, w

    def fourier_factor(self, k, dx: float):
        """S(k) = sinc^{order+1}(k dx / 2) (continuous shape transform)."""
        h = np.asarray(k, dtype=float) * dx / 2.0
        with np.errstate(invalid="ignore", divide="ignore"):
            sinc = np.where(h == 0, 1.0, np.sin(h) / np.where(h == 0, 1.0, h))
        return sinc ** (self.order + 1)


NGP = ShapeFunction("ngp", 0)
CIC = ShapeFunction("cic", 1)
_SHAPES = {"ngp": NGP, "cic": CIC}


def get_shape(name: str) -> ShapeFunction:
    try:
        return _SHAPES[name]
    except KeyError:
        raise ValueError(f"unknown shape function '{name}' (available: {sorted(_SHAPES)})") from None


def grid_stencils(positions: np.ndarray, grid, shape: ShapeFunction, offsets) -> list[tuple[np.ndarray, np.ndarray]]:
    """Per-axis stencils for all grid dimensions."""
    out = []
    for a in range(grid.dimension):
        out.append(shape.stencil(positions[:, a], grid.lower_m[a], float(grid.spacing_m[a]), grid.cells[a],
                                 offsets[a], grid.periodic[a]))
    return out
