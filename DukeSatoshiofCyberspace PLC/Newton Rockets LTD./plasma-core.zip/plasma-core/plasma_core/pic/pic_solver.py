"""Particle-in-cell models.

:class:`ElectrostaticPICModel` (1D3V and 2D3V)
    deposit rho -> Poisson -> E -> interpolate -> Boris push -> boundaries.
    Uniform external E and B may be applied.

:class:`ElectromagneticPIC1DModel` (1D3V, periodic) - *foundation*
    Longitudinal E_x from Poisson, transverse (E_y, E_z, B_y, B_z) from the
    1D Yee solver driven by direct current deposition.  Not a 2D/3D EM-PIC.

:class:`TestParticleModel`
    Particles in prescribed uniform external fields; no self-consistent
    fields.  Used for single-particle validation (gyro-motion, E x B drift).

The loop of every PIC model is (one step t^n -> t^{n+1})::

    gather E^n, B^n at x^n  ->  Boris  v^{n-1/2} -> v^{n+1/2}
    [collision operator, if configured]
    x^{n+1} = x^n + v^{n+1/2} dt  ->  particle boundaries
    deposit rho^{n+1} (and J^{n+1/2})  ->  field solve  E^{n+1} (B^{n+1})
"""

from __future__ import annotations

import math

import numpy as np

from ..constants import SPEED_OF_LIGHT
from ..diagnostics.energy import leapfrog_kinetic_energy
from ..diagnostics.momentum import field_momentum, particle_momentum, particle_momentum_scale
from ..diagnostics.temperature import (
    anisotropic_temperature,
    electron_ion_temperatures,
    species_temperatures,
)
from ..fields.electric_field import electric_field_energy, gauss_law_residual
from ..fields.electromagnetic import ElectromagneticField1D
from ..fields.electrostatic import ElectrostaticField
from ..fields.field_boundary import build_field_boundary, check_compatibility
from ..fields.magnetic_field import magnetic_field_energy
from ..initial_conditions import build_particles
from ..boundary_conditions import BOUNDARY_CONDITIONS
from ..particles.particle_boundary import ParticleLossLedger
from ..particles.particle_state import ParticleState
from ..simulation.model import SimulationModel
from ..solvers import timestep as ts
from ..state import PlasmaState
from .current_deposition import DirectCurrentDeposition, deposit_current
from .particle_push import initial_half_step_back
from .shapes import get_shape


class _ParticleModel(SimulationModel):
    """Shared machinery of particle models."""

    has_self_fields = True

    def __init__(self, config, grid, backend, collisions, runtime_rng) -> None:
        super().__init__(config, grid, backend, collisions, runtime_rng)
        sc = config.solver
        self.shape_dep = get_shape(sc.deposition)
        self.shape_int = get_shape(sc.interpolation)
        self.charges = np.array([s.charge_c for s in self.species])
        self.masses = np.array([s.mass_kg for s in self.species])
        self.E_ext = np.asarray(sc.external_electric_field_v_m, dtype=float)
        self.B_ext = np.asarray(sc.external_magnetic_field_t, dtype=float)
        self.background_rho = float(sum(s.charge_density_c_m3 for s in self.species if not s.mobile))
        self.boundary_condition = BOUNDARY_CONDITIONS[config.boundaries.particles]
        self.boundary = self.boundary_condition.particle_boundary()
        self.ledger = ParticleLossLedger(self.n_species)
        self.particles = ParticleState.empty()
        self._cache_n = -1

    # per-particle property arrays, recomputed only when the population changes
    def _per_particle(self):
        ps = self.particles
        if self._cache_n != ps.n or self._cache_sid is not ps.species_id:
            self._qm = (self.charges / self.masses)[ps.species_id]
            self._qw = self.charges[ps.species_id] * ps.weights
            self._mp = self.masses[ps.species_id]
            self._cache_n = ps.n
            self._cache_sid = ps.species_id
        return self._qm, self._qw, self._mp

    _cache_sid = None

    def _apply_boundaries(self) -> None:
        for a in range(self.grid.dimension):
            self.boundary.apply(self.particles, a, self.grid.lower_m[a], self.grid.upper_m[a], self.ledger,
                                self.charges, self.masses)

    def _deposit_rho(self) -> np.ndarray:
        _, qw, _ = self._per_particle()
        rho = self.backend.deposit(self.particles.positions, qw, self.grid, self.shape_dep, 0.5) / self.grid.cell_volume_m3
        return rho + self.background_rho

    def _gather(self, field_grid: np.ndarray, offset: float = 0.5) -> np.ndarray:
        if self.grid.dimension == 1:
            return self.backend.interpolate(field_grid, self.particles.positions, self.grid, self.shape_int, offset)
        from .field_interpolation import interpolate_field

        return interpolate_field(field_grid, self.particles.positions, self.grid, self.shape_int, offset)

    def max_speed_array(self):
        return self.particles.velocities

    # common observation pieces -------------------------------------------
    def _particle_observables(self, E_p_self_and_ext: np.ndarray, B_p: np.ndarray, E_p_self: np.ndarray) -> dict:
        ps = self.particles
        qm, qw, mp = self._per_particle()
        v_old = ps.velocities
        v_new = self.backend.boris_push(v_old, E_p_self_and_ext, B_p, qm, self.dt)
        v_sync = 0.5 * (v_old + v_new)
        ke = leapfrog_kinetic_energy(v_old, v_new, mp, ps.weights)
        e_sp = 0.25 * mp * ps.weights * (np.einsum("ij,ij->i", v_old, v_old) + np.einsum("ij,ij->i", v_new, v_new))
        ke_by_species = np.bincount(ps.species_id, weights=e_sp, minlength=self.n_species)
        temps = species_temperatures(v_sync, ps.weights, ps.species_id, self.species)
        wbs = ps.weight_by_species(self.n_species)
        te, ti = electron_ion_temperatures(temps, self.species, wbs)
        out = {
            "v_sync": v_sync, "kinetic_energy": ke, "ke_by_species": ke_by_species, "temps": temps, "te": te,
            "ti": ti, "weights_by_species": wbs,
            "momentum": particle_momentum(v_sync, mp, ps.weights),
            "momentum_scale": particle_momentum_scale(v_sync, mp, ps.weights),
            "power_self": float(np.sum(qw * np.einsum("ij,ij->i", v_sync, E_p_self))),
        }
        if np.any(self.B_ext != 0):
            tpar = np.full(self.n_species, np.nan)
            tperp = np.full(self.n_species, np.nan)
            for i, s in enumerate(self.species):
                m = ps.species_id == i
                if s.mobile and m.any():
                    tpar[i], tperp[i] = anisotropic_temperature(v_sync[m], ps.weights[m], s.mass_kg, self.B_ext)
            out["tpar"], out["tperp"] = tpar, tperp
        return out

    def _densities(self) -> np.ndarray:
        ps = self.particles
        out = np.zeros((self.n_species,) + self.grid.shape)
        for i, s in enumerate(self.species):
            if not s.mobile:
                out[i] = s.density_m3
                continue
            m = ps.species_id == i
            if m.any():
                out[i] = self.backend.deposit(ps.positions[m], ps.weights[m], self.grid, self.shape_dep, 0.5) \
                    / self.grid.cell_volume_m3
        return out

    def _base_state(self, obs: dict, E_total_grid, B_total_grid, we, wb, rho, phi, extras) -> PlasmaState:
        ps = self.particles
        _, qw, _ = self._per_particle()
        nc = self.grid.n_cells
        J = deposit_current(ps.positions, obs["v_sync"], qw, self.grid, self.shape_dep)
        Q = float(np.sum(qw)) + self.background_rho * self.grid.domain_volume_m3
        extras = dict(extras)
        extras.update(
            power_j_dot_e_w=obs["power_self"],
            kinetic_energy_by_species_j=obs["ke_by_species"].tolist(),
            momentum_scale_kg_m_s=obs["momentum_scale"],
            grid_charge_c=float(np.sum(rho)) * self.grid.cell_volume_m3,
            loss_ledger=self.ledger.to_dict(),
            particles_by_species=ps.count_by_species(self.n_species).tolist(),
            weight_by_species=obs["weights_by_species"].tolist(),
            temperature_estimator="3V isotropic, time-centred velocities",
        )
        if "tpar" in obs:
            extras["temperature_parallel_k"] = obs["tpar"].tolist()
            extras["temperature_perpendicular_k"] = obs["tperp"].tolist()
        return PlasmaState(
            time_s=self.time_s, step=self.step_index, grid=self.grid,
            species_names=[s.name for s in self.species],
            number_density_m3=self._densities().reshape(self.n_species, nc),
            charge_density_c_m3=rho.reshape(nc),
            current_density_a_m2=J.reshape(nc, 3),
            electric_field_v_m=E_total_grid.reshape(nc, 3),
            magnetic_field_t=B_total_grid.reshape(nc, 3),
            species_temperature_k=obs["temps"], electron_temperature_k=obs["te"], ion_temperature_k=obs["ti"],
            kinetic_energy_j=obs["kinetic_energy"], electric_field_energy_j=we, magnetic_field_energy_j=wb,
            total_charge_c=Q, total_momentum_kg_m_s=obs["momentum"],
            potential_v=None if phi is None else phi.reshape(nc),
            particle_positions_m=ps.positions.copy(), particle_velocities_m_s=obs["v_sync"],
            particle_species_id=ps.species_id.copy(), particle_weights=ps.weights.copy(),
            particle_ids=ps.particle_ids.copy(), solver=self.solver_name, extras=extras)

    # checkpoint ----------------------------------------------------------
    def _particle_arrays(self) -> dict[str, np.ndarray]:
        ps = self.particles
        return {"particles/positions_m": ps.positions, "particles/velocities_m_s": ps.velocities,
                "particles/species_id": ps.species_id, "particles/weights": ps.weights,
                "particles/particle_ids": ps.particle_ids}

    def _load_particles(self, a: dict[str, np.ndarray], scalars: dict) -> None:
        self.particles = ParticleState(a["particles/positions_m"], a["particles/velocities_m_s"],
                                       a["particles/species_id"], a["particles/weights"], a["particles/particle_ids"],
                                       float(scalars.get("velocity_time_offset", -0.5)))
        self.ledger = ParticleLossLedger.from_dict(self.n_species, scalars.get("loss_ledger", {}))
        self.step_index = int(scalars["step_index"])
        self._cache_n = -1

    def scalars(self) -> dict:
        return {"step_index": self.step_index, "velocity_time_offset": self.particles.velocity_time_offset,
                "loss_ledger": self.ledger.to_dict()}

    # stability -------------------------------------------------------------
    def timestep_assessments(self, scales) -> list:
        out = []
        dx = float(np.min(self.grid.spacing_m))
        if self.has_self_fields and scales.plasma_frequency_rad_s > 0:
            out.append(ts.plasma_oscillation_criterion(scales.plasma_frequency_rad_s, self.dt))
        if scales.max_cyclotron_frequency_rad_s > 0:
            out.append(ts.gyration_criterion(scales.max_cyclotron_frequency_rad_s, self.dt))
        vmax = scales.max_particle_speed_m_s
        if self.config.initial_condition.type == "single_particle":
            vmax = max(float(np.linalg.norm(v)) for v in self.config.initial_condition.velocities_m_s)
            Emag = float(np.linalg.norm(self.E_ext))
            Bmag = float(np.linalg.norm(self.B_ext))
            if Bmag > 0:
                vmax += 2 * Emag / Bmag
        if vmax > 0 and self.has_self_fields:
            out.append(ts.particle_cfl_criterion(vmax, self.dt, dx))
        return out

    def configuration_warnings(self, scales) -> list[str]:
        w = []
        if not self.has_self_fields:
            return w
        dx = float(np.min(self.grid.spacing_m))
        lam = scales.debye_length_m
        if math.isfinite(lam) and dx > math.pi * lam:
            w.append(f"dx/lambda_D = {dx / lam:.2f} > pi: risk of finite-grid (aliasing) heating "
                     "(Birdsall & Langdon ch. 8); refine the grid or accept numerical heating")
        ppc = self.config.particles.count / self.grid.n_cells if self.config.particles.count else 0
        if self.config.initial_condition.type != "single_particle" and ppc < 10:
            w.append(f"{ppc:.1f} macro-particles per cell per species: expect large statistical noise (< 10)")
        if self.config.solver.deposition != self.config.solver.interpolation:
            w.append("deposition and interpolation shapes differ: self-force present, momentum not conserved")
        L = float(np.min(self.grid.lengths_m))
        if math.isfinite(lam) and L < 10 * lam and self.config.initial_condition.type not in ("cold",):
            w.append(f"domain length {L:.3e} m is < 10 Debye lengths ({lam:.3e} m)")
        return w


# ==========================================================================
class ElectrostaticPICModel(_ParticleModel):
    solver_name = "electrostatic_pic"

    def __init__(self, config, grid, backend, collisions, runtime_rng) -> None:
        super().__init__(config, grid, backend, collisions, runtime_rng)
        fb = build_field_boundary(config)
        check_compatibility(self.solver_name, fb)
        self.field = ElectrostaticField(grid, config.solver.poisson, fb)
        self.E_self = np.zeros(grid.shape + (3,))
        self.rho = np.zeros(grid.shape)

    def _B_p(self):
        return self.B_ext  # uniform; broadcast inside the pusher

    def _solve_fields(self) -> None:
        self.rho = self._deposit_rho()
        self.E_self = self.field.solve(self.rho)  # self-consistent part only; E_ext added at gather

    def _E_total_p(self) -> tuple[np.ndarray, np.ndarray]:
        E_self_p = self._gather(self.E_self)
        return E_self_p + self.E_ext, E_self_p

    def initialize(self, seeds) -> None:
        self.particles = build_particles(self.config, self.grid, seeds)
        self._apply_boundaries()
        self._cache_n = -1
        self._solve_fields()
        Ep, _ = self._E_total_p()
        qm, _, _ = self._per_particle()
        self.particles.velocities = initial_half_step_back(self.backend, self.particles.velocities, Ep, self._B_p(),
                                                           qm, self.dt)
        self.particles.velocity_time_offset = -0.5
        self.step_index = 0

    def step(self) -> None:
        Ep, _ = self._E_total_p()
        qm, _, _ = self._per_particle()
        ps = self.particles
        v_new = self.backend.boris_push(ps.velocities, Ep, self._B_p(), qm, self.dt)
        if not self.collisions.is_collisionless:
            self.collisions.apply_particles(v_new, ps.species_id, self.masses, self.dt, self.rng)
        ps.velocities = v_new
        ps.positions += v_new * self.dt
        self._apply_boundaries()
        self._solve_fields()
        self.step_index += 1

    def observe(self) -> PlasmaState:
        Ep, Ep_self = self._E_total_p()
        obs = self._particle_observables(Ep, self._B_p(), Ep_self)
        we = electric_field_energy(self.E_self, self.grid.cell_volume_m3)
        E_total = self.E_self + self.E_ext
        B_total = np.broadcast_to(self.B_ext, self.grid.shape + (3,)).copy()
        last = self.field.last
        periodic = self.config.boundaries.fields == "periodic"
        extras = {"poisson_residual": last.residual, "removed_mean_charge_density": last.removed_mean_charge_density,
                  "gauss_residual": gauss_law_residual(self.E_self, self.rho, self.grid, periodic)}
        if np.any(self.E_ext):
            extras["power_external_w"] = float(np.sum(self._per_particle()[1] *
                                                      (obs["v_sync"] @ self.E_ext)))
        return self._base_state(obs, E_total, B_total, we, 0.0, self.rho, last.phi_v, extras)

    def state_arrays(self):
        a = self._particle_arrays()
        a.update({"fields/E_self_v_m": self.E_self, "fields/rho_c_m3": self.rho})
        return a

    def load_state_arrays(self, arrays, scalars) -> None:
        self._load_particles(arrays, scalars)
        self._solve_fields()  # recomputed deterministically from positions
        if not np.array_equal(self.E_self, arrays["fields/E_self_v_m"]):
            # identical inputs and code must reproduce the stored field exactly
            from ..exceptions import CheckpointError

            raise CheckpointError("electric field recomputed from checkpointed particles differs from stored field",
                                  why="non-deterministic field solve or modified checkpoint",
                                  parameter="fields/E_self_v_m",
                                  investigate="check software version and backend recorded in the checkpoint")


# ==========================================================================
class TestParticleModel(ElectrostaticPICModel):
    """Particles in uniform external fields only (no self-consistent fields)."""

    solver_name = "test_particle"
    has_self_fields = False
    __test__ = False  # not a pytest test class

    def __init__(self, config, grid, backend, collisions, runtime_rng) -> None:
        _ParticleModel.__init__(self, config, grid, backend, collisions, runtime_rng)
        self.E_self = np.zeros(grid.shape + (3,))
        self.rho = np.zeros(grid.shape)
        self.field = None

    def _solve_fields(self) -> None:
        self.rho = self._deposit_rho()

    def _E_total_p(self):
        z = np.zeros((self.particles.n, 3))
        return z + self.E_ext, z

    def observe(self) -> PlasmaState:
        Ep, Ep_self = self._E_total_p()
        obs = self._particle_observables(Ep, self._B_p(), Ep_self)
        E_total = np.broadcast_to(self.E_ext, self.grid.shape + (3,)).copy()
        B_total = np.broadcast_to(self.B_ext, self.grid.shape + (3,)).copy()
        extras = {"power_external_w": float(np.sum(self._per_particle()[1] * (obs["v_sync"] @ self.E_ext)))}
        return self._base_state(obs, E_total, B_total, 0.0, 0.0, self.rho, None, extras)

    def load_state_arrays(self, arrays, scalars) -> None:
        self._load_particles(arrays, scalars)
        self._solve_fields()


# ==========================================================================
class ElectromagneticPIC1DModel(_ParticleModel):
    solver_name = "electromagnetic_pic"

    def __init__(self, config, grid, backend, collisions, runtime_rng) -> None:
        super().__init__(config, grid, backend, collisions, runtime_rng)
        fb = build_field_boundary(config)
        check_compatibility(self.solver_name, fb)
        self.fields = ElectromagneticField1D(grid, self.dt, config.solver.poisson, fb, self.E_ext, self.B_ext)
        self.current = DirectCurrentDeposition(self.shape_dep, 0.5)
        self.rho = np.zeros(grid.shape)
        self.J = np.zeros(grid.shape + (3,))

    def _solve_longitudinal(self) -> None:
        self.rho = self._deposit_rho()
        self.fields.solve_longitudinal(self.rho)

    def _fields_at_particles(self):
        E_self = np.stack([self.fields.Ex, self.fields.yee.Ey, self.fields.yee.Ez], axis=1)
        E_self_p = self._gather(E_self, 0.5)
        B_p = self._gather(self.fields.b_edges(), 0.0) + self.B_ext
        return E_self_p + self.E_ext, B_p, E_self_p

    def initialize(self, seeds) -> None:
        self.particles = build_particles(self.config, self.grid, seeds)
        self._apply_boundaries()
        self._cache_n = -1
        self._solve_longitudinal()
        self._initial_em_wave()
        Ep, Bp, _ = self._fields_at_particles()
        qm, _, _ = self._per_particle()
        self.particles.velocities = initial_half_step_back(self.backend, self.particles.velocities, Ep, Bp, qm, self.dt)
        self.particles.velocity_time_offset = -0.5
        self.step_index = 0

    def _initial_em_wave(self) -> None:
        w = self.config.initial_condition.em_wave
        if w is None or w.amplitude_v_m == 0.0:
            return
        k = self.grid.mode_wavenumber(w.mode)
        xc = self.grid.centres(0) - self.grid.lower_m[0]
        xe = self.grid.edges(0)[:-1] - self.grid.lower_m[0]
        E = w.amplitude_v_m * np.cos(k * xc + w.phase_rad)
        B = (w.amplitude_v_m / SPEED_OF_LIGHT) * np.cos(k * xe + w.phase_rad) if w.kind == "travelling" else 0.0 * xe
        if w.polarization == "y":
            self.fields.yee.Ey[:] = E
            self.fields.yee.Bz[:] = B      # E_y, B_z = E_y/c : propagation along +x
        else:
            self.fields.yee.Ez[:] = E
            self.fields.yee.By[:] = -B     # E_z, B_y = -E_z/c : propagation along +x

    def step(self) -> None:
        Ep, Bp, _ = self._fields_at_particles()
        qm, qw, _ = self._per_particle()
        ps = self.particles
        x_old = ps.positions.copy()
        v_new = self.backend.boris_push(ps.velocities, Ep, Bp, qm, self.dt)
        if not self.collisions.is_collisionless:
            self.collisions.apply_particles(v_new, ps.species_id, self.masses, self.dt, self.rng)
        ps.velocities = v_new
        ps.positions += v_new * self.dt
        self._apply_boundaries()
        self.J = self.current.deposit(x_old, ps.positions, v_new, qw, self.grid, self.dt)
        self.fields.yee.step(self.J[:, 1], self.J[:, 2])
        self._solve_longitudinal()
        self.step_index += 1

    def observe(self) -> PlasmaState:
        Ep, Bp, Ep_self = self._fields_at_particles()
        obs = self._particle_observables(Ep, Bp, Ep_self)
        dV = self.grid.cell_volume_m3
        E_self = np.stack([self.fields.Ex, self.fields.yee.Ey, self.fields.yee.Ez], axis=1)
        we = electric_field_energy(E_self, dV)
        B_self_edges = self.fields.b_edges()
        wb = magnetic_field_energy(B_self_edges, dV)
        B_c = self.fields.b_centres_total()
        last = self.fields.longitudinal.last
        extras = {
            "poisson_residual": last.residual,
            "gauss_residual": gauss_law_residual(E_self, self.rho, self.grid, True),
            "longitudinal_field_energy_j": electric_field_energy(E_self[:, :1], dV),
            "transverse_electric_energy_j": electric_field_energy(E_self[:, 1:], dV),
            "field_momentum_kg_m_s": field_momentum(E_self, B_c - self.B_ext, dV).tolist(),
            "courant_number": self.fields.yee.courant,
        }
        return self._base_state(obs, E_self + self.E_ext, B_c, we, wb, self.rho, last.phi_v, extras)

    def state_arrays(self):
        a = self._particle_arrays()
        a.update({f"fields/{k}": v for k, v in self.fields.yee.state_arrays().items()})
        a["fields/J_a_m2"] = self.J
        return a

    def load_state_arrays(self, arrays, scalars) -> None:
        self._load_particles(arrays, scalars)
        self.fields.yee.load_state_arrays({k.split("/", 1)[1]: v for k, v in arrays.items() if k.startswith("fields/")})
        self.J = np.array(arrays["fields/J_a_m2"])
        self._solve_longitudinal()

    def timestep_assessments(self, scales) -> list:
        out = super().timestep_assessments(scales)
        out.append(ts.courant_em_criterion(self.dt, float(self.grid.spacing_m[0])))
        return out
