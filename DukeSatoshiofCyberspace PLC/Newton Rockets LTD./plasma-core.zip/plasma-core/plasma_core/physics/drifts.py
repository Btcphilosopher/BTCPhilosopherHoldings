"""Guiding-centre drift formulas and extension points.

The full-orbit (Boris) particle solver does *not* use any of these: they are
analytic references for validation and the interface for future reduced
(guiding-centre) models, which must remain distinct from the full-orbit solver.

    v_E    = E x B / B^2                                   (E x B drift)
    v_gradB = (m v_perp^2 / (2 q B^3)) (B x grad B)        (grad-B drift, grad |B|)
    v_curv  = (m v_par^2 / (q B^2)) (R_c x B) / R_c^2      (curvature drift)
    F_mirror = -mu grad_par B,  mu = m v_perp^2 / (2 B)    (mirror force)
"""

from __future__ import annotations

from abc import ABC, abstractmethod

import numpy as np


def exb_drift_velocity(E, B) -> np.ndarray:
    E = np.asarray(E, dtype=float)
    B = np.asarray(B, dtype=float)
    return np.cross(E, B) / np.sum(B * B, axis=-1, keepdims=True)


def grad_b_drift_velocity(mass_kg, charge_c, v_perp, B, grad_B) -> np.ndarray:
    """(m v_perp^2 / (2 q B^3)) B x grad|B|; vectors broadcast over a leading axis."""
    B = np.asarray(B, dtype=float)
    gB = np.asarray(grad_B, dtype=float)
    Bmag = np.linalg.norm(B, axis=-1, keepdims=True)
    coef = mass_kg * np.asarray(v_perp, dtype=float)[..., None] ** 2 / (2.0 * charge_c * Bmag**3)
    out = coef * np.cross(B, gB)
    return out.reshape(np.broadcast_shapes(B.shape, gB.shape))


def curvature_drift_velocity(mass_kg, charge_c, v_par, B, curvature_radius_vector) -> np.ndarray:
    B = np.asarray(B, dtype=float)
    Rc = np.asarray(curvature_radius_vector, dtype=float)
    B2 = float(np.dot(B, B))
    Rc2 = float(np.dot(Rc, Rc))
    return mass_kg * v_par**2 / (charge_c * B2) * np.cross(Rc, B) / Rc2


def magnetic_moment(mass_kg, v_perp, B_magnitude):
    return mass_kg * np.asarray(v_perp) ** 2 / (2.0 * np.asarray(B_magnitude))


class GuidingCentreModel(ABC):
    """Extension point for reduced guiding-centre dynamics (not implemented)."""

    @abstractmethod
    def advance(self, positions, v_parallel, magnetic_moment, dt):  # pragma: no cover
        raise NotImplementedError("guiding-centre models are a planned extension")
