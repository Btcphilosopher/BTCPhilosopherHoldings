"""Cyclotron (gyro) motion.

    omega_c = |q| B / m          [rad/s]   (angular cyclotron frequency)
    T_c     = 2 pi / omega_c     [s]
    r_L     = m v_perp / (|q| B) [m]       (Larmor radius)

The sense of rotation is left-handed about B for positive charges and
right-handed for negative charges; :func:`gyro_sense` returns -sign(q).
"""

from __future__ import annotations

import numpy as np


def cyclotron_frequency(charge_c, magnetic_field_t, mass_kg):
    """omega_c = |q| |B| / m [rad/s]."""
    return np.abs(np.asarray(charge_c, dtype=float)) * np.abs(np.asarray(magnetic_field_t, dtype=float)) / np.asarray(mass_kg, dtype=float)


def gyroperiod(charge_c, magnetic_field_t, mass_kg):
    """2 pi / omega_c [s]."""
    return 2.0 * np.pi / cyclotron_frequency(charge_c, magnetic_field_t, mass_kg)


def larmor_radius(v_perp_m_s, charge_c, magnetic_field_t, mass_kg):
    """r_L = m v_perp / (|q| B) [m]."""
    return np.asarray(mass_kg, dtype=float) * np.asarray(v_perp_m_s, dtype=float) / (
        np.abs(np.asarray(charge_c, dtype=float)) * np.abs(np.asarray(magnetic_field_t, dtype=float)))


def gyro_sense(charge_c) -> float:
    """+1 for right-handed rotation about B (electrons), -1 for left-handed (ions)."""
    return float(-np.sign(charge_c))
