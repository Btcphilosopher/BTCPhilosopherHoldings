"""Analytical / semi-analytical dispersion relations used for validation.

These are *theory* functions.  They never use simulation output, so they can
serve as independent references.  All frequencies are angular [rad/s].

Electrostatic kinetic dispersion (1D, drifting Maxwellians)
-----------------------------------------------------------
For species s with plasma frequency omega_ps, drift u_s and thermal speed
v_s = sqrt(k_B T_s / m_s):

    D(omega, k) = 1 + sum_s (omega_ps^2 / (k^2 v_s^2)) [1 + zeta_s Z(zeta_s)] = 0,
    zeta_s = (omega - k u_s) / (sqrt(2) k v_s),

where Z is the Fried-Conte plasma dispersion function
Z(zeta) = i sqrt(pi) w(zeta) with w the Faddeeva function (scipy.special.wofz).
w is entire, so this expression is the Landau-continued Z for all Im(zeta).
Cold species (T_s = 0) contribute -omega_ps^2/(omega - k u_s)^2.
"""

from __future__ import annotations

import math
from dataclasses import dataclass

from scipy.special import wofz

from ..constants import BOLTZMANN_CONSTANT, SPEED_OF_LIGHT


def plasma_dispersion_function(zeta):
    """Z(zeta) = i sqrt(pi) w(zeta)."""
    return 1j * math.sqrt(math.pi) * wofz(zeta)


def plasma_dispersion_derivative(zeta):
    """Z'(zeta) = -2 (1 + zeta Z(zeta))."""
    return -2.0 * (1.0 + zeta * plasma_dispersion_function(zeta))


@dataclass(frozen=True)
class KineticSpecies:
    """Minimal description of a species for the kinetic dispersion relation."""

    omega_p_rad_s: float
    drift_m_s: float
    thermal_speed_m_s: float  # sqrt(kT/m)

    @classmethod
    def from_species(cls, s) -> "KineticSpecies":
        return cls(s.plasma_frequency_rad_s, float(s.bulk_velocity_m_s[0]),
                   math.sqrt(BOLTZMANN_CONSTANT * s.temperature_k / s.mass_kg))


def electrostatic_dielectric(omega: complex, k: float, species: list[KineticSpecies]) -> tuple[complex, complex]:
    """Return (D(omega,k), dD/domega)."""
    D = 1.0 + 0j
    dD = 0j
    for s in species:
        if s.thermal_speed_m_s == 0.0:
            w = omega - k * s.drift_m_s
            D -= s.omega_p_rad_s**2 / w**2
            dD += 2.0 * s.omega_p_rad_s**2 / w**3
        else:
            a = math.sqrt(2.0) * k * s.thermal_speed_m_s
            zeta = (omega - k * s.drift_m_s) / a
            Z = plasma_dispersion_function(zeta)
            Zp = -2.0 * (1.0 + zeta * Z)
            pref = s.omega_p_rad_s**2 / (k**2 * s.thermal_speed_m_s**2)
            D += pref * (1.0 + zeta * Z)
            dD += pref * (Z + zeta * Zp) / a
    return D, dD


def solve_electrostatic_dispersion(k: float, species: list[KineticSpecies], omega_guess: complex,
                                   tol: float = 1e-13, max_iter: int = 200) -> complex:
    """Newton iteration for a root of D(omega, k) = 0 near ``omega_guess``."""
    omega = complex(omega_guess)
    scale = abs(omega) if omega != 0 else 1.0
    for _ in range(max_iter):
        D, dD = electrostatic_dielectric(omega, k, species)
        if dD == 0:
            break
        step = D / dD
        omega -= step
        if abs(step) < tol * scale:
            return omega
    raise RuntimeError(f"dispersion root did not converge (k={k}, guess={omega_guess})")


# --------------------------------------------------------------------------
# Fluid / cold-plasma relations
# --------------------------------------------------------------------------


def bohm_gross_frequency(omega_p: float, k: float, thermal_speed_m_s: float, gamma: float = 3.0) -> float:
    """omega^2 = omega_p^2 + gamma k^2 v_th^2, v_th = sqrt(kT/m) (gamma=3: 1D adiabatic)."""
    return math.sqrt(omega_p**2 + gamma * k**2 * thermal_speed_m_s**2)


def upper_hybrid_frequency(omega_p: float, omega_c: float) -> float:
    """omega_UH = sqrt(omega_p^2 + omega_c^2) (cold, k perpendicular to B, k lambda_D -> 0)."""
    return math.sqrt(omega_p**2 + omega_c**2)


def cold_em_wave_frequency(omega_p: float, k: float) -> float:
    """Transverse EM wave in a cold unmagnetised plasma: omega^2 = omega_p^2 + c^2 k^2."""
    return math.sqrt(omega_p**2 + (SPEED_OF_LIGHT * k) ** 2)


def leapfrog_oscillator_frequency(omega0: float, dt: float) -> float:
    """Frequency of a harmonic oscillator integrated with leapfrog: sin(w dt/2) = w0 dt/2."""
    x = omega0 * dt / 2.0
    if x >= 1.0:
        return float("nan")  # unstable
    return 2.0 / dt * math.asin(x)


def boris_gyrofrequency(omega_c: float, dt: float) -> float:
    """Numerical gyrofrequency of the Boris rotation: 2 arctan(omega_c dt / 2) / dt."""
    return 2.0 / dt * math.atan(omega_c * dt / 2.0)


def pic_cold_plasma_frequency(omega_p: float, k: float, dx: float, dt: float, *, shape_order: int,
                              poisson: str) -> float:
    """Principal-alias cold-plasma dispersion of the momentum-conserving ES-PIC scheme.

    omega_grid^2 = omega_p^2 * S(k)^2 * kappa(k) k / K^2(k)
      S(k)    = sinc^{order+1}(k dx/2)      (shape factor of NGP/CIC)
      kappa   = sin(k dx)/dx (centred gradient) or k (spectral)
      K^2     = (2 sin(k dx/2)/dx)^2 (FD Laplacian) or k^2 (spectral)
    followed by the leapfrog correction sin(omega dt/2) = omega_grid dt/2.
    Alias terms (p != 0) are neglected; they are O((k dx)^(4(order+1))).
    (Derivation: Birdsall & Langdon, Plasma Physics via Computer Simulation, ch. 4-5.)
    """
    h = k * dx / 2.0
    S = (math.sin(h) / h) ** (shape_order + 1)
    if poisson == "fft_spectral":
        kappa, K2 = k, k * k
    else:
        kappa, K2 = math.sin(k * dx) / dx, (2.0 * math.sin(h) / dx) ** 2
    w_grid = omega_p * math.sqrt(S * S * kappa * k / K2)
    return leapfrog_oscillator_frequency(w_grid, dt)


def yee_vacuum_frequency(k: float, dx: float, dt: float) -> float:
    """1D Yee discrete dispersion: sin(w dt/2)/(c dt) = sin(k dx/2)/dx."""
    s = SPEED_OF_LIGHT * dt / dx * math.sin(k * dx / 2.0)
    if s > 1.0:
        return float("nan")
    return 2.0 / dt * math.asin(s)


def cold_two_stream_growth_rate(omega_p_total: float, k: float, drift_m_s: float) -> float:
    """Max imaginary root for two equal cold counter-streaming beams (+-v0, each n0/2).

    omega^2 = a^2 + wb^2 - wb sqrt(wb^2 + 4 a^2),  a = k v0,  wb^2 = omega_p^2/2.
    Returns gamma >= 0 (0 if stable).  Maximum gamma = omega_p/(2 sqrt 2) at k v0 = sqrt(3/8) omega_p.
    """
    a2 = (k * drift_m_s) ** 2
    wb2 = omega_p_total**2 / 2.0
    w2 = a2 + wb2 - math.sqrt(wb2) * math.sqrt(wb2 + 4.0 * a2)
    return math.sqrt(-w2) if w2 < 0 else 0.0


def landau_damping_root(k_lambda_d: float) -> complex:
    """Normalised Langmuir root omega/omega_p for a single Maxwellian (k in units of 1/lambda_D)."""
    sp = [KineticSpecies(1.0, 0.0, 1.0)]  # omega_p = 1, v_th = 1 => lambda_D = 1
    guess = math.sqrt(1.0 + 3.0 * k_lambda_d**2) - 0.01j
    return solve_electrostatic_dispersion(k_lambda_d, sp, guess)
