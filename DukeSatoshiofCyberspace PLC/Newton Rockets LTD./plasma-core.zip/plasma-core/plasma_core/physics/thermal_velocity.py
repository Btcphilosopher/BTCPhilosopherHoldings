"""Thermal velocity with an explicit convention.

Two conventions are in common use and are *never* mixed in plasma_core.
Every call must state which one is meant:

``RMS_1D``         v_th = sqrt(k_B T / m)
    Standard deviation of one Cartesian velocity component of a Maxwellian.
    Used internally everywhere (loading, Debye length relation
    lambda_D = v_th / omega_p, Bohm-Gross relation).

``MOST_PROBABLE``  v_th = sqrt(2 k_B T / m)
    Most probable speed of a 2D Maxwellian / the 1D "e-folding" speed in
    f ~ exp(-v^2/v_th^2).  Used in the plasma dispersion function argument.
"""

from __future__ import annotations

from enum import Enum

import numpy as np

from ..constants import BOLTZMANN_CONSTANT


class ThermalVelocityConvention(str, Enum):
    RMS_1D = "sqrt(kT/m)"
    MOST_PROBABLE = "sqrt(2kT/m)"


def thermal_velocity(temperature_k, mass_kg, *, convention: ThermalVelocityConvention):
    """Thermal velocity [m/s] in the requested convention (keyword required)."""
    conv = ThermalVelocityConvention(convention)
    factor = 1.0 if conv is ThermalVelocityConvention.RMS_1D else 2.0
    return np.sqrt(factor * BOLTZMANN_CONSTANT * np.asarray(temperature_k, dtype=float) / np.asarray(mass_kg, dtype=float))
