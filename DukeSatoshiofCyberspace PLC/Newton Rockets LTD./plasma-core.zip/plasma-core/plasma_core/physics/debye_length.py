"""Debye length and plasma parameter.

    lambda_D,s = sqrt(epsilon_0 k_B T_s / (n_s q_s^2))   [m]
    1/lambda_D^2 = sum_s 1/lambda_D,s^2                  (total, all species with T_s > 0)
    N_D = (4/3) pi n lambda_D^3                          (particles per Debye sphere)
"""

from __future__ import annotations

import math

import numpy as np

from ..constants import BOLTZMANN_CONSTANT, VACUUM_PERMITTIVITY


def debye_length(temperature_k, density_m3, charge_c):
    """Debye length of one species [m]; returns 0 for T = 0 (cold)."""
    T = np.asarray(temperature_k, dtype=float)
    return np.sqrt(VACUUM_PERMITTIVITY * BOLTZMANN_CONSTANT * T
                   / (np.asarray(density_m3, dtype=float) * np.asarray(charge_c, dtype=float) ** 2))


def total_debye_length(species) -> float:
    """Combined Debye length over mobile species with T > 0 [m]; inf if all are cold."""
    inv2 = 0.0
    for s in species:
        if s.mobile and s.temperature_k > 0:
            inv2 += 1.0 / float(debye_length(s.temperature_k, s.density_m3, s.charge_c)) ** 2
    return math.inf if inv2 == 0 else 1.0 / math.sqrt(inv2)


def debye_number(density_m3: float, debye_length_m: float) -> float:
    """Number of particles in a Debye sphere, (4/3) pi n lambda_D^3."""
    return 4.0 / 3.0 * math.pi * density_m3 * debye_length_m**3
