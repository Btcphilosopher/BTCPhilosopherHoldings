"""Characteristic plasma scales of a configuration.

Computes the length/time/velocity scales listed below for every species and
for the combined plasma, so that the simulation set-up can be compared with
the physics it is meant to resolve.

Per species:   omega_p, plasma period, v_th = sqrt(kT/m), lambda_D,
               omega_c, gyroperiod, Larmor radius (thermal), skin depth c/omega_p
Combined:      omega_p,total, lambda_D,total, Alfven speed, beta,
               particle crossing time of one cell (max speed estimate),
               light crossing time of one cell.
"""

from __future__ import annotations

import math
from dataclasses import asdict, dataclass, field

import numpy as np

from ..constants import BOLTZMANN_CONSTANT, SPEED_OF_LIGHT
from .debye_length import debye_length, total_debye_length
from .gyrofrequency import cyclotron_frequency, larmor_radius
from .plasma_frequency import plasma_frequency, total_plasma_frequency
from .pressure import alfven_speed, plasma_beta


@dataclass
class SpeciesScales:
    name: str
    plasma_frequency_rad_s: float
    plasma_period_s: float
    thermal_speed_rms_1d_m_s: float
    debye_length_m: float
    cyclotron_frequency_rad_s: float
    gyroperiod_s: float
    thermal_larmor_radius_m: float
    skin_depth_m: float
    max_speed_estimate_m_s: float


@dataclass
class CharacteristicScales:
    species: list[SpeciesScales]
    plasma_frequency_rad_s: float
    plasma_period_s: float
    debye_length_m: float
    magnetic_field_t: float
    alfven_speed_m_s: float
    plasma_beta: float
    max_cyclotron_frequency_rad_s: float
    min_gyroperiod_s: float
    cell_size_m: float
    max_particle_speed_m_s: float
    particle_crossing_time_s: float
    light_crossing_time_s: float
    extras: dict = field(default_factory=dict)

    def to_dict(self) -> dict:
        return asdict(self)


def compute_scales(species, magnetic_field_t: float, cell_size_m: float, thermal_tail_factor: float = 5.0) -> CharacteristicScales:
    """Characteristic scales for a list of :class:`~plasma_core.species.Species`.

    ``max_speed_estimate`` = |u| + thermal_tail_factor * sqrt(kT/m) is used for
    the particle crossing time dx / v_max (default: 5 thermal speeds).
    """
    B = abs(float(magnetic_field_t))
    sp: list[SpeciesScales] = []
    rho_m = 0.0
    vmax = 0.0
    for s in species:
        if not s.mobile:
            continue
        wp = float(plasma_frequency(s.density_m3, s.charge_c, s.mass_kg))
        vt = math.sqrt(BOLTZMANN_CONSTANT * s.temperature_k / s.mass_kg)
        wc = float(cyclotron_frequency(s.charge_c, B, s.mass_kg)) if B > 0 else 0.0
        u = float(np.linalg.norm(s.bulk_velocity_m_s))
        vs = u + thermal_tail_factor * vt
        vmax = max(vmax, vs)
        rho_m += s.mass_density_kg_m3
        sp.append(SpeciesScales(
            name=s.name,
            plasma_frequency_rad_s=wp,
            plasma_period_s=2 * math.pi / wp,
            thermal_speed_rms_1d_m_s=vt,
            debye_length_m=float(debye_length(s.temperature_k, s.density_m3, s.charge_c)),
            cyclotron_frequency_rad_s=wc,
            gyroperiod_s=2 * math.pi / wc if wc > 0 else math.inf,
            thermal_larmor_radius_m=float(larmor_radius(vt, s.charge_c, B, s.mass_kg)) if B > 0 else math.inf,
            skin_depth_m=SPEED_OF_LIGHT / wp,
            max_speed_estimate_m_s=vs,
        ))
    wp_tot = total_plasma_frequency(species)
    wc_max = max((x.cyclotron_frequency_rad_s for x in sp), default=0.0)
    return CharacteristicScales(
        species=sp,
        plasma_frequency_rad_s=wp_tot,
        plasma_period_s=2 * math.pi / wp_tot if wp_tot > 0 else math.inf,
        debye_length_m=total_debye_length(species),
        magnetic_field_t=B,
        alfven_speed_m_s=alfven_speed(B, rho_m) if (B > 0 and rho_m > 0) else 0.0,
        plasma_beta=plasma_beta(species, B),
        max_cyclotron_frequency_rad_s=wc_max,
        min_gyroperiod_s=2 * math.pi / wc_max if wc_max > 0 else math.inf,
        cell_size_m=float(cell_size_m),
        max_particle_speed_m_s=vmax,
        particle_crossing_time_s=cell_size_m / vmax if vmax > 0 else math.inf,
        light_crossing_time_s=cell_size_m / SPEED_OF_LIGHT,
    )
