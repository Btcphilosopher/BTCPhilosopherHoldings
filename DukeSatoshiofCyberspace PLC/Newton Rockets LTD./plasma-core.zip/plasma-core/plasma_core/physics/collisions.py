"""Collision models.

The governing kinetic equation carries a collision operator C[f]:

    df/dt + v . grad_x f + (q/m)(E + v x B) . grad_v f = C[f]

plasma_core never applies collisions unless a non-trivial model is selected
explicitly in the configuration.  The selected model is printed in the
startup summary and recorded in all metadata.

Implemented
-----------
:class:`Collisionless`
    C[f] = 0.

:class:`EffectiveCollisionFrequency`
    Relaxation towards a *fixed background* Maxwellian (temperature T_b, drift
    u_b) at a prescribed collision frequency nu [s^-1].

    * Particles: exact Ornstein-Uhlenbeck (Langevin) update over one step dt
          v <- u_b + (v - u_b) e^{-nu dt} + sqrt(k_B T_b/m (1 - e^{-2 nu dt})) xi,
      xi ~ N(0, 1) per component, drawn from the simulation's recorded
      numpy Generator.  This is the Fokker-Planck operator for collisions
      with an infinitely massive thermal background (e.g. a neutral gas in the
      limit of heavy neutrals).  It does *not* conserve particle momentum or
      energy - the background is a reservoir.
    * Distribution functions: BGK relaxation
          f <- f_M + (f - f_M) e^{-nu dt},
      where f_M is the Maxwellian with the *local* density, mean velocity and
      temperature of f (moment-conserving BGK, Bhatnagar-Gross-Krook 1954),
      multiplied by a quadratic correction (a + b v + c v^2) per cell that makes
      its *discrete* moments 0, 1, 2 equal those of f.  Density, momentum and
      energy are therefore conserved to round-off on the velocity grid.

Extension points (not implemented - raise NotImplementedError)
--------------------------------------------------------------
:class:`CoulombCollisions` (e.g. Takizuka-Abe binary collisions, Landau/
Rosenbluth operator), :class:`MonteCarloCollisions` (null-collision MCC with
cross sections), :class:`NeutralCollisions` (elastic/charge-exchange with
tabulated cross sections).

Reference collision-frequency estimates
---------------------------------------
:func:`coulomb_logarithm` and :func:`electron_ion_collision_frequency` are
*estimates* for diagnosing whether a nominally collisionless run is
justified; they are never applied automatically.
"""

from __future__ import annotations

import math
from abc import ABC, abstractmethod

import numpy as np

from ..constants import BOLTZMANN_CONSTANT, ELECTRON_MASS, ELEMENTARY_CHARGE, VACUUM_PERMITTIVITY


class CollisionModel(ABC):
    """Interface for collision operators."""

    name: str = "abstract"
    #: whether the operator consumes random numbers (affects restart state)
    stochastic: bool = False

    @property
    def is_collisionless(self) -> bool:
        return False

    @abstractmethod
    def apply_particles(self, velocities: np.ndarray, species_id: np.ndarray, masses_kg: np.ndarray,
                        dt: float, rng: np.random.Generator) -> None:
        """Apply the operator to particle velocities in place over one step dt."""

    @abstractmethod
    def apply_distribution(self, f: np.ndarray, v: np.ndarray, dv: float, mass_kg: float, dt: float) -> np.ndarray:
        """Apply the operator to a 1D1V distribution f[x, v] over dt; return new f."""

    def describe(self) -> dict:
        return {"model": self.name}


class Collisionless(CollisionModel):
    name = "collisionless"

    @property
    def is_collisionless(self) -> bool:
        return True

    def apply_particles(self, velocities, species_id, masses_kg, dt, rng):
        return None

    def apply_distribution(self, f, v, dv, mass_kg, dt):
        return f


class EffectiveCollisionFrequency(CollisionModel):
    """Relaxation at a prescribed collision frequency (see module docstring)."""

    name = "effective_collision_frequency"
    stochastic = True

    def __init__(self, frequency_hz: float, background_temperature_k: float = 0.0,
                 background_velocity_m_s=(0.0, 0.0, 0.0)) -> None:
        if frequency_hz < 0:
            raise ValueError("collision frequency must be >= 0")
        self.nu = float(frequency_hz)
        self.T_b = float(background_temperature_k)
        self.u_b = np.asarray(background_velocity_m_s, dtype=float).reshape(3)

    def apply_particles(self, velocities, species_id, masses_kg, dt, rng):
        if self.nu == 0.0:
            return
        decay = math.exp(-self.nu * dt)
        m = masses_kg[species_id][:, None]
        sigma = np.sqrt(BOLTZMANN_CONSTANT * self.T_b / m * (1.0 - decay * decay))
        noise = rng.standard_normal(velocities.shape)
        velocities -= self.u_b
        velocities *= decay
        velocities += self.u_b + sigma * noise

    def apply_distribution(self, f, v, dv, mass_kg, dt):
        if self.nu == 0.0:
            return f
        n = f.sum(axis=1) * dv
        safe_n = np.where(n > 0, n, 1.0)
        u = (f * v[None, :]).sum(axis=1) * dv / safe_n
        var = (f * (v[None, :] - u[:, None]) ** 2).sum(axis=1) * dv / safe_n
        var = np.maximum(var, 1e-300)
        fm = n[:, None] / np.sqrt(2 * np.pi * var[:, None]) * np.exp(-(v[None, :] - u[:, None]) ** 2 / (2 * var[:, None]))
        # Discrete moment matching: f_M <- f_M (a + b v + c v^2) with (a, b, c) chosen per cell so that the
        # discrete moments 0, 1, 2 of f_M equal those of f exactly (the sampled Maxwellian is truncated by the
        # finite velocity grid, so without this correction BGK would not conserve n, nu, energy discretely).
        powers = np.stack([np.ones_like(v), v, v * v])  # (3, nv)
        M = np.einsum("xv,iv,jv->xij", fm, powers, powers) * dv
        rhs = np.einsum("xv,iv->xi", f, powers) * dv
        ok = n > 0
        coef = np.zeros((f.shape[0], 3))
        coef[:, 0] = 1.0
        if ok.any():
            coef[ok] = np.linalg.solve(M[ok], rhs[ok][..., None])[..., 0]
        fm = fm * np.einsum("xi,iv->xv", coef, powers)
        decay = math.exp(-self.nu * dt)
        return fm + (f - fm) * decay

    def describe(self):
        return {"model": self.name, "frequency_hz": self.nu, "background_temperature_k": self.T_b,
                "background_velocity_m_s": self.u_b.tolist()}


class _NotImplementedCollisions(CollisionModel):
    reason = "not implemented"

    def __init__(self, *args, **kwargs) -> None:
        raise NotImplementedError(f"{type(self).__name__} is an extension point: {self.reason}")

    def apply_particles(self, *a, **k):  # pragma: no cover
        raise NotImplementedError

    def apply_distribution(self, *a, **k):  # pragma: no cover
        raise NotImplementedError


class CoulombCollisions(_NotImplementedCollisions):
    name = "coulomb"
    reason = "binary Coulomb collisions (e.g. Takizuka-Abe) require pairing and are not yet implemented"


class MonteCarloCollisions(_NotImplementedCollisions):
    name = "monte_carlo"
    reason = "null-collision Monte Carlo requires cross-section data and is not yet implemented"


class NeutralCollisions(_NotImplementedCollisions):
    name = "neutral"
    reason = "charged-neutral collisions require tabulated cross sections and are not yet implemented"


def build_collision_model(config) -> CollisionModel:
    """Construct the collision model selected in a :class:`CollisionConfig`."""
    if config is None or config.model == "collisionless":
        return Collisionless()
    if config.model == "effective_frequency":
        return EffectiveCollisionFrequency(config.frequency_hz, config.background_temperature_k,
                                           config.background_velocity_m_s)
    raise ValueError(f"unknown collision model {config.model}")


# --------------------------------------------------------------------------
# Estimates (diagnostic only)
# --------------------------------------------------------------------------


def coulomb_logarithm(density_m3: float, temperature_k: float) -> float:
    """Classical estimate ln(Lambda), Lambda = 12 pi n lambda_De^3 (approximate)."""
    lam = math.sqrt(VACUUM_PERMITTIVITY * BOLTZMANN_CONSTANT * temperature_k / (density_m3 * ELEMENTARY_CHARGE**2))
    Lam = 12.0 * math.pi * density_m3 * lam**3
    return math.log(Lam) if Lam > 1 else float("nan")


def electron_ion_collision_frequency(density_m3: float, temperature_k: float, ion_charge_state: int = 1,
                                     coulomb_log: float | None = None) -> float:
    """1/tau_e in Braginskii's convention [s^-1] (estimate):

        1/tau_e = sqrt(2) n_e Z e^4 lnL / (12 pi^{3/2} eps0^2 sqrt(m_e) (k_B T_e)^{3/2})

    (S. I. Braginskii, Reviews of Plasma Physics vol. 1, 1965).  Here n_e = Z n_i.
    """
    lnL = coulomb_log if coulomb_log is not None else coulomb_logarithm(density_m3, temperature_k)
    kT = BOLTZMANN_CONSTANT * temperature_k
    return (math.sqrt(2.0) * density_m3 * ion_charge_state * ELEMENTARY_CHARGE**4 * lnL
            / (12.0 * math.pi**1.5 * VACUUM_PERMITTIVITY**2 * math.sqrt(ELECTRON_MASS) * kT**1.5))
