"""Plasma frequency.

    omega_p,s = sqrt(n_s q_s^2 / (m_s epsilon_0))     [rad/s]
    omega_p^2 = sum_s omega_p,s^2                     (total)
    T_p = 2 pi / omega_p                              [s]
"""

from __future__ import annotations

import numpy as np

from ..constants import VACUUM_PERMITTIVITY


def plasma_frequency(density_m3, charge_c, mass_kg):
    """Angular plasma frequency of one species [rad/s]."""
    return np.sqrt(np.asarray(density_m3, dtype=float) * np.asarray(charge_c, dtype=float) ** 2
                   / (np.asarray(mass_kg, dtype=float) * VACUUM_PERMITTIVITY))


def total_plasma_frequency(species) -> float:
    """sqrt(sum_s omega_p,s^2) over *mobile* species [rad/s]."""
    return float(np.sqrt(sum(plasma_frequency(s.density_m3, s.charge_c, s.mass_kg) ** 2
                             for s in species if s.mobile)))


def plasma_period(omega_p) -> float:
    """2 pi / omega_p [s]."""
    return 2.0 * np.pi / np.asarray(omega_p, dtype=float)
