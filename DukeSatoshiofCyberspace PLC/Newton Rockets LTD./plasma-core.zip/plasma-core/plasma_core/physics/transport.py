"""Simple transport coefficients derived from a given collision frequency.

These relations follow from a single-relaxation-time (Drude / Lorentz-gas)
model and are only as accurate as the collision frequency supplied.  They are
labelled approximate and are not used implicitly by any solver.

    sigma   = n q^2 / (m nu)            electrical conductivity [S/m]
    mu      = |q| / (m nu)              mobility [m^2 V^-1 s^-1]
    D       = k_B T / (m nu)            diffusion coefficient [m^2/s]
    (Einstein relation D = mu k_B T / |q| holds by construction.)
    sigma_perp / sigma_par = nu^2 / (nu^2 + omega_c^2)   (Drude cross-field reduction)
"""

from __future__ import annotations

from ..constants import BOLTZMANN_CONSTANT


def drude_conductivity(density_m3: float, charge_c: float, mass_kg: float, collision_frequency_hz: float) -> float:
    return density_m3 * charge_c**2 / (mass_kg * collision_frequency_hz)


def mobility(charge_c: float, mass_kg: float, collision_frequency_hz: float) -> float:
    return abs(charge_c) / (mass_kg * collision_frequency_hz)


def diffusion_coefficient(temperature_k: float, mass_kg: float, collision_frequency_hz: float) -> float:
    return BOLTZMANN_CONSTANT * temperature_k / (mass_kg * collision_frequency_hz)


def perpendicular_conductivity_factor(collision_frequency_hz: float, cyclotron_frequency_rad_s: float) -> float:
    nu2 = collision_frequency_hz**2
    return nu2 / (nu2 + cyclotron_frequency_rad_s**2)
