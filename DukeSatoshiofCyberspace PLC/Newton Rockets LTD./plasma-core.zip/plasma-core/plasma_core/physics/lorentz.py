"""Lorentz force (non-relativistic).

    F = q (E + v x B)            [N]
    dv/dt = (q/m) (E + v x B)    [m/s^2]

All functions are vectorised over particles.  Shapes: ``v``, ``E``, ``B``
are ``(N, 3)`` (or broadcastable, e.g. ``(3,)`` for a uniform field);
``q`` and ``m`` are scalars or ``(N,)`` arrays.
"""

from __future__ import annotations

import numpy as np


def lorentz_force(q, v, E, B) -> np.ndarray:
    """F = q (E + v x B), returns shape (N, 3) [N]."""
    v = np.asarray(v, dtype=float)
    q = np.asarray(q, dtype=float)
    if q.ndim == 1:
        q = q[:, None]
    return q * (np.asarray(E, dtype=float) + np.cross(v, np.asarray(B, dtype=float)))


def lorentz_acceleration(q_over_m, v, E, B) -> np.ndarray:
    """a = (q/m)(E + v x B), returns shape (N, 3) [m/s^2]."""
    qm = np.asarray(q_over_m, dtype=float)
    if qm.ndim == 1:
        qm = qm[:, None]
    v = np.asarray(v, dtype=float)
    return qm * (np.asarray(E, dtype=float) + np.cross(v, np.asarray(B, dtype=float)))
