"""Pressure, plasma beta, magnetic pressure and fluid equation-of-state closures.

    p_s       = n_s k_B T_s                     [Pa]   (ideal scalar pressure)
    p_B       = |B|^2 / (2 mu_0)                [Pa]
    beta      = sum_s p_s / p_B
    v_A       = |B| / sqrt(mu_0 rho_m),  rho_m = sum_s m_s n_s   [m/s]

Equation-of-state closures (fluid model)
----------------------------------------
A closure supplies the scalar pressure p(n[, epsilon]) and the squared sound
speed c_s^2 = dp/d(rho_m) used by the fluid solver's wave-speed estimate.

* :class:`IsothermalClosure`  p = n k_B T0;               c_s^2 = k_B T0 / m
* :class:`PolytropicClosure`  p = p0 (n/n0)^gamma;        c_s^2 = gamma p / (m n)
* :class:`AdiabaticClosure`   polytropic closure whose reference state is the
                              initial (n0, T0) of the species (isentropic flow)
* :class:`IdealGasClosure`    p = (gamma-1)(epsilon - m n |v|^2 / 2), the
                              total energy density epsilon is evolved by the
                              energy equation;            c_s^2 = gamma p/(m n)
* :class:`CustomClosure`      user-supplied p(n) and dp/dn

Assumptions: isotropic scalar pressure (no pressure tensor, no heat flux);
the closures are local and instantaneous.  For 1D electron plasma waves
the kinetic result omega^2 = omega_p^2 + 3 k^2 k_B T/m corresponds to the
adiabatic closure with gamma = 3 (one translational degree of freedom).
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Callable

import numpy as np

from ..constants import BOLTZMANN_CONSTANT, VACUUM_PERMEABILITY


def kinetic_pressure(density_m3, temperature_k):
    """p = n k_B T [Pa]."""
    return np.asarray(density_m3, dtype=float) * BOLTZMANN_CONSTANT * np.asarray(temperature_k, dtype=float)


def magnetic_pressure(magnetic_field_t):
    """p_B = B^2 / (2 mu_0) [Pa]."""
    return np.asarray(magnetic_field_t, dtype=float) ** 2 / (2.0 * VACUUM_PERMEABILITY)


def plasma_beta(species, magnetic_field_t: float) -> float:
    """beta = sum_s n_s k_B T_s / (B^2 / 2 mu_0); inf for B = 0."""
    pB = float(magnetic_pressure(magnetic_field_t))
    p = sum(float(kinetic_pressure(s.density_m3, s.temperature_k)) for s in species if s.mobile)
    return float("inf") if pB == 0 else p / pB


def alfven_speed(magnetic_field_t: float, mass_density_kg_m3: float) -> float:
    """v_A = B / sqrt(mu_0 rho_m) [m/s] (non-relativistic; may exceed c formally)."""
    return float(abs(magnetic_field_t) / np.sqrt(VACUUM_PERMEABILITY * mass_density_kg_m3))


# --------------------------------------------------------------------------
# Closures
# --------------------------------------------------------------------------


class PressureClosure(ABC):
    """Interface of a fluid pressure closure."""

    #: True if the closure requires the energy equation to be evolved.
    evolves_energy: bool = False
    name: str = "abstract"

    @abstractmethod
    def pressure(self, density_m3: np.ndarray, mass_kg: float,
                 internal_energy_density_j_m3: np.ndarray | None = None) -> np.ndarray:
        """Scalar pressure [Pa]."""

    @abstractmethod
    def sound_speed_sq(self, density_m3: np.ndarray, pressure_pa: np.ndarray, mass_kg: float) -> np.ndarray:
        """c_s^2 [m^2/s^2]."""

    def describe(self) -> dict:
        return {"closure": self.name}


class IsothermalClosure(PressureClosure):
    name = "isothermal"

    def __init__(self, temperature_k: float) -> None:
        if temperature_k < 0:
            raise ValueError("temperature must be >= 0")
        self.temperature_k = float(temperature_k)

    def pressure(self, density_m3, mass_kg, internal_energy_density_j_m3=None):
        return np.asarray(density_m3) * BOLTZMANN_CONSTANT * self.temperature_k

    def sound_speed_sq(self, density_m3, pressure_pa, mass_kg):
        return np.full_like(np.asarray(density_m3, dtype=float), BOLTZMANN_CONSTANT * self.temperature_k / mass_kg)

    def describe(self):
        return {"closure": self.name, "temperature_k": self.temperature_k}


class PolytropicClosure(PressureClosure):
    name = "polytropic"

    def __init__(self, gamma: float, reference_density_m3: float, reference_pressure_pa: float) -> None:
        if gamma < 1.0:
            raise ValueError("polytropic index gamma must be >= 1")
        if reference_density_m3 <= 0 or reference_pressure_pa < 0:
            raise ValueError("reference density must be > 0 and pressure >= 0")
        self.gamma = float(gamma)
        self.n0 = float(reference_density_m3)
        self.p0 = float(reference_pressure_pa)

    def pressure(self, density_m3, mass_kg, internal_energy_density_j_m3=None):
        n = np.maximum(np.asarray(density_m3, dtype=float), 0.0)
        return self.p0 * (n / self.n0) ** self.gamma

    def sound_speed_sq(self, density_m3, pressure_pa, mass_kg):
        n = np.maximum(np.asarray(density_m3, dtype=float), 1e-300)
        return self.gamma * np.asarray(pressure_pa) / (mass_kg * n)

    def describe(self):
        return {"closure": self.name, "gamma": self.gamma, "n0_m3": self.n0, "p0_pa": self.p0}


class AdiabaticClosure(PolytropicClosure):
    """Isentropic closure p = n0 k T0 (n/n0)^gamma referenced to the initial state."""

    name = "adiabatic"

    def __init__(self, gamma: float, initial_density_m3: float, initial_temperature_k: float) -> None:
        super().__init__(gamma, initial_density_m3, initial_density_m3 * BOLTZMANN_CONSTANT * initial_temperature_k)


class IdealGasClosure(PressureClosure):
    """p = (gamma - 1) * (epsilon - m n |v|^2 / 2); energy equation is evolved."""

    name = "ideal_gas"
    evolves_energy = True

    def __init__(self, gamma: float = 5.0 / 3.0) -> None:
        if gamma <= 1.0:
            raise ValueError("ideal-gas gamma must be > 1")
        self.gamma = float(gamma)

    def pressure(self, density_m3, mass_kg, internal_energy_density_j_m3=None):
        if internal_energy_density_j_m3 is None:
            raise ValueError("ideal-gas closure needs the internal energy density")
        return (self.gamma - 1.0) * np.asarray(internal_energy_density_j_m3)

    def sound_speed_sq(self, density_m3, pressure_pa, mass_kg):
        n = np.maximum(np.asarray(density_m3, dtype=float), 1e-300)
        return self.gamma * np.maximum(np.asarray(pressure_pa), 0.0) / (mass_kg * n)

    def describe(self):
        return {"closure": self.name, "gamma": self.gamma}


class CustomClosure(PressureClosure):
    """User-defined barotropic closure p = p(n) with derivative dp/dn."""

    name = "custom"

    def __init__(self, pressure_fn: Callable[[np.ndarray], np.ndarray],
                 dpressure_dn_fn: Callable[[np.ndarray], np.ndarray], label: str = "custom") -> None:
        self._p = pressure_fn
        self._dp = dpressure_dn_fn
        self.label = label

    def pressure(self, density_m3, mass_kg, internal_energy_density_j_m3=None):
        return self._p(np.asarray(density_m3, dtype=float))

    def sound_speed_sq(self, density_m3, pressure_pa, mass_kg):
        return np.maximum(self._dp(np.asarray(density_m3, dtype=float)), 0.0) / mass_kg

    def describe(self):
        return {"closure": self.name, "label": self.label}
