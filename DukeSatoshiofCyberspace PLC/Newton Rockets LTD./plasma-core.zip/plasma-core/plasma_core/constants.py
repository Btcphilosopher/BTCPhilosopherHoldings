"""Authoritative physical constants for plasma_core.

This is the *only* module in the package that defines numerical values of
physical constants. Every other module must import from here.

Source
------
All values are the CODATA 2018 recommended values, published in

    E. Tiesinga, P. J. Mohr, D. B. Newell, B. N. Taylor,
    "CODATA recommended values of the fundamental physical constants: 2018",
    Rev. Mod. Phys. 93, 025010 (2021).

Since the 2019 SI redefinition the elementary charge, Boltzmann constant,
Planck constant and speed of light are *exact* by definition.  The vacuum
permittivity and permeability are measured quantities in the revised SI.

The identifier ``CONSTANTS_VERSION`` is recorded in every output file so that
results can be traced to the constant set used to compute them.
"""

from __future__ import annotations

from dataclasses import dataclass

CONSTANTS_VERSION = "CODATA-2018"

_CODATA_2018 = (
    "CODATA 2018 recommended values; Tiesinga et al., Rev. Mod. Phys. 93, 025010 (2021)"
)


@dataclass(frozen=True)
class PhysicalConstant:
    """A documented physical constant.

    Attributes
    ----------
    name:
        Human-readable name.
    symbol:
        Conventional symbol.
    value:
        Numerical value in SI units.
    unit:
        SI unit string.
    exact:
        True if the value is exact by definition of the SI (2019 redefinition).
    description:
        Short physical description.
    source:
        Reference for the numerical value.
    """

    name: str
    symbol: str
    value: float
    unit: str
    exact: bool
    description: str
    source: str = _CODATA_2018

    def __float__(self) -> float:  # allows float(CONSTANT)
        return self.value


ELEMENTARY_CHARGE_CONSTANT = PhysicalConstant(
    name="elementary charge",
    symbol="e",
    value=1.602176634e-19,
    unit="C",
    exact=True,
    description="Magnitude of the electron charge.",
)
ELECTRON_MASS_CONSTANT = PhysicalConstant(
    name="electron mass",
    symbol="m_e",
    value=9.1093837015e-31,
    unit="kg",
    exact=False,
    description="Rest mass of the electron (relative standard uncertainty 3.0e-10).",
)
PROTON_MASS_CONSTANT = PhysicalConstant(
    name="proton mass",
    symbol="m_p",
    value=1.67262192369e-27,
    unit="kg",
    exact=False,
    description="Rest mass of the proton (relative standard uncertainty 3.1e-10).",
)
ATOMIC_MASS_CONSTANT_CONSTANT = PhysicalConstant(
    name="atomic mass constant",
    symbol="m_u",
    value=1.66053906660e-27,
    unit="kg",
    exact=False,
    description="One twelfth of the mass of a carbon-12 atom (unified atomic mass unit).",
)
VACUUM_PERMITTIVITY_CONSTANT = PhysicalConstant(
    name="vacuum electric permittivity",
    symbol="epsilon_0",
    value=8.8541878128e-12,
    unit="F m^-1",
    exact=False,
    description="Electric constant (relative standard uncertainty 1.5e-10).",
)
VACUUM_PERMEABILITY_CONSTANT = PhysicalConstant(
    name="vacuum magnetic permeability",
    symbol="mu_0",
    value=1.25663706212e-6,
    unit="N A^-2",
    exact=False,
    description="Magnetic constant (relative standard uncertainty 1.5e-10).",
)
BOLTZMANN_CONSTANT_CONSTANT = PhysicalConstant(
    name="Boltzmann constant",
    symbol="k_B",
    value=1.380649e-23,
    unit="J K^-1",
    exact=True,
    description="Relates thermodynamic temperature to energy.",
)
SPEED_OF_LIGHT_CONSTANT = PhysicalConstant(
    name="speed of light in vacuum",
    symbol="c",
    value=299792458.0,
    unit="m s^-1",
    exact=True,
    description="Speed of electromagnetic waves in vacuum.",
)
PLANCK_CONSTANT_CONSTANT = PhysicalConstant(
    name="Planck constant",
    symbol="h",
    value=6.62607015e-34,
    unit="J s",
    exact=True,
    description="Quantum of action.",
)

#: Registry of all documented constants, keyed by Python identifier.
CONSTANTS: dict[str, PhysicalConstant] = {
    "ELEMENTARY_CHARGE": ELEMENTARY_CHARGE_CONSTANT,
    "ELECTRON_MASS": ELECTRON_MASS_CONSTANT,
    "PROTON_MASS": PROTON_MASS_CONSTANT,
    "ATOMIC_MASS_CONSTANT": ATOMIC_MASS_CONSTANT_CONSTANT,
    "VACUUM_PERMITTIVITY": VACUUM_PERMITTIVITY_CONSTANT,
    "VACUUM_PERMEABILITY": VACUUM_PERMEABILITY_CONSTANT,
    "BOLTZMANN_CONSTANT": BOLTZMANN_CONSTANT_CONSTANT,
    "SPEED_OF_LIGHT": SPEED_OF_LIGHT_CONSTANT,
    "PLANCK_CONSTANT": PLANCK_CONSTANT_CONSTANT,
}

# Plain float aliases for use inside numerical kernels (SI units).
ELEMENTARY_CHARGE: float = ELEMENTARY_CHARGE_CONSTANT.value  #: [C]
ELECTRON_MASS: float = ELECTRON_MASS_CONSTANT.value  #: [kg]
PROTON_MASS: float = PROTON_MASS_CONSTANT.value  #: [kg]
ATOMIC_MASS_CONSTANT: float = ATOMIC_MASS_CONSTANT_CONSTANT.value  #: [kg]
VACUUM_PERMITTIVITY: float = VACUUM_PERMITTIVITY_CONSTANT.value  #: [F/m]
VACUUM_PERMEABILITY: float = VACUUM_PERMEABILITY_CONSTANT.value  #: [N/A^2]
BOLTZMANN_CONSTANT: float = BOLTZMANN_CONSTANT_CONSTANT.value  #: [J/K]
SPEED_OF_LIGHT: float = SPEED_OF_LIGHT_CONSTANT.value  #: [m/s]
PLANCK_CONSTANT: float = PLANCK_CONSTANT_CONSTANT.value  #: [J s]


def constants_table() -> list[dict[str, object]]:
    """Return the constant registry as a list of plain dictionaries (for metadata/IO)."""
    return [
        {
            "identifier": key,
            "name": c.name,
            "symbol": c.symbol,
            "value": c.value,
            "unit": c.unit,
            "exact": c.exact,
            "source": c.source,
        }
        for key, c in CONSTANTS.items()
    ]
