"""Strongly typed charged-species model.

A :class:`Species` describes one population of charged particles: its
charge, mass, macro-particle weight and initial macroscopic parameters.
No species (not even hydrogen) is hard-coded into the solvers; factory
functions are provided for common species and arbitrary species can be built
directly.

Units (SI): charge [C], mass [kg], temperature [K], density [m^-3],
bulk velocity [m/s].

``particle_weight`` is the number of physical particles represented by one
macro-particle.  If left ``None`` it is computed at initialisation from
``density * domain_volume / particle_count``.

``mobile=False`` declares the species an immobile, spatially uniform
neutralising background.  Such a species contributes a constant charge
density ``charge_c * density_m3`` to Poisson's equation and is never
represented by particles or advanced in time.
"""

from __future__ import annotations

import math
from typing import Any

from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator

from .constants import (
    ATOMIC_MASS_CONSTANT,
    BOLTZMANN_CONSTANT,
    ELECTRON_MASS,
    ELEMENTARY_CHARGE,
    PROTON_MASS,
    SPEED_OF_LIGHT,
    VACUUM_PERMITTIVITY,
)
from .units import KELVIN_PER_EV

_PRESETS: dict[str, tuple[float, float]] = {
    "electron": (-ELEMENTARY_CHARGE, ELECTRON_MASS),
    "positron": (+ELEMENTARY_CHARGE, ELECTRON_MASS),
    "proton": (+ELEMENTARY_CHARGE, PROTON_MASS),
}


class Species(BaseModel):
    """A charged species.

    Accepted API-boundary conveniences (converted to SI on construction):
    ``preset`` ("electron", "positron", "proton"), ``charge_e`` (multiples of e),
    ``mass_amu``, ``temperature_ev``, ``density_cm3``.
    """

    model_config = ConfigDict(frozen=True, extra="forbid")

    name: str = Field(min_length=1)
    charge_c: float
    mass_kg: float = Field(gt=0.0)
    particle_weight: float | None = Field(default=None, gt=0.0)
    temperature_k: float = Field(default=0.0, ge=0.0)
    density_m3: float = Field(gt=0.0)
    bulk_velocity_m_s: tuple[float, float, float] = (0.0, 0.0, 0.0)
    mobile: bool = True

    @model_validator(mode="before")
    @classmethod
    def _convert_boundary_units(cls, data: Any) -> Any:
        if not isinstance(data, dict):
            return data
        data = dict(data)
        preset = data.pop("preset", None)
        if preset is not None:
            if preset not in _PRESETS:
                raise ValueError(f"unknown species preset '{preset}'; choose from {sorted(_PRESETS)}")
            q, m = _PRESETS[preset]
            data.setdefault("charge_c", q)
            data.setdefault("mass_kg", m)
            data.setdefault("name", preset)
        if "charge_e" in data:
            if "charge_c" in data:
                raise ValueError("specify only one of charge_c / charge_e")
            data["charge_c"] = float(data.pop("charge_e")) * ELEMENTARY_CHARGE
        if "mass_amu" in data:
            if "mass_kg" in data:
                raise ValueError("specify only one of mass_kg / mass_amu")
            data["mass_kg"] = float(data.pop("mass_amu")) * ATOMIC_MASS_CONSTANT
        if "temperature_ev" in data:
            if "temperature_k" in data:
                raise ValueError("specify only one of temperature_k / temperature_ev")
            data["temperature_k"] = float(data.pop("temperature_ev")) * KELVIN_PER_EV
        if "density_cm3" in data:
            if "density_m3" in data:
                raise ValueError("specify only one of density_m3 / density_cm3")
            data["density_m3"] = float(data.pop("density_cm3")) * 1.0e6
        return data

    @field_validator("charge_c")
    @classmethod
    def _nonzero_charge(cls, v: float) -> float:
        if v == 0.0 or not math.isfinite(v):
            raise ValueError("charge_c must be finite and non-zero (neutral species are not plasma species)")
        return v

    @field_validator("bulk_velocity_m_s", mode="before")
    @classmethod
    def _vec3(cls, v: Any) -> tuple[float, float, float]:
        if isinstance(v, (int, float)):
            return (float(v), 0.0, 0.0)
        v = tuple(float(x) for x in v)
        if len(v) != 3:
            raise ValueError("bulk_velocity_m_s must have 3 components")
        return v  # type: ignore[return-value]

    @model_validator(mode="after")
    def _subluminal(self) -> "Species":
        speed = math.sqrt(sum(c * c for c in self.bulk_velocity_m_s))
        if speed >= SPEED_OF_LIGHT:
            raise ValueError(f"bulk speed {speed:.3e} m/s of species '{self.name}' is not below c")
        thermal = math.sqrt(BOLTZMANN_CONSTANT * self.temperature_k / self.mass_kg)
        if thermal >= 0.1 * SPEED_OF_LIGHT:
            raise ValueError(
                f"thermal speed sqrt(kT/m)={thermal:.3e} m/s of species '{self.name}' exceeds 0.1c; "
                "the non-relativistic models in plasma_core are not valid"
            )
        return self

    # ------------------------------------------------------------------
    @property
    def charge_to_mass_c_kg(self) -> float:
        """q/m [C/kg]."""
        return self.charge_c / self.mass_kg

    @property
    def charge_density_c_m3(self) -> float:
        """q n [C/m^3]."""
        return self.charge_c * self.density_m3

    @property
    def mass_density_kg_m3(self) -> float:
        """m n [kg/m^3]."""
        return self.mass_kg * self.density_m3

    @property
    def plasma_frequency_rad_s(self) -> float:
        """omega_p = sqrt(n q^2 / (m epsilon_0)) [rad/s]."""
        return math.sqrt(self.density_m3 * self.charge_c**2 / (self.mass_kg * VACUUM_PERMITTIVITY))

    @property
    def thermal_speed_rms_1d_m_s(self) -> float:
        """sqrt(k_B T / m) [m/s] (standard deviation of one velocity component)."""
        return math.sqrt(BOLTZMANN_CONSTANT * self.temperature_k / self.mass_kg)

    def with_updates(self, **kwargs: Any) -> "Species":
        """Return a copy with modified fields (re-validated)."""
        data = self.model_dump()
        data.update(kwargs)
        return Species(**data)


# --------------------------------------------------------------------------
# Factories
# --------------------------------------------------------------------------


def electron(density_m3: float, temperature_k: float = 0.0, *, name: str = "electrons", **kw: Any) -> Species:
    """Electron species (q = -e, m = m_e)."""
    return Species(name=name, charge_c=-ELEMENTARY_CHARGE, mass_kg=ELECTRON_MASS,
                   density_m3=density_m3, temperature_k=temperature_k, **kw)


def positron(density_m3: float, temperature_k: float = 0.0, *, name: str = "positrons", **kw: Any) -> Species:
    """Positron species (q = +e, m = m_e)."""
    return Species(name=name, charge_c=ELEMENTARY_CHARGE, mass_kg=ELECTRON_MASS,
                   density_m3=density_m3, temperature_k=temperature_k, **kw)


def proton(density_m3: float, temperature_k: float = 0.0, *, name: str = "protons", **kw: Any) -> Species:
    """Proton species (q = +e, m = m_p)."""
    return Species(name=name, charge_c=ELEMENTARY_CHARGE, mass_kg=PROTON_MASS,
                   density_m3=density_m3, temperature_k=temperature_k, **kw)


def ion(
    density_m3: float,
    *,
    charge_state: int,
    mass_amu: float | None = None,
    mass_kg: float | None = None,
    temperature_k: float = 0.0,
    name: str = "ions",
    **kw: Any,
) -> Species:
    """Ion of charge ``charge_state * e``.  Mass via ``mass_amu`` or ``mass_kg``.

    The mass is the ion mass as given; electron binding/missing-electron mass
    corrections are the caller's responsibility.
    """
    if (mass_amu is None) == (mass_kg is None):
        raise ValueError("specify exactly one of mass_amu / mass_kg")
    m = mass_kg if mass_kg is not None else mass_amu * ATOMIC_MASS_CONSTANT
    return Species(name=name, charge_c=charge_state * ELEMENTARY_CHARGE, mass_kg=m,
                   density_m3=density_m3, temperature_k=temperature_k, **kw)


def custom_species(name: str, charge_c: float, mass_kg: float, density_m3: float, **kw: Any) -> Species:
    """Arbitrary charged species."""
    return Species(name=name, charge_c=charge_c, mass_kg=mass_kg, density_m3=density_m3, **kw)


def neutralizing_background(species_list: list[Species], *, name: str = "background_ions",
                            mass_kg: float = PROTON_MASS, charge_c: float = ELEMENTARY_CHARGE) -> Species:
    """Immobile uniform background that exactly neutralises ``species_list``.

    The background density is chosen so that sum(q n) = 0.  Its sign of charge
    is chosen opposite to the net charge of the supplied species.
    """
    net = sum(s.charge_density_c_m3 for s in species_list)
    if net == 0.0:
        raise ValueError("species are already neutral; no background required")
    q = abs(charge_c) if net < 0 else -abs(charge_c)
    return Species(name=name, charge_c=q, mass_kg=mass_kg, density_m3=abs(net) / abs(charge_c), mobile=False)
