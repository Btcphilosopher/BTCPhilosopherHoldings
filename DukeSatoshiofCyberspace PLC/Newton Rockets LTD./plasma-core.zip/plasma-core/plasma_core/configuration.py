"""Validated simulation configuration (Pydantic).

A :class:`SimulationConfig` is the complete, serialisable description of a
run.  It is validated *before* any simulation object is created so that
physically or mathematically nonsensical set-ups are rejected early, with an
explanation of which parameter is responsible.

The YAML/TOML layout mirrors the model::

    solver:   {type: electrostatic_pic, deposition: cic, poisson: fft_fd}
    domain:   {dimension: 1, length_m: 1.0}
    grid:     {cells: 256}
    species:  [{preset: electron, density_m3: 1e12, temperature_ev: 1.0}, ...]
    boundaries: {particles: periodic}
    particles: {count: 100000}
    initial_condition: {type: plasma_wave, perturbation: {mode: 1, amplitude: 0.01}}
    time:     {dt_s: 1.0e-10, duration_s: 1.0e-7}
    random_seed: 42
"""

from __future__ import annotations

import hashlib
import json
import math
from pathlib import Path
from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field, ValidationError, field_validator, model_validator

from .constants import SPEED_OF_LIGHT
from .exceptions import InvalidPhysicalConfiguration
from .species import Species

Vec3 = tuple[float, float, float]


def _vec3(v: Any) -> Vec3:
    if isinstance(v, (int, float)):
        return (float(v), 0.0, 0.0)
    t = tuple(float(x) for x in v)
    if len(t) != 3:
        raise ValueError("expected a 3-component vector")
    return t  # type: ignore[return-value]


class _Strict(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)


class DomainConfig(_Strict):
    dimension: Literal[1, 2] = 1
    length_m: tuple[float, ...]
    origin_m: tuple[float, ...] | None = None

    @field_validator("length_m", "origin_m", mode="before")
    @classmethod
    def _tuple(cls, v: Any) -> Any:
        if v is None:
            return v
        if isinstance(v, (int, float)):
            return (float(v),)
        return tuple(float(x) for x in v)

    @model_validator(mode="after")
    def _check(self) -> "DomainConfig":
        if len(self.length_m) == 1 and self.dimension > 1:
            object.__setattr__(self, "length_m", self.length_m * self.dimension)
        if len(self.length_m) != self.dimension:
            raise ValueError("domain.length_m must have one entry per dimension")
        if any(not (L > 0 and math.isfinite(L)) for L in self.length_m):
            raise ValueError("domain.length_m must be positive and finite")
        if self.origin_m is None:
            object.__setattr__(self, "origin_m", (0.0,) * self.dimension)
        elif len(self.origin_m) == 1 and self.dimension > 1:
            object.__setattr__(self, "origin_m", self.origin_m * self.dimension)
        return self


class GridConfig(_Strict):
    cells: tuple[int, ...]

    @field_validator("cells", mode="before")
    @classmethod
    def _tuple(cls, v: Any) -> Any:
        if isinstance(v, int):
            return (v,)
        return tuple(int(x) for x in v)

    @field_validator("cells")
    @classmethod
    def _positive(cls, v: tuple[int, ...]) -> tuple[int, ...]:
        if any(c < 4 for c in v):
            raise ValueError("grid.cells must be >= 4 along every axis")
        return v


class BoundaryConfig(_Strict):
    """Boundary conditions (applied to all axes).

    ``fields`` defaults to the mathematically consistent partner of the
    particle boundary: periodic->periodic, reflecting->neumann,
    absorbing->dirichlet (grounded walls), open->dirichlet (approximation).
    """

    particles: Literal["periodic", "reflecting", "absorbing", "open"] = "periodic"
    fields: Literal["periodic", "dirichlet", "neumann"] | None = None
    potential_low_v: float = 0.0
    potential_high_v: float = 0.0

    @model_validator(mode="after")
    def _defaults(self) -> "BoundaryConfig":
        partner = {"periodic": "periodic", "reflecting": "neumann", "absorbing": "dirichlet", "open": "dirichlet"}
        if self.fields is None:
            object.__setattr__(self, "fields", partner[self.particles])
        if (self.particles == "periodic") != (self.fields == "periodic"):
            raise ValueError(
                f"boundaries.particles={self.particles} is incompatible with boundaries.fields={self.fields}: "
                "periodic particles require periodic fields and vice versa"
            )
        if self.fields != "dirichlet" and (self.potential_low_v or self.potential_high_v):
            raise ValueError("wall potentials are only meaningful with dirichlet field boundaries")
        return self


class FluidSolverConfig(_Strict):
    closure: Literal["isothermal", "adiabatic", "polytropic", "ideal_gas"] = "adiabatic"
    gamma: float = Field(default=3.0, ge=1.0)
    reconstruction: Literal["first_order", "muscl_minmod", "muscl_mc"] = "muscl_mc"
    cfl: float = Field(default=0.4, gt=0.0, le=1.0)


class VlasovSolverConfig(_Strict):
    velocity_cells: int = Field(default=256, ge=16)
    velocity_extent_vth: float = Field(default=6.0, gt=2.0)
    velocity_min_m_s: float | None = None
    velocity_max_m_s: float | None = None
    velocity_interpolation: Literal["cubic_spline"] = "cubic_spline"

    @model_validator(mode="after")
    def _bounds(self) -> "VlasovSolverConfig":
        if (self.velocity_min_m_s is None) != (self.velocity_max_m_s is None):
            raise ValueError("give both velocity_min_m_s and velocity_max_m_s or neither")
        if self.velocity_min_m_s is not None and not self.velocity_max_m_s > self.velocity_min_m_s:
            raise ValueError("velocity_max_m_s must exceed velocity_min_m_s")
        return self


class CollisionConfig(_Strict):
    model: Literal["collisionless", "effective_frequency"] = "collisionless"
    frequency_hz: float = Field(default=0.0, ge=0.0)
    background_temperature_k: float = Field(default=0.0, ge=0.0)
    background_velocity_m_s: Vec3 = (0.0, 0.0, 0.0)

    @field_validator("background_velocity_m_s", mode="before")
    @classmethod
    def _bg_vec(cls, v: Any) -> Vec3:
        return _vec3(v)

    @model_validator(mode="after")
    def _check(self) -> "CollisionConfig":
        if self.model == "collisionless" and self.frequency_hz != 0.0:
            raise ValueError("collisions.frequency_hz > 0 given but model is 'collisionless'; "
                             "select model: effective_frequency explicitly")
        if self.model == "effective_frequency" and self.frequency_hz <= 0.0:
            raise ValueError("effective_frequency collisions need frequency_hz > 0")
        return self


class SolverConfig(_Strict):
    type: Literal["electrostatic_pic", "electromagnetic_pic", "test_particle", "fluid", "vlasov"]
    deposition: Literal["ngp", "cic"] = "cic"
    interpolation: Literal["ngp", "cic"] | None = None
    poisson: Literal["fft_fd", "fft_spectral", "fd"] = "fft_fd"
    pusher: Literal["boris"] = "boris"
    current_deposition: Literal["direct"] = "direct"
    external_electric_field_v_m: Vec3 = (0.0, 0.0, 0.0)
    external_magnetic_field_t: Vec3 = (0.0, 0.0, 0.0)
    backend: Literal["cpu_reference", "numba", "cupy", "jax"] = "cpu_reference"
    precision: Literal["float64", "float32"] = "float64"
    fluid: FluidSolverConfig | None = None
    vlasov: VlasovSolverConfig | None = None
    collisions: CollisionConfig = CollisionConfig()
    allow_non_neutral: bool = False

    @field_validator("external_electric_field_v_m", "external_magnetic_field_t", mode="before")
    @classmethod
    def _field_vec(cls, v: Any) -> Vec3:
        return _vec3(v)

    @model_validator(mode="after")
    def _defaults(self) -> "SolverConfig":
        if self.interpolation is None:
            object.__setattr__(self, "interpolation", self.deposition)
        if self.type == "fluid" and self.fluid is None:
            object.__setattr__(self, "fluid", FluidSolverConfig())
        if self.type == "vlasov" and self.vlasov is None:
            object.__setattr__(self, "vlasov", VlasovSolverConfig())
        if self.precision == "float32":
            raise ValueError("float32 is not validated for the reference solver; use float64 "
                             "(float32 support is reserved for validated accelerator backends)")
        return self


class ParticlesConfig(_Strict):
    count: int = Field(default=0, ge=0, description="macro-particles per mobile species")
    position_loading: Literal["random", "quiet"] = "random"
    velocity_loading: Literal["random", "quiet"] = "random"


class PerturbationConfig(_Strict):
    """Small-amplitude density perturbation delta n / n0 = amplitude * cos(k x + phase)."""

    mode: int = Field(default=1, ge=1)
    amplitude: float = Field(default=0.0, ge=0.0, lt=1.0)
    phase_rad: float = 0.0
    axis: int = Field(default=0, ge=0, le=1)
    species: list[str] | None = None  # None -> all mobile species
    wavelength_m: float | None = None  # if given must match an integer mode of the domain


class EMWaveConfig(_Strict):
    """Initial transverse wave (electromagnetic_pic only): E = A cos(k x + phase).

    ``standing``: B = 0 initially (superposition of +x and -x waves);
    ``travelling``: B = E/c with the sign of a +x propagating wave (exact only in the
    continuum limit; the Yee staggering leaves a small backward component).
    """

    mode: int = Field(default=1, ge=1)
    amplitude_v_m: float = 0.0
    phase_rad: float = 0.0
    polarization: Literal["y", "z"] = "y"
    kind: Literal["standing", "travelling"] = "standing"


class InitialConditionConfig(_Strict):
    type: Literal["maxwellian", "cold", "drifting_maxwellian", "two_stream", "plasma_wave",
                  "magnetised", "single_particle"] = "maxwellian"
    perturbation: PerturbationConfig = PerturbationConfig()
    # magnetised (bi-Maxwellian about B): per-species overrides keyed by species name
    temperature_parallel_k: dict[str, float] | None = None
    temperature_perpendicular_k: dict[str, float] | None = None
    # single particle(s): one entry per particle
    positions_m: list[Vec3] | None = None
    velocities_m_s: list[Vec3] | None = None
    em_wave: EMWaveConfig | None = None


class TimeConfig(_Strict):
    dt_s: float = Field(gt=0.0)
    duration_s: float = Field(gt=0.0)
    stability_policy: Literal["error", "warn"] = "error"

    @model_validator(mode="after")
    def _check(self) -> "TimeConfig":
        if self.duration_s < self.dt_s:
            raise ValueError("time.duration_s must be >= time.dt_s")
        return self


class StabilityMonitorConfig(_Strict):
    check_interval: int = Field(default=10, ge=1)
    max_relative_energy_error: float | None = Field(default=1.0, gt=0.0)
    max_relative_charge_error: float | None = Field(default=1e-6, gt=0.0)
    action: Literal["stop", "warn"] = "stop"


class DiagnosticsConfig(_Strict):
    """Per-diagnostic sampling intervals in steps (None -> ``interval``; 0 -> disabled)."""

    interval: int = Field(default=10, ge=1)
    energy: int | None = None
    charge: int | None = None
    momentum: int | None = None
    temperature: int | None = None
    density: int | None = None
    velocity_distribution: int | None = 0
    field_statistics: int | None = None
    particle_statistics: int | None = None
    field_modes: list[int] = [1, 2, 3]
    distribution_bins: int = Field(default=64, ge=4)
    record_trajectories: list[int] = []  # particle ids whose trajectories are stored at each energy sample
    stability: StabilityMonitorConfig = StabilityMonitorConfig()

    def interval_for(self, name: str) -> int:
        v = getattr(self, name)
        return self.interval if v is None else int(v)


class OutputConfig(_Strict):
    directory: str = "output"
    hdf5: bool = True
    parquet: bool = True
    output_interval: int = Field(default=0, ge=0, description="field/particle snapshot interval (0 = none)")
    checkpoint_interval: int = Field(default=0, ge=0)
    particle_snapshot_max: int = Field(default=100_000, ge=0)


class SimulationConfig(_Strict):
    """Complete validated configuration of a simulation."""

    name: str = "plasma_core_run"
    unit_system: Literal["SI"] = "SI"
    solver: SolverConfig
    domain: DomainConfig
    grid: GridConfig
    species: list[Species]
    boundaries: BoundaryConfig = BoundaryConfig()
    particles: ParticlesConfig = ParticlesConfig()
    initial_condition: InitialConditionConfig = InitialConditionConfig()
    time: TimeConfig
    random_seed: int = Field(ge=0)
    diagnostics: DiagnosticsConfig = DiagnosticsConfig()
    output: OutputConfig = OutputConfig()

    # ------------------------------------------------------------------
    @model_validator(mode="after")
    def _physical_consistency(self) -> "SimulationConfig":
        s, d = self.solver, self.domain
        if len(self.grid.cells) != d.dimension:
            raise ValueError(f"grid.cells has {len(self.grid.cells)} entries but domain.dimension={d.dimension}")
        if d.dimension == 2 and s.type not in ("electrostatic_pic", "test_particle"):
            raise ValueError(f"solver '{s.type}' is implemented in 1D only (dimension=2 requested)")
        if not self.species:
            raise ValueError("at least one species is required")
        names = [sp.name for sp in self.species]
        if len(set(names)) != len(names):
            raise ValueError(f"species names must be unique, got {names}")
        mobile = [sp for sp in self.species if sp.mobile]
        if not mobile:
            raise ValueError("at least one mobile species is required")
        for sp in self.species:
            if math.sqrt(sum(c * c for c in sp.bulk_velocity_m_s)) >= SPEED_OF_LIGHT:
                raise ValueError(f"species {sp.name}: bulk velocity >= c")

        particle_based = s.type in ("electrostatic_pic", "electromagnetic_pic", "test_particle")
        ic = self.initial_condition
        if particle_based:
            if ic.type == "single_particle":
                if not ic.positions_m or not ic.velocities_m_s or len(ic.positions_m) != len(ic.velocities_m_s):
                    raise ValueError("single_particle needs equal-length positions_m and velocities_m_s")
                if len(mobile) != 1:
                    raise ValueError("single_particle initial condition supports exactly one mobile species")
            elif self.particles.count < 1:
                raise ValueError("particles.count must be >= 1 for particle solvers")
        if s.type == "test_particle" and ic.type != "single_particle" and self.particles.count < 1:
            raise ValueError("test_particle requires particles")

        if ic.type == "cold":
            hot = [sp.name for sp in mobile if sp.temperature_k > 0]
            if hot:
                raise ValueError(f"initial_condition 'cold' requires temperature_k=0 for mobile species, got {hot}")
        if ic.type == "two_stream":
            drifts = [sp.bulk_velocity_m_s[0] for sp in mobile]
            if len(mobile) < 2 or not (min(drifts) < 0 < max(drifts)):
                raise ValueError("two_stream requires >= 2 mobile species with opposite x-drifts")
        if ic.type == "magnetised" and all(b == 0.0 for b in s.external_magnetic_field_t):
            raise ValueError("magnetised initial condition requires a non-zero external_magnetic_field_t")
        pert = ic.perturbation
        if pert.axis >= d.dimension:
            raise ValueError("perturbation.axis exceeds domain dimension")
        if pert.wavelength_m is not None:
            m = d.length_m[pert.axis] / pert.wavelength_m
            if abs(m - round(m)) > 1e-9 or round(m) != pert.mode:
                raise ValueError("perturbation.wavelength_m must equal length/mode for the given mode "
                                 f"(length/wavelength={m:.6g}, mode={pert.mode})")
        if pert.mode > self.grid.cells[pert.axis] // 2:
            raise ValueError("perturbation.mode exceeds the Nyquist mode of the grid")

        # Field / boundary compatibility
        b = self.boundaries
        if s.type == "electromagnetic_pic" and b.particles != "periodic":
            raise ValueError("electromagnetic_pic currently supports periodic boundaries only "
                             "(absorbing EM boundaries such as Mur/PML are not implemented)")
        if s.type == "vlasov" and b.particles != "periodic":
            raise ValueError("vlasov solver supports periodic spatial boundaries only")
        if s.type == "fluid" and b.particles not in ("periodic", "reflecting"):
            raise ValueError("fluid solver supports periodic and reflecting (wall) boundaries only")
        if b.fields == "neumann" and d.dimension != 1:
            raise ValueError("neumann field boundaries are implemented in 1D only")
        if s.poisson in ("fft_fd", "fft_spectral") and b.fields != "periodic":
            raise ValueError(f"solver.poisson={s.poisson} requires periodic fields; use poisson: fd "
                             f"for {b.fields} boundaries")

        # Neutrality: periodic Poisson needs zero net charge (k=0 mode)
        if s.type != "test_particle" and b.fields in ("periodic", "neumann"):
            rho = sum(sp.charge_density_c_m3 for sp in self.species)
            scale = sum(abs(sp.charge_density_c_m3) for sp in self.species)
            if abs(rho) > 1e-9 * scale and not s.allow_non_neutral:
                raise ValueError(
                    f"net charge density {rho:.3e} C/m^3 is non-zero; {b.fields} Poisson problems require "
                    "quasi-neutrality. Add a neutralising species (mobile: false) or set "
                    "solver.allow_non_neutral: true to remove the mean explicitly"
                )
        if ic.em_wave is not None and s.type != "electromagnetic_pic":
            raise ValueError("initial_condition.em_wave requires solver.type = electromagnetic_pic")
        if s.type in ("vlasov", "fluid") and ic.type in ("magnetised", "single_particle"):
            raise ValueError(f"initial condition '{ic.type}' is not available for the {s.type} solver")
        if s.type == "vlasov" and any(c != 0.0 for c in s.external_magnetic_field_t):
            raise ValueError("the 1D1V Vlasov solver cannot represent v x B (needs >= 2 velocity dimensions); "
                             "external_magnetic_field_t must be zero")
        if s.type == "vlasov":
            for sp in mobile:
                if sp.temperature_k <= 0 and s.vlasov.velocity_min_m_s is None:  # type: ignore[union-attr]
                    raise ValueError(f"vlasov: species {sp.name} is cold; give explicit velocity bounds")
        if self.time.duration_s / self.time.dt_s > 1e8:
            raise ValueError("more than 1e8 time steps requested; check time.dt_s / time.duration_s")
        return self

    # ------------------------------------------------------------------
    # Convenience accessors (names used in the specification)
    @property
    def dimension(self) -> int:
        return self.domain.dimension

    @property
    def domain_size(self) -> tuple[float, ...]:
        return self.domain.length_m

    @property
    def grid_resolution(self) -> tuple[int, ...]:
        return self.grid.cells

    @property
    def dt(self) -> float:
        return self.time.dt_s

    @property
    def total_time(self) -> float:
        return self.time.duration_s

    @property
    def n_steps(self) -> int:
        """Number of steps; duration is rounded to the nearest whole step."""
        return max(1, int(round(self.time.duration_s / self.time.dt_s)))

    @property
    def particle_count(self) -> int:
        return self.particles.count

    @property
    def diagnostic_interval(self) -> int:
        return self.diagnostics.interval

    @property
    def output_interval(self) -> int:
        return self.output.output_interval

    @property
    def checkpoint_interval(self) -> int:
        return self.output.checkpoint_interval

    @property
    def mobile_species(self) -> list[Species]:
        return [s for s in self.species if s.mobile]

    # ------------------------------------------------------------------
    def canonical_json(self) -> str:
        return json.dumps(self.model_dump(mode="json"), sort_keys=True, separators=(",", ":"))

    def config_hash(self) -> str:
        """SHA-256 of the canonical JSON representation."""
        return hashlib.sha256(self.canonical_json().encode()).hexdigest()

    def with_updates(self, **changes: Any) -> "SimulationConfig":
        """Deep-update helper: ``cfg.with_updates(time={'dt_s': 1e-10})``."""
        data = self.model_dump(mode="python")
        _deep_update(data, changes)
        return SimulationConfig.from_dict(data)

    # ------------------------------------------------------------------
    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "SimulationConfig":
        try:
            return cls.model_validate(data)
        except ValidationError as exc:
            errs = "; ".join(f"{'.'.join(str(x) for x in e['loc']) or '<root>'}: {e['msg']}" for e in exc.errors())
            first = exc.errors()[0]["loc"] if exc.errors() else ()
            raise InvalidPhysicalConfiguration(
                "configuration rejected before simulation start",
                why=errs,
                parameter=".".join(str(x) for x in first) or None,
                investigate="fix the listed parameters; see docs/PHYSICS.md and docs/NUMERICS.md for constraints",
            ) from exc

    @classmethod
    def from_file(cls, path: str | Path) -> "SimulationConfig":
        path = Path(path)
        text = path.read_text()
        if path.suffix in (".yaml", ".yml"):
            import yaml

            data = yaml.safe_load(text)
        elif path.suffix == ".toml":
            import tomllib

            data = tomllib.loads(text)
        elif path.suffix == ".json":
            data = json.loads(text)
        else:
            raise InvalidPhysicalConfiguration(f"unsupported configuration format '{path.suffix}'",
                                               investigate="use .yaml, .yml, .toml or .json")
        return cls.from_dict(data)

    def to_file(self, path: str | Path) -> None:
        path = Path(path)
        data = self.model_dump(mode="json")
        if path.suffix in (".yaml", ".yml"):
            import yaml

            path.write_text(yaml.safe_dump(data, sort_keys=False))
        else:
            path.write_text(json.dumps(data, indent=2))


def _deep_update(base: dict, changes: dict) -> None:
    for k, v in changes.items():
        if isinstance(v, dict) and isinstance(base.get(k), dict):
            _deep_update(base[k], v)
        else:
            base[k] = v
