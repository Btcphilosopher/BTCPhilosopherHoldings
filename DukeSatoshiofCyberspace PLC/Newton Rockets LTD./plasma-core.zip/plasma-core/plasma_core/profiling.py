"""Profiling helpers built on the standard library (cProfile, tracemalloc) and Numba.

    from plasma_core.profiling import profile_cpu, profile_memory
    stats_text = profile_cpu(lambda: sim.run(n_steps=100))
    peak_mb, top = profile_memory(lambda: sim.run(n_steps=10))
"""

from __future__ import annotations

import cProfile
import io
import pstats
import tracemalloc
from typing import Callable


def profile_cpu(fn: Callable[[], object], sort: str = "cumulative", limit: int = 25) -> str:
    pr = cProfile.Profile()
    pr.enable()
    fn()
    pr.disable()
    s = io.StringIO()
    pstats.Stats(pr, stream=s).sort_stats(sort).print_stats(limit)
    return s.getvalue()


def profile_memory(fn: Callable[[], object], top: int = 10) -> tuple[float, list[str]]:
    tracemalloc.start()
    fn()
    snap = tracemalloc.take_snapshot()
    _, peak = tracemalloc.get_traced_memory()
    tracemalloc.stop()
    stats = snap.statistics("lineno")[:top]
    return peak / 1e6, [str(s) for s in stats]


def numba_kernel_report() -> dict:
    """Compiled signatures of the Numba kernels (empty if not yet compiled)."""
    try:
        from .backends import numba_backend as nb
    except Exception:  # pragma: no cover
        return {}
    out = {}
    for name in ("_boris", "_deposit_1d", "_interp_1d"):
        k = getattr(nb, name, None)
        if k is not None:
            out[name] = [str(s) for s in k.signatures]
    return out
