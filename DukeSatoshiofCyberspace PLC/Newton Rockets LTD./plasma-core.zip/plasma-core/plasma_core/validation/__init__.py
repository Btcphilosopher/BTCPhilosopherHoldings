"""Validation suite: simulations compared with independent analytical results."""

from .result import ValidationResult

__all__ = ["ValidationResult"]
