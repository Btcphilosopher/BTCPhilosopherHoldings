"""Validation result record."""

from __future__ import annotations

import math
from dataclasses import asdict, dataclass, field


@dataclass
class ValidationResult:
    name: str
    problem: str
    equations: str
    method: str
    configuration: dict
    analytical: dict
    numerical: dict
    errors: dict
    tolerances: dict
    passed: bool = False
    conclusion: str = ""
    runtime_s: float = 0.0
    notes: list[str] = field(default_factory=list)

    def evaluate(self) -> "ValidationResult":
        """passed = every error listed in ``tolerances`` is finite and within its tolerance."""
        failures = []
        for key, tol in self.tolerances.items():
            err = self.errors.get(key)
            if err is None or not math.isfinite(err) or abs(err) > tol:
                failures.append(f"{key}={err!r} > {tol:g}")
        self.passed = not failures
        if not self.conclusion:
            self.conclusion = ("PASS: all measured errors within the stated tolerances"
                               if self.passed else "FAIL: " + "; ".join(failures))
        elif not self.passed:
            self.conclusion = "FAIL: " + "; ".join(failures) + ". " + self.conclusion
        else:
            self.conclusion = "PASS: " + self.conclusion
        return self

    def to_dict(self) -> dict:
        return asdict(self)
