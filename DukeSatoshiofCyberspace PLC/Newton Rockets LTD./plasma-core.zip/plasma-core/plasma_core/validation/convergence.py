"""Convergence-testing framework.

A study evaluates an error functional e(h) for a sequence of resolutions h
(grid spacing, time step or inverse particle number) and reports the
observed order p_i = log(e_i / e_{i+1}) / log(h_i / h_{i+1}).
"""

from __future__ import annotations

import math
import time
from dataclasses import asdict, dataclass
from typing import Callable

import numpy as np

from ..configuration import SimulationConfig
from ..constants import BOLTZMANN_CONSTANT, ELECTRON_MASS, ELEMENTARY_CHARGE, SPEED_OF_LIGHT, VACUUM_PERMITTIVITY
from ..grid.spatial_grid import SpatialGrid
from ..physics import dispersion as disp
from ..simulation.simulation import PlasmaSimulation
from ..solvers.poisson import PoissonSolver


@dataclass
class ConvergenceStudy:
    name: str
    parameter: str
    resolutions: list[float]
    errors: list[float]
    observed_orders: list[float]
    expected_order: float
    order_tolerance: float
    description: str
    passed: bool = False
    runtime_s: float = 0.0

    def to_dict(self) -> dict:
        return asdict(self)


def observed_orders(h: list[float], e: list[float]) -> list[float]:
    return [math.log(e[i] / e[i + 1]) / math.log(h[i] / h[i + 1]) for i in range(len(h) - 1)]


def run_study(name: str, parameter: str, resolutions: list[float], error_fn: Callable[[float], float],
              expected_order: float, order_tolerance: float, description: str) -> ConvergenceStudy:
    t0 = time.perf_counter()
    errs = [float(error_fn(h)) for h in resolutions]
    p = observed_orders(resolutions, errs)
    st = ConvergenceStudy(name, parameter, list(resolutions), errs, p, expected_order, order_tolerance, description)
    st.passed = all(math.isfinite(x) for x in p) and abs(p[-1] - expected_order) <= order_tolerance
    st.runtime_s = time.perf_counter() - t0
    return st


def poisson_grid_study() -> ConvergenceStudy:
    L = 1.0

    def err(dx):
        n = int(round(L / dx))
        g = SpatialGrid.uniform(n, L)
        x = g.centres(0)
        k = 2 * math.pi / L
        r = PoissonSolver(g, "fft_fd").solve(np.sin(k * x))
        E_a = -np.cos(k * x) / (VACUUM_PERMITTIVITY * k)
        return np.max(np.abs(r.electric_field_v_m[:, 0] - E_a)) / np.max(np.abs(E_a))

    return run_study("poisson_grid_refinement", "dx [m]", [L / n for n in (16, 32, 64, 128, 256)], err, 2.0, 0.1,
                     "max relative error of E for rho = sin(2 pi x / L), fft_fd solver")


def yee_dispersion_study() -> ConvergenceStudy:
    L, mode, courant = 1.0, 4, 0.5
    k = 2 * math.pi * mode / L

    def err(dx):
        dt = courant * dx / SPEED_OF_LIGHT
        return abs(disp.yee_vacuum_frequency(k, dx, dt) - SPEED_OF_LIGHT * k) / (SPEED_OF_LIGHT * k)

    return run_study("yee_dispersion_grid_refinement", "dx [m]", [L / n for n in (32, 64, 128, 256)], err, 2.0, 0.1,
                     "relative phase-velocity error of the Yee scheme at Courant 0.5 (discrete dispersion relation)")


def boris_timestep_study() -> ConvergenceStudy:
    B = 1e-3
    wc = ELEMENTARY_CHARGE * B / ELECTRON_MASS
    T_end = 5 * 2 * math.pi / wc

    def err(dt):
        cfg = {"solver": {"type": "test_particle", "external_magnetic_field_t": [0, 0, B]}, "domain": {"length_m": 1.0},
               "grid": {"cells": 8}, "species": [{"preset": "electron", "density_m3": 1.0}],
               "initial_condition": {"type": "single_particle", "positions_m": [[0.5, 0, 0]],
                                     "velocities_m_s": [[1e5, 0, 0]]},
               "time": {"dt_s": dt, "duration_s": T_end}, "random_seed": 0,
               "diagnostics": {"interval": 1, "record_trajectories": [0]}}
        sim = PlasmaSimulation(SimulationConfig.from_dict(cfg))
        sim.initialize()
        sim.run()
        t, x, y, z, vx, vy, vz = sim.diagnostics.trajectory(0).T
        w = np.polyfit(t, np.unwrap(np.arctan2(vy, vx)), 1)[0]
        return abs(w - wc) / wc

    return run_study("boris_timestep_refinement", "dt [s]", [x / wc for x in (0.4, 0.2, 0.1, 0.05)], err, 2.0, 0.1,
                     "relative gyrofrequency error of the Boris pusher (5 gyro-periods)")


def pic_particle_number_study() -> ConvergenceStudy:
    """Statistical convergence of the deposited density with particle number.

    Random (Poisson) loading gives a relative density fluctuation per cell of
    ~ (ppc)^{-1/2} (CIC smoothing changes the prefactor, not the exponent).  The
    RMS of rho/rho_0 - 1 at load time is averaged over 8 independent seeds.
    """
    n0 = 1e12
    T = 10.0 * ELEMENTARY_CHARGE / BOLTZMANN_CONSTANT
    cells = 64

    def err(inv_ppc):
        ppc = int(round(1.0 / inv_ppc))
        vals = []
        for seed in range(8):
            cfg = {"solver": {"type": "electrostatic_pic"}, "domain": {"length_m": 1.0}, "grid": {"cells": cells},
                   "species": [{"preset": "electron", "density_m3": n0, "temperature_k": T},
                               {"preset": "proton", "density_m3": n0, "mobile": False}],
                   "particles": {"count": cells * ppc},
                   "time": {"dt_s": 1e-12, "duration_s": 1e-12, "stability_policy": "warn"}, "random_seed": seed}
            sim = PlasmaSimulation(SimulationConfig.from_dict(cfg))
            import warnings

            with warnings.catch_warnings():
                warnings.simplefilter("ignore")
                sim.initialize()
            n_e = sim.state.number_density_m3[0]
            vals.append(float(np.sqrt(np.mean((n_e / n0 - 1.0) ** 2))))
        return float(np.mean(vals))

    return run_study("pic_particle_number_refinement", "1/ppc", [1 / 10, 1 / 40, 1 / 160, 1 / 640], err, 0.5, 0.05,
                     "RMS relative fluctuation of the CIC-deposited electron density at load time (random positions, "
                     "mean of 8 seeds); statistical convergence ~ ppc^(-1/2), not truncation convergence")


ALL_STUDIES = [poisson_grid_study, yee_dispersion_study, boris_timestep_study, pic_particle_number_study]
