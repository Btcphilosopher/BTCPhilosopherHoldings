"""Run the validation suite and render docs/VALIDATION.md from measured results.

Nothing in the generated report is typed by hand: every number is taken from
the :class:`ValidationResult` / :class:`ConvergenceStudy` objects produced by
running the cases.
"""

from __future__ import annotations

import datetime as _dt
import json
import platform
import sys
from pathlib import Path

import numpy as np

from .. import __version__
from ..io.metadata import git_commit
from . import cases, convergence


def run_suite(selected: list[str] | None = None, include_convergence: bool = True, verbose: bool = True) -> dict:
    results, studies = [], []
    for fn in cases.ALL_CASES:
        if selected and fn.__name__ not in selected:
            continue
        r = fn()
        results.append(r)
        if verbose:
            print(f"[{'PASS' if r.passed else 'FAIL'}] {r.name:<34s} {r.runtime_s:6.1f} s")
    if include_convergence:
        for fn in convergence.ALL_STUDIES:
            if selected and fn.__name__ not in selected:
                continue
            s = fn()
            studies.append(s)
            if verbose:
                print(f"[{'PASS' if s.passed else 'FAIL'}] {s.name:<34s} {s.runtime_s:6.1f} s  observed order "
                      f"{s.observed_orders[-1]:.3f} (expected {s.expected_order})")
    return {
        "generated_utc": _dt.datetime.now(_dt.timezone.utc).isoformat(timespec="seconds"),
        "software_version": __version__, **git_commit(), "python": sys.version.split()[0],
        "numpy": np.__version__, "platform": f"{platform.system()} {platform.machine()}",
        "cases": [r.to_dict() for r in results], "convergence": [s.to_dict() for s in studies],
    }


def _fmt(v) -> str:
    if isinstance(v, float):
        return f"{v:.6g}"
    if isinstance(v, (list, tuple)):
        return "[" + ", ".join(_fmt(x) for x in v) + "]"
    if isinstance(v, dict):
        return "{" + ", ".join(f"{k}: {_fmt(x)}" for k, x in v.items()) + "}"
    return str(v)


INTRO = """# Validation report

This file is **generated** by `plasma-core validation-suite --report docs/VALIDATION.md`
(`plasma_core/validation/report.py`).  Every number below was measured by running the
listed simulation; nothing is typed by hand.  A case passes only if *every* error listed
under "tolerances" is within its tolerance; tolerances are fixed in
`plasma_core/validation/cases.py` from the known truncation error of each method.

Interpretation rules used throughout:

* "analytical" values come from closed-form or semi-analytical theory
  (`plasma_core/physics/dispersion.py`), never from simulation output;
* "numerical" values are measurements from simulated time series with the
  estimators in `plasma_core/diagnostics/analysis.py`;
* where the discrete dispersion relation of the scheme is known, both the
  continuum error and the error relative to the discrete theory are given; the
  latter isolates implementation errors from expected truncation error;
* a pass means agreement within the stated tolerance for the stated configuration
  only.  It is not a claim of validity for other parameters.
"""


def render_markdown(data: dict) -> str:
    out = [INTRO]
    out.append(f"Generated {data['generated_utc']} with plasma_core {data['software_version']} "
               f"(git {data.get('git_commit', 'n/a')[:12]}{' + local changes' if data.get('git_dirty') else ''}), "
               f"Python {data['python']}, NumPy {data['numpy']}, {data['platform']}.\n")
    out.append("## Summary\n")
    out.append("| case | result | runtime [s] |\n|---|---|---|")
    for r in data["cases"]:
        out.append(f"| {r['name']} | {'PASS' if r['passed'] else '**FAIL**'} | {r['runtime_s']:.1f} |")
    for s in data["convergence"]:
        out.append(f"| convergence: {s['name']} | {'PASS' if s['passed'] else '**FAIL**'} | {s['runtime_s']:.1f} |")
    out.append("")
    for r in data["cases"]:
        out.append(f"## {r['name']}\n")
        out.append(f"**Problem.** {r['problem']}\n")
        out.append(f"**Equations.** {r['equations']}\n")
        out.append(f"**Numerical method.** {r['method']}\n")
        out.append(f"**Configuration.** {_fmt(r['configuration'])}\n")
        out.append("**Analytical result.**\n")
        for k, v in r["analytical"].items():
            out.append(f"- `{k}` = {_fmt(v)}")
        out.append("\n**Numerical result.**\n")
        for k, v in r["numerical"].items():
            out.append(f"- `{k}` = {_fmt(v)}")
        out.append("\n**Error** (tolerance in brackets where it is a pass criterion).\n")
        for k, v in r["errors"].items():
            tol = r["tolerances"].get(k)
            out.append(f"- `{k}` = {_fmt(v)}" + (f"  [<= {tol:g}]" if tol is not None else "  [reported only]"))
        out.append(f"\n**Conclusion.** {r['conclusion']}\n")
    if data["convergence"]:
        out.append("## Convergence studies\n")
        for s in data["convergence"]:
            out.append(f"### {s['name']}\n")
            out.append(f"{s['description']}.  Expected order {s['expected_order']} "
                       f"(tolerance +-{s['order_tolerance']}).\n")
            out.append(f"| {s['parameter']} | error | observed order |\n|---|---|---|")
            for i, (h, e) in enumerate(zip(s["resolutions"], s["errors"])):
                p = s["observed_orders"][i - 1] if i > 0 else float("nan")
                out.append(f"| {h:.4g} | {e:.4e} | {'' if i == 0 else f'{p:.3f}'} |")
            out.append(f"\nResult: {'PASS' if s['passed'] else 'FAIL'} (final observed order "
                       f"{s['observed_orders'][-1]:.3f}).\n")
    return "\n".join(out)


def write_report(data: dict, markdown_path: str | Path | None, json_path: str | Path | None) -> None:
    if json_path:
        Path(json_path).write_text(json.dumps(data, indent=1, default=float))
    if markdown_path:
        Path(markdown_path).write_text(render_markdown(data))


REGRESSION_KEYS = {
    "gyro_motion": ["omega_rad_s", "radius_m"],
    "exb_drift": ["electron_drift_m_s", "proton_drift_m_s"],
    "plasma_oscillation": ["omega_rad_s", "max_abs_energy_error"],
    "upper_hybrid_oscillation": ["omega_rad_s"],
    "two_stream_instability": ["gamma_s"],
    "landau_damping": ["gamma_s", "omega_rad_s"],
    "fluid_langmuir_wave": ["omega_rad_s"],
    "electromagnetic_wave": ["standing_omega_courant0.5"],
    "energy_momentum_conservation": ["max_abs_energy_error"],
    "charge_conservation_absorbing": ["particles_lost", "charge_lost_c"],
}


def regression_reference(data: dict) -> dict:
    ref = {"software_version": data["software_version"], "generated_utc": data["generated_utc"], "values": {}}
    for r in data["cases"]:
        for k in REGRESSION_KEYS.get(r["name"], []):
            ref["values"][f"{r['name']}.{k}"] = r["numerical"][k]
    return ref
