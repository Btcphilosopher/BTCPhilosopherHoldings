"""Validation cases: each compares a simulation with an independent analytical result.

All cases run through the public simulation API (or the field solvers
directly where no particles are involved), measure the relevant quantity
from the simulated data with :mod:`plasma_core.diagnostics.analysis`, and
compare with theory from :mod:`plasma_core.physics.dispersion`.

Tolerances are stated *before* the comparison and justified from the known
truncation error of the method (see docs/VALIDATION.md).  Where the scheme's
own discrete dispersion relation is known, the numerical result is compared
with both the continuum theory and the discrete theory.
"""

from __future__ import annotations

import math
import tempfile
import time
from pathlib import Path

import numpy as np

from ..configuration import SimulationConfig
from ..constants import (
    BOLTZMANN_CONSTANT,
    ELECTRON_MASS,
    ELEMENTARY_CHARGE,
    PROTON_MASS,
    SPEED_OF_LIGHT,
    VACUUM_PERMEABILITY,
    VACUUM_PERMITTIVITY,
)
from ..diagnostics.analysis import (
    fit_damped_oscillation,
    fit_growth_rate,
    peak_envelope_rate,
    peak_period_frequency,
    phase_velocity_from_mode,
)
from ..grid.spatial_grid import SpatialGrid
from ..physics import dispersion as disp
from ..simulation.simulation import PlasmaSimulation
from ..solvers.maxwell import Yee1DMaxwellSolver
from ..solvers.poisson import PoissonSolver
from .result import ValidationResult

N0 = 1.0e12  # reference electron density [m^-3]
WPE = math.sqrt(N0 * ELEMENTARY_CHARGE**2 / (ELECTRON_MASS * VACUUM_PERMITTIVITY))


def _electrons_and_ions(temperature_k: float = 0.0, n0: float = N0) -> list[dict]:
    return [{"preset": "electron", "density_m3": n0, "temperature_k": temperature_k},
            {"preset": "proton", "density_m3": n0, "mobile": False}]


def _run(cfg: dict) -> PlasmaSimulation:
    sim = PlasmaSimulation(SimulationConfig.from_dict(cfg))
    sim.initialize()
    sim.run()
    return sim


def _timed(fn):
    def wrapper(*a, **k):
        t0 = time.perf_counter()
        r = fn(*a, **k)
        r.runtime_s = time.perf_counter() - t0
        return r.evaluate()
    wrapper.__name__ = fn.__name__
    wrapper.__doc__ = fn.__doc__
    return wrapper


def _circle_fit(x: np.ndarray, y: np.ndarray) -> tuple[float, float, float]:
    """Algebraic (Kasa) least-squares circle fit -> (xc, yc, r)."""
    A = np.stack([x, y, np.ones_like(x)], axis=1)
    b = x * x + y * y
    c, *_ = np.linalg.lstsq(A, b, rcond=None)
    xc, yc = c[0] / 2, c[1] / 2
    return xc, yc, math.sqrt(c[2] + xc * xc + yc * yc)


# ==========================================================================
@_timed
def gyro_motion() -> ValidationResult:
    """Single electron in a uniform magnetic field."""
    B, vperp, vpar = 1.0e-3, 1.0e5, 2.0e4
    wc = ELEMENTARY_CHARGE * B / ELECTRON_MASS
    dt = 0.05 / wc
    periods = 20
    cfg = {"name": "val_gyro", "solver": {"type": "test_particle", "external_magnetic_field_t": [0, 0, B]},
           "domain": {"length_m": 1.0}, "grid": {"cells": 8},
           "species": [{"preset": "electron", "density_m3": 1.0}],
           "initial_condition": {"type": "single_particle", "positions_m": [[0.5, 0, 0]],
                                 "velocities_m_s": [[vperp, 0, vpar]]},
           "time": {"dt_s": dt, "duration_s": periods * 2 * math.pi / wc}, "random_seed": 0,
           "diagnostics": {"interval": 1, "record_trajectories": [0]}}
    sim = _run(cfg)
    tr = sim.diagnostics.trajectory(0)
    t, x, y, z, vx, vy, vz = tr.T
    phase = np.unwrap(np.arctan2(vy, vx))
    omega_meas = float(np.polyfit(t, phase, 1)[0])
    xc, yc, r_meas = _circle_fit(x, y)
    v_half = sim.model.particles.velocities[0]
    vperp_meas = float(np.hypot(v_half[0], v_half[1]))
    vpar_meas = float(np.polyfit(t, z, 1)[0])
    _, ke = sim.diagnostics.history("kinetic_energy_j")
    r_L = ELECTRON_MASS * vperp / (ELEMENTARY_CHARGE * B)
    w_boris = disp.boris_gyrofrequency(wc, dt)
    r_boris = r_L * math.sqrt(1 + (wc * dt / 2) ** 2)
    return ValidationResult(
        name="gyro_motion",
        problem="Electron (q=-e) with v_perp=1e5 m/s, v_par=2e4 m/s in uniform B=1e-3 T along z: helical orbit.",
        equations="m dv/dt = q v x B;  omega_c = |q|B/m;  r_L = m v_perp/(|q|B); rotation right-handed about B "
                  "for q<0. Boris discrete theory: omega_B = (2/dt) arctan(omega_c dt/2), "
                  "r_B = r_L sqrt(1+(omega_c dt/2)^2).",
        method="test_particle model, Boris pusher, omega_c dt = 0.05, 20 gyro-periods; frequency from the slope of "
               "the unwrapped velocity phase, radius from a least-squares circle fit of (x, y).",
        configuration={"B_t": B, "dt_s": dt, "omega_c_dt": wc * dt, "periods": periods},
        analytical={"omega_c_rad_s": wc, "omega_boris_rad_s": w_boris, "larmor_radius_m": r_L,
                    "boris_radius_m": r_boris, "v_perp_m_s": vperp, "v_par_m_s": vpar},
        numerical={"omega_rad_s": omega_meas, "radius_m": r_meas, "v_perp_m_s": vperp_meas, "v_par_m_s": vpar_meas,
                   "rotation_sense": "right-handed" if omega_meas > 0 else "left-handed",
                   "kinetic_energy_rel_variation": float((ke.max() - ke.min()) / ke.mean())},
        errors={"omega_rel_vs_boris": abs(omega_meas - w_boris) / w_boris,
                "omega_rel_vs_continuum": abs(omega_meas - wc) / wc,
                "radius_rel_vs_boris": abs(r_meas - r_boris) / r_boris,
                "radius_rel_vs_continuum": abs(r_meas - r_L) / r_L,
                "v_perp_rel": abs(vperp_meas - vperp) / vperp, "v_par_rel": abs(vpar_meas - vpar) / vpar,
                "energy_rel_variation": float((ke.max() - ke.min()) / ke.mean())},
        tolerances={"omega_rel_vs_boris": 1e-9, "omega_rel_vs_continuum": 3e-4, "radius_rel_vs_boris": 1e-9,
                    "radius_rel_vs_continuum": 5e-4, "v_perp_rel": 1e-12, "v_par_rel": 1e-12,
                    "energy_rel_variation": 1e-12},
        conclusion="the orbit matches the Boris discrete theory to round-off; the continuum error is the known "
                   "O((omega_c dt)^2/12) phase error and O((omega_c dt)^2/8) radius error; |v| is conserved exactly.",
    )


@_timed
def exb_drift() -> ValidationResult:
    """E x B drift of an electron and a proton in crossed uniform fields."""
    B, E = 1.0e-3, 1.0e2
    vE = np.cross([E, 0, 0], [0, 0, B]) / B**2  # (0, -1e5, 0)
    res_num, res_err = {}, {}
    cfgs = {}
    for name, preset, mass in (("electron", "electron", ELECTRON_MASS), ("proton", "proton", PROTON_MASS)):
        wc = ELEMENTARY_CHARGE * B / mass
        dt = 0.05 / wc
        L = max(1.0, 100 * float(np.linalg.norm(vE)) / wc)
        cfg = {"name": f"val_exb_{name}", "solver": {"type": "test_particle", "external_magnetic_field_t": [0, 0, B],
                                                     "external_electric_field_v_m": [E, 0, 0]},
               "domain": {"length_m": L}, "grid": {"cells": 8}, "species": [{"preset": preset, "density_m3": 1.0}],
               "initial_condition": {"type": "single_particle", "positions_m": [[L / 2, 0, 0]],
                                     "velocities_m_s": [[0, 0, 0]]},
               "time": {"dt_s": dt, "duration_s": 10 * 2 * math.pi / wc}, "random_seed": 0,
               "diagnostics": {"interval": 1, "record_trajectories": [0]}}
        cfgs[name] = {"dt_s": dt, "omega_c_dt": 0.05, "periods": 10}
        sim = _run(cfg)
        t, x, y, z, vx, vy, vz = sim.diagnostics.trajectory(0).T
        w = disp.boris_gyrofrequency(wc, dt)
        M = np.stack([t, np.cos(w * t), np.sin(w * t), np.ones_like(t)], axis=1)
        drift_y = float(np.linalg.lstsq(M, y, rcond=None)[0][0])
        Mx = np.stack([t, np.cos(w * t), np.sin(w * t), np.ones_like(t)], axis=1)
        drift_x = float(np.linalg.lstsq(Mx, x, rcond=None)[0][0])
        res_num[f"{name}_drift_m_s"] = [drift_x, drift_y, float(np.polyfit(t, z, 1)[0])]
        res_err[f"{name}_drift_rel"] = float(np.linalg.norm(np.array([drift_x, drift_y]) - vE[:2]) / np.linalg.norm(vE))
    return ValidationResult(
        name="exb_drift",
        problem="Electron and proton starting at rest in E = 100 V/m x-hat, B = 1e-3 T z-hat.",
        equations="v_E = E x B / B^2 = (0, -E/B, 0) = (0, -1e5, 0) m/s, independent of charge and mass.",
        method="test_particle model, Boris, omega_c dt = 0.05, 10 gyro-periods; guiding-centre drift from a linear "
               "least-squares fit y(t) = v t + a cos(omega_B t) + b sin(omega_B t) + c.",
        configuration=cfgs,
        analytical={"v_E_m_s": vE.tolist()},
        numerical=res_num,
        errors=res_err,
        tolerances={k: 1e-9 for k in res_err},
        conclusion="the Boris scheme reproduces the E x B drift to round-off for both species (charge and mass "
                   "independence verified).",
    )


@_timed
def poisson_equation() -> ValidationResult:
    """Poisson solver against analytical solutions, with convergence orders."""
    eps0 = VACUUM_PERMITTIVITY
    L = 1.0
    num, err, ana = {}, {}, {}
    orders = {}
    for method, bc in (("fft_fd", "periodic"), ("fft_spectral", "periodic"), ("fd", "periodic"), ("fd", "dirichlet")):
        errs = []
        ns = (32, 64, 128, 256)
        for n in ns:
            g = SpatialGrid.uniform(n, L, periodic=(bc == "periodic"))
            x = g.centres(0)
            k = 2 * math.pi / L if bc == "periodic" else math.pi / L
            rho = 1e-6 * np.sin(k * x)
            phi_a = 1e-6 * np.sin(k * x) / (eps0 * k * k)
            E_a = -1e-6 * np.cos(k * x) / (eps0 * k)
            r = PoissonSolver(g, method, bc).solve(rho)
            errs.append((float(np.max(np.abs(r.phi_v - phi_a)) / np.max(np.abs(phi_a))),
                         float(np.max(np.abs(r.electric_field_v_m[:, 0] - E_a)) / np.max(np.abs(E_a)))))
        e = np.array(errs)
        key = f"{method}_{bc}"
        num[f"{key}_phi_rel_err_n32_to_256"] = e[:, 0].tolist()
        num[f"{key}_E_rel_err_n32_to_256"] = e[:, 1].tolist()
        if method != "fft_spectral":
            p = np.log(e[:-1, 0] / e[1:, 0]) / np.log(2.0)
            orders[key] = float(p[-1])
            err[f"{key}_order_deviation"] = abs(float(p[-1]) - 2.0)
        else:
            err["fft_spectral_phi_rel_err"] = float(e[:, 0].max())
    num["observed_order_phi"] = orders
    # uniform neutral plasma: rho = 0 -> E = 0
    g = SpatialGrid.uniform(64, L)
    r = PoissonSolver(g, "fft_fd").solve(np.zeros(64))
    err["uniform_neutral_max_E_v_m"] = float(np.max(np.abs(r.electric_field_v_m)))
    # point-like source: one cell of charge density q/dx, periodic, neutralising mean removed
    n = 128
    g = SpatialGrid.uniform(n, L)
    x = g.centres(0)
    dx = L / n
    j0 = 40
    q = 1e-12
    rho = np.zeros(n)
    rho[j0] = q / dx
    r = PoissonSolver(g, "fft_fd").solve(rho)
    s = x - x[j0]
    s = (s + L / 2) % L - L / 2
    phi_a = q / eps0 * (s**2 / (2 * L) - np.abs(s) / 2 + L / 12)
    phi_a -= phi_a.mean()
    E_a = -q / eps0 * (s / L - np.sign(s) / 2)
    err["point_source_phi_rel_err"] = float(np.max(np.abs(r.phi_v - phi_a)) / np.max(np.abs(phi_a)))
    err["point_source_E_rel_err"] = float(np.max(np.abs(r.electric_field_v_m[:, 0] - E_a)) / np.max(np.abs(E_a)))
    err["point_source_residual"] = r.residual
    ana["point_source"] = "phi(s) = (q/eps0)[s^2/(2L) - |s|/2 + L/12] (periodic Green's function, zero mean); " \
                          "the 3-point Laplacian of this piecewise quadratic is exact at the nodes."
    ana["sinusoid"] = "rho = A sin(kx): phi = A sin(kx)/(eps0 k^2), E = -A cos(kx)/(eps0 k)"
    ana["dirichlet"] = "k = pi/L so that phi(0) = phi(L) = 0"
    return ValidationResult(
        name="poisson_equation",
        problem="Poisson equation for sinusoidal densities (periodic and grounded walls), a uniform neutral plasma "
                "and a single-cell point-like source.",
        equations="d^2 phi/dx^2 = -rho/eps0,  E = -d phi/dx",
        method="fft_fd, fft_spectral, sparse fd (periodic & Dirichlet ghost-cell); grids 32-256 cells.",
        configuration={"L_m": L, "cells": [32, 64, 128, 256]},
        analytical=ana, numerical=num, errors=err,
        tolerances={**{k: 0.05 for k in err if k.endswith("order_deviation")}, "fft_spectral_phi_rel_err": 1e-12,
                    "uniform_neutral_max_E_v_m": 1e-20, "point_source_phi_rel_err": 1e-10,
                    "point_source_E_rel_err": 1e-10, "point_source_residual": 1e-10},
        conclusion="finite-difference solvers converge at second order; the spectral solver is exact for "
                   "band-limited data; the point-source solution equals the discrete Green's function to round-off.",
    )


@_timed
def electromagnetic_wave() -> ValidationResult:
    """Vacuum EM wave in the 1D Yee solver: frequency, speed, wavelength, dispersion."""
    c_theory = 1.0 / math.sqrt(VACUUM_PERMEABILITY * VACUUM_PERMITTIVITY)
    L, n, mode = 1.0, 128, 4
    g = SpatialGrid.uniform(n, L)
    k = 2 * math.pi * mode / L
    dx = L / n
    num, err, ana = {}, {}, {}
    for courant in (0.5, 1.0):
        dt = courant * dx / SPEED_OF_LIGHT
        # standing wave
        s = Yee1DMaxwellSolver(g, dt)
        xc = g.centres(0)
        s.Ey[:] = np.sin(k * xc)
        nsteps = int(round(6 * 2 * math.pi / (SPEED_OF_LIGHT * k) / dt))
        amp = np.empty(nsteps + 1)
        for i in range(nsteps + 1):
            amp[i] = 2.0 / n * np.sum(s.Ey * np.sin(k * xc))
            s.step()
        t = np.arange(nsteps + 1) * dt
        f = fit_damped_oscillation(t, amp, omega_guess=SPEED_OF_LIGHT * k, fit_offset=False)
        w_yee = disp.yee_vacuum_frequency(k, dx, dt)
        num[f"standing_omega_courant{courant}"] = f.omega_rad_s
        ana[f"yee_omega_courant{courant}"] = w_yee
        err[f"standing_omega_rel_vs_yee_courant{courant}"] = abs(f.omega_rad_s - w_yee) / w_yee
        num[f"standing_amplitude_decay_rate_courant{courant}"] = f.gamma_s
        # travelling wave: Ey = cos(kx), Bz = Ey / c at edges
        s = Yee1DMaxwellSolver(g, dt)
        xe = g.edges(0)[:-1]
        s.Ey[:] = np.cos(k * xc)
        s.Bz[:] = np.cos(k * xe) / SPEED_OF_LIGHT
        modes = []
        for i in range(nsteps + 1):
            modes.append(np.sum(s.Ey * np.exp(-1j * k * xc)))
            s.step()
        omega_tr, vph = phase_velocity_from_mode(t, np.array(modes), k)
        spec = np.abs(np.fft.rfft(s.Ey))
        m_peak = int(np.argmax(spec[1:]) + 1)
        num[f"phase_velocity_m_s_courant{courant}"] = vph
        num[f"wavelength_m_courant{courant}"] = L / m_peak
        err[f"phase_velocity_rel_vs_yee_courant{courant}"] = abs(vph - w_yee / k) / (w_yee / k)
        err[f"phase_velocity_rel_vs_c_courant{courant}"] = abs(vph - c_theory) / c_theory
        err[f"wavelength_rel_courant{courant}"] = abs(L / m_peak - L / mode) / (L / mode)
        num[f"numerical_dispersion_omega_over_ck_courant{courant}"] = f.omega_rad_s / (SPEED_OF_LIGHT * k)
    ana["c_from_mu0_eps0_m_s"] = c_theory
    ana["omega_ck_rad_s"] = SPEED_OF_LIGHT * k
    k_dx = k * dx
    return ValidationResult(
        name="electromagnetic_wave",
        problem="Vacuum transverse wave (E_y, B_z), mode 4 on a 1 m periodic domain with 128 cells, standing and "
                "travelling initial conditions, Courant numbers 0.5 and 1.0.",
        equations="dB_z/dt = -dE_y/dx, dE_y/dt = -c^2 dB_z/dx; omega = c k with c = 1/sqrt(mu0 eps0); Yee discrete "
                  "dispersion sin(omega dt/2)/(c dt) = sin(k dx/2)/dx.",
        method="Yee1DMaxwellSolver; standing-wave frequency by nonlinear least squares; travelling-wave phase "
               "velocity from the unwrapped phase of the Fourier mode; wavelength from the spectral peak.",
        configuration={"L_m": L, "cells": n, "mode": mode, "k_dx": k_dx, "courant": [0.5, 1.0]},
        analytical=ana, numerical=num, errors=err,
        tolerances={"standing_omega_rel_vs_yee_courant0.5": 1e-8, "standing_omega_rel_vs_yee_courant1.0": 1e-8,
                    "phase_velocity_rel_vs_yee_courant0.5": 5e-5, "phase_velocity_rel_vs_yee_courant1.0": 5e-5,
                    "phase_velocity_rel_vs_c_courant0.5": 2e-3, "phase_velocity_rel_vs_c_courant1.0": 5e-5,
                    "wavelength_rel_courant0.5": 0.0, "wavelength_rel_courant1.0": 0.0},
        conclusion=f"frequencies match the Yee dispersion relation to round-off; at Courant 0.5 the numerical phase "
                   f"velocity is below c by the predicted O((k dx)^2 (1-C^2)/24) = "
                   f"{(k_dx**2) * (1 - 0.25) / 24:.2e}; at Courant 1 the scheme is dispersion-free. The travelling "
                   "initialisation (B_z = E_y/c sampled at edges, same time level) contains a small backward wave "
                   "that limits the phase-velocity measurement to ~1e-5; the standing-wave frequency is the precise "
                   "dispersion measurement (fit precision ~1e-9).",
    )


def _cold_cfg(name: str, cells=64, ppc=100, periods=10, dt_wp=0.05, amp=0.01, B=None, extra_solver=None):
    cfg = {"name": name, "solver": {"type": "electrostatic_pic", "deposition": "cic", "poisson": "fft_fd"},
           "domain": {"length_m": 1.0}, "grid": {"cells": cells}, "species": _electrons_and_ions(),
           "particles": {"count": cells * ppc, "position_loading": "quiet"},
           "initial_condition": {"type": "cold", "perturbation": {"mode": 1, "amplitude": amp}},
           "time": {"dt_s": dt_wp / WPE, "duration_s": periods * 2 * math.pi / WPE}, "random_seed": 1,
           "diagnostics": {"interval": 2}}
    if B is not None:
        cfg["solver"]["external_magnetic_field_t"] = [0, 0, B]
    if extra_solver:
        cfg["solver"].update(extra_solver)
    return cfg


@_timed
def plasma_oscillation() -> ValidationResult:
    """Cold electron plasma oscillation in electrostatic PIC."""
    cells, dt_wp = 64, 0.05
    sim = _run(_cold_cfg("val_cold_oscillation", cells=cells, dt_wp=dt_wp))
    t, y = sim.diagnostics.history("mode_im_Ex_m1")
    f = fit_damped_oscillation(t, y)
    k = 2 * math.pi
    dx, dt = 1.0 / cells, dt_wp / WPE
    w_disc = disp.pic_cold_plasma_frequency(WPE, k, dx, dt, shape_order=1, poisson="fft_fd")
    _, ee = sim.diagnostics.history("energy_error")
    return ValidationResult(
        name="plasma_oscillation",
        problem="Cold electron plasma (n = 1e12 m^-3) over immobile protons; 1% density perturbation at mode 1.",
        equations="omega = omega_pe = sqrt(n e^2/(m_e eps0)); discrete ES-PIC (CIC, FD Poisson, centred gradient, "
                  "leapfrog): omega^2 = omega_p^2 S(k)^2 kappa(k) k / K(k)^2, sin(omega dt/2) = omega_grid dt/2.",
        method="electrostatic_pic, 64 cells, 100 particles/cell (quiet start), omega_p dt = 0.05, 10 periods; "
               "frequency from a least-squares fit of the mode-1 Fourier amplitude of E_x.",
        configuration={"cells": cells, "ppc": 100, "omega_p_dt": dt_wp, "amplitude": 0.01, "k_dx": k * dx},
        analytical={"omega_p_rad_s": WPE, "omega_discrete_theory_rad_s": w_disc},
        numerical={"omega_rad_s": f.omega_rad_s, "omega_std_err": f.omega_std_err, "fit_r2": f.r_squared,
                   "amplitude_rate_s": f.gamma_s, "max_abs_energy_error": float(np.abs(ee).max())},
        errors={"omega_rel_vs_omega_p": abs(f.omega_rad_s - WPE) / WPE,
                "omega_rel_vs_discrete_theory": abs(f.omega_rad_s - w_disc) / w_disc,
                "max_abs_energy_error": float(np.abs(ee).max())},
        tolerances={"omega_rel_vs_omega_p": 3e-3, "omega_rel_vs_discrete_theory": 3e-4, "max_abs_energy_error": 5e-3},
        conclusion="the oscillation frequency emerges from deposition + Poisson + push and agrees with omega_pe "
                   "within the predicted O((k dx)^2, (omega dt)^2) discretisation error; the residual relative to the "
                   "discrete theory is set by the nonlinear (1% amplitude) and alias terms neglected in it.",
    )


@_timed
def langmuir_wave() -> ValidationResult:
    """Warm Langmuir wave: Bohm-Gross / kinetic dispersion in ES-PIC."""
    k_lambda = 0.2
    k = 2 * math.pi
    lam = k_lambda / k
    T = lam**2 * N0 * ELEMENTARY_CHARGE**2 / (VACUUM_PERMITTIVITY * BOLTZMANN_CONSTANT)
    cells, ppc = 64, 1000
    cfg = {"name": "val_langmuir", "solver": {"type": "electrostatic_pic", "poisson": "fft_fd"},
           "domain": {"length_m": 1.0}, "grid": {"cells": cells}, "species": _electrons_and_ions(T),
           "particles": {"count": cells * ppc, "position_loading": "quiet", "velocity_loading": "quiet"},
           "initial_condition": {"type": "plasma_wave", "perturbation": {"mode": 1, "amplitude": 0.05}},
           "time": {"dt_s": 0.05 / WPE, "duration_s": 8 * 2 * math.pi / WPE}, "random_seed": 3,
           "diagnostics": {"interval": 2}}
    sim = _run(cfg)
    t, y = sim.diagnostics.history("mode_im_Ex_m1")
    f = fit_damped_oscillation(t, y)
    vt = math.sqrt(BOLTZMANN_CONSTANT * T / ELECTRON_MASS)
    w_bg = disp.bohm_gross_frequency(WPE, k, vt, 3.0)
    root = disp.landau_damping_root(k_lambda) * WPE
    return ValidationResult(
        name="langmuir_wave",
        problem=f"Warm electron plasma, k lambda_D = {k_lambda}, 5% density perturbation (T = {T:.4e} K).",
        equations="kinetic: 1 + (1/(k lambda_D)^2)[1 + zeta Z(zeta)] = 0, zeta = omega/(sqrt2 k v_th); "
                  "fluid limit (Bohm-Gross): omega^2 = omega_p^2 + 3 k^2 v_th^2, v_th = sqrt(kT/m).",
        method="electrostatic_pic, 64 cells (dx = 0.49 lambda_D), 1000 particles/cell, quiet start in x and v, "
               "omega_p dt = 0.05, 8 periods; frequency by least squares on the E_x mode-1 amplitude.",
        configuration={"k_lambda_D": k_lambda, "temperature_k": T, "cells": cells, "ppc": ppc},
        analytical={"omega_kinetic_rad_s": root.real, "gamma_kinetic_s": root.imag, "omega_bohm_gross_rad_s": w_bg},
        numerical={"omega_rad_s": f.omega_rad_s, "omega_std_err": f.omega_std_err, "amplitude_rate_s": f.gamma_s,
                   "fit_r2": f.r_squared},
        errors={"omega_rel_vs_kinetic": abs(f.omega_rad_s - root.real) / root.real,
                "omega_rel_vs_bohm_gross": abs(f.omega_rad_s - w_bg) / w_bg},
        tolerances={"omega_rel_vs_kinetic": 5e-3},
        conclusion="the thermal frequency shift emerges from the particle dynamics and agrees with the kinetic "
                   "(Landau) dispersion root; Bohm-Gross is shown for reference (it is the small-k lambda_D limit).",
    )


@_timed
def upper_hybrid_oscillation() -> ValidationResult:
    """Cold magnetised plasma oscillation perpendicular to B."""
    ratio = 0.8
    B = ratio * WPE * ELECTRON_MASS / ELEMENTARY_CHARGE
    sim = _run(_cold_cfg("val_upper_hybrid", B=B, dt_wp=0.02, periods=8))
    t, y = sim.diagnostics.history("mode_im_Ex_m1")
    f = fit_damped_oscillation(t, y)
    wuh = disp.upper_hybrid_frequency(WPE, ratio * WPE)
    return ValidationResult(
        name="upper_hybrid_oscillation",
        problem="Cold electron plasma in B = 0.8 m_e omega_pe / e along z, perturbation with k along x (k perp B).",
        equations="omega_UH^2 = omega_pe^2 + omega_ce^2",
        method="electrostatic_pic with uniform external B, Boris, omega_p dt = 0.02, 64 cells x 100 ppc, 8 periods.",
        configuration={"B_t": B, "omega_c_over_omega_p": ratio, "omega_p_dt": 0.02},
        analytical={"omega_uh_rad_s": wuh},
        numerical={"omega_rad_s": f.omega_rad_s, "fit_r2": f.r_squared},
        errors={"omega_rel_vs_upper_hybrid": abs(f.omega_rad_s - wuh) / wuh},
        tolerances={"omega_rel_vs_upper_hybrid": 3e-3},
        conclusion="magnetised oscillation frequency agrees with the cold upper-hybrid frequency within the "
                   "grid-shape correction (~(k dx)^2/12 on the omega_p^2 term).",
    )


@_timed
def two_stream_instability() -> ValidationResult:
    """Two-stream instability growth rate in ES-PIC vs kinetic theory."""
    L, cells, ppc = 1.0, 128, 200
    k = 2 * math.pi / L
    v0 = math.sqrt(3.0 / 8.0) * WPE / k  # most unstable cold-beam wavenumber at mode 1
    vt = 0.05 * v0
    T = ELECTRON_MASS * vt**2 / BOLTZMANN_CONSTANT
    sp = [{"name": "beam_plus", "preset": "electron", "density_m3": N0 / 2, "temperature_k": T,
           "bulk_velocity_m_s": [v0, 0, 0]},
          {"name": "beam_minus", "preset": "electron", "density_m3": N0 / 2, "temperature_k": T,
           "bulk_velocity_m_s": [-v0, 0, 0]},
          {"name": "ions", "preset": "proton", "density_m3": N0, "mobile": False}]
    cfg = {"name": "val_two_stream", "solver": {"type": "electrostatic_pic", "poisson": "fft_fd"},
           "domain": {"length_m": L}, "grid": {"cells": cells}, "species": sp,
           "particles": {"count": cells * ppc, "position_loading": "quiet"},
           "initial_condition": {"type": "two_stream", "perturbation": {"mode": 1, "amplitude": 1e-3}},
           "time": {"dt_s": 0.04 / WPE, "duration_s": 40 / WPE}, "random_seed": 7,
           "diagnostics": {"interval": 2, "field_modes": [1, 2, 3]}}
    sim = _run(cfg)
    t, a = sim.diagnostics.history("mode_amp_Ex_m1")
    fit = fit_growth_rate(t, a, min_r2=0.995)
    g_cold = disp.cold_two_stream_growth_rate(WPE, k, v0)
    ks = [disp.KineticSpecies(WPE / math.sqrt(2), v0, vt), disp.KineticSpecies(WPE / math.sqrt(2), -v0, vt)]
    root = disp.solve_electrostatic_dispersion(k, ks, 1j * g_cold)
    sat = float(a.max())
    return ValidationResult(
        name="two_stream_instability",
        problem="Two counter-streaming electron beams (+-v0, each n0/2, v_th = 0.05 v0) over immobile ions; "
                "mode 1 at the cold-beam fastest-growing wavenumber k v0 = sqrt(3/8) omega_p; seed 1e-3.",
        equations="1 + sum_s (omega_ps^2/(k^2 v_s^2)) [1 + zeta_s Z(zeta_s)] = 0, zeta_s = (omega - k u_s)/"
                  "(sqrt2 k v_s); cold limit gamma = omega_p/(2 sqrt2).",
        method="electrostatic_pic, 128 cells, 200 particles/cell/beam, omega_p dt = 0.04; growth rate from a linear "
               "fit of log|E_1(t)| over the automatically selected linear phase (see fit_growth_rate).",
        configuration={"v0_m_s": v0, "v_th_m_s": vt, "temperature_k": T, "k_v0_over_omega_p": k * v0 / WPE,
                       "cells": cells, "ppc_per_beam": ppc, "seed": 7},
        analytical={"gamma_kinetic_s": root.imag, "omega_r_kinetic_rad_s": root.real, "gamma_cold_s": g_cold},
        numerical={"gamma_s": fit.growth_rate_s, "gamma_std_err_s": fit.growth_rate_std_err,
                   "fit_interval_s": list(fit.fit_interval_s), "fit_r2": fit.r_squared,
                   "n_fit_points": fit.n_points, "saturation_amplitude_v_m": sat,
                   "gamma_over_omega_p": fit.growth_rate_s / WPE},
        errors={"gamma_rel_vs_kinetic": abs(fit.growth_rate_s - root.imag) / root.imag,
                "gamma_rel_vs_cold": abs(fit.growth_rate_s - g_cold) / g_cold,
                "fit_r2_deficit": 1.0 - fit.r_squared},
        tolerances={"gamma_rel_vs_kinetic": 0.05, "fit_r2_deficit": 0.01},
        conclusion="exponential growth emerges from the seeded perturbation; the measured growth rate (a "
                   "numerical measurement) agrees with the kinetic linear theory within the tolerance set by finite "
                   "particle number, the seed's mixture of normal modes and grid effects.",
    )


@_timed
def landau_damping() -> ValidationResult:
    """Linear Landau damping in the Vlasov-Poisson solver."""
    T_ev = 10.0
    T = T_ev * ELEMENTARY_CHARGE / BOLTZMANN_CONSTANT
    lam = math.sqrt(VACUUM_PERMITTIVITY * BOLTZMANN_CONSTANT * T / (N0 * ELEMENTARY_CHARGE**2))
    k_lambda = 0.5
    L = 2 * math.pi * lam / k_lambda
    cfg = {"name": "val_landau", "solver": {"type": "vlasov", "poisson": "fft_spectral",
                                             "vlasov": {"velocity_cells": 256, "velocity_extent_vth": 6.0}},
           "domain": {"length_m": L}, "grid": {"cells": 32}, "species": _electrons_and_ions(T),
           "initial_condition": {"type": "plasma_wave", "perturbation": {"mode": 1, "amplitude": 0.01}},
           "time": {"dt_s": 0.05 / WPE, "duration_s": 30 / WPE}, "random_seed": 0, "diagnostics": {"interval": 1}}
    sim = _run(cfg)
    t, y = sim.diagnostics.history("mode_amp_Ex_m1")
    g = peak_envelope_rate(t, y, (3 / WPE, 30 / WPE))
    w = peak_period_frequency(t, y, (3 / WPE, 30 / WPE))
    root = disp.landau_damping_root(k_lambda) * WPE
    _, me = sim.diagnostics.history("relative_mass_error__electron")
    _, ee = sim.diagnostics.history("energy_error")
    return ValidationResult(
        name="landau_damping",
        problem="Maxwellian electrons (10 eV), 1% density perturbation at k lambda_D = 0.5, immobile ions.",
        equations="df/dt + v df/dx - (e/m) E df/dv = 0, dE/dx = rho/eps0; linear theory: root of "
                  "1 + (1/(k lambda_D)^2)[1 + zeta Z(zeta)] = 0.",
        method="vlasov (1D1V semi-Lagrangian, Strang), 32 x 256 phase-space cells, v in +-6 v_th, omega_p dt = "
               "0.05, t <= 30/omega_p (recurrence time 268/omega_p); damping from log of |E_1| peaks, frequency "
               "from peak spacing.",
        configuration={"k_lambda_D": k_lambda, "nx": 32, "nv": 256, "omega_p_dt": 0.05},
        analytical={"omega_rad_s": root.real, "gamma_s": root.imag, "omega_over_omega_p": root.real / WPE,
                    "gamma_over_omega_p": root.imag / WPE},
        numerical={"omega_rad_s": w, "gamma_s": g.growth_rate_s, "gamma_std_err_s": g.growth_rate_std_err,
                   "fit_r2": g.r_squared, "omega_over_omega_p": w / WPE, "gamma_over_omega_p": g.growth_rate_s / WPE,
                   "final_relative_mass_error": float(me[-1]), "max_abs_energy_error": float(np.abs(ee).max())},
        errors={"gamma_rel": abs(g.growth_rate_s - root.imag) / abs(root.imag),
                "omega_rel": abs(w - root.real) / root.real, "mass_error": abs(float(me[-1])),
                "energy_error": float(np.abs(ee).max())},
        tolerances={"gamma_rel": 0.02, "omega_rel": 0.01, "mass_error": 1e-8, "energy_error": 1e-4},
        conclusion="collisionless damping emerges from phase mixing and matches the Landau root; the frequency "
                   "estimate from peak spacing has an O(1e-3) bias from the transient of the initial perturbation.",
    )


@_timed
def fluid_langmuir_wave() -> ValidationResult:
    """Langmuir wave in the adiabatic (gamma = 3) electron fluid model."""
    T_ev = 10.0
    k = 2 * math.pi
    cfg = {"name": "val_fluid_langmuir", "solver": {"type": "fluid", "fluid": {"closure": "adiabatic", "gamma": 3.0}},
           "domain": {"length_m": 1.0}, "grid": {"cells": 64},
           "species": [{"preset": "electron", "density_m3": N0, "temperature_ev": T_ev},
                       {"preset": "proton", "density_m3": N0, "mobile": False}],
           "initial_condition": {"type": "plasma_wave", "perturbation": {"mode": 1, "amplitude": 0.01}},
           "time": {"dt_s": 0.05 / WPE, "duration_s": 10 * 2 * math.pi / WPE}, "random_seed": 0,
           "diagnostics": {"interval": 2}}
    sim = _run(cfg)
    t, y = sim.diagnostics.history("mode_im_Ex_m1")
    f = fit_damped_oscillation(t, y)
    vt = math.sqrt(T_ev * ELEMENTARY_CHARGE / ELECTRON_MASS)
    w = disp.bohm_gross_frequency(WPE, k, vt, 3.0)
    _, ee = sim.diagnostics.history("energy_error")
    _, me = sim.diagnostics.history("relative_mass_error__electron")
    return ValidationResult(
        name="fluid_langmuir_wave",
        problem="Electron fluid (adiabatic gamma = 3, T = 10 eV) over immobile ions, 1% perturbation at mode 1.",
        equations="omega^2 = omega_p^2 + gamma k^2 k_B T/m (linearised Euler-Poisson).",
        method="fluid model, MUSCL-MC + Rusanov + SSP-RK3, 64 cells, omega_p dt = 0.05, 10 periods.",
        configuration={"gamma": 3.0, "T_ev": T_ev, "cells": 64},
        analytical={"omega_bohm_gross_rad_s": w},
        numerical={"omega_rad_s": f.omega_rad_s, "amplitude_rate_s": f.gamma_s, "fit_r2": f.r_squared,
                   "max_abs_energy_error": float(np.abs(ee).max())},
        errors={"omega_rel": abs(f.omega_rad_s - w) / w, "max_abs_energy_error": float(np.abs(ee).max()),
                "mass_error": float(np.abs(me).max())},
        tolerances={"omega_rel": 1e-3, "max_abs_energy_error": 1e-3, "mass_error": 1e-12},
        conclusion="the fluid model reproduces the Bohm-Gross frequency; mass is conserved to round-off by the "
                   "finite-volume form; the small energy error is numerical dissipation of the limiter/Rusanov flux.",
    )


@_timed
def electromagnetic_plasma_wave() -> ValidationResult:
    """Transverse EM wave in a cold plasma (1D EM-PIC foundation)."""
    L = 2 * math.pi * SPEED_OF_LIGHT / WPE  # k c = omega_p for mode 1
    cells = 128
    dx = L / cells
    cfg = {"name": "val_em_plasma", "solver": {"type": "electromagnetic_pic", "poisson": "fft_fd"},
           "domain": {"length_m": L}, "grid": {"cells": cells}, "species": _electrons_and_ions(),
           "particles": {"count": cells * 50, "position_loading": "quiet"},
           "initial_condition": {"type": "cold", "em_wave": {"mode": 1, "amplitude_v_m": 1.0}},
           "time": {"dt_s": 0.5 * dx / SPEED_OF_LIGHT, "duration_s": 6 * 2 * math.pi / WPE}, "random_seed": 0,
           "diagnostics": {"interval": 2}}
    sim = _run(cfg)
    t, y = sim.diagnostics.history("mode_re_Ey_m1")
    f = fit_damped_oscillation(t, y)
    k = 2 * math.pi / L
    w = disp.cold_em_wave_frequency(WPE, k)
    _, ee = sim.diagnostics.history("energy_error")
    _, gr = sim.diagnostics.history("gauss_residual")
    return ValidationResult(
        name="electromagnetic_plasma_wave",
        problem="Standing E_y wave (mode 1, k c = omega_p) in a cold electron plasma with immobile ions.",
        equations="omega^2 = omega_p^2 + c^2 k^2 (cold unmagnetised plasma, transverse mode).",
        method="electromagnetic_pic (1D Yee + direct J_y,J_z deposition, E_x from Poisson), 128 cells, 50 ppc, "
               "c dt/dx = 0.5, 6 plasma periods.",
        configuration={"L_m": L, "cells": cells, "courant": 0.5, "k_c_over_omega_p": 1.0},
        analytical={"omega_rad_s": w, "omega_over_omega_p": w / WPE},
        numerical={"omega_rad_s": f.omega_rad_s, "fit_r2": f.r_squared, "max_abs_energy_error": float(np.abs(ee).max()),
                   "max_gauss_residual": float(np.max(gr))},
        errors={"omega_rel": abs(f.omega_rad_s - w) / w, "max_abs_energy_error": float(np.abs(ee).max())},
        tolerances={"omega_rel": 1e-3, "max_abs_energy_error": 5e-3},
        conclusion="the coupled particle-field system reproduces the cold-plasma EM dispersion relation. This "
                   "validates the 1D EM-PIC foundation only (1D, periodic, non-charge-conserving current deposition "
                   "made harmless by solving E_x from Poisson).",
    )


@_timed
def energy_momentum_conservation() -> ValidationResult:
    """Energy and momentum conservation of periodic thermal ES-PIC."""
    T_ev = 10.0
    T = T_ev * ELEMENTARY_CHARGE / BOLTZMANN_CONSTANT
    lam = math.sqrt(VACUUM_PERMITTIVITY * BOLTZMANN_CONSTANT * T / (N0 * ELEMENTARY_CHARGE**2))
    cells = 64
    L = 0.5 * lam * cells  # dx = 0.5 lambda_D
    cfg = {"name": "val_conservation", "solver": {"type": "electrostatic_pic", "poisson": "fft_fd"},
           "domain": {"length_m": L}, "grid": {"cells": cells}, "species": _electrons_and_ions(T),
           "particles": {"count": cells * 100}, "initial_condition": {"type": "maxwellian"},
           "time": {"dt_s": 0.05 / WPE, "duration_s": 20 * 2 * math.pi / WPE}, "random_seed": 11,
           "diagnostics": {"interval": 10}}
    sim = _run(cfg)
    _, ee = sim.diagnostics.history("energy_error")
    _, pe = sim.diagnostics.history("momentum_error")
    _, qe = sim.diagnostics.history("relative_charge_error")
    return ValidationResult(
        name="energy_momentum_conservation",
        problem="Thermal electron plasma (10 eV, random loading), periodic, 20 plasma periods, dx = 0.5 lambda_D.",
        equations="d/dt [sum m v^2/2 + integral eps0 E^2/2] = 0;  d/dt sum m v = 0 (closed periodic system).",
        method="electrostatic_pic, CIC deposition = CIC interpolation, FD Poisson via FFT, centred gradient "
               "(momentum-conserving scheme), omega_p dt = 0.05, 100 ppc.",
        configuration={"cells": cells, "ppc": 100, "dx_over_lambda_D": 0.5, "omega_p_dt": 0.05, "seed": 11},
        analytical={"energy_error": 0.0, "momentum_error": 0.0, "charge_error": 0.0},
        numerical={"max_abs_energy_error": float(np.abs(ee).max()), "final_energy_error": float(ee[-1]),
                   "max_momentum_error": float(np.max(pe)), "max_charge_error": float(np.max(qe))},
        errors={"max_abs_energy_error": float(np.abs(ee).max()), "max_momentum_error": float(np.max(pe)),
                "max_charge_error": float(np.max(qe))},
        tolerances={"max_abs_energy_error": 1e-2, "max_momentum_error": 1e-10, "max_charge_error": 1e-14},
        conclusion="momentum is conserved to round-off (the scheme is momentum-conserving by construction); total "
                   "energy is not an exact invariant of momentum-conserving PIC and shows a small measured drift "
                   "(numerical heating); charge is exactly conserved.",
    )


@_timed
def charge_conservation_absorbing() -> ValidationResult:
    """Charge accounting with absorbing walls (charge leaves only through the walls)."""
    T = 10.0 * ELEMENTARY_CHARGE / BOLTZMANN_CONSTANT
    cfg = {"name": "val_absorbing", "solver": {"type": "electrostatic_pic", "poisson": "fd"},
           "domain": {"length_m": 0.2}, "grid": {"cells": 32}, "species": _electrons_and_ions(T),
           "boundaries": {"particles": "absorbing"}, "particles": {"count": 20000},
           "initial_condition": {"type": "maxwellian"},
           "time": {"dt_s": 0.04 / WPE, "duration_s": 10 * 2 * math.pi / WPE}, "random_seed": 5,
           "diagnostics": {"interval": 5}}
    sim = _run(cfg)
    _, qe = sim.diagnostics.history("relative_charge_error")
    _, ql = sim.diagnostics.history("charge_lost_c")
    _, n = sim.diagnostics.history("particles__electron")
    _, me = sim.diagnostics.history("mass_error_accounted__electron")
    _, ea = sim.diagnostics.history("energy_error_accounted")
    led = sim.model.ledger
    st = sim.state
    grid_q = st.extras["grid_charge_c"]
    return ValidationResult(
        name="charge_conservation_absorbing",
        problem="Thermal electrons between grounded absorbing walls (sheath formation); immobile ions.",
        equations="Q(t) + Q_lost(t) = Q(0);  W(t) + W_lost(t) = W(0) for the particle weight (mass).",
        method="electrostatic_pic with absorbing particle boundaries and Dirichlet (phi = 0) walls, fd Poisson.",
        configuration={"L_m": 0.2, "cells": 32, "particles": 20000, "omega_p_dt": 0.04},
        analytical={"accounted_charge_residual": 0.0, "accounted_mass_residual": 0.0},
        numerical={"particles_initial": int(n[0]), "particles_remaining": int(n[-1]),
                   "particles_lost": int(led.particles_lost.sum()), "charge_lost_c": float(ql[-1]),
                   "energy_lost_j": float(led.energy_lost_j.sum()), "max_accounted_charge_error": float(np.max(qe)),
                   "max_accounted_mass_error": float(np.max(np.abs(me))),
                   "grid_vs_particle_charge_rel": abs(grid_q - st.total_charge_c) / sim.diagnostics.q_abs,
                   "final_accounted_energy_error": float(ea[-1])},
        errors={"max_accounted_charge_error": float(np.max(qe)), "max_accounted_mass_error": float(np.max(np.abs(me))),
                "grid_vs_particle_charge_rel": abs(grid_q - st.total_charge_c) / sim.diagnostics.q_abs},
        tolerances={"max_accounted_charge_error": 1e-13, "max_accounted_mass_error": 1e-13,
                    "grid_vs_particle_charge_rel": 1e-13},
        conclusion="every particle, coulomb and joule leaving the domain is accounted for in the loss ledger; "
                   "deposited grid charge equals the particle charge (deposition is charge-conserving). The "
                   "accounted energy error is reported but not a pass criterion: with grounded walls the wall "
                   "potential does work (image charges) that is not part of the closed-system budget.",
    )


@_timed
def checkpoint_restart() -> ValidationResult:
    """Continuous run vs run -> checkpoint -> restart -> continue."""
    T = 5.0 * ELEMENTARY_CHARGE / BOLTZMANN_CONSTANT
    base = {"name": "val_restart", "solver": {"type": "electrostatic_pic", "poisson": "fft_fd",
                                                "collisions": {"model": "effective_frequency", "frequency_hz": 0.01 * WPE,
                                                               "background_temperature_k": T}},
            "domain": {"length_m": 0.5}, "grid": {"cells": 32}, "species": _electrons_and_ions(T),
            "particles": {"count": 3200}, "initial_condition": {"type": "plasma_wave",
                                                                "perturbation": {"mode": 1, "amplitude": 0.05}},
            "time": {"dt_s": 0.1 / WPE, "duration_s": 200 * 0.1 / WPE}, "random_seed": 21, "diagnostics": {"interval": 10}}
    a = _run(base)
    with tempfile.TemporaryDirectory() as d:
        b = PlasmaSimulation(SimulationConfig.from_dict(base))
        b.initialize()
        b.run(until_step=100)
        path = b.checkpoint(Path(d) / "ck.h5")
        c = PlasmaSimulation.restart(path)
        c.run()
    pa, pc = a.model.particles, c.model.particles
    dpos = float(np.max(np.abs(pa.positions - pc.positions)))
    dvel = float(np.max(np.abs(pa.velocities - pc.velocities)))
    ta, tc = a.diagnostics.table(), c.diagnostics.table()
    def _coldiff(x, y):
        if np.array_equal(x, y, equal_nan=True):
            return 0.0
        both = ~(np.isnan(x) & np.isnan(y))
        return float(np.max(np.abs(x[both] - y[both]))) if both.any() else math.inf
    ddiag = max(_coldiff(ta[k], tc[k]) if k in tc else math.inf for k in ta)
    return ValidationResult(
        name="checkpoint_restart",
        problem="Warm plasma wave with stochastic (Langevin) collisions: 200 steps continuous vs 100 steps, "
                "checkpoint, restart from file, 100 steps.",
        equations="bitwise identity of the final state and diagnostic history",
        method="HDF5 checkpoint of particles, fields, step counter, random-generator state and diagnostics.",
        configuration={"steps": 200, "checkpoint_step": 100, "collision_frequency_hz": 0.01 * WPE},
        analytical={"max_position_difference_m": 0.0, "max_velocity_difference_m_s": 0.0},
        numerical={"max_position_difference_m": dpos, "max_velocity_difference_m_s": dvel,
                   "max_diagnostic_difference": ddiag, "rows_continuous": len(a.diagnostics.rows),
                   "rows_restarted": len(c.diagnostics.rows)},
        errors={"max_position_difference_m": dpos, "max_velocity_difference_m_s": dvel,
                "max_diagnostic_difference": ddiag,
                "row_count_mismatch": float(len(a.diagnostics.rows) - len(c.diagnostics.rows))},
        tolerances={"max_position_difference_m": 0.0, "max_velocity_difference_m_s": 0.0,
                    "max_diagnostic_difference": 0.0, "row_count_mismatch": 0.0},
        conclusion="the restarted trajectory, including the random collision stream, is bitwise identical to the "
                   "continuous run on the same platform/backend.",
    )


@_timed
def reproducibility() -> ValidationResult:
    """Identical configuration + seed -> identical initial population; different seed -> different."""
    cfg = SimulationConfig.from_dict({
        "solver": {"type": "electrostatic_pic"}, "domain": {"length_m": 1.0}, "grid": {"cells": 32},
        "species": _electrons_and_ions(1e4), "particles": {"count": 1000}, "time": {"dt_s": 1e-10, "duration_s": 1e-9},
        "random_seed": 42})
    a = PlasmaSimulation(cfg).initialize().model.particles
    b = PlasmaSimulation(cfg).initialize().model.particles
    c = PlasmaSimulation(cfg.with_updates(random_seed=43)).initialize().model.particles
    same = float(np.max(np.abs(a.velocities - b.velocities)) + np.max(np.abs(a.positions - b.positions)))
    diff = float(np.max(np.abs(a.velocities - c.velocities)))
    return ValidationResult(
        name="reproducibility", problem="Initial particle populations for identical and different seeds.",
        equations="population = F(configuration, seed, software version)",
        method="numpy PCG64 Generators spawned from SeedSequence(random_seed), one per species.",
        configuration={"seed": 42, "particles": 1000},
        analytical={"identical_difference": 0.0},
        numerical={"identical_seed_max_difference": same, "different_seed_max_difference": diff},
        errors={"identical_seed_max_difference": same, "different_seed_is_different": 0.0 if diff > 0 else 1.0},
        tolerances={"identical_seed_max_difference": 0.0, "different_seed_is_different": 0.0},
        conclusion="initial populations are deterministic functions of the recorded seed.",
    )


ALL_CASES = [gyro_motion, exb_drift, poisson_equation, electromagnetic_wave, plasma_oscillation, langmuir_wave,
             upper_hybrid_oscillation, two_stream_instability, landau_damping, fluid_langmuir_wave,
             electromagnetic_plasma_wave, energy_momentum_conservation, charge_conservation_absorbing,
             checkpoint_restart, reproducibility]
