"""plasma_core: a reference plasma-physics simulation framework (SI units).

The physics is the product; visualisation is only an observation of it.
See README.md and docs/ for scope, equations, numerics and validation.
"""

__version__ = "0.1.0"

from . import constants, units  # noqa: E402
from .configuration import SimulationConfig  # noqa: E402
from .exceptions import (  # noqa: E402
    BoundaryConditionError,
    CheckpointError,
    ConservationError,
    InvalidPhysicalConfiguration,
    NumericalInstabilityError,
    SolverConfigurationError,
    StabilityCriterionViolation,
)
from .simulation import PlasmaSimulation  # noqa: E402
from .species import Species, custom_species, electron, ion, neutralizing_background, positron, proton  # noqa: E402
from .state import PlasmaState  # noqa: E402

__all__ = [
    "__version__", "constants", "units", "SimulationConfig", "PlasmaSimulation", "PlasmaState", "Species",
    "electron", "proton", "positron", "ion", "custom_species", "neutralizing_background",
    "InvalidPhysicalConfiguration", "NumericalInstabilityError", "StabilityCriterionViolation",
    "BoundaryConditionError", "SolverConfigurationError", "CheckpointError", "ConservationError",
]
