"""Kernel and full-step benchmarks; writes benchmarks/results.json.

    python benchmarks/run_benchmarks.py [n_particles] [n_cells]
"""

import json
import platform
import sys
from pathlib import Path

from plasma_core.benchmarks import format_benchmarks, run_benchmarks

n = int(sys.argv[1]) if len(sys.argv) > 1 else 200_000
c = int(sys.argv[2]) if len(sys.argv) > 2 else 1024
rows = run_benchmarks(n, c)
print(f"platform: {platform.platform()}  processor: {platform.processor() or platform.machine()}")
print(format_benchmarks(rows))
Path(__file__).with_name("results.json").write_text(json.dumps({"platform": platform.platform(), "rows": rows}, indent=1))
