"""CPU and memory profile of an electrostatic PIC run (standard-library tooling)."""

from plasma_core import PlasmaSimulation, SimulationConfig
from plasma_core.profiling import numba_kernel_report, profile_cpu, profile_memory

cfg = SimulationConfig.from_dict({
    "solver": {"type": "electrostatic_pic"}, "domain": {"length_m": 1.0}, "grid": {"cells": 256},
    "species": [{"preset": "electron", "density_m3": 1e12, "temperature_ev": 1.0},
                {"preset": "proton", "density_m3": 1e12, "mobile": False}],
    "particles": {"count": 100_000}, "time": {"dt_s": 1e-10, "duration_s": 1e-8}, "random_seed": 0,
    "diagnostics": {"interval": 10}})
sim = PlasmaSimulation(cfg)
sim.initialize()
print(profile_cpu(lambda: sim.run(n_steps=50), limit=15))
peak, top = profile_memory(lambda: sim.run(n_steps=5))
print(f"peak traced allocation during 5 steps: {peak:.1f} MB")
print("\n".join(top[:5]))
print("numba kernels:", numba_kernel_report())
