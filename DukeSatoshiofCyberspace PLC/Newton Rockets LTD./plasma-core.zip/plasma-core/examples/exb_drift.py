"""E x B drift of an electron and a proton in crossed uniform fields.

Both start at rest in E = 100 V/m x-hat, B = 1e-3 T z-hat.  The guiding
centres must drift at v_E = E x B / B^2 = (0, -1e5, 0) m/s regardless of
charge and mass; the orbits are cycloids of very different size.
"""

import math

import matplotlib.pyplot as plt
from _common import outdir, report

from plasma_core import PlasmaSimulation, SimulationConfig
from plasma_core.constants import ELECTRON_MASS, ELEMENTARY_CHARGE, PROTON_MASS
from plasma_core.validation.cases import exb_drift

out = outdir("exb_drift")
r = exb_drift()
vE = r.analytical["v_E_m_s"]
report("E x B drift (guiding-centre velocity, y component)", [
    ("electron drift v_y [m/s]", vE[1], r.numerical["electron_drift_m_s"][1]),
    ("proton drift v_y [m/s]", vE[1], r.numerical["proton_drift_m_s"][1]),
])
print(f"  x-drift: electron {r.numerical['electron_drift_m_s'][0]:.2e}, proton "
      f"{r.numerical['proton_drift_m_s'][0]:.2e} m/s (analytical 0)")
print(f"  validation verdict: {r.conclusion}")

fig, axes = plt.subplots(1, 2, figsize=(10, 4))
for ax, (preset, m) in zip(axes, (("electron", ELECTRON_MASS), ("proton", PROTON_MASS))):
    wc = ELEMENTARY_CHARGE * 1e-3 / m
    L = max(1.0, 100 * 1e5 / wc)
    cfg = SimulationConfig.from_dict({
        "name": f"exb_{preset}",
        "solver": {"type": "test_particle", "external_magnetic_field_t": [0, 0, 1e-3],
                   "external_electric_field_v_m": [100.0, 0, 0]},
        "domain": {"length_m": L}, "grid": {"cells": 8}, "species": [{"preset": preset, "density_m3": 1.0}],
        "initial_condition": {"type": "single_particle", "positions_m": [[L / 2, 0, 0]], "velocities_m_s": [[0, 0, 0]]},
        "time": {"dt_s": 0.05 / wc, "duration_s": 4 * 2 * math.pi / wc}, "random_seed": 0,
        "diagnostics": {"interval": 1, "record_trajectories": [0]}, "output": {"directory": str(out)},
    })
    sim = PlasmaSimulation(cfg)
    sim.initialize()
    sim.run(write_output=True)
    t, x, y, *_ = sim.diagnostics.trajectory(0).T
    ax.plot(x - L / 2, y)
    ax.set_xlabel("x - x0 [m]")
    ax.set_ylabel("y [m]")
    ax.set_title(f"{preset}: cycloid, 4 gyro-periods")
fig.tight_layout()
fig.savefig(out / "cycloids.png", dpi=130)
print(f"outputs in {out}")
