"""Shared helpers for the examples (output directory, plotting backend)."""

from __future__ import annotations

from pathlib import Path

import matplotlib

matplotlib.use("Agg")

ROOT = Path(__file__).resolve().parent


def outdir(name: str) -> Path:
    p = ROOT / "output" / name
    p.mkdir(parents=True, exist_ok=True)
    return p


def report(title: str, rows: list[tuple[str, float, float]]) -> None:
    """Print analytical vs numerical comparison lines: (quantity, analytical, numerical)."""
    print(f"\n{title}")
    print(f"  {'quantity':<36s} {'analytical':>14s} {'numerical':>14s} {'abs error':>11s} {'rel error':>10s}")
    for name, a, n in rows:
        print(f"  {name:<36s} {a:>14.6e} {n:>14.6e} {abs(n - a):>11.3e} {abs(n - a) / abs(a):>10.3e}")
