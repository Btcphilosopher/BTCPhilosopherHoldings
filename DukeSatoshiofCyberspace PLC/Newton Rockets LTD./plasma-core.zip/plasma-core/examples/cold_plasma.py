"""Cold electron-proton plasma: density, plasma frequency, neutrality and electrostatic response.

Both species are mobile particles.  A 1% electron density perturbation is
released from rest.  For a cold two-species plasma the linear response
oscillates at omega = sqrt(omega_pe^2 + omega_pi^2), independent of k.
"""

import math

import numpy as np
from _common import outdir, report

from plasma_core import PlasmaSimulation, SimulationConfig
from plasma_core import visualization as viz
from plasma_core.diagnostics import fit_damped_oscillation
from plasma_core.physics import plasma_frequency
from plasma_core.physics.dispersion import pic_cold_plasma_frequency
from plasma_core.constants import ELECTRON_MASS, ELEMENTARY_CHARGE, PROTON_MASS

N0 = 1.0e12
out = outdir("cold_plasma")
wpe = float(plasma_frequency(N0, ELEMENTARY_CHARGE, ELECTRON_MASS))
wpi = float(plasma_frequency(N0, ELEMENTARY_CHARGE, PROTON_MASS))
w_theory = math.sqrt(wpe**2 + wpi**2)

cfg = SimulationConfig.from_dict({
    "name": "cold_plasma",
    "solver": {"type": "electrostatic_pic", "deposition": "cic", "poisson": "fft_fd"},
    "domain": {"length_m": 1.0}, "grid": {"cells": 64},
    "species": [{"preset": "electron", "density_m3": N0}, {"preset": "proton", "density_m3": N0}],
    "particles": {"count": 6400, "position_loading": "quiet"},
    "initial_condition": {"type": "cold", "perturbation": {"mode": 1, "amplitude": 0.01, "species": ["electron"]}},
    "time": {"dt_s": 0.05 / wpe, "duration_s": 12 * 2 * math.pi / wpe},
    "random_seed": 2026,
    "diagnostics": {"interval": 2},
    "output": {"directory": str(out), "output_interval": 100},
})
sim = PlasmaSimulation(cfg, verbose=True)
sim.initialize()
st0 = sim.state
print(f"\ninitial net charge Q = {st0.total_charge_c:.3e} C/m^2 "
      f"(|Q|/Q_abs = {abs(st0.total_charge_c) / sim.diagnostics.q_abs:.2e}); "
      f"mean n_e = {st0.number_density_m3[0].mean():.6e} m^-3")
sim.run(write_output=True)

t, y = sim.diagnostics.history("mode_im_Ex_m1")
fit = fit_damped_oscillation(t, y)
_, ee = sim.diagnostics.history("energy_error")
_, qe = sim.diagnostics.history("relative_charge_error")
_, pe = sim.diagnostics.history("momentum_error")
w_disc = pic_cold_plasma_frequency(w_theory, 2 * math.pi, 1.0 / 64, 0.05 / wpe, shape_order=1, poisson="fft_fd")
report("Cold plasma oscillation (two mobile species)", [
    ("omega [rad/s]  sqrt(wpe^2+wpi^2)", w_theory, fit.omega_rad_s),
    ("omega [rad/s]  discrete ES-PIC theory", w_disc, fit.omega_rad_s),
])
print("  the continuum difference is the expected CIC/finite-difference grid correction (k dx = 0.098)")
print(f"  fit R^2 = {fit.r_squared:.8f};  max |energy error| = {np.abs(ee).max():.3e};  "
      f"max charge error = {qe.max():.2e};  max momentum error = {pe.max():.2e}")

md = sim.metadata
viz.mode_history(sim.diagnostics, name="mode_im_Ex_m1", log=False, metadata=md, path=out / "mode1_Ex.png")
viz.energy_history(sim.diagnostics, metadata=md, path=out / "energy.png")
viz.density_profile(sim.state, metadata=md, path=out / "density.png")
viz.field_profile(sim.state, components=("x",), magnitude=False, metadata=md, path=out / "Ex.png")
viz.potential_profile(sim.state, metadata=md, path=out / "potential.png")
viz.charge_error_history(sim.diagnostics, metadata=md, path=out / "charge_error.png")
viz.phase_space(sim.state, metadata=md, path=out / "phase_space_x_vx.png")
print(f"outputs in {out}")
