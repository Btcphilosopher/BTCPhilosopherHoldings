"""Warm Langmuir waves: dispersion relation omega(k) vs kinetic theory and Bohm-Gross.

Modes m = 1, 2, 3 (k lambda_D = 0.15, 0.30, 0.45) are excited by small density
perturbations, independently, with two kinetic models:

* ES-PIC (0.5% amplitude, quiet start): frequency from the E_x mode history.
  PIC damping rates are not reported: within six periods the wave damps into
  the particle-noise floor and the fitted rate is not a reliable measurement.
* Vlasov-Poisson (0.1% amplitude, noise-free): frequency and Landau damping
  rate from the envelope peaks.

The amplitudes are chosen so that the trapping (bounce) frequency
sqrt(A) omega_p stays below or comparable to the damping rates of interest
(linear regime); larger amplitudes visibly shift the measured frequency.
"""

import math

import matplotlib.pyplot as plt
import numpy as np
from _common import outdir, report

from plasma_core import PlasmaSimulation, SimulationConfig
from plasma_core import visualization as viz
from plasma_core.constants import BOLTZMANN_CONSTANT, ELECTRON_MASS, ELEMENTARY_CHARGE, VACUUM_PERMITTIVITY
from plasma_core.diagnostics import fit_damped_oscillation, peak_envelope_rate, peak_period_frequency
from plasma_core.physics.dispersion import bohm_gross_frequency, landau_damping_root

N0 = 1.0e12
out = outdir("plasma_wave")
wp = math.sqrt(N0 * ELEMENTARY_CHARGE**2 / (ELECTRON_MASS * VACUUM_PERMITTIVITY))
L = 1.0
k1 = 2 * math.pi / L
lam = 0.15 / k1  # k1 lambda_D = 0.15
T = lam**2 * N0 * ELEMENTARY_CHARGE**2 / (VACUUM_PERMITTIVITY * BOLTZMANN_CONSTANT)
vt = math.sqrt(BOLTZMANN_CONSTANT * T / ELECTRON_MASS)

rows, kl, w_num, g_num = [], [], [], []
for m in (1, 2, 3):
    cfg = SimulationConfig.from_dict({
        "name": f"langmuir_mode{m}", "solver": {"type": "electrostatic_pic", "poisson": "fft_fd"},
        "domain": {"length_m": L}, "grid": {"cells": 128},
        "species": [{"preset": "electron", "density_m3": N0, "temperature_k": T},
                    {"preset": "proton", "density_m3": N0, "mobile": False}],
        "particles": {"count": 128 * 400, "position_loading": "quiet", "velocity_loading": "quiet"},
        "initial_condition": {"type": "plasma_wave", "perturbation": {"mode": m, "amplitude": 0.005}},
        "time": {"dt_s": 0.05 / wp, "duration_s": 6 * 2 * math.pi / wp},
        "random_seed": 100 + m, "diagnostics": {"interval": 2, "field_modes": [m]},
        "output": {"directory": str(out)},
    })
    sim = PlasmaSimulation(cfg, verbose=(m == 1))
    sim.initialize()
    sim.run(write_output=True)
    t, y = sim.diagnostics.history(f"mode_im_Ex_m{m}")
    skip = t >= 2 * math.pi / wp  # skip the first period (non-modal ballistic transient of the initial condition)
    f = fit_damped_oscillation(t[skip], y[skip])
    k = m * k1
    root = landau_damping_root(k * lam) * wp
    kl.append(k * lam)
    w_num.append(f.omega_rad_s)
    g_num.append(f.gamma_s)
    rows += [(f"PIC    m={m} omega vs kinetic  klD={k * lam:.2f}", root.real, f.omega_rad_s),
             (f"PIC    m={m} omega vs Bohm-Gross", bohm_gross_frequency(wp, k, vt), f.omega_rad_s)]
    # Vlasov run of the same mode (noise-free): frequency and damping
    vcfg = cfg.with_updates(name=f"langmuir_vlasov_mode{m}", particles={"count": 0},
                            solver={"type": "vlasov", "poisson": "fft_spectral",
                                    "vlasov": {"velocity_cells": 256, "velocity_extent_vth": 6.0}},
                            grid={"cells": 64},
                            initial_condition={"type": "plasma_wave", "perturbation": {"mode": m, "amplitude": 0.001}},
                            time={"dt_s": 0.05 / wp, "duration_s": 30 / wp}, diagnostics={"interval": 1, "field_modes": [m]})
    vs = PlasmaSimulation(vcfg)
    vs.initialize()
    vs.run()
    tv, av = vs.diagnostics.history(f"mode_amp_Ex_m{m}")
    wv = peak_period_frequency(tv, av, (3 / wp, 30 / wp))
    rows.append((f"Vlasov m={m} omega vs kinetic", root.real, wv))
    if abs(root.imag) > 1e-3 * wp:  # damping resolvable within 30 / omega_p
        gv = peak_envelope_rate(tv, av, (3 / wp, 30 / wp)).growth_rate_s
        rows.append((f"Vlasov m={m} gamma [1/s] vs kinetic", root.imag, gv))
    viz.mode_history(sim.diagnostics, name=f"mode_im_Ex_m{m}", log=False, metadata=sim.metadata,
                     path=out / f"field_history_mode{m}.png")

report("Langmuir-wave dispersion: ES-PIC measurement vs theory", rows)
print("  notes: damping is compared only where |gamma| > 1e-3 omega_p (at k lambda_D = 0.15 it is ~1e-8 omega_p).\n"
      "  The Vlasov frequency comes from the spacing of |E| peaks (biased by the initial transient at the 1e-3\n"
      "  level); the PIC frequency residual includes finite-particle-number and grid effects.")

kk = np.linspace(0.05, 0.5, 100)
fig, ax = plt.subplots(figsize=(6.5, 4.5))
ax.plot(kk, [landau_damping_root(x).real for x in kk], label="kinetic theory (Landau root)")
ax.plot(kk, np.sqrt(1 + 3 * kk**2), "--", label="Bohm-Gross")
ax.plot(kl, np.array(w_num) / wp, "ko", label="ES-PIC measurement")
ax.set_xlabel(r"$k\lambda_D$")
ax.set_ylabel(r"$\omega/\omega_{pe}$")
ax.set_title(f"Langmuir dispersion, T = {T:.4e} K, n = {N0:.1e} m$^{{-3}}$")
ax.legend()
fig.text(0.01, 0.005, "plasma_core: 128 cells, 400 ppc quiet start, omega_p dt = 0.05", fontsize=6, color="0.35")
fig.tight_layout(rect=(0, 0.02, 1, 1))
fig.savefig(out / "dispersion.png", dpi=130)
print(f"outputs in {out}")
