"""End-to-end acceptance workflow (item 99 of the specification).

run -> write HDF5 -> read diagnostics -> checkpoint -> restart -> compare
continuous vs restarted trajectories -> scientific plots.
"""

import math
import sys

import numpy as np
from _common import outdir

from plasma_core import PlasmaSimulation, SimulationConfig
from plasma_core import visualization as viz
from plasma_core.constants import ELECTRON_MASS, ELEMENTARY_CHARGE, VACUUM_PERMITTIVITY
from plasma_core.io import fields_dataset_from_hdf5, read_diagnostics, read_diagnostics_parquet, read_metadata

out = outdir("acceptance")
N0 = 1e12
wp = math.sqrt(N0 * ELEMENTARY_CHARGE**2 / (ELECTRON_MASS * VACUUM_PERMITTIVITY))
base = {
    "name": "acceptance", "solver": {"type": "electrostatic_pic"},
    "domain": {"length_m": 0.5}, "grid": {"cells": 64},
    "species": [{"preset": "electron", "density_m3": N0, "temperature_ev": 2.0},
                {"preset": "proton", "density_m3": N0, "mobile": False}],
    "particles": {"count": 12800}, "initial_condition": {"type": "plasma_wave",
                                                         "perturbation": {"mode": 2, "amplitude": 0.05}},
    "time": {"dt_s": 0.05 / wp, "duration_s": 400 * 0.05 / wp}, "random_seed": 99,
    "diagnostics": {"interval": 4, "record_trajectories": [0, 1, 2]},
    "output": {"directory": str(out), "output_interval": 100},
}
ok = True

# 1. continuous run with HDF5 + Parquet output
cont = PlasmaSimulation(SimulationConfig.from_dict(base), verbose=True)
cont.initialize()
cont.run(write_output=True)
h5 = out / "acceptance.h5"
tab = read_diagnostics(h5)
md = read_metadata(h5)
ptab, _ = read_diagnostics_parquet(out / "acceptance_diagnostics.parquet")
ds = fields_dataset_from_hdf5(h5)
print(f"\n[1] HDF5 written: {h5.name}; {len(tab['time_s'])} diagnostic rows; fields dataset dims {dict(ds.sizes)}")
print(f"    metadata: solver={md['solver']}, seed={md['random_seed']}, config={md['configuration_hash'][:12]}, "
      f"git={str(md['git_commit'])[:12]}")
ok &= bool(np.array_equal(tab["total_energy_j"], ptab["total_energy_j"]))

# 2. run -> checkpoint -> restart -> continue
part = PlasmaSimulation(SimulationConfig.from_dict({**base, "name": "acceptance_part"}))
part.initialize()
part.run(until_step=200)
ck = part.checkpoint(out / "acceptance_checkpoint_00000200.h5")
rest = PlasmaSimulation.restart(ck)
rest.run()
dx = float(np.max(np.abs(cont.model.particles.positions - rest.model.particles.positions)))
dv = float(np.max(np.abs(cont.model.particles.velocities - rest.model.particles.velocities)))
traj_diff = max(float(np.max(np.abs(cont.diagnostics.trajectory(i) - rest.diagnostics.trajectory(i))))
                for i in (0, 1, 2))
ta, tr = cont.diagnostics.table(), rest.diagnostics.table()
diag_same = all(np.array_equal(ta[k], tr[k], equal_nan=True) for k in ta)
print(f"[2] restart at step 200: max |dx| = {dx:.3e} m, max |dv| = {dv:.3e} m/s, "
      f"max trajectory difference = {traj_diff:.3e}, diagnostics identical = {diag_same}")
ok &= dx == 0.0 and dv == 0.0 and traj_diff == 0.0 and diag_same

# 3. conservation summary from the stored data
print(f"[3] max |energy error| = {np.nanmax(np.abs(tab['energy_error'])):.3e}; "
      f"max charge error = {np.nanmax(tab['relative_charge_error']):.2e}; "
      f"max momentum error = {np.nanmax(tab['momentum_error']):.2e}")

# 4. plots
st = cont.state
for f in (viz.phase_space(st, metadata=cont.metadata, path=out / "phase_space.png"),
          viz.velocity_distribution(st, metadata=cont.metadata, path=out / "velocity_distribution.png"),
          viz.density_profile(st, metadata=cont.metadata, path=out / "density.png"),
          viz.field_profile(st, metadata=cont.metadata, path=out / "electric_field.png"),
          viz.field_profile(st, field="B", metadata=cont.metadata, path=out / "magnetic_field.png"),
          viz.potential_profile(st, metadata=cont.metadata, path=out / "potential.png"),
          viz.energy_history(cont.diagnostics, metadata=cont.metadata, path=out / "energy.png"),
          viz.charge_error_history(cont.diagnostics, metadata=cont.metadata, path=out / "charge_error.png"),
          viz.temperature_history(cont.diagnostics, st.species_names, metadata=cont.metadata, path=out / "temperature.png")):
    ok &= f.exists()
print(f"[4] plots written to {out}")
print("ACCEPTANCE WORKFLOW:", "PASS" if ok else "FAIL")
sys.exit(0 if ok else 1)
