"""Magnetised plasma in a uniform magnetic field.

Part A - test electrons with a spread of parallel and perpendicular velocities
(bi-Maxwellian about B): every particle's gyrofrequency must equal |q|B/m
(independent of velocity) and its gyro-radius m v_perp/(|q| B).

Part B - self-consistent ES-PIC: cold electrons in B perpendicular to k
oscillate at the upper-hybrid frequency sqrt(omega_pe^2 + omega_ce^2), and the
temperature anisotropy of a warm bi-Maxwellian is preserved by gyration.
"""

import math

import matplotlib.pyplot as plt
import numpy as np
from _common import outdir, report

from plasma_core import PlasmaSimulation, SimulationConfig
from plasma_core import visualization as viz
from plasma_core.constants import ELECTRON_MASS, ELEMENTARY_CHARGE, VACUUM_PERMITTIVITY
from plasma_core.diagnostics import fit_damped_oscillation
from plasma_core.initial_conditions.magnetised import bi_maxwellian_velocities
from plasma_core.particles.particle_initializer import make_generator
from plasma_core.physics.dispersion import boris_gyrofrequency, upper_hybrid_frequency

out = outdir("magnetised_plasma")
B = 5.0e-4
wc = ELEMENTARY_CHARGE * B / ELECTRON_MASS
dt = 0.05 / wc

# ---------------- Part A: test particles -------------------------------
n = 16
v = bi_maxwellian_velocities(n, 2e4, 8e4, ELECTRON_MASS, (0, 0, B), (0, 0, 0), make_generator(11))
pos = [[0.5, 0.0, 0.0]] * n
cfg = SimulationConfig.from_dict({
    "name": "magnetised_test_particles",
    "solver": {"type": "test_particle", "external_magnetic_field_t": [0, 0, B]},
    "domain": {"length_m": 1.0}, "grid": {"cells": 8}, "species": [{"preset": "electron", "density_m3": 1.0}],
    "initial_condition": {"type": "single_particle", "positions_m": pos, "velocities_m_s": v.tolist()},
    "time": {"dt_s": dt, "duration_s": 10 * 2 * math.pi / wc}, "random_seed": 11,
    "diagnostics": {"interval": 1, "record_trajectories": list(range(n))},
})
sim = PlasmaSimulation(cfg, verbose=True)
sim.initialize()
sim.run()
w_b = boris_gyrofrequency(wc, dt)
rows = []
fig, ax = plt.subplots(figsize=(5.5, 5))
for pid in range(n):
    t, x, y, z, vx, vy, vz = sim.diagnostics.trajectory(pid).T
    w = np.polyfit(t, np.unwrap(np.arctan2(vy, vx)), 1)[0]
    vperp = float(np.hypot(*v[pid, :2]))
    r_theory = ELECTRON_MASS * vperp / (ELEMENTARY_CHARGE * B) * math.sqrt(1 + (wc * dt / 2) ** 2)
    r_meas = 0.5 * (x.max() - x.min() + y.max() - y.min()) / 2
    if pid < 4:
        rows += [(f"particle {pid}: omega_c [rad/s] (Boris)", w_b, w),
                 (f"particle {pid}: r [m] (Boris)", r_theory, r_meas),
                 (f"particle {pid}: v_par [m/s]", v[pid, 2], float(np.polyfit(t, z, 1)[0]))]
    ax.plot(x - 0.5, y, lw=0.6)
ax.set_xlabel("x - x0 [m]")
ax.set_ylabel("y [m]")
ax.set_aspect("equal")
ax.set_title(f"Electron gyro-orbits, B = {B:.1e} T (16 particles, 10 periods)")
fig.tight_layout()
fig.savefig(out / "gyro_orbits.png", dpi=130)
report(f"Part A: gyro-motion of test electrons (omega_c = {wc:.6e} rad/s, Boris = {w_b:.6e})", rows)
print("  (radius measured from the orbit extent; continuum r_L = m v_perp/(|q|B) differs from the Boris radius "
      f"by a factor {math.sqrt(1 + (wc * dt / 2) ** 2):.6f})")

# ---------------- Part B: self-consistent magnetised plasma -------------
N0 = 1e12
wp = math.sqrt(N0 * ELEMENTARY_CHARGE**2 / (ELECTRON_MASS * VACUUM_PERMITTIVITY))
B2 = 0.8 * wp * ELECTRON_MASS / ELEMENTARY_CHARGE
cfg = SimulationConfig.from_dict({
    "name": "upper_hybrid", "solver": {"type": "electrostatic_pic", "external_magnetic_field_t": [0, 0, B2]},
    "domain": {"length_m": 1.0}, "grid": {"cells": 64},
    "species": [{"preset": "electron", "density_m3": N0}, {"preset": "proton", "density_m3": N0, "mobile": False}],
    "particles": {"count": 6400, "position_loading": "quiet"},
    "initial_condition": {"type": "cold", "perturbation": {"mode": 1, "amplitude": 0.01}},
    "time": {"dt_s": 0.02 / wp, "duration_s": 8 * 2 * math.pi / wp}, "random_seed": 5,
    "diagnostics": {"interval": 2}, "output": {"directory": str(out)},
})
sim = PlasmaSimulation(cfg, verbose=True)
sim.initialize()
sim.run(write_output=True)
t, y = sim.diagnostics.history("mode_im_Ex_m1")
f = fit_damped_oscillation(t, y)
report("Part B: upper-hybrid oscillation (k perpendicular to B)",
       [("omega_UH [rad/s]", upper_hybrid_frequency(wp, 0.8 * wp), f.omega_rad_s)])
viz.mode_history(sim.diagnostics, log=False, name="mode_im_Ex_m1", metadata=sim.metadata, path=out / "upper_hybrid.png")

T_par, T_perp = 2e4, 8e4
cfg_w = cfg.with_updates(name="anisotropic", species=[
    {"preset": "electron", "density_m3": N0, "temperature_k": T_par},
    {"preset": "proton", "density_m3": N0, "mobile": False}],
    initial_condition={"type": "magnetised", "temperature_parallel_k": {"electron": T_par},
                       "temperature_perpendicular_k": {"electron": T_perp}},
    particles={"count": 64 * 200, "position_loading": "random"})
sim = PlasmaSimulation(cfg_w)
sim.initialize()
sim.run()
_, tpar = sim.diagnostics.history("temperature_parallel_k__electron")
_, tperp = sim.diagnostics.history("temperature_perpendicular_k__electron")
report("Part B: bi-Maxwellian anisotropy preserved over 8 plasma periods",
       [("T_par final [K]", T_par, tpar[-1]), ("T_perp final [K]", T_perp, tperp[-1])])
print("  (deviations are statistical: 12,800 random-loaded particles; time-centred velocities reduce T_perp by "
      "cos^2(omega_c dt/2) ~ 1 - 1e-4)")
viz.temperature_history(sim.diagnostics, ["electron"], metadata=sim.metadata, path=out / "temperature.png")
print(f"outputs in {out}")
