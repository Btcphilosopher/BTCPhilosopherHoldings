"""Single-electron gyro-motion in a uniform magnetic field (helical orbit).

Measures gyrofrequency, gyro-radius, parallel and perpendicular velocity and
compares with omega_c = |q|B/m, r_L = m v_perp/(|q|B), and with the exact
discrete Boris orbit.  Writes the trajectory to HDF5 and plots it.
"""

import math

import matplotlib.pyplot as plt
from _common import outdir, report

from plasma_core.validation.cases import gyro_motion

out = outdir("gyro_motion")
r = gyro_motion()
a, n = r.analytical, r.numerical
report("Gyro-motion: electron, B = 1e-3 T, omega_c dt = 0.05, 20 periods", [
    ("gyrofrequency [rad/s] vs continuum", a["omega_c_rad_s"], n["omega_rad_s"]),
    ("gyrofrequency [rad/s] vs Boris discrete", a["omega_boris_rad_s"], n["omega_rad_s"]),
    ("gyro-radius [m] vs r_L", a["larmor_radius_m"], n["radius_m"]),
    ("gyro-radius [m] vs Boris discrete", a["boris_radius_m"], n["radius_m"]),
    ("v_perp [m/s]", a["v_perp_m_s"], n["v_perp_m_s"]),
    ("v_par [m/s]", a["v_par_m_s"], n["v_par_m_s"]),
])
print(f"  rotation sense: {n['rotation_sense']} about B (expected right-handed for q < 0); "
      f"relative kinetic-energy variation {n['kinetic_energy_rel_variation']:.2e}")
print(f"  validation verdict: {r.conclusion}")

# re-run for the trajectory plot
from plasma_core import PlasmaSimulation, SimulationConfig  # noqa: E402
from plasma_core.constants import ELECTRON_MASS, ELEMENTARY_CHARGE  # noqa: E402

B = 1e-3
wc = ELEMENTARY_CHARGE * B / ELECTRON_MASS
cfg = SimulationConfig.from_dict({
    "name": "gyro_motion", "solver": {"type": "test_particle", "external_magnetic_field_t": [0, 0, B]},
    "domain": {"length_m": 1.0}, "grid": {"cells": 8}, "species": [{"preset": "electron", "density_m3": 1.0}],
    "initial_condition": {"type": "single_particle", "positions_m": [[0.5, 0, 0]], "velocities_m_s": [[1e5, 0, 2e4]]},
    "time": {"dt_s": 0.05 / wc, "duration_s": 3 * 2 * math.pi / wc}, "random_seed": 0,
    "diagnostics": {"interval": 1, "record_trajectories": [0]}, "output": {"directory": str(out)},
})
sim = PlasmaSimulation(cfg)
sim.initialize()
sim.run(write_output=True)
t, x, y, z, *_ = sim.diagnostics.trajectory(0).T
fig = plt.figure(figsize=(6, 5))
ax = fig.add_subplot(projection="3d")
ax.plot(x - 0.5, y, z, lw=1)
ax.set_xlabel("x - x0 [m]")
ax.set_ylabel("y [m]")
ax.set_zlabel("z [m]")
ax.set_title("Electron helix in B = 1e-3 T z-hat (3 gyro-periods)")
fig.savefig(out / "helix.png", dpi=130)
print(f"outputs in {out}")
