"""Deterministic two-stream instability.

Configuration (fully specified, seed 7): two electron beams +-v0 with
k v0 = sqrt(3/8) omega_p at mode 1 (the cold-beam fastest-growing mode),
v_th = 0.05 v0, 128 cells, 200 particles/cell/beam, omega_p dt = 0.04, seed
perturbation 1e-3.

Documented expected result (docs/VALIDATION.md, two_stream_instability):
measured growth rate gamma ~= 0.35 omega_p, within 5% of the kinetic linear
theory (gamma_kinetic = 0.3525 omega_p; cold theory 0.3536 omega_p), followed by
nonlinear saturation with phase-space vortices.
"""

import math

import numpy as np
from _common import outdir, report

from plasma_core import PlasmaSimulation, SimulationConfig
from plasma_core import visualization as viz
from plasma_core.constants import BOLTZMANN_CONSTANT, ELECTRON_MASS, ELEMENTARY_CHARGE, VACUUM_PERMITTIVITY
from plasma_core.diagnostics import fit_growth_rate
from plasma_core.physics.dispersion import KineticSpecies, cold_two_stream_growth_rate, solve_electrostatic_dispersion

N0 = 1.0e12
out = outdir("two_stream")
wp = math.sqrt(N0 * ELEMENTARY_CHARGE**2 / (ELECTRON_MASS * VACUUM_PERMITTIVITY))
L = 1.0
k = 2 * math.pi / L
v0 = math.sqrt(3 / 8) * wp / k
vt = 0.05 * v0
T = ELECTRON_MASS * vt**2 / BOLTZMANN_CONSTANT
cfg = SimulationConfig.from_dict({
    "name": "two_stream",
    "solver": {"type": "electrostatic_pic", "poisson": "fft_fd"},
    "domain": {"length_m": L}, "grid": {"cells": 128},
    "species": [{"name": "beam_plus", "preset": "electron", "density_m3": N0 / 2, "temperature_k": T,
                 "bulk_velocity_m_s": [v0, 0, 0]},
                {"name": "beam_minus", "preset": "electron", "density_m3": N0 / 2, "temperature_k": T,
                 "bulk_velocity_m_s": [-v0, 0, 0]},
                {"name": "ions", "preset": "proton", "density_m3": N0, "mobile": False}],
    "particles": {"count": 128 * 200, "position_loading": "quiet"},
    "initial_condition": {"type": "two_stream", "perturbation": {"mode": 1, "amplitude": 1e-3}},
    "time": {"dt_s": 0.04 / wp, "duration_s": 40 / wp},
    "random_seed": 7,
    "diagnostics": {"interval": 2, "field_modes": [1, 2, 3], "velocity_distribution": 250},
    "output": {"directory": str(out), "output_interval": 250},
})
cfg.to_file(out / "two_stream_config.yaml")
sim = PlasmaSimulation(cfg, verbose=True)
sim.initialize()
snap_steps = (0, 400, 600, 1000)
snaps = {}
for s in snap_steps:
    if s > sim.step_index:
        sim.run(until_step=s)
    snaps[s] = sim.state
    viz.phase_space(sim.state, metadata=sim.metadata, path=out / f"phase_space_step{s:05d}.png")
sim.run(write_output=True)

t, a = sim.diagnostics.history("mode_amp_Ex_m1")
fit = fit_growth_rate(t, a, min_r2=0.995)
g_cold = cold_two_stream_growth_rate(wp, k, v0)
root = solve_electrostatic_dispersion(k, [KineticSpecies(wp / math.sqrt(2), v0, vt),
                                         KineticSpecies(wp / math.sqrt(2), -v0, vt)], 1j * g_cold)
report("Two-stream growth rate (numerical measurement vs linear theory)", [
    ("gamma [1/s] vs kinetic theory", root.imag, fit.growth_rate_s),
    ("gamma [1/s] vs cold-beam theory", g_cold, fit.growth_rate_s),
])
print(f"  fit interval [{fit.fit_interval_s[0] * wp:.2f}, {fit.fit_interval_s[1] * wp:.2f}] / omega_p, "
      f"R^2 = {fit.r_squared:.5f}, std err = {fit.growth_rate_std_err:.3e} 1/s ({fit.method})")
print(f"  saturation |E_1| = {a.max():.3e} V/m at t omega_p = {t[np.argmax(a)] * wp:.2f}")
_, ee = sim.diagnostics.history("energy_error")
print(f"  max |energy error| over the run = {np.abs(ee).max():.3e}")
viz.mode_history(sim.diagnostics, name="mode_amp_Ex_m1", fit=fit, metadata=sim.metadata, path=out / "growth.png")
viz.energy_history(sim.diagnostics, metadata=sim.metadata, path=out / "energy.png")
viz.velocity_distribution(sim.state, metadata=sim.metadata, path=out / "velocity_distribution_final.png")
print(f"outputs in {out}")
