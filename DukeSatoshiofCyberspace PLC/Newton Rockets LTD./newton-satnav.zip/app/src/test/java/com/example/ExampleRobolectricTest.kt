package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.newton.domain.model.GeoPoint
import com.example.newton.domain.model.NavigationPosition
import com.example.newton.domain.model.Route
import com.example.newton.domain.model.RouteType
import com.example.newton.location.DeadReckoningEngine
import com.example.newton.routing.OffRouteDetector
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

    @Test
    fun `read app string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("Newton SatNav", appName)
    }

    @Test
    fun `test dead reckoning position estimation`() {
        val startPos = NavigationPosition(
            latitude = 53.3811,
            longitude = -1.4701,
            altitudeMeters = 82.0,
            accuracyMeters = 3.0,
            speedMetersPerSecond = 20.0,
            bearingDegrees = 0.0 // Head North
        )

        // Drive 10 seconds at 20 m/s north (200m)
        val estimatedPos = DeadReckoningEngine.estimatePosition(
            lastPosition = startPos,
            speedMetersPerSec = 20.0,
            bearingDeg = 0.0,
            elapsedSeconds = 10.0
        )

        assertTrue(estimatedPos.isEstimated)
        assertTrue(estimatedPos.latitude > startPos.latitude)
        assertEquals(startPos.longitude, estimatedPos.longitude, 0.0001)
    }

    @Test
    fun `test off route detection`() {
        val routeGeom = listOf(
            GeoPoint(53.3811, -1.4701),
            GeoPoint(53.3820, -1.4701),
            GeoPoint(53.3830, -1.4701)
        )
        val route = Route(
            id = "test_route",
            name = "Test Route",
            distanceMeters = 500.0,
            durationSeconds = 30,
            geometry = routeGeom,
            instructions = emptyList(),
            routeType = RouteType.FASTEST
        )

        // Point strictly on route
        val onRoutePos = NavigationPosition(
            latitude = 53.3815,
            longitude = -1.4701
        )
        assertFalse(OffRouteDetector.isOffRoute(onRoutePos, route))

        // Point far off route (200m away to the East)
        val offRoutePos = NavigationPosition(
            latitude = 53.3815,
            longitude = -1.4650
        )
        assertTrue(OffRouteDetector.isOffRoute(offRoutePos, route))
    }
}
