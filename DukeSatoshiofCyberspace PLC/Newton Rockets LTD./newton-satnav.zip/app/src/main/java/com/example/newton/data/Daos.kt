package com.example.newton.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.newton.domain.model.JourneyRecord
import com.example.newton.domain.model.OfflineRegion
import com.example.newton.domain.model.SavedPlace
import kotlinx.coroutines.flow.Flow

@Dao
interface SavedPlaceDao {
    @Query("SELECT * FROM saved_places ORDER BY dateAdded DESC")
    fun getAllSavedPlaces(): Flow<List<SavedPlace>>

    @Query("SELECT * FROM saved_places WHERE placeType = :type LIMIT 1")
    suspend fun getPlaceByType(type: String): SavedPlace?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSavedPlace(place: SavedPlace)

    @Delete
    suspend fun deleteSavedPlace(place: SavedPlace)
}

@Dao
interface JourneyDao {
    @Query("SELECT * FROM journey_history ORDER BY timestamp DESC")
    fun getAllJourneys(): Flow<List<JourneyRecord>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertJourney(journey: JourneyRecord)

    @Query("DELETE FROM journey_history")
    suspend fun clearHistory()
}

@Dao
interface OfflineRegionDao {
    @Query("SELECT * FROM offline_regions")
    fun getAllOfflineRegions(): Flow<List<OfflineRegion>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOfflineRegion(region: OfflineRegion)

    @Query("UPDATE offline_regions SET isDownloaded = :downloaded, downloadTimestamp = :timestamp WHERE regionId = :regionId")
    suspend fun updateDownloadState(regionId: String, downloaded: Boolean, timestamp: Long)
}
