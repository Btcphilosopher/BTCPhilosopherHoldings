package com.example.newton.maps

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableDoubleStateOf
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.platform.testTag
import com.example.newton.domain.model.GeoPoint
import com.example.newton.domain.model.NavigationPosition
import com.example.newton.domain.model.Route
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin

import androidx.compose.ui.input.pointer.pointerInput

enum class CameraMode {
    NORTH_UP,
    HEADING_UP,
    PERSPECTIVE_3D
}

@Composable
fun VectorMapCanvas(
    modifier: Modifier = Modifier,
    currentPosition: NavigationPosition,
    activeRoute: Route? = null,
    cameraMode: CameraMode = CameraMode.HEADING_UP,
    isDarkTheme: Boolean = true,
    onMapClick: ((GeoPoint) -> Unit)? = null
) {
    // Map view state
    var zoomLevel by remember { mutableFloatStateOf(15.5f) } // 1.0 to 20.0
    var panOffsetX by remember { mutableFloatStateOf(0f) }
    var panOffsetY by remember { mutableFloatStateOf(0f) }
    var userRotation by remember { mutableFloatStateOf(0f) }

    // Color palette definitions according to Newton Design Guidelines
    val bgColor = if (isDarkTheme) Color(0xFF0A121E) else Color(0xFFF5F6F8)
    val waterColor = if (isDarkTheme) Color(0xFF132B45) else Color(0xFFD0E4F7)
    val parkColor = if (isDarkTheme) Color(0xFF142E25) else Color(0xFFE2F0D9)
    val buildingColor = if (isDarkTheme) Color(0xFF1A2636) else Color(0xFFE5E9EE)
    val motorwayColor = Color(0xFF1E88E5) // Newton Blue
    val primaryRoadColor = if (isDarkTheme) Color(0xFF4A6572) else Color(0xFF90A4AE)
    val localRoadColor = if (isDarkTheme) Color(0xFF263238) else Color(0xFFCFD8DC)
    val routeLineColor = Color(0xFF00B0FF)
    val routeBorderColor = Color(0xFF004080)

    val currentBearing = currentPosition.bearingDegrees?.toFloat() ?: 0f

    Box(
        modifier = modifier
            .fillMaxSize()
            .testTag("vector_map_canvas")
            .pointerInput(Unit) {
                detectTransformGestures { _, pan, zoom, rotation ->
                    zoomLevel = (zoomLevel * zoom).coerceIn(10f, 19f)
                    userRotation += rotation
                    panOffsetX += pan.x
                    panOffsetY += pan.y
                }
            }
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val canvasWidth = size.width
            val canvasHeight = size.height
            val center = Offset(canvasWidth / 2f + panOffsetX, canvasHeight / 2f + panOffsetY)

            // Calculate map scale based on zoom level
            val metersPerPixel = (156543.03392 * cos(Math.toRadians(currentPosition.latitude)) / Math.pow(2.0, zoomLevel.toDouble())).toFloat()
            val scaleFactor = 1f / metersPerPixel

            // Apply base canvas background
            drawRect(color = bgColor)

            val rotationAngle = when (cameraMode) {
                CameraMode.NORTH_UP -> userRotation
                CameraMode.HEADING_UP, CameraMode.PERSPECTIVE_3D -> -currentBearing + userRotation
            }

            withTransform({
                rotate(rotationAngle, center)
                if (cameraMode == CameraMode.PERSPECTIVE_3D) {
                    scale(scaleX = 1.0f, scaleY = 0.72f, pivot = center)
                }
            }) {
                // 1. Draw Terrain / Water / Parks vector polygons
                drawWaterAndParks(center, currentPosition, scaleFactor, waterColor, parkColor, buildingColor)

                // 2. Draw Vector Road Network Hierarchy
                drawRoadNetwork(center, currentPosition, scaleFactor, motorwayColor, primaryRoadColor, localRoadColor)

                // 3. Draw Active Planned Route Polyline
                activeRoute?.let { route ->
                    drawActiveRoute(center, currentPosition, route, scaleFactor, routeLineColor, routeBorderColor)
                }

                // 4. Draw Current Position Marker, Accuracy Aura, and Heading Cone
                drawPositionMarker(center, currentPosition, cameraMode, currentBearing, isDarkTheme)
            }
        }
    }
}

private fun DrawScope.drawWaterAndParks(
    center: Offset,
    pos: NavigationPosition,
    scale: Float,
    waterColor: Color,
    parkColor: Color,
    buildingColor: Color
) {
    // Synthetic water body (river / harbour vector)
    val riverPath = Path().apply {
        val startX = center.x - 600f
        val startY = center.y - 400f
        moveTo(startX, startY)
        cubicTo(
            startX + 300f, startY + 200f,
            startX + 200f, startY + 600f,
            startX + 800f, startY + 900f
        )
    }
    drawPath(
        path = riverPath,
        color = waterColor,
        style = Stroke(width = 90f * (scale / 5f).coerceIn(0.5f, 3.0f), cap = StrokeCap.Round)
    )

    // Synthetic park polygon
    val parkPath = Path().apply {
        moveTo(center.x + 180f, center.y - 300f)
        lineTo(center.x + 450f, center.y - 250f)
        lineTo(center.x + 400f, center.y - 50f)
        lineTo(center.x + 150f, center.y - 100f)
        close()
    }
    drawPath(path = parkPath, color = parkColor)

    // Synthetic buildings low-contrast vector blocks
    val building1 = Path().apply {
        addRect(androidx.compose.ui.geometry.Rect(center.x - 300f, center.y - 200f, center.x - 200f, center.y - 120f))
    }
    val building2 = Path().apply {
        addRect(androidx.compose.ui.geometry.Rect(center.x - 180f, center.y - 200f, center.x - 80f, center.y - 120f))
    }
    drawPath(path = building1, color = buildingColor)
    drawPath(path = building2, color = buildingColor)
}

private fun DrawScope.drawRoadNetwork(
    center: Offset,
    pos: NavigationPosition,
    scale: Float,
    motorwayColor: Color,
    primaryRoadColor: Color,
    localRoadColor: Color
) {
    val roadWidthScale = (scale / 4f).coerceIn(0.6f, 2.5f)

    // Local streets fine grid
    for (i in -3..3) {
        val y = center.y + i * 180f
        drawLine(
            color = localRoadColor,
            start = Offset(center.x - 800f, y),
            end = Offset(center.x + 800f, y),
            strokeWidth = 10f * roadWidthScale
        )
    }

    // Primary roads
    val primaryPath = Path().apply {
        moveTo(center.x - 700f, center.y + 400f)
        lineTo(center.x + 100f, center.y - 200f)
        lineTo(center.x + 700f, center.y - 400f)
    }
    drawPath(
        path = primaryPath,
        color = primaryRoadColor,
        style = Stroke(width = 22f * roadWidthScale, cap = StrokeCap.Round)
    )

    // Motorway major corridor
    val motorwayPath = Path().apply {
        moveTo(center.x - 800f, center.y - 500f)
        cubicTo(
            center.x - 200f, center.y - 300f,
            center.x + 300f, center.y + 100f,
            center.x + 800f, center.y + 600f
        )
    }
    drawPath(
        path = motorwayPath,
        color = motorwayColor,
        style = Stroke(width = 34f * roadWidthScale, cap = StrokeCap.Round)
    )
}

private fun DrawScope.drawActiveRoute(
    center: Offset,
    currentPos: NavigationPosition,
    route: Route,
    scale: Float,
    lineColor: Color,
    borderColor: Color
) {
    if (route.geometry.isEmpty()) return

    val routePath = Path()
    val firstPt = route.geometry.first()
    val startOffset = geoToCanvasOffset(firstPt, currentPos, center, scale)
    routePath.moveTo(startOffset.x, startOffset.y)

    for (i in 1 until route.geometry.size) {
        val pt = route.geometry[i]
        val off = geoToCanvasOffset(pt, currentPos, center, scale)
        routePath.lineTo(off.x, off.y)
    }

    val width = 28f * (scale / 4f).coerceIn(0.8f, 2.5f)

    // Outer border stroke
    drawPath(
        path = routePath,
        color = borderColor,
        style = Stroke(width = width + 10f, cap = StrokeCap.Round, join = StrokeJoin.Round)
    )
    // Inner active route stroke
    drawPath(
        path = routePath,
        color = lineColor,
        style = Stroke(width = width, cap = StrokeCap.Round, join = StrokeJoin.Round)
    )
}

private fun DrawScope.drawPositionMarker(
    center: Offset,
    pos: NavigationPosition,
    cameraMode: CameraMode,
    bearing: Float,
    isDarkTheme: Boolean
) {
    // 1. Accuracy Aura Circle
    val auraRadius = (pos.accuracyMeters * 3f).toFloat().coerceIn(18f, 120f)
    drawCircle(
        color = Color(0x331E88E5),
        radius = auraRadius,
        center = center
    )
    drawCircle(
        color = Color(0x661E88E5),
        radius = auraRadius,
        center = center,
        style = Stroke(width = 2f)
    )

    // 2. Heading Cone / Beam
    val conePath = Path().apply {
        moveTo(center.x, center.y)
        lineTo(center.x - 35f, center.y - 120f)
        lineTo(center.x + 35f, center.y - 120f)
        close()
    }
    val coneAngle = if (cameraMode == CameraMode.NORTH_UP) bearing else 0f
    rotate(coneAngle, pivot = center) {
        drawPath(
            path = conePath,
            color = Color(0x4400B0FF)
        )

        // 3. Precision Vehicle Marker (Aerospace Triangle Pointer)
        val markerPath = Path().apply {
            moveTo(center.x, center.y - 28f)
            lineTo(center.x + 20f, center.y + 22f)
            lineTo(center.x, center.y + 12f)
            lineTo(center.x - 20f, center.y + 22f)
            close()
        }

        // Drop shadow / glow ring
        drawCircle(
            color = if (pos.isEstimated) Color(0xFFFFB300) else Color(0xFF1E88E5),
            radius = 22f,
            center = center,
            style = Stroke(width = 3f)
        )

        // Core marker
        drawPath(
            path = markerPath,
            color = if (pos.isEstimated) Color(0xFFFFB300) else Color(0xFF00E5FF)
        )
        drawPath(
            path = markerPath,
            color = Color.White,
            style = Stroke(width = 3f)
        )
    }
}

private fun geoToCanvasOffset(
    pt: GeoPoint,
    centerPos: NavigationPosition,
    centerOffset: Offset,
    scale: Float
): Offset {
    val latDiff = pt.latitude - centerPos.latitude
    val lonDiff = pt.longitude - centerPos.longitude

    // 1 degree lat = ~111,139m
    val dyMeters = latDiff * 111139.0
    val dxMeters = lonDiff * (111139.0 * cos(Math.toRadians(centerPos.latitude)))

    val px = centerOffset.x + (dxMeters * scale).toFloat()
    val py = centerOffset.y - (dyMeters * scale).toFloat() // Y canvas is inverted

    return Offset(px, py)
}
