package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val NewtonDeepNavy = Color(0xFF0A121E)
val NewtonGraphite = Color(0xFF15202B)
val NewtonCardBg = Color(0xFF1B2735)
val NewtonBlue = Color(0xFF1E88E5)
val NewtonElectricBlue = Color(0xFF00B0FF)
val NewtonWarmWhite = Color(0xFFF5F6F8)
val NewtonPaleStone = Color(0xFFE2E6EA)
val NewtonAmber = Color(0xFFFFB300)
val NewtonEmerald = Color(0xFF26A69A)
val NewtonMuted = Color(0xFF6C7A89)
