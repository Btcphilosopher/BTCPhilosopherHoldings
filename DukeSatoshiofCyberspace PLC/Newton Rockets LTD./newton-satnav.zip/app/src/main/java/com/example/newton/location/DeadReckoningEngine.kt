package com.example.newton.location

import com.example.newton.domain.model.NavigationPosition
import kotlin.math.cos
import kotlin.math.sin

object DeadReckoningEngine {

    private const val METERS_PER_DEGREE_LAT = 111139.0

    /**
     * Estimates new position using inertial speed, bearing and elapsed time when GNSS is lost or degraded.
     */
    fun estimatePosition(
        lastPosition: NavigationPosition,
        speedMetersPerSec: Double,
        bearingDeg: Double,
        elapsedSeconds: Double
    ): NavigationPosition {
        val distanceMeters = speedMetersPerSec * elapsedSeconds
        val bearingRad = Math.toRadians(bearingDeg)

        val deltaLat = (distanceMeters * cos(bearingRad)) / METERS_PER_DEGREE_LAT
        val metersPerDegLon = METERS_PER_DEGREE_LAT * cos(Math.toRadians(lastPosition.latitude))
        val deltaLon = if (metersPerDegLon != 0.0) (distanceMeters * sin(bearingRad)) / metersPerDegLon else 0.0

        val estimatedLat = lastPosition.latitude + deltaLat
        val estimatedLon = lastPosition.longitude + deltaLon

        return NavigationPosition(
            latitude = estimatedLat,
            longitude = estimatedLon,
            altitudeMeters = lastPosition.altitudeMeters,
            accuracyMeters = (lastPosition.accuracyMeters + elapsedSeconds * 1.5).coerceAtMost(50.0),
            speedMetersPerSecond = speedMetersPerSec,
            bearingDegrees = bearingDeg,
            timestamp = System.currentTimeMillis(),
            isEstimated = true
        )
    }

    /**
     * Reconciles estimated position back to exact GNSS fix smoothly.
     */
    fun reconcilePosition(
        estimatedPosition: NavigationPosition,
        gnssPosition: NavigationPosition,
        alpha: Double = 0.3
    ): NavigationPosition {
        val lat = estimatedPosition.latitude * (1 - alpha) + gnssPosition.latitude * alpha
        val lon = estimatedPosition.longitude * (1 - alpha) + gnssPosition.longitude * alpha

        return NavigationPosition(
            latitude = lat,
            longitude = lon,
            altitudeMeters = gnssPosition.altitudeMeters,
            accuracyMeters = gnssPosition.accuracyMeters,
            speedMetersPerSecond = gnssPosition.speedMetersPerSecond,
            bearingDegrees = gnssPosition.bearingDegrees,
            timestamp = System.currentTimeMillis(),
            isEstimated = false
        )
    }
}
