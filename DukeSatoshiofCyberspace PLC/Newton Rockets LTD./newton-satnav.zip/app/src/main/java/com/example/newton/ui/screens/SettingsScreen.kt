package com.example.newton.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.newton.domain.model.DistanceUnit

@Composable
fun SettingsScreen(
    distanceUnit: DistanceUnit,
    onDistanceUnitChange: (DistanceUnit) -> Unit,
    isVoiceEnabled: Boolean,
    onVoiceToggle: (Boolean) -> Unit,
    simSpeedFactor: Double,
    onSimSpeedChange: (Double) -> Unit,
    isSignalLossSimulated: Boolean,
    onToggleSignalLoss: () -> Unit,
    onTriggerOffRoute: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .testTag("settings_screen")
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(20.dp)
                .verticalScroll(rememberScrollState())
        ) {
            Spacer(modifier = Modifier.height(28.dp))

            Text(
                text = "NAVIGATION SETTINGS",
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 2.sp,
                    fontFamily = FontFamily.Monospace
                ),
                color = MaterialTheme.colorScheme.onBackground
            )
            Text(
                text = "NEWTON ROCKETS LTD. — INSTRUMENT CONFIG",
                style = MaterialTheme.typography.labelSmall.copy(
                    letterSpacing = 1.sp,
                    fontFamily = FontFamily.Monospace
                ),
                color = Color(0xFF00B0FF)
            )

            Spacer(modifier = Modifier.height(20.dp))

            // 1. Units Section
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1B2735)),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "MEASUREMENT UNITS",
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold
                        ),
                        color = Color.Gray
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Distance & Speed",
                            style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Bold),
                            color = Color.White
                        )

                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(
                                onClick = { onDistanceUnitChange(DistanceUnit.MILES_FEET) },
                                shape = RoundedCornerShape(8.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (distanceUnit == DistanceUnit.MILES_FEET) Color(0xFF00B0FF) else Color(0xFF15202B)
                                ),
                                modifier = Modifier.testTag("unit_miles_button")
                            ) {
                                Text("MI / MPH", color = if (distanceUnit == DistanceUnit.MILES_FEET) Color.Black else Color.White)
                            }

                            Button(
                                onClick = { onDistanceUnitChange(DistanceUnit.KILOMETERS_METERS) },
                                shape = RoundedCornerShape(8.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (distanceUnit == DistanceUnit.KILOMETERS_METERS) Color(0xFF00B0FF) else Color(0xFF15202B)
                                ),
                                modifier = Modifier.testTag("unit_km_button")
                            ) {
                                Text("KM / KM/H", color = if (distanceUnit == DistanceUnit.KILOMETERS_METERS) Color.Black else Color.White)
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // 2. Voice Guidance Section
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1B2735)),
                shape = RoundedCornerShape(16.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "AEROSPACE VOICE GUIDANCE",
                            style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Bold),
                            color = Color.White
                        )
                        Text(
                            text = "Text-to-speech spoken turn cues",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color.Gray
                        )
                    }

                    Switch(
                        checked = isVoiceEnabled,
                        onCheckedChange = onVoiceToggle,
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color.Black,
                            checkedTrackColor = Color(0xFF00B0FF)
                        ),
                        modifier = Modifier.testTag("voice_switch")
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // 3. Development Simulation Controls
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1B2735)),
                shape = RoundedCornerShape(16.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFFFB300).copy(alpha = 0.5f))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "DEV SIMULATION CONTROL PANEL",
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold
                        ),
                        color = Color(0xFFFFB300)
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = "Simulation Speed Factor: ${String.format("%.1f", simSpeedFactor)}x",
                        style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold),
                        color = Color.White
                    )

                    Slider(
                        value = simSpeedFactor.toFloat(),
                        onValueChange = { onSimSpeedChange(it.toDouble()) },
                        valueRange = 0.5f..5.0f,
                        colors = SliderDefaults.colors(
                            thumbColor = Color(0xFFFFB300),
                            activeTrackColor = Color(0xFFFFB300)
                        ),
                        modifier = Modifier.testTag("sim_speed_slider")
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = onToggleSignalLoss,
                            modifier = Modifier
                                .weight(1f)
                                .testTag("sim_tunnel_loss_button"),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (isSignalLossSimulated) Color(0xFFFFB300) else Color(0xFF15202B)
                            )
                        ) {
                            Text(
                                text = if (isSignalLossSimulated) "RECOVER GNSS" else "SIM TUNNEL LOSS",
                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                color = if (isSignalLossSimulated) Color.Black else Color.White
                            )
                        }

                        Button(
                            onClick = onTriggerOffRoute,
                            modifier = Modifier
                                .weight(1f)
                                .testTag("sim_off_route_button"),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF15202B))
                        ) {
                            Text(
                                text = "DEV OFF-ROUTE",
                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                color = Color.White
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // 4. Privacy & System Info
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF15202B)),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "PRIVACY & LOCAL STORAGE",
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold
                        ),
                        color = Color.Gray
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "All GNSS positioning, journey history, and saved places are stored 100% locally on your device. Newton SatNav does not transmit location telemetry to external servers.",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color.Gray
                    )
                }
            }
        }
    }
}
