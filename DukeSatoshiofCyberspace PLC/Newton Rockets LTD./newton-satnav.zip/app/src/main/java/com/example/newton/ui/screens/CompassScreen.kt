package com.example.newton.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.newton.domain.model.NavigationPosition
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun CompassScreen(
    currentPosition: NavigationPosition,
    compassHeading: Double,
    pitch: Double,
    roll: Double
) {
    val headingDeg = (currentPosition.bearingDegrees ?: compassHeading).toFloat()
    val cardinal = getCardinalDirection(headingDeg)

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .testTag("compass_screen")
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(modifier = Modifier.height(28.dp))

            // Title
            Text(
                text = "AEROSPACE COMPASS INSTRUMENT",
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 2.sp,
                    fontFamily = FontFamily.Monospace
                ),
                color = MaterialTheme.colorScheme.onBackground
            )
            Text(
                text = "NEWTON PRECISION INERTIAL BEARING",
                style = MaterialTheme.typography.labelSmall.copy(
                    letterSpacing = 1.sp,
                    fontFamily = FontFamily.Monospace
                ),
                color = Color(0xFF00B0FF)
            )

            Spacer(modifier = Modifier.height(24.dp))

            // Compass Dial Canvas
            Box(
                modifier = Modifier
                    .size(280.dp)
                    .testTag("compass_dial_canvas"),
                contentAlignment = Alignment.Center
            ) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val center = Offset(size.width / 2f, size.height / 2f)
                    val radius = size.width / 2f - 16f

                    // Draw Dial Bezel
                    drawCircle(color = Color(0xFF1B2735), radius = radius)
                    drawCircle(color = Color(0xFF00B0FF), radius = radius, style = Stroke(width = 3f))

                    // Inner Dial Ring
                    drawCircle(color = Color(0xFF0A121E), radius = radius * 0.75f)

                    // Draw Rotating Compass Degree Ticks
                    rotate(-headingDeg, pivot = center) {
                        for (i in 0 until 360 step 15) {
                            val rad = Math.toRadians(i.toDouble() - 90)
                            val isMajor = i % 90 == 0
                            val tickLen = if (isMajor) 22f else 10f
                            val strokeW = if (isMajor) 3f else 1.5f

                            val p1 = Offset(
                                (center.x + (radius - tickLen) * cos(rad)).toFloat(),
                                (center.y + (radius - tickLen) * sin(rad)).toFloat()
                            )
                            val p2 = Offset(
                                (center.x + radius * cos(rad)).toFloat(),
                                (center.y + radius * sin(rad)).toFloat()
                            )

                            drawLine(
                                color = if (i == 0) Color.Red else Color.White,
                                start = p1,
                                end = p2,
                                strokeWidth = strokeW
                            )
                        }
                    }

                    // Static Pointer Triangle (Top North Indicator)
                    val pointerPath = Path().apply {
                        moveTo(center.x, center.y - radius + 22f)
                        lineTo(center.x - 12f, center.y - radius - 8f)
                        lineTo(center.x + 12f, center.y - radius - 8f)
                        close()
                    }
                    drawPath(path = pointerPath, color = Color(0xFF00B0FF))
                }

                // Center Heading Text Readout
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = "${headingDeg.toInt()}°",
                        style = MaterialTheme.typography.headlineMedium.copy(
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 36.sp
                        ),
                        color = Color.White
                    )
                    Text(
                        text = cardinal,
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 2.sp,
                            fontFamily = FontFamily.Monospace
                        ),
                        color = Color(0xFF00B0FF)
                    )
                }
            }

            Spacer(modifier = Modifier.height(30.dp))

            // Inertial Telemetry Cards
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                TelemetryCard(
                    title = "PITCH",
                    value = "${String.format("%.1f", pitch)}°",
                    modifier = Modifier.weight(1f)
                )
                TelemetryCard(
                    title = "ROLL",
                    value = "${String.format("%.1f", roll)}°",
                    modifier = Modifier.weight(1f)
                )
                TelemetryCard(
                    title = "ALTITUDE",
                    value = "${currentPosition.altitudeMeters?.toInt() ?: 82} m",
                    modifier = Modifier.weight(1f)
                )
            }
        }
    }
}

@Composable
private fun TelemetryCard(
    title: String,
    value: String,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(containerColor = Color(0xFF1B2735)),
        shape = RoundedCornerShape(14.dp)
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = title,
                style = MaterialTheme.typography.labelSmall.copy(fontFamily = FontFamily.Monospace),
                color = Color.Gray
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = value,
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                ),
                color = Color.White
            )
        }
    }
}

private fun getCardinalDirection(deg: Float): String {
    val normalized = (deg % 360 + 360) % 360
    return when {
        normalized >= 337.5 || normalized < 22.5 -> "N"
        normalized >= 22.5 && normalized < 67.5 -> "NE"
        normalized >= 67.5 && normalized < 112.5 -> "E"
        normalized >= 112.5 && normalized < 157.5 -> "SE"
        normalized >= 157.5 && normalized < 202.5 -> "S"
        normalized >= 202.5 && normalized < 247.5 -> "SW"
        normalized >= 247.5 && normalized < 292.5 -> "W"
        else -> "NW"
    }
}
