package com.example.newton.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Radar
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.newton.domain.model.ConstellationType
import com.example.newton.domain.model.SatelliteStatus
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun SatelliteScreen(
    satellites: List<SatelliteStatus>,
    fixState: String,
    accuracyMeters: Double
) {
    val usedCount = satellites.count { it.usedInFix }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .testTag("satellite_screen")
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(20.dp)
        ) {
            Spacer(modifier = Modifier.height(28.dp))

            // Header Title
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "GNSS SATELLITE STATUS",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 2.sp,
                            fontFamily = FontFamily.Monospace
                        ),
                        color = MaterialTheme.colorScheme.onBackground
                    )
                    Text(
                        text = "NEWTON HIGH-PRECISION ORBITAL INSTRUMENT",
                        style = MaterialTheme.typography.labelSmall.copy(
                            letterSpacing = 1.sp,
                            fontFamily = FontFamily.Monospace
                        ),
                        color = Color(0xFF00B0FF)
                    )
                }

                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = Color(0xFF26A69A)
                ) {
                    Text(
                        text = fixState,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                        color = Color.Black
                    )
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Stat Cards Grid
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                StatCard(
                    title = "SATELLITES",
                    value = "${satellites.size}",
                    subtitle = "VISIBLE",
                    modifier = Modifier.weight(1f)
                )
                StatCard(
                    title = "USED IN FIX",
                    value = "$usedCount",
                    subtitle = "ACTIVE ORBITS",
                    modifier = Modifier.weight(1f)
                )
                StatCard(
                    title = "ACCURACY",
                    value = "${String.format("%.1f", accuracyMeters)}m",
                    subtitle = "3D HDOP",
                    modifier = Modifier.weight(1f)
                )
            }

            Spacer(modifier = Modifier.height(20.dp))

            // 2D/3D Orbital Skyplot Radar View
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(260.dp)
                    .testTag("skyplot_radar_card"),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF0A121E)),
                shape = RoundedCornerShape(20.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF1B2735))
            ) {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    Canvas(modifier = Modifier.size(230.dp)) {
                        val center = Offset(size.width / 2f, size.height / 2f)
                        val maxRadius = size.width / 2f - 20f

                        // Draw Radar Rings (Elevation 0°, 30°, 60°)
                        drawCircle(color = Color(0xFF263238), radius = maxRadius, style = Stroke(width = 1.5f))
                        drawCircle(color = Color(0xFF15202B), radius = maxRadius * 0.66f, style = Stroke(width = 1f))
                        drawCircle(color = Color(0xFF15202B), radius = maxRadius * 0.33f, style = Stroke(width = 1f))

                        // Crosshairs (N-S / E-W)
                        drawLine(color = Color(0xFF263238), start = Offset(center.x, 10f), end = Offset(center.x, size.height - 10f))
                        drawLine(color = Color(0xFF263238), start = Offset(10f, center.y), end = Offset(size.width - 10f, center.y))

                        // Plot Satellites on Skyplot
                        satellites.forEach { sat ->
                            val r = maxRadius * (1f - sat.elevationDegrees.toFloat() / 90f)
                            val azRad = Math.toRadians(sat.azimuthDegrees - 90) // 0° North is up

                            val x = center.x + (r * cos(azRad)).toFloat()
                            val y = center.y + (r * sin(azRad)).toFloat()

                            val color = if (sat.usedInFix) {
                                when (sat.constellation) {
                                    ConstellationType.GPS -> Color(0xFF00B0FF)
                                    ConstellationType.GALILEO -> Color(0xFF26A69A)
                                    ConstellationType.GLONASS -> Color(0xFFFFB300)
                                    ConstellationType.BEIDOU -> Color(0xFFAB47BC)
                                    ConstellationType.QZSS -> Color(0xFFFF7043)
                                    else -> Color.White
                                }
                            } else Color.DarkGray

                            drawCircle(color = color, radius = 6f, center = Offset(x, y))
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            Text(
                text = "CONSTELLATIONS SIGNAL BREAKDOWN",
                style = MaterialTheme.typography.labelMedium.copy(
                    letterSpacing = 1.2.sp,
                    fontFamily = FontFamily.Monospace
                ),
                color = MaterialTheme.colorScheme.outline
            )
            Spacer(modifier = Modifier.height(8.dp))

            // Satellite Signal Breakdown List
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.weight(1f)
            ) {
                items(satellites) { sat ->
                    SatelliteRowItem(sat)
                }
            }
        }
    }
}

@Composable
private fun StatCard(
    title: String,
    value: String,
    subtitle: String,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(containerColor = Color(0xFF1B2735)),
        shape = RoundedCornerShape(14.dp)
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = title,
                style = MaterialTheme.typography.labelSmall.copy(
                    fontFamily = FontFamily.Monospace,
                    fontSize = 10.sp
                ),
                color = Color.Gray
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = value,
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                ),
                color = Color.White
            )
            Text(
                text = subtitle,
                style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp),
                color = Color(0xFF00B0FF)
            )
        }
    }
}

@Composable
private fun SatelliteRowItem(sat: SatelliteStatus) {
    Surface(
        shape = RoundedCornerShape(10.dp),
        color = Color(0xFF15202B),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(8.dp)
                        .clip(CircleShape)
                        .background(if (sat.usedInFix) Color(0xFF26A69A) else Color.Gray)
                )
                Spacer(modifier = Modifier.width(10.dp))
                Text(
                    text = "${sat.constellation.name} PRN #${sat.satelliteId}",
                    style = MaterialTheme.typography.bodyMedium.copy(
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    ),
                    color = Color.White
                )
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = "AZ: ${sat.azimuthDegrees.toInt()}° EL: ${sat.elevationDegrees.toInt()}°",
                    style = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace),
                    color = Color.Gray
                )
                Spacer(modifier = Modifier.width(12.dp))
                val snrVal = sat.signalStrengthDbHz ?: 35.0
                Text(
                    text = "${snrVal.toInt()} dB-Hz",
                    style = MaterialTheme.typography.bodyMedium.copy(
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold
                    ),
                    color = if (snrVal > 38) Color(0xFF00B0FF) else Color(0xFFFFB300)
                )
            }
        }
    }
}
