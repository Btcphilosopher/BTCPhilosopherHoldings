package com.example.newton.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.automirrored.filled.VolumeMute
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.CompassCalibration
import androidx.compose.material.icons.filled.Directions
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.filled.Navigation
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.TurnRight
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.newton.domain.model.ManoeuvreType
import com.example.newton.domain.model.NavigationPosition
import com.example.newton.domain.model.NavigationState
import com.example.newton.domain.model.Route
import com.example.newton.maps.CameraMode
import com.example.newton.maps.VectorMapCanvas

@Composable
fun LiveNavScreen(
    currentPosition: NavigationPosition,
    activeRoute: Route?,
    currentInstructionIndex: Int,
    remainingDistanceMeters: Double,
    remainingDurationSeconds: Long,
    navState: NavigationState,
    isVoiceEnabled: Boolean,
    onToggleVoice: () -> Unit,
    onTriggerOffRoute: () -> Unit,
    onStopNavigation: () -> Unit
) {
    var cameraMode by remember { mutableStateOf(CameraMode.PERSPECTIVE_3D) }

    val currentInstruction = activeRoute?.instructions?.getOrNull(currentInstructionIndex)
    val yardsToManeuver = currentInstruction?.distanceMeters?.let { (it * 1.09361).toInt() } ?: 300
    val currentSpeedMph = ((currentPosition.speedMetersPerSecond ?: 0.0) * 2.23694).toInt()

    Box(
        modifier = Modifier
            .fillMaxSize()
            .testTag("live_nav_screen")
    ) {
        // 1. Vector Map Hero Canvas
        VectorMapCanvas(
            modifier = Modifier.fillMaxSize(),
            currentPosition = currentPosition,
            activeRoute = activeRoute,
            cameraMode = cameraMode,
            isDarkTheme = true
        )

        // 2. Top Turn Instruction Banner
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
                .align(Alignment.TopCenter)
        ) {
            Spacer(modifier = Modifier.height(24.dp))

            // State Alert Notification Overlays
            if (navState == NavigationState.OFF_ROUTE || navState == NavigationState.RECALCULATING) {
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = Color(0xFFFFB300),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 8.dp)
                        .testTag("recalculating_alert_banner")
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Refresh,
                            contentDescription = "Recalculating",
                            tint = Color.Black,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "ROUTE CHANGED — RECALCULATING…",
                            style = MaterialTheme.typography.labelMedium.copy(
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            ),
                            color = Color.Black
                        )
                    }
                }
            } else if (navState == NavigationState.ESTIMATED_POSITION || currentPosition.isEstimated) {
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = Color(0xFFFFB300),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 8.dp)
                        .testTag("dead_reckoning_alert_banner")
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.CompassCalibration,
                            contentDescription = "Inertial",
                            tint = Color.Black,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "GNSS DEGRADED — DEAD RECKONING ACTIVE",
                            style = MaterialTheme.typography.labelMedium.copy(
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            ),
                            color = Color.Black
                        )
                    }
                }
            }

            // Primary Turn-by-Turn Guidance Banner
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("turn_guidance_banner"),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF0A121E)),
                border = androidx.compose.foundation.BorderStroke(1.5.dp, Color(0xFF00B0FF))
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Manoeuvre Icon Box
                        Box(
                            modifier = Modifier
                                .size(56.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(Color(0xFF1E88E5)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = when (currentInstruction?.manoeuvre) {
                                    ManoeuvreType.TURN_LEFT, ManoeuvreType.SLIGHT_LEFT, ManoeuvreType.KEEP_LEFT -> Icons.Default.Directions
                                    ManoeuvreType.TURN_RIGHT, ManoeuvreType.SLIGHT_RIGHT, ManoeuvreType.KEEP_RIGHT -> Icons.Default.TurnRight
                                    else -> Icons.Default.Navigation
                                },
                                contentDescription = "Turn Action",
                                tint = Color.White,
                                modifier = Modifier.size(34.dp)
                            )
                        }

                        Spacer(modifier = Modifier.width(16.dp))

                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "IN $yardsToManeuver YD",
                                style = MaterialTheme.typography.headlineSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace
                                ),
                                color = Color(0xFF00B0FF)
                            )
                            Text(
                                text = currentInstruction?.instructionText ?: "Continue on route",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.SemiBold),
                                color = Color.White
                            )
                            Text(
                                text = currentInstruction?.roadName ?: "A57 Sheffield / M1 North",
                                style = MaterialTheme.typography.bodyMedium,
                                color = Color.Gray
                            )
                        }
                    }

                    // Multi-Lane Guidance Bar (if available)
                    if (currentInstruction?.lanes?.isNotEmpty() == true) {
                        Spacer(modifier = Modifier.height(12.dp))
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            currentInstruction.lanes.forEach { lane ->
                                Surface(
                                    shape = RoundedCornerShape(4.dp),
                                    color = if (lane.isRecommended) Color(0xFF00B0FF) else Color(0xFF1B2735),
                                    modifier = Modifier.size(width = 36.dp, height = 28.dp)
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Text(
                                            text = if (lane.indication == "right") "↗" else "↑",
                                            color = if (lane.isRecommended) Color.Black else Color.Gray,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 16.sp
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // 3. Map Control Floating Action Buttons (Right Margin)
        Column(
            modifier = Modifier
                .align(Alignment.CenterEnd)
                .padding(end = 16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Camera Mode Toggle
            IconButton(
                onClick = {
                    cameraMode = when (cameraMode) {
                        CameraMode.PERSPECTIVE_3D -> CameraMode.HEADING_UP
                        CameraMode.HEADING_UP -> CameraMode.NORTH_UP
                        CameraMode.NORTH_UP -> CameraMode.PERSPECTIVE_3D
                    }
                },
                modifier = Modifier
                    .clip(CircleShape)
                    .background(Color(0xFF0A121E))
                    .border(1.dp, Color(0xFF00B0FF), CircleShape)
                    .testTag("camera_mode_toggle_button")
            ) {
                Icon(
                    imageVector = Icons.Default.Explore,
                    contentDescription = "Camera Mode",
                    tint = Color(0xFF00B0FF)
                )
            }

            // Mute / Voice Guidance
            IconButton(
                onClick = onToggleVoice,
                modifier = Modifier
                    .clip(CircleShape)
                    .background(Color(0xFF0A121E))
                    .border(1.dp, Color(0xFF00B0FF), CircleShape)
                    .testTag("voice_mute_button")
            ) {
                Icon(
                    imageVector = if (isVoiceEnabled) Icons.AutoMirrored.Filled.VolumeUp else Icons.AutoMirrored.Filled.VolumeMute,
                    contentDescription = "Mute Voice",
                    tint = Color(0xFF00B0FF)
                )
            }

            // Dev Trigger Off-Route Test
            IconButton(
                onClick = onTriggerOffRoute,
                modifier = Modifier
                    .clip(CircleShape)
                    .background(Color(0xFF0A121E))
                    .border(1.dp, Color(0xFFFFB300), CircleShape)
                    .testTag("trigger_off_route_button")
            ) {
                Icon(
                    imageVector = Icons.Default.Refresh,
                    contentDescription = "Dev Off Route",
                    tint = Color(0xFFFFB300)
                )
            }

            // Cancel / Stop Navigation
            IconButton(
                onClick = onStopNavigation,
                modifier = Modifier
                    .clip(CircleShape)
                    .background(Color(0xFF0A121E))
                    .border(1.dp, Color(0xFFFF5252), CircleShape)
                    .testTag("stop_navigation_button")
            ) {
                Icon(
                    imageVector = Icons.Default.Close,
                    contentDescription = "Stop Navigation",
                    tint = Color(0xFFFF5252)
                )
            }
        }

        // 4. Bottom Aerospace Instrument Cluster
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
                .align(Alignment.BottomCenter)
                .testTag("bottom_instrument_cluster"),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF0A121E)),
            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF1B2735))
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(18.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Remaining Distance & Time
                Column {
                    val remMiles = remainingDistanceMeters * 0.000621371
                    val remMinutes = remainingDurationSeconds / 60

                    Text(
                        text = "${String.format("%.1f", remMiles)} MI REMAINING",
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        ),
                        color = Color.White
                    )
                    Text(
                        text = "$remMinutes MIN • ARRIVAL ${
                            java.text.SimpleDateFormat("HH:mm", java.util.Locale.UK)
                                .format(java.util.Date(System.currentTimeMillis() + remainingDurationSeconds * 1000))
                        }",
                        style = MaterialTheme.typography.bodyMedium.copy(
                            fontFamily = FontFamily.Monospace
                        ),
                        color = Color(0xFF00B0FF)
                    )
                }

                // Speedometer & Speed Limit Badge
                Row(verticalAlignment = Alignment.CenterVertically) {
                    // Speed Limit Circle Badge
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(CircleShape)
                            .background(Color.White)
                            .border(3.dp, Color.Red, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "70",
                            style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold),
                            color = Color.Black
                        )
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    // Current Speed Readout
                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            text = "$currentSpeedMph",
                            style = MaterialTheme.typography.headlineLarge.copy(
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            ),
                            color = Color.White
                        )
                        Text(
                            text = "MPH",
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontFamily = FontFamily.Monospace
                            ),
                            color = Color.Gray
                        )
                    }
                }
            }
        }
    }
}
