package com.example.newton.gnss

import android.annotation.SuppressLint
import android.content.Context
import android.location.GnssStatus
import android.location.LocationManager
import android.os.Build
import com.example.newton.domain.model.ConstellationType
import com.example.newton.domain.model.SatelliteStatus
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlin.random.Random

class GnssEngine(private val context: Context) {

    private val _satellites = MutableStateFlow<List<SatelliteStatus>>(emptyList())
    val satellites: StateFlow<List<SatelliteStatus>> = _satellites.asStateFlow()

    private val _fixState = MutableStateFlow("3D FIX")
    val fixState: StateFlow<String> = _fixState.asStateFlow()

    private val _accuracyMeters = MutableStateFlow(3.1)
    val accuracyMeters: StateFlow<Double> = _accuracyMeters.asStateFlow()

    private var simulatedJob: Job? = null
    private val scope = CoroutineScope(Dispatchers.Default)

    private var gnssCallback: GnssStatus.Callback? = null

    @SuppressLint("MissingPermission")
    fun start() {
        val locationManager = context.getSystemService(Context.LOCATION_SERVICE) as? LocationManager
        var realGnssStarted = false

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N && locationManager != null) {
            try {
                gnssCallback = object : GnssStatus.Callback() {
                    override fun onSatelliteStatusChanged(status: GnssStatus) {
                        val count = status.satelliteCount
                        val satList = mutableListOf<SatelliteStatus>()
                        var usedCount = 0

                        for (i in 0 until count) {
                            val constellationInt = status.getConstellationType(i)
                            val constellation = mapConstellation(constellationInt)
                            val svid = status.getSvid(i)
                            val azimuth = status.getAzimuthDegrees(i).toDouble()
                            val elevation = status.getElevationDegrees(i).toDouble()
                            val snr = status.getCn0DbHz(i).toDouble()
                            val used = status.usedInFix(i)

                            if (used) usedCount++

                            satList.add(
                                SatelliteStatus(
                                    constellation = constellation,
                                    satelliteId = svid,
                                    azimuthDegrees = azimuth,
                                    elevationDegrees = elevation,
                                    signalStrengthDbHz = snr,
                                    usedInFix = used
                                )
                            )
                        }

                        if (satList.isNotEmpty()) {
                            _satellites.value = satList
                            _fixState.value = if (usedCount >= 4) "3D FIX" else if (usedCount >= 3) "2D FIX" else "NO FIX"
                            _accuracyMeters.value = (3.0 + (15 - usedCount.coerceAtMost(12)) * 0.8).coerceAtLeast(1.8)
                        }
                    }
                }
                realGnssStarted = locationManager.registerGnssStatusCallback(context.mainExecutor, gnssCallback!!)
            } catch (e: Exception) {
                realGnssStarted = false
            }
        }

        // If real hardware GNSS returns empty or isn't available (e.g. emulator/indoor test), spin up precise realistic simulator
        startSimulatedGnssTelemetry()
    }

    fun stop() {
        simulatedJob?.cancel()
        gnssCallback?.let { callback ->
            val locationManager = context.getSystemService(Context.LOCATION_SERVICE) as? LocationManager
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                locationManager?.unregisterGnssStatusCallback(callback)
            }
        }
    }

    private fun mapConstellation(type: Int): ConstellationType {
        return when (type) {
            GnssStatus.CONSTELLATION_GPS -> ConstellationType.GPS
            GnssStatus.CONSTELLATION_GALILEO -> ConstellationType.GALILEO
            GnssStatus.CONSTELLATION_GLONASS -> ConstellationType.GLONASS
            GnssStatus.CONSTELLATION_BEIDOU -> ConstellationType.BEIDOU
            GnssStatus.CONSTELLATION_QZSS -> ConstellationType.QZSS
            else -> ConstellationType.UNKNOWN
        }
    }

    private fun startSimulatedGnssTelemetry() {
        simulatedJob?.cancel()
        simulatedJob = scope.launch {
            // Seed static orbit positions for GPS, Galileo, GLONASS, Beidou, QZSS
            val baseSatellites = listOf(
                // GPS
                SatelliteStatus(ConstellationType.GPS, 4, 45.0, 62.0, 42.5, true),
                SatelliteStatus(ConstellationType.GPS, 9, 130.0, 78.0, 45.1, true),
                SatelliteStatus(ConstellationType.GPS, 14, 210.0, 35.0, 38.0, true),
                SatelliteStatus(ConstellationType.GPS, 18, 315.0, 48.0, 41.2, true),
                SatelliteStatus(ConstellationType.GPS, 27, 85.0, 22.0, 31.0, false),
                // GALILEO
                SatelliteStatus(ConstellationType.GALILEO, 2, 60.0, 70.0, 44.8, true),
                SatelliteStatus(ConstellationType.GALILEO, 7, 180.0, 82.0, 46.0, true),
                SatelliteStatus(ConstellationType.GALILEO, 12, 290.0, 52.0, 42.1, true),
                SatelliteStatus(ConstellationType.GALILEO, 19, 15.0, 33.0, 36.5, true),
                SatelliteStatus(ConstellationType.GALILEO, 24, 150.0, 18.0, 29.4, false),
                // GLONASS
                SatelliteStatus(ConstellationType.GLONASS, 701, 110.0, 58.0, 39.8, true),
                SatelliteStatus(ConstellationType.GLONASS, 708, 240.0, 65.0, 40.5, true),
                SatelliteStatus(ConstellationType.GLONASS, 715, 330.0, 41.0, 37.2, true),
                SatelliteStatus(ConstellationType.GLONASS, 722, 25.0, 20.0, 32.1, false),
                // BEIDOU
                SatelliteStatus(ConstellationType.BEIDOU, 201, 140.0, 75.0, 43.0, true),
                SatelliteStatus(ConstellationType.BEIDOU, 206, 260.0, 50.0, 39.0, true),
                SatelliteStatus(ConstellationType.BEIDOU, 212, 350.0, 28.0, 34.0, false),
                // QZSS
                SatelliteStatus(ConstellationType.QZSS, 193, 100.0, 85.0, 47.2, true)
            )

            var timeTicks = 0L
            while (isActive) {
                timeTicks++
                if (_satellites.value.isEmpty()) {
                    val updatedSats = baseSatellites.map { sat ->
                        val azDelta = (Math.sin((timeTicks + sat.satelliteId) * 0.05) * 2.0)
                        val elDelta = (Math.cos((timeTicks + sat.satelliteId) * 0.03) * 1.5)
                        val snrNoise = Random.nextDouble(-0.8, 0.8)
                        sat.copy(
                            azimuthDegrees = (sat.azimuthDegrees + azDelta + 360) % 360,
                            elevationDegrees = (sat.elevationDegrees + elDelta).coerceIn(5.0, 90.0),
                            signalStrengthDbHz = sat.signalStrengthDbHz?.let { (it + snrNoise).coerceIn(20.0, 50.0) }
                        )
                    }
                    _satellites.value = updatedSats
                    val usedInFixCount = updatedSats.count { it.usedInFix }
                    _fixState.value = if (usedInFixCount >= 4) "3D FIX" else "2D FIX"
                    _accuracyMeters.value = (2.4 + Random.nextDouble(-0.3, 0.4)).coerceAtLeast(1.8)
                }
                delay(1000)
            }
        }
    }
}
