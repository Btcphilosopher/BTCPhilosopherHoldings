package com.example.newton.domain.model

import androidx.room.Entity
import androidx.room.PrimaryKey

data class GeoPoint(
    val latitude: Double,
    val longitude: Double,
    val altitudeMeters: Double = 0.0
)

data class NavigationPosition(
    val latitude: Double,
    val longitude: Double,
    val altitudeMeters: Double? = null,
    val accuracyMeters: Double = 5.0,
    val speedMetersPerSecond: Double? = 0.0,
    val bearingDegrees: Double? = 0.0,
    val timestamp: Long = System.currentTimeMillis(),
    val isEstimated: Boolean = false
)

enum class ConstellationType {
    GPS, GALILEO, GLONASS, BEIDOU, QZSS, UNKNOWN
}

data class SatelliteStatus(
    val constellation: ConstellationType,
    val satelliteId: Int,
    val azimuthDegrees: Double,
    val elevationDegrees: Double,
    val signalStrengthDbHz: Double?,
    val usedInFix: Boolean
)

enum class ManoeuvreType {
    DEPART,
    TURN_LEFT,
    TURN_RIGHT,
    SLIGHT_LEFT,
    SLIGHT_RIGHT,
    KEEP_LEFT,
    KEEP_RIGHT,
    CONTINUE,
    ROUNDABOUT,
    MERGE,
    U_TURN,
    ARRIVE
}

data class LaneInfo(
    val indication: String, // e.g. "straight", "right", "left"
    val isRecommended: Boolean
)

data class NavigationInstruction(
    val distanceMeters: Double,
    val durationSeconds: Long,
    val instructionText: String,
    val roadName: String,
    val manoeuvre: ManoeuvreType,
    val targetGeoPoint: GeoPoint,
    val lanes: List<LaneInfo> = emptyList()
)

enum class RouteType {
    FASTEST,
    ALTERNATIVE,
    AVOID_MOTORWAYS
}

data class Route(
    val id: String,
    val name: String,
    val distanceMeters: Double,
    val durationSeconds: Long,
    val geometry: List<GeoPoint>,
    val instructions: List<NavigationInstruction>,
    val routeType: RouteType = RouteType.FASTEST,
    val hasTolls: Boolean = false,
    val hasMotorways: Boolean = true
)

data class SearchResult(
    val id: String,
    val name: String,
    val category: String,
    val latitude: Double,
    val longitude: Double,
    val address: String,
    val distanceKm: Double = 0.0
)

enum class NavigationState {
    SEARCHING,
    POSITIONING,
    READY,
    NAVIGATING,
    OFF_ROUTE,
    RECALCULATING,
    GNSS_DEGRADED,
    ESTIMATED_POSITION,
    ARRIVED
}

enum class VehicleProfile(
    val displayName: String,
    val iconName: String,
    val maxSpeedMph: Int,
    val avoidMotorwaysByDefault: Boolean
) {
    CAR("Passenger Vehicle", "directions_car", 70, false),
    ELECTRIC_VEHICLE("EV Rocket", "electric_car", 70, false),
    HEAVY_GOODS("Heavy Goods Vehicle", "local_shipping", 56, false),
    BICYCLE("Aerospace Cycle", "directions_bike", 18, true),
    PEDESTRIAN("Pedestrian Explorer", "directions_walk", 4, true)
}

enum class DistanceUnit {
    MILES_FEET,
    KILOMETERS_METERS
}

@Entity(tableName = "saved_places")
data class SavedPlace(
    @PrimaryKey val id: String,
    val name: String,
    val address: String,
    val latitude: Double,
    val longitude: Double,
    val placeType: String, // "HOME", "WORK", "FAVOURITE", "CUSTOM"
    val iconName: String = "place",
    val dateAdded: Long = System.currentTimeMillis()
)

@Entity(tableName = "journey_history")
data class JourneyRecord(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val originName: String,
    val destinationName: String,
    val distanceMiles: Double,
    val durationMinutes: Long,
    val avgSpeedMph: Double,
    val maxSpeedMph: Double,
    val elevationGainMeters: Double,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "offline_regions")
data class OfflineRegion(
    @PrimaryKey val regionId: String,
    val name: String,
    val minLat: Double,
    val maxLat: Double,
    val minLon: Double,
    val maxLon: Double,
    val sizeMb: Double,
    val tileCount: Int,
    val isDownloaded: Boolean = false,
    val downloadTimestamp: Long = 0
)
