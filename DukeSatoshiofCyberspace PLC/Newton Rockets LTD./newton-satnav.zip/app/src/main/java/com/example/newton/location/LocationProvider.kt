package com.example.newton.location

import android.annotation.SuppressLint
import android.content.Context
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Bundle
import com.example.newton.domain.model.NavigationPosition
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class LocationProvider(
    private val context: Context,
    val sensorFusion: SensorFusionManager,
    val simulator: SimulationLocationProvider
) : LocationListener {

    private val locationManager = context.getSystemService(Context.LOCATION_SERVICE) as? LocationManager

    private val _currentPosition = MutableStateFlow<NavigationPosition>(
        NavigationPosition(
            latitude = 53.3811, // Default Sheffield Newton HQ
            longitude = -1.4701,
            altitudeMeters = 82.0,
            accuracyMeters = 3.2,
            speedMetersPerSecond = 0.0,
            bearingDegrees = 0.0,
            timestamp = System.currentTimeMillis()
        )
    )
    val currentPosition: StateFlow<NavigationPosition> = _currentPosition.asStateFlow()

    private val _isGpsActive = MutableStateFlow(false)
    val isGpsActive: StateFlow<Boolean> = _isGpsActive.asStateFlow()

    private val scope = CoroutineScope(Dispatchers.Default)

    init {
        scope.launch {
            simulator.simulatedPosition.collect { simPos ->
                if (simPos != null && simulator.isSimulating.value) {
                    _currentPosition.value = simPos
                }
            }
        }
    }

    @SuppressLint("MissingPermission")
    fun startLocationUpdates() {
        sensorFusion.start()
        try {
            locationManager?.let { lm ->
                if (lm.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
                    lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000L, 1.0f, this)
                    _isGpsActive.value = true
                }
                if (lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER)) {
                    lm.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 2000L, 5.0f, this)
                }
            }
        } catch (e: Exception) {
            _isGpsActive.value = false
        }
    }

    fun stopLocationUpdates() {
        sensorFusion.stop()
        try {
            locationManager?.removeUpdates(this)
        } catch (e: Exception) {
            // Ignored
        }
    }

    override fun onLocationChanged(location: Location) {
        if (simulator.isSimulating.value) return // Simulator takes precedence when active

        val bearing = if (location.hasBearing()) location.bearing.toDouble() else sensorFusion.compassHeading.value
        val speed = if (location.hasSpeed()) location.speed.toDouble() else 0.0
        val alt = if (location.hasAltitude()) location.altitude else null

        _currentPosition.value = NavigationPosition(
            latitude = location.latitude,
            longitude = location.longitude,
            altitudeMeters = alt,
            accuracyMeters = location.accuracy.toDouble(),
            speedMetersPerSecond = speed,
            bearingDegrees = bearing,
            timestamp = location.time,
            isEstimated = false
        )
    }

    override fun onProviderEnabled(provider: String) {
        if (provider == LocationManager.GPS_PROVIDER) _isGpsActive.value = true
    }

    override fun onProviderDisabled(provider: String) {
        if (provider == LocationManager.GPS_PROVIDER) _isGpsActive.value = false
    }

    @Deprecated("Deprecated in Java")
    override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
}
