package com.example.newton.routing

import com.example.newton.domain.model.GeoPoint
import com.example.newton.domain.model.NavigationPosition
import com.example.newton.domain.model.Route
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

object OffRouteDetector {

    private const val THRESHOLD_METERS = 35.0

    /**
     * Checks whether current vehicle position has deviated from the planned route polyline.
     */
    fun isOffRoute(
        position: NavigationPosition,
        route: Route,
        thresholdMeters: Double = THRESHOLD_METERS
    ): Boolean {
        if (route.geometry.size < 2) return false

        val userPt = GeoPoint(position.latitude, position.longitude)
        var minDistance = Double.MAX_VALUE

        for (i in 0 until route.geometry.size - 1) {
            val p1 = route.geometry[i]
            val p2 = route.geometry[i + 1]
            val dist = pointToSegmentDistanceMeters(userPt, p1, p2)
            if (dist < minDistance) {
                minDistance = dist
            }
        }

        return minDistance > thresholdMeters
    }

    private fun pointToSegmentDistanceMeters(p: GeoPoint, v: GeoPoint, w: GeoPoint): Double {
        val l2 = distanceMetersSq(v, w)
        if (l2 == 0.0) return distanceMeters(p, v)

        val t = (((p.latitude - v.latitude) * (w.latitude - v.latitude) +
                (p.longitude - v.longitude) * (w.longitude - v.longitude)) / l2).coerceIn(0.0, 1.0)

        val projection = GeoPoint(
            latitude = v.latitude + t * (w.latitude - v.latitude),
            longitude = v.longitude + t * (w.longitude - v.longitude)
        )

        return distanceMeters(p, projection)
    }

    private fun distanceMetersSq(p1: GeoPoint, p2: GeoPoint): Double {
        val dLat = p2.latitude - p1.latitude
        val dLon = p2.longitude - p1.longitude
        return dLat * dLat + dLon * dLon
    }

    fun distanceMeters(p1: GeoPoint, p2: GeoPoint): Double {
        val r = 6371000.0
        val dLat = Math.toRadians(p2.latitude - p1.latitude)
        val dLon = Math.toRadians(p2.longitude - p1.longitude)
        val a = sin(dLat / 2) * sin(dLat / 2) +
                cos(Math.toRadians(p1.latitude)) * cos(Math.toRadians(p2.latitude)) *
                sin(dLon / 2) * sin(dLon / 2)
        val c = 2 * atan2(sqrt(a), sqrt(1 - a))
        return r * c
    }
}
