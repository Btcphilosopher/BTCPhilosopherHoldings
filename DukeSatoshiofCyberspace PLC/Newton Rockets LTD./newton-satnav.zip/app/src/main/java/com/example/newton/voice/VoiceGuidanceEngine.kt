package com.example.newton.voice

import android.content.Context
import android.speech.tts.TextToSpeech
import java.util.Locale

class VoiceGuidanceEngine(context: Context) : TextToSpeech.OnInitListener {

    private var tts: TextToSpeech? = TextToSpeech(context.applicationContext, this)
    private var isInitialized = false
    var isEnabled: Boolean = true

    private var lastSpokenInstruction: String? = null

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            val result = tts?.setLanguage(Locale.UK)
            if (result != TextToSpeech.LANG_MISSING_DATA && result != TextToSpeech.LANG_NOT_SUPPORTED) {
                isInitialized = true
                tts?.setSpeechRate(0.95f) // Calm, authoritative British cadence
                tts?.setPitch(0.98f)
            }
        }
    }

    fun speak(text: String, interrupt: Boolean = false) {
        if (!isEnabled || !isInitialized) return
        if (!interrupt && text == lastSpokenInstruction) return

        lastSpokenInstruction = text
        val queueMode = if (interrupt) TextToSpeech.QUEUE_FLUSH else TextToSpeech.QUEUE_ADD
        tts?.speak(text, queueMode, null, "newton_satnav_utterance_${System.currentTimeMillis()}")
    }

    fun stop() {
        tts?.stop()
    }

    fun shutdown() {
        tts?.stop()
        tts?.shutdown()
    }
}
