package com.example.newton.location

import com.example.newton.domain.model.GeoPoint
import com.example.newton.domain.model.NavigationPosition
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

class SimulationLocationProvider {

    private val _simulatedPosition = MutableStateFlow<NavigationPosition?>(null)
    val simulatedPosition: StateFlow<NavigationPosition?> = _simulatedPosition.asStateFlow()

    private val _isSimulating = MutableStateFlow(false)
    val isSimulating: StateFlow<Boolean> = _isSimulating.asStateFlow()

    private val _speedFactor = MutableStateFlow(1.0)
    val speedFactor: StateFlow<Double> = _speedFactor.asStateFlow()

    private val _signalLossActive = MutableStateFlow(false)
    val signalLossActive: StateFlow<Boolean> = _signalLossActive.asStateFlow()

    private var simulationJob: Job? = null
    private val scope = CoroutineScope(Dispatchers.Default)

    // Preset route points for Sheffield -> Leeds by default
    val defaultPresetRoute = listOf(
        GeoPoint(53.3811, -1.4701), // Sheffield City Centre
        GeoPoint(53.4222, -1.4111), // M1 Junction 34 Meadowhall
        GeoPoint(53.5512, -1.4823), // Barnsley Bypass
        GeoPoint(53.6811, -1.4988), // Wakefield Junction
        GeoPoint(53.7997, -1.5492)  // Leeds City Centre
    )

    fun setSpeedFactor(factor: Double) {
        _speedFactor.value = factor.coerceIn(0.5, 10.0)
    }

    fun toggleSignalLoss(active: Boolean? = null) {
        _signalLossActive.value = active ?: !_signalLossActive.value
    }

    fun startSimulation(waypoints: List<GeoPoint> = defaultPresetRoute) {
        stopSimulation()
        if (waypoints.size < 2) return

        _isSimulating.value = true
        simulationJob = scope.launch {
            var currentWaypointIndex = 0
            var currentPoint = waypoints[0]
            var targetPoint = waypoints[1]

            var currentLat = currentPoint.latitude
            var currentLon = currentPoint.longitude

            _simulatedPosition.value = NavigationPosition(
                latitude = currentLat,
                longitude = currentLon,
                altitudeMeters = 82.0,
                accuracyMeters = 3.0,
                speedMetersPerSecond = 18.0, // ~40 mph
                bearingDegrees = calculateBearing(currentPoint, targetPoint)
            )

            val updateIntervalMs = 500L

            while (isActive && currentWaypointIndex < waypoints.size - 1) {
                delay(updateIntervalMs)

                val speedMps = 22.0 * _speedFactor.value // ~50mph * factor
                val bearingDeg = calculateBearing(GeoPoint(currentLat, currentLon), targetPoint)
                val elapsedSec = updateIntervalMs / 1000.0

                if (_signalLossActive.value) {
                    // Use dead reckoning during simulated signal loss
                    val lastPos = _simulatedPosition.value ?: NavigationPosition(currentLat, currentLon)
                    val estPos = DeadReckoningEngine.estimatePosition(lastPos, speedMps, bearingDeg, elapsedSec)
                    currentLat = estPos.latitude
                    currentLon = estPos.longitude
                    _simulatedPosition.value = estPos
                } else {
                    // Normal simulated position calculation
                    val metersToTarget = distanceMeters(GeoPoint(currentLat, currentLon), targetPoint)
                    if (metersToTarget < speedMps * elapsedSec * 2) {
                        currentWaypointIndex++
                        if (currentWaypointIndex >= waypoints.size - 1) break
                        currentPoint = waypoints[currentWaypointIndex]
                        targetPoint = waypoints[currentWaypointIndex + 1]
                    }

                    val bearingRad = Math.toRadians(bearingDeg)
                    val deltaLat = (speedMps * elapsedSec * cos(bearingRad)) / 111139.0
                    val deltaLon = (speedMps * elapsedSec * sin(bearingRad)) / (111139.0 * cos(Math.toRadians(currentLat)))

                    currentLat += deltaLat
                    currentLon += deltaLon

                    _simulatedPosition.value = NavigationPosition(
                        latitude = currentLat,
                        longitude = currentLon,
                        altitudeMeters = 82.0 + Math.sin(currentWaypointIndex.toDouble()) * 20,
                        accuracyMeters = 2.8,
                        speedMetersPerSecond = speedMps,
                        bearingDegrees = bearingDeg,
                        timestamp = System.currentTimeMillis(),
                        isEstimated = false
                    )
                }
            }
            _isSimulating.value = false
        }
    }

    fun triggerOffRouteDeviation() {
        val currentPos = _simulatedPosition.value ?: return
        // Shift position 150 meters to the east to force off-route detection
        val devLat = currentPos.latitude + 0.001
        val devLon = currentPos.longitude + 0.002

        _simulatedPosition.value = currentPos.copy(
            latitude = devLat,
            longitude = devLon,
            timestamp = System.currentTimeMillis()
        )
    }

    fun stopSimulation() {
        simulationJob?.cancel()
        _isSimulating.value = false
    }

    private fun calculateBearing(start: GeoPoint, end: GeoPoint): Double {
        val lat1 = Math.toRadians(start.latitude)
        val lat2 = Math.toRadians(end.latitude)
        val dLon = Math.toRadians(end.longitude - start.longitude)

        val y = sin(dLon) * cos(lat2)
        val x = cos(lat1) * sin(lat2) - sin(lat1) * cos(lat2) * cos(dLon)
        val bearingRad = atan2(y, x)
        return (Math.toDegrees(bearingRad) + 360) % 360
    }

    private fun distanceMeters(p1: GeoPoint, p2: GeoPoint): Double {
        val r = 6371000.0
        val dLat = Math.toRadians(p2.latitude - p1.latitude)
        val dLon = Math.toRadians(p2.longitude - p1.longitude)
        val a = sin(dLat / 2) * sin(dLat / 2) +
                cos(Math.toRadians(p1.latitude)) * cos(Math.toRadians(p2.latitude)) *
                sin(dLon / 2) * sin(dLon / 2)
        val c = 2 * atan2(sqrt(a), sqrt(1 - a))
        return r * c
    }
}
