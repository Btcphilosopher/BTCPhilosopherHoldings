package com.example.newton.location

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlin.math.atan2

class SensorFusionManager(context: Context) : SensorEventListener {

    private val sensorManager = context.getSystemService(Context.SENSOR_SERVICE) as? SensorManager

    private val _compassHeading = MutableStateFlow(0.0)
    val compassHeading: StateFlow<Double> = _compassHeading.asStateFlow()

    private val _pitch = MutableStateFlow(0.0)
    val pitch: StateFlow<Double> = _pitch.asStateFlow()

    private val _roll = MutableStateFlow(0.0)
    val roll: StateFlow<Double> = _roll.asStateFlow()

    private val _linearAcceleration = MutableStateFlow(0.0)
    val linearAcceleration: StateFlow<Double> = _linearAcceleration.asStateFlow()

    private val gravity = FloatArray(3)
    private val geomagnetic = FloatArray(3)
    private val rotationMatrix = FloatArray(9)
    private val orientationAngles = FloatArray(3)

    private var hasGravity = false
    private var hasGeomagnetic = false

    fun start() {
        sensorManager?.let { sm ->
            val accel = sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
            val mag = sm.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD)
            val gyro = sm.getDefaultSensor(Sensor.TYPE_GYROSCOPE)

            accel?.let { sm.registerListener(this, it, SensorManager.SENSOR_DELAY_GAME) }
            mag?.let { sm.registerListener(this, it, SensorManager.SENSOR_DELAY_GAME) }
            gyro?.let { sm.registerListener(this, it, SensorManager.SENSOR_DELAY_GAME) }
        }
    }

    fun stop() {
        sensorManager?.unregisterListener(this)
    }

    override fun onSensorChanged(event: SensorEvent?) {
        if (event == null) return

        when (event.sensor.type) {
            Sensor.TYPE_ACCELEROMETER -> {
                System.arraycopy(event.values, 0, gravity, 0, 3)
                hasGravity = true

                val ax = event.values[0]
                val ay = event.values[1]
                val az = event.values[2]
                val magSq = ax * ax + ay * ay + az * az
                val normAcc = kotlin.math.sqrt(magSq.toDouble()) - 9.81
                _linearAcceleration.value = normAcc
            }
            Sensor.TYPE_MAGNETIC_FIELD -> {
                System.arraycopy(event.values, 0, geomagnetic, 0, 3)
                hasGeomagnetic = true
            }
        }

        if (hasGravity && hasGeomagnetic) {
            val success = SensorManager.getRotationMatrix(rotationMatrix, null, gravity, geomagnetic)
            if (success) {
                SensorManager.getOrientation(rotationMatrix, orientationAngles)
                val azimuthRad = orientationAngles[0]
                val pitchRad = orientationAngles[1]
                val rollRad = orientationAngles[2]

                var azimuthDeg = Math.toDegrees(azimuthRad.toDouble())
                if (azimuthDeg < 0) azimuthDeg += 360.0

                _compassHeading.value = azimuthDeg
                _pitch.value = Math.toDegrees(pitchRad.toDouble())
                _roll.value = Math.toDegrees(rollRad.toDouble())
            }
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
}
