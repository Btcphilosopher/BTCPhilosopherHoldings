package com.example.newton.search

import com.example.newton.domain.model.GeoPoint
import com.example.newton.domain.model.SearchResult
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.URLEncoder
import java.util.UUID
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

class SearchEngine {

    private val client = OkHttpClient.Builder().build()

    // Pre-indexed local database for fast offline search & immediate response
    private val offlineLandmarks = listOf(
        SearchResult(
            id = "uk_sheffield",
            name = "Sheffield City Centre",
            category = "City",
            latitude = 53.3811,
            longitude = -1.4701,
            address = "Sheffield, South Yorkshire, S1 2HH"
        ),
        SearchResult(
            id = "uk_leeds",
            name = "Leeds Station",
            category = "Transport",
            latitude = 53.7952,
            longitude = -1.5481,
            address = "New Station St, Leeds, LS1 4DY"
        ),
        SearchResult(
            id = "uk_manchester",
            name = "Manchester Piccadilly",
            category = "Transport",
            latitude = 53.4774,
            longitude = -2.2309,
            address = "Piccadilly Station, Manchester, M1 2PB"
        ),
        SearchResult(
            id = "uk_heathrow",
            name = "Heathrow Airport (LHR)",
            category = "Airport",
            latitude = 51.4700,
            longitude = -0.4543,
            address = "Longford, Hounslow, TW6 1AP"
        ),
        SearchResult(
            id = "uk_downing",
            name = "10 Downing Street",
            category = "Landmark",
            latitude = 51.5034,
            longitude = -0.1276,
            address = "10 Downing St, London, SW1A 2AA"
        ),
        SearchResult(
            id = "uk_oxford",
            name = "Oxford Station",
            category = "Transport",
            latitude = 51.7533,
            longitude = -1.2702,
            address = "Park End St, Oxford, OX1 1HS"
        ),
        SearchResult(
            id = "uk_cambridge",
            name = "Cambridge Science Park",
            category = "Business",
            latitude = 52.2325,
            longitude = 0.1492,
            address = "Milton Rd, Cambridge, CB4 0FW"
        ),
        SearchResult(
            id = "uk_edinburgh",
            name = "Edinburgh Waverley",
            category = "Transport",
            latitude = 55.9520,
            longitude = -3.1890,
            address = "Waverley Bridge, Edinburgh, EH1 1BB"
        )
    )

    suspend fun search(query: String, userLocation: GeoPoint? = null): List<SearchResult> = withContext(Dispatchers.IO) {
        val trimmed = query.trim()
        if (trimmed.isEmpty()) return@withContext emptyList()

        // 1. Check coordinate search (e.g. "53.3811,-1.4701")
        if (trimmed.contains(",")) {
            val parts = trimmed.split(",")
            if (parts.size == 2) {
                val lat = parts[0].trim().toDoubleOrNull()
                val lon = parts[1].trim().toDoubleOrNull()
                if (lat != null && lon != null) {
                    return@withContext listOf(
                        SearchResult(
                            id = "coord_${System.currentTimeMillis()}",
                            name = "Coordinate Point ($lat, $lon)",
                            category = "GPS Position",
                            latitude = lat,
                            longitude = lon,
                            address = "Target GNSS Coordinates"
                        )
                    )
                }
            }
        }

        // 2. Perform online Nominatim lookup
        val onlineResults = mutableListOf<SearchResult>()
        try {
            val encodedQuery = URLEncoder.encode(trimmed, "UTF-8")
            val url = "https://nominatim.openstreetmap.org/search?q=$encodedQuery&format=json&limit=6&addressdetails=1"
            val request = Request.Builder()
                .url(url)
                .header("User-Agent", "NewtonSatNav/1.0 (aerospace.navigation@newtonrockets.co.uk)")
                .build()

            val response = client.newCall(request).execute()
            if (response.isSuccessful) {
                val bodyString = response.body?.string()
                if (!bodyString.isNullOrEmpty()) {
                    val jsonArray = JSONArray(bodyString)
                    for (i in 0 until jsonArray.length()) {
                        val obj = jsonArray.getJSONObject(i)
                        val name = obj.optString("display_name").split(",").firstOrNull() ?: "Location"
                        val fullAddress = obj.optString("display_name")
                        val lat = obj.getDouble("lat")
                        val lon = obj.getDouble("lon")
                        val category = obj.optString("type").replace("_", " ").capitalize()

                        val dist = if (userLocation != null) calculateDistanceKm(userLocation, GeoPoint(lat, lon)) else 0.0

                        onlineResults.add(
                            SearchResult(
                                id = "nom_${UUID.randomUUID()}",
                                name = name,
                                category = category,
                                latitude = lat,
                                longitude = lon,
                                address = fullAddress,
                                distanceKm = dist
                            )
                        )
                    }
                }
            }
        } catch (e: Exception) {
            // Online search failed or offline, fallback to offline search index
        }

        if (onlineResults.isNotEmpty()) {
            return@withContext onlineResults
        }

        // 3. Fallback to local offline landmark index
        return@withContext offlineLandmarks.filter {
            it.name.contains(trimmed, ignoreCase = true) ||
            it.address.contains(trimmed, ignoreCase = true) ||
            it.category.contains(trimmed, ignoreCase = true)
        }.map { res ->
            val dist = if (userLocation != null) calculateDistanceKm(userLocation, GeoPoint(res.latitude, res.longitude)) else 0.0
            res.copy(distanceKm = dist)
        }
    }

    private fun calculateDistanceKm(p1: GeoPoint, p2: GeoPoint): Double {
        val r = 6371.0
        val dLat = Math.toRadians(p2.latitude - p1.latitude)
        val dLon = Math.toRadians(p2.longitude - p1.longitude)
        val a = sin(dLat / 2) * sin(dLat / 2) +
                cos(Math.toRadians(p1.latitude)) * cos(Math.toRadians(p2.latitude)) *
                sin(dLon / 2) * sin(dLon / 2)
        val c = 2 * atan2(sqrt(a), sqrt(1 - a))
        return r * c
    }
}
