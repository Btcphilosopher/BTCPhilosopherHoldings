package com.example

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CompassCalibration
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.Navigation
import androidx.compose.material.icons.filled.Radar
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.example.newton.data.NewtonDatabase
import com.example.newton.domain.model.DistanceUnit
import com.example.newton.domain.model.GeoPoint
import com.example.newton.domain.model.NavigationState
import com.example.newton.domain.model.SavedPlace
import com.example.newton.domain.model.SearchResult
import com.example.newton.gnss.GnssEngine
import com.example.newton.location.LocationProvider
import com.example.newton.location.SensorFusionManager
import com.example.newton.location.SimulationLocationProvider
import com.example.newton.navigation.NavigationEngine
import com.example.newton.offline.OfflineMapManager
import com.example.newton.routing.RoutingEngine
import com.example.newton.search.SearchEngine
import com.example.newton.ui.screens.CompassScreen
import com.example.newton.ui.screens.DestinationScreen
import com.example.newton.ui.screens.HomeScreen
import com.example.newton.ui.screens.JourneyScreen
import com.example.newton.ui.screens.LiveNavScreen
import com.example.newton.ui.screens.OfflineMapsScreen
import com.example.newton.ui.screens.SatelliteScreen
import com.example.newton.ui.screens.SavedPlacesScreen
import com.example.newton.ui.screens.SearchScreen
import com.example.newton.ui.screens.SettingsScreen
import com.example.newton.voice.VoiceGuidanceEngine
import com.example.ui.theme.NewtonSatNavTheme
import kotlinx.coroutines.launch

enum class MainTab {
    HOME,
    SEARCH,
    DESTINATION,
    SATELLITE,
    COMPASS,
    JOURNEY,
    OFFLINE,
    SAVED,
    SETTINGS
}

class MainActivity : ComponentActivity() {

    private lateinit var db: NewtonDatabase
    private lateinit var gnssEngine: GnssEngine
    private lateinit var sensorFusionManager: SensorFusionManager
    private lateinit var simulator: SimulationLocationProvider
    private lateinit var locationProvider: LocationProvider
    private lateinit var routingEngine: RoutingEngine
    private lateinit var voiceGuidanceEngine: VoiceGuidanceEngine
    private lateinit var navigationEngine: NavigationEngine
    private lateinit var searchEngine: SearchEngine
    private lateinit var offlineMapManager: OfflineMapManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        db = NewtonDatabase.getDatabase(this)
        gnssEngine = GnssEngine(this)
        sensorFusionManager = SensorFusionManager(this)
        simulator = SimulationLocationProvider()
        locationProvider = LocationProvider(this, sensorFusionManager, simulator)
        routingEngine = RoutingEngine()
        voiceGuidanceEngine = VoiceGuidanceEngine(this)
        navigationEngine = NavigationEngine(locationProvider, routingEngine, voiceGuidanceEngine, db.journeyDao())
        searchEngine = SearchEngine()
        offlineMapManager = OfflineMapManager(db.offlineRegionDao())

        gnssEngine.start()
        locationProvider.startLocationUpdates()

        setContent {
            NewtonSatNavTheme(darkTheme = true) {
                MainAppScreen(
                    navigationEngine = navigationEngine,
                    gnssEngine = gnssEngine,
                    searchEngine = searchEngine,
                    offlineMapManager = offlineMapManager,
                    db = db
                )
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        gnssEngine.stop()
        locationProvider.stopLocationUpdates()
        voiceGuidanceEngine.shutdown()
    }
}

@Composable
fun MainAppScreen(
    navigationEngine: NavigationEngine,
    gnssEngine: GnssEngine,
    searchEngine: SearchEngine,
    offlineMapManager: OfflineMapManager,
    db: NewtonDatabase
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var activeTab by remember { mutableStateOf(MainTab.HOME) }
    var distanceUnit by remember { mutableStateOf(DistanceUnit.MILES_FEET) }
    var isVoiceEnabled by remember { mutableStateOf(true) }

    // State flows
    val currentPosition by navigationEngine.locationProvider.currentPosition.collectAsState()
    val navState by navigationEngine.navState.collectAsState()
    val activeDestination by navigationEngine.activeDestination.collectAsState()
    val availableRoutes by navigationEngine.availableRoutes.collectAsState()
    val selectedRoute by navigationEngine.selectedRoute.collectAsState()
    val currentInstructionIndex by navigationEngine.currentInstructionIndex.collectAsState()
    val remainingDistanceMeters by navigationEngine.remainingDistanceMeters.collectAsState()
    val remainingDurationSeconds by navigationEngine.remainingDurationSeconds.collectAsState()
    val vehicleProfile by navigationEngine.vehicleProfile.collectAsState()

    val satellites by gnssEngine.satellites.collectAsState()
    val fixState by gnssEngine.fixState.collectAsState()
    val accuracyMeters by gnssEngine.accuracyMeters.collectAsState()

    val compassHeading by navigationEngine.locationProvider.sensorFusion.compassHeading.collectAsState()
    val pitch by navigationEngine.locationProvider.sensorFusion.pitch.collectAsState()
    val roll by navigationEngine.locationProvider.sensorFusion.roll.collectAsState()

    val isSimulating by navigationEngine.locationProvider.simulator.isSimulating.collectAsState()
    val simSpeedFactor by navigationEngine.locationProvider.simulator.speedFactor.collectAsState()
    val isSignalLossSimulated by navigationEngine.locationProvider.simulator.signalLossActive.collectAsState()

    val journeys by db.journeyDao().getAllJourneys().collectAsState(initial = emptyList())
    val savedPlaces by db.savedPlaceDao().getAllSavedPlaces().collectAsState(initial = emptyList())
    val offlineRegions by offlineMapManager.allRegions.collectAsState(initial = emptyList())
    val downloadProgress by offlineMapManager.downloadProgress.collectAsState()

    // Location Permission Request
    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            navigationEngine.locationProvider.startLocationUpdates()
        }
    }

    LaunchedEffect(Unit) {
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            permissionLauncher.launch(Manifest.permission.ACCESS_FINE_LOCATION)
        }
        offlineMapManager.seedDefaultRegions()
    }

    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .testTag("main_app_scaffold"),
        bottomBar = {
            if (navState != NavigationState.NAVIGATING &&
                navState != NavigationState.OFF_ROUTE &&
                navState != NavigationState.RECALCULATING &&
                navState != NavigationState.ESTIMATED_POSITION
            ) {
                NavigationBar(
                    containerColor = Color(0xFF0A121E),
                    contentColor = Color.White,
                    modifier = Modifier.testTag("aerospace_bottom_bar")
                ) {
                    NavigationBarItem(
                        selected = activeTab == MainTab.HOME,
                        onClick = { activeTab = MainTab.HOME },
                        icon = { Icon(Icons.Default.Map, contentDescription = "Nav") },
                        label = { Text("NAV", fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Color(0xFF00B0FF),
                            selectedTextColor = Color(0xFF00B0FF),
                            unselectedIconColor = Color.Gray,
                            unselectedTextColor = Color.Gray,
                            indicatorColor = Color(0xFF1B2735)
                        ),
                        modifier = Modifier.testTag("nav_tab_home")
                    )

                    NavigationBarItem(
                        selected = activeTab == MainTab.SATELLITE,
                        onClick = { activeTab = MainTab.SATELLITE },
                        icon = { Icon(Icons.Default.Radar, contentDescription = "Satellite") },
                        label = { Text("SATELLITE", fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Color(0xFF00B0FF),
                            selectedTextColor = Color(0xFF00B0FF),
                            unselectedIconColor = Color.Gray,
                            unselectedTextColor = Color.Gray,
                            indicatorColor = Color(0xFF1B2735)
                        ),
                        modifier = Modifier.testTag("nav_tab_satellite")
                    )

                    NavigationBarItem(
                        selected = activeTab == MainTab.COMPASS,
                        onClick = { activeTab = MainTab.COMPASS },
                        icon = { Icon(Icons.Default.Explore, contentDescription = "Compass") },
                        label = { Text("COMPASS", fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Color(0xFF00B0FF),
                            selectedTextColor = Color(0xFF00B0FF),
                            unselectedIconColor = Color.Gray,
                            unselectedTextColor = Color.Gray,
                            indicatorColor = Color(0xFF1B2735)
                        ),
                        modifier = Modifier.testTag("nav_tab_compass")
                    )

                    NavigationBarItem(
                        selected = activeTab == MainTab.JOURNEY,
                        onClick = { activeTab = MainTab.JOURNEY },
                        icon = { Icon(Icons.Default.History, contentDescription = "Journey") },
                        label = { Text("LOGS", fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Color(0xFF00B0FF),
                            selectedTextColor = Color(0xFF00B0FF),
                            unselectedIconColor = Color.Gray,
                            unselectedTextColor = Color.Gray,
                            indicatorColor = Color(0xFF1B2735)
                        ),
                        modifier = Modifier.testTag("nav_tab_journey")
                    )

                    NavigationBarItem(
                        selected = activeTab == MainTab.OFFLINE,
                        onClick = { activeTab = MainTab.OFFLINE },
                        icon = { Icon(Icons.Default.Download, contentDescription = "Offline") },
                        label = { Text("OFFLINE", fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Color(0xFF00B0FF),
                            selectedTextColor = Color(0xFF00B0FF),
                            unselectedIconColor = Color.Gray,
                            unselectedTextColor = Color.Gray,
                            indicatorColor = Color(0xFF1B2735)
                        ),
                        modifier = Modifier.testTag("nav_tab_offline")
                    )

                    NavigationBarItem(
                        selected = activeTab == MainTab.SETTINGS,
                        onClick = { activeTab = MainTab.SETTINGS },
                        icon = { Icon(Icons.Default.Settings, contentDescription = "Settings") },
                        label = { Text("CONFIG", fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Color(0xFF00B0FF),
                            selectedTextColor = Color(0xFF00B0FF),
                            unselectedIconColor = Color.Gray,
                            unselectedTextColor = Color.Gray,
                            indicatorColor = Color(0xFF1B2735)
                        ),
                        modifier = Modifier.testTag("nav_tab_settings")
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            if (navState == NavigationState.NAVIGATING ||
                navState == NavigationState.OFF_ROUTE ||
                navState == NavigationState.RECALCULATING ||
                navState == NavigationState.ESTIMATED_POSITION
            ) {
                LiveNavScreen(
                    currentPosition = currentPosition,
                    activeRoute = selectedRoute,
                    currentInstructionIndex = currentInstructionIndex,
                    remainingDistanceMeters = remainingDistanceMeters,
                    remainingDurationSeconds = remainingDurationSeconds,
                    navState = navState,
                    isVoiceEnabled = isVoiceEnabled,
                    onToggleVoice = {
                        isVoiceEnabled = !isVoiceEnabled
                        navigationEngine.voiceEngine.isEnabled = isVoiceEnabled
                    },
                    onTriggerOffRoute = {
                        navigationEngine.locationProvider.simulator.triggerOffRouteDeviation()
                    },
                    onStopNavigation = {
                        navigationEngine.stopNavigation()
                        navigationEngine.locationProvider.simulator.stopSimulation()
                        activeTab = MainTab.HOME
                    }
                )
            } else {
                when (activeTab) {
                    MainTab.HOME -> HomeScreen(
                        currentPosition = currentPosition,
                        vehicleProfile = vehicleProfile,
                        onVehicleProfileChange = { navigationEngine.setVehicleProfile(it) },
                        onSearchClick = { activeTab = MainTab.SEARCH },
                        onSelectQuickPlace = { searchRes ->
                            navigationEngine.selectDestination(searchRes)
                            activeTab = MainTab.DESTINATION
                        },
                        isSimulating = isSimulating,
                        onToggleSimulation = {
                            if (isSimulating) {
                                navigationEngine.locationProvider.simulator.stopSimulation()
                            } else {
                                navigationEngine.locationProvider.simulator.startSimulation()
                            }
                        }
                    )

                    MainTab.SEARCH -> SearchScreen(
                        searchEngine = searchEngine,
                        userLocation = GeoPoint(currentPosition.latitude, currentPosition.longitude),
                        onSelectDestination = { searchRes ->
                            navigationEngine.selectDestination(searchRes)
                            activeTab = MainTab.DESTINATION
                        },
                        onBackClick = { activeTab = MainTab.HOME }
                    )

                    MainTab.DESTINATION -> {
                        activeDestination?.let { dest ->
                            DestinationScreen(
                                destination = dest,
                                availableRoutes = availableRoutes,
                                selectedRoute = selectedRoute,
                                vehicleProfile = vehicleProfile,
                                onSelectRoute = { navigationEngine.setSelectedRoute(it) },
                                onStartNavigation = {
                                    if (!isSimulating) {
                                        // Auto start simulator if physical motion isn't detected
                                        val geom = selectedRoute?.geometry ?: navigationEngine.locationProvider.simulator.defaultPresetRoute
                                        navigationEngine.locationProvider.simulator.startSimulation(geom)
                                    }
                                    navigationEngine.startNavigation()
                                },
                                onBackClick = { activeTab = MainTab.HOME }
                            )
                        } ?: run {
                            activeTab = MainTab.HOME
                        }
                    }

                    MainTab.SATELLITE -> SatelliteScreen(
                        satellites = satellites,
                        fixState = fixState,
                        accuracyMeters = accuracyMeters
                    )

                    MainTab.COMPASS -> CompassScreen(
                        currentPosition = currentPosition,
                        compassHeading = compassHeading,
                        pitch = pitch,
                        roll = roll
                    )

                    MainTab.JOURNEY -> JourneyScreen(
                        journeys = journeys,
                        onClearHistory = {
                            scope.launch { db.journeyDao().clearHistory() }
                        }
                    )

                    MainTab.OFFLINE -> OfflineMapsScreen(
                        regions = offlineRegions,
                        downloadProgress = downloadProgress,
                        onDownloadRegion = { region ->
                            scope.launch { offlineMapManager.downloadRegion(region) }
                        },
                        onDeleteRegion = { region ->
                            scope.launch { offlineMapManager.deleteRegion(region) }
                        }
                    )

                    MainTab.SAVED -> SavedPlacesScreen(
                        savedPlaces = savedPlaces,
                        onSelectPlace = { place ->
                            navigationEngine.selectDestination(
                                SearchResult(
                                    id = place.id,
                                    name = place.name,
                                    category = place.placeType,
                                    latitude = place.latitude,
                                    longitude = place.longitude,
                                    address = place.address
                                )
                            )
                            activeTab = MainTab.DESTINATION
                        },
                        onDeletePlace = { place ->
                            scope.launch { db.savedPlaceDao().deleteSavedPlace(place) }
                        }
                    )

                    MainTab.SETTINGS -> SettingsScreen(
                        distanceUnit = distanceUnit,
                        onDistanceUnitChange = { distanceUnit = it },
                        isVoiceEnabled = isVoiceEnabled,
                        onVoiceToggle = {
                            isVoiceEnabled = it
                            navigationEngine.voiceEngine.isEnabled = it
                        },
                        simSpeedFactor = simSpeedFactor,
                        onSimSpeedChange = { navigationEngine.locationProvider.simulator.setSpeedFactor(it) },
                        isSignalLossSimulated = isSignalLossSimulated,
                        onToggleSignalLoss = { navigationEngine.locationProvider.simulator.toggleSignalLoss() },
                        onTriggerOffRoute = { navigationEngine.locationProvider.simulator.triggerOffRouteDeviation() }
                    )
                }
            }
        }
    }
}
