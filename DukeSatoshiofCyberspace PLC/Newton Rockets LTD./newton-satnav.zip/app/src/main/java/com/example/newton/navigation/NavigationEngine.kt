package com.example.newton.navigation

import com.example.newton.data.JourneyDao
import com.example.newton.domain.model.GeoPoint
import com.example.newton.domain.model.JourneyRecord
import com.example.newton.domain.model.NavigationInstruction
import com.example.newton.domain.model.NavigationPosition
import com.example.newton.domain.model.NavigationState
import com.example.newton.domain.model.Route
import com.example.newton.domain.model.SearchResult
import com.example.newton.domain.model.VehicleProfile
import com.example.newton.location.LocationProvider
import com.example.newton.routing.OffRouteDetector
import com.example.newton.routing.RoutingEngine
import com.example.newton.voice.VoiceGuidanceEngine
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class NavigationEngine(
    val locationProvider: LocationProvider,
    val routingEngine: RoutingEngine,
    val voiceEngine: VoiceGuidanceEngine,
    val journeyDao: JourneyDao
) {

    private val _navState = MutableStateFlow(NavigationState.READY)
    val navState: StateFlow<NavigationState> = _navState.asStateFlow()

    private val _activeDestination = MutableStateFlow<SearchResult?>(null)
    val activeDestination: StateFlow<SearchResult?> = _activeDestination.asStateFlow()

    private val _availableRoutes = MutableStateFlow<List<Route>>(emptyList())
    val availableRoutes: StateFlow<List<Route>> = _availableRoutes.asStateFlow()

    private val _selectedRoute = MutableStateFlow<Route?>(null)
    val selectedRoute: StateFlow<Route?> = _selectedRoute.asStateFlow()

    private val _currentInstructionIndex = MutableStateFlow(0)
    val currentInstructionIndex: StateFlow<Int> = _currentInstructionIndex.asStateFlow()

    private val _remainingDistanceMeters = MutableStateFlow(0.0)
    val remainingDistanceMeters: StateFlow<Double> = _remainingDistanceMeters.asStateFlow()

    private val _remainingDurationSeconds = MutableStateFlow(0L)
    val remainingDurationSeconds: StateFlow<Long> = _remainingDurationSeconds.asStateFlow()

    private val _vehicleProfile = MutableStateFlow(VehicleProfile.CAR)
    val vehicleProfile: StateFlow<VehicleProfile> = _vehicleProfile.asStateFlow()

    // Journey analytics tracking
    private var tripStartTimeMs = 0L
    private var maxSpeedMps = 0.0
    private var initialDistanceMeters = 0.0

    private var trackingJob: Job? = null
    private val scope = CoroutineScope(Dispatchers.Default)

    fun setVehicleProfile(profile: VehicleProfile) {
        _vehicleProfile.value = profile
        // Recalculate routes if active destination is set
        activeDestination.value?.let { dest ->
            selectDestination(dest)
        }
    }

    fun selectDestination(destination: SearchResult) {
        _activeDestination.value = destination
        _navState.value = NavigationState.SEARCHING

        scope.launch {
            val origin = GeoPoint(
                locationProvider.currentPosition.value.latitude,
                locationProvider.currentPosition.value.longitude
            )
            val destPt = GeoPoint(destination.latitude, destination.longitude)

            val routes = routingEngine.calculateRoutes(origin, destPt, vehicleProfile.value)
            _availableRoutes.value = routes
            if (routes.isNotEmpty()) {
                _selectedRoute.value = routes[0]
                _remainingDistanceMeters.value = routes[0].distanceMeters
                _remainingDurationSeconds.value = routes[0].durationSeconds
                _navState.value = NavigationState.READY
            } else {
                _navState.value = NavigationState.READY
            }
        }
    }

    fun setSelectedRoute(route: Route) {
        _selectedRoute.value = route
        _remainingDistanceMeters.value = route.distanceMeters
        _remainingDurationSeconds.value = route.durationSeconds
    }

    fun startNavigation() {
        val route = selectedRoute.value ?: return
        _navState.value = NavigationState.NAVIGATING
        _currentInstructionIndex.value = 0

        tripStartTimeMs = System.currentTimeMillis()
        maxSpeedMps = 0.0
        initialDistanceMeters = route.distanceMeters

        voiceEngine.speak("Starting navigation to ${activeDestination.value?.name ?: "destination"}. ${route.instructions.firstOrNull()?.instructionText ?: ""}", interrupt = true)

        startProgressTracking()
    }

    fun stopNavigation() {
        trackingJob?.cancel()
        _navState.value = NavigationState.READY
        voiceEngine.stop()
    }

    private fun startProgressTracking() {
        trackingJob?.cancel()
        trackingJob = scope.launch {
            while (_navState.value == NavigationState.NAVIGATING ||
                _navState.value == NavigationState.OFF_ROUTE ||
                _navState.value == NavigationState.RECALCULATING ||
                _navState.value == NavigationState.ESTIMATED_POSITION
            ) {
                delay(1000)

                val route = selectedRoute.value ?: continue
                val pos = locationProvider.currentPosition.value

                // Update signal/dead reckoning state indicator
                if (pos.isEstimated) {
                    if (_navState.value != NavigationState.ESTIMATED_POSITION) {
                        _navState.value = NavigationState.ESTIMATED_POSITION
                        voiceEngine.speak("GNSS signal degraded. Position estimated.")
                    }
                } else if (_navState.value == NavigationState.ESTIMATED_POSITION) {
                    _navState.value = NavigationState.NAVIGATING
                    voiceEngine.speak("Position reacquired.")
                }

                // Analytics
                pos.speedMetersPerSecond?.let { spd ->
                    if (spd > maxSpeedMps) maxSpeedMps = spd
                }

                // Check distance to destination arrival
                val destPt = GeoPoint(route.geometry.last().latitude, route.geometry.last().longitude)
                val distToDest = OffRouteDetector.distanceMeters(GeoPoint(pos.latitude, pos.longitude), destPt)

                if (distToDest < 25.0) {
                    handleArrival()
                    break
                }

                // Off-route detection
                val offRoute = OffRouteDetector.isOffRoute(pos, route)
                if (offRoute && _navState.value != NavigationState.RECALCULATING) {
                    _navState.value = NavigationState.OFF_ROUTE
                    triggerRecalculation(pos, destPt)
                    continue
                }

                // Calculate remaining distance along route polyline
                _remainingDistanceMeters.value = distToDest
                val speedMps = (pos.speedMetersPerSecond ?: 15.0).coerceAtLeast(3.0)
                _remainingDurationSeconds.value = (distToDest / speedMps).toLong()

                // Advance instruction steps
                val currentIdx = _currentInstructionIndex.value
                if (currentIdx < route.instructions.size - 1) {
                    val nextInstruction = route.instructions[currentIdx + 1]
                    val distToNextManeuver = OffRouteDetector.distanceMeters(
                        GeoPoint(pos.latitude, pos.longitude),
                        nextInstruction.targetGeoPoint
                    )

                    if (distToNextManeuver < 50.0) {
                        _currentInstructionIndex.value = currentIdx + 1
                        voiceEngine.speak(nextInstruction.instructionText, interrupt = true)
                    } else if (distToNextManeuver in 250.0..320.0) {
                        voiceEngine.speak(nextInstruction.instructionText)
                    }
                }
            }
        }
    }

    private fun triggerRecalculation(currentPos: NavigationPosition, destinationPt: GeoPoint) {
        _navState.value = NavigationState.RECALCULATING
        voiceEngine.speak("Route changed. Recalculating…", interrupt = true)

        scope.launch {
            val origin = GeoPoint(currentPos.latitude, currentPos.longitude)
            val newRoutes = routingEngine.calculateRoutes(origin, destinationPt, vehicleProfile.value)

            if (newRoutes.isNotEmpty()) {
                _availableRoutes.value = newRoutes
                _selectedRoute.value = newRoutes[0]
                _currentInstructionIndex.value = 0
                _navState.value = NavigationState.NAVIGATING
                voiceEngine.speak("New route calculated. ${newRoutes[0].instructions.firstOrNull()?.instructionText ?: ""}")
            } else {
                _navState.value = NavigationState.NAVIGATING
            }
        }
    }

    private fun handleArrival() {
        _navState.value = NavigationState.ARRIVED
        voiceEngine.speak("You have arrived at your destination.", interrupt = true)

        val durationMinutes = ((System.currentTimeMillis() - tripStartTimeMs) / 60000).coerceAtLeast(1)
        val distMiles = (initialDistanceMeters * 0.000621371)
        val maxMph = maxSpeedMps * 2.23694
        val avgMph = if (durationMinutes > 0) (distMiles / (durationMinutes / 60.0)) else 0.0

        val destName = activeDestination.value?.name ?: "Target Location"

        scope.launch {
            journeyDao.insertJourney(
                JourneyRecord(
                    originName = "Departure HQ",
                    destinationName = destName,
                    distanceMiles = distMiles,
                    durationMinutes = durationMinutes,
                    avgSpeedMph = avgMph,
                    maxSpeedMph = maxMph,
                    elevationGainMeters = 42.0
                )
            )
        }
    }
}
