package com.example.newton.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.newton.domain.model.JourneyRecord
import com.example.newton.domain.model.OfflineRegion
import com.example.newton.domain.model.SavedPlace

@Database(
    entities = [SavedPlace::class, JourneyRecord::class, OfflineRegion::class],
    version = 1,
    exportSchema = false
)
abstract class NewtonDatabase : RoomDatabase() {
    abstract fun savedPlaceDao(): SavedPlaceDao
    abstract fun journeyDao(): JourneyDao
    abstract fun offlineRegionDao(): OfflineRegionDao

    companion object {
        @Volatile
        private var INSTANCE: NewtonDatabase? = null

        fun getDatabase(context: Context): NewtonDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    NewtonDatabase::class.java,
                    "newton_satnav.db"
                ).build()
                INSTANCE = instance
                instance
            }
        }
    }
}
