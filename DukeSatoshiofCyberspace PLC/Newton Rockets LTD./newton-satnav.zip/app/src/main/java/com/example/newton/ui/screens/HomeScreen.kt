package com.example.newton.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DirectionsBike
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.DirectionsWalk
import androidx.compose.material.icons.filled.ElectricCar
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.LocalShipping
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.Navigation
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Radar
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Work
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.newton.domain.model.NavigationPosition
import com.example.newton.domain.model.SearchResult
import com.example.newton.domain.model.VehicleProfile

@Composable
fun HomeScreen(
    currentPosition: NavigationPosition,
    vehicleProfile: VehicleProfile,
    onVehicleProfileChange: (VehicleProfile) -> Unit,
    onSearchClick: () -> Unit,
    onSelectQuickPlace: (SearchResult) -> Unit,
    isSimulating: Boolean,
    onToggleSimulation: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(20.dp)
        ) {
            Spacer(modifier = Modifier.height(36.dp))

            // Newton Aerospace Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "NEWTON",
                        style = MaterialTheme.typography.headlineLarge.copy(
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 4.sp,
                            fontFamily = FontFamily.Monospace
                        ),
                        color = MaterialTheme.colorScheme.onBackground
                    )
                    Text(
                        text = "NEWTON ROCKETS LTD. — SATNAV",
                        style = MaterialTheme.typography.labelSmall.copy(
                            letterSpacing = 1.5.sp,
                            fontFamily = FontFamily.Monospace
                        ),
                        color = Color(0xFF00B0FF)
                    )
                }

                // Simulation Mode Toggle Chip
                Surface(
                    onClick = onToggleSimulation,
                    shape = RoundedCornerShape(20.dp),
                    color = if (isSimulating) Color(0xFFFFB300) else Color(0xFF1B2735),
                    modifier = Modifier.testTag("sim_toggle_chip")
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = if (isSimulating) Icons.Default.Stop else Icons.Default.PlayArrow,
                            contentDescription = "Simulate",
                            tint = if (isSimulating) Color.Black else Color.White,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = if (isSimulating) "SIM ACTIVE" else "DEV SIM",
                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                            color = if (isSimulating) Color.Black else Color.White
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(28.dp))

            // Prominent "Where to?" Search Field
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onSearchClick() }
                    .testTag("where_to_search_box"),
                shape = RoundedCornerShape(16.dp),
                color = MaterialTheme.colorScheme.surfaceVariant,
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF00B0FF).copy(alpha = 0.4f))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 18.dp, vertical = 18.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Search,
                        contentDescription = "Search",
                        tint = Color(0xFF00B0FF),
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(14.dp))
                    Text(
                        text = "Where to?",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Medium,
                            fontSize = 18.sp
                        ),
                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                    )
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Vehicle Profile Selector
            Text(
                text = "VEHICLE PROFILE",
                style = MaterialTheme.typography.labelMedium.copy(
                    letterSpacing = 1.2.sp,
                    fontFamily = FontFamily.Monospace
                ),
                color = MaterialTheme.colorScheme.outline
            )
            Spacer(modifier = Modifier.height(8.dp))
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(VehicleProfile.entries.toTypedArray()) { profile ->
                    val isSelected = profile == vehicleProfile
                    Surface(
                        onClick = { onVehicleProfileChange(profile) },
                        shape = RoundedCornerShape(12.dp),
                        color = if (isSelected) Color(0xFF1E88E5) else Color(0xFF1B2735),
                        modifier = Modifier.testTag("vehicle_profile_${profile.name}")
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            val icon = when (profile) {
                                VehicleProfile.CAR -> Icons.Default.DirectionsCar
                                VehicleProfile.ELECTRIC_VEHICLE -> Icons.Default.ElectricCar
                                VehicleProfile.HEAVY_GOODS -> Icons.Default.LocalShipping
                                VehicleProfile.BICYCLE -> Icons.Default.DirectionsBike
                                VehicleProfile.PEDESTRIAN -> Icons.Default.DirectionsWalk
                            }
                            Icon(
                                imageVector = icon,
                                contentDescription = profile.displayName,
                                tint = if (isSelected) Color.White else Color.Gray,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = profile.displayName,
                                style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Medium),
                                color = if (isSelected) Color.White else Color.Gray
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Quick Actions & Saved Shortcuts
            Text(
                text = "SAVED & RECENT PLACES",
                style = MaterialTheme.typography.labelMedium.copy(
                    letterSpacing = 1.2.sp,
                    fontFamily = FontFamily.Monospace
                ),
                color = MaterialTheme.colorScheme.outline
            )
            Spacer(modifier = Modifier.height(10.dp))

            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                QuickPlaceRow(
                    title = "Home",
                    subtitle = "Sheffield City Centre, S1 2HH",
                    icon = Icons.Default.Home,
                    testTag = "quick_place_home",
                    onClick = {
                        onSelectQuickPlace(
                            SearchResult(
                                id = "qp_home",
                                name = "Home (Sheffield)",
                                category = "Saved Home",
                                latitude = 53.3811,
                                longitude = -1.4701,
                                address = "Sheffield City Centre, S1 2HH"
                            )
                        )
                    }
                )

                QuickPlaceRow(
                    title = "Work",
                    subtitle = "Leeds City Station, LS1 4DY",
                    icon = Icons.Default.Work,
                    testTag = "quick_place_work",
                    onClick = {
                        onSelectQuickPlace(
                            SearchResult(
                                id = "qp_work",
                                name = "Leeds Station",
                                category = "Saved Work",
                                latitude = 53.7952,
                                longitude = -1.5481,
                                address = "New Station St, Leeds, LS1 4DY"
                            )
                        )
                    }
                )

                QuickPlaceRow(
                    title = "Recent: Manchester Piccadilly",
                    subtitle = "Piccadilly Station, Manchester, M1 2PB",
                    icon = Icons.Default.History,
                    testTag = "quick_place_manchester",
                    onClick = {
                        onSelectQuickPlace(
                            SearchResult(
                                id = "qp_manchester",
                                name = "Manchester Piccadilly",
                                category = "Recent Destination",
                                latitude = 53.4774,
                                longitude = -2.2309,
                                address = "Piccadilly Station, Manchester, M1 2PB"
                            )
                        )
                    }
                )

                QuickPlaceRow(
                    title = "Saved: Heathrow Airport",
                    subtitle = "Longford, Hounslow, TW6 1AP",
                    icon = Icons.Default.Star,
                    testTag = "quick_place_heathrow",
                    onClick = {
                        onSelectQuickPlace(
                            SearchResult(
                                id = "qp_heathrow",
                                name = "Heathrow Airport (LHR)",
                                category = "Saved Place",
                                latitude = 51.4700,
                                longitude = -0.4543,
                                address = "Longford, Hounslow, TW6 1AP"
                            )
                        )
                    }
                )
            }

            Spacer(modifier = Modifier.weight(1f))

            // GNSS Live Position Status Telemetry Card
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("gnss_status_card"),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF15202B)),
                shape = RoundedCornerShape(16.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF263238))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(10.dp)
                                .clip(CircleShape)
                                .background(if (currentPosition.isEstimated) Color(0xFFFFB300) else Color(0xFF26A69A))
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = if (currentPosition.isEstimated) "GNSS ESTIMATED" else "GNSS 3D FIX",
                                style = MaterialTheme.typography.labelMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace
                                ),
                                color = Color.White
                            )
                            Text(
                                text = "ACCURACY: ±${String.format("%.1f", currentPosition.accuracyMeters)}m • ALT: ${currentPosition.altitudeMeters?.toInt() ?: 82}m",
                                style = MaterialTheme.typography.labelSmall.copy(fontFamily = FontFamily.Monospace),
                                color = Color.Gray
                            )
                        }
                    }

                    Text(
                        text = "${String.format("%.4f", currentPosition.latitude)}, ${String.format("%.4f", currentPosition.longitude)}",
                        style = MaterialTheme.typography.labelSmall.copy(fontFamily = FontFamily.Monospace),
                        color = Color(0xFF00B0FF)
                    )
                }
            }
        }
    }
}

@Composable
private fun QuickPlaceRow(
    title: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    testTag: String,
    onClick: () -> Unit
) {
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(12.dp),
        color = Color(0xFF1B2735),
        modifier = Modifier
            .fillMaxWidth()
            .testTag(testTag)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(Color(0xFF0A121E)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = title,
                    tint = Color(0xFF00B0FF),
                    modifier = Modifier.size(20.dp)
                )
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column {
                Text(
                    text = title,
                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold),
                    color = Color.White
                )
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = Color.Gray
                )
            }
        }
    }
}
