package com.example.newton.offline

import com.example.newton.data.OfflineRegionDao
import com.example.newton.domain.model.OfflineRegion
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext

class OfflineMapManager(private val dao: OfflineRegionDao) {

    val allRegions: Flow<List<OfflineRegion>> = dao.getAllOfflineRegions()

    private val _downloadProgress = MutableStateFlow<Map<String, Float>>(emptyMap())
    val downloadProgress: StateFlow<Map<String, Float>> = _downloadProgress.asStateFlow()

    suspend fun seedDefaultRegions() {
        val defaults = listOf(
            OfflineRegion(
                regionId = "uk_all",
                name = "United Kingdom (Core Vector)",
                minLat = 49.8, maxLat = 60.8,
                minLon = -8.1, maxLon = 1.8,
                sizeMb = 48.5, tileCount = 14200,
                isDownloaded = true,
                downloadTimestamp = System.currentTimeMillis() - 86400000
            ),
            OfflineRegion(
                regionId = "uk_yorkshire",
                name = "Yorkshire & Humber",
                minLat = 53.3, maxLat = 54.5,
                minLon = -2.5, maxLon = 0.2,
                sizeMb = 18.2, tileCount = 5800,
                isDownloaded = true,
                downloadTimestamp = System.currentTimeMillis() - 43200000
            ),
            OfflineRegion(
                regionId = "uk_london",
                name = "Greater London",
                minLat = 51.2, maxLat = 51.7,
                minLon = -0.5, maxLon = 0.3,
                sizeMb = 24.6, tileCount = 8200,
                isDownloaded = false
            ),
            OfflineRegion(
                regionId = "uk_manchester",
                name = "Greater Manchester & North West",
                minLat = 53.2, maxLat = 53.9,
                minLon = -2.8, maxLon = -1.8,
                sizeMb = 15.4, tileCount = 4900,
                isDownloaded = false
            )
        )

        for (region in defaults) {
            dao.insertOfflineRegion(region)
        }
    }

    suspend fun downloadRegion(region: OfflineRegion) = withContext(Dispatchers.IO) {
        val currentProgress = _downloadProgress.value.toMutableMap()
        for (step in 1..10) {
            delay(150)
            currentProgress[region.regionId] = step / 10f
            _downloadProgress.value = currentProgress.toMap()
        }

        dao.updateDownloadState(region.regionId, downloaded = true, timestamp = System.currentTimeMillis())
        val updatedMap = _downloadProgress.value.toMutableMap()
        updatedMap.remove(region.regionId)
        _downloadProgress.value = updatedMap
    }

    suspend fun deleteRegion(region: OfflineRegion) = withContext(Dispatchers.IO) {
        dao.updateDownloadState(region.regionId, downloaded = false, timestamp = 0)
    }
}
