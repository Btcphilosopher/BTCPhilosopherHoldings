package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val NewtonDarkColorScheme = darkColorScheme(
    primary = NewtonElectricBlue,
    onPrimary = Color.Black,
    primaryContainer = NewtonBlue,
    onPrimaryContainer = Color.White,
    secondary = NewtonAmber,
    onSecondary = Color.Black,
    background = NewtonDeepNavy,
    onBackground = NewtonWarmWhite,
    surface = NewtonGraphite,
    onSurface = NewtonWarmWhite,
    surfaceVariant = NewtonCardBg,
    onSurfaceVariant = NewtonPaleStone,
    outline = NewtonMuted
)

private val NewtonLightColorScheme = lightColorScheme(
    primary = NewtonBlue,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFD0E4F7),
    onPrimaryContainer = NewtonDeepNavy,
    secondary = NewtonAmber,
    onSecondary = Color.Black,
    background = NewtonWarmWhite,
    onBackground = NewtonDeepNavy,
    surface = Color.White,
    onSurface = NewtonDeepNavy,
    surfaceVariant = NewtonPaleStone,
    onSurfaceVariant = NewtonGraphite,
    outline = NewtonMuted
)

@Composable
fun NewtonSatNavTheme(
    darkTheme: Boolean = true, // Default to Aerospace Instrument Dark Theme
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) NewtonDarkColorScheme else NewtonLightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}

// Backwards compatibility wrapper for template references
@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true,
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    NewtonSatNavTheme(darkTheme = darkTheme, content = content)
}
