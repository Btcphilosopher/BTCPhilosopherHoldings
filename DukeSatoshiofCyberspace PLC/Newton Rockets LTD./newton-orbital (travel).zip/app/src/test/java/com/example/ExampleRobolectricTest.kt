package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.simulation.*
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `read string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("Newton Orbital", appName)
    }

    @Test
    fun `validate great circle distance calculations`() {
        // Analytical check: London (51.5074, -0.1278) to New York (40.7128, -74.0060) is approx 5570 km
        val distM = TrajectoryEngine.calculateGreatCircleDistanceM(
            51.5074, -0.1278,
            40.7128, -74.0060
        )
        val distKm = distM / 1000.0

        // Allow 2% discrepancy due to spheroid approximations vs simple sphere radius of 6371km
        assertTrue("Distance should be approximately 5570 km", distKm in 5400.0..5700.0)
    }

    @Test
    fun `validate physical simulation engine trajectory boundary limits`() {
        val vehicle = FleetRegistry.vehicles[2] // Newton OX-7 Heavy Passenger Cruiser
        val steps = TrajectoryEngine.runFullTrajectorySimulation(
            51.5074, -0.1278, // London LSP
            40.7128, -74.0060, // New York NSP
            vehicle
        )

        assertFalse("Trajectory steps should not be empty", steps.isEmpty())

        // Check starting state
        val startStep = steps.first()
        assertEquals(0.0, startStep.altitudeM, 0.01)
        assertEquals(0.0, startStep.velocityMs, 0.01)
        assertEquals(vehicle.propellantCapacityKg, startStep.propellantMassKg, 0.01)

        // Check end state
        val finalStep = steps.last()
        assertEquals(0.0, finalStep.altitudeM, 0.01)
        assertEquals(0.0, finalStep.velocityMs, 0.01)
        assertEquals(MissionPhase.COMPLETED, finalStep.phase)

        // Propellant depletion constraint check
        assertTrue("Propellant should have been consumed during ascent/landing", finalStep.propellantMassKg < vehicle.propellantCapacityKg)
        assertTrue("Propellant cannot go negative", finalStep.propellantMassKg >= 0.0)

        // Verification of conservation indices: Total mass must match dry mass + remaining fuel
        steps.forEach { step ->
            val expectedMass = vehicle.dryMassKg + step.propellantMassKg
            assertEquals("Total mass must conserve", expectedMass, step.totalMassKg, 0.01)
        }
    }
}
