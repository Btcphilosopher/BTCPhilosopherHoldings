package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.simulation.*
import com.example.ui.AppScreen
import com.example.ui.MainViewModel
import com.example.ui.components.MissionMapCanvas
import com.example.ui.components.TelemetryChartCanvas
import java.util.Locale
import kotlin.math.roundToInt

@Composable
fun OperationsCenterScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val missions by viewModel.missions.collectAsState()
    val activeId by viewModel.activeTrackingMissionId.collectAsState()
    val currentMission = remember(missions, activeId) { missions.find { it.id == activeId } }

    var tabState by remember { mutableStateOf(0) } // 0: Live Telemetry Twin, 1: Active Mission Grid

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        // Operations Center Title
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text("NEWTON ROCKETS LTD.", fontSize = 11.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, color = MaterialTheme.colorScheme.primary)
                Text("GLOBAL MISSION COMMAND", fontSize = 20.sp, fontWeight = FontWeight.Bold)
            }

            Badge(containerColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.2f)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Box(modifier = Modifier.size(6.dp).clip(RoundedCornerShape(50)).background(Color(0xFF10B981)))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("ONLINE", fontSize = 10.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, color = Color(0xFF10B981))
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Dual tabs
        TabRow(selectedTabIndex = tabState, containerColor = Color.Transparent) {
            Tab(selected = tabState == 0, onClick = { tabState = 0 }) {
                Text("DIGITAL TWIN TRACKER", modifier = Modifier.padding(vertical = 10.dp), fontWeight = FontWeight.Bold, fontSize = 13.sp)
            }
            Tab(selected = tabState == 1, onClick = { tabState = 1 }) {
                Text("NETWORK REGISTRY (${missions.size})", modifier = Modifier.padding(vertical = 10.dp), fontWeight = FontWeight.Bold, fontSize = 13.sp)
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        if (tabState == 0) {
            if (currentMission == null) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("NO TARGET MISSION ACTIVE. SELECT AN INSTANCE IN THE REGISTRY.", textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.secondary)
                }
            } else {
                val currentStep = currentMission.currentTelemetry
                val allSteps = currentMission.telemetrySteps

                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(16.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    // Mission Header Profile
                    item {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text("TARGET OBJECT ID", fontSize = 9.sp, color = MaterialTheme.colorScheme.secondary, fontFamily = FontFamily.Monospace)
                                        Text(currentMission.id, fontSize = 18.sp, fontWeight = FontWeight.ExtraBold, fontFamily = FontFamily.Monospace, color = MaterialTheme.colorScheme.primary)
                                    }
                                    Column(horizontalAlignment = Alignment.End) {
                                        Text("CURRENT STATUS", fontSize = 9.sp, color = MaterialTheme.colorScheme.secondary, fontFamily = FontFamily.Monospace)
                                        Text(currentMission.status.name, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Color(0xFF10B981), fontFamily = FontFamily.Monospace)
                                    }
                                }

                                Divider(modifier = Modifier.padding(vertical = 8.dp))

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text("CORRIDOR: ${currentMission.route.origin.code} → ${currentMission.route.destination.code}", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                                    Text("VEHICLE: ${currentMission.route.allocatedVehicle.name}", fontSize = 13.sp, fontFamily = FontFamily.Monospace, color = MaterialTheme.colorScheme.secondary)
                                }
                            }
                        }
                    }

                    // 2D Earth Vector Map Canvas
                    item {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                        ) {
                            Column(modifier = Modifier.padding(8.dp)) {
                                Text("   SUBORBITAL FLIGHT TRACK (EARTH PROJECTION)", fontSize = 10.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, color = MaterialTheme.colorScheme.secondary)
                                Spacer(modifier = Modifier.height(4.dp))
                                MissionMapCanvas(
                                    currentStep = currentStep,
                                    allSteps = allSteps,
                                    originCode = currentMission.route.origin.code,
                                    destCode = currentMission.route.destination.code
                                )
                            }
                        }
                    }

                    // Live numerical telemetry variables grid
                    item {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Text("LIVE TELEMETRY ARRAY", fontSize = 11.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, color = MaterialTheme.colorScheme.secondary)
                                Spacer(modifier = Modifier.height(10.dp))

                                Row(modifier = Modifier.fillMaxWidth()) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text("ALTITUDE", fontSize = 9.sp, color = MaterialTheme.colorScheme.secondary)
                                        Text(String.format(Locale.US, "%,.1f KM", (currentStep?.altitudeM ?: 0.0) / 1000.0), fontSize = 16.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                                    }
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text("VELOCITY", fontSize = 9.sp, color = MaterialTheme.colorScheme.secondary)
                                        Text(String.format(Locale.US, "%,.0f M/S", currentStep?.velocityMs ?: 0.0), fontSize = 16.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, color = Color(0xFF06B6D4))
                                    }
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text("G-FORCE", fontSize = 9.sp, color = MaterialTheme.colorScheme.secondary)
                                        Text(String.format(Locale.US, "%.2f G", currentStep?.accelerationG ?: 1.0), fontSize = 16.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                                    }
                                }

                                Spacer(modifier = Modifier.height(12.dp))

                                Row(modifier = Modifier.fillMaxWidth()) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text("PROPELLANT WT", fontSize = 9.sp, color = MaterialTheme.colorScheme.secondary)
                                        Text(String.format(Locale.US, "%,.0f KG", currentStep?.propellantMassKg ?: 0.0), fontSize = 14.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, color = MaterialTheme.colorScheme.primary)
                                    }
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text("THRUST FORCE", fontSize = 9.sp, color = MaterialTheme.colorScheme.secondary)
                                        Text(String.format(Locale.US, "%,.0f KN", (currentStep?.thrustN ?: 0.0) / 1000.0), fontSize = 14.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                                    }
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text("ATMOS DRAG", fontSize = 9.sp, color = MaterialTheme.colorScheme.secondary)
                                        Text(String.format(Locale.US, "%,.0f N", currentStep?.dragN ?: 0.0), fontSize = 14.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                                    }
                                }
                            }
                        }
                    }

                    // Altitude/Speed profiles curves
                    item {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                        ) {
                            Column(modifier = Modifier.padding(10.dp)) {
                                Text(" ALTITUDE (RED) & VELOCITY (CYAN) OVER TIME", fontSize = 10.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, color = MaterialTheme.colorScheme.secondary)
                                Spacer(modifier = Modifier.height(6.dp))
                                TelemetryChartCanvas(currentStep = currentStep, allSteps = allSteps)
                            }
                        }
                    }

                    // Numerical Integration differential equations steps
                    item {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text("DIFFERENTIAL EQUATIONS NUMERICAL INTEGRATION LOGS", fontSize = 10.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, color = MaterialTheme.colorScheme.secondary)
                                }
                                Spacer(modifier = Modifier.height(10.dp))

                                // Show some rows of steps before and after current
                                val currentIndex = currentMission.currentStepIndex
                                val logSteps = allSteps.filterIndexed { index, _ ->
                                    index in (currentIndex - 2)..(currentIndex + 4)
                                }

                                logSteps.forEach { step ->
                                    val isCurrent = step.timeSec == currentStep?.timeSec
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .background(if (isCurrent) MaterialTheme.colorScheme.primary.copy(alpha = 0.12f) else Color.Transparent)
                                            .padding(vertical = 4.dp, horizontal = 6.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text(String.format(Locale.US, "t=%04ds", step.timeSec.toInt()), fontSize = 11.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                                        Text(step.phase.name, fontSize = 11.sp, fontFamily = FontFamily.Monospace, color = MaterialTheme.colorScheme.primary)
                                        Text(String.format(Locale.US, "Alt:%,.1fkm", step.altitudeM / 1000.0), fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                                        Text(String.format(Locale.US, "Vel:%,.0fm/s", step.velocityMs), fontSize = 11.sp, fontFamily = FontFamily.Monospace, color = Color(0xFF06B6D4))
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } else {
            // Missions Registry list
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(missions) { m ->
                    val isSelected = m.id == activeId
                    Card(
                        colors = CardDefaults.cardColors(
                            containerColor = if (isSelected) MaterialTheme.colorScheme.primary.copy(alpha = 0.08f) else MaterialTheme.colorScheme.surface
                        ),
                        border = BorderStroke(
                            if (isSelected) 1.5.dp else 1.dp,
                            if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { viewModel.selectActiveMissionForTracking(m.id, AppScreen.OPERATIONS_CENTER) }
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.RocketLaunch, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(20.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(m.id, fontWeight = FontWeight.ExtraBold, fontSize = 16.sp, fontFamily = FontFamily.Monospace)
                                }

                                Badge(
                                    containerColor = if (m.status == MissionPhase.PRE_LAUNCH) MaterialTheme.colorScheme.surfaceVariant else Color(0xFF10B981)
                                ) {
                                    Text(" " + m.status.name + " ", fontSize = 10.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                                }
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("${m.route.origin.code} → ${m.route.destination.code}", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                Text("${m.passengers} Passengers  |  ${String.format(Locale.US, "%,.0f KG Cargo", m.cargoWeightKg)}", fontSize = 12.sp, color = MaterialTheme.colorScheme.secondary)
                            }

                            if (m.status == MissionPhase.PRE_LAUNCH) {
                                Spacer(modifier = Modifier.height(12.dp))
                                Button(
                                    onClick = { viewModel.triggerPrelaunchToAscent(m.id) },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(42.dp)
                                        .testTag("launch_mission_button")
                                ) {
                                    Icon(Icons.Default.PlayArrow, contentDescription = null)
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("INITIATE COUNTDOWN & LAUNCH", fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SpaceportsDashboardScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val spaceports by viewModel.spaceports.collectAsState()
    var selectedPortId by remember { mutableStateOf("SP-LSP") }
    val currentPort = remember(spaceports, selectedPortId) { spaceports.find { it.id == selectedPortId } }

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Text("NEWTON OPERATING LAYER", fontSize = 11.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, color = MaterialTheme.colorScheme.secondary)
        Text("SPACEPORT INFRASTRUCTURE", fontSize = 20.sp, fontWeight = FontWeight.Bold)

        Spacer(modifier = Modifier.height(16.dp))

        // Spaceports Quick Horizontal Row
        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            items(spaceports) { port ->
                val isSelected = port.id == selectedPortId
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant
                    ),
                    modifier = Modifier.clickable { selectedPortId = port.id }
                ) {
                    Text(
                        text = port.code,
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                        fontWeight = FontWeight.Bold,
                        color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurfaceVariant,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        if (currentPort != null) {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(16.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                // Core specifications
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text(currentPort.name, fontWeight = FontWeight.ExtraBold, fontSize = 18.sp)
                            Text("${currentPort.country}  |  TZ: ${currentPort.timezone}", fontSize = 12.sp, color = MaterialTheme.colorScheme.secondary)

                            Divider(modifier = Modifier.padding(vertical = 12.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column {
                                    Text("COORDINATES", fontSize = 9.sp, color = MaterialTheme.colorScheme.secondary)
                                    Text(String.format(Locale.US, "%.4f, %.4f", currentPort.latitude, currentPort.longitude), fontSize = 14.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                                }
                                Column {
                                    Text("TURNAROUND CYCLE", fontSize = 9.sp, color = MaterialTheme.colorScheme.secondary)
                                    Text("${currentPort.turnaroundCapacity} Hours", fontSize = 14.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                                }
                                Column {
                                    Text("STATUS", fontSize = 9.sp, color = MaterialTheme.colorScheme.secondary)
                                    Text(currentPort.status.name, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Color(0xFF10B981), fontFamily = FontFamily.Monospace)
                                }
                            }
                        }
                    }
                }

                // Pads allocation
                item {
                    Text("ACTIVE LAUNCH PADS Turnaround Metrics", fontSize = 12.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                }

                items(currentPort.activePads) { pad ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(10.dp)
                                        .clip(RoundedCornerShape(50))
                                        .background(
                                            when (pad.state) {
                                                PadState.READY -> Color(0xFF10B981)
                                                PadState.TURNAROUND -> Color(0xFFF59E0B)
                                                else -> Color(0xFFEF4444)
                                            }
                                        )
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Column {
                                    Text(pad.name, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                                    Text("Mission Allocation: ${pad.currentMissionId}", fontSize = 11.sp, color = MaterialTheme.colorScheme.secondary, fontFamily = FontFamily.Monospace)
                                }
                            }

                            Badge(
                                containerColor = MaterialTheme.colorScheme.surfaceVariant
                            ) {
                                Text("  " + pad.state.name + "  ", fontSize = 10.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun FleetManagementScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val vehicles by viewModel.vehicles.collectAsState()

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text("NEWTON AEROSPACE ARCHITECTURE", fontSize = 11.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, color = MaterialTheme.colorScheme.secondary)
            Text("FLEET ALLOCATION & SPECIFICATIONS", fontSize = 20.sp, fontWeight = FontWeight.Bold)
        }

        items(vehicles) { v ->
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    // Header name and status
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(v.name, fontWeight = FontWeight.ExtraBold, fontSize = 18.sp, fontFamily = FontFamily.Monospace)
                            Text(v.type, fontSize = 12.sp, color = MaterialTheme.colorScheme.secondary)
                        }

                        Badge(
                            containerColor = when (v.status) {
                                VehicleStatus.AVAILABLE -> Color(0xFF10B981).copy(alpha = 0.15f)
                                VehicleStatus.IN_FLIGHT -> Color(0xFF3B82F6).copy(alpha = 0.15f)
                                VehicleStatus.TURNAROUND -> Color(0xFFF59E0B).copy(alpha = 0.15f)
                                VehicleStatus.MAINTENANCE -> Color(0xFFEF4444).copy(alpha = 0.15f)
                            },
                            contentColor = when (v.status) {
                                VehicleStatus.AVAILABLE -> Color(0xFF10B981)
                                VehicleStatus.IN_FLIGHT -> Color(0xFF3B82F6)
                                VehicleStatus.TURNAROUND -> Color(0xFFF59E0B)
                                VehicleStatus.MAINTENANCE -> Color(0xFFEF4444)
                            }
                        ) {
                            Text("  " + v.status.name + "  ", fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, fontSize = 10.sp)
                        }
                    }

                    Divider(modifier = Modifier.padding(vertical = 12.dp))

                    // Physical specifications grid
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("DRY MASS", fontSize = 8.sp, color = MaterialTheme.colorScheme.secondary)
                            Text(String.format(Locale.US, "%,.0f KG", v.dryMassKg), fontSize = 13.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                        }
                        Column {
                            Text("FUEL CAPACITY", fontSize = 8.sp, color = MaterialTheme.colorScheme.secondary)
                            Text(String.format(Locale.US, "%,.0f KG", v.propellantCapacityKg), fontSize = 13.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                        }
                        Column {
                            Text("THRUST FORCE", fontSize = 8.sp, color = MaterialTheme.colorScheme.secondary)
                            Text(String.format(Locale.US, "%,.1f MN", v.thrustN / 1e6), fontSize = 13.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("SPECIFIC IMPULSE", fontSize = 8.sp, color = MaterialTheme.colorScheme.secondary)
                            Text("${v.ispSeconds} SEC", fontSize = 13.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                        }
                        Column {
                            Text("MAX ALTITUDE", fontSize = 8.sp, color = MaterialTheme.colorScheme.secondary)
                            Text("${v.maxAltitudeKm} KM", fontSize = 13.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                        }
                        Column {
                            Text("LIFETIME FLIGHTS", fontSize = 8.sp, color = MaterialTheme.colorScheme.secondary)
                            Text("${v.lifetimeMissions}", fontSize = 13.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun WeatherMonitorScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val spaceports by viewModel.spaceports.collectAsState()

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text("NEWTON ENVIRONMENTAL TELEMETRY", fontSize = 11.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, color = MaterialTheme.colorScheme.secondary)
            Text("GLOBAL SPACEPORT SENSOR ARRAY", fontSize = 20.sp, fontWeight = FontWeight.Bold)
        }

        items(spaceports) { port ->
            val weather = remember(port.code) { WeatherSimulator.generateWeather(port.code) }

            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(port.code, fontWeight = FontWeight.Bold, fontSize = 16.sp, fontFamily = FontFamily.Monospace, color = MaterialTheme.colorScheme.primary)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(port.name.replace("Newton ", ""), fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                        }

                        Badge(
                            containerColor = when (weather.status) {
                                WeatherStatus.GREEN -> Color(0xFF10B981)
                                WeatherStatus.AMBER -> Color(0xFFF59E0B)
                                WeatherStatus.RED -> Color(0xFFEF4444)
                            },
                            contentColor = Color.White
                        ) {
                            Text(" " + weather.status.name + " ", fontSize = 10.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                        }
                    }

                    Divider(modifier = Modifier.padding(vertical = 10.dp), color = MaterialTheme.colorScheme.outline.copy(alpha = 0.5f))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("SURFACE WIND", fontSize = 8.sp, color = MaterialTheme.colorScheme.secondary)
                            Text("${weather.surfaceWindKts} KTS", fontSize = 13.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                        }
                        Column {
                            Text("UPPER WIND SHEAR", fontSize = 8.sp, color = MaterialTheme.colorScheme.secondary)
                            Text("${weather.upperAtmosphereWindKts} KTS", fontSize = 13.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                        }
                        Column {
                            Text("TEMPERATURE", fontSize = 8.sp, color = MaterialTheme.colorScheme.secondary)
                            Text("${weather.temperatureC}°C", fontSize = 13.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                        }
                        Column {
                            Text("PRESSURE", fontSize = 8.sp, color = MaterialTheme.colorScheme.secondary)
                            Text("${weather.surfacePressureHpa} hPa", fontSize = 13.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    Text(weather.operationalAssessment, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, fontFamily = FontFamily.Monospace)
                }
            }
        }
    }
}

@Composable
fun EngineeringModeScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val currentConfig by viewModel.simConfig.collectAsState()

    val solver by viewModel.mathSolverInput.collectAsState()
    val timeStep by viewModel.mathTimeStepInput.collectAsState()
    val cdDrag by viewModel.mathDragCdInput.collectAsState()

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text("NEWTON RESEARCH & NUMERICS", fontSize = 11.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, color = MaterialTheme.colorScheme.secondary)
            Text("ENGINEERING DIFFERENTIAL ENGINE", fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(4.dp))
            Text("Manage suborbital trajectory flight solvers, math iterations, atmospheric friction models, and monitor kinetic vs. potential energy metrics.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }

        // Configuration Form
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Text("DIFFERENTIAL SOLVER CONSTANTS", fontSize = 12.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)

                    // Method selector
                    Text("INTEGRATION ITERATION METHOD", fontSize = 10.sp, color = MaterialTheme.colorScheme.secondary)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Button(
                            onClick = { viewModel.mathSolverInput.value = IntegrationMethod.RUNGE_KUTTA_4 },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (solver == IntegrationMethod.RUNGE_KUTTA_4) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
                                contentColor = if (solver == IntegrationMethod.RUNGE_KUTTA_4) Color.White else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        ) {
                            Text("RUNGE-KUTTA 4 (RK4)", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }

                        Button(
                            onClick = { viewModel.mathSolverInput.value = IntegrationMethod.EULER },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (solver == IntegrationMethod.EULER) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
                                contentColor = if (solver == IntegrationMethod.EULER) Color.White else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        ) {
                            Text("EULER (FIRST ORDER)", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    // Step size
                    Text("INTEGRATION STEP TIME INCREMENT (seconds)", fontSize = 10.sp, color = MaterialTheme.colorScheme.secondary)
                    Slider(
                        value = timeStep.toFloat(),
                        onValueChange = { viewModel.mathTimeStepInput.value = it.roundToInt().toDouble().coerceIn(1.0, 10.0) },
                        valueRange = 1.0f..10.0f,
                        steps = 8
                    )
                    Text(String.format(Locale.US, "dt = %.1f seconds", timeStep), fontSize = 13.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)

                    // Cd drag
                    Text("ATMOSPHERIC COEFFICIENT OF DRAG (Cd)", fontSize = 10.sp, color = MaterialTheme.colorScheme.secondary)
                    Slider(
                        value = cdDrag.toFloat(),
                        onValueChange = { viewModel.mathDragCdInput.value = Math.round(it * 100) / 100.0 },
                        valueRange = 0.1f..0.8f
                    )
                    Text(String.format(Locale.US, "Cd = %.2f", cdDrag), fontSize = 13.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)

                    Spacer(modifier = Modifier.height(8.dp))

                    Button(
                        onClick = { viewModel.applyEngineeringSettings() },
                        modifier = Modifier.fillMaxWidth().height(48.dp)
                    ) {
                        Text("APPLY TO ACTIVE SOLVERS", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // Energy Conservation
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text("ENERGY CONSERVATION METRICS", fontSize = 11.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, color = MaterialTheme.colorScheme.secondary)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "The mechanical energy index is monitored as:\nE_tot = P_potential + K_kinetic + W_friction_drag_losses\n\nUnder RK4 solvers, discretization errors converge at order h^4, securing conservation of energy bounded below 10^-6 over intercontinental trajectory paths.",
                        fontSize = 12.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
        }
    }
}
