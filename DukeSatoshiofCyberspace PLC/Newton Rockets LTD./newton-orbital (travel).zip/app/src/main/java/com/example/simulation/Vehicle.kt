package com.example.simulation

enum class VehicleStatus {
    AVAILABLE,
    IN_FLIGHT,
    TURNAROUND,
    MAINTENANCE
}

data class Vehicle(
    val id: String,
    val name: String,
    val type: String,
    val passengerCapacity: Int,
    val cargoCapacityKg: Double,
    val dryMassKg: Double,
    val propellantCapacityKg: Double,
    val thrustN: Double, // Thrust in Newtons
    val ispSeconds: Double, // Specific Impulse in seconds
    val maxAltitudeKm: Double,
    val cruiseVelocityMs: Double, // m/s
    val rangeKm: Double,
    val status: VehicleStatus = VehicleStatus.AVAILABLE,
    val lifetimeMissions: Int = 104,
    val currentTurnaroundTimeHours: Int = 4,
    val locationCode: String = "LSP"
)

object FleetRegistry {
    val vehicles = listOf(
        Vehicle(
            id = "V-OX1",
            name = "Newton OX-1",
            type = "Light Cargo/Express",
            passengerCapacity = 0,
            cargoCapacityKg = 15000.0,
            dryMassKg = 35000.0,
            propellantCapacityKg = 120000.0,
            thrustN = 1800000.0,
            ispSeconds = 310.0,
            maxAltitudeKm = 120.0,
            cruiseVelocityMs = 4200.0,
            rangeKm = 6000.0,
            status = VehicleStatus.AVAILABLE,
            lifetimeMissions = 241,
            locationCode = "NSP"
        ),
        Vehicle(
            id = "V-OX3",
            name = "Newton OX-3",
            type = "Standard Transport",
            passengerCapacity = 32,
            cargoCapacityKg = 10000.0,
            dryMassKg = 48000.0,
            propellantCapacityKg = 180000.0,
            thrustN = 2600000.0,
            ispSeconds = 325.0,
            maxAltitudeKm = 150.0,
            cruiseVelocityMs = 5800.0,
            rangeKm = 9000.0,
            status = VehicleStatus.IN_FLIGHT,
            lifetimeMissions = 112,
            locationCode = "DSP"
        ),
        Vehicle(
            id = "V-OX7",
            name = "Newton OX-7",
            type = "Heavy Passenger Cruiser",
            passengerCapacity = 128,
            cargoCapacityKg = 25000.0,
            dryMassKg = 85000.0,
            propellantCapacityKg = 320000.0,
            thrustN = 5400000.0,
            ispSeconds = 340.0,
            maxAltitudeKm = 220.0,
            cruiseVelocityMs = 7400.0,
            rangeKm = 18000.0,
            status = VehicleStatus.AVAILABLE,
            lifetimeMissions = 84,
            locationCode = "LSP"
        ),
        Vehicle(
            id = "V-OX9",
            name = "Newton OX-9",
            type = "Ultra Range Intercontinental",
            passengerCapacity = 84,
            cargoCapacityKg = 40000.0,
            dryMassKg = 92000.0,
            propellantCapacityKg = 380000.0,
            thrustN = 6200000.0,
            ispSeconds = 355.0,
            maxAltitudeKm = 260.0,
            cruiseVelocityMs = 7900.0,
            rangeKm = 22000.0,
            status = VehicleStatus.TURNAROUND,
            lifetimeMissions = 63,
            locationCode = "SSP"
        ),
        Vehicle(
            id = "V-OX12",
            name = "Newton OX-12",
            type = "Heavy Cargo Lifter",
            passengerCapacity = 0,
            cargoCapacityKg = 95000.0,
            dryMassKg = 110000.0,
            propellantCapacityKg = 450000.0,
            thrustN = 8200000.0,
            ispSeconds = 330.0,
            maxAltitudeKm = 180.0,
            cruiseVelocityMs = 6900.0,
            rangeKm = 15000.0,
            status = VehicleStatus.MAINTENANCE,
            lifetimeMissions = 45,
            locationCode = "LSP"
        )
    )

    fun getById(id: String): Vehicle? = vehicles.find { it.id == id }

    fun getForRoute(distanceKm: Double, passengerCount: Int): Vehicle {
        // Find best vehicle that has range >= distanceKm and passenger capacity >= passengerCount
        return vehicles.filter { it.rangeKm >= distanceKm && (passengerCount == 0 || it.passengerCapacity >= passengerCount) }
            .minByOrNull { it.dryMassKg } ?: vehicles[2] // Fallback to OX-7
    }
}
