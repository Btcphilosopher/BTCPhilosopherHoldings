package com.example.simulation

import java.util.*
import kotlin.math.roundToInt

data class Route(
    val id: String,
    val origin: Spaceport,
    val destination: Spaceport,
    val distanceKm: Double,
    val estimatedFlightTimeMin: Int,
    val groundTransferMin: Int = 45,
    val allocatedVehicle: Vehicle,
    val baseTicketPriceGbp: Double,
    val baseCargoPricePerKgGbp: Double,
    val launchWindowStart: String,
    val launchWindowEnd: String,
    val status: RouteStatus
)

enum class RouteStatus {
    AVAILABLE,
    WEATHER_HOLD,
    VEHICLE_UNAVAILABLE,
    RESTRICTED
}

object RouteEngine {

    fun searchJourneys(
        originCode: String,
        destCode: String,
        passengerCount: Int = 1,
        cargoWeightKg: Double = 0.0
    ): List<Route> {
        val origin = SpaceportRegistry.getByCode(originCode) ?: return emptyList()
        val dest = SpaceportRegistry.getByCode(destCode) ?: return emptyList()

        if (origin.id == dest.id) return emptyList()

        // Calculate Great-Circle distance
        val distM = TrajectoryEngine.calculateGreatCircleDistanceM(
            origin.latitude, origin.longitude,
            dest.latitude, dest.longitude
        )
        val distKm = distM / 1000.0

        // Allocate a suitable vehicle
        val vehicle = FleetRegistry.getForRoute(distKm, passengerCount)

        // Calculate flight duration based on average trajectory cruise speed
        val flightSec = distM / (vehicle.cruiseVelocityMs * 0.85) // average velocity fraction
        val flightMin = (flightSec / 60.0).roundToInt().coerceIn(25, 95) // Rockets are extremely fast!

        // Generate pricing based on physical factors
        val baseTicketPrice = calculatePassengerTicketPrice(distKm, vehicle)
        val baseCargoPrice = calculateCargoPricePerKg(distKm, vehicle)

        // Evaluate Weather Statuses
        val weatherOrigin = WeatherSimulator.generateWeather(origin.code)
        val weatherDest = WeatherSimulator.generateWeather(dest.code)

        val routeStatus = when {
            weatherOrigin.status == WeatherStatus.RED || weatherDest.status == WeatherStatus.RED -> RouteStatus.WEATHER_HOLD
            vehicle.status == VehicleStatus.MAINTENANCE -> RouteStatus.VEHICLE_UNAVAILABLE
            else -> RouteStatus.AVAILABLE
        }

        // Launch windows
        val nowHour = 9
        val preferredMin = 20
        val windowStart = String.format(Locale.US, "%02d:%02d", nowHour - 1, preferredMin + 30)
        val windowEnd = String.format(Locale.US, "%02d:%02d", nowHour + 1, preferredMin + 15)

        return listOf(
            Route(
                id = "R-${origin.code}-${dest.code}-${vehicle.id.takeLast(3)}",
                origin = origin,
                destination = dest,
                distanceKm = Math.round(distKm * 10) / 10.0,
                estimatedFlightTimeMin = flightMin,
                groundTransferMin = 45,
                allocatedVehicle = vehicle,
                baseTicketPriceGbp = baseTicketPrice,
                baseCargoPricePerKgGbp = baseCargoPrice,
                launchWindowStart = windowStart,
                launchWindowEnd = windowEnd,
                status = routeStatus
            )
        )
    }

    private fun calculatePassengerTicketPrice(distanceKm: Double, vehicle: Vehicle): Double {
        val fuelFactor = vehicle.propellantCapacityKg * 0.08
        val baseFare = 12000.0
        val distanceFare = distanceKm * 0.85
        val premiumFactor = when (vehicle.id) {
            "V-OX7" -> 1.2  // Heavy Premium Cruiser
            "V-OX9" -> 1.5  // Ultra Range
            else -> 1.0
        }
        return Math.round((baseFare + distanceFare + fuelFactor) * premiumFactor / 100) * 100.0
    }

    private fun calculateCargoPricePerKg(distanceKm: Double, vehicle: Vehicle): Double {
        val baseCargo = 12.50
        val distanceFactor = distanceKm * 0.0015
        return Math.round((baseCargo + distanceFactor) * 100) / 100.0
    }
}
