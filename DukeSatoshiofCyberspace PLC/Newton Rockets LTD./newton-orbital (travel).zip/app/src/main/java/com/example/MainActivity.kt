package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.AppScreen
import com.example.ui.MainViewModel
import com.example.ui.screens.*
import com.example.ui.theme.NewtonOrbitalTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            NewtonOrbitalTheme {
                val viewModel: MainViewModel = viewModel()
                MainAppScaffold(viewModel = viewModel)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainAppScaffold(viewModel: MainViewModel) {
    val currentScreen by viewModel.currentScreen.collectAsState()
    var isOperationsMode by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = "NEWTON ORBITAL",
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 16.sp,
                            fontFamily = FontFamily.Monospace,
                            letterSpacing = 1.sp
                        )
                        Text(
                            text = if (isOperationsMode) "AEROSPACE OPERATIONS COMMAND" else "GLOBAL PASSENGER HUB",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.primary,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                },
                actions = {
                    // Mode Toggle Button (Customer vs Operations)
                    Button(
                        onClick = {
                            isOperationsMode = !isOperationsMode
                            if (isOperationsMode) {
                                viewModel.navigateTo(AppScreen.OPERATIONS_CENTER)
                            } else {
                                viewModel.navigateTo(AppScreen.HOME)
                            }
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (isOperationsMode) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.secondary
                        ),
                        modifier = Modifier
                            .padding(end = 8.dp)
                            .testTag("mode_toggle_button")
                    ) {
                        Icon(
                            imageVector = if (isOperationsMode) Icons.Default.AdminPanelSettings else Icons.Default.TravelExplore,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = if (isOperationsMode) "OPS CONSOLE" else "PASSENGER",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface,
                    titleContentColor = MaterialTheme.colorScheme.onSurface
                )
            )
        },
        bottomBar = {
            NavigationBar(
                containerColor = MaterialTheme.colorScheme.surface,
                tonalElevation = 8.dp
            ) {
                if (!isOperationsMode) {
                    // Customer Mode Navigation Bars
                    NavigationBarItem(
                        selected = currentScreen == AppScreen.HOME || currentScreen == AppScreen.ROUTE_SEARCH_RESULTS,
                        onClick = { viewModel.navigateTo(AppScreen.HOME) },
                        icon = { Icon(Icons.Default.Search, contentDescription = null) },
                        label = { Text("Search Flights", fontSize = 11.sp) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = MaterialTheme.colorScheme.primary,
                            selectedTextColor = MaterialTheme.colorScheme.primary
                        )
                    )
                    NavigationBarItem(
                        selected = currentScreen == AppScreen.CUSTOMER_DASHBOARD || currentScreen == AppScreen.BOOKING_CONFIRMATION,
                        onClick = { viewModel.navigateTo(AppScreen.CUSTOMER_DASHBOARD) },
                        icon = { Icon(Icons.Default.ConfirmationNumber, contentDescription = null) },
                        label = { Text("My Tickets", fontSize = 11.sp) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = MaterialTheme.colorScheme.primary,
                            selectedTextColor = MaterialTheme.colorScheme.primary
                        )
                    )
                    NavigationBarItem(
                        selected = currentScreen == AppScreen.CARGO_PORTAL,
                        onClick = { viewModel.navigateTo(AppScreen.CARGO_PORTAL) },
                        icon = { Icon(Icons.Default.LocalShipping, contentDescription = null) },
                        label = { Text("Cargo Portal", fontSize = 11.sp) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = MaterialTheme.colorScheme.primary,
                            selectedTextColor = MaterialTheme.colorScheme.primary
                        )
                    )
                } else {
                    // Operations Mode Navigation Bars
                    NavigationBarItem(
                        selected = currentScreen == AppScreen.OPERATIONS_CENTER,
                        onClick = { viewModel.navigateTo(AppScreen.OPERATIONS_CENTER) },
                        icon = { Icon(Icons.Default.Analytics, contentDescription = null) },
                        label = { Text("Control Center", fontSize = 10.sp) }
                    )
                    NavigationBarItem(
                        selected = currentScreen == AppScreen.SPACEPORTS_DASHBOARD,
                        onClick = { viewModel.navigateTo(AppScreen.SPACEPORTS_DASHBOARD) },
                        icon = { Icon(Icons.Default.Business, contentDescription = null) },
                        label = { Text("Spaceports", fontSize = 10.sp) }
                    )
                    NavigationBarItem(
                        selected = currentScreen == AppScreen.FLEET_MANAGEMENT,
                        onClick = { viewModel.navigateTo(AppScreen.FLEET_MANAGEMENT) },
                        icon = { Icon(Icons.Default.RocketLaunch, contentDescription = null) },
                        label = { Text("Fleet Specs", fontSize = 10.sp) }
                    )
                    NavigationBarItem(
                        selected = currentScreen == AppScreen.WEATHER_MONITOR,
                        onClick = { viewModel.navigateTo(AppScreen.WEATHER_MONITOR) },
                        icon = { Icon(Icons.Default.Cloud, contentDescription = null) },
                        label = { Text("Weather Grid", fontSize = 10.sp) }
                    )
                    NavigationBarItem(
                        selected = currentScreen == AppScreen.ENGINEERING_MODE,
                        onClick = { viewModel.navigateTo(AppScreen.ENGINEERING_MODE) },
                        icon = { Icon(Icons.Default.SettingsInputComponent, contentDescription = null) },
                        label = { Text("Engineering", fontSize = 10.sp) }
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            when (currentScreen) {
                AppScreen.HOME -> CustomerHomeScreen(viewModel = viewModel)
                AppScreen.ROUTE_SEARCH_RESULTS -> RouteSearchResultsScreen(viewModel = viewModel)
                AppScreen.BOOKING_PASSENGER_DETAILS -> BookingPassengerDetailsScreen(viewModel = viewModel)
                AppScreen.BOOKING_SEAT_MAP -> BookingSeatMapScreen(viewModel = viewModel)
                AppScreen.BOOKING_CONFIRMATION -> BookingConfirmationScreen(viewModel = viewModel)
                AppScreen.CARGO_PORTAL -> CargoPortalScreen(viewModel = viewModel)
                AppScreen.CUSTOMER_DASHBOARD -> CustomerDashboardScreen(viewModel = viewModel)
                AppScreen.OPERATIONS_CENTER -> OperationsCenterScreen(viewModel = viewModel)
                AppScreen.SPACEPORTS_DASHBOARD -> SpaceportsDashboardScreen(viewModel = viewModel)
                AppScreen.FLEET_MANAGEMENT -> FleetManagementScreen(viewModel = viewModel)
                AppScreen.WEATHER_MONITOR -> WeatherMonitorScreen(viewModel = viewModel)
                AppScreen.ENGINEERING_MODE -> EngineeringModeScreen(viewModel = viewModel)
            }
        }
    }
}
