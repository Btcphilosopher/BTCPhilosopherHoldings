package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import com.example.simulation.TrajectoryStep
import kotlin.math.max

@Composable
fun TelemetryChartCanvas(
    currentStep: TrajectoryStep?,
    allSteps: List<TrajectoryStep>,
    modifier: Modifier = Modifier
) {
    val gridColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f)
    val altColor = MaterialTheme.colorScheme.primary
    val velColor = Color(0xFF06B6D4) // Space Cyan
    val onSurfaceColor = MaterialTheme.colorScheme.onSurface

    Canvas(
        modifier = modifier
            .fillMaxWidth()
            .height(130.dp)
            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.2f))
    ) {
        val width = size.width
        val height = size.height
        val paddingL = 10f
        val paddingR = 10f
        val paddingT = 15f
        val paddingB = 15f

        val chartW = width - paddingL - paddingR
        val chartH = height - paddingT - paddingB

        // Draw horizontal grid lines
        for (i in 0..4) {
            val y = paddingT + (chartH / 4) * i
            drawLine(
                color = gridColor,
                start = Offset(paddingL, y),
                end = Offset(width - paddingR, y),
                strokeWidth = 1f
            )
        }

        if (allSteps.isEmpty()) return@Canvas

        // Find max altitude and max velocity for scaling
        val maxAlt = max(allSteps.maxOfOrNull { it.altitudeM } ?: 1.0, 1.0)
        val maxVel = max(allSteps.maxOfOrNull { it.velocityMs } ?: 1.0, 1.0)
        val maxTime = max(allSteps.lastOrNull()?.timeSec ?: 1.0, 1.0)

        // Plot Altitude Path
        val altPath = Path()
        val velPath = Path()

        allSteps.forEachIndexed { index, step ->
            val x = paddingL + (step.timeSec / maxTime).toFloat() * chartW
            val yAlt = height - paddingB - (step.altitudeM / maxAlt).toFloat() * chartH
            val yVel = height - paddingB - (step.velocityMs / maxVel).toFloat() * chartH

            if (index == 0) {
                altPath.moveTo(x, yAlt)
                velPath.moveTo(x, yVel)
            } else {
                altPath.lineTo(x, yAlt)
                velPath.lineTo(x, yVel)
            }
        }

        // Draw Altitude curve (Red)
        drawPath(
            path = altPath,
            color = altColor,
            style = Stroke(width = 2.dp.toPx())
        )

        // Draw Velocity curve (Cyan)
        drawPath(
            path = velPath,
            color = velColor,
            style = Stroke(width = 1.5.dp.toPx(), pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 6f), 0f))
        )

        // Draw Current time vertical crosshair tracker
        if (currentStep != null) {
            val currentX = paddingL + (currentStep.timeSec / maxTime).toFloat() * chartW
            val currentYAlt = height - paddingB - (currentStep.altitudeM / maxAlt).toFloat() * chartH
            val currentYVel = height - paddingB - (currentStep.velocityMs / maxVel).toFloat() * chartH

            // Vertical line
            drawLine(
                color = onSurfaceColor.copy(alpha = 0.4f),
                start = Offset(currentX, paddingT),
                end = Offset(currentX, height - paddingB),
                strokeWidth = 1.dp.toPx(),
                pathEffect = PathEffect.dashPathEffect(floatArrayOf(4f, 4f), 0f)
            )

            // Altitude crosshair node (Filled Red)
            drawCircle(
                color = altColor,
                radius = 5.dp.toPx(),
                center = Offset(currentX, currentYAlt)
            )

            // Velocity crosshair node (Filled Cyan)
            drawCircle(
                color = velColor,
                radius = 4.dp.toPx(),
                center = Offset(currentX, currentYVel)
            )
        }
    }
}
