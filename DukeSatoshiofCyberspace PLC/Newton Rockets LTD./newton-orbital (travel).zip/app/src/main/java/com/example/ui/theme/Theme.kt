package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable

private val DarkColorScheme = darkColorScheme(
    primary = NewtonRed,
    onPrimary = OnDarkPrimary,
    secondary = OnDarkSecondary,
    onSecondary = DarkBackground,
    background = DarkBackground,
    onBackground = OnDarkPrimary,
    surface = DarkSurface,
    onSurface = OnDarkPrimary,
    surfaceVariant = DarkSurfaceElevated,
    onSurfaceVariant = OnDarkSecondary,
    outline = DarkBorder,
    error = SpaceRed
)

private val LightColorScheme = lightColorScheme(
    primary = NewtonRed,
    onPrimary = LightBackground,
    secondary = OnLightSecondary,
    onSecondary = OnLightPrimary,
    background = LightBackground,
    onBackground = OnLightPrimary,
    surface = LightSurface,
    onSurface = OnLightPrimary,
    surfaceVariant = LightSurfaceElevated,
    onSurfaceVariant = OnLightSecondary,
    outline = LightBorder,
    error = SpaceRed
)

@Composable
fun NewtonOrbitalTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
