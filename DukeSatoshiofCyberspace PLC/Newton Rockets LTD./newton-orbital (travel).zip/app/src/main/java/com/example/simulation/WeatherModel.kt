package com.example.simulation

import kotlin.random.Random

enum class WeatherStatus {
    GREEN,  // Nominal
    AMBER,  // Precautionary warning, review required
    RED     // NO-GO for launch/landing operations
}

data class SpaceportWeather(
    val spaceportCode: String,
    val surfaceWindKts: Double,
    val upperAtmosphereWindKts: Double,
    val temperatureC: Double,
    val surfacePressureHpa: Double,
    val precipitationMmHr: Double,
    val cloudCeilingFt: Double,
    val visibilityKm: Double,
    val status: WeatherStatus,
    val operationalAssessment: String
)

object WeatherSimulator {
    fun generateWeather(code: String, seed: Long = code.hashCode().toLong()): SpaceportWeather {
        val random = Random(seed)
        val wind = random.nextDouble(5.0, 32.0)
        val upperWind = random.nextDouble(20.0, 120.0)
        val temp = random.nextDouble(5.0, 35.0)
        val press = random.nextDouble(990.0, 1025.0)
        val precip = if (random.nextDouble() < 0.2) random.nextDouble(0.0, 8.0) else 0.0
        val visibility = random.nextDouble(2.0, 15.0)
        val ceiling = if (precip > 0) random.nextDouble(1000.0, 5000.0) else random.nextDouble(10000.0, 30000.0)

        // Determine status
        val status = when {
            wind > 28.0 || upperWind > 100.0 || precip > 5.0 || visibility < 3.0 -> WeatherStatus.RED
            wind > 18.0 || upperWind > 75.0 || precip > 1.5 || visibility < 6.0 -> WeatherStatus.AMBER
            else -> WeatherStatus.GREEN
        }

        val assessment = when (status) {
            WeatherStatus.GREEN -> "ALL MET SYSTEMS NOMINAL. GO FOR NOMINAL TRAJECTORIES."
            WeatherStatus.AMBER -> "UPPER WIND / SHEAR ELEVATED. FLIGHT CONTROLLER REVIEW MANDATORY."
            WeatherStatus.RED -> "WINDS / PRECIP EXCEED SAFETY CRITERIA. RANGE SAFETY STATE: HOLD."
        }

        return SpaceportWeather(
            spaceportCode = code,
            surfaceWindKts = Math.round(wind * 10) / 10.0,
            upperAtmosphereWindKts = Math.round(upperWind * 10) / 10.0,
            temperatureC = Math.round(temp * 10) / 10.0,
            surfacePressureHpa = Math.round(press * 10) / 10.0,
            precipitationMmHr = Math.round(precip * 10) / 10.0,
            cloudCeilingFt = Math.round(ceiling / 100) * 100.0,
            visibilityKm = Math.round(visibility * 10) / 10.0,
            status = status,
            operationalAssessment = assessment
        )
    }
}
