package com.example.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.repository.Booking
import com.example.repository.CargoShipment
import com.example.repository.NewtonRepository
import com.example.simulation.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.Locale

// Navigation route structure for our custom state-switching navigation
enum class AppScreen {
    HOME,                     // Splendid hero welcome & route search
    CUSTOMER_DASHBOARD,       // Travel history, booked tickets, active mission tracker shortcut
    ROUTE_SEARCH_RESULTS,     // Journey options for chosen search
    BOOKING_PASSENGER_DETAILS,// Passenger name, baggages, seat selection
    BOOKING_SEAT_MAP,         // Beautiful interactive aerospace seat layout selector
    BOOKING_CONFIRMATION,     // Beautiful digital receipt and rocket boarding pass
    CARGO_PORTAL,             // Cargo shipping quotes & booking manifests
    OPERATIONS_CENTER,        // British Aerospace Mission Control, numerical telemetry, global active flights
    SPACEPORTS_DASHBOARD,     // Spaceport operations, runways, pad states, departures & arrivals list
    FLEET_MANAGEMENT,         // Fleet utilization, rocket dry masses, specs list
    WEATHER_MONITOR,          // Real-time environmental sensor array across all spaceports
    ENGINEERING_MODE          // Advanced numerical integration solvers, cd, area, timesteps, conservation of energy
}

class MainViewModel : ViewModel() {

    private val repository = NewtonRepository.getInstance()

    // Screen State
    private val _currentScreen = MutableStateFlow(AppScreen.HOME)
    val currentScreen = _currentScreen.asStateFlow()

    // Navigation Stack for robust back navigation
    private val screenStack = mutableListOf<AppScreen>()

    // Exposed Flows from Repository
    val spaceports = repository.spaceports
    val vehicles = repository.vehicles
    val bookings = repository.bookings
    val cargoShipments = repository.cargoShipments
    val missions = repository.missions
    val simConfig = repository.simConfig

    // Search Parameters State
    val searchOrigin = MutableStateFlow("LSP")
    val searchDest = MutableStateFlow("SSP")
    val searchDate = MutableStateFlow("17 Oct 2027")
    val searchPassengers = MutableStateFlow(1)
    val searchBaggageKg = MutableStateFlow(25.0)

    // Route search results State
    private val _searchResults = MutableStateFlow<List<Route>>(emptyList())
    val searchResults = _searchResults.asStateFlow()

    // Selected Route for booking progress
    private val _selectedRoute = MutableStateFlow<Route?>(null)
    val selectedRoute = _selectedRoute.asStateFlow()

    // Interactive booking state
    val passengerNameInput = MutableStateFlow("John Smith")
    val selectedSeatClass = MutableStateFlow("Orbital First")
    val selectedSeatCode = MutableStateFlow("Row 02, Seat A")

    // Confirmation ticket output
    private val _latestBooking = MutableStateFlow<Booking?>(null)
    val latestBooking = _latestBooking.asStateFlow()

    // Selected Mission ID for deep tracking (Digital Twin)
    private val _activeTrackingMissionId = MutableStateFlow("NO-2714")
    val activeTrackingMissionId = _activeTrackingMissionId.asStateFlow()

    // Engineering State parameters
    val mathSolverInput = MutableStateFlow(IntegrationMethod.RUNGE_KUTTA_4)
    val mathTimeStepInput = MutableStateFlow(1.0)
    val mathDragCdInput = MutableStateFlow(0.3)

    // Cargo Booking Parameters
    val cargoWeightKgInput = MutableStateFlow(1500.0)
    val cargoVolumeM3Input = MutableStateFlow(4.5)
    val cargoDeclaredValueInput = MutableStateFlow(25000.0)
    val cargoPriorityInput = MutableStateFlow("EXPRESS")
    val cargoHandlingInput = MutableStateFlow("SENSITIVE ELECTRICALS")
    private val _latestCargoShipment = MutableStateFlow<CargoShipment?>(null)
    val latestCargoShipment = _latestCargoShipment.asStateFlow()

    init {
        // Init math configs matching current config
        viewModelScope.launch {
            simConfig.collect { config ->
                mathSolverInput.value = config.integrationMethod
                mathTimeStepInput.value = config.timeStepSec
                mathDragCdInput.value = config.cdDragCoefficient
            }
        }
    }

    // Custom back navigation support
    fun navigateTo(screen: AppScreen) {
        screenStack.add(_currentScreen.value)
        _currentScreen.value = screen
    }

    fun navigateBack() {
        if (screenStack.isNotEmpty()) {
            _currentScreen.value = screenStack.removeAt(screenStack.size - 1)
        } else {
            _currentScreen.value = AppScreen.HOME
        }
    }

    // Performs physical route search based on user variables
    fun executeSearch() {
        viewModelScope.launch {
            val results = RouteEngine.searchJourneys(
                originCode = searchOrigin.value,
                destCode = searchDest.value,
                passengerCount = searchPassengers.value
            )
            _searchResults.value = results
            navigateTo(AppScreen.ROUTE_SEARCH_RESULTS)
        }
    }

    fun selectRouteForBooking(route: Route) {
        _selectedRoute.value = route
        selectedSeatClass.value = if (route.allocatedVehicle.passengerCapacity > 32) "Orbital Business" else "Orbital First"
        selectedSeatCode.value = "Row 04, Seat B"
        navigateTo(AppScreen.BOOKING_PASSENGER_DETAILS)
    }

    fun confirmBooking() {
        val route = _selectedRoute.value ?: return
        viewModelScope.launch {
            val totalCost = route.baseTicketPriceGbp * searchPassengers.value + (if (selectedSeatClass.value == "Orbital First") 4000.0 else 0.0)
            val booking = repository.createBooking(
                passengerName = passengerNameInput.value,
                route = route,
                seatClass = selectedSeatClass.value,
                seatCode = selectedSeatCode.value,
                baggageKg = searchBaggageKg.value,
                price = totalCost,
                date = searchDate.value
            )
            _latestBooking.value = booking
            _activeTrackingMissionId.value = booking.missionId
            navigateTo(AppScreen.BOOKING_CONFIRMATION)
        }
    }

    // Handles Cargo shipping quote and booking
    fun createCargoShipment() {
        viewModelScope.launch {
            val origin = SpaceportRegistry.getByCode(searchOrigin.value) ?: return@launch
            val dest = SpaceportRegistry.getByCode(searchDest.value) ?: return@launch
            val routes = RouteEngine.searchJourneys(origin.code, dest.code, 0, cargoWeightKgInput.value)
            val selectedRoute = routes.firstOrNull() ?: return@launch

            val price = selectedRoute.baseCargoPricePerKgGbp * cargoWeightKgInput.value + (if (cargoPriorityInput.value == "CRITICAL") 3500.0 else 1000.0)
            val shipment = repository.createCargoBooking(
                route = selectedRoute,
                weightKg = cargoWeightKgInput.value,
                volumeM3 = cargoVolumeM3Input.value,
                declaredValueGbp = cargoDeclaredValueInput.value,
                priority = cargoPriorityInput.value,
                handling = cargoHandlingInput.value,
                price = price
            )
            _latestCargoShipment.value = shipment
            _activeTrackingMissionId.value = shipment.missionId
            navigateTo(AppScreen.CUSTOMER_DASHBOARD)
        }
    }

    // Launches a vehicle in PRE_LAUNCH status
    fun triggerPrelaunchToAscent(missionId: String) {
        repository.startMissionManually(missionId)
    }

    // Apply Engineering adjustments to the trajectory parameters
    fun applyEngineeringSettings() {
        val current = simConfig.value
        val newConfig = current.copy(
            integrationMethod = mathSolverInput.value,
            timeStepSec = mathTimeStepInput.value,
            cdDragCoefficient = mathDragCdInput.value
        )
        repository.updateSimulationConfig(newConfig)
    }

    fun selectActiveMissionForTracking(missionId: String, nextScreen: AppScreen = AppScreen.CUSTOMER_DASHBOARD) {
        _activeTrackingMissionId.value = missionId
        navigateTo(nextScreen)
    }
}
