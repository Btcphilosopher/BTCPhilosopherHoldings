package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Premium Newton Orbital Palette
val NewtonRed = Color(0xFFD13438)
val NewtonRedDim = Color(0xFFA22024)

// Dark Palette (British Aerospace Control Center / Bloomberg Terminal vibe)
val DarkBackground = Color(0xFF0C0E12)
val DarkSurface = Color(0xFF15181E)
val DarkSurfaceElevated = Color(0xFF1F242C)
val OnDarkPrimary = Color(0xFFF8F9FA)
val OnDarkSecondary = Color(0xFFB0B8C4)
val DarkBorder = Color(0xFF2C323E)

// Light Palette (High-end Travel Brand / Roll-Royce Documentation paper vibe)
val LightBackground = Color(0xFFFAF9F6)
val LightSurface = Color(0xFFF3F1EC)
val LightSurfaceElevated = Color(0xFFE9E5DC)
val OnLightPrimary = Color(0xFF1A1D24)
val OnLightSecondary = Color(0xFF5D6674)
val LightBorder = Color(0xFFDFDACF)

// Functional Status Markers (Aerospace standards)
val SpaceGreen = Color(0xFF10B981)
val SpaceAmber = Color(0xFFF59E0B)
val SpaceRed = Color(0xFFEF4444)
val SpaceBlue = Color(0xFF3B82F6)
val SpaceCyan = Color(0xFF06B6D4)
