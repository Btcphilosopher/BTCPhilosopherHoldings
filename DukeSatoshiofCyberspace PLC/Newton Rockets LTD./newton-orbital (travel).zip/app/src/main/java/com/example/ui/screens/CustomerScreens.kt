package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.repository.Booking
import com.example.simulation.*
import com.example.ui.AppScreen
import com.example.ui.MainViewModel
import java.util.Locale

@Composable
fun CustomerHomeScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val origin by viewModel.searchOrigin.collectAsState()
    val dest by viewModel.searchDest.collectAsState()
    val date by viewModel.searchDate.collectAsState()
    val passengers by viewModel.searchPassengers.collectAsState()
    val spaceports by viewModel.spaceports.collectAsState()

    var showOriginDropdown by remember { mutableStateOf(false) }
    var showDestDropdown by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Welcome Header
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.3f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "NEWTON ORBITAL",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary,
                        fontFamily = FontFamily.Monospace
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "THE WORLD, WITHIN REACH.",
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Light,
                        fontFamily = FontFamily.SansSerif,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Next-generation suborbital transport networks connecting major cities across Earth via reusable rocket vehicles. Point-to-point intercontinental flights completed in minutes.",
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        // Search Engine Form
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Text(
                        text = "SEARCH ROCKET FLIGHTS",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        color = MaterialTheme.colorScheme.onSurface
                    )

                    // Origin selector
                    Box(modifier = Modifier.fillMaxWidth()) {
                        OutlinedButton(
                            onClick = { showOriginDropdown = true },
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.onSurface)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(horizontalAlignment = Alignment.Start) {
                                    Text("FROM (ORIGIN SPACEPORT)", fontSize = 10.sp, color = MaterialTheme.colorScheme.secondary)
                                    val port = SpaceportRegistry.getByCode(origin)
                                    Text(port?.name ?: origin, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                                }
                                Icon(Icons.Default.ArrowDropDown, contentDescription = "Dropdown")
                            }
                        }

                        DropdownMenu(
                            expanded = showOriginDropdown,
                            onDismissRequest = { showOriginDropdown = false }
                        ) {
                            spaceports.forEach { port ->
                                DropdownMenuItem(
                                    text = { Text("${port.name} (${port.code})") },
                                    onClick = {
                                        viewModel.searchOrigin.value = port.code
                                        showOriginDropdown = false
                                    }
                                )
                            }
                        }
                    }

                    // Destination selector
                    Box(modifier = Modifier.fillMaxWidth()) {
                        OutlinedButton(
                            onClick = { showDestDropdown = true },
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.onSurface)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(horizontalAlignment = Alignment.Start) {
                                    Text("TO (DESTINATION SPACEPORT)", fontSize = 10.sp, color = MaterialTheme.colorScheme.secondary)
                                    val port = SpaceportRegistry.getByCode(dest)
                                    Text(port?.name ?: dest, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                                }
                                Icon(Icons.Default.ArrowDropDown, contentDescription = "Dropdown")
                            }
                        }

                        DropdownMenu(
                            expanded = showDestDropdown,
                            onDismissRequest = { showDestDropdown = false }
                        ) {
                            spaceports.forEach { port ->
                                DropdownMenuItem(
                                    text = { Text("${port.name} (${port.code})") },
                                    onClick = {
                                        viewModel.searchDest.value = port.code
                                        showDestDropdown = false
                                    }
                                )
                            }
                        }
                    }

                    // Date & Passengers Row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedTextField(
                            value = date,
                            onValueChange = { viewModel.searchDate.value = it },
                            label = { Text("DEPARTURE DATE") },
                            modifier = Modifier.weight(1f),
                            textStyle = LocalTextStyle.current.copy(fontSize = 14.sp)
                        )

                        OutlinedTextField(
                            value = passengers.toString(),
                            onValueChange = {
                                val count = it.toIntOrNull() ?: 1
                                viewModel.searchPassengers.value = count.coerceIn(1, 100)
                            },
                            label = { Text("PASSENGERS") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(0.8f),
                            textStyle = LocalTextStyle.current.copy(fontSize = 14.sp)
                        )
                    }

                    // Search Button
                    Button(
                        onClick = { viewModel.executeSearch() },
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(52.dp)
                            .testTag("search_journey_button")
                    ) {
                        Icon(Icons.Default.Search, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("COMPUTE FLIGHT PATH", fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                    }
                }
            }
        }

        // Live Network Stats Card
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "NEWTON FLIGHT NETWORK INTEGRITY",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        color = MaterialTheme.colorScheme.secondary
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("NETWORK STATUS", fontSize = 9.sp, color = MaterialTheme.colorScheme.secondary)
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(8.dp)
                                        .clip(RoundedCornerShape(50))
                                        .background(Color(0xFF10B981))
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("NOMINAL", fontSize = 14.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                            }
                        }
                        Column {
                            Text("ACTIVE FLIGHTS", fontSize = 9.sp, color = MaterialTheme.colorScheme.secondary)
                            Text("24", fontSize = 14.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                        }
                        Column {
                            Text("GLOBAL AVAILABILITY", fontSize = 9.sp, color = MaterialTheme.colorScheme.secondary)
                            Text("96.8%", fontSize = 14.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, color = Color(0xFF10B981))
                        }
                        Column {
                            Text("SPACEPORTS", fontSize = 9.sp, color = MaterialTheme.colorScheme.secondary)
                            Text("8 Active", fontSize = 14.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                        }
                    }
                }
            }
        }

        // Travel Scenarios Presets
        item {
            Text(
                text = "FEATURED DEPARTURE SCENARIOS",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace,
                modifier = Modifier.padding(top = 8.dp)
            )
        }

        items(ScenarioRegistry.scenarios) { scenario ->
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.2f)),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable {
                        viewModel.searchOrigin.value = scenario.originCode
                        viewModel.searchDest.value = scenario.destCode
                        viewModel.executeSearch()
                    }
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(scenario.title, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(scenario.description, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Icon(
                        Icons.Default.ArrowForward,
                        contentDescription = "Select Scenario",
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.padding(start = 12.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun RouteSearchResultsScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val results by viewModel.searchResults.collectAsState()
    val origin by viewModel.searchOrigin.collectAsState()
    val dest by viewModel.searchDest.collectAsState()

    BackHandler {
        viewModel.navigateBack()
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = { viewModel.navigateBack() },
                modifier = Modifier.testTag("back_button")
            ) {
                Icon(Icons.Default.ArrowBack, contentDescription = "Back")
            }
            Spacer(modifier = Modifier.width(8.dp))
            Column {
                Text("SEARCH OUTPUTS", fontSize = 11.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, color = MaterialTheme.colorScheme.secondary)
                Text("$origin → $dest", fontSize = 18.sp, fontWeight = FontWeight.Bold)
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        if (results.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("NO FLIGHT CORRIDORS CONVERGED FOR THE SELECTED DATES.", textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.secondary)
            }
        } else {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(16.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(results) { route ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        border = BorderStroke(1.5.dp, if (route.status == RouteStatus.AVAILABLE) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            // Header Info
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Badge(
                                    containerColor = when (route.status) {
                                        RouteStatus.AVAILABLE -> Color(0xFF10B981)
                                        RouteStatus.WEATHER_HOLD -> Color(0xFFF59E0B)
                                        else -> Color(0xFFEF4444)
                                    },
                                    contentColor = Color.White,
                                    modifier = Modifier.padding(bottom = 4.dp)
                                ) {
                                    Text(
                                        "  " + route.status.name + "  ",
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        fontFamily = FontFamily.Monospace
                                    )
                                }

                                Text(
                                    route.allocatedVehicle.name,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp,
                                    color = MaterialTheme.colorScheme.primary,
                                    fontFamily = FontFamily.Monospace
                                )
                            }

                            Spacer(modifier = Modifier.height(12.dp))

                            // Core Stats Grid
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column {
                                    Text("ROCKET FLIGHT", fontSize = 9.sp, color = MaterialTheme.colorScheme.secondary)
                                    Text("~${route.estimatedFlightTimeMin} MIN", fontSize = 16.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                                }
                                Column {
                                    Text("GREAT-CIRCLE DIST", fontSize = 9.sp, color = MaterialTheme.colorScheme.secondary)
                                    Text(String.format(Locale.US, "%,.0f KM", route.distanceKm), fontSize = 16.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                                }
                                Column {
                                    Text("BASE FARE", fontSize = 9.sp, color = MaterialTheme.colorScheme.secondary)
                                    Text(String.format(Locale.US, "£%,.0f", route.baseTicketPriceGbp), fontSize = 16.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary, fontFamily = FontFamily.Monospace)
                                }
                            }

                            Divider(modifier = Modifier.padding(vertical = 12.dp), color = MaterialTheme.colorScheme.outline.copy(alpha = 0.5f))

                            // Route Phases
                            Text("FLIGHT PATH SEQUENCE:", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.secondary, fontFamily = FontFamily.Monospace)
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "${route.origin.code} Spaceport → Launch/Ascent → Suborbital Trajectory → Atmospheric Re-entry → Powered Landing → ${route.destination.code} Spaceport",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )

                            Spacer(modifier = Modifier.height(16.dp))

                            Button(
                                onClick = { viewModel.selectRouteForBooking(route) },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(48.dp)
                                    .testTag("book_flight_button"),
                                enabled = route.status == RouteStatus.AVAILABLE
                            ) {
                                Text("SELECT & PROCEED TO CABIN SELECTION", fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun BookingPassengerDetailsScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val route by viewModel.selectedRoute.collectAsState()
    val passengerName by viewModel.passengerNameInput.collectAsState()
    val baggageKg by viewModel.searchBaggageKg.collectAsState()
    val seatClass by viewModel.selectedSeatClass.collectAsState()
    val seatCode by viewModel.selectedSeatCode.collectAsState()

    BackHandler {
        viewModel.navigateBack()
    }

    if (route == null) return

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = { viewModel.navigateBack() }) {
                    Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                }
                Spacer(modifier = Modifier.width(8.dp))
                Column {
                    Text("BOOKING INFRASTRUCTURE", fontSize = 11.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, color = MaterialTheme.colorScheme.secondary)
                    Text("PASSENGER & CABIN PROFILE", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        // Passenger Details Form
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Text("PRIMARY PASSENGER IDENTITY", fontSize = 12.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)

                    OutlinedTextField(
                        value = passengerName,
                        onValueChange = { viewModel.passengerNameInput.value = it },
                        label = { Text("FULL NAME (PASSPORT MATCH)") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = baggageKg.toString(),
                        onValueChange = {
                            val kg = it.toDoubleOrNull() ?: 0.0
                            viewModel.searchBaggageKg.value = kg.coerceIn(0.0, 150.0)
                        },
                        label = { Text("BAGGAGE / ALLOWED WEIGHT (KG)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        }

        // Cabin and Class
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("SELECT RE-ENTRY CABIN CLASS", fontSize = 12.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Card(
                            colors = CardDefaults.cardColors(
                                containerColor = if (seatClass == "Orbital First") MaterialTheme.colorScheme.primary.copy(alpha = 0.1f) else MaterialTheme.colorScheme.surfaceVariant
                            ),
                            border = BorderStroke(
                                1.5.dp,
                                if (seatClass == "Orbital First") MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline.copy(alpha = 0.5f)
                            ),
                            modifier = Modifier
                                .weight(1f)
                                .clickable { viewModel.selectedSeatClass.value = "Orbital First" }
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text("ORBITAL FIRST", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                Spacer(modifier = Modifier.height(4.dp))
                                Text("Private semi-gimbaled sleeper pod, active deceleration dampening.", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Spacer(modifier = Modifier.height(8.dp))
                                Text("+£4,000", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary, fontSize = 13.sp, fontFamily = FontFamily.Monospace)
                            }
                        }

                        Card(
                            colors = CardDefaults.cardColors(
                                containerColor = if (seatClass == "Orbital Business") MaterialTheme.colorScheme.primary.copy(alpha = 0.1f) else MaterialTheme.colorScheme.surfaceVariant
                            ),
                            border = BorderStroke(
                                1.5.dp,
                                if (seatClass == "Orbital Business") MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline.copy(alpha = 0.5f)
                            ),
                            modifier = Modifier
                                .weight(1f)
                                .clickable { viewModel.selectedSeatClass.value = "Orbital Business" }
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text("ORBITAL BUSINESS", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                Spacer(modifier = Modifier.height(4.dp))
                                Text("Premium contour seat, 180° panoramic atmospheric viewports.", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Spacer(modifier = Modifier.height(8.dp))
                                Text("+£0", fontWeight = FontWeight.Bold, fontSize = 13.sp, fontFamily = FontFamily.Monospace)
                            }
                        }
                    }
                }
            }
        }

        // Seat Selector Button
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("ALLOCATED CABIN SEAT", fontSize = 10.sp, color = MaterialTheme.colorScheme.secondary)
                        Text(seatCode, fontSize = 16.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary, fontFamily = FontFamily.Monospace)
                    }

                    Button(
                        onClick = { viewModel.navigateTo(AppScreen.BOOKING_SEAT_MAP) },
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary)
                    ) {
                        Icon(Icons.Default.AirlineSeatReclineExtra, contentDescription = null)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("CHANGE SEAT", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // Checkout pricing summary
        item {
            val classPremium = if (seatClass == "Orbital First") 4000.0 else 0.0
            val total = route!!.baseTicketPriceGbp * viewModel.searchPassengers.collectAsState().value + classPremium

            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("COST BREAKDOWN", fontSize = 10.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, color = MaterialTheme.colorScheme.secondary)
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Subtotal Base Transit (x${viewModel.searchPassengers.collectAsState().value})", fontSize = 13.sp)
                        Text(String.format(Locale.US, "£%,.0f", route!!.baseTicketPriceGbp * viewModel.searchPassengers.collectAsState().value), fontSize = 13.sp, fontFamily = FontFamily.Monospace)
                    }
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Cabin Class Upgrades", fontSize = 13.sp)
                        Text(String.format(Locale.US, "£%,.0f", classPremium), fontSize = 13.sp, fontFamily = FontFamily.Monospace)
                    }
                    Divider(modifier = Modifier.padding(vertical = 8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("TOTAL COST (INCL. FUEL TAXES)", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        Text(String.format(Locale.US, "£%,.0f", total), fontSize = 18.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary, fontFamily = FontFamily.Monospace)
                    }
                }
            }
        }

        // Confirm
        item {
            Button(
                onClick = { viewModel.confirmBooking() },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .testTag("confirm_booking_button"),
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
            ) {
                Icon(Icons.Default.Payments, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("AUTHORIZE PAYMENT & BOOK", fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
fun BookingSeatMapScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val selectedSeat by viewModel.selectedSeatCode.collectAsState()

    BackHandler {
        viewModel.navigateBack()
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = { viewModel.navigateBack() }) {
                Icon(Icons.Default.ArrowBack, contentDescription = "Back")
            }
            Spacer(modifier = Modifier.width(8.dp))
            Column {
                Text("NEWTON CRADLE SEATING", fontSize = 11.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, color = MaterialTheme.colorScheme.secondary)
                Text("AEROSPACE COMPARTMENT", fontSize = 18.sp, fontWeight = FontWeight.Bold)
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Grid explanation
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(16.dp, Alignment.CenterHorizontally)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(modifier = Modifier.size(16.dp).border(1.dp, MaterialTheme.colorScheme.outline).background(Color.White))
                Spacer(modifier = Modifier.width(4.dp))
                Text("Available", fontSize = 12.sp)
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(modifier = Modifier.size(16.dp).background(MaterialTheme.colorScheme.primary))
                Spacer(modifier = Modifier.width(4.dp))
                Text("Your Seat", fontSize = 12.sp)
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(modifier = Modifier.size(16.dp).background(Color.LightGray))
                Spacer(modifier = Modifier.width(4.dp))
                Text("Occupied", fontSize = 12.sp)
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // CABIN SCHEMATIC
        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(8.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Nose Cone indicator
                Box(
                    modifier = Modifier
                        .width(120.dp)
                        .height(30.dp)
                        .clip(RoundedCornerShape(topStart = 100.dp, topEnd = 100.dp))
                        .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.2f))
                        .border(1.dp, MaterialTheme.colorScheme.primary, RoundedCornerShape(topStart = 100.dp, topEnd = 100.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Text("NOSE CONE / COCKPIT", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                }

                Spacer(modifier = Modifier.height(12.dp))

                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(6.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    items((1..12).toList()) { row ->
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Text(
                                text = String.format(Locale.US, "%02d", row),
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace,
                                modifier = Modifier.width(20.dp)
                            )

                            // Seat A
                            val seatA = "Row $row, Seat A"
                            val isSelectedA = selectedSeat == seatA
                            val isOccupiedA = row % 3 == 0 && row != 4

                            Box(
                                modifier = Modifier
                                    .size(38.dp)
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(
                                        when {
                                            isSelectedA -> MaterialTheme.colorScheme.primary
                                            isOccupiedA -> Color.LightGray
                                            else -> Color.White
                                        }
                                    )
                                    .border(
                                        1.dp,
                                        if (isSelectedA) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline
                                    )
                                    .clickable(enabled = !isOccupiedA) {
                                        viewModel.selectedSeatCode.value = seatA
                                    },
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    "A",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isSelectedA) Color.White else Color.Black
                                )
                            }

                            // Seat B
                            val seatB = "Row $row, Seat B"
                            val isSelectedB = selectedSeat == seatB
                            val isOccupiedB = row == 5 || row == 8

                            Box(
                                modifier = Modifier
                                    .size(38.dp)
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(
                                        when {
                                            isSelectedB -> MaterialTheme.colorScheme.primary
                                            isOccupiedB -> Color.LightGray
                                            else -> Color.White
                                        }
                                    )
                                    .border(
                                        1.dp,
                                        if (isSelectedB) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline
                                    )
                                    .clickable(enabled = !isOccupiedB) {
                                        viewModel.selectedSeatCode.value = seatB
                                    },
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    "B",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isSelectedB) Color.White else Color.Black
                                )
                            }

                            // AISLE SPACING
                            Spacer(modifier = Modifier.width(16.dp))

                            // Seat C
                            val seatC = "Row $row, Seat C"
                            val isSelectedC = selectedSeat == seatC
                            val isOccupiedC = row == 1 || row == 10

                            Box(
                                modifier = Modifier
                                    .size(38.dp)
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(
                                        when {
                                            isSelectedC -> MaterialTheme.colorScheme.primary
                                            isOccupiedC -> Color.LightGray
                                            else -> Color.White
                                        }
                                    )
                                    .border(
                                        1.dp,
                                        if (isSelectedC) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline
                                    )
                                    .clickable(enabled = !isOccupiedC) {
                                        viewModel.selectedSeatCode.value = seatC
                                    },
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    "C",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isSelectedC) Color.White else Color.Black
                                )
                            }

                            // Seat D
                            val seatD = "Row $row, Seat D"
                            val isSelectedD = selectedSeat == seatD
                            val isOccupiedD = row % 4 == 0

                            Box(
                                modifier = Modifier
                                    .size(38.dp)
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(
                                        when {
                                            isSelectedD -> MaterialTheme.colorScheme.primary
                                            isOccupiedD -> Color.LightGray
                                            else -> Color.White
                                        }
                                    )
                                    .border(
                                        1.dp,
                                        if (isSelectedD) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline
                                    )
                                    .clickable(enabled = !isOccupiedD) {
                                        viewModel.selectedSeatCode.value = seatD
                                    },
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    "D",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isSelectedD) Color.White else Color.Black
                                )
                            }
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        Button(
            onClick = { viewModel.navigateBack() },
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp)
                .testTag("select_seat_button")
        ) {
            Text("CONFIRM SEATING LAYOUT", fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun BookingConfirmationScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val booking by viewModel.latestBooking.collectAsState()

    BackHandler {
        viewModel.navigateTo(AppScreen.HOME)
    }

    if (booking == null) return

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Icon(
                Icons.Default.CheckCircle,
                contentDescription = null,
                tint = Color(0xFF10B981),
                modifier = Modifier.size(56.dp)
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text("TRANSACTION AUTHORIZED", fontSize = 12.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, color = Color(0xFF10B981))
            Text("BOARDING VOUCHER ISSUED", fontSize = 20.sp, fontWeight = FontWeight.Bold)
        }

        // Voucher Boarding Pass card
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.5.dp, MaterialTheme.colorScheme.primary),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    // Header Brand
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("NEWTON BOARDING PASS", fontSize = 11.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, color = MaterialTheme.colorScheme.primary)
                        Text(booking!!.id, fontSize = 11.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Route details
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(booking!!.route.origin.code, fontSize = 32.sp, fontWeight = FontWeight.ExtraBold, fontFamily = FontFamily.SansSerif)
                            Text(booking!!.route.origin.name.replace("Newton ", ""), fontSize = 11.sp, color = MaterialTheme.colorScheme.secondary)
                        }

                        Icon(
                            Icons.Default.RocketLaunch,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(32.dp)
                        )

                        Column(horizontalAlignment = Alignment.End) {
                            Text(booking!!.route.destination.code, fontSize = 32.sp, fontWeight = FontWeight.ExtraBold, fontFamily = FontFamily.SansSerif)
                            Text(booking!!.route.destination.name.replace("Newton ", ""), fontSize = 11.sp, color = MaterialTheme.colorScheme.secondary)
                        }
                    }

                    Divider(modifier = Modifier.padding(vertical = 14.dp))

                    // Passenger Details Grid
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("PASSENGER", fontSize = 9.sp, color = MaterialTheme.colorScheme.secondary)
                            Text(booking!!.passengerName, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        }
                        Column {
                            Text("MISSION ID", fontSize = 9.sp, color = MaterialTheme.colorScheme.secondary)
                            Text(booking!!.missionId, fontSize = 13.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                        }
                        Column {
                            Text("LAUNCH PAD", fontSize = 9.sp, color = MaterialTheme.colorScheme.secondary)
                            Text("PAD-A", fontSize = 13.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("CABIN / SEAT", fontSize = 9.sp, color = MaterialTheme.colorScheme.secondary)
                            Text(booking!!.seatCode, fontSize = 13.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                        }
                        Column {
                            Text("DEPARTURE DATE", fontSize = 9.sp, color = MaterialTheme.colorScheme.secondary)
                            Text(booking!!.date, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        }
                        Column {
                            Text("CLASS", fontSize = 9.sp, color = MaterialTheme.colorScheme.secondary)
                            Text(booking!!.seatClass, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Mock Barcode
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp)
                            .background(Color.White)
                            .border(1.dp, Color.Black)
                            .padding(8.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            "||| | |||| ||| || |||| || ||| || |||| | |",
                            fontFamily = FontFamily.Monospace,
                            fontSize = 24.sp,
                            letterSpacing = 1.sp,
                            color = Color.Black
                        )
                    }

                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        "SCAN AT PAD SECURITY DEPARTURE PORT",
                        fontSize = 8.sp,
                        color = MaterialTheme.colorScheme.secondary,
                        modifier = Modifier.fillMaxWidth(),
                        textAlign = TextAlign.Center,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
        }

        item {
            Button(
                onClick = {
                    viewModel.selectActiveMissionForTracking(booking!!.missionId, AppScreen.CUSTOMER_DASHBOARD)
                },
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
            ) {
                Icon(Icons.Default.TrackChanges, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("LAUNCH PHYSICAL MISSION TRACKER", fontWeight = FontWeight.Bold)
            }
        }

        item {
            OutlinedButton(
                onClick = { viewModel.navigateTo(AppScreen.HOME) },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("RETURN TO CENTRAL PORTAL", fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
fun CargoPortalScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val origin by viewModel.searchOrigin.collectAsState()
    val dest by viewModel.searchDest.collectAsState()
    val spaceports by viewModel.spaceports.collectAsState()

    val weightKg by viewModel.cargoWeightKgInput.collectAsState()
    val volumeM3 by viewModel.cargoVolumeM3Input.collectAsState()
    val declaredValue by viewModel.cargoDeclaredValueInput.collectAsState()
    val priority by viewModel.cargoPriorityInput.collectAsState()
    val handling by viewModel.cargoHandlingInput.collectAsState()

    var showOriginDropdown by remember { mutableStateOf(false) }
    var showDestDropdown by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text("NEWTON FREIGHT NETWORK", fontSize = 11.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, color = MaterialTheme.colorScheme.secondary)
            Text("ORBITAL LOGISTICS CONSOLE", fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(4.dp))
            Text("Book high-priority physical assets, medical supplies, sensitive electricals, or documents onto suborbital rocket freight manifests.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }

        // Form
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text("ROUTE CONSTRAINTS", fontSize = 12.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)

                    // Origin selector
                    Box(modifier = Modifier.fillMaxWidth()) {
                        OutlinedButton(
                            onClick = { showOriginDropdown = true },
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.onSurface)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(horizontalAlignment = Alignment.Start) {
                                    Text("FREIGHT ORIGIN", fontSize = 10.sp, color = MaterialTheme.colorScheme.secondary)
                                    val port = SpaceportRegistry.getByCode(origin)
                                    Text(port?.name ?: origin, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                                }
                                Icon(Icons.Default.ArrowDropDown, contentDescription = "Dropdown")
                            }
                        }

                        DropdownMenu(
                            expanded = showOriginDropdown,
                            onDismissRequest = { showOriginDropdown = false }
                        ) {
                            spaceports.forEach { port ->
                                DropdownMenuItem(
                                    text = { Text("${port.name} (${port.code})") },
                                    onClick = {
                                        viewModel.searchOrigin.value = port.code
                                        showOriginDropdown = false
                                    }
                                )
                            }
                        }
                    }

                    // Destination selector
                    Box(modifier = Modifier.fillMaxWidth()) {
                        OutlinedButton(
                            onClick = { showDestDropdown = true },
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.onSurface)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(horizontalAlignment = Alignment.Start) {
                                    Text("FREIGHT DESTINATION", fontSize = 10.sp, color = MaterialTheme.colorScheme.secondary)
                                    val port = SpaceportRegistry.getByCode(dest)
                                    Text(port?.name ?: dest, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                                }
                                Icon(Icons.Default.ArrowDropDown, contentDescription = "Dropdown")
                            }
                        }

                        DropdownMenu(
                            expanded = showDestDropdown,
                            onDismissRequest = { showDestDropdown = false }
                        ) {
                            spaceports.forEach { port ->
                                DropdownMenuItem(
                                    text = { Text("${port.name} (${port.code})") },
                                    onClick = {
                                        viewModel.searchDest.value = port.code
                                        showDestDropdown = false
                                    }
                                )
                            }
                        }
                    }
                }
            }
        }

        // Metrics Form
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text("CARGO SPECIFICATIONS", fontSize = 12.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedTextField(
                            value = weightKg.toString(),
                            onValueChange = {
                                val v = it.toDoubleOrNull() ?: 0.0
                                viewModel.cargoWeightKgInput.value = v.coerceIn(1.0, 95000.0)
                            },
                            label = { Text("WEIGHT (KG)") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(1f)
                        )

                        OutlinedTextField(
                            value = volumeM3.toString(),
                            onValueChange = {
                                val v = it.toDoubleOrNull() ?: 0.0
                                viewModel.cargoVolumeM3Input.value = v.coerceIn(0.1, 150.0)
                            },
                            label = { Text("VOLUME (M³)") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(1f)
                        )
                    }

                    OutlinedTextField(
                        value = declaredValue.toString(),
                        onValueChange = {
                            val v = it.toDoubleOrNull() ?: 0.0
                            viewModel.cargoDeclaredValueInput.value = v.coerceIn(1.0, 10000000.0)
                        },
                        label = { Text("DECLARED COMMERCIAL VALUE (GBP)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = handling,
                        onValueChange = { viewModel.cargoHandlingInput.value = it },
                        label = { Text("SPECIAL HANDLING REQUIREMENTS") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        }

        // Priority class selector
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("SELECT MANIFEST CORRIDOR PRIORITY", fontSize = 12.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf("STANDARD", "EXPRESS", "CRITICAL").forEach { p ->
                            Button(
                                onClick = { viewModel.cargoPriorityInput.value = p },
                                modifier = Modifier.weight(1f),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (priority == p) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
                                    contentColor = if (priority == p) Color.White else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            ) {
                                Text(p, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }

        // Book cargo
        item {
            Button(
                onClick = { viewModel.createCargoShipment() },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp),
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
            ) {
                Icon(Icons.Default.LocalShipping, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("QUOTE & DISPATCH FREIGHT CORRIDOR", fontWeight = FontWeight.Bold)
            }
        }
    }
}
