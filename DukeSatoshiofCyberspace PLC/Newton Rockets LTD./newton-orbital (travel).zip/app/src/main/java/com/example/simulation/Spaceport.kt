package com.example.simulation

enum class SpaceportStatus {
    OPERATIONAL,
    CAUTION,
    STANDBY,
    DEGRADED
}

data class Spaceport(
    val id: String,
    val name: String,
    val code: String,
    val country: String,
    val latitude: Double,
    val longitude: Double,
    val timezone: String,
    val status: SpaceportStatus = SpaceportStatus.OPERATIONAL,
    val padCount: Int = 3,
    val activePads: List<PadStatus> = listOf(
        PadStatus(1, "PAD-A", PadState.READY, "None"),
        PadStatus(2, "PAD-B", PadState.TURNAROUND, "NO-2712"),
        PadStatus(3, "PAD-C", PadState.MAINTENANCE, "None")
    ),
    val turnaroundCapacity: Int = 12 // Hours
)

enum class PadState {
    READY,
    TURNAROUND,
    MAINTENANCE,
    PRELAUNCH
}

data class PadStatus(
    val id: Int,
    val name: String,
    val state: PadState,
    val currentMissionId: String
)

object SpaceportRegistry {
    val spaceports = listOf(
        Spaceport("SP-LSP", "Newton London Spaceport", "LSP", "United Kingdom", 51.5074, -0.1278, "GMT"),
        Spaceport("SP-SSP", "Newton Sydney Spaceport", "SSP", "Australia", -33.8688, 151.2093, "AEST"),
        Spaceport("SP-NSP", "Newton New York Spaceport", "NSP", "United States", 40.7128, -74.0060, "EST"),
        Spaceport("SP-DSP", "Newton Dubai Spaceport", "DSP", "United Arab Emirates", 25.2048, 55.2708, "GST"),
        Spaceport("SP-TSP", "Newton Tokyo Spaceport", "TSP", "Japan", 35.6762, 139.6503, "JST"),
        Spaceport("SP-SGP", "Newton Singapore Spaceport", "SGP", "Singapore", 1.3521, 103.8198, "SGT"),
        Spaceport("SP-ASP", "Newton Los Angeles Spaceport", "ASP", "United States", 34.0522, -118.2437, "PST"),
        Spaceport("SP-PSP", "Newton Paris Spaceport", "PSP", "France", 48.8566, 2.3522, "CET")
    )

    fun getByCode(code: String): Spaceport? {
        return spaceports.find { it.code.equals(code, ignoreCase = true) }
    }

    fun getById(id: String): Spaceport? {
        return spaceports.find { it.id == id }
    }
}
