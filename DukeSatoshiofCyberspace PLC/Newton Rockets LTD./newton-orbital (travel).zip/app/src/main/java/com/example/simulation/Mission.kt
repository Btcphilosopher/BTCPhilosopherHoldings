package com.example.simulation

data class Mission(
    val id: String,
    val route: Route,
    val passengers: Int,
    val cargoWeightKg: Double,
    val status: MissionPhase = MissionPhase.PRE_LAUNCH,
    val currentStepIndex: Int = 0,
    val telemetrySteps: List<TrajectoryStep> = emptyList()
) {
    val currentTelemetry: TrajectoryStep?
        get() = telemetrySteps.getOrNull(currentStepIndex)

    val isCompleted: Boolean
        get() = status == MissionPhase.COMPLETED || currentStepIndex >= telemetrySteps.size - 1
}

object ScenarioRegistry {
    val scenarios = listOf(
        ScenarioPreset("London → Sydney", "LSP", "SSP", "Ultra range intercontinental travel spanning Europe to Australia."),
        ScenarioPreset("London → New York", "LSP", "NSP", "Classic transatlantic suborbital hop."),
        ScenarioPreset("New York → Tokyo", "NSP", "TSP", "High-velocity Pacific crossing bypassing Arctic airspaces."),
        ScenarioPreset("Dubai → Singapore", "DSP", "SGP", "Rapid Middle-East to Southeast Asia transit corridor."),
        ScenarioPreset("Paris → Los Angeles", "PSP", "ASP", "Polar trajectory connecting major economic centers."),
        ScenarioPreset("Singapore → Sydney", "SGP", "SSP", "Fast regional suborbital shuttle."),
        ScenarioPreset("Tokyo → London", "TSP", "LSP", "Westbound orbital trajectory crossing Eurasian plains.")
    )
}

data class ScenarioPreset(
    val title: String,
    val originCode: String,
    val destCode: String,
    val description: String
)
