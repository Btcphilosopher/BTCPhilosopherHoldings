package com.example.repository

import com.example.simulation.*
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.UUID
import kotlin.random.Random

data class Booking(
    val id: String,
    val passengerName: String,
    val route: Route,
    val seatClass: String, // "Orbital First" or "Orbital Business"
    val seatCode: String,
    val baggageKg: Double,
    val price: Double,
    val date: String,
    val missionId: String,
    val status: String = "CONFIRMED"
)

data class CargoShipment(
    val id: String,
    val route: Route,
    val weightKg: Double,
    val volumeM3: Double,
    val declaredValueGbp: Double,
    val priority: String, // "CRITICAL", "EXPRESS", "STANDARD"
    val handling: String,
    val price: Double,
    val missionId: String,
    val status: String = "MANIFESTED"
)

class NewtonRepository private constructor() {

    private val repositoryScope = CoroutineScope(Dispatchers.Default + SupervisorJob())

    // Spaceports & Vehicles State
    private val _spaceports = MutableStateFlow(SpaceportRegistry.spaceports)
    val spaceports = _spaceports.asStateFlow()

    private val _vehicles = MutableStateFlow(FleetRegistry.vehicles)
    val vehicles = _vehicles.asStateFlow()

    // Bookings State
    private val _bookings = MutableStateFlow<List<Booking>>(emptyList())
    val bookings = _bookings.asStateFlow()

    // Cargo State
    private val _cargoShipments = MutableStateFlow<List<CargoShipment>>(emptyList())
    val cargoShipments = _cargoShipments.asStateFlow()

    // Active & Scheduled Missions
    private val _missions = MutableStateFlow<List<Mission>>(emptyList())
    val missions = _missions.asStateFlow()

    // Simulation settings for trajectory engine
    private val _simConfig = MutableStateFlow(SimulationConfig())
    val simConfig = _simConfig.asStateFlow()

    init {
        // Seed some initial demo missions and bookings so the app feels populated on startup
        seedInitialData()

        // Background ticker to run real-time telemetry updates for all active missions
        repositoryScope.launch {
            while (isActive) {
                delay(1200) // Telemetry updates every 1.2 seconds
                advanceActiveMissions()
            }
        }
    }

    private fun seedInitialData() {
        val lsp = SpaceportRegistry.getByCode("LSP")!!
        val ssp = SpaceportRegistry.getByCode("SSP")!!
        val nsp = SpaceportRegistry.getByCode("NSP")!!
        val tsp = SpaceportRegistry.getByCode("TSP")!!

        // Seed 1: Active Flight (London to Sydney in transit)
        val lspToSspRoute = RouteEngine.searchJourneys("LSP", "SSP", 40).firstOrNull()
        if (lspToSspRoute != null) {
            val steps = TrajectoryEngine.runFullTrajectorySimulation(
                lsp.latitude, lsp.longitude, ssp.latitude, ssp.longitude, lspToSspRoute.allocatedVehicle
            )
            // Put it about 45% through the flight
            val startIndex = (steps.size * 0.45).toInt().coerceIn(0, steps.size - 1)
            val currentPhase = steps[startIndex].phase

            val activeMission = Mission(
                id = "NO-2714",
                route = lspToSspRoute,
                passengers = 42,
                cargoWeightKg = 12000.0,
                status = currentPhase,
                currentStepIndex = startIndex,
                telemetrySteps = steps
            )

            // Seed a booking for the current user
            val demoBooking = Booking(
                id = "B-NTWN891",
                passengerName = "Principal Architect",
                route = lspToSspRoute,
                seatClass = "Orbital First",
                seatCode = "Row 02, Seat A",
                baggageKg = 25.0,
                price = lspToSspRoute.baseTicketPriceGbp * 1.5,
                date = "17 Oct 2027",
                missionId = "NO-2714"
            )

            _bookings.value = listOf(demoBooking)
            _missions.value = listOf(activeMission)
        }

        // Seed 2: Scheduled Flight (New York to Tokyo)
        val nspToTspRoute = RouteEngine.searchJourneys("NSP", "TSP", 12).firstOrNull()
        if (nspToTspRoute != null) {
            val steps = TrajectoryEngine.runFullTrajectorySimulation(
                nsp.latitude, nsp.longitude, tsp.latitude, tsp.longitude, nspToTspRoute.allocatedVehicle
            )
            val scheduledMission = Mission(
                id = "NO-3801",
                route = nspToTspRoute,
                passengers = 14,
                cargoWeightKg = 8500.0,
                status = MissionPhase.PRE_LAUNCH,
                currentStepIndex = 0,
                telemetrySteps = steps
            )
            _missions.value = _missions.value + scheduledMission
        }
    }

    private fun advanceActiveMissions() {
        val updatedList = _missions.value.map { mission ->
            // We only advance missions that are not in finished phases or can be ticked
            if (mission.isCompleted) {
                mission.copy(status = MissionPhase.COMPLETED)
            } else {
                val nextIndex = mission.currentStepIndex + 1
                val targetStep = mission.telemetrySteps.getOrNull(nextIndex)
                if (targetStep != null) {
                    mission.copy(
                        currentStepIndex = nextIndex,
                        status = targetStep.phase
                    )
                } else {
                    mission.copy(status = MissionPhase.COMPLETED)
                }
            }
        }

        // Also update vehicle location / state matching active missions
        val updatedVehicles = _vehicles.value.map { vehicle ->
            val activeMission = updatedList.find { it.route.allocatedVehicle.id == vehicle.id }
            if (activeMission != null) {
                if (activeMission.status == MissionPhase.COMPLETED) {
                    vehicle.copy(status = VehicleStatus.TURNAROUND, locationCode = activeMission.route.destination.code)
                } else {
                    vehicle.copy(status = VehicleStatus.IN_FLIGHT)
                }
            } else {
                vehicle
            }
        }

        _missions.value = updatedList
        _vehicles.value = updatedVehicles
    }

    // Creates a new customer booking and launches its Mission simulation thread
    fun createBooking(
        passengerName: String,
        route: Route,
        seatClass: String,
        seatCode: String,
        baggageKg: Double,
        price: Double,
        date: String
    ): Booking {
        val missionId = "NO-${1000 + Random.nextInt(8999)}"

        // Pre-solve the entire physical flight trajectory using current config
        val steps = TrajectoryEngine.runFullTrajectorySimulation(
            route.origin.latitude, route.origin.longitude,
            route.destination.latitude, route.destination.longitude,
            route.allocatedVehicle,
            _simConfig.value
        )

        val newMission = Mission(
            id = missionId,
            route = route,
            passengers = Random.nextInt(15, route.allocatedVehicle.passengerCapacity.coerceAtLeast(20)),
            cargoWeightKg = Random.nextDouble(500.0, 8000.0),
            status = MissionPhase.PRE_LAUNCH,
            currentStepIndex = 0,
            telemetrySteps = steps
        )

        val newBooking = Booking(
            id = "B-${UUID.randomUUID().toString().take(8).uppercase()}",
            passengerName = passengerName,
            route = route,
            seatClass = seatClass,
            seatCode = seatCode,
            baggageKg = baggageKg,
            price = price,
            date = date,
            missionId = missionId
        )

        _bookings.value = _bookings.value + newBooking
        _missions.value = _missions.value + newMission

        return newBooking
    }

    // Creates cargo booking
    fun createCargoBooking(
        route: Route,
        weightKg: Double,
        volumeM3: Double,
        declaredValueGbp: Double,
        priority: String,
        handling: String,
        price: Double
    ): CargoShipment {
        val missionId = "NO-${1000 + Random.nextInt(8999)}"

        val steps = TrajectoryEngine.runFullTrajectorySimulation(
            route.origin.latitude, route.origin.longitude,
            route.destination.latitude, route.destination.longitude,
            route.allocatedVehicle,
            _simConfig.value
        )

        val newMission = Mission(
            id = missionId,
            route = route,
            passengers = 0,
            cargoWeightKg = weightKg,
            status = MissionPhase.PRE_LAUNCH,
            currentStepIndex = 0,
            telemetrySteps = steps
        )

        val newShipment = CargoShipment(
            id = "C-${UUID.randomUUID().toString().take(8).uppercase()}",
            route = route,
            weightKg = weightKg,
            volumeM3 = volumeM3,
            declaredValueGbp = declaredValueGbp,
            priority = priority,
            handling = handling,
            price = price,
            missionId = missionId
        )

        _cargoShipments.value = _cargoShipments.value + newShipment
        _missions.value = _missions.value + newMission

        return newShipment
    }

    // Launches a scheduled mission manually from Mission Control
    fun startMissionManually(missionId: String) {
        _missions.value = _missions.value.map { mission ->
            if (mission.id == missionId && mission.status == MissionPhase.PRE_LAUNCH) {
                mission.copy(status = MissionPhase.ASCENT, currentStepIndex = 0)
            } else {
                mission
            }
        }
    }

    // Update simulation physical properties in Engineering Mode
    fun updateSimulationConfig(newConfig: SimulationConfig) {
        _simConfig.value = newConfig
        // Recalculate trajectory steps for any upcoming/scheduled missions
        _missions.value = _missions.value.map { mission ->
            if (mission.status == MissionPhase.PRE_LAUNCH) {
                val newSteps = TrajectoryEngine.runFullTrajectorySimulation(
                    mission.route.origin.latitude, mission.route.origin.longitude,
                    mission.route.destination.latitude, mission.route.destination.longitude,
                    mission.route.allocatedVehicle,
                    newConfig
                )
                mission.copy(telemetrySteps = newSteps, currentStepIndex = 0)
            } else {
                mission
            }
        }
    }

    companion object {
        @Volatile
        private var INSTANCE: NewtonRepository? = null

        fun getInstance(): NewtonRepository {
            return INSTANCE ?: synchronized(this) {
                val instance = NewtonRepository()
                INSTANCE = instance
                instance
            }
        }
    }
}
