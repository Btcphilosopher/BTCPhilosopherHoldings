package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import com.example.simulation.SpaceportRegistry
import com.example.simulation.TrajectoryStep
import kotlin.math.*

@Composable
fun MissionMapCanvas(
    currentStep: TrajectoryStep?,
    allSteps: List<TrajectoryStep>,
    originCode: String,
    destCode: String,
    modifier: Modifier = Modifier
) {
    val origin = remember(originCode) { SpaceportRegistry.getByCode(originCode) }
    val dest = remember(destCode) { SpaceportRegistry.getByCode(destCode) }

    val gridColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.25f)
    val pathColor = MaterialTheme.colorScheme.primary
    val activeColor = MaterialTheme.colorScheme.primary
    val textColor = MaterialTheme.colorScheme.onSurface

    Canvas(
        modifier = modifier
            .fillMaxWidth()
            .height(220.dp)
            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f))
    ) {
        val width = size.width
        val height = size.height
        val centerX = width / 2f
        val centerY = height / 2f
        val radius = min(width, height) * 0.45f

        // Draw deep space background stars (subtle circles)
        drawCircle(
            color = Color.Black.copy(alpha = 0.05f),
            radius = radius * 1.2f,
            center = Offset(centerX, centerY)
        )

        // Draw Earth perimeter
        drawCircle(
            color = gridColor,
            radius = radius,
            center = Offset(centerX, centerY),
            style = Stroke(width = 1.5.dp.toPx())
        )

        // Draw latitude and longitude grids inside Earth circle for aerospace feel
        for (lat in -60..60 step 30) {
            val latRad = Math.toRadians(lat.toDouble())
            val r = radius * cos(latRad).toFloat()
            val y = centerY - radius * sin(latRad).toFloat()
            if (r > 0) {
                // Draw latitude lines as squashed ellipses
                drawOval(
                    color = gridColor.copy(alpha = 0.15f),
                    topLeft = Offset(centerX - r, y - (r * 0.1f)),
                    size = Size(r * 2, r * 0.2f),
                    style = Stroke(width = 1.dp.toPx())
                )
            }
        }

        for (lon in -120..120 step 40) {
            val lonRad = Math.toRadians(lon.toDouble())
            val rx = radius * sin(lonRad).toFloat()
            // Draw longitudinal arc lines
            drawOval(
                color = gridColor.copy(alpha = 0.15f),
                topLeft = Offset(centerX - rx, centerY - radius),
                size = Size(rx * 2, radius * 2),
                style = Stroke(width = 1.dp.toPx())
            )
        }

        // Project coordinate Helper to screen space
        fun getProjectedOffset(lat: Double, lon: Double): Offset {
            // Very simple orthographic or equirectangular projection to coordinate disk
            val latRad = Math.toRadians(lat)
            val lonRad = Math.toRadians(lon)

            val x = centerX + radius * cos(latRad).toFloat() * sin(lonRad).toFloat() * 0.9f
            val y = centerY - radius * sin(latRad).toFloat() * 0.9f
            return Offset(x, y)
        }

        // Draw Spaceport Hubs
        SpaceportRegistry.spaceports.forEach { port ->
            val pos = getProjectedOffset(port.latitude, port.longitude)
            val isOrigin = port.code == originCode
            val isDest = port.code == destCode

            when {
                isOrigin -> {
                    drawCircle(
                        color = pathColor,
                        radius = 6.dp.toPx(),
                        center = pos
                    )
                    drawCircle(
                        color = Color.White,
                        radius = 2.dp.toPx(),
                        center = pos
                    )
                }
                isDest -> {
                    drawCircle(
                        color = Color(0xFF10B981), // Green
                        radius = 6.dp.toPx(),
                        center = pos
                    )
                    drawCircle(
                        color = Color.White,
                        radius = 2.dp.toPx(),
                        center = pos
                    )
                }
                else -> {
                    drawCircle(
                        color = textColor.copy(alpha = 0.4f),
                        radius = 3.dp.toPx(),
                        center = pos
                    )
                }
            }
        }

        // Draw flight path from simulation steps
        if (allSteps.isNotEmpty()) {
            val path = Path()
            val startPos = getProjectedOffset(allSteps.first().latitude, allSteps.first().longitude)
            path.moveTo(startPos.x, startPos.y)

            allSteps.forEach { step ->
                val pos = getProjectedOffset(step.latitude, step.longitude)
                path.lineTo(pos.x, pos.y)
            }

            drawPath(
                path = path,
                color = pathColor.copy(alpha = 0.5f),
                style = Stroke(
                    width = 2.dp.toPx(),
                    pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 10f), 0f)
                )
            )
        }

        // Draw Active Rocket Position with glow
        if (currentStep != null) {
            val rocketPos = getProjectedOffset(currentStep.latitude, currentStep.longitude)

            // Outer pulse circle
            drawCircle(
                color = activeColor.copy(alpha = 0.3f),
                radius = 12.dp.toPx(),
                center = rocketPos
            )

            // Inner core point
            drawCircle(
                color = activeColor,
                radius = 5.dp.toPx(),
                center = rocketPos
            )
        }
    }
}
