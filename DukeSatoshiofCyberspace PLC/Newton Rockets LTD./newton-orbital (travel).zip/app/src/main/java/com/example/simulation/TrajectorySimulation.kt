package com.example.simulation

import kotlin.math.*

enum class IntegrationMethod {
    EULER,
    RUNGE_KUTTA_4
}

enum class MissionPhase {
    BOARDING,
    TAXI,
    PRE_LAUNCH,
    ASCENT,
    CRUISE, // Suborbital drift
    DESCENT, // Re-entry
    LANDING,
    DISEMBARKATION,
    COMPLETED
}

data class TrajectoryStep(
    val timeSec: Double,
    val phase: MissionPhase,
    val altitudeM: Double,
    val velocityMs: Double,
    val accelerationG: Double,
    val distanceTravelledM: Double,
    val propellantMassKg: Double,
    val totalMassKg: Double,
    val thrustN: Double,
    val dragN: Double,
    val potentialEnergyJ: Double,
    val kineticEnergyJ: Double,
    val totalMechanicalEnergyJ: Double,
    val latitude: Double,
    val longitude: Double
)

data class SimulationConfig(
    val integrationMethod: IntegrationMethod = IntegrationMethod.RUNGE_KUTTA_4,
    val timeStepSec: Double = 1.0,
    val cdDragCoefficient: Double = 0.3,
    val crossSectionalAreaM2: Double = 12.5,
    val gravityGM: Double = 3.986004418e14, // Earth gravitational parameter
    val earthRadiusM: Double = 6371000.0,
    val scaleHeightAtmosphereM: Double = 8500.0,
    val seaLevelAirDensity: Double = 1.225
)

object TrajectoryEngine {

    // Calculate great-circle distance in meters between two lat/lon pairs
    fun calculateGreatCircleDistanceM(
        lat1: Double, lon1: Double,
        lat2: Double, lon2: Double,
        earthRadiusM: Double = 6371000.0
    ): Double {
        val phi1 = Math.toRadians(lat1)
        val phi2 = Math.toRadians(lat2)
        val deltaPhi = Math.toRadians(lat2 - lat1)
        val deltaLambda = Math.toRadians(lon2 - lon1)

        val a = sin(deltaPhi / 2).pow(2) +
                cos(phi1) * cos(phi2) * sin(deltaLambda / 2).pow(2)
        val c = 2 * atan2(sqrt(a), sqrt(1 - a))
        return earthRadiusM * c
    }

    // High fidelity suborbital trajectory simulation
    fun runFullTrajectorySimulation(
        originLat: Double, originLon: Double,
        destLat: Double, destLon: Double,
        vehicle: Vehicle,
        config: SimulationConfig = SimulationConfig()
    ): List<TrajectoryStep> {
        val steps = mutableListOf<TrajectoryStep>()
        val totalDistanceM = calculateGreatCircleDistanceM(originLat, originLon, destLat, destLon, config.earthRadiusM)

        // Initialize parameters
        var time = 0.0
        var altitude = 0.0
        var velocity = 0.0
        var distanceTravelled = 0.0
        var propellant = vehicle.propellantCapacityKg
        var dryMass = vehicle.dryMassKg
        var totalMass = dryMass + propellant
        val dt = config.timeStepSec

        // Add PRE-LAUNCH state
        steps.add(
            createStepRecord(time, MissionPhase.PRE_LAUNCH, altitude, velocity, 1.0, distanceTravelled, propellant, totalMass, 0.0, 0.0, originLat, originLon, destLat, destLon, totalDistanceM, config)
        )

        // Phased state machine simulation
        // Phase 1: Ascent (Burn engine to pitch over and enter space trajectory)
        val g0 = 9.80665
        val fuelBurnRateKgSec = vehicle.thrustN / (g0 * vehicle.ispSeconds)
        val targetAscentBurnTime = min(propellant / fuelBurnRateKgSec * 0.45, 120.0) // 45% of fuel burned in ascent

        var currentPhase = MissionPhase.ASCENT
        var localPhaseTime = 0.0

        while (altitude < vehicle.maxAltitudeKm * 1000.0 && distanceTravelled < totalDistanceM && steps.size < 1500) {
            localPhaseTime += dt
            time += dt

            // Air density: exponential scale model
            val rho = config.seaLevelAirDensity * exp(-altitude / config.scaleHeightAtmosphereM)
            val drag = 0.5 * config.cdDragCoefficient * rho * config.crossSectionalAreaM2 * velocity.pow(2)

            var thrust = 0.0
            if (currentPhase == MissionPhase.ASCENT && propellant > 100.0 && localPhaseTime < targetAscentBurnTime) {
                thrust = vehicle.thrustN
                propellant -= fuelBurnRateKgSec * dt
            } else if (currentPhase == MissionPhase.ASCENT) {
                // Change phase to CRUISE (ballistic coast)
                currentPhase = MissionPhase.CRUISE
                localPhaseTime = 0.0
            }

            totalMass = dryMass + propellant

            // Force equations
            val gravityAcceleration = config.gravityGM / (config.earthRadiusM + altitude).pow(2)
            val netThrustForce = thrust - drag
            val kinematicAccel = netThrustForce / totalMass - gravityAcceleration

            val netGForce = (netThrustForce / totalMass) / g0

            // Integration
            if (config.integrationMethod == IntegrationMethod.RUNGE_KUTTA_4) {
                // RK4 update for 1D trajectory projection
                val k1_v = kinematicAccel
                val k1_x = velocity

                val half_v = velocity + 0.5 * dt * k1_v
                val half_alt = altitude + 0.5 * dt * k1_x
                val k2_v = (thrust - (0.5 * config.cdDragCoefficient * (config.seaLevelAirDensity * exp(-half_alt / config.scaleHeightAtmosphereM)) * config.crossSectionalAreaM2 * half_v.pow(2))) / totalMass - (config.gravityGM / (config.earthRadiusM + half_alt).pow(2))
                val k2_x = half_v

                val half_v2 = velocity + 0.5 * dt * k2_v
                val half_alt2 = altitude + 0.5 * dt * k2_x
                val k3_v = (thrust - (0.5 * config.cdDragCoefficient * (config.seaLevelAirDensity * exp(-half_alt2 / config.scaleHeightAtmosphereM)) * config.crossSectionalAreaM2 * half_v2.pow(2))) / totalMass - (config.gravityGM / (config.earthRadiusM + half_alt2).pow(2))
                val k3_x = half_v2

                val full_v = velocity + dt * k3_v
                val full_alt = altitude + dt * k3_x
                val k4_v = (thrust - (0.5 * config.cdDragCoefficient * (config.seaLevelAirDensity * exp(-full_alt / config.scaleHeightAtmosphereM)) * config.crossSectionalAreaM2 * full_v.pow(2))) / totalMass - (config.gravityGM / (config.earthRadiusM + full_alt).pow(2))
                val k4_x = full_v

                velocity += (dt / 6.0) * (k1_v + 2 * k2_v + 2 * k3_v + k4_v)
                altitude += (dt / 6.0) * (k1_x + 2 * k2_x + 2 * k3_x + k4_x)
            } else {
                // Euler method
                velocity += kinematicAccel * dt
                altitude += velocity * dt
            }

            // Downrange distance calculation - linear projection based on velocity vector
            val pathPitchAngle = if (currentPhase == MissionPhase.ASCENT) 1.2 else 0.4 // radians
            val horizVelocity = velocity * cos(pathPitchAngle)
            distanceTravelled += horizVelocity * dt

            // Ensure altitude doesn't drop below 0 in drift
            if (altitude <= 0.0) {
                altitude = 0.0
                if (currentPhase == MissionPhase.CRUISE) {
                    break
                }
            }

            // Phase transition to Descent
            if (currentPhase == MissionPhase.CRUISE && velocity < 100.0) {
                // Peak of ballistic arc reached or slowing down
                currentPhase = MissionPhase.DESCENT
                localPhaseTime = 0.0
            }

            // Add step
            steps.add(
                createStepRecord(time, currentPhase, altitude, velocity, netGForce, distanceTravelled, propellant, totalMass, thrust, drag, originLat, originLon, destLat, destLon, totalDistanceM, config)
            )

            // Break if we exceed range
            if (distanceTravelled >= totalDistanceM) {
                break
            }
        }

        // Phase 2: Descent & Atmospheric Re-entry
        var descentTime = 0.0
        while (distanceTravelled < totalDistanceM * 0.92 && steps.size < 2500) {
            descentTime += dt
            time += dt

            val rho = config.seaLevelAirDensity * exp(-altitude / config.scaleHeightAtmosphereM)
            val drag = 0.5 * config.cdDragCoefficient * rho * config.crossSectionalAreaM2 * velocity.pow(2)
            totalMass = dryMass + propellant

            // Ballistic falling down
            val gravityAcceleration = config.gravityGM / (config.earthRadiusM + altitude).pow(2)
            val descentAccel = drag / totalMass - gravityAcceleration // drag opposes descent velocity

            // Decrease altitude, increase velocity (gaining kinetic energy as we drop)
            velocity += descentAccel * dt
            altitude -= abs(velocity) * dt * 0.6 // Controlled descent path
            if (altitude < 15000.0) {
                break // Initiate landing burn below 15km
            }

            distanceTravelled += abs(velocity) * dt * 0.75

            steps.add(
                createStepRecord(time, MissionPhase.DESCENT, altitude, velocity, -drag / (totalMass * g0), distanceTravelled, propellant, totalMass, 0.0, drag, originLat, originLon, destLat, destLon, totalDistanceM, config)
            )
        }

        // Phase 3: Powered Landing
        var landingTime = 0.0
        while (altitude > 0.0 && distanceTravelled < totalDistanceM && steps.size < 3500) {
            landingTime += dt
            time += dt

            val rho = config.seaLevelAirDensity * exp(-altitude / config.scaleHeightAtmosphereM)
            val drag = 0.5 * config.cdDragCoefficient * rho * config.crossSectionalAreaM2 * velocity.pow(2)

            // Retro propulsion
            var thrust = 0.0
            if (propellant > 50.0) {
                thrust = vehicle.thrustN * 0.65 // Retro burn is throttled
                propellant -= fuelBurnRateKgSec * 0.65 * dt
            }

            totalMass = dryMass + propellant
            val gravityAcceleration = config.gravityGM / (config.earthRadiusM + altitude).pow(2)

            // Retro thrust decelerates landing velocity
            val landingDecel = (thrust + drag) / totalMass - gravityAcceleration
            velocity -= landingDecel * dt
            if (velocity < 10.0) {
                velocity = 10.0 // Slow down to final terminal velocity
            }

            altitude -= velocity * dt
            if (altitude < 0) {
                altitude = 0.0
                velocity = 0.0
            }

            distanceTravelled += (totalDistanceM - distanceTravelled) * 0.1 // Intercept landing site

            steps.add(
                createStepRecord(time, MissionPhase.LANDING, altitude, velocity, landingDecel / g0, distanceTravelled, propellant, totalMass, thrust, drag, originLat, originLon, destLat, destLon, totalDistanceM, config)
            )
        }

        // Final Completed State
        steps.add(
            createStepRecord(time + dt, MissionPhase.COMPLETED, 0.0, 0.0, 1.0, totalDistanceM, propellant, dryMass + propellant, 0.0, 0.0, destLat, destLon, destLat, destLon, totalDistanceM, config)
        )

        return steps
    }

    private fun createStepRecord(
        timeSec: Double,
        phase: MissionPhase,
        altitudeM: Double,
        velocityMs: Double,
        accelerationG: Double,
        distanceTravelledM: Double,
        propellantMassKg: Double,
        totalMassKg: Double,
        thrustN: Double,
        dragN: Double,
        originLat: Double,
        originLon: Double,
        destLat: Double,
        destLon: Double,
        totalDistanceM: Double,
        config: SimulationConfig
    ): TrajectoryStep {
        // Potential Energy: m * g * h
        val g = config.gravityGM / (config.earthRadiusM + altitudeM).pow(2)
        val pe = totalMassKg * g * altitudeM

        // Kinetic Energy: 0.5 * m * v^2
        val ke = 0.5 * totalMassKg * velocityMs.pow(2)

        // Map linear downrange distance to intermediate latitude/longitude values
        val fraction = if (totalDistanceM > 0.0) (distanceTravelledM / totalDistanceM).coerceIn(0.0, 1.0) else 1.0
        val lat = originLat + (destLat - originLat) * fraction
        val lon = originLon + (destLon - originLon) * fraction

        return TrajectoryStep(
            timeSec = timeSec,
            phase = phase,
            altitudeM = altitudeM,
            velocityMs = velocityMs,
            accelerationG = accelerationG,
            distanceTravelledM = distanceTravelledM,
            propellantMassKg = propellantMassKg,
            totalMassKg = totalMassKg,
            thrustN = thrustN,
            dragN = dragN,
            potentialEnergyJ = pe,
            kineticEnergyJ = ke,
            totalMechanicalEnergyJ = pe + ke,
            latitude = lat,
            longitude = lon
        )
    }
}
