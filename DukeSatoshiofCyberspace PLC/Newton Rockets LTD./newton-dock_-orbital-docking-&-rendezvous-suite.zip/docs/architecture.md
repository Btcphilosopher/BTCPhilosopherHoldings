# NEWTON DOCK Architecture & Theory Manual

## 1. System Philosophy
**THE DOCKING PORT IS THE INTERFACE.**
**THE RELATIVE STATE IS THE TRUTH.**
**THE PHYSICS IS THE PRODUCT.**

NEWTON DOCK is aerospace engineering software engineered for rigorous orbital rendezvous, relative navigation, 6-DOF terminal approach corridor control, compliant interface contact dynamics, capture state estimation, and Monte Carlo clearance verification.

## 2. Mathematical Formulations

### 2.1 Orbital & Relative Dynamics
Relative motion in the target Local Vertical Local Horizontal (LVLH) frame is governed by the Clohessy-Wiltshire (Hill) linearized equations:

$$\ddot{x} - 2n\dot{y} - 3n^2 x = \frac{F_x}{m}$$
$$\ddot{y} + 2n\dot{x} = \frac{F_y}{m}$$
$$\ddot{z} + n^2 z = \frac{F_z}{m}$$

where:
- $n = \sqrt{\frac{\mu}{a^3}}$ is the target orbit mean motion.
- $x$ is along the radial direction ($+R$-bar / away from primary body).
- $y$ is along the velocity direction ($+V$-bar / in-track).
- $z$ is along the angular momentum vector ($+H$-bar / out-of-plane cross-track).

### 2.2 Six-Degree-of-Freedom Rigid Body Dynamics
Translational dynamics:
$$m \ddot{\mathbf{r}} = \mathbf{F}_{thrust} + \mathbf{F}_{contact} + \mathbf{F}_{grav}$$

Rotational kinematics and Euler's dynamical equations:
$$\dot{\mathbf{q}} = \frac{1}{2} \mathbf{q} \otimes \begin{bmatrix} 0 \\ \boldsymbol{\omega} \end{bmatrix}$$
$$\mathbf{I}\dot{\boldsymbol{\omega}} + \boldsymbol{\omega} \times (\mathbf{I}\boldsymbol{\omega}) = \boldsymbol{\tau}_{thrust} + \boldsymbol{\tau}_{contact}$$

### 2.3 Compliant Interface Contact Dynamics (Hunt-Crossley Model)
To prevent nonphysical adhesive tension upon interface rebound, normal contact load is computed using the non-linear elastoplastic Hunt-Crossley formulation:
$$F_n = \max\left(0, k \delta^n + \frac{3}{2}\alpha k \delta^n \dot{\delta}\right) + F_{latch}$$

where:
- $\delta$ is interface penetration depth.
- $\dot{\delta}$ is penetration rate.
- $k$ is structural interface contact stiffness ($250\text{ kN/m}^{1.5}$).
- $\alpha$ is dissipation coefficient ($0.15\text{ s/m}$).
- $n = 1.5$ is the Hertzian contact exponent.

### 2.4 Extended Kalman Filter Navigation (EKF)
The 16-state navigation filter continuously fuses tactical IMU accelerations, gyroscopic rates, LIDAR time-of-flight ranges, and optical target camera 8-marker PnP pose estimates.
$$\mathbf{K}_k = \mathbf{P}_k^- \mathbf{H}_k^T (\mathbf{H}_k \mathbf{P}_k^- \mathbf{H}_k^T + \mathbf{R}_k)^{-1}$$
$$\chi^2 = \boldsymbol{\nu}_k^T \mathbf{S}_k^{-1} \boldsymbol{\nu}_k$$
Chi-squared consistency gating rejects spurious sensor outliers and detects optical blackout conditions.
