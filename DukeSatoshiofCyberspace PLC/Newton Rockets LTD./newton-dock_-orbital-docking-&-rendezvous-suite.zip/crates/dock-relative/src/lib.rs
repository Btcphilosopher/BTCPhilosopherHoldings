//! dock-relative: Relative orbital dynamics (Clohessy-Wiltshire & Tschauner-Hempel equations)

use nalgebra::Vector3;

/// Computes Clohessy-Wiltshire linear relative orbital acceleration in Hill/LVLH frame:
/// x'' = 2*n*y' + 3*n^2*x + f_x/m   (Radial R-bar)
/// y'' = -2*n*x' + f_y/m            (In-track V-bar)
/// z'' = -n^2*z + f_z/m             (Cross-track H-bar)
pub fn cw_acceleration(
    r_lvlh: &Vector3<f64>,
    v_lvlh: &Vector3<f64>,
    mean_motion_rad_per_sec: f64,
    thrust_acc_mps2: &Vector3<f64>,
) -> Vector3<f64> {
    let n = mean_motion_rad_per_sec;
    let n2 = n * n;
    Vector3::new(
        2.0 * n * v_lvlh.y + 3.0 * n2 * r_lvlh.x + thrust_acc_mps2.x,
        -2.0 * n * v_lvlh.x + thrust_acc_mps2.y,
        -n2 * r_lvlh.z + thrust_acc_mps2.z,
    )
}

/// Analytical State Transition Matrix propagation for unforced Clohessy-Wiltshire relative motion
pub fn propagate_cw_analytical(
    r0: &Vector3<f64>,
    v0: &Vector3<f64>,
    n: f64,
    dt: f64,
) -> (Vector3<f64>, Vector3<f64>) {
    let nt = n * dt;
    let sin_nt = nt.sin();
    let cos_nt = nt.cos();

    let x = (4.0 - 3.0 * cos_nt) * r0.x + (sin_nt / n) * v0.x + (2.0 / n) * (1.0 - cos_nt) * v0.y;
    let y = 6.0 * (sin_nt - nt) * r0.x + r0.y - (2.0 / n) * (1.0 - cos_nt) * v0.x + ((4.0 * sin_nt - 3.0 * nt) / n) * v0.y;
    let z = cos_nt * r0.z + (sin_nt / n) * v0.z;

    let vx = 3.0 * n * sin_nt * r0.x + cos_nt * v0.x + 2.0 * sin_nt * v0.y;
    let vy = 6.0 * n * (cos_nt - 1.0) * r0.x - 2.0 * sin_nt * v0.x + (4.0 * cos_nt - 3.0) * v0.y;
    let vz = -n * sin_nt * r0.z + cos_nt * v0.z;

    (Vector3::new(x, y, z), Vector3::new(vx, vy, vz))
}
