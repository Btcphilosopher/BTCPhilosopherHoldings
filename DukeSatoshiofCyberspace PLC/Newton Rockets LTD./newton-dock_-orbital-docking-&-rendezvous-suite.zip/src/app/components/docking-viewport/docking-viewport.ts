// High-Precision 3D Docking Port & Orbital Trajectory Canvas Visualizer
// Renders Target Spacecraft, Chaser 6-DOF Vehicle, RCS Plumes, Corridor Cone, Reticles, and Trajectory Trails.

import {
  ChangeDetectionStrategy,
  Component,
  ElementRef,
  Input,
  OnDestroy,
  OnInit,
  ViewChild,
  signal,
} from '@angular/core';
import { MatIconModule } from '@angular/material/icon';
import { CommonModule } from '@angular/common';
import { Vector3, Vec3, Quaternion, Quat, ReferenceFrame } from '../../core/physics/math3d';
import { Spacecraft6DofState } from '../../core/physics/spacecraft-6dof';
import { GuidanceCommand } from '../../core/physics/guidance';
import { ThrusterAllocationResult } from '../../core/physics/control';
import { StateMachineStatus } from '../../core/physics/docking-state-machine';
import { ContactForceResult } from '../../core/physics/contact-dynamics';
import { TelemetryRecorder } from '../../core/telemetry/telemetry-recorder';

export type CameraViewMode = 'CHASE_CAM' | 'PORT_CAM' | 'CHASER_POV' | 'TOP_DOWN' | 'SIDE_VIEW';

@Component({
  selector: 'app-docking-viewport',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="relative w-full h-full bg-slate-950 flex flex-col select-none overflow-hidden border border-slate-800 rounded-xl">
      <!-- HUD Top Overlay Bar -->
      <div class="absolute top-0 left-0 right-0 z-10 px-4 py-2 bg-slate-900/80 backdrop-blur-sm border-b border-slate-800/80 flex items-center justify-between">
        <div class="flex items-center gap-3">
          <span class="inline-flex items-center gap-1.5 px-2 py-0.5 rounded text-xs font-mono font-semibold bg-cyan-950 text-cyan-400 border border-cyan-800/50">
            <mat-icon class="text-sm scale-75">videocam</mat-icon>
            VIEW: {{ viewMode() }}
          </span>
          <span class="text-xs font-mono text-slate-400">
            FRAME: <span class="text-slate-200 font-semibold">{{ activeFrame }}</span>
          </span>
          <span class="text-xs font-mono text-slate-400 hidden sm:inline">
            RANGE: <span class="text-emerald-400 font-mono font-bold">{{ rangeM.toFixed(3) }} m</span>
          </span>
          <span class="text-xs font-mono text-slate-400 hidden sm:inline">
            CLOSING: <span class="text-amber-400 font-mono font-bold">{{ closingVelMps.toFixed(3) }} m/s</span>
          </span>
        </div>

        <!-- Camera Angle Switcher Buttons -->
        <div class="flex items-center gap-1 bg-slate-950/80 p-0.5 rounded-lg border border-slate-800">
          <button
            (click)="setViewMode('CHASE_CAM')"
            [class.bg-slate-800]="viewMode() === 'CHASE_CAM'"
            [class.text-cyan-400]="viewMode() === 'CHASE_CAM'"
            class="px-2 py-1 text-xs font-mono rounded hover:bg-slate-800/60 text-slate-400 transition"
            title="External 3/4 Isometric Chase Camera"
          >
            ISO CHASE
          </button>
          <button
            (click)="setViewMode('PORT_CAM')"
            [class.bg-slate-800]="viewMode() === 'PORT_CAM'"
            [class.text-cyan-400]="viewMode() === 'PORT_CAM'"
            class="px-2 py-1 text-xs font-mono rounded hover:bg-slate-800/60 text-slate-400 transition"
            title="Target Docking Port Boresight"
          >
            TARGET PORT
          </button>
          <button
            (click)="setViewMode('CHASER_POV')"
            [class.bg-slate-800]="viewMode() === 'CHASER_POV'"
            [class.text-cyan-400]="viewMode() === 'CHASER_POV'"
            class="px-2 py-1 text-xs font-mono rounded hover:bg-slate-800/60 text-slate-400 transition"
            title="Chaser Optical Sensor POV"
          >
            CHASER POV
          </button>
          <button
            (click)="setViewMode('TOP_DOWN')"
            [class.bg-slate-800]="viewMode() === 'TOP_DOWN'"
            [class.text-cyan-400]="viewMode() === 'TOP_DOWN'"
            class="px-2 py-1 text-xs font-mono rounded hover:bg-slate-800/60 text-slate-400 transition"
            title="Top-down Orbital Plane V-bar"
          >
            TOP (V-BAR)
          </button>
        </div>
      </div>

      <!-- Main 3D Canvas Rendering Area -->
      <div class="relative flex-1 w-full h-full min-h-[360px] cursor-grab active:cursor-grabbing"
           (mousedown)="onMouseDown($event)"
           (mousemove)="onMouseMove($event)"
           (mouseup)="onMouseUp()"
           (wheel)="onWheel($event)">
        <canvas #canvas3d class="w-full h-full block"></canvas>

        <!-- Docking Reticle Crosshair in Center -->
        @if (viewMode() === 'PORT_CAM' || viewMode() === 'CHASER_POV') {
          <div class="absolute inset-0 pointer-events-none flex items-center justify-center">
            <div class="relative w-48 h-48 border border-emerald-500/30 rounded-full flex items-center justify-center">
              <div class="w-24 h-24 border border-emerald-500/50 rounded-full"></div>
              <div class="absolute top-0 bottom-0 w-[1px] bg-emerald-500/40"></div>
              <div class="absolute left-0 right-0 h-[1px] bg-emerald-500/40"></div>
              <!-- 4-Quadrant Alignment Ticks -->
              <div class="absolute -top-3 text-[9px] font-mono text-emerald-400">+Z (ZENITH)</div>
              <div class="absolute -bottom-3 text-[9px] font-mono text-emerald-400">-Z (NADIR)</div>
              <div class="absolute -left-10 text-[9px] font-mono text-emerald-400">-X (IN-TRACK)</div>
              <div class="absolute -right-10 text-[9px] font-mono text-emerald-400">+X (IN-TRACK)</div>
            </div>
          </div>
        }

        <!-- Tactical HUD Overlay Legends -->
        <div class="absolute bottom-3 left-3 pointer-events-none bg-slate-900/85 backdrop-blur-md p-2.5 rounded-lg border border-slate-800 font-mono text-xs text-slate-300 space-y-1">
          <div class="flex items-center gap-2">
            <span class="w-2.5 h-2.5 rounded-full" [class.bg-emerald-500]="guidance?.isInCorridor" [class.bg-rose-500]="!guidance?.isInCorridor"></span>
            <span>CORRIDOR: <strong [class.text-emerald-400]="guidance?.isInCorridor" [class.text-rose-400]="!guidance?.isInCorridor">{{ guidance?.isInCorridor ? 'ALIGNED' : 'MARGIN WARNING' }}</strong></span>
          </div>
          <div class="text-[11px] text-slate-400">
            LATERAL OFFSET: <span class="text-slate-200">{{ lateralOffsetM.toFixed(3) }} m</span>
          </div>
          <div class="text-[11px] text-slate-400">
            ATTITUDE ERROR: <span class="text-slate-200">{{ attitudeErrorDeg.toFixed(2) }}°</span>
          </div>
          <div class="text-[11px] text-slate-400">
            TTC (TIME-TO-CONTACT): <span class="text-amber-300">{{ guidance?.timeToContactSeconds && guidance!.timeToContactSeconds < 1000 ? guidance!.timeToContactSeconds.toFixed(1) + ' s' : 'N/A' }}</span>
          </div>
        </div>

        <!-- Contact Force & Latch HUD in Top Right -->
        @if (contactResult && contactResult.inContact) {
          <div class="absolute top-14 right-3 pointer-events-none bg-emerald-950/90 border border-emerald-500/60 p-2.5 rounded-lg font-mono text-xs text-emerald-300 animate-pulse">
            <div class="flex items-center gap-1.5 font-bold text-emerald-400">
              <mat-icon class="text-sm">sensors</mat-icon>
              PHYSICAL CONTACT ENGAGED
            </div>
            <div class="text-[11px] mt-1">NORMAL LOAD: {{ contactResult.normalForce.toFixed(1) }} N</div>
            <div class="text-[11px]">PENETRATION: {{ (contactResult.penetrationDepth * 1000).toFixed(1) }} mm</div>
            <div class="text-[11px]">LATCHES: {{ contactResult.latchEngaged ? 'ENGAGED' : 'ALIGNING' }}</div>
          </div>
        }
      </div>
    </div>
  `,
})
export class DockingViewport implements OnInit, OnDestroy {
  @ViewChild('canvas3d', { static: true }) canvasRef!: ElementRef<HTMLCanvasElement>;

  @Input() chaserState: Spacecraft6DofState | null = null;
  @Input() guidance: GuidanceCommand | null = null;
  @Input() thrusterAllocation: ThrusterAllocationResult | null = null;
  @Input() stateMachineStatus: StateMachineStatus | null = null;
  @Input() contactResult: ContactForceResult | null = null;
  @Input() telemetry: TelemetryRecorder | null = null;
  @Input() activeFrame: ReferenceFrame = 'LVLH';

  readonly viewMode = signal<CameraViewMode>('CHASE_CAM');

  // Camera Orbit Controls
  private camDistance = 35.0; // meters
  private camYaw = -0.5;      // radians
  private camPitch = 0.35;    // radians
  private isDragging = false;
  private dragStartX = 0;
  private dragStartY = 0;

  private animationFrameId: number | null = null;

  get rangeM(): number {
    return this.chaserState ? Vec3.norm(this.chaserState.position) : 0;
  }

  get closingVelMps(): number {
    return this.chaserState ? -this.chaserState.velocity.y : 0;
  }

  get lateralOffsetM(): number {
    if (!this.chaserState) return 0;
    return Math.sqrt(
      this.chaserState.position.x * this.chaserState.position.x +
      this.chaserState.position.z * this.chaserState.position.z
    );
  }

  get attitudeErrorDeg(): number {
    if (!this.chaserState) return 0;
    const euler = Quat.toEuler(this.chaserState.attitude);
    return (Math.sqrt(euler.pitch * euler.pitch + euler.yaw * euler.yaw) * 180) / Math.PI;
  }

  ngOnInit() {
    this.startRendering();
  }

  ngOnDestroy() {
    if (this.animationFrameId) {
      cancelAnimationFrame(this.animationFrameId);
    }
  }

  setViewMode(mode: CameraViewMode) {
    this.viewMode.set(mode);
    if (mode === 'CHASE_CAM') {
      this.camDistance = Math.max(12, Math.min(150, this.rangeM * 1.3));
      this.camYaw = -0.6;
      this.camPitch = 0.35;
    } else if (mode === 'PORT_CAM') {
      this.camDistance = 2.0;
      this.camYaw = 0;
      this.camPitch = 0;
    } else if (mode === 'CHASER_POV') {
      this.camDistance = 0.1;
      this.camYaw = Math.PI;
      this.camPitch = 0;
    } else if (mode === 'TOP_DOWN') {
      this.camDistance = Math.max(20, this.rangeM * 1.4);
      this.camYaw = 0;
      this.camPitch = Math.PI / 2 - 0.01;
    }
  }

  onMouseDown(e: MouseEvent) {
    this.isDragging = true;
    this.dragStartX = e.clientX;
    this.dragStartY = e.clientY;
  }

  onMouseMove(e: MouseEvent) {
    if (!this.isDragging) return;
    const dx = e.clientX - this.dragStartX;
    const dy = e.clientY - this.dragStartY;
    this.dragStartX = e.clientX;
    this.dragStartY = e.clientY;

    this.camYaw += dx * 0.008;
    this.camPitch = Math.max(-Math.PI / 2 + 0.1, Math.min(Math.PI / 2 - 0.1, this.camPitch - dy * 0.008));
  }

  onMouseUp() {
    this.isDragging = false;
  }

  onWheel(e: WheelEvent) {
    e.preventDefault();
    this.camDistance = Math.max(1.5, Math.min(250, this.camDistance * (1.0 + e.deltaY * 0.0015)));
  }

  private startRendering() {
    const render = () => {
      this.draw3DScene();
      this.animationFrameId = requestAnimationFrame(render);
    };
    this.animationFrameId = requestAnimationFrame(render);
  }

  private draw3DScene() {
    const canvas = this.canvasRef.nativeElement;
    if (!canvas) return;

    // Handle canvas high-DPI scaling
    const rect = canvas.getBoundingClientRect();
    const width = rect.width;
    const height = rect.height;
    const dpr = window.devicePixelRatio || 1;

    if (canvas.width !== width * dpr || canvas.height !== height * dpr) {
      canvas.width = width * dpr;
      canvas.height = height * dpr;
    }

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.save();
    ctx.scale(dpr, dpr);

    // Clear background: Deep space gradient with orbital starfield
    const grad = ctx.createLinearGradient(0, 0, width, height);
    grad.addColorStop(0, '#030712');
    grad.addColorStop(0.5, '#080e1e');
    grad.addColorStop(1, '#020617');
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, width, height);

    // Draw Subtle Earth Limb in distant background (orbital horizon)
    this.drawEarthLimb(ctx, width, height);

    // Compute Camera Transform Matrix
    // Target spacecraft is fixed at world origin (0, 0, 0)
    // Chaser is at (chaser.position.x, chaser.position.y, chaser.position.z)
    const chaserPos = this.chaserState?.position ?? { x: 0, y: 35, z: 0 };
    const chaserAtt = this.chaserState?.attitude ?? Quat.identity();

    // Setup 3D Projection
    const cx = width / 2;
    const cy = height / 2;
    const fov = 480; // Focal length

    let camPos: Vector3;
    let lookAt: Vector3;

    if (this.viewMode() === 'PORT_CAM') {
      camPos = { x: 0, y: -0.5, z: 0 };
      lookAt = { x: 0, y: 100, z: 0 };
    } else if (this.viewMode() === 'CHASER_POV') {
      camPos = { x: chaserPos.x, y: chaserPos.y + 0.5, z: chaserPos.z };
      lookAt = { x: 0, y: 0, z: 0 };
    } else {
      // Orbit around midpoint between Target and Chaser
      const midY = chaserPos.y * 0.45;
      lookAt = { x: chaserPos.x * 0.3, y: midY, z: chaserPos.z * 0.3 };
      camPos = {
        x: lookAt.x + this.camDistance * Math.cos(this.camPitch) * Math.sin(this.camYaw),
        y: lookAt.y + this.camDistance * Math.sin(this.camPitch),
        z: lookAt.z + this.camDistance * Math.cos(this.camPitch) * Math.cos(this.camYaw),
      };
    }

    // 3D to 2D Projector function
    const project = (p: Vector3): { x: number; y: number; zDepth: number; visible: boolean } => {
      // Relative vector from camera to point
      const dx = p.x - camPos.x;
      const dy = p.y - camPos.y;
      const dz = p.z - camPos.z;

      // Camera orientation basis vectors
      const forward = Vec3.normalize(Vec3.sub(lookAt, camPos));
      const up = { x: 0, y: 0, z: 1 };
      const right = Vec3.normalize(Vec3.cross(forward, up));
      const camUp = Vec3.cross(right, forward);

      const xCam = dx * right.x + dy * right.y + dz * right.z;
      const yCam = dx * camUp.x + dy * camUp.y + dz * camUp.z;
      const zCam = dx * forward.x + dy * forward.y + dz * forward.z;

      if (zCam < 0.2) {
        return { x: 0, y: 0, zDepth: zCam, visible: false };
      }

      const xProj = cx + (xCam / zCam) * fov;
      const yProj = cy - (yCam / zCam) * fov;

      return { x: xProj, y: yProj, zDepth: zCam, visible: true };
    };

    // 1. Draw Docking Approach Cone & Keep-Out Zone
    this.drawDockingCorridorCone(ctx, project);

    // 2. Draw Relative Trajectory History Trail
    this.drawTrajectoryTrail(ctx, project);

    // 3. Draw Target Spacecraft (Orbital Station / Passive Target)
    this.drawTargetSpacecraft(ctx, project);

    // 4. Draw Chaser Spacecraft (6-DOF Active Servicing Vehicle)
    this.drawChaserSpacecraft(ctx, project, chaserPos, chaserAtt);

    // 5. Draw Active RCS Thruster Plumes
    if (this.thrusterAllocation) {
      this.drawRcsPlumes(ctx, project, chaserPos, chaserAtt);
    }

    // 6. Draw Coordinate Reference Frame Axes at Origin
    this.drawReferenceAxes(ctx, project);

    ctx.restore();
  }

  private drawEarthLimb(ctx: CanvasRenderingContext2D, width: number, height: number) {
    ctx.save();
    // Atmospheric glow curve at bottom of viewport
    const earthGrad = ctx.createRadialGradient(width / 2, height * 1.8, height * 0.7, width / 2, height * 1.8, height * 1.4);
    earthGrad.addColorStop(0, 'rgba(14, 116, 144, 0.25)');
    earthGrad.addColorStop(0.3, 'rgba(56, 189, 248, 0.12)');
    earthGrad.addColorStop(0.7, 'rgba(30, 58, 138, 0.05)');
    earthGrad.addColorStop(1, 'transparent');

    ctx.fillStyle = earthGrad;
    ctx.beginPath();
    ctx.arc(width / 2, height * 1.8, height * 1.3, 0, Math.PI * 2);
    ctx.fill();

    // Subtle starfield
    ctx.fillStyle = 'rgba(255, 255, 255, 0.4)';
    const starCoords = [
      [width * 0.12, height * 0.18], [width * 0.25, height * 0.08], [width * 0.42, height * 0.22],
      [width * 0.78, height * 0.14], [width * 0.88, height * 0.35], [width * 0.65, height * 0.06],
      [width * 0.15, height * 0.45], [width * 0.92, height * 0.12], [width * 0.35, height * 0.52]
    ];
    for (const [sx, sy] of starCoords) {
      ctx.beginPath();
      ctx.arc(sx, sy, 1.0, 0, Math.PI * 2);
      ctx.fill();
    }
    ctx.restore();
  }

  private drawDockingCorridorCone(
    ctx: CanvasRenderingContext2D,
    project: (p: Vector3) => { x: number; y: number; zDepth: number; visible: boolean }
  ) {
    ctx.save();
    const coneAngleRad = (12.0 * Math.PI) / 180;
    const tanAngle = Math.tan(coneAngleRad);

    // Draw green approach axis line from Target Port (0,0,0) to +Y 150m
    const pOrigin = project({ x: 0, y: 0, z: 0 });
    const pFar = project({ x: 0, y: 120, z: 0 });

    if (pOrigin.visible && pFar.visible) {
      ctx.strokeStyle = 'rgba(16, 185, 129, 0.4)';
      ctx.lineWidth = 1.5;
      ctx.setLineDash([4, 4]);
      ctx.beginPath();
      ctx.moveTo(pOrigin.x, pOrigin.y);
      ctx.lineTo(pFar.x, pFar.y);
      ctx.stroke();
      ctx.setLineDash([]);
    }

    // Draw corridor rings at 10m, 25m, 50m, 100m
    const ranges = [5, 15, 35, 75, 120];
    for (const r of ranges) {
      const radius = Math.max(0.2, r * tanAngle);
      const points: { x: number; y: number; visible: boolean }[] = [];
      const numSegments = 16;
      for (let i = 0; i <= numSegments; i++) {
        const theta = (i / numSegments) * Math.PI * 2;
        const pt = project({
          x: radius * Math.cos(theta),
          y: r,
          z: radius * Math.sin(theta),
        });
        points.push(pt);
      }

      ctx.strokeStyle = r <= 20 ? 'rgba(16, 185, 129, 0.4)' : 'rgba(56, 189, 248, 0.25)';
      ctx.lineWidth = 1;
      ctx.beginPath();
      let started = false;
      for (const p of points) {
        if (p.visible) {
          if (!started) {
            ctx.moveTo(p.x, p.y);
            started = true;
          } else {
            ctx.lineTo(p.x, p.y);
          }
        }
      }
      ctx.stroke();
    }
    ctx.restore();
  }

  private drawTrajectoryTrail(
    ctx: CanvasRenderingContext2D,
    project: (p: Vector3) => { x: number; y: number; zDepth: number; visible: boolean }
  ) {
    if (!this.telemetry) return;
    const frames = this.telemetry.getFrames();
    if (frames.length < 2) return;

    ctx.save();
    ctx.strokeStyle = 'rgba(56, 189, 248, 0.7)';
    ctx.lineWidth = 2;
    ctx.beginPath();

    let started = false;
    // Downsample for rendering speed
    const step = Math.max(1, Math.floor(frames.length / 100));
    for (let i = 0; i < frames.length; i += step) {
      const f = frames[i];
      const pt = project(f.truePos);
      if (pt.visible) {
        if (!started) {
          ctx.moveTo(pt.x, pt.y);
          started = true;
        } else {
          ctx.lineTo(pt.x, pt.y);
        }
      }
    }
    ctx.stroke();
    ctx.restore();
  }

  private drawTargetSpacecraft(
    ctx: CanvasRenderingContext2D,
    project: (p: Vector3) => { x: number; y: number; zDepth: number; visible: boolean }
  ) {
    ctx.save();
    // Target Spacecraft Bus at (0, -2.5, 0) with docking collar at (0, 0, 0)
    const pCenter = project({ x: 0, y: -2.5, z: 0 });
    const pPort = project({ x: 0, y: 0, z: 0 });

    if (!pCenter.visible && !pPort.visible) {
      ctx.restore();
      return;
    }

    // Draw Station Module Cylinder / Box
    const s = 1.8;
    const vertices = [
      project({ x: -s, y: -0.5, z: -s }),
      project({ x: s, y: -0.5, z: -s }),
      project({ x: s, y: -4.5, z: -s }),
      project({ x: -s, y: -4.5, z: -s }),
      project({ x: -s, y: -0.5, z: s }),
      project({ x: s, y: -0.5, z: s }),
      project({ x: s, y: -4.5, z: s }),
      project({ x: -s, y: -4.5, z: s }),
    ];

    ctx.strokeStyle = '#38bdf8';
    ctx.fillStyle = 'rgba(15, 23, 42, 0.85)';
    ctx.lineWidth = 1.5;

    // Draw wireframe edges
    const edges = [
      [0, 1], [1, 2], [2, 3], [3, 0], // Bottom face
      [4, 5], [5, 6], [6, 7], [7, 4], // Top face
      [0, 4], [1, 5], [2, 6], [3, 7]  // Vertical pillars
    ];

    for (const [i, j] of edges) {
      const p1 = vertices[i];
      const p2 = vertices[j];
      if (p1.visible && p2.visible) {
        ctx.beginPath();
        ctx.moveTo(p1.x, p1.y);
        ctx.lineTo(p2.x, p2.y);
        ctx.stroke();
      }
    }

    // Draw Solar Arrays on Station (+X and -X)
    const solarLeft = [
      project({ x: -2.0, y: -2.5, z: -0.8 }),
      project({ x: -8.0, y: -2.5, z: -0.8 }),
      project({ x: -8.0, y: -2.5, z: 0.8 }),
      project({ x: -2.0, y: -2.5, z: 0.8 }),
    ];
    const solarRight = [
      project({ x: 2.0, y: -2.5, z: -0.8 }),
      project({ x: 8.0, y: -2.5, z: -0.8 }),
      project({ x: 8.0, y: -2.5, z: 0.8 }),
      project({ x: 2.0, y: -2.5, z: 0.8 }),
    ];

    ctx.fillStyle = 'rgba(30, 64, 175, 0.4)';
    ctx.strokeStyle = '#60a5fa';

    for (const poly of [solarLeft, solarRight]) {
      if (poly.every(p => p.visible)) {
        ctx.beginPath();
        ctx.moveTo(poly[0].x, poly[0].y);
        for (let k = 1; k < poly.length; k++) ctx.lineTo(poly[k].x, poly[k].y);
        ctx.closePath();
        ctx.fill();
        ctx.stroke();
      }
    }

    // Draw Docking Collar Ring at (0,0,0)
    const ringRadius = 0.45;
    const ringPts: { x: number; y: number; visible: boolean }[] = [];
    for (let i = 0; i <= 12; i++) {
      const th = (i / 12) * Math.PI * 2;
      ringPts.push(project({ x: ringRadius * Math.cos(th), y: 0, z: ringRadius * Math.sin(th) }));
    }
    ctx.strokeStyle = '#10b981';
    ctx.lineWidth = 2.5;
    ctx.beginPath();
    let rStart = false;
    for (const rp of ringPts) {
      if (rp.visible) {
        if (!rStart) { ctx.moveTo(rp.x, rp.y); rStart = true; }
        else { ctx.lineTo(rp.x, rp.y); }
      }
    }
    ctx.stroke();

    ctx.restore();
  }

  private drawChaserSpacecraft(
    ctx: CanvasRenderingContext2D,
    project: (p: Vector3) => { x: number; y: number; zDepth: number; visible: boolean },
    chaserPos: Vector3,
    chaserAtt: Quaternion
  ) {
    ctx.save();
    // Chaser vehicle dimensions
    const w = 1.2;
    const L = 2.0;

    // Body vertices in local spacecraft frame (docking port forward at local -Y)
    const localVerts: Vector3[] = [
      { x: -w, y: -0.2, z: -w },
      { x: w, y: -0.2, z: -w },
      { x: w, y: L, z: -w },
      { x: -w, y: L, z: -w },
      { x: -w, y: -0.2, z: w },
      { x: w, y: -0.2, z: w },
      { x: w, y: L, z: w },
      { x: -w, y: L, z: w },
    ];

    // Transform local body vertices to world frame: p_world = r_chaser + Quat.rotate(att, p_local)
    const worldVerts = localVerts.map(lv => {
      const rotated = Quat.rotateVector(chaserAtt, lv);
      return project(Vec3.add(chaserPos, rotated));
    });

    ctx.fillStyle = 'rgba(2, 132, 199, 0.2)';
    ctx.strokeStyle = '#38bdf8';
    ctx.lineWidth = 1.8;

    const edges = [
      [0, 1], [1, 2], [2, 3], [3, 0],
      [4, 5], [5, 6], [6, 7], [7, 4],
      [0, 4], [1, 5], [2, 6], [3, 7]
    ];

    for (const [i, j] of edges) {
      const p1 = worldVerts[i];
      const p2 = worldVerts[j];
      if (p1.visible && p2.visible) {
        ctx.beginPath();
        ctx.moveTo(p1.x, p1.y);
        ctx.lineTo(p2.x, p2.y);
        ctx.stroke();
      }
    }

    // Draw Chaser Docking Probe / Guide Petals forward
    const probeTipLocal: Vector3 = { x: 0, y: -0.6, z: 0 };
    const probeTipWorld = project(Vec3.add(chaserPos, Quat.rotateVector(chaserAtt, probeTipLocal)));
    const probeBaseWorld = project(Vec3.add(chaserPos, Quat.rotateVector(chaserAtt, { x: 0, y: -0.2, z: 0 })));

    if (probeTipWorld.visible && probeBaseWorld.visible) {
      ctx.strokeStyle = '#f59e0b';
      ctx.lineWidth = 2.5;
      ctx.beginPath();
      ctx.moveTo(probeBaseWorld.x, probeBaseWorld.y);
      ctx.lineTo(probeTipWorld.x, probeTipWorld.y);
      ctx.stroke();

      // Petal cone
      ctx.fillStyle = 'rgba(245, 158, 11, 0.4)';
      ctx.beginPath();
      ctx.arc(probeTipWorld.x, probeTipWorld.y, 4, 0, Math.PI * 2);
      ctx.fill();
    }

    ctx.restore();
  }

  private drawRcsPlumes(
    ctx: CanvasRenderingContext2D,
    project: (p: Vector3) => { x: number; y: number; zDepth: number; visible: boolean },
    chaserPos: Vector3,
    chaserAtt: Quaternion
  ) {
    if (!this.thrusterAllocation) return;
    const firings = this.thrusterAllocation.firings;

    ctx.save();
    for (const f of firings) {
      if (f.dutyCycle <= 0.05) continue;

      // Identify pod location based on thrusterId
      const d = 1.2;
      const h = 1.0;
      let thrusterPosLocal: Vector3 = { x: d, y: h, z: d };
      if (f.thrusterId >= 4 && f.thrusterId < 8) thrusterPosLocal = { x: -d, y: h, z: d };
      else if (f.thrusterId >= 8 && f.thrusterId < 12) thrusterPosLocal = { x: d, y: -h, z: -d };
      else if (f.thrusterId >= 12) thrusterPosLocal = { x: -d, y: -h, z: -d };

      const nozzleWorld = Vec3.add(chaserPos, Quat.rotateVector(chaserAtt, thrusterPosLocal));
      const pNozzle = project(nozzleWorld);

      if (pNozzle.visible) {
        // Draw blue-white supersonic plume cone
        const plumeLength = 6 + f.dutyCycle * 14;
        ctx.fillStyle = 'rgba(147, 197, 253, 0.8)';
        ctx.shadowColor = '#60a5fa';
        ctx.shadowBlur = 8;
        ctx.beginPath();
        ctx.arc(pNozzle.x, pNozzle.y, plumeLength * 0.3, 0, Math.PI * 2);
        ctx.fill();
        ctx.shadowBlur = 0;
      }
    }
    ctx.restore();
  }

  private drawReferenceAxes(
    ctx: CanvasRenderingContext2D,
    project: (p: Vector3) => { x: number; y: number; zDepth: number; visible: boolean }
  ) {
    ctx.save();
    const p0 = project({ x: 0, y: 0, z: 0 });
    const px = project({ x: 2.5, y: 0, z: 0 });
    const py = project({ x: 0, y: 2.5, z: 0 });
    const pz = project({ x: 0, y: 0, z: 2.5 });

    if (p0.visible) {
      // X-axis (Red: Radial / In-track)
      if (px.visible) {
        ctx.strokeStyle = '#ef4444';
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.moveTo(p0.x, p0.y);
        ctx.lineTo(px.x, px.y);
        ctx.stroke();
      }
      // Y-axis (Green: Approach axis / V-bar)
      if (py.visible) {
        ctx.strokeStyle = '#10b981';
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.moveTo(p0.x, p0.y);
        ctx.lineTo(py.x, py.y);
        ctx.stroke();
      }
      // Z-axis (Blue: Cross-track / Zenith)
      if (pz.visible) {
        ctx.strokeStyle = '#3b82f6';
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.moveTo(p0.x, p0.y);
        ctx.lineTo(pz.x, pz.y);
        ctx.stroke();
      }
    }
    ctx.restore();
  }
}
