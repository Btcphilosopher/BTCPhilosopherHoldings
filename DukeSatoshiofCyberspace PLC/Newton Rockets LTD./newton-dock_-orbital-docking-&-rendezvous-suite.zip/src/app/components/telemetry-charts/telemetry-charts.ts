// High-Frequency Real-Time Telemetry Strip-Chart Plotter for NEWTON DOCK
// Plots Range, Closing Velocity, Attitude Euler Angles, EKF 3-Sigma Bounds, and Contact Loads.

import {
  ChangeDetectionStrategy,
  Component,
  ElementRef,
  Input,
  OnDestroy,
  OnInit,
  ViewChild,
  signal,
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { TelemetryRecorder, TelemetryFrame } from '../../core/telemetry/telemetry-recorder';

export type ChartCategory = 'RANGE_VELOCITY' | 'ATTITUDE_EULER' | 'NAV_COVARIANCE' | 'CONTACT_LOADS' | 'PROPULSION_DELTA_V';

@Component({
  selector: 'app-telemetry-charts',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="w-full bg-slate-950 border border-slate-800 rounded-xl flex flex-col select-none overflow-hidden">
      <!-- Chart Category Switcher Tab Bar -->
      <div class="px-4 py-2 bg-slate-900 border-b border-slate-800 flex items-center justify-between flex-wrap gap-2">
        <div class="flex items-center gap-2">
          <mat-icon class="text-cyan-400 text-sm">show_chart</mat-icon>
          <span class="text-xs font-mono font-bold text-slate-200 tracking-wider">TELEMETRY STRIP-CHART STREAM</span>
        </div>

        <div class="flex items-center gap-1 bg-slate-950 p-0.5 rounded-lg border border-slate-800">
          <button
            (click)="setCategory('RANGE_VELOCITY')"
            [class.bg-slate-800]="category() === 'RANGE_VELOCITY'"
            [class.text-cyan-400]="category() === 'RANGE_VELOCITY'"
            class="px-2.5 py-1 text-xs font-mono rounded text-slate-400 hover:bg-slate-800/60 transition"
          >
            RANGE & VELOCITY
          </button>
          <button
            (click)="setCategory('ATTITUDE_EULER')"
            [class.bg-slate-800]="category() === 'ATTITUDE_EULER'"
            [class.text-cyan-400]="category() === 'ATTITUDE_EULER'"
            class="px-2.5 py-1 text-xs font-mono rounded text-slate-400 hover:bg-slate-800/60 transition"
          >
            ATTITUDE (EULER)
          </button>
          <button
            (click)="setCategory('NAV_COVARIANCE')"
            [class.bg-slate-800]="category() === 'NAV_COVARIANCE'"
            [class.text-cyan-400]="category() === 'NAV_COVARIANCE'"
            class="px-2.5 py-1 text-xs font-mono rounded text-slate-400 hover:bg-slate-800/60 transition"
          >
            EKF 3σ UNCERTAINTY
          </button>
          <button
            (click)="setCategory('CONTACT_LOADS')"
            [class.bg-slate-800]="category() === 'CONTACT_LOADS'"
            [class.text-cyan-400]="category() === 'CONTACT_LOADS'"
            class="px-2.5 py-1 text-xs font-mono rounded text-slate-400 hover:bg-slate-800/60 transition"
          >
            CONTACT LOADS (N)
          </button>
          <button
            (click)="setCategory('PROPULSION_DELTA_V')"
            [class.bg-slate-800]="category() === 'PROPULSION_DELTA_V'"
            [class.text-cyan-400]="category() === 'PROPULSION_DELTA_V'"
            class="px-2.5 py-1 text-xs font-mono rounded text-slate-400 hover:bg-slate-800/60 transition"
          >
            PROPULSION & ΔV
          </button>
        </div>
      </div>

      <!-- Canvas Plotting Area -->
      <div class="relative w-full h-44 bg-slate-950 p-2">
        <canvas #chartCanvas class="w-full h-full block"></canvas>
      </div>
    </div>
  `,
})
export class TelemetryCharts implements OnInit, OnDestroy {
  @ViewChild('chartCanvas', { static: true }) canvasRef!: ElementRef<HTMLCanvasElement>;
  @Input() telemetry: TelemetryRecorder | null = null;

  readonly category = signal<ChartCategory>('RANGE_VELOCITY');
  private animId: number | null = null;

  ngOnInit() {
    this.startChartLoop();
  }

  ngOnDestroy() {
    if (this.animId) cancelAnimationFrame(this.animId);
  }

  setCategory(cat: ChartCategory) {
    this.category.set(cat);
  }

  private startChartLoop() {
    const loop = () => {
      this.drawChart();
      this.animId = requestAnimationFrame(loop);
    };
    this.animId = requestAnimationFrame(loop);
  }

  private drawChart() {
    const canvas = this.canvasRef?.nativeElement;
    if (!canvas) return;

    const rect = canvas.getBoundingClientRect();
    const width = rect.width;
    const height = rect.height;
    const dpr = window.devicePixelRatio || 1;

    if (canvas.width !== width * dpr || canvas.height !== height * dpr) {
      canvas.width = width * dpr;
      canvas.height = height * dpr;
    }

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.save();
    ctx.scale(dpr, dpr);

    // Background
    ctx.fillStyle = '#030712';
    ctx.fillRect(0, 0, width, height);

    // Draw Grid Lines
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.05)';
    ctx.lineWidth = 1;
    const numHGrids = 4;
    for (let i = 0; i <= numHGrids; i++) {
      const y = (height / numHGrids) * i;
      ctx.beginPath();
      ctx.moveTo(40, y);
      ctx.lineTo(width - 10, y);
      ctx.stroke();
    }

    if (!this.telemetry) {
      ctx.restore();
      return;
    }

    const frames = this.telemetry.getFrames();
    if (frames.length < 2) {
      ctx.fillStyle = '#64748b';
      ctx.font = '12px monospace';
      ctx.fillText('Awaiting telemetry frames...', width / 2 - 80, height / 2);
      ctx.restore();
      return;
    }

    // Plot data traces based on selected category
    const padLeft = 45;
    const padRight = 15;
    const plotW = width - padLeft - padRight;
    const padTop = 15;
    const padBottom = 20;
    const plotH = height - padTop - padBottom;

    // Time window: show up to the last 300 frames
    const windowFrames = frames.slice(Math.max(0, frames.length - 300));
    const cat = this.category();

    if (cat === 'RANGE_VELOCITY') {
      // Trace 1: Range [0 - 150m], Trace 2: Range Rate [-0.5 to +0.1 m/s]
      this.drawTrace(ctx, windowFrames, f => f.rangeM, 0, 125, plotW, plotH, padLeft, padTop, '#10b981', 'Range (m)');
      this.drawTrace(ctx, windowFrames, f => f.rangeRateMps * 100, -50, 10, plotW, plotH, padLeft, padTop, '#f59e0b', 'Closing Rate x100 (cm/s)');
    } else if (cat === 'ATTITUDE_EULER') {
      this.drawTrace(ctx, windowFrames, f => f.trueEulerDeg.roll, -5, 5, plotW, plotH, padLeft, padTop, '#ef4444', 'Roll (°)');
      this.drawTrace(ctx, windowFrames, f => f.trueEulerDeg.pitch, -5, 5, plotW, plotH, padLeft, padTop, '#10b981', 'Pitch (°)');
      this.drawTrace(ctx, windowFrames, f => f.trueEulerDeg.yaw, -5, 5, plotW, plotH, padLeft, padTop, '#38bdf8', 'Yaw (°)');
    } else if (cat === 'NAV_COVARIANCE') {
      this.drawTrace(ctx, windowFrames, f => f.sigmaPos3SigmaM.y, 0, 1.5, plotW, plotH, padLeft, padTop, '#a855f7', '3σ Y-axis (m)');
      this.drawTrace(ctx, windowFrames, f => f.sigmaPos3SigmaM.x, 0, 1.5, plotW, plotH, padLeft, padTop, '#ec4899', '3σ X-axis (m)');
      this.drawTrace(ctx, windowFrames, f => f.chiSquared, 0, 20, plotW, plotH, padLeft, padTop, '#38bdf8', 'Chi² Gate');
    } else if (cat === 'CONTACT_LOADS') {
      this.drawTrace(ctx, windowFrames, f => f.normalContactForceN, 0, 1500, plotW, plotH, padLeft, padTop, '#ef4444', 'Normal Contact Force (N)');
      this.drawTrace(ctx, windowFrames, f => f.penetrationDepthMm, 0, 40, plotW, plotH, padLeft, padTop, '#38bdf8', 'Penetration Depth (mm)');
    } else if (cat === 'PROPULSION_DELTA_V') {
      this.drawTrace(ctx, windowFrames, f => f.cumulativeDeltaVMps, 0, 5.0, plotW, plotH, padLeft, padTop, '#f59e0b', 'Cumulative ΔV (m/s)');
      this.drawTrace(ctx, windowFrames, f => f.cmdForceBodyN.y, -100, 100, plotW, plotH, padLeft, padTop, '#38bdf8', 'Cmd Force Y (N)');
    }

    ctx.restore();
  }

  private drawTrace(
    ctx: CanvasRenderingContext2D,
    frames: TelemetryFrame[],
    valFn: (f: TelemetryFrame) => number,
    minVal: number,
    maxVal: number,
    plotW: number,
    plotH: number,
    padLeft: number,
    padTop: number,
    color: string,
    label: string
  ) {
    ctx.strokeStyle = color;
    ctx.lineWidth = 1.8;
    ctx.beginPath();

    const n = frames.length;
    for (let i = 0; i < n; i++) {
      const f = frames[i];
      const val = valFn(f);
      const normVal = (val - minVal) / Math.max(1e-6, maxVal - minVal);
      const clamped = Math.max(0, Math.min(1, normVal));

      const x = padLeft + (i / Math.max(1, n - 1)) * plotW;
      const y = padTop + plotH - clamped * plotH;

      if (i === 0) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
    }
    ctx.stroke();

    // Draw current value label at end
    const lastVal = valFn(frames[n - 1]);
    ctx.fillStyle = color;
    ctx.font = '10px monospace';
    ctx.fillText(`${label}: ${lastVal.toFixed(2)}`, padLeft + 10, padTop + 14 + (color === '#f59e0b' ? 14 : color === '#38bdf8' ? 28 : color === '#a855f7' ? 14 : 0));
  }
}
