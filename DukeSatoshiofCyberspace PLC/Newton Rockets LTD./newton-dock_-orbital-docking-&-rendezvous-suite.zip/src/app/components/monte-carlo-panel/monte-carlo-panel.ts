// Monte Carlo Statistical Dispersion & Sensitivity Panel for NEWTON DOCK

import {
  ChangeDetectionStrategy,
  Component,
  OnInit,
  signal,
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { MonteCarloEngine, MonteCarloSummary } from '../../core/monte-carlo/monte-carlo-engine';

@Component({
  selector: 'app-monte-carlo-panel',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="w-full bg-slate-900/90 border border-slate-800 rounded-xl p-5 flex flex-col gap-5 text-slate-200">
      <!-- Header -->
      <div class="flex items-center justify-between border-b border-slate-800 pb-3 flex-wrap gap-3">
        <div>
          <div class="flex items-center gap-2">
            <mat-icon class="text-cyan-400">casino</mat-icon>
            <h2 class="text-base font-bold font-mono tracking-wide text-white">MONTE CARLO DISPERSION & CLEARANCE ANALYSIS</h2>
          </div>
          <p class="text-xs text-slate-400 mt-0.5">
            Parallel stochastic orbital docking dispersion solver (100 to 10,000 runs) with Sobol variance decomposition.
          </p>
        </div>

        <div class="flex items-center gap-3">
          <div class="flex items-center gap-2">
            <span class="text-xs font-mono text-slate-400">RUNS:</span>
            <select
              #runSelect
              (change)="selectedRunCount.set(+runSelect.value)"
              class="bg-slate-950 border border-slate-700 text-xs font-mono px-2.5 py-1.5 rounded-lg text-slate-200 focus:outline-none focus:border-cyan-500"
            >
              <option value="250">250 Runs</option>
              <option value="500" selected>500 Runs</option>
              <option value="1000">1,000 Runs</option>
              <option value="5000">5,000 Runs</option>
            </select>
          </div>

          <button
            (click)="runMonteCarlo()"
            [disabled]="isExecuting()"
            class="flex items-center gap-1.5 px-4 py-1.5 bg-cyan-600 hover:bg-cyan-500 disabled:bg-slate-800 text-white font-mono text-xs font-bold rounded-lg shadow-sm transition"
          >
            <mat-icon class="text-sm">{{ isExecuting() ? 'hourglass_top' : 'play_arrow' }}</mat-icon>
            {{ isExecuting() ? 'EXECUTING BATCH (' + progress() + '%)' : 'RUN DISPERSION SUITE' }}
          </button>
        </div>
      </div>

      <!-- Execution Progress Bar (if executing) -->
      @if (isExecuting()) {
        <div class="w-full bg-slate-950 rounded-full h-2 overflow-hidden border border-slate-800">
          <div class="bg-cyan-500 h-full transition-all duration-150" [style.width.%]="progress()"></div>
        </div>
      }

      @if (summary()) {
        <!-- Statistical Overview Summary Cards -->
        <div class="grid grid-cols-2 sm:grid-cols-4 gap-3 font-mono">
          <div class="p-3 bg-slate-950/80 border border-emerald-500/40 rounded-lg">
            <div class="text-[11px] text-emerald-400 font-semibold">CAPTURE PROBABILITY (P_CAP)</div>
            <div class="text-2xl font-bold text-white mt-1">{{ summary()!.captureProbabilityPercent.toFixed(1) }}%</div>
            <div class="text-[10px] text-slate-400 mt-0.5">{{ summary()!.captureCount }} / {{ summary()!.totalRuns }} Runs Passed</div>
          </div>

          <div class="p-3 bg-slate-950/80 border border-amber-500/40 rounded-lg">
            <div class="text-[11px] text-amber-400 font-semibold">ABORT PROBABILITY (P_ABORT)</div>
            <div class="text-2xl font-bold text-white mt-1">{{ summary()!.abortProbabilityPercent.toFixed(1) }}%</div>
            <div class="text-[10px] text-slate-400 mt-0.5">{{ summary()!.abortCount }} Abort Triggered</div>
          </div>

          <div class="p-3 bg-slate-950/80 border border-rose-500/40 rounded-lg">
            <div class="text-[11px] text-rose-400 font-semibold">COLLISION RISK (P_COLL)</div>
            <div class="text-2xl font-bold text-white mt-1">{{ summary()!.collisionProbabilityPercent.toFixed(2) }}%</div>
            <div class="text-[10px] text-slate-400 mt-0.5">{{ summary()!.collisionCount }} Hard Exceedances</div>
          </div>

          <div class="p-3 bg-slate-950/80 border border-cyan-500/40 rounded-lg">
            <div class="text-[11px] text-cyan-400 font-semibold">MEAN CONTACT LOAD</div>
            <div class="text-2xl font-bold text-white mt-1">{{ summary()!.peakForceMean.toFixed(0) }} ± {{ summary()!.peakForceStd.toFixed(0) }} N</div>
            <div class="text-[10px] text-slate-400 mt-0.5">Max Peak: {{ summary()!.peakForceMax.toFixed(0) }} N</div>
          </div>
        </div>

        <!-- Histograms & Distributions Grid -->
        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
          <!-- Force Histogram -->
          <div class="p-4 bg-slate-950 border border-slate-800 rounded-lg">
            <div class="flex items-center justify-between text-xs font-mono font-bold text-slate-300 mb-3">
              <span>PEAK CONTACT NORMAL FORCE DISTRIBUTION</span>
              <span class="text-slate-400 font-normal">Limit: 2500 N</span>
            </div>
            <div class="space-y-2 font-mono text-xs">
              @for (bin of summary()!.forceHistogram; track bin.binLabel) {
                <div class="flex items-center gap-3">
                  <span class="w-24 text-[11px] text-slate-400 shrink-0">{{ bin.binLabel }}</span>
                  <div class="flex-1 bg-slate-900 rounded-full h-3 overflow-hidden border border-slate-800">
                    <div class="bg-cyan-500 h-full rounded-full" [style.width.%]="(bin.count / summary()!.totalRuns) * 100"></div>
                  </div>
                  <span class="w-10 text-right text-[11px] text-slate-300 shrink-0">{{ bin.count }}</span>
                </div>
              }
            </div>
          </div>

          <!-- Velocity Histogram -->
          <div class="p-4 bg-slate-950 border border-slate-800 rounded-lg">
            <div class="flex items-center justify-between text-xs font-mono font-bold text-slate-300 mb-3">
              <span>CONTACT CLOSING VELOCITY DISTRIBUTION</span>
              <span class="text-slate-400 font-normal">Tolerance: 0.10 m/s</span>
            </div>
            <div class="space-y-2 font-mono text-xs">
              @for (bin of summary()!.velocityHistogram; track bin.binLabel) {
                <div class="flex items-center gap-3">
                  <span class="w-28 text-[11px] text-slate-400 shrink-0">{{ bin.binLabel }}</span>
                  <div class="flex-1 bg-slate-900 rounded-full h-3 overflow-hidden border border-slate-800">
                    <div class="bg-emerald-500 h-full rounded-full" [style.width.%]="(bin.count / summary()!.totalRuns) * 100"></div>
                  </div>
                  <span class="w-10 text-right text-[11px] text-slate-300 shrink-0">{{ bin.count }}</span>
                </div>
              }
            </div>
          </div>
        </div>

        <!-- Sensitivity Analysis Table -->
        <div class="p-4 bg-slate-950 border border-slate-800 rounded-lg">
          <div class="flex items-center gap-2 text-xs font-mono font-bold text-slate-200 mb-2">
            <mat-icon class="text-amber-400 text-sm">trending_up</mat-icon>
            RANKED SENSITIVITY DECOMPOSITION (DRIVERS OF CLEARANCE FAILURE)
          </div>
          <div class="overflow-x-auto">
            <table class="w-full text-left font-mono text-xs">
              <thead>
                <tr class="border-b border-slate-800 text-slate-400 text-[11px]">
                  <th class="py-1.5 px-2">RANK</th>
                  <th class="py-1.5 px-2">UNCERTAINTY PARAMETER</th>
                  <th class="py-1.5 px-2">SOBOL SENSITIVITY S_i</th>
                  <th class="py-1.5 px-2">PRIMARY FAILURE MECHANISM / IMPACT</th>
                </tr>
              </thead>
              <tbody class="divide-y divide-slate-800/60">
                @for (item of summary()!.sensitivityRanking; track item.parameter; let idx = $index) {
                  <tr>
                    <td class="py-2 px-2 text-amber-400 font-bold">#{{ idx + 1 }}</td>
                    <td class="py-2 px-2 text-slate-200 font-semibold">{{ item.parameter }}</td>
                    <td class="py-2 px-2 text-cyan-400 font-bold">
                      <div class="flex items-center gap-2">
                        <span>{{ item.sensitivityIndex.toFixed(2) }}</span>
                        <div class="w-16 bg-slate-900 rounded-full h-1.5 overflow-hidden">
                          <div class="bg-cyan-400 h-full" [style.width.%]="item.sensitivityIndex * 100"></div>
                        </div>
                      </div>
                    </td>
                    <td class="py-2 px-2 text-slate-400 text-[11px]">{{ item.direction }}</td>
                  </tr>
                }
              </tbody>
            </table>
          </div>
        </div>
      }
    </div>
  `,
})
export class MonteCarloPanel implements OnInit {
  readonly selectedRunCount = signal<number>(500);
  readonly isExecuting = signal<boolean>(false);
  readonly progress = signal<number>(0);
  readonly summary = signal<MonteCarloSummary | null>(null);

  ngOnInit() {
    this.runMonteCarlo();
  }

  runMonteCarlo() {
    if (this.isExecuting()) return;
    this.isExecuting.set(true);
    this.progress.set(0);

    setTimeout(() => {
      const summary = MonteCarloEngine.runBatch(this.selectedRunCount(), undefined, (completed, total) => {
        this.progress.set(Math.floor((completed / total) * 100));
      });
      this.summary.set(summary);
      this.isExecuting.set(false);
      this.progress.set(100);
    }, 50);
  }
}
