// Interactive Rust Codebase Inspector & CLI Terminal Emulator for NEWTON DOCK

import {
  ChangeDetectionStrategy,
  Component,
  OnInit,
  signal,
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';

export interface CrateFile {
  name: string;
  crate: string;
  path: string;
  code: string;
}

@Component({
  selector: 'app-rust-workspace-viewer',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="w-full bg-slate-900 border border-slate-800 rounded-xl overflow-hidden flex flex-col font-mono text-xs">
      <!-- Tab Header: Source Code vs CLI Console -->
      <div class="px-4 py-2.5 bg-slate-950 border-b border-slate-800 flex items-center justify-between">
        <div class="flex items-center gap-3">
          <mat-icon class="text-orange-400 text-sm">integration_instructions</mat-icon>
          <span class="font-bold text-slate-200">RUST WORKSPACE & CLI SUITE</span>
          <span class="px-2 py-0.5 rounded text-[10px] bg-slate-800 text-slate-400">20 CARGO CRATES</span>
        </div>

        <div class="flex items-center gap-1 bg-slate-900 p-0.5 rounded-lg border border-slate-800">
          <button
            (click)="activeTab.set('CLI')"
            [class.bg-slate-800]="activeTab() === 'CLI'"
            [class.text-orange-400]="activeTab() === 'CLI'"
            class="px-2.5 py-1 text-xs rounded text-slate-400 hover:text-slate-200 transition"
          >
            CLI TERMINAL
          </button>
          <button
            (click)="activeTab.set('SOURCE')"
            [class.bg-slate-800]="activeTab() === 'SOURCE'"
            [class.text-orange-400]="activeTab() === 'SOURCE'"
            class="px-2.5 py-1 text-xs rounded text-slate-400 hover:text-slate-200 transition"
          >
            CRATE SOURCES (.RS)
          </button>
        </div>
      </div>

      <!-- Content Area -->
      @if (activeTab() === 'CLI') {
        <div class="p-4 bg-black text-emerald-400 flex flex-col gap-3 min-h-[300px]">
          <div class="text-slate-400 text-[11px] leading-relaxed">
            <div>NEWTON DOCK: Orbital Docking Technology & Rendezvous Engineering Suite CLI [v1.4.0-rust]</div>
            <div>Type a command below or click a quick action preset to execute:</div>
          </div>

          <!-- Quick Command Preset Buttons -->
          <div class="flex flex-wrap gap-2">
            <button
              (click)="executeCommand('newton-dock validate scenario.toml')"
              class="px-2 py-1 bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-300 rounded text-[11px] transition"
            >
              $ newton-dock validate
            </button>
            <button
              (click)="executeCommand('newton-dock simulate scenario.toml')"
              class="px-2 py-1 bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-300 rounded text-[11px] transition"
            >
              $ newton-dock simulate
            </button>
            <button
              (click)="executeCommand('newton-dock docking scenario.toml')"
              class="px-2 py-1 bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-300 rounded text-[11px] transition"
            >
              $ newton-dock docking
            </button>
            <button
              (click)="executeCommand('newton-dock monte-carlo scenario.toml --runs 10000')"
              class="px-2 py-1 bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-300 rounded text-[11px] transition"
            >
              $ newton-dock monte-carlo --runs 10000
            </button>
            <button
              (click)="executeCommand('newton-dock report scenario.toml')"
              class="px-2 py-1 bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-300 rounded text-[11px] transition"
            >
              $ newton-dock report
            </button>
          </div>

          <!-- Terminal Output Log -->
          <div class="flex-1 overflow-y-auto p-3 bg-slate-950/90 border border-slate-800/80 rounded-lg text-xs font-mono space-y-1 max-h-72">
            @for (line of terminalLines(); track $index) {
              <div [innerHTML]="line"></div>
            }
          </div>
        </div>
      } @else {
        <!-- Crate File Explorer & Code Viewer -->
        <div class="flex flex-col md:flex-row h-[360px] bg-slate-950">
          <!-- Sidebar file list -->
          <div class="w-full md:w-64 border-r border-slate-800 p-2 overflow-y-auto space-y-1 shrink-0">
            <div class="px-2 py-1 text-[11px] text-slate-400 font-bold">WORKSPACE CRATES</div>
            @for (file of crateFiles; track file.path) {
              <button
                (click)="selectedFile.set(file)"
                [class.bg-slate-800]="selectedFile()?.path === file.path"
                [class.text-orange-400]="selectedFile()?.path === file.path"
                class="w-full text-left px-2 py-1.5 rounded hover:bg-slate-900 text-slate-300 text-[11px] truncate flex items-center gap-1.5 transition"
              >
                <mat-icon class="text-xs text-slate-400">code</mat-icon>
                <span>{{ file.name }}</span>
              </button>
            }
          </div>

          <!-- Code View Area -->
          <div class="flex-1 flex flex-col overflow-hidden">
            <div class="px-4 py-2 bg-slate-900 border-b border-slate-800 text-slate-400 text-[11px] flex items-center justify-between">
              <span>{{ selectedFile()?.path }}</span>
              <span class="text-orange-400">RUST 2024 EDITION</span>
            </div>
            <pre class="flex-1 overflow-auto p-4 bg-slate-950 text-slate-200 text-xs leading-relaxed font-mono"><code>{{ selectedFile()?.code }}</code></pre>
          </div>
        </div>
      }
    </div>
  `,
})
export class RustWorkspaceViewer implements OnInit {
  readonly activeTab = signal<'CLI' | 'SOURCE'>('CLI');
  readonly terminalLines = signal<string[]>([
    '<span class="text-cyan-400">newton-dock v1.4.0 (x86_64-unknown-linux-gnu)</span>',
    '<span class="text-slate-400">Type a command or select a preset to begin aerospace analysis.</span>',
  ]);

  readonly crateFiles: CrateFile[] = [
    {
      name: 'dock-core/src/state.rs',
      crate: 'dock-core',
      path: 'crates/dock-core/src/state.rs',
      code: `use nalgebra::{Matrix3, Quaternion, UnitQuaternion, Vector3};
use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Spacecraft6DofState {
    pub time_s: f64,
    pub position_m: Vector3<f64>,
    pub velocity_mps: Vector3<f64>,
    pub attitude: UnitQuaternion<f64>,
    pub angular_velocity_rps: Vector3<f64>,
    pub dry_mass_kg: f64,
    pub propellant_mass_kg: f64,
    pub inertia_tensor: Matrix3<f64>,
}

impl Spacecraft6DofState {
    pub fn total_mass_kg(&self) -> f64 {
        self.dry_mass_kg + self.propellant_mass_kg
    }
}`,
    },
    {
      name: 'dock-relative/src/clohessy_wiltshire.rs',
      crate: 'dock-relative',
      path: 'crates/dock-relative/src/clohessy_wiltshire.rs',
      code: `use nalgebra::Vector3;

/// Clohessy-Wiltshire relative orbital equations of motion in LVLH frame:
/// x'' = 2*n*y' + 3*n^2*x + f_x/m  (Radial R-bar)
/// y'' = -2*n*x' + f_y/m           (In-track V-bar)
/// z'' = -n^2*z + f_z/m            (Cross-track H-bar)
pub fn cw_acceleration(
    r_lvlh: &Vector3<f64>,
    v_lvlh: &Vector3<f64>,
    mean_motion: f64,
    thrust_acc: &Vector3<f64>,
) -> Vector3<f64> {
    let n = mean_motion;
    let n2 = n * n;
    Vector3::new(
        2.0 * n * v_lvlh.y + 3.0 * n2 * r_lvlh.x + thrust_acc.x,
        -2.0 * n * v_lvlh.x + thrust_acc.y,
        -n2 * r_lvlh.z + thrust_acc.z,
    )
}`,
    },
    {
      name: 'dock-contact/src/hunt_crossley.rs',
      crate: 'dock-contact',
      path: 'crates/dock-contact/src/hunt_crossley.rs',
      code: `/// Hunt-Crossley compliant contact model preventing nonphysical adhesive tension:
/// F_n = max(0, k * delta^n + (1.5 * alpha * k * delta^n) * delta_dot)
pub fn compute_compliant_contact_force(
    penetration_depth_m: f64,
    penetration_rate_mps: f64,
    stiffness_k: f64,
    damping_alpha: f64,
    exponent_n: f64,
) -> f64 {
    if penetration_depth_m <= 0.0 {
        return 0.0;
    }
    let delta_n = penetration_depth_m.powf(exponent_n);
    let elastic = stiffness_k * delta_n;
    let damping = 1.5 * damping_alpha * stiffness_k * delta_n * penetration_rate_mps;
    (elastic + damping).max(0.0)
}`,
    },
    {
      name: 'dock-monte-carlo/src/parallel.rs',
      crate: 'dock-monte-carlo',
      path: 'crates/dock-monte-carlo/src/parallel.rs',
      code: `use rayon::prelude::*;

pub fn run_monte_carlo_batch(num_runs: usize, seed: u64) -> MonteCarloResultSummary {
    let runs: Vec<SingleRunResult> = (0..num_runs)
        .into_par_iter()
        .map(|idx| simulate_docking_run(seed + idx as u64))
        .collect();

    aggregate_statistics(&runs)
}`,
    },
  ];

  readonly selectedFile = signal<CrateFile | null>(null);

  ngOnInit() {
    this.selectedFile.set(this.crateFiles[0]);
  }

  executeCommand(cmd: string) {
    const lines = [...this.terminalLines()];
    lines.push(`<span class="text-white font-bold">$ ${cmd}</span>`);

    if (cmd.includes('validate')) {
      lines.push('<span class="text-emerald-400">✓ Parsing scenario.toml ... OK</span>');
      lines.push('<span class="text-emerald-400">✓ Orbital Mechanics Constraints: PASS</span>');
      lines.push('<span class="text-emerald-400">✓ 16-RCS Thruster Allocation Matrix rank = 6: FULL CONTROLLABILITY</span>');
      lines.push('<span class="text-emerald-400">✓ Validation completed: 0 errors, 0 warnings.</span>');
    } else if (cmd.includes('simulate') || cmd.includes('docking')) {
      lines.push('<span class="text-cyan-400">[SIM] Propagating 6-DOF Trajectory with RK4 (dt = 33.3ms)...</span>');
      lines.push('<span class="text-slate-300">T+000.0s [FREE_FLIGHT] Range: 120.0m, v_y: -0.35 m/s</span>');
      lines.push('<span class="text-slate-300">T+045.2s [APPROACH] Hold Point S2 (20.0m) Acquired</span>');
      lines.push('<span class="text-slate-300">T+098.4s [CONTACT] Docking interface contact detected (F_n = 342 N)</span>');
      lines.push('<span class="text-emerald-400">T+102.1s [SOFT_CAPTURE] Petal latches engaged. Alignment: 0.34 deg</span>');
      lines.push('<span class="text-emerald-400">T+108.5s [DOCKED] Structural Hard Lock Achieved. ΔV: 2.14 m/s</span>');
    } else if (cmd.includes('monte-carlo')) {
      lines.push('<span class="text-cyan-400">[MC] Spawning Rayon parallel thread pool (10,000 runs)...</span>');
      lines.push('<span class="text-slate-300">Completed 10,000 runs in 1.42s (7,042 runs/sec)</span>');
      lines.push('<span class="text-emerald-400">Capture Probability: 98.4% (9,840/10,000)</span>');
      lines.push('<span class="text-amber-400">Abort Probability: 1.5% (150/10,000)</span>');
      lines.push('<span class="text-rose-400">Collision Risk: 0.1% (10/10,000)</span>');
      lines.push('<span class="text-slate-300">Mean Contact Force: 312 ± 84 N (Max: 1,420 N)</span>');
    } else if (cmd.includes('report')) {
      lines.push('<span class="text-emerald-400">✓ Generated ISO-9001 Aerospace Clearance Report: ND-REP-2026-001.md</span>');
      lines.push('<span class="text-slate-300">Scenario Hash: 7f8a91c3e45b6a12 // Integrator: RK4</span>');
    }

    this.terminalLines.set(lines);
  }
}
