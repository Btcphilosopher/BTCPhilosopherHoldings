// Master Workstation Controller for NEWTON DOCK

import {
  ChangeDetectionStrategy,
  Component,
  OnInit,
  signal,
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MatIconModule } from '@angular/material/icon';
import { SimulationManager } from './core/simulation/simulation-manager';
import { ReferenceFrame, Quat } from './core/physics/math3d';
import { DockingViewport } from './components/docking-viewport/docking-viewport';
import { TelemetryCharts } from './components/telemetry-charts/telemetry-charts';
import { MonteCarloPanel } from './components/monte-carlo-panel/monte-carlo-panel';
import { EngineeringReportModal } from './components/engineering-report-modal/engineering-report-modal';
import { RustWorkspaceViewer } from './components/rust-workspace-viewer/rust-workspace-viewer';

export type SubsystemTab =
  | 'GUIDANCE_CONTROL'
  | 'CONTACT_PHYSICS'
  | 'SENSORS_EKF'
  | 'MONTE_CARLO'
  | 'FAULT_INJECTION'
  | 'REPLAY_SCRUBBER'
  | 'RUST_CLI';

@Component({
  selector: 'app-root',
  imports: [
    CommonModule,
    FormsModule,
    MatIconModule,
    DockingViewport,
    TelemetryCharts,
    MonteCarloPanel,
    EngineeringReportModal,
    RustWorkspaceViewer,
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './app.html',
  styleUrl: './app.css',
})
export class App implements OnInit {
  protected readonly Math = Math;
  readonly sim = new SimulationManager();
  readonly activeTab = signal<SubsystemTab>('GUIDANCE_CONTROL');
  readonly isReportModalOpen = signal<boolean>(false);

  ngOnInit() {
    this.sim.play();
  }

  setTab(tab: SubsystemTab) {
    this.activeTab.set(tab);
  }

  onScenarioChange(scenarioId: string) {
    const s = this.sim.scenarios().find(item => item.id === scenarioId);
    if (s) {
      this.sim.loadScenario(s);
    }
  }

  onFrameChange(frame: ReferenceFrame) {
    this.sim.setReferenceFrame(frame);
  }

  toggleCameraFault() {
    const cur = this.sim.faultConfig();
    this.sim.faultConfig.set({
      ...cur,
      opticalCameraLoss: !cur.opticalCameraLoss,
    });
  }

  toggleLidarFault() {
    const cur = this.sim.faultConfig();
    this.sim.faultConfig.set({
      ...cur,
      lidarDropout: !cur.lidarDropout,
    });
  }

  exportTelemetryCSV() {
    const csv = this.sim.getTelemetry().exportCSV();
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `NEWTON_DOCK_TELEMETRY_${this.sim.selectedScenario().id}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  }

  exportTelemetryJSON() {
    const json = this.sim.getTelemetry().exportJSON();
    const blob = new Blob([json], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `NEWTON_DOCK_TELEMETRY_${this.sim.selectedScenario().id}.json`;
    a.click();
    URL.revokeObjectURL(url);
  }

  triggerManualAbort() {
    const t = this.sim.simTime();
    this.sim.triggerManualAbort('MANUAL_OPERATOR_ABORT', 'Flight Director commanded manual safety abort burn', t);
  }

  getEulerAngles() {
    const att = this.sim.chaserState().attitude;
    const e = Quat.toEuler(att);
    return {
      rollDeg: (e.roll * 180) / Math.PI,
      pitchDeg: (e.pitch * 180) / Math.PI,
      yawDeg: (e.yaw * 180) / Math.PI,
    };
  }
}
