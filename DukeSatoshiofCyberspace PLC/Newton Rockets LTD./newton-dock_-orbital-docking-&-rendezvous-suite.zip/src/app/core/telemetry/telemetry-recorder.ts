// High-Resolution Telemetry Stream & Replay Subsystem for NEWTON DOCK

import { Vector3 } from '../physics/math3d';
import { DockingPhase } from '../physics/docking-state-machine';

export interface TelemetryFrame {
  timestamp: number;
  // Truth States
  truePos: Vector3;
  trueVel: Vector3;
  trueEulerDeg: { roll: number; pitch: number; yaw: number };
  trueOmegaDegPerSec: Vector3;
  rangeM: number;
  rangeRateMps: number;
  totalMassKg: number;
  propellantConsumedKg: number;
  cumulativeDeltaVMps: number;

  // Navigation State Estimate & Uncertainties
  estPos: Vector3;
  estVel: Vector3;
  estEulerDeg: { roll: number; pitch: number; yaw: number };
  sigmaPos3SigmaM: Vector3;
  chiSquared: number;
  navHealth: string;

  // Guidance Commands
  desiredPos: Vector3;
  desiredVel: Vector3;
  corridorErrorM: number;
  corridorMarginRatio: number;
  glideslopeSpeedLimitMps: number;
  timeToContactSec: number;
  currentWaypointId: string;

  // Control & Thrusters
  cmdForceBodyN: Vector3;
  cmdTorqueBodyNm: Vector3;
  activeThrusterCount: number;
  totalThrustBodyN: Vector3;
  propellantFlowKgPerSec: number;

  // Contact Dynamics & State Machine
  dockingPhase: DockingPhase;
  inContact: boolean;
  normalContactForceN: number;
  frictionContactForceN: number;
  penetrationDepthMm: number;
  dissipatedPowerWatts: number;
  latchEngaged: boolean;
  isHardLocked: boolean;
}

export class TelemetryRecorder {
  private frames: TelemetryFrame[] = [];
  private maxFrames = 30000; // ~15 minutes at 30Hz

  clear() {
    this.frames = [];
  }

  recordFrame(frame: TelemetryFrame) {
    if (this.frames.length >= this.maxFrames) {
      this.frames.shift(); // Evict oldest
    }
    this.frames.push(frame);
  }

  getFrames(): TelemetryFrame[] {
    return this.frames;
  }

  getFrameCount(): number {
    return this.frames.length;
  }

  getFrameAt(index: number): TelemetryFrame | null {
    if (index < 0 || index >= this.frames.length) return null;
    return this.frames[index];
  }

  exportCSV(): string {
    const headers = [
      'Timestamp_s',
      'True_PosX_m', 'True_PosY_m', 'True_PosZ_m',
      'True_VelX_mps', 'True_VelY_mps', 'True_VelZ_mps',
      'Range_m', 'RangeRate_mps',
      'True_Roll_deg', 'True_Pitch_deg', 'True_Yaw_deg',
      'Est_PosX_m', 'Est_PosY_m', 'Est_PosZ_m',
      'Nav_SigmaX_m', 'Nav_SigmaY_m', 'Nav_SigmaZ_m',
      'Chi_Squared',
      'Cmd_ForceY_N',
      'Contact_NormalForce_N',
      'Penetration_mm',
      'Docking_Phase',
      'Cumulative_DeltaV_mps',
      'Propellant_Consumed_kg'
    ].join(',');

    const rows = this.frames.map(f => [
      f.timestamp.toFixed(3),
      f.truePos.x.toFixed(4), f.truePos.y.toFixed(4), f.truePos.z.toFixed(4),
      f.trueVel.x.toFixed(4), f.trueVel.y.toFixed(4), f.trueVel.z.toFixed(4),
      f.rangeM.toFixed(4), f.rangeRateMps.toFixed(4),
      f.trueEulerDeg.roll.toFixed(2), f.trueEulerDeg.pitch.toFixed(2), f.trueEulerDeg.yaw.toFixed(2),
      f.estPos.x.toFixed(4), f.estPos.y.toFixed(4), f.estPos.z.toFixed(4),
      f.sigmaPos3SigmaM.x.toFixed(4), f.sigmaPos3SigmaM.y.toFixed(4), f.sigmaPos3SigmaM.z.toFixed(4),
      f.chiSquared.toFixed(2),
      f.cmdForceBodyN.y.toFixed(2),
      f.normalContactForceN.toFixed(2),
      f.penetrationDepthMm.toFixed(2),
      f.dockingPhase,
      f.cumulativeDeltaVMps.toFixed(3),
      f.propellantConsumedKg.toFixed(4),
    ].join(','));

    return [headers, ...rows].join('\n');
  }

  exportJSON(): string {
    return JSON.stringify({
      software: 'NEWTON DOCK Engineering Suite',
      version: '1.4.0-RUST-WORKSPACE',
      recordTimestamp: new Date().toISOString(),
      frameCount: this.frames.length,
      sampleRateHz: 30,
      frames: this.frames,
    }, null, 2);
  }
}
