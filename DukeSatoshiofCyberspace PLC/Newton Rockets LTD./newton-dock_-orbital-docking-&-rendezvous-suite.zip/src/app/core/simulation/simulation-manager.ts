// Master Simulation & Aerospace Mission Orchestrator for NEWTON DOCK
// Runs deterministic 6-DOF simulation loop with sensor sampling, EKF navigation, guidance, control, and contact physics.

import { signal } from '@angular/core';
import { Vec3, ReferenceFrame } from '../physics/math3d';
import { OrbitalMechanics, KeplerianElements, CartesianState } from '../physics/orbital-mechanics';
import { Spacecraft6DOF, Spacecraft6DofState, DynamicForcesMoments } from '../physics/spacecraft-6dof';
import { SensorSuite, SensorFaultConfig, LidarMeasurement, OpticalCameraPoseMeasurement, ImuMeasurement, StarTrackerMeasurement } from '../physics/sensors';
import { NavigationEKF, EkfStateEstimate } from '../physics/navigation-ekf';
import { GuidanceEngine, GuidanceCommand } from '../physics/guidance';
import { SpacecraftController, ControlCommand, ThrusterAllocationResult, ThrusterDef } from '../physics/control';
import { ContactDynamics, ContactParameters, ContactForceResult } from '../physics/contact-dynamics';
import { DockingGeometryRegistry, CaptureAssessment, RelativeDockingState } from '../physics/docking-geometry';
import { DockingStateMachine, StateMachineStatus } from '../physics/docking-state-machine';
import { AbortMonitor } from '../physics/abort-monitor';
import { TelemetryRecorder, TelemetryFrame } from '../telemetry/telemetry-recorder';
import { MissionScenario, SCENARIOS } from '../scenarios/scenario-registry';

export class SimulationManager {
  // Core physical subsystems
  private sensors = new SensorSuite();
  private ekf = new NavigationEKF();
  private guidance = new GuidanceEngine();
  private controller = new SpacecraftController();
  private stateMachine = new DockingStateMachine();
  private telemetry = new TelemetryRecorder();

  // Active Scenario Configuration
  readonly scenarios = signal<MissionScenario[]>(SCENARIOS);
  readonly selectedScenario = signal<MissionScenario>(SCENARIOS[0]);

  // Simulation Execution State
  readonly isRunning = signal<boolean>(false);
  readonly simTime = signal<number>(0);
  readonly timeStep = signal<number>(0.0333); // 30 Hz (33.3ms)
  readonly playbackSpeed = signal<number>(1.0); // 1x, 2x, 5x, 10x
  readonly isReplayMode = signal<boolean>(false);
  readonly replayFrameIndex = signal<number>(0);

  // Active Reference Frame for UI displays
  readonly activeReferenceFrame = signal<ReferenceFrame>('LVLH');

  // Spacecraft Physical State Signals (Truth)
  readonly chaserState = signal<Spacecraft6DofState>(Spacecraft6DOF.createDefaultChaser());
  readonly targetOrbitState = signal<CartesianState>({
    position: { x: 6798137.0, y: 0, z: 0 },
    velocity: { x: 0, y: 7660.0, z: 0 },
    time: 0,
  });
  readonly targetKeplerian = signal<KeplerianElements>({
    semiMajorAxis: 6798137.0,
    eccentricity: 0.0002,
    inclination: (51.64 * Math.PI) / 180,
    raan: 0.2,
    argOfPeriapsis: 0.5,
    trueAnomaly: 0.0,
  });

  // Sensor Measurements Signals
  readonly lastLidar = signal<LidarMeasurement | null>(null);
  readonly lastCamera = signal<OpticalCameraPoseMeasurement | null>(null);
  readonly lastImu = signal<ImuMeasurement | null>(null);
  readonly lastStarTracker = signal<StarTrackerMeasurement | null>(null);

  // Estimation & Guidance Signals
  readonly ekfEstimate = signal<EkfStateEstimate | null>(null);
  readonly guidanceCommand = signal<GuidanceCommand | null>(null);
  readonly controlCommand = signal<ControlCommand | null>(null);
  readonly thrusterAllocation = signal<ThrusterAllocationResult | null>(null);

  // Contact Dynamics & Capture State Machine Signals
  readonly contactResult = signal<ContactForceResult | null>(null);
  readonly captureAssessment = signal<CaptureAssessment | null>(null);
  readonly stateMachineStatus = signal<StateMachineStatus>(this.stateMachine.getStatus());

  // Fault Configuration Signal (Mutable live in UI)
  readonly faultConfig = signal<SensorFaultConfig>({
    lidarDropout: false,
    opticalCameraLoss: false,
    imuExcessiveBias: false,
    highSensorNoise: false,
    latencySeconds: 0,
  });

  // Contact Parameters
  readonly contactParams = signal<ContactParameters>(ContactDynamics.getDefaultParameters());

  // Animation Frame timer
  private timerHandle: number | null = null;
  private lastWallTime = 0;

  constructor() {
    this.loadScenario(this.selectedScenario());
  }

  loadScenario(scenario: MissionScenario) {
    this.pause();
    this.selectedScenario.set(scenario);
    this.isReplayMode.set(false);

    // Initialize orbit
    const mu = scenario.targetOrbit.mu;
    const rOrbit = (scenario.targetOrbit.altitudeKm * 1000) + 6378137.0;
    const vOrbit = Math.sqrt(mu / rOrbit);

    this.targetOrbitState.set({
      position: { x: rOrbit, y: 0, z: 0 },
      velocity: { x: 0, y: vOrbit, z: 0 },
      time: 0,
    });

    this.targetKeplerian.set({
      semiMajorAxis: rOrbit,
      eccentricity: scenario.targetOrbit.eccentricity,
      inclination: (scenario.targetOrbit.inclinationDeg * Math.PI) / 180,
      raan: 0.25,
      argOfPeriapsis: 0.4,
      trueAnomaly: 0.0,
      period: 2 * Math.PI * Math.sqrt(Math.pow(rOrbit, 3) / mu),
    });

    // Initialize Chaser
    const baseChaser = Spacecraft6DOF.createDefaultChaser();
    const chaser: Spacecraft6DofState = {
      ...baseChaser,
      position: { ...scenario.initialChaserState.position },
      velocity: { ...scenario.initialChaserState.velocity },
      attitude: { ...scenario.initialChaserState.attitude },
      angularVelocity: { ...scenario.initialChaserState.angularVelocity },
      totalMassKg: scenario.initialChaserState.totalMassKg,
      propellantMassKg: scenario.initialChaserState.propellantMassKg,
      dryMassKg: scenario.initialChaserState.totalMassKg - scenario.initialChaserState.propellantMassKg,
      cumulativeDeltaV: 0,
      propellantConsumedKg: 0,
      time: 0,
    };
    this.chaserState.set(chaser);
    this.simTime.set(0);

    // Reset Subsystems
    this.guidance.reset();
    this.controller = new SpacecraftController();
    for (const tf of scenario.thrusterFaults) {
      this.controller.setThrusterFault(tf.thrusterId, tf.functional, tf.degradation);
    }

    this.ekf.initialize(chaser.position, chaser.velocity, chaser.attitude);
    this.stateMachine.reset();
    this.telemetry.clear();
    this.faultConfig.set({ ...scenario.sensorFaults });

    // Initial evaluation
    this.evaluateSubsystems(0.001);
  }

  play() {
    if (this.isRunning()) return;
    this.isRunning.set(true);
    this.isReplayMode.set(false);
    this.lastWallTime = performance.now();
    this.loop();
  }

  pause() {
    this.isRunning.set(false);
    if (this.timerHandle !== null) {
      cancelAnimationFrame(this.timerHandle);
      this.timerHandle = null;
    }
  }

  stepOnce() {
    this.pause();
    this.isReplayMode.set(false);
    this.stepSimulation(this.timeStep());
  }

  reset() {
    this.pause();
    this.loadScenario(this.selectedScenario());
  }

  triggerManualAbort(code: string, description: string, time: number) {
    this.stateMachine.triggerAbort(code, description, 0, 0, time);
    this.stateMachineStatus.set(this.stateMachine.getStatus());
  }

  setSpeed(speed: number) {
    this.playbackSpeed.set(speed);
  }

  setReferenceFrame(frame: ReferenceFrame) {
    this.activeReferenceFrame.set(frame);
  }

  getThrusters(): ThrusterDef[] {
    return this.controller.getThrusters();
  }

  setThrusterHealth(thrusterId: number, functional: boolean, degradation: number) {
    this.controller.setThrusterFault(thrusterId, functional, degradation);
  }

  getTelemetry(): TelemetryRecorder {
    return this.telemetry;
  }

  seekReplay(frameIndex: number) {
    const frame = this.telemetry.getFrameAt(frameIndex);
    if (!frame) return;

    this.pause();
    this.isReplayMode.set(true);
    this.replayFrameIndex.set(frameIndex);
    this.simTime.set(frame.timestamp);

    // Restore state from frame
    const cur = this.chaserState();
    this.chaserState.set({
      ...cur,
      time: frame.timestamp,
      position: frame.truePos,
      velocity: frame.trueVel,
      attitude: {
        w: 1, x: 0, y: 0, z: 0
      },
      angularVelocity: {
        x: (frame.trueOmegaDegPerSec.x * Math.PI) / 180,
        y: (frame.trueOmegaDegPerSec.y * Math.PI) / 180,
        z: (frame.trueOmegaDegPerSec.z * Math.PI) / 180,
      },
      cumulativeDeltaV: frame.cumulativeDeltaVMps,
      propellantConsumedKg: frame.propellantConsumedKg,
    });
  }

  private loop = () => {
    if (!this.isRunning()) return;

    const now = performance.now();
    const wallDt = (now - this.lastWallTime) / 1000.0;
    this.lastWallTime = now;

    // Scale by playback speed with max step clamping
    const simDt = Math.min(0.2, wallDt * this.playbackSpeed());
    const baseDt = this.timeStep();

    // Sub-step integration for high numerical fidelity
    let remainingTime = simDt;
    while (remainingTime > 0.001) {
      const step = Math.min(remainingTime, baseDt);
      this.stepSimulation(step);
      remainingTime -= step;
    }

    this.timerHandle = requestAnimationFrame(this.loop);
  };

  /**
   * Deterministic 1-step simulation update
   */
  private stepSimulation(dt: number) {
    const t = this.simTime() + dt;
    this.simTime.set(t);

    const scenario = this.selectedScenario();
    const mu = scenario.targetOrbit.mu;
    const a = this.targetKeplerian().semiMajorAxis;
    const meanMotion = Math.sqrt(mu / Math.pow(a, 3));

    // Propagate Target Orbit
    const newTargetOrbit = OrbitalMechanics.propagateKepler(this.targetOrbitState(), dt, mu);
    this.targetOrbitState.set(newTargetOrbit);

    this.evaluateSubsystems(dt, meanMotion);
  }

  private evaluateSubsystems(dt: number, meanMotion = 0.00113) {
    const t = this.simTime();
    const chaser = this.chaserState();
    const faults = this.faultConfig();
    const geom = this.selectedScenario().dockingPort;
    const cParams = this.contactParams();

    // 1. SENSORS SAMPLING (with noise, drift, and faults)
    const lidar = this.sensors.sampleLidar(chaser.position, chaser.velocity, t, faults);
    const camera = this.sensors.sampleOpticalCamera(chaser.position, chaser.attitude, t, faults);
    const imu = this.sensors.sampleImu(
      Vec3.scale(chaser.velocity, 0), // specific force
      chaser.angularVelocity,
      t,
      dt,
      faults
    );
    const starTracker = this.sensors.sampleStarTracker(chaser.attitude, t, faults);

    this.lastLidar.set(lidar);
    this.lastCamera.set(camera);
    this.lastImu.set(imu);
    this.lastStarTracker.set(starTracker);

    // 2. NAVIGATION EKF
    this.ekf.predict(meanMotion, imu, dt);
    this.ekf.update(lidar, camera);
    const navEst = this.ekf.getEstimate();
    this.ekfEstimate.set(navEst);

    // 3. GUIDANCE
    const guidCmd = this.guidance.computeGuidance(
      navEst.relativePosition,
      navEst.relativeVelocity,
      navEst.relativeAttitude,
      dt,
      this.selectedScenario().corridorConfig
    );
    this.guidanceCommand.set(guidCmd);

    // 4. CONTACT DYNAMICS
    const relDockState: RelativeDockingState = {
      portRelativePosition: chaser.position,
      portRelativeVelocity: chaser.velocity,
      relativeAttitude: chaser.attitude,
      relativeAngularVelocity: chaser.angularVelocity,
    };

    const isSoftCap = this.stateMachine.getStatus().isSoftCaptured;
    const contactRes = ContactDynamics.computeContact(relDockState, cParams, isSoftCap);
    this.contactResult.set(contactRes);

    const captureAssess = DockingGeometryRegistry.assessCapture(relDockState, geom);
    this.captureAssessment.set(captureAssess);

    // 5. SAFETY ABORT MONITOR
    const abortCheck = AbortMonitor.checkSafety(navEst, guidCmd, geom, contactRes.normalForce);
    if (abortCheck.shouldAbort && !isSoftCap) {
      this.stateMachine.triggerAbort(abortCheck.code, abortCheck.message, abortCheck.threshold, abortCheck.measured, t);
    }

    // 6. STATE MACHINE
    const range = Vec3.norm(chaser.position);
    const smStatus = this.stateMachine.update(range, contactRes, captureAssess, t, dt);
    this.stateMachineStatus.set(smStatus);

    // 7. 6-DOF CONTROL & THRUSTER ALLOCATION
    let ctrlCmd: ControlCommand;
    if (smStatus.currentPhase === 'ABORT') {
      // Emergency Abort Maneuver: Fire maximum retrograde thrusters (+Y in LVLH) and align attitude
      ctrlCmd = {
        commandedForceBody: { x: 0, y: 180.0, z: 0 },
        commandedTorqueBody: { x: 0, y: 0, z: 0 },
        deltaVRequested: { x: 0, y: (180.0 / chaser.totalMassKg) * dt, z: 0 },
      };
    } else if (smStatus.currentPhase === 'DOCKED') {
      // In docked state: Thrusters disabled (station control takes over)
      ctrlCmd = {
        commandedForceBody: { x: 0, y: 0, z: 0 },
        commandedTorqueBody: { x: 0, y: 0, z: 0 },
        deltaVRequested: { x: 0, y: 0, z: 0 },
      };
    } else {
      ctrlCmd = this.controller.computeControlCommands(
        navEst.relativePosition,
        navEst.relativeVelocity,
        navEst.relativeAttitude,
        navEst.angularVelocity,
        guidCmd.desiredPosition,
        guidCmd.desiredVelocity,
        guidCmd.desiredAttitude,
        guidCmd.desiredAngularRate,
        chaser.totalMassKg,
        chaser.inertiaMatrix,
        dt
      );
    }
    this.controlCommand.set(ctrlCmd);

    const allocation = this.controller.allocateThrusters(ctrlCmd.commandedForceBody, ctrlCmd.commandedTorqueBody);
    this.thrusterAllocation.set(allocation);

    // 8. 6-DOF RIGID BODY INTEGRATION (RK4)
    const dynForces: DynamicForcesMoments = {
      forceLVLH: { x: 0, y: 0, z: 0 },
      forceBody: allocation.totalForceBody,
      torqueBody: Vec3.add(allocation.totalTorqueBody, contactRes.contactTorque),
      contactForcePort: contactRes.contactForce,
      contactTorquePort: contactRes.contactTorque,
    };

    const newChaser = Spacecraft6DOF.stepRK4(
      chaser,
      dynForces,
      allocation.totalPropellantFlowKgPerSec,
      meanMotion,
      dt
    );
    this.chaserState.set(newChaser);

    // 9. RECORD TELEMETRY FRAME
    const frame: TelemetryFrame = {
      timestamp: t,
      truePos: { ...newChaser.position },
      trueVel: { ...newChaser.velocity },
      trueEulerDeg: {
        roll: 0,
        pitch: 0,
        yaw: 0,
      },
      trueOmegaDegPerSec: {
        x: (newChaser.angularVelocity.x * 180) / Math.PI,
        y: (newChaser.angularVelocity.y * 180) / Math.PI,
        z: (newChaser.angularVelocity.z * 180) / Math.PI,
      },
      rangeM: Vec3.norm(newChaser.position),
      rangeRateMps: Vec3.dot(newChaser.velocity, Vec3.normalize(newChaser.position)),
      totalMassKg: newChaser.totalMassKg,
      propellantConsumedKg: newChaser.propellantConsumedKg,
      cumulativeDeltaVMps: newChaser.cumulativeDeltaV,
      estPos: { ...navEst.relativePosition },
      estVel: { ...navEst.relativeVelocity },
      estEulerDeg: {
        roll: 0,
        pitch: 0,
        yaw: 0,
      },
      sigmaPos3SigmaM: {
        x: navEst.sigmaPos.x * 3.0,
        y: navEst.sigmaPos.y * 3.0,
        z: navEst.sigmaPos.z * 3.0,
      },
      chiSquared: navEst.chiSquared,
      navHealth: navEst.filterHealth,
      desiredPos: { ...guidCmd.desiredPosition },
      desiredVel: { ...guidCmd.desiredVelocity },
      corridorErrorM: guidCmd.corridorErrorM,
      corridorMarginRatio: guidCmd.corridorMarginRatio,
      glideslopeSpeedLimitMps: guidCmd.glideslopeSpeedLimitMps,
      timeToContactSec: guidCmd.timeToContactSeconds,
      currentWaypointId: guidCmd.currentWaypointId,
      cmdForceBodyN: { ...ctrlCmd.commandedForceBody },
      cmdTorqueBodyNm: { ...ctrlCmd.commandedTorqueBody },
      activeThrusterCount: allocation.firings.filter(f => f.dutyCycle > 0).length,
      totalThrustBodyN: { ...allocation.totalForceBody },
      propellantFlowKgPerSec: allocation.totalPropellantFlowKgPerSec,
      dockingPhase: smStatus.currentPhase,
      inContact: contactRes.inContact,
      normalContactForceN: contactRes.normalForce,
      frictionContactForceN: contactRes.frictionForce,
      penetrationDepthMm: contactRes.penetrationDepth * 1000.0,
      dissipatedPowerWatts: contactRes.dissipatedPower,
      latchEngaged: contactRes.latchEngaged,
      isHardLocked: smStatus.isHardLocked,
    };

    this.telemetry.recordFrame(frame);
  }
}

