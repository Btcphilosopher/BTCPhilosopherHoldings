// Compliant Contact Dynamics Model for NEWTON DOCK
// Hunt-Crossley elastoplastic contact mechanics, friction cones, and capture latch dynamics.

import { Vector3, Vec3 } from './math3d';
import { RelativeDockingState } from './docking-geometry';

export interface ContactParameters {
  // Normal contact stiffness k [N / m^1.5]
  stiffnessK: number;
  // Damping coefficient alpha [s / m] in Hunt-Crossley model
  dampingAlpha: number;
  // Non-linear exponent n (typically 1.5 for Hertzian contact)
  exponentN: number;
  // Static friction coefficient mu_s
  staticFrictionMu: number;
  // Dynamic friction coefficient mu_d
  dynamicFrictionMu: number;
  // Viscous tangential damping [N*s / m]
  viscousFrictionDamping: number;
  // Contact interface radius [m]
  contactRadiusM: number;
  // Capture latch retention spring stiffness [N / m]
  latchSpringK: number;
}

export interface ContactForceResult {
  inContact: boolean;
  // Total contact force exerted on Chaser in target port frame [N]
  contactForce: Vector3;
  // Total contact torque exerted on Chaser in target port frame [N*m]
  contactTorque: Vector3;
  // Normal force magnitude [N]
  normalForce: number;
  // Tangential friction force magnitude [N]
  frictionForce: number;
  // Penetration / interface indentation depth [m]
  penetrationDepth: number;
  // Rate of penetration / indentation velocity [m/s]
  penetrationRate: number;
  // Instantaneous power dissipated by damping and friction [Watts]
  dissipatedPower: number;
  // Latch capture engaged
  latchEngaged: boolean;
}

export class ContactDynamics {
  static getDefaultParameters(): ContactParameters {
    return {
      stiffnessK: 2.5e5, // 250 kN/m^1.5 for metallic docking ring with elastomeric seals
      dampingAlpha: 0.15, // Hunt-Crossley damping factor
      exponentN: 1.5,
      staticFrictionMu: 0.25,
      dynamicFrictionMu: 0.18,
      viscousFrictionDamping: 450.0,
      contactRadiusM: 0.40,
      latchSpringK: 1.2e4, // 12 kN/m capture latch
    };
  }

  /**
   * Compute compliant contact forces and moments during interface contact
   *
   * Hunt-Crossley Model:
   * F_n = k * delta^n + (3/2 * alpha * k * delta^n) * delta_dot
   * F_n is strictly >= 0 (no tensile adhesion/suction forces upon separation)
   */
  static computeContact(
    state: RelativeDockingState,
    params: ContactParameters = this.getDefaultParameters(),
    isSoftCaptured = false
  ): ContactForceResult {
    // In docking port frame:
    // +Y is the normal separation axis (approach axis)
    // Contact occurs when port separation y <= 0 (penetration depth delta = -y > 0)
    const portSeparation = state.portRelativePosition.y;
    const penetrationDepth = -portSeparation; // Positive when penetrating
    const penetrationRate = -state.portRelativeVelocity.y; // Positive when penetrating deeper

    // If separated and not captured: no contact forces
    if (penetrationDepth <= 0 && !isSoftCaptured) {
      return {
        inContact: false,
        contactForce: { x: 0, y: 0, z: 0 },
        contactTorque: { x: 0, y: 0, z: 0 },
        normalForce: 0,
        frictionForce: 0,
        penetrationDepth: 0,
        penetrationRate: 0,
        dissipatedPower: 0,
        latchEngaged: false,
      };
    }

    let normalForce = 0;
    let dissipatedPower = 0;

    if (penetrationDepth > 0) {
      // Hunt-Crossley normal force calculation
      const deltaN = Math.pow(penetrationDepth, params.exponentN);
      const elasticTerm = params.stiffnessK * deltaN;
      const dampingTerm = 1.5 * params.dampingAlpha * params.stiffnessK * deltaN * penetrationRate;

      normalForce = elasticTerm + dampingTerm;
      // Enforce unilateral constraint (contact can only push apart, not pull)
      if (normalForce < 0) {
        normalForce = 0;
      }
      dissipatedPower += Math.max(0, dampingTerm * penetrationRate);
    }

    // Latch retention force if captured or within latch engagement pocket
    let latchForceY = 0;
    let latchEngaged = false;
    if (isSoftCaptured) {
      latchEngaged = true;
      // Restoration spring toward zero separation
      latchForceY = -params.latchSpringK * portSeparation;
    }

    // Total normal force along port Y axis (pushes chaser outward in +Y)
    const totalFy = normalForce + latchForceY;

    // Tangential relative velocity in X-Z plane
    const vTangential: Vector3 = {
      x: state.portRelativeVelocity.x,
      y: 0,
      z: state.portRelativeVelocity.z,
    };
    const vTanMag = Vec3.norm(vTangential);

    // Tangential friction calculation (Coulomb friction + viscous damping)
    let frictionForce = 0;
    let fFrictionX = 0;
    let fFrictionZ = 0;

    if (normalForce > 0 && vTanMag > 1e-6) {
      // Dynamic Coulomb friction magnitude: F_f = mu * F_n
      const coulombFriction = params.dynamicFrictionMu * normalForce;
      const viscousFriction = params.viscousFrictionDamping * vTanMag;
      frictionForce = coulombFriction + viscousFriction;

      const frictionDir = Vec3.scale(vTangential, -1.0 / vTanMag);
      fFrictionX = frictionDir.x * frictionForce;
      fFrictionZ = frictionDir.z * frictionForce;

      dissipatedPower += frictionForce * vTanMag;
    }

    const contactForce: Vector3 = {
      x: fFrictionX,
      y: totalFy,
      z: fFrictionZ,
    };

    // Restoring Contact Torques from Guide Petals / Ring Moment Arm
    // When interface is misaligned or has angular rate, petal contact produces alignment torque
    const lateralOffsetX = state.portRelativePosition.x;
    const lateralOffsetZ = state.portRelativePosition.z;

    // Torque tau = r_contact x F_contact
    const contactTorque: Vector3 = {
      x: -lateralOffsetZ * totalFy - params.contactRadiusM * 0.5 * normalForce * state.relativeAngularVelocity.x * 0.1,
      y: -params.contactRadiusM * frictionForce * Math.sign(state.relativeAngularVelocity.y || 1) * 0.2,
      z: lateralOffsetX * totalFy - params.contactRadiusM * 0.5 * normalForce * state.relativeAngularVelocity.z * 0.1,
    };

    return {
      inContact: penetrationDepth > 0 || isSoftCaptured,
      contactForce,
      contactTorque,
      normalForce,
      frictionForce,
      penetrationDepth: Math.max(0, penetrationDepth),
      penetrationRate,
      dissipatedPower,
      latchEngaged,
    };
  }
}
