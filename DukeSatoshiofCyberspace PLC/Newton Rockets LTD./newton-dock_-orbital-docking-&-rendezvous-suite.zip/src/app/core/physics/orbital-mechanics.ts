// Orbital Mechanics Engine for NEWTON DOCK
// Two-body propagation, Keplerian elements, anomaly transformations, and frame conversions.

import { Vector3, Vec3, Matrix3x3 } from './math3d';

export const MU_EARTH = 3.986004418e14; // m^3 / s^2
export const R_EARTH = 6378137.0; // Earth mean equatorial radius (m)
export const MU_MOON = 4.9048695e12; // m^3 / s^2 (for Lunar Gateway rendezvous)

export interface KeplerianElements {
  semiMajorAxis: number;     // a (meters)
  eccentricity: number;      // e (dimensionless, 0 <= e < 1 for elliptical)
  inclination: number;       // i (radians)
  raan: number;              // Right Ascension of Ascending Node Omega (radians)
  argOfPeriapsis: number;    // omega (radians)
  trueAnomaly: number;       // nu (radians)
  meanAnomaly?: number;      // M (radians)
  period?: number;           // T (seconds)
  apoapsisRadius?: number;   // ra (meters)
  periapsisRadius?: number;  // rp (meters)
}

export interface CartesianState {
  position: Vector3; // m (Inertial ECI)
  velocity: Vector3; // m/s (Inertial ECI)
  time: number;      // Epoch time in seconds
}

export class OrbitalMechanics {
  /**
   * Convert Cartesian State (ECI) to Classical Keplerian Elements
   */
  static stateToElements(state: CartesianState, mu = MU_EARTH): KeplerianElements {
    const r = state.position;
    const v = state.velocity;
    const rMag = Vec3.norm(r);
    const vMag = Vec3.norm(v);

    // Specific angular momentum h = r x v
    const h = Vec3.cross(r, v);
    const hMag = Vec3.norm(h);

    // Line of nodes vector n = k x h = [-hy, hx, 0]
    const n = { x: -h.y, y: h.x, z: 0 };
    const nMag = Vec3.norm(n);

    // Specific energy epsilon = v^2/2 - mu/r
    const energy = (vMag * vMag) / 2.0 - mu / rMag;

    // Semi-major axis a = -mu / (2 * energy)
    const a = -mu / (2.0 * energy);

    // Eccentricity vector e_vec = ((v^2 - mu/r)*r - (r.v)*v) / mu
    const rDotV = Vec3.dot(r, v);
    const eVec = Vec3.scale(
      Vec3.sub(
        Vec3.scale(r, vMag * vMag - mu / rMag),
        Vec3.scale(v, rDotV)
      ),
      1.0 / mu
    );
    const e = Vec3.norm(eVec);

    // Inclination i = acos(hz / h)
    const inc = Math.acos(Math.max(-1.0, Math.min(1.0, h.z / hMag)));

    // RAAN Omega = acos(nx / n)
    let raan = 0;
    if (nMag > 1e-9) {
      raan = Math.acos(Math.max(-1.0, Math.min(1.0, n.x / nMag)));
      if (n.y < 0) {
        raan = 2 * Math.PI - raan;
      }
    }

    // Argument of periapsis omega = acos((n . e) / (n * e))
    let argPeri = 0;
    if (nMag > 1e-9 && e > 1e-8) {
      argPeri = Math.acos(Math.max(-1.0, Math.min(1.0, Vec3.dot(n, eVec) / (nMag * e))));
      if (eVec.z < 0) {
        argPeri = 2 * Math.PI - argPeri;
      }
    } else if (e > 1e-8) {
      // Equatorial orbit
      argPeri = Math.atan2(eVec.y, eVec.x);
      if (argPeri < 0) argPeri += 2 * Math.PI;
    }

    // True anomaly nu = acos((e . r) / (e * r))
    let nu = 0;
    if (e > 1e-8) {
      nu = Math.acos(Math.max(-1.0, Math.min(1.0, Vec3.dot(eVec, r) / (e * rMag))));
      if (rDotV < 0) {
        nu = 2 * Math.PI - nu;
      }
    } else {
      // Circular orbit
      if (nMag > 1e-9) {
        nu = Math.acos(Math.max(-1.0, Math.min(1.0, Vec3.dot(n, r) / (nMag * rMag))));
        if (r.z < 0) nu = 2 * Math.PI - nu;
      } else {
        nu = Math.atan2(r.y, r.x);
        if (nu < 0) nu += 2 * Math.PI;
      }
    }

    const period = 2 * Math.PI * Math.sqrt(Math.pow(Math.abs(a), 3) / mu);
    const meanAnomaly = this.trueToMeanAnomaly(nu, e);
    const rp = a * (1 - e);
    const ra = a * (1 + e);

    return {
      semiMajorAxis: a,
      eccentricity: e,
      inclination: inc,
      raan,
      argOfPeriapsis: argPeri,
      trueAnomaly: nu,
      meanAnomaly,
      period,
      periapsisRadius: rp,
      apoapsisRadius: ra,
    };
  }

  /**
   * Convert Classical Keplerian Elements to Cartesian State (ECI)
   */
  static elementsToState(elem: KeplerianElements, mu = MU_EARTH): CartesianState {
    const a = elem.semiMajorAxis;
    const e = elem.eccentricity;
    const i = elem.inclination;
    const O = elem.raan;
    const w = elem.argOfPeriapsis;
    const nu = elem.trueAnomaly;

    // Radius in orbital plane
    const p = a * (1.0 - e * e); // semi-latus rectum
    const r = p / (1.0 + e * Math.cos(nu));

    // Perifocal coordinates (PQW)
    const rPQW: Vector3 = {
      x: r * Math.cos(nu),
      y: r * Math.sin(nu),
      z: 0,
    };

    const sqrtMuOverP = Math.sqrt(mu / p);
    const vPQW: Vector3 = {
      x: -sqrtMuOverP * Math.sin(nu),
      y: sqrtMuOverP * (e + Math.cos(nu)),
      z: 0,
    };

    // Transformation matrix from Perifocal to ECI: R = Rz(-O) * Rx(-i) * Rz(-w)
    const cosO = Math.cos(O);
    const sinO = Math.sin(O);
    const cosi = Math.cos(i);
    const sini = Math.sin(i);
    const cosw = Math.cos(w);
    const sinw = Math.sin(w);

    const Px = cosO * cosw - sinO * sinw * cosi;
    const Py = sinO * cosw + cosO * sinw * cosi;
    const Pz = sinw * sini;

    const Qx = -cosO * sinw - sinO * cosw * cosi;
    const Qy = -sinO * sinw + cosO * cosw * cosi;
    const Qz = cosw * sini;

    const pos: Vector3 = {
      x: Px * rPQW.x + Qx * rPQW.y,
      y: Py * rPQW.x + Qy * rPQW.y,
      z: Pz * rPQW.x + Qz * rPQW.y,
    };

    const vel: Vector3 = {
      x: Px * vPQW.x + Qx * vPQW.y,
      y: Py * vPQW.x + Qy * vPQW.y,
      z: Pz * vPQW.x + Qz * vPQW.y,
    };

    return {
      position: pos,
      velocity: vel,
      time: 0,
    };
  }

  /**
   * Solve Kepler's equation for Eccentric Anomaly E given Mean Anomaly M: M = E - e*sin(E)
   * Using high-precision Newton-Raphson iteration.
   */
  static solveKepler(M: number, e: number, tol = 1e-12, maxIter = 50): number {
    let E = M;
    if (e > 0.8) {
      E = Math.PI;
    }
    for (let iter = 0; iter < maxIter; iter++) {
      const f = E - e * Math.sin(E) - M;
      const fPrime = 1.0 - e * Math.cos(E);
      const delta = f / fPrime;
      E -= delta;
      if (Math.abs(delta) < tol) {
        break;
      }
    }
    return E;
  }

  static trueToMeanAnomaly(nu: number, e: number): number {
    // Eccentric Anomaly E from nu
    const cosNu = Math.cos(nu);
    const sinNu = Math.sin(nu);
    const E = Math.atan2(Math.sqrt(1 - e * e) * sinNu, e + cosNu);
    // Mean Anomaly M = E - e * sin(E)
    let M = E - e * Math.sin(E);
    if (M < 0) M += 2 * Math.PI;
    return M;
  }

  static meanToTrueAnomaly(M: number, e: number): number {
    const E = this.solveKepler(M, e);
    const cosE = Math.cos(E);
    const sinE = Math.sin(E);
    const nu = Math.atan2(Math.sqrt(1 - e * e) * sinE, cosE - e);
    return nu >= 0 ? nu : nu + 2 * Math.PI;
  }

  /**
   * Propagate two-body orbit analytically by deltaT seconds
   */
  static propagateKepler(state: CartesianState, deltaT: number, mu = MU_EARTH): CartesianState {
    const elem = this.stateToElements(state, mu);
    const n = Math.sqrt(mu / Math.pow(elem.semiMajorAxis, 3)); // Mean motion (rad/s)
    const M0 = elem.meanAnomaly ?? this.trueToMeanAnomaly(elem.trueAnomaly, elem.eccentricity);
    const M_new = (M0 + n * deltaT) % (2 * Math.PI);
    const nu_new = this.meanToTrueAnomaly(M_new, elem.eccentricity);

    const newElem: KeplerianElements = {
      ...elem,
      trueAnomaly: nu_new,
      meanAnomaly: M_new,
    };

    const newState = this.elementsToState(newElem, mu);
    newState.time = state.time + deltaT;
    return newState;
  }

  /**
   * Compute LVLH (Local Vertical Local Horizontal / Hill) Reference Frame unit vectors:
   * x_lvlh (Radial): r / |r| (Pointing away from central body)
   * z_lvlh (Cross-track / Out-of-plane): (r x v) / |r x v| (Along orbital angular momentum)
   * y_lvlh (In-track / Along-track): z_lvlh x x_lvlh (In velocity direction for circular orbit)
   */
  static getLVLHFrame(r: Vector3, v: Vector3): { x: Vector3; y: Vector3; z: Vector3; rotMatrix: Matrix3x3 } {
    const x = Vec3.normalize(r);
    const z = Vec3.normalize(Vec3.cross(r, v));
    const y = Vec3.normalize(Vec3.cross(z, x));

    const rotMatrix: Matrix3x3 = {
      m: [
        x.x, x.y, x.z,
        y.x, y.y, y.z,
        z.x, z.y, z.z,
      ],
    };

    return { x, y, z, rotMatrix };
  }

  /**
   * Transform Inertial (ECI) relative vector to LVLH frame
   */
  static eciToLvlh(vECI: Vector3, targetPos: Vector3, targetVel: Vector3): Vector3 {
    const frame = this.getLVLHFrame(targetPos, targetVel);
    return {
      x: Vec3.dot(frame.x, vECI),
      y: Vec3.dot(frame.y, vECI),
      z: Vec3.dot(frame.z, vECI),
    };
  }

  /**
   * Transform LVLH vector to Inertial (ECI) frame
   */
  static lvlhToEci(vLVLH: Vector3, targetPos: Vector3, targetVel: Vector3): Vector3 {
    const frame = this.getLVLHFrame(targetPos, targetVel);
    return Vec3.add(
      Vec3.scale(frame.x, vLVLH.x),
      Vec3.add(Vec3.scale(frame.y, vLVLH.y), Vec3.scale(frame.z, vLVLH.z))
    );
  }
}
