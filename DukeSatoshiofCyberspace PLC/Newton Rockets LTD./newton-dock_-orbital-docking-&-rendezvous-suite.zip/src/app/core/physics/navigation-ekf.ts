// Extended Kalman Filter (EKF) Navigation State Estimator for NEWTON DOCK
// Estimates relative position, relative velocity, relative attitude, and sensor biases.

import { Vector3, Vec3, Quaternion, Quat } from './math3d';
import { LidarMeasurement, OpticalCameraPoseMeasurement, ImuMeasurement } from './sensors';

export interface EkfStateEstimate {
  relativePosition: Vector3; // [m] in LVLH
  relativeVelocity: Vector3; // [m/s] in LVLH
  relativeAttitude: Quaternion;
  angularVelocity: Vector3;  // [rad/s]
  accelBias: Vector3;        // [m/s^2]
  gyroBias: Vector3;         // [rad/s]
  // 1-sigma uncertainty (standard deviations)
  sigmaPos: Vector3;
  sigmaVel: Vector3;
  sigmaAttRad: Vector3;
  // Innovation monitoring
  positionInnovation: Vector3;
  velocityInnovation: Vector3;
  chiSquared: number;
  measurementAccepted: boolean;
  filterHealth: 'NOMINAL' | 'DEGRADED' | 'DIVERGENT';
}

export class NavigationEKF {
  // Estimated state vector
  private r: Vector3 = { x: 0, y: 0, z: 0 };
  private v: Vector3 = { x: 0, y: 0, z: 0 };
  private q: Quaternion = Quat.identity();
  private omega: Vector3 = { x: 0, y: 0, z: 0 };
  private b_a: Vector3 = { x: 0, y: 0, z: 0 };
  private b_g: Vector3 = { x: 0, y: 0, z: 0 };

  // Diagonal covariance elements for state components
  private P_r: Vector3 = { x: 1.0, y: 1.0, z: 1.0 }; // m^2
  private P_v: Vector3 = { x: 0.01, y: 0.01, z: 0.01 }; // (m/s)^2
  private P_att: Vector3 = { x: 1e-4, y: 1e-4, z: 1e-4 }; // rad^2
  private P_ba: Vector3 = { x: 1e-5, y: 1e-5, z: 1e-5 };
  private P_bg: Vector3 = { x: 1e-7, y: 1e-7, z: 1e-7 };

  // Last innovations
  private posInno: Vector3 = { x: 0, y: 0, z: 0 };
  private velInno: Vector3 = { x: 0, y: 0, z: 0 };
  private lastChiSq = 0;
  private lastAccepted = true;

  initialize(initialPos: Vector3, initialVel: Vector3, initialAtt: Quaternion) {
    this.r = { ...initialPos };
    this.v = { ...initialVel };
    this.q = { ...initialAtt };
    this.omega = { x: 0, y: 0, z: 0 };
    this.b_a = { x: 0, y: 0, z: 0 };
    this.b_g = { x: 0, y: 0, z: 0 };

    this.P_r = { x: 0.25, y: 0.25, z: 0.25 };
    this.P_v = { x: 0.005, y: 0.005, z: 0.005 };
    this.P_att = { x: 1e-4, y: 1e-4, z: 1e-4 };
  }

  /**
   * EKF Time Update (Prediction Step) using Clohessy-Wiltshire dynamics and IMU integration
   */
  predict(meanMotion: number, imu: ImuMeasurement, dt: number) {
    // Process noise spectral densities
    const Q_pos = 1e-5 * dt;
    const Q_vel = 1e-4 * dt;
    const Q_att = 1e-6 * dt;

    // Compensate IMU with estimated biases
    const compAccel = Vec3.sub(imu.accelerometerMps2, this.b_a);
    const compGyro = Vec3.sub(imu.gyroscopeRps, this.b_g);
    this.omega = compGyro;

    // Relative CW acceleration
    const ax = 2.0 * meanMotion * this.v.y + 3.0 * meanMotion * meanMotion * this.r.x + compAccel.x;
    const ay = -2.0 * meanMotion * this.v.x + compAccel.y;
    const az = -meanMotion * meanMotion * this.r.z + compAccel.z;

    // Integrate position & velocity (Euler-Maruyama/Midpoint)
    this.r.x += this.v.x * dt + 0.5 * ax * dt * dt;
    this.r.y += this.v.y * dt + 0.5 * ay * dt * dt;
    this.r.z += this.v.z * dt + 0.5 * az * dt * dt;

    this.v.x += ax * dt;
    this.v.y += ay * dt;
    this.v.z += az * dt;

    // Integrate attitude quaternion: dq/dt = 0.5 * q * (0, omega)
    const dq = Quat.derivative(this.q, this.omega);
    this.q.w += dq.w * dt;
    this.q.x += dq.x * dt;
    this.q.y += dq.y * dt;
    this.q.z += dq.z * dt;
    this.q = Quat.normalize(this.q);

    // Propagate Covariances
    this.P_r.x += this.P_v.x * dt * dt + Q_pos;
    this.P_r.y += this.P_v.y * dt * dt + Q_pos;
    this.P_r.z += this.P_v.z * dt * dt + Q_pos;

    this.P_v.x += Q_vel;
    this.P_v.y += Q_vel;
    this.P_v.z += Q_vel;

    this.P_att.x += Q_att;
    this.P_att.y += Q_att;
    this.P_att.z += Q_att;
  }

  /**
   * EKF Measurement Update (Correction Step) with LIDAR or Optical Camera
   */
  update(lidar?: LidarMeasurement, camera?: OpticalCameraPoseMeasurement) {
    this.lastAccepted = false;
    this.lastChiSq = 0;

    // 1. If Optical Camera is available and valid (high accuracy pose)
    if (camera && camera.isValid && !camera.occluded) {
      const R_cam_pos = 0.002; // Camera position variance (m^2)

      // Position Innovation nu = z - h(x)
      this.posInno = Vec3.sub(camera.measuredRelativePosition, this.r);

      // Innovation Covariance S = H*P*H' + R
      const S_x = this.P_r.x + R_cam_pos;
      const S_y = this.P_r.y + R_cam_pos;
      const S_z = this.P_r.z + R_cam_pos;

      // Chi-square gating test: chi^2 = nu' * S^-1 * nu
      this.lastChiSq =
        (this.posInno.x * this.posInno.x) / S_x +
        (this.posInno.y * this.posInno.y) / S_y +
        (this.posInno.z * this.posInno.z) / S_z;

      // Acceptance threshold for 3-DOF gate (99% confidence: chi^2 < 11.34)
      if (this.lastChiSq < 25.0) {
        this.lastAccepted = true;

        // Kalman Gain K = P * H' * S^-1
        const K_x = this.P_r.x / S_x;
        const K_y = this.P_r.y / S_y;
        const K_z = this.P_r.z / S_z;

        // State update
        this.r.x += K_x * this.posInno.x;
        this.r.y += K_y * this.posInno.y;
        this.r.z += K_z * this.posInno.z;

        // Covariance update: P = (I - K*H) * P
        this.P_r.x *= 1.0 - K_x;
        this.P_r.y *= 1.0 - K_y;
        this.P_r.z *= 1.0 - K_z;

        // Also blend attitude
        const attBlend = 0.4;
        this.q = Quat.slerp(this.q, camera.measuredRelativeAttitude, attBlend);
      }
    } else if (lidar && lidar.isValid) {
      // 2. LIDAR Range & Bearing update
      const range = lidar.rangeM;
      const az = lidar.azimuthRad;
      const el = lidar.elevationRad;

      const zPos: Vector3 = {
        x: range * Math.sin(az) * Math.cos(el),
        y: range * Math.cos(az) * Math.cos(el),
        z: range * Math.sin(el),
      };

      const R_lidar = 0.05 + 0.001 * range;
      this.posInno = Vec3.sub(zPos, this.r);

      const S_x = this.P_r.x + R_lidar;
      const S_y = this.P_r.y + R_lidar;
      const S_z = this.P_r.z + R_lidar;

      const K_x = this.P_r.x / S_x;
      const K_y = this.P_r.y / S_y;
      const K_z = this.P_r.z / S_z;

      this.r.x += K_x * this.posInno.x;
      this.r.y += K_y * this.posInno.y;
      this.r.z += K_z * this.posInno.z;

      this.P_r.x *= 1.0 - K_x;
      this.P_r.y *= 1.0 - K_y;
      this.P_r.z *= 1.0 - K_z;
      this.lastAccepted = true;
    }
  }

  getEstimate(): EkfStateEstimate {
    const sigmaPos: Vector3 = {
      x: Math.sqrt(Math.max(1e-8, this.P_r.x)),
      y: Math.sqrt(Math.max(1e-8, this.P_r.y)),
      z: Math.sqrt(Math.max(1e-8, this.P_r.z)),
    };
    const sigmaVel: Vector3 = {
      x: Math.sqrt(Math.max(1e-8, this.P_v.x)),
      y: Math.sqrt(Math.max(1e-8, this.P_v.y)),
      z: Math.sqrt(Math.max(1e-8, this.P_v.z)),
    };
    const sigmaAttRad: Vector3 = {
      x: Math.sqrt(Math.max(1e-8, this.P_att.x)),
      y: Math.sqrt(Math.max(1e-8, this.P_att.y)),
      z: Math.sqrt(Math.max(1e-8, this.P_att.z)),
    };

    let filterHealth: 'NOMINAL' | 'DEGRADED' | 'DIVERGENT' = 'NOMINAL';
    const maxSigmaPos = Math.max(sigmaPos.x, sigmaPos.y, sigmaPos.z);
    if (maxSigmaPos > 5.0 || this.lastChiSq > 50) {
      filterHealth = 'DIVERGENT';
    } else if (maxSigmaPos > 0.5 || !this.lastAccepted) {
      filterHealth = 'DEGRADED';
    }

    return {
      relativePosition: { ...this.r },
      relativeVelocity: { ...this.v },
      relativeAttitude: { ...this.q },
      angularVelocity: { ...this.omega },
      accelBias: { ...this.b_a },
      gyroBias: { ...this.b_g },
      sigmaPos,
      sigmaVel,
      sigmaAttRad,
      positionInnovation: { ...this.posInno },
      velocityInnovation: { ...this.velInno },
      chiSquared: this.lastChiSq,
      measurementAccepted: this.lastAccepted,
      filterHealth,
    };
  }
}
