// Safety Abort Monitor for NEWTON DOCK
// Continuously evaluates flight envelopes: closing speed, corridor boundaries, angular rates, navigation health.

import { Vec3 } from './math3d';
import { EkfStateEstimate } from './navigation-ekf';
import { GuidanceCommand } from './guidance';
import { DockingPortGeometry } from './docking-geometry';

export interface AbortCriteriaLimits {
  maxAllowableClosingSpeedMps: number;
  maxCorridorMarginRatio: number;
  maxAngularRateDegPerSec: number;
  maxNavPositionUncertainty3SigmaM: number;
  maxAllowableNormalContactForceN: number;
}

export class AbortMonitor {
  static checkSafety(
    est: EkfStateEstimate,
    guidance: GuidanceCommand,
    geom: DockingPortGeometry,
    normalContactForceN: number,
    limits: AbortCriteriaLimits = {
      maxAllowableClosingSpeedMps: 0.35, // Hard cap 35 cm/s
      maxCorridorMarginRatio: 1.25,      // 25% outside cone boundary
      maxAngularRateDegPerSec: 3.5,      // 3.5 deg/s
      maxNavPositionUncertainty3SigmaM: 2.0, // 2m 3-sigma
      maxAllowableNormalContactForceN: 2500.0,
    }
  ): { shouldAbort: boolean; code: string; message: string; threshold: number; measured: number } {
    const range = Math.max(0.1, est.relativePosition.y);
    const closingSpeed = -est.relativeVelocity.y;

    // 1. Check excessive closing velocity relative to range (Over-speed abort)
    const speedLimitAtRange = Math.min(limits.maxAllowableClosingSpeedMps, 0.05 + 0.05 * Math.sqrt(range));
    if (closingSpeed > speedLimitAtRange && range < 50.0) {
      return {
        shouldAbort: true,
        code: 'EXCESSIVE_CLOSING_VELOCITY',
        message: `Closing velocity ${closingSpeed.toFixed(3)} m/s exceeded safe threshold ${speedLimitAtRange.toFixed(3)} m/s at range ${range.toFixed(1)}m`,
        threshold: speedLimitAtRange,
        measured: closingSpeed,
      };
    }

    // 2. Check corridor boundary breach
    if (guidance.corridorMarginRatio > limits.maxCorridorMarginRatio && range > 0.5) {
      return {
        shouldAbort: true,
        code: 'CORRIDOR_SAFETY_BREACH',
        message: `Lateral offset ${guidance.corridorErrorM.toFixed(2)}m exceeded corridor boundary by ${(guidance.corridorMarginRatio * 100 - 100).toFixed(0)}%`,
        threshold: 1.0,
        measured: guidance.corridorMarginRatio,
      };
    }

    // 3. Check excessive vehicle angular rate
    const angularRateDeg = (Vec3.norm(est.angularVelocity) * 180) / Math.PI;
    if (angularRateDeg > limits.maxAngularRateDegPerSec) {
      return {
        shouldAbort: true,
        code: 'EXCESSIVE_ANGULAR_RATE',
        message: `Angular rate ${angularRateDeg.toFixed(2)}°/s exceeded safe attitude stability threshold ${limits.maxAngularRateDegPerSec}°/s`,
        threshold: limits.maxAngularRateDegPerSec,
        measured: angularRateDeg,
      };
    }

    // 4. Check Navigation EKF divergence
    const maxSigma = Math.max(est.sigmaPos.x, est.sigmaPos.y, est.sigmaPos.z) * 3.0; // 3-sigma
    if (maxSigma > limits.maxNavPositionUncertainty3SigmaM && range < 30.0) {
      return {
        shouldAbort: true,
        code: 'NAV_UNCERTAINTY_EXCEEDED',
        message: `Navigation 3-sigma position uncertainty ${maxSigma.toFixed(2)}m exceeded safe close-proximity limit ${limits.maxNavPositionUncertainty3SigmaM}m`,
        threshold: limits.maxNavPositionUncertainty3SigmaM,
        measured: maxSigma,
      };
    }

    // 5. Excessive contact force
    if (normalContactForceN > limits.maxAllowableNormalContactForceN) {
      return {
        shouldAbort: true,
        code: 'EXCESSIVE_CONTACT_LOAD',
        message: `Interface contact load ${normalContactForceN.toFixed(0)} N exceeded structural threshold ${limits.maxAllowableNormalContactForceN} N`,
        threshold: limits.maxAllowableNormalContactForceN,
        measured: normalContactForceN,
      };
    }

    return {
      shouldAbort: false,
      code: 'NOMINAL',
      message: 'All parameters within flight envelope limits',
      threshold: 0,
      measured: 0,
    };
  }
}
