// 6-Degree-of-Freedom (6-DOF) Spacecraft Rigid Body Numerical Integrator for NEWTON DOCK
// Integrates 3-axis translational motion and 3-axis rotational dynamics using 4th-Order Runge-Kutta (RK4).

import { Vector3, Vec3, Quaternion, Quat, Matrix3x3, Mat3 } from './math3d';

export interface Spacecraft6DofState {
  time: number;
  // Translational State (LVLH / Relative)
  position: Vector3;       // [m]
  velocity: Vector3;       // [m/s]
  // Rotational State
  attitude: Quaternion;    // Body attitude quaternion relative to LVLH
  angularVelocity: Vector3;// Body angular velocity omega [rad/s]
  // Mass Properties
  dryMassKg: number;
  propellantMassKg: number;
  totalMassKg: number;
  inertiaMatrix: Matrix3x3;
  // Accumulated Metrics
  cumulativeDeltaV: number;
  propellantConsumedKg: number;
}

export interface DynamicForcesMoments {
  forceLVLH: Vector3;
  forceBody: Vector3;
  torqueBody: Vector3;
  contactForcePort: Vector3;
  contactTorquePort: Vector3;
}

export class Spacecraft6DOF {
  static createDefaultChaser(): Spacecraft6DofState {
    const dryMass = 12500.0; // 12.5 tons servicing vehicle
    const propMass = 1800.0;
    const totalMass = dryMass + propMass;

    // Principal moments of inertia for cylindrical vehicle (r = 1.6m, L = 4.2m)
    // Ixx = 1/12 m (3r^2 + L^2), Iyy = 1/2 m r^2 (longitudinal axis), Izz = Ixx
    const Ixx = (1.0 / 12.0) * totalMass * (3 * 1.6 * 1.6 + 4.2 * 4.2);
    const Iyy = 0.5 * totalMass * (1.6 * 1.6);
    const Izz = Ixx;

    return {
      time: 0,
      position: { x: 0, y: 120, z: 0 }, // 120m away along approach axis
      velocity: { x: 0, y: -0.4, z: 0 },
      attitude: Quat.identity(),
      angularVelocity: { x: 0, y: 0, z: 0 },
      dryMassKg: dryMass,
      propellantMassKg: propMass,
      totalMassKg: totalMass,
      inertiaMatrix: Mat3.fromDiagonal({ x: Ixx, y: Iyy, z: Izz }),
      cumulativeDeltaV: 0,
      propellantConsumedKg: 0,
    };
  }

  /**
   * Evaluate state derivatives [dr/dt, dv/dt, dq/dt, domega/dt]
   */
  private static evaluateDerivatives(
    pos: Vector3,
    vel: Vector3,
    att: Quaternion,
    omega: Vector3,
    forcesMoments: DynamicForcesMoments,
    massKg: number,
    invInertia: Matrix3x3,
    meanMotion: number
  ) {
    // 1. Translational derivatives:
    // CW orbital acceleration + thruster specific force
    const n = meanMotion;
    const n2 = n * n;
    const fTotalLVLH = Vec3.add(
      forcesMoments.forceLVLH,
      Quat.rotateVector(att, forcesMoments.forceBody)
    );

    const aThrustX = fTotalLVLH.x / massKg;
    const aThrustY = fTotalLVLH.y / massKg;
    const aThrustZ = fTotalLVLH.z / massKg;

    const ax = 2.0 * n * vel.y + 3.0 * n2 * pos.x + aThrustX;
    const ay = -2.0 * n * vel.x + aThrustY;
    const az = -n2 * pos.z + aThrustZ;

    const dPos = { ...vel };
    const dVel = { x: ax, y: ay, z: az };

    // 2. Rotational derivatives:
    // dq/dt = 0.5 * q * (0, omega)
    const dAtt = Quat.derivative(att, omega);

    // Euler rotational equation: I * domega/dt = tau - omega x (I * omega)
    const I_omega = Mat3.multiplyVec(Mat3.invert(invInertia), omega);
    const gyroCross = Vec3.cross(omega, I_omega);
    const netTorque = Vec3.sub(forcesMoments.torqueBody, gyroCross);
    const dOmega = Mat3.multiplyVec(invInertia, netTorque);

    return { dPos, dVel, dAtt, dOmega };
  }

  /**
   * 4th-Order Runge-Kutta (RK4) 6-DOF Numerical Integration Step
   */
  static stepRK4(
    state: Spacecraft6DofState,
    forcesMoments: DynamicForcesMoments,
    massFlowRateKgPerSec: number,
    meanMotion: number,
    dt: number
  ): Spacecraft6DofState {
    const mass = Math.max(100.0, state.totalMassKg);
    const invInertia = Mat3.invert(state.inertiaMatrix);

    const r0 = state.position;
    const v0 = state.velocity;
    const q0 = state.attitude;
    const w0 = state.angularVelocity;

    // k1
    const k1 = this.evaluateDerivatives(r0, v0, q0, w0, forcesMoments, mass, invInertia, meanMotion);

    // k2
    const r_k2 = Vec3.add(r0, Vec3.scale(k1.dPos, 0.5 * dt));
    const v_k2 = Vec3.add(v0, Vec3.scale(k1.dVel, 0.5 * dt));
    const q_k2 = Quat.normalize({
      w: q0.w + 0.5 * dt * k1.dAtt.w,
      x: q0.x + 0.5 * dt * k1.dAtt.x,
      y: q0.y + 0.5 * dt * k1.dAtt.y,
      z: q0.z + 0.5 * dt * k1.dAtt.z,
    });
    const w_k2 = Vec3.add(w0, Vec3.scale(k1.dOmega, 0.5 * dt));
    const k2 = this.evaluateDerivatives(r_k2, v_k2, q_k2, w_k2, forcesMoments, mass, invInertia, meanMotion);

    // k3
    const r_k3 = Vec3.add(r0, Vec3.scale(k2.dPos, 0.5 * dt));
    const v_k3 = Vec3.add(v0, Vec3.scale(k2.dVel, 0.5 * dt));
    const q_k3 = Quat.normalize({
      w: q0.w + 0.5 * dt * k2.dAtt.w,
      x: q0.x + 0.5 * dt * k2.dAtt.x,
      y: q0.y + 0.5 * dt * k2.dAtt.y,
      z: q0.z + 0.5 * dt * k2.dAtt.z,
    });
    const w_k3 = Vec3.add(w0, Vec3.scale(k2.dOmega, 0.5 * dt));
    const k3 = this.evaluateDerivatives(r_k3, v_k3, q_k3, w_k3, forcesMoments, mass, invInertia, meanMotion);

    // k4
    const r_k4 = Vec3.add(r0, Vec3.scale(k3.dPos, dt));
    const v_k4 = Vec3.add(v0, Vec3.scale(k3.dVel, dt));
    const q_k4 = Quat.normalize({
      w: q0.w + dt * k3.dAtt.w,
      x: q0.x + dt * k3.dAtt.x,
      y: q0.y + dt * k3.dAtt.y,
      z: q0.z + dt * k3.dAtt.z,
    });
    const w_k4 = Vec3.add(w0, Vec3.scale(k3.dOmega, dt));
    const k4 = this.evaluateDerivatives(r_k4, v_k4, q_k4, w_k4, forcesMoments, mass, invInertia, meanMotion);

    // Weighted average sum
    const dPosNet: Vector3 = {
      x: (k1.dPos.x + 2 * k2.dPos.x + 2 * k3.dPos.x + k4.dPos.x) / 6.0,
      y: (k1.dPos.y + 2 * k2.dPos.y + 2 * k3.dPos.y + k4.dPos.y) / 6.0,
      z: (k1.dPos.z + 2 * k2.dPos.z + 2 * k3.dPos.z + k4.dPos.z) / 6.0,
    };

    const dVelNet: Vector3 = {
      x: (k1.dVel.x + 2 * k2.dVel.x + 2 * k3.dVel.x + k4.dVel.x) / 6.0,
      y: (k1.dVel.y + 2 * k2.dVel.y + 2 * k3.dVel.y + k4.dVel.y) / 6.0,
      z: (k1.dVel.z + 2 * k2.dVel.z + 2 * k3.dVel.z + k4.dVel.z) / 6.0,
    };

    const dAttNet: Quaternion = {
      w: (k1.dAtt.w + 2 * k2.dAtt.w + 2 * k3.dAtt.w + k4.dAtt.w) / 6.0,
      x: (k1.dAtt.x + 2 * k2.dAtt.x + 2 * k3.dAtt.x + k4.dAtt.x) / 6.0,
      y: (k1.dAtt.y + 2 * k2.dAtt.y + 2 * k3.dAtt.y + k4.dAtt.y) / 6.0,
      z: (k1.dAtt.z + 2 * k2.dAtt.z + 2 * k3.dAtt.z + k4.dAtt.z) / 6.0,
    };

    const dOmegaNet: Vector3 = {
      x: (k1.dOmega.x + 2 * k2.dOmega.x + 2 * k3.dOmega.x + k4.dOmega.x) / 6.0,
      y: (k1.dOmega.y + 2 * k2.dOmega.y + 2 * k3.dOmega.y + k4.dOmega.y) / 6.0,
      z: (k1.dOmega.z + 2 * k2.dOmega.z + 2 * k3.dOmega.z + k4.dOmega.z) / 6.0,
    };

    const newPos = Vec3.add(r0, Vec3.scale(dPosNet, dt));
    const newVel = Vec3.add(v0, Vec3.scale(dVelNet, dt));
    const newAtt = Quat.normalize({
      w: q0.w + dAttNet.w * dt,
      x: q0.x + dAttNet.x * dt,
      y: q0.y + dAttNet.y * dt,
      z: q0.z + dAttNet.z * dt,
    });
    const newOmega = Vec3.add(w0, Vec3.scale(dOmegaNet, dt));

    // Propellant mass update
    const deltaProp = massFlowRateKgPerSec * dt;
    const newPropMass = Math.max(0, state.propellantMassKg - deltaProp);
    const newTotalMass = state.dryMassKg + newPropMass;

    const fNetLVLH = Vec3.add(
      forcesMoments.forceLVLH,
      Quat.rotateVector(newAtt, forcesMoments.forceBody)
    );
    const fNetMag = Vec3.norm(fNetLVLH);
    const deltaV = (fNetMag / mass) * dt;

    return {
      time: state.time + dt,
      position: newPos,
      velocity: newVel,
      attitude: newAtt,
      angularVelocity: newOmega,
      dryMassKg: state.dryMassKg,
      propellantMassKg: newPropMass,
      totalMassKg: newTotalMass,
      inertiaMatrix: state.inertiaMatrix,
      cumulativeDeltaV: state.cumulativeDeltaV + deltaV,
      propellantConsumedKg: state.propellantConsumedKg + deltaProp,
    };
  }
}
