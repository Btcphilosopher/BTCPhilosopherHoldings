// 6-DOF Flight Controller & Thruster Allocation Matrix (TAM) Engine for NEWTON DOCK
// Translational PID, Quaternion Feedback Attitude Control, and Optimal Thruster Allocation.

import { Vector3, Vec3, Quaternion, Quat, Matrix3x3, Mat3 } from './math3d';

export interface ThrusterDef {
  id: number;
  name: string;
  positionInBody: Vector3; // [m]
  thrustDirection: Vector3; // Unit vector in body frame
  maxThrustN: number;      // Maximum thrust [N] (e.g. 25N cold-gas / 100N biprop)
  ispSeconds: number;      // Specific impulse (e.g. 220s / 310s)
  minPulseWidthSec: number;// Minimum impulse bit (MIB, e.g. 0.02s)
  isFunctional: boolean;   // Health state
  healthDegradation: number; // 1.0 = nominal, 0.0 = completely failed
}

export interface ControlCommand {
  commandedForceBody: Vector3;  // [N]
  commandedTorqueBody: Vector3; // [N*m]
  deltaVRequested: Vector3;     // [m/s]
}

export interface ThrusterFiringStatus {
  thrusterId: number;
  dutyCycle: number; // 0.0 to 1.0
  activeThrustN: number;
  massFlowKgPerSec: number;
}

export interface ThrusterAllocationResult {
  firings: ThrusterFiringStatus[];
  totalForceBody: Vector3;
  totalTorqueBody: Vector3;
  totalPropellantFlowKgPerSec: number;
  saturationOccurred: boolean;
}

export class SpacecraftController {
  // Translational PID gains
  private Kp_trans = 45.0;
  private Kd_trans = 65.0;
  private Ki_trans = 0.05;

  // Attitude PD gains
  private Kp_att = 120.0;
  private Kd_att = 80.0;

  // Integrator states
  private posErrorIntegral: Vector3 = { x: 0, y: 0, z: 0 };

  // 16-RCS Thruster Suite (4 Pods of 4 Thrusters on corners of the vehicle)
  private thrusters: ThrusterDef[] = [];

  constructor() {
    this.initStandardThrusterConfiguration();
  }

  private initStandardThrusterConfiguration() {
    this.thrusters = [];
    const d = 1.2; // Half-width of spacecraft bus
    const h = 1.0; // Half-height
    const maxT = 25.0; // 25 N thrusters
    const isp = 230.0; // seconds

    // Pod 1 (+X, +Z, +Y forward)
    this.thrusters.push(
      { id: 0, name: 'RCS_P1_PX', positionInBody: { x: d, y: h, z: d }, thrustDirection: { x: 1, y: 0, z: 0 }, maxThrustN: maxT, ispSeconds: isp, minPulseWidthSec: 0.02, isFunctional: true, healthDegradation: 1.0 },
      { id: 1, name: 'RCS_P1_PZ', positionInBody: { x: d, y: h, z: d }, thrustDirection: { x: 0, y: 0, z: 1 }, maxThrustN: maxT, ispSeconds: isp, minPulseWidthSec: 0.02, isFunctional: true, healthDegradation: 1.0 },
      { id: 2, name: 'RCS_P1_PY', positionInBody: { x: d, y: h, z: d }, thrustDirection: { x: 0, y: 1, z: 0 }, maxThrustN: maxT, ispSeconds: isp, minPulseWidthSec: 0.02, isFunctional: true, healthDegradation: 1.0 },
      { id: 3, name: 'RCS_P1_MY', positionInBody: { x: d, y: h, z: d }, thrustDirection: { x: 0, y: -1, z: 0 }, maxThrustN: maxT, ispSeconds: isp, minPulseWidthSec: 0.02, isFunctional: true, healthDegradation: 1.0 }
    );

    // Pod 2 (-X, +Z)
    this.thrusters.push(
      { id: 4, name: 'RCS_P2_MX', positionInBody: { x: -d, y: h, z: d }, thrustDirection: { x: -1, y: 0, z: 0 }, maxThrustN: maxT, ispSeconds: isp, minPulseWidthSec: 0.02, isFunctional: true, healthDegradation: 1.0 },
      { id: 5, name: 'RCS_P2_PZ', positionInBody: { x: -d, y: h, z: d }, thrustDirection: { x: 0, y: 0, z: 1 }, maxThrustN: maxT, ispSeconds: isp, minPulseWidthSec: 0.02, isFunctional: true, healthDegradation: 1.0 },
      { id: 6, name: 'RCS_P2_PY', positionInBody: { x: -d, y: h, z: d }, thrustDirection: { x: 0, y: 1, z: 0 }, maxThrustN: maxT, ispSeconds: isp, minPulseWidthSec: 0.02, isFunctional: true, healthDegradation: 1.0 },
      { id: 7, name: 'RCS_P2_MY', positionInBody: { x: -d, y: h, z: d }, thrustDirection: { x: 0, y: -1, z: 0 }, maxThrustN: maxT, ispSeconds: isp, minPulseWidthSec: 0.02, isFunctional: true, healthDegradation: 1.0 }
    );

    // Pod 3 (+X, -Z)
    this.thrusters.push(
      { id: 8, name: 'RCS_P3_PX', positionInBody: { x: d, y: -h, z: -d }, thrustDirection: { x: 1, y: 0, z: 0 }, maxThrustN: maxT, ispSeconds: isp, minPulseWidthSec: 0.02, isFunctional: true, healthDegradation: 1.0 },
      { id: 9, name: 'RCS_P3_MZ', positionInBody: { x: d, y: -h, z: -d }, thrustDirection: { x: 0, y: 0, z: -1 }, maxThrustN: maxT, ispSeconds: isp, minPulseWidthSec: 0.02, isFunctional: true, healthDegradation: 1.0 },
      { id: 10, name: 'RCS_P3_PY', positionInBody: { x: d, y: -h, z: -d }, thrustDirection: { x: 0, y: 1, z: 0 }, maxThrustN: maxT, ispSeconds: isp, minPulseWidthSec: 0.02, isFunctional: true, healthDegradation: 1.0 },
      { id: 11, name: 'RCS_P3_MY', positionInBody: { x: d, y: -h, z: -d }, thrustDirection: { x: 0, y: -1, z: 0 }, maxThrustN: maxT, ispSeconds: isp, minPulseWidthSec: 0.02, isFunctional: true, healthDegradation: 1.0 }
    );

    // Pod 4 (-X, -Z)
    this.thrusters.push(
      { id: 12, name: 'RCS_P4_MX', positionInBody: { x: -d, y: -h, z: -d }, thrustDirection: { x: -1, y: 0, z: 0 }, maxThrustN: maxT, ispSeconds: isp, minPulseWidthSec: 0.02, isFunctional: true, healthDegradation: 1.0 },
      { id: 13, name: 'RCS_P4_MZ', positionInBody: { x: -d, y: -h, z: -d }, thrustDirection: { x: 0, y: 0, z: -1 }, maxThrustN: maxT, ispSeconds: isp, minPulseWidthSec: 0.02, isFunctional: true, healthDegradation: 1.0 },
      { id: 14, name: 'RCS_P4_PY', positionInBody: { x: -d, y: -h, z: -d }, thrustDirection: { x: 0, y: 1, z: 0 }, maxThrustN: maxT, ispSeconds: isp, minPulseWidthSec: 0.02, isFunctional: true, healthDegradation: 1.0 },
      { id: 15, name: 'RCS_P4_MY', positionInBody: { x: -d, y: -h, z: -d }, thrustDirection: { x: 0, y: -1, z: 0 }, maxThrustN: maxT, ispSeconds: isp, minPulseWidthSec: 0.02, isFunctional: true, healthDegradation: 1.0 }
    );
  }

  getThrusters(): ThrusterDef[] {
    return this.thrusters;
  }

  setThrusterFault(thrusterId: number, isFunctional: boolean, degradation = 1.0) {
    const t = this.thrusters.find(item => item.id === thrusterId);
    if (t) {
      t.isFunctional = isFunctional;
      t.healthDegradation = degradation;
    }
  }

  resetIntegrators() {
    this.posErrorIntegral = { x: 0, y: 0, z: 0 };
  }

  /**
   * Compute commanded Force and Torque vectors in Chaser body frame
   */
  computeControlCommands(
    estPos: Vector3,
    estVel: Vector3,
    estAtt: Quaternion,
    estOmega: Vector3,
    desiredPos: Vector3,
    desiredVel: Vector3,
    desiredAtt: Quaternion,
    desiredOmega: Vector3,
    massKg: number,
    inertiaMatrix: Matrix3x3,
    dt: number
  ): ControlCommand {
    // 1. Translational Control (PID)
    const posError = Vec3.sub(desiredPos, estPos);
    const velError = Vec3.sub(desiredVel, estVel);

    this.posErrorIntegral = Vec3.add(
      this.posErrorIntegral,
      Vec3.scale(posError, dt)
    );
    // Anti-windup clamping on integral
    this.posErrorIntegral.x = Math.max(-10, Math.min(10, this.posErrorIntegral.x));
    this.posErrorIntegral.y = Math.max(-10, Math.min(10, this.posErrorIntegral.y));
    this.posErrorIntegral.z = Math.max(-10, Math.min(10, this.posErrorIntegral.z));

    const forceLVLH: Vector3 = {
      x: massKg * (this.Kp_trans * posError.x + this.Kd_trans * velError.x + this.Ki_trans * this.posErrorIntegral.x),
      y: massKg * (this.Kp_trans * posError.y + this.Kd_trans * velError.y + this.Ki_trans * this.posErrorIntegral.y),
      z: massKg * (this.Kp_trans * posError.z + this.Kd_trans * velError.z + this.Ki_trans * this.posErrorIntegral.z),
    };

    // Rotate commanded force into body frame
    const forceBody = Quat.rotateVector(Quat.conjugate(estAtt), forceLVLH);

    // 2. Rotational Attitude Control (Quaternion Feedback PD)
    // Error quaternion: q_err = q_desired * q_current^-1
    const qErr = Quat.multiply(desiredAtt, Quat.conjugate(estAtt));
    // Vector part of error quaternion represents axis and half angle of rotation
    const signW = qErr.w >= 0 ? 1 : -1;
    const qErrVec: Vector3 = {
      x: signW * qErr.x,
      y: signW * qErr.y,
      z: signW * qErr.z,
    };

    const omegaError = Vec3.sub(desiredOmega, estOmega);

    // Gyro coupling feedforward term: omega x (I * omega)
    const I_omega = Mat3.multiplyVec(inertiaMatrix, estOmega);
    const gyroCoupling = Vec3.cross(estOmega, I_omega);

    const torqueBody: Vector3 = {
      x: this.Kp_att * qErrVec.x + this.Kd_att * omegaError.x + gyroCoupling.x,
      y: this.Kp_att * qErrVec.y + this.Kd_att * omegaError.y + gyroCoupling.y,
      z: this.Kp_att * qErrVec.z + this.Kd_att * omegaError.z + gyroCoupling.z,
    };

    return {
      commandedForceBody: forceBody,
      commandedTorqueBody: torqueBody,
      deltaVRequested: Vec3.scale(forceLVLH, dt / massKg),
    };
  }

  /**
   * Allocate forces and moments across 16 RCS thrusters via pseudo-inverse & PWM
   */
  allocateThrusters(
    cmdForce: Vector3,
    cmdTorque: Vector3
  ): ThrusterAllocationResult {
    const g0 = 9.80665; // m/s^2
    const firings: ThrusterFiringStatus[] = [];
    let totalFx = 0;
    let totalFy = 0;
    let totalFz = 0;
    let totalTx = 0;
    let totalTy = 0;
    let totalTz = 0;
    let totalFlow = 0;
    let saturation = false;

    // Linear mapping for each thruster: B_i = [ d_i; r_i x d_i ]
    for (const t of this.thrusters) {
      if (!t.isFunctional || t.healthDegradation <= 0.01) {
        firings.push({
          thrusterId: t.id,
          dutyCycle: 0,
          activeThrustN: 0,
          massFlowKgPerSec: 0,
        });
        continue;
      }

      const d = t.thrustDirection;
      const r = t.positionInBody;
      const torqueArm = Vec3.cross(r, d);

      // Dot product projection of desired force and torque along this thruster's action
      const forceContribution = (cmdForce.x * d.x + cmdForce.y * d.y + cmdForce.z * d.z) / (t.maxThrustN * 2.0);
      const torqueContribution = (cmdTorque.x * torqueArm.x + cmdTorque.y * torqueArm.y + cmdTorque.z * torqueArm.z) / (t.maxThrustN * 2.0);

      const rawDemand = forceContribution + torqueContribution;
      let duty = Math.max(0.0, Math.min(1.0, rawDemand));

      // Minimum impulse bit threshold (pulse quantization)
      if (duty < 0.04) {
        duty = 0.0;
      }
      if (rawDemand > 1.0) {
        saturation = true;
      }

      const activeThrust = duty * t.maxThrustN * t.healthDegradation;
      const massFlow = activeThrust / (t.ispSeconds * g0);

      totalFx += activeThrust * d.x;
      totalFy += activeThrust * d.y;
      totalFz += activeThrust * d.z;

      totalTx += activeThrust * torqueArm.x;
      totalTy += activeThrust * torqueArm.y;
      totalTz += activeThrust * torqueArm.z;

      totalFlow += massFlow;

      firings.push({
        thrusterId: t.id,
        dutyCycle: duty,
        activeThrustN: activeThrust,
        massFlowKgPerSec: massFlow,
      });
    }

    return {
      firings,
      totalForceBody: { x: totalFx, y: totalFy, z: totalFz },
      totalTorqueBody: { x: totalTx, y: totalTy, z: totalTz },
      totalPropellantFlowKgPerSec: totalFlow,
      saturationOccurred: saturation,
    };
  }
}
