// Terminal Rendezvous & Approach Guidance Engine for NEWTON DOCK
// Waypoint sequencing, glideslope velocity tapering, approach corridor geometry, and LOS control.

import { Vector3, Vec3, Quaternion, Quat } from './math3d';

export interface Waypoint {
  id: string;
  name: string;
  targetRelativePosition: Vector3; // [m] in LVLH
  targetRelativeVelocity: Vector3; // [m/s]
  targetAttitude: Quaternion;
  holdDurationSeconds: number;
  positionToleranceM: number;
  velocityToleranceMps: number;
}

export interface GuidanceCommand {
  desiredPosition: Vector3;
  desiredVelocity: Vector3;
  desiredAcceleration: Vector3;
  desiredAttitude: Quaternion;
  desiredAngularRate: Vector3;
  currentWaypointId: string;
  corridorErrorM: number;
  timeToContactSeconds: number;
  glideslopeSpeedLimitMps: number;
  isInCorridor: boolean;
  corridorMarginRatio: number; // 0 = centerline, 1.0 = corridor boundary, >1.0 = breach
}

export interface CorridorConfig {
  approachConeHalfAngleRad: number; // e.g. 10 deg
  maxAxialVelocityMps: number;      // e.g. 0.10 m/s
  minAxialVelocityMps: number;      // e.g. 0.01 m/s
  glideslopeK: number;              // v_limit = K * sqrt(range)
  keepOutZoneRadiusM: number;       // 200m KOZ
  corridorSafetyBufferM: number;
}

export class GuidanceEngine {
  private waypoints: Waypoint[] = [
    {
      id: 'S1_HOLD',
      name: 'Hold Point S1 (Far Hold - 100m)',
      targetRelativePosition: { x: 0, y: 100, z: 0 },
      targetRelativeVelocity: { x: 0, y: 0, z: 0 },
      targetAttitude: Quat.identity(),
      holdDurationSeconds: 10,
      positionToleranceM: 2.0,
      velocityToleranceMps: 0.05,
    },
    {
      id: 'S2_HOLD',
      name: 'Hold Point S2 (Near Hold - 20m)',
      targetRelativePosition: { x: 0, y: 20, z: 0 },
      targetRelativeVelocity: { x: 0, y: 0, z: 0 },
      targetAttitude: Quat.identity(),
      holdDurationSeconds: 15,
      positionToleranceM: 0.5,
      velocityToleranceMps: 0.02,
    },
    {
      id: 'FINAL_APPROACH',
      name: 'Final Alignment & Terminal Ingress (0m)',
      targetRelativePosition: { x: 0, y: 0, z: 0 },
      targetRelativeVelocity: { x: 0, y: -0.05, z: 0 }, // 5 cm/s contact rate
      targetAttitude: Quat.identity(),
      holdDurationSeconds: 0,
      positionToleranceM: 0.05,
      velocityToleranceMps: 0.01,
    },
  ];

  private currentWpIndex = 0;
  private holdTimer = 0;

  static getDefaultCorridor(): CorridorConfig {
    return {
      approachConeHalfAngleRad: (12.0 * Math.PI) / 180.0, // 12 deg
      maxAxialVelocityMps: 0.15,
      minAxialVelocityMps: 0.015,
      glideslopeK: 0.035, // v(r) = 0.035 * sqrt(r)
      keepOutZoneRadiusM: 200.0,
      corridorSafetyBufferM: 0.05,
    };
  }

  reset() {
    this.currentWpIndex = 0;
    this.holdTimer = 0;
  }

  setWaypointIndex(index: number) {
    this.currentWpIndex = Math.min(this.waypoints.length - 1, Math.max(0, index));
    this.holdTimer = 0;
  }

  getCurrentWaypoint(): Waypoint {
    return this.waypoints[this.currentWpIndex];
  }

  /**
   * Compute terminal guidance command based on estimated relative state
   */
  computeGuidance(
    estPos: Vector3,
    estVel: Vector3,
    estAtt: Quaternion,
    dt: number,
    corridor: CorridorConfig = GuidanceEngine.getDefaultCorridor()
  ): GuidanceCommand {
    const wp = this.waypoints[this.currentWpIndex];
    const distToWp = Vec3.distance(estPos, wp.targetRelativePosition);
    const speed = Vec3.norm(estVel);

    // Check if waypoint reached to progress hold timer
    if (distToWp <= wp.positionToleranceM && speed <= wp.velocityToleranceMps) {
      this.holdTimer += dt;
      if (this.holdTimer >= wp.holdDurationSeconds && this.currentWpIndex < this.waypoints.length - 1) {
        this.currentWpIndex++;
        this.holdTimer = 0;
      }
    }

    const currentWp = this.waypoints[this.currentWpIndex];

    // In Docking Axis (+Y is approach axis):
    // Separation range is estPos.y
    const rangeY = Math.max(0.001, estPos.y);
    const lateralDist = Math.sqrt(estPos.x * estPos.x + estPos.z * estPos.z);

    // Corridor allowable lateral radius at range Y: R_corridor = y * tan(theta)
    const allowableLateralRadius = Math.max(0.15, rangeY * Math.tan(corridor.approachConeHalfAngleRad));
    const corridorMarginRatio = lateralDist / allowableLateralRadius;
    const isInCorridor = corridorMarginRatio <= 1.0;

    // Glideslope velocity profile (parabolic speed taper)
    // v_desired_y = -min(v_max, max(v_min, K * sqrt(y)))
    const taperedSpeed = Math.min(
      corridor.maxAxialVelocityMps,
      Math.max(corridor.minAxialVelocityMps, corridor.glideslopeK * Math.sqrt(rangeY))
    );

    let desiredVy = 0;
    if (this.currentWpIndex === this.waypoints.length - 1) {
      // Final approach: glide smoothly toward y=0 at tapered closing velocity
      desiredVy = -taperedSpeed;
    } else {
      // Station keeping or transitioning to intermediate hold
      const dy = currentWp.targetRelativePosition.y - estPos.y;
      desiredVy = Math.sign(dy) * Math.min(Math.abs(dy) * 0.1, corridor.maxAxialVelocityMps);
    }

    // Desired lateral position is on the docking centerline (x=0, z=0)
    const desiredPos: Vector3 = {
      x: 0,
      y: Math.max(0, currentWp.targetRelativePosition.y),
      z: 0,
    };

    // Lateral velocity damping toward centerline: v_x = -K_lat * x
    const kLat = 0.25;
    const desiredVx = -kLat * estPos.x;
    const desiredVz = -kLat * estPos.z;

    const desiredVel: Vector3 = {
      x: Math.max(-0.1, Math.min(0.1, desiredVx)),
      y: desiredVy,
      z: Math.max(-0.1, Math.min(0.1, desiredVz)),
    };

    // Acceleration feedforward
    const desiredAcc: Vector3 = {
      x: (desiredVel.x - estVel.x) * 0.5,
      y: (desiredVel.y - estVel.y) * 0.5,
      z: (desiredVel.z - estVel.z) * 0.5,
    };

    // Desired attitude: Co-aligned with Target docking port
    const desiredAtt = Quat.identity();
    const desiredAngularRate: Vector3 = { x: 0, y: 0, z: 0 };

    // Estimated time to contact
    const closingSpeed = -estVel.y;
    const timeToContactSeconds = closingSpeed > 0.001 ? rangeY / closingSpeed : 9999.0;

    return {
      desiredPosition: desiredPos,
      desiredVelocity: desiredVel,
      desiredAcceleration: desiredAcc,
      desiredAttitude: desiredAtt,
      desiredAngularRate: desiredAngularRate,
      currentWaypointId: currentWp.id,
      corridorErrorM: lateralDist,
      timeToContactSeconds,
      glideslopeSpeedLimitMps: taperedSpeed,
      isInCorridor,
      corridorMarginRatio,
    };
  }
}
