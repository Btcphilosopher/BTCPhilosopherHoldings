// 3D Vector, Matrix, Quaternion, and Coordinate Frame transformations for NEWTON DOCK
// Deterministic mathematical foundation for orbital mechanics and 6-DOF spacecraft simulation.

export interface Vector3 {
  x: number;
  y: number;
  z: number;
}

export interface Quaternion {
  w: number;
  x: number;
  y: number;
  z: number;
}

export interface Matrix3x3 {
  m: [
    number, number, number,
    number, number, number,
    number, number, number
  ];
}

export type ReferenceFrame = 'ECI' | 'LVLH' | 'RTN' | 'TARGET_BODY' | 'CHASER_BODY' | 'DOCKING_PORT';

export class Vec3 {
  static create(x = 0, y = 0, z = 0): Vector3 {
    return { x, y, z };
  }

  static clone(v: Vector3): Vector3 {
    return { x: v.x, y: v.y, z: v.z };
  }

  static add(a: Vector3, b: Vector3): Vector3 {
    return { x: a.x + b.x, y: a.y + b.y, z: a.z + b.z };
  }

  static sub(a: Vector3, b: Vector3): Vector3 {
    return { x: a.x - b.x, y: a.y - b.y, z: a.z - b.z };
  }

  static scale(v: Vector3, s: number): Vector3 {
    return { x: v.x * s, y: v.y * s, z: v.z * s };
  }

  static dot(a: Vector3, b: Vector3): number {
    return a.x * b.x + a.y * b.y + a.z * b.z;
  }

  static cross(a: Vector3, b: Vector3): Vector3 {
    return {
      x: a.y * b.z - a.z * b.y,
      y: a.z * b.x - a.x * b.z,
      z: a.x * b.y - a.y * b.x,
    };
  }

  static norm(v: Vector3): number {
    return Math.sqrt(v.x * v.x + v.y * v.y + v.z * v.z);
  }

  static normSq(v: Vector3): number {
    return v.x * v.x + v.y * v.y + v.z * v.z;
  }

  static normalize(v: Vector3): Vector3 {
    const n = Vec3.norm(v);
    if (n < 1e-12) return { x: 0, y: 0, z: 0 };
    return { x: v.x / n, y: v.y / n, z: v.z / n };
  }

  static distance(a: Vector3, b: Vector3): number {
    return Vec3.norm(Vec3.sub(a, b));
  }

  static isFinite(v: Vector3): boolean {
    return Number.isFinite(v.x) && Number.isFinite(v.y) && Number.isFinite(v.z);
  }
}

export class Quat {
  static identity(): Quaternion {
    return { w: 1, x: 0, y: 0, z: 0 };
  }

  static fromAxisAngle(axis: Vector3, angleRad: number): Quaternion {
    const normAxis = Vec3.normalize(axis);
    const halfAngle = angleRad * 0.5;
    const sinHalf = Math.sin(halfAngle);
    return {
      w: Math.cos(halfAngle),
      x: normAxis.x * sinHalf,
      y: normAxis.y * sinHalf,
      z: normAxis.z * sinHalf,
    };
  }

  static fromEuler(rollRad: number, pitchRad: number, yawRad: number): Quaternion {
    const cr = Math.cos(rollRad * 0.5);
    const sr = Math.sin(rollRad * 0.5);
    const cp = Math.cos(pitchRad * 0.5);
    const sp = Math.sin(pitchRad * 0.5);
    const cy = Math.cos(yawRad * 0.5);
    const sy = Math.sin(yawRad * 0.5);

    return {
      w: cr * cp * cy + sr * sp * sy,
      x: sr * cp * cy - cr * sp * sy,
      y: cr * sp * cy + sr * cp * sy,
      z: cr * cp * sy - sr * sp * cy,
    };
  }

  static toEuler(q: Quaternion): { roll: number; pitch: number; yaw: number } {
    // Roll (x-axis rotation)
    const sinr_cosp = 2 * (q.w * q.x + q.y * q.z);
    const cosr_cosp = 1 - 2 * (q.x * q.x + q.y * q.y);
    const roll = Math.atan2(sinr_cosp, cosr_cosp);

    // Pitch (y-axis rotation)
    const sinp = 2 * (q.w * q.y - q.z * q.x);
    let pitch: number;
    if (Math.abs(sinp) >= 1) {
      pitch = (Math.sign(sinp) * Math.PI) / 2; // use 90 degrees if out of range
    } else {
      pitch = Math.asin(sinp);
    }

    // Yaw (z-axis rotation)
    const siny_cosp = 2 * (q.w * q.z + q.x * q.y);
    const cosy_cosp = 1 - 2 * (q.y * q.y + q.z * q.z);
    const yaw = Math.atan2(siny_cosp, cosy_cosp);

    return { roll, pitch, yaw };
  }

  static multiply(a: Quaternion, b: Quaternion): Quaternion {
    return {
      w: a.w * b.w - a.x * b.x - a.y * b.y - a.z * b.z,
      x: a.w * b.x + a.x * b.w + a.y * b.z - a.z * b.y,
      y: a.w * b.y - a.x * b.z + a.y * b.w + a.z * b.x,
      z: a.w * b.z + a.x * b.y - a.y * b.x + a.z * b.w,
    };
  }

  static conjugate(q: Quaternion): Quaternion {
    return { w: q.w, x: -q.x, y: -q.y, z: -q.z };
  }

  static normalize(q: Quaternion): Quaternion {
    const norm = Math.sqrt(q.w * q.w + q.x * q.x + q.y * q.y + q.z * q.z);
    if (norm < 1e-12) return Quat.identity();
    return {
      w: q.w / norm,
      x: q.x / norm,
      y: q.y / norm,
      z: q.z / norm,
    };
  }

  static rotateVector(q: Quaternion, v: Vector3): Vector3 {
    // v' = q * (0, v) * q^-1
    const qv: Quaternion = { w: 0, x: v.x, y: v.y, z: v.z };
    const qConj = Quat.conjugate(q);
    const res = Quat.multiply(Quat.multiply(q, qv), qConj);
    return { x: res.x, y: res.y, z: res.z };
  }

  static slerp(a: Quaternion, b: Quaternion, t: number): Quaternion {
    let dot = a.w * b.w + a.x * b.x + a.y * b.y + a.z * b.z;
    let bNorm = { ...b };
    if (dot < 0) {
      dot = -dot;
      bNorm = { w: -b.w, x: -b.x, y: -b.y, z: -b.z };
    }

    if (dot > 0.9995) {
      return Quat.normalize({
        w: a.w + t * (bNorm.w - a.w),
        x: a.x + t * (bNorm.x - a.x),
        y: a.y + t * (bNorm.y - a.y),
        z: a.z + t * (bNorm.z - a.z),
      });
    }

    const theta0 = Math.acos(dot);
    const theta = theta0 * t;
    const sinTheta = Math.sin(theta);
    const sinTheta0 = Math.sin(theta0);

    const s0 = Math.cos(theta) - (dot * sinTheta) / sinTheta0;
    const s1 = sinTheta / sinTheta0;

    return {
      w: s0 * a.w + s1 * bNorm.w,
      x: s0 * a.x + s1 * bNorm.x,
      y: s0 * a.y + s1 * bNorm.y,
      z: s0 * a.z + s1 * bNorm.z,
    };
  }

  static derivative(q: Quaternion, omega: Vector3): Quaternion {
    // dq/dt = 0.5 * q * (0, omega)
    return {
      w: 0.5 * (-q.x * omega.x - q.y * omega.y - q.z * omega.z),
      x: 0.5 * (q.w * omega.x + q.y * omega.z - q.z * omega.y),
      y: 0.5 * (q.w * omega.y - q.x * omega.z + q.z * omega.x),
      z: 0.5 * (q.w * omega.z + q.x * omega.y - q.y * omega.x),
    };
  }

  static angleBetween(a: Quaternion, b: Quaternion): number {
    const dot = Math.abs(a.w * b.w + a.x * b.x + a.y * b.y + a.z * b.z);
    const clamped = Math.min(1.0, Math.max(-1.0, dot));
    return 2.0 * Math.acos(clamped);
  }
}

export class Mat3 {
  static identity(): Matrix3x3 {
    return {
      m: [
        1, 0, 0,
        0, 1, 0,
        0, 0, 1,
      ],
    };
  }

  static fromDiagonal(d: Vector3): Matrix3x3 {
    return {
      m: [
        d.x, 0, 0,
        0, d.y, 0,
        0, 0, d.z,
      ],
    };
  }

  static multiplyVec(mat: Matrix3x3, v: Vector3): Vector3 {
    const m = mat.m;
    return {
      x: m[0] * v.x + m[1] * v.y + m[2] * v.z,
      y: m[3] * v.x + m[4] * v.y + m[5] * v.z,
      z: m[6] * v.x + m[7] * v.y + m[8] * v.z,
    };
  }

  static invert(mat: Matrix3x3): Matrix3x3 {
    const m = mat.m;
    const det =
      m[0] * (m[4] * m[8] - m[5] * m[7]) -
      m[1] * (m[3] * m[8] - m[5] * m[6]) +
      m[2] * (m[3] * m[7] - m[4] * m[6]);

    if (Math.abs(det) < 1e-15) {
      return Mat3.identity();
    }
    const invDet = 1.0 / det;

    return {
      m: [
        (m[4] * m[8] - m[5] * m[7]) * invDet,
        (m[2] * m[7] - m[1] * m[8]) * invDet,
        (m[1] * m[5] - m[2] * m[4]) * invDet,

        (m[5] * m[6] - m[3] * m[8]) * invDet,
        (m[0] * m[8] - m[2] * m[6]) * invDet,
        (m[2] * m[3] - m[0] * m[5]) * invDet,

        (m[3] * m[7] - m[4] * m[6]) * invDet,
        (m[1] * m[6] - m[0] * m[7]) * invDet,
        (m[0] * m[4] - m[1] * m[3]) * invDet,
      ],
    };
  }
}
