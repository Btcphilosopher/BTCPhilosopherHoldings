// Relative Orbital Dynamics Engine for NEWTON DOCK
// Clohessy-Wiltshire (Hill) linear equations, State Transition Matrix, and nonlinear relative motion.

import { Vector3, Vec3 } from './math3d';

export interface RelativeState {
  // Relative position in LVLH frame [m]
  // x: Radial (R-bar / away from Earth)
  // y: In-track (V-bar / along velocity direction)
  // z: Cross-track (H-bar / out-of-plane)
  position: Vector3;
  // Relative velocity in LVLH frame [m/s]
  velocity: Vector3;
  // Relative acceleration [m/s^2]
  acceleration?: Vector3;
}

export class RelativeMotion {
  /**
   * Compute relative acceleration from Clohessy-Wiltshire equations:
   * x'' = 2*n*y' + 3*n^2*x + fx/m
   * y'' = -2*n*x' + fy/m
   * z'' = -n^2*z + fz/m
   *
   * @param relState Current relative position & velocity in LVLH frame
   * @param n Mean motion of target circular orbit (rad/s), n = sqrt(mu / a^3)
   * @param thrustAcc Specific thrust acceleration (m/s^2) in LVLH frame
   */
  static cwAcceleration(relState: RelativeState, n: number, thrustAcc: Vector3 = { x: 0, y: 0, z: 0 }): Vector3 {
    const { x: rx, z: rz } = relState.position;
    const { x: vx, y: vy } = relState.velocity;

    const n2 = n * n;

    const ax = 2.0 * n * vy + 3.0 * n2 * rx + thrustAcc.x;
    const ay = -2.0 * n * vx + thrustAcc.y;
    const az = -n2 * rz + thrustAcc.z;

    return { x: ax, y: ay, z: az };
  }

  /**
   * Analytical Clohessy-Wiltshire (Hill) State Transition Matrix propagation for unforced motion
   * [r(t); v(t)] = Phi(t) * [r(0); v(0)]
   */
  static propagateCWAnalytical(initialState: RelativeState, n: number, dt: number): RelativeState {
    const x0 = initialState.position.x;
    const y0 = initialState.position.y;
    const z0 = initialState.position.z;
    const vx0 = initialState.velocity.x;
    const vy0 = initialState.velocity.y;
    const vz0 = initialState.velocity.z;

    const nt = n * dt;
    const sin_nt = Math.sin(nt);
    const cos_nt = Math.cos(nt);

    // Radial position x(t)
    const x = (4.0 - 3.0 * cos_nt) * x0 + (sin_nt / n) * vx0 + (2.0 / n) * (1.0 - cos_nt) * vy0;

    // In-track position y(t)
    const y =
      6.0 * (sin_nt - nt) * x0 +
      y0 -
      (2.0 / n) * (1.0 - cos_nt) * vx0 +
      ((4.0 * sin_nt - 3.0 * nt) / n) * vy0;

    // Cross-track position z(t)
    const z = cos_nt * z0 + (sin_nt / n) * vz0;

    // Radial velocity vx(t)
    const vx = 3.0 * n * sin_nt * x0 + cos_nt * vx0 + 2.0 * sin_nt * vy0;

    // In-track velocity vy(t)
    const vy = 6.0 * n * (cos_nt - 1.0) * x0 - 2.0 * sin_nt * vx0 + (4.0 * cos_nt - 3.0) * vy0;

    // Cross-track velocity vz(t)
    const vz = -n * sin_nt * z0 + cos_nt * vz0;

    const pos = { x, y, z };
    const vel = { x: vx, y: vy, z: vz };
    const acc = this.cwAcceleration({ position: pos, velocity: vel }, n);

    return {
      position: pos,
      velocity: vel,
      acceleration: acc,
    };
  }

  /**
   * Calculate Range, Range-Rate, and relative approach metrics
   */
  static computeRelativeMetrics(relState: RelativeState) {
    const range = Vec3.norm(relState.position);
    const posNorm = Vec3.normalize(relState.position);
    // Range rate is the projection of relative velocity along the line-of-sight vector
    // Range rate < 0 means approaching (closing)
    const rangeRate = Vec3.dot(relState.velocity, posNorm);
    const closingVelocity = -rangeRate; // Positive when closing

    // Lateral offset and velocity perpendicular to approach axis (assuming approach along +y or -y V-bar)
    const lateralPos = Math.sqrt(relState.position.x * relState.position.x + relState.position.z * relState.position.z);
    const lateralVel = Math.sqrt(relState.velocity.x * relState.velocity.x + relState.velocity.z * relState.velocity.z);

    return {
      range,
      rangeRate,
      closingVelocity,
      lateralPos,
      lateralVel,
    };
  }
}
