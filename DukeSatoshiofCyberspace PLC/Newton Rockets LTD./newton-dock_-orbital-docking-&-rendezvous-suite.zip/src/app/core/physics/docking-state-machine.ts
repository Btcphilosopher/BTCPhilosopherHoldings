// Deterministic Docking Capture State Machine & Safety Abort Monitor for NEWTON DOCK

import { CaptureAssessment } from './docking-geometry';
import { ContactForceResult } from './contact-dynamics';

export type DockingPhase =
  | 'FREE_FLIGHT'
  | 'APPROACH'
  | 'TERMINAL_APPROACH'
  | 'CONTACT'
  | 'INITIAL_CAPTURE'
  | 'SOFT_CAPTURE'
  | 'HARD_CAPTURE'
  | 'DOCKED'
  | 'ABORT';

export interface AbortReason {
  code: string;
  description: string;
  thresholdValue: number;
  measuredValue: number;
  timestamp: number;
}

export interface StateMachineStatus {
  currentPhase: DockingPhase;
  previousPhase: DockingPhase;
  timeInPhase: number;
  transitionReason: string;
  isSoftCaptured: boolean;
  isHardLocked: boolean;
  activeAbort: AbortReason | null;
  history: { from: DockingPhase; to: DockingPhase; time: number; reason: string }[];
}

export class DockingStateMachine {
  private currentPhase: DockingPhase = 'FREE_FLIGHT';
  private previousPhase: DockingPhase = 'FREE_FLIGHT';
  private timeInPhase = 0;
  private transitionReason = 'System initialized in Free Flight';
  private isSoftCaptured = false;
  private isHardLocked = false;
  private activeAbort: AbortReason | null = null;
  private history: { from: DockingPhase; to: DockingPhase; time: number; reason: string }[] = [];

  // Latch damping & hard-dock ring motorized retract timers
  private softCaptureDwellTime = 0;
  private hardLockRetractTime = 0;

  reset() {
    this.currentPhase = 'FREE_FLIGHT';
    this.previousPhase = 'FREE_FLIGHT';
    this.timeInPhase = 0;
    this.transitionReason = 'Reset to initial state';
    this.isSoftCaptured = false;
    this.isHardLocked = false;
    this.activeAbort = null;
    this.history = [];
    this.softCaptureDwellTime = 0;
    this.hardLockRetractTime = 0;
  }

  triggerAbort(code: string, description: string, threshold: number, measured: number, time: number) {
    if (this.currentPhase === 'ABORT' || this.currentPhase === 'DOCKED') return;

    this.activeAbort = {
      code,
      description,
      thresholdValue: threshold,
      measuredValue: measured,
      timestamp: time,
    };
    this.transitionTo('ABORT', `Safety abort triggered: ${description} (${code})`, time);
  }

  private transitionTo(nextPhase: DockingPhase, reason: string, time: number) {
    if (this.currentPhase === nextPhase) return;
    this.history.push({
      from: this.currentPhase,
      to: nextPhase,
      time,
      reason,
    });
    this.previousPhase = this.currentPhase;
    this.currentPhase = nextPhase;
    this.transitionReason = reason;
    this.timeInPhase = 0;
  }

  /**
   * Step the state machine given current physical state and contact forces
   */
  update(
    rangeM: number,
    contactResult: ContactForceResult,
    captureAssessment: CaptureAssessment,
    time: number,
    dt: number
  ): StateMachineStatus {
    this.timeInPhase += dt;

    if (this.currentPhase === 'ABORT' || this.currentPhase === 'DOCKED') {
      return this.getStatus();
    }

    switch (this.currentPhase) {
      case 'FREE_FLIGHT':
        // Transition to APPROACH when inside 200m Keep-Out-Zone (KOZ)
        if (rangeM <= 200.0) {
          this.transitionTo('APPROACH', `Range ${rangeM.toFixed(1)}m entered 200m Keep-Out Zone (KOZ)`, time);
        }
        break;

      case 'APPROACH':
        // Transition to TERMINAL_APPROACH inside 20m alignment gate
        if (rangeM <= 20.0) {
          this.transitionTo('TERMINAL_APPROACH', `Range ${rangeM.toFixed(1)}m entered Terminal 20m Ingress corridor`, time);
        }
        break;

      case 'TERMINAL_APPROACH':
        // Detect physical contact when contact force arises or separation <= 0
        if (contactResult.inContact || contactResult.normalForce > 10.0) {
          this.transitionTo('CONTACT', `Docking ring contact detected (Normal Force: ${contactResult.normalForce.toFixed(1)} N)`, time);
        }
        break;

      case 'CONTACT':
        // Verify capture conditions at contact interface
        if (captureAssessment.canCapture) {
          this.transitionTo('INITIAL_CAPTURE', 'Interface alignment & velocity within capture envelope; capture latches tripped', time);
        } else if (contactResult.normalForce > 2500.0) {
          this.triggerAbort('PEAK_LOAD_EXCEEDED', 'Peak contact force exceeded structural limit 2.5 kN', 2500, contactResult.normalForce, time);
        } else if (!contactResult.inContact && this.timeInPhase > 1.5) {
          // Rebounded without latch capture
          this.triggerAbort('CONTACT_REBOUND', 'Spacecraft rebounded from contact ring without capture latch engagement', 0, 0, time);
        }
        break;

      case 'INITIAL_CAPTURE':
        this.isSoftCaptured = true;
        // Damp relative kinematics for 2.0 seconds
        if (this.timeInPhase >= 1.5) {
          this.transitionTo('SOFT_CAPTURE', 'Soft capture latches locked, relative kinetic energy dissipated', time);
        }
        break;

      case 'SOFT_CAPTURE':
        this.softCaptureDwellTime += dt;
        // Motorized ring retraction begins (simulated 3 seconds)
        if (this.softCaptureDwellTime >= 2.5) {
          this.transitionTo('HARD_CAPTURE', 'Motorized capture ring retracted; 12 structural latches engaging', time);
        }
        break;

      case 'HARD_CAPTURE':
        this.hardLockRetractTime += dt;
        if (this.hardLockRetractTime >= 2.0) {
          this.isHardLocked = true;
          this.transitionTo('DOCKED', 'Structural hard-dock achieved; 12/12 hooks closed, umbilical seals pressurized', time);
        }
        break;
    }

    return this.getStatus();
  }

  getStatus(): StateMachineStatus {
    return {
      currentPhase: this.currentPhase,
      previousPhase: this.previousPhase,
      timeInPhase: this.timeInPhase,
      transitionReason: this.transitionReason,
      isSoftCaptured: this.isSoftCaptured,
      isHardLocked: this.isHardLocked,
      activeAbort: this.activeAbort,
      history: [...this.history],
    };
  }
}
