// Docking Interface Geometry & Physical Tolerances for NEWTON DOCK

import { Vector3, Vec3, Quaternion, Quat } from './math3d';

export type DockingInterfaceType = 'NASA_DOCKING_SYSTEM_IDA' | 'APAS_95' | 'PROBE_AND_DROGUE' | 'SERVICING_BERTHING_CBM';

export interface DockingPortGeometry {
  interfaceType: DockingInterfaceType;
  name: string;
  // Port position relative to spacecraft center of mass [m]
  portPositionInBody: Vector3;
  // Port orientation unit outward normal vector in body frame
  portNormalInBody: Vector3;
  // Capture guide cone half-angle [rad]
  captureConeAngleRad: number;
  // Maximum allowable lateral alignment error at contact [m]
  lateralToleranceM: number;
  // Maximum allowable axial contact distance for latch engagement [m]
  axialToleranceM: number;
  // Maximum allowable relative contact velocity [m/s]
  maxClosingVelocityMps: number;
  // Maximum allowable lateral velocity [m/s]
  maxLateralVelocityMps: number;
  // Maximum allowable angular misalignment (pitch/yaw) [rad]
  maxAngularMisalignmentRad: number;
  // Maximum allowable roll misalignment [rad]
  maxRollMisalignmentRad: number;
  // Maximum allowable angular velocity [rad/s]
  maxAngularVelocityRps: number;
  // Guide petal radius [m]
  guidePetalRadiusM: number;
  // Latch capture engagement depth [m]
  captureDepthM: number;
}

export interface RelativeDockingState {
  // Chaser port position relative to Target port in Target port frame [m]
  portRelativePosition: Vector3;
  // Chaser port velocity relative to Target port in Target port frame [m/s]
  portRelativeVelocity: Vector3;
  // Relative attitude quaternion (Target port to Chaser port)
  relativeAttitude: Quaternion;
  // Relative angular velocity in Target port frame [rad/s]
  relativeAngularVelocity: Vector3;
}

export interface CaptureAssessment {
  canCapture: boolean;
  axialDistanceM: number;
  lateralOffsetM: number;
  closingVelocityMps: number;
  lateralVelocityMps: number;
  angularMisalignmentDeg: number;
  rollMisalignmentDeg: number;
  angularRateDegPerSec: number;
  criteriaResults: {
    axialPassed: boolean;
    lateralPassed: boolean;
    closingVelPassed: boolean;
    lateralVelPassed: boolean;
    angularAlignPassed: boolean;
    rollAlignPassed: boolean;
    angularRatePassed: boolean;
  };
  failureReasons: string[];
}

export class DockingGeometryRegistry {
  static getStandardIDA(): DockingPortGeometry {
    return {
      interfaceType: 'NASA_DOCKING_SYSTEM_IDA',
      name: 'International Docking Adapter (NDS/IDSS)',
      portPositionInBody: { x: 0, y: 2.8, z: 0 },
      portNormalInBody: { x: 0, y: 1, z: 0 }, // Outward along +Y
      captureConeAngleRad: (10.0 * Math.PI) / 180.0, // 10 deg corridor
      lateralToleranceM: 0.10, // 10 cm max lateral offset
      axialToleranceM: 0.05, // 5 cm contact threshold
      maxClosingVelocityMps: 0.10, // 10 cm/s
      maxLateralVelocityMps: 0.05, // 5 cm/s
      maxAngularMisalignmentRad: (2.5 * Math.PI) / 180.0, // 2.5 deg
      maxRollMisalignmentRad: (3.0 * Math.PI) / 180.0, // 3.0 deg
      maxAngularVelocityRps: (0.5 * Math.PI) / 180.0, // 0.5 deg/s
      guidePetalRadiusM: 0.40,
      captureDepthM: 0.04,
    };
  }

  static getProbeAndDrogue(): DockingPortGeometry {
    return {
      interfaceType: 'PROBE_AND_DROGUE',
      name: 'Coaxial Probe and Drogue System',
      portPositionInBody: { x: 0, y: 2.2, z: 0 },
      portNormalInBody: { x: 0, y: 1, z: 0 },
      captureConeAngleRad: (15.0 * Math.PI) / 180.0,
      lateralToleranceM: 0.18,
      axialToleranceM: 0.06,
      maxClosingVelocityMps: 0.25,
      maxLateralVelocityMps: 0.10,
      maxAngularMisalignmentRad: (4.0 * Math.PI) / 180.0,
      maxRollMisalignmentRad: (180.0 * Math.PI) / 180.0, // Any roll angle
      maxAngularVelocityRps: (1.0 * Math.PI) / 180.0,
      guidePetalRadiusM: 0.30,
      captureDepthM: 0.08,
    };
  }

  static getServicingBerthing(): DockingPortGeometry {
    return {
      interfaceType: 'SERVICING_BERTHING_CBM',
      name: 'Common Berthing / Servicing Mechanism',
      portPositionInBody: { x: 0, y: 3.5, z: 0 },
      portNormalInBody: { x: 0, y: 1, z: 0 },
      captureConeAngleRad: (6.0 * Math.PI) / 180.0,
      lateralToleranceM: 0.06,
      axialToleranceM: 0.03,
      maxClosingVelocityMps: 0.04,
      maxLateralVelocityMps: 0.02,
      maxAngularMisalignmentRad: (1.5 * Math.PI) / 180.0,
      maxRollMisalignmentRad: (1.5 * Math.PI) / 180.0,
      maxAngularVelocityRps: (0.2 * Math.PI) / 180.0,
      guidePetalRadiusM: 0.65,
      captureDepthM: 0.03,
    };
  }

  /**
   * Evaluate if current relative port state satisfies capture conditions
   */
  static assessCapture(state: RelativeDockingState, geom: DockingPortGeometry): CaptureAssessment {
    // In docking port frame: +Y is approach axis outward from target port
    // Axial separation is state.portRelativePosition.y
    const axialDistanceM = Math.abs(state.portRelativePosition.y);
    const lateralOffsetM = Math.sqrt(
      state.portRelativePosition.x * state.portRelativePosition.x +
      state.portRelativePosition.z * state.portRelativePosition.z
    );

    // Closing velocity along approach axis (negative vy is closing)
    const closingVelocityMps = -state.portRelativeVelocity.y;
    const lateralVelocityMps = Math.sqrt(
      state.portRelativeVelocity.x * state.portRelativeVelocity.x +
      state.portRelativeVelocity.z * state.portRelativeVelocity.z
    );

    const euler = Quat.toEuler(state.relativeAttitude);
    const pitchDeg = Math.abs((euler.pitch * 180) / Math.PI);
    const yawDeg = Math.abs((euler.yaw * 180) / Math.PI);
    const rollDeg = Math.abs((euler.roll * 180) / Math.PI);
    const angularMisalignmentDeg = Math.sqrt(pitchDeg * pitchDeg + yawDeg * yawDeg);
    const rollMisalignmentDeg = rollDeg;

    const angularRateDegPerSec = (Vec3.norm(state.relativeAngularVelocity) * 180) / Math.PI;

    const axialPassed = axialDistanceM <= geom.axialToleranceM;
    const lateralPassed = lateralOffsetM <= geom.lateralToleranceM;
    const closingVelPassed = closingVelocityMps >= 0.005 && closingVelocityMps <= geom.maxClosingVelocityMps;
    const lateralVelPassed = lateralVelocityMps <= geom.maxLateralVelocityMps;
    const angularAlignPassed = (angularMisalignmentDeg * Math.PI) / 180 <= geom.maxAngularMisalignmentRad;
    const rollAlignPassed = (rollMisalignmentDeg * Math.PI) / 180 <= geom.maxRollMisalignmentRad;
    const angularRatePassed = (angularRateDegPerSec * Math.PI) / 180 <= geom.maxAngularVelocityRps;

    const failureReasons: string[] = [];
    if (!axialPassed) failureReasons.push(`Axial separation ${axialDistanceM.toFixed(3)}m exceeds ${geom.axialToleranceM}m`);
    if (!lateralPassed) failureReasons.push(`Lateral offset ${lateralOffsetM.toFixed(3)}m exceeds ${geom.lateralToleranceM}m`);
    if (closingVelocityMps < 0.005) failureReasons.push(`Insufficient closing velocity: ${closingVelocityMps.toFixed(3)} m/s (opening or stalled)`);
    if (closingVelocityMps > geom.maxClosingVelocityMps) failureReasons.push(`Closing velocity ${closingVelocityMps.toFixed(3)} m/s exceeds max ${geom.maxClosingVelocityMps} m/s`);
    if (!lateralVelPassed) failureReasons.push(`Lateral velocity ${lateralVelocityMps.toFixed(3)} m/s exceeds limit ${geom.maxLateralVelocityMps} m/s`);
    if (!angularAlignPassed) failureReasons.push(`Pitch/Yaw alignment error ${angularMisalignmentDeg.toFixed(2)}° exceeds max ${(geom.maxAngularMisalignmentRad * 180 / Math.PI).toFixed(1)}°`);
    if (!rollAlignPassed) failureReasons.push(`Roll error ${rollMisalignmentDeg.toFixed(2)}° exceeds max ${(geom.maxRollMisalignmentRad * 180 / Math.PI).toFixed(1)}°`);
    if (!angularRatePassed) failureReasons.push(`Angular rate ${angularRateDegPerSec.toFixed(2)}°/s exceeds max ${(geom.maxAngularVelocityRps * 180 / Math.PI).toFixed(2)}°/s`);

    const canCapture =
      axialPassed &&
      lateralPassed &&
      closingVelPassed &&
      lateralVelPassed &&
      angularAlignPassed &&
      rollAlignPassed &&
      angularRatePassed;

    return {
      canCapture,
      axialDistanceM,
      lateralOffsetM,
      closingVelocityMps,
      lateralVelocityMps,
      angularMisalignmentDeg,
      rollMisalignmentDeg,
      angularRateDegPerSec,
      criteriaResults: {
        axialPassed,
        lateralPassed,
        closingVelPassed,
        lateralVelPassed,
        angularAlignPassed,
        rollAlignPassed,
        angularRatePassed,
      },
      failureReasons,
    };
  }
}
