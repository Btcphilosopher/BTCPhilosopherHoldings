// Realistic Sensor Suite for NEWTON DOCK
// Models relative LIDAR, Optical Target Camera, 6-DOF IMU, Star Tracker with noise, bias drift, latency, and dropouts.

import { Vector3, Vec3, Quaternion, Quat } from './math3d';

export interface LidarMeasurement {
  timestamp: number;
  rangeM: number;
  rangeRateMps: number;
  azimuthRad: number;
  elevationRad: number;
  isValid: boolean;
  receivedSignalStrength: number;
}

export interface OpticalCameraPoseMeasurement {
  timestamp: number;
  measuredRelativePosition: Vector3;
  measuredRelativeAttitude: Quaternion;
  targetMarkersDetected: number;
  isValid: boolean;
  occluded: boolean;
}

export interface ImuMeasurement {
  timestamp: number;
  accelerometerMps2: Vector3; // Specific force (a - g) in body frame
  gyroscopeRps: Vector3;      // Body angular rate omega
  accelBias: Vector3;
  gyroBias: Vector3;
}

export interface StarTrackerMeasurement {
  timestamp: number;
  measuredAttitude: Quaternion;
  starsTracked: number;
  isValid: boolean;
}

export interface SensorFaultConfig {
  lidarDropout: boolean;
  opticalCameraLoss: boolean;
  imuExcessiveBias: boolean;
  highSensorNoise: boolean;
  latencySeconds: number;
}

export class SensorSuite {
  // IMU internal bias states (integrated random walk)
  private accelBiasState: Vector3 = { x: 0.002, y: -0.003, z: 0.001 }; // m/s^2
  private gyroBiasState: Vector3 = { x: 0.0001, y: 0.00015, z: -0.0001 }; // rad/s

  private lastTime = 0;

  // Simple pseudo-random Gaussian generator (Box-Muller)
  private gaussian(mean = 0, stdDev = 1): number {
    const u1 = Math.max(1e-15, Math.random());
    const u2 = Math.random();
    const z0 = Math.sqrt(-2.0 * Math.log(u1)) * Math.cos(2.0 * Math.PI * u2);
    return mean + z0 * stdDev;
  }

  private gaussianVec3(stdDev: number): Vector3 {
    return {
      x: this.gaussian(0, stdDev),
      y: this.gaussian(0, stdDev),
      z: this.gaussian(0, stdDev),
    };
  }

  /**
   * Measure relative range and line-of-sight angles with LIDAR
   */
  sampleLidar(
    trueRelPos: Vector3,
    trueRelVel: Vector3,
    time: number,
    faults: SensorFaultConfig
  ): LidarMeasurement {
    const trueRange = Vec3.norm(trueRelPos);
    const trueDir = Vec3.normalize(trueRelPos);
    const trueRangeRate = Vec3.dot(trueRelVel, trueDir);

    // Max range: 3000m, Min range: 0.02m
    if (faults.lidarDropout || trueRange > 3000 || trueRange < 0.02) {
      return {
        timestamp: time,
        rangeM: 0,
        rangeRateMps: 0,
        azimuthRad: 0,
        elevationRad: 0,
        isValid: false,
        receivedSignalStrength: 0,
      };
    }

    const noiseMultiplier = faults.highSensorNoise ? 5.0 : 1.0;
    // Range noise: ~1 cm + 0.05% of range
    const rangeNoiseStd = (0.01 + 0.0005 * trueRange) * noiseMultiplier;
    const rangeRateNoiseStd = 0.005 * noiseMultiplier;
    const angleNoiseStd = (0.0005) * noiseMultiplier; // ~0.03 deg

    const measuredRange = Math.max(0, trueRange + this.gaussian(0, rangeNoiseStd));
    const measuredRangeRate = trueRangeRate + this.gaussian(0, rangeRateNoiseStd);

    const trueAzimuth = Math.atan2(trueRelPos.x, trueRelPos.y);
    const trueElevation = Math.asin(Math.max(-1, Math.min(1, trueRelPos.z / Math.max(1e-6, trueRange))));

    return {
      timestamp: time,
      rangeM: measuredRange,
      rangeRateMps: measuredRangeRate,
      azimuthRad: trueAzimuth + this.gaussian(0, angleNoiseStd),
      elevationRad: trueElevation + this.gaussian(0, angleNoiseStd),
      isValid: true,
      receivedSignalStrength: Math.min(100, Math.max(10, 1000 / (trueRange * trueRange + 1))),
    };
  }

  /**
   * Measure 6-DOF relative pose with Optical Target Camera (Target Marker detection)
   */
  sampleOpticalCamera(
    trueRelPos: Vector3,
    trueRelAttitude: Quaternion,
    time: number,
    faults: SensorFaultConfig
  ): OpticalCameraPoseMeasurement {
    const range = Vec3.norm(trueRelPos);
    // Camera operational range: 0.1m to 150m, requires line-of-sight
    if (faults.opticalCameraLoss || range > 150 || range < 0.05) {
      return {
        timestamp: time,
        measuredRelativePosition: { x: 0, y: 0, z: 0 },
        measuredRelativeAttitude: Quat.identity(),
        targetMarkersDetected: 0,
        isValid: false,
        occluded: true,
      };
    }

    const noiseMultiplier = faults.highSensorNoise ? 4.0 : 1.0;
    // Pos noise: ~3 mm at 1m, ~50mm at 50m
    const posNoiseStd = (0.003 + 0.001 * range) * noiseMultiplier;
    const attNoiseStd = (0.002 + 0.0005 * range) * noiseMultiplier; // radians

    const posNoise = this.gaussianVec3(posNoiseStd);
    const measuredPos = Vec3.add(trueRelPos, posNoise);

    // Perturb quaternion with small random rotation
    const rotNoiseQuat = Quat.fromEuler(
      this.gaussian(0, attNoiseStd),
      this.gaussian(0, attNoiseStd),
      this.gaussian(0, attNoiseStd)
    );
    const measuredAtt = Quat.normalize(Quat.multiply(trueRelAttitude, rotNoiseQuat));

    return {
      timestamp: time,
      measuredRelativePosition: measuredPos,
      measuredRelativeAttitude: measuredAtt,
      targetMarkersDetected: range < 20 ? 8 : 4,
      isValid: true,
      occluded: false,
    };
  }

  /**
   * Sample 6-DOF Tactical-grade IMU (Specific force + Angular rates with bias random-walk)
   */
  sampleImu(
    trueSpecificForce: Vector3,
    trueAngularVel: Vector3,
    time: number,
    dt: number,
    faults: SensorFaultConfig
  ): ImuMeasurement {
    // Evolve bias random walk: d(bias)/dt = white noise
    const biasRandomWalkStd = 1e-5 * Math.sqrt(Math.max(1e-4, dt));
    this.accelBiasState = Vec3.add(this.accelBiasState, this.gaussianVec3(biasRandomWalkStd));
    this.gyroBiasState = Vec3.add(this.gyroBiasState, this.gaussianVec3(biasRandomWalkStd * 0.1));

    if (faults.imuExcessiveBias) {
      this.accelBiasState.x += 0.05 * dt;
      this.gyroBiasState.z += 0.005 * dt;
    }

    const noiseMult = faults.highSensorNoise ? 3.0 : 1.0;
    const accelNoise = this.gaussianVec3(0.0015 * noiseMult); // ~1.5 mg
    const gyroNoise = this.gaussianVec3(0.00025 * noiseMult);  // ~0.014 deg/s

    const measuredAccel = Vec3.add(Vec3.add(trueSpecificForce, this.accelBiasState), accelNoise);
    const measuredGyro = Vec3.add(Vec3.add(trueAngularVel, this.gyroBiasState), gyroNoise);

    return {
      timestamp: time,
      accelerometerMps2: measuredAccel,
      gyroscopeRps: measuredGyro,
      accelBias: { ...this.accelBiasState },
      gyroBias: { ...this.gyroBiasState },
    };
  }

  /**
   * Sample Autonomous Star Tracker
   */
  sampleStarTracker(
    trueInertialAttitude: Quaternion,
    time: number,
    faults: SensorFaultConfig
  ): StarTrackerMeasurement {
    const jitterStd = (faults.highSensorNoise ? 3.0 : 1.0) * 0.0001; // ~20 arcsec
    const jitterQuat = Quat.fromEuler(
      this.gaussian(0, jitterStd),
      this.gaussian(0, jitterStd),
      this.gaussian(0, jitterStd * 3.0) // Roll around boresight has higher jitter
    );

    return {
      timestamp: time,
      measuredAttitude: Quat.normalize(Quat.multiply(trueInertialAttitude, jitterQuat)),
      starsTracked: 18,
      isValid: true,
    };
  }
}
