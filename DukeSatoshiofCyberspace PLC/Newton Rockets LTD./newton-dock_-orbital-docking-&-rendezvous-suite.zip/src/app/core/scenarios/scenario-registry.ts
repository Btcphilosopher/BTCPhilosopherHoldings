// Pre-Configured Aerospace Scenario Registry for NEWTON DOCK

import { Vector3, Quaternion, Quat } from '../physics/math3d';
import { SensorFaultConfig } from '../physics/sensors';
import { CorridorConfig, GuidanceEngine } from '../physics/guidance';
import { DockingPortGeometry, DockingGeometryRegistry } from '../physics/docking-geometry';

export interface MissionScenario {
  id: string;
  name: string;
  category: 'NOMINAL' | 'ABORT' | 'CONTINGENCY' | 'ADVANCED';
  description: string;
  targetOrbit: {
    name: string;
    altitudeKm: number;
    eccentricity: number;
    inclinationDeg: number;
    mu: number;
  };
  initialChaserState: {
    position: Vector3; // [m] in LVLH
    velocity: Vector3; // [m/s]
    attitude: Quaternion;
    angularVelocity: Vector3;
    totalMassKg: number;
    propellantMassKg: number;
  };
  sensorFaults: SensorFaultConfig;
  thrusterFaults: { thrusterId: number; functional: boolean; degradation: number }[];
  dockingPort: DockingPortGeometry;
  corridorConfig: CorridorConfig;
  expectedOutcome: string;
}

export const SCENARIOS: MissionScenario[] = [
  {
    id: 'nominal_docking',
    name: 'ND-001: Nominal International Docking Adapter (IDA) Rendezvous',
    category: 'NOMINAL',
    description: 'Standard nominal approach from 120m Hold Point S1 to 20m Hold Point S2, terminal corridor alignment, soft capture latch engagement, and structural hard-lock at 420km LEO.',
    targetOrbit: {
      name: 'Low Earth Orbit (ISS Orbit)',
      altitudeKm: 420,
      eccentricity: 0.0002,
      inclinationDeg: 51.64,
      mu: 3.986004418e14,
    },
    initialChaserState: {
      position: { x: 0.2, y: 120.0, z: -0.1 },
      velocity: { x: -0.01, y: -0.35, z: 0.01 },
      attitude: Quat.fromEuler(0.01, -0.02, 0.01),
      angularVelocity: { x: 0.001, y: -0.001, z: 0.001 },
      totalMassKg: 14300.0,
      propellantMassKg: 1800.0,
    },
    sensorFaults: {
      lidarDropout: false,
      opticalCameraLoss: false,
      imuExcessiveBias: false,
      highSensorNoise: false,
      latencySeconds: 0,
    },
    thrusterFaults: [],
    dockingPort: DockingGeometryRegistry.getStandardIDA(),
    corridorConfig: GuidanceEngine.getDefaultCorridor(),
    expectedOutcome: 'Successful soft capture at ~0.045 m/s, followed by ring retraction and 12/12 hard dock hooks locked.',
  },
  {
    id: 'high_closing_velocity',
    name: 'ND-002: Over-Speed Corridor Violation & Retrograde Abort',
    category: 'ABORT',
    description: 'Chaser approaches terminal gate with excessive closing velocity (-0.42 m/s). Safety monitor detects kinetic envelope breach at 25m and commands automated abort retro-burn.',
    targetOrbit: {
      name: 'Low Earth Orbit (ISS Orbit)',
      altitudeKm: 420,
      eccentricity: 0.0002,
      inclinationDeg: 51.64,
      mu: 3.986004418e14,
    },
    initialChaserState: {
      position: { x: 0.1, y: 80.0, z: 0.0 },
      velocity: { x: 0.0, y: -0.55, z: 0.0 }, // Excessive closing velocity
      attitude: Quat.identity(),
      angularVelocity: { x: 0, y: 0, z: 0 },
      totalMassKg: 14300.0,
      propellantMassKg: 1800.0,
    },
    sensorFaults: {
      lidarDropout: false,
      opticalCameraLoss: false,
      imuExcessiveBias: false,
      highSensorNoise: false,
      latencySeconds: 0,
    },
    thrusterFaults: [],
    dockingPort: DockingGeometryRegistry.getStandardIDA(),
    corridorConfig: GuidanceEngine.getDefaultCorridor(),
    expectedOutcome: 'Safety Abort triggered (EXCESSIVE_CLOSING_VELOCITY) at 25m. Abort burn clears keep-out zone safely.',
  },
  {
    id: 'lateral_offset_drift',
    name: 'ND-003: 4.5m Lateral Offset Glideslope Corridor Acquisition',
    category: 'CONTINGENCY',
    description: 'Chaser enters terminal region with severe lateral offset (dx = +4.5m, dz = -3.2m). 6-DOF cross-track thrusters actively drive vehicle back to approach centerline.',
    targetOrbit: {
      name: 'Low Earth Orbit (420 km)',
      altitudeKm: 420,
      eccentricity: 0.0002,
      inclinationDeg: 51.64,
      mu: 3.986004418e14,
    },
    initialChaserState: {
      position: { x: 4.5, y: 65.0, z: -3.2 },
      velocity: { x: -0.05, y: -0.22, z: 0.04 },
      attitude: Quat.fromEuler(0.04, 0.03, -0.02),
      angularVelocity: { x: 0, y: 0, z: 0 },
      totalMassKg: 14300.0,
      propellantMassKg: 1800.0,
    },
    sensorFaults: {
      lidarDropout: false,
      opticalCameraLoss: false,
      imuExcessiveBias: false,
      highSensorNoise: false,
      latencySeconds: 0,
    },
    thrusterFaults: [],
    dockingPort: DockingGeometryRegistry.getStandardIDA(),
    corridorConfig: GuidanceEngine.getDefaultCorridor(),
    expectedOutcome: 'Lateral deviation reduced to < 0.04m prior to 10m gate. Successful nominal capture.',
  },
  {
    id: 'sensor_dropout_blind',
    name: 'ND-004: Optical Camera Blackout & EKF Dead-Reckoning',
    category: 'CONTINGENCY',
    description: 'Optical Pose Camera experiences sun-glint blinding at 15m range. EKF navigation filter coasts on IMU and LIDAR range, monitoring 3-sigma covariance growth.',
    targetOrbit: {
      name: 'Low Earth Orbit (420 km)',
      altitudeKm: 420,
      eccentricity: 0.0002,
      inclinationDeg: 51.64,
      mu: 3.986004418e14,
    },
    initialChaserState: {
      position: { x: 0.1, y: 40.0, z: 0.1 },
      velocity: { x: 0.0, y: -0.15, z: 0.0 },
      attitude: Quat.identity(),
      angularVelocity: { x: 0, y: 0, z: 0 },
      totalMassKg: 14300.0,
      propellantMassKg: 1800.0,
    },
    sensorFaults: {
      lidarDropout: false,
      opticalCameraLoss: true, // Camera blackout injected
      imuExcessiveBias: false,
      highSensorNoise: false,
      latencySeconds: 0,
    },
    thrusterFaults: [],
    dockingPort: DockingGeometryRegistry.getStandardIDA(),
    corridorConfig: GuidanceEngine.getDefaultCorridor(),
    expectedOutcome: 'EKF maintains bounded covariance via LIDAR ranging; capture achieved with degraded attitude margin.',
  },
  {
    id: 'thruster_pod_failure',
    name: 'ND-005: RCS Pod #2 Pitch-Down Thruster Fail-Frozen',
    category: 'CONTINGENCY',
    description: 'Thruster #6 (RCS Pod 2) suffers valve actuator failure. Thruster Allocation Matrix detects degradation and re-allocates torque demand across remaining 15 thrusters.',
    targetOrbit: {
      name: 'Low Earth Orbit (420 km)',
      altitudeKm: 420,
      eccentricity: 0.0002,
      inclinationDeg: 51.64,
      mu: 3.986004418e14,
    },
    initialChaserState: {
      position: { x: 0.0, y: 50.0, z: 0.0 },
      velocity: { x: 0.0, y: -0.18, z: 0.0 },
      attitude: Quat.identity(),
      angularVelocity: { x: 0, y: 0, z: 0 },
      totalMassKg: 14300.0,
      propellantMassKg: 1800.0,
    },
    sensorFaults: {
      lidarDropout: false,
      opticalCameraLoss: false,
      imuExcessiveBias: false,
      highSensorNoise: false,
      latencySeconds: 0,
    },
    thrusterFaults: [
      { thrusterId: 6, functional: false, degradation: 0.0 },
    ],
    dockingPort: DockingGeometryRegistry.getStandardIDA(),
    corridorConfig: GuidanceEngine.getDefaultCorridor(),
    expectedOutcome: 'Autonomous TAM re-allocation compensates for asymmetrical moment arm. Successful capture.',
  },
  {
    id: 'lunar_gateway_nrho',
    name: 'ND-006: Lunar Orbit Gateway Near-Rectilinear Halo Rendezvous',
    category: 'ADVANCED',
    description: 'Cislunar autonomous docking with Lunar Gateway in Moon orbital gravity field (mu = 4.9048695e12 m^3/s^2).',
    targetOrbit: {
      name: 'Lunar NRHO / Gateway Orbit',
      altitudeKm: 3200,
      eccentricity: 0.04,
      inclinationDeg: 89.2,
      mu: 4.9048695e12,
    },
    initialChaserState: {
      position: { x: 0.0, y: 90.0, z: 0.0 },
      velocity: { x: 0.0, y: -0.25, z: 0.0 },
      attitude: Quat.identity(),
      angularVelocity: { x: 0, y: 0, z: 0 },
      totalMassKg: 18500.0,
      propellantMassKg: 3200.0,
    },
    sensorFaults: {
      lidarDropout: false,
      opticalCameraLoss: false,
      imuExcessiveBias: false,
      highSensorNoise: false,
      latencySeconds: 0,
    },
    thrusterFaults: [],
    dockingPort: DockingGeometryRegistry.getStandardIDA(),
    corridorConfig: GuidanceEngine.getDefaultCorridor(),
    expectedOutcome: 'High-precision cislunar autonomous rendezvous and latch capture within tight contact velocity envelope.',
  },
];
