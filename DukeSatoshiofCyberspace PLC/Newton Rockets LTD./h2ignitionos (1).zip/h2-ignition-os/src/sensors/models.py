"""Abstract sensor models.

These describe *generic* sensing channels (temperature-like, pressure-like, ...) in
normalised units. Nothing here is tied to real hardware wiring, part numbers, or
physical installation — that is out of scope for this platform by design.
"""
from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from enum import Enum


class SensorType(str, Enum):
    TEMPERATURE = "temperature"
    PRESSURE = "pressure"
    FLOW = "flow"
    OPTICAL_INTENSITY = "optical_intensity"
    ELECTRICAL_SIGNAL = "electrical_signal"
    ACOUSTIC_SIGNAL = "acoustic_signal"
    VIBRATION = "vibration"
    CHAMBER_RESPONSE_PROXY = "chamber_response_proxy"
    IGNITION_EVENT_DETECTOR = "ignition_event_detector"


class QualityFlag(str, Enum):
    OK = "OK"
    DEGRADED = "DEGRADED"
    BAD = "BAD"
    DROPOUT = "DROPOUT"


@dataclass(frozen=True)
class SensorReading:
    """A single generic sensor observation."""

    timestamp: datetime
    sensor_id: str
    value: float
    uncertainty: float
    quality: QualityFlag = QualityFlag.OK


@dataclass(frozen=True)
class SensorSpec:
    """Static description of an abstract sensor channel."""

    sensor_id: str
    sensor_type: SensorType
    variable: str  # canonical normalised variable name this sensor reports
    nominal_noise_std: float
    nominal_sample_rate_hz: float
    dropout_probability: float = 0.0
