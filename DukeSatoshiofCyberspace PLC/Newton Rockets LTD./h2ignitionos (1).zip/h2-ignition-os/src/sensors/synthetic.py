"""Synthetic experiment generator.

Produces a fully labelled, clearly-marked-SYNTHETIC dataset in the platform's
canonical schema, driven entirely by normalised/dimensionless variables. This is the
data source used by ``examples/demo.py`` and by the test suite — no real experimental
or hardware data is used anywhere in this repository.
"""
from __future__ import annotations

import uuid
from dataclasses import dataclass

import numpy as np
import pandas as pd

from src.sensors.models import SensorType

SENSOR_SPECS: dict[str, dict] = {
    "temperature_1": {"type": SensorType.TEMPERATURE, "variable": "normalised_temperature", "rate_hz": 20, "noise": 0.02},
    "pressure_1": {"type": SensorType.PRESSURE, "variable": "normalised_pressure", "rate_hz": 50, "noise": 0.015},
    "flow_1": {"type": SensorType.FLOW, "variable": "normalised_flow", "rate_hz": 25, "noise": 0.02},
    "optical_1": {"type": SensorType.OPTICAL_INTENSITY, "variable": "normalised_optical_intensity", "rate_hz": 100, "noise": 0.03},
    "electrical_1": {"type": SensorType.ELECTRICAL_SIGNAL, "variable": "normalised_electrical_signal", "rate_hz": 100, "noise": 0.025},
    "acoustic_1": {"type": SensorType.ACOUSTIC_SIGNAL, "variable": "normalised_acoustic_signal", "rate_hz": 80, "noise": 0.03},
    "vibration_1": {"type": SensorType.VIBRATION, "variable": "normalised_vibration", "rate_hz": 60, "noise": 0.02},
    "chamber_response_1": {"type": SensorType.CHAMBER_RESPONSE_PROXY, "variable": "normalised_chamber_response", "rate_hz": 40, "noise": 0.02},
}

WINDOW_DURATION = 1.0  # normalised_transient_time spans [0, 1]


@dataclass
class SyntheticExperimentBundle:
    experiment_id: str
    measurements: pd.DataFrame
    run_metadata: pd.DataFrame
    source_label: str = "SYNTHETIC SIMULATION"


def _sigmoid(x: np.ndarray) -> np.ndarray:
    return 1.0 / (1.0 + np.exp(-x))


def generate_experiment(n_runs: int, seed: int = 42, anomaly_rate: float = 0.03,
                         corrupt_rate: float = 0.01) -> SyntheticExperimentBundle:
    """Generate a synthetic hydrogen-ignition research dataset.

    Every value produced is a normalised/dimensionless quantity. The dataset is
    intended purely for exercising the platform's statistical/ML pipeline.
    """
    rng = np.random.default_rng(seed)
    experiment_id = f"exp_synth_{seed:04d}"

    # --- run-level exogenous ("recorded in test log") setpoints ---
    normalised_temperature_set = rng.uniform(0.2, 0.95, n_runs)
    normalised_pressure_set = rng.uniform(0.2, 0.95, n_runs)
    normalised_flow_set = rng.uniform(0.1, 0.9, n_runs)
    normalised_energy_set = rng.uniform(0.1, 1.0, n_runs)
    normalised_mixture_state = rng.uniform(0.0, 1.0, n_runs)

    # Latent ignition-propensity score: a smooth, qualitative (not hardware-derived)
    # function of the normalised state — deliberately nonlinear + noisy so downstream
    # ML has something real to recover.
    latent = (
        2.6 * normalised_energy_set
        + 2.1 * normalised_mixture_state
        + 1.4 * normalised_temperature_set
        + 1.1 * normalised_pressure_set
        - 0.9 * (normalised_flow_set - 0.5) ** 2 * 4
        - 3.1
    )
    latent += rng.normal(0, 0.35, n_runs)
    p_ignite = _sigmoid(latent)
    ignited = rng.uniform(0, 1, n_runs) < p_ignite

    # Ignition delay: shorter with higher energy/mixture quality (lognormal proxy).
    delay_mu = 0.6 - 0.35 * normalised_energy_set - 0.25 * normalised_mixture_state
    delay_sigma = 0.25 + 0.1 * (1 - normalised_mixture_state)
    normalised_ignition_delay = rng.lognormal(delay_mu, delay_sigma)
    normalised_ignition_delay = np.clip(normalised_ignition_delay, 0.02, 0.9)

    is_anomalous = rng.uniform(0, 1, n_runs) < anomaly_rate

    run_ids = [f"run_{i:05d}" for i in range(n_runs)]
    run_metadata = pd.DataFrame({
        "experiment_id": experiment_id,
        "run_id": run_ids,
        "normalised_temperature_setpoint": normalised_temperature_set,
        "normalised_pressure_setpoint": normalised_pressure_set,
        "normalised_flow_setpoint": normalised_flow_set,
        "normalised_energy_setpoint": normalised_energy_set,
        "normalised_mixture_state": normalised_mixture_state,
        "ignited": ignited,
        "true_ignition_time": np.where(ignited, normalised_ignition_delay, np.nan),
        "is_anomalous": is_anomalous,
    })

    rows: list[dict] = []
    base_time = pd.Timestamp("2026-01-01T00:00:00Z")
    for i, run_id in enumerate(run_ids):
        t_ign = normalised_ignition_delay[i] if ignited[i] else None
        rows.extend(_simulate_run(
            rng=rng,
            experiment_id=experiment_id,
            run_id=run_id,
            run_index=i,
            base_time=base_time,
            ignited=bool(ignited[i]),
            t_ignition=t_ign,
            energy=normalised_energy_set[i],
            mixture=normalised_mixture_state[i],
            anomalous=bool(is_anomalous[i]),
            temperature_setpoint=normalised_temperature_set[i],
            pressure_setpoint=normalised_pressure_set[i],
            flow_setpoint=normalised_flow_set[i],
        ))

    df = pd.DataFrame(rows)

    # Inject a small number of explicit data-quality defects so the validation engine
    # has something real to find (still entirely synthetic).
    n_corrupt = int(len(df) * corrupt_rate)
    if n_corrupt:
        idx = rng.choice(df.index, size=n_corrupt, replace=False)
        df.loc[idx, "quality_flag"] = "BAD"
    n_dup = max(1, len(df) // 500)
    dup_rows = df.sample(n=min(n_dup, len(df)), random_state=seed)
    df = pd.concat([df, dup_rows], ignore_index=True)

    return SyntheticExperimentBundle(experiment_id=experiment_id, measurements=df, run_metadata=run_metadata)


_BASELINE_SETPOINT_TRACKING: dict[str, float] = {
    # Fraction of the corresponding normalised setpoint that a slow/ambient sensor's
    # quiescent baseline is expected to track (e.g. a pressure sensor's baseline
    # reading legitimately depends on the commanded normalised_pressure setpoint,
    # even before any ignition event). Event-driven channels (optical, electrical,
    # acoustic, vibration, chamber response) are excluded: they are expected to sit
    # near a near-zero noise floor until an ignition-related transient occurs.
    "temperature_1": 0.5,
    "pressure_1": 0.5,
    "flow_1": 0.6,
}


def _simulate_run(rng: np.random.Generator, experiment_id: str, run_id: str, run_index: int,
                   base_time: pd.Timestamp, ignited: bool, t_ignition: float | None,
                   energy: float, mixture: float, anomalous: bool,
                   temperature_setpoint: float, pressure_setpoint: float, flow_setpoint: float) -> list[dict]:
    rows: list[dict] = []
    run_start = base_time + pd.Timedelta(seconds=2.0 * run_index)
    setpoint_by_sensor = {
        "temperature_1": temperature_setpoint, "pressure_1": pressure_setpoint, "flow_1": flow_setpoint,
    }

    for sensor_id, spec in SENSOR_SPECS.items():
        n_samples = max(4, int(spec["rate_hz"] * WINDOW_DURATION))
        t = np.linspace(0, WINDOW_DURATION, n_samples)
        noise = rng.normal(0, spec["noise"], n_samples)
        tracking = _BASELINE_SETPOINT_TRACKING.get(sensor_id)
        if tracking is not None:
            baseline = tracking * setpoint_by_sensor[sensor_id] + 0.03 * rng.standard_normal()
        else:
            baseline = 0.1 + 0.05 * rng.standard_normal()

        signal = baseline + noise
        if ignited and t_ignition is not None:
            rise = _sigmoid((t - t_ignition) / 0.01)
            amplitude = 0.5 + 0.4 * energy + 0.2 * mixture
            signal = signal + amplitude * rise * _channel_gain(sensor_id, t, t_ignition)
            if anomalous:
                # abnormal secondary transient / oscillation after the primary event
                osc = 0.15 * np.sin(2 * np.pi * 12 * (t - t_ignition)) * (t > t_ignition)
                signal = signal + osc
        elif anomalous:
            # spurious transient with no true ignition -> should read as ABNORMAL/AMBIGUOUS
            spurious_t = rng.uniform(0.2, 0.8)
            signal = signal + 0.35 * _sigmoid((t - spurious_t) / 0.02) * np.exp(-4 * (t - spurious_t) ** 2)

        signal = np.clip(signal, -0.2, 1.4)

        dropout_mask = rng.uniform(0, 1, n_samples) < 0.002
        quality = np.where(dropout_mask, "DROPOUT", "OK")

        for j in range(n_samples):
            if dropout_mask[j]:
                continue
            rows.append({
                "experiment_id": experiment_id,
                "timestamp": run_start + pd.Timedelta(seconds=float(t[j])),
                "run_id": run_id,
                "sensor_id": sensor_id,
                "variable": spec["variable"],
                "value": float(signal[j]),
                "unit": "normalised",
                "quality_flag": quality[j],
                "uncertainty": float(spec["noise"]),
                "source": "SYNTHETIC SIMULATION",
            })
    return rows


def _channel_gain(sensor_id: str, t: np.ndarray, t_ignition: float) -> np.ndarray:
    """Per-channel response shape multiplier relative to the primary ignition rise."""
    if sensor_id == "optical_1":
        return np.ones_like(t)  # fastest, sharpest responder
    if sensor_id == "electrical_1":
        return np.ones_like(t)
    if sensor_id == "acoustic_1":
        return np.where(t > t_ignition, 0.9, 0.0) + 0.1  # slight propagation lag, modelled via rise term
    if sensor_id == "temperature_1":
        return 0.6 + 0.4 * _sigmoid((t - t_ignition - 0.05) / 0.03)  # slower thermal response
    if sensor_id == "pressure_1":
        return 0.85 * np.ones_like(t)
    if sensor_id == "vibration_1":
        return 0.5 * np.ones_like(t)
    return 0.7 * np.ones_like(t)
