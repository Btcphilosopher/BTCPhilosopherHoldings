"""Public Python API: ``H2IgnitionEngine`` ties every subsystem together behind a
small, stable surface, kept deliberately separate from any future GUI (project
requirement #25).

    engine = H2IgnitionEngine()
    dataset = engine.data.load("experiment.parquet")
    clean = engine.preprocess(dataset)
    features = engine.features.extract(clean)
    model = engine.models.train(features)
    prediction = model.predict(experimental_state)
    report = engine.optimisation.analyse(model)
"""
from __future__ import annotations

import pandas as pd

from src.anomaly.engine import AnomalyEngine
from src.data.loader import DataLoader
from src.data.schema import Dataset
from src.data.validation import DataQualityReport, DataValidator
from src.digital_twin.twin import DigitalTwin
from src.engine.config import EngineConfig
from src.engine.reproducibility import set_global_seed
from src.events.ignition_detector import IgnitionEventDetector
from src.events.timeseries import TimeSeriesEngine
from src.experiments.design import ExperimentalDesignEngine
from src.features.extraction import FeatureEngine
from src.models.ignition_delay import IgnitionDelayModel
from src.models.ignition_probability import IgnitionProbabilityModel, train_ignition_probability_model
from src.optimisation.engine import OptimisationEngine
from src.optimisation.sensitivity import SensitivityEngine
from src.physics.relations import PhysicsInformedModel
from src.reliability.engine import ReliabilityEngine
from src.reports.report_engine import ReportEngine
from src.storage.database import ExperimentDatabase
from src.uncertainty.engine import UncertaintyEngine
from src.uncertainty.monte_carlo import MonteCarloEngine


class _DataNamespace:
    def __init__(self, config: EngineConfig) -> None:
        self._loader = DataLoader()
        self._validator = DataValidator(config.data)

    def load(self, path: str) -> Dataset:
        return self._loader.load(path)

    def load_dataframe(self, df: pd.DataFrame, name: str = "in_memory") -> Dataset:
        return self._loader.load_dataframe(df, name=name)

    def validate(self, df: pd.DataFrame) -> DataQualityReport:
        return self._validator.validate(df)


class _FeaturesNamespace:
    def __init__(self) -> None:
        self._engine = FeatureEngine()

    def extract(self, clean_df: pd.DataFrame, run_metadata=None, event_results=None) -> pd.DataFrame:
        return self._engine.extract(clean_df, run_metadata=run_metadata, event_results=event_results)


class _ModelsNamespace:
    def __init__(self, config: EngineConfig) -> None:
        self.config = config

    def train(self, features: pd.DataFrame, feature_columns: list[str],
              label_column: str = "ignited", model_name: str = "random_forest") -> IgnitionProbabilityModel:
        return train_ignition_probability_model(
            features, feature_columns, label_column=label_column, model_name=model_name,
            random_state=self.config.reproducibility.random_seed,
            model_version=self.config.reproducibility.software_version,
        )

    def delay_model(self) -> IgnitionDelayModel:
        return IgnitionDelayModel()


class _OptimisationNamespace:
    def __init__(self, config: EngineConfig) -> None:
        self._engine = OptimisationEngine(
            n_lhs_samples=config.optimisation.n_lhs_samples,
            random_state=config.reproducibility.random_seed,
        )
        self.sensitivity = SensitivityEngine(random_state=config.reproducibility.random_seed)

    def evaluate(self, variable_bounds, objective_fn):
        return self._engine.evaluate(variable_bounds, objective_fn)

    def analyse(self, model: IgnitionProbabilityModel) -> dict:
        """Lightweight analysis summary keyed off an already-trained model's
        held-out metrics — a convenience wrapper matching the API sketch in the
        project spec; for full multi-objective search use ``evaluate``."""
        return {
            "model_name": model.model_name,
            "model_version": model.model_version,
            "metrics": model.metrics.to_dict(),
            "note": "Call engine.optimisation.evaluate(...) for full multi-objective / "
                    "Pareto-front optimisation over the normalised design space.",
        }


class H2IgnitionEngine:
    """Top-level facade for H2-IGNITION.OS."""

    config: EngineConfig

    def __init__(self, config: EngineConfig | None = None) -> None:
        self.config = config or EngineConfig()
        set_global_seed(self.config.reproducibility.random_seed)

        self.data = _DataNamespace(self.config)
        self.features = _FeaturesNamespace()
        self.models = _ModelsNamespace(self.config)
        self.optimisation = _OptimisationNamespace(self.config)

        self.timeseries = TimeSeriesEngine()
        self.event_detector = IgnitionEventDetector(self.config.event_detection)
        self.physics = PhysicsInformedModel()
        self.reliability = ReliabilityEngine(
            bootstrap_samples=self.config.reliability.bootstrap_samples,
            confidence=self.config.reliability.confidence_level,
            seed=self.config.reproducibility.random_seed,
        )
        self.uncertainty = UncertaintyEngine()
        self.monte_carlo = MonteCarloEngine(seed=self.config.reproducibility.random_seed)
        self.anomaly = AnomalyEngine()
        self.digital_twin_factory = DigitalTwin
        self.experimental_design = ExperimentalDesignEngine(random_state=self.config.reproducibility.random_seed)
        self.reports = ReportEngine()
        self.database = ExperimentDatabase(self.config.database_path)

    def preprocess(self, dataset: Dataset) -> pd.DataFrame:
        """Validates a dataset and returns the cleaned canonical-schema frame."""
        report = self.data.validate(dataset.to_frame())
        return report.clean_frame
