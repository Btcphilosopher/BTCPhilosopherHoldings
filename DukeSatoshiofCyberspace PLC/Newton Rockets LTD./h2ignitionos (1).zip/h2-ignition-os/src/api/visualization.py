"""Visualisation data API: structured, JSON-serialisable data for a future frontend
(telemetry dashboard, digital twin view, engineering HUD, research workstation). This
module contains no rendering code — only the data contract."""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

import numpy as np


def _jsonable(x: Any) -> Any:
    if isinstance(x, np.ndarray):
        return x.tolist()
    if isinstance(x, (np.floating, np.integer)):
        return x.item()
    return x


@dataclass
class VisualisationBundle:
    time_series: dict[str, list[dict[str, float]]] = field(default_factory=dict)
    prediction_curves: dict[str, list[dict[str, float]]] = field(default_factory=dict)
    confidence_intervals: dict[str, dict[str, float]] = field(default_factory=dict)
    heatmaps: dict[str, list[list[float]]] = field(default_factory=dict)
    sensitivity_ranking: list[dict[str, float]] = field(default_factory=list)
    pareto_front: list[dict[str, float]] = field(default_factory=list)
    monte_carlo_distributions: dict[str, list[float]] = field(default_factory=dict)
    anomaly_markers: list[dict[str, Any]] = field(default_factory=list)
    digital_twin_residuals: list[dict[str, Any]] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return {
            "time_series": self.time_series,
            "prediction_curves": self.prediction_curves,
            "confidence_intervals": self.confidence_intervals,
            "heatmaps": self.heatmaps,
            "sensitivity_ranking": self.sensitivity_ranking,
            "pareto_front": self.pareto_front,
            "monte_carlo_distributions": {k: [_jsonable(v) for v in vs] for k, vs in self.monte_carlo_distributions.items()},
            "anomaly_markers": self.anomaly_markers,
            "digital_twin_residuals": self.digital_twin_residuals,
        }


class VisualisationDataAPI:
    """Builds a :class:`VisualisationBundle` from platform outputs, kept
    intentionally decoupled from any GUI."""

    def build(self, *, run_df=None, sensitivity_report=None, optimisation_result=None,
              monte_carlo_results=None, anomaly_report=None, residual_reports=None) -> VisualisationBundle:
        bundle = VisualisationBundle()

        if run_df is not None:
            for variable, g in run_df.groupby("variable"):
                bundle.time_series[variable] = [
                    {"t": (ts - g["timestamp"].iloc[0]).total_seconds(), "value": float(v)}
                    for ts, v in zip(g["timestamp"], g["value"])
                ]

        if sensitivity_report is not None:
            bundle.sensitivity_ranking = [
                {"variable": v, "importance": imp} for v, imp in sensitivity_report.ranked()
            ]

        if optimisation_result is not None:
            bundle.pareto_front = [
                {**p.normalised_design_variables,
                 "ignition_probability": p.objectives.ignition_probability,
                 "repeatability": p.objectives.repeatability}
                for p in optimisation_result.pareto_front
            ]

        if monte_carlo_results is not None:
            for name, result in monte_carlo_results.items():
                bundle.monte_carlo_distributions[name] = result.samples.tolist()
                bundle.confidence_intervals[name] = {
                    "lower": result.confidence_interval[0], "upper": result.confidence_interval[1],
                    "mean": result.mean,
                }

        if anomaly_report is not None:
            bundle.anomaly_markers = [
                {"run_id": rid, "score": float(score), "is_anomalous": bool(flag)}
                for rid, score, flag in zip(
                    anomaly_report.run_ids, anomaly_report.anomaly_score, anomaly_report.is_anomalous
                )
            ]

        if residual_reports is not None:
            bundle.digital_twin_residuals = [
                {"run_id": rid, "rmse": r.rmse, "max_abs_residual": r.max_abs_residual,
                 "within_tolerance": r.within_tolerance}
                for rid, r in residual_reports.items()
            ]

        return bundle
