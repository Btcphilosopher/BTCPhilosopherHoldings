"""Scientific report generation. Uncertainty is never omitted; synthetic results are
always labelled; a limitations section is always present."""
from __future__ import annotations

import json
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any


@dataclass
class ScientificReport:
    experiment_summary: dict[str, Any]
    data_quality: dict[str, Any]
    model_performance: dict[str, Any]
    ignition_probability: dict[str, Any]
    ignition_delay: dict[str, Any]
    uncertainty: dict[str, Any]
    sensitivity: dict[str, Any]
    anomaly_detection: dict[str, Any]
    optimisation_results: dict[str, Any]
    reliability: dict[str, Any]
    limitations: list[str] = field(default_factory=list)
    generated_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    is_synthetic: bool = True

    def to_dict(self) -> dict[str, Any]:
        return {
            "generated_at": self.generated_at,
            "data_provenance": "SYNTHETIC SIMULATION" if self.is_synthetic else "supplied experimental data",
            "experiment_summary": self.experiment_summary,
            "data_quality": self.data_quality,
            "model_performance": self.model_performance,
            "ignition_probability": self.ignition_probability,
            "ignition_delay": self.ignition_delay,
            "uncertainty": self.uncertainty,
            "sensitivity": self.sensitivity,
            "anomaly_detection": self.anomaly_detection,
            "reliability": self.reliability,
            "optimisation_results": self.optimisation_results,
            "limitations": self.limitations,
        }

    def to_json(self, indent: int = 2) -> str:
        return json.dumps(self.to_dict(), indent=indent, default=str)

    def to_text(self) -> str:
        d = self.to_dict()
        lines = [
            "H2-IGNITION.OS — SCIENTIFIC REPORT",
            "=" * 40,
            f"Generated: {d['generated_at']}",
            f"Data provenance: {d['data_provenance']}",
            "",
            "EXPERIMENT SUMMARY",
            "-" * 20,
            *[f"  {k}: {v}" for k, v in d["experiment_summary"].items()],
            "",
            "DATA QUALITY",
            "-" * 20,
            *[f"  {k}: {v}" for k, v in d["data_quality"].items()],
            "",
            "MODEL PERFORMANCE",
            "-" * 20,
            *[f"  {k}: {v}" for k, v in d["model_performance"].items()],
            "",
            "IGNITION PROBABILITY",
            "-" * 20,
            *[f"  {k}: {v}" for k, v in d["ignition_probability"].items()],
            "",
            "IGNITION DELAY",
            "-" * 20,
            *[f"  {k}: {v}" for k, v in d["ignition_delay"].items()],
            "",
            "UNCERTAINTY",
            "-" * 20,
            *[f"  {k}: {v}" for k, v in d["uncertainty"].items()],
            "",
            "SENSITIVITY (ranked)",
            "-" * 20,
            *[f"  {name}: {imp:.3f}" for name, imp in d["sensitivity"].get("ranked", [])],
            "",
            "RELIABILITY",
            "-" * 20,
            *[f"  {k}: {v}" for k, v in d["reliability"].items()],
            "",
            "ANOMALY DETECTION",
            "-" * 20,
            *[f"  {k}: {v}" for k, v in d["anomaly_detection"].items()],
            "",
            "OPTIMISATION RESULTS",
            "-" * 20,
            *[f"  {k}: {v}" for k, v in d["optimisation_results"].items()],
            "",
            "LIMITATIONS",
            "-" * 20,
            *[f"  - {line}" for line in d["limitations"]],
            "",
            "IMPORTANT: This platform produces statistical/ML analysis of supplied or "
            "synthetic data. No output here is a guarantee of physical ignition "
            "behaviour, and this software contains no ignition-control capability.",
        ]
        return "\n".join(lines)


DEFAULT_LIMITATIONS = [
    "All numerical results in a SYNTHETIC SIMULATION report are generated from "
    "synthetic data and do not describe any real hardware or propellant system.",
    "Ignition-probability and ignition-delay predictions are statistical estimates "
    "over the supplied feature set, not guarantees of physical behaviour.",
    "Model performance metrics reflect held-out (out-of-fold) evaluation on the "
    "supplied dataset only, and may not generalise to conditions outside its range.",
    "Sensitivity rankings are model-relative (permutation importance / correlation) "
    "and do not, by themselves, establish causal mechanisms.",
    "Benchmark timings measure this software's computational performance only and "
    "must never be interpreted as physical propulsion-system performance.",
]


class ReportEngine:
    def generate(self, **sections: Any) -> ScientificReport:
        sections.setdefault("limitations", list(DEFAULT_LIMITATIONS))
        return ScientificReport(**sections)
