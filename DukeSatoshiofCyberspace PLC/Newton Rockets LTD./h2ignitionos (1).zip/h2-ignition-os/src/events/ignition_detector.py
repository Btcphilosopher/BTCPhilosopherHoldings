"""Abstract ignition-event detector.

Classifies a single run's synchronised sensor time series into NO_EVENT / AMBIGUOUS /
IGNITION_EVENT / ABNORMAL_EVENT, working entirely from supplied experimental or
synthetic data — there is no actuator or control-loop coupling here.
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import pandas as pd

from src.engine.config import EventDetectionConfig
from src.engine.states import IgnitionEventLabel


@dataclass
class IgnitionEventResult:
    run_id: str
    label: IgnitionEventLabel
    event_time: float | None
    confidence: float
    detection_latency: float | None
    signal_quality: float


class IgnitionEventDetector:
    """Detects a candidate ignition event from a run's aligned time series using a
    robust-statistics rise detector on the configured primary channel, cross-checked
    against a secondary channel for corroboration."""

    def __init__(self, config: EventDetectionConfig | None = None,
                 secondary_channel: str = "normalised_electrical_signal") -> None:
        self.config = config or EventDetectionConfig()
        self.secondary_channel = secondary_channel

    def detect(self, run_id: str, aligned: pd.DataFrame) -> IgnitionEventResult:
        channel = self.config.detection_channel
        if channel not in aligned.columns or aligned.empty:
            return IgnitionEventResult(run_id, IgnitionEventLabel.NO_EVENT, None, 0.0, None, 0.0)

        t = (aligned["timestamp"] - aligned["timestamp"].iloc[0]).dt.total_seconds().to_numpy()
        primary = aligned[channel].to_numpy(dtype=float)
        signal_quality = self._signal_quality(primary)

        # A too-small baseline window gives an unreliable std estimate (a handful of
        # noise samples can understate the true noise floor by chance, producing
        # spurious rise detections) — floor it at 10 samples where the channel has
        # enough history, and fall back to a robust (MAD-based) std estimator.
        baseline_n = max(10, len(primary) // 10)
        baseline_n = min(baseline_n, max(3, len(primary) // 2))
        baseline_mean = np.nanmean(primary[:baseline_n])
        mad = np.nanmedian(np.abs(primary[:baseline_n] - np.nanmedian(primary[:baseline_n])))
        baseline_std = max(np.nanstd(primary[:baseline_n]), 1.4826 * mad) + 1e-6

        z = (primary - baseline_mean) / baseline_std
        rise_idx = np.where(z > self.config.rise_threshold_sigma)[0]

        if len(rise_idx) == 0:
            ambiguous_idx = np.where(z > self.config.ambiguous_band_sigma)[0]
            if len(ambiguous_idx) == 0:
                return IgnitionEventResult(run_id, IgnitionEventLabel.NO_EVENT, None,
                                            confidence=float(1 - self._sigmoid(z.max())),
                                            detection_latency=None, signal_quality=signal_quality)
            event_idx = int(ambiguous_idx[0])
            confidence = float(self._sigmoid(z[event_idx] - self.config.rise_threshold_sigma))
            return IgnitionEventResult(run_id, IgnitionEventLabel.AMBIGUOUS, float(t[event_idx]),
                                        confidence=min(confidence, self.config.min_confidence),
                                        detection_latency=float(t[event_idx]), signal_quality=signal_quality)

        event_idx = int(rise_idx[0])
        event_time = float(t[event_idx])
        confidence = float(self._sigmoid(z[event_idx] - self.config.rise_threshold_sigma))

        secondary_corroborates = self._secondary_corroborates(aligned, t, event_idx)
        is_abnormal = self._is_abnormal(z, event_idx)

        if is_abnormal:
            label = IgnitionEventLabel.ABNORMAL_EVENT
            confidence *= 0.7
        elif not secondary_corroborates:
            label = IgnitionEventLabel.AMBIGUOUS
            confidence *= 0.6
        else:
            label = IgnitionEventLabel.IGNITION_EVENT

        return IgnitionEventResult(
            run_id=run_id, label=label, event_time=event_time,
            confidence=float(np.clip(confidence, 0, 1)),
            detection_latency=event_time, signal_quality=signal_quality,
        )

    def _secondary_corroborates(self, aligned: pd.DataFrame, t: np.ndarray, event_idx: int,
                                 tolerance_frac: float = 0.15) -> bool:
        if self.secondary_channel not in aligned.columns:
            return True
        sec = aligned[self.secondary_channel].to_numpy(dtype=float)
        baseline_n = max(3, len(sec) // 10)
        sec_z = (sec - np.nanmean(sec[:baseline_n])) / (np.nanstd(sec[:baseline_n]) + 1e-6)
        sec_rise = np.where(sec_z > self.config.ambiguous_band_sigma)[0]
        if len(sec_rise) == 0:
            return False
        window = max(1, int(len(t) * tolerance_frac))
        return bool(np.any(np.abs(sec_rise - event_idx) <= window))

    @staticmethod
    def _is_abnormal(z: np.ndarray, event_idx: int) -> bool:
        """A second independent rise well after the primary one indicates an abnormal
        (e.g. oscillatory / secondary-transient) event rather than a clean ignition."""
        after = z[event_idx + 1:]
        if len(after) < 4:
            return False
        settled = after[: len(after) // 3]
        late = after[len(after) // 3:]
        if len(settled) == 0 or len(late) == 0:
            return False
        return bool(np.nanmax(late) > np.nanmax(settled) + 2.0)

    @staticmethod
    def _signal_quality(values: np.ndarray) -> float:
        finite = np.isfinite(values)
        if finite.sum() == 0:
            return 0.0
        completeness = finite.mean()
        noisiness = 1.0 / (1.0 + np.nanstd(np.diff(values[finite])) if finite.sum() > 1 else 1.0)
        return float(np.clip(0.5 * completeness + 0.5 * noisiness, 0, 1))

    @staticmethod
    def _sigmoid(x: float) -> float:
        return 1.0 / (1.0 + np.exp(-x))
