"""High-resolution time-series engine: resampling, filtering, alignment, and
change-point / lag detection across multi-rate sensor channels."""
from __future__ import annotations

import numpy as np
import pandas as pd
from scipy import signal as sp_signal


class TimeSeriesEngine:
    """Utilities for turning multi-sensor, multi-rate canonical measurements into a
    single synchronised per-run timeline."""

    @staticmethod
    def resample(series: pd.Series, target_rate_hz: float) -> pd.Series:
        """Resample a timestamp-indexed series onto a uniform grid via linear
        interpolation (a light-weight alternative to full spectral resampling that
        keeps the operation robust to irregular input sampling)."""
        if series.empty:
            return series
        start, end = series.index.min(), series.index.max()
        if start == end:
            return series
        n = max(2, int((end - start).total_seconds() * target_rate_hz) + 1)
        grid = pd.date_range(start, end, periods=n)
        numeric_index = series.index.view(np.int64)
        grid_numeric = grid.view(np.int64)
        values = np.interp(grid_numeric, numeric_index, series.to_numpy())
        return pd.Series(values, index=grid, name=series.name)

    @staticmethod
    def interpolate_gaps(series: pd.Series, method: str = "linear") -> pd.Series:
        return series.interpolate(method=method).ffill().bfill()

    @staticmethod
    def low_pass_filter(values: np.ndarray, cutoff_ratio: float = 0.2, order: int = 3) -> np.ndarray:
        """Zero-phase Butterworth low-pass filter, cutoff expressed as a fraction of
        the Nyquist frequency (dimensionless — no assumed sample rate)."""
        if len(values) < 3 * (order + 1):
            return values
        b, a = sp_signal.butter(order, cutoff_ratio, btype="low")
        return sp_signal.filtfilt(b, a, values)

    @staticmethod
    def window(values: np.ndarray, window_size: int, step: int | None = None) -> list[np.ndarray]:
        step = step or window_size
        return [values[i:i + window_size] for i in range(0, max(1, len(values) - window_size + 1), step)]

    @staticmethod
    def align_to_canonical_timeline(run_df: pd.DataFrame, target_rate_hz: float = 100.0) -> pd.DataFrame:
        """Given long-format measurements for a single run (columns: timestamp,
        sensor_id, variable, value), synchronise every channel onto one shared,
        uniformly-sampled canonical timeline via `merge_asof`-style nearest alignment."""
        if run_df.empty:
            return pd.DataFrame()
        t0, t1 = run_df["timestamp"].min(), run_df["timestamp"].max()
        n = max(2, int((t1 - t0).total_seconds() * target_rate_hz) + 1)
        canonical = pd.DataFrame({"timestamp": pd.date_range(t0, t1, periods=n)})

        out = canonical.copy()
        for variable, g in run_df.groupby("variable"):
            g = g.sort_values("timestamp")
            merged = pd.merge_asof(canonical, g[["timestamp", "value"]], on="timestamp",
                                    direction="nearest")
            out[variable] = merged["value"]
        return out

    @staticmethod
    def cross_correlation(a: np.ndarray, b: np.ndarray) -> np.ndarray:
        a = (a - np.mean(a)) / (np.std(a) + 1e-12)
        b = (b - np.mean(b)) / (np.std(b) + 1e-12)
        return sp_signal.correlate(a, b, mode="full") / len(a)

    @classmethod
    def lag_detection(cls, a: np.ndarray, b: np.ndarray, dt: float = 1.0) -> float:
        """Estimated lag (in the same time units as ``dt``) of series ``b`` relative
        to ``a``, from the cross-correlation peak."""
        corr = cls.cross_correlation(a, b)
        lags = np.arange(-len(a) + 1, len(b))
        return float(lags[int(np.argmax(corr))] * dt)

    @staticmethod
    def change_point_detection(values: np.ndarray, window: int = 5, z_threshold: float = 4.0) -> list[int]:
        """Simple CUSUM-style rolling mean-shift detector. Returns indices flagged as
        change points. Deliberately dependency-free (no external change-point
        library) to keep the platform's dependency surface small."""
        if len(values) < 2 * window:
            return []
        series = pd.Series(values)
        rolling_mean = series.rolling(window).mean()
        rolling_std = series.rolling(window).std().replace(0, np.nan)
        z = ((series - rolling_mean.shift(window)) / rolling_std).abs()
        return list(np.where(z.to_numpy() > z_threshold)[0])
