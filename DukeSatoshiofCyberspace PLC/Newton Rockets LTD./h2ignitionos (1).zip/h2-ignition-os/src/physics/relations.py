"""Simplified, qualitative physics-informed relationships between normalised
experimental variables.

These are illustrative, dimensionless proxy relationships intended to give the
digital twin and surrogate model a physically-motivated prior — they are **not**
operational engine-design equations and use no real propellant properties, hardware
dimensions, or firing parameters.
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np


@dataclass(frozen=True)
class NormalisedState:
    normalised_temperature: float
    normalised_pressure: float
    normalised_flow: float
    normalised_energy: float
    normalised_mixture_state: float


class PhysicsInformedModel:
    """Computes qualitative, dimensionless proxy quantities from a normalised
    experimental state. All outputs are ratios/proxies in roughly [0, 1] or
    unitless — never real physical quantities."""

    def reaction_rate_proxy(self, state: NormalisedState) -> float:
        """Arrhenius-*shaped* (not Arrhenius-parameterised) dimensionless proxy:
        rate rises with normalised temperature and mixture quality, saturating at
        high values, consistent with qualitative combustion-kinetics intuition."""
        temperature_ratio = state.normalised_temperature
        mixture_quality = 1.0 - abs(state.normalised_mixture_state - 0.6) / 0.6
        proxy = 1.0 - np.exp(-3.0 * temperature_ratio * max(mixture_quality, 0.0))
        return float(np.clip(proxy, 0.0, 1.0))

    def energy_ratio(self, state: NormalisedState) -> float:
        return float(np.clip(state.normalised_energy, 0.0, 1.0))

    def pressure_ratio(self, state: NormalisedState) -> float:
        return float(np.clip(state.normalised_pressure, 0.0, 1.0))

    def flow_ratio(self, state: NormalisedState) -> float:
        return float(np.clip(state.normalised_flow, 0.0, 1.0))

    def delay_ratio(self, state: NormalisedState) -> float:
        """Qualitative proxy: ignition-delay ratio decreases as reaction-rate proxy
        and energy ratio increase (faster reaction / more energy -> shorter relative
        delay). Bounded to (epsilon, 1]."""
        rate = self.reaction_rate_proxy(state)
        energy = self.energy_ratio(state)
        denom = max(rate + 0.5 * energy, 1e-3)
        return float(np.clip(1.0 / (1.0 + 4.0 * denom), 1e-3, 1.0))

    def predicted_state_vector(self, state: NormalisedState) -> dict[str, float]:
        """Bundle of physics-informed proxies used as digital-twin priors and as
        surrogate-model training targets."""
        return {
            "reaction_rate_proxy": self.reaction_rate_proxy(state),
            "energy_ratio": self.energy_ratio(state),
            "pressure_ratio": self.pressure_ratio(state),
            "flow_ratio": self.flow_ratio(state),
            "delay_ratio": self.delay_ratio(state),
        }
