"""Engine-wide configuration, validated with Pydantic.

All configuration is expressed in normalised / dimensionless terms — there is no
hardware-specific configuration surface in this platform.
"""
from __future__ import annotations

from pathlib import Path
from typing import Optional

import yaml
from pydantic import BaseModel, Field, field_validator


class DataConfig(BaseModel):
    """Configuration for the data ingestion engine."""

    outlier_z_threshold: float = Field(4.0, gt=0)
    max_clock_drift_s: float = Field(0.25, gt=0)
    min_sampling_rate_hz: float = Field(1.0, gt=0)
    duplicate_timestamp_tolerance_s: float = Field(1e-6, ge=0)


class EventDetectionConfig(BaseModel):
    """Configuration for the ignition-event detector."""

    detection_channel: str = "normalised_optical_intensity"
    rise_threshold_sigma: float = Field(3.0, gt=0)
    ambiguous_band_sigma: float = Field(1.5, gt=0)
    min_confidence: float = Field(0.5, ge=0, le=1)


class ReliabilityConfig(BaseModel):
    bootstrap_samples: int = Field(2000, gt=0)
    confidence_level: float = Field(0.95, gt=0, lt=1)


class OptimisationConfig(BaseModel):
    n_lhs_samples: int = Field(256, gt=0)
    pareto_objectives: tuple[str, ...] = (
        "ignition_probability",
        "delay_variance",
        "uncertainty",
        "repeatability",
        "anomaly_probability",
        "transient_severity",
    )


class ReproducibilityConfig(BaseModel):
    random_seed: int = 42
    software_version: str = "0.1.0"


class EngineConfig(BaseModel):
    """Top-level configuration for :class:`H2IgnitionEngine`."""

    data: DataConfig = Field(default_factory=DataConfig)
    event_detection: EventDetectionConfig = Field(default_factory=EventDetectionConfig)
    reliability: ReliabilityConfig = Field(default_factory=ReliabilityConfig)
    optimisation: OptimisationConfig = Field(default_factory=OptimisationConfig)
    reproducibility: ReproducibilityConfig = Field(default_factory=ReproducibilityConfig)
    database_path: str = "synthetic_data/h2_ignition_os.sqlite"

    @field_validator("database_path")
    @classmethod
    def _non_empty(cls, v: str) -> str:
        if not v:
            raise ValueError("database_path must not be empty")
        return v

    @classmethod
    def from_yaml(cls, path: str | Path) -> "EngineConfig":
        with open(path, "r", encoding="utf-8") as fh:
            raw = yaml.safe_load(fh) or {}
        return cls.model_validate(raw)

    @classmethod
    def load(cls, path: Optional[str | Path] = None) -> "EngineConfig":
        if path is None:
            return cls()
        return cls.from_yaml(path)
