"""Reproducibility utilities: seed control and run-provenance capture.

Every simulation / model-training / optimisation run in H2-IGNITION.OS should record a
:class:`RunProvenance` so it can be exactly reproduced later.
"""
from __future__ import annotations

import hashlib
import platform
import random
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Mapping

import numpy as np

from src import __version__ as SOFTWARE_VERSION


def set_global_seed(seed: int) -> None:
    """Seed every RNG this platform touches (Python, NumPy)."""
    random.seed(seed)
    np.random.seed(seed)


def new_run_id() -> str:
    return str(uuid.uuid4())


def dataset_fingerprint(data_bytes: bytes) -> str:
    """Stable content hash used as a dataset version identifier."""
    return hashlib.sha256(data_bytes).hexdigest()[:16]


@dataclass(frozen=True)
class RunProvenance:
    """Everything needed to exactly reproduce a simulation / training run."""

    run_id: str
    random_seed: int
    model_version: str
    dataset_version: str
    parameters: Mapping[str, Any]
    configuration: Mapping[str, Any]
    software_version: str = SOFTWARE_VERSION
    python_version: str = field(default_factory=platform.python_version)
    timestamp: str = field(
        default_factory=lambda: datetime.now(timezone.utc).isoformat()
    )

    def to_dict(self) -> dict[str, Any]:
        return {
            "run_id": self.run_id,
            "random_seed": self.random_seed,
            "model_version": self.model_version,
            "dataset_version": self.dataset_version,
            "parameters": dict(self.parameters),
            "configuration": dict(self.configuration),
            "software_version": self.software_version,
            "python_version": self.python_version,
            "timestamp": self.timestamp,
        }
