"""Shared state enumerations used across the platform (notably the digital twin)."""
from __future__ import annotations

from enum import Enum


class DigitalTwinState(str, Enum):
    INITIALISING = "INITIALISING"
    CALIBRATING = "CALIBRATING"
    READY = "READY"
    RUNNING_SIMULATION = "RUNNING_SIMULATION"
    ANALYSING = "ANALYSING"
    UNCERTAIN = "UNCERTAIN"
    ANOMALY = "ANOMALY"
    COMPLETE = "COMPLETE"
    FAILED = "FAILED"


class IgnitionEventLabel(str, Enum):
    NO_EVENT = "NO_EVENT"
    AMBIGUOUS = "AMBIGUOUS"
    IGNITION_EVENT = "IGNITION_EVENT"
    ABNORMAL_EVENT = "ABNORMAL_EVENT"
