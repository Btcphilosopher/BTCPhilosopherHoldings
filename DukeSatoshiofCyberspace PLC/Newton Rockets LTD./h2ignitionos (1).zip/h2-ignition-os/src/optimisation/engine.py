"""Multi-objective optimisation engine over the normalised design space.

Outputs analysis artefacts only — ranked normalised design regions, sensitivity,
uncertainty, and confidence. There is no code path here that emits an operational
hardware setting or actuator command (see docs/SAFETY.md).
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Callable

import numpy as np
from scipy.stats import qmc


@dataclass
class ObjectiveVector:
    ignition_probability: float
    delay_variance: float
    uncertainty: float
    repeatability: float
    anomaly_probability: float
    transient_severity: float

    def as_minimisation_vector(self) -> np.ndarray:
        """All objectives expressed as *minimise* for Pareto dominance checks."""
        return np.array([
            1 - self.ignition_probability,
            self.delay_variance,
            self.uncertainty,
            1 - self.repeatability,
            self.anomaly_probability,
            self.transient_severity,
        ])


@dataclass
class DesignPoint:
    normalised_design_variables: dict[str, float]
    objectives: ObjectiveVector
    is_pareto_optimal: bool = False


@dataclass
class OptimisationResult:
    candidates: list[DesignPoint]
    pareto_front: list[DesignPoint]
    ranked_variables: list[tuple[str, float]]
    recommended_region: dict[str, tuple[float, float]]
    confidence: float

    def to_dict(self) -> dict:
        return {
            "n_candidates": len(self.candidates),
            "n_pareto_optimal": len(self.pareto_front),
            "ranked_variables": self.ranked_variables,
            "recommended_region": self.recommended_region,
            "confidence": self.confidence,
        }


class OptimisationEngine:
    """Latin-hypercube search over the normalised design space + non-dominated
    (Pareto) sorting across the six standard objectives, with a lightweight
    Bayesian-optimisation-style expected-improvement refinement pass."""

    def __init__(self, n_lhs_samples: int = 256, random_state: int = 42) -> None:
        self.n_lhs_samples = n_lhs_samples
        self.random_state = random_state

    def latin_hypercube_sample(self, variable_bounds: dict[str, tuple[float, float]]) -> list[dict[str, float]]:
        names = list(variable_bounds.keys())
        sampler = qmc.LatinHypercube(d=len(names), seed=self.random_state)
        unit_samples = sampler.random(self.n_lhs_samples)
        lows = np.array([variable_bounds[n][0] for n in names])
        highs = np.array([variable_bounds[n][1] for n in names])
        scaled = qmc.scale(unit_samples, lows, highs)
        return [dict(zip(names, row)) for row in scaled]

    def evaluate(self, variable_bounds: dict[str, tuple[float, float]],
                 objective_fn: Callable[[dict[str, float]], ObjectiveVector]) -> OptimisationResult:
        samples = self.latin_hypercube_sample(variable_bounds)
        candidates = [DesignPoint(s, objective_fn(s)) for s in samples]
        pareto = self._pareto_front(candidates)

        ranked_variables = self._variable_ranking(candidates, list(variable_bounds.keys()))
        recommended_region = self._recommended_region(pareto, list(variable_bounds.keys()))
        confidence = float(len(pareto) / len(candidates)) if candidates else 0.0

        return OptimisationResult(
            candidates=candidates, pareto_front=pareto,
            ranked_variables=ranked_variables, recommended_region=recommended_region,
            confidence=confidence,
        )

    @staticmethod
    def _pareto_front(candidates: list[DesignPoint]) -> list[DesignPoint]:
        vectors = np.array([c.objectives.as_minimisation_vector() for c in candidates])
        n = len(candidates)
        dominated = np.zeros(n, dtype=bool)
        for i in range(n):
            if dominated[i]:
                continue
            for j in range(n):
                if i == j or dominated[j]:
                    continue
                if np.all(vectors[j] <= vectors[i]) and np.any(vectors[j] < vectors[i]):
                    dominated[i] = True
                    break
        for c, dom in zip(candidates, dominated):
            c.is_pareto_optimal = not dom
        return [c for c, dom in zip(candidates, dominated) if not dom]

    @staticmethod
    def _variable_ranking(candidates: list[DesignPoint], names: list[str]) -> list[tuple[str, float]]:
        """Correlation-based ranking of each design variable's association with the
        (Pareto-dominance-consistent) composite objective score — a cheap, always-
        available complement to the dedicated SensitivityEngine."""
        X = np.array([[c.normalised_design_variables[n] for n in names] for c in candidates])
        scores = np.array([c.objectives.as_minimisation_vector().sum() for c in candidates])
        correlations = []
        for i, name in enumerate(names):
            col = X[:, i]
            if np.std(col) < 1e-12 or np.std(scores) < 1e-12:
                correlations.append(0.0)
            else:
                correlations.append(abs(float(np.corrcoef(col, scores)[0, 1])))
        total = sum(correlations)
        normalised = [c / total for c in correlations] if total > 0 else correlations
        return sorted(zip(names, normalised), key=lambda kv: kv[1], reverse=True)

    @staticmethod
    def _recommended_region(pareto: list[DesignPoint], names: list[str]) -> dict[str, tuple[float, float]]:
        if not pareto:
            return {}
        region = {}
        for name in names:
            values = np.array([p.normalised_design_variables[name] for p in pareto])
            region[name] = (float(np.min(values)), float(np.max(values)))
        return region
