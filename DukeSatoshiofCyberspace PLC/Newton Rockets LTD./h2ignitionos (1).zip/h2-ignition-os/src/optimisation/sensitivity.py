"""Sensitivity engine: how strongly does each normalised variable influence the
predicted ignition behaviour?"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np
from sklearn.inspection import permutation_importance


@dataclass
class SensitivityReport:
    variable: list[str]
    importance: list[float]

    def to_dict(self) -> dict:
        return {"variable": self.variable, "importance": self.importance}

    def ranked(self) -> list[tuple[str, float]]:
        return sorted(zip(self.variable, self.importance), key=lambda vi: vi[1], reverse=True)


class SensitivityEngine:
    """Permutation importance (model-agnostic) plus a finite-difference local
    sensitivity, both normalised to sum to 1 for readability."""

    def __init__(self, random_state: int = 42) -> None:
        self.random_state = random_state

    def permutation_importance(self, estimator, X: np.ndarray, y: np.ndarray,
                                 feature_names: list[str], n_repeats: int = 20) -> SensitivityReport:
        result = permutation_importance(
            estimator, X, y, n_repeats=n_repeats, random_state=self.random_state, scoring="roc_auc"
        )
        importances = np.clip(result.importances_mean, 0, None)
        total = importances.sum()
        normalised = (importances / total).tolist() if total > 0 else importances.tolist()
        return SensitivityReport(variable=list(feature_names), importance=normalised)

    def finite_difference(self, predict_fn, base_point: np.ndarray, feature_names: list[str],
                           step: float = 0.05) -> SensitivityReport:
        base = np.asarray(base_point, dtype=float)
        base_out = float(np.ravel(predict_fn(base.reshape(1, -1)))[0])
        sensitivities = []
        for i in range(len(base)):
            perturbed = base.copy()
            perturbed[i] += step
            out = float(np.ravel(predict_fn(perturbed.reshape(1, -1)))[0])
            sensitivities.append(abs(out - base_out) / step)
        total = sum(sensitivities)
        normalised = [s / total for s in sensitivities] if total > 0 else sensitivities
        return SensitivityReport(variable=list(feature_names), importance=normalised)
