"""Anomaly detection over per-run feature vectors.

Combines an Isolation Forest (multivariate structural anomalies), PCA reconstruction
error (correlated-signature anomalies), and per-feature statistical thresholds
(univariate anomalies) into a single anomaly probability/score per run.
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np
from sklearn.decomposition import PCA
from sklearn.ensemble import IsolationForest
from sklearn.preprocessing import StandardScaler


@dataclass
class AnomalyReport:
    run_ids: list[str]
    anomaly_score: np.ndarray  # higher = more anomalous, in [0, 1]
    is_anomalous: np.ndarray
    isolation_forest_score: np.ndarray
    pca_reconstruction_error: np.ndarray
    statistical_flags: np.ndarray

    def to_dict(self) -> dict:
        return {
            "n_runs": len(self.run_ids),
            "n_anomalous": int(self.is_anomalous.sum()),
            "anomaly_rate": float(self.is_anomalous.mean()) if len(self.run_ids) else 0.0,
        }


class AnomalyEngine:
    def __init__(self, contamination: float = 0.05, n_pca_components: int = 3,
                 z_threshold: float = 4.0, random_state: int = 42) -> None:
        self.contamination = contamination
        self.n_pca_components = n_pca_components
        self.z_threshold = z_threshold
        self.random_state = random_state

    def detect(self, run_ids: list[str], X: np.ndarray) -> AnomalyReport:
        n, d = X.shape
        scaler = StandardScaler()
        Xs = scaler.fit_transform(X)

        iso = IsolationForest(contamination=self.contamination, random_state=self.random_state)
        iso.fit(Xs)
        # decision_function: higher = more normal -> invert & rescale to [0, 1]
        raw_iso = -iso.decision_function(Xs)
        iso_score = self._minmax(raw_iso)

        n_components = max(1, min(self.n_pca_components, d, n - 1))
        pca = PCA(n_components=n_components, random_state=self.random_state)
        transformed = pca.fit_transform(Xs)
        reconstructed = pca.inverse_transform(transformed)
        recon_error = np.mean((Xs - reconstructed) ** 2, axis=1)
        recon_score = self._minmax(recon_error)

        z = np.abs(Xs)
        stat_flags = (z > self.z_threshold).any(axis=1)

        combined = 0.5 * iso_score + 0.4 * recon_score + 0.1 * stat_flags.astype(float)
        is_anomalous = (combined > np.quantile(combined, 1 - self.contamination)) | stat_flags

        return AnomalyReport(
            run_ids=list(run_ids), anomaly_score=combined, is_anomalous=is_anomalous,
            isolation_forest_score=iso_score, pca_reconstruction_error=recon_score,
            statistical_flags=stat_flags,
        )

    @staticmethod
    def _minmax(x: np.ndarray) -> np.ndarray:
        lo, hi = np.min(x), np.max(x)
        if hi - lo < 1e-12:
            return np.zeros_like(x)
        return (x - lo) / (hi - lo)
