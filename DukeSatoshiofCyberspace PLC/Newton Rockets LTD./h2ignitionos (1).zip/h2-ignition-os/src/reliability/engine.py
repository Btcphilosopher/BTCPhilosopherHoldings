"""Reliability engine: success rate, repeatability, failure clustering, and
reliability-distribution fits over a set of runs."""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np
from scipy import stats

from src.uncertainty.engine import UncertaintyEngine

RELIABILITY_DISTRIBUTIONS = {
    "weibull": stats.weibull_min,
    "log_normal": stats.lognorm,
    "exponential": stats.expon,
}


@dataclass
class ReliabilityReport:
    success_rate: float
    success_rate_ci: tuple[float, float]
    failure_probability: float
    repeatability_score: float
    run_to_run_variability: float
    mean_time_between_anomalies: float
    failure_clustering_index: float
    best_fit_distribution: str
    distribution_params: tuple

    def to_dict(self) -> dict:
        d = self.__dict__.copy()
        d["distribution_params"] = list(d["distribution_params"])
        return d


class ReliabilityEngine:
    def __init__(self, bootstrap_samples: int = 2000, confidence: float = 0.95, seed: int = 42) -> None:
        self.bootstrap_samples = bootstrap_samples
        self.confidence = confidence
        self.uncertainty = UncertaintyEngine()
        self.seed = seed

    def analyse(self, ignited: np.ndarray, delay_or_index: np.ndarray,
                anomaly_flags: np.ndarray | None = None) -> ReliabilityReport:
        ignited = np.asarray(ignited, dtype=bool)
        n = len(ignited)
        if n == 0:
            raise ValueError("Need at least one run to compute reliability")

        success_rate, lower, upper = self.uncertainty.bootstrap_ci(
            ignited.astype(float), np.mean, self.bootstrap_samples, self.confidence, self.seed
        )
        failure_probability = 1.0 - success_rate

        # Repeatability: 1 - coefficient of variation of successful-run delays
        # (or of the binary outcome, if no delay data is supplied).
        delays = np.asarray(delay_or_index, dtype=float)
        valid_delays = delays[ignited & np.isfinite(delays)]
        if len(valid_delays) > 1 and valid_delays.mean() > 0:
            cov = valid_delays.std() / valid_delays.mean()
            repeatability_score = float(np.clip(1 - cov, 0, 1))
            run_to_run_variability = float(cov)
        else:
            repeatability_score = float(np.clip(1 - ignited.astype(float).std(), 0, 1))
            run_to_run_variability = float(ignited.astype(float).std())

        anomaly_flags = np.zeros(n, dtype=bool) if anomaly_flags is None else np.asarray(anomaly_flags, dtype=bool)
        mtba = self._mean_time_between_anomalies(anomaly_flags)
        clustering = self._failure_clustering(~ignited)

        # Fit a reliability distribution over "cycles to failure" proxy: run index
        # gaps between successive failures (classic reliability-engineering framing).
        failure_gaps = self._event_gaps(~ignited)
        best_name, best_params = self._best_distribution_fit(failure_gaps)

        return ReliabilityReport(
            success_rate=success_rate, success_rate_ci=(lower, upper),
            failure_probability=failure_probability, repeatability_score=repeatability_score,
            run_to_run_variability=run_to_run_variability, mean_time_between_anomalies=mtba,
            failure_clustering_index=clustering, best_fit_distribution=best_name,
            distribution_params=best_params,
        )

    @staticmethod
    def _mean_time_between_anomalies(anomaly_flags: np.ndarray) -> float:
        idx = np.where(anomaly_flags)[0]
        if len(idx) < 2:
            return float("nan")
        return float(np.mean(np.diff(idx)))

    @staticmethod
    def _event_gaps(event_flags: np.ndarray) -> np.ndarray:
        idx = np.where(event_flags)[0]
        if len(idx) < 2:
            return np.array([1.0])
        return np.diff(idx).astype(float)

    @staticmethod
    def _failure_clustering(failure_flags: np.ndarray) -> float:
        """Ratio of observed run-length variance to that of a Bernoulli process with
        the same failure rate — >1 indicates clustering (bursty failures), ~1
        indicates a memoryless (Poisson-like) failure process."""
        p = failure_flags.mean()
        if p in (0.0, 1.0) or len(failure_flags) < 3:
            return float("nan")
        runs = np.diff(np.where(np.concatenate(([1], np.diff(failure_flags.astype(int)) != 0, [1])))[0])
        observed_var = np.var(runs) if len(runs) > 1 else 0.0
        expected_var = (1 - p) / p ** 2  # geometric-distribution variance for gaps
        return float(observed_var / expected_var) if expected_var else float("nan")

    @staticmethod
    def _best_distribution_fit(samples: np.ndarray) -> tuple[str, tuple]:
        samples = samples[samples > 0]
        if len(samples) < 3:
            return "insufficient_data", tuple()
        best_name, best_params, best_aic = "insufficient_data", tuple(), np.inf
        for name, dist in RELIABILITY_DISTRIBUTIONS.items():
            try:
                params = dist.fit(samples, floc=0)
                loglik = np.sum(dist.logpdf(samples, *params))
                aic = 2 * len(params) - 2 * loglik
                if aic < best_aic:
                    best_name, best_params, best_aic = name, params, aic
            except Exception:  # noqa: BLE001 - robust fitting, skip distributions that fail
                continue
        return best_name, best_params
