"""Canonical measurement schema shared by every data source the platform ingests."""
from __future__ import annotations

from datetime import datetime
from typing import Optional

import pandas as pd
from pydantic import BaseModel, Field

CANONICAL_COLUMNS: tuple[str, ...] = (
    "experiment_id",
    "timestamp",
    "run_id",
    "sensor_id",
    "variable",
    "value",
    "unit",
    "quality_flag",
    "uncertainty",
    "source",
)


class Measurement(BaseModel):
    """A single canonical measurement record.

    All physical-looking ``variable`` names in this platform are normalised /
    dimensionless quantities (e.g. ``normalised_temperature``), never real hardware
    setpoints.
    """

    experiment_id: str
    timestamp: datetime
    run_id: str
    sensor_id: str
    variable: str
    value: float
    unit: str = "normalised"
    quality_flag: str = "OK"
    uncertainty: float = Field(0.0, ge=0)
    source: str = "unknown"


class Dataset(BaseModel):
    """A named, versioned collection of canonical measurements."""

    name: str
    records: list[Measurement]

    def to_frame(self) -> pd.DataFrame:
        if not self.records:
            return pd.DataFrame(columns=CANONICAL_COLUMNS)
        df = pd.DataFrame([r.model_dump() for r in self.records])
        df["timestamp"] = pd.to_datetime(df["timestamp"], utc=True)
        return df[list(CANONICAL_COLUMNS)]

    @classmethod
    def from_frame(cls, name: str, df: pd.DataFrame) -> "Dataset":
        missing = set(CANONICAL_COLUMNS) - set(df.columns)
        if missing:
            raise ValueError(f"DataFrame missing canonical columns: {sorted(missing)}")
        records = [Measurement(**row) for row in df[list(CANONICAL_COLUMNS)].to_dict("records")]
        return cls(name=name, records=records)

    def __len__(self) -> int:
        return len(self.records)
