"""Data ingestion: load canonical-schema measurement data from common formats.

Supports CSV, JSON, and Parquet natively. HDF5 support is provided if ``h5py`` is
installed (optional dependency) so the platform can run without it.
"""
from __future__ import annotations

from pathlib import Path

import pandas as pd

from src.data.schema import CANONICAL_COLUMNS, Dataset
from src.engine.logging_setup import get_logger

logger = get_logger(__name__)

REQUIRED_COLUMNS: tuple[str, ...] = (
    "experiment_id",
    "timestamp",
    "run_id",
    "sensor_id",
    "variable",
    "value",
)


class UnsupportedFormatError(ValueError):
    pass


class DataLoader:
    """Loads experimental / sensor-log / simulation-output datasets into a
    :class:`~src.data.schema.Dataset` with the canonical schema."""

    def load(self, path: str | Path) -> Dataset:
        path = Path(path)
        suffix = path.suffix.lower()
        if suffix == ".csv":
            df = pd.read_csv(path)
        elif suffix == ".json":
            df = pd.read_json(path, orient="records")
        elif suffix == ".parquet":
            df = pd.read_parquet(path)
        elif suffix in (".h5", ".hdf5"):
            df = self._load_hdf5(path)
        else:
            raise UnsupportedFormatError(f"Unsupported data format: {suffix!r}")

        df = self._coerce_canonical(df)
        logger.info("dataset loaded", extra={"extra_fields": {"path": str(path), "rows": len(df)}})
        return Dataset.from_frame(name=path.stem, df=df)

    def load_dataframe(self, df: pd.DataFrame, name: str = "in_memory") -> Dataset:
        """Load an already-in-memory DataFrame (useful for synthetic data / tests)."""
        return Dataset.from_frame(name=name, df=self._coerce_canonical(df))

    @staticmethod
    def _load_hdf5(path: Path) -> pd.DataFrame:
        try:
            import h5py  # noqa: F401  (optional dependency)
        except ImportError as exc:  # pragma: no cover - optional dependency
            raise UnsupportedFormatError(
                "HDF5 support requires the optional 'h5py' dependency"
            ) from exc
        return pd.read_hdf(path, key="measurements")

    @staticmethod
    def _coerce_canonical(df: pd.DataFrame) -> pd.DataFrame:
        missing = set(REQUIRED_COLUMNS) - set(df.columns)
        if missing:
            raise ValueError(f"Input data missing required columns: {sorted(missing)}")
        df = df.copy()
        df["timestamp"] = pd.to_datetime(df["timestamp"], utc=True)
        for col, default in (
            ("unit", "normalised"),
            ("quality_flag", "OK"),
            ("uncertainty", 0.0),
            ("source", "unknown"),
        ):
            if col not in df.columns:
                df[col] = default
        return df[list(CANONICAL_COLUMNS)]
