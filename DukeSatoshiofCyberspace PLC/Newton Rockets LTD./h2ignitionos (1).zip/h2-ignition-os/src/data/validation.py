"""Data-quality validation for canonical-schema measurement DataFrames."""
from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np
import pandas as pd
from pydantic import BaseModel

from src.engine.config import DataConfig

# Values outside this normalised envelope are considered physically impossible for a
# normalised variable (all normalised quantities in this platform are defined on
# roughly [-0.5, 1.5], allowing modest overshoot beyond the nominal [0, 1] band).
IMPOSSIBLE_VALUE_BOUNDS = (-0.5, 1.5)


class QualityIssue(BaseModel):
    kind: str
    count: int
    detail: str


@dataclass
class DataQualityReport:
    n_rows: int
    issues: list[QualityIssue] = field(default_factory=list)
    outlier_mask: pd.Series | None = None
    clean_frame: pd.DataFrame | None = None

    @property
    def n_issues(self) -> int:
        return sum(i.count for i in self.issues)

    @property
    def is_clean(self) -> bool:
        return self.n_issues == 0

    def summary(self) -> dict:
        return {
            "n_rows": self.n_rows,
            "n_issue_types": len(self.issues),
            "n_flagged_records": self.n_issues,
            "issues": [i.model_dump() for i in self.issues],
        }


class DataValidator:
    """Runs canonical data-quality checks and produces a cleaned frame."""

    def __init__(self, config: DataConfig | None = None) -> None:
        self.config = config or DataConfig()

    def validate(self, df: pd.DataFrame) -> DataQualityReport:
        issues: list[QualityIssue] = []
        working = df.copy().sort_values(["sensor_id", "run_id", "timestamp"])
        n_rows = len(working)

        # 1. Missing values
        missing_mask = working["value"].isna()
        if missing_mask.any():
            issues.append(QualityIssue(kind="missing_value", count=int(missing_mask.sum()),
                                        detail="NaN in 'value' column"))

        # 2. Duplicate timestamps (per sensor/run/variable)
        dup_mask = working.duplicated(subset=["run_id", "sensor_id", "variable", "timestamp"], keep="first")
        if dup_mask.any():
            issues.append(QualityIssue(kind="duplicate_timestamp", count=int(dup_mask.sum()),
                                        detail="Repeated (run, sensor, variable, timestamp)"))

        # 3. Impossible values (outside physically-plausible normalised envelope)
        lo, hi = IMPOSSIBLE_VALUE_BOUNDS
        impossible_mask = (working["value"] < lo) | (working["value"] > hi)
        impossible_mask = impossible_mask.fillna(False)
        if impossible_mask.any():
            issues.append(QualityIssue(kind="impossible_value", count=int(impossible_mask.sum()),
                                        detail=f"value outside plausible envelope {IMPOSSIBLE_VALUE_BOUNDS}"))

        # 4. Statistical outliers (z-score per sensor/variable)
        outlier_mask = self._z_score_outliers(working)
        if outlier_mask.any():
            issues.append(QualityIssue(kind="statistical_outlier", count=int(outlier_mask.sum()),
                                        detail=f"|z| > {self.config.outlier_z_threshold}"))

        # 5. Sensor dropouts: gaps in a sensor's timestamps far exceeding its median cadence
        dropout_count = self._count_dropouts(working)
        if dropout_count:
            issues.append(QualityIssue(kind="sensor_dropout", count=dropout_count,
                                        detail="Gap > 5x median sampling interval"))

        # 6. Sampling-rate changes within a single run/sensor
        rate_change_count = self._count_sampling_rate_changes(working)
        if rate_change_count:
            issues.append(QualityIssue(kind="sampling_rate_change", count=rate_change_count,
                                        detail="Sampling interval changed materially mid-run"))

        # 7. Clock drift: non-monotonic timestamps within a run/sensor, evaluated in
        # original arrival order (not the timestamp-sorted working frame).
        drift_count = self._count_clock_drift(df)
        if drift_count:
            issues.append(QualityIssue(kind="clock_drift", count=drift_count,
                                        detail="Non-monotonic or negative-delta timestamps"))

        # 8. Corrupted records: explicit quality_flag
        corrupted_mask = working["quality_flag"].astype(str).str.upper().isin(["BAD", "CORRUPT", "CORRUPTED"])
        if corrupted_mask.any():
            issues.append(QualityIssue(kind="corrupted_record", count=int(corrupted_mask.sum()),
                                        detail="quality_flag marked BAD/CORRUPT"))

        drop_mask = missing_mask | dup_mask | impossible_mask | corrupted_mask
        clean = working.loc[~drop_mask].reset_index(drop=True)

        return DataQualityReport(
            n_rows=n_rows,
            issues=issues,
            outlier_mask=outlier_mask,
            clean_frame=clean,
        )

    def _z_score_outliers(self, df: pd.DataFrame) -> pd.Series:
        def z(group: pd.Series) -> pd.Series:
            std = group.std(ddof=0)
            if not std or np.isnan(std):
                return pd.Series(False, index=group.index)
            return ((group - group.mean()).abs() / std) > self.config.outlier_z_threshold

        return df.groupby(["sensor_id", "variable"])["value"].transform(z).fillna(False)

    @staticmethod
    def _count_dropouts(df: pd.DataFrame) -> int:
        count = 0
        for _, g in df.groupby(["run_id", "sensor_id"]):
            if len(g) < 3:
                continue
            dt = g["timestamp"].sort_values().diff().dt.total_seconds().dropna()
            median = dt.median()
            if median and median > 0:
                count += int((dt > 5 * median).sum())
        return count

    @staticmethod
    def _count_sampling_rate_changes(df: pd.DataFrame, rel_tol: float = 0.5) -> int:
        count = 0
        for _, g in df.groupby(["run_id", "sensor_id"]):
            if len(g) < 4:
                continue
            dt = g["timestamp"].sort_values().diff().dt.total_seconds().dropna().to_numpy()
            if len(dt) < 3:
                continue
            rolling_median = pd.Series(dt).rolling(3, min_periods=3).median().to_numpy()
            with np.errstate(invalid="ignore", divide="ignore"):
                rel_change = np.abs(dt - rolling_median) / np.where(rolling_median == 0, np.nan, rolling_median)
            count += int(np.nansum(rel_change > rel_tol))
        return count

    @staticmethod
    def _count_clock_drift(df: pd.DataFrame) -> int:
        count = 0
        for _, g in df.groupby(["run_id", "sensor_id"]):
            ts = g["timestamp"].to_numpy()
            deltas = np.diff(ts).astype("timedelta64[ns]").astype(np.int64)
            count += int((deltas < 0).sum())
        return count
