"""Ignition-probability model: P(ignition | experimental_state).

Trains and evaluates classifiers with group-aware cross-validation (grouped by
experiment_id to prevent leakage across runs of the same experiment), reports
calibrated probabilities with uncertainty, and standard classification metrics.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional

import numpy as np
import pandas as pd
from sklearn.calibration import CalibratedClassifierCV
from sklearn.ensemble import GradientBoostingClassifier, RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (
    average_precision_score,
    brier_score_loss,
    confusion_matrix,
    roc_auc_score,
)
from sklearn.model_selection import GroupKFold

from src.uncertainty.engine import PredictionWithUncertainty

MODEL_REGISTRY = {
    "logistic_regression": lambda: LogisticRegression(max_iter=1000),
    "random_forest": lambda: RandomForestClassifier(n_estimators=300, max_depth=6, random_state=0),
    "gradient_boosting": lambda: GradientBoostingClassifier(random_state=0),
}


@dataclass
class ClassificationMetrics:
    roc_auc: float
    pr_auc: float
    brier_score: float
    accuracy: float
    precision: float
    recall: float
    confusion: list[list[int]]

    def to_dict(self) -> dict:
        return {
            "roc_auc": self.roc_auc, "pr_auc": self.pr_auc, "brier_score": self.brier_score,
            "accuracy": self.accuracy, "precision": self.precision, "recall": self.recall,
            "confusion_matrix": self.confusion,
        }


@dataclass
class IgnitionProbabilityModel:
    model_name: str
    estimator: object
    feature_columns: list[str]
    metrics: ClassificationMetrics
    model_version: str
    ensemble_estimators: list = field(default_factory=list)
    oof_predictions: Optional[np.ndarray] = None
    oof_labels: Optional[np.ndarray] = None

    def predict(self, experimental_state: pd.DataFrame) -> PredictionWithUncertainty:
        X = experimental_state[self.feature_columns].to_numpy(dtype=float)
        p = self.estimator.predict_proba(X)[:, 1]

        if self.ensemble_estimators:
            ensemble_preds = np.stack([est.predict_proba(X)[:, 1] for est in self.ensemble_estimators])
            epistemic = ensemble_preds.std(axis=0)
        else:
            epistemic = np.zeros_like(p)

        aleatoric = np.sqrt(p * (1 - p) + 1e-9)  # Bernoulli variance proxy
        total = np.sqrt(epistemic ** 2 + (aleatoric / np.sqrt(len(X))) ** 2)
        lower = np.clip(p - 1.96 * total, 0, 1)
        upper = np.clip(p + 1.96 * total, 0, 1)
        return PredictionWithUncertainty(
            prediction=p, lower_bound=lower, upper_bound=upper,
            aleatoric_uncertainty=aleatoric, epistemic_uncertainty=epistemic,
            confidence=0.95,
        )


def train_ignition_probability_model(
    features: pd.DataFrame,
    feature_columns: list[str],
    label_column: str = "ignited",
    group_column: str = "experiment_id",
    model_name: str = "random_forest",
    n_folds: int = 5,
    calibrate: bool = True,
    model_version: str = "v1",
    random_state: int = 42,
) -> IgnitionProbabilityModel:
    """Trains a classifier with group-K-fold cross-validation (grouped by experiment
    to avoid train/test contamination across runs sharing the same experiment) and
    returns held-out (out-of-fold) metrics — never metrics computed on training data."""
    if model_name not in MODEL_REGISTRY:
        raise ValueError(f"Unknown model {model_name!r}; choose from {list(MODEL_REGISTRY)}")

    df = features.dropna(subset=feature_columns + [label_column]).reset_index(drop=True)
    X = df[feature_columns].to_numpy(dtype=float)
    y = df[label_column].to_numpy(dtype=int)
    groups = df[group_column].to_numpy() if group_column in df.columns else np.arange(len(df))
    if len(np.unique(groups)) < 2:
        # Degenerate grouping (e.g. a single experiment_id): each row (run) is
        # already an independent trial, so fall back to per-row groups, which
        # makes GroupKFold behave as an ordinary K-fold split.
        groups = np.arange(len(df))

    n_groups = len(np.unique(groups))
    n_splits = max(2, min(n_folds, n_groups))
    gkf = GroupKFold(n_splits=n_splits)

    oof_pred = np.full(len(y), np.nan)
    fold_estimators: list = []
    for train_idx, test_idx in gkf.split(X, y, groups):
        base = MODEL_REGISTRY[model_name]()
        base.fit(X[train_idx], y[train_idx])
        if calibrate and len(np.unique(y[train_idx])) > 1:
            try:
                clf = CalibratedClassifierCV(base, method="sigmoid", cv=3)
                clf.fit(X[train_idx], y[train_idx])
            except ValueError:
                clf = base
        else:
            clf = base
        oof_pred[test_idx] = clf.predict_proba(X[test_idx])[:, 1]
        fold_estimators.append(clf)

    valid = ~np.isnan(oof_pred)
    metrics = _compute_metrics(y[valid], oof_pred[valid])

    final_estimator = MODEL_REGISTRY[model_name]()
    final_estimator.fit(X, y)
    if calibrate and len(np.unique(y)) > 1:
        try:
            final_estimator = CalibratedClassifierCV(final_estimator, method="sigmoid", cv=3)
            final_estimator.fit(X, y)
        except ValueError:
            pass

    return IgnitionProbabilityModel(
        model_name=model_name, estimator=final_estimator, feature_columns=feature_columns,
        metrics=metrics, model_version=model_version, ensemble_estimators=fold_estimators,
        oof_predictions=oof_pred[valid], oof_labels=y[valid],
    )


def _compute_metrics(y_true: np.ndarray, y_prob: np.ndarray) -> ClassificationMetrics:
    y_pred = (y_prob >= 0.5).astype(int)
    tn, fp, fn, tp = confusion_matrix(y_true, y_pred, labels=[0, 1]).ravel()
    precision = tp / (tp + fp) if (tp + fp) else 0.0
    recall = tp / (tp + fn) if (tp + fn) else 0.0
    accuracy = (tp + tn) / len(y_true) if len(y_true) else 0.0
    roc_auc = roc_auc_score(y_true, y_prob) if len(np.unique(y_true)) > 1 else float("nan")
    pr_auc = average_precision_score(y_true, y_prob) if len(np.unique(y_true)) > 1 else float("nan")
    brier = brier_score_loss(y_true, y_prob)
    return ClassificationMetrics(
        roc_auc=float(roc_auc), pr_auc=float(pr_auc), brier_score=float(brier),
        accuracy=float(accuracy), precision=float(precision), recall=float(recall),
        confusion=[[int(tn), int(fp)], [int(fn), int(tp)]],
    )
