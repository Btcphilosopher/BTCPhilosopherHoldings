"""Calibration diagnostics for probabilistic classifiers."""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np
from sklearn.calibration import calibration_curve


@dataclass
class CalibrationReport:
    bin_confidence: list[float]
    bin_accuracy: list[float]
    expected_calibration_error: float

    def to_dict(self) -> dict:
        return {
            "bin_confidence": self.bin_confidence,
            "bin_accuracy": self.bin_accuracy,
            "expected_calibration_error": self.expected_calibration_error,
        }


def assess_calibration(y_true: np.ndarray, y_prob: np.ndarray, n_bins: int = 10) -> CalibrationReport:
    y_true = np.asarray(y_true)
    y_prob = np.asarray(y_prob)
    if len(np.unique(y_true)) < 2:
        return CalibrationReport([], [], float("nan"))

    frac_pos, mean_pred = calibration_curve(y_true, y_prob, n_bins=n_bins, strategy="quantile")
    bin_edges = np.linspace(0, 1, n_bins + 1)
    bin_idx = np.clip(np.digitize(y_prob, bin_edges) - 1, 0, n_bins - 1)
    weights = np.array([(bin_idx == b).sum() for b in range(len(mean_pred))], dtype=float)
    weights = weights[: len(frac_pos)]
    ece = float(np.sum(weights / weights.sum() * np.abs(frac_pos - mean_pred))) if weights.sum() else float("nan")

    return CalibrationReport(
        bin_confidence=[float(x) for x in mean_pred],
        bin_accuracy=[float(x) for x in frac_pos],
        expected_calibration_error=ece,
    )
