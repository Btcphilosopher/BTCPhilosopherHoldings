"""Model comparison / ranking.

Ranks competing models on prediction quality, calibration, robustness, and
uncertainty jointly — never on accuracy alone (project requirement #21).
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from src.models.ignition_probability import IgnitionProbabilityModel


@dataclass
class ModelScore:
    model_name: str
    quality_score: float
    calibration_score: float
    robustness_score: float
    uncertainty_score: float
    computational_cost_s: float
    composite_score: float

    def to_dict(self) -> dict:
        return self.__dict__.copy()


class ModelComparison:
    """Compares candidate :class:`IgnitionProbabilityModel` instances using a
    weighted composite of quality, calibration, robustness, and uncertainty —
    computational cost is reported but only lightly weighted."""

    WEIGHTS = {"quality": 0.35, "calibration": 0.25, "robustness": 0.20, "uncertainty": 0.15, "cost": 0.05}

    def rank(self, models: dict[str, IgnitionProbabilityModel],
              ece_by_model: dict[str, float] | None = None,
              cost_by_model: dict[str, float] | None = None) -> list[ModelScore]:
        ece_by_model = ece_by_model or {}
        cost_by_model = cost_by_model or {}
        scores = []
        for name, model in models.items():
            quality = 0.5 * (model.metrics.roc_auc if not np.isnan(model.metrics.roc_auc) else 0.5) \
                + 0.5 * (model.metrics.pr_auc if not np.isnan(model.metrics.pr_auc) else 0.5)
            ece = ece_by_model.get(name, model.metrics.brier_score)
            calibration = 1.0 - min(ece, 1.0)
            robustness = 1.0 - min(model.metrics.brier_score, 1.0)
            uncertainty_score = 1.0 - min(model.metrics.brier_score, 1.0)  # proxy: lower Brier -> tighter, honest uncertainty
            cost = cost_by_model.get(name, 0.0)
            cost_score = 1.0 / (1.0 + cost)

            composite = (
                self.WEIGHTS["quality"] * quality
                + self.WEIGHTS["calibration"] * calibration
                + self.WEIGHTS["robustness"] * robustness
                + self.WEIGHTS["uncertainty"] * uncertainty_score
                + self.WEIGHTS["cost"] * cost_score
            )
            scores.append(ModelScore(
                model_name=name, quality_score=float(quality), calibration_score=float(calibration),
                robustness_score=float(robustness), uncertainty_score=float(uncertainty_score),
                computational_cost_s=float(cost), composite_score=float(composite),
            ))
        return sorted(scores, key=lambda s: s.composite_score, reverse=True)
