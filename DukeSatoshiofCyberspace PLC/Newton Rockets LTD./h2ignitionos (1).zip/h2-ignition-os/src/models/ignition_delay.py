"""Ignition-delay statistical model.

Represents ignition delay (``t_ignition``) as a random variable, not a single
deterministic number, and fits several standard candidate distributions.
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np
from scipy import stats


@dataclass
class DelayDistributionFit:
    distribution: str
    params: tuple
    aic: float
    mean: float
    median: float
    std: float
    percentiles: dict[str, float]
    confidence_interval: tuple[float, float]

    def to_dict(self) -> dict:
        return {
            "distribution": self.distribution, "aic": self.aic,
            "mean": self.mean, "median": self.median, "std": self.std,
            "percentiles": self.percentiles, "confidence_interval": self.confidence_interval,
        }


CANDIDATE_DISTRIBUTIONS = {
    "gaussian": stats.norm,
    "log_normal": stats.lognorm,
    "weibull": stats.weibull_min,
}


class IgnitionDelayModel:
    """Fits ignition-delay distributions to observed (or synthetic) delay samples and
    reports summary statistics with confidence intervals — never a bare point
    estimate."""

    def fit(self, delay_samples: np.ndarray, confidence: float = 0.95) -> dict[str, DelayDistributionFit]:
        samples = np.asarray(delay_samples, dtype=float)
        samples = samples[np.isfinite(samples) & (samples > 0)]
        if len(samples) < 5:
            raise ValueError("Need at least 5 positive delay samples to fit distributions")

        fits: dict[str, DelayDistributionFit] = {}
        for name, dist in CANDIDATE_DISTRIBUTIONS.items():
            params = dist.fit(samples, floc=0) if name != "gaussian" else dist.fit(samples)
            loglik = np.sum(dist.logpdf(samples, *params))
            aic = 2 * len(params) - 2 * loglik
            fits[name] = self._summarise(name, params, dist, samples, aic, confidence)

        fits["empirical"] = self._empirical(samples, confidence)
        fits["kernel_density"] = self._kde(samples, confidence)
        return fits

    def best_fit(self, delay_samples: np.ndarray, confidence: float = 0.95) -> DelayDistributionFit:
        fits = self.fit(delay_samples, confidence)
        parametric = {k: v for k, v in fits.items() if k not in ("empirical", "kernel_density")}
        return min(parametric.values(), key=lambda f: f.aic)

    @staticmethod
    def _summarise(name: str, params: tuple, dist, samples: np.ndarray, aic: float,
                    confidence: float) -> DelayDistributionFit:
        alpha = 1 - confidence
        mean = float(dist.mean(*params))
        median = float(dist.median(*params))
        std = float(dist.std(*params))
        percentiles = {f"p{p}": float(dist.ppf(p / 100, *params)) for p in (5, 25, 50, 75, 90, 95)}
        ci = (float(dist.ppf(alpha / 2, *params)), float(dist.ppf(1 - alpha / 2, *params)))
        return DelayDistributionFit(name, params, float(aic), mean, median, std, percentiles, ci)

    @staticmethod
    def _empirical(samples: np.ndarray, confidence: float) -> DelayDistributionFit:
        alpha = 1 - confidence
        percentiles = {f"p{p}": float(np.percentile(samples, p)) for p in (5, 25, 50, 75, 90, 95)}
        ci = (float(np.percentile(samples, 100 * alpha / 2)), float(np.percentile(samples, 100 * (1 - alpha / 2))))
        return DelayDistributionFit(
            "empirical", tuple(), float("nan"),
            float(np.mean(samples)), float(np.median(samples)), float(np.std(samples)),
            percentiles, ci,
        )

    @staticmethod
    def _kde(samples: np.ndarray, confidence: float, n_grid: int = 2000) -> DelayDistributionFit:
        kde = stats.gaussian_kde(samples)
        grid = np.linspace(samples.min(), samples.max(), n_grid)
        pdf = kde(grid)
        cdf = np.cumsum(pdf) / np.sum(pdf)
        alpha = 1 - confidence

        def ppf(q: float) -> float:
            idx = min(np.searchsorted(cdf, q), len(grid) - 1)
            return float(grid[idx])

        percentiles = {f"p{p}": ppf(p / 100) for p in (5, 25, 50, 75, 90, 95)}
        ci = (ppf(alpha / 2), ppf(1 - alpha / 2))
        return DelayDistributionFit(
            "kernel_density", tuple(), float("nan"),
            float(np.mean(samples)), percentiles["p50"], float(np.std(samples)),
            percentiles, ci,
        )
