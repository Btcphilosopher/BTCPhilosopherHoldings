"""H2-IGNITION.OS — Hydrogen Ignition Research, Digital Twin & Optimisation Platform.

This package is a research / simulation / experimental-data-analysis platform. It
contains no hardware assembly, actuator-control, or ignition-firing instructions. See
``docs/SAFETY.md`` for the safety boundary.
"""

__version__ = "0.1.0"
