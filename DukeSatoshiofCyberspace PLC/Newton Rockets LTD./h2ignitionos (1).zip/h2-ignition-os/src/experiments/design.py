"""Experimental-design engine: recommends the *most informative next region to
experiment in* — never an actuator command. Uses Gaussian-Process predictive
variance (active learning / uncertainty reduction) over a space-filling candidate
pool."""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np
from scipy.stats import qmc
from sklearn.gaussian_process import GaussianProcessRegressor
from sklearn.gaussian_process.kernels import RBF, ConstantKernel, WhiteKernel


@dataclass
class ExperimentRecommendation:
    normalised_design_variables: dict[str, float]
    expected_information_gain: float
    predictive_std: float
    rationale: str

    def to_dict(self) -> dict:
        return self.__dict__.copy()


class ExperimentalDesignEngine:
    """Bayesian-experimental-design-style active learning: fits a GP surrogate to
    observed (X, y) pairs and recommends the *region* (not a control command) with
    the highest predictive uncertainty, i.e. the most informative next experiment."""

    def __init__(self, random_state: int = 42) -> None:
        self.random_state = random_state

    def recommend_next_region(self, X_observed: np.ndarray, y_observed: np.ndarray,
                               variable_bounds: dict[str, tuple[float, float]],
                               n_candidates: int = 500, top_k: int = 5) -> list[ExperimentRecommendation]:
        names = list(variable_bounds.keys())
        kernel = ConstantKernel(1.0) * RBF(length_scale=1.0) + WhiteKernel(1e-3)
        gp = GaussianProcessRegressor(kernel=kernel, normalize_y=True, random_state=self.random_state)
        gp.fit(X_observed, y_observed)

        sampler = qmc.LatinHypercube(d=len(names), seed=self.random_state)
        unit_candidates = sampler.random(n_candidates)
        lows = np.array([variable_bounds[n][0] for n in names])
        highs = np.array([variable_bounds[n][1] for n in names])
        candidates = qmc.scale(unit_candidates, lows, highs)

        _, std = gp.predict(candidates, return_std=True)
        # expected information gain proxy: differential-entropy reduction of a
        # Gaussian, i.e. monotonic in predictive std.
        info_gain = 0.5 * np.log(1 + std ** 2 / (np.var(y_observed) + 1e-9))

        order = np.argsort(-info_gain)[:top_k]
        recommendations = []
        for idx in order:
            point = dict(zip(names, candidates[idx]))
            recommendations.append(ExperimentRecommendation(
                normalised_design_variables=point,
                expected_information_gain=float(info_gain[idx]),
                predictive_std=float(std[idx]),
                rationale="Highest GP predictive-variance region among a space-filling "
                          "(Latin-hypercube) candidate pool — recommended to reduce model "
                          "epistemic uncertainty, not a control instruction.",
            ))
        return recommendations
