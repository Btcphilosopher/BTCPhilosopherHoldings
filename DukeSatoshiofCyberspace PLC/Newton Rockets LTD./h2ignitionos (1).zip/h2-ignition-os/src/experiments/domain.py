"""Domain objects for the experiment database: Experiment, Run, Sensor, Measurement,
Prediction, Model, Optimisation, Anomaly, Report — with the relationships between
them needed for full traceability (see project requirement #23-24)."""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Optional


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


@dataclass
class Experiment:
    experiment_id: str
    name: str
    description: str = ""
    created_at: str = field(default_factory=_now)
    source_label: str = "unknown"  # e.g. "SYNTHETIC SIMULATION" or a real dataset name


@dataclass
class Run:
    run_id: str
    experiment_id: str
    started_at: str
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class SensorRecord:
    sensor_id: str
    sensor_type: str
    variable: str


@dataclass
class ModelRecord:
    model_id: str
    model_name: str
    model_version: str
    dataset_version: str
    parameters: dict[str, Any]
    random_seed: int
    software_version: str
    trained_at: str = field(default_factory=_now)


@dataclass
class PredictionRecord:
    prediction_id: str
    model_id: str
    run_id: str
    target: str
    value: float
    lower_bound: float
    upper_bound: float
    confidence: float
    created_at: str = field(default_factory=_now)


@dataclass
class OptimisationRecord:
    optimisation_id: str
    experiment_id: str
    objective_summary: dict[str, Any]
    n_pareto_optimal: int
    created_at: str = field(default_factory=_now)


@dataclass
class AnomalyRecord:
    anomaly_id: str
    run_id: str
    anomaly_score: float
    is_anomalous: bool
    created_at: str = field(default_factory=_now)


@dataclass
class ReportRecord:
    report_id: str
    experiment_id: str
    summary: str
    created_at: str = field(default_factory=_now)
