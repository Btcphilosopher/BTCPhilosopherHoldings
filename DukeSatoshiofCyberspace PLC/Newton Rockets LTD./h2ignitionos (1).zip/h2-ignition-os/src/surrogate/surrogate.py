"""Surrogate model: a fast, cheap approximation of the (comparatively expensive)
physics-informed simulator / full ML pipeline, for use inside the optimisation and
experimental-design inner loops."""
from __future__ import annotations

from dataclasses import dataclass
from typing import Literal

import numpy as np
from sklearn.ensemble import GradientBoostingRegressor, RandomForestRegressor
from sklearn.gaussian_process import GaussianProcessRegressor
from sklearn.gaussian_process.kernels import RBF, ConstantKernel, WhiteKernel
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import PolynomialFeatures
from sklearn.linear_model import LinearRegression
from sklearn.pipeline import make_pipeline

SurrogateKind = Literal["gaussian_process", "random_forest", "gradient_boosting", "polynomial"]


@dataclass
class SurrogateValidationReport:
    mae: float
    rmse: float
    r2: float
    n_holdout: int

    def to_dict(self) -> dict:
        return self.__dict__.copy()


class SurrogateModel:
    """Fits a fast surrogate for a scalar physics/simulator output as a function of
    normalised design variables, and validates it against a held-out split of the
    (physics-simulator-generated) training dataset."""

    def __init__(self, kind: SurrogateKind = "gaussian_process", random_state: int = 42) -> None:
        self.kind = kind
        self.random_state = random_state
        self._model = None
        self.validation: SurrogateValidationReport | None = None
        self.feature_columns: list[str] = []

    def _build(self):
        if self.kind == "gaussian_process":
            kernel = ConstantKernel(1.0) * RBF(length_scale=1.0) + WhiteKernel(1e-3)
            return GaussianProcessRegressor(kernel=kernel, normalize_y=True, random_state=self.random_state)
        if self.kind == "random_forest":
            return RandomForestRegressor(n_estimators=300, max_depth=8, random_state=self.random_state)
        if self.kind == "gradient_boosting":
            return GradientBoostingRegressor(random_state=self.random_state)
        if self.kind == "polynomial":
            return make_pipeline(PolynomialFeatures(degree=2), LinearRegression())
        raise ValueError(f"Unknown surrogate kind {self.kind!r}")

    def fit(self, X: np.ndarray, y: np.ndarray, feature_columns: list[str], test_size: float = 0.2) -> "SurrogateModel":
        self.feature_columns = feature_columns
        X_train, X_test, y_train, y_test = train_test_split(
            X, y, test_size=test_size, random_state=self.random_state
        )
        self._model = self._build()
        self._model.fit(X_train, y_train)
        y_pred = self._model.predict(X_test)
        self.validation = SurrogateValidationReport(
            mae=float(mean_absolute_error(y_test, y_pred)),
            rmse=float(np.sqrt(mean_squared_error(y_test, y_pred))),
            r2=float(r2_score(y_test, y_pred)) if len(np.unique(y_test)) > 1 else float("nan"),
            n_holdout=len(y_test),
        )
        # refit on full data for downstream (fast prediction) use
        self._model = self._build()
        self._model.fit(X, y)
        return self

    def predict(self, X: np.ndarray, return_std: bool = False):
        if self._model is None:
            raise RuntimeError("SurrogateModel must be fit() before predict()")
        if return_std and self.kind == "gaussian_process":
            return self._model.predict(X, return_std=True)
        pred = self._model.predict(X)
        if return_std:
            return pred, np.zeros_like(pred)
        return pred

    def predict_with_std(self, X: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
        """Prediction + an epistemic-uncertainty proxy: GP posterior std for a
        Gaussian-process surrogate, or cross-tree ensemble spread for a
        random-forest surrogate. Falls back to zero std for surrogate kinds with
        no native ensemble/posterior (gradient boosting, polynomial)."""
        if self._model is None:
            raise RuntimeError("SurrogateModel must be fit() before predict_with_std()")
        if self.kind == "gaussian_process":
            mean, std = self._model.predict(X, return_std=True)
            return mean, std
        if self.kind == "random_forest":
            tree_preds = np.stack([t.predict(X) for t in self._model.estimators_])
            return tree_preds.mean(axis=0), tree_preds.std(axis=0)
        pred = self._model.predict(X)
        return pred, np.zeros_like(pred)
