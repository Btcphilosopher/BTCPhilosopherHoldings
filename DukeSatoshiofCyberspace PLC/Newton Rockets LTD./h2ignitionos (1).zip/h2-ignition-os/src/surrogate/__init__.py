from src.surrogate.surrogate import SurrogateModel, SurrogateValidationReport

__all__ = ["SurrogateModel", "SurrogateValidationReport"]
