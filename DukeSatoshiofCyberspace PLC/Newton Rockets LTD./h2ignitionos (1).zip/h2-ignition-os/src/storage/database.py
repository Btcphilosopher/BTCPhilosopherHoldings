"""SQLite-backed experiment database implementing the Experiment / Run / Sensor /
Measurement / Prediction / Model / Optimisation / Anomaly / Report schema, with full
traceability from every prediction back to its dataset, model version, parameters,
timestamp, and software version.
"""
from __future__ import annotations

import json
import sqlite3
from pathlib import Path

from src.experiments.domain import (
    AnomalyRecord,
    Experiment,
    ModelRecord,
    OptimisationRecord,
    PredictionRecord,
    ReportRecord,
    Run,
    SensorRecord,
)

SCHEMA = """
CREATE TABLE IF NOT EXISTS experiments (
    experiment_id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    description TEXT,
    created_at TEXT NOT NULL,
    source_label TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS runs (
    run_id TEXT PRIMARY KEY,
    experiment_id TEXT NOT NULL REFERENCES experiments(experiment_id),
    started_at TEXT NOT NULL,
    metadata TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS sensors (
    sensor_id TEXT PRIMARY KEY,
    sensor_type TEXT NOT NULL,
    variable TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS measurements (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    experiment_id TEXT NOT NULL,
    run_id TEXT NOT NULL REFERENCES runs(run_id),
    sensor_id TEXT NOT NULL,
    variable TEXT NOT NULL,
    timestamp TEXT NOT NULL,
    value REAL NOT NULL,
    unit TEXT,
    quality_flag TEXT,
    uncertainty REAL,
    source TEXT
);

CREATE TABLE IF NOT EXISTS models (
    model_id TEXT PRIMARY KEY,
    model_name TEXT NOT NULL,
    model_version TEXT NOT NULL,
    dataset_version TEXT NOT NULL,
    parameters TEXT NOT NULL,
    random_seed INTEGER NOT NULL,
    software_version TEXT NOT NULL,
    trained_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS predictions (
    prediction_id TEXT PRIMARY KEY,
    model_id TEXT NOT NULL REFERENCES models(model_id),
    run_id TEXT NOT NULL REFERENCES runs(run_id),
    target TEXT NOT NULL,
    value REAL NOT NULL,
    lower_bound REAL NOT NULL,
    upper_bound REAL NOT NULL,
    confidence REAL NOT NULL,
    created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS optimisations (
    optimisation_id TEXT PRIMARY KEY,
    experiment_id TEXT NOT NULL REFERENCES experiments(experiment_id),
    objective_summary TEXT NOT NULL,
    n_pareto_optimal INTEGER NOT NULL,
    created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS anomalies (
    anomaly_id TEXT PRIMARY KEY,
    run_id TEXT NOT NULL REFERENCES runs(run_id),
    anomaly_score REAL NOT NULL,
    is_anomalous INTEGER NOT NULL,
    created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS reports (
    report_id TEXT PRIMARY KEY,
    experiment_id TEXT NOT NULL REFERENCES experiments(experiment_id),
    summary TEXT NOT NULL,
    created_at TEXT NOT NULL
);
"""


class ExperimentDatabase:
    """A thin, dependency-free (stdlib ``sqlite3``) persistence layer for the
    platform's experiment/run/model/prediction schema."""

    def __init__(self, path: str | Path = ":memory:") -> None:
        self.path = str(path)
        if self.path != ":memory:":
            Path(self.path).parent.mkdir(parents=True, exist_ok=True)
        self.conn = sqlite3.connect(self.path)
        self.conn.execute("PRAGMA foreign_keys = ON;")
        self.conn.executescript(SCHEMA)
        self.conn.commit()

    def close(self) -> None:
        self.conn.close()

    # --- writers -----------------------------------------------------------------
    def insert_experiment(self, e: Experiment) -> None:
        self.conn.execute(
            "INSERT OR REPLACE INTO experiments VALUES (?, ?, ?, ?, ?)",
            (e.experiment_id, e.name, e.description, e.created_at, e.source_label),
        )
        self.conn.commit()

    def insert_run(self, r: Run) -> None:
        self.conn.execute(
            "INSERT OR REPLACE INTO runs VALUES (?, ?, ?, ?)",
            (r.run_id, r.experiment_id, r.started_at, json.dumps(r.metadata)),
        )
        self.conn.commit()

    def insert_sensor(self, s: SensorRecord) -> None:
        self.conn.execute(
            "INSERT OR REPLACE INTO sensors VALUES (?, ?, ?)",
            (s.sensor_id, s.sensor_type, s.variable),
        )
        self.conn.commit()

    def insert_measurements(self, df) -> None:
        """Bulk-insert a canonical-schema measurements DataFrame."""
        records = df.to_dict("records")
        self.conn.executemany(
            "INSERT INTO measurements "
            "(experiment_id, run_id, sensor_id, variable, timestamp, value, unit, quality_flag, uncertainty, source) "
            "VALUES (:experiment_id, :run_id, :sensor_id, :variable, :timestamp, :value, :unit, :quality_flag, :uncertainty, :source)",
            [{**r, "timestamp": str(r["timestamp"])} for r in records],
        )
        self.conn.commit()

    def insert_model(self, m: ModelRecord) -> None:
        self.conn.execute(
            "INSERT OR REPLACE INTO models VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
            (m.model_id, m.model_name, m.model_version, m.dataset_version,
             json.dumps(m.parameters), m.random_seed, m.software_version, m.trained_at),
        )
        self.conn.commit()

    def insert_prediction(self, p: PredictionRecord) -> None:
        self.conn.execute(
            "INSERT OR REPLACE INTO predictions VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
            (p.prediction_id, p.model_id, p.run_id, p.target, p.value,
             p.lower_bound, p.upper_bound, p.confidence, p.created_at),
        )
        self.conn.commit()

    def insert_optimisation(self, o: OptimisationRecord) -> None:
        self.conn.execute(
            "INSERT OR REPLACE INTO optimisations VALUES (?, ?, ?, ?, ?)",
            (o.optimisation_id, o.experiment_id, json.dumps(o.objective_summary),
             o.n_pareto_optimal, o.created_at),
        )
        self.conn.commit()

    def insert_anomaly(self, a: AnomalyRecord) -> None:
        self.conn.execute(
            "INSERT OR REPLACE INTO anomalies VALUES (?, ?, ?, ?, ?)",
            (a.anomaly_id, a.run_id, a.anomaly_score, int(a.is_anomalous), a.created_at),
        )
        self.conn.commit()

    def insert_report(self, r: ReportRecord) -> None:
        self.conn.execute(
            "INSERT OR REPLACE INTO reports VALUES (?, ?, ?, ?)",
            (r.report_id, r.experiment_id, r.summary, r.created_at),
        )
        self.conn.commit()

    # --- readers / traceability ----------------------------------------------------
    def prediction_provenance(self, prediction_id: str) -> dict:
        """Traces a prediction back to its model (and thus dataset_version,
        parameters, random_seed, software_version, timestamp)."""
        cur = self.conn.execute(
            "SELECT p.*, m.model_name, m.model_version, m.dataset_version, m.parameters, "
            "m.random_seed, m.software_version, m.trained_at "
            "FROM predictions p JOIN models m ON p.model_id = m.model_id "
            "WHERE p.prediction_id = ?",
            (prediction_id,),
        )
        row = cur.fetchone()
        if row is None:
            return {}
        cols = [c[0] for c in cur.description]
        return dict(zip(cols, row))

    def count(self, table: str) -> int:
        cur = self.conn.execute(f"SELECT COUNT(*) FROM {table}")
        return int(cur.fetchone()[0])

    def integrity_check(self) -> list[str]:
        """Runs SQLite's built-in foreign-key + integrity checks."""
        issues = []
        for row in self.conn.execute("PRAGMA foreign_key_check;"):
            issues.append(str(row))
        result = self.conn.execute("PRAGMA integrity_check;").fetchone()
        if result and result[0] != "ok":
            issues.append(f"integrity_check: {result[0]}")
        return issues
