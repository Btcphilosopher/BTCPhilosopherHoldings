"""Feature engineering: turns cleaned canonical measurements + detected events into a
per-run feature matrix for the ML / surrogate models."""
from __future__ import annotations

import numpy as np
import pandas as pd

from src.events.ignition_detector import IgnitionEventResult
from src.events.timeseries import TimeSeriesEngine

STAT_FUNCS: dict[str, "callable"] = {
    "mean": np.nanmean,
    "std": np.nanstd,
    "min": np.nanmin,
    "max": np.nanmax,
    "p90": lambda x: np.nanpercentile(x, 90),
}


class FeatureEngine:
    """Builds a wide, per-run feature table from long-format canonical measurements,
    run-level metadata, and (optionally) ignition-event-detector output."""

    def __init__(self) -> None:
        self.tse = TimeSeriesEngine()

    def extract(self, clean_df: pd.DataFrame, run_metadata: pd.DataFrame | None = None,
                event_results: dict[str, IgnitionEventResult] | None = None) -> pd.DataFrame:
        rows = []
        for run_id, g in clean_df.groupby("run_id"):
            row: dict = {"run_id": run_id, "experiment_id": g["experiment_id"].iloc[0]}
            row.update(self._per_channel_stats(g))
            row.update(self._transient_severity(g))
            row.update(self._cross_sensor_features(g))
            if event_results and run_id in event_results:
                ev = event_results[run_id]
                row["event_confidence"] = ev.confidence
                row["event_time"] = ev.event_time if ev.event_time is not None else np.nan
                row["signal_quality"] = ev.signal_quality
                row["event_label"] = ev.label.value
            rows.append(row)

        features = pd.DataFrame(rows)
        if run_metadata is not None:
            features = features.merge(run_metadata, on=["run_id", "experiment_id"], how="left")
        return features

    @staticmethod
    def _per_channel_stats(g: pd.DataFrame) -> dict:
        out: dict = {}
        for variable, gv in g.groupby("variable"):
            values = gv["value"].to_numpy(dtype=float)
            for stat_name, func in STAT_FUNCS.items():
                out[f"{variable}__{stat_name}"] = float(func(values)) if len(values) else np.nan
        return out

    @staticmethod
    def _transient_severity(g: pd.DataFrame) -> dict:
        """A simple transient-severity proxy per run: the largest absolute first
        difference observed on any channel (captures pressure/thermal 'spikiness')."""
        severities = []
        for _, gv in g.groupby(["sensor_id"]):
            values = gv.sort_values("timestamp")["value"].to_numpy(dtype=float)
            if len(values) > 1:
                severities.append(np.nanmax(np.abs(np.diff(values))))
        return {"transient_severity": float(np.nanmax(severities)) if severities else 0.0}

    def _cross_sensor_features(self, g: pd.DataFrame) -> dict:
        pivot = g.pivot_table(index="timestamp", columns="variable", values="value", aggfunc="mean")
        pivot = pivot.sort_index().interpolate().ffill().bfill()
        out: dict = {}
        cols = list(pivot.columns)
        if "normalised_optical_intensity" in cols and "normalised_pressure" in cols and len(pivot) > 3:
            lag = self.tse.lag_detection(
                pivot["normalised_optical_intensity"].to_numpy(),
                pivot["normalised_pressure"].to_numpy(),
            )
            out["optical_pressure_lag"] = float(lag)
        return out
