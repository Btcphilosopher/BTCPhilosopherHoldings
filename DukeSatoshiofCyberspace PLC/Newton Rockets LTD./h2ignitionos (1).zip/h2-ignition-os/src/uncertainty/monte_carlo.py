"""Monte Carlo engine.

Generates synthetic variations of an experimental state (sensor noise, model-
parameter jitter, timing jitter) and propagates them through a supplied prediction
function to build ignition-probability / delay / failure distributions.

Every result produced here is synthetic by construction and MUST be labelled
``SYNTHETIC SIMULATION`` wherever it is surfaced (report engine, API responses).
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Callable

import numpy as np

SYNTHETIC_LABEL = "SYNTHETIC SIMULATION"


@dataclass
class MonteCarloResult:
    label: str
    samples: np.ndarray
    mean: float
    std: float
    percentiles: dict[str, float]
    confidence_interval: tuple[float, float]

    def to_dict(self) -> dict:
        return {
            "label": self.label,
            "n_samples": int(len(self.samples)),
            "mean": self.mean,
            "std": self.std,
            "percentiles": self.percentiles,
            "confidence_interval": self.confidence_interval,
        }


class MonteCarloEngine:
    def __init__(self, seed: int = 42) -> None:
        self.rng = np.random.default_rng(seed)

    def perturb_state(self, base_state: dict[str, float], noise_std: dict[str, float],
                       n_samples: int = 1000) -> "np.ndarray":
        """Draws ``n_samples`` perturbed copies of ``base_state`` under independent
        Gaussian noise per variable (sensor noise / experimental-condition jitter)."""
        keys = list(base_state.keys())
        means = np.array([base_state[k] for k in keys])
        stds = np.array([noise_std.get(k, 0.0) for k in keys])
        draws = self.rng.normal(loc=means, scale=stds, size=(n_samples, len(keys)))
        return draws, keys

    def propagate(self, base_state: dict[str, float], noise_std: dict[str, float],
                   predict_fn: Callable[[np.ndarray], np.ndarray],
                   n_samples: int = 1000, confidence: float = 0.95) -> MonteCarloResult:
        draws, _ = self.perturb_state(base_state, noise_std, n_samples)
        outputs = np.asarray(predict_fn(draws))
        return self._summarise(outputs, confidence)

    def failure_probability(self, ignition_prob_samples: np.ndarray) -> MonteCarloResult:
        """Monte Carlo estimate of failure probability from an ensemble of
        per-sample ignition-probability draws (treated as independent Bernoulli
        trials)."""
        rng_draws = self.rng.uniform(0, 1, size=ignition_prob_samples.shape)
        failures = (rng_draws >= ignition_prob_samples).astype(float)
        return self._summarise(failures, confidence=0.95)

    def _summarise(self, samples: np.ndarray, confidence: float) -> MonteCarloResult:
        samples = np.asarray(samples).ravel()
        alpha = 1 - confidence
        lower, upper = np.percentile(samples, [100 * alpha / 2, 100 * (1 - alpha / 2)])
        percentiles = {f"p{p}": float(np.percentile(samples, p)) for p in (5, 25, 50, 75, 95)}
        return MonteCarloResult(
            label=SYNTHETIC_LABEL, samples=samples,
            mean=float(np.mean(samples)), std=float(np.std(samples)),
            percentiles=percentiles, confidence_interval=(float(lower), float(upper)),
        )
