"""Uncertainty quantification.

Every prediction produced anywhere in this platform should be wrapped in a
:class:`PredictionWithUncertainty` — a naked point prediction is never returned when
uncertainty can be quantified (see project requirement #18).
"""
from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np


@dataclass
class PredictionWithUncertainty:
    """A prediction (scalar or vector) with decomposed uncertainty."""

    prediction: np.ndarray
    lower_bound: np.ndarray
    upper_bound: np.ndarray
    aleatoric_uncertainty: np.ndarray
    epistemic_uncertainty: np.ndarray
    confidence: float = 0.95
    measurement_uncertainty: np.ndarray | None = None
    parameter_uncertainty: np.ndarray | None = None

    @property
    def total_uncertainty(self) -> np.ndarray:
        components = [self.aleatoric_uncertainty, self.epistemic_uncertainty]
        if self.measurement_uncertainty is not None:
            components.append(self.measurement_uncertainty)
        if self.parameter_uncertainty is not None:
            components.append(self.parameter_uncertainty)
        return np.sqrt(sum(np.asarray(c) ** 2 for c in components))

    def to_dict(self) -> dict:
        def _s(x):
            arr = np.asarray(x)
            return float(arr.item()) if arr.size == 1 else arr.tolist()
        return {
            "prediction": _s(self.prediction),
            "lower_bound": _s(self.lower_bound),
            "upper_bound": _s(self.upper_bound),
            "confidence": self.confidence,
            "aleatoric_uncertainty": _s(self.aleatoric_uncertainty),
            "epistemic_uncertainty": _s(self.epistemic_uncertainty),
            "total_uncertainty": _s(self.total_uncertainty),
        }


class UncertaintyEngine:
    """Helpers for combining and propagating uncertainty across subsystems."""

    @staticmethod
    def bootstrap_ci(samples: np.ndarray, statistic=np.mean, n_bootstrap: int = 2000,
                      confidence: float = 0.95, seed: int = 42) -> tuple[float, float, float]:
        rng = np.random.default_rng(seed)
        samples = np.asarray(samples)
        samples = samples[~np.isnan(samples)]
        if len(samples) == 0:
            return float("nan"), float("nan"), float("nan")
        boot = np.array([
            statistic(rng.choice(samples, size=len(samples), replace=True))
            for _ in range(n_bootstrap)
        ])
        alpha = 1 - confidence
        lower, upper = np.percentile(boot, [100 * alpha / 2, 100 * (1 - alpha / 2)])
        return float(statistic(samples)), float(lower), float(upper)

    @staticmethod
    def combine(*uncertainties: np.ndarray) -> np.ndarray:
        """Root-sum-square combination of independent uncertainty sources."""
        arrs = [np.asarray(u) for u in uncertainties]
        return np.sqrt(sum(a ** 2 for a in arrs))

    @staticmethod
    def ensemble_epistemic(predictions: np.ndarray) -> np.ndarray:
        """Epistemic uncertainty proxy: cross-model / cross-fold disagreement.
        ``predictions`` has shape (n_models, n_samples)."""
        return np.asarray(predictions).std(axis=0)
