"""Digital twin: compares physics-informed / model-predicted state against observed
experimental state and computes residuals, advancing through an explicit state
machine.

    Experimental System -> Sensor State -> Physics-Informed State -> Predicted State
    -> Observed State -> Residual -> Model Update
"""
from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np

from src.engine.states import DigitalTwinState
from src.physics.relations import NormalisedState, PhysicsInformedModel


@dataclass
class ResidualReport:
    residuals: dict[str, float]
    rmse: float
    max_abs_residual: float
    within_tolerance: bool


@dataclass
class DigitalTwin:
    physics_model: PhysicsInformedModel = field(default_factory=PhysicsInformedModel)
    tolerance: float = 0.2
    state: DigitalTwinState = DigitalTwinState.INITIALISING
    history: list[DigitalTwinState] = field(default_factory=list)

    def __post_init__(self) -> None:
        self._transition(DigitalTwinState.INITIALISING)

    def _transition(self, new_state: DigitalTwinState) -> None:
        self.state = new_state
        self.history.append(new_state)

    def calibrate(self) -> None:
        self._transition(DigitalTwinState.CALIBRATING)
        self._transition(DigitalTwinState.READY)

    def run(self, sensor_state: NormalisedState, observed_state: dict[str, float]) -> ResidualReport:
        """Advance the twin through one full cycle for a single run and return the
        residual between the physics-informed/predicted state and the observed
        (measured) state."""
        if self.state not in (DigitalTwinState.READY, DigitalTwinState.COMPLETE, DigitalTwinState.ANALYSING):
            self.calibrate()

        self._transition(DigitalTwinState.RUNNING_SIMULATION)
        predicted_state = self.physics_model.predicted_state_vector(sensor_state)

        self._transition(DigitalTwinState.ANALYSING)
        residual_report = self._compute_residual(predicted_state, observed_state)

        if residual_report.max_abs_residual > 3 * self.tolerance:
            self._transition(DigitalTwinState.ANOMALY)
        elif not residual_report.within_tolerance:
            self._transition(DigitalTwinState.UNCERTAIN)
        else:
            self._transition(DigitalTwinState.COMPLETE)

        return residual_report

    def _compute_residual(self, predicted: dict[str, float], observed: dict[str, float]) -> ResidualReport:
        shared_keys = sorted(set(predicted) & set(observed))
        if not shared_keys:
            return ResidualReport(residuals={}, rmse=float("nan"), max_abs_residual=float("nan"),
                                   within_tolerance=False)
        residuals = {k: float(observed[k] - predicted[k]) for k in shared_keys}
        values = np.array(list(residuals.values()))
        rmse = float(np.sqrt(np.mean(values ** 2)))
        max_abs = float(np.max(np.abs(values)))
        return ResidualReport(residuals=residuals, rmse=rmse, max_abs_residual=max_abs,
                               within_tolerance=max_abs <= self.tolerance)

    def fail(self, reason: str = "") -> None:
        self._transition(DigitalTwinState.FAILED)
