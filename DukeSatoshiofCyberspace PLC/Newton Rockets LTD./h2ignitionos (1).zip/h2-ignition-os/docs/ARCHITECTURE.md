# Architecture

H2-IGNITION.OS is organised as a pipeline of independent, individually-testable
subsystems under `src/`. Each subsystem exposes a small class-based API and has no
hidden global state — every engine is instantiated with explicit configuration.

```
                    H2-IGNITION.OS
                           |
          +----------------+----------------+
          |                |                |
          v                v                v
     DATA ENGINE       PHYSICS MODEL    EXPERIMENT ENGINE
          |                |                |
          v                v                v
      SENSOR DATA     IGNITION MODEL    TEST DATABASE
          |                |                |
          +--------+-------+-------+--------+
                   |
                   v
             FEATURE ENGINE
                   |
                   v
             ML / SURROGATE
                   |
                   v
             OPTIMISATION
                   |
          +--------+---------+
          |                  |
          v                  v
     RELIABILITY        UNCERTAINTY
       ENGINE             ENGINE
          |                  |
          +--------+---------+
                   |
                   v
             DIGITAL TWIN
                   |
                   v
             REPORT ENGINE
```

## Module-by-module

| Module | Responsibility |
| --- | --- |
| `src/engine` | `EngineConfig` (Pydantic, validated), structured JSON logging, reproducibility (seed control, `RunProvenance`), shared state enums (`DigitalTwinState`, `IgnitionEventLabel`). |
| `src/data` | Canonical measurement schema (`Measurement`/`Dataset`, Pydantic), format-agnostic `DataLoader` (CSV/JSON/Parquet/HDF5), `DataValidator` producing a `DataQualityReport` (missing values, duplicates, impossible values, outliers, dropouts, sampling-rate changes, clock drift, corrupted records). |
| `src/sensors` | Abstract `SensorReading`/`SensorSpec`/`SensorType` contracts (no real hardware wiring) and the synthetic-experiment generator used by the demo and test suite. |
| `src/events` | `TimeSeriesEngine` (resampling, interpolation, filtering, windowing, multi-rate alignment, cross-correlation/lag detection, change-point detection) and `IgnitionEventDetector` (NO_EVENT / AMBIGUOUS / IGNITION_EVENT / ABNORMAL_EVENT with confidence + latency). |
| `src/physics` | `PhysicsInformedModel`: simplified, qualitative, dimensionless proxy relationships between normalised variables — a prior for the digital twin and surrogate model, not an operational design equation. |
| `src/features` | `FeatureEngine`: per-run statistical features per sensor channel, transient-severity proxy, cross-sensor lag features. |
| `src/models` | `train_ignition_probability_model` (group-K-fold CV, calibration, leakage-aware), `IgnitionDelayModel` (distribution fitting: Gaussian/log-normal/Weibull/empirical/KDE), `assess_calibration`, `ModelComparison` (multi-criteria ranking). |
| `src/surrogate` | `SurrogateModel`: fast GP / random-forest / gradient-boosting / polynomial approximations with held-out validation and ensemble/posterior uncertainty. |
| `src/optimisation` | `OptimisationEngine` (Latin-hypercube sampling + Pareto/non-dominated sorting over the six standard objectives) and `SensitivityEngine` (permutation importance, finite-difference local sensitivity). |
| `src/reliability` | `ReliabilityEngine`: success rate with bootstrap CI, repeatability score, run-to-run variability, failure clustering, MTBA, Weibull/log-normal/exponential fits. |
| `src/uncertainty` | `UncertaintyEngine` (bootstrap CI, combination, ensemble epistemic uncertainty) and `MonteCarloEngine` (state perturbation, failure-probability distribution — always labelled `SYNTHETIC SIMULATION`). |
| `src/anomaly` | `AnomalyEngine`: Isolation Forest + PCA reconstruction error + statistical thresholds combined into one anomaly score. |
| `src/digital_twin` | `DigitalTwin`: explicit state machine (`INITIALISING → CALIBRATING → READY → RUNNING_SIMULATION → ANALYSING → {UNCERTAIN, ANOMALY, COMPLETE}`, or `FAILED`) comparing the physics-informed predicted state against the observed state and computing residuals. |
| `src/experiments` | `ExperimentalDesignEngine` (GP-predictive-variance active learning → "next most informative region", never an actuator command) and domain dataclasses (`Experiment`, `Run`, `SensorRecord`, `ModelRecord`, `PredictionRecord`, `OptimisationRecord`, `AnomalyRecord`, `ReportRecord`). |
| `src/storage` | `ExperimentDatabase`: SQLite persistence for the full domain schema with foreign-key integrity and prediction→model provenance tracing. |
| `src/reports` | `ReportEngine` / `ScientificReport`: never omits uncertainty, always carries a limitations section, always labels synthetic data. |
| `src/api` | `H2IgnitionEngine` facade (the public Python API) and `VisualisationDataAPI` (the structured data contract for a future frontend — no rendering code). |

## Design decisions worth knowing

- **Leakage-free training set.** The ignition-probability classifier is trained only
  on a *pre-ignition-window* slice of each run's sensor data (see
  `examples/demo.py`, `PRE_IGNITION_FRACTION`) plus recorded setpoints — never on
  post-event sensor statistics, which would trivially "predict" the label they were
  computed from.
- **The physics-informed prior is deliberately simplified and uncalibrated.** The
  digital twin's residuals are consequently often non-trivial (mostly `UNCERTAIN`,
  a meaningful minority `COMPLETE`) — this is the intended behaviour of comparing a
  qualitative first-principles prior against measured data, not a bug. A follow-on
  "Model Update" step (recalibrating the prior from accumulated residuals) is a
  natural extension point but is not implemented in this foundation.
- **Everything normalised.** No module accepts or emits a real-world engineering
  unit. See `docs/SAFETY.md`.
