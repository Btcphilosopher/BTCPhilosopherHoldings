# Safety Boundary

H2-IGNITION.OS is a **research, simulation, and experimental-data-analysis platform**.
It studies the software-defined statistical and machine-learning behaviour of ignition
*data* — it does not describe, control, or instruct the construction of any physical
ignition system.

## This software does NOT contain

- Ignition-system construction or assembly instructions
- Hardware wiring, actuation, or physical assembly guidance
- Explosive or pyrotechnic formulations/recipes
- Operational rocket-engine firing sequences
- Real-world ignition-control commands or actuator commands
- Automatic physical ignition control of any kind
- Instructions for bypassing safety systems or interlocks

## Design choices that enforce this boundary

1. **Normalised variables only.** All physical-looking quantities the platform accepts
   or produces are dimensionless/normalised (`normalised_temperature`,
   `normalised_pressure`, `normalised_flow`, `normalised_energy`,
   `normalised_mixture_state`, `normalised_transient_time`, and derived *ratios*). There
   is no code path that emits a real-world engineering setpoint (a temperature in
   Kelvin for a specific propellant, a valve timing in milliseconds, an injector
   pressure in bar, etc.).
2. **Analysis and recommendation, never control.** The optimisation and experimental
   design engines output *analysis artefacts*: ranked normalised design regions,
   sensitivity rankings, uncertainty bounds, and "next most informative experiment"
   recommendations. They never emit actuator commands, and the codebase has no
   actuator, hardware, or fire-control interface of any kind.
3. **Statistical, not deterministic, claims.** Ignition probability and ignition delay
   are always represented as random variables / distributions with explicit
   uncertainty. The report engine is not permitted to state a prediction without
   accompanying bounds and a "not a guarantee of physical behaviour" caveat.
4. **Synthetic data is always labelled.** Any Monte-Carlo-generated or synthetically
   simulated dataset is tagged `SYNTHETIC SIMULATION` end-to-end, including in stored
   database records and generated reports, so it is never confused with real
   experimental data.
5. **No physical performance claims from benchmarks.** `benchmarks/benchmark.py`
   measures wall-clock software performance of this codebase only. The report and
   benchmark output explicitly state that these numbers do not translate into physical
   propulsion-system performance.

## Intended use

Engineers and researchers supply (or synthetically generate for testing) experimental
sensor datasets and use this platform to ask analytical questions such as "which
normalised variables are most associated with reliable ignition in this dataset?" or
"how repeatable is the ignition event across runs?" — the same class of question asked
of any statistical/ML analysis platform, applied here to hydrogen-ignition research
data.
