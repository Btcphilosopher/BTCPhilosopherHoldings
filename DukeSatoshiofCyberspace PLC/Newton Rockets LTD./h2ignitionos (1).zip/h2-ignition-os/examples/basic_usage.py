#!/usr/bin/env python3
"""Minimal H2IgnitionEngine API walkthrough (matches the sketch in README.md).

Uses a small synthetic dataset. For the full pipeline (uncertainty, digital twin,
optimisation, scientific report) see examples/demo.py.
"""
from __future__ import annotations

from src.api.engine import H2IgnitionEngine
from src.sensors.synthetic import generate_experiment


def main() -> None:
    engine = H2IgnitionEngine()

    # In place of engine.data.load("experiment.parquet"), generate a small SYNTHETIC
    # dataset in-memory (no real experimental or hardware data is used anywhere here).
    bundle = generate_experiment(n_runs=150, seed=1)
    dataset = engine.data.load_dataframe(bundle.measurements, name=bundle.experiment_id)

    clean = engine.preprocess(dataset)
    features = engine.features.extract(clean, run_metadata=bundle.run_metadata)

    # NOTE: for brevity this uses full-observation-window sensor statistics as
    # predictors, which include the post-ignition signal itself — fine for an API
    # walkthrough, but see examples/demo.py for the leakage-aware pre-ignition-window
    # feature set that a real predictive model should be trained on.
    predictor_columns = [
        c for c in features.columns
        if "__" in c and features[c].notna().all()
    ][:20]

    model = engine.models.train(features, predictor_columns)
    prediction = model.predict(features)

    print(f"Trained {model.model_name} (version {model.model_version})")
    print(f"Held-out ROC-AUC: {model.metrics.roc_auc:.3f}")
    print(f"Mean predicted ignition probability: {prediction.prediction.mean():.3f} "
          f"[{prediction.lower_bound.mean():.3f}, {prediction.upper_bound.mean():.3f}] "
          f"@ {prediction.confidence:.0%} confidence")

    report = engine.optimisation.analyse(model)
    print(f"\nOptimisation-analysis summary: {report}")

    engine.database.close()


if __name__ == "__main__":
    main()
