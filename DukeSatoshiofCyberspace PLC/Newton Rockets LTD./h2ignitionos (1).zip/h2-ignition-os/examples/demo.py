#!/usr/bin/env python3
"""H2-IGNITION.OS — end-to-end synthetic demonstration.

    synthetic experiment -> sensor simulation -> data cleaning -> ignition detection
    -> feature extraction -> ML model -> uncertainty -> digital twin -> optimisation
    -> scientific report

ALL DATA AND RESULTS PRODUCED BY THIS SCRIPT ARE SYNTHETIC. Nothing here is real
experimental or hardware data, and nothing here controls physical hardware.
"""
from __future__ import annotations

import json
import time
from pathlib import Path

import numpy as np
import pandas as pd

from src.anomaly.engine import AnomalyEngine
from src.digital_twin.twin import DigitalTwin
from src.engine.config import EngineConfig
from src.engine.reproducibility import RunProvenance, dataset_fingerprint, new_run_id, set_global_seed
from src.events.ignition_detector import IgnitionEventDetector
from src.events.timeseries import TimeSeriesEngine
from src.experiments.design import ExperimentalDesignEngine
from src.experiments.domain import (
    AnomalyRecord,
    Experiment,
    ModelRecord,
    OptimisationRecord,
    PredictionRecord,
    ReportRecord,
    Run,
    SensorRecord,
)
from src.features.extraction import FeatureEngine
from src.models.calibration import assess_calibration
from src.models.comparison import ModelComparison
from src.models.ignition_delay import IgnitionDelayModel
from src.models.ignition_probability import train_ignition_probability_model
from src.optimisation.engine import ObjectiveVector, OptimisationEngine
from src.optimisation.sensitivity import SensitivityEngine
from src.physics.relations import NormalisedState, PhysicsInformedModel
from src.reliability.engine import ReliabilityEngine
from src.reports.report_engine import ReportEngine
from src.sensors.models import SensorType
from src.sensors.synthetic import SENSOR_SPECS, generate_experiment
from src.storage.database import ExperimentDatabase
from src.surrogate.surrogate import SurrogateModel
from src.uncertainty.engine import UncertaintyEngine
from src.uncertainty.monte_carlo import MonteCarloEngine

ROOT = Path(__file__).resolve().parents[1]
SYNTHETIC_DATA_DIR = ROOT / "synthetic_data"
N_RUNS = 1000
SEED = 42

SETPOINT_COLUMNS = [
    "normalised_temperature_setpoint",
    "normalised_pressure_setpoint",
    "normalised_flow_setpoint",
    "normalised_energy_setpoint",
    "normalised_mixture_state",
]


def section(title: str) -> None:
    print(f"\n{'=' * 70}\n{title}\n{'=' * 70}")


def main() -> dict:
    t_start = time.time()
    timings: dict[str, float] = {}
    SYNTHETIC_DATA_DIR.mkdir(exist_ok=True)
    config = EngineConfig(database_path=str(SYNTHETIC_DATA_DIR / "h2_ignition_os.sqlite"))
    set_global_seed(config.reproducibility.random_seed)

    print("H2-IGNITION.OS")
    print("=" * 15)
    print("Hydrogen Ignition Research, Digital Twin & Optimisation Platform")
    print("ALL RESULTS BELOW ARE SYNTHETIC SIMULATION. No physical hardware is involved.")

    # ------------------------------------------------------------------ 1. DATA
    section("1. SYNTHETIC EXPERIMENT GENERATION")
    t0 = time.time()
    bundle = generate_experiment(n_runs=N_RUNS, seed=SEED)
    timings["synthetic_generation_s"] = time.time() - t0
    bundle.measurements.to_parquet(SYNTHETIC_DATA_DIR / "demo_experiment_measurements.parquet", index=False)
    bundle.run_metadata.to_parquet(SYNTHETIC_DATA_DIR / "demo_experiment_run_metadata.parquet", index=False)
    print(f"Experiment ID: {bundle.experiment_id}")
    print(f"Runs generated: {N_RUNS}")
    print(f"Raw measurement records: {len(bundle.measurements):,}")
    print(f"Source label: {bundle.source_label}")

    dataset_version = dataset_fingerprint(
        pd.util.hash_pandas_object(bundle.measurements).values.tobytes()
    )

    # ------------------------------------------------------------- 2. VALIDATION
    section("2. DATA VALIDATION")
    from src.data.loader import DataLoader
    from src.data.validation import DataValidator

    t0 = time.time()
    dataset = DataLoader().load_dataframe(bundle.measurements, name=bundle.experiment_id)
    quality_report = DataValidator(config.data).validate(dataset.to_frame())
    timings["validation_s"] = time.time() - t0
    clean = quality_report.clean_frame

    original_counts = bundle.measurements.groupby("run_id").size()
    clean_counts = clean.groupby("run_id").size()
    valid_runs = int((clean_counts.reindex(original_counts.index).fillna(0) >= original_counts * 0.95).sum())

    print(json.dumps(quality_report.summary(), indent=2))
    print(f"Valid runs (>=95% of records retained): {valid_runs} / {N_RUNS}")

    # --------------------------------------------------------- 3. EVENT DETECTION
    section("3. IGNITION EVENT DETECTION")
    t0 = time.time()
    tse = TimeSeriesEngine()
    detector = IgnitionEventDetector(config.event_detection)
    event_results = {}
    for run_id, g in clean.groupby("run_id"):
        aligned = tse.align_to_canonical_timeline(g, target_rate_hz=100)
        event_results[run_id] = detector.detect(run_id, aligned)
    timings["event_detection_s"] = time.time() - t0

    label_counts = pd.Series([r.label.value for r in event_results.values()]).value_counts()
    truth = bundle.run_metadata.set_index("run_id")["ignited"]
    detected_ignited = pd.Series({
        rid: r.label.value in ("IGNITION_EVENT", "ABNORMAL_EVENT") for rid, r in event_results.items()
    })
    agreement = float((detected_ignited.reindex(truth.index) == truth).mean())
    print(f"Event labels: {label_counts.to_dict()}")
    print(f"Detector/test-log agreement: {agreement:.3f}")

    # ------------------------------------------------------- 4. FEATURE EXTRACTION
    section("4. FEATURE EXTRACTION")
    t0 = time.time()
    features = FeatureEngine().extract(clean, run_metadata=bundle.run_metadata, event_results=event_results)
    timings["feature_extraction_s"] = time.time() - t0
    print(f"Full-window feature matrix (post-hoc analysis: reliability, anomaly detection, "
          f"digital twin): {features.shape[0]} runs x {features.shape[1]} columns")

    sensor_stat_cols = [c for c in features.columns if "__" in c]

    # --- leakage-free predictor set -------------------------------------------------
    # The ignition-probability *classifier* must not see post-ignition sensor readings
    # (e.g. the optical-intensity spike that literally *is* the ignition event) or it
    # trivially "predicts" the label it was given — textbook target leakage (see
    # project requirement #9). Every observed ignition delay in this dataset falls
    # after 85% of the observation window, so the classifier is instead trained on a
    # pre-ignition-window slice of each run's sensor data plus its recorded setpoints
    # — a genuinely predictive framing ("will this run ignite, given what we can see
    # before any event") rather than a circular one.
    PRE_IGNITION_FRACTION = 0.6
    run_start = clean.groupby("run_id")["timestamp"].transform("min")
    pre_window_clean = clean.loc[(clean["timestamp"] - run_start) <= pd.Timedelta(seconds=PRE_IGNITION_FRACTION)]
    train_features = FeatureEngine().extract(pre_window_clean, run_metadata=bundle.run_metadata)
    print(f"Pre-ignition-window (t <= {PRE_IGNITION_FRACTION:.0%} of window) feature matrix "
          f"used for classifier training: {train_features.shape[0]} runs x {train_features.shape[1]} columns")

    train_sensor_stat_cols = [c for c in train_features.columns if "__" in c]
    predictor_columns = [c for c in train_sensor_stat_cols + ["transient_severity"] + SETPOINT_COLUMNS
                          if train_features[c].notna().all()]
    print(f"Predictor columns used for ignition-probability model ({len(predictor_columns)}): "
          f"{predictor_columns[:8]}{'...' if len(predictor_columns) > 8 else ''}")
    print("Note: predictors are restricted to the pre-ignition window plus recorded "
          "setpoints — post-event sensor statistics and event-detector output "
          "(event_confidence, signal_quality) are excluded from the predictor set to "
          "avoid target leakage.")

    # -------------------------------------------------------------- 5. ML MODELS
    section("5. IGNITION-PROBABILITY MODEL (TRAIN / CROSS-VALIDATE / CALIBRATE)")
    trained_models = {}
    training_times = {}
    for model_name in ("logistic_regression", "random_forest", "gradient_boosting"):
        t0 = time.time()
        trained_models[model_name] = train_ignition_probability_model(
            train_features, predictor_columns, model_name=model_name,
            random_state=SEED, model_version="v1",
        )
        training_times[model_name] = time.time() - t0
    timings["model_training_s"] = sum(training_times.values())

    for name, m in trained_models.items():
        print(f"  [{name}] {m.metrics.to_dict()}")

    primary_model = trained_models["random_forest"]
    calibration = assess_calibration(primary_model.oof_labels, primary_model.oof_predictions)
    ece_by_model = {}
    for name, m in trained_models.items():
        ece_by_model[name] = assess_calibration(m.oof_labels, m.oof_predictions).expected_calibration_error

    comparison = ModelComparison().rank(trained_models, ece_by_model=ece_by_model, cost_by_model=training_times)
    print("\nModel comparison (ranked, NOT accuracy-only):")
    for score in comparison:
        print(f"  {score.model_name}: composite={score.composite_score:.3f} "
              f"(quality={score.quality_score:.3f}, calibration={score.calibration_score:.3f}, "
              f"robustness={score.robustness_score:.3f}, cost={score.computational_cost_s:.2f}s)")

    prediction = primary_model.predict(train_features)
    print(f"\nMean predicted ignition probability: {float(np.mean(prediction.prediction)):.3f} "
          f"[{float(np.mean(prediction.lower_bound)):.3f}, {float(np.mean(prediction.upper_bound)):.3f}] "
          f"@ {prediction.confidence:.0%} confidence")

    # ---------------------------------------------------------- 6. IGNITION DELAY
    section("6. IGNITION-DELAY STATISTICAL MODEL")
    delay_samples = features.loc[features["ignited"] == True, "true_ignition_time"].dropna().to_numpy()  # noqa: E712
    delay_model = IgnitionDelayModel()
    delay_fits = delay_model.fit(delay_samples)
    best_delay_fit = min(
        (f for k, f in delay_fits.items() if k not in ("empirical", "kernel_density")),
        key=lambda f: f.aic,
    )
    print(f"Delay samples (ignited runs): {len(delay_samples)}")
    for name, fit in delay_fits.items():
        aic_str = f"{fit.aic:.1f}" if not np.isnan(fit.aic) else "n/a"
        print(f"  [{name}] mean={fit.mean:.4f} median={fit.median:.4f} std={fit.std:.4f} AIC={aic_str}")
    print(f"Best parametric fit: {best_delay_fit.distribution} "
          f"(median={best_delay_fit.median:.4f}, p95={best_delay_fit.percentiles['p95']:.4f})")

    # ------------------------------------------------------------ 7. UNCERTAINTY
    section("7. UNCERTAINTY QUANTIFICATION")
    ue = UncertaintyEngine()
    success_rate, lo, hi = ue.bootstrap_ci(features["ignited"].astype(float).to_numpy())
    print(f"Bootstrap ignition success rate: {success_rate:.3f} [{lo:.3f}, {hi:.3f}] (95% CI)")
    print(f"Model mean epistemic uncertainty: {float(np.mean(prediction.epistemic_uncertainty)):.4f}")
    print(f"Model mean aleatoric uncertainty: {float(np.mean(prediction.aleatoric_uncertainty)):.4f}")

    # ----------------------------------------------------------- 8. MONTE CARLO
    section("8. MONTE CARLO ENGINE [SYNTHETIC SIMULATION]")
    mc = MonteCarloEngine(seed=SEED)
    mc_failure = mc.failure_probability(prediction.prediction)
    print(f"[{mc_failure.label}] Monte Carlo failure-probability estimate: "
          f"mean={mc_failure.mean:.3f} CI={mc_failure.confidence_interval}")

    base_state = {c: float(features[c].mean()) for c in SETPOINT_COLUMNS}
    noise_std = {c: 0.05 for c in SETPOINT_COLUMNS}
    surrogate_ignition = SurrogateModel(kind="random_forest", random_state=SEED).fit(
        train_features[SETPOINT_COLUMNS].to_numpy(dtype=float),  # same row order as `prediction`
        prediction.prediction,
        feature_columns=SETPOINT_COLUMNS,
    )
    print(f"Surrogate (ignition probability, RF) validation: {surrogate_ignition.validation.to_dict()}")

    mc_state = mc.propagate(
        base_state, noise_std,
        predict_fn=lambda draws: surrogate_ignition.predict(draws),
        n_samples=2000,
    )
    print(f"[{mc_state.label}] Ignition-probability distribution under state perturbation: "
          f"mean={mc_state.mean:.3f} std={mc_state.std:.3f} CI={mc_state.confidence_interval}")

    # ---------------------------------------------------------- 9. DIGITAL TWIN
    section("9. DIGITAL TWIN")
    physics = PhysicsInformedModel()
    residual_reports = {}
    twin_states = []
    sample_run_ids = features["run_id"].sample(n=min(200, len(features)), random_state=SEED)
    feat_idx = features.set_index("run_id")
    for run_id in sample_run_ids:
        row = feat_idx.loc[run_id]
        state = NormalisedState(
            normalised_temperature=row["normalised_temperature_setpoint"],
            normalised_pressure=row["normalised_pressure_setpoint"],
            normalised_flow=row["normalised_flow_setpoint"],
            normalised_energy=row["normalised_energy_setpoint"],
            normalised_mixture_state=row["normalised_mixture_state"],
        )
        observed_state = {
            "reaction_rate_proxy": float(np.clip(row.get("normalised_optical_intensity__mean", 0), 0, 1)),
            # Energy is a commanded setpoint, not directly re-measured; the electrical
            # channel's peak is used as the closest measured proxy for delivered energy.
            "energy_ratio": float(np.clip(row.get("normalised_electrical_signal__max", 0), 0, 1)),
            "pressure_ratio": float(np.clip(row.get("normalised_pressure__mean", 0), 0, 1)),
            "flow_ratio": float(np.clip(row.get("normalised_flow__mean", 0), 0, 1)),
            "delay_ratio": float(np.clip(row.get("event_time", np.nan) if not np.isnan(row.get("event_time", np.nan)) else 1.0, 0, 1)),
        }
        # tolerance chosen empirically from this platform's simplified, uncalibrated
        # physics-informed prior vs measured-feature residuals; see docs/ARCHITECTURE.md
        twin = DigitalTwin(tolerance=0.45)
        residual_reports[run_id] = twin.run(state, observed_state)
        twin_states.append(twin.state.value)

    twin_state_counts = pd.Series(twin_states).value_counts().to_dict()
    rmses = [r.rmse for r in residual_reports.values() if np.isfinite(r.rmse)]
    print(f"Digital twin final states across {len(twin_states)} sampled runs: {twin_state_counts}")
    print(f"Digital twin residual RMSE: mean={np.mean(rmses):.4f} std={np.std(rmses):.4f}")

    # ----------------------------------------------------------- 10. RELIABILITY
    section("10. RELIABILITY ENGINE")
    reliability_engine = ReliabilityEngine(
        bootstrap_samples=config.reliability.bootstrap_samples,
        confidence=config.reliability.confidence_level, seed=SEED,
    )
    anomaly_engine = AnomalyEngine(contamination=0.05, random_state=SEED)
    anomaly_feature_cols = [c for c in sensor_stat_cols + ["transient_severity"] if features[c].notna().all()]
    anomaly_report = anomaly_engine.detect(
        features["run_id"].tolist(), features[anomaly_feature_cols].to_numpy(dtype=float)
    )
    reliability_report = reliability_engine.analyse(
        ignited=features["ignited"].to_numpy(dtype=bool),
        delay_or_index=features["true_ignition_time"].to_numpy(dtype=float),
        anomaly_flags=anomaly_report.is_anomalous,
    )
    print(json.dumps(reliability_report.to_dict(), indent=2))

    # ------------------------------------------------------- 11. ANOMALY DETECTION
    section("11. ANOMALY DETECTION")
    print(json.dumps(anomaly_report.to_dict(), indent=2))
    true_anomalous = features["is_anomalous"].to_numpy(dtype=bool)
    anomaly_agreement = float((anomaly_report.is_anomalous == true_anomalous).mean())
    print(f"Detector agreement with synthetic ground-truth anomaly flag: {anomaly_agreement:.3f}")

    # --------------------------------------------------------- 12. SENSITIVITY
    section("12. SENSITIVITY ENGINE")
    sensitivity_engine = SensitivityEngine(random_state=SEED)
    X_all = train_features[predictor_columns].to_numpy(dtype=float)
    y_all = train_features["ignited"].to_numpy(dtype=int)
    sensitivity_report = sensitivity_engine.permutation_importance(
        primary_model.estimator, X_all, y_all, predictor_columns, n_repeats=10
    )
    print("Top-10 sensitivity ranking:")
    for name, imp in sensitivity_report.ranked()[:10]:
        print(f"  {name:45s} {imp:.4f}")

    # ------------------------------------------------------- 13. OPTIMISATION
    section("13. OPTIMISATION ENGINE")
    variable_bounds = {c: (float(features[c].min()), float(features[c].max())) for c in SETPOINT_COLUMNS}

    surrogate_delay = SurrogateModel(kind="random_forest", random_state=SEED).fit(
        features.loc[features["ignited"] == True, SETPOINT_COLUMNS].to_numpy(dtype=float),  # noqa: E712
        features.loc[features["ignited"] == True, "true_ignition_time"].to_numpy(dtype=float),  # noqa: E712
        feature_columns=SETPOINT_COLUMNS,
    )
    surrogate_anomaly = SurrogateModel(kind="random_forest", random_state=SEED).fit(
        features[SETPOINT_COLUMNS].to_numpy(dtype=float),
        anomaly_report.anomaly_score,
        feature_columns=SETPOINT_COLUMNS,
    )
    surrogate_transient = SurrogateModel(kind="random_forest", random_state=SEED).fit(
        features[SETPOINT_COLUMNS].to_numpy(dtype=float),
        features["transient_severity"].to_numpy(dtype=float),
        feature_columns=SETPOINT_COLUMNS,
    )

    def objective_fn(point: dict[str, float]) -> ObjectiveVector:
        x = np.array([[point[c] for c in SETPOINT_COLUMNS]])
        p_ignite, p_ignite_std = surrogate_ignition.predict_with_std(x)
        delay_mean, delay_std = surrogate_delay.predict_with_std(x)
        anomaly_p, _ = surrogate_anomaly.predict_with_std(x)
        transient, _ = surrogate_transient.predict_with_std(x)
        repeatability = float(np.clip(1 - delay_std[0] / (abs(delay_mean[0]) + 1e-6), 0, 1))
        return ObjectiveVector(
            ignition_probability=float(np.clip(p_ignite[0], 0, 1)),
            delay_variance=float(max(delay_std[0], 0) ** 2),
            uncertainty=float(p_ignite_std[0]),
            repeatability=repeatability,
            anomaly_probability=float(np.clip(anomaly_p[0], 0, 1)),
            transient_severity=float(max(transient[0], 0)),
        )

    t0 = time.time()
    optimisation_engine = OptimisationEngine(n_lhs_samples=config.optimisation.n_lhs_samples, random_state=SEED)
    optimisation_result = optimisation_engine.evaluate(variable_bounds, objective_fn)
    timings["optimisation_s"] = time.time() - t0
    print(f"Evaluated {len(optimisation_result.candidates)} normalised design points via "
          f"Latin-hypercube sampling.")
    print(f"Pareto-optimal set size: {len(optimisation_result.pareto_front)}")
    print(f"Ranked design variables: {optimisation_result.ranked_variables}")
    print("Recommended normalised design region (Pareto-consistent bounds):")
    for k, (lo_v, hi_v) in optimisation_result.recommended_region.items():
        print(f"  {k}: [{lo_v:.3f}, {hi_v:.3f}]")

    # -------------------------------------------------- 14. EXPERIMENTAL DESIGN
    section("14. EXPERIMENTAL-DESIGN ENGINE (ACTIVE LEARNING)")
    design_engine = ExperimentalDesignEngine(random_state=SEED)
    recommendations = design_engine.recommend_next_region(
        X_observed=train_features[SETPOINT_COLUMNS].to_numpy(dtype=float),  # aligned with `prediction`
        y_observed=prediction.prediction,
        variable_bounds=variable_bounds,
        n_candidates=500, top_k=3,
    )
    print("NEXT MOST INFORMATIVE REGION(S) (uncertainty-reduction recommendation, NOT an "
          "actuator command):")
    for rec in recommendations:
        print(f"  info_gain={rec.expected_information_gain:.4f} std={rec.predictive_std:.4f} "
              f"point={ {k: round(v, 3) for k, v in rec.normalised_design_variables.items()} }")

    # ------------------------------------------------------------- 15. DATABASE
    section("15. EXPERIMENT DATABASE PERSISTENCE")
    db = ExperimentDatabase(config.database_path)
    db.insert_experiment(Experiment(
        experiment_id=bundle.experiment_id, name="H2-IGNITION.OS synthetic demonstration",
        description="Fully synthetic dataset generated for platform demonstration/testing.",
        source_label=bundle.source_label,
    ))
    for run_id in bundle.run_metadata["run_id"]:
        db.insert_run(Run(run_id=run_id, experiment_id=bundle.experiment_id,
                           started_at=str(clean.loc[clean["run_id"] == run_id, "timestamp"].min())))
    for sensor_id, spec in SENSOR_SPECS.items():
        db.insert_sensor(SensorRecord(sensor_id=sensor_id, sensor_type=spec["type"].value, variable=spec["variable"]))
    t0 = time.time()
    db.insert_measurements(clean)
    timings["database_insert_s"] = time.time() - t0

    for name, model in trained_models.items():
        db.insert_model(ModelRecord(
            model_id=f"{name}_v1", model_name=name, model_version="v1", dataset_version=dataset_version,
            parameters={"feature_columns": predictor_columns}, random_seed=SEED,
            software_version=config.reproducibility.software_version,
        ))
    for run_id, p, lo_p, hi_p in list(zip(
        train_features["run_id"], prediction.prediction, prediction.lower_bound, prediction.upper_bound
    ))[:200]:
        db.insert_prediction(PredictionRecord(
            prediction_id=f"pred_{run_id}", model_id="random_forest_v1", run_id=run_id,
            target="ignition_probability", value=float(p), lower_bound=float(lo_p),
            upper_bound=float(hi_p), confidence=prediction.confidence,
        ))
    db.insert_optimisation(OptimisationRecord(
        optimisation_id=f"opt_{bundle.experiment_id}", experiment_id=bundle.experiment_id,
        objective_summary=optimisation_result.to_dict(), n_pareto_optimal=len(optimisation_result.pareto_front),
    ))
    for run_id, score, flag in zip(anomaly_report.run_ids, anomaly_report.anomaly_score, anomaly_report.is_anomalous):
        if flag:
            db.insert_anomaly(AnomalyRecord(
                anomaly_id=f"anom_{run_id}", run_id=run_id, anomaly_score=float(score), is_anomalous=bool(flag),
            ))

    integrity_issues = db.integrity_check()
    print(f"Database tables: experiments={db.count('experiments')} runs={db.count('runs')} "
          f"sensors={db.count('sensors')} measurements={db.count('measurements')} "
          f"models={db.count('models')} predictions={db.count('predictions')} "
          f"optimisations={db.count('optimisations')} anomalies={db.count('anomalies')}")
    print(f"Integrity check issues: {integrity_issues if integrity_issues else 'none'}")

    # -------------------------------------------------------------- 16. REPORT
    section("16. SCIENTIFIC REPORT")
    report_engine = ReportEngine()
    report = report_engine.generate(
        experiment_summary={
            "experiment_id": bundle.experiment_id, "runs": N_RUNS, "valid_runs": valid_runs,
            "source": bundle.source_label,
        },
        data_quality=quality_report.summary(),
        model_performance={name: m.metrics.to_dict() for name, m in trained_models.items()},
        ignition_probability={
            "mean_prediction": float(np.mean(prediction.prediction)),
            "mean_lower_bound": float(np.mean(prediction.lower_bound)),
            "mean_upper_bound": float(np.mean(prediction.upper_bound)),
            "confidence": prediction.confidence,
        },
        ignition_delay=best_delay_fit.to_dict(),
        uncertainty={
            "mean_epistemic": float(np.mean(prediction.epistemic_uncertainty)),
            "mean_aleatoric": float(np.mean(prediction.aleatoric_uncertainty)),
            "bootstrap_success_rate_ci": [lo, hi],
        },
        sensitivity={"ranked": sensitivity_report.ranked()},
        anomaly_detection=anomaly_report.to_dict(),
        reliability=reliability_report.to_dict(),
        optimisation_results=optimisation_result.to_dict(),
    )
    report_text = report.to_text()
    print(report_text)
    (SYNTHETIC_DATA_DIR / "demo_report.txt").write_text(report_text)
    (SYNTHETIC_DATA_DIR / "demo_report.json").write_text(report.to_json())
    db.insert_report(ReportRecord(
        report_id=f"report_{bundle.experiment_id}", experiment_id=bundle.experiment_id,
        summary=json.dumps(report.experiment_summary),
    ))
    db.close()

    # --------------------------------------------------------- 17. REPRODUCIBILITY
    section("17. REPRODUCIBILITY RECORD")
    provenance = RunProvenance(
        run_id=new_run_id(), random_seed=SEED, model_version="v1", dataset_version=dataset_version,
        parameters={"predictor_columns": predictor_columns, "n_runs": N_RUNS},
        configuration=config.model_dump(),
    )
    (SYNTHETIC_DATA_DIR / "provenance.json").write_text(json.dumps(provenance.to_dict(), indent=2))
    print(json.dumps(provenance.to_dict(), indent=2, default=str))

    timings["total_s"] = time.time() - t_start
    section("TIMING SUMMARY (measured on this run)")
    print(json.dumps(timings, indent=2))

    return {
        "timings": timings,
        "quality_report": quality_report.summary(),
        "model_metrics": {name: m.metrics.to_dict() for name, m in trained_models.items()},
        "reliability": reliability_report.to_dict(),
        "anomaly": anomaly_report.to_dict(),
        "optimisation": optimisation_result.to_dict(),
    }


if __name__ == "__main__":
    main()
