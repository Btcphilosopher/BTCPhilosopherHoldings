import numpy as np

from src.models.calibration import assess_calibration
from src.models.comparison import ModelComparison
from src.models.ignition_delay import IgnitionDelayModel
from src.models.ignition_probability import train_ignition_probability_model


def _predictor_columns(features):
    stat_cols = [c for c in features.columns if "__" in c]
    cols = stat_cols + ["transient_severity", "normalised_mixture_state", "normalised_energy_setpoint"]
    return [c for c in cols if features[c].notna().all()]


def test_train_ignition_probability_model_returns_valid_metrics(features):
    cols = _predictor_columns(features)
    model = train_ignition_probability_model(features, cols, model_name="logistic_regression", random_state=1)
    m = model.metrics
    assert 0 <= m.accuracy <= 1
    assert 0 <= m.precision <= 1
    assert 0 <= m.recall <= 1
    assert 0 <= m.brier_score <= 1
    assert model.oof_predictions is not None
    assert len(model.oof_predictions) == len(model.oof_labels)


def test_predictions_include_uncertainty(features):
    cols = _predictor_columns(features)
    model = train_ignition_probability_model(features, cols, model_name="random_forest", random_state=1)
    pred = model.predict(features)
    assert pred.prediction.shape == (len(features),)
    assert (pred.lower_bound <= pred.prediction + 1e-9).all()
    assert (pred.prediction - 1e-9 <= pred.upper_bound).all()
    assert (pred.total_uncertainty >= 0).all()


def test_out_of_fold_predictions_are_held_out_not_training_predictions(features):
    """Regression test: `oof_predictions` must come from each fold's held-out split,
    not from predicting on the same data the model was trained on (which would
    silently reintroduce train/test contamination)."""
    cols = _predictor_columns(features)
    model = train_ignition_probability_model(features, cols, model_name="logistic_regression", random_state=1)
    # Out-of-fold predictions should show real spread (not collapsed to 0/1 constants,
    # which is what near-perfect training-set predictions on a separable-by-training
    # coincidence would look like).
    assert model.oof_predictions.std() > 0.01
    assert len(model.oof_predictions) <= len(features)


def test_calibration_report_reasonable(features):
    cols = _predictor_columns(features)
    model = train_ignition_probability_model(features, cols, model_name="random_forest", random_state=1)
    report = assess_calibration(model.oof_labels, model.oof_predictions)
    assert 0 <= report.expected_calibration_error <= 1 or np.isnan(report.expected_calibration_error)


def test_model_comparison_ranks_without_relying_on_accuracy_alone(features):
    cols = _predictor_columns(features)
    models = {
        name: train_ignition_probability_model(features, cols, model_name=name, random_state=1)
        for name in ("logistic_regression", "random_forest")
    }
    ranked = ModelComparison().rank(models)
    assert len(ranked) == 2
    assert ranked[0].composite_score >= ranked[1].composite_score


def test_ignition_delay_model_never_returns_bare_point_estimate():
    rng = np.random.default_rng(0)
    samples = rng.lognormal(mean=0.0, sigma=0.3, size=200)
    fits = IgnitionDelayModel().fit(samples)
    for fit in fits.values():
        assert fit.confidence_interval[0] <= fit.median <= fit.confidence_interval[1]
        assert fit.std >= 0


def test_ignition_delay_requires_minimum_samples():
    try:
        IgnitionDelayModel().fit(np.array([1.0, 2.0]))
        assert False, "expected ValueError for too few samples"
    except ValueError:
        pass
