import numpy as np

from src.uncertainty.engine import PredictionWithUncertainty, UncertaintyEngine
from src.uncertainty.monte_carlo import MonteCarloEngine, SYNTHETIC_LABEL


def test_bootstrap_ci_contains_point_estimate():
    rng = np.random.default_rng(0)
    samples = rng.normal(0.6, 0.1, 500)
    mean, lo, hi = UncertaintyEngine.bootstrap_ci(samples)
    assert lo <= mean <= hi


def test_combine_is_root_sum_square():
    combined = UncertaintyEngine.combine(np.array([3.0]), np.array([4.0]))
    assert np.isclose(combined[0], 5.0)


def test_prediction_with_uncertainty_total_uncertainty():
    pred = PredictionWithUncertainty(
        prediction=np.array([0.5]), lower_bound=np.array([0.3]), upper_bound=np.array([0.7]),
        aleatoric_uncertainty=np.array([0.1]), epistemic_uncertainty=np.array([0.1]),
    )
    assert np.isclose(pred.total_uncertainty[0], np.sqrt(0.02))
    d = pred.to_dict()
    assert "lower_bound" in d and "upper_bound" in d


def test_monte_carlo_results_are_labelled_synthetic():
    mc = MonteCarloEngine(seed=1)
    result = mc.failure_probability(np.full(1000, 0.3))
    assert result.label == SYNTHETIC_LABEL
    assert 0 <= result.mean <= 1


def test_monte_carlo_reproducible_with_same_seed():
    mc1 = MonteCarloEngine(seed=7)
    mc2 = MonteCarloEngine(seed=7)
    r1 = mc1.failure_probability(np.full(500, 0.4))
    r2 = mc2.failure_probability(np.full(500, 0.4))
    assert np.array_equal(r1.samples, r2.samples)


def test_monte_carlo_propagate_uses_predict_fn():
    mc = MonteCarloEngine(seed=3)
    base_state = {"x": 0.5}
    noise = {"x": 0.05}
    result = mc.propagate(base_state, noise, predict_fn=lambda draws: draws[:, 0] * 2, n_samples=1000)
    assert np.isclose(result.mean, 1.0, atol=0.05)
