import numpy as np

from src.engine.reproducibility import RunProvenance, dataset_fingerprint, new_run_id, set_global_seed


def test_set_global_seed_makes_numpy_deterministic():
    set_global_seed(123)
    a = np.random.rand(5)
    set_global_seed(123)
    b = np.random.rand(5)
    assert np.array_equal(a, b)


def test_dataset_fingerprint_is_stable_for_same_bytes():
    data = b"some deterministic content"
    assert dataset_fingerprint(data) == dataset_fingerprint(data)


def test_dataset_fingerprint_changes_with_content():
    assert dataset_fingerprint(b"a") != dataset_fingerprint(b"b")


def test_new_run_id_is_unique():
    ids = {new_run_id() for _ in range(100)}
    assert len(ids) == 100


def test_run_provenance_round_trip():
    prov = RunProvenance(
        run_id="r1", random_seed=42, model_version="v1", dataset_version="d1",
        parameters={"a": 1}, configuration={"b": 2},
    )
    d = prov.to_dict()
    assert d["run_id"] == "r1"
    assert d["random_seed"] == 42
    assert d["parameters"] == {"a": 1}


def test_synthetic_generation_reproducible_with_same_seed():
    from src.sensors.synthetic import generate_experiment
    b1 = generate_experiment(n_runs=20, seed=99)
    b2 = generate_experiment(n_runs=20, seed=99)
    assert b1.measurements["value"].to_numpy().tolist() == b2.measurements["value"].to_numpy().tolist()
    assert b1.run_metadata["ignited"].tolist() == b2.run_metadata["ignited"].tolist()
