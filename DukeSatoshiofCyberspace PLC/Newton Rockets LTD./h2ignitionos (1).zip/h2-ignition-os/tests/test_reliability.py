import numpy as np

from src.reliability.engine import ReliabilityEngine


def test_reliability_report_success_rate_matches_data():
    rng = np.random.default_rng(0)
    ignited = rng.uniform(0, 1, 500) < 0.7
    delays = np.where(ignited, rng.lognormal(0, 0.2, 500), np.nan)
    report = ReliabilityEngine(bootstrap_samples=500, seed=0).analyse(ignited, delays)
    assert abs(report.success_rate - ignited.mean()) < 1e-9
    assert report.success_rate_ci[0] <= report.success_rate <= report.success_rate_ci[1]
    assert 0 <= report.repeatability_score <= 1


def test_reliability_handles_all_success():
    ignited = np.ones(20, dtype=bool)
    delays = np.full(20, 0.5)
    report = ReliabilityEngine(bootstrap_samples=200, seed=0).analyse(ignited, delays)
    assert report.failure_probability == 0.0


def test_reliability_distribution_fit_returns_named_distribution():
    rng = np.random.default_rng(0)
    ignited = rng.uniform(0, 1, 300) < 0.5
    delays = np.where(ignited, rng.lognormal(0, 0.3, 300), np.nan)
    report = ReliabilityEngine(bootstrap_samples=200, seed=0).analyse(ignited, delays)
    assert report.best_fit_distribution in ("weibull", "log_normal", "exponential", "insufficient_data")
