"""Shared pytest fixtures. All fixtures use synthetic data only."""
from __future__ import annotations

import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from src.data.loader import DataLoader
from src.data.validation import DataValidator
from src.events.ignition_detector import IgnitionEventDetector
from src.events.timeseries import TimeSeriesEngine
from src.features.extraction import FeatureEngine
from src.sensors.synthetic import SyntheticExperimentBundle, generate_experiment


@pytest.fixture(scope="session")
def synthetic_bundle() -> SyntheticExperimentBundle:
    return generate_experiment(n_runs=120, seed=123)


@pytest.fixture(scope="session")
def clean_frame(synthetic_bundle):
    ds = DataLoader().load_dataframe(synthetic_bundle.measurements, name="test")
    report = DataValidator().validate(ds.to_frame())
    return report.clean_frame


@pytest.fixture(scope="session")
def event_results(clean_frame):
    tse = TimeSeriesEngine()
    detector = IgnitionEventDetector()
    results = {}
    for run_id, g in clean_frame.groupby("run_id"):
        aligned = tse.align_to_canonical_timeline(g, target_rate_hz=100)
        results[run_id] = detector.detect(run_id, aligned)
    return results


@pytest.fixture(scope="session")
def features(clean_frame, synthetic_bundle, event_results):
    return FeatureEngine().extract(clean_frame, run_metadata=synthetic_bundle.run_metadata, event_results=event_results)
