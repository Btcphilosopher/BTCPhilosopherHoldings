import numpy as np

from src.optimisation.engine import ObjectiveVector, OptimisationEngine


def _objective_fn(point: dict) -> ObjectiveVector:
    # Simple synthetic objective: higher x -> better ignition probability & repeatability.
    x = point["x"]
    return ObjectiveVector(
        ignition_probability=float(np.clip(x, 0, 1)),
        delay_variance=float((1 - x) ** 2),
        uncertainty=float(0.1 * (1 - x)),
        repeatability=float(np.clip(x, 0, 1)),
        anomaly_probability=float(0.05),
        transient_severity=float(0.1),
    )


def test_latin_hypercube_sample_respects_bounds():
    engine = OptimisationEngine(n_lhs_samples=64, random_state=0)
    samples = engine.latin_hypercube_sample({"x": (0.0, 1.0), "y": (-1.0, 1.0)})
    xs = [s["x"] for s in samples]
    ys = [s["y"] for s in samples]
    assert min(xs) >= 0.0 and max(xs) <= 1.0
    assert min(ys) >= -1.0 and max(ys) <= 1.0


def test_pareto_front_is_non_dominated():
    engine = OptimisationEngine(n_lhs_samples=64, random_state=0)
    result = engine.evaluate({"x": (0.0, 1.0)}, _objective_fn)
    assert len(result.pareto_front) > 0
    vectors = [c.objectives.as_minimisation_vector() for c in result.pareto_front]
    for i, v in enumerate(vectors):
        for j, w in enumerate(vectors):
            if i == j:
                continue
            dominated = np.all(w <= v) and np.any(w < v)
            assert not dominated


def test_optimisation_never_emits_hardware_settings():
    """The result object must only expose normalised design variables / analysis
    artefacts, never anything resembling a real hardware setpoint field."""
    engine = OptimisationEngine(n_lhs_samples=32, random_state=0)
    result = engine.evaluate({"x": (0.0, 1.0)}, _objective_fn)
    d = result.to_dict()
    forbidden = {"actuator_command", "fire", "ignite_now", "valve_position_mm", "voltage_v"}
    assert forbidden.isdisjoint(d.keys())
    assert forbidden.isdisjoint(result.recommended_region.keys())


def test_ranked_variables_sum_to_one_or_zero():
    engine = OptimisationEngine(n_lhs_samples=32, random_state=0)
    result = engine.evaluate({"x": (0.0, 1.0), "y": (0.0, 1.0)}, lambda p: _objective_fn({"x": p["x"]}))
    total = sum(v for _, v in result.ranked_variables)
    assert total == 0 or abs(total - 1.0) < 1e-6
