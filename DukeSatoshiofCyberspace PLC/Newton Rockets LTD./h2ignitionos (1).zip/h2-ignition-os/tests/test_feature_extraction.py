def test_feature_matrix_has_one_row_per_run(features, synthetic_bundle):
    assert len(features) == len(synthetic_bundle.run_metadata)
    assert features["run_id"].is_unique


def test_feature_matrix_includes_sensor_stats(features):
    stat_cols = [c for c in features.columns if "__" in c]
    assert len(stat_cols) > 0
    for suffix in ("mean", "std", "min", "max", "p90"):
        assert any(c.endswith(f"__{suffix}") for c in stat_cols)


def test_feature_matrix_merges_run_metadata(features):
    assert "ignited" in features.columns
    assert "normalised_mixture_state" in features.columns


def test_transient_severity_is_non_negative(features):
    assert (features["transient_severity"] >= 0).all()
