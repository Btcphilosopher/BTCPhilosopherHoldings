from src.physics.relations import NormalisedState, PhysicsInformedModel


def test_all_physics_outputs_are_bounded():
    model = PhysicsInformedModel()
    state = NormalisedState(0.8, 0.6, 0.4, 0.9, 0.7)
    out = model.predicted_state_vector(state)
    for key, value in out.items():
        assert 0.0 <= value <= 1.0, f"{key} out of bounds: {value}"


def test_reaction_rate_increases_with_temperature():
    model = PhysicsInformedModel()
    low = model.reaction_rate_proxy(NormalisedState(0.1, 0.5, 0.5, 0.5, 0.6))
    high = model.reaction_rate_proxy(NormalisedState(0.9, 0.5, 0.5, 0.5, 0.6))
    assert high > low


def test_delay_ratio_decreases_with_energy():
    model = PhysicsInformedModel()
    low_energy = model.delay_ratio(NormalisedState(0.6, 0.6, 0.6, 0.1, 0.6))
    high_energy = model.delay_ratio(NormalisedState(0.6, 0.6, 0.6, 1.0, 0.6))
    assert high_energy <= low_energy


def test_no_hardware_specific_fields_in_state():
    """The normalised-state contract must never grow a real hardware field (voltage,
    valve position, propellant mass flow in kg/s, etc.)."""
    fields = set(NormalisedState.__dataclass_fields__.keys())
    forbidden = {"voltage", "valve_position", "mass_flow_kg_s", "injector_diameter_mm"}
    assert fields.isdisjoint(forbidden)
    assert all(f.startswith("normalised_") for f in fields)
