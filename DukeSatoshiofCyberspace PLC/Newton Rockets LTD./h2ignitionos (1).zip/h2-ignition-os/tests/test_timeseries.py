import numpy as np
import pandas as pd

from src.events.timeseries import TimeSeriesEngine


def test_resample_preserves_endpoints():
    idx = pd.date_range("2026-01-01", periods=5, freq="1s", tz="UTC")
    s = pd.Series([0, 1, 2, 3, 4], index=idx, dtype=float)
    resampled = TimeSeriesEngine.resample(s, target_rate_hz=10)
    assert resampled.iloc[0] == 0
    assert resampled.iloc[-1] == 4
    assert len(resampled) > len(s)


def test_interpolate_gaps_fills_nan():
    idx = pd.date_range("2026-01-01", periods=5, freq="1s", tz="UTC")
    s = pd.Series([0.0, np.nan, 2.0, np.nan, 4.0], index=idx)
    filled = TimeSeriesEngine.interpolate_gaps(s)
    assert not filled.isna().any()
    assert filled.iloc[1] == 1.0


def test_low_pass_filter_reduces_high_frequency_energy():
    t = np.linspace(0, 1, 500)
    clean = np.sin(2 * np.pi * 2 * t)
    noisy = clean + 0.5 * np.sin(2 * np.pi * 80 * t)
    filtered = TimeSeriesEngine.low_pass_filter(noisy, cutoff_ratio=0.1)
    assert np.std(filtered - clean) < np.std(noisy - clean)


def test_align_to_canonical_timeline_synchronises_multirate_channels():
    t1 = pd.date_range("2026-01-01", periods=10, freq="100ms", tz="UTC")
    t2 = pd.date_range("2026-01-01", periods=5, freq="200ms", tz="UTC")
    df = pd.concat([
        pd.DataFrame({"timestamp": t1, "variable": "a", "value": np.arange(10, dtype=float)}),
        pd.DataFrame({"timestamp": t2, "variable": "b", "value": np.arange(5, dtype=float)}),
    ])
    aligned = TimeSeriesEngine.align_to_canonical_timeline(df, target_rate_hz=50)
    assert "a" in aligned.columns and "b" in aligned.columns
    assert len(aligned) > 0
    assert not aligned["a"].isna().any()


def test_lag_detection_recovers_known_shift():
    rng = np.random.default_rng(0)
    base = rng.normal(size=200)
    shift = 7
    shifted = np.roll(base, shift)
    lag = TimeSeriesEngine().lag_detection(base, shifted, dt=1.0)
    assert abs(abs(lag) - shift) <= 1


def test_change_point_detection_finds_a_mean_shift():
    # Real sensor data always carries some noise; a perfectly zero-variance flat
    # segment is a degenerate case this z-score-based detector isn't meant to
    # handle (its ratio is undefined against zero variance), so a small noise
    # floor is included, as any real channel would have.
    rng = np.random.default_rng(0)
    values = np.concatenate([
        rng.normal(0, 0.05, 50),
        rng.normal(10, 0.05, 50),
    ])
    points = TimeSeriesEngine.change_point_detection(values, window=5, z_threshold=3.0)
    assert len(points) > 0
    assert any(45 <= p <= 60 for p in points)
