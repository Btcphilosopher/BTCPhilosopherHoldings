from src.reports.report_engine import ReportEngine


def _minimal_report():
    return ReportEngine().generate(
        experiment_summary={"experiment_id": "e1", "runs": 10},
        data_quality={"n_rows": 100, "n_issue_types": 0, "n_flagged_records": 0},
        model_performance={"random_forest": {"roc_auc": 0.9}},
        ignition_probability={"mean_prediction": 0.6, "mean_lower_bound": 0.5, "mean_upper_bound": 0.7},
        ignition_delay={"median": 0.5, "p95": 0.8},
        uncertainty={"mean_epistemic": 0.05, "mean_aleatoric": 0.1},
        sensitivity={"ranked": [("x", 1.0)]},
        anomaly_detection={"n_anomalous": 1},
        optimisation_results={"n_pareto_optimal": 5},
        reliability={"success_rate": 0.6},
    )


def test_report_never_omits_uncertainty():
    report = _minimal_report()
    d = report.to_dict()
    assert "uncertainty" in d
    assert d["uncertainty"]["mean_epistemic"] is not None
    assert d["uncertainty"]["mean_aleatoric"] is not None


def test_report_includes_limitations_by_default():
    report = _minimal_report()
    assert len(report.limitations) > 0


def test_report_labels_synthetic_data():
    report = _minimal_report()
    assert report.is_synthetic is True
    assert report.to_dict()["data_provenance"] == "SYNTHETIC SIMULATION"


def test_report_text_contains_disclaimer():
    report = _minimal_report()
    text = report.to_text().lower()
    assert "a guarantee of physical ignition" in text
    assert "no ignition-control capability" in text


def test_report_json_round_trip():
    import json
    report = _minimal_report()
    parsed = json.loads(report.to_json())
    assert parsed["experiment_summary"]["experiment_id"] == "e1"
