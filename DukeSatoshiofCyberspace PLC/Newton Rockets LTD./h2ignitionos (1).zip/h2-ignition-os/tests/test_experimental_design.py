import numpy as np

from src.experiments.design import ExperimentalDesignEngine


def test_recommend_next_region_returns_points_within_bounds():
    rng = np.random.default_rng(0)
    X = rng.uniform(0, 1, size=(30, 2))
    y = X[:, 0] + 0.1 * rng.standard_normal(30)
    bounds = {"a": (0.0, 1.0), "b": (0.0, 1.0)}

    recs = ExperimentalDesignEngine(random_state=0).recommend_next_region(X, y, bounds, n_candidates=100, top_k=3)
    assert len(recs) == 3
    for rec in recs:
        assert 0.0 <= rec.normalised_design_variables["a"] <= 1.0
        assert 0.0 <= rec.normalised_design_variables["b"] <= 1.0
        assert rec.expected_information_gain >= 0
        assert "not a control instruction" in rec.rationale


def test_recommendations_are_never_actuator_commands():
    rng = np.random.default_rng(1)
    X = rng.uniform(0, 1, size=(20, 1))
    y = rng.uniform(0, 1, 20)
    recs = ExperimentalDesignEngine(random_state=1).recommend_next_region(
        X, y, {"x": (0.0, 1.0)}, n_candidates=50, top_k=1
    )
    d = recs[0].to_dict()
    assert set(d.keys()) == {"normalised_design_variables", "expected_information_gain", "predictive_std", "rationale"}
