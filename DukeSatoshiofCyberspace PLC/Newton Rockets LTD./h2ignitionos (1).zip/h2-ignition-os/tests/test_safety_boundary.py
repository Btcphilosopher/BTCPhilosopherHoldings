"""Static checks that the safety boundary in docs/SAFETY.md actually holds in code:
no actuator/firing/control vocabulary anywhere in the source tree."""
from __future__ import annotations

from pathlib import Path

SRC_ROOT = Path(__file__).resolve().parents[1] / "src"

FORBIDDEN_TOKENS = (
    "fire_ignitor", "actuator_command", "valve_open", "valve_close", "ignite_now",
    "arm_system", "detonate", "propellant_mass", "injector_pressure_bar",
    "gpio.write", "serial.write", "send_command_to_hardware",
)


def _all_source_files():
    return list(SRC_ROOT.rglob("*.py"))


def test_no_forbidden_control_vocabulary_in_source():
    hits = []
    for path in _all_source_files():
        text = path.read_text(encoding="utf-8").lower()
        for token in FORBIDDEN_TOKENS:
            if token in text:
                hits.append((str(path), token))
    assert hits == [], f"Forbidden hardware-control vocabulary found: {hits}"


def test_no_hardware_io_imports_in_source():
    """The platform must never import real hardware/serial/GPIO control libraries."""
    forbidden_imports = ("serial", "RPi.GPIO", "gpiozero", "pyfirmata", "can.interface")
    hits = []
    for path in _all_source_files():
        text = path.read_text(encoding="utf-8")
        for lib in forbidden_imports:
            if f"import {lib}" in text or f"from {lib}" in text:
                hits.append((str(path), lib))
    assert hits == [], f"Forbidden hardware-IO imports found: {hits}"


def test_optimisation_and_experiment_design_are_analysis_only():
    """Both engines must expose analysis artefacts, never a `send`/`execute`/`fire`
    style method that would suggest a physical-control code path."""
    import inspect

    from src.experiments.design import ExperimentalDesignEngine
    from src.optimisation.engine import OptimisationEngine

    forbidden_method_prefixes = ("fire", "execute_", "send_", "actuate", "control_")
    for cls in (ExperimentalDesignEngine, OptimisationEngine):
        methods = [name for name, _ in inspect.getmembers(cls, predicate=inspect.isfunction)]
        for m in methods:
            assert not m.startswith(forbidden_method_prefixes), f"{cls.__name__}.{m} looks like a control method"
