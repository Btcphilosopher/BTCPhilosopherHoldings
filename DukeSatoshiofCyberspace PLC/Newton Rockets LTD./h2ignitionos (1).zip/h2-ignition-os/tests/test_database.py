import pandas as pd
import pytest

from src.experiments.domain import Experiment, ModelRecord, PredictionRecord, Run
from src.storage.database import ExperimentDatabase


@pytest.fixture
def db(tmp_path):
    database = ExperimentDatabase(tmp_path / "test.sqlite")
    yield database
    database.close()


def test_experiment_and_run_round_trip(db):
    db.insert_experiment(Experiment(experiment_id="e1", name="Test", source_label="SYNTHETIC SIMULATION"))
    db.insert_run(Run(run_id="r1", experiment_id="e1", started_at="2026-01-01T00:00:00Z"))
    assert db.count("experiments") == 1
    assert db.count("runs") == 1


def test_bulk_measurement_insert(db):
    db.insert_experiment(Experiment(experiment_id="e1", name="Test"))
    db.insert_run(Run(run_id="r1", experiment_id="e1", started_at="2026-01-01T00:00:00Z"))
    df = pd.DataFrame({
        "experiment_id": ["e1"] * 5, "run_id": ["r1"] * 5, "sensor_id": ["s1"] * 5,
        "variable": ["normalised_pressure"] * 5, "timestamp": pd.date_range("2026-01-01", periods=5, freq="s"),
        "value": [0.1, 0.2, 0.3, 0.4, 0.5], "unit": ["normalised"] * 5, "quality_flag": ["OK"] * 5,
        "uncertainty": [0.01] * 5, "source": ["test"] * 5,
    })
    db.insert_measurements(df)
    assert db.count("measurements") == 5


def test_prediction_provenance_traceability(db):
    db.insert_experiment(Experiment(experiment_id="e1", name="Test"))
    db.insert_run(Run(run_id="r1", experiment_id="e1", started_at="2026-01-01T00:00:00Z"))
    db.insert_model(ModelRecord(
        model_id="m1", model_name="random_forest", model_version="v1", dataset_version="d1",
        parameters={"k": 1}, random_seed=42, software_version="0.1.0",
    ))
    db.insert_prediction(PredictionRecord(
        prediction_id="p1", model_id="m1", run_id="r1", target="ignition_probability",
        value=0.8, lower_bound=0.6, upper_bound=0.95, confidence=0.95,
    ))
    provenance = db.prediction_provenance("p1")
    assert provenance["model_name"] == "random_forest"
    assert provenance["dataset_version"] == "d1"
    assert provenance["random_seed"] == 42


def test_integrity_check_clean_on_valid_data(db):
    db.insert_experiment(Experiment(experiment_id="e1", name="Test"))
    db.insert_run(Run(run_id="r1", experiment_id="e1", started_at="2026-01-01T00:00:00Z"))
    assert db.integrity_check() == []
