from src.digital_twin.twin import DigitalTwin
from src.engine.states import DigitalTwinState
from src.physics.relations import NormalisedState


def test_digital_twin_reaches_complete_on_matching_state():
    twin = DigitalTwin(tolerance=1.0)  # generous tolerance -> should reach COMPLETE
    state = NormalisedState(0.5, 0.5, 0.5, 0.5, 0.5)
    predicted = twin.physics_model.predicted_state_vector(state)
    result = twin.run(state, observed_state=predicted)  # perfect match -> zero residual
    assert result.within_tolerance
    assert twin.state == DigitalTwinState.COMPLETE


def test_digital_twin_flags_anomaly_on_large_mismatch():
    twin = DigitalTwin(tolerance=0.05)
    state = NormalisedState(0.9, 0.9, 0.9, 0.9, 0.9)
    observed = {"reaction_rate_proxy": 0.0, "energy_ratio": 0.0, "pressure_ratio": 0.0,
                "flow_ratio": 0.0, "delay_ratio": 1.0}
    twin.run(state, observed)
    assert twin.state in (DigitalTwinState.ANOMALY, DigitalTwinState.UNCERTAIN)


def test_digital_twin_state_history_is_recorded():
    twin = DigitalTwin(tolerance=0.5)
    state = NormalisedState(0.5, 0.5, 0.5, 0.5, 0.5)
    twin.run(state, twin.physics_model.predicted_state_vector(state))
    assert DigitalTwinState.INITIALISING in twin.history
    assert DigitalTwinState.RUNNING_SIMULATION in twin.history
    assert DigitalTwinState.ANALYSING in twin.history


def test_residual_report_empty_when_no_shared_keys():
    twin = DigitalTwin()
    state = NormalisedState(0.5, 0.5, 0.5, 0.5, 0.5)
    result = twin.run(state, observed_state={"unrelated_key": 1.0})
    assert result.residuals == {}
    assert not result.within_tolerance
