import numpy as np

from src.surrogate.surrogate import SurrogateModel


def _toy_data(n=200, seed=0):
    rng = np.random.default_rng(seed)
    X = rng.uniform(0, 1, size=(n, 2))
    y = X[:, 0] * 2 + X[:, 1] * 0.5 + rng.normal(0, 0.05, n)
    return X, y


def test_surrogate_fit_produces_validation_report():
    X, y = _toy_data()
    model = SurrogateModel(kind="random_forest", random_state=0).fit(X, y, feature_columns=["a", "b"])
    assert model.validation is not None
    assert model.validation.r2 > 0.5  # should recover a mostly-linear relationship


def test_surrogate_predict_shape():
    X, y = _toy_data()
    model = SurrogateModel(kind="gradient_boosting", random_state=0).fit(X, y, feature_columns=["a", "b"])
    preds = model.predict(X[:10])
    assert preds.shape == (10,)


def test_surrogate_predict_with_std_random_forest():
    X, y = _toy_data()
    model = SurrogateModel(kind="random_forest", random_state=0).fit(X, y, feature_columns=["a", "b"])
    mean, std = model.predict_with_std(X[:5])
    assert mean.shape == (5,)
    assert (std >= 0).all()


def test_surrogate_gaussian_process_returns_posterior_std():
    X, y = _toy_data(n=60)
    model = SurrogateModel(kind="gaussian_process", random_state=0).fit(X, y, feature_columns=["a", "b"])
    mean, std = model.predict_with_std(X[:5])
    assert (std >= 0).all()


def test_predict_before_fit_raises():
    model = SurrogateModel(kind="random_forest")
    try:
        model.predict(np.zeros((1, 2)))
        assert False, "expected RuntimeError"
    except RuntimeError:
        pass
