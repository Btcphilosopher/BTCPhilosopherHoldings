from src.api.engine import H2IgnitionEngine
from src.api.visualization import VisualisationDataAPI
from src.engine.config import EngineConfig


def test_engine_initialises_all_subsystems(tmp_path):
    config = EngineConfig(database_path=str(tmp_path / "db.sqlite"))
    engine = H2IgnitionEngine(config)
    for attr in ("data", "features", "models", "optimisation", "timeseries", "event_detector",
                 "physics", "reliability", "uncertainty", "monte_carlo", "anomaly",
                 "experimental_design", "reports", "database"):
        assert hasattr(engine, attr)
    engine.database.close()


def test_preprocess_returns_clean_frame(tmp_path, synthetic_bundle):
    config = EngineConfig(database_path=str(tmp_path / "db.sqlite"))
    engine = H2IgnitionEngine(config)
    dataset = engine.data.load_dataframe(synthetic_bundle.measurements, name="test")
    clean = engine.preprocess(dataset)
    assert len(clean) > 0
    assert len(clean) <= len(synthetic_bundle.measurements)
    engine.database.close()


def test_full_train_predict_flow(tmp_path, synthetic_bundle):
    config = EngineConfig(database_path=str(tmp_path / "db.sqlite"))
    engine = H2IgnitionEngine(config)
    dataset = engine.data.load_dataframe(synthetic_bundle.measurements, name="test")
    clean = engine.preprocess(dataset)
    features = engine.features.extract(clean, run_metadata=synthetic_bundle.run_metadata)
    cols = [c for c in features.columns if "__" in c and features[c].notna().all()]
    model = engine.models.train(features, cols)
    prediction = model.predict(features)
    assert prediction.prediction.shape == (len(features),)
    summary = engine.optimisation.analyse(model)
    assert "metrics" in summary
    engine.database.close()


def test_visualisation_api_builds_from_none_gracefully():
    bundle = VisualisationDataAPI().build()
    d = bundle.to_dict()
    assert d["time_series"] == {}
    assert d["pareto_front"] == []
