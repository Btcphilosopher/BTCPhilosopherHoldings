import numpy as np

from src.anomaly.engine import AnomalyEngine


def test_anomaly_engine_flags_injected_outliers():
    rng = np.random.default_rng(0)
    normal = rng.normal(0, 1, size=(190, 5))
    outliers = rng.normal(8, 1, size=(10, 5))
    X = np.vstack([normal, outliers])
    run_ids = [f"run_{i}" for i in range(len(X))]

    report = AnomalyEngine(contamination=0.05, random_state=0).detect(run_ids, X)
    assert report.anomaly_score.shape == (200,)
    # Most of the injected outliers should be among the top-flagged anomalies.
    outlier_scores = report.anomaly_score[190:]
    normal_scores = report.anomaly_score[:190]
    assert outlier_scores.mean() > normal_scores.mean()


def test_anomaly_score_bounded_and_flags_boolean():
    rng = np.random.default_rng(1)
    X = rng.normal(size=(100, 4))
    report = AnomalyEngine(contamination=0.1, random_state=0).detect([f"r{i}" for i in range(100)], X)
    assert report.is_anomalous.dtype == bool
    assert (report.anomaly_score >= 0).all()
