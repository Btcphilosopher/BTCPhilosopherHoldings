from src.engine.states import IgnitionEventLabel


def test_event_labels_are_valid(event_results):
    valid = {e.value for e in IgnitionEventLabel}
    for result in event_results.values():
        assert result.label.value in valid
        assert 0.0 <= result.confidence <= 1.0
        assert 0.0 <= result.signal_quality <= 1.0


def test_detector_broadly_agrees_with_synthetic_ground_truth(synthetic_bundle, event_results):
    truth = synthetic_bundle.run_metadata.set_index("run_id")["ignited"]
    agreements = []
    for run_id, result in event_results.items():
        if run_id not in truth.index:
            continue
        predicted_ignited = result.label.value in ("IGNITION_EVENT", "ABNORMAL_EVENT")
        agreements.append(predicted_ignited == truth.loc[run_id])
    agreement_rate = sum(agreements) / len(agreements)
    # The detector should be substantially better than chance on this synthetic set.
    assert agreement_rate > 0.6


def test_flat_noise_is_never_classified_as_a_confident_event():
    """Pure sensor noise (no real rise) must never be reported as a confident
    IGNITION_EVENT or ABNORMAL_EVENT — at most NO_EVENT or a low-confidence
    AMBIGUOUS (occasional >1.5-sigma noise excursions are statistically normal)."""
    from src.events.ignition_detector import IgnitionEventDetector
    import pandas as pd
    import numpy as np

    for seed in range(5):
        rng = np.random.default_rng(seed)
        ts = pd.date_range("2026-01-01", periods=50, freq="10ms", tz="UTC")
        flat = pd.DataFrame({
            "timestamp": ts,
            "normalised_optical_intensity": 0.1 + 0.01 * rng.standard_normal(50),
            "normalised_electrical_signal": 0.1 + 0.01 * rng.standard_normal(50),
        })
        result = IgnitionEventDetector().detect("flat_run", flat)
        assert result.label in (IgnitionEventLabel.NO_EVENT, IgnitionEventLabel.AMBIGUOUS), (
            f"seed={seed} produced {result.label} on pure noise"
        )
        if result.label == IgnitionEventLabel.NO_EVENT:
            assert result.event_time is None
