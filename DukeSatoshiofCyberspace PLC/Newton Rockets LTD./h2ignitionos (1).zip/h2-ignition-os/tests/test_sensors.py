from src.sensors.synthetic import SENSOR_SPECS, generate_experiment


def test_generated_bundle_has_expected_shape():
    bundle = generate_experiment(n_runs=25, seed=5)
    assert bundle.source_label == "SYNTHETIC SIMULATION"
    assert set(bundle.run_metadata["run_id"]) == set(bundle.measurements["run_id"].unique())
    assert len(bundle.run_metadata) == 25


def test_all_measurement_variables_are_normalised():
    bundle = generate_experiment(n_runs=10, seed=5)
    variables = set(bundle.measurements["variable"].unique())
    assert all(v.startswith("normalised_") for v in variables)
    expected = {spec["variable"] for spec in SENSOR_SPECS.values()}
    assert variables == expected


def test_measurement_values_within_plausible_envelope():
    bundle = generate_experiment(n_runs=10, seed=5)
    assert bundle.measurements["value"].between(-0.5, 1.5).all()


def test_ignited_runs_have_a_true_ignition_time():
    bundle = generate_experiment(n_runs=200, seed=5)
    ignited = bundle.run_metadata[bundle.run_metadata["ignited"]]
    not_ignited = bundle.run_metadata[~bundle.run_metadata["ignited"]]
    assert ignited["true_ignition_time"].notna().all()
    assert not_ignited["true_ignition_time"].isna().all()
