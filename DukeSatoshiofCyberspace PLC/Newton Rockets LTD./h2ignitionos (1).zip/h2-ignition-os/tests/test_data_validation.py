import numpy as np
import pandas as pd

from src.data.loader import DataLoader
from src.data.validation import DataValidator


def _minimal_frame() -> pd.DataFrame:
    ts = pd.date_range("2026-01-01", periods=10, freq="1s", tz="UTC")
    return pd.DataFrame({
        "experiment_id": "exp_1", "timestamp": ts, "run_id": "run_1",
        "sensor_id": "pressure_1", "variable": "normalised_pressure",
        "value": np.linspace(0.1, 0.5, 10), "unit": "normalised",
        "quality_flag": "OK", "uncertainty": 0.01, "source": "test",
    })


def test_missing_values_flagged():
    df = _minimal_frame()
    df.loc[3, "value"] = np.nan
    report = DataValidator().validate(df)
    assert any(i.kind == "missing_value" and i.count == 1 for i in report.issues)
    assert len(report.clean_frame) == len(df) - 1


def test_duplicate_timestamps_flagged():
    df = _minimal_frame()
    dup = df.iloc[[0]].copy()
    df = pd.concat([df, dup], ignore_index=True)
    report = DataValidator().validate(df)
    assert any(i.kind == "duplicate_timestamp" for i in report.issues)


def test_impossible_values_flagged():
    df = _minimal_frame()
    df.loc[0, "value"] = 999.0
    report = DataValidator().validate(df)
    assert any(i.kind == "impossible_value" for i in report.issues)
    assert 999.0 not in report.clean_frame["value"].to_numpy()


def test_corrupted_records_flagged_and_dropped():
    df = _minimal_frame()
    df.loc[0, "quality_flag"] = "BAD"
    report = DataValidator().validate(df)
    assert any(i.kind == "corrupted_record" for i in report.issues)
    assert "BAD" not in report.clean_frame["quality_flag"].values


def test_clean_data_has_no_issues():
    df = _minimal_frame()
    report = DataValidator().validate(df)
    # A tidy, monotonic, single-rate frame should not trip dropout/rate/drift checks.
    kinds = {i.kind for i in report.issues}
    assert kinds.isdisjoint({"sensor_dropout", "clock_drift", "missing_value", "corrupted_record"})


def test_loader_rejects_missing_required_columns():
    df = _minimal_frame().drop(columns=["value"])
    try:
        DataLoader().load_dataframe(df)
        assert False, "expected ValueError"
    except ValueError:
        pass


def test_synthetic_dataset_round_trip(clean_frame):
    assert len(clean_frame) > 0
    assert set(["experiment_id", "run_id", "sensor_id", "variable", "value"]).issubset(clean_frame.columns)
