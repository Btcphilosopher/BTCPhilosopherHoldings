# H2-IGNITION.OS

**Hydrogen Ignition Research, Digital Twin & Optimisation Platform**

H2-IGNITION.OS is a research, simulation, and experimental-data-analysis platform for
studying the *software-defined* behaviour of hydrogen ignition systems used in aerospace
propulsion **research**. It is a scientific analytics stack — not a control system.

## What this is

- A modular Python research platform for ignition-probability modelling, ignition-delay
  statistics, reliability/repeatability analysis, anomaly detection, uncertainty
  quantification, surrogate modelling, multi-objective optimisation, active experimental
  design, and digital-twin residual analysis.
- Built around **normalised / dimensionless variables** (`normalised_temperature`,
  `normalised_pressure`, `normalised_flow`, `normalised_energy`,
  `normalised_mixture_state`, `normalised_transient_time`) rather than real hardware
  settings.
- Driven entirely by supplied experimental datasets or clearly-labelled **synthetic**
  data generated for research/testing purposes.

## What this explicitly is NOT

See [`docs/SAFETY.md`](docs/SAFETY.md). In summary, this repository contains **no**:

- ignition-system construction or hardware-assembly instructions,
- explosive/pyrotechnic recipes,
- operational rocket-engine firing sequences or real-world ignition-control commands,
- actuator commands or automatic physical ignition control,
- instructions for bypassing safety systems.

All numerical outputs are statistical/ML predictions over abstract, normalised state —
never guarantees of physical behaviour, and never real hardware setpoints.

## Architecture

```
                    H2-IGNITION.OS
                           |
          +----------------+----------------+
          |                |                |
          v                v                v
     DATA ENGINE       PHYSICS MODEL    EXPERIMENT ENGINE
          |                |                |
          v                v                v
      SENSOR DATA     IGNITION MODEL    TEST DATABASE
          |                |                |
          +--------+-------+-------+--------+
                   |
                   v
             FEATURE ENGINE
                   |
                   v
             ML / SURROGATE
                   |
                   v
             OPTIMISATION
                   |
          +--------+---------+
          |                  |
          v                  v
     RELIABILITY        UNCERTAINTY
       ENGINE             ENGINE
          |                  |
          +--------+---------+
                   |
                   v
             DIGITAL TWIN
                   |
                   v
             REPORT ENGINE
```

Each subsystem lives under `src/` as an independent, testable module. See
`docs/ARCHITECTURE.md` for a module-by-module description.

## Quick start

```bash
python3 -m pip install -r requirements.txt

# Run the full synthetic demonstration (generates data, trains models,
# runs the digital twin and optimiser, and writes a scientific report)
PYTHONPATH=. python3 examples/demo.py

# Run the test suite
PYTHONPATH=. python3 -m pytest tests/ -q

# Run benchmarks
PYTHONPATH=. python3 benchmarks/benchmark.py
```

## API sketch

```python
from src.api.engine import H2IgnitionEngine

engine = H2IgnitionEngine()

dataset = engine.data.load("synthetic_data/demo_experiment.parquet")
clean = engine.preprocess(dataset)
features = engine.features.extract(clean)
model = engine.models.train(features)
prediction = model.predict(experimental_state)
report = engine.optimisation.analyse(model)
```

The API (`src/api/`) is intentionally decoupled from any future GUI/frontend; see
`src/api/visualization.py` for the structured data contract a dashboard would consume.

## Project layout

```
h2-ignition-os/
├── src/
│   ├── engine/        configuration, logging, reproducibility, versioning
│   ├── data/           canonical schema, loaders, validation, quality reports
│   ├── sensors/        abstract sensor models + synthetic sensor generation
│   ├── events/         time-series engine + ignition-event detector
│   ├── physics/        normalised, qualitative physics-informed relations
│   ├── features/       feature engineering
│   ├── models/         ignition-probability + ignition-delay statistical models
│   ├── surrogate/      fast surrogate models of the simulator
│   ├── optimisation/   multi-objective optimisation / Pareto search
│   ├── reliability/    reliability & repeatability statistics
│   ├── uncertainty/    uncertainty quantification + Monte Carlo engine
│   ├── anomaly/        anomaly detection
│   ├── digital_twin/   digital-twin state machine + residual analysis
│   ├── experiments/    experimental-design engine + domain objects
│   ├── storage/        experiment database (SQLite)
│   ├── reports/        scientific report generation
│   └── api/            public Python API + visualisation data contract
├── tests/               pytest suite (synthetic data only)
├── examples/            end-to-end synthetic demonstration
├── configs/             default configuration
├── synthetic_data/      generated synthetic datasets (demo output)
├── notebooks/           exploratory notebook
├── benchmarks/          performance benchmarks
└── docs/                architecture & safety documentation
```

## Disclaimer

All example outputs are produced from **synthetic** data and are clearly labelled
`SYNTHETIC SIMULATION`. Software benchmark timings measure this codebase only and must
never be interpreted as physical engine performance.
