#!/usr/bin/env python3
"""Performance benchmarks for H2-IGNITION.OS.

Measures this software's own computational performance on synthetic data. These are
SOFTWARE benchmarks only — timings here say nothing about, and must never be
interpreted as, physical propulsion-system or hardware performance.
"""
from __future__ import annotations

import json
import time
from pathlib import Path
from statistics import mean, stdev

import numpy as np

from src.anomaly.engine import AnomalyEngine
from src.data.loader import DataLoader
from src.data.validation import DataValidator
from src.digital_twin.twin import DigitalTwin
from src.events.ignition_detector import IgnitionEventDetector
from src.events.timeseries import TimeSeriesEngine
from src.features.extraction import FeatureEngine
from src.models.ignition_probability import train_ignition_probability_model
from src.optimisation.engine import ObjectiveVector, OptimisationEngine
from src.physics.relations import NormalisedState, PhysicsInformedModel
from src.sensors.synthetic import generate_experiment
from src.uncertainty.monte_carlo import MonteCarloEngine

ROOT = Path(__file__).resolve().parents[1]
N_RUNS = 200
N_REPEATS = 3


def timed(fn, *args, repeats: int = N_REPEATS, **kwargs):
    times = []
    result = None
    for _ in range(repeats):
        t0 = time.perf_counter()
        result = fn(*args, **kwargs)
        times.append(time.perf_counter() - t0)
    return result, times


def summarise(name: str, times: list[float], n_items: int) -> dict:
    m = mean(times)
    s = stdev(times) if len(times) > 1 else 0.0
    return {
        "benchmark": name, "n_items": n_items, "repeats": len(times),
        "mean_s": round(m, 4), "std_s": round(s, 4),
        "items_per_s": round(n_items / m, 1) if m > 0 else float("inf"),
    }


def main() -> list[dict]:
    print("H2-IGNITION.OS BENCHMARKS")
    print("=" * 40)
    print("Software performance only. No result here describes physical hardware.\n")

    results: list[dict] = []
    bundle = generate_experiment(n_runs=N_RUNS, seed=1)

    # 1. Data ingestion
    _, times = timed(lambda: DataLoader().load_dataframe(bundle.measurements, name="bench"))
    results.append(summarise("data_ingestion", times, len(bundle.measurements)))

    dataset = DataLoader().load_dataframe(bundle.measurements, name="bench")
    _, times = timed(lambda: DataValidator().validate(dataset.to_frame()), repeats=N_REPEATS)
    results.append(summarise("data_validation", times, len(bundle.measurements)))

    clean = DataValidator().validate(dataset.to_frame()).clean_frame

    # 2. Event detection
    tse, detector = TimeSeriesEngine(), IgnitionEventDetector()

    def run_event_detection():
        out = {}
        for run_id, g in clean.groupby("run_id"):
            aligned = tse.align_to_canonical_timeline(g, target_rate_hz=100)
            out[run_id] = detector.detect(run_id, aligned)
        return out

    event_results, times = timed(run_event_detection, repeats=1)
    results.append(summarise("event_detection", times, N_RUNS))

    # 3. Feature extraction
    _, times = timed(lambda: FeatureEngine().extract(clean, run_metadata=bundle.run_metadata, event_results=event_results), repeats=1)
    results.append(summarise("feature_extraction", times, N_RUNS))
    features = FeatureEngine().extract(clean, run_metadata=bundle.run_metadata, event_results=event_results)

    predictor_cols = [c for c in features.columns if "__" in c and features[c].notna().all()][:20]
    model = train_ignition_probability_model(features, predictor_cols, model_name="random_forest", random_state=0)

    # 4. Model inference
    _, times = timed(lambda: model.predict(features))
    results.append(summarise("model_inference", times, len(features)))

    # 5. Monte Carlo
    mc = MonteCarloEngine(seed=0)
    prediction = model.predict(features)
    _, times = timed(lambda: mc.failure_probability(prediction.prediction))
    results.append(summarise("monte_carlo_failure_probability", times, len(prediction.prediction)))

    # 6. Optimisation (Latin-hypercube + Pareto front)
    def toy_objective(point):
        x = point["x"]
        return ObjectiveVector(x, (1 - x) ** 2, 0.1, x, 0.05, 0.1)

    opt_engine = OptimisationEngine(n_lhs_samples=200, random_state=0)
    _, times = timed(lambda: opt_engine.evaluate({"x": (0.0, 1.0)}, toy_objective), repeats=N_REPEATS)
    results.append(summarise("optimisation_evaluate", times, 200))

    # 7. Digital twin update
    physics = PhysicsInformedModel()
    state = NormalisedState(0.5, 0.5, 0.5, 0.5, 0.5)
    observed = physics.predicted_state_vector(state)

    def run_twin_updates(n=200):
        for _ in range(n):
            DigitalTwin(tolerance=0.3).run(state, observed)

    _, times = timed(lambda: run_twin_updates(200), repeats=N_REPEATS)
    results.append(summarise("digital_twin_update", times, 200))

    # 8. Anomaly detection
    anomaly_cols = [c for c in features.columns if "__" in c and features[c].notna().all()]
    X = features[anomaly_cols].to_numpy(dtype=float)
    anomaly_engine = AnomalyEngine(random_state=0)
    _, times = timed(lambda: anomaly_engine.detect(features["run_id"].tolist(), X), repeats=N_REPEATS)
    results.append(summarise("anomaly_detection", times, len(features)))

    print(f"{'benchmark':30s} {'n_items':>10s} {'mean_s':>10s} {'std_s':>10s} {'items/s':>12s}")
    print("-" * 76)
    for r in results:
        print(f"{r['benchmark']:30s} {r['n_items']:>10d} {r['mean_s']:>10.4f} {r['std_s']:>10.4f} {r['items_per_s']:>12.1f}")

    print("\nIMPORTANT: these are software wall-clock measurements on synthetic data, "
          "run on this machine, on this run. They are NOT a measure of physical "
          "propulsion-system or hardware performance.")

    out_path = ROOT / "benchmarks" / "last_run_results.json"
    out_path.write_text(json.dumps(results, indent=2))
    print(f"\nResults written to {out_path}")
    return results


if __name__ == "__main__":
    main()
