package com.example.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.*
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlin.math.*
import kotlin.random.Random

class NewtonViewModel(application: Application) : AndroidViewModel(application) {

    private val dao = AppDatabase.getDatabase(application).newtonDao()

    // ----------------------------------------------------
    // APP NAVIGATION & SESSION STATE
    // ----------------------------------------------------
    val currentScreen = MutableStateFlow("dashboard") // dashboard, configurator, control, telemetry, docs, account
    val selectedOrganizationId = MutableStateFlow(1) // Default to first seeded org
    val selectedRole = MutableStateFlow("MISSION_MANAGER") // CUSTOMER_ADMIN, MISSION_MANAGER, ENGINEER, VIEWER, NEWTON_OPERATOR, NEWTON_ADMIN

    // Database reactive streams
    val organisations = dao.getAllOrganisations().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val allSpacecraft = dao.getAllSpacecraft().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val missions = dao.getAllMissions().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val auditLogs = dao.getAuditLogs().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Currently focused mission for tracking / simulation
    val selectedMissionId = MutableStateFlow<Int?>(null)
    
    // Derived selected mission
    val activeMission: StateFlow<MissionEntity?> = selectedMissionId
        .flatMapLatest { id ->
            if (id != null) dao.getMissionFlow(id) else flowOf(null)
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    // Derived active spacecraft for focused mission
    val activeSpacecraft = activeMission.map { mission ->
        if (mission != null) dao.getSpacecraftById(mission.spacecraftId) else null
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    // Active mission telemetry and events
    val activeTelemetry = selectedMissionId.flatMapLatest { id ->
        if (id != null) dao.getTelemetryForMission(id) else flowOf(emptyList())
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val activeEvents = selectedMissionId.flatMapLatest { id ->
        if (id != null) dao.getEventsForMission(id) else flowOf(emptyList())
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val activeDocuments = selectedMissionId.flatMapLatest { id ->
        if (id != null) dao.getDocumentsForMission(id) else flowOf(emptyList())
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // ----------------------------------------------------
    // MULTI-STAGE CONFIGURATOR STATE
    // ----------------------------------------------------
    val configSpacecraftName = MutableStateFlow("Aureom-1B")
    val configSpacecraftMass = MutableStateFlow("180") // kg
    val configSpacecraftWidth = MutableStateFlow("0.6") // m
    val configSpacecraftHeight = MutableStateFlow("0.8") // m
    val configSpacecraftDepth = MutableStateFlow("0.6") // m
    val configSpacecraftPower = MutableStateFlow("250") // W
    val configSpacecraftClass = MutableStateFlow(SpacecraftClass.SMALLSAT)
    val configDeploymentMechanism = MutableStateFlow("Pneumatic Push Plate")

    val configOrbitType = MutableStateFlow(OrbitType.LEO)
    val configAltitudeKm = MutableStateFlow(500.0)
    val configInclinationDeg = MutableStateFlow(51.6)
    val configEccentricity = MutableStateFlow(0.0)
    val configRaanDeg = MutableStateFlow(90.0)
    val configArgOfPerigeeDeg = MutableStateFlow(45.0)

    val configSelectedVehicle = MutableStateFlow("N-1")
    val configSelectedSite = MutableStateFlow("shetland")

    // Dynamic quote calculation
    val calculatedQuote = combine(
        listOf(
            configSelectedVehicle,
            configSelectedSite,
            configSpacecraftMass,
            configAltitudeKm,
            configInclinationDeg,
            configSpacecraftClass
        )
    ) { array ->
        val veh = array[0] as String
        val site = array[1] as String
        val massStr = array[2] as String
        val alt = array[3] as Double
        val inc = array[4] as Double
        val sClass = array[5] as SpacecraftClass
        
        val mass = massStr.toDoubleOrNull() ?: 100.0
        QuoteEngine.calculateQuote(veh, site, mass, alt, inc, sClass)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), QuoteEngine.calculateQuote("N-1", "shetland", 100.0, 500.0, 51.6, SpacecraftClass.SMALLSAT))

    // ----------------------------------------------------
    // LIVE SIMULATION CLOCK & CONTROLLER
    // ----------------------------------------------------
    private var simulationJob: Job? = null
    val simIsRunning = MutableStateFlow(false)
    val simSpeedMultiplier = MutableStateFlow(1) // Time compression warp: 1x, 10x, 100x, 1000x, 10000x
    val simElapsedSeconds = MutableStateFlow(0L)
    val simTimeLabel = MutableStateFlow("T+00:00:00")
    
    // Simulated Anomaly states
    val anomalyTelemetryDrop = MutableStateFlow(false)
    val anomalyContactLoss = MutableStateFlow(false)
    val anomalyThermalWarning = MutableStateFlow(false)
    val anomalyPowerWarning = MutableStateFlow(false)

    // Fictional weather based on catalog sites
    val simulatedWeather = configSelectedSite.map { siteId ->
        generateFictionalWeather(siteId)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), generateFictionalWeather("shetland"))

    init {
        // Automatic Seeding of High-Fidelity Fictional Aerospace Logistics Data
        seedDatabaseIfNeeded()
    }

    private fun seedDatabaseIfNeeded() {
        viewModelScope.launch {
            val existingOrgs = organisations.value
            if (existingOrgs.isEmpty()) {
                // Seed Organizations
                val org1Id = dao.insertOrganisation(OrganisationEntity(name = "Aureom Imaging Ltd.", code = "AUREOM"))
                val org2Id = dao.insertOrganisation(OrganisationEntity(name = "North Atlantic Earth Observation", code = "NAEO"))
                val org3Id = dao.insertOrganisation(OrganisationEntity(name = "British Orbital Research", code = "BOR"))
                val org4Id = dao.insertOrganisation(OrganisationEntity(name = "Yorkshire Space Systems", code = "YSS"))
                val org5Id = dao.insertOrganisation(OrganisationEntity(name = "Cambridge Atmospheric Lab", code = "CAMBRIDGE"))

                dao.insertAuditLog(AuditLogEntity(actor = "SYSTEM", action = "DB_INITIALIZE", details = "Preloaded 5 corporate and governmental customer entities."))

                // Seed Spacecraft
                val sc1Id = dao.insertSpacecraft(SpacecraftEntity(
                    name = "Aureom-1A",
                    massKg = 150.0, widthM = 0.5, heightM = 0.5, depthM = 0.7, powerW = 200.0,
                    spacecraftClass = SpacecraftClass.SMALLSAT.name,
                    deploymentMechanism = "Separation Clampband",
                    organisationId = org1Id.toInt(),
                    altitudeKm = 520.0, inclinationDeg = 97.5, eccentricity = 0.0002, raanDeg = 180.0, argOfPerigeeDeg = 0.0
                ))

                val sc2Id = dao.insertSpacecraft(SpacecraftEntity(
                    name = "NAEO-Horizon-3",
                    massKg = 450.0, widthM = 1.2, heightM = 1.2, depthM = 1.5, powerW = 850.0,
                    spacecraftClass = SpacecraftClass.EARTH_OBSERVATION.name,
                    deploymentMechanism = "Heavy Clampband",
                    organisationId = org2Id.toInt(),
                    altitudeKm = 650.0, inclinationDeg = 98.2, eccentricity = 0.001, raanDeg = 45.0, argOfPerigeeDeg = 90.0
                ))

                val sc3Id = dao.insertSpacecraft(SpacecraftEntity(
                    name = "AtmoSentry-Cube",
                    massKg = 12.0, widthM = 0.2, heightM = 0.2, depthM = 0.3, powerW = 35.0,
                    spacecraftClass = SpacecraftClass.CUBESAT.name,
                    deploymentMechanism = "CubeSat Dispenser Pod",
                    organisationId = org5Id.toInt(),
                    altitudeKm = 400.0, inclinationDeg = 51.6, eccentricity = 0.0, raanDeg = 320.0, argOfPerigeeDeg = 180.0
                ))

                dao.insertAuditLog(AuditLogEntity(actor = "SYSTEM", action = "SEED_SPACECRAFT", details = "Seeded academic, defense, and imaging spacecraft payloads."))

                // Seed Missions
                val m1Id = dao.insertMission(MissionEntity(
                    name = "AUREOM-LIGHT-01",
                    spacecraftId = sc1Id.toInt(),
                    launchVehicleId = "N-1",
                    launchSiteId = "shetland",
                    currentState = "ACTIVE_ORBIT",
                    quotePriceGbp = 4_250_000.0,
                    bookedTime = System.currentTimeMillis() - 86400000L * 10,
                    isCompleted = true,
                    docApproved = true, specApproved = true, massConfirmed = true, orbitConfirmed = true,
                    integrationComplete = true, safetyReviewApproved = true, missionReviewApproved = true, launchAuthorityApproved = true
                ))

                // Prepopulate telemetry for completed mission m1Id to make charts populated initially
                seedHistoricalTelemetry(m1Id.toInt(), OrbitParameters.SSO_PRESET)

                val m2Id = dao.insertMission(MissionEntity(
                    name = "NAEO-OCEANIC-3",
                    spacecraftId = sc2Id.toInt(),
                    launchVehicleId = "N-2",
                    launchSiteId = "ocean",
                    currentState = "INTEGRATION",
                    quotePriceGbp = 9_850_000.0,
                    bookedTime = System.currentTimeMillis() - 86400000L * 2,
                    isCompleted = false,
                    docApproved = true, specApproved = true, massConfirmed = true, orbitConfirmed = true,
                    integrationComplete = false, safetyReviewApproved = false, missionReviewApproved = false, launchAuthorityApproved = false
                ))

                // Create initial files for Documents
                createDefaultDocuments(m1Id.toInt())
                createDefaultDocuments(m2Id.toInt())

                // Select m2Id by default to view
                selectedMissionId.value = m2Id.toInt()
            }
        }
    }

    private suspend fun seedHistoricalTelemetry(missionId: Int, orbit: OrbitParameters) {
        val count = 40
        val baseTime = System.currentTimeMillis() - 3600000L
        for (i in 0 until count) {
            val elapsedSec = i * 300.0
            val state = OrbitalPropagator.propagate(orbit, elapsedSec)
            dao.insertTelemetryPoint(TelemetryPointEntity(
                missionId = missionId,
                timestamp = baseTime + (i * 300_000L),
                phase = "ORBIT",
                altitudeKm = state.altitudeKm,
                velocityKms = state.velocityKms,
                latitudeDeg = state.latitudeDeg,
                longitudeDeg = state.longitudeDeg,
                inclinationDeg = orbit.inclinationDeg,
                batteryPercent = 90.0 + sin(i / 5.0) * 8.0,
                temperatureC = 15.0 + cos(i / 3.0) * 12.0,
                signalDb = -72.0 + (i % 5) * 2.0
            ))
        }
        dao.insertMissionEvent(MissionEventEntity(
            missionId = missionId,
            timestamp = baseTime,
            elapsedSeconds = 0,
            title = "LIFTOFF",
            description = "Main engines ignited. Nominal vertical ascent trajectory.",
            severity = "SUCCESS"
        ))
        dao.insertMissionEvent(MissionEventEntity(
            missionId = missionId,
            timestamp = baseTime + 600_000L,
            elapsedSeconds = 600,
            title = "SPACECRAFT DEPLOYED",
            description = "Separation clampband fired. Spacecraft successfully inserted to target Sun-Synch orbital envelope.",
            severity = "SUCCESS"
        ))
    }

    private suspend fun createDefaultDocuments(missionId: Int) {
        dao.insertDocument(DocumentEntity(
            missionId = missionId,
            name = "Spacecraft Structural Specification",
            category = "Technical",
            status = "APPROVED",
            contentSummary = "Defines mechanical envelopes, vibration thresholds, and center of mass constraints."
        ))
        dao.insertDocument(DocumentEntity(
            missionId = missionId,
            name = "Orbital Safety Review Plan",
            category = "Safety",
            status = "UNDER_REVIEW",
            contentSummary = "Compliance evaluation regarding orbital debris prevention policies and collision avoidance protocol."
        ))
        dao.insertDocument(DocumentEntity(
            missionId = missionId,
            name = "Launch Logistics Agreement",
            category = "Legal",
            status = "SUBMITTED",
            contentSummary = "Operational liability insurance coverage clauses, transport schedules, and UK Space Agency launch licensing parameters."
        ))
    }

    // ----------------------------------------------------
    // USER ACTIONS
    // ----------------------------------------------------

    fun deleteSpacecraft(id: Int) {
        viewModelScope.launch {
            dao.deleteSpacecraft(id)
            dao.insertAuditLog(AuditLogEntity(actor = selectedRole.value, action = "DELETE_SPACECRAFT", details = "Removed spacecraft ID: $id"))
        }
    }

    fun applyPresetOrbit(preset: OrbitType) {
        configOrbitType.value = preset
        when (preset) {
            OrbitType.LEO -> {
                configAltitudeKm.value = OrbitParameters.LEO_PRESET.altitudeKm
                configInclinationDeg.value = OrbitParameters.LEO_PRESET.inclinationDeg
                configEccentricity.value = OrbitParameters.LEO_PRESET.eccentricity
                configRaanDeg.value = OrbitParameters.LEO_PRESET.raanDeg
                configArgOfPerigeeDeg.value = OrbitParameters.LEO_PRESET.argOfPerigeeDeg
            }
            OrbitType.SSO -> {
                configAltitudeKm.value = OrbitParameters.SSO_PRESET.altitudeKm
                configInclinationDeg.value = OrbitParameters.SSO_PRESET.inclinationDeg
                configEccentricity.value = OrbitParameters.SSO_PRESET.eccentricity
                configRaanDeg.value = OrbitParameters.SSO_PRESET.raanDeg
                configArgOfPerigeeDeg.value = OrbitParameters.SSO_PRESET.argOfPerigeeDeg
            }
            OrbitType.POLAR -> {
                configAltitudeKm.value = OrbitParameters.POLAR_PRESET.altitudeKm
                configInclinationDeg.value = OrbitParameters.POLAR_PRESET.inclinationDeg
                configEccentricity.value = OrbitParameters.POLAR_PRESET.eccentricity
                configRaanDeg.value = OrbitParameters.POLAR_PRESET.raanDeg
                configArgOfPerigeeDeg.value = OrbitParameters.POLAR_PRESET.argOfPerigeeDeg
            }
            OrbitType.EQUATORIAL -> {
                configAltitudeKm.value = OrbitParameters.EQUATORIAL_PRESET.altitudeKm
                configInclinationDeg.value = OrbitParameters.EQUATORIAL_PRESET.inclinationDeg
                configEccentricity.value = OrbitParameters.EQUATORIAL_PRESET.eccentricity
                configRaanDeg.value = OrbitParameters.EQUATORIAL_PRESET.raanDeg
                configArgOfPerigeeDeg.value = OrbitParameters.EQUATORIAL_PRESET.argOfPerigeeDeg
            }
            OrbitType.CUSTOM -> {}
        }
    }

    fun bookLaunchMission() {
        viewModelScope.launch {
            val mass = configSpacecraftMass.value.toDoubleOrNull() ?: 100.0
            val width = configSpacecraftWidth.value.toDoubleOrNull() ?: 0.5
            val height = configSpacecraftHeight.value.toDoubleOrNull() ?: 0.5
            val depth = configSpacecraftDepth.value.toDoubleOrNull() ?: 0.5
            val power = configSpacecraftPower.value.toDoubleOrNull() ?: 100.0

            // 1. Create Spacecraft entity
            val scId = dao.insertSpacecraft(SpacecraftEntity(
                name = configSpacecraftName.value,
                massKg = mass, widthM = width, heightM = height, depthM = depth, powerW = power,
                spacecraftClass = configSpacecraftClass.value.name,
                deploymentMechanism = configDeploymentMechanism.value,
                organisationId = selectedOrganizationId.value,
                altitudeKm = configAltitudeKm.value,
                inclinationDeg = configInclinationDeg.value,
                eccentricity = configEccentricity.value,
                raanDeg = configRaanDeg.value,
                argOfPerigeeDeg = configArgOfPerigeeDeg.value
            ))

            // 2. Create Mission entity
            val quote = calculatedQuote.value
            val mId = dao.insertMission(MissionEntity(
                name = "NEWTON-MT-${1000 + Random.nextInt(9000)}",
                spacecraftId = scId.toInt(),
                launchVehicleId = configSelectedVehicle.value,
                launchSiteId = configSelectedSite.value,
                currentState = "PLANNED",
                quotePriceGbp = quote.totalGbp,
                bookedTime = System.currentTimeMillis()
            ))

            // 3. Create Documents for mission
            createDefaultDocuments(mId.toInt())

            // 4. Record audit log
            dao.insertAuditLog(AuditLogEntity(
                actor = selectedRole.value,
                action = "BOOK_MISSION",
                details = "Successfully configured mission payload: '${configSpacecraftName.value}' with vehicle ${configSelectedVehicle.value} from ${configSelectedSite.value} Range. Valuation: £${"%,.2f".format(quote.totalGbp)}"
            ))

            // Go to dashboard to see upcoming launch
            selectedMissionId.value = mId.toInt()
            currentScreen.value = "dashboard"
        }
    }

    fun updateChecklistField(field: String, value: Boolean) {
        val mission = activeMission.value ?: return
        viewModelScope.launch {
            val updated = when (field) {
                "docApproved" -> mission.copy(docApproved = value)
                "specApproved" -> mission.copy(specApproved = value)
                "massConfirmed" -> mission.copy(massConfirmed = value)
                "orbitConfirmed" -> mission.copy(orbitConfirmed = value)
                "integrationComplete" -> mission.copy(integrationComplete = value)
                "safetyReviewApproved" -> mission.copy(safetyReviewApproved = value)
                "missionReviewApproved" -> mission.copy(missionReviewApproved = value)
                "launchAuthorityApproved" -> mission.copy(launchAuthorityApproved = value)
                else -> mission
            }
            dao.insertMission(updated)
            dao.insertAuditLog(AuditLogEntity(
                actor = selectedRole.value,
                action = "CHECKLIST_UPDATE",
                details = "Set readiness checklist field '$field' to $value for mission ${mission.name}"
            ))
        }
    }

    // ----------------------------------------------------
    // DIGITAL TWIN PROPAGATOR WORKER
    // ----------------------------------------------------

    fun startMissionSimulation() {
        val mission = activeMission.value ?: return
        val spacecraft = activeSpacecraft.value ?: return
        
        // Checklist gating rule: Must confirm basic safety parameters to clear launch
        val isClearedToLaunch = mission.docApproved && mission.specApproved && mission.massConfirmed && 
                               mission.orbitConfirmed && mission.integrationComplete && mission.safetyReviewApproved
        
        if (!isClearedToLaunch && mission.currentState == "PLANNED") {
            // Log warning about checklist constraint
            viewModelScope.launch {
                dao.insertMissionEvent(MissionEventEntity(
                    missionId = mission.id,
                    timestamp = System.currentTimeMillis(),
                    elapsedSeconds = 0,
                    title = "LAUNCH ABORTED",
                    description = "Preflight safety checklists not fully approved. Vehicle ignition prevented by ground system interlocks.",
                    severity = "ALERT"
                ))
            }
            return
        }

        // Cancel previous running simulation
        simulationJob?.cancel()
        simIsRunning.value = true
        simElapsedSeconds.value = 0L

        simulationJob = viewModelScope.launch {
            // Clean dynamic simulation tables
            dao.clearTelemetryForMission(mission.id)
            dao.clearEventsForMission(mission.id)
            
            val orbit = OrbitParameters(
                altitudeKm = spacecraft.altitudeKm,
                inclinationDeg = spacecraft.inclinationDeg,
                eccentricity = spacecraft.eccentricity,
                raanDeg = spacecraft.raanDeg,
                argOfPerigeeDeg = spacecraft.argOfPerigeeDeg
            )

            // Dynamic launch state machine iteration
            var currentState = "COUNTDOWN"
            dao.insertMission(mission.copy(currentState = "COUNTDOWN", isCompleted = false))
            
            // Add initial log
            dao.insertMissionEvent(MissionEventEntity(
                missionId = mission.id,
                timestamp = System.currentTimeMillis(),
                elapsedSeconds = 0,
                title = "COUNTDOWN START",
                description = "Automated terminal count initiated. Weather state: GO.",
                severity = "INFO"
            ))

            var seconds = -10L // starts at T-10 seconds
            val rand = Random(42)

            while (simIsRunning.value) {
                val speed = simSpeedMultiplier.value
                simElapsedSeconds.value = max(0L, seconds)
                
                // Format clock
                simTimeLabel.value = if (seconds < 0) "T${seconds}s" else "T+${formatTime(seconds)}"

                // State transitions & events triggering
                if (seconds == 0L) {
                    currentState = "LAUNCH"
                    dao.insertMission(activeMission.value!!.copy(currentState = "LAUNCH"))
                    dao.insertMissionEvent(MissionEventEntity(
                        missionId = mission.id,
                        timestamp = System.currentTimeMillis() + (seconds * 1000L),
                        elapsedSeconds = seconds,
                        title = "LIFTOFF",
                        description = "Engine ignition confirmed. Newton launch vehicle has cleared the tower. Nominal telemetry uplink established.",
                        severity = "SUCCESS"
                    ))
                } else if (seconds == 60L) {
                    currentState = "ASCENT"
                    dao.insertMission(activeMission.value!!.copy(currentState = "ASCENT"))
                    dao.insertMissionEvent(MissionEventEntity(
                        missionId = mission.id,
                        timestamp = System.currentTimeMillis() + (seconds * 1000L),
                        elapsedSeconds = seconds,
                        title = "MAX Q ENCOUNTERED",
                        description = "Vehicle passing through region of maximum dynamic pressure.",
                        severity = "INFO"
                    ))
                } else if (seconds == 150L) {
                    dao.insertMissionEvent(MissionEventEntity(
                        missionId = mission.id,
                        timestamp = System.currentTimeMillis() + (seconds * 1000L),
                        elapsedSeconds = seconds,
                        title = "MECO & STAGE SEPARATION",
                        description = "Main Engine Cut-Off. Booster stage successfully jettisoned. Vacuum stage ignition nominal.",
                        severity = "SUCCESS"
                    ))
                } else if (seconds == 400L) {
                    currentState = "ORBITAL_INSERTION"
                    dao.insertMission(activeMission.value!!.copy(currentState = "ORBITAL_INSERTION"))
                    dao.insertMissionEvent(MissionEventEntity(
                        missionId = mission.id,
                        timestamp = System.currentTimeMillis() + (seconds * 1000L),
                        elapsedSeconds = seconds,
                        title = "ORBITAL INSERTION PROFILE",
                        description = "Upper stage performing orbital circularization burn.",
                        severity = "INFO"
                    ))
                } else if (seconds == 600L) {
                    currentState = "DEPLOYMENT"
                    dao.insertMission(activeMission.value!!.copy(currentState = "DEPLOYMENT"))
                    dao.insertMissionEvent(MissionEventEntity(
                        missionId = mission.id,
                        timestamp = System.currentTimeMillis() + (seconds * 1000L),
                        elapsedSeconds = seconds,
                        title = "SPACECRAFT DEPLOYMENT",
                        description = "Deployment trigger authorized. ${spacecraft.name} has separated from the launcher payload adapter. Solar panels expanding.",
                        severity = "SUCCESS"
                    ))
                } else if (seconds == 750L) {
                    currentState = "ACTIVE_ORBIT"
                    dao.insertMission(activeMission.value!!.copy(currentState = "ACTIVE_ORBIT", isCompleted = true))
                    dao.insertMissionEvent(MissionEventEntity(
                        missionId = mission.id,
                        timestamp = System.currentTimeMillis() + (seconds * 1000L),
                        elapsedSeconds = seconds,
                        title = "MISSION COMPLETED",
                        description = "Spacecraft fully operational in target coordinate envelope. Continuous ground downlink acquired.",
                        severity = "SUCCESS"
                    ))
                }

                // Periodic dynamic telemetry generation (when flight begins at T>=0)
                if (seconds >= 0) {
                    val pState = OrbitalPropagator.propagate(orbit, seconds.toDouble())
                    
                    // Adjust parameters during launch vs orbital state
                    val currentAlt = if (seconds < 600) {
                        // Ascent phase simple linear climb simulation to orbital height
                        (seconds.toDouble() / 600.0) * orbit.altitudeKm
                    } else {
                        pState.altitudeKm
                    }

                    val currentVel = if (seconds < 600) {
                        // Accel from 0 to orbital velocity
                        (seconds.toDouble() / 600.0) * pState.velocityKms
                    } else {
                        pState.velocityKms
                    }

                    // Simulated battery / temperature
                    var battery = 100.0
                    if (seconds > 600) {
                        // standard thermal oscillation as it cycles solar eclipse/illumination
                        battery = 80.0 + sin(seconds / 200.0) * 15.0
                    }
                    var temperature = 20.0
                    if (seconds > 600) {
                        temperature = 12.0 + cos(seconds / 300.0) * 18.0
                    }

                    // Injected anomaly impact
                    if (anomalyPowerWarning.value) {
                        battery *= 0.35 // drastic drop
                    }
                    if (anomalyThermalWarning.value) {
                        temperature += 45.0 // thermal spike
                    }

                    // Antenna signal db based on ground station angle or simplified line of sight
                    var signal = -70.0 - (rand.nextDouble() * 5)
                    if (anomalyTelemetryDrop.value || anomalyContactLoss.value) {
                        signal = -115.0 // telemetry loss
                    } else if (seconds < 600) {
                        // ascent fading away from local range station
                        signal = -60.0 - (seconds / 15.0)
                    } else {
                        // orbital passes: signal waves based on ground track
                        signal = -80.0 + sin(seconds / 100.0) * 15.0
                    }

                    // Insert telemetry to DB
                    dao.insertTelemetryPoint(TelemetryPointEntity(
                        missionId = mission.id,
                        timestamp = System.currentTimeMillis(),
                        phase = currentState,
                        altitudeKm = currentAlt,
                        velocityKms = currentVel,
                        latitudeDeg = pState.latitudeDeg,
                        longitudeDeg = pState.longitudeDeg,
                        inclinationDeg = orbit.inclinationDeg,
                        batteryPercent = battery,
                        temperatureC = temperature,
                        signalDb = signal
                    ))
                }

                // Delay according to time compression warp
                delay((1000 / speed).toLong())
                seconds += 5 // progress by 5 seconds per tick
            }
        }
    }

    fun stopMissionSimulation() {
        simIsRunning.value = false
        simulationJob?.cancel()
    }

    fun triggerAnomaly(type: String) {
        viewModelScope.launch {
            val mission = activeMission.value ?: return@launch
            when (type) {
                "TELEMETRY_DROP" -> {
                    anomalyTelemetryDrop.value = !anomalyTelemetryDrop.value
                    dao.insertMissionEvent(MissionEventEntity(
                        missionId = mission.id,
                        timestamp = System.currentTimeMillis(),
                        elapsedSeconds = simElapsedSeconds.value,
                        title = "ANOMALY: TELEMETRY DROP",
                        description = "Intermittent transmitter lock. Downlink packets degraded.",
                        severity = "WARNING"
                    ))
                }
                "CONTACT_LOSS" -> {
                    anomalyContactLoss.value = !anomalyContactLoss.value
                    dao.insertMissionEvent(MissionEventEntity(
                        missionId = mission.id,
                        timestamp = System.currentTimeMillis(),
                        elapsedSeconds = simElapsedSeconds.value,
                        title = "ANOMALY: COMPLETE CONTACT LOSS",
                        description = "Range Station Shetland reports loss of signal (LOS). Retrying secondary link.",
                        severity = "ALERT"
                    ))
                }
                "THERMAL_WARNING" -> {
                    anomalyThermalWarning.value = !anomalyThermalWarning.value
                    dao.insertMissionEvent(MissionEventEntity(
                        missionId = mission.id,
                        timestamp = System.currentTimeMillis(),
                        elapsedSeconds = simElapsedSeconds.value,
                        title = "ANOMALY: THERMAL WARNING",
                        description = "On-board temperature exceeding critical thermal tolerance envelope.",
                        severity = "ALERT"
                    ))
                }
                "POWER_WARNING" -> {
                    anomalyPowerWarning.value = !anomalyPowerWarning.value
                    dao.insertMissionEvent(MissionEventEntity(
                        missionId = mission.id,
                        timestamp = System.currentTimeMillis(),
                        elapsedSeconds = simElapsedSeconds.value,
                        title = "ANOMALY: POWER CRITICAL",
                        description = "Battery reserve voltage below 30%. Initiating automatic low-power shutdown mode.",
                        severity = "ALERT"
                    ))
                }
            }
        }
    }

    // Help formatting
    private fun formatTime(seconds: Long): String {
        val hrs = seconds / 3600
        val mins = (seconds % 3600) / 60
        val secs = seconds % 60
        return "%02d:%02d:%02d".format(hrs, mins, secs)
    }

    private fun generateFictionalWeather(siteId: String): String {
        return when (siteId) {
            "shetland" -> "8°C | Winds N 24 knots | Overcast | Launch status: GO WITH CAUTION"
            "sutherland" -> "11°C | Winds NW 14 knots | Clear skies | Launch status: GO / GREEN"
            "ocean" -> "28°C | Winds E 5 knots | Mild swell | Launch status: GO / GREEN"
            else -> "15°C | Winds SW 10 knots | Launch status: GO"
        }
    }
}
