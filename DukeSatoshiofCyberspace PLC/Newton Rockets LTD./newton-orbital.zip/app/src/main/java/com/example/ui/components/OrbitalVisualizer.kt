package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ZoomIn
import androidx.compose.material.icons.filled.ZoomOut
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import com.example.data.EarthPhysics
import com.example.data.OrbitParameters
import com.example.data.OrbitalPropagator
import com.example.ui.theme.*
import kotlin.math.*

@Composable
fun OrbitalVisualizer(
    orbitParams: OrbitParameters,
    simTimeSeconds: Double,
    modifier: Modifier = Modifier
) {
    // 3D camera angles
    var yaw by remember { mutableFloatStateOf(-0.6f) }  // horizontal rotation
    var pitch by remember { mutableFloatStateOf(0.4f) } // vertical rotation
    var zoom by remember { mutableFloatStateOf(1.2f) }  // zoom factor

    Box(
        modifier = modifier
            .pointerInput(Unit) {
                detectDragGestures { change, dragAmount ->
                    change.consume()
                    yaw += dragAmount.x * 0.005f
                    pitch = max(-1.4f, min(1.4f, pitch + dragAmount.y * 0.005f))
                }
            }
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val cx = size.width / 2f
            val cy = size.height / 2f
            val baseRadius = min(size.width, size.height) * 0.28f * zoom

            // Camera calculations
            val d = 25000.0 // camera distance (fictional units)
            val earthRadius = EarthPhysics.RADIUS_KM

            fun project(x: Double, y: Double, z: Double): Offset? {
                // 1. Rotate around Y (yaw)
                val x1 = x * cos(yaw) - z * sin(yaw)
                val z1 = x * sin(yaw) + z * cos(yaw)
                val y1 = y

                // 2. Rotate around X (pitch)
                val x2 = x1
                val y2 = y1 * cos(pitch) - z1 * sin(pitch)
                val z2 = y1 * sin(pitch) + z1 * cos(pitch)

                // 3. Simple orthographic-perspective mix for depth
                val depthFactor = (d / (d - z2)).toFloat()
                
                // Return coordinate on screen plus depth check
                return Offset(
                    x = (cx + x2 * (baseRadius / earthRadius) * depthFactor).toFloat(),
                    y = (cy - y2 * (baseRadius / earthRadius) * depthFactor).toFloat()
                )
            }

            fun isFront(x: Double, y: Double, z: Double): Boolean {
                val x1 = x * cos(yaw) - z * sin(yaw)
                val z1 = x * sin(yaw) + z * cos(yaw)
                val y2 = y * cos(pitch) - z1 * sin(pitch)
                return (y * sin(pitch) + z1 * cos(pitch)) > 0
            }

            // Draw deep space Technical grid lines
            drawRect(color = Color(0xFF0F1115))

            // Draw Earth sphere outline
            drawCircle(
                color = SteelGray,
                radius = baseRadius.toFloat(),
                center = Offset(cx, cy),
                style = Stroke(width = 2.dp.toPx())
            )

            // Draw Equatorial Plane Ring
            val numRingSegments = 64
            val ringPoints = mutableListOf<Offset>()
            val ringFront = mutableListOf<Boolean>()
            for (i in 0..numRingSegments) {
                val theta = (i * 2.0 * PI) / numRingSegments
                val rx = earthRadius * cos(theta)
                val rz = earthRadius * sin(theta)
                val ry = 0.0
                project(rx, ry, rz)?.let { ringPoints.add(it) }
                ringFront.add(isFront(rx, ry, rz))
            }
            // Render Equatorial Plane
            for (i in 0 until ringPoints.size - 1) {
                drawLine(
                    color = if (ringFront[i]) GridLineColor else GridLineColor.copy(alpha = 0.1f),
                    start = ringPoints[i],
                    end = ringPoints[i + 1],
                    strokeWidth = 1.dp.toPx()
                )
            }

            // Draw Latitude Lines (Parallels)
            val parallels = listOf(-45.0, -30.0, 0.0, 30.0, 45.0)
            parallels.forEach { lat ->
                val latRad = Math.toRadians(lat)
                val rLat = earthRadius * cos(latRad)
                val yLat = earthRadius * sin(latRad)
                val latPoints = mutableListOf<Offset>()
                val latFront = mutableListOf<Boolean>()
                for (i in 0..36) {
                    val lon = i * 10.0
                    val lonRad = Math.toRadians(lon)
                    val rx = rLat * cos(lonRad)
                    val rz = rLat * sin(lonRad)
                    project(rx, yLat, rz)?.let { latPoints.add(it) }
                    latFront.add(isFront(rx, yLat, rz))
                }
                for (i in 0 until latPoints.size - 1) {
                    drawLine(
                        color = if (latFront[i]) GridLineColor else GridLineColor.copy(alpha = 0.1f),
                        start = latPoints[i],
                        end = latPoints[i + 1],
                        strokeWidth = 1.dp.toPx()
                    )
                }
            }

            // Draw Longitude Lines (Meridians)
            val meridians = listOf(0.0, 45.0, 90.0, 135.0, 180.0, 225.0, 270.0, 315.0)
            meridians.forEach { lon ->
                val lonRad = Math.toRadians(lon)
                val merPoints = mutableListOf<Offset>()
                val merFront = mutableListOf<Boolean>()
                for (i in 0..36) {
                    val lat = -90.0 + i * 5.0
                    val latRad = Math.toRadians(lat)
                    val rx = earthRadius * cos(latRad) * cos(lonRad)
                    val ry = earthRadius * sin(latRad)
                    val rz = earthRadius * cos(latRad) * sin(lonRad)
                    project(rx, ry, rz)?.let { merPoints.add(it) }
                    merFront.add(isFront(rx, ry, rz))
                }
                for (i in 0 until merPoints.size - 1) {
                    drawLine(
                        color = if (merFront[i]) GridLineColor else GridLineColor.copy(alpha = 0.1f),
                        start = merPoints[i],
                        end = merPoints[i + 1],
                        strokeWidth = 1.dp.toPx()
                    )
                }
            }

            // Draw target Orbit Line
            val numOrbitSegments = 120
            val orbitPoints = mutableListOf<Offset>()
            val orbitFront = mutableListOf<Boolean>()
            val orbitStateList = mutableListOf<com.example.data.OrbitState>()
            
            for (i in 0..numOrbitSegments) {
                val t = (i * 2.0 * PI) / numOrbitSegments
                // Simulate time increments covering the whole orbit period
                val orbitPeriodSec = 2.0 * PI * sqrt((earthRadius + orbitParams.altitudeKm).pow(3) / EarthPhysics.MU)
                val testTime = (i.toDouble() / numOrbitSegments) * orbitPeriodSec
                val state = OrbitalPropagator.propagate(orbitParams, testTime)
                orbitStateList.add(state)
                project(state.r.x, state.r.y, state.r.z)?.let { orbitPoints.add(it) }
                orbitFront.add(isFront(state.r.x, state.r.y, state.r.z))
            }

            // Draw orbit path
            for (i in 0 until orbitPoints.size - 1) {
                drawLine(
                    color = if (orbitFront[i]) ElectricBlue else ElectricBlue.copy(alpha = 0.2f),
                    start = orbitPoints[i],
                    end = orbitPoints[i + 1],
                    strokeWidth = 2.dp.toPx()
                )
            }

            // Draw Ascending Node (AN) and Descending Node (DN)
            // AN occurs when z crossed equatorial plane (y = 0 ascending)
            // Let's identify equator crossings in our state array
            var ascOffset: Offset? = null
            var descOffset: Offset? = null
            for (i in 0 until orbitStateList.size - 1) {
                val s1 = orbitStateList[i]
                val s2 = orbitStateList[i + 1]
                if (s1.r.z <= 0 && s2.r.z > 0) {
                    ascOffset = project(s1.r.x, s1.r.y, s1.r.z)
                } else if (s1.r.z >= 0 && s2.r.z < 0) {
                    descOffset = project(s1.r.x, s1.r.y, s1.r.z)
                }
            }

            ascOffset?.let {
                drawCircle(color = SignalGreen, radius = 5.dp.toPx(), center = it)
            }
            descOffset?.let {
                drawCircle(color = WarningAmber, radius = 5.dp.toPx(), center = it)
            }

            // Draw Current Satellite Position
            val satState = OrbitalPropagator.propagate(orbitParams, simTimeSeconds)
            val satProj = project(satState.r.x, satState.r.y, satState.r.z)
            val satVisible = isFront(satState.r.x, satState.r.y, satState.r.z)

            satProj?.let {
                // Draw ground projection link
                val groundRadiusFactor = earthRadius / (earthRadius + satState.altitudeKm)
                val gx = satState.r.x * groundRadiusFactor
                val gy = satState.r.y * groundRadiusFactor
                val gz = satState.r.z * groundRadiusFactor
                val groundProj = project(gx, gy, gz)
                
                if (groundProj != null) {
                    drawLine(
                        color = LightSteel.copy(alpha = 0.3f),
                        start = it,
                        end = groundProj,
                        strokeWidth = 1.dp.toPx(),
                        pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 10f), 0f)
                    )
                    drawCircle(
                        color = TechBlue.copy(alpha = 0.6f),
                        radius = 4.dp.toPx(),
                        center = groundProj
                    )
                }

                // Satellite core marker
                drawCircle(
                    color = if (satVisible) WarmOffWhite else LightSteel,
                    radius = 8.dp.toPx(),
                    center = it
                )
                drawCircle(
                    color = ElectricBlue,
                    radius = 12.dp.toPx(),
                    center = it,
                    style = Stroke(width = 1.dp.toPx())
                )
            }
        }

        // Overlay Interactive Controls
        Row(
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(12.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            FilledIconButton(
                onClick = { zoom = min(2.5f, zoom + 0.1f) },
                colors = IconButtonDefaults.filledIconButtonColors(containerColor = SteelGray)
            ) {
                Icon(Icons.Default.ZoomIn, contentDescription = "Zoom In", tint = WarmOffWhite)
            }
            FilledIconButton(
                onClick = { zoom = max(0.4f, zoom - 0.1f) },
                colors = IconButtonDefaults.filledIconButtonColors(containerColor = SteelGray)
            ) {
                Icon(Icons.Default.ZoomOut, contentDescription = "Zoom Out", tint = WarmOffWhite)
            }
        }

        // Orbital Parameters Legend
        Column(
            modifier = Modifier
                .align(Alignment.TopStart)
                .padding(12.dp)
        ) {
            Text(
                "DIGITAL TWIN RECONSTRUCTION",
                style = MaterialTheme.typography.labelSmall,
                color = ElectricBlue
            )
            Spacer(modifier = Modifier.height(4.dp))
            Row(
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(modifier = Modifier.size(8.dp).graphicsLayer { clip = true; translationY = -1f }) {
                        Canvas(Modifier.fillMaxSize()) { drawCircle(color = SignalGreen) }
                    }
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Ascending Node (AN)", style = MaterialTheme.typography.bodySmall, color = LightSteel)
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(modifier = Modifier.size(8.dp)) {
                        Canvas(Modifier.fillMaxSize()) { drawCircle(color = WarningAmber) }
                    }
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Descending Node (DN)", style = MaterialTheme.typography.bodySmall, color = LightSteel)
                }
            }
        }
    }
}
