package com.example.data

// Launch Vehicles Catalog Model
data class LaunchVehicle(
    val id: String,
    val name: String,
    val description: String,
    val payloadCapacityKg: Double,
    val baseCostM: Double,
    val compatibleSites: List<String>,
    val maxInclination: Double,
    val maxAltitude: Double
) {
    companion object {
        val FLEET = listOf(
            LaunchVehicle(
                id = "N-1",
                name = "Newton N-1 (Light Launcher)",
                description = "Three-stage light-lift liquid launcher. Designed for high precision delivery of CubeSats and constellations to LEO and Polar orbits.",
                payloadCapacityKg = 500.0,
                baseCostM = 3.5,
                compatibleSites = listOf("shetland", "sutherland"),
                maxInclination = 105.0,
                maxAltitude = 1200.0
            ),
            LaunchVehicle(
                id = "N-2",
                name = "Newton N-2 (Medium Commercial)",
                description = "Highly reliable, reusable first-stage medium commercial workhorse. Fully certified for Sun-Synchronous and GTO missions.",
                payloadCapacityKg = 3500.0,
                baseCostM = 8.2,
                compatibleSites = listOf("shetland", "sutherland", "ocean"),
                maxInclination = 99.0,
                maxAltitude = 2000.0
            ),
            LaunchVehicle(
                id = "N-3",
                name = "Newton N-3 (Heavy Transport)",
                description = "Heavy dual-manifest launch system. Ideal for major telecommunications platforms, heavy scientific observatories, and interplanetary payloads.",
                payloadCapacityKg = 15000.0,
                baseCostM = 18.5,
                compatibleSites = listOf("ocean", "shetland"),
                maxInclination = 60.0,
                maxAltitude = 5000.0
            )
        )
    }
}

// Launch Sites Catalog Model
data class LaunchSite(
    val id: String,
    val name: String,
    val location: String,
    val latitude: Double,
    val longitude: Double,
    val description: String,
    val status: String
) {
    companion object {
        val SITES = listOf(
            LaunchSite(
                id = "shetland",
                name = "Newton Spaceport (Shetland)",
                location = "Shetland Isles, Scotland (60.8° N, 0.9° W)",
                latitude = 60.8,
                longitude = -0.9,
                description = "Northernmost European site. Exceptionally suited for high inclination polar orbits and Sun-Synchronous insertion profiles.",
                status = "GO / OPERATIONAL"
            ),
            LaunchSite(
                id = "sutherland",
                name = "Newton Northern Range",
                location = "A' Mhòine, Highland, Scotland (58.5° N, 4.4° W)",
                latitude = 58.5,
                longitude = -4.4,
                description = "Modern mainland range optimized for highly automated smallsat launch campaigns.",
                status = "GO / OPERATIONAL"
            ),
            LaunchSite(
                id = "ocean",
                name = "Newton Ocean Range",
                location = "Pacific Equatorial Station (0.0° N, 154.0° W)",
                latitude = 0.0,
                longitude = -154.0,
                description = "Mobile, deep-sea semi-submersible launch platform positioned directly on the equator, maximizing Earth's rotational velocity boost.",
                status = "GO / OPERATIONAL"
            )
        )
    }
}
