package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.screens.*
import com.example.ui.theme.GraphiteDark
import com.example.ui.theme.GraphiteMedium
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.SteelGray
import com.example.viewmodel.NewtonViewModel

class MainActivity : ComponentActivity() {
    private val viewModel: NewtonViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        // Enforce proper edge-to-edge safe area drawing
        enableEdgeToEdge()

        setContent {
            MyApplicationTheme {
                val currentScreen by viewModel.currentScreen.collectAsStateWithLifecycle()

                // Register system back handler to pop back to dashboard from secondary screens
                if (currentScreen != "dashboard") {
                    BackHandler {
                        viewModel.currentScreen.value = "dashboard"
                    }
                }

                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    topBar = { NewtonTopAppBar(viewModel) },
                    bottomBar = { NewtonBottomNavigationBar(viewModel, currentScreen) },
                    containerColor = GraphiteDark,
                    contentWindowInsets = WindowInsets.safeDrawing
                ) { innerPadding ->
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                    ) {
                        when (currentScreen) {
                            "dashboard" -> DashboardScreen(viewModel = viewModel)
                            "configurator" -> ConfiguratorScreen(viewModel = viewModel)
                            "control" -> MissionControlScreen(viewModel = viewModel)
                            "telemetry" -> EngineeringScreen(viewModel = viewModel)
                            "docs" -> DocumentsScreen(viewModel = viewModel)
                            "account" -> AccountScreen(viewModel = viewModel)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun NewtonTopAppBar(viewModel: NewtonViewModel) {
    val activeMission by viewModel.activeMission.collectAsStateWithLifecycle()

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .statusBarsPadding()
            .background(GraphiteMedium)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(56.dp)
                .padding(horizontal = 16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                // Elegant minimalist Union Jack representation for British Aerospace brand
                Row(
                    modifier = Modifier
                        .width(22.dp)
                        .height(14.dp)
                        .border(1.dp, Color(0x66FFFFFF))
                        .background(Color(0xFF012169)),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(modifier = Modifier.fillMaxHeight().width(2.dp).background(Color.White))
                    Box(modifier = Modifier.fillMaxHeight().width(2.dp).background(Color(0xFFC8102E)))
                    Box(modifier = Modifier.fillMaxHeight().width(2.dp).background(Color.White))
                }

                Spacer(modifier = Modifier.width(10.dp))
                Text(
                    "NEWTON",
                    color = Color.White,
                    fontSize = 14.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 2.sp
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    "ORBITAL",
                    color = Color(0xFF38BDF8),
                    fontSize = 14.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Light,
                    letterSpacing = 2.sp
                )
            }

            if (activeMission != null) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .border(1.dp, Color(0x3310B981))
                        .background(Color(0x1110B981))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(6.dp)
                            .background(Color(0xFF10B981))
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        "LINKED: ${activeMission!!.name}",
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace,
                        color = Color(0xFF10B981)
                    )
                }
            }
        }
        HorizontalDivider(modifier = Modifier.fillMaxWidth(), thickness = 1.dp, color = SteelGray)
    }
}

@Composable
fun NewtonBottomNavigationBar(viewModel: NewtonViewModel, currentScreen: String) {
    NavigationBar(
        containerColor = GraphiteMedium,
        tonalElevation = 8.dp,
        modifier = Modifier.windowInsetsPadding(WindowInsets.navigationBars)
    ) {
        NavigationBarItem(
            selected = currentScreen == "dashboard",
            onClick = { viewModel.currentScreen.value = "dashboard" },
            icon = { Icon(Icons.Default.Dashboard, contentDescription = "Dashboard") },
            label = { Text("Manifest", fontFamily = FontFamily.Monospace, fontSize = 9.sp) },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = Color(0xFF38BDF8),
                selectedTextColor = Color(0xFF38BDF8),
                indicatorColor = SteelGray,
                unselectedIconColor = Color(0xFF8E9AA6),
                unselectedTextColor = Color(0xFF8E9AA6)
            ),
            modifier = Modifier.testTag("nav_dashboard")
        )

        NavigationBarItem(
            selected = currentScreen == "configurator",
            onClick = { viewModel.currentScreen.value = "configurator" },
            icon = { Icon(Icons.Default.AddLocation, contentDescription = "Configurator") },
            label = { Text("Planner", fontFamily = FontFamily.Monospace, fontSize = 9.sp) },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = Color(0xFF38BDF8),
                selectedTextColor = Color(0xFF38BDF8),
                indicatorColor = SteelGray,
                unselectedIconColor = Color(0xFF8E9AA6),
                unselectedTextColor = Color(0xFF8E9AA6)
            ),
            modifier = Modifier.testTag("nav_planner")
        )

        NavigationBarItem(
            selected = currentScreen == "control",
            onClick = { viewModel.currentScreen.value = "control" },
            icon = { Icon(Icons.Default.CellTower, contentDescription = "Mission Control") },
            label = { Text("Control", fontFamily = FontFamily.Monospace, fontSize = 9.sp) },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = Color(0xFF38BDF8),
                selectedTextColor = Color(0xFF38BDF8),
                indicatorColor = SteelGray,
                unselectedIconColor = Color(0xFF8E9AA6),
                unselectedTextColor = Color(0xFF8E9AA6)
            ),
            modifier = Modifier.testTag("nav_control")
        )

        NavigationBarItem(
            selected = currentScreen == "telemetry",
            onClick = { viewModel.currentScreen.value = "telemetry" },
            icon = { Icon(Icons.Default.DeveloperMode, contentDescription = "Diagnostics") },
            label = { Text("Vectors", fontFamily = FontFamily.Monospace, fontSize = 9.sp) },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = Color(0xFF38BDF8),
                selectedTextColor = Color(0xFF38BDF8),
                indicatorColor = SteelGray,
                unselectedIconColor = Color(0xFF8E9AA6),
                unselectedTextColor = Color(0xFF8E9AA6)
            )
        )

        NavigationBarItem(
            selected = currentScreen == "docs",
            onClick = { viewModel.currentScreen.value = "docs" },
            icon = { Icon(Icons.Default.FolderZip, contentDescription = "Documents") },
            label = { Text("Vault", fontFamily = FontFamily.Monospace, fontSize = 9.sp) },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = Color(0xFF38BDF8),
                selectedTextColor = Color(0xFF38BDF8),
                indicatorColor = SteelGray,
                unselectedIconColor = Color(0xFF8E9AA6),
                unselectedTextColor = Color(0xFF8E9AA6)
            )
        )

        NavigationBarItem(
            selected = currentScreen == "account",
            onClick = { viewModel.currentScreen.value = "account" },
            icon = { Icon(Icons.Default.AccountBox, contentDescription = "Account") },
            label = { Text("Workspace", fontFamily = FontFamily.Monospace, fontSize = 9.sp) },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = Color(0xFF38BDF8),
                selectedTextColor = Color(0xFF38BDF8),
                indicatorColor = SteelGray,
                unselectedIconColor = Color(0xFF8E9AA6),
                unselectedTextColor = Color(0xFF8E9AA6)
            )
        )
    }
}
