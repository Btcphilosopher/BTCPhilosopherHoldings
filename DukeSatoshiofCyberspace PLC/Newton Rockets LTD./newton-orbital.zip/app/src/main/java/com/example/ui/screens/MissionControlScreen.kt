package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.*
import com.example.ui.components.GroundTrackMap
import com.example.ui.components.OrbitalVisualizer
import com.example.ui.theme.*
import com.example.viewmodel.NewtonViewModel

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun MissionControlScreen(
    viewModel: NewtonViewModel,
    modifier: Modifier = Modifier
) {
    val activeMission by viewModel.activeMission.collectAsStateWithLifecycle()
    val activeSpacecraft by viewModel.activeSpacecraft.collectAsStateWithLifecycle()
    val allMissions by viewModel.missions.collectAsStateWithLifecycle()

    val telemetryLogs by viewModel.activeTelemetry.collectAsStateWithLifecycle()
    val eventLogs by viewModel.activeEvents.collectAsStateWithLifecycle()

    val simRunning by viewModel.simIsRunning.collectAsStateWithLifecycle()
    val simTimeLabel by viewModel.simTimeLabel.collectAsStateWithLifecycle()
    val simWarpSpeed by viewModel.simSpeedMultiplier.collectAsStateWithLifecycle()

    val anomalyDrop by viewModel.anomalyTelemetryDrop.collectAsStateWithLifecycle()
    val anomalyLoss by viewModel.anomalyContactLoss.collectAsStateWithLifecycle()
    val anomalyThermal by viewModel.anomalyThermalWarning.collectAsStateWithLifecycle()
    val anomalyPower by viewModel.anomalyPowerWarning.collectAsStateWithLifecycle()

    val role by viewModel.selectedRole.collectAsStateWithLifecycle()

    if (activeMission == null) {
        // Selection state placeholder
        Column(
            modifier = modifier
                .fillMaxSize()
                .background(GraphiteDark)
                .padding(24.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(Icons.Default.CellTower, contentDescription = null, modifier = Modifier.size(64.dp), tint = LightSteel)
            Spacer(modifier = Modifier.height(16.dp))
            Text(
                "SELECT ACTIVE MISSION TO TRACK",
                style = MaterialTheme.typography.titleMedium,
                color = WarmOffWhite,
                fontFamily = FontFamily.Monospace
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                "No focused satellite spacecraft link. Select an upcoming or active flight profile from the manifest database.",
                style = MaterialTheme.typography.bodySmall,
                color = LightSteel,
                textAlign = TextAlign.Center
            )
            Spacer(modifier = Modifier.height(16.dp))
            Row(modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                allMissions.forEach { m ->
                    Text(
                        m.name,
                        fontFamily = FontFamily.Monospace,
                        color = ElectricBlue,
                        modifier = Modifier
                            .border(1.dp, SteelGray)
                            .clickable { viewModel.selectedMissionId.value = m.id }
                            .padding(12.dp)
                    )
                }
            }
        }
        return
    }

    val mission = activeMission!!
    val spacecraft = activeSpacecraft ?: SpacecraftEntity(
        name = "Aureom Placeholder", massKg = 100.0, widthM = 0.5, heightM = 0.5, depthM = 0.5, powerW = 100.0,
        spacecraftClass = SpacecraftClass.SMALLSAT.name, deploymentMechanism = "Clamp", organisationId = 1,
        altitudeKm = 500.0, inclinationDeg = 50.0, eccentricity = 0.0, raanDeg = 0.0, argOfPerigeeDeg = 0.0
    )

    Row(modifier = Modifier.fillMaxWidth().background(GraphiteMedium).padding(8.dp).horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.CellTower, contentDescription = null, tint = ElectricBlue)
            Spacer(modifier = Modifier.width(8.dp))
            Text("MISSION CONTROL COCKPIT: ${mission.name}", fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, color = WarmOffWhite, fontSize = 13.sp)
        }
        Text(
            "SWITCH TARGET LINK",
            color = ElectricBlue,
            fontFamily = FontFamily.Monospace,
            style = MaterialTheme.typography.labelSmall,
            modifier = Modifier
                .border(1.dp, SteelGray)
                .clickable { viewModel.selectedMissionId.value = null }
                .padding(horizontal = 8.dp, vertical = 4.dp)
        )
    }

    BoxWithConstraints(modifier = modifier.fillMaxSize().background(GraphiteDark)) {
        val isExpanded = maxWidth > 800.dp

        if (isExpanded) {
            Row(modifier = Modifier.fillMaxSize()) {
                // Left dynamic simulation column
                Column(
                    modifier = Modifier
                        .weight(1.3f)
                        .fillMaxHeight()
                        .padding(16.dp)
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    FlightConsoleCard(
                        mission = mission,
                        spacecraft = spacecraft,
                        simRunning = simRunning,
                        simTimeLabel = simTimeLabel,
                        simWarpSpeed = simWarpSpeed,
                        viewModel = viewModel
                    )

                    TelemetryGrid(
                        telemetryLogs = telemetryLogs,
                        anomalyLoss = anomalyLoss,
                        anomalyPower = anomalyPower,
                        anomalyThermal = anomalyThermal
                    )

                    // Readiness Checklist
                    ReadinessChecklistCard(mission = mission, viewModel = viewModel, simRunning = simRunning)

                    // Staff Anomaly Injectors
                    if (role == "NEWTON_OPERATOR" || role == "NEWTON_ADMIN" || role == "ENGINEER") {
                        AnomalyInjectorsCard(
                            anomalyDrop = anomalyDrop,
                            anomalyLoss = anomalyLoss,
                            anomalyThermal = anomalyThermal,
                            anomalyPower = anomalyPower,
                            onTrigger = { viewModel.triggerAnomaly(it) }
                        )
                    }
                }

                // Vertical border
                Box(modifier = Modifier.fillMaxHeight().width(1.dp).background(SteelGray))

                // Right graphics visualization & logs column
                Column(
                    modifier = Modifier
                        .weight(1.2f)
                        .fillMaxHeight()
                ) {
                    // Quick Map / Visualizer
                    Box(modifier = Modifier.weight(1f).fillMaxWidth()) {
                        GroundTrackMap(
                            orbitParams = OrbitParameters(
                                spacecraft.altitudeKm, spacecraft.inclinationDeg,
                                spacecraft.eccentricity, spacecraft.raanDeg, spacecraft.argOfPerigeeDeg
                            ),
                            simTimeSeconds = viewModel.simElapsedSeconds.collectAsStateWithLifecycle().value.toDouble(),
                            modifier = Modifier.fillMaxSize()
                        )
                    }

                    Box(modifier = Modifier.height(1.dp).fillMaxWidth().background(SteelGray))

                    // Events Stream Logger
                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth()
                            .padding(16.dp)
                    ) {
                        Text(
                            "RANGE FLIGHT STREAM LOGS",
                            style = MaterialTheme.typography.labelSmall,
                            color = ElectricBlue,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        LazyColumn(
                            modifier = Modifier.weight(1f),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            items(eventLogs) { ev ->
                                EventLogItem(ev)
                            }
                        }
                    }
                }
            }
        } else {
            // Compact Vertical layout
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                FlightConsoleCard(
                    mission = mission,
                    spacecraft = spacecraft,
                    simRunning = simRunning,
                    simTimeLabel = simTimeLabel,
                    simWarpSpeed = simWarpSpeed,
                    viewModel = viewModel
                )

                Box(modifier = Modifier.fillMaxWidth().height(200.dp)) {
                    OrbitalVisualizer(
                        orbitParams = OrbitParameters(
                            spacecraft.altitudeKm, spacecraft.inclinationDeg,
                            spacecraft.eccentricity, spacecraft.raanDeg, spacecraft.argOfPerigeeDeg
                        ),
                        simTimeSeconds = viewModel.simElapsedSeconds.collectAsStateWithLifecycle().value.toDouble(),
                        modifier = Modifier.fillMaxSize()
                    )
                }

                TelemetryGrid(
                    telemetryLogs = telemetryLogs,
                    anomalyLoss = anomalyLoss,
                    anomalyPower = anomalyPower,
                    anomalyThermal = anomalyThermal
                )

                ReadinessChecklistCard(mission = mission, viewModel = viewModel, simRunning = simRunning)

                if (role == "NEWTON_OPERATOR" || role == "NEWTON_ADMIN" || role == "ENGINEER") {
                    AnomalyInjectorsCard(
                        anomalyDrop = anomalyDrop,
                        anomalyLoss = anomalyLoss,
                        anomalyThermal = anomalyThermal,
                        anomalyPower = anomalyPower,
                        onTrigger = { viewModel.triggerAnomaly(it) }
                    )
                }

                // Log display compact
                Text("FLIGHT EVENT STREAM", style = MaterialTheme.typography.labelSmall, color = ElectricBlue, fontFamily = FontFamily.Monospace)
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    eventLogs.take(5).forEach { ev ->
                        EventLogItem(ev)
                    }
                }
            }
        }
    }
}

@Composable
fun FlightConsoleCard(
    mission: MissionEntity,
    spacecraft: SpacecraftEntity,
    simRunning: Boolean,
    simTimeLabel: String,
    simWarpSpeed: Int,
    viewModel: NewtonViewModel
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, SteelGray)
            .background(GraphiteMedium)
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    "DIGITAL TWIN TELEMETRY SYSTEM",
                    style = MaterialTheme.typography.labelSmall,
                    color = LightSteel,
                    fontFamily = FontFamily.Monospace
                )
                Text(
                    "TARGET: ${spacecraft.name}",
                    style = MaterialTheme.typography.titleMedium,
                    color = WarmOffWhite,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.SansSerif
                )
            }
            // Timer Clock display
            Text(
                simTimeLabel,
                style = MaterialTheme.typography.titleLarge,
                color = if (simRunning) SignalGreen else LightSteel,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Actions
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (!simRunning) {
                Button(
                    onClick = { viewModel.startMissionSimulation() },
                    colors = ButtonDefaults.buttonColors(containerColor = TechBlue),
                    shape = RoundedCornerShape(2.dp),
                    modifier = Modifier.weight(1.3f).testTag("run_simulation_button")
                ) {
                    Icon(Icons.Default.PlayArrow, contentDescription = null)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("START FLIGHT SIMULATION", fontFamily = FontFamily.Monospace, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            } else {
                Button(
                    onClick = { viewModel.stopMissionSimulation() },
                    colors = ButtonDefaults.buttonColors(containerColor = AlertRed),
                    shape = RoundedCornerShape(2.dp),
                    modifier = Modifier.weight(1.3f).testTag("stop_simulation_button")
                ) {
                    Icon(Icons.Default.Stop, contentDescription = null)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("STOP MISSION RUN", fontFamily = FontFamily.Monospace, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }

            // Warp compression row
            Row(
                modifier = Modifier
                    .weight(1f)
                    .border(1.dp, SteelGray)
                    .background(Color.Black.copy(alpha = 0.2f))
                    .padding(4.dp),
                horizontalArrangement = Arrangement.SpaceAround,
                verticalAlignment = Alignment.CenterVertically
            ) {
                listOf(1, 10, 100, 1000).forEach { warp ->
                    Text(
                        "${warp}x",
                        style = MaterialTheme.typography.labelSmall,
                        fontFamily = FontFamily.Monospace,
                        color = if (simWarpSpeed == warp) ElectricBlue else LightSteel,
                        fontWeight = if (simWarpSpeed == warp) FontWeight.Bold else FontWeight.Normal,
                        modifier = Modifier
                            .clickable { viewModel.simSpeedMultiplier.value = warp }
                            .padding(4.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun TelemetryGrid(
    telemetryLogs: List<TelemetryPointEntity>,
    anomalyLoss: Boolean,
    anomalyPower: Boolean,
    anomalyThermal: Boolean
) {
    val currentTel = telemetryLogs.lastOrNull() ?: TelemetryPointEntity(
        missionId = 0, timestamp = 0, phase = "STANDBY", altitudeKm = 0.0, velocityKms = 0.0,
        latitudeDeg = 0.0, longitudeDeg = 0.0, inclinationDeg = 0.0, batteryPercent = 100.0, temperatureC = 15.0, signalDb = -75.0
    )

    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            TelemetryGaugeCard(
                label = "ALTITUDE",
                value = "${currentTel.altitudeKm.round(1)} km",
                indicatorColor = ElectricBlue,
                modifier = Modifier.weight(1f)
            )
            TelemetryGaugeCard(
                label = "VELOCITY",
                value = "${currentTel.velocityKms.round(3)} km/s",
                indicatorColor = ElectricBlue,
                modifier = Modifier.weight(1f)
            )
        }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            TelemetryGaugeCard(
                label = "BATTERY STATUS",
                value = "${currentTel.batteryPercent.round(1)}%",
                indicatorColor = if (anomalyPower) AlertRed else SignalGreen,
                modifier = Modifier.weight(1f)
            )
            TelemetryGaugeCard(
                label = "TEMPERATURE",
                value = "${currentTel.temperatureC.round(1)} °C",
                indicatorColor = if (anomalyThermal) AlertRed else SignalGreen,
                modifier = Modifier.weight(1f)
            )
            TelemetryGaugeCard(
                label = "LINK STRENGTH",
                value = if (anomalyLoss) "LOSS OF SIGNAL" else "${currentTel.signalDb.round(0)} dBm",
                indicatorColor = if (anomalyLoss) AlertRed else SignalGreen,
                modifier = Modifier.weight(1.1f)
            )
        }
    }
}

@Composable
fun TelemetryGaugeCard(
    label: String,
    value: String,
    indicatorColor: Color,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .border(1.dp, SteelGray)
            .background(GraphiteMedium)
            .padding(12.dp)
    ) {
        Text(
            label,
            style = MaterialTheme.typography.labelSmall,
            color = LightSteel,
            fontFamily = FontFamily.Monospace,
            fontSize = 9.sp
        )
        Spacer(modifier = Modifier.height(4.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(6.dp)
                    .background(indicatorColor, RoundedCornerShape(3.dp))
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                value,
                style = MaterialTheme.typography.bodyMedium,
                color = WarmOffWhite,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

@Composable
fun ReadinessChecklistCard(
    mission: MissionEntity,
    viewModel: NewtonViewModel,
    simRunning: Boolean
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, SteelGray)
            .background(GraphiteMedium)
            .padding(16.dp)
    ) {
        Text(
            "PREFLIGHT SAFETY CHECKLIST",
            style = MaterialTheme.typography.labelSmall,
            color = ElectricBlue,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold
        )
        Text(
            "Gating safety review. All steps must be cleared by authorized managers to enable booster ignition.",
            style = MaterialTheme.typography.bodySmall,
            color = LightSteel
        )
        Spacer(modifier = Modifier.height(12.dp))

        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
            ChecklistToggleRow("TECHNICAL SPECIFICATION ENVELOPE", mission.specApproved, simRunning) {
                viewModel.updateChecklistField("specApproved", it)
            }
            ChecklistToggleRow("MASS COMPLIANCE SIGN-OFF", mission.massConfirmed, simRunning) {
                viewModel.updateChecklistField("massConfirmed", it)
            }
            ChecklistToggleRow("ORBIT REGISTRATION DOCUMENTATION", mission.orbitConfirmed, simRunning) {
                viewModel.updateChecklistField("orbitConfirmed", it)
            }
            ChecklistToggleRow("SPACEPORT RANGE INTEGRATION COMPLETE", mission.integrationComplete, simRunning) {
                viewModel.updateChecklistField("integrationComplete", it)
            }
            ChecklistToggleRow("UK SPACE AGENCY SAFETY CLEARANCE", mission.safetyReviewApproved, simRunning) {
                viewModel.updateChecklistField("safetyReviewApproved", it)
            }
            ChecklistToggleRow("FLIGHT COMPLIANCE AGREEMENT SIGNED", mission.docApproved, simRunning) {
                viewModel.updateChecklistField("docApproved", it)
            }
            ChecklistToggleRow("JOINT MISSION REVIEW CLEARED", mission.missionReviewApproved, simRunning) {
                viewModel.updateChecklistField("missionReviewApproved", it)
            }
            ChecklistToggleRow("LAUNCH AUTHORITY SIGN-OFF", mission.launchAuthorityApproved, simRunning) {
                viewModel.updateChecklistField("launchAuthorityApproved", it)
            }
        }
    }
}

@Composable
fun ChecklistToggleRow(
    label: String,
    checked: Boolean,
    simRunning: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, SteelGray)
            .background(Color.Black.copy(alpha = 0.15f))
            .padding(horizontal = 8.dp, vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            label,
            style = MaterialTheme.typography.bodySmall,
            fontFamily = FontFamily.Monospace,
            color = if (checked) WarmOffWhite else LightSteel,
            fontSize = 11.sp
        )
        Checkbox(
            checked = checked,
            onCheckedChange = if (simRunning) null else onCheckedChange,
            colors = CheckboxDefaults.colors(
                checkedColor = SignalGreen,
                uncheckedColor = LightSteel
            ),
            modifier = Modifier.testTag("checklist_check_${label.lowercase().replace(" ", "_")}")
        )
    }
}

@Composable
fun AnomalyInjectorsCard(
    anomalyDrop: Boolean,
    anomalyLoss: Boolean,
    anomalyThermal: Boolean,
    anomalyPower: Boolean,
    onTrigger: (String) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, SteelGray)
            .background(GraphiteMedium)
            .padding(16.dp)
    ) {
        Text(
            "FLIGHT TRAINING SYSTEM (ANOMALY INJECTORS)",
            style = MaterialTheme.typography.labelSmall,
            color = AlertRed,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold
        )
        Text(
            "Inject flight faults to test ground-station compliance and telemetry drop protocols. Understated simulation use only.",
            style = MaterialTheme.typography.bodySmall,
            color = LightSteel
        )
        Spacer(modifier = Modifier.height(12.dp))

        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Box(modifier = Modifier.weight(1f)) { AnomalyButton("TELEMETRY DROP", anomalyDrop) { onTrigger("TELEMETRY_DROP") } }
                Box(modifier = Modifier.weight(1f)) { AnomalyButton("COMPLETE CONTACT LOSS", anomalyLoss) { onTrigger("CONTACT_LOSS") } }
            }
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Box(modifier = Modifier.weight(1f)) { AnomalyButton("THERMAL WARP WARNING", anomalyThermal) { onTrigger("THERMAL_WARNING") } }
                Box(modifier = Modifier.weight(1f)) { AnomalyButton("BATTERY RESERVE LOSS", anomalyPower) { onTrigger("POWER_WARNING") } }
            }
        }
    }
}

@Composable
fun AnomalyButton(
    label: String,
    active: Boolean,
    onClick: () -> Unit
) {
    Text(
        label,
        fontFamily = FontFamily.Monospace,
        color = if (active) Color.White else LightSteel,
        style = MaterialTheme.typography.labelSmall,
        modifier = Modifier
            .border(1.dp, if (active) AlertRed else SteelGray)
            .background(if (active) AlertRed.copy(alpha = 0.2f) else Color.Transparent)
            .clickable { onClick() }
            .padding(horizontal = 10.dp, vertical = 6.dp)
    )
}

@Composable
fun EventLogItem(event: MissionEventEntity) {
    val badgeColor = when (event.severity) {
        "SUCCESS" -> SignalGreen
        "WARNING" -> WarningAmber
        "ALERT" -> AlertRed
        else -> LightSteel
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, SteelGray)
            .background(GraphiteMedium.copy(alpha = 0.5f))
            .padding(12.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(6.dp)
                        .background(badgeColor, RoundedCornerShape(3.dp))
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    event.title,
                    style = MaterialTheme.typography.bodySmall,
                    color = WarmOffWhite,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
            }
            Text(
                "T+${formatTime(event.elapsedSeconds)}",
                style = MaterialTheme.typography.labelSmall,
                color = ElectricBlue,
                fontFamily = FontFamily.Monospace
            )
        }
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            event.description,
            style = MaterialTheme.typography.bodySmall,
            color = LightSteel
        )
    }
}

private fun formatTime(seconds: Long): String {
    val hrs = seconds / 3600
    val mins = (seconds % 3600) / 60
    val secs = seconds % 60
    return "%02d:%02d:%02d".format(hrs, mins, secs)
}

private fun Double.round(decimals: Int): Double {
    var multiplier = 1.0
    repeat(decimals) { multiplier *= 10 }
    return kotlin.math.round(this * multiplier) / multiplier
}
