package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val GraphiteDark = Color(0xFF121416)
val GraphiteMedium = Color(0xFF1E2124)
val SteelGray = Color(0xFF2D3238)
val LightSteel = Color(0xFF8E9AA6)
val WarmOffWhite = Color(0xFFF3F4F6)
val BritishNavy = Color(0xFF151B26)
val TechBlue = Color(0xFF2563EB)
val ElectricBlue = Color(0xFF38BDF8)
val SignalGreen = Color(0xFF10B981)
val AlertRed = Color(0xFFEF4444)
val WarningAmber = Color(0xFFF59E0B)
val GridLineColor = Color(0x338E9AA6)
