package com.example.ui.screens

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.*
import com.example.ui.theme.*
import com.example.viewmodel.NewtonViewModel

@Composable
fun AccountScreen(
    viewModel: NewtonViewModel,
    modifier: Modifier = Modifier
) {
    val orgs by viewModel.organisations.collectAsStateWithLifecycle()
    val currentOrgId by viewModel.selectedOrganizationId.collectAsStateWithLifecycle()
    val currentRole by viewModel.selectedRole.collectAsStateWithLifecycle()

    val currentOrg = orgs.firstOrNull { it.id == currentOrgId } ?: OrganisationEntity(name = "Aureom Imaging Ltd.", code = "AUREOM")

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(GraphiteDark)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(20.dp)
    ) {
        // Workspace Header
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, SteelGray)
                    .background(GraphiteMedium)
                    .padding(16.dp)
            ) {
                Text(
                    "ORGANISATION PLATFORM DIRECTORY",
                    style = MaterialTheme.typography.labelSmall,
                    color = ElectricBlue,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    "USER PROFILE & WORKSPACE POLICY",
                    style = MaterialTheme.typography.titleLarge,
                    color = WarmOffWhite,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    "Manage multi-tenant workspaces, switch testing identities, and adjust security clearances.",
                    style = MaterialTheme.typography.bodySmall,
                    color = LightSteel
                )
            }
        }

        // Active workspace details
        item {
            Text(
                "ACTIVE CORPORATE WORKSPACE",
                style = MaterialTheme.typography.titleMedium,
                color = WarmOffWhite,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(10.dp))
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, SteelGray)
                    .background(GraphiteMedium)
                    .padding(16.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Business, contentDescription = null, tint = ElectricBlue)
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            currentOrg.name,
                            color = WarmOffWhite,
                            style = MaterialTheme.typography.bodyLarge,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            "CONTRACT CODE: NT-${currentOrg.code}-2026",
                            color = LightSteel,
                            style = MaterialTheme.typography.bodySmall,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }
        }

        // Workspace selection
        item {
            Text(
                "SWITCH CORPORATE ORGANIZATION DELEGATE",
                style = MaterialTheme.typography.titleMedium,
                color = WarmOffWhite,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(8.dp))
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                orgs.forEach { org ->
                    val active = org.id == currentOrgId
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, if (active) ElectricBlue else SteelGray)
                            .background(if (active) TechBlue.copy(alpha = 0.1f) else GraphiteMedium)
                            .clickable { viewModel.selectedOrganizationId.value = org.id }
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(
                            selected = active,
                            onClick = { viewModel.selectedOrganizationId.value = org.id },
                            colors = RadioButtonDefaults.colors(selectedColor = ElectricBlue)
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Text(
                            org.name,
                            color = WarmOffWhite,
                            style = MaterialTheme.typography.bodyMedium,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }
        }

        // RBAC Switcher
        item {
            Text(
                "SWITCH ROLE SECURITY CLEARANCE",
                style = MaterialTheme.typography.titleMedium,
                color = WarmOffWhite,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(8.dp))
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(
                    Pair("MISSION_MANAGER", "Mission Logistics Manager (Checklist Editing)"),
                    Pair("ENGINEER", "Scientific System Specialist (Engineering Diagnostics View)"),
                    Pair("VIEWER", "Default Customer Observer (ReadOnly view)"),
                    Pair("NEWTON_OPERATOR", "Booster Range Operator (Anomaly Injector Access)"),
                    Pair("NEWTON_ADMIN", "Full Fleet Executive Administrator")
                ).forEach { (roleKey, roleLabel) ->
                    val active = currentRole == roleKey
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, if (active) ElectricBlue else SteelGray)
                            .background(if (active) TechBlue.copy(alpha = 0.1f) else GraphiteMedium)
                            .clickable { viewModel.selectedRole.value = roleKey }
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(
                            selected = active,
                            onClick = { viewModel.selectedRole.value = roleKey },
                            colors = RadioButtonDefaults.colors(selectedColor = ElectricBlue)
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                roleKey,
                                color = WarmOffWhite,
                                style = MaterialTheme.typography.bodyMedium,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                roleLabel,
                                color = LightSteel,
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                    }
                }
            }
        }
    }
}
