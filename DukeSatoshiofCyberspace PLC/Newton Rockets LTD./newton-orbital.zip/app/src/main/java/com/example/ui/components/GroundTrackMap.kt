package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import com.example.data.OrbitParameters
import com.example.data.OrbitalPropagator
import com.example.ui.theme.*
import kotlin.math.abs

@Composable
fun GroundTrackMap(
    orbitParams: OrbitParameters,
    simTimeSeconds: Double,
    modifier: Modifier = Modifier
) {
    Box(modifier = modifier) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height

            // Mercator Projection Helper
            fun toScreen(lat: Double, lon: Double): Offset {
                // lon: [-180, 180] -> [0, w]
                // lat: [90, -90] -> [0, h]
                val x = ((lon + 180.0) / 360.0) * w
                val y = ((90.0 - lat) / 180.0) * h
                return Offset(x.toFloat(), y.toFloat())
            }

            // Draw dark background
            drawRect(color = Color(0xFF0F1115))

            // Draw Coordinate Grid Lines
            val gridPaint = GridLineColor
            // Longitude Merdians (vertical lines every 30 degrees)
            for (lon in -180..180 step 30) {
                drawLine(
                    color = gridPaint,
                    start = Offset(((lon + 180.0) / 360.0 * w).toFloat(), 0f),
                    end = Offset(((lon + 180.0) / 360.0 * w).toFloat(), h),
                    strokeWidth = 0.5.dp.toPx()
                )
            }
            // Latitude Parallels (horizontal lines every 30 degrees)
            for (lat in -60..60 step 30) {
                drawLine(
                    color = gridPaint,
                    start = Offset(0f, ((90.0 - lat) / 180.0 * h).toFloat()),
                    end = Offset(w, ((90.0 - lat) / 180.0 * h).toFloat()),
                    strokeWidth = 0.5.dp.toPx()
                )
            }

            // Draw Stylized Simplistic Vector Continents for Control Center Aesthetic
            val landColor = SteelGray.copy(alpha = 0.6f)
            val landStrokeColor = LightSteel.copy(alpha = 0.25f)

            fun drawLandmass(coords: List<Pair<Double, Double>>) {
                if (coords.isEmpty()) return
                val path = Path()
                val start = toScreen(coords[0].first, coords[0].second)
                path.moveTo(start.x, start.y)
                for (i in 1 until coords.size) {
                    val pt = toScreen(coords[i].first, coords[i].second)
                    path.lineTo(pt.x, pt.y)
                }
                path.close()
                drawPath(path = path, color = landColor)
                drawPath(path = path, color = landStrokeColor, style = Stroke(width = 1.dp.toPx()))
            }

            // High-fidelity simplified global land contours
            // North America outline
            drawLandmass(listOf(
                Pair(70.0, -160.0), Pair(70.0, -80.0), Pair(45.0, -50.0), Pair(25.0, -80.0),
                Pair(15.0, -90.0), Pair(15.0, -100.0), Pair(30.0, -115.0), Pair(55.0, -130.0), Pair(65.0, -165.0)
            ))
            
            // South America outline
            drawLandmass(listOf(
                Pair(12.0, -72.0), Pair(5.0, -50.0), Pair(-5.0, -35.0), Pair(-20.0, -40.0),
                Pair(-50.0, -65.0), Pair(-55.0, -70.0), Pair(-40.0, -75.0), Pair(-20.0, -70.0), Pair(-5.0, -80.0)
            ))

            // Eurasia + Africa outline
            drawLandmass(listOf(
                Pair(75.0, 10.0), Pair(75.0, 170.0), Pair(60.0, 170.0), Pair(40.0, 140.0),
                Pair(10.0, 110.0), Pair(5.0, 95.0), Pair(15.0, 75.0), Pair(12.0, 45.0),
                Pair(30.0, 32.0), Pair(15.0, 40.0), Pair(5.0, 50.0), Pair(-30.0, 30.0),
                Pair(-34.0, 20.0), Pair(-10.0, 10.0), Pair(5.0, -10.0), Pair(15.0, -15.0),
                Pair(35.0, -10.0), Pair(35.0, 15.0), Pair(50.0, 5.0)
            ))

            // Australia outline
            drawLandmass(listOf(
                Pair(-12.0, 130.0), Pair(-15.0, 145.0), Pair(-25.0, 150.0), Pair(-35.0, 145.0),
                Pair(-35.0, 115.0), Pair(-20.0, 113.0), Pair(-15.0, 120.0)
            ))

            // Greenland outline
            drawLandmass(listOf(
                Pair(80.0, -60.0), Pair(80.0, -30.0), Pair(65.0, -40.0), Pair(60.0, -45.0), Pair(70.0, -55.0)
            ))

            // British Isles outline (Aesthetics for Newton Rockets!)
            drawLandmass(listOf(
                Pair(58.0, -8.0), Pair(60.0, -1.0), Pair(55.0, -1.0), Pair(50.0, 2.0),
                Pair(50.0, -5.0), Pair(53.0, -5.0), Pair(54.0, -10.0)
            ))

            // Draw Fictional Range Ground Stations
            val groundStations = listOf(
                Pair("Shetland Downlink", Pair(60.8, -0.9)),
                Pair("Sutherland Downlink", Pair(58.5, -4.4)),
                Pair("Equatorial Downlink", Pair(0.0, -154.0))
            )

            groundStations.forEach { (name, pos) ->
                val (lat, lon) = pos
                val offset = toScreen(lat, lon)
                
                // Pulsing station marker
                drawCircle(color = TechBlue.copy(alpha = 0.4f), radius = 12.dp.toPx(), center = offset)
                drawCircle(color = ElectricBlue, radius = 4.dp.toPx(), center = offset)
            }

            // Generate and draw Ground Track points
            // Generate full orbit ground path (100 points)
            val trackPoints = OrbitalPropagator.generateGroundTrack(orbitParams, simTimeSeconds)
            
            // Draw track line. Since map wraps at -180 and 180 longitude, we avoid drawing connecting lines
            // across the screen bounds which would make a horizontal stripe.
            for (i in 0 until trackPoints.size - 1) {
                val pt1 = trackPoints[i]
                val pt2 = trackPoints[i + 1]
                
                // If it doesn't wrap boundaries
                if (abs(pt1.second - pt2.second) < 180.0) {
                    drawLine(
                        color = ElectricBlue,
                        start = toScreen(pt1.first, pt1.second),
                        end = toScreen(pt2.first, pt2.second),
                        strokeWidth = 2.dp.toPx()
                    )
                }
            }

            // Draw Current Satellite Location
            val currentSatState = OrbitalPropagator.propagate(orbitParams, simTimeSeconds)
            val satPos = toScreen(currentSatState.latitudeDeg, currentSatState.longitudeDeg)

            // Dynamic targeting radar circles
            drawCircle(
                color = SignalGreen.copy(alpha = 0.25f),
                radius = 18.dp.toPx(),
                center = satPos
            )
            drawCircle(
                color = SignalGreen,
                radius = 6.dp.toPx(),
                center = satPos
            )
        }

        // Fictional telemetry overlay tag
        Column(
            modifier = Modifier
                .align(Alignment.TopEnd)
                .padding(12.dp)
        ) {
            Text(
                "MERCATOR CYLINDRICAL GROUND PROJECTION",
                style = MaterialTheme.typography.labelSmall,
                color = ElectricBlue
            )
        }
    }
}
