package com.example.ui.screens

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.*
import com.example.ui.theme.*
import com.example.viewmodel.NewtonViewModel

@Composable
fun DocumentsScreen(
    viewModel: NewtonViewModel,
    modifier: Modifier = Modifier
) {
    val activeMission by viewModel.activeMission.collectAsStateWithLifecycle()
    val documents by viewModel.activeDocuments.collectAsStateWithLifecycle()

    if (activeMission == null) {
        Column(
            modifier = modifier
                .fillMaxSize()
                .background(GraphiteDark)
                .padding(24.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(Icons.Default.FolderZip, contentDescription = null, modifier = Modifier.size(64.dp), tint = LightSteel)
            Spacer(modifier = Modifier.height(16.dp))
            Text(
                "DOCUMENT INTEGRATION VAULT",
                style = MaterialTheme.typography.titleMedium,
                color = WarmOffWhite,
                fontFamily = FontFamily.Monospace
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                "Link a focused launch mission from Dashboard or Mission Control to view its technical documentation and legal clearances.",
                style = MaterialTheme.typography.bodySmall,
                color = LightSteel
            )
        }
        return
    }

    val mission = activeMission!!

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(GraphiteDark)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, SteelGray)
                    .background(GraphiteMedium)
                    .padding(16.dp)
            ) {
                Text(
                    "COMPLIANCE CABINET: ${mission.name}",
                    style = MaterialTheme.typography.labelSmall,
                    color = ElectricBlue,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    "TECHNICAL & REGULATORY DOCUMENTATION",
                    style = MaterialTheme.typography.titleMedium,
                    color = WarmOffWhite,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    "Newton Rockets Ltd. enforces rigid safety verification. All regulatory documents must be APPROVED before launch.",
                    style = MaterialTheme.typography.bodySmall,
                    color = LightSteel
                )
            }
        }

        if (documents.isEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(120.dp)
                        .border(1.dp, SteelGray),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        "No technical files loaded for this contract.",
                        style = MaterialTheme.typography.bodySmall,
                        color = LightSteel,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
        }

        items(documents) { doc ->
            DocumentItem(doc = doc)
        }
    }
}

@Composable
fun DocumentItem(doc: DocumentEntity) {
    val statusColor = when (doc.status) {
        "APPROVED" -> SignalGreen
        "UNDER_REVIEW", "SUBMITTED" -> WarningAmber
        else -> AlertRed
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, SteelGray)
            .background(GraphiteMedium)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                doc.name,
                style = MaterialTheme.typography.bodyMedium,
                color = WarmOffWhite,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace
            )
            Text(
                doc.status,
                style = MaterialTheme.typography.labelSmall,
                color = statusColor,
                fontFamily = FontFamily.Monospace,
                modifier = Modifier
                    .border(1.dp, statusColor.copy(alpha = 0.5f))
                    .padding(horizontal = 6.dp, vertical = 2.dp)
            )
        }

        Text(
            "CATEGORY: ${doc.category} | UPDATED: ${formatDate(doc.updatedTime)}",
            style = MaterialTheme.typography.labelSmall,
            color = LightSteel,
            fontFamily = FontFamily.Monospace,
            fontSize = 10.sp
        )

        Text(
            doc.contentSummary,
            style = MaterialTheme.typography.bodySmall,
            color = LightSteel,
            lineHeight = 16.sp
        )
    }
}

private fun formatDate(time: Long): String {
    // Simple mock formatter
    return "2026-09-28 10:00"
}
