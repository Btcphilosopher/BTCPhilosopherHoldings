package com.example.data

import kotlin.math.*

// Enums for spacecraft and orbital categories
enum class SpacecraftClass(val label: String) {
    CUBESAT("CubeSat (1U-12U)"),
    SMALLSAT("SmallSat (100-500kg)"),
    EARTH_OBSERVATION("Earth Observation"),
    COMMUNICATIONS("Communications Satellite"),
    SCIENTIFIC("Scientific Observatory"),
    TECH_DEMO("Technology Demonstrator"),
    CUSTOM("Custom Spacecraft")
}

enum class OrbitType(val label: String) {
    LEO("Low Earth Orbit (LEO)"),
    SSO("Sun-Synchronous Orbit (SSO)"),
    POLAR("Polar Orbit"),
    EQUATORIAL("Equatorial Orbit"),
    CUSTOM("Custom Arbitrary Orbit")
}

// Orbit Keplerian Parameters
data class OrbitParameters(
    val altitudeKm: Double = 500.0,
    val inclinationDeg: Double = 45.0,
    val eccentricity: Double = 0.0, // circular default
    val raanDeg: Double = 0.0,
    val argOfPerigeeDeg: Double = 0.0
) {
    companion object {
        val LEO_PRESET = OrbitParameters(400.0, 51.6, 0.0, 180.0, 0.0)
        val SSO_PRESET = OrbitParameters(600.0, 97.8, 0.001, 220.0, 90.0)
        val POLAR_PRESET = OrbitParameters(750.0, 90.0, 0.0, 120.0, 0.0)
        val EQUATORIAL_PRESET = OrbitParameters(550.0, 0.0, 0.0, 0.0, 0.0)
    }
}

// Physical constants for Earth
object EarthPhysics {
    const val RADIUS_KM = 6378.137
    const val MU = 398600.4418 // km^3 / s^2 (Earth's standard gravitational parameter)
    const val ROTATION_RATE_RAD_S = 7.292115e-5 // Earth's angular speed
}

// 3D Cartesian Coordinate
data class Vector3D(val x: Double, val y: Double, val z: Double)

// Propagator output representing state at a specific time t
data class OrbitState(
    val r: Vector3D,       // Position vector in geocentric inertial frame (km)
    val v: Vector3D,       // Velocity vector in geocentric inertial frame (km/s)
    val altitudeKm: Double,
    val velocityKms: Double,
    val latitudeDeg: Double,
    val longitudeDeg: Double,
    val orbitalPeriodSeconds: Double,
    val specificEnergy: Double,
    val angularMomentum: Double
)

// Main Orbital Propagation Engine
object OrbitalPropagator {

    /**
     * Propagates a Keplerian orbit over a time t (seconds) since epoch.
     * Computes Kepler's equation and translates position to geodetic lat/lon coordinates
     * accounting for Earth's rotation.
     */
    fun propagate(params: OrbitParameters, timeSeconds: Double): OrbitState {
        val mu = EarthPhysics.MU
        val rEarth = EarthPhysics.RADIUS_KM
        
        // 1. Semi-major axis (a)
        val a = rEarth + params.altitudeKm
        
        // 2. Orbital Period (T = 2 * PI * sqrt(a^3 / mu))
        val period = 2.0 * PI * sqrt(a.pow(3) / mu)
        
        // 3. Mean motion (n = 2 * PI / T)
        val n = 2.0 * PI / period
        
        // 4. Mean anomaly (M)
        val m0 = 0.0 // epoch anomaly at t=0
        var M = (m0 + n * timeSeconds) % (2.0 * PI)
        if (M < 0) M += 2.0 * PI
        
        // 5. Solve Kepler's Equation for Eccentric Anomaly (E - e * sin(E) = M)
        val e = max(0.0, min(0.99, params.eccentricity)) // bound eccentricity
        var E = M
        val maxIterations = 10
        val tolerance = 1e-8
        for (i in 0 until maxIterations) {
            val deltaE = (E - e * sin(E) - M) / (1.0 - e * cos(E))
            E -= deltaE
            if (abs(deltaE) < tolerance) break
        }
        
        // 6. True Anomaly (v)
        val trueAnomaly = 2.0 * atan2(
            sqrt(1.0 + e) * sin(E / 2.0),
            sqrt(1.0 - e) * cos(E / 2.0)
        )
        
        // 7. Distance from center of Earth (r = a * (1 - e^2) / (1 + e * cos(v)))
        val rMagnitude = a * (1.0 - e.pow(2)) / (1.0 + e * cos(trueAnomaly))
        val currentAltitude = rMagnitude - rEarth
        
        // 8. Velocity magnitude (vis-viva: v = sqrt(mu * (2/r - 1/a)))
        val currentVelocity = sqrt(mu * (2.0 / rMagnitude - 1.0 / a))
        
        // 9. Coordinate generation in the orbital plane
        val argumentOfLatitude = Math.toRadians(params.argOfPerigeeDeg) + trueAnomaly
        val xp = rMagnitude * cos(argumentOfLatitude)
        val yp = rMagnitude * sin(argumentOfLatitude)
        
        // 10. Transform orbital plane to 3D Geocentric Equatorial Inertial Frame (ECI)
        val raanRad = Math.toRadians(params.raanDeg)
        val incRad = Math.toRadians(params.inclinationDeg)
        
        val cosR = cos(raanRad)
        val sinR = sin(raanRad)
        val cosI = cos(incRad)
        val sinI = sin(incRad)
        
        // ECI Cartesian positions
        val rx = xp * cosR - yp * sinR * cosI
        val ry = xp * sinR + yp * cosR * cosI
        val rz = yp * sinI
        
        // Approximate velocities in ECI (used for display, simple derivative representation)
        // Specific energy (E = v^2/2 - mu/r = -mu/2a)
        val specificEnergy = -mu / (2.0 * a)
        
        // Specific angular momentum h = r * v_perp
        val h = sqrt(mu * a * (1.0 - e.pow(2)))
        
        val vx = - (mu / h) * (sinR * (sin(argumentOfLatitude) + e * sin(Math.toRadians(params.argOfPerigeeDeg))) + cosR * (cos(argumentOfLatitude) + e * cos(Math.toRadians(params.argOfPerigeeDeg))) * cosI)
        val vy = (mu / h) * (cosR * (sin(argumentOfLatitude) + e * sin(Math.toRadians(params.argOfPerigeeDeg))) - sinR * (cos(argumentOfLatitude) + e * cos(Math.toRadians(params.argOfPerigeeDeg))) * cosI)
        val vz = (mu / h) * (cos(argumentOfLatitude) + e * cos(Math.toRadians(params.argOfPerigeeDeg))) * sinI
        
        // 11. Calculate Right Ascension (alpha) and Declination (delta)
        val alpha = atan2(ry, rx)
        val delta = asin(rz / rMagnitude)
        
        // 12. Geodetic coordinates taking Earth's Greenwich Sidereal rotation into account
        val earthRotationAngle = (EarthPhysics.ROTATION_RATE_RAD_S * timeSeconds) % (2.0 * PI)
        
        var longitudeRad = alpha - earthRotationAngle
        // Wrap longitude to [-PI, PI]
        while (longitudeRad < -PI) longitudeRad += 2.0 * PI
        while (longitudeRad > PI) longitudeRad -= 2.0 * PI
        
        val latitudeDeg = Math.toDegrees(delta)
        val longitudeDeg = Math.toDegrees(longitudeRad)
        
        return OrbitState(
            r = Vector3D(rx, ry, rz),
            v = Vector3D(vx, vy, vz),
            altitudeKm = currentAltitude,
            velocityKms = currentVelocity,
            latitudeDeg = latitudeDeg,
            longitudeDeg = longitudeDeg,
            orbitalPeriodSeconds = period,
            specificEnergy = specificEnergy,
            angularMomentum = h
        )
    }

    /**
     * Generates a list of LatLng pairs mapping the projected future ground track of the spacecraft.
     */
    fun generateGroundTrack(params: OrbitParameters, startTimeSeconds: Double, numPoints: Int = 100): List<Pair<Double, Double>> {
        val period = 2.0 * PI * sqrt((EarthPhysics.RADIUS_KM + params.altitudeKm).pow(3) / EarthPhysics.MU)
        val step = period / numPoints
        val track = mutableListOf<Pair<Double, Double>>()
        for (i in 0 until numPoints) {
            val t = startTimeSeconds + (i * step)
            val state = propagate(params, t)
            track.add(Pair(state.latitudeDeg, state.longitudeDeg))
        }
        return track
    }
}
