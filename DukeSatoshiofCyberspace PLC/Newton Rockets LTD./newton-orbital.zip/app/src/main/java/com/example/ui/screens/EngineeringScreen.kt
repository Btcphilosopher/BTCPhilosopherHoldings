package com.example.ui.screens

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.*
import com.example.ui.theme.*
import com.example.viewmodel.NewtonViewModel
import kotlin.math.PI
import kotlin.math.sqrt
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*

@Composable
fun EngineeringScreen(
    viewModel: NewtonViewModel,
    modifier: Modifier = Modifier
) {
    val activeMission by viewModel.activeMission.collectAsStateWithLifecycle()
    val activeSpacecraft by viewModel.activeSpacecraft.collectAsStateWithLifecycle()
    val elapsedSeconds by viewModel.simElapsedSeconds.collectAsStateWithLifecycle()

    if (activeMission == null || activeSpacecraft == null) {
        Column(
            modifier = modifier
                .fillMaxSize()
                .background(GraphiteDark)
                .padding(24.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(Icons.Default.Info, contentDescription = null, modifier = Modifier.size(64.dp), tint = LightSteel)
            Spacer(modifier = Modifier.height(16.dp))
            Text(
                "ENGINEERING DIAGNOSTICS TERMINAL",
                style = MaterialTheme.typography.titleMedium,
                color = WarmOffWhite,
                fontFamily = FontFamily.Monospace
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                "No active spacecraft telemetry stream found. Link an operational satellite flight from Mission Control first.",
                style = MaterialTheme.typography.bodySmall,
                color = LightSteel
            )
        }
        return
    }

    val spacecraft = activeSpacecraft!!
    val orbitParams = OrbitParameters(
        spacecraft.altitudeKm, spacecraft.inclinationDeg,
        spacecraft.eccentricity, spacecraft.raanDeg, spacecraft.argOfPerigeeDeg
    )

    // Run propagation mechanics on the current elapsed time
    val state = OrbitalPropagator.propagate(orbitParams, elapsedSeconds.toDouble())

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(GraphiteDark)
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Monospace Header
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, SteelGray)
                .background(GraphiteMedium)
                .padding(16.dp)
        ) {
            Text(
                "NEWTON INSTRUMENTATION LABORATORY",
                style = MaterialTheme.typography.labelSmall,
                color = ElectricBlue,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold
            )
            Text(
                "HIGH-PRECISION KEPLERIAN VECTOR DESTRUCT MATRIX",
                style = MaterialTheme.typography.titleLarge,
                color = WarmOffWhite,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                "PHYSICS FRAME OF REFERENCE: ECI J2000 EQUATORIAL | EPOCH: J2026.74",
                style = MaterialTheme.typography.labelSmall,
                color = LightSteel,
                fontFamily = FontFamily.Monospace
            )
        }

        // Split Grid Row
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Left block: Coordinate matrices
            Column(
                modifier = Modifier
                    .weight(1f)
                    .border(1.dp, SteelGray)
                    .background(Color.Black.copy(alpha = 0.2f))
                    .padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    "GEOCENTRIC POSITION VECTOR (r)",
                    style = MaterialTheme.typography.labelSmall,
                    color = ElectricBlue,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
                VectorRow("r_x (X-Inertial)", "${state.r.x.round(4)} km")
                VectorRow("r_y (Y-Inertial)", "${state.r.y.round(4)} km")
                VectorRow("r_z (Z-Inertial)", "${state.r.z.round(4)} km")
                VectorRow("Radius Magnitude (|r|)", "${(EarthPhysics.RADIUS_KM + state.altitudeKm).round(4)} km")

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    "GEOCENTRIC VELOCITY VECTOR (v)",
                    style = MaterialTheme.typography.labelSmall,
                    color = ElectricBlue,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
                VectorRow("v_x (X-Velocity)", "${state.v.x.round(6)} km/s")
                VectorRow("v_y (Y-Velocity)", "${state.v.y.round(6)} km/s")
                VectorRow("v_z (Z-Velocity)", "${state.v.z.round(6)} km/s")
                VectorRow("Velocity Magnitude (|v|)", "${state.velocityKms.round(6)} km/s")
            }

            // Right block: Orbital elements
            Column(
                modifier = Modifier
                    .weight(1f)
                    .border(1.dp, SteelGray)
                    .background(Color.Black.copy(alpha = 0.2f))
                    .padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    "INTEGRALS OF THE MOTION",
                    style = MaterialTheme.typography.labelSmall,
                    color = ElectricBlue,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
                VectorRow("Specific Energy (ε)", "${state.specificEnergy.round(4)} km²/s²")
                VectorRow("Angular Momentum (h)", "${state.angularMomentum.round(4)} km²/s")
                VectorRow("Semi-major Axis (a)", "${(EarthPhysics.RADIUS_KM + spacecraft.altitudeKm).round(3)} km")
                VectorRow("Eccentricity (e)", "${spacecraft.eccentricity.round(6)}")
                VectorRow("Inclination (i)", "${spacecraft.inclinationDeg.round(4)}°")
                VectorRow("RAAN (Ω)", "${spacecraft.raanDeg.round(4)}°")
                VectorRow("Arg of Perigee (ω)", "${spacecraft.argOfPerigeeDeg.round(4)}°")
                
                // Greenwich Earth angle
                val gmstRad = (EarthPhysics.ROTATION_RATE_RAD_S * elapsedSeconds) % (2.0 * PI)
                val gmstDeg = Math.toDegrees(gmstRad)
                VectorRow("Sidereal Earth GMST", "${gmstDeg.round(3)}°")
            }
        }

        // Additional information banner
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, SteelGray)
                .background(GraphiteMedium)
                .padding(16.dp)
        ) {
            Text(
                "PROPAGATOR VERIFICATION METADATA",
                style = MaterialTheme.typography.labelSmall,
                color = LightSteel,
                fontFamily = FontFamily.Monospace
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                "Keplerian solver compiled utilizing native 64-bit IEEE 754 precision floats. Convection models verify deterministic reproducibility across cold restarts.",
                style = MaterialTheme.typography.bodySmall,
                color = LightSteel,
                lineHeight = 16.sp
            )
        }
    }
}

@Composable
fun VectorRow(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            label,
            style = MaterialTheme.typography.bodySmall,
            color = LightSteel,
            fontFamily = FontFamily.Monospace,
            fontSize = 11.sp
        )
        Text(
            value,
            style = MaterialTheme.typography.bodySmall,
            color = WarmOffWhite,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            fontSize = 11.sp
        )
    }
}

private fun Double.round(decimals: Int): Double {
    var multiplier = 1.0
    repeat(decimals) { multiplier *= 10 }
    return kotlin.math.round(this * multiplier) / multiplier
}
