package com.example.data

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

// ----------------------------------------------------
// ENTITIES
// ----------------------------------------------------

@Entity(tableName = "organisations")
data class OrganisationEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val name: String,
    val code: String
)

@Entity(tableName = "spacecraft")
data class SpacecraftEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val name: String,
    val massKg: Double,
    val widthM: Double,
    val heightM: Double,
    val depthM: Double,
    val powerW: Double,
    val spacecraftClass: String, // from SpacecraftClass enum
    val deploymentMechanism: String,
    val organisationId: Int,
    
    // Orbital parameters
    val altitudeKm: Double,
    val inclinationDeg: Double,
    val eccentricity: Double,
    val raanDeg: Double,
    val argOfPerigeeDeg: Double
)

@Entity(tableName = "missions")
data class MissionEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val name: String,
    val spacecraftId: Int,
    val launchVehicleId: String,
    val launchSiteId: String,
    val currentState: String, // MissionState label
    val quotePriceGbp: Double,
    val createdTime: Long = System.currentTimeMillis(),
    val bookedTime: Long? = null,
    val isCompleted: Boolean = false,
    
    // Readiness checklist fields
    val docApproved: Boolean = false,
    val specApproved: Boolean = false,
    val massConfirmed: Boolean = false,
    val orbitConfirmed: Boolean = false,
    val integrationComplete: Boolean = false,
    val safetyReviewApproved: Boolean = false,
    val missionReviewApproved: Boolean = false,
    val launchAuthorityApproved: Boolean = false
)

@Entity(tableName = "telemetry")
data class TelemetryPointEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val missionId: Int,
    val timestamp: Long,
    val phase: String,
    val altitudeKm: Double,
    val velocityKms: Double,
    val latitudeDeg: Double,
    val longitudeDeg: Double,
    val inclinationDeg: Double,
    val batteryPercent: Double,
    val temperatureC: Double,
    val signalDb: Double
)

@Entity(tableName = "mission_events")
data class MissionEventEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val missionId: Int,
    val timestamp: Long,
    val elapsedSeconds: Long,
    val title: String,
    val description: String,
    val severity: String // INFO, WARNING, ALERT, SUCCESS
)

@Entity(tableName = "documents")
data class DocumentEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val missionId: Int,
    val name: String,
    val category: String,
    val status: String, // DRAFT, SUBMITTED, UNDER_REVIEW, APPROVED, REJECTED
    val updatedTime: Long = System.currentTimeMillis(),
    val contentSummary: String
)

@Entity(tableName = "audit_logs")
data class AuditLogEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val timestamp: Long = System.currentTimeMillis(),
    val actor: String,
    val action: String,
    val details: String
)

// ----------------------------------------------------
// DAOS
// ----------------------------------------------------

@Dao
interface NewtonDao {

    // Organisations
    @Query("SELECT * FROM organisations")
    fun getAllOrganisations(): Flow<List<OrganisationEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrganisation(org: OrganisationEntity): Long

    // Spacecraft
    @Query("SELECT * FROM spacecraft WHERE organisationId = :orgId")
    fun getSpacecraftForOrganisation(orgId: Int): Flow<List<SpacecraftEntity>>

    @Query("SELECT * FROM spacecraft")
    fun getAllSpacecraft(): Flow<List<SpacecraftEntity>>

    @Query("SELECT * FROM spacecraft WHERE id = :id")
    suspend fun getSpacecraftById(id: Int): SpacecraftEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSpacecraft(spacecraft: SpacecraftEntity): Long

    @Query("DELETE FROM spacecraft WHERE id = :id")
    suspend fun deleteSpacecraft(id: Int)

    // Missions
    @Query("SELECT * FROM missions ORDER BY createdTime DESC")
    fun getAllMissions(): Flow<List<MissionEntity>>

    @Query("SELECT * FROM missions WHERE id = :id")
    fun getMissionFlow(id: Int): Flow<MissionEntity?>

    @Query("SELECT * FROM missions WHERE id = :id")
    suspend fun getMissionById(id: Int): MissionEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMission(mission: MissionEntity): Long

    @Query("DELETE FROM missions WHERE id = :id")
    suspend fun deleteMission(id: Int)

    // Telemetry
    @Query("SELECT * FROM telemetry WHERE missionId = :missionId ORDER BY timestamp ASC")
    fun getTelemetryForMission(missionId: Int): Flow<List<TelemetryPointEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTelemetryPoint(point: TelemetryPointEntity)

    @Query("DELETE FROM telemetry WHERE missionId = :missionId")
    suspend fun clearTelemetryForMission(missionId: Int)

    // Mission Events
    @Query("SELECT * FROM mission_events WHERE missionId = :missionId ORDER BY timestamp DESC")
    fun getEventsForMission(missionId: Int): Flow<List<MissionEventEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMissionEvent(event: MissionEventEntity)

    @Query("DELETE FROM mission_events WHERE missionId = :missionId")
    suspend fun clearEventsForMission(missionId: Int)

    // Documents
    @Query("SELECT * FROM documents WHERE missionId = :missionId")
    fun getDocumentsForMission(missionId: Int): Flow<List<DocumentEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDocument(doc: DocumentEntity)

    // Audit Logs
    @Query("SELECT * FROM audit_logs ORDER BY timestamp DESC LIMIT 100")
    fun getAuditLogs(): Flow<List<AuditLogEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAuditLog(log: AuditLogEntity)
}

// ----------------------------------------------------
// DATABASE HOLDER
// ----------------------------------------------------

@Database(
    entities = [
        OrganisationEntity::class,
        SpacecraftEntity::class,
        MissionEntity::class,
        TelemetryPointEntity::class,
        MissionEventEntity::class,
        DocumentEntity::class,
        AuditLogEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun newtonDao(): NewtonDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "newton_orbital_database"
                )
                .fallbackToDestructiveMigration()
                .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
