package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = TechBlue,
    onPrimary = Color.White,
    secondary = ElectricBlue,
    onSecondary = Color.Black,
    background = GraphiteDark,
    onBackground = WarmOffWhite,
    surface = GraphiteMedium,
    onSurface = WarmOffWhite,
    surfaceVariant = SteelGray,
    onSurfaceVariant = LightSteel,
    outline = LightSteel,
    error = AlertRed,
    onError = Color.White
)

@Composable
fun MyApplicationTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = DarkColorScheme,
        typography = Typography,
        content = content
    )
}
