package com.example.data

import kotlin.math.max

data class QuoteResult(
    val baseLaunchGbp: Double,
    val payloadIntegrationGbp: Double,
    val orbitalPremiumGbp: Double,
    val rangeOperationsGbp: Double,
    val standardInsuranceGbp: Double,
    val groundSupportGbp: Double,
    val totalGbp: Double
)

object QuoteEngine {
    
    /**
     * Calculates a detailed pricing quote based on multi-factor aerospace economics.
     */
    fun calculateQuote(
        vehicleId: String,
        siteId: String,
        payloadMassKg: Double,
        altitudeKm: Double,
        inclinationDeg: Double,
        spacecraftClass: SpacecraftClass
    ): QuoteResult {
        // Find vehicle base cost
        val vehicle = LaunchVehicle.FLEET.firstOrNull { it.id == vehicleId } ?: LaunchVehicle.FLEET[0]
        val baseLaunchCost = vehicle.baseCostM * 1_000_000.0
        
        // 1. Mass pricing surcharge (fuel & propellant burn costs)
        val payloadIntegrationFee = payloadMassKg * 2500.0
        
        // 2. Orbital altitude and inclination premium
        // Propellant requirement scales with altitude above a 200km baseline and out-of-plane inclination maneuvers
        val altitudeStep = max(0.0, altitudeKm - 200.0) / 10.0
        val altitudePremium = altitudeStep * 1200.0
        val inclinationFactor = 1.0 + (inclinationDeg / 180.0) * 0.15
        
        val orbitalPremium = (baseLaunchCost * 0.05 + altitudePremium) * inclinationFactor
        
        // 3. Range logistics and site operations fees
        val rangeOpsFee = when (siteId) {
            "shetland" -> 150_000.0
            "sutherland" -> 100_000.0
            "ocean" -> 450_000.0 // Equatorial oceanic platform logistics are higher
            else -> 120_000.0
        }
        
        // 4. Ground support and tracking operations
        val groundSupportFee = when (spacecraftClass) {
            SpacecraftClass.CUBESAT -> 50_000.0
            SpacecraftClass.SMALLSAT -> 100_000.0
            SpacecraftClass.EARTH_OBSERVATION -> 150_000.0
            SpacecraftClass.COMMUNICATIONS -> 220_000.0
            SpacecraftClass.SCIENTIFIC -> 180_000.0
            SpacecraftClass.TECH_DEMO -> 80_000.0
            SpacecraftClass.CUSTOM -> 250_000.0
        }
        
        // 5. Insurance premium
        // Standard payload insurance is approximately 3.2% of launch logistics and assumed spacecraft value
        val estimatedSpacecraftValue = payloadMassKg * 30_000.0 // Assume £30k value per kg of high-end satellite
        val valuationBase = baseLaunchCost + payloadIntegrationFee + orbitalPremium + rangeOpsFee + groundSupportFee + estimatedSpacecraftValue
        val insurancePremium = valuationBase * 0.035
        
        val total = baseLaunchCost + payloadIntegrationFee + orbitalPremium + rangeOpsFee + groundSupportFee + insurancePremium
        
        return QuoteResult(
            baseLaunchGbp = baseLaunchCost,
            payloadIntegrationGbp = payloadIntegrationFee,
            orbitalPremiumGbp = orbitalPremium,
            rangeOperationsGbp = rangeOpsFee,
            standardInsuranceGbp = insurancePremium,
            groundSupportGbp = groundSupportFee,
            totalGbp = total
        )
    }
}
