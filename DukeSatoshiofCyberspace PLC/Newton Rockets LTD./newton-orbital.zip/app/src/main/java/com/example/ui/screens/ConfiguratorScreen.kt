package com.example.ui.screens

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.*
import com.example.ui.components.GroundTrackMap
import com.example.ui.components.OrbitalVisualizer
import com.example.ui.theme.*
import com.example.viewmodel.NewtonViewModel

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ConfiguratorScreen(
    viewModel: NewtonViewModel,
    modifier: Modifier = Modifier
) {
    var activeStep by remember { mutableIntStateOf(1) } // 1: SPACECRAFT, 2: ORBIT, 3: VEHICLE & SITE, 4: QUOTE

    // Configurator inputs
    val scName by viewModel.configSpacecraftName.collectAsStateWithLifecycle()
    val scMass by viewModel.configSpacecraftMass.collectAsStateWithLifecycle()
    val scWidth by viewModel.configSpacecraftWidth.collectAsStateWithLifecycle()
    val scHeight by viewModel.configSpacecraftHeight.collectAsStateWithLifecycle()
    val scDepth by viewModel.configSpacecraftDepth.collectAsStateWithLifecycle()
    val scPower by viewModel.configSpacecraftPower.collectAsStateWithLifecycle()
    val scClass by viewModel.configSpacecraftClass.collectAsStateWithLifecycle()
    val scDeployer by viewModel.configDeploymentMechanism.collectAsStateWithLifecycle()

    val orbitType by viewModel.configOrbitType.collectAsStateWithLifecycle()
    val altKm by viewModel.configAltitudeKm.collectAsStateWithLifecycle()
    val incDeg by viewModel.configInclinationDeg.collectAsStateWithLifecycle()
    val ecc by viewModel.configEccentricity.collectAsStateWithLifecycle()
    val raan by viewModel.configRaanDeg.collectAsStateWithLifecycle()
    val argOfPerigee by viewModel.configArgOfPerigeeDeg.collectAsStateWithLifecycle()

    val selectedVehicle by viewModel.configSelectedVehicle.collectAsStateWithLifecycle()
    val selectedSite by viewModel.configSelectedSite.collectAsStateWithLifecycle()
    val quote by viewModel.calculatedQuote.collectAsStateWithLifecycle()

    val scrollState = rememberScrollState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(GraphiteDark)
    ) {
        // Step Tracker header
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(GraphiteMedium)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 12.dp, horizontal = 16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    "MISSION PLANNER TERMINAL",
                    style = MaterialTheme.typography.labelMedium,
                    color = ElectricBlue,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(1, 2, 3, 4).forEach { step ->
                        Box(
                            modifier = Modifier
                                .size(24.dp)
                                .border(
                                    1.dp,
                                    if (step == activeStep) ElectricBlue else LightSteel.copy(alpha = 0.3f)
                                )
                                .background(if (step == activeStep) TechBlue.copy(alpha = 0.2f) else Color.Transparent),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                "$step",
                                color = if (step == activeStep) ElectricBlue else LightSteel,
                                style = MaterialTheme.typography.labelSmall,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
            HorizontalDivider(modifier = Modifier.fillMaxWidth(), thickness = 1.dp, color = SteelGray)
        }

        // Split Layout: Inputs on left/top, 3D visualization on right/bottom
        BoxWithConstraints(modifier = Modifier.weight(1f)) {
            val isExpanded = maxWidth > 650.dp

            if (isExpanded) {
                Row(modifier = Modifier.fillMaxSize()) {
                    // Left Input panel
                    Column(
                        modifier = Modifier
                            .weight(1.1f)
                            .fillMaxHeight()
                            .verticalScroll(scrollState)
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        StepContent(
                            step = activeStep,
                            viewModel = viewModel,
                            scName = scName, scMass = scMass, scWidth = scWidth, scHeight = scHeight, scDepth = scDepth, scPower = scPower, scClass = scClass, scDeployer = scDeployer,
                            orbitType = orbitType, altKm = altKm, incDeg = incDeg, ecc = ecc, raan = raan, argOfPerigee = argOfPerigee,
                            selectedVehicle = selectedVehicle, selectedSite = selectedSite, quote = quote
                        )
                        Spacer(modifier = Modifier.weight(1f))
                        NavigationButtons(
                            activeStep = activeStep,
                            onPrev = { activeStep-- },
                            onNext = { activeStep++ },
                            onBook = { viewModel.bookLaunchMission() }
                        )
                    }

                    // Vertical fine border line
                    Box(modifier = Modifier.fillMaxHeight().width(1.dp).background(SteelGray))

                    // Right Live Simulation Twin Visualizer
                    Column(
                        modifier = Modifier
                            .weight(1.3f)
                            .fillMaxHeight()
                    ) {
                        Box(modifier = Modifier.weight(1f).fillMaxWidth()) {
                            OrbitalVisualizer(
                                orbitParams = OrbitParameters(altKm, incDeg, ecc, raan, argOfPerigee),
                                simTimeSeconds = 0.0,
                                modifier = Modifier.fillMaxSize()
                            )
                        }
                        Box(modifier = Modifier.height(1.dp).fillMaxWidth().background(SteelGray))
                        Box(modifier = Modifier.weight(1f).fillMaxWidth()) {
                            GroundTrackMap(
                                orbitParams = OrbitParameters(altKm, incDeg, ecc, raan, argOfPerigee),
                                simTimeSeconds = 0.0,
                                modifier = Modifier.fillMaxSize()
                            )
                        }
                    }
                }
            } else {
                // Compact Vertical layout
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .verticalScroll(scrollState)
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(280.dp)
                    ) {
                        OrbitalVisualizer(
                            orbitParams = OrbitParameters(altKm, incDeg, ecc, raan, argOfPerigee),
                            simTimeSeconds = 0.0,
                            modifier = Modifier.fillMaxSize()
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    StepContent(
                        step = activeStep,
                        viewModel = viewModel,
                        scName = scName, scMass = scMass, scWidth = scWidth, scHeight = scHeight, scDepth = scDepth, scPower = scPower, scClass = scClass, scDeployer = scDeployer,
                        orbitType = orbitType, altKm = altKm, incDeg = incDeg, ecc = ecc, raan = raan, argOfPerigee = argOfPerigee,
                        selectedVehicle = selectedVehicle, selectedSite = selectedSite, quote = quote
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    NavigationButtons(
                        activeStep = activeStep,
                        onPrev = { activeStep-- },
                        onNext = { activeStep++ },
                        onBook = { viewModel.bookLaunchMission() }
                    )
                }
            }
        }
    }
}

@Composable
fun StepContent(
    step: Int,
    viewModel: NewtonViewModel,
    scName: String, scMass: String, scWidth: String, scHeight: String, scDepth: String, scPower: String, scClass: SpacecraftClass, scDeployer: String,
    orbitType: OrbitType, altKm: Double, incDeg: Double, ecc: Double, raan: Double, argOfPerigee: Double,
    selectedVehicle: String, selectedSite: String, quote: QuoteResult
) {
    when (step) {
        1 -> {
            Text(
                "STAGE 1: SPACECRAFT PARAMETERS",
                style = MaterialTheme.typography.titleMedium,
                color = WarmOffWhite,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold
            )
            Text(
                "Enter physical hardware parameters for safety, fit checks, and range configuration.",
                style = MaterialTheme.typography.bodySmall,
                color = LightSteel
            )
            Spacer(modifier = Modifier.height(8.dp))

            OutlinedTextField(
                value = scName,
                onValueChange = { viewModel.configSpacecraftName.value = it },
                label = { Text("Spacecraft Name") },
                textStyle = MaterialTheme.typography.bodyMedium.copy(fontFamily = FontFamily.Monospace),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = ElectricBlue,
                    unfocusedBorderColor = SteelGray,
                    focusedLabelColor = ElectricBlue,
                    unfocusedLabelColor = LightSteel
                ),
                modifier = Modifier.fillMaxWidth().testTag("spacecraft_name_input")
            )

            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedTextField(
                    value = scMass,
                    onValueChange = { viewModel.configSpacecraftMass.value = it },
                    label = { Text("Mass (kg)") },
                    textStyle = MaterialTheme.typography.bodyMedium.copy(fontFamily = FontFamily.Monospace),
                    colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = ElectricBlue, unfocusedBorderColor = SteelGray),
                    modifier = Modifier.weight(1f).testTag("spacecraft_mass_input")
                )
                OutlinedTextField(
                    value = scPower,
                    onValueChange = { viewModel.configSpacecraftPower.value = it },
                    label = { Text("Power Req (W)") },
                    textStyle = MaterialTheme.typography.bodyMedium.copy(fontFamily = FontFamily.Monospace),
                    colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = ElectricBlue, unfocusedBorderColor = SteelGray),
                    modifier = Modifier.weight(1f)
                )
            }

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = scWidth,
                    onValueChange = { viewModel.configSpacecraftWidth.value = it },
                    label = { Text("Width (m)") },
                    textStyle = MaterialTheme.typography.bodyMedium.copy(fontFamily = FontFamily.Monospace),
                    colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = ElectricBlue, unfocusedBorderColor = SteelGray),
                    modifier = Modifier.weight(1f)
                )
                OutlinedTextField(
                    value = scHeight,
                    onValueChange = { viewModel.configSpacecraftHeight.value = it },
                    label = { Text("Height (m)") },
                    textStyle = MaterialTheme.typography.bodyMedium.copy(fontFamily = FontFamily.Monospace),
                    colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = ElectricBlue, unfocusedBorderColor = SteelGray),
                    modifier = Modifier.weight(1f)
                )
                OutlinedTextField(
                    value = scDepth,
                    onValueChange = { viewModel.configSpacecraftDepth.value = it },
                    label = { Text("Depth (m)") },
                    textStyle = MaterialTheme.typography.bodyMedium.copy(fontFamily = FontFamily.Monospace),
                    colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = ElectricBlue, unfocusedBorderColor = SteelGray),
                    modifier = Modifier.weight(1f)
                )
            }

            Text("Spacecraft Mission Classification", style = MaterialTheme.typography.labelSmall, color = LightSteel, fontFamily = FontFamily.Monospace)
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                SpacecraftClass.values().forEach { sCls ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(
                                1.dp,
                                if (scClass == sCls) ElectricBlue else SteelGray
                            )
                            .background(if (scClass == sCls) TechBlue.copy(alpha = 0.15f) else Color.Transparent)
                            .clickable { viewModel.configSpacecraftClass.value = sCls }
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(
                            selected = scClass == sCls,
                            onClick = { viewModel.configSpacecraftClass.value = sCls },
                            colors = RadioButtonDefaults.colors(selectedColor = ElectricBlue)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(sCls.label, color = WarmOffWhite, style = MaterialTheme.typography.bodyMedium, fontFamily = FontFamily.Monospace)
                    }
                }
            }
        }
        2 -> {
            Text(
                "STAGE 2: TARGET ORBIT ENVELOPE",
                style = MaterialTheme.typography.titleMedium,
                color = WarmOffWhite,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold
            )
            Text(
                "Select a pre-designed orbital orbital template, or customize parameters with the scientific sliders.",
                style = MaterialTheme.typography.bodySmall,
                color = LightSteel
            )
            Spacer(modifier = Modifier.height(12.dp))

            // Presets row
            Row(
                modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OrbitType.values().forEach { preset ->
                    val active = orbitType == preset
                    Text(
                        preset.name,
                        style = MaterialTheme.typography.labelSmall,
                        fontFamily = FontFamily.Monospace,
                        color = if (active) ElectricBlue else LightSteel,
                        modifier = Modifier
                            .border(1.dp, if (active) ElectricBlue else SteelGray)
                            .background(if (active) TechBlue.copy(alpha = 0.1f) else Color.Transparent)
                            .clickable { viewModel.applyPresetOrbit(preset) }
                            .padding(horizontal = 10.dp, vertical = 6.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Altitude Slider
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Altitude (Circularized)", style = MaterialTheme.typography.bodySmall, color = WarmOffWhite, fontFamily = FontFamily.Monospace)
                    Text("${altKm.toInt()} km", style = MaterialTheme.typography.bodySmall, color = ElectricBlue, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                }
                Slider(
                    value = altKm.toFloat(),
                    onValueChange = { viewModel.configAltitudeKm.value = it.toDouble().round(1) },
                    valueRange = 150f..2000f,
                    colors = SliderDefaults.colors(thumbColor = ElectricBlue, activeTrackColor = TechBlue)
                )
            }

            // Inclination Slider
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Orbit Inclination", style = MaterialTheme.typography.bodySmall, color = WarmOffWhite, fontFamily = FontFamily.Monospace)
                    Text("${incDeg.round(2)}°", style = MaterialTheme.typography.bodySmall, color = ElectricBlue, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                }
                Slider(
                    value = incDeg.toFloat(),
                    onValueChange = { viewModel.configInclinationDeg.value = it.toDouble().round(2) },
                    valueRange = 0f..180f,
                    colors = SliderDefaults.colors(thumbColor = ElectricBlue, activeTrackColor = TechBlue)
                )
            }

            // Mathematical calculation derived indicators (Ground Track Period)
            val periodMin = 2.0 * Math.PI * Math.sqrt(Math.pow(6378.137 + altKm, 3.0) / 398600.4418) / 60.0
            val velocity = Math.sqrt(398600.4418 / (6378.137 + altKm))
            
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, SteelGray)
                    .background(Color.Black.copy(alpha = 0.3f))
                    .padding(12.dp)
            ) {
                Text("PROPAGATION CONSTANTS (2-BODY DYNAMICS)", style = MaterialTheme.typography.labelSmall, color = LightSteel, fontFamily = FontFamily.Monospace)
                Spacer(modifier = Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("ORBITAL PERIOD", style = MaterialTheme.typography.labelSmall, color = LightSteel, fontSize = 9.sp)
                        Text("${periodMin.round(1)} MIN", style = MaterialTheme.typography.bodyMedium, color = WarmOffWhite, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                    }
                    Column(modifier = Modifier.weight(1f)) {
                        Text("VELOCITY MAGNITUDE", style = MaterialTheme.typography.labelSmall, color = LightSteel, fontSize = 9.sp)
                        Text("${velocity.round(3)} KM/S", style = MaterialTheme.typography.bodyMedium, color = WarmOffWhite, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
        3 -> {
            Text(
                "STAGE 3: BOOSTER & SITE COUPLING",
                style = MaterialTheme.typography.titleMedium,
                color = WarmOffWhite,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold
            )
            Text(
                "Pair launch specifications with fleet hardware capabilities and site constraints.",
                style = MaterialTheme.typography.bodySmall,
                color = LightSteel
            )
            Spacer(modifier = Modifier.height(16.dp))

            Text("Select Newton Launch Vehicle", style = MaterialTheme.typography.labelSmall, color = LightSteel, fontFamily = FontFamily.Monospace)
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                LaunchVehicle.FLEET.forEach { vehicle ->
                    val active = selectedVehicle == vehicle.id
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, if (active) ElectricBlue else SteelGray)
                            .background(if (active) TechBlue.copy(alpha = 0.1f) else Color.Transparent)
                            .clickable { viewModel.configSelectedVehicle.value = vehicle.id }
                            .padding(12.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            RadioButton(selected = active, onClick = { viewModel.configSelectedVehicle.value = vehicle.id }, colors = RadioButtonDefaults.colors(selectedColor = ElectricBlue))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(vehicle.name, color = WarmOffWhite, style = MaterialTheme.typography.bodyMedium, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                        }
                        Text("Capacity: Up to ${vehicle.payloadCapacityKg.toInt()}kg LEO", color = LightSteel, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(start = 40.dp))
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            Text("Select Launch Spaceport / Range", style = MaterialTheme.typography.labelSmall, color = LightSteel, fontFamily = FontFamily.Monospace)
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                LaunchSite.SITES.forEach { site ->
                    val active = selectedSite == site.id
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, if (active) ElectricBlue else SteelGray)
                            .background(if (active) TechBlue.copy(alpha = 0.1f) else Color.Transparent)
                            .clickable { viewModel.configSelectedSite.value = site.id }
                            .padding(12.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            RadioButton(selected = active, onClick = { viewModel.configSelectedSite.value = site.id }, colors = RadioButtonDefaults.colors(selectedColor = ElectricBlue))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(site.name, color = WarmOffWhite, style = MaterialTheme.typography.bodyMedium, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                        }
                        Text(site.location, color = LightSteel, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(start = 40.dp))
                    }
                }
            }
        }
        4 -> {
            Text(
                "STAGE 4: LAUNCH PRICING QUOTE",
                style = MaterialTheme.typography.titleMedium,
                color = WarmOffWhite,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold
            )
            Text(
                "Final itemized billing analysis based on spacecraft mass, launch logistics, range operations, and system integration.",
                style = MaterialTheme.typography.bodySmall,
                color = LightSteel
            )
            Spacer(modifier = Modifier.height(16.dp))

            // Breakdown card
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, SteelGray)
                    .background(GraphiteMedium)
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text("ITEMIZED LAUNCH ESTIMATE", style = MaterialTheme.typography.labelSmall, color = ElectricBlue, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                Box(modifier = Modifier.fillMaxWidth().height(1.dp).background(SteelGray))

                QuoteRow("BASE LAUNCH SERVICES (VEHICLE)", quote.baseLaunchGbp)
                QuoteRow("PAYLOAD INTEGRATION & MECHANISMS", quote.payloadIntegrationGbp)
                QuoteRow("ORBIT PROFILE MANEUVER MARGIN", quote.orbitalPremiumGbp)
                QuoteRow("RANGE SAFETY & SITE OPERATIONS", quote.rangeOperationsGbp)
                QuoteRow("GROUND TELEMETRY LINK SUBSCRIPTION", quote.groundSupportGbp)
                QuoteRow("FLIGHT INDEMNITY / INSURANCE", quote.standardInsuranceGbp)

                Box(modifier = Modifier.fillMaxWidth().height(1.dp).background(SteelGray))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("TOTAL MISSION COST (GBP)", style = MaterialTheme.typography.bodyMedium, color = WarmOffWhite, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                    Text("£${"%,.2f".format(quote.totalGbp)}", style = MaterialTheme.typography.bodyLarge, color = SignalGreen, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                }
            }

            Spacer(modifier = Modifier.height(12.dp))
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, WarningAmber.copy(alpha = 0.3f))
                    .background(WarningAmber.copy(alpha = 0.05f))
                    .padding(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Default.Warning, contentDescription = null, tint = WarningAmber)
                Spacer(modifier = Modifier.width(12.dp))
                Text(
                    "All calculations generated from flight-matching rules. Invoices are subject to UK Space Agency review and standard range safety certification.",
                    style = MaterialTheme.typography.bodySmall,
                    color = WarningAmber
                )
            }
        }
    }
}

@Composable
fun QuoteRow(label: String, value: Double) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, style = MaterialTheme.typography.bodySmall, color = LightSteel, fontFamily = FontFamily.Monospace)
        Text("£${"%,.2f".format(value)}", style = MaterialTheme.typography.bodySmall, color = WarmOffWhite, fontFamily = FontFamily.Monospace)
    }
}

@Composable
fun NavigationButtons(
    activeStep: Int,
    onPrev: () -> Unit,
    onNext: () -> Unit,
    onBook: () -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        if (activeStep > 1) {
            OutlinedButton(
                onClick = onPrev,
                shape = RoundedCornerShape(2.dp),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = ElectricBlue),
                border = BorderStroke(1.dp, SteelGray)
            ) {
                Text("PREVIOUS STAGE", fontFamily = FontFamily.Monospace)
            }
        } else {
            Spacer(modifier = Modifier.width(10.dp))
        }

        if (activeStep < 4) {
            Button(
                onClick = onNext,
                shape = RoundedCornerShape(2.dp),
                colors = ButtonDefaults.buttonColors(containerColor = TechBlue)
            ) {
                Text("CONTINUE", fontFamily = FontFamily.Monospace)
                Spacer(modifier = Modifier.width(8.dp))
                Icon(Icons.Default.ArrowForward, contentDescription = null)
            }
        } else {
            Button(
                onClick = onBook,
                shape = RoundedCornerShape(2.dp),
                colors = ButtonDefaults.buttonColors(containerColor = SignalGreen),
                modifier = Modifier.testTag("book_launch_button")
            ) {
                Icon(Icons.Default.Check, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("BOOK MISSION LAUNCH", fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
            }
        }
    }
}

// Float helper rounding
private fun Double.round(decimals: Int): Double {
    var multiplier = 1.0
    repeat(decimals) { multiplier *= 10 }
    return kotlin.math.round(this * multiplier) / multiplier
}
