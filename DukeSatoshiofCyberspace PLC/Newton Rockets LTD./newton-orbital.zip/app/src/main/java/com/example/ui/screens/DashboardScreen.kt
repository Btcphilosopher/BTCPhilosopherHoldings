package com.example.ui.screens

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.*
import com.example.ui.theme.*
import com.example.viewmodel.NewtonViewModel

@Composable
fun DashboardScreen(
    viewModel: NewtonViewModel,
    modifier: Modifier = Modifier
) {
    val missions by viewModel.missions.collectAsStateWithLifecycle()
    val fleet = LaunchVehicle.FLEET

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(GraphiteDark)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(24.dp)
    ) {
        // Hero Section
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, SteelGray)
                    .background(GraphiteMedium)
                    .padding(24.dp)
            ) {
                Text(
                    "NEWTON ROCKETS LTD.",
                    style = MaterialTheme.typography.labelMedium,
                    color = LightSteel,
                    fontFamily = FontFamily.Monospace,
                    letterSpacing = 2.sp
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    "SATELLITE DELIVERY, TO ORBIT.",
                    style = MaterialTheme.typography.headlineLarge,
                    color = WarmOffWhite,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.SansSerif
                )
                Spacer(modifier = Modifier.height(12.dp))
                Text(
                    "Deploy your spacecraft. Configure custom Keplerian envelopes. Access continuous telemetry stream and digital twins of Newton spaceflight operations.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = LightSteel
                )
                Spacer(modifier = Modifier.height(20.dp))
                Row(
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Button(
                        onClick = { viewModel.currentScreen.value = "configurator" },
                        colors = ButtonDefaults.buttonColors(containerColor = TechBlue),
                        shape = RoundedCornerShape(2.dp),
                        modifier = Modifier.testTag("plan_mission_button")
                    ) {
                        Icon(Icons.Default.Add, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("PLAN A NEW MISSION", fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // Active Missions list
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    "MISSION OPERATIONS MANIFEST",
                    style = MaterialTheme.typography.titleMedium,
                    color = WarmOffWhite,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    "${missions.size} ACTIVE CONTRACTS",
                    style = MaterialTheme.typography.labelSmall,
                    color = ElectricBlue,
                    fontFamily = FontFamily.Monospace
                )
            }
            Spacer(modifier = Modifier.height(8.dp))
            if (missions.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(100.dp)
                        .border(1.dp, SteelGray, RoundedCornerShape(2.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        "No active spacecraft delivery missions booked. Initialize custom flight plan above.",
                        style = MaterialTheme.typography.bodySmall,
                        color = LightSteel,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
        }

        items(missions) { mission ->
            MissionListItem(
                mission = mission,
                onTrack = {
                    viewModel.selectedMissionId.value = mission.id
                    viewModel.currentScreen.value = "control"
                }
            )
        }

        // Newton launcher fleet status
        item {
            Text(
                "LAUNCH VEHICLE FLEET INVENTORY",
                style = MaterialTheme.typography.titleMedium,
                color = WarmOffWhite,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(12.dp))
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                fleet.forEach { vehicle ->
                    VehicleStatusCard(vehicle = vehicle)
                }
            }
        }
    }
}

@Composable
fun MissionListItem(
    mission: MissionEntity,
    onTrack: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, SteelGray)
            .background(GraphiteMedium)
            .clickable { onTrack() }
            .padding(16.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    mission.name,
                    style = MaterialTheme.typography.titleMedium,
                    color = WarmOffWhite,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.width(12.dp))
                // Status Pill
                val statusColor = when (mission.currentState) {
                    "ACTIVE_ORBIT", "COMPLETE" -> SignalGreen
                    "COUNTDOWN", "LAUNCH", "ASCENT", "ORBITAL_INSERTION", "DEPLOYMENT" -> WarningAmber
                    else -> LightSteel
                }
                Text(
                    mission.currentState,
                    style = MaterialTheme.typography.labelSmall,
                    color = statusColor,
                    fontFamily = FontFamily.Monospace,
                    modifier = Modifier
                        .border(1.dp, statusColor.copy(alpha = 0.5f))
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                )
            }
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                "LAUNCHER: ${mission.launchVehicleId} | RANGE: ${mission.launchSiteId.uppercase()} | QUOTE: £${"%,.2f".format(mission.quotePriceGbp)}",
                style = MaterialTheme.typography.bodySmall,
                color = LightSteel,
                fontFamily = FontFamily.Monospace
            )
        }
        Icon(
            Icons.Default.ChevronRight,
            contentDescription = "Navigate to mission control",
            tint = ElectricBlue
        )
    }
}

@Composable
fun VehicleStatusCard(vehicle: LaunchVehicle) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, SteelGray)
            .background(GraphiteMedium)
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                vehicle.name,
                style = MaterialTheme.typography.bodyMedium,
                color = WarmOffWhite,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold
            )
            Text(
                "FLEET STATUS: STANDBY",
                style = MaterialTheme.typography.labelSmall,
                color = SignalGreen,
                fontFamily = FontFamily.Monospace
            )
        }
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            vehicle.description,
            style = MaterialTheme.typography.bodySmall,
            color = LightSteel
        )
        Spacer(modifier = Modifier.height(8.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                "PAYLOAD CAP: ${vehicle.payloadCapacityKg.toInt()} kg",
                style = MaterialTheme.typography.labelSmall,
                color = ElectricBlue,
                fontFamily = FontFamily.Monospace
            )
            Text(
                "BASE LAUNCH: £${vehicle.baseCostM}M",
                style = MaterialTheme.typography.labelSmall,
                color = LightSteel,
                fontFamily = FontFamily.Monospace
            )
        }
    }
}
