# Newton Rockets Ltd. — LH₂ Densification & Conditioning Digital Twin

**RESEARCH / ENGINEERING SIMULATION — NOT FLIGHT-CERTIFIED.**

A first-principles Python digital twin of the cryogenic liquid-hydrogen
densification and conditioning system associated with a large-scale hydrogen
propulsion test facility. It simulates thermodynamics, tank behaviour,
recirculation and conditioning, pump and cavitation diagnostics, transient
mass/energy conservation, sensitivity, and uncertainty — from a real,
validated equation of state up through a control-room-style dashboard.

The engineering model terminates at the **conditioned LH₂ outlet**. Any
downstream combustion or propulsion system is treated as an abstract
boundary condition; this is not, and must never be extended into, a
combustion or propulsion-performance tool.

> **The physics is the product. The digital twin is the interface to the
> physics.** Every number the dashboard shows is traceable to a sensor
> model, a facility parameter, a thermodynamic property, or a calculated
> state — never a decorative placeholder.

---

## 1. Quick start

```bash
python -m venv .venv && source .venv/bin/activate      # or: uv venv && source .venv/bin/activate
pip install -e ".[dev]"                                  # or: uv pip install -e ".[dev]"

newton-lh2 validate
newton-lh2 scenario densification
newton-lh2 simulate --tank-volume 100 --initial-temperature 19.5 --duration 3600
pytest -q
```

Requires **Python 3.12+**. The property engine is backed by
[CoolProp](http://www.coolprop.org/) (`ParaHydrogen`, HEOS backend) —
`pip install coolprop` pulls a prebuilt wheel on all common platforms; no
compiler needed.

---

## 2. Repository layout

```
newton-lh2-twin/
├── src/newton_lh2/
│   ├── thermodynamics/   properties, phase classification, saturation, EOS metadata, validity ranges
│   ├── cryogenics/       tank, heat leak, insulation, recirculation, heat exchanger, densification
│   ├── fluid/             pipe, pressure drop, pump, cavitation diagnostics
│   ├── simulation/        state containers, timestep utilities, ODE solver, events, scenarios A–F
│   ├── models/             facility composition (process train), synthetic telemetry + replay
│   ├── analysis/           density/energy summaries, sensitivity sweeps, Monte Carlo uncertainty
│   └── cli.py               `newton-lh2` command-line interface
├── tests/                  94 pytest tests across every module
├── notebooks/               01–05 validation notebooks
├── dashboard/                self-contained HTML engineering dashboard generator
├── examples/                 runnable example scripts
└── data/                     scratch output directory for generated telemetry/reports
```

---

## 3. Physical model

### 3.1 Thermodynamic property engine (`thermodynamics/`)

All real-fluid properties come from a single place —
`thermodynamics/properties.py` — which wraps CoolProp's `HEOS` backend for
**`ParaHydrogen`** and is the *only* module in the codebase that imports
CoolProp. Every other module (tank, pump, heat exchanger, densification,
…) talks to hydrogen exclusively through `HydrogenProperties`, so the
backend could be swapped for a tabulated or REFPROP source without
touching any component model.

**Why parahydrogen, not normal hydrogen?** Liquid hydrogen at cryogenic
ground-storage conditions is predominantly (>95 %) the para spin isomer
at equilibrium, so `ParaHydrogen` — not the room-temperature
ortho/para-mixture `Hydrogen` fluid — is the physically appropriate model
for an LH₂ facility.

**Reference equation of state:** Leachman, Jacobsen, Penoncello & Lemmon
(2009), *"Fundamental Equations of State for Parahydrogen, Normal
Hydrogen, and Orthohydrogen,"* J. Phys. Chem. Ref. Data 38(3) — the same
family of correlation used by NIST REFPROP.

**Validity envelope.** The simulator refuses to silently extrapolate.
`thermodynamics/validation.py` defines a facility-level envelope
(13.8–320 K, 6 kPa–30 bar by default — deliberately narrower than the
underlying correlation's full 13.8–1000 K / 2 GPa range) and raises
`PropertyRangeError` outside it (or warns, in explicit permissive mode).
A numerically special case is handled explicitly: a P–T flash is
ill-conditioned *exactly on* the saturation curve (T and P are not
independent there); rather than fail on this physically real operating
point (e.g. a pump inlet sitting right at its NPSH margin), the engine
nudges the pressure by a vanishing relative amount and retries.

**Phase classification** (`thermodynamics/phase.py`) is explicit, not
inferred from a density threshold: subcooled liquid, saturated
liquid/vapour, two-phase, superheated vapour, and the three supercritical
regimes, plus a solid flag (checked against the real melting line, not
modelled further).

**Reduced-order cross-check** (`thermodynamics/equation_of_state.py`). A
classical two-parameter Redlich–Kwong cubic EOS and a Rackett
saturated-liquid-density correlation are implemented *only* as an
independent analytic cross-check in the validation notebooks, and as a
degraded-mode fallback if CoolProp is unavailable — never used
operationally. The RK cubic is known to be qualitatively but not
quantitatively reliable for the liquid branch; see
`notebooks/01_property_validation.ipynb` for exactly how far off it runs.

### 3.2 Densification (`cryogenics/densification.py`)

Densification is modelled as a genuine thermodynamic state-change process,
not `density * factor`. Given real initial/final `LH2State`s and a
processed mass:

```
heat_removed      = -m · (h_final − h_initial)
COP_Carnot        = T_cold / (T_warm − T_cold)                  [2nd law bound]
W_min             = heat_removed / COP_Carnot
W_actual          = W_min / carnot_fraction   (or a measured value, if supplied)
process_efficiency = W_min / W_actual
```

`carnot_fraction` (default 0.22) is a representative, clearly-labelled
order-of-magnitude figure for how close real small/mid-scale hydrogen
refrigeration equipment gets to the reversible (Carnot) bound — not a
precise, sourced constant. Densifying from 20 K to 16 K at 1.3 bar gives
≈ +5.7 % liquid density, matching the order of magnitude reported in the
literature for LH₂ subcooling toward ~17 K.

### 3.3 Cryogenic tank (`cryogenics/tank.py`)

The tank is a **rigid, fixed-volume, well-mixed** control volume: a
saturated liquid pool plus a saturated vapour ullage in mutual
thermodynamic equilibrium. This is the standard simplifying assumption for
a first-principles storage-tank model (see §7, Limitations, for what it
does not capture).

The tank's *only* independent dynamic state is `(M, U)` — total mass and
total internal energy inside the fixed geometric volume `V`. Given
`(M, U, V)`, the physical state follows from a **closed-system,
fixed-volume "UV flash"**:

* **Two-phase branch** (the expected operating regime): find the
  saturation temperature `T` such that a liquid/vapour split consistent
  with the volume constraint,

  ```
  x(T) = (v − v_L(T)) / (v_V(T) − v_L(T)),   v = V/M
  ```

  also satisfies the energy constraint,

  ```
  u(T) = (1 − x) u_L(T) + x u_V(T) = U/M
  ```

  — solved by bracketed 1-D root-finding (`scipy.optimize.brentq`), with a
  finer fallback grid near the critical point where the dome narrows
  sharply enough to straddle a coarse bracket.

* **Single-phase fallback** (fully-liquid, fully-vapour, or compressed
  outside the dome): `(T, P)` solved directly by 2-D Newton iteration so
  that `rho(T, P) = M/V` and `u(T, P) = U/M`, using the property engine's
  analytic partial derivatives (`∂ρ/∂T|_P`, `∂ρ/∂P|_T`, `∂u/∂T|_P`,
  `∂u/∂P|_T`), damped to stay within the validated property range.

* **Last-resort projection**: if a solver trial state (deep inside an
  adaptive ODE step, see §4) is transiently outside what *any* phase split
  can achieve, the state is clamped to the nearest saturation-dome
  boundary and a `RuntimeWarning` is raised rather than crashing an
  otherwise well-posed simulation — the ODE solver's own error control
  sees the resulting large local error and shrinks the step.

**Boil-off.** Two related but distinct figures are reported: the
*self-pressurization* response (closed tank, no venting — heat leak raises
`U` at constant `M`; the UV flash directly returns the resulting rise in
`T`, `P`, and vapour fraction `x`), and the conventional **normal boil-off
rate** (NBOR), `Q̇ / h_fg(T)` — the vent rate that would hold pressure
constant by rejecting all incoming heat as latent heat.

### 3.4 Heat leak (`cryogenics/heat_leak.py`, `insulation.py`)

```
Q_total = Q_conduction + Q_radiation + Q_penetrations + Q_piping + Q_instrumentation + Q_environmental
```

* **Conduction** — Fourier's law through the insulation's *apparent*
  conductivity (a characterised system parameter, not a universal
  constant — representative starting values: ~3×10⁻⁵ W/(m·K) for
  60-layer MLI in hard vacuum, ~0.02 W/(m·K) for closed-cell foam).
* **Radiation** — N floating radiation shields between matched-emissivity
  boundaries (Incropera & DeWitt's standard N-shield network result):
  `Q_rad = σA(T_w⁴ − T_c⁴) / [(2/ε − 1)(N + 1)]`.
* **Penetrations / piping / instrumentation** — lumped conductances
  `UA·ΔT`, representing structural supports, fill/vent/relief lines, and
  instrumentation leads bridging the insulation boundary.
* **Environmental** — an optional convective term for equipment that
  isn't fully vacuum-jacketed.

Every contribution is independently toggleable
(`HeatLeakConfig(enable_conduction=..., ...)`), and a "degraded vacuum
jacket" (`InsulationSystem.degraded(base, vacuum_loss_factor=N)`) models
the classic soft-vacuum-collapse failure mode used in Scenario D.

### 3.5 Recirculation loop (`cryogenics/recirculation.py`)

```
TANK → WITHDRAWAL (pipe ΔP) → PUMP → CONDITIONER/HX → RETURN (pipe ΔP) → TANK
```

Each stage produces a full `ComponentState` (inlet/outlet `LH2State`,
mass flow, ΔP, heat transfer, power, warnings) for complete traceability.
The withdrawal/return legs use Darcy–Weisbach pressure drop with a
Colebrook–White friction factor (laminar `64/Re` below Re 2300, a linear
transitional blend to 4000, Colebrook–White turbulent above); the pump is
a generic efficiency-based model (§3.6); the conditioner is the heat
exchanger of §3.7. A commanded flow rate that the piping genuinely cannot
support (pressure drop would exceed what's available) raises a clear
`FlowInfeasibleError` naming the undersized component, rather than
propagating a cryptic backend failure.

### 3.6 Pump (`fluid/pump.py`, `fluid/cavitation.py`)

A **generic** cryogenic pump — no commercial head curve or impeller
geometry:

```
hydraulic_power = ṁ (P_out − P_in) / ρ_in
shaft_power     = hydraulic_power / η
Δh_actual       = shaft_power / ṁ                 (all inefficiency → fluid enthalpy)
outlet state    = state_PH(P_out, h_in + Δh_actual)  [real-fluid flash]
```

Routing the actual enthalpy rise back through the property engine — rather
than an ad hoc "temperature rise" formula — correctly captures that a real
cryogenic liquid's temperature rise for a given work input depends on its
local specific heat, and keeps the pump outlet fully consistent with the
rest of the twin.

**Cavitation diagnostics** report both the classical NPSH margin
(`(P_in − P_vapor(T_in))/(ρg) + v²/2g` vs. a configurable NPSH-required)
and — because LH₂ systems routinely operate within a few kelvin of their
vapour pressure, making a length-based NPSH figure easy to misread — the
direct **subcooling margin**, `T_sat(P_in) − T_in`. A pump inlet with
zero or negative subcooling is flagged at risk regardless of NPSH.

### 3.7 Heat exchanger / conditioner (`cryogenics/heat_exchanger.py`)

Two modes, deliberately kept distinct per the "specified operating
condition vs. calculated physical response" principle:

* **`specified_outlet_temperature`** — a control setpoint for the process
  stream's outlet temperature (an actively-controlled conditioner holding
  a setpoint); duty follows from a direct real-fluid enthalpy balance —
  no constant-cp assumption, valid across a partial phase change.
* **`specified_UA`** — only the exchanger's conductance `UA` and both
  streams' inlet states/flows are given; outlet temperatures and duty are
  ***calculated*** via effectiveness-NTU for a counter-current exchanger:

  ```
  Cmin = min(ṁ_p cp_p, ṁ_c cp_c),  Cr = Cmin/Cmax,  NTU = UA/Cmin
  ε = (1 − e^(−NTU(1−Cr))) / (1 − Cr e^(−NTU(1−Cr)))     [Cr < 1]
  Q = ε · Cmin · (T_process,in − T_coolant,in)
  ```

An optional first-order thermal-mass lag (`apply_thermal_lag`) represents
the exchanger metal's own capacitance damping a step change in setpoint.

### 3.8 Facility composition (`models/facility.py`, `models/process_train.py`)

`NewtonLH2Facility` combines a `CryoTank` and a `ProcessTrain`
(recirculation loop + default conditioner setpoint) and exposes one
`derivative()` call the transient solver drives. **Design choice:** the
tank's thermal mass sets the dominant (slow) system timescale, while
pump/HX/piping response is fast relative to it — a standard and realistic
simplification — so the recirculation loop is evaluated **quasi-statically**
(a full steady-state component chain) once per solver evaluation, rather
than carrying its own separate dynamic states. This keeps the ODE state
vector to exactly `[M, U]` (robust, fast, well-conditioned) while the loop
itself still produces a fully traceable `RecirculationResult` at every
instant.

Three physically distinct boundary flows act on the tank simultaneously:
the internal recirculation loop (mass-neutral, but **not**
energy-neutral — this is the actual mechanism by which densification
cools the tank), permanent outlet withdrawal (supply to the downstream
boundary), and controlled venting.

---

## 4. Transient solver (`simulation/solver.py`)

The coupled mass/energy ODE `y = [M, U]` is integrated with
`scipy.integrate.solve_ivp` (adaptive RK45, dense output). Numerical
priorities follow the project brief's order — **conservation, stability,
traceability, validation, performance**:

* **Stability.** `first_step` is set explicitly small (rather than
  letting scipy's own initial-step heuristic choose): a large trial
  probe on a stiff first step was found, empirically, to occasionally
  jump into an unreachable trial `(M, U)` (see `tests/test_simulation.py`
  and the commit history for the concrete failure this fixed). `atol` is
  scaled to the actual mass/energy magnitudes in play, not a fixed Joule
  count — CoolProp's reference state means a low-quality two-phase
  mixture's *specific* internal energy can sit near zero from liquid/vapour
  cancellation even though the *physically meaningful* scale of energy
  change is orders of magnitude larger; an unscaled tight tolerance was
  found to make the adaptive stepper chase an unreachable precision.
* **Conservation.** After integration, an *independent* trapezoidal
  reconstruction of the boundary mass/energy flow terms is compared
  against the ODE trajectory's actual `(M, U)` change (`ConservationReport`,
  `PASS`/`FAIL` against a throughput-relative tolerance — 0.2 %/0.5 % by
  default, which absorbs the small, expected quadrature error a discrete
  event's flow-rate *discontinuity* introduces at the reporting-grid
  resolution, without masking a genuine bookkeeping bug).
* **Traceability.** Every reported instant re-derives its full
  `FacilityState` from `(M, U)` via the real property engine and component
  models — never an interpolated "pretty" number.
* **Performance.** The `(M, U)` trajectory is available essentially free
  at arbitrarily many points via dense-output interpolation; only the
  (optionally strided) diagnostic columns re-invoke the full component
  chain, which is the expensive path (see §6).

**Events** (`simulation/events.py`) — a relief valve opening/reclosing, a
low-level loop shutoff — are handled as *occasional* segment boundaries:
the solver samples each `EventSpec`'s trigger against the dense output,
and only on an actual zero-crossing does it truncate the segment, apply
the event's action (a small, explicit mutation of a `ControlState`), and
resume. A commanded vent rate is physically clamped against the tank's
*actual* current vapour inventory (over a conservative 1 s response time)
— venting faster than vapour is genuinely present would otherwise drive
the state outside any achievable phase, exactly the kind of unphysical
boundary condition §3.3's last-resort projection exists to catch
gracefully.

---

## 5. Scenarios (`simulation/scenarios.py`)

| Scenario | CLI name | What it shows |
|---|---|---|
| A — Warm Tank | `warm-tank` / `cooldown` | Cooldown/self-pressurization from a warm (27 K) initial liquid |
| B — Steady Cryogenic Storage | `steady-storage` | Long-duration passive storage, slow self-pressurization + boil-off diagnostics |
| C — Controlled Densification | `densification` | Continuous recirculation through the conditioner, progressive subcooling |
| D — High Heat Leak | `high-heat-leak` | Degraded vacuum jacket (15× conductivity), relief valve opens/recloses |
| E — Recirculation | `recirculation` | Steady continuous tank→conditioner→tank loop operation |
| F — Transient Demand | `transient-demand` | A ramped downstream outlet-demand boundary condition during conditioning |

None model combustion.

```bash
newton-lh2 scenario densification
newton-lh2 scenario high-heat-leak --output run.csv
```

---

## 6. Performance

The core `(M, U)` ODE trajectory scales to the **100,000+ timestep**
target with wide margin:

```
100,001 reporting steps, 100,000 s duration:  ≈ 0.1–0.2 s  (dense-output interpolation)
```

Full per-step *diagnostics* (which re-invoke the property engine and the
whole recirculation-loop component chain several times per row) are the
expensive path — roughly 300–500 rows/s — so `diagnostic_stride` lets a
caller decouple "how finely did the physics get integrated" from "how many
fully-detailed rows do I actually want back." `tests/test_simulation.py::
TestSolverConservation::test_high_timestep_count_runs_quickly` exercises
this directly. `max_step` is left generous by default so smooth/slow
scenarios keep the benefit of large adaptive strides; pass `max_step_s`
explicitly for a scenario expected to be unusually stiff (see §7).
Vectorisation (NumPy throughout the property/pressure-drop/EOS layers) and
embarrassingly-parallel sweeps (`analysis/sensitivity.py`,
`analysis/uncertainty.py`, both trivially parallelisable across processes)
are where JAX/Numba/multiprocessing could accelerate further without
rewriting the scientific model — deliberately not added prematurely.

---

## 7. Validation strategy & limitations

**Validation.** `notebooks/01`–`05` (property cross-checks against the
independent RK/Rackett correlations, tank cooldown/self-pressurization
sanity checks, a densification study reproducing the expected ~5 %
density gain for a 20→16 K subcooling, an energy-balance closure check,
and the Monte Carlo uncertainty study) plus 94 `pytest` tests covering
every module (property round-trips, conservation, phase classification,
component models, solver stability/events, the full CLI). Run
`newton-lh2 validate` for a quick command-line conservation/consistency
check.

**Known limitations** (stated plainly, not hidden):

* **Well-mixed tank, no resolved stratification.** The liquid pool and
  vapour ullage are assumed in mutual thermodynamic equilibrium at every
  instant. Real tanks can stratify (a warmer liquid layer near the wall),
  which this lumped model does not resolve — a documented simplification,
  not an oversight (see `cryogenics/tank.py`'s module docstring).
* **No non-equilibrium flash dynamics.** Rapid depressurization / flash
  boiling transients are outside this model's equilibrium-flash
  assumption.
* **Quasi-static recirculation loop.** The pump/HX/piping chain has no
  independent dynamic state of its own (§3.8) — appropriate given the
  tank's much larger thermal mass, but not a resolved fast-transient model
  of the loop itself.
* **Numerically stiff extremes.** A very large heat leak combined with a
  tight relief margin (e.g. severe insulation failure on a small vessel)
  can produce a genuinely stiff right-hand side where the adaptive
  explicit (RK45) stepper is slow or requires an explicit `max_step_s`
  hint; an implicit stiff-aware method (`solve_ivp(method="Radau")`, say)
  would be the natural next step for that regime rather than the current
  default.
* **RK/Rackett cross-check is qualitative only**, especially on the liquid
  branch near/away from the calibration point — see
  `notebooks/01_property_validation.ipynb` for exactly how far off it
  runs. It is never used operationally.
* **`carnot_fraction` and MLI apparent-conductivity defaults** are
  representative order-of-magnitude industry figures, not measured
  facility data — override them with characterised values for any
  quantitative use.

This program is a research/engineering simulation. It carries no
certification of any kind and must not be represented as validated for
flight, safety, or regulatory purposes.

**Not included in this delivery:** a 3-D visual representation of the
tank/pipework/equipment. The 2-D dashboard (§below) is authoritative and
covers every required live/derived quantity; a 3-D view was a
conditional ("if practical") item in the brief and was deliberately
deprioritised in favour of depth and correctness across the rest of the
platform. `models/facility.py`'s `FacilityState` already carries
everything a future 3-D layer would need (component states, flow
directions via mass-flow sign, thermal state per node).

---

## 8. CLI reference

```
newton-lh2 simulate [--tank-volume M3] [--diameter M] [--initial-temperature K]
                     [--initial-mass KG] [--pressure PA] [--ambient K]
                     [--coolant-temperature K] [--mass-flow KG_S]
                     [--duration S] [--timestep S] [--output FILE]
newton-lh2 scenario {warm-tank|cooldown|steady-storage|densification|
                     high-heat-leak|recirculation|transient-demand} [--output FILE]
newton-lh2 sensitivity --parameter NAME --values "V1,V2,..." [--output FILE]
newton-lh2 monte-carlo [--n N] [--seed N] [--output FILE]
newton-lh2 validate
newton-lh2 generate-telemetry [--scenario NAME] [--output FILE]
newton-lh2 replay TELEMETRY_FILE [--initial-temperature K] [--timestep S]
```

All units SI throughout. `--help` on any subcommand is self-documenting.

---

## 9. License

Proprietary — Newton Rockets Ltd., internal research use. See `LICENSE`.
