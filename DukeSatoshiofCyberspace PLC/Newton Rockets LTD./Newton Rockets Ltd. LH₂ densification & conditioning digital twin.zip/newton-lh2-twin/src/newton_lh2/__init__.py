"""
Newton Rockets Ltd. -- LH2 Densification & Conditioning Digital Twin
======================================================================

RESEARCH / ENGINEERING SIMULATION -- NOT FLIGHT-CERTIFIED.

This package models the thermodynamic and fluid behaviour of a cryogenic
liquid-hydrogen (LH2) densification and conditioning process, terminating
at the conditioned LH2 outlet. It does not model combustion, propulsion
performance, or any downstream flight system -- those are treated as an
abstract boundary condition beyond ``outlet``.

Top-level subpackages
----------------------
thermodynamics  Property engine, phase classification, saturation curve.
cryogenics      Tank, heat leak, insulation, recirculation, HX, densification.
fluid           Piping, pressure drop, pump, cavitation diagnostics.
simulation      State containers, time-stepping, ODE solver, events, scenarios.
models          Facility-level composition: process train, telemetry.
analysis        Density/energy analysis, sensitivity sweeps, Monte Carlo.
"""

from __future__ import annotations

__version__ = "0.1.0"
__disclaimer__ = "RESEARCH / ENGINEERING SIMULATION -- NOT FLIGHT-CERTIFIED"

from newton_lh2.simulation.state import LH2State, FacilityState  # noqa: E402,F401
from newton_lh2.thermodynamics.phase import Phase  # noqa: E402,F401

__all__ = ["LH2State", "FacilityState", "Phase", "__version__", "__disclaimer__"]
