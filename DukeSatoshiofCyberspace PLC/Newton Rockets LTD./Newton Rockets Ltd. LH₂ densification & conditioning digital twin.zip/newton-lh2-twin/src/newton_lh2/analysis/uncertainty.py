"""
Monte Carlo uncertainty quantification.

Two response models are supported:

* A **fast analytic response** (:func:`heat_leak_response`,
  the default) -- perturbs heat-leak-relevant inputs (insulation apparent
  conductivity, layer emissivity, ambient temperature, tank liquid
  temperature) and evaluates the heat-leak model directly, with no
  transient ODE integration. This is cheap enough to run thousands of
  trials in seconds, appropriate for propagating property/parameter
  uncertainty through a single algebraic model.
* A **full simulation response**, supplied by the caller as an arbitrary
  ``model_fn`` (e.g. wrapping a short
  :class:`~newton_lh2.simulation.solver.LH2Simulation` run) -- far more
  expensive per trial, so ``n`` should be reduced accordingly (a few
  hundred, not thousands).

Both go through the same :func:`monte_carlo` driver and produce the same
:class:`MonteCarloResult` summary statistics.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Callable, Optional

import numpy as np

from newton_lh2.cryogenics.heat_leak import HeatLeakConfig, heat_leak
from newton_lh2.cryogenics.insulation import InsulationSystem


@dataclass(frozen=True)
class MonteCarloResult:
    samples: np.ndarray
    n: int
    mean: float
    median: float
    std: float
    p5: float
    p95: float
    parameter_samples: dict

    def report(self, label: str = "response") -> str:
        return (
            f"MONTE CARLO UNCERTAINTY -- {label} (n={self.n})\n"
            f"  mean   : {self.mean:.6g}\n"
            f"  median : {self.median:.6g}\n"
            f"  std    : {self.std:.6g}\n"
            f"  p5     : {self.p5:.6g}\n"
            f"  p95    : {self.p95:.6g}"
        )


def monte_carlo(
    parameter_distributions: dict[str, Callable[[np.random.Generator], np.ndarray]],
    model_fn: Callable[[dict], np.ndarray],
    n: int = 5000,
    seed: int = 7,
) -> MonteCarloResult:
    """
    Generic Monte Carlo driver.

    ``parameter_distributions`` maps a parameter name to a sampler
    ``sampler(rng, n) -> ndarray`` of ``n`` draws (build these with
    ``functools.partial`` around e.g. ``rng.normal``/``rng.uniform``, or
    use the convenience constructors in this module).
    ``model_fn`` takes a dict of ``{parameter: ndarray[n]}`` (vectorised)
    and returns an ``ndarray[n]`` of responses.
    """
    rng = np.random.default_rng(seed)
    samples = {name: sampler(rng, n) for name, sampler in parameter_distributions.items()}
    response = np.asarray(model_fn(samples), dtype=float)
    if response.shape != (n,):
        raise ValueError(f"model_fn must return an array of shape ({n},), got {response.shape}")
    return MonteCarloResult(
        samples=response,
        n=n,
        mean=float(np.mean(response)),
        median=float(np.median(response)),
        std=float(np.std(response, ddof=1)),
        p5=float(np.percentile(response, 5)),
        p95=float(np.percentile(response, 95)),
        parameter_samples=samples,
    )


# ---------------------------------------------------------------------- #
# Convenience distribution samplers
# ---------------------------------------------------------------------- #


def normal(mean: float, std: float) -> Callable[[np.random.Generator, int], np.ndarray]:
    return lambda rng, n: rng.normal(mean, std, size=n)


def uniform(low: float, high: float) -> Callable[[np.random.Generator, int], np.ndarray]:
    return lambda rng, n: rng.uniform(low, high, size=n)


def lognormal_relative(mean: float, relative_std: float) -> Callable[[np.random.Generator, int], np.ndarray]:
    """A positive quantity with approximately ``relative_std`` fractional scatter about ``mean``."""
    sigma = np.sqrt(np.log(1.0 + relative_std**2))
    mu = np.log(mean) - 0.5 * sigma**2
    return lambda rng, n: rng.lognormal(mu, sigma, size=n)


# ---------------------------------------------------------------------- #
# Default fast analytic response: total tank heat leak, W
# ---------------------------------------------------------------------- #


def heat_leak_response(
    base_area_m2: float = 90.0,
    base_thickness_m: float = 0.025,
    base_layer_count: int = 60,
) -> Callable[[dict], np.ndarray]:
    """
    Vectorised heat-leak model for Monte Carlo use. Expects sampled arrays
    for any of: ``apparent_conductivity_W_mK``, ``layer_emissivity``,
    ``ambient_temperature_K``, ``liquid_temperature_K``,
    ``penetration_conductance_W_K``. Missing parameters fall back to the
    :class:`~newton_lh2.cryogenics.insulation.InsulationSystem`/
    :class:`~newton_lh2.cryogenics.heat_leak.HeatLeakConfig` defaults.
    """

    def model(samples: dict) -> np.ndarray:
        n = len(next(iter(samples.values())))
        k = samples.get("apparent_conductivity_W_mK", np.full(n, 3.0e-5))
        eps = samples.get("layer_emissivity", np.full(n, 0.03))
        T_amb = samples.get("ambient_temperature_K", np.full(n, 293.15))
        T_liq = samples.get("liquid_temperature_K", np.full(n, 20.0))
        pen = samples.get("penetration_conductance_W_K", np.full(n, 0.05))

        out = np.empty(n)
        for i in range(n):
            ins = InsulationSystem(base_area_m2, base_thickness_m, float(k[i]), base_layer_count, float(eps[i]))
            cfg = HeatLeakConfig(penetration_conductance_W_K=float(pen[i]))
            out[i] = heat_leak(ins, float(T_amb[i]), float(T_liq[i]), cfg, ambient_T_K=float(T_amb[i])).total_W
        return out

    return model
