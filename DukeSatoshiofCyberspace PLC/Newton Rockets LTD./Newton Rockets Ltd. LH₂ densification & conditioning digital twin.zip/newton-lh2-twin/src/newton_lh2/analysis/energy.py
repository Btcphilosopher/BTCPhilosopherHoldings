"""Energy-balance post-processing of a simulation trajectory."""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import pandas as pd


@dataclass(frozen=True)
class EnergyBalanceSummary:
    duration_s: float
    total_heat_leak_J: float
    total_cooling_duty_J: float
    total_pump_work_J: float
    net_energy_change_J: float
    mean_heat_leak_W: float
    mean_cooling_duty_W: float
    mean_pump_power_W: float

    def report(self) -> str:
        return (
            "ENERGY BALANCE SUMMARY\n"
            f"  Duration              : {self.duration_s:10.1f} s\n"
            f"  Total heat leak in    : {self.total_heat_leak_J/1e6:10.4f} MJ "
            f"(mean {self.mean_heat_leak_W:8.2f} W)\n"
            f"  Total cooling duty    : {self.total_cooling_duty_J/1e6:10.4f} MJ "
            f"(mean {self.mean_cooling_duty_W:8.2f} W)\n"
            f"  Total pump shaft work : {self.total_pump_work_J/1e6:10.4f} MJ "
            f"(mean {self.mean_pump_power_W:8.2f} W)\n"
            f"  Net internal-energy change (from state) : {self.net_energy_change_J/1e6:10.4f} MJ"
        )


def summarize_energy_balance(diagnostics: pd.DataFrame, internal_energy_J: np.ndarray = None) -> EnergyBalanceSummary:
    """Integrate the power columns of a simulation's diagnostics into an energy-balance summary."""
    t = diagnostics["time_s"].to_numpy(dtype=float)
    duration = float(t[-1] - t[0]) if len(t) > 1 else 0.0

    def integral(col: str) -> float:
        if col not in diagnostics.columns:
            return 0.0
        return float(np.trapezoid(diagnostics[col].to_numpy(dtype=float), t))

    total_heat_leak = integral("heat_leak_W")
    total_cooling = integral("cooling_duty_W")
    total_pump = integral("pump_shaft_power_W")
    net_change = (
        float(internal_energy_J[-1] - internal_energy_J[0]) if internal_energy_J is not None else float("nan")
    )

    return EnergyBalanceSummary(
        duration_s=duration,
        total_heat_leak_J=total_heat_leak,
        total_cooling_duty_J=total_cooling,
        total_pump_work_J=total_pump,
        net_energy_change_J=net_change,
        mean_heat_leak_W=total_heat_leak / duration if duration > 0 else 0.0,
        mean_cooling_duty_W=total_cooling / duration if duration > 0 else 0.0,
        mean_pump_power_W=total_pump / duration if duration > 0 else 0.0,
    )


def specific_energy_consumption_J_kg(total_energy_J: float, mass_processed_kg: float) -> float:
    if mass_processed_kg <= 0:
        raise ValueError("mass_processed_kg must be positive")
    return total_energy_J / mass_processed_kg
