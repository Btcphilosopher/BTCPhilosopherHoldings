"""Density/energy analysis, sensitivity sweeps, and Monte Carlo uncertainty quantification."""
