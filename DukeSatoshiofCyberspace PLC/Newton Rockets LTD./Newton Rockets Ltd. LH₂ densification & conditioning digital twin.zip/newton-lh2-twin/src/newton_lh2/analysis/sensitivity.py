"""
Deterministic parameter-sensitivity sweeps.

Each named parameter maps onto a keyword of
:func:`newton_lh2.simulation.scenarios._standard_facility`, so a sweep
varies exactly one facility/process input at a time (holding all others
at a baseline), runs a short densification-style simulation, and records
how the response quantities (final density, cooling energy, boil-off
rate, final pressure, "cooldown time" to a target temperature drop) move.
Runs are deterministic (no randomness) -- for randomised uncertainty
propagation see :mod:`newton_lh2.analysis.uncertainty`.
"""

from __future__ import annotations

from typing import Callable, Optional, Sequence

import numpy as np
import pandas as pd

from newton_lh2.models.facility import BoundaryConditions
from newton_lh2.simulation.solver import LH2Simulation
from newton_lh2.simulation.scenarios import _standard_facility

#: Facility-input parameters this module knows how to sweep, matching the
#: project brief's list (tank pressure is a derived/output quantity here,
#: not an independent input, so it is not included).
SWEEPABLE_PARAMETERS = (
    "initial_temperature_K",  # initial temperature
    "ambient_K",  # ambient temperature
    "vacuum_loss_factor",  # heat-leak coefficient / insulation degradation
    "mli_area_m2",  # insulation (surface) performance proxy
    "volume_m3",  # tank volume
    "coolant_temperature_K",  # cooler effectiveness proxy (colder coolant -> more effective conditioning)
)


def _run_point(
    overrides: dict,
    duration_s: float,
    timestep_s: float,
    mass_flow_kg_s: float,
    target_temperature_drop_K: float,
) -> dict:
    facility = _standard_facility(**overrides)

    def bc_fn(t, control):
        return BoundaryConditions(recirculation_mass_flow_kg_s=mass_flow_kg_s)

    sim = LH2Simulation(facility, bc_fn, duration_s=duration_s, timestep_s=timestep_s, diagnostic_stride=1)
    result = sim.run()
    d = result.diagnostics

    T0 = float(d["temperature_K"].iloc[0])
    mask = d["temperature_K"] <= (T0 - target_temperature_drop_K)
    cooldown_time_s = float(d.loc[mask, "time_s"].iloc[0]) if mask.any() else float("nan")
    cooling_energy_J = float(np.trapezoid(d["cooling_duty_W"], d["time_s"]))

    return {
        "final_density_kg_m3": float(d["liquid_density_kg_m3"].iloc[-1]),
        "cooling_energy_J": cooling_energy_J,
        "boiloff_rate_kg_s": float(d["normal_boiloff_rate_kg_s"].iloc[-1]),
        "final_pressure_Pa": float(d["pressure_Pa"].iloc[-1]),
        "cooldown_time_s": cooldown_time_s,
        "mass_conservation_pass": result.conservation.mass_pass,
        "energy_conservation_pass": result.conservation.energy_pass,
    }


def run_parameter_sweep(
    parameter: str,
    values: Sequence[float],
    baseline: Optional[dict] = None,
    duration_s: float = 2000.0,
    timestep_s: float = 20.0,
    mass_flow_kg_s: float = 1.0,
    target_temperature_drop_K: float = 1.0,
) -> pd.DataFrame:
    """Sweep a single facility parameter, holding all others at ``baseline``."""
    if parameter not in SWEEPABLE_PARAMETERS:
        raise ValueError(f"Unknown sweepable parameter {parameter!r}; choose from {SWEEPABLE_PARAMETERS}")
    baseline = dict(baseline or {})
    rows = []
    for v in values:
        overrides = dict(baseline)
        overrides[parameter] = v
        row = {"parameter": parameter, "value": v}
        row.update(_run_point(overrides, duration_s, timestep_s, mass_flow_kg_s, target_temperature_drop_K))
        rows.append(row)
    return pd.DataFrame(rows)


def run_multi_parameter_sweep(
    parameters: dict[str, Sequence[float]],
    baseline: Optional[dict] = None,
    **kwargs,
) -> pd.DataFrame:
    """Run a 1-D sweep for each entry of ``parameters`` (holding the rest at baseline) and concatenate."""
    frames = [run_parameter_sweep(name, values, baseline=baseline, **kwargs) for name, values in parameters.items()]
    return pd.concat(frames, ignore_index=True)


def plot_sensitivity(df: pd.DataFrame, response: str = "final_density_kg_m3"):
    """Grid of matplotlib subplots: response vs value, one panel per swept parameter."""
    import matplotlib.pyplot as plt

    params = df["parameter"].unique()
    n = len(params)
    ncols = min(3, n)
    nrows = int(np.ceil(n / ncols))
    fig, axes = plt.subplots(nrows, ncols, figsize=(4.5 * ncols, 3.5 * nrows), squeeze=False)
    for i, p in enumerate(params):
        ax = axes[i // ncols][i % ncols]
        sub = df[df["parameter"] == p].sort_values("value")
        ax.plot(sub["value"], sub[response], marker="o")
        ax.set_xlabel(p)
        ax.set_ylabel(response)
        ax.set_title(p)
        ax.grid(alpha=0.3)
    for j in range(n, nrows * ncols):
        axes[j // ncols][j % ncols].axis("off")
    fig.tight_layout()
    return fig
