"""Density-focused post-processing of a simulation trajectory."""

from __future__ import annotations

from dataclasses import dataclass

import pandas as pd

from newton_lh2.cryogenics.densification import densify, DensificationResult
from newton_lh2.thermodynamics.properties import HydrogenProperties, DEFAULT_PROPERTIES


@dataclass(frozen=True)
class VolumetricCapacityGain:
    """How much more (or less) mass the same tank volume can hold at a new liquid density."""

    tank_volume_m3: float
    initial_density_kg_m3: float
    final_density_kg_m3: float

    @property
    def initial_capacity_kg(self) -> float:
        return self.tank_volume_m3 * self.initial_density_kg_m3

    @property
    def final_capacity_kg(self) -> float:
        return self.tank_volume_m3 * self.final_density_kg_m3

    @property
    def additional_capacity_kg(self) -> float:
        return self.final_capacity_kg - self.initial_capacity_kg

    @property
    def additional_capacity_percent(self) -> float:
        return 100.0 * self.additional_capacity_kg / self.initial_capacity_kg


def volumetric_capacity_gain(
    initial_density_kg_m3: float, final_density_kg_m3: float, tank_volume_m3: float
) -> VolumetricCapacityGain:
    return VolumetricCapacityGain(tank_volume_m3, initial_density_kg_m3, final_density_kg_m3)


def summarize_densification(
    diagnostics: pd.DataFrame,
    mass_processed_kg: float,
    ambient_temperature_K: float = 293.15,
    carnot_fraction: float = 0.22,
    props: HydrogenProperties = None,
) -> DensificationResult:
    """
    Reconstruct a :class:`~newton_lh2.cryogenics.densification.DensificationResult`
    from a simulation's first and last diagnostic rows.
    """
    props = props or DEFAULT_PROPERTIES
    first, last = diagnostics.iloc[0], diagnostics.iloc[-1]

    def liquid_reference_state(row):
        # Densification analysis concerns the *liquid* being processed.
        # Building the reference state via state_TP(T, P) is ambiguous
        # exactly on the saturation curve (a common tank operating point,
        # e.g. right after fill); state_TQ(T, 0.0) -- saturated liquid --
        # is unambiguous and is what's actually drawn off for conditioning.
        # If the row is meaningfully subcooled (P above Psat(T)), use the
        # unambiguous subcooled-liquid TP state instead.
        T = float(row["temperature_K"])
        P = float(row["pressure_Pa"])
        try:
            p_sat = props.saturation_pressure(T)
        except Exception:
            return props.state_TP(T, P)
        if P > p_sat * 1.0001:
            return props.state_TP(T, P)
        return props.state_TQ(T, 0.0)

    initial_state = liquid_reference_state(first)
    final_state = liquid_reference_state(last)
    return densify(
        initial_state, final_state, mass_processed_kg,
        ambient_temperature_K=ambient_temperature_K, carnot_fraction=carnot_fraction, props=props,
    )


def density_trace(diagnostics: pd.DataFrame) -> pd.DataFrame:
    """Time series of liquid/vapour density and quality, for plotting."""
    cols = [c for c in ("time_s", "liquid_density_kg_m3", "vapor_density_kg_m3", "quality") if c in diagnostics.columns]
    return diagnostics[cols].copy()
