"""
Discrete event handling for the transient solver.

The core mass/energy ODE is integrated continuously (and efficiently) via
``scipy.integrate.solve_ivp`` with dense output. Discrete control actions
-- opening a relief vent when tank pressure exceeds a setpoint, tripping
an alarm when liquid level runs low, flagging a cavitation excursion --
are handled as *occasional* segment boundaries: the solver samples each
:class:`EventSpec`'s trigger against the dense output, and if a zero
crossing is found, truncates the segment there, applies the event's
action (a small, explicit mutation of the solver's control state), and
resumes integration. This keeps the common case (no events firing) at
full continuous-integration performance, while still giving genuine
event-driven behaviour when a threshold is actually crossed.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Callable, Optional

import numpy as np


@dataclass
class ControlState:
    """Mutable control state that event actions may modify mid-simulation."""

    vent_open: bool = False
    loop_enabled: bool = True
    flags: dict = field(default_factory=dict)


@dataclass
class EventSpec:
    """
    A monitored threshold on the tank's derived state.

    ``trigger`` maps a :class:`~newton_lh2.cryogenics.tank.TankState` to a
    signed value; the event fires on a zero crossing in the requested
    ``direction`` (+1 rising, -1 falling, 0 either).
    ``action`` mutates the given :class:`ControlState` in place when the
    event fires.
    """

    name: str
    trigger: Callable[[object], float]  # TankState -> float
    direction: int = 0
    action: Optional[Callable[[ControlState], None]] = None
    log: list = field(default_factory=list)

    def fire(self, t: float, control: ControlState) -> None:
        if self.action is not None:
            self.action(control)
        self.log.append(t)


def find_first_crossing(
    t_grid: np.ndarray,
    values: np.ndarray,
    direction: int = 0,
) -> Optional[float]:
    """Linear-interpolated first zero-crossing time of ``values`` sampled at ``t_grid``, or None."""
    for i in range(len(values) - 1):
        v0, v1 = values[i], values[i + 1]
        if v0 == 0.0:
            return float(t_grid[i])
        if v0 * v1 < 0.0:
            if direction > 0 and v1 < v0:
                continue
            if direction < 0 and v1 > v0:
                continue
            frac = -v0 / (v1 - v0)
            return float(t_grid[i] + frac * (t_grid[i + 1] - t_grid[i]))
    return None


def high_pressure_vent_event(threshold_Pa: float) -> EventSpec:
    def trigger(tank_state) -> float:
        return tank_state.pressure_Pa - threshold_Pa

    def action(control: ControlState) -> None:
        control.vent_open = True
        control.flags["last_vent_event"] = True

    return EventSpec(name=f"HIGH_PRESSURE_VENT@{threshold_Pa/1e5:.3f}bar", trigger=trigger, direction=1, action=action)


def vent_reclose_event(threshold_Pa: float) -> EventSpec:
    def trigger(tank_state) -> float:
        return tank_state.pressure_Pa - threshold_Pa

    def action(control: ControlState) -> None:
        control.vent_open = False

    return EventSpec(name=f"VENT_RECLOSE@{threshold_Pa/1e5:.3f}bar", trigger=trigger, direction=-1, action=action)


def low_level_shutoff_event(threshold_fill_fraction: float) -> EventSpec:
    def trigger(tank_state) -> float:
        return tank_state.fill_fraction - threshold_fill_fraction

    def action(control: ControlState) -> None:
        control.loop_enabled = False
        control.flags["low_level_shutoff"] = True

    return EventSpec(
        name=f"LOW_LEVEL_SHUTOFF@{threshold_fill_fraction:.3f}", trigger=trigger, direction=-1, action=action
    )
