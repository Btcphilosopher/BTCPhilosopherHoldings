"""
Canonical state containers for the digital twin.

``LH2State`` is the fundamental thermodynamic state vector for a parcel of
hydrogen: it is produced by the property engine (never hand-assembled with
an arbitrary density) and consumed by every downstream component model.

``FacilityState`` is the top-level snapshot of the whole process train at
one instant in time, as would be logged to telemetry.
"""

from __future__ import annotations

from dataclasses import dataclass, field, asdict
from typing import Any, Optional

from newton_lh2.thermodynamics.phase import Phase


@dataclass(frozen=True)
class LH2State:
    """
    Immutable thermodynamic state of a hydrogen parcel.

    Attributes
    ----------
    temperature_K : float
        Static temperature, kelvin.
    pressure_Pa : float
        Static pressure, pascal (absolute).
    density_kg_m3 : float
        Mass density, kg/m^3.
    enthalpy_J_kg : float
        Specific mass enthalpy, J/kg (CoolProp reference state).
    entropy_J_kgK : float
        Specific mass entropy, J/(kg K).
    internal_energy_J_kg : float
        Specific internal energy, J/kg.
    quality : float or None
        Vapour mass fraction in [0, 1] for two-phase / saturation states;
        ``None`` for single-phase states where quality is not defined.
    phase : Phase
        Explicit phase classification (see :mod:`newton_lh2.thermodynamics.phase`).
    """

    temperature_K: float
    pressure_Pa: float
    density_kg_m3: float
    enthalpy_J_kg: float
    entropy_J_kgK: float
    internal_energy_J_kg: float
    quality: Optional[float]
    phase: Phase

    def as_dict(self) -> dict[str, Any]:
        d = asdict(self)
        d["phase"] = str(self.phase)
        return d

    def __repr__(self) -> str:  # pragma: no cover - cosmetic
        q = f"{self.quality:.4f}" if self.quality is not None else "--"
        return (
            f"LH2State(T={self.temperature_K:.3f} K, P={self.pressure_Pa/1e5:.4f} bar, "
            f"rho={self.density_kg_m3:.3f} kg/m3, h={self.enthalpy_J_kg/1e3:.2f} kJ/kg, "
            f"s={self.entropy_J_kgK:.2f} J/kgK, x={q}, phase={self.phase})"
        )


@dataclass(frozen=True)
class ComponentState:
    """
    Generic inlet/outlet snapshot for a single process-train component
    (pump, heat exchanger, pipe segment, ...) at one instant in time.
    """

    name: str
    inlet: LH2State
    outlet: LH2State
    mass_flow_kg_s: float
    pressure_drop_Pa: float
    heat_transfer_W: float
    power_W: float
    warnings: tuple[str, ...] = field(default_factory=tuple)

    def as_dict(self) -> dict[str, Any]:
        return {
            "name": self.name,
            "inlet": self.inlet.as_dict(),
            "outlet": self.outlet.as_dict(),
            "mass_flow_kg_s": self.mass_flow_kg_s,
            "pressure_drop_Pa": self.pressure_drop_Pa,
            "heat_transfer_W": self.heat_transfer_W,
            "power_W": self.power_W,
            "warnings": list(self.warnings),
        }


@dataclass(frozen=True)
class FacilityState:
    """Top-level snapshot of the whole facility at one instant in time."""

    timestamp_s: float
    tank: dict[str, Any]
    recirculation: dict[str, Any]
    conditioner: dict[str, Any]
    pump: dict[str, Any]
    outlet: LH2State
    alarms: tuple[str, ...] = field(default_factory=tuple)

    def as_dict(self) -> dict[str, Any]:
        return {
            "timestamp_s": self.timestamp_s,
            "tank": self.tank,
            "recirculation": self.recirculation,
            "conditioner": self.conditioner,
            "pump": self.pump,
            "outlet": self.outlet.as_dict(),
            "alarms": list(self.alarms),
        }
