"""State containers, time-stepping and the transient ODE solver."""
