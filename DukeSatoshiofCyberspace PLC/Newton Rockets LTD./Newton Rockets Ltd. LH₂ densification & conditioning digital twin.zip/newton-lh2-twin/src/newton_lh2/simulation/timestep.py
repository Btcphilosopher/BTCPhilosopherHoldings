"""Time-grid utilities for the transient solver."""

from __future__ import annotations

import numpy as np


def build_time_grid(duration_s: float, dt_s: float) -> np.ndarray:
    """Uniform reporting grid from 0 to duration_s inclusive, step dt_s."""
    if duration_s <= 0:
        raise ValueError("duration_s must be positive")
    if dt_s <= 0:
        raise ValueError("dt_s must be positive")
    n = int(round(duration_s / dt_s))
    grid = np.linspace(0.0, n * dt_s, n + 1)
    return grid


def recommended_max_dt_s(mass_kg: float, cp_J_kgK: float, heat_rate_W: float, max_dT_K: float = 0.5) -> float:
    """
    A simple thermal-time-constant-based upper bound on timestep size: the
    time for ``heat_rate_W`` to change the bulk temperature by
    ``max_dT_K``, as a coarse numerical-stability/accuracy guideline for
    explicit stepping schemes (informational; the ODE solver itself uses
    adaptive error control regardless).
    """
    if heat_rate_W <= 0 or mass_kg <= 0 or cp_J_kgK <= 0:
        return float("inf")
    return mass_kg * cp_J_kgK * max_dT_K / heat_rate_W
