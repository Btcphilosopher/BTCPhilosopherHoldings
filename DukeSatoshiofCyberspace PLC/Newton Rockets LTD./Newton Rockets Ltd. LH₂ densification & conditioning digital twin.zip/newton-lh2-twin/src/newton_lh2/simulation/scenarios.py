"""
Predefined digital-twin scenarios (A-F).

Each scenario function builds a self-contained
:class:`~newton_lh2.models.facility.NewtonLH2Facility` and
:class:`~newton_lh2.simulation.solver.LH2Simulation`, and returns the
:class:`~newton_lh2.simulation.solver.SimulationResult`. They are meant as
both ready-to-run demonstrations and as templates for building custom
facility configurations.

None of these scenarios model combustion; all of them terminate the
engineering model at the conditioned LH2 outlet.
"""

from __future__ import annotations

from dataclasses import dataclass

from newton_lh2.cryogenics.tank import CryoTank, TankGeometry
from newton_lh2.cryogenics.insulation import InsulationSystem
from newton_lh2.cryogenics.heat_leak import HeatLeakConfig
from newton_lh2.cryogenics.recirculation import RecirculationLoopConfig, ConditionerSetpoint
from newton_lh2.fluid.pipe import Pipe
from newton_lh2.fluid.pump import PumpSpec
from newton_lh2.models.process_train import ProcessTrain, ProcessTrainConfig
from newton_lh2.models.facility import NewtonLH2Facility, BoundaryConditions, FacilityLimits
from newton_lh2.simulation.solver import LH2Simulation, SimulationResult
from newton_lh2.simulation.events import high_pressure_vent_event, vent_reclose_event
from newton_lh2.thermodynamics.properties import DEFAULT_PROPERTIES as hp


def _standard_facility(
    volume_m3: float = 100.0,
    diameter_m: float = 4.5,
    mli_area_m2: float = 90.0,
    ambient_K: float = 293.15,
    initial_mass_kg: float = 4500.0,
    initial_temperature_K: float = 19.5,
    vacuum_loss_factor: float = 1.0,
    max_pressure_Pa: float = 3.0e5,
    coolant_temperature_K: float = 14.0,
) -> NewtonLH2Facility:
    ins = InsulationSystem.mli_vacuum_jacket(area_m2=mli_area_m2)
    if vacuum_loss_factor != 1.0:
        ins = InsulationSystem.degraded(ins, vacuum_loss_factor=vacuum_loss_factor)
    tank = CryoTank(
        TankGeometry(volume_m3=volume_m3, diameter_m=diameter_m),
        ins,
        ambient_temperature_K=ambient_K,
        initial_mass_kg=initial_mass_kg,
        initial_temperature_K=initial_temperature_K,
    )
    recirc_cfg = RecirculationLoopConfig(
        withdrawal_pipe=Pipe(length_m=15.0, inner_diameter_m=0.05, minor_loss_K=2.0),
        return_pipe=Pipe(length_m=18.0, inner_diameter_m=0.05, minor_loss_K=3.0),
        pump_spec=PumpSpec(efficiency=0.62, npsh_required_m=0.3, subcooling_safety_margin_K=0.2),
    )
    setpoint = ConditionerSetpoint(
        mode="specified_outlet_temperature",
        outlet_temperature_K=coolant_temperature_K + 3.0,
        coolant_inlet=hp.state_TP(coolant_temperature_K, 1.5e5),
        coolant_mass_flow_kg_s=0.6,
    )
    pt = ProcessTrain(ProcessTrainConfig(recirc_cfg, setpoint, nominal_mass_flow_kg_s=0.0))
    return NewtonLH2Facility(tank, pt, limits=FacilityLimits(max_pressure_Pa=max_pressure_Pa))


@dataclass(frozen=True)
class ScenarioRun:
    name: str
    description: str
    result: SimulationResult


def scenario_a_warm_tank(duration_s: float = 20000.0, timestep_s: float = 50.0) -> ScenarioRun:
    """Scenario A -- Warm Tank: cooldown from a comparatively warm initial condition (no recirculation)."""
    facility = _standard_facility(initial_temperature_K=27.0, initial_mass_kg=3000.0)

    def bc_fn(t, control):
        return BoundaryConditions()

    sim = LH2Simulation(facility, bc_fn, duration_s=duration_s, timestep_s=timestep_s, diagnostic_stride=1)
    return ScenarioRun(
        "A: Warm Tank",
        "Self-pressurization/heat-leak response starting from a warm (27 K) initial liquid.",
        sim.run(),
    )


def scenario_b_steady_storage(duration_s: float = 36000.0, timestep_s: float = 60.0) -> ScenarioRun:
    """Scenario B -- Steady Cryogenic Storage: long-duration storage with environmental heat ingress."""
    facility = _standard_facility(initial_temperature_K=19.5, initial_mass_kg=4200.0)

    def bc_fn(t, control):
        return BoundaryConditions(outlet_demand_kg_s=0.0)

    sim = LH2Simulation(facility, bc_fn, duration_s=duration_s, timestep_s=timestep_s, diagnostic_stride=1)
    return ScenarioRun(
        "B: Steady Cryogenic Storage",
        "Long-duration passive storage; tracks slow self-pressurization and boil-off diagnostics.",
        sim.run(),
    )


def scenario_c_controlled_densification(duration_s: float = 3000.0, timestep_s: float = 10.0) -> ScenarioRun:
    """Scenario C -- Controlled Densification: progressive cooling and resulting density increase."""
    facility = _standard_facility(initial_temperature_K=20.0, initial_mass_kg=4200.0, coolant_temperature_K=14.2)

    def bc_fn(t, control):
        return BoundaryConditions(recirculation_mass_flow_kg_s=1.2)

    sim = LH2Simulation(facility, bc_fn, duration_s=duration_s, timestep_s=timestep_s, diagnostic_stride=1)
    return ScenarioRun(
        "C: Controlled Densification",
        "Continuous recirculation through the conditioner, progressively subcooling and densifying the tank.",
        sim.run(),
    )


def scenario_d_high_heat_leak(duration_s: float = 100000.0, timestep_s: float = 100.0) -> ScenarioRun:
    """Scenario D -- High Heat Leak: degraded insulation, with relief-valve events."""
    facility = _standard_facility(
        volume_m3=50.0, diameter_m=3.5, mli_area_m2=45.0, initial_mass_kg=2500.0,
        initial_temperature_K=20.0, vacuum_loss_factor=15.0, max_pressure_Pa=1.05e5,
    )

    def bc_fn(t, control):
        return BoundaryConditions()

    events = [high_pressure_vent_event(1.05e5), vent_reclose_event(1.02e5)]
    sim = LH2Simulation(
        facility, bc_fn, duration_s=duration_s, timestep_s=timestep_s, diagnostic_stride=1,
        events=events, vent_capacity_kg_s=0.003,
    )
    return ScenarioRun(
        "D: High Heat Leak",
        "Degraded vacuum-jacket insulation (15x apparent-conductivity penalty) drives faster "
        "self-pressurization; a relief valve opens/recloses against configured setpoints.",
        sim.run(),
    )


def scenario_e_recirculation(duration_s: float = 4000.0, timestep_s: float = 10.0) -> ScenarioRun:
    """Scenario E -- Recirculation: continuous tank -> conditioner -> tank circulation at steady flow."""
    facility = _standard_facility(initial_temperature_K=19.0, initial_mass_kg=4200.0)

    def bc_fn(t, control):
        return BoundaryConditions(recirculation_mass_flow_kg_s=0.8)

    sim = LH2Simulation(facility, bc_fn, duration_s=duration_s, timestep_s=timestep_s, diagnostic_stride=1)
    return ScenarioRun(
        "E: Recirculation",
        "Steady continuous recirculation loop operation: tank -> withdrawal -> pump -> conditioner -> return.",
        sim.run(),
    )


def scenario_f_transient_demand(duration_s: float = 6000.0, timestep_s: float = 10.0) -> ScenarioRun:
    """Scenario F -- Transient Demand: a changing downstream (outlet) mass-flow boundary condition."""
    facility = _standard_facility(initial_temperature_K=19.0, initial_mass_kg=4200.0)

    def outlet_demand_kg_s(t: float) -> float:
        # A simple ramp-up / plateau / ramp-down demand profile.
        if t < 1500:
            return 0.4 * (t / 1500.0)
        if t < 4000:
            return 0.4
        if t < 5000:
            return 0.4 * (1.0 - (t - 4000) / 1000.0)
        return 0.0

    def bc_fn(t, control):
        return BoundaryConditions(recirculation_mass_flow_kg_s=0.8, outlet_demand_kg_s=outlet_demand_kg_s(t))

    sim = LH2Simulation(facility, bc_fn, duration_s=duration_s, timestep_s=timestep_s, diagnostic_stride=1)
    return ScenarioRun(
        "F: Transient Demand",
        "Recirculation/conditioning continues while a ramped downstream outlet demand withdraws LH2.",
        sim.run(),
    )


SCENARIOS = {
    "warm-tank": scenario_a_warm_tank,
    "steady-storage": scenario_b_steady_storage,
    "densification": scenario_c_controlled_densification,
    "high-heat-leak": scenario_d_high_heat_leak,
    "recirculation": scenario_e_recirculation,
    "transient-demand": scenario_f_transient_demand,
}
