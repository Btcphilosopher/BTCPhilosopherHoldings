"""
Thermodynamic property engine for parahydrogen.

This module is the *only* place in the codebase that imports the third
party property backend (CoolProp / HEOS). Every other module obtains
properties exclusively through :class:`HydrogenProperties` or the
convenience singleton :data:`DEFAULT_PROPERTIES`, so the backend could be
swapped (e.g. for a tabulated / REFPROP / NIST-webbook backend) without
touching the rest of the simulator.

Backend
-------
CoolProp's HEOS backend for ``ParaHydrogen`` implements the Leachman et al.
(2009) reference equation of state for normal and para-hydrogen, the same
family of correlation used by NIST REFPROP. Liquid hydrogen at cryogenic
ground-storage conditions is predominantly (>95%) the para spin isomer at
equilibrium, so ``ParaHydrogen`` is the physically appropriate fluid model
for an LH2 facility (as opposed to ``Hydrogen``, the room-temperature
normal-ortho/para mixture).

Reference
---------
Leachman, J.W., Jacobsen, R.T, Penoncello, S.G., Lemmon, E.W. (2009),
"Fundamental Equations of State for Parahydrogen, Normal Hydrogen, and
Orthohydrogen", J. Phys. Chem. Ref. Data, 38 (3).
"""

from __future__ import annotations

import functools
import warnings
from dataclasses import dataclass

try:
    import CoolProp.CoolProp as CP

    _COOLPROP_AVAILABLE = True
except Exception:  # pragma: no cover - exercised only without CoolProp installed
    CP = None
    _COOLPROP_AVAILABLE = False

from newton_lh2.thermodynamics.phase import Phase
from newton_lh2.thermodynamics.validation import DEFAULT_RANGE, ValidRange, PropertyRangeError
from newton_lh2.simulation.state import LH2State

FLUID = "ParaHydrogen"
BACKEND = "HEOS"

# Fixed points, read once from the backend at import time so they are never
# hand-typed / scattered as magic numbers elsewhere in the codebase.
if _COOLPROP_AVAILABLE:
    T_CRIT_K = CP.PropsSI("Tcrit", FLUID)
    P_CRIT_PA = CP.PropsSI("pcrit", FLUID)
    RHO_CRIT_KG_M3 = CP.PropsSI("rhocrit", FLUID)
    T_TRIPLE_K = CP.PropsSI("Ttriple", FLUID)
    P_TRIPLE_PA = CP.PropsSI("ptriple", FLUID)
    MOLAR_MASS_KG_MOL = CP.PropsSI("molar_mass", FLUID)
else:  # pragma: no cover - fallback literals, NIST/Leachman reference values
    T_CRIT_K = 32.9378
    P_CRIT_PA = 1.28578e6
    RHO_CRIT_KG_M3 = 31.315
    T_TRIPLE_K = 13.8033
    P_TRIPLE_PA = 7041.09
    MOLAR_MASS_KG_MOL = 2.01588e-3

R_UNIVERSAL_J_MOLK = 8.314462618
R_SPECIFIC_J_KGK = R_UNIVERSAL_J_MOLK / MOLAR_MASS_KG_MOL
G_STANDARD_M_S2 = 9.80665
NORMAL_BOILING_POINT_K = 20.369  # NIST value at 101.325 kPa, normal hydrogen convention;
# the HEOS-computed NBP for the active fluid is available via `normal_boiling_point()`.


class PropertyBackendError(RuntimeError):
    """Raised when the underlying property backend fails or is unavailable."""


def _require_backend() -> None:
    if not _COOLPROP_AVAILABLE:
        raise PropertyBackendError(
            "CoolProp is not installed/importable. The high-fidelity parahydrogen "
            "property engine requires CoolProp>=6.6. Install it, or use "
            "newton_lh2.thermodynamics.equation_of_state for a reduced-order "
            "fallback (explicitly lower fidelity -- not for production use)."
        )


@dataclass(frozen=True)
class SaturationEnvelope:
    """Saturated liquid/vapour properties at a single saturation state."""

    temperature_K: float
    pressure_Pa: float
    liquid_density_kg_m3: float
    vapor_density_kg_m3: float
    liquid_enthalpy_J_kg: float
    vapor_enthalpy_J_kg: float
    liquid_entropy_J_kgK: float
    vapor_entropy_J_kgK: float

    @property
    def latent_heat_J_kg(self) -> float:
        return self.vapor_enthalpy_J_kg - self.liquid_enthalpy_J_kg


class HydrogenProperties:
    """
    Real-fluid property accessor for parahydrogen, backed by CoolProp/HEOS.

    All methods take/return SI units. An internal ``AbstractState`` is
    reused across calls for performance; this class is **not** thread-safe
    (construct one instance per thread/process if parallelising, e.g. for
    Monte Carlo workers).

    Parameters
    ----------
    valid_range : ValidRange
        Facility-level validity envelope enforced before every property
        evaluation that specifies (T, P) directly.
    strict : bool
        If True (default), a state outside ``valid_range`` raises
        :class:`~newton_lh2.thermodynamics.validation.PropertyRangeError`.
        If False, it emits a :class:`PropertyRangeWarning` and proceeds
        (CoolProp itself will still refuse states outside its own
        correlation domain, e.g. below the melting line).
    """

    fluid = FLUID
    backend = BACKEND

    def __init__(self, valid_range: ValidRange = DEFAULT_RANGE, strict: bool = True):
        _require_backend()
        self._AS = CP.AbstractState(BACKEND, FLUID)
        self.valid_range = valid_range
        self.strict = strict

    # ------------------------------------------------------------------ #
    # Fixed points / metadata
    # ------------------------------------------------------------------ #
    @property
    def T_crit_K(self) -> float:
        return T_CRIT_K

    @property
    def P_crit_Pa(self) -> float:
        return P_CRIT_PA

    @property
    def T_triple_K(self) -> float:
        return T_TRIPLE_K

    @property
    def P_triple_Pa(self) -> float:
        return P_TRIPLE_PA

    @functools.lru_cache(maxsize=1)
    def normal_boiling_point(self) -> float:
        """Saturation temperature at 101325 Pa, kelvin."""
        return self.saturation_temperature(101325.0)

    # ------------------------------------------------------------------ #
    # Range checking
    # ------------------------------------------------------------------ #
    def _check_tp(self, temperature_K: float, pressure_Pa: float) -> None:
        self.valid_range.check(temperature_K, pressure_Pa, strict=self.strict)

    def is_below_melting_line(self, temperature_K: float, pressure_Pa: float) -> bool:
        """True if (T, P) lies in the solid region (below the melting curve)."""
        if pressure_Pa <= P_TRIPLE_PA:
            return False
        try:
            t_melt = self._AS.melting_line(CP.iT, CP.iP, pressure_Pa)
        except Exception:
            return False
        return temperature_K < t_melt

    # ------------------------------------------------------------------ #
    # Single-phase / general property lookups, given (T, P)
    # ------------------------------------------------------------------ #
    def _update_TP(self, temperature_K: float, pressure_Pa: float) -> None:
        self._check_tp(temperature_K, pressure_Pa)
        try:
            self._AS.update(CP.PT_INPUTS, pressure_Pa, temperature_K)
            return
        except ValueError as exc:
            first_exc = exc
        # The PT flash is numerically ill-conditioned exactly on the
        # saturation curve (T and P are not independent there). This is a
        # physically real operating point (e.g. a pump inlet at its NPSH
        # margin limit), so nudge pressure by a vanishing relative amount
        # rather than failing outright; the property values change
        # negligibly for a 1e-6-1e-4 relative perturbation this close in.
        for eps in (1e-6, 1e-5, 1e-4, 1e-3):
            for sign in (1.0, -1.0):
                try:
                    self._AS.update(CP.PT_INPUTS, pressure_Pa * (1.0 + sign * eps), temperature_K)
                    return
                except ValueError:
                    continue
        raise PropertyRangeError(
            f"Backend refused T={temperature_K:.3f} K, P={pressure_Pa:.1f} Pa: {first_exc}"
        ) from first_exc

    def density(self, temperature_K: float, pressure_Pa: float) -> float:
        self._update_TP(temperature_K, pressure_Pa)
        return self._AS.rhomass()

    def enthalpy(self, temperature_K: float, pressure_Pa: float) -> float:
        self._update_TP(temperature_K, pressure_Pa)
        return self._AS.hmass()

    def entropy(self, temperature_K: float, pressure_Pa: float) -> float:
        self._update_TP(temperature_K, pressure_Pa)
        return self._AS.smass()

    def internal_energy(self, temperature_K: float, pressure_Pa: float) -> float:
        self._update_TP(temperature_K, pressure_Pa)
        return self._AS.umass()

    def cp(self, temperature_K: float, pressure_Pa: float) -> float:
        """Isobaric specific heat, J/(kg K)."""
        self._update_TP(temperature_K, pressure_Pa)
        return self._AS.cpmass()

    def cv(self, temperature_K: float, pressure_Pa: float) -> float:
        """Isochoric specific heat, J/(kg K)."""
        self._update_TP(temperature_K, pressure_Pa)
        return self._AS.cvmass()

    def viscosity(self, temperature_K: float, pressure_Pa: float) -> float:
        """Dynamic viscosity, Pa s."""
        self._update_TP(temperature_K, pressure_Pa)
        return self._AS.viscosity()

    def thermal_conductivity(self, temperature_K: float, pressure_Pa: float) -> float:
        """Thermal conductivity, W/(m K)."""
        self._update_TP(temperature_K, pressure_Pa)
        return self._AS.conductivity()

    def speed_of_sound(self, temperature_K: float, pressure_Pa: float) -> float:
        self._update_TP(temperature_K, pressure_Pa)
        return self._AS.speed_sound()

    def drho_dT_at_P(self, temperature_K: float, pressure_Pa: float) -> float:
        """Partial derivative (d rho / d T) at constant P, kg/(m3 K)."""
        self._update_TP(temperature_K, pressure_Pa)
        return self._AS.first_partial_deriv(CP.iDmass, CP.iT, CP.iP)

    def drho_dP_at_T(self, temperature_K: float, pressure_Pa: float) -> float:
        """Partial derivative (d rho / d P) at constant T, kg/(m3 Pa)."""
        self._update_TP(temperature_K, pressure_Pa)
        return self._AS.first_partial_deriv(CP.iDmass, CP.iP, CP.iT)

    def du_dT_at_P(self, temperature_K: float, pressure_Pa: float) -> float:
        """Partial derivative (d u / d T) at constant P, J/(kg K) -- equals cp - P/rho^2 * drho/dT|P... (reported directly from the backend)."""
        self._update_TP(temperature_K, pressure_Pa)
        return self._AS.first_partial_deriv(CP.iUmass, CP.iT, CP.iP)

    def du_dP_at_T(self, temperature_K: float, pressure_Pa: float) -> float:
        """Partial derivative (d u / d P) at constant T, J/(kg Pa)."""
        self._update_TP(temperature_K, pressure_Pa)
        return self._AS.first_partial_deriv(CP.iUmass, CP.iP, CP.iT)

    # ------------------------------------------------------------------ #
    # Saturation curve
    # ------------------------------------------------------------------ #
    def saturation_pressure(self, temperature_K: float) -> float:
        """Saturation (vapour) pressure at the given temperature, Pa."""
        if not (T_TRIPLE_K <= temperature_K <= T_CRIT_K):
            raise PropertyRangeError(
                f"Saturation pressure undefined for T={temperature_K:.3f} K outside "
                f"[{T_TRIPLE_K:.3f}, {T_CRIT_K:.3f}] K"
            )
        return CP.PropsSI("P", "T", temperature_K, "Q", 0, FLUID)

    def saturation_temperature(self, pressure_Pa: float) -> float:
        """Saturation temperature at the given pressure, K."""
        if not (P_TRIPLE_PA <= pressure_Pa <= P_CRIT_PA):
            raise PropertyRangeError(
                f"Saturation temperature undefined for P={pressure_Pa:.1f} Pa outside "
                f"[{P_TRIPLE_PA:.1f}, {P_CRIT_PA:.1f}] Pa"
            )
        return CP.PropsSI("T", "P", pressure_Pa, "Q", 0, FLUID)

    def latent_heat(self, temperature_K: float) -> float:
        """Latent heat of vaporisation at the given saturation temperature, J/kg."""
        env = self.saturation_envelope_T(temperature_K)
        return env.latent_heat_J_kg

    def saturation_envelope_T(self, temperature_K: float) -> SaturationEnvelope:
        """Full saturated liquid/vapour property pair at a given temperature."""
        if not (T_TRIPLE_K <= temperature_K <= T_CRIT_K):
            raise PropertyRangeError(f"T={temperature_K:.3f} K outside saturation dome")
        self._AS.update(CP.QT_INPUTS, 0.0, temperature_K)
        p = self._AS.p()
        rho_l, h_l, s_l = self._AS.rhomass(), self._AS.hmass(), self._AS.smass()
        self._AS.update(CP.QT_INPUTS, 1.0, temperature_K)
        rho_v, h_v, s_v = self._AS.rhomass(), self._AS.hmass(), self._AS.smass()
        return SaturationEnvelope(temperature_K, p, rho_l, rho_v, h_l, h_v, s_l, s_v)

    def saturation_envelope_P(self, pressure_Pa: float) -> SaturationEnvelope:
        """Full saturated liquid/vapour property pair at a given pressure."""
        t_sat = self.saturation_temperature(pressure_Pa)
        return self.saturation_envelope_T(t_sat)

    def saturated_liquid_density(self, temperature_K: float) -> float:
        return self.saturation_envelope_T(temperature_K).liquid_density_kg_m3

    def saturated_vapor_density(self, temperature_K: float) -> float:
        return self.saturation_envelope_T(temperature_K).vapor_density_kg_m3

    def subcooling_K(self, temperature_K: float, pressure_Pa: float) -> float:
        """
        Degrees of subcooling below the saturation temperature at this
        pressure. Positive => subcooled liquid; negative => superheated
        vapour side; zero => on the saturation line.
        """
        if pressure_Pa >= P_CRIT_PA:
            return float("nan")
        t_sat = self.saturation_temperature(pressure_Pa)
        return t_sat - temperature_K

    # ------------------------------------------------------------------ #
    # Phase classification and full-state construction
    # ------------------------------------------------------------------ #
    def classify_phase(
        self, temperature_K: float, pressure_Pa: float, quality: float | None = None
    ) -> Phase:
        if self.is_below_melting_line(temperature_K, pressure_Pa):
            return Phase.SOLID
        supercritical_T = temperature_K >= T_CRIT_K
        supercritical_P = pressure_Pa >= P_CRIT_PA
        if supercritical_T and supercritical_P:
            return Phase.SUPERCRITICAL
        if supercritical_P and not supercritical_T:
            return Phase.SUPERCRITICAL_LIQUID
        if supercritical_T and not supercritical_P:
            return Phase.SUPERCRITICAL_GAS
        if quality is not None:
            if quality <= 1e-9:
                return Phase.SATURATED_LIQUID
            if quality >= 1 - 1e-9:
                return Phase.SATURATED_VAPOR
            return Phase.TWO_PHASE
        dT = self.subcooling_K(temperature_K, pressure_Pa)  # Tsat - T
        if dT > 1e-6:
            return Phase.SUBCOOLED_LIQUID
        if dT < -1e-6:
            return Phase.SUPERHEATED_VAPOR
        # Exactly on the saturation line but no quality supplied: use density
        # to disambiguate liquid-side vs vapour-side.
        rho = self.density(temperature_K, pressure_Pa)
        rho_l = self.saturated_liquid_density(temperature_K)
        rho_v = self.saturated_vapor_density(temperature_K)
        return Phase.SATURATED_LIQUID if abs(rho - rho_l) < abs(rho - rho_v) else Phase.SATURATED_VAPOR

    def state_TP(self, temperature_K: float, pressure_Pa: float) -> LH2State:
        """Build a full :class:`LH2State` from temperature and pressure."""
        self._update_TP(temperature_K, pressure_Pa)
        rho = self._AS.rhomass()
        h = self._AS.hmass()
        s = self._AS.smass()
        u = self._AS.umass()
        phase = self.classify_phase(temperature_K, pressure_Pa)
        quality = None
        if phase.is_two_phase:
            quality = self._AS.Q()
        elif phase in (Phase.SATURATED_LIQUID,):
            quality = 0.0
        elif phase in (Phase.SATURATED_VAPOR,):
            quality = 1.0
        return LH2State(temperature_K, pressure_Pa, rho, h, s, u, quality, phase)

    def state_TQ(self, temperature_K: float, quality: float) -> LH2State:
        """Build a saturation-line state from temperature and vapour quality."""
        if not (0.0 <= quality <= 1.0):
            raise ValueError(f"quality must be in [0, 1], got {quality}")
        self._AS.update(CP.QT_INPUTS, quality, temperature_K)
        p = self._AS.p()
        phase = self.classify_phase(temperature_K, p, quality=quality)
        return LH2State(
            temperature_K, p, self._AS.rhomass(), self._AS.hmass(), self._AS.smass(),
            self._AS.umass(), quality, phase,
        )

    def state_PQ(self, pressure_Pa: float, quality: float) -> LH2State:
        """Build a saturation-line state from pressure and vapour quality."""
        t_sat = self.saturation_temperature(pressure_Pa)
        return self.state_TQ(t_sat, quality)

    def state_PH(self, pressure_Pa: float, enthalpy_J_kg: float) -> LH2State:
        """Flash a state from pressure and specific enthalpy."""
        if pressure_Pa <= 0:
            raise PropertyRangeError(
                f"Non-physical pressure {pressure_Pa:.1f} Pa requested in P-H flash -- this "
                "usually means an upstream pressure-drop calculation has exceeded the available "
                "pressure (e.g. an undersized pipe or excessive flow rate)."
            )
        try:
            self._AS.update(CP.HmassP_INPUTS, enthalpy_J_kg, pressure_Pa)
        except ValueError as exc:
            raise PropertyRangeError(f"P-H flash failed at P={pressure_Pa:.1f} Pa, h={enthalpy_J_kg:.1f} J/kg: {exc}") from exc
        T = self._AS.T()
        rho = self._AS.rhomass()
        s = self._AS.smass()
        u = self._AS.umass()
        q = self._AS.Q()
        quality = q if 0.0 <= q <= 1.0 else None
        phase = self.classify_phase(T, pressure_Pa, quality=quality)
        self._check_tp(T, pressure_Pa) if not phase.is_two_phase else None
        return LH2State(T, pressure_Pa, rho, enthalpy_J_kg, s, u, quality, phase)

    def state_PS(self, pressure_Pa: float, entropy_J_kgK: float) -> LH2State:
        """Flash a state from pressure and specific entropy."""
        try:
            self._AS.update(CP.PSmass_INPUTS, pressure_Pa, entropy_J_kgK)
        except ValueError as exc:
            raise PropertyRangeError(f"P-S flash failed at P={pressure_Pa:.1f} Pa, s={entropy_J_kgK:.1f} J/kgK: {exc}") from exc
        T = self._AS.T()
        rho = self._AS.rhomass()
        h = self._AS.hmass()
        u = self._AS.umass()
        q = self._AS.Q()
        quality = q if 0.0 <= q <= 1.0 else None
        phase = self.classify_phase(T, pressure_Pa, quality=quality)
        return LH2State(T, pressure_Pa, rho, h, entropy_J_kgK, u, quality, phase)


#: Module-level convenience singleton. Component models default to this
#: unless a caller injects a differently-configured HydrogenProperties.
if _COOLPROP_AVAILABLE:
    DEFAULT_PROPERTIES = HydrogenProperties()
else:  # pragma: no cover
    DEFAULT_PROPERTIES = None
    warnings.warn(
        "CoolProp not available at import time -- DEFAULT_PROPERTIES is None. "
        "Construct HydrogenProperties() explicitly once CoolProp is installed.",
        RuntimeWarning,
    )
