"""
Validity-range enforcement for the property engine.

The simulator must never silently extrapolate a real-fluid property
correlation beyond the domain it was fitted to. This module defines the
domain the facility is validated for, and raises (or, in permissive mode,
warns) when a requested state falls outside it.
"""

from __future__ import annotations

import warnings
from dataclasses import dataclass


class PropertyRangeError(ValueError):
    """Raised when a requested thermodynamic state is outside the validated domain."""


class PropertyRangeWarning(UserWarning):
    """Raised in permissive mode instead of :class:`PropertyRangeError`."""


@dataclass(frozen=True)
class ValidRange:
    """
    Inclusive validity envelope for the parahydrogen property backend, as
    used by this facility.

    Bounds are deliberately narrower than the full HEOS correlation range
    (13.8--1000 K, up to 2 GPa): they describe the domain this *facility's*
    equipment and process are validated for, not the outer limit of what
    the underlying equation of state can technically compute.
    """

    T_min_K: float = 13.803  # triple point of parahydrogen
    T_max_K: float = 320.0  # generous margin above ambient piping temperature
    P_min_Pa: float = 6000.0  # just below triple-point pressure (7041 Pa)
    P_max_Pa: float = 3.0e6  # 30 bar -- conservative ground-system MAWP envelope

    def check(self, temperature_K: float, pressure_Pa: float, *, strict: bool = True) -> None:
        """Raise/warn if (T, P) lies outside the validated envelope."""
        problems = []
        if not (self.T_min_K <= temperature_K <= self.T_max_K):
            problems.append(
                f"temperature {temperature_K:.3f} K outside validated range "
                f"[{self.T_min_K:.3f}, {self.T_max_K:.3f}] K"
            )
        if not (self.P_min_Pa <= pressure_Pa <= self.P_max_Pa):
            problems.append(
                f"pressure {pressure_Pa:.1f} Pa outside validated range "
                f"[{self.P_min_Pa:.1f}, {self.P_max_Pa:.1f}] Pa"
            )
        if problems:
            message = "; ".join(problems)
            if strict:
                raise PropertyRangeError(message)
            warnings.warn(message, PropertyRangeWarning, stacklevel=3)


DEFAULT_RANGE = ValidRange()
