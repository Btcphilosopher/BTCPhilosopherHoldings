"""
Equation-of-state metadata and a reduced-order analytic cross-check model.

Primary property source
------------------------
The facility's primary property source is the Leachman et al. (2009)
multiparameter Helmholtz-energy equation of state for parahydrogen, accessed
through CoolProp/HEOS in :mod:`newton_lh2.thermodynamics.properties`. That
is what every component model uses operationally.

Reduced-order fallback / cross-check
-------------------------------------
This module additionally implements a classical two-parameter cubic
equation of state (Redlich-Kwong) purely as:

1. an independent analytic cross-check of the primary EOS in the
   validation notebooks (does a simple corresponding-states cubic agree
   with the reference EOS to the expected ~5-10% in the vapour region?),
   and
2. a degraded-mode fallback if CoolProp is unavailable.

The RK model is **not** used by any operational component model, is not
tuned to LH2 specifically beyond its critical-point parameters, and is
known to be a poor approximation for the saturated liquid density (cubic
EOS liquid roots are qualitatively but not quantitatively reliable). It
must never be silently substituted for the primary source; callers must
opt in explicitly.

Redlich-Kwong equation
-----------------------
    P = R T / (V - b)  -  a / (sqrt(T) V (V + b))

    a = 0.42748 R^2 Tc^2.5 / Pc
    b = 0.08664 R Tc / Pc

in molar form (V = molar volume, m3/mol). Compressibility-factor cubic:

    Z^3 - Z^2 + (A - B - B^2) Z - A B = 0
    A = a P / (R^2 T^2.5),   B = b P / (R T)

Residual (departure) enthalpy/entropy relative to an ideal gas at the same
(T, P), using the standard generic-cubic departure formulas with
eps=0, sigma=1 (Smith, Van Ness & Abbott, "Introduction to Chemical
Engineering Thermodynamics"):

    H^R / (R T) = Z - 1 - (3/2) * a / (b R T) * ln[(Z + B) / Z]
    S^R / R     = ln(Z - B) - (1/2) * a / (b R T) * ln[(Z + B) / Z]

(using d(a/sqrt(T))/dT = -a / (2T) for the classical RK temperature
dependence).
"""

from __future__ import annotations

import math
from dataclasses import dataclass

import numpy as np

from newton_lh2.thermodynamics.properties import (
    T_CRIT_K,
    P_CRIT_PA,
    MOLAR_MASS_KG_MOL,
    R_UNIVERSAL_J_MOLK as R,
)

# ---------------------------------------------------------------------- #
# Metadata
# ---------------------------------------------------------------------- #


@dataclass(frozen=True)
class EquationOfStateInfo:
    name: str
    reference: str
    domain: str
    is_primary: bool


PRIMARY_EOS = EquationOfStateInfo(
    name="Leachman et al. (2009) parahydrogen HEOS (via CoolProp)",
    reference=(
        "Leachman, J.W., Jacobsen, R.T., Penoncello, S.G., Lemmon, E.W., "
        "'Fundamental Equations of State for Parahydrogen, Normal Hydrogen, "
        "and Orthohydrogen', J. Phys. Chem. Ref. Data 38(3), 2009."
    ),
    domain="13.8033-1000 K, up to 2 GPa (facility envelope restricted further, see thermodynamics.validation)",
    is_primary=True,
)

FALLBACK_EOS = EquationOfStateInfo(
    name="Redlich-Kwong cubic (corresponding-states, Tc/Pc calibrated)",
    reference="Redlich, O.; Kwong, J.N.S. (1949), Chem. Rev. 44 (1): 233-244.",
    domain="Qualitative only; not fit to parahydrogen beyond Tc, Pc. Vapour phase acceptable, liquid phase poor.",
    is_primary=False,
)

# ---------------------------------------------------------------------- #
# Redlich-Kwong parameters (molar basis, SI)
# ---------------------------------------------------------------------- #

_A0 = 0.42748 * R**2 * T_CRIT_K**2.5 / P_CRIT_PA  # Pa m6 K^0.5 / mol^2
_B0 = 0.08664 * R * T_CRIT_K / P_CRIT_PA  # m3/mol


def _a_of_T(temperature_K: float) -> float:
    return _A0 / math.sqrt(temperature_K)


def compressibility_roots(temperature_K: float, pressure_Pa: float) -> np.ndarray:
    """
    Real roots Z of the Redlich-Kwong compressibility-factor cubic at
    (T, P), sorted ascending. Typically one root in the liquid-like
    region and one in the vapour-like region below the critical point;
    a single root above it.
    """
    a = _a_of_T(temperature_K)
    A = a * pressure_Pa / (R**2 * temperature_K**2.5)
    B = _B0 * pressure_Pa / (R * temperature_K)
    coeffs = [1.0, -1.0, A - B - B**2, -A * B]
    roots = np.roots(coeffs)
    real = roots[np.abs(roots.imag) < 1e-8].real
    real = real[real > B]  # V > b required physically
    return np.sort(real)


def molar_volume(temperature_K: float, pressure_Pa: float, branch: str = "vapor") -> float:
    """
    RK molar volume, m3/mol. ``branch`` selects "vapor" (largest root,
    recommended) or "liquid" (smallest root, poor quantitative accuracy --
    cross-check use only).
    """
    roots = compressibility_roots(temperature_K, pressure_Pa)
    if roots.size == 0:
        raise ValueError(f"No physical RK root at T={temperature_K}, P={pressure_Pa}")
    Z = roots[-1] if branch == "vapor" else roots[0]
    return Z * R * temperature_K / pressure_Pa


def density_rk(temperature_K: float, pressure_Pa: float, branch: str = "vapor") -> float:
    """RK mass density cross-check, kg/m3."""
    V = molar_volume(temperature_K, pressure_Pa, branch=branch)
    return MOLAR_MASS_KG_MOL / V


def residual_enthalpy_J_mol(temperature_K: float, pressure_Pa: float, branch: str = "vapor") -> float:
    """RK residual (departure) molar enthalpy H - H_ideal_gas at same (T,P), J/mol."""
    roots = compressibility_roots(temperature_K, pressure_Pa)
    Z = roots[-1] if branch == "vapor" else roots[0]
    a = _a_of_T(temperature_K)
    B = _B0 * pressure_Pa / (R * temperature_K)
    return R * temperature_K * (Z - 1.0 - 1.5 * a / (_B0 * R * temperature_K**1.5) * math.log((Z + B) / Z))


def residual_entropy_J_molK(temperature_K: float, pressure_Pa: float, branch: str = "vapor") -> float:
    """RK residual (departure) molar entropy S - S_ideal_gas at same (T,P), J/(mol K)."""
    roots = compressibility_roots(temperature_K, pressure_Pa)
    Z = roots[-1] if branch == "vapor" else roots[0]
    a = _a_of_T(temperature_K)
    B = _B0 * pressure_Pa / (R * temperature_K)
    return R * (math.log(Z - B) - 0.5 * a / (_B0 * R * temperature_K**1.5) * math.log((Z + B) / Z))


# ---------------------------------------------------------------------- #
# Rackett correlation cross-check for saturated liquid density
# ---------------------------------------------------------------------- #


def calibrate_rackett_zc(reference_density_kg_m3: float, temperature_K: float) -> float:
    """
    Fit the empirical Rackett compressibility parameter Zc_R against one
    known saturated-liquid density point (typically the normal boiling
    point from the primary EOS), so the correlation's *shape* can then be
    used to cross-check the primary EOS's trend away from that point.
    """
    Tr = temperature_K / T_CRIT_K
    v_sat = MOLAR_MASS_KG_MOL / reference_density_kg_m3
    exponent = 1.0 + (1.0 - Tr) ** (2.0 / 7.0)
    # v_sat = (R Tc / Pc) * Zc_R ** exponent  =>  solve for Zc_R
    v_ideal_crit = R * T_CRIT_K / P_CRIT_PA
    return (v_sat / v_ideal_crit) ** (1.0 / exponent)


def rackett_saturated_liquid_density(temperature_K: float, zc_rackett: float) -> float:
    """Rackett-correlation saturated liquid density, kg/m3, given a calibrated Zc_R."""
    Tr = temperature_K / T_CRIT_K
    exponent = 1.0 + (1.0 - Tr) ** (2.0 / 7.0)
    v_ideal_crit = R * T_CRIT_K / P_CRIT_PA
    v_sat = v_ideal_crit * zc_rackett**exponent
    return MOLAR_MASS_KG_MOL / v_sat
