"""
Phase classification for parahydrogen.

Distinguishes the physical regimes relevant to a cryogenic conditioning
process:

* ``SOLID``               -- below the melting line (flagged, not modelled)
* ``SUBCOOLED_LIQUID``     -- liquid, T below Tsat(P) by more than a margin
* ``SATURATED_LIQUID``     -- liquid at the saturation line (quality = 0)
* ``TWO_PHASE``            -- liquid + vapour mixture (0 < quality < 1)
* ``SATURATED_VAPOR``      -- vapour at the saturation line (quality = 1)
* ``SUPERHEATED_VAPOR``    -- vapour, T above Tsat(P)
* ``SUPERCRITICAL_LIQUID`` -- above critical pressure, below critical T
* ``SUPERCRITICAL_GAS``    -- above critical T, below critical P
* ``SUPERCRITICAL``        -- above both critical T and critical P

The classification is deliberately explicit rather than inferred from a
single density threshold, matching the way a cryogenics engineer would
describe fluid state on a T-s or P-h diagram.
"""

from __future__ import annotations

from enum import Enum


class Phase(str, Enum):
    SOLID = "solid"
    SUBCOOLED_LIQUID = "subcooled_liquid"
    SATURATED_LIQUID = "saturated_liquid"
    TWO_PHASE = "two_phase"
    SATURATED_VAPOR = "saturated_vapor"
    SUPERHEATED_VAPOR = "superheated_vapor"
    SUPERCRITICAL_LIQUID = "supercritical_liquid"
    SUPERCRITICAL_GAS = "supercritical_gas"
    SUPERCRITICAL = "supercritical"

    def __str__(self) -> str:  # pragma: no cover - trivial
        return self.value

    @property
    def is_liquid_like(self) -> bool:
        return self in (
            Phase.SUBCOOLED_LIQUID,
            Phase.SATURATED_LIQUID,
            Phase.SUPERCRITICAL_LIQUID,
        )

    @property
    def is_vapor_like(self) -> bool:
        return self in (
            Phase.SATURATED_VAPOR,
            Phase.SUPERHEATED_VAPOR,
            Phase.SUPERCRITICAL_GAS,
        )

    @property
    def is_two_phase(self) -> bool:
        return self is Phase.TWO_PHASE
