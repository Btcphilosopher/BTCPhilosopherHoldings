"""
Saturation-curve convenience helpers built on top of
:class:`~newton_lh2.thermodynamics.properties.HydrogenProperties`.

These are thin, intention-revealing wrappers used throughout the tank and
densification models so call sites read like engineering statements
("is this liquid subcooled by at least 0.5 K?") rather than raw property
calls.
"""

from __future__ import annotations

from dataclasses import dataclass

from newton_lh2.thermodynamics.properties import (
    HydrogenProperties,
    DEFAULT_PROPERTIES,
    T_CRIT_K,
    P_CRIT_PA,
    T_TRIPLE_K,
    P_TRIPLE_PA,
)


@dataclass(frozen=True)
class SubcoolingMargin:
    """Result of a subcooling-margin check at a given (T, P)."""

    temperature_K: float
    pressure_Pa: float
    saturation_temperature_K: float
    margin_K: float  # Tsat(P) - T ; positive => subcooled

    @property
    def is_subcooled(self) -> bool:
        return self.margin_K > 0.0

    @property
    def is_saturated(self) -> bool:
        return abs(self.margin_K) < 1e-6

    @property
    def is_superheated(self) -> bool:
        return self.margin_K < 0.0


def subcooling_margin(
    temperature_K: float,
    pressure_Pa: float,
    props: HydrogenProperties = None,
) -> SubcoolingMargin:
    """Compute subcooling margin at (T, P). Positive margin = subcooled liquid."""
    props = props or DEFAULT_PROPERTIES
    t_sat = props.saturation_temperature(min(pressure_Pa, P_CRIT_PA * 0.999999))
    return SubcoolingMargin(temperature_K, pressure_Pa, t_sat, t_sat - temperature_K)


def is_within_saturation_dome(temperature_K: float, pressure_Pa: float) -> bool:
    """True if (T, P) is thermodynamically capable of two-phase coexistence."""
    return (T_TRIPLE_K <= temperature_K <= T_CRIT_K) and (P_TRIPLE_PA <= pressure_Pa <= P_CRIT_PA)


def reduced_temperature(temperature_K: float) -> float:
    """T / Tcrit."""
    return temperature_K / T_CRIT_K


def reduced_pressure(pressure_Pa: float) -> float:
    """P / Pcrit."""
    return pressure_Pa / P_CRIT_PA
