"""
Densification: LH2 conditioning process analysis.

Densification is modelled as a genuine thermodynamic state-change process
-- an initial LH2 state is cooled (and/or pressure-adjusted) to a final
state via the conditioner (:mod:`newton_lh2.cryogenics.heat_exchanger`),
and this module characterises the *consequences* of that state change:
how much denser the fluid becomes, how much heat had to be removed to get
there, and -- because "cold enough" is not "free" -- an estimate of the
real energy cost of removing that heat against an ambient heat sink.

Second-law energy-cost estimate
---------------------------------
The **minimum possible** work to pump heat ``Q_removed`` from the process
fluid (near temperature ``T_cold``) up to an ambient heat rejection
temperature ``T_warm`` is set by the reverse-Carnot coefficient of
performance:

    COP_Carnot = T_cold / (T_warm - T_cold)
    W_min      = Q_removed / COP_Carnot

Real hydrogen refrigeration/liquefaction equipment does not reach Carnot
performance; a **practical Carnot fraction** (representative order-of-
magnitude figure commonly cited for small-to-mid-scale hydrogen
refrigeration plants, roughly 15-30% of Carnot -- larger, more optimised
liquefiers trend toward the upper end) converts the ideal bound into a
representative estimate of actual shaft/electrical energy consumption
when the caller has not supplied a measured value directly:

    W_actual_est = W_min / carnot_fraction
    process_efficiency = W_min / W_actual  (== carnot_fraction, by construction,
                                             unless the caller supplies a measured
                                             W_actual, in which case this reports
                                             the *true* second-law efficiency)
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

from newton_lh2.simulation.state import LH2State
from newton_lh2.thermodynamics.properties import HydrogenProperties, DEFAULT_PROPERTIES


@dataclass(frozen=True)
class DensificationResult:
    initial_state: LH2State
    final_state: LH2State
    mass_processed_kg: float
    delta_density_kg_m3: float
    delta_temperature_K: float
    delta_pressure_Pa: float
    delta_enthalpy_J_kg: float
    heat_removed_J: float
    energy_consumption_J: float
    volumetric_change_m3: float
    specific_cooling_energy_J_kg: float
    process_efficiency: float
    ambient_temperature_K: float

    @property
    def density_increase_percent(self) -> float:
        return 100.0 * self.delta_density_kg_m3 / self.initial_state.density_kg_m3

    def report(self) -> str:
        return (
            "DENSIFICATION RESULT\n"
            f"  Initial : {self.initial_state.temperature_K:7.3f} K, "
            f"{self.initial_state.pressure_Pa/1e5:7.4f} bar, {self.initial_state.density_kg_m3:7.3f} kg/m3\n"
            f"  Final   : {self.final_state.temperature_K:7.3f} K, "
            f"{self.final_state.pressure_Pa/1e5:7.4f} bar, {self.final_state.density_kg_m3:7.3f} kg/m3\n"
            f"  Density increase : {self.delta_density_kg_m3:+7.3f} kg/m3 "
            f"({self.density_increase_percent:+.3f} %)\n"
            f"  Mass processed   : {self.mass_processed_kg:10.3f} kg\n"
            f"  Heat removed     : {self.heat_removed_J/1e6:10.4f} MJ\n"
            f"  Energy consumed  : {self.energy_consumption_J/1e6:10.4f} MJ (est.)\n"
            f"  Specific cooling energy : {self.specific_cooling_energy_J_kg/1e3:8.3f} kJ/kg\n"
            f"  Process (2nd-law) efficiency : {self.process_efficiency*100:6.2f} %"
        )


def densify(
    initial_state: LH2State,
    final_state: LH2State,
    mass_processed_kg: float,
    ambient_temperature_K: float = 293.15,
    carnot_fraction: float = 0.22,
    measured_energy_consumption_J: Optional[float] = None,
    props: HydrogenProperties = None,
) -> DensificationResult:
    """
    Characterise a densification process from ``initial_state`` to
    ``final_state`` for ``mass_processed_kg`` of hydrogen.

    Parameters
    ----------
    ambient_temperature_K : float
        Heat-rejection (ambient) temperature for the Carnot bound.
    carnot_fraction : float
        Assumed fraction of Carnot COP achieved by the real refrigeration
        plant, used only if ``measured_energy_consumption_J`` is not
        supplied (see module docstring).
    measured_energy_consumption_J : float, optional
        If the actual shaft/electrical energy consumed is known (e.g.
        integrated compressor power from telemetry), pass it here to get
        a *true* second-law process efficiency instead of an estimate.
    """
    props = props or DEFAULT_PROPERTIES
    if mass_processed_kg <= 0:
        raise ValueError("mass_processed_kg must be positive")
    if not (0.0 < carnot_fraction <= 1.0):
        raise ValueError("carnot_fraction must be in (0, 1]")

    dh = final_state.enthalpy_J_kg - initial_state.enthalpy_J_kg
    heat_removed_J = -mass_processed_kg * dh  # positive when the fluid is cooled

    T_cold = final_state.temperature_K
    if ambient_temperature_K <= T_cold:
        raise ValueError("ambient_temperature_K must exceed the final (cold) temperature")
    cop_carnot = T_cold / (ambient_temperature_K - T_cold)
    w_min = heat_removed_J / cop_carnot if heat_removed_J > 0 else 0.0

    if measured_energy_consumption_J is not None:
        w_actual = measured_energy_consumption_J
    else:
        w_actual = w_min / carnot_fraction if heat_removed_J > 0 else 0.0

    efficiency = (w_min / w_actual) if w_actual > 0 else float("nan")

    vol_initial = mass_processed_kg / initial_state.density_kg_m3
    vol_final = mass_processed_kg / final_state.density_kg_m3

    return DensificationResult(
        initial_state=initial_state,
        final_state=final_state,
        mass_processed_kg=mass_processed_kg,
        delta_density_kg_m3=final_state.density_kg_m3 - initial_state.density_kg_m3,
        delta_temperature_K=final_state.temperature_K - initial_state.temperature_K,
        delta_pressure_Pa=final_state.pressure_Pa - initial_state.pressure_Pa,
        delta_enthalpy_J_kg=dh,
        heat_removed_J=heat_removed_J,
        energy_consumption_J=w_actual,
        volumetric_change_m3=vol_final - vol_initial,
        specific_cooling_energy_J_kg=w_actual / mass_processed_kg,
        process_efficiency=efficiency,
        ambient_temperature_K=ambient_temperature_K,
    )
