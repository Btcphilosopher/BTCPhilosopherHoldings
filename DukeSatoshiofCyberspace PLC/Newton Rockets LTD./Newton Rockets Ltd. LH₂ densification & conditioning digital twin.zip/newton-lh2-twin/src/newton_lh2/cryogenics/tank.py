"""
Cryogenic tank digital twin.

Two-region (saturated liquid pool + saturated vapour ullage) thermodynamic
equilibrium model of a rigid, fixed-volume LH2 storage/conditioning tank.

Model
-----
The tank's independent dynamic state is its total hydrogen mass ``M`` and
total internal energy ``U`` inside the fixed geometric volume ``V``. Given
``(M, U, V)``, the equilibrium state follows from a closed-system,
fixed-volume "UV flash":

* **Two-phase branch** (liquid pool + vapour ullage, the expected
  operating regime for a vented/near-equilibrium storage or conditioning
  tank): find the saturation temperature ``T`` such that a liquid/vapour
  split consistent with the volume constraint,

      x(T) = (v - v_L(T)) / (v_V(T) - v_L(T)),   v = V/M

  also satisfies the energy constraint,

      u(T) = (1 - x) u_L(T) + x u_V(T) = U/M.

  This is solved by 1-D root-finding on ``T`` (Brent's method) over the
  saturation dome.

* **Single-phase fallback** (fully-liquid or fully-vapour tank, or a
  compressed/subcooled state outside the dome): if no two-phase root
  exists, ``(T, P)`` are solved directly by 2-D Newton iteration so that
  ``rho(T, P) = M/V`` and ``u(T, P) = U/M``.

This is a deliberately simple, physically transparent model (a single
well-mixed control volume) rather than a resolved-stratification CFD
model. See the "Limitations" section of the project README for what this
does and does not capture (notably: it assumes the liquid pool and vapour
ullage are in mutual thermodynamic equilibrium at every instant, i.e. no
stratification and no non-equilibrium pressure spikes from rapid
flash-boiling).

Boil-off
--------
Two related but distinct quantities are reported:

``self_pressurization`` mode (no venting): heat leak raises ``U`` at
constant ``M``; the UV flash returns the resulting rise in ``T``, ``P``
and vapour fraction ``x`` directly -- this *is* the transient response,
no additional "boil-off rate" is needed.

``normal_boiloff_rate_kg_s``: the vent mass flow rate that would be
required to reject the current heat leak entirely as latent heat, holding
pressure constant -- ``Q_dot / h_fg(T)``. This is the conventional
"NBOR" figure of merit reported for vented cryogenic storage, and is
always available as a diagnostic regardless of whether venting is active.
"""

from __future__ import annotations

import warnings
from dataclasses import dataclass
from typing import Optional

import numpy as np
from scipy.optimize import brentq

from newton_lh2.cryogenics.heat_leak import HeatLeakBudget
from newton_lh2.cryogenics.insulation import InsulationSystem
from newton_lh2.thermodynamics.phase import Phase
from newton_lh2.thermodynamics.properties import (
    HydrogenProperties,
    DEFAULT_PROPERTIES,
    T_TRIPLE_K,
    T_CRIT_K,
)
from newton_lh2.thermodynamics.validation import PropertyRangeError
from newton_lh2.simulation.state import LH2State


class TankStateError(RuntimeError):
    """Raised when the tank (M, U, V) state cannot be resolved to a physical state."""


@dataclass(frozen=True)
class TankGeometry:
    """Right-circular-cylinder tank geometry (flat-end simplification)."""

    volume_m3: float
    diameter_m: Optional[float] = None

    def __post_init__(self) -> None:
        if self.volume_m3 <= 0:
            raise ValueError("volume_m3 must be positive")
        if self.diameter_m is not None and self.diameter_m <= 0:
            raise ValueError("diameter_m must be positive if given")

    @property
    def cross_section_area_m2(self) -> Optional[float]:
        if self.diameter_m is None:
            return None
        return np.pi * self.diameter_m**2 / 4.0

    @property
    def height_m(self) -> Optional[float]:
        A = self.cross_section_area_m2
        if A is None:
            return None
        return self.volume_m3 / A

    def liquid_level_m(self, liquid_volume_m3: float) -> Optional[float]:
        A = self.cross_section_area_m2
        if A is None:
            return None
        return liquid_volume_m3 / A


@dataclass(frozen=True)
class TankState:
    """Reporting snapshot of a :class:`CryoTank` at one instant in time."""

    time_s: float
    mass_total_kg: float
    mass_liquid_kg: float
    mass_vapor_kg: float
    temperature_K: float
    pressure_Pa: float
    quality: float
    phase: Phase
    liquid_density_kg_m3: float
    vapor_density_kg_m3: float
    liquid_volume_m3: float
    vapor_volume_m3: float
    fill_fraction: float
    liquid_level_m: Optional[float]
    heat_leak_W: float
    normal_boiloff_rate_kg_s: float
    internal_energy_J: float

    def as_dict(self) -> dict:
        d = dict(self.__dict__)
        d["phase"] = str(self.phase)
        return d


class CryoTank:
    """
    Rigid, fixed-volume LH2 tank with a well-mixed liquid pool + vapour
    ullage in mutual thermodynamic equilibrium.
    """

    def __init__(
        self,
        geometry: TankGeometry,
        insulation: InsulationSystem,
        ambient_temperature_K: float,
        initial_mass_kg: float,
        initial_temperature_K: float,
        props: HydrogenProperties = None,
        heat_leak_config=None,
    ):
        self.geometry = geometry
        self.insulation = insulation
        self.ambient_temperature_K = ambient_temperature_K
        self.props = props or DEFAULT_PROPERTIES
        from newton_lh2.cryogenics.heat_leak import HeatLeakConfig  # local import, avoid cycle at module load

        self.heat_leak_config = heat_leak_config or HeatLeakConfig()

        if not (T_TRIPLE_K < initial_temperature_K < T_CRIT_K):
            raise ValueError(
                f"initial_temperature_K={initial_temperature_K} must lie strictly within the "
                f"two-phase dome ({T_TRIPLE_K}, {T_CRIT_K}) K for saturated-equilibrium initialisation"
            )

        env = self.props.saturation_envelope_T(initial_temperature_K)
        v_L, v_V = 1.0 / env.liquid_density_kg_m3, 1.0 / env.vapor_density_kg_m3
        v_target = geometry.volume_m3 / initial_mass_kg
        if not (v_L <= v_target <= v_V):
            raise ValueError(
                f"initial_mass_kg={initial_mass_kg} at T={initial_temperature_K} K does not fit "
                f"within tank volume {geometry.volume_m3} m3 as a two-phase mixture "
                f"(specific volume {v_target:.6e} m3/kg outside [{v_L:.6e}, {v_V:.6e}])"
            )
        x0 = (v_target - v_L) / (v_V - v_L)
        u_L = self._liquid_internal_energy(initial_temperature_K, env)
        u_V = self._vapor_internal_energy(initial_temperature_K, env)
        u0 = (1 - x0) * u_L + x0 * u_V

        self.M = float(initial_mass_kg)
        self.U = float(u0 * initial_mass_kg)

    # ------------------------------------------------------------------ #
    # Internal helpers
    # ------------------------------------------------------------------ #
    def _vapor_internal_energy(self, T: float, env) -> float:
        # u = h - P v  for the saturated vapour branch
        return env.vapor_enthalpy_J_kg - env.pressure_Pa / env.vapor_density_kg_m3

    def _liquid_internal_energy(self, T: float, env) -> float:
        return env.liquid_enthalpy_J_kg - env.pressure_Pa / env.liquid_density_kg_m3

    def _flash_two_phase(self, M: float, U: float, n: int = 40) -> Optional[tuple[float, float]]:
        """Attempt the two-phase UV flash. Returns (T, x) or None if infeasible."""
        v = self.geometry.volume_m3 / M
        u = U / M

        def residual(T: float) -> float:
            env = self.props.saturation_envelope_T(T)
            v_L, v_V = 1.0 / env.liquid_density_kg_m3, 1.0 / env.vapor_density_kg_m3
            x = (v - v_L) / (v_V - v_L)
            if x < -1e-6 or x > 1 + 1e-6:
                # Signal infeasibility with a large residual of consistent sign
                return 1.0e12 * (x if x > 1 else (x - 1))
            x = min(max(x, 0.0), 1.0)
            u_L = self._liquid_internal_energy(T, env)
            u_V = self._vapor_internal_energy(T, env)
            return ((1 - x) * u_L + x * u_V) - u

        T_lo, T_hi = T_TRIPLE_K * 1.0005, T_CRIT_K * 0.9995
        # Bias sampling density toward T_crit: the dome narrows sharply
        # there (v_V - v_L -> 0), so a uniform grid coarser than ~0.1 K
        # near the top can straddle a root without detecting a sign change.
        frac = np.linspace(0.0, 1.0, n) ** 2
        Ts = T_lo + frac * (T_hi - T_lo)
        residuals = []
        for T in Ts:
            try:
                residuals.append(residual(T))
            except PropertyRangeError:
                residuals.append(np.nan)
        residuals = np.array(residuals)
        for i in range(n - 1):
            r0, r1 = residuals[i], residuals[i + 1]
            if np.isnan(r0) or np.isnan(r1):
                continue
            if r0 == 0.0:
                T_sol = Ts[i]
                break
            if r0 * r1 < 0.0:
                T_sol = brentq(residual, Ts[i], Ts[i + 1], xtol=1e-8, rtol=1e-10)
                break
        else:
            return None

        env = self.props.saturation_envelope_T(T_sol)
        v_L, v_V = 1.0 / env.liquid_density_kg_m3, 1.0 / env.vapor_density_kg_m3
        x_sol = min(max((v - v_L) / (v_V - v_L), 0.0), 1.0)
        return T_sol, x_sol

    def _flash_single_phase(self, M: float, U: float, branch_hint: str) -> tuple[float, float]:
        """2-D Newton solve for a single-phase (subcooled liquid or superheated vapour) state."""
        rho_target = M / self.geometry.volume_m3
        u_target = U / M
        # Seed guess
        if branch_hint == "liquid":
            T, P = 18.0, 1.5e5
        else:
            T, P = 30.0, 1.0e5
        for _ in range(50):
            rho = self.props.density(T, P)
            u = self.props.internal_energy(T, P)
            f1 = rho - rho_target
            f2 = u - u_target
            drho_dT = self.props.drho_dT_at_P(T, P)
            drho_dP = self.props.drho_dP_at_T(T, P)
            du_dT = self.props.du_dT_at_P(T, P)
            du_dP = self.props.du_dP_at_T(T, P)
            J = np.array([[drho_dT, drho_dP], [du_dT, du_dP]])
            F = np.array([f1, f2])
            try:
                delta = np.linalg.solve(J, -F)
            except np.linalg.LinAlgError as exc:
                raise TankStateError("Singular Jacobian in single-phase tank flash") from exc
            step = 1.0
            T_max = self.props.valid_range.T_max_K * 0.999
            P_max = self.props.valid_range.P_max_Pa * 0.999
            P_min = self.props.valid_range.P_min_Pa * 1.001
            T_min = max(T_TRIPLE_K * 0.99, self.props.valid_range.T_min_K * 1.001)
            T_new, P_new = T + step * delta[0], P + step * delta[1]
            while P_new < P_min or P_new > P_max or T_new < T_min or T_new > T_max:
                step *= 0.5
                T_new, P_new = T + step * delta[0], P + step * delta[1]
                if step < 1e-8:
                    raise TankStateError(
                        f"Single-phase tank flash step stayed out of the validated domain "
                        f"(target rho={rho_target:.4f} kg/m3, u={u_target:.4e} J/kg)"
                    )
            T, P = T_new, P_new
            if abs(f1) < 1e-6 * max(rho_target, 1.0) and abs(f2) < 1e-3 * max(abs(u_target), 1.0):
                return T, P
        raise TankStateError(
            f"Single-phase tank flash did not converge for M={M:.4f} kg, U={U:.4e} J, V={self.geometry.volume_m3} m3"
        )

    # ------------------------------------------------------------------ #
    # Public API
    def _project_to_dome_boundary(self, M: float, U: float) -> LH2State:
        """
        Last-resort fallback when (M, U) cannot be resolved to any
        physical state (two-phase flash found no root even on a fine
        grid, and the single-phase Newton solve also failed): this means
        the requested specific energy is outside what the saturation dome
        can supply at this specific volume at *any* temperature (e.g. an
        ODE solver's trial sub-step overshot into a genuinely
        unreachable corner). Rather than raise and abort an otherwise
        well-posed simulation, clamp to whichever dome boundary
        (T -> T_triple or T -> T_crit) is energetically closest, and warn.
        This only ever fires for transient *trial* evaluations deep inside
        an adaptive step -- the solver's own error control will see the
        resulting large local error and shrink the step, so it does not
        silently corrupt the accepted trajectory.
        """
        v = self.geometry.volume_m3 / M
        u = U / M

        def x_and_u(T: float) -> tuple[float, float]:
            env = self.props.saturation_envelope_T(T)
            v_L, v_V = 1.0 / env.liquid_density_kg_m3, 1.0 / env.vapor_density_kg_m3
            x = min(max((v - v_L) / (v_V - v_L), 0.0), 1.0)
            u_L, u_V = self._liquid_internal_energy(T, env), self._vapor_internal_energy(T, env)
            return x, (1 - x) * u_L + x * u_V

        T_lo, T_hi = T_TRIPLE_K * 1.0005, T_CRIT_K * 0.9995
        x_lo, u_lo = x_and_u(T_lo)
        x_hi, u_hi = x_and_u(T_hi)
        if abs(u - u_lo) <= abs(u - u_hi):
            T_sel, x_sel = T_lo, x_lo
        else:
            T_sel, x_sel = T_hi, x_hi
        warnings.warn(
            f"Tank (M={M:.4f} kg, U={U:.6e} J) is outside the physically achievable envelope "
            f"(specific volume {v:.6e} m3/kg, specific energy {u:.4e} J/kg); clamped to the "
            f"nearest saturation-dome boundary at T={T_sel:.3f} K. This should only occur for a "
            f"transient trial state deep inside an adaptive integration step.",
            RuntimeWarning,
            stacklevel=3,
        )
        return self.props.state_TQ(T_sel, x_sel)

    # ------------------------------------------------------------------ #
    def flash(self, M: float, U: float) -> LH2State:
        """Resolve (M, U) at the tank's fixed volume to a full LH2State."""
        if M <= 0:
            raise TankStateError("Tank mass must be positive")
        result = self._flash_two_phase(M, U)
        if result is None:
            # Retry with a much finer bracket-search grid before giving up:
            # a state very near the critical point can have its root
            # straddled (undetected sign change) by the default coarse grid.
            result = self._flash_two_phase(M, U, n=400)
        if result is not None:
            T, x = result
            return self.props.state_TQ(T, x)
        v = self.geometry.volume_m3 / M
        env_lo = self.props.saturation_envelope_T(T_TRIPLE_K * 1.0005)
        branch_hint = "liquid" if v < 1.0 / env_lo.liquid_density_kg_m3 * 1.5 else "vapor"
        try:
            T, P = self._flash_single_phase(M, U, branch_hint)
            return self.props.state_TP(T, P)
        except (TankStateError, PropertyRangeError):
            return self._project_to_dome_boundary(M, U)

    def heat_leak(self) -> HeatLeakBudget:
        from newton_lh2.cryogenics.heat_leak import heat_leak as _heat_leak

        # Use the current cold-side (fluid) temperature as the cold boundary.
        state = self.flash(self.M, self.U)
        return _heat_leak(
            self.insulation,
            self.ambient_temperature_K,
            state.temperature_K,
            self.heat_leak_config,
            ambient_T_K=self.ambient_temperature_K,
        )

    def state(self, time_s: float = 0.0) -> TankState:
        s = self.flash(self.M, self.U)
        env = self.props.saturation_envelope_T(s.temperature_K) if s.phase != Phase.SUPERCRITICAL else None
        if s.phase.is_two_phase or s.phase in (Phase.SATURATED_LIQUID, Phase.SATURATED_VAPOR):
            x = s.quality if s.quality is not None else (0.0 if s.phase == Phase.SATURATED_LIQUID else 1.0)
            rho_L, rho_V = env.liquid_density_kg_m3, env.vapor_density_kg_m3
            m_V = x * self.M
            m_L = self.M - m_V
            vol_V = m_V / rho_V if rho_V > 0 else 0.0
            vol_L = self.geometry.volume_m3 - vol_V
        else:
            # Single phase filling the whole volume
            if s.phase.is_liquid_like:
                m_L, m_V = self.M, 0.0
                vol_L, vol_V = self.geometry.volume_m3, 0.0
                rho_L, rho_V = s.density_kg_m3, float("nan")
                x = 0.0
            else:
                m_L, m_V = 0.0, self.M
                vol_L, vol_V = 0.0, self.geometry.volume_m3
                rho_L, rho_V = float("nan"), s.density_kg_m3
                x = 1.0

        budget = self.heat_leak()
        try:
            h_fg = self.props.latent_heat(s.temperature_K)
            nbor = budget.total_W / h_fg if h_fg > 0 else float("nan")
        except PropertyRangeError:
            nbor = float("nan")

        return TankState(
            time_s=time_s,
            mass_total_kg=self.M,
            mass_liquid_kg=m_L,
            mass_vapor_kg=m_V,
            temperature_K=s.temperature_K,
            pressure_Pa=s.pressure_Pa,
            quality=x,
            phase=s.phase,
            liquid_density_kg_m3=rho_L,
            vapor_density_kg_m3=rho_V,
            liquid_volume_m3=vol_L,
            vapor_volume_m3=vol_V,
            fill_fraction=vol_L / self.geometry.volume_m3,
            liquid_level_m=self.geometry.liquid_level_m(vol_L),
            heat_leak_W=budget.total_W,
            normal_boiloff_rate_kg_s=nbor,
            internal_energy_J=self.U,
        )

    def derivative(
        self,
        Q_dot_extra_W: float = 0.0,
        m_dot_loop_kg_s: float = 0.0,
        h_loop_return_J_kg: Optional[float] = None,
        m_dot_outlet_kg_s: float = 0.0,
        m_dot_vent_kg_s: float = 0.0,
    ) -> tuple[float, float]:
        """
        Right-hand side (dM/dt, dU/dt) of the tank ODE at the current
        (self.M, self.U), given boundary mass/energy flows.

        Three physically distinct flows are supported simultaneously:

        * ``m_dot_loop_kg_s`` -- the internal recirculation loop: mass
          leaves as saturated liquid and returns at
          ``h_loop_return_J_kg`` (typically cooler, after conditioning).
          Mass-neutral on the tank (what leaves as liquid returns), but
          **not** energy-neutral -- this is the mechanism by which
          densification actively cools the tank contents.
        * ``m_dot_outlet_kg_s`` -- permanent withdrawal to the downstream
          conditioned-LH2 outlet (the facility boundary); leaves at the
          current saturated-liquid enthalpy and is not returned.
        * ``m_dot_vent_kg_s`` -- permanent withdrawal of saturated vapour
          (pressure-relief / controlled venting).

        ``Q_dot_extra_W`` is any additional net heat flow beyond the
        passive insulation heat leak (which is always included
        automatically); pass a negative value for extra active cooling
        not already captured via the loop's return enthalpy.
        """
        s = self.flash(self.M, self.U)
        env = self.props.saturation_envelope_T(s.temperature_K) if T_TRIPLE_K < s.temperature_K < T_CRIT_K else None
        h_L = env.liquid_enthalpy_J_kg if env else s.enthalpy_J_kg
        h_V = env.vapor_enthalpy_J_kg if env else s.enthalpy_J_kg

        Q_leak = self.heat_leak().total_W

        # A commanded vent rate cannot exceed what the tank can physically
        # supply from its current vapour space: venting faster than vapour
        # is actually present would drive the (M, U) state outside any
        # achievable phase. Real relief-valve flow is self-limiting in the
        # same way (choked/orifice flow tracks what's upstream); here we
        # simply cap the vent draw against the current vapour inventory
        # over a conservative 1 s response time.
        if m_dot_vent_kg_s > 0:
            if s.quality is not None:
                mass_vapor_now = s.quality * self.M
            else:
                mass_vapor_now = self.M if s.phase.is_vapor_like else 0.0
            m_dot_vent_kg_s = min(m_dot_vent_kg_s, mass_vapor_now / 1.0)

        dM_dt = -m_dot_outlet_kg_s - m_dot_vent_kg_s
        dU_dt = (
            Q_leak
            + Q_dot_extra_W
            + m_dot_loop_kg_s * ((h_loop_return_J_kg if h_loop_return_J_kg is not None else h_L) - h_L)
            - m_dot_outlet_kg_s * h_L
            - m_dot_vent_kg_s * h_V
        )
        return dM_dt, dU_dt

    def set_state(self, M: float, U: float) -> None:
        self.M, self.U = float(M), float(U)
