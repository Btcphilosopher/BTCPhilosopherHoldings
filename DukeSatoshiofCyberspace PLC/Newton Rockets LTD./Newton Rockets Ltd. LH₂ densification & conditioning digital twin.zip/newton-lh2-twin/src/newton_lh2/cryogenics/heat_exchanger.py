"""
Cryogenic conditioner / heat-exchanger model.

Throughout this module the **process stream** is the facility's LH2 loop
fluid being actively cooled, and the **coolant stream** is the (colder)
cooling medium it is exchanging heat with (e.g. a closed-loop cold-helium
or cold-hydrogen refrigerant circuit). ``duty_W`` is always reported as
the cooling duty delivered to the process stream: **positive means heat
removed from the process stream.**

Two operating modes are supported, deliberately kept distinct per the
project's "specified operating condition vs calculated physical response"
principle:

``run_specified_outlet_temperature``
    The **specified operating condition** mode: a control setpoint for
    the process-stream outlet temperature is given directly (representing
    an actively-controlled conditioner holding a setpoint). The duty
    follows from a direct real-fluid enthalpy balance -- no NTU
    approximation, no constant-cp assumption, valid even if the process
    stream partially changes phase across the unit.

``run_specified_UA``
    The **calculated physical response** mode: only the exchanger's
    overall conductance ``UA`` and both streams' inlet states/flows are
    given; the outlet temperatures and duty are *calculated* via the
    effectiveness-NTU method for a counter-current exchanger (Incropera &
    DeWitt), with stream heat capacities evaluated at inlet conditions:

        C_min = min(m_process cp_process, m_coolant cp_coolant), C_max = max(...)
        Cr = C_min / C_max,   NTU = UA / C_min
        eff = (1 - exp(-NTU(1-Cr))) / (1 - Cr exp(-NTU(1-Cr)))   [Cr < 1]
        eff = NTU / (1 + NTU)                                     [Cr = 1]
        Q = eff * C_min * (T_process_in - T_coolant_in)

    This mode assumes a small-to-moderate per-pass temperature change so a
    single inlet-evaluated cp is representative; it is not appropriate
    across a phase change on either stream (use the specified-outlet-
    temperature mode instead, or a UA per pass small enough to keep each
    call's change modest, for those cases).

Transient thermal mass (optional)
-----------------------------------
A simple first-order lag can be layered on either mode's outlet
temperature to represent the exchanger metal's own thermal capacitance
damping a step change in operating point:

    T(t+dt) = T(t) + (T_target - T(t)) * (1 - exp(-dt / tau))
"""

from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Optional

from newton_lh2.simulation.state import LH2State, ComponentState
from newton_lh2.thermodynamics.properties import HydrogenProperties, DEFAULT_PROPERTIES


@dataclass(frozen=True)
class HeatExchangerResult:
    process_inlet: LH2State
    process_outlet: LH2State
    coolant_inlet: LH2State
    coolant_outlet: LH2State
    process_mass_flow_kg_s: float
    coolant_mass_flow_kg_s: float
    duty_W: float  # positive = heat removed from the process stream
    effectiveness: Optional[float]
    UA_W_K: Optional[float]
    mode: str

    def report(self) -> str:
        eff_str = f", effectiveness = {self.effectiveness:.4f}" if self.effectiveness is not None else ""
        return (
            f"HEAT EXCHANGER [{self.mode}]\n"
            f"  Process: {self.process_inlet.temperature_K:7.3f} K -> {self.process_outlet.temperature_K:7.3f} K "
            f"@ {self.process_mass_flow_kg_s:.4f} kg/s\n"
            f"  Coolant: {self.coolant_inlet.temperature_K:7.3f} K -> {self.coolant_outlet.temperature_K:7.3f} K "
            f"@ {self.coolant_mass_flow_kg_s:.4f} kg/s\n"
            f"  Cooling duty = {self.duty_W:10.2f} W{eff_str}"
        )

    def as_component_state(self, name: str = "CONDITIONER") -> ComponentState:
        return ComponentState(
            name=name,
            inlet=self.process_inlet,
            outlet=self.process_outlet,
            mass_flow_kg_s=self.process_mass_flow_kg_s,
            pressure_drop_Pa=self.process_inlet.pressure_Pa - self.process_outlet.pressure_Pa,
            heat_transfer_W=-self.duty_W,  # heat *added to* the process stream (negative when cooling)
            power_W=0.0,
            warnings=(),
        )


def run_specified_outlet_temperature(
    process_inlet: LH2State,
    process_mass_flow_kg_s: float,
    process_outlet_temperature_K: float,
    coolant_inlet: LH2State,
    coolant_mass_flow_kg_s: float,
    process_outlet_pressure_Pa: Optional[float] = None,
    props: HydrogenProperties = None,
) -> HeatExchangerResult:
    """Specified-operating-condition mode: process-stream outlet T is a control setpoint."""
    props = props or DEFAULT_PROPERTIES
    P_out = process_outlet_pressure_Pa if process_outlet_pressure_Pa is not None else process_inlet.pressure_Pa
    process_outlet = props.state_TP(process_outlet_temperature_K, P_out)
    duty = process_mass_flow_kg_s * (process_inlet.enthalpy_J_kg - process_outlet.enthalpy_J_kg)  # >=0 when cooling

    if coolant_mass_flow_kg_s > 0:
        dh_coolant = duty / coolant_mass_flow_kg_s
        h_coolant_out = coolant_inlet.enthalpy_J_kg + dh_coolant
        coolant_outlet = props.state_PH(coolant_inlet.pressure_Pa, h_coolant_out)
    else:
        coolant_outlet = coolant_inlet

    return HeatExchangerResult(
        process_inlet=process_inlet,
        process_outlet=process_outlet,
        coolant_inlet=coolant_inlet,
        coolant_outlet=coolant_outlet,
        process_mass_flow_kg_s=process_mass_flow_kg_s,
        coolant_mass_flow_kg_s=coolant_mass_flow_kg_s,
        duty_W=duty,
        effectiveness=None,
        UA_W_K=None,
        mode="specified_outlet_temperature",
    )


def run_specified_UA(
    process_inlet: LH2State,
    process_mass_flow_kg_s: float,
    coolant_inlet: LH2State,
    coolant_mass_flow_kg_s: float,
    UA_W_K: float,
    props: HydrogenProperties = None,
) -> HeatExchangerResult:
    """Calculated-physical-response mode: effectiveness-NTU, counter-current."""
    props = props or DEFAULT_PROPERTIES
    if UA_W_K < 0:
        raise ValueError("UA_W_K must be non-negative")
    if process_inlet.temperature_K <= coolant_inlet.temperature_K:
        raise ValueError("process_inlet must be warmer than coolant_inlet for a cooling conditioner")

    cp_process = props.cp(process_inlet.temperature_K, process_inlet.pressure_Pa)
    cp_coolant = props.cp(coolant_inlet.temperature_K, coolant_inlet.pressure_Pa)
    C_process = process_mass_flow_kg_s * cp_process
    C_coolant = coolant_mass_flow_kg_s * cp_coolant

    if C_process <= 0 or C_coolant <= 0:
        return HeatExchangerResult(
            process_inlet, process_inlet, coolant_inlet, coolant_inlet,
            process_mass_flow_kg_s, coolant_mass_flow_kg_s, 0.0, 0.0, UA_W_K, "specified_UA",
        )

    C_min, C_max = min(C_process, C_coolant), max(C_process, C_coolant)
    Cr = C_min / C_max
    NTU = UA_W_K / C_min
    if Cr < 1.0 - 1e-9:
        eff = (1 - math.exp(-NTU * (1 - Cr))) / (1 - Cr * math.exp(-NTU * (1 - Cr)))
    else:
        eff = NTU / (1 + NTU)

    Q_max = C_min * (process_inlet.temperature_K - coolant_inlet.temperature_K)
    Q = eff * Q_max  # positive: heat transferred process -> coolant

    T_process_out = process_inlet.temperature_K - Q / C_process
    T_coolant_out = coolant_inlet.temperature_K + Q / C_coolant

    process_outlet = props.state_TP(T_process_out, process_inlet.pressure_Pa)
    coolant_outlet = props.state_TP(T_coolant_out, coolant_inlet.pressure_Pa)

    return HeatExchangerResult(
        process_inlet=process_inlet,
        process_outlet=process_outlet,
        coolant_inlet=coolant_inlet,
        coolant_outlet=coolant_outlet,
        process_mass_flow_kg_s=process_mass_flow_kg_s,
        coolant_mass_flow_kg_s=coolant_mass_flow_kg_s,
        duty_W=Q,
        effectiveness=eff,
        UA_W_K=UA_W_K,
        mode="specified_UA",
    )


def apply_thermal_lag(T_target_K: float, T_previous_K: float, dt_s: float, tau_s: float) -> float:
    """First-order thermal-mass lag toward a new target outlet temperature."""
    if tau_s <= 0:
        return T_target_K
    return T_previous_K + (T_target_K - T_previous_K) * (1.0 - math.exp(-dt_s / tau_s))
