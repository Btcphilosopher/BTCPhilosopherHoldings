"""
Cryogenic recirculation loop: TANK -> WITHDRAWAL -> PUMP -> CONDITIONER -> RETURN -> TANK.

Each stage is evaluated quasi-statically (steady-state component models
applied to the current instantaneous flow/state) once per simulation
timestep, consistent with the design choice documented in
:mod:`newton_lh2.simulation.solver`: the tank's thermal mass sets the
dominant (slow) system timescale, while pump/HX/piping response is fast
relative to it. Each component still exposes a full
:class:`~newton_lh2.simulation.state.ComponentState` for traceability.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional

from newton_lh2.fluid.pipe import Pipe
from newton_lh2.fluid.pressure_drop import pressure_drop
from newton_lh2.fluid.pump import PumpSpec, run_pump
from newton_lh2.cryogenics.heat_exchanger import (
    run_specified_outlet_temperature,
    run_specified_UA,
)
from newton_lh2.simulation.state import LH2State, ComponentState
from newton_lh2.thermodynamics.properties import HydrogenProperties, DEFAULT_PROPERTIES
from newton_lh2.thermodynamics.validation import PropertyRangeError


class FlowInfeasibleError(RuntimeError):
    """Raised when a requested flow rate is not achievable through the given piping/equipment."""


@dataclass(frozen=True)
class ConditionerSetpoint:
    """Operating point for the conditioner within the recirculation loop."""

    mode: str  # "specified_outlet_temperature" or "specified_UA"
    outlet_temperature_K: Optional[float] = None
    UA_W_K: Optional[float] = None
    coolant_inlet: Optional[LH2State] = None
    coolant_mass_flow_kg_s: float = 0.0

    def __post_init__(self) -> None:
        if self.mode not in ("specified_outlet_temperature", "specified_UA"):
            raise ValueError("mode must be 'specified_outlet_temperature' or 'specified_UA'")
        if self.mode == "specified_outlet_temperature" and self.outlet_temperature_K is None:
            raise ValueError("outlet_temperature_K required for specified_outlet_temperature mode")
        if self.mode == "specified_UA" and (self.UA_W_K is None or self.coolant_inlet is None):
            raise ValueError("UA_W_K and coolant_inlet required for specified_UA mode")


@dataclass(frozen=True)
class RecirculationLoopConfig:
    withdrawal_pipe: Pipe
    return_pipe: Pipe
    pump_spec: PumpSpec = field(default_factory=PumpSpec)


@dataclass(frozen=True)
class RecirculationResult:
    mass_flow_kg_s: float
    tank_offtake: ComponentState
    withdrawal_line: ComponentState
    pump: ComponentState
    conditioner: ComponentState
    return_line: ComponentState
    return_state: LH2State
    total_shaft_power_W: float
    total_cooling_duty_W: float
    net_pressure_change_Pa: float

    @property
    def components(self) -> tuple[ComponentState, ...]:
        return (self.tank_offtake, self.withdrawal_line, self.pump, self.conditioner, self.return_line)

    @property
    def warnings(self) -> tuple[str, ...]:
        out: list[str] = []
        for c in self.components:
            out.extend(c.warnings)
        return tuple(out)


def run_recirculation_loop(
    tank_liquid_state: LH2State,
    mass_flow_kg_s: float,
    config: RecirculationLoopConfig,
    conditioner_setpoint: ConditionerSetpoint,
    return_pressure_margin_Pa: float = 0.0,
    props: HydrogenProperties = None,
) -> RecirculationResult:
    """
    Advance a fixed mass flow of tank liquid once around the
    tank -> withdrawal -> pump -> conditioner -> return -> tank loop.
    """
    props = props or DEFAULT_PROPERTIES

    tank_offtake = ComponentState(
        name="TANK_OFFTAKE", inlet=tank_liquid_state, outlet=tank_liquid_state,
        mass_flow_kg_s=mass_flow_kg_s, pressure_drop_Pa=0.0, heat_transfer_W=0.0, power_W=0.0,
    )

    if mass_flow_kg_s <= 0:
        zero = ComponentState(
            "IDLE", tank_liquid_state, tank_liquid_state, 0.0, 0.0, 0.0, 0.0,
        )
        return RecirculationResult(
            0.0, tank_offtake, zero, zero, zero, zero, tank_liquid_state, 0.0, 0.0, 0.0
        )

    # -- Withdrawal line --------------------------------------------------
    mu_L = props.viscosity(tank_liquid_state.temperature_K, tank_liquid_state.pressure_Pa)
    dp_wd = pressure_drop(config.withdrawal_pipe, mass_flow_kg_s, tank_liquid_state.density_kg_m3, mu_L)
    p_pump_inlet = tank_liquid_state.pressure_Pa - dp_wd.total_Pa
    if p_pump_inlet <= 1000.0:
        raise FlowInfeasibleError(
            f"Withdrawal line pressure drop ({dp_wd.total_Pa/1e5:.3f} bar) at {mass_flow_kg_s:.4f} kg/s "
            f"leaves only {p_pump_inlet/1e5:.3f} bar at the pump inlet -- the withdrawal pipe "
            f"(ID={config.withdrawal_pipe.inner_diameter_m*1e3:.1f} mm) is undersized for this flow rate, "
            "or the requested mass flow is not achievable. Increase pipe diameter or reduce flow."
        )
    try:
        pump_inlet_state = props.state_PH(p_pump_inlet, tank_liquid_state.enthalpy_J_kg)
    except PropertyRangeError as exc:
        raise FlowInfeasibleError(f"Withdrawal line outlet state is non-physical: {exc}") from exc
    withdrawal_line = ComponentState(
        "WITHDRAWAL_LINE", tank_liquid_state, pump_inlet_state, mass_flow_kg_s,
        dp_wd.total_Pa, 0.0, 0.0,
    )

    # -- Pump ---------------------------------------------------------------
    # Pump discharge pressure: enough to overcome the return line's expected
    # drop plus a margin, referenced to the tank pressure it must return against.
    mu_ret_guess = mu_L
    dp_ret_guess = pressure_drop(config.return_pipe, mass_flow_kg_s, tank_liquid_state.density_kg_m3, mu_ret_guess)
    p_discharge = tank_liquid_state.pressure_Pa + dp_ret_guess.total_Pa + return_pressure_margin_Pa
    p_discharge = max(p_discharge, pump_inlet_state.pressure_Pa + 1.0)
    pump_result = run_pump(pump_inlet_state, p_discharge, mass_flow_kg_s, config.pump_spec, props=props)
    pump_component = pump_result.as_component_state("PUMP")

    # -- Conditioner ----------------------------------------------------------
    if conditioner_setpoint.mode == "specified_outlet_temperature":
        hx = run_specified_outlet_temperature(
            pump_result.outlet, mass_flow_kg_s, conditioner_setpoint.outlet_temperature_K,
            conditioner_setpoint.coolant_inlet or pump_result.outlet,
            conditioner_setpoint.coolant_mass_flow_kg_s, props=props,
        )
    else:
        hx = run_specified_UA(
            pump_result.outlet, mass_flow_kg_s,
            conditioner_setpoint.coolant_inlet, conditioner_setpoint.coolant_mass_flow_kg_s,
            conditioner_setpoint.UA_W_K, props=props,
        )
    conditioner_component = hx.as_component_state("CONDITIONER")

    # -- Return line ----------------------------------------------------------
    mu_cooled = props.viscosity(hx.process_outlet.temperature_K, hx.process_outlet.pressure_Pa)
    dp_return = pressure_drop(config.return_pipe, mass_flow_kg_s, hx.process_outlet.density_kg_m3, mu_cooled)
    p_return_to_tank = hx.process_outlet.pressure_Pa - dp_return.total_Pa
    if p_return_to_tank <= 1000.0:
        raise FlowInfeasibleError(
            f"Return line pressure drop ({dp_return.total_Pa/1e5:.3f} bar) at {mass_flow_kg_s:.4f} kg/s "
            f"leaves only {p_return_to_tank/1e5:.3f} bar -- increase pump discharge pressure margin, "
            f"increase return pipe diameter (ID={config.return_pipe.inner_diameter_m*1e3:.1f} mm), or reduce flow."
        )
    return_state = props.state_PH(p_return_to_tank, hx.process_outlet.enthalpy_J_kg)
    return_line = ComponentState(
        "RETURN_LINE", hx.process_outlet, return_state, mass_flow_kg_s, dp_return.total_Pa, 0.0, 0.0,
    )

    return RecirculationResult(
        mass_flow_kg_s=mass_flow_kg_s,
        tank_offtake=tank_offtake,
        withdrawal_line=withdrawal_line,
        pump=pump_component,
        conditioner=conditioner_component,
        return_line=return_line,
        return_state=return_state,
        total_shaft_power_W=pump_result.shaft_power_W,
        total_cooling_duty_W=hx.duty_W,
        net_pressure_change_Pa=return_state.pressure_Pa - tank_liquid_state.pressure_Pa,
    )
