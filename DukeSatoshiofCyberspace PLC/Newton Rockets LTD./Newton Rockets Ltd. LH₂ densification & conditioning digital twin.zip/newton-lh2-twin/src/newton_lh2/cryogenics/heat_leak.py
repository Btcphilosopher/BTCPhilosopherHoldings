"""
Heat-leak model for a cryogenic LH2 tank.

Computes the total parasitic heat ingress into the tank contents as a sum
of independently-toggleable contributions:

    Q_dot_total = Q_cond + Q_rad + Q_penetrations + Q_piping + Q_instrumentation + Q_environmental

Conduction
    Fourier's law through the bulk insulation thickness, using the
    insulation system's apparent conductivity (see
    :mod:`newton_lh2.cryogenics.insulation`):

        Q_cond = k_eff * A / L * (T_warm - T_cold)

Radiation
    Multi-layer-insulation modelled as N floating radiation shields
    between two boundary surfaces of matched emissivity (Incropera &
    DeWitt, "Fundamentals of Heat and Mass Transfer", radiation shield
    network result for N identical shields):

        Q_rad,0 = sigma * A * (T_warm^4 - T_cold^4) / (2/eps - 1)
        Q_rad   = Q_rad,0 / (N + 1)

    which reduces to plain two-surface radiation when N = 0.

Penetrations / piping / instrumentation
    Modelled as lumped lands: a conductance UA_i (W/K) driven by the same
    (T_warm - T_cold), representing structural supports, fill/vent/relief
    piping, and instrumentation leads bridging the insulation boundary.

Environmental coupling
    An optional simplified convective term from an exposed outer surface
    to ambient air, for equipment that is not fully vacuum-jacketed.
"""

from __future__ import annotations

from dataclasses import dataclass, field

from newton_lh2.cryogenics.insulation import InsulationSystem

SIGMA_SB = 5.670374419e-8  # Stefan-Boltzmann constant, W/(m^2 K^4)


@dataclass(frozen=True)
class HeatLeakConfig:
    """Toggle flags and lumped conductances for each heat-leak contribution."""

    enable_conduction: bool = True
    enable_radiation: bool = True
    enable_penetrations: bool = True
    enable_piping: bool = True
    enable_instrumentation: bool = True
    enable_environmental: bool = False

    penetration_conductance_W_K: float = 0.05
    piping_conductance_W_K: float = 0.08
    instrumentation_conductance_W_K: float = 0.01
    environmental_htc_W_m2K: float = 5.0
    environmental_area_m2: float = 0.0


@dataclass(frozen=True)
class HeatLeakBudget:
    """Itemised heat-leak result, W, at one operating point."""

    conduction_W: float
    radiation_W: float
    penetrations_W: float
    piping_W: float
    instrumentation_W: float
    environmental_W: float

    @property
    def total_W(self) -> float:
        return (
            self.conduction_W
            + self.radiation_W
            + self.penetrations_W
            + self.piping_W
            + self.instrumentation_W
            + self.environmental_W
        )

    def report(self) -> str:
        lines = [
            "HEAT LEAK BUDGET",
            "-" * 40,
            f"  Conduction        {self.conduction_W:10.4f} W",
            f"  Radiation (MLI)   {self.radiation_W:10.4f} W",
            f"  Penetrations      {self.penetrations_W:10.4f} W",
            f"  Piping            {self.piping_W:10.4f} W",
            f"  Instrumentation   {self.instrumentation_W:10.4f} W",
            f"  Environmental     {self.environmental_W:10.4f} W",
            "-" * 40,
            f"  TOTAL             {self.total_W:10.4f} W",
        ]
        return "\n".join(lines)


def heat_leak(
    insulation: InsulationSystem,
    T_warm_K: float,
    T_cold_K: float,
    config: HeatLeakConfig = HeatLeakConfig(),
    ambient_T_K: float | None = None,
) -> HeatLeakBudget:
    """
    Compute the itemised heat-leak budget into a cryogenic vessel.

    Parameters
    ----------
    insulation : InsulationSystem
        Insulation performance characterisation.
    T_warm_K, T_cold_K : float
        Outer (warm, typically ~ambient at the vacuum jacket) and inner
        (cold, cryogen-side) boundary temperatures of the conduction/
        radiation path.
    config : HeatLeakConfig
        Which contributions are active, and lumped conductances for the
        penetration/piping/instrumentation/environmental terms.
    ambient_T_K : float, optional
        Ambient air temperature for the environmental term; defaults to
        ``T_warm_K`` if not given.
    """
    if T_warm_K < T_cold_K:
        raise ValueError(f"T_warm_K ({T_warm_K}) must be >= T_cold_K ({T_cold_K})")

    dT = T_warm_K - T_cold_K

    q_cond = 0.0
    if config.enable_conduction:
        q_cond = insulation.apparent_conductivity_W_mK * insulation.area_m2 / insulation.thickness_m * dT

    q_rad = 0.0
    if config.enable_radiation:
        eps = insulation.layer_emissivity
        q_rad0 = SIGMA_SB * insulation.area_m2 * (T_warm_K**4 - T_cold_K**4) / (2.0 / eps - 1.0)
        q_rad = q_rad0 / (insulation.layer_count + 1)

    q_pen = config.penetration_conductance_W_K * dT if config.enable_penetrations else 0.0
    q_pipe = config.piping_conductance_W_K * dT if config.enable_piping else 0.0
    q_instr = config.instrumentation_conductance_W_K * dT if config.enable_instrumentation else 0.0

    q_env = 0.0
    if config.enable_environmental and config.environmental_area_m2 > 0:
        T_amb = ambient_T_K if ambient_T_K is not None else T_warm_K
        q_env = config.environmental_htc_W_m2K * config.environmental_area_m2 * (T_amb - T_cold_K)

    return HeatLeakBudget(q_cond, q_rad, q_pen, q_pipe, q_instr, q_env)
