"""
Insulation-system parameters for the cryogenic tank and piping.

The facility's insulation performance is treated as a *characterised
input parameter set* (as it would be in practice -- apparent conductivity
and layer emissivity of a specific MLI blanket are measured/vendor-quoted
quantities, not universal physical constants), not something the engine
invents. The factory constructors below provide representative starting
values commonly cited in cryogenic-engineering practice for multi-layer
insulation (MLI) and closed-cell foam, clearly labelled as such.
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class InsulationSystem:
    """
    Thermal-performance characterisation of a tank's (or pipe run's)
    insulation system.

    Attributes
    ----------
    area_m2 : float
        Heat-transfer area across the insulation (outer tank/pipe surface).
    thickness_m : float
        Insulation thickness in the conduction path.
    apparent_conductivity_W_mK : float
        Effective ("apparent") thermal conductivity of the insulation
        system as installed, including seams, penetrations local effects
        smeared into an average value. For good 30-80 layer MLI in hard
        vacuum this is typically of order 1e-5 to 5e-5 W/(m K); for
        closed-cell foam typically 0.01-0.03 W/(m K). These are
        representative starting points, not measured facility data.
    layer_count : int
        Number of radiation shields (MLI layers), 0 for non-MLI insulation.
    layer_emissivity : float
        Effective emissivity of each radiation shield / boundary surface
        (aluminized Mylar/polyester is typically ~0.02-0.05).
    """

    area_m2: float
    thickness_m: float
    apparent_conductivity_W_mK: float
    layer_count: int = 0
    layer_emissivity: float = 0.03

    def __post_init__(self) -> None:
        if self.area_m2 <= 0:
            raise ValueError("area_m2 must be positive")
        if self.thickness_m <= 0:
            raise ValueError("thickness_m must be positive")
        if self.apparent_conductivity_W_mK <= 0:
            raise ValueError("apparent_conductivity_W_mK must be positive")
        if self.layer_count < 0:
            raise ValueError("layer_count must be >= 0")
        if not (0.0 < self.layer_emissivity <= 1.0):
            raise ValueError("layer_emissivity must be in (0, 1]")

    @classmethod
    def mli_vacuum_jacket(
        cls,
        area_m2: float,
        thickness_m: float = 0.025,
        layer_count: int = 60,
        layer_emissivity: float = 0.03,
        apparent_conductivity_W_mK: float = 3.0e-5,
    ) -> "InsulationSystem":
        """Representative high-performance MLI / hard-vacuum jacket."""
        return cls(area_m2, thickness_m, apparent_conductivity_W_mK, layer_count, layer_emissivity)

    @classmethod
    def foam_insulation(
        cls,
        area_m2: float,
        thickness_m: float = 0.05,
        apparent_conductivity_W_mK: float = 0.02,
    ) -> "InsulationSystem":
        """Representative closed-cell foam insulation (no radiation shielding)."""
        return cls(area_m2, thickness_m, apparent_conductivity_W_mK, layer_count=0, layer_emissivity=1.0)

    @classmethod
    def degraded(cls, base: "InsulationSystem", vacuum_loss_factor: float = 10.0) -> "InsulationSystem":
        """
        Represent a vacuum-jacket degradation event (e.g. partial vacuum
        loss) by scaling apparent conductivity up, as commonly observed
        when MLI performance collapses toward a soft-vacuum/backfilled
        gas-conduction regime.
        """
        if vacuum_loss_factor <= 0:
            raise ValueError("vacuum_loss_factor must be positive")
        return cls(
            base.area_m2,
            base.thickness_m,
            base.apparent_conductivity_W_mK * vacuum_loss_factor,
            base.layer_count,
            base.layer_emissivity,
        )
