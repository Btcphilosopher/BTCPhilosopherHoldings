"""
Generic cryogenic pump model.

This deliberately does **not** model a particular commercial pump's head
curve or impeller geometry -- it is a thermodynamically consistent,
efficiency-based model suitable for a generic centrifugal or positive-
displacement cryogenic transfer pump in a recirculation loop:

    hydraulic_power = mass_flow * (P_out - P_in) / rho_in      (incompressible approx.)
    shaft_power     = hydraulic_power / efficiency
    dh_actual       = shaft_power / mass_flow                  (all inefficiency -> fluid enthalpy)
    outlet state    = state_PH(P_out, h_in + dh_actual)         (real-fluid flash -> actual T rise)

Routing the actual enthalpy rise back through the primary property engine
(rather than an ad hoc "temperature rise" formula) keeps the pump's
outlet state fully consistent with the rest of the digital twin, and
correctly captures that a real cryogenic liquid's temperature rise for a
given enthalpy addition depends on its local specific heat.
"""

from __future__ import annotations

from dataclasses import dataclass

from newton_lh2.fluid.cavitation import cavitation_check, CavitationDiagnostic
from newton_lh2.thermodynamics.properties import HydrogenProperties, DEFAULT_PROPERTIES
from newton_lh2.simulation.state import LH2State, ComponentState


@dataclass(frozen=True)
class PumpSpec:
    """Generic pump characteristic parameters."""

    efficiency: float = 0.65  # isentropic/hydraulic efficiency, representative for a small cryo centrifugal pump
    npsh_required_m: float = 1.0
    inlet_pipe_area_m2: float = 7.85e-4  # ~ DN32 bore, used only for the inlet velocity head in NPSH
    subcooling_safety_margin_K: float = 0.5

    def __post_init__(self) -> None:
        if not (0.0 < self.efficiency <= 1.0):
            raise ValueError("efficiency must be in (0, 1]")
        if self.npsh_required_m < 0:
            raise ValueError("npsh_required_m must be non-negative")


@dataclass(frozen=True)
class PumpResult:
    inlet: LH2State
    outlet: LH2State
    mass_flow_kg_s: float
    pressure_rise_Pa: float
    temperature_rise_K: float
    hydraulic_power_W: float
    shaft_power_W: float
    losses_W: float
    cavitation: CavitationDiagnostic

    @property
    def warnings(self) -> tuple[str, ...]:
        return self.cavitation.warnings

    def as_component_state(self, name: str = "PUMP") -> ComponentState:
        return ComponentState(
            name=name,
            inlet=self.inlet,
            outlet=self.outlet,
            mass_flow_kg_s=self.mass_flow_kg_s,
            pressure_drop_Pa=-self.pressure_rise_Pa,
            heat_transfer_W=0.0,
            power_W=self.shaft_power_W,
            warnings=self.warnings,
        )


def run_pump(
    inlet_state: LH2State,
    outlet_pressure_Pa: float,
    mass_flow_kg_s: float,
    spec: PumpSpec = PumpSpec(),
    props: HydrogenProperties = None,
) -> PumpResult:
    props = props or DEFAULT_PROPERTIES
    if mass_flow_kg_s < 0:
        raise ValueError("mass_flow_kg_s must be non-negative")
    if outlet_pressure_Pa < inlet_state.pressure_Pa:
        raise ValueError("Pump outlet pressure must be >= inlet pressure")

    dP = outlet_pressure_Pa - inlet_state.pressure_Pa
    rho_in = inlet_state.density_kg_m3
    hydraulic_power = mass_flow_kg_s * dP / rho_in
    shaft_power = hydraulic_power / spec.efficiency
    losses = shaft_power - hydraulic_power

    if mass_flow_kg_s > 0:
        dh_actual = shaft_power / mass_flow_kg_s
        h_out = inlet_state.enthalpy_J_kg + dh_actual
        outlet = props.state_PH(outlet_pressure_Pa, h_out)
    else:
        outlet = props.state_TP(inlet_state.temperature_K, outlet_pressure_Pa)

    v_inlet = mass_flow_kg_s / (rho_in * spec.inlet_pipe_area_m2) if mass_flow_kg_s > 0 else 0.0
    cav = cavitation_check(
        inlet_state.temperature_K,
        inlet_state.pressure_Pa,
        v_inlet,
        spec.npsh_required_m,
        spec.subcooling_safety_margin_K,
        props=props,
    )

    return PumpResult(
        inlet=inlet_state,
        outlet=outlet,
        mass_flow_kg_s=mass_flow_kg_s,
        pressure_rise_Pa=dP,
        temperature_rise_K=outlet.temperature_K - inlet_state.temperature_K,
        hydraulic_power_W=hydraulic_power,
        shaft_power_W=shaft_power,
        losses_W=losses,
        cavitation=cav,
    )
