"""Piping geometry for the recirculation loop."""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np


@dataclass(frozen=True)
class Pipe:
    """Straight-run pipe segment geometry."""

    length_m: float
    inner_diameter_m: float
    roughness_m: float = 1.5e-6  # representative drawn stainless tube roughness
    elevation_change_m: float = 0.0  # outlet - inlet, positive = uphill
    minor_loss_K: float = 0.0  # sum of local loss coefficients (bends, fittings, valves)

    def __post_init__(self) -> None:
        if self.length_m <= 0:
            raise ValueError("length_m must be positive")
        if self.inner_diameter_m <= 0:
            raise ValueError("inner_diameter_m must be positive")
        if self.roughness_m < 0:
            raise ValueError("roughness_m must be non-negative")
        if self.minor_loss_K < 0:
            raise ValueError("minor_loss_K must be non-negative")

    @property
    def cross_section_area_m2(self) -> float:
        return np.pi * self.inner_diameter_m**2 / 4.0

    def velocity_m_s(self, mass_flow_kg_s: float, density_kg_m3: float) -> float:
        return mass_flow_kg_s / (density_kg_m3 * self.cross_section_area_m2)

    @property
    def relative_roughness(self) -> float:
        return self.roughness_m / self.inner_diameter_m
