"""
Cavitation / pump-inlet-margin diagnostics for cryogenic service.

Two complementary figures of merit are provided:

NPSH (Net Positive Suction Head)
    The classical pump-industry margin, in metres of fluid column:

        NPSH_available = (P_inlet - P_vapor(T_inlet)) / (rho_inlet * g) + v_inlet^2 / (2g)

    compared against a pump-specific NPSH_required.

Subcooling margin
    For cryogens, engineers commonly reason directly in temperature
    margin below the local saturation temperature, since LH2 systems
    routinely operate within a few kelvin of their vapour pressure and a
    length-based NPSH figure can obscure how thin that margin really is:

        subcooling_margin_K = T_sat(P_inlet) - T_inlet

Both are reported; a cavitation risk warning is raised if either margin
is non-positive or below a configurable safety threshold.
"""

from __future__ import annotations

from dataclasses import dataclass

from newton_lh2.thermodynamics.properties import HydrogenProperties, DEFAULT_PROPERTIES, G_STANDARD_M_S2


@dataclass(frozen=True)
class CavitationDiagnostic:
    npsh_available_m: float
    npsh_required_m: float
    npsh_margin_m: float
    subcooling_margin_K: float
    at_risk: bool
    warnings: tuple[str, ...]


def cavitation_check(
    inlet_temperature_K: float,
    inlet_pressure_Pa: float,
    inlet_velocity_m_s: float,
    npsh_required_m: float,
    subcooling_safety_margin_K: float = 0.5,
    props: HydrogenProperties = None,
) -> CavitationDiagnostic:
    props = props or DEFAULT_PROPERTIES
    rho = props.density(inlet_temperature_K, inlet_pressure_Pa)
    p_vap = props.saturation_pressure(min(inlet_temperature_K, props.T_crit_K * 0.999999))
    npsh_avail = max(inlet_pressure_Pa - p_vap, 0.0) / (rho * G_STANDARD_M_S2) + inlet_velocity_m_s**2 / (
        2.0 * G_STANDARD_M_S2
    )
    npsh_margin = npsh_avail - npsh_required_m
    subcool = props.subcooling_K(inlet_temperature_K, inlet_pressure_Pa)

    warnings = []
    at_risk = False
    if npsh_margin <= 0:
        warnings.append(f"NPSH margin non-positive ({npsh_margin:.4f} m): cavitation likely.")
        at_risk = True
    if subcool <= 0:
        warnings.append(f"Pump inlet is at/above saturation (subcooling {subcool:.4f} K): flashing likely.")
        at_risk = True
    elif subcool < subcooling_safety_margin_K:
        warnings.append(
            f"Pump inlet subcooling margin {subcool:.4f} K below safety threshold "
            f"{subcooling_safety_margin_K:.4f} K."
        )
        at_risk = True

    return CavitationDiagnostic(npsh_avail, npsh_required_m, npsh_margin, subcool, at_risk, tuple(warnings))
