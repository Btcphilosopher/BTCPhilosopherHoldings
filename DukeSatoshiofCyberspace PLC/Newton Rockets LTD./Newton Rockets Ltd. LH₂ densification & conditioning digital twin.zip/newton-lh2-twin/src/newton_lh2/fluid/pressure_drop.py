"""
Single-phase (and simplified homogeneous two-phase) pressure-drop model
for piping in the recirculation loop.

Friction factor
----------------
Darcy friction factor via the Colebrook-White implicit correlation,
solved with a bracketed root-find; falls back to the laminar result
``f = 64/Re`` below Re = 2300, with a simple linear blend across the
2300-4000 transitional band (standard engineering practice absent a
pipe-specific transition correlation).

Total pressure drop
--------------------
    dP = dP_friction + dP_minor + dP_elevation

    dP_friction = f * (L/D) * (rho v^2 / 2)
    dP_minor    = K_total * (rho v^2 / 2)
    dP_elevation = rho * g * dz

Two-phase (optional)
----------------------
A homogeneous-equilibrium-model (HEM) multiplier is applied when a vapour
quality is supplied: the mixture is treated as a single fluid with
quality-weighted density and viscosity, which is the simplest defensible
two-phase pressure-drop approximation and is adequate for the low-quality
conditions expected in a densification/subcooling loop. This is *not* a
substitute for a Lockhart-Martinelli or Friedel correlation in a
detailed two-phase piping design.
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np
from scipy.optimize import brentq

from newton_lh2.fluid.pipe import Pipe

G_STANDARD = 9.80665


@dataclass(frozen=True)
class PressureDropResult:
    friction_Pa: float
    minor_losses_Pa: float
    elevation_Pa: float
    velocity_m_s: float
    reynolds_number: float
    friction_factor: float
    flow_regime: str

    @property
    def total_Pa(self) -> float:
        return self.friction_Pa + self.minor_losses_Pa + self.elevation_Pa


def darcy_friction_factor(reynolds_number: float, relative_roughness: float) -> tuple[float, str]:
    """Darcy friction factor and flow-regime label."""
    Re = reynolds_number
    if Re <= 0:
        return 0.0, "stagnant"
    if Re < 2300:
        return 64.0 / Re, "laminar"

    def colebrook(f):
        return 1.0 / np.sqrt(f) + 2.0 * np.log10(relative_roughness / 3.7 + 2.51 / (Re * np.sqrt(f)))

    f_turb = brentq(colebrook, 1e-5, 1.0, xtol=1e-12)
    if Re <= 4000:
        f_lam = 64.0 / Re
        w = (Re - 2300.0) / (4000.0 - 2300.0)
        return (1 - w) * f_lam + w * f_turb, "transitional"
    return f_turb, "turbulent"


def pressure_drop(
    pipe: Pipe,
    mass_flow_kg_s: float,
    density_kg_m3: float,
    viscosity_Pa_s: float,
) -> PressureDropResult:
    """Single-phase pressure drop along ``pipe`` for the given flow and fluid properties."""
    if mass_flow_kg_s == 0:
        return PressureDropResult(0.0, 0.0, density_kg_m3 * G_STANDARD * pipe.elevation_change_m, 0.0, 0.0, 0.0, "stagnant")

    v = pipe.velocity_m_s(abs(mass_flow_kg_s), density_kg_m3)
    Re = density_kg_m3 * v * pipe.inner_diameter_m / viscosity_Pa_s
    f, regime = darcy_friction_factor(Re, pipe.relative_roughness)

    dynamic_pressure = 0.5 * density_kg_m3 * v**2
    dP_friction = f * (pipe.length_m / pipe.inner_diameter_m) * dynamic_pressure
    dP_minor = pipe.minor_loss_K * dynamic_pressure
    dP_elevation = density_kg_m3 * G_STANDARD * pipe.elevation_change_m

    sign = 1.0 if mass_flow_kg_s > 0 else -1.0
    return PressureDropResult(
        friction_Pa=sign * dP_friction,
        minor_losses_Pa=sign * dP_minor,
        elevation_Pa=dP_elevation,
        velocity_m_s=sign * v,
        reynolds_number=Re,
        friction_factor=f,
        flow_regime=regime,
    )


def homogeneous_two_phase_pressure_drop(
    pipe: Pipe,
    mass_flow_kg_s: float,
    quality: float,
    liquid_density_kg_m3: float,
    vapor_density_kg_m3: float,
    liquid_viscosity_Pa_s: float,
    vapor_viscosity_Pa_s: float,
) -> PressureDropResult:
    """Homogeneous-equilibrium-model two-phase pressure drop (see module docstring)."""
    if not (0.0 <= quality <= 1.0):
        raise ValueError("quality must be in [0, 1]")
    rho_mix_inv = quality / vapor_density_kg_m3 + (1 - quality) / liquid_density_kg_m3
    rho_mix = 1.0 / rho_mix_inv
    mu_mix = quality * vapor_viscosity_Pa_s + (1 - quality) * liquid_viscosity_Pa_s  # McAdams-style linear blend
    return pressure_drop(pipe, mass_flow_kg_s, rho_mix, mu_mix)
