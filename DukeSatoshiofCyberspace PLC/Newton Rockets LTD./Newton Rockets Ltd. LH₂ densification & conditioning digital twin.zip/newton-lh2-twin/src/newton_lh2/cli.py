"""
Command-line interface for the Newton Rockets LH2 digital twin.

RESEARCH / ENGINEERING SIMULATION -- NOT FLIGHT-CERTIFIED.

Examples
--------
    newton-lh2 simulate --tank-volume 100 --initial-temperature 19.5 --duration 3600
    newton-lh2 scenario densification
    newton-lh2 sensitivity --parameter vacuum_loss_factor --values 1,5,10,20
    newton-lh2 monte-carlo --n 5000
    newton-lh2 validate
    newton-lh2 generate-telemetry --scenario recirculation --output telemetry.parquet
    newton-lh2 replay telemetry.parquet
"""

from __future__ import annotations

import argparse
import sys

import numpy as np

from newton_lh2 import __disclaimer__, __version__


def _save_dataframe(df, path: str) -> None:
    if path.endswith(".parquet"):
        try:
            df.to_parquet(path, index=False)
            return
        except Exception:
            path = path.rsplit(".", 1)[0] + ".csv"
    if path.endswith(".json"):
        df.to_json(path, orient="records", indent=2)
    else:
        df.to_csv(path, index=False)
    print(f"Wrote {path}")


def cmd_simulate(args: argparse.Namespace) -> int:
    from newton_lh2.cryogenics.tank import CryoTank, TankGeometry
    from newton_lh2.cryogenics.insulation import InsulationSystem
    from newton_lh2.cryogenics.recirculation import RecirculationLoopConfig, ConditionerSetpoint
    from newton_lh2.fluid.pipe import Pipe
    from newton_lh2.fluid.pump import PumpSpec
    from newton_lh2.models.process_train import ProcessTrain, ProcessTrainConfig
    from newton_lh2.models.facility import NewtonLH2Facility, BoundaryConditions, FacilityLimits
    from newton_lh2.simulation.solver import LH2Simulation
    from newton_lh2.thermodynamics.properties import DEFAULT_PROPERTIES as hp

    ins = InsulationSystem.mli_vacuum_jacket(area_m2=args.tank_volume * 0.9)
    tank = CryoTank(
        TankGeometry(volume_m3=args.tank_volume, diameter_m=args.diameter),
        ins,
        ambient_temperature_K=args.ambient,
        initial_mass_kg=args.initial_mass,
        initial_temperature_K=args.initial_temperature,
    )
    recirc_cfg = RecirculationLoopConfig(
        withdrawal_pipe=Pipe(length_m=15.0, inner_diameter_m=0.05, minor_loss_K=2.0),
        return_pipe=Pipe(length_m=18.0, inner_diameter_m=0.05, minor_loss_K=3.0),
        pump_spec=PumpSpec(efficiency=0.62, npsh_required_m=0.3, subcooling_safety_margin_K=0.2),
    )
    setpoint = ConditionerSetpoint(
        mode="specified_outlet_temperature",
        outlet_temperature_K=args.coolant_temperature + 3.0,
        coolant_inlet=hp.state_TP(args.coolant_temperature, 1.5e5),
        coolant_mass_flow_kg_s=0.6,
    )
    pt = ProcessTrain(ProcessTrainConfig(recirc_cfg, setpoint, nominal_mass_flow_kg_s=0.0))
    facility = NewtonLH2Facility(tank, pt, limits=FacilityLimits(max_pressure_Pa=args.pressure))

    initial_state = facility.tank.state()
    print(f"Initial operating pressure (saturated at {args.initial_temperature:.3f} K): "
          f"{initial_state.pressure_Pa/1e5:.4f} bar")
    print(f"Relief/alarm pressure threshold: {args.pressure/1e5:.4f} bar")

    def bc_fn(t, control):
        return BoundaryConditions(recirculation_mass_flow_kg_s=args.mass_flow)

    sim = LH2Simulation(facility, bc_fn, duration_s=args.duration, timestep_s=args.timestep, diagnostic_stride=1)
    result = sim.run()
    print(result.summary())
    if args.output:
        _save_dataframe(result.diagnostics, args.output)
    return 0 if (result.conservation.mass_pass and result.conservation.energy_pass) else 1


def cmd_scenario(args: argparse.Namespace) -> int:
    from newton_lh2.simulation.scenarios import SCENARIOS

    aliases = {"cooldown": "warm-tank"}
    name = aliases.get(args.name, args.name)
    if name not in SCENARIOS:
        print(f"Unknown scenario {args.name!r}. Choose from: {list(SCENARIOS) + list(aliases)}", file=sys.stderr)
        return 2
    run = SCENARIOS[name]()
    print(f"SCENARIO {run.name}\n  {run.description}\n")
    print(run.result.summary())
    if args.output:
        _save_dataframe(run.result.diagnostics, args.output)
    return 0 if (run.result.conservation.mass_pass and run.result.conservation.energy_pass) else 1


def cmd_sensitivity(args: argparse.Namespace) -> int:
    from newton_lh2.analysis.sensitivity import run_parameter_sweep, SWEEPABLE_PARAMETERS

    if args.parameter not in SWEEPABLE_PARAMETERS:
        print(f"parameter must be one of: {SWEEPABLE_PARAMETERS}", file=sys.stderr)
        return 2
    values = [float(v) for v in args.values.split(",")]
    df = run_parameter_sweep(args.parameter, values, duration_s=args.duration, timestep_s=args.timestep)
    print(df.to_string(index=False))
    if args.output:
        _save_dataframe(df, args.output)
    return 0


def cmd_monte_carlo(args: argparse.Namespace) -> int:
    from newton_lh2.analysis.uncertainty import monte_carlo, normal, lognormal_relative, heat_leak_response

    dists = {
        "apparent_conductivity_W_mK": lognormal_relative(3.0e-5, 0.25),
        "layer_emissivity": lognormal_relative(0.03, 0.20),
        "ambient_temperature_K": normal(293.15, 3.0),
        "liquid_temperature_K": normal(20.0, 0.3),
    }
    result = monte_carlo(dists, heat_leak_response(), n=args.n, seed=args.seed)
    print(result.report("total tank heat leak, W"))
    if args.output:
        import pandas as pd

        _save_dataframe(pd.DataFrame({"heat_leak_W": result.samples}), args.output)
    return 0


def cmd_validate(args: argparse.Namespace) -> int:
    from newton_lh2.thermodynamics.properties import DEFAULT_PROPERTIES as hp
    from newton_lh2.simulation.scenarios import scenario_e_recirculation

    print(f"newton-lh2 {__version__} -- {__disclaimer__}\n")
    print("VALIDATION CHECKS")
    print("-" * 50)
    ok = True

    # 1. Round-trip property flash consistency
    s = hp.state_TP(18.0, 1.3e5)
    s2 = hp.state_PH(1.3e5, s.enthalpy_J_kg)
    dT = abs(s.temperature_K - s2.temperature_K)
    check1 = dT < 1e-4
    ok &= check1
    print(f"  PROPERTY ROUND-TRIP (T-P -> P-H -> T)   {'PASS' if check1 else 'FAIL'}  (dT={dT:.2e} K)")

    # 2. Saturation envelope self-consistency (latent heat = hV - hL)
    env = hp.saturation_envelope_T(20.0)
    check2 = env.latent_heat_J_kg > 0
    ok &= check2
    print(f"  SATURATION ENVELOPE (hfg > 0 at 20 K)   {'PASS' if check2 else 'FAIL'}  (hfg={env.latent_heat_J_kg:.1f} J/kg)")

    # 3. A short simulation's own conservation diagnostics
    run = scenario_e_recirculation(duration_s=400.0, timestep_s=10.0)
    check3 = run.result.conservation.mass_pass
    check4 = run.result.conservation.energy_pass
    ok &= check3 & check4
    print(f"  MASS BALANCE (scenario E, 400 s)        {'PASS' if check3 else 'FAIL'}")
    print(f"  ENERGY BALANCE (scenario E, 400 s)       {'PASS' if check4 else 'FAIL'}")
    print("-" * 50)
    print("OVERALL: " + ("PASS" if ok else "FAIL"))
    return 0 if ok else 1


def cmd_generate_telemetry(args: argparse.Namespace) -> int:
    from newton_lh2.simulation.scenarios import SCENARIOS
    from newton_lh2.models.telemetry import generate_telemetry, save_telemetry

    if args.scenario not in SCENARIOS:
        print(f"Unknown scenario {args.scenario!r}. Choose from: {list(SCENARIOS)}", file=sys.stderr)
        return 2
    run = SCENARIOS[args.scenario]()
    tel = generate_telemetry(run.result.diagnostics, seed=args.seed)
    save_telemetry(tel, args.output)
    print(f"Wrote synthetic telemetry ({len(tel)} rows) from scenario {args.scenario!r} to {args.output}")
    return 0


def cmd_replay(args: argparse.Namespace) -> int:
    from newton_lh2.models.telemetry import load_telemetry, replay_telemetry
    from newton_lh2.simulation.scenarios import _standard_facility
    from newton_lh2.cryogenics.recirculation import ConditionerSetpoint
    from newton_lh2.thermodynamics.properties import DEFAULT_PROPERTIES as hp

    df = load_telemetry(args.telemetry_file)
    facility = _standard_facility(initial_temperature_K=args.initial_temperature)
    setpoint = ConditionerSetpoint(
        mode="specified_outlet_temperature", outlet_temperature_K=17.0,
        coolant_inlet=hp.state_TP(14.0, 1.5e5), coolant_mass_flow_kg_s=0.6,
    )
    result = replay_telemetry(df, facility, setpoint, timestep_s=args.timestep)
    print(f"Replayed {len(df)} telemetry rows from {args.telemetry_file}\n")
    print(result.summary())
    if args.output:
        _save_dataframe(result.diagnostics, args.output)
    return 0 if (result.conservation.mass_pass and result.conservation.energy_pass) else 1


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="newton-lh2",
        description=__doc__,
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    p.add_argument("--version", action="version", version=f"newton-lh2 {__version__}")
    sub = p.add_subparsers(dest="command", required=True)

    ps = sub.add_parser("simulate", help="Run a free-form transient simulation. SI units throughout.")
    ps.add_argument("--tank-volume", type=float, default=100.0, help="Tank volume, m^3 (default 100)")
    ps.add_argument("--diameter", type=float, default=4.5, help="Tank diameter, m (default 4.5)")
    ps.add_argument("--initial-temperature", type=float, default=19.5, help="Initial LH2 temperature, K")
    ps.add_argument("--initial-mass", type=float, default=4500.0, help="Initial LH2 mass, kg")
    ps.add_argument("--pressure", type=float, default=3.0e5, help="Relief/alarm pressure threshold, Pa")
    ps.add_argument("--ambient", type=float, default=293.15, help="Ambient temperature, K")
    ps.add_argument("--coolant-temperature", type=float, default=14.0, help="Conditioner coolant inlet temperature, K")
    ps.add_argument("--mass-flow", type=float, default=0.0, help="Recirculation mass flow, kg/s (0 = passive storage)")
    ps.add_argument("--duration", type=float, default=3600.0, help="Simulated duration, s")
    ps.add_argument("--timestep", type=float, default=10.0, help="Reporting timestep, s")
    ps.add_argument("--output", type=str, default=None, help="Write diagnostics to CSV/JSON/Parquet")
    ps.set_defaults(func=cmd_simulate)

    psc = sub.add_parser("scenario", help="Run a predefined scenario (A-F).")
    psc.add_argument(
        "name",
        choices=["warm-tank", "cooldown", "steady-storage", "densification", "high-heat-leak",
                 "recirculation", "transient-demand"],
    )
    psc.add_argument("--output", type=str, default=None)
    psc.set_defaults(func=cmd_scenario)

    pse = sub.add_parser("sensitivity", help="Deterministic parameter sensitivity sweep.")
    pse.add_argument("--parameter", type=str, default="vacuum_loss_factor")
    pse.add_argument("--values", type=str, default="1,5,10,20", help="Comma-separated values")
    pse.add_argument("--duration", type=float, default=2000.0)
    pse.add_argument("--timestep", type=float, default=20.0)
    pse.add_argument("--output", type=str, default=None)
    pse.set_defaults(func=cmd_sensitivity)

    pmc = sub.add_parser("monte-carlo", help="Monte Carlo heat-leak uncertainty quantification.")
    pmc.add_argument("--n", type=int, default=5000)
    pmc.add_argument("--seed", type=int, default=7)
    pmc.add_argument("--output", type=str, default=None)
    pmc.set_defaults(func=cmd_monte_carlo)

    pv = sub.add_parser("validate", help="Run internal consistency/conservation checks.")
    pv.set_defaults(func=cmd_validate)

    pgt = sub.add_parser("generate-telemetry", help="Generate synthetic sensor telemetry from a scenario.")
    pgt.add_argument("--scenario", type=str, default="recirculation")
    pgt.add_argument("--output", type=str, default="telemetry.parquet")
    pgt.add_argument("--seed", type=int, default=42)
    pgt.set_defaults(func=cmd_generate_telemetry)

    pr = sub.add_parser("replay", help="Replay a recorded telemetry file's control inputs through the twin.")
    pr.add_argument("telemetry_file", type=str)
    pr.add_argument("--initial-temperature", type=float, default=19.0)
    pr.add_argument("--timestep", type=float, default=10.0)
    pr.add_argument("--output", type=str, default=None)
    pr.set_defaults(func=cmd_replay)

    return p


def main(argv=None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    return args.func(args)


if __name__ == "__main__":
    sys.exit(main())
