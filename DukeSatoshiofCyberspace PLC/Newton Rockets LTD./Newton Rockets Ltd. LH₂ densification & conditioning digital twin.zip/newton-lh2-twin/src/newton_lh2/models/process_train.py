"""
Process-train orchestration: wraps the recirculation loop
(:mod:`newton_lh2.cryogenics.recirculation`) with a facility-level default
operating point, so callers (the solver, scenarios, CLI) can drive it with
just a mass-flow rate and an optional setpoint override per call.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

from newton_lh2.cryogenics.recirculation import (
    RecirculationLoopConfig,
    ConditionerSetpoint,
    RecirculationResult,
    run_recirculation_loop,
)
from newton_lh2.simulation.state import LH2State
from newton_lh2.thermodynamics.properties import HydrogenProperties, DEFAULT_PROPERTIES


@dataclass(frozen=True)
class ProcessTrainConfig:
    recirculation: RecirculationLoopConfig
    default_conditioner_setpoint: ConditionerSetpoint
    nominal_mass_flow_kg_s: float
    return_pressure_margin_Pa: float = 2.0e4


class ProcessTrain:
    """TANK -> WITHDRAWAL -> PUMP -> CONDITIONER -> RETURN -> TANK, at a facility's default operating point."""

    def __init__(self, config: ProcessTrainConfig, props: HydrogenProperties = None):
        self.config = config
        self.props = props or DEFAULT_PROPERTIES

    def run(
        self,
        tank_liquid_state: LH2State,
        mass_flow_kg_s: Optional[float] = None,
        conditioner_setpoint: Optional[ConditionerSetpoint] = None,
    ) -> RecirculationResult:
        mf = self.config.nominal_mass_flow_kg_s if mass_flow_kg_s is None else mass_flow_kg_s
        sp = self.config.default_conditioner_setpoint if conditioner_setpoint is None else conditioner_setpoint
        return run_recirculation_loop(
            tank_liquid_state,
            mf,
            self.config.recirculation,
            sp,
            return_pressure_margin_Pa=self.config.return_pressure_margin_Pa,
            props=self.props,
        )
