"""Facility-level composition: process train orchestration and telemetry."""
