"""
Synthetic telemetry generation and replay.

``generate_telemetry`` takes a simulation's diagnostic trajectory (the
"truth", as produced by :meth:`newton_lh2.simulation.solver.LH2Simulation.run`)
and produces an explicitly-synthetic sensor log: each measured channel is
the true value plus independent Gaussian sensor noise, stored in a column
suffixed ``_measured`` alongside the untouched ``_true`` column. Nothing
here is presented as, or derived from, real facility data.

``replay_telemetry`` goes the other direction: given a previously-recorded
(or synthetic) telemetry log, it extracts the recorded *control inputs*
(recirculation flow, outlet demand, vent flow) as a function of time and
drives a fresh :class:`~newton_lh2.simulation.solver.LH2Simulation` with
them as boundary conditions, reconstructing the facility's physical state
trajectory implied by that recorded operational history -- the core
"replay recorded telemetry through the digital twin" workflow.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Callable

import numpy as np
import pandas as pd

from newton_lh2.models.facility import NewtonLH2Facility, BoundaryConditions
from newton_lh2.simulation.solver import LH2Simulation, SimulationResult
from newton_lh2.simulation.events import ControlState

TRUE_CHANNELS = (
    "temperature_K",
    "pressure_Pa",
    "liquid_density_kg_m3",
    "mass_total_kg",
    "liquid_level_m",
    "heat_leak_W",
    "recirc_mass_flow_kg_s",
    "pump_shaft_power_W",
    "cooling_duty_W",
)


@dataclass(frozen=True)
class SensorNoiseConfig:
    """Per-channel Gaussian sensor-noise standard deviations (SYNTHETIC)."""

    temperature_K: float = 0.05
    pressure_Pa: float = 500.0
    liquid_density_kg_m3: float = 0.15
    mass_total_kg: float = 1.5
    liquid_level_m: float = 0.01
    heat_leak_W: float = 2.0
    recirc_mass_flow_kg_s: float = 0.01
    pump_shaft_power_W: float = 50.0
    cooling_duty_W: float = 100.0

    def std(self, channel: str) -> float:
        return getattr(self, channel, 0.0)


def generate_telemetry(
    diagnostics: pd.DataFrame,
    config: SensorNoiseConfig = SensorNoiseConfig(),
    seed: int = 42,
    channels: tuple = TRUE_CHANNELS,
) -> pd.DataFrame:
    """
    Build a synthetic sensor log from a simulation's diagnostic trajectory.

    Returns a DataFrame with ``time_s`` plus, for each requested channel,
    ``<channel>_true`` (copied straight from the simulation) and
    ``<channel>_measured`` (true value + Gaussian noise, std per
    :class:`SensorNoiseConfig`). Every value here is derived from the
    simulator's own physics -- there is no real sensor data involved.
    """
    rng = np.random.default_rng(seed)
    out = {"time_s": diagnostics["time_s"].to_numpy()}
    for ch in channels:
        if ch not in diagnostics.columns:
            continue
        true_vals = diagnostics[ch].to_numpy(dtype=float)
        noise = rng.normal(0.0, config.std(ch), size=true_vals.shape)
        out[f"{ch}_true"] = true_vals
        out[f"{ch}_measured"] = true_vals + noise
    return pd.DataFrame(out)


def save_telemetry(df: pd.DataFrame, path: str) -> None:
    """Save telemetry to Parquet (falls back to CSV if pyarrow is unavailable)."""
    try:
        df.to_parquet(path, index=False)
    except Exception:
        df.to_csv(path.rsplit(".", 1)[0] + ".csv", index=False)


def load_telemetry(path: str) -> pd.DataFrame:
    if path.endswith(".parquet"):
        return pd.read_parquet(path)
    return pd.read_csv(path)


def load_telemetry_window(
    path: str, t_min_s: float = None, t_max_s: float = None, channels: tuple = None
) -> pd.DataFrame:
    """
    Lazily scan a (potentially large) Parquet telemetry log and pull out
    only a time window and/or subset of channels, without materialising
    the whole file. Uses Polars' lazy query engine (`scan_parquet` +
    predicate/column pushdown), which is the appropriate tool here: a
    long-running facility log easily reaches millions of rows, and a
    pandas `read_parquet` would load and hold the entire thing in memory
    before any filtering happens.
    """
    import polars as pl

    lf = pl.scan_parquet(path)
    if t_min_s is not None:
        lf = lf.filter(pl.col("time_s") >= t_min_s)
    if t_max_s is not None:
        lf = lf.filter(pl.col("time_s") <= t_max_s)
    if channels is not None:
        cols = ["time_s"] + [c for c in channels if c != "time_s"]
        lf = lf.select([c for c in cols if c in lf.collect_schema().names()])
    return lf.collect().to_pandas()


# ---------------------------------------------------------------------- #
# Replay
# ---------------------------------------------------------------------- #


def _interpolated_column(df: pd.DataFrame, column: str, default: float = 0.0) -> Callable[[float], float]:
    if column not in df.columns:
        return lambda t: default
    t = df["time_s"].to_numpy(dtype=float)
    v = df[column].to_numpy(dtype=float)

    def f(query_t: float) -> float:
        return float(np.interp(query_t, t, v))

    return f


def replay_telemetry(
    df: pd.DataFrame,
    facility: NewtonLH2Facility,
    conditioner_setpoint,
    duration_s: float = None,
    timestep_s: float = 10.0,
    flow_column: str = "recirc_mass_flow_kg_s_measured",
    outlet_demand_column: str = "outlet_demand_kg_s_measured",
) -> SimulationResult:
    """
    Replay a recorded telemetry log's control inputs through a fresh
    facility model, reconstructing the physical state trajectory implied
    by that operational history.

    The *recorded measured* flow-rate channels become the simulation's
    boundary conditions (interpolated in time); everything else (tank
    state, pressures, densities, ...) is (re)computed by the physics
    model from first principles, so it can be compared against the
    recorded ``_measured``/``_true`` values for reconciliation.
    """
    if duration_s is None:
        duration_s = float(df["time_s"].max())

    flow_fn = _interpolated_column(df, flow_column, default=0.0)
    outlet_fn = _interpolated_column(df, outlet_demand_column, default=0.0)

    def bc_fn(t: float, control: ControlState) -> BoundaryConditions:
        return BoundaryConditions(
            recirculation_mass_flow_kg_s=max(flow_fn(t), 0.0),
            conditioner_setpoint=conditioner_setpoint,
            outlet_demand_kg_s=max(outlet_fn(t), 0.0),
        )

    sim = LH2Simulation(facility, bc_fn, duration_s=duration_s, timestep_s=timestep_s, diagnostic_stride=1)
    return sim.run()
