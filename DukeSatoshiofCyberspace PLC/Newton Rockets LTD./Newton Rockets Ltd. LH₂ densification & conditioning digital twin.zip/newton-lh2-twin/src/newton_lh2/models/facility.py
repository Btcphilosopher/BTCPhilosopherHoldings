"""
Top-level facility composition: the LH2 tank plus its recirculation /
conditioning process train, combined into a single object that the
transient solver drives and that produces
:class:`~newton_lh2.simulation.state.FacilityState` snapshots for
reporting, telemetry and the dashboard.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional

from newton_lh2.cryogenics.tank import CryoTank
from newton_lh2.cryogenics.recirculation import ConditionerSetpoint, FlowInfeasibleError
from newton_lh2.models.process_train import ProcessTrain
from newton_lh2.simulation.state import LH2State, FacilityState
from newton_lh2.thermodynamics.properties import HydrogenProperties, DEFAULT_PROPERTIES
from newton_lh2.thermodynamics.phase import Phase


@dataclass(frozen=True)
class FacilityLimits:
    """Operating envelope used to raise alarms (not to physically clamp the model)."""

    max_pressure_Pa: float = 3.0e5
    min_fill_fraction: float = 0.05
    max_fill_fraction: float = 0.98
    min_pump_npsh_margin_m: float = 0.0  # informational; the real check lives in cavitation diagnostics


@dataclass
class BoundaryConditions:
    """Time-varying facility inputs for one solver step."""

    recirculation_mass_flow_kg_s: float = 0.0
    conditioner_setpoint: Optional[ConditionerSetpoint] = None
    outlet_demand_kg_s: float = 0.0
    vent_mass_flow_kg_s: float = 0.0
    Q_dot_extra_W: float = 0.0


class NewtonLH2Facility:
    """The whole conditioning facility: tank + process train."""

    def __init__(self, tank: CryoTank, process_train: ProcessTrain, limits: FacilityLimits = None, props: HydrogenProperties = None):
        self.tank = tank
        self.process_train = process_train
        self.limits = limits or FacilityLimits()
        self.props = props or DEFAULT_PROPERTIES

    # ------------------------------------------------------------------ #
    def tank_liquid_state(self) -> LH2State:
        """The liquid available for withdrawal from the tank right now."""
        ts = self.tank.state()
        if ts.phase.is_liquid_like or ts.phase == Phase.TWO_PHASE:
            if ts.phase == Phase.TWO_PHASE:
                return self.props.state_TQ(ts.temperature_K, 0.0)
            return self.props.state_TP(ts.temperature_K, ts.pressure_Pa)
        raise RuntimeError(f"Tank has no withdrawable liquid (phase={ts.phase})")

    def initial_state_vector(self) -> tuple[float, float]:
        return self.tank.M, self.tank.U

    def set_state_vector(self, M: float, U: float) -> None:
        self.tank.set_state(M, U)

    # ------------------------------------------------------------------ #
    def derivative(self, boundary: BoundaryConditions):
        """
        Right-hand side of the coupled facility ODE at the tank's current
        state, given the boundary conditions for this instant. Returns
        ``(dM_dt, dU_dt, recirculation_result_or_None)``.
        """
        loop_result = None
        h_loop_return = None
        m_loop = boundary.recirculation_mass_flow_kg_s
        if m_loop > 0:
            liquid = self.tank_liquid_state()
            loop_result = self.process_train.run(
                liquid, mass_flow_kg_s=m_loop, conditioner_setpoint=boundary.conditioner_setpoint
            )
            h_loop_return = loop_result.return_state.enthalpy_J_kg

        dM, dU = self.tank.derivative(
            Q_dot_extra_W=boundary.Q_dot_extra_W,
            m_dot_loop_kg_s=m_loop,
            h_loop_return_J_kg=h_loop_return,
            m_dot_outlet_kg_s=boundary.outlet_demand_kg_s,
            m_dot_vent_kg_s=boundary.vent_mass_flow_kg_s,
        )
        return dM, dU, loop_result

    # ------------------------------------------------------------------ #
    def alarms(self, tank_state, loop_result) -> tuple[str, ...]:
        alarms: list[str] = []
        if tank_state.pressure_Pa > self.limits.max_pressure_Pa:
            alarms.append(
                f"HIGH PRESSURE: tank {tank_state.pressure_Pa/1e5:.3f} bar exceeds limit "
                f"{self.limits.max_pressure_Pa/1e5:.3f} bar"
            )
        if tank_state.fill_fraction < self.limits.min_fill_fraction:
            alarms.append(f"LOW LEVEL: fill fraction {tank_state.fill_fraction:.3f} below minimum")
        if tank_state.fill_fraction > self.limits.max_fill_fraction:
            alarms.append(f"HIGH LEVEL: fill fraction {tank_state.fill_fraction:.3f} above maximum")
        if loop_result is not None:
            alarms.extend(loop_result.warnings)
        return tuple(alarms)

    def snapshot(self, time_s: float, boundary: BoundaryConditions) -> FacilityState:
        """A FacilityState built from the tank's *current* stored state (no integration)."""
        ts = self.tank.state(time_s)
        loop_result = None
        outlet_state = self.tank_liquid_state() if ts.mass_liquid_kg > 0 else self.props.state_TQ(ts.temperature_K, 1.0)
        if boundary.recirculation_mass_flow_kg_s > 0:
            try:
                loop_result = self.process_train.run(
                    self.tank_liquid_state(),
                    mass_flow_kg_s=boundary.recirculation_mass_flow_kg_s,
                    conditioner_setpoint=boundary.conditioner_setpoint,
                )
            except FlowInfeasibleError:
                loop_result = None

        recirc_dict = {
            "mass_flow_kg_s": boundary.recirculation_mass_flow_kg_s,
            "withdrawal_pressure_drop_Pa": loop_result.withdrawal_line.pressure_drop_Pa if loop_result else 0.0,
            "return_pressure_drop_Pa": loop_result.return_line.pressure_drop_Pa if loop_result else 0.0,
        }
        conditioner_dict = {
            "duty_W": loop_result.total_cooling_duty_W if loop_result else 0.0,
            "process_outlet_K": loop_result.conditioner.outlet.temperature_K if loop_result else None,
        }
        pump_dict = {
            "shaft_power_W": loop_result.total_shaft_power_W if loop_result else 0.0,
        }

        alarms = self.alarms(ts, loop_result)

        return FacilityState(
            timestamp_s=time_s,
            tank=ts.as_dict(),
            recirculation=recirc_dict,
            conditioner=conditioner_dict,
            pump=pump_dict,
            outlet=outlet_state,
            alarms=alarms,
        )
