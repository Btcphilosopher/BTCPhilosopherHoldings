"""
Newton Rockets Ltd. engineering dashboard generator.

Produces a single self-contained HTML file from a simulation's
diagnostics trajectory. Visual language: British aerospace laboratory +
modern industrial control room + scientific computing workstation --
deliberately restrained (no neon, no gradients, no game-HUD chrome).

Every number on this dashboard is read directly from the physics model's
own diagnostic trajectory -- nothing here is a placeholder or a
decorative animation. The dashboard is strictly downstream of the
scientific model (see README.md, "Engineering philosophy").

Usage
-----
    python dashboard/generate_dashboard.py                      # runs Scenario C by default
    python dashboard/generate_dashboard.py --scenario high-heat-leak --output out.html
"""

from __future__ import annotations

import argparse
import html
from pathlib import Path

import pandas as pd
import plotly.graph_objects as go
from plotly.subplots import make_subplots

# ---------------------------------------------------------------------- #
# Palette -- restrained aerospace-lab tones, not neon
# ---------------------------------------------------------------------- #
BG = "#0c1117"
PANEL_BG = "#131a22"
BORDER = "#2a3542"
INK = "#d7dee5"
DIM = "#7c8a99"
ACCENT_AMBER = "#e0a94d"
ACCENT_GREEN = "#5fb87a"
ACCENT_RED = "#c1594f"
GRID = "#1e2831"
MONO = "'IBM Plex Mono', 'JetBrains Mono', 'Consolas', 'SF Mono', monospace"


def _status(ok: bool) -> str:
    return f'<span style="color:{ACCENT_GREEN}">PASS</span>' if ok else f'<span style="color:{ACCENT_RED}">FAIL</span>'


def _card(label: str, value: str, unit: str = "", color: str = INK) -> str:
    return f"""
    <div class="card">
      <div class="card-label">{html.escape(label)}</div>
      <div class="card-value" style="color:{color}">{value}<span class="card-unit">{html.escape(unit)}</span></div>
    </div>"""


def _trace_figure(diagnostics: pd.DataFrame) -> str:
    t = diagnostics["time_s"] / 3600.0  # hours, easier to read on long runs
    fig = make_subplots(
        rows=2, cols=2,
        subplot_titles=("LIQUID DENSITY", "TEMPERATURE / PRESSURE", "COOLING DUTY / PUMP POWER", "TANK FILL"),
        vertical_spacing=0.16, horizontal_spacing=0.09,
    )
    fig.add_trace(go.Scatter(x=t, y=diagnostics["liquid_density_kg_m3"], mode="lines",
                              line=dict(color=ACCENT_AMBER, width=2), name="Liquid density"), row=1, col=1)
    fig.add_trace(go.Scatter(x=t, y=diagnostics["temperature_K"], mode="lines",
                              line=dict(color=ACCENT_AMBER, width=2), name="Temperature"), row=1, col=2)
    fig.add_trace(go.Scatter(x=t, y=diagnostics["pressure_Pa"] / 1e5, mode="lines",
                              line=dict(color=ACCENT_GREEN, width=2, dash="dot"), name="Pressure",
                              yaxis="y4"), row=1, col=2)
    if "cooling_duty_W" in diagnostics:
        fig.add_trace(go.Scatter(x=t, y=diagnostics["cooling_duty_W"], mode="lines",
                                  line=dict(color=ACCENT_GREEN, width=2), name="Cooling duty"), row=2, col=1)
    if "pump_shaft_power_W" in diagnostics:
        fig.add_trace(go.Scatter(x=t, y=diagnostics["pump_shaft_power_W"], mode="lines",
                                  line=dict(color=ACCENT_AMBER, width=1.5, dash="dot"), name="Pump power"), row=2, col=1)
    fig.add_trace(go.Scatter(x=t, y=diagnostics["fill_fraction"] * 100.0, mode="lines",
                              line=dict(color=ACCENT_AMBER, width=2), fill="tozeroy",
                              fillcolor="rgba(224,169,77,0.08)", name="Fill %"), row=2, col=2)

    fig.update_layout(
        paper_bgcolor=PANEL_BG, plot_bgcolor=PANEL_BG,
        font=dict(family=MONO, color=INK, size=12),
        showlegend=False, margin=dict(l=50, r=30, t=40, b=40), height=560,
    )
    fig.update_xaxes(title_text="time, h", gridcolor=GRID, zerolinecolor=GRID, color=DIM)
    fig.update_yaxes(gridcolor=GRID, zerolinecolor=GRID, color=DIM)
    fig.update_annotations(font=dict(family=MONO, size=12, color=DIM))
    return fig.to_html(include_plotlyjs="cdn", full_html=False, config={"displaylogo": False})


def generate_dashboard(
    diagnostics: pd.DataFrame,
    title: str,
    output_path: str,
    mass_conservation_pass: bool = True,
    energy_conservation_pass: bool = True,
    subtitle: str = "",
) -> str:
    last = diagnostics.iloc[-1]
    first = diagnostics.iloc[0]

    plot_html = _trace_figure(diagnostics)

    alarms = str(last.get("alarms", "") or "")
    n_alarms = int(last.get("n_alarms", 0) or 0)
    alarm_html = (
        f'<div class="alarm-banner">{html.escape(alarms)}</div>' if n_alarms > 0 else ""
    )

    doc = f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>{html.escape(title)} — Newton Rockets Ltd.</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=IBM+Plex+Mono:wght@400;500;600&display=swap" rel="stylesheet">
<style>
  :root {{
    color-scheme: dark;
  }}
  * {{ box-sizing: border-box; }}
  body {{
    margin: 0; background: {BG}; color: {INK};
    font-family: {MONO};
    padding: 24px; line-height: 1.4;
  }}
  .frame {{
    max-width: 1180px; margin: 0 auto;
    border: 1px solid {BORDER}; background: {PANEL_BG};
  }}
  header {{
    display: flex; justify-content: space-between; align-items: baseline;
    padding: 18px 24px; border-bottom: 1px solid {BORDER};
  }}
  header .brand {{ font-size: 13px; letter-spacing: 0.12em; color: {DIM}; }}
  header h1 {{ font-size: 18px; margin: 4px 0 0 0; letter-spacing: 0.04em; font-weight: 600; }}
  header .disclaimer {{ font-size: 10px; color: {ACCENT_AMBER}; text-align: right; letter-spacing: 0.06em; }}
  .alarm-banner {{
    background: rgba(193,89,79,0.15); border-bottom: 1px solid {ACCENT_RED};
    color: {ACCENT_RED}; padding: 8px 24px; font-size: 12px; letter-spacing: 0.03em;
  }}
  .nodes {{
    display: grid; grid-template-columns: repeat(3, 1fr); gap: 1px;
    background: {BORDER}; border-bottom: 1px solid {BORDER};
  }}
  .node {{ background: {PANEL_BG}; padding: 16px 22px; }}
  .node-title {{ font-size: 11px; color: {DIM}; letter-spacing: 0.12em; margin-bottom: 10px; }}
  .node-row {{ display: flex; justify-content: space-between; font-size: 20px; margin: 4px 0; }}
  .node-row .u {{ font-size: 12px; color: {DIM}; align-self: flex-end; margin-left: 6px; }}
  .charts {{ padding: 18px 20px 6px 20px; }}
  .cards {{
    display: grid; grid-template-columns: repeat(4, 1fr); gap: 1px;
    background: {BORDER}; border-top: 1px solid {BORDER};
  }}
  .card {{ background: {PANEL_BG}; padding: 14px 20px; }}
  .card-label {{ font-size: 10px; color: {DIM}; letter-spacing: 0.1em; margin-bottom: 6px; }}
  .card-value {{ font-size: 18px; font-weight: 600; }}
  .card-unit {{ font-size: 11px; color: {DIM}; margin-left: 4px; font-weight: 400; }}
  footer {{ padding: 10px 24px; font-size: 10px; color: {DIM}; border-top: 1px solid {BORDER}; }}
</style>
</head>
<body>
  <div class="frame">
    <header>
      <div>
        <div class="brand">NEWTON ROCKETS LTD.</div>
        <h1>{html.escape(title)}</h1>
      </div>
      <div class="disclaimer">RESEARCH / ENGINEERING SIMULATION<br>NOT FLIGHT-CERTIFIED</div>
    </header>
    {alarm_html}
    <div class="nodes">
      <div class="node">
        <div class="node-title">TANK</div>
        <div class="node-row">{last['temperature_K']:.2f}<span class="u">K</span></div>
        <div class="node-row">{last['pressure_Pa']/1e5:.3f}<span class="u">bar</span></div>
        <div class="node-row">{last['liquid_density_kg_m3']:.1f}<span class="u">kg/m³</span></div>
      </div>
      <div class="node">
        <div class="node-title">CONDITIONER</div>
        <div class="node-row">{last.get('cooling_duty_W', 0.0)/1e3:.2f}<span class="u">kW duty</span></div>
        <div class="node-row">{last.get('pump_shaft_power_W', 0.0)/1e3:.2f}<span class="u">kW pump</span></div>
        <div class="node-row">{last.get('recirc_mass_flow_kg_s', 0.0):.3f}<span class="u">kg/s</span></div>
      </div>
      <div class="node">
        <div class="node-title">OUTLET</div>
        <div class="node-row">{last['temperature_K']:.2f}<span class="u">K (loop return)</span></div>
        <div class="node-row">{last.get('outlet_demand_kg_s', 0.0):.3f}<span class="u">kg/s demand</span></div>
        <div class="node-row">{last['fill_fraction']*100.0:.1f}<span class="u">% full</span></div>
      </div>
    </div>
    <div class="charts">
      {plot_html}
    </div>
    <div class="cards">
      {_card("MASS BALANCE", _status(mass_conservation_pass))}
      {_card("ENERGY BALANCE", _status(energy_conservation_pass))}
      {_card("HEAT LEAK", f"{last.get('heat_leak_W', 0.0):.2f}", "W")}
      {_card("BOIL-OFF RATE", f"{last.get('normal_boiloff_rate_kg_s', 0.0)*1000:.3f}", "g/s")}
    </div>
    <footer>
      {html.escape(subtitle)} &nbsp;·&nbsp;
      {len(diagnostics)} diagnostic samples over {(last['time_s']-first['time_s'])/3600.0:.2f} h &nbsp;·&nbsp;
      generated by newton_lh2.dashboard
    </footer>
  </div>
</body>
</html>"""

    Path(output_path).write_text(doc, encoding="utf-8")
    return output_path


def main() -> int:
    from newton_lh2.simulation.scenarios import SCENARIOS

    parser = argparse.ArgumentParser(description="Generate the Newton Rockets LH2 engineering dashboard.")
    parser.add_argument("--scenario", default="densification", choices=list(SCENARIOS))
    parser.add_argument("--output", default="dashboard/output/dashboard.html")
    args = parser.parse_args()

    run = SCENARIOS[args.scenario]()
    Path(args.output).parent.mkdir(parents=True, exist_ok=True)
    path = generate_dashboard(
        run.result.diagnostics,
        title=f"LH2 CONDITIONING TWIN — {run.name.upper()}",
        output_path=args.output,
        mass_conservation_pass=run.result.conservation.mass_pass,
        energy_conservation_pass=run.result.conservation.energy_pass,
        subtitle=run.description,
    )
    print(f"Wrote {path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
