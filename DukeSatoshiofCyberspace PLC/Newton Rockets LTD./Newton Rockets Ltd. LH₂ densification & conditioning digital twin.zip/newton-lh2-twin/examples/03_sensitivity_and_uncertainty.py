"""
Example: a deterministic sensitivity sweep plus a Monte Carlo uncertainty
study, matching the CLI's `sensitivity` and `monte-carlo` subcommands.

Run with:  python examples/03_sensitivity_and_uncertainty.py
"""

from newton_lh2.analysis.sensitivity import run_parameter_sweep
from newton_lh2.analysis.uncertainty import monte_carlo, normal, lognormal_relative, heat_leak_response

if __name__ == "__main__":
    print("Sensitivity: effect of degraded insulation (vacuum_loss_factor) on final density")
    df = run_parameter_sweep("vacuum_loss_factor", [1.0, 5.0, 10.0, 20.0], duration_s=2000.0, timestep_s=20.0)
    print(df[["value", "final_density_kg_m3", "cooling_energy_J", "final_pressure_Pa"]].to_string(index=False))

    print("\nMonte Carlo: heat-leak uncertainty from insulation/property scatter")
    dists = {
        "apparent_conductivity_W_mK": lognormal_relative(3.0e-5, 0.25),
        "layer_emissivity": lognormal_relative(0.03, 0.20),
        "ambient_temperature_K": normal(293.15, 3.0),
        "liquid_temperature_K": normal(20.0, 0.3),
    }
    result = monte_carlo(dists, heat_leak_response(), n=5000, seed=1)
    print(result.report("total tank heat leak, W"))
