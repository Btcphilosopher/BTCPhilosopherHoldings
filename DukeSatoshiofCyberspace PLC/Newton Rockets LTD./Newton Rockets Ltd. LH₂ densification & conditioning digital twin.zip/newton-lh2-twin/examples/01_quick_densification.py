"""
Example: run Scenario C (Controlled Densification) and print a summary
of the density gain, energy cost, and conservation diagnostics.

Run with:  python examples/01_quick_densification.py
"""

from newton_lh2.simulation.scenarios import scenario_c_controlled_densification
from newton_lh2.analysis.density import summarize_densification, volumetric_capacity_gain
from newton_lh2.analysis.energy import summarize_energy_balance

if __name__ == "__main__":
    run = scenario_c_controlled_densification(duration_s=3000.0, timestep_s=10.0)
    print(f"{run.name}\n  {run.description}\n")
    print(run.result.summary())

    d = run.result.diagnostics
    mass_processed = float(d["mass_total_kg"].iloc[0])  # order-of-magnitude proxy for this example
    densification = summarize_densification(d, mass_processed_kg=mass_processed)
    print("\n" + densification.report())

    gain = volumetric_capacity_gain(
        d["liquid_density_kg_m3"].iloc[0], d["liquid_density_kg_m3"].iloc[-1], tank_volume_m3=100.0
    )
    print(f"\nAdditional tank capacity at final density: {gain.additional_capacity_kg:.1f} kg "
          f"({gain.additional_capacity_percent:+.2f} %)")

    energy = summarize_energy_balance(d, run.result.internal_energy_J)
    print("\n" + energy.report())
