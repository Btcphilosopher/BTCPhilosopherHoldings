"""
Example: Scenario D (High Heat Leak) with a relief-valve event, showing
the pressure trace opening and reclosing the vent.

Run with:  python examples/02_relief_valve_event.py
"""

from newton_lh2.simulation.scenarios import scenario_d_high_heat_leak

if __name__ == "__main__":
    run = scenario_d_high_heat_leak()
    print(f"{run.name}\n  {run.description}\n")
    print(run.result.summary())

    d = run.result.diagnostics
    print("\nPressure trace (every 40th sample):")
    print(d[["time_s", "pressure_Pa", "vent_open", "mass_total_kg"]].iloc[::40].to_string(index=False))
