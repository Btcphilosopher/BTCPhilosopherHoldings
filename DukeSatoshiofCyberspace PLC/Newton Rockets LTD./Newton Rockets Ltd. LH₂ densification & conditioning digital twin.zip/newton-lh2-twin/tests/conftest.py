"""Shared pytest fixtures."""

import pytest

from newton_lh2.thermodynamics.properties import HydrogenProperties


@pytest.fixture(scope="session")
def props() -> HydrogenProperties:
    return HydrogenProperties()
