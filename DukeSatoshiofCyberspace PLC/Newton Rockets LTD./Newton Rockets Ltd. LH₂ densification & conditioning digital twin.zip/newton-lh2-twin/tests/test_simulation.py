"""Transient solver, conservation diagnostics, events, and predefined scenarios."""

import pytest

from newton_lh2.cryogenics.tank import CryoTank, TankGeometry
from newton_lh2.cryogenics.insulation import InsulationSystem
from newton_lh2.cryogenics.recirculation import RecirculationLoopConfig, ConditionerSetpoint
from newton_lh2.fluid.pipe import Pipe
from newton_lh2.fluid.pump import PumpSpec
from newton_lh2.models.process_train import ProcessTrain, ProcessTrainConfig
from newton_lh2.models.facility import NewtonLH2Facility, BoundaryConditions, FacilityLimits
from newton_lh2.simulation.solver import LH2Simulation
from newton_lh2.simulation.events import high_pressure_vent_event, vent_reclose_event
from newton_lh2.simulation.timestep import build_time_grid
import newton_lh2.simulation.scenarios as scenarios


def _passive_facility(props):
    geom = TankGeometry(volume_m3=100.0, diameter_m=4.5)
    ins = InsulationSystem.mli_vacuum_jacket(area_m2=90.0)
    tank = CryoTank(geom, ins, ambient_temperature_K=293.0, initial_mass_kg=4500.0, initial_temperature_K=19.0)
    recirc_cfg = RecirculationLoopConfig(
        withdrawal_pipe=Pipe(length_m=15.0, inner_diameter_m=0.05, minor_loss_K=2.0),
        return_pipe=Pipe(length_m=18.0, inner_diameter_m=0.05, minor_loss_K=3.0),
        pump_spec=PumpSpec(efficiency=0.6, npsh_required_m=0.3, subcooling_safety_margin_K=0.2),
    )
    setpoint = ConditionerSetpoint(
        mode="specified_outlet_temperature", outlet_temperature_K=17.0,
        coolant_inlet=props.state_TP(14.0, 1.5e5), coolant_mass_flow_kg_s=0.6,
    )
    pt = ProcessTrain(ProcessTrainConfig(recirc_cfg, setpoint, nominal_mass_flow_kg_s=0.0))
    return NewtonLH2Facility(tank, pt, limits=FacilityLimits())


class TestTimestepUtils:
    def test_build_time_grid(self):
        grid = build_time_grid(100.0, 10.0)
        assert grid[0] == 0.0
        assert grid[-1] == pytest.approx(100.0)
        assert len(grid) == 11


class TestSolverConservation:
    def test_passive_storage_conserves_mass_and_energy(self, props):
        facility = _passive_facility(props)

        def bc_fn(t, control):
            return BoundaryConditions()

        sim = LH2Simulation(facility, bc_fn, duration_s=600.0, timestep_s=10.0, diagnostic_stride=1)
        result = sim.run()
        assert result.conservation.mass_pass
        assert result.conservation.energy_pass
        assert result.mass_kg[0] == pytest.approx(result.mass_kg[-1])

    def test_active_recirculation_cools_tank(self, props):
        facility = _passive_facility(props)

        def bc_fn(t, control):
            return BoundaryConditions(recirculation_mass_flow_kg_s=1.0)

        sim = LH2Simulation(facility, bc_fn, duration_s=300.0, timestep_s=10.0, diagnostic_stride=1)
        result = sim.run()
        assert result.conservation.mass_pass
        assert result.conservation.energy_pass
        d = result.diagnostics
        assert d["temperature_K"].iloc[-1] < d["temperature_K"].iloc[0]

    def test_outlet_demand_reduces_mass(self, props):
        facility = _passive_facility(props)

        def bc_fn(t, control):
            return BoundaryConditions(outlet_demand_kg_s=0.05)

        sim = LH2Simulation(facility, bc_fn, duration_s=200.0, timestep_s=10.0, diagnostic_stride=1)
        result = sim.run()
        assert result.mass_kg[-1] < result.mass_kg[0]
        assert result.conservation.mass_pass

    def test_high_timestep_count_runs_quickly(self, props):
        """Core (M, U) trajectory must scale to 100,000+ reporting timesteps (performance target)."""
        facility = _passive_facility(props)

        def bc_fn(t, control):
            return BoundaryConditions()

        sim = LH2Simulation(facility, bc_fn, duration_s=100000.0, timestep_s=1.0, diagnostic_stride=10000)
        result = sim.run()
        assert len(result.t_s) >= 100000
        assert result.conservation.mass_pass
        assert result.conservation.energy_pass


class TestEvents:
    def test_relief_valve_opens_and_recloses(self, props):
        geom = TankGeometry(volume_m3=50.0, diameter_m=3.5)
        ins = InsulationSystem.degraded(InsulationSystem.mli_vacuum_jacket(area_m2=45.0), vacuum_loss_factor=15.0)
        tank = CryoTank(geom, ins, ambient_temperature_K=293.0, initial_mass_kg=2500.0, initial_temperature_K=20.0)
        recirc_cfg = RecirculationLoopConfig(
            withdrawal_pipe=Pipe(length_m=10.0, inner_diameter_m=0.05, minor_loss_K=2.0),
            return_pipe=Pipe(length_m=10.0, inner_diameter_m=0.05, minor_loss_K=2.0),
        )
        setpoint = ConditionerSetpoint(
            mode="specified_outlet_temperature", outlet_temperature_K=17.0,
            coolant_inlet=props.state_TP(14.0, 1.5e5), coolant_mass_flow_kg_s=0.3,
        )
        pt = ProcessTrain(ProcessTrainConfig(recirc_cfg, setpoint, nominal_mass_flow_kg_s=0.0))
        facility = NewtonLH2Facility(tank, pt, limits=FacilityLimits(max_pressure_Pa=1.05e5))

        def bc_fn(t, control):
            return BoundaryConditions()

        events = [high_pressure_vent_event(1.05e5), vent_reclose_event(1.02e5)]
        sim = LH2Simulation(
            facility, bc_fn, duration_s=60000.0, timestep_s=100.0, diagnostic_stride=1,
            events=events, vent_capacity_kg_s=0.003,
        )
        result = sim.run()
        assert "HIGH_PRESSURE_VENT@1.050bar" in result.event_log
        assert result.diagnostics["mass_total_kg"].iloc[-1] < 2500.0
        assert result.conservation.mass_pass
        assert result.conservation.energy_pass


class TestScenarios:
    @pytest.mark.parametrize("name", list(scenarios.SCENARIOS.keys()))
    def test_scenario_runs_and_conserves(self, name):
        run = scenarios.SCENARIOS[name]()
        assert run.result.conservation.mass_pass
        assert run.result.conservation.energy_pass
        assert len(run.result.diagnostics) > 1
