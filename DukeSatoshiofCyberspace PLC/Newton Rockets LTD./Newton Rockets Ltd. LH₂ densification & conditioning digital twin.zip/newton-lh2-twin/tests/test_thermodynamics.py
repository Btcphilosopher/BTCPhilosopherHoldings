"""Property engine, phase classification, saturation, validation, EOS cross-check."""

import math

import pytest

from newton_lh2.thermodynamics.phase import Phase
from newton_lh2.thermodynamics.properties import (
    HydrogenProperties, T_CRIT_K, P_CRIT_PA, T_TRIPLE_K, P_TRIPLE_PA,
)
from newton_lh2.thermodynamics.validation import ValidRange, PropertyRangeError, PropertyRangeWarning
from newton_lh2.thermodynamics.saturation import subcooling_margin, is_within_saturation_dome
from newton_lh2.thermodynamics import equation_of_state as eos


class TestFixedPoints:
    def test_critical_point_matches_leachman_order_of_magnitude(self):
        assert 32.0 < T_CRIT_K < 34.0
        assert 1.2e6 < P_CRIT_PA < 1.35e6

    def test_triple_point(self):
        assert 13.7 < T_TRIPLE_K < 13.9
        assert 6500 < P_TRIPLE_PA < 7500

    def test_normal_boiling_point(self, props):
        nbp = props.normal_boiling_point()
        assert 20.0 < nbp < 20.6


class TestStateConstruction:
    def test_state_tp_subcooled_liquid(self, props):
        s = props.state_TP(18.0, 1.3e5)
        assert s.phase == Phase.SUBCOOLED_LIQUID
        assert 60 < s.density_kg_m3 < 80
        assert s.quality is None

    def test_state_tq_saturated_liquid(self, props):
        s = props.state_TQ(20.0, 0.0)
        assert s.phase == Phase.SATURATED_LIQUID
        assert s.quality == 0.0

    def test_state_tq_two_phase(self, props):
        s = props.state_TQ(20.0, 0.3)
        assert s.phase == Phase.TWO_PHASE
        assert math.isclose(s.quality, 0.3)

    def test_ph_roundtrip(self, props):
        s0 = props.state_TP(17.5, 1.4e5)
        s1 = props.state_PH(1.4e5, s0.enthalpy_J_kg)
        assert abs(s0.temperature_K - s1.temperature_K) < 1e-6
        assert abs(s0.density_kg_m3 - s1.density_kg_m3) < 1e-6

    def test_ps_roundtrip(self, props):
        s0 = props.state_TP(17.5, 1.4e5)
        s1 = props.state_PS(1.4e5, s0.entropy_J_kgK)
        assert abs(s0.temperature_K - s1.temperature_K) < 1e-6

    def test_near_saturation_pt_does_not_raise(self, props):
        # Regression: PT flash exactly on the saturation curve is
        # numerically degenerate; the engine must nudge past it, not raise.
        t_sat = props.saturation_temperature(1.3e5)
        s = props.state_TP(t_sat, 1.3e5)
        assert s.temperature_K == pytest.approx(t_sat, abs=1e-6)


class TestSaturation:
    def test_latent_heat_positive(self, props):
        assert props.latent_heat(20.0) > 0

    def test_saturation_envelope_consistency(self, props):
        env = props.saturation_envelope_T(20.0)
        assert env.vapor_density_kg_m3 < env.liquid_density_kg_m3
        assert env.latent_heat_J_kg == pytest.approx(env.vapor_enthalpy_J_kg - env.liquid_enthalpy_J_kg)

    def test_saturation_pressure_temperature_are_inverse(self, props):
        p = props.saturation_pressure(19.0)
        t = props.saturation_temperature(p)
        assert t == pytest.approx(19.0, abs=1e-6)

    def test_subcooling_margin_sign(self, props):
        m = subcooling_margin(17.0, 1.3e5, props=props)
        assert m.is_subcooled
        assert m.margin_K > 0

    def test_within_dome(self):
        assert is_within_saturation_dome(20.0, 1e5)
        assert not is_within_saturation_dome(20.0, 5e6)


class TestValidation:
    def test_out_of_range_temperature_raises(self, props):
        with pytest.raises(PropertyRangeError):
            props.density(5.0, 1e5)

    def test_permissive_mode_warns_instead_of_raising(self):
        # 350 K is outside this facility's validated envelope (T_max=320 K)
        # but well within the backend's own computable range, so this
        # exercises *our* range check in permissive mode, not the
        # backend's independent refusal to model the solid phase.
        permissive = HydrogenProperties(valid_range=ValidRange(), strict=False)
        with pytest.warns(PropertyRangeWarning):
            permissive.density(350.0, 1e5)

    def test_saturation_pressure_out_of_dome_raises(self, props):
        with pytest.raises(PropertyRangeError):
            props.saturation_pressure(5.0)


class TestPhaseClassification:
    @pytest.mark.parametrize(
        "T,P,expected",
        [
            (15.0, 5.0e5, Phase.SUBCOOLED_LIQUID),
            (25.0, 0.5e5, Phase.SUPERHEATED_VAPOR),
        ],
    )
    def test_classify(self, props, T, P, expected):
        assert props.classify_phase(T, P) == expected

    def test_supercritical(self, props):
        assert props.classify_phase(35.0, 1.5e6) == Phase.SUPERCRITICAL


class TestEquationOfStateCrossCheck:
    def test_rk_vapor_density_same_order_as_heos(self, props):
        env = props.saturation_envelope_T(20.0)
        rk_rho = eos.density_rk(20.0, env.pressure_Pa, branch="vapor")
        assert 0.3 * env.vapor_density_kg_m3 < rk_rho < 3.0 * env.vapor_density_kg_m3

    def test_rackett_calibrated_tracks_heos_within_a_few_percent(self, props):
        rho_ref = props.saturated_liquid_density(20.0)
        zc = eos.calibrate_rackett_zc(rho_ref, 20.0)
        for T in (16.0, 18.0, 22.0):
            rho_true = props.saturated_liquid_density(T)
            rho_rackett = eos.rackett_saturated_liquid_density(T, zc)
            assert abs(rho_rackett - rho_true) / rho_true < 0.05

    def test_metadata_present(self):
        assert eos.PRIMARY_EOS.is_primary
        assert not eos.FALLBACK_EOS.is_primary
