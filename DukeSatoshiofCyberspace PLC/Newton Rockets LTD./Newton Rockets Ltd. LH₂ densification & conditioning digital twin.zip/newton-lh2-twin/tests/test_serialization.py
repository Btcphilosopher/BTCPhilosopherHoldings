"""State containers serialize cleanly to JSON/CSV/Parquet-friendly forms."""

import json

import pytest

from newton_lh2.simulation.state import LH2State, ComponentState, FacilityState
from newton_lh2.thermodynamics.phase import Phase


class TestLH2StateSerialization:
    def test_as_dict_is_json_serializable(self, props):
        s = props.state_TP(18.0, 1.3e5)
        d = s.as_dict()
        assert json.dumps(d)  # no exception
        assert d["phase"] == "subcooled_liquid"

    def test_frozen_immutable(self, props):
        s = props.state_TP(18.0, 1.3e5)
        with pytest.raises(Exception):
            s.temperature_K = 999.0


class TestComponentStateSerialization:
    def test_as_dict_nests_inlet_outlet(self, props):
        inlet = props.state_TP(20.0, 1.3e5)
        outlet = props.state_TP(17.0, 1.3e5)
        cs = ComponentState("TEST", inlet, outlet, 1.0, 100.0, -5000.0, 0.0, warnings=("a warning",))
        d = cs.as_dict()
        assert json.dumps(d)
        assert d["warnings"] == ["a warning"]


class TestFacilityStateSerialization:
    def test_scenario_snapshot_round_trips_to_json(self):
        import newton_lh2.simulation.scenarios as scenarios

        run = scenarios.scenario_e_recirculation(duration_s=200.0, timestep_s=10.0)
        row = run.result.diagnostics.iloc[0].to_dict()
        assert json.dumps(row, default=str)
