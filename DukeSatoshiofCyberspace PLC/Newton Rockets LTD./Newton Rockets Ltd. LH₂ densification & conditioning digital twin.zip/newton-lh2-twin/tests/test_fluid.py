"""Pipe/pressure-drop, pump, cavitation."""

import pytest

from newton_lh2.fluid.pipe import Pipe
from newton_lh2.fluid.pressure_drop import pressure_drop, darcy_friction_factor, homogeneous_two_phase_pressure_drop
from newton_lh2.fluid.pump import run_pump, PumpSpec
from newton_lh2.fluid.cavitation import cavitation_check


class TestPressureDrop:
    def test_laminar_regime(self):
        f, regime = darcy_friction_factor(1000.0, 1e-5)
        assert regime == "laminar"
        assert f == pytest.approx(64.0 / 1000.0)

    def test_turbulent_regime(self):
        f, regime = darcy_friction_factor(1e5, 1e-4)
        assert regime == "turbulent"
        assert 0.01 < f < 0.05

    def test_pressure_drop_scales_with_length(self):
        p_short = Pipe(length_m=5.0, inner_diameter_m=0.05)
        p_long = Pipe(length_m=50.0, inner_diameter_m=0.05)
        r_short = pressure_drop(p_short, 1.0, 71.0, 1.3e-5)
        r_long = pressure_drop(p_long, 1.0, 71.0, 1.3e-5)
        assert r_long.friction_Pa > r_short.friction_Pa

    def test_zero_flow_gives_only_elevation_term(self):
        p = Pipe(length_m=10.0, inner_diameter_m=0.05, elevation_change_m=2.0)
        r = pressure_drop(p, 0.0, 71.0, 1.3e-5)
        assert r.friction_Pa == 0.0
        assert r.elevation_Pa == pytest.approx(71.0 * 9.80665 * 2.0)

    def test_two_phase_pressure_drop_exceeds_liquid_only(self):
        p = Pipe(length_m=10.0, inner_diameter_m=0.03, minor_loss_K=1.0)
        liquid_only = pressure_drop(p, 0.5, 71.0, 1.3e-5)
        two_phase = homogeneous_two_phase_pressure_drop(p, 0.5, 0.1, 71.0, 1.2, 1.3e-5, 1.0e-6)
        assert two_phase.total_Pa > liquid_only.total_Pa

    def test_rejects_bad_geometry(self):
        with pytest.raises(ValueError):
            Pipe(length_m=-1.0, inner_diameter_m=0.05)


class TestPump:
    def test_pump_raises_pressure_and_temperature(self, props):
        inlet = props.state_TP(19.5, 1.3e5)
        r = run_pump(inlet, 6.0e5, 1.0, PumpSpec(efficiency=0.6, npsh_required_m=0.5), props=props)
        assert r.outlet.pressure_Pa == pytest.approx(6.0e5)
        assert r.outlet.temperature_K > inlet.temperature_K
        assert r.shaft_power_W > r.hydraulic_power_W  # inefficiency

    def test_lower_efficiency_means_more_temperature_rise(self, props):
        inlet = props.state_TP(19.5, 1.3e5)
        r_eff = run_pump(inlet, 6.0e5, 1.0, PumpSpec(efficiency=0.9, npsh_required_m=0.5), props=props)
        r_ineff = run_pump(inlet, 6.0e5, 1.0, PumpSpec(efficiency=0.4, npsh_required_m=0.5), props=props)
        assert r_ineff.temperature_rise_K > r_eff.temperature_rise_K

    def test_rejects_outlet_below_inlet_pressure(self, props):
        inlet = props.state_TP(19.5, 1.3e5)
        with pytest.raises(ValueError):
            run_pump(inlet, 1.0e5, 1.0, PumpSpec(), props=props)


class TestCavitation:
    def test_healthy_margin_not_at_risk(self, props):
        diag = cavitation_check(17.0, 3.0e5, 2.0, npsh_required_m=1.0, props=props)
        assert not diag.at_risk
        assert diag.subcooling_margin_K > 0

    def test_near_saturation_flags_risk(self, props):
        p_sat = props.saturation_pressure(20.0)
        diag = cavitation_check(20.0, p_sat, 2.0, npsh_required_m=1.0, props=props)
        assert diag.at_risk
        assert len(diag.warnings) > 0
