"""Density/energy analysis, sensitivity sweeps, Monte Carlo, telemetry, facility."""

import numpy as np
import pytest

from newton_lh2.analysis.density import volumetric_capacity_gain, summarize_densification
from newton_lh2.analysis.energy import summarize_energy_balance
from newton_lh2.analysis.sensitivity import run_parameter_sweep, SWEEPABLE_PARAMETERS
from newton_lh2.analysis.uncertainty import monte_carlo, normal, lognormal_relative, heat_leak_response
from newton_lh2.models.telemetry import (
    generate_telemetry, save_telemetry, load_telemetry, load_telemetry_window, replay_telemetry,
)
from newton_lh2.cryogenics.recirculation import ConditionerSetpoint
import newton_lh2.simulation.scenarios as scenarios


class TestDensityAnalysis:
    def test_volumetric_capacity_gain(self):
        gain = volumetric_capacity_gain(70.0, 75.0, tank_volume_m3=100.0)
        assert gain.additional_capacity_kg == pytest.approx(500.0)
        assert gain.additional_capacity_percent == pytest.approx(500.0 / 7000.0 * 100.0)

    def test_summarize_densification_from_trajectory(self, props):
        run = scenarios.scenario_c_controlled_densification(duration_s=500.0, timestep_s=20.0)
        result = summarize_densification(run.result.diagnostics, mass_processed_kg=500.0, props=props)
        assert result.delta_density_kg_m3 > 0


class TestEnergyAnalysis:
    def test_summarize_energy_balance(self):
        run = scenarios.scenario_e_recirculation(duration_s=300.0, timestep_s=10.0)
        summary = summarize_energy_balance(run.result.diagnostics, run.result.internal_energy_J)
        assert summary.total_cooling_duty_J > 0
        assert summary.duration_s == pytest.approx(300.0, rel=0.05)


class TestSensitivity:
    def test_sweep_returns_one_row_per_value(self):
        df = run_parameter_sweep("initial_temperature_K", [18.0, 20.0], duration_s=400.0, timestep_s=20.0)
        assert len(df) == 2
        assert set(df["value"]) == {18.0, 20.0}

    def test_higher_initial_temperature_gives_lower_final_density(self):
        df = run_parameter_sweep("initial_temperature_K", [18.0, 20.0], duration_s=400.0, timestep_s=20.0)
        df = df.sort_values("value")
        assert df["final_density_kg_m3"].iloc[0] > df["final_density_kg_m3"].iloc[1]

    def test_unknown_parameter_rejected(self):
        with pytest.raises(ValueError):
            run_parameter_sweep("not_a_real_parameter", [1, 2])


class TestUncertainty:
    def test_monte_carlo_statistics_are_self_consistent(self):
        dists = {"ambient_temperature_K": normal(293.15, 3.0)}
        result = monte_carlo(dists, heat_leak_response(), n=2000, seed=3)
        assert result.n == 2000
        assert result.p5 < result.median < result.p95
        assert result.std > 0

    def test_lognormal_relative_is_positive(self):
        rng = np.random.default_rng(0)
        sampler = lognormal_relative(3.0e-5, 0.25)
        samples = sampler(rng, 1000)
        assert (samples > 0).all()

    def test_reproducible_with_seed(self):
        dists = {"ambient_temperature_K": normal(293.15, 3.0)}
        r1 = monte_carlo(dists, heat_leak_response(), n=500, seed=99)
        r2 = monte_carlo(dists, heat_leak_response(), n=500, seed=99)
        assert r1.mean == r2.mean


class TestTelemetry:
    def test_generate_telemetry_has_true_and_measured_columns(self):
        run = scenarios.scenario_e_recirculation(duration_s=200.0, timestep_s=10.0)
        tel = generate_telemetry(run.result.diagnostics, seed=1)
        assert "temperature_K_true" in tel.columns
        assert "temperature_K_measured" in tel.columns
        assert len(tel) == len(run.result.diagnostics)

    def test_save_load_roundtrip(self, tmp_path):
        run = scenarios.scenario_e_recirculation(duration_s=200.0, timestep_s=10.0)
        tel = generate_telemetry(run.result.diagnostics, seed=1)
        path = str(tmp_path / "telemetry.parquet")
        save_telemetry(tel, path)
        tel2 = load_telemetry(path)
        assert len(tel2) == len(tel)

    def test_load_telemetry_window_filters_time_and_channels(self, tmp_path):
        run = scenarios.scenario_e_recirculation(duration_s=500.0, timestep_s=10.0)
        tel = generate_telemetry(run.result.diagnostics, seed=1)
        path = str(tmp_path / "telemetry.parquet")
        save_telemetry(tel, path)

        windowed = load_telemetry_window(
            path, t_min_s=100.0, t_max_s=300.0, channels=("time_s", "temperature_K_true")
        )
        assert windowed["time_s"].min() >= 100.0
        assert windowed["time_s"].max() <= 300.0
        assert list(windowed.columns) == ["time_s", "temperature_K_true"]

    def test_replay_reconstructs_a_trajectory(self, props):
        run = scenarios.scenario_e_recirculation(duration_s=300.0, timestep_s=10.0)
        tel = generate_telemetry(run.result.diagnostics, seed=1)
        facility = scenarios._standard_facility(initial_temperature_K=19.0, initial_mass_kg=4200.0)
        setpoint = ConditionerSetpoint(
            mode="specified_outlet_temperature", outlet_temperature_K=17.0,
            coolant_inlet=props.state_TP(14.0, 1.5e5), coolant_mass_flow_kg_s=0.6,
        )
        replay_result = replay_telemetry(tel, facility, setpoint, timestep_s=10.0)
        assert replay_result.conservation.mass_pass
        assert len(replay_result.diagnostics) > 1
