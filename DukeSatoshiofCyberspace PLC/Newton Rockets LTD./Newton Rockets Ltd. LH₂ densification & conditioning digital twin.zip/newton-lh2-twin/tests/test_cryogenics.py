"""Tank, heat leak, insulation, heat exchanger, densification, recirculation."""

import pytest

from newton_lh2.cryogenics.tank import CryoTank, TankGeometry, TankStateError
from newton_lh2.cryogenics.insulation import InsulationSystem
from newton_lh2.cryogenics.heat_leak import HeatLeakConfig, heat_leak
from newton_lh2.cryogenics.heat_exchanger import run_specified_outlet_temperature, run_specified_UA
from newton_lh2.cryogenics.densification import densify
from newton_lh2.cryogenics.recirculation import (
    run_recirculation_loop, RecirculationLoopConfig, ConditionerSetpoint, FlowInfeasibleError,
)
from newton_lh2.fluid.pipe import Pipe
from newton_lh2.fluid.pump import PumpSpec
from newton_lh2.thermodynamics.phase import Phase


@pytest.fixture
def tank(props):
    geom = TankGeometry(volume_m3=100.0, diameter_m=4.5)
    ins = InsulationSystem.mli_vacuum_jacket(area_m2=90.0)
    return CryoTank(geom, ins, ambient_temperature_K=293.0, initial_mass_kg=4500.0, initial_temperature_K=20.0)


class TestTankGeometry:
    def test_rejects_nonpositive_volume(self):
        with pytest.raises(ValueError):
            TankGeometry(volume_m3=-1.0)

    def test_liquid_level(self):
        g = TankGeometry(volume_m3=100.0, diameter_m=4.5)
        level = g.liquid_level_m(g.volume_m3 * 0.5)
        assert 0 < level < g.height_m


class TestCryoTank:
    def test_construction_rejects_infeasible_fill(self):
        geom = TankGeometry(volume_m3=1.0, diameter_m=1.0)
        ins = InsulationSystem.mli_vacuum_jacket(area_m2=5.0)
        with pytest.raises(ValueError):
            # far too much mass for 1 m3 at 20 K (max ~71 kg/m3 liquid)
            CryoTank(geom, ins, ambient_temperature_K=293.0, initial_mass_kg=500.0, initial_temperature_K=20.0)

    def test_state_reports_two_phase_by_default(self, tank):
        st = tank.state()
        assert st.phase in (Phase.TWO_PHASE, Phase.SATURATED_LIQUID)
        assert 0.0 <= st.fill_fraction <= 1.0
        assert st.mass_liquid_kg + st.mass_vapor_kg == pytest.approx(tank.M, rel=1e-9)

    def test_passive_self_pressurization(self, tank):
        """With no active cooling, heat leak alone must raise T, P over time; mass is conserved."""
        M0, U0 = tank.M, tank.U
        M, U = M0, U0
        for _ in range(500):
            dM, dU = tank.derivative()
            M += dM * 5.0
            U += dU * 5.0
            tank.set_state(M, U)
        st = tank.state()
        assert st.temperature_K > 20.0
        assert st.pressure_Pa > 0.934e5 * 0.99  # started near NBP saturation pressure
        assert tank.M == pytest.approx(M0, rel=1e-9)

    def test_derivative_zero_flow_gives_only_heat_leak(self, tank):
        dM, dU = tank.derivative()
        assert dM == 0.0
        assert dU > 0.0  # passive heat leak only

    def test_loop_cooling_reduces_energy(self, tank):
        # A loop returning much colder liquid than it withdrew must net-cool the tank.
        dM, dU_passive = tank.derivative()
        dM2, dU_cooled = tank.derivative(m_dot_loop_kg_s=1.0, h_loop_return_J_kg=-50000.0)
        assert dU_cooled < dU_passive

    def test_outlet_withdrawal_reduces_mass_only(self, tank):
        dM, dU = tank.derivative(m_dot_outlet_kg_s=0.5)
        assert dM == pytest.approx(-0.5)

    def test_flash_matches_direct_state(self, tank):
        s1 = tank.flash(tank.M, tank.U)
        s2 = tank.state()
        assert s1.temperature_K == pytest.approx(s2.temperature_K)

    def test_flash_rejects_nonpositive_mass(self, tank):
        with pytest.raises(TankStateError):
            tank.flash(-1.0, tank.U)


class TestHeatLeak:
    def test_all_contributions_toggle_off_gives_zero(self):
        ins = InsulationSystem.mli_vacuum_jacket(area_m2=50.0)
        cfg = HeatLeakConfig(
            enable_conduction=False, enable_radiation=False, enable_penetrations=False,
            enable_piping=False, enable_instrumentation=False, enable_environmental=False,
        )
        budget = heat_leak(ins, 293.0, 20.0, cfg)
        assert budget.total_W == 0.0

    def test_degraded_insulation_increases_leak(self):
        base = InsulationSystem.mli_vacuum_jacket(area_m2=50.0)
        degraded = InsulationSystem.degraded(base, vacuum_loss_factor=10.0)
        b1 = heat_leak(base, 293.0, 20.0)
        b2 = heat_leak(degraded, 293.0, 20.0)
        assert b2.conduction_W > b1.conduction_W

    def test_more_mli_layers_reduce_radiation(self):
        few = InsulationSystem.mli_vacuum_jacket(area_m2=50.0, layer_count=10)
        many = InsulationSystem.mli_vacuum_jacket(area_m2=50.0, layer_count=100)
        assert heat_leak(many, 293.0, 20.0).radiation_W < heat_leak(few, 293.0, 20.0).radiation_W

    def test_rejects_inverted_temperatures(self):
        ins = InsulationSystem.mli_vacuum_jacket(area_m2=50.0)
        with pytest.raises(ValueError):
            heat_leak(ins, 20.0, 293.0)


class TestHeatExchanger:
    def test_specified_outlet_temperature_cools_process(self, props):
        process_in = props.state_TP(20.0, 1.3e5)
        coolant_in = props.state_TP(14.0, 1.5e5)
        r = run_specified_outlet_temperature(process_in, 1.0, 17.0, coolant_in, 0.5, props=props)
        assert r.process_outlet.temperature_K == pytest.approx(17.0, abs=1e-6)
        assert r.duty_W > 0
        assert r.coolant_outlet.temperature_K > coolant_in.temperature_K

    def test_specified_ua_effectiveness_between_0_and_1(self, props):
        process_in = props.state_TP(20.0, 1.3e5)
        coolant_in = props.state_TP(15.0, 1.5e5)
        r = run_specified_UA(process_in, 1.0, coolant_in, 0.5, UA_W_K=200.0, props=props)
        assert 0.0 < r.effectiveness < 1.0
        assert r.process_outlet.temperature_K < process_in.temperature_K

    def test_ua_rejects_inverted_streams(self, props):
        cold = props.state_TP(14.0, 1.5e5)
        warm = props.state_TP(20.0, 1.3e5)
        with pytest.raises(ValueError):
            run_specified_UA(cold, 1.0, warm, 0.5, UA_W_K=100.0, props=props)


class TestDensification:
    def test_cooling_increases_density(self, props):
        s0 = props.state_TP(20.0, 1.3e5)
        s1 = props.state_TP(16.0, 1.3e5)
        result = densify(s0, s1, mass_processed_kg=1000.0, props=props)
        assert result.delta_density_kg_m3 > 0
        assert result.heat_removed_J > 0
        assert 0.0 < result.process_efficiency <= 1.0

    def test_rejects_nonpositive_mass(self, props):
        s0 = props.state_TP(20.0, 1.3e5)
        with pytest.raises(ValueError):
            densify(s0, s0, mass_processed_kg=0.0, props=props)


class TestRecirculationLoop:
    def _config(self, withdrawal_id=0.05):
        return RecirculationLoopConfig(
            withdrawal_pipe=Pipe(length_m=15.0, inner_diameter_m=withdrawal_id, minor_loss_K=2.0),
            return_pipe=Pipe(length_m=18.0, inner_diameter_m=0.05, minor_loss_K=3.0),
            pump_spec=PumpSpec(efficiency=0.6, npsh_required_m=0.3, subcooling_safety_margin_K=0.2),
        )

    def test_full_loop_cools_and_conserves_mass_flow(self, props):
        tank_liquid = props.state_TP(19.5, 1.3e5)
        setpoint = ConditionerSetpoint(
            mode="specified_outlet_temperature", outlet_temperature_K=17.0,
            coolant_inlet=props.state_TP(14.0, 1.5e5), coolant_mass_flow_kg_s=0.6,
        )
        result = run_recirculation_loop(tank_liquid, 1.0, self._config(), setpoint, return_pressure_margin_Pa=2e4, props=props)
        assert result.return_state.temperature_K < tank_liquid.temperature_K
        for c in result.components:
            assert c.mass_flow_kg_s == pytest.approx(1.0) or c.name == "IDLE"

    def test_undersized_pipe_raises_clean_error(self, props):
        tank_liquid = props.state_TP(20.0, 1.3e5)
        setpoint = ConditionerSetpoint(
            mode="specified_outlet_temperature", outlet_temperature_K=17.0,
            coolant_inlet=props.state_TP(14.0, 1.5e5), coolant_mass_flow_kg_s=0.6,
        )
        with pytest.raises(FlowInfeasibleError):
            run_recirculation_loop(tank_liquid, 1.5, self._config(withdrawal_id=0.015), setpoint, props=props)

    def test_zero_flow_is_idle(self, props):
        tank_liquid = props.state_TP(20.0, 1.3e5)
        setpoint = ConditionerSetpoint(
            mode="specified_outlet_temperature", outlet_temperature_K=17.0,
            coolant_inlet=props.state_TP(14.0, 1.5e5), coolant_mass_flow_kg_s=0.6,
        )
        result = run_recirculation_loop(tank_liquid, 0.0, self._config(), setpoint, props=props)
        assert result.total_cooling_duty_W == 0.0
        assert result.total_shaft_power_W == 0.0
