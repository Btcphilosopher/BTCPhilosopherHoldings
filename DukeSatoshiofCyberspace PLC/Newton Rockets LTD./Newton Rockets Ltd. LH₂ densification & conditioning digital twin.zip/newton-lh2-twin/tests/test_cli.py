"""CLI subcommands run end-to-end and return success exit codes."""

import pytest

from newton_lh2.cli import build_parser, main


def run_cli(args):
    return main(args)


class TestCLI:
    def test_help_does_not_crash(self):
        parser = build_parser()
        with pytest.raises(SystemExit) as exc:
            parser.parse_args(["--help"])
        assert exc.value.code == 0

    def test_validate(self):
        assert run_cli(["validate"]) == 0

    def test_simulate_short_run(self):
        assert run_cli([
            "simulate", "--duration", "200", "--timestep", "20",
            "--tank-volume", "50", "--initial-mass", "2200",
        ]) == 0

    def test_scenario_cooldown_alias(self):
        assert run_cli(["scenario", "cooldown"]) == 0

    def test_scenario_recirculation(self, tmp_path):
        out = str(tmp_path / "out.csv")
        assert run_cli(["scenario", "recirculation", "--output", out]) == 0
        assert (tmp_path / "out.csv").exists()

    def test_unknown_scenario_returns_error(self):
        parser = build_parser()
        with pytest.raises(SystemExit):
            parser.parse_args(["scenario", "not-a-scenario"])

    def test_sensitivity(self, tmp_path):
        out = str(tmp_path / "sens.csv")
        code = run_cli([
            "sensitivity", "--parameter", "initial_temperature_K", "--values", "18,20",
            "--duration", "300", "--timestep", "20", "--output", out,
        ])
        assert code == 0
        assert (tmp_path / "sens.csv").exists()

    def test_monte_carlo(self):
        assert run_cli(["monte-carlo", "--n", "500"]) == 0

    def test_generate_telemetry_and_replay(self, tmp_path):
        tel_path = str(tmp_path / "telemetry.parquet")
        assert run_cli(["generate-telemetry", "--scenario", "recirculation", "--output", tel_path]) == 0
        assert run_cli(["replay", tel_path, "--timestep", "10"]) == 0
