# data/

Scratch output directory for generated artefacts: synthetic telemetry
(`newton-lh2 generate-telemetry`), CSV/Parquet exports from
`newton-lh2 simulate`/`scenario`/`sensitivity`/`monte-carlo`, etc.

Nothing in this directory is committed as reference data; it is created
on demand by the CLI and example scripts.
